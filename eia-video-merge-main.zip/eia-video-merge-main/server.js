import express from "express";
import { spawn } from "node:child_process";
import { createWriteStream } from "node:fs";
import { readFile, unlink } from "node:fs/promises";
import { Readable } from "node:stream";
import { pipeline } from "node:stream/promises";
import { S3Client, PutObjectCommand } from "@aws-sdk/client-s3";

const {
  R2_ACCESS_KEY_ID,
  R2_SECRET,
  R2_ENDPOINT,
  R2_BUCKET,
  MERGE_SECRET,
} = process.env;

const PORT = process.env.PORT || 10000;

const s3 = new S3Client({
  region: "auto",
  endpoint: R2_ENDPOINT,
  credentials: {
    accessKeyId: R2_ACCESS_KEY_ID,
    secretAccessKey: R2_SECRET,
  },
});

const app = express();
app.use(express.json({ limit: "1mb" }));

app.get("/", (_req, res) => {
  res.status(200).json({ status: "alive" });
});

async function downloadToFile(url, dest) {
  const resp = await fetch(url);
  if (!resp.ok || !resp.body) {
    const err = new Error(`fetch failed ${resp.status} for ${url}`);
    err.status = resp.status;
    throw err;
  }
  await pipeline(Readable.fromWeb(resp.body), createWriteStream(dest));
}

function runFfmpeg(args) {
  return new Promise((resolve) => {
    const proc = spawn("ffmpeg", args);
    let stderr = "";
    proc.stderr.on("data", (chunk) => {
      stderr += chunk.toString();
      if (stderr.length > 64_000) {
        stderr = stderr.slice(-64_000);
      }
    });
    proc.on("error", (err) => resolve({ code: -1, stderr: String(err) }));
    proc.on("close", (code) => resolve({ code, stderr }));
  });
}

async function safeUnlink(path) {
  try {
    await unlink(path);
  } catch {
    // ignore
  }
}

app.post("/merge", async (req, res) => {
  if (!MERGE_SECRET || req.header("x-merge-secret") !== MERGE_SECRET) {
    return res.status(401).json({ ok: false, error: "unauthorized" });
  }

  const { video_url, audio_url, output_key } = req.body || {};
  if (!video_url || !audio_url || !output_key) {
    return res.status(400).json({
      ok: false,
      error: "video_url, audio_url, and output_key are required",
    });
  }

  const inVideo = "/tmp/in_video";
  const inAudio = "/tmp/in_audio";
  const outFile = "/tmp/out.mp4";

  console.log(`[merge] start output_key=${output_key}`);

  try {
    try {
      await downloadToFile(video_url, inVideo);
      await downloadToFile(audio_url, inAudio);
    } catch (err) {
      console.log(`[merge] download failed output_key=${output_key} err=${err.message}`);
      return res.status(502).json({
        ok: false,
        error: "failed to download input",
        detail: err.message,
      });
    }

    const baseArgs = [
      "-y",
      "-i", inVideo,
      "-i", inAudio,
      "-map", "0:v:0",
      "-map", "1:a:0",
    ];

    let result = await runFfmpeg([
      ...baseArgs,
      "-c:v", "copy",
      "-c:a", "aac",
      "-shortest",
      outFile,
    ]);

    if (result.code !== 0) {
      console.log(
        `[merge] ffmpeg copy failed output_key=${output_key} code=${result.code}; retrying with libx264`
      );
      result = await runFfmpeg([
        ...baseArgs,
        "-c:v", "libx264",
        "-pix_fmt", "yuv420p",
        "-c:a", "aac",
        "-shortest",
        outFile,
      ]);
    }

    if (result.code !== 0) {
      const tail = result.stderr.split(/\r?\n/).slice(-30).join("\n");
      console.log(
        `[merge] ffmpeg failed output_key=${output_key} code=${result.code}`
      );
      return res.status(500).json({
        ok: false,
        error: "ffmpeg failed",
        exit_code: result.code,
        stderr_tail: tail,
      });
    }

    const body = await readFile(outFile);
    await s3.send(
      new PutObjectCommand({
        Bucket: R2_BUCKET,
        Key: output_key,
        Body: body,
        ContentType: "video/mp4",
      })
    );

    console.log(
      `[merge] success output_key=${output_key} ffmpeg_code=${result.code} bytes=${body.length}`
    );
    return res.status(200).json({ ok: true, output_key });
  } catch (err) {
    console.log(`[merge] error output_key=${output_key} err=${err.message}`);
    return res.status(500).json({ ok: false, error: err.message });
  } finally {
    await Promise.all([safeUnlink(inVideo), safeUnlink(inAudio), safeUnlink(outFile)]);
  }
});

app.listen(PORT, () => {
  console.log(`eia-video-merge listening on :${PORT}`);
});
