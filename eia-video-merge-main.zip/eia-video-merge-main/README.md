# eia-video-merge

EIA interview video + audio merge service.

A tiny Node.js + Express web service with one job: download a silent video file
and a separate audio file, mux them into a single MP4 using `ffmpeg`, upload the
result to Cloudflare R2, and return the R2 object key.

Deployed on **Render** as a Web Service (built from the included `Dockerfile`,
which installs `ffmpeg` on top of `node:20-slim`).

## Endpoints

### `GET /`
Health check. Returns `200 {"status":"alive"}`.

### `POST /merge`
Auth: header `x-merge-secret` must equal `MERGE_SECRET`.

Request body (JSON):
```json
{
  "video_url": "https://.../silent-video.mp4",
  "audio_url": "https://.../audio.wav",
  "output_key": "merged/{response_id}/{call_id}.mp4"
}
```

On success returns `200 {"ok": true, "output_key": "..."}`.

## Environment variables

All read from `process.env` — nothing is hardcoded.

| Var | Purpose |
| --- | --- |
| `R2_ACCESS_KEY_ID` | Cloudflare R2 access key id |
| `R2_SECRET` | Cloudflare R2 secret access key |
| `R2_ENDPOINT` | R2 S3-compatible endpoint, e.g. `https://<account>.r2.cloudflarestorage.com` |
| `R2_BUCKET` | Target R2 bucket name |
| `MERGE_SECRET` | Shared secret required in the `x-merge-secret` request header |
| `PORT` | Optional; defaults to `10000` |

Set these in the Render dashboard — do **not** commit them.
