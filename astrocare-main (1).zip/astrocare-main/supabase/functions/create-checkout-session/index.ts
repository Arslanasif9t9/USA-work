// Creates a Stripe Embedded Checkout Session for a wallet recharge.
// Accepts either:
//   { priceId: "recharge_500_inr" }   -> resolves price via lookup_keys
//   { amount: 750 }                    -> creates an inline price_data line item
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.45.0";
import { createStripeClient, corsHeaders } from "../_shared/stripe.ts";

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const body = await req.json().catch(() => ({}));
    const priceId: string | undefined = body.priceId;
    const customAmount: number | undefined =
      body.amount != null ? Number(body.amount) : undefined;
    const environment: "sandbox" | "live" =
      body.environment === "live" ? "live" : "sandbox";

    const origin =
      req.headers.get("origin") ||
      req.headers.get("referer")?.replace(/\/$/, "") ||
      "";
    const returnUrl =
      body.returnUrl ||
      `${origin}/recharge/success?session_id={CHECKOUT_SESSION_ID}`;

    // Auth: identify the user so we can stamp metadata for the webhook.
    const authHeader = req.headers.get("Authorization");
    let userId: string | null = null;
    let userEmail: string | undefined;
    if (authHeader) {
      const supabase = createClient(
        Deno.env.get("SUPABASE_URL")!,
        Deno.env.get("SUPABASE_ANON_KEY")!,
        { global: { headers: { Authorization: authHeader } } }
      );
      const { data } = await supabase.auth.getUser();
      if (data?.user) {
        userId = data.user.id;
        userEmail = data.user.email ?? undefined;
      }
    }
    if (!userId) {
      return jsonResponse({ error: "Unauthorized" }, 401);
    }

    const stripe = createStripeClient(environment);

    let lineItems: unknown[];
    let purchaseKind: "pack" | "custom";
    let metadata: Record<string, string> = { user_id: userId };

    if (priceId) {
      // Pack purchase — resolve via lookup_keys
      if (!/^[a-zA-Z0-9_-]+$/.test(priceId)) {
        return jsonResponse({ error: "Invalid priceId" }, 400);
      }
      const prices = await stripe.prices.list({ lookup_keys: [priceId] });
      if (!prices.data.length) {
        return jsonResponse({ error: "Price not found" }, 404);
      }
      lineItems = [{ price: prices.data[0].id, quantity: 1 }];
      purchaseKind = "pack";
      metadata.price_id = priceId;
    } else {
      // Custom amount recharge
      if (
        !Number.isFinite(customAmount) ||
        (customAmount as number) < 10 ||
        (customAmount as number) > 100000
      ) {
        return jsonResponse(
          { error: "Amount must be between ₹10 and ₹1,00,000" },
          400
        );
      }
      lineItems = [
        {
          price_data: {
            currency: "inr",
            product_data: {
              name: "AstroGuide Wallet Recharge",
              description: `Add ₹${customAmount} to your wallet`,
            },
            unit_amount: Math.round((customAmount as number) * 100),
          },
          quantity: 1,
        },
      ];
      purchaseKind = "custom";
      metadata.amount = String(customAmount);
    }

    metadata.purchase_kind = purchaseKind;

    const session = await stripe.checkout.sessions.create({
      ui_mode: "embedded",
      mode: "payment",
      line_items: lineItems,
      return_url: returnUrl,
      ...(userEmail && { customer_email: userEmail }),
      metadata,
    });

    return jsonResponse({
      clientSecret: session.client_secret,
      sessionId: session.id,
    });
  } catch (err) {
    console.error("create-checkout-session error", err);
    return jsonResponse({ error: (err as Error).message }, 500);
  }
});

function jsonResponse(data: unknown, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { ...corsHeaders, "Content-Type": "application/json" },
  });
}
