import { createClient } from "npm:@supabase/supabase-js@2.45.0";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
const SERVICE_ROLE_KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
const TWILIO_ACCOUNT_SID = Deno.env.get("TWILIO_ACCOUNT_SID");
const TWILIO_AUTH_TOKEN = Deno.env.get("TWILIO_AUTH_TOKEN");
const TWILIO_PHONE_NUMBER = Deno.env.get("TWILIO_PHONE_NUMBER");

const E164_RE = /^\+[1-9]\d{7,14}$/;

async function hashOtp(otp: string, salt: string): Promise<string> {
  const data = new TextEncoder().encode(`${salt}:${otp}`);
  const buf = await crypto.subtle.digest("SHA-256", data);
  return Array.from(new Uint8Array(buf))
    .map((b) => b.toString(16).padStart(2, "0"))
    .join("");
}

function jsonResponse(body: unknown, status = 200) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { ...corsHeaders, "Content-Type": "application/json" },
  });
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });
  if (req.method !== "POST") return jsonResponse({ error: "Method not allowed" }, 405);

  try {
    const authHeader = req.headers.get("Authorization") ?? "";
    const userClient = createClient(SUPABASE_URL, Deno.env.get("SUPABASE_ANON_KEY")!, {
      global: { headers: { Authorization: authHeader } },
    });
    const { data: userData, error: userErr } = await userClient.auth.getUser();
    if (userErr || !userData.user) return jsonResponse({ error: "Not authenticated" }, 401);
    const user = userData.user;

    const body = (await req.json().catch(() => ({}))) as {
      phone_number?: string;
      user_type?: "customer" | "astrologer";
    };
    const phone = (body.phone_number ?? "").trim();
    const userType = body.user_type === "astrologer" ? "astrologer" : "customer";

    if (!E164_RE.test(phone)) {
      return jsonResponse(
        { error: "Phone must be in E.164 format like +919876543210" },
        400,
      );
    }

    const admin = createClient(SUPABASE_URL, SERVICE_ROLE_KEY);

    // Rate limit: max 5 OTPs / phone / 24h
    const since = new Date(Date.now() - 24 * 3600 * 1000).toISOString();
    const { count } = await admin
      .from("phone_verifications")
      .select("id", { count: "exact", head: true })
      .eq("phone_number", phone)
      .gte("created_at", since);
    if ((count ?? 0) >= 5) {
      return jsonResponse(
        { error: "Too many OTP requests. Try again in a few hours." },
        429,
      );
    }

    const otp = String(Math.floor(100000 + Math.random() * 900000));
    const otpHash = await hashOtp(otp, user.id);
    const expiresAt = new Date(Date.now() + 10 * 60 * 1000).toISOString();

    const { error: insErr } = await admin.from("phone_verifications").insert({
      user_id: user.id,
      user_type: userType,
      phone_number: phone,
      otp_hash: otpHash,
      expires_at: expiresAt,
    });
    if (insErr) {
      console.error("insert verification failed", insErr);
      return jsonResponse({ error: "Could not start verification" }, 500);
    }

    const haveTwilio = !!(TWILIO_ACCOUNT_SID && TWILIO_AUTH_TOKEN && TWILIO_PHONE_NUMBER);
    let mode: "sms" | "simulation" = "simulation";
    let devOtp: string | null = otp;

    if (haveTwilio) {
      const twilioUrl =
        `https://api.twilio.com/2010-04-01/Accounts/${TWILIO_ACCOUNT_SID}/Messages.json`;
      const auth = btoa(`${TWILIO_ACCOUNT_SID}:${TWILIO_AUTH_TOKEN}`);
      const form = new URLSearchParams({
        To: phone,
        From: TWILIO_PHONE_NUMBER!,
        Body:
          `Your AstroGuide verification code is ${otp}. Valid for 10 minutes. Do not share this code.`,
      });
      const tw = await fetch(twilioUrl, {
        method: "POST",
        headers: {
          Authorization: `Basic ${auth}`,
          "Content-Type": "application/x-www-form-urlencoded",
        },
        body: form,
      });
      if (!tw.ok) {
        const errText = await tw.text();
        console.error("twilio sms send failed", tw.status, errText);
        // Fall back to simulation so dev can still verify
        mode = "simulation";
      } else {
        await tw.text();
        mode = "sms";
        devOtp = null;
      }
    }

    return jsonResponse({
      ok: true,
      mode,
      // Only returned in simulation so the dev flow still works
      dev_otp: mode === "simulation" ? devOtp : undefined,
      expires_at: expiresAt,
    });
  } catch (e) {
    console.error("send-phone-otp error", e);
    return jsonResponse({ error: "Unexpected error" }, 500);
  }
});
