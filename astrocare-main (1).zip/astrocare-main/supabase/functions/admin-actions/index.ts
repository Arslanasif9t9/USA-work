// Privileged admin actions that need the service role.
// All actions verify the caller is an active admin with the right permission.
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.45.0";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });

  try {
    const auth = req.headers.get("Authorization") || "";
    const token = auth.replace("Bearer ", "");
    if (!token) return j({ ok: false, error: "Missing auth" }, 401);

    const url = Deno.env.get("SUPABASE_URL")!;
    const svc = createClient(url, Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!);
    const { data: who, error: whoErr } = await svc.auth.getUser(token);
    if (whoErr || !who.user) return j({ ok: false, error: "Invalid session" }, 401);

    const { data: admin } = await svc.from("admin_users")
      .select("*").eq("user_id", who.user.id).maybeSingle();
    if (!admin || !admin.is_active) return j({ ok: false, error: "Not an admin" }, 403);

    const hasPerm = (k: string) =>
      admin.role === "master_admin" ||
      (Array.isArray(admin.permissions) && (admin.permissions as string[]).includes(k));

    const body = await req.json().catch(() => ({}));
    const action = String(body.action || "");

    // ---------- ASTROLOGERS ----------
    if (action === "astrologer.set_status") {
      if (!hasPerm("manage_astrologers")) return j(forbidden, 403);
      const { astrologer_id, status, reason } = body;
      if (!["pending", "approved", "rejected", "blocked"].includes(status))
        return j({ ok: false, error: "Invalid status" }, 400);

      const patch: any = { approval_status: status, updated_at: new Date().toISOString() };
      if (status === "rejected" || status === "blocked") patch.rejection_reason = reason || null;
      if (status === "approved") patch.rejection_reason = null;
      // If blocked, also force them offline so customers can't request sessions
      if (status === "blocked") {
        patch.is_online = false;
        patch.is_chat_online = false;
        patch.accepting_calls = false;
        patch.accepting_chat = false;
        patch.status = "offline";
      }

      const { data: ast } = await svc.from("astrologers").select("user_id, display_name").eq("id", astrologer_id).maybeSingle();
      const { error } = await svc.from("astrologers").update(patch).eq("id", astrologer_id);
      if (error) return j({ ok: false, error: error.message }, 400);

      // Force-logout the astrologer immediately if blocked or rejected
      if (ast?.user_id && (status === "blocked" || status === "rejected")) {
        try { await svc.auth.admin.updateUserById(ast.user_id, { ban_duration: "876000h" }); } catch (_) {}
        try { await svc.auth.admin.signOut(ast.user_id); } catch (_) {}
      } else if (ast?.user_id && status === "approved") {
        try { await svc.auth.admin.updateUserById(ast.user_id, { ban_duration: "none" }); } catch (_) {}
      }

      if (ast?.user_id) {
        const titles: Record<string, string> = {
          approved: "Your application is approved 🎉",
          rejected: "Your application was rejected",
          blocked:  "Your account has been blocked",
          pending:  "Your account is under review",
        };
        await svc.from("notifications").insert({
          user_id: ast.user_id,
          type: "astrologer_status",
          title: titles[status],
          body: reason || (status === "approved" ? "You can now go online and accept consultations." : null),
          link: "/astrologer/overview",
        });
      }
      await log(svc, admin.id, `astrologer.${status}`, "astrologer", astrologer_id, { reason });
      return j({ ok: true });
    }

    if (action === "astrologer.update_profile") {
      if (!hasPerm("manage_astrologers")) return j(forbidden, 403);
      const { astrologer_id, patch } = body;
      const allowed = ["display_name", "bio", "base_rate_per_min", "chat_rate_per_min",
        "specializations", "languages", "avatar_url", "experience_years", "focus_area", "education"];
      const clean: any = {};
      for (const k of allowed) if (k in (patch || {})) clean[k] = patch[k];
      clean.updated_at = new Date().toISOString();
      const { error } = await svc.from("astrologers").update(clean).eq("id", astrologer_id);
      if (error) return j({ ok: false, error: error.message }, 400);
      await log(svc, admin.id, "astrologer.update_profile", "astrologer", astrologer_id, clean);
      return j({ ok: true });
    }

    if (action === "send_notification") {
      if (!hasPerm("manage_astrologers") && !hasPerm("manage_customers")) return j(forbidden, 403);
      const { user_id, title, body: msg, link } = body;
      if (!user_id || !title) return j({ ok: false, error: "Missing fields" }, 400);
      await svc.from("notifications").insert({
        user_id, type: "admin_message", title, body: msg || null, link: link || null,
      });
      await log(svc, admin.id, "notification.send", "user", user_id, { title });
      return j({ ok: true });
    }

    // ---------- CUSTOMERS ----------
    if (action === "customer.set_block") {
      if (!hasPerm("manage_customers")) return j(forbidden, 403);
      const { user_id, blocked, reason } = body;
      const patch: any = { is_blocked: !!blocked };
      if (blocked) { patch.blocked_reason = reason || null; patch.blocked_at = new Date().toISOString(); }
      else { patch.blocked_reason = null; patch.blocked_at = null; }
      const { error } = await svc.from("profiles").update(patch).eq("id", user_id);
      if (error) return j({ ok: false, error: error.message }, 400);
      // Also disable auth so they can't log in. Force-logout existing sessions immediately.
      await svc.auth.admin.updateUserById(user_id, { ban_duration: blocked ? "876000h" : "none" });
      if (blocked) {
        try { await svc.auth.admin.signOut(user_id); } catch (_) { /* best effort */ }
      }
      await log(svc, admin.id, blocked ? "customer.block" : "customer.unblock", "user", user_id, { reason });
      return j({ ok: true });
    }

    // ---------- WALLET ADJUSTMENT REQUESTS (regular admin -> finance) ----------
    if (action === "wallet_request.create") {
      if (!hasPerm("manage_wallet")) return j(forbidden, 403);
      const { target_user_id, target_user_type, amount, reason } = body;
      const amt = Number(amount);
      if (!target_user_id || !["customer","astrologer"].includes(target_user_type) || !amt)
        return j({ ok: false, error: "Invalid input" }, 400);
      const limit = (admin as any).max_wallet_adjustment;
      if (limit && Math.abs(amt) > Number(limit))
        return j({ ok: false, error: `Amount exceeds your max of ₹${limit}` }, 400);
      const { error } = await svc.from("wallet_adjustment_requests").insert({
        requested_by_admin_id: admin.id,
        target_user_id, target_user_type, amount: amt, reason: reason || null,
        status: "pending",
      });
      if (error) return j({ ok: false, error: error.message }, 400);
      await log(svc, admin.id, "wallet_request.create", "user", target_user_id, { amount: amt, reason });
      return j({ ok: true });
    }

    if (action === "wallet_request.review") {
      // master_admin or finance_admin
      if (admin.role !== "master_admin" && admin.role !== "finance_admin")
        return j(forbidden, 403);
      const { request_id, decision, note } = body;
      if (!["approved","rejected"].includes(decision))
        return j({ ok: false, error: "Invalid decision" }, 400);
      const { data: r } = await svc.from("wallet_adjustment_requests")
        .select("*").eq("id", request_id).maybeSingle();
      if (!r) return j({ ok: false, error: "Not found" }, 404);
      if (r.status !== "pending") return j({ ok: false, error: "Already reviewed" }, 400);

      if (decision === "approved") {
        const direction = Number(r.amount) >= 0 ? "credit" : "debit";
        const { error: rpcErr } = await svc.rpc("admin_adjust_wallet", {
          _user_id: r.target_user_id,
          _amount: Math.abs(Number(r.amount)),
          _reason: `Approved request: ${r.reason || ""}`,
          _direction: direction,
        });
        if (rpcErr) return j({ ok: false, error: rpcErr.message }, 400);
      }
      await svc.from("wallet_adjustment_requests").update({
        status: decision,
        reviewed_by_admin_id: admin.id,
        reviewed_at: new Date().toISOString(),
        review_note: note || null,
      }).eq("id", request_id);
      await log(svc, admin.id, `wallet_request.${decision}`, "wallet_adjustment", request_id, { note });
      return j({ ok: true });
    }

    // ---------- REVIEWS ----------
    if (action === "review.moderate") {
      if (!hasPerm("manage_reviews")) return j(forbidden, 403);
      const { review_id, status, reason } = body;
      if (!["approved", "rejected", "pending"].includes(status))
        return j({ ok: false, error: "Invalid status" }, 400);
      const { error } = await svc.from("reviews").update({
        moderation_status: status,
        rejection_reason: status === "rejected" ? reason || null : null,
        moderated_at: new Date().toISOString(),
        moderated_by: who.user.id,
      }).eq("id", review_id);
      if (error) return j({ ok: false, error: error.message }, 400);
      await log(svc, admin.id, `review.${status}`, "review", review_id, { reason });
      return j({ ok: true });
    }

    if (action === "review.delete") {
      if (!hasPerm("manage_reviews")) return j(forbidden, 403);
      const { review_id } = body;
      const { error } = await svc.from("reviews").delete().eq("id", review_id);
      if (error) return j({ ok: false, error: error.message }, 400);
      await log(svc, admin.id, "review.delete", "review", review_id, {});
      return j({ ok: true });
    }

    // ---------- SUPPORT ----------
    if (action === "support.reply") {
      if (!hasPerm("manage_support")) return j(forbidden, 403);
      const { ticket_id, message } = body;
      if (!ticket_id || !message) return j({ ok: false, error: "Missing fields" }, 400);
      const { data: t } = await svc.from("support_tickets").select("user_id").eq("id", ticket_id).maybeSingle();
      await svc.from("support_ticket_replies").insert({
        ticket_id, author_id: who.user.id, author_role: "admin", message,
      });
      await svc.from("support_tickets").update({
        status: "in_progress", updated_at: new Date().toISOString(),
      }).eq("id", ticket_id).eq("status", "open");
      if (t?.user_id) {
        await svc.from("notifications").insert({
          user_id: t.user_id, type: "support",
          title: "Support replied to your ticket", body: message.slice(0, 120), link: "/notifications",
        });
      }
      await log(svc, admin.id, "support.reply", "ticket", ticket_id, {});
      return j({ ok: true });
    }

    if (action === "support.set_status") {
      if (!hasPerm("manage_support")) return j(forbidden, 403);
      const { ticket_id, status } = body;
      if (!["open", "in_progress", "resolved"].includes(status)) return j({ ok: false, error: "Invalid status" }, 400);
      const { error } = await svc.from("support_tickets").update({
        status, updated_at: new Date().toISOString(),
      }).eq("id", ticket_id);
      if (error) return j({ ok: false, error: error.message }, 400);
      await log(svc, admin.id, `support.${status}`, "ticket", ticket_id, {});
      return j({ ok: true });
    }

    // ---------- DASHBOARD QUICK ALIAS ----------
    if (action === "astrologer_set_approval") {
      if (!hasPerm("manage_astrologers")) return j(forbidden, 403);
      const { astrologer_id, approval_status, rejection_reason } = body;
      if (!["pending", "approved", "rejected", "blocked"].includes(approval_status))
        return j({ ok: false, error: "Invalid status" }, 400);
      const patch: any = { approval_status, updated_at: new Date().toISOString() };
      if (approval_status === "approved") patch.rejection_reason = null;
      else patch.rejection_reason = rejection_reason || null;
      const { error } = await svc.from("astrologers").update(patch).eq("id", astrologer_id);
      if (error) return j({ ok: false, error: error.message }, 400);
      await log(svc, admin.id, `astrologer.${approval_status}`, "astrologer", astrologer_id, { rejection_reason });
      return j({ ok: true });
    }

    // ---------- SETTINGS ----------
    if (action === "settings_update") {
      if (admin.role !== "master_admin") return j(forbidden, 403);
      const allowed = [
        "min_billing_seconds", "auto_end_below_balance", "max_session_minutes",
        "astrologer_share_percent",
        "min_recharge_amount", "max_wallet_balance",
        "reviews_require_approval", "min_review_session_seconds",
        "min_withdrawal_amount", "max_withdrawal_amount", "withdrawal_processing_notice",
        "maintenance_mode", "maintenance_message",
      ];
      const patch: any = { updated_at: new Date().toISOString(), updated_by: who.user.id };
      for (const k of allowed) if (k in body) patch[k] = (body as any)[k];

      // Capture previous values for audit log
      const { data: prev } = await svc.from("platform_settings").select("*").eq("id", 1).maybeSingle();
      const { error } = await svc.from("platform_settings").update(patch).eq("id", 1);
      if (error) return j({ ok: false, error: error.message }, 400);
      await log(svc, admin.id, "settings.update", "platform_settings", "1", { previous: prev, next: patch });
      return j({ ok: true });
    }

    // ---------- ANNOUNCEMENTS ----------
    if (action === "announcement_create") {
      if (!hasPerm("manage_content")) return j(forbidden, 403);
      const { title, body: msg, audience, target_email, display_type, scheduled_at, expires_at } = body;
      if (!title || !msg) return j({ ok: false, error: "Title and message required" }, 400);
      if (!["all", "customers", "astrologers", "user"].includes(audience))
        return j({ ok: false, error: "Invalid audience" }, 400);

      let target_user_id: string | null = null;
      if (audience === "user") {
        if (!target_email) return j({ ok: false, error: "Target email required" }, 400);
        const { data: prof } = await svc.from("profiles").select("id").eq("email", target_email).maybeSingle();
        if (!prof) return j({ ok: false, error: "User with that email not found" }, 400);
        target_user_id = prof.id;
      }

      const scheduled = scheduled_at ? new Date(scheduled_at).toISOString() : new Date().toISOString();
      const sendNow = new Date(scheduled).getTime() <= Date.now();

      const { data: ann, error } = await svc.from("announcements").insert({
        title, body: msg,
        audience,
        target_user_id,
        display_type: display_type || "notification",
        scheduled_at: scheduled,
        expires_at: expires_at ? new Date(expires_at).toISOString() : null,
        is_active: true,
        delivered: false,
        created_by: who.user.id,
      }).select("id").maybeSingle();
      if (error) return j({ ok: false, error: error.message }, 400);

      // Deliver as in-app notifications immediately if scheduled now and notification type
      if (sendNow && display_type === "notification") {
        let recipients: string[] = [];
        if (audience === "user" && target_user_id) {
          recipients = [target_user_id];
        } else if (audience === "all" || audience === "customers") {
          const { data } = await svc.from("profiles").select("id").eq("is_blocked", false).limit(5000);
          recipients = (data || []).map((p: any) => p.id);
          if (audience === "all") {
            const { data: a } = await svc.from("astrologers").select("user_id").not("user_id", "is", null).limit(5000);
            const extra = (a || []).map((x: any) => x.user_id).filter(Boolean);
            recipients = Array.from(new Set([...recipients, ...extra]));
          }
        } else if (audience === "astrologers") {
          const { data } = await svc.from("astrologers").select("user_id").not("user_id", "is", null).limit(5000);
          recipients = (data || []).map((x: any) => x.user_id).filter(Boolean);
        }
        if (recipients.length > 0) {
          const rows = recipients.map((uid) => ({
            user_id: uid, type: "announcement", title, body: msg, link: "/notifications",
          }));
          // chunked insert
          for (let i = 0; i < rows.length; i += 500) {
            await svc.from("notifications").insert(rows.slice(i, i + 500));
          }
          await svc.from("announcements").update({ delivered: true }).eq("id", ann!.id);
        }
      }

      await log(svc, admin.id, "announcement.create", "announcement", ann?.id || "", { audience, display_type });
      return j({ ok: true, id: ann?.id });
    }

    if (action === "announcement_set_active") {
      if (!hasPerm("manage_content")) return j(forbidden, 403);
      const { id, is_active } = body;
      const { error } = await svc.from("announcements").update({ is_active: !!is_active }).eq("id", id);
      if (error) return j({ ok: false, error: error.message }, 400);
      await log(svc, admin.id, is_active ? "announcement.enable" : "announcement.disable", "announcement", id, {});
      return j({ ok: true });
    }

    // ---------- BIRTH-CHART RECOMPUTE ----------
    // Master-only utility: re-runs calculate-chart for every birth_charts row
    // whose source != 'astrologyapi' (i.e. produced by the legacy in-house engine).
    // Master admin only — never gate behind a regular permission key.
    if (action === "recompute_legacy_charts") {
      if (admin.role !== "master_admin") return j(forbidden, 403);
      const limit = Math.min(Number(body.limit ?? 100), 500);

      const { data: rows, error: selErr } = await svc
        .from("birth_charts")
        .select("id, user_id, birth_date, birth_time, time_unknown, latitude, longitude, timezone, source")
        .neq("source", "astrologyapi")
        .order("created_at", { ascending: true })
        .limit(limit);
      if (selErr) return j({ ok: false, error: selErr.message }, 400);

      const total = rows?.length ?? 0;
      let succeeded = 0;
      let failed = 0;
      const errors: { id: string; error: string }[] = [];

      // Reuse the auth header so calculate-chart sees an authenticated context.
      const calcUrl = `${url}/functions/v1/calculate-chart`;
      for (const row of rows ?? []) {
        try {
          const res = await fetch(calcUrl, {
            method: "POST",
            headers: {
              "content-type": "application/json",
              Authorization: `Bearer ${Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")}`,
              apikey: Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? "",
            },
            body: JSON.stringify({
              birthDate: row.birth_date,
              birthTime: row.birth_time ?? "12:00",
              latitude: Number(row.latitude),
              longitude: Number(row.longitude),
              timezone: row.timezone,
              timeUnknown: row.time_unknown,
            }),
          });
          const calc = await res.json();
          if (!res.ok || calc?.error) {
            throw new Error(calc?.error || `HTTP ${res.status}`);
          }
          const nextSource = calc?.source === "astrologyapi" ? "astrologyapi" : "inhouse";
          const { error: upErr } = await svc
            .from("birth_charts")
            .update({
              chart_data: calc,
              source: nextSource,
              recomputed_at: new Date().toISOString(),
            })
            .eq("id", row.id);
          if (upErr) throw upErr;
          succeeded += 1;
        } catch (e) {
          failed += 1;
          errors.push({ id: row.id, error: e instanceof Error ? e.message : String(e) });
        }
      }

      await log(svc, admin.id, "charts.recompute_legacy", "birth_charts", "bulk", {
        attempted: total, succeeded, failed, errors: errors.slice(0, 20),
      });

      return j({ ok: true, attempted: total, succeeded, failed, errors });
    }

    return j({ ok: false, error: "Unknown action" }, 400);
  } catch (e: any) {
    return j({ ok: false, error: e?.message || String(e) }, 500);
  }
});

const forbidden = { ok: false, error: "Permission denied" };
function j(b: unknown, status = 200) {
  return new Response(JSON.stringify(b), {
    status, headers: { ...corsHeaders, "content-type": "application/json" },
  });
}
async function log(svc: any, adminId: string, action: string, target_type: string, target_id: string, details: any) {
  await svc.from("admin_activity_log").insert({ admin_id: adminId, action, target_type, target_id, details });
}
