// deno-lint-ignore-file no-explicit-any
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.45.0";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type",
};

const NAKSHATRA_NAMES = [
  "Ashwini","Bharani","Krittika","Rohini","Mrigashira","Ardra",
  "Punarvasu","Pushya","Ashlesha","Magha","Purva Phalguni","Uttara Phalguni",
  "Hasta","Chitra","Swati","Vishakha","Anuradha","Jyeshtha","Mula",
  "Purva Ashadha","Uttara Ashadha","Shravana","Dhanishta","Shatabhisha",
  "Purva Bhadrapada","Uttara Bhadrapada","Revati",
];

function jsonResponse(body: unknown, status = 200) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { ...corsHeaders, "Content-Type": "application/json" },
  });
}

function nakshatraIdFromMoon(moonLon: number): { id: number; pada: number } {
  const span = 360 / 27;
  const norm = ((moonLon % 360) + 360) % 360;
  const idx = Math.floor(norm / span);
  const within = norm - idx * span;
  const pada = Math.min(4, Math.max(1, Math.floor(within / (span / 4)) + 1));
  return { id: idx + 1, pada };
}

function tzOffsetHours(date: string, time: string, tz: string): number {
  try {
    const isoLocal = `${date}T${time}`;
    const asUtc = new Date(isoLocal + "Z");
    if (isNaN(asUtc.getTime())) return 0;
    const dtf = new Intl.DateTimeFormat("en-US", {
      timeZone: tz, hour12: false,
      year: "numeric", month: "2-digit", day: "2-digit",
      hour: "2-digit", minute: "2-digit", second: "2-digit",
    });
    const parts = Object.fromEntries(dtf.formatToParts(asUtc).map(p => [p.type, p.value]));
    const asTz = Date.UTC(+parts.year, +parts.month - 1, +parts.day,
      +parts.hour, +parts.minute, +parts.second);
    return (asTz - asUtc.getTime()) / 3600000;
  } catch (e) {
    console.error("[nakshatra] tzOffsetHours failed", { date, time, tz, e: String(e) });
    return 5.5;
  }
}

async function callAstrologyApi(
  endpoint: string,
  body: Record<string, unknown>,
  language: "en" | "hi",
): Promise<{ ok: boolean; status: number; data: any }> {
  const userId = Deno.env.get("ASTROLOGY_API_USER_ID");
  const apiKey = Deno.env.get("ASTROLOGY_API_KEY");
  if (!userId || !apiKey) {
    console.error("[nakshatra] missing API credentials");
    return { ok: false, status: 0, data: { error: "missing_credentials" } };
  }
  const auth = btoa(`${userId}:${apiKey}`);
  try {
    const res = await fetch(`https://json.astrologyapi.com/v1/${endpoint}`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Accept-Language": language,
        Authorization: `Basic ${auth}`,
      },
      body: JSON.stringify(body),
    });
    const text = await res.text();
    let data: any;
    try { data = JSON.parse(text); } catch { data = { raw: text }; }
    if (!res.ok) {
      console.error(`[nakshatra] API ${endpoint} failed`, { status: res.status, body: text.slice(0, 300) });
    }
    return { ok: res.ok, status: res.status, data };
  } catch (e) {
    console.error(`[nakshatra] API ${endpoint} threw`, String(e));
    return { ok: false, status: 0, data: { error: String(e) } };
  }
}

interface BirthData {
  day: number; month: number; year: number;
  hour: number; min: number;
  lat: number; lon: number; tzone: number;
  moon_longitude?: number;
  timezone_name?: string;
}

async function fetchNakshatra(
  apiBody: BirthData, language: "en" | "hi",
): Promise<{ source: "astrologyapi" | "static_fallback"; api_response: any }> {
  let attempt = await callAstrologyApi("nakshatra_report", apiBody as any, language);
  if (!attempt.ok) {
    attempt = await callAstrologyApi("general_nakshatra_report", apiBody as any, language);
  }
  return attempt.ok
    ? { source: "astrologyapi", api_response: attempt.data }
    : { source: "static_fallback", api_response: { error: attempt.data, status: attempt.status } };
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL");
    const serviceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
    if (!supabaseUrl || !serviceKey) {
      console.error("[nakshatra] missing supabase env");
      return jsonResponse({ error: "server_misconfigured" }, 500);
    }

    const body = await req.json().catch(() => ({}));
    const language: "en" | "hi" = body.language === "hi" ? "hi" : "en";
    const birthChartId = body.birth_chart_id ? String(body.birth_chart_id) : "";
    const birthData: BirthData | null = body.birth_data && typeof body.birth_data === "object"
      ? body.birth_data : null;

    const isAnonymous = !birthChartId && birthData;

    // ========= ANONYMOUS MODE =========
    if (isAnonymous) {
      console.log("[nakshatra] anonymous mode", { day: birthData.day, month: birthData.month, year: birthData.year });
      const moonLon = typeof birthData.moon_longitude === "number" ? birthData.moon_longitude : null;

      const apiBody = {
        day: birthData.day, month: birthData.month, year: birthData.year,
        hour: birthData.hour, min: birthData.min,
        lat: birthData.lat, lon: birthData.lon, tzone: birthData.tzone,
      };
      const { source, api_response } = await fetchNakshatra(apiBody, language);

      // Determine nakshatra id either from API response or moon longitude
      let nakshatraId = 0, pada = 0;
      const apiNak = (api_response as any)?.nakshatra_number ?? (api_response as any)?.nakshatra ?? null;
      if (typeof apiNak === "number" && apiNak >= 1 && apiNak <= 27) {
        nakshatraId = apiNak;
        pada = (api_response as any)?.pada ?? 1;
      } else if (typeof moonLon === "number") {
        const r = nakshatraIdFromMoon(moonLon);
        nakshatraId = r.id; pada = r.pada;
      } else {
        return jsonResponse({ error: "moon_position_unavailable" }, 422);
      }

      return jsonResponse({
        nakshatra_id: nakshatraId,
        pada,
        language,
        source,
        api_response,
        nakshatra_name: NAKSHATRA_NAMES[nakshatraId - 1],
        cached: false,
        anonymous: true,
      });
    }

    // ========= AUTHENTICATED MODE =========
    const authHeader = req.headers.get("Authorization");
    if (!authHeader) return jsonResponse({ error: "unauthorized" }, 401);

    const userClient = createClient(supabaseUrl, serviceKey, {
      global: { headers: { Authorization: authHeader } },
    });
    const adminClient = createClient(supabaseUrl, serviceKey);

    const { data: userData, error: userErr } = await userClient.auth.getUser();
    if (userErr || !userData?.user) return jsonResponse({ error: "unauthorized" }, 401);
    const userId = userData.user.id;

    if (!birthChartId) return jsonResponse({ error: "missing_birth_chart_id" }, 400);

    const { data: chart, error: chartErr } = await adminClient
      .from("birth_charts")
      .select("*")
      .eq("id", birthChartId)
      .eq("user_id", userId)
      .maybeSingle();
    if (chartErr) {
      console.error("[nakshatra] chart query error", chartErr);
      return jsonResponse({ error: "chart_query_failed", detail: chartErr.message }, 500);
    }
    if (!chart) return jsonResponse({ error: "chart_not_found" }, 404);

    const cd: any = chart.chart_data || {};
    const moon = (cd.planets || []).find((p: any) => p.name === "Moon");
    if (!moon || typeof moon.longitude !== "number") {
      console.error("[nakshatra] moon position missing", { hasChartData: !!chart.chart_data, planetCount: (cd.planets || []).length });
      return jsonResponse({ error: "moon_position_unavailable" }, 422);
    }
    const { id: nakshatraId, pada } = nakshatraIdFromMoon(moon.longitude);

    const { data: cached } = await adminClient
      .from("nakshatra_reports")
      .select("*")
      .eq("birth_chart_id", birthChartId)
      .eq("language", language)
      .maybeSingle();
    if (cached) {
      return jsonResponse({
        nakshatra_id: cached.nakshatra_id,
        pada: cached.pada,
        language: cached.language,
        source: cached.source,
        api_response: cached.api_response,
        cached: true,
      });
    }

    if (chart.time_unknown || !chart.birth_time) {
      const payload = {
        nakshatra_id: nakshatraId, pada, language,
        source: "static_fallback" as const,
        api_response: { reason: "time_unknown" },
      };
      const { error: insErr } = await adminClient.from("nakshatra_reports").insert({
        birth_chart_id: birthChartId, ...payload,
      });
      if (insErr) console.error("[nakshatra] insert (no-time) failed", insErr);
      return jsonResponse({ ...payload, cached: false });
    }

    const [y, m, d] = String(chart.birth_date).split("-").map(Number);
    const [hh, mm] = String(chart.birth_time).split(":").map(Number);
    const tzone = tzOffsetHours(chart.birth_date, chart.birth_time, chart.timezone || "Asia/Kolkata");
    const apiBody = {
      day: d, month: m, year: y, hour: hh, min: mm,
      lat: Number(chart.latitude), lon: Number(chart.longitude), tzone,
    };

    const { source, api_response: apiResponse } = await fetchNakshatra(apiBody, language);

    const { error: insertErr } = await adminClient.from("nakshatra_reports").insert({
      birth_chart_id: birthChartId,
      nakshatra_id: nakshatraId,
      pada,
      api_response: apiResponse,
      language,
      source,
    });
    if (insertErr) console.error("[nakshatra] cache insert failed", insertErr);

    return jsonResponse({
      nakshatra_id: nakshatraId,
      pada,
      language,
      source,
      api_response: apiResponse,
      nakshatra_name: NAKSHATRA_NAMES[nakshatraId - 1],
      cached: false,
    });
  } catch (e) {
    console.error("[nakshatra] unhandled error", e instanceof Error ? e.stack : String(e));
    return jsonResponse({ error: "internal_error", message: String(e) }, 500);
  }
});
