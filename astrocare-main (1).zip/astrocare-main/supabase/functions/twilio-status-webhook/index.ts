import { createClient } from "npm:@supabase/supabase-js@2.45.0";
import { createHmac } from "node:crypto";

const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
const SERVICE_ROLE_KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
const TWILIO_AUTH_TOKEN = Deno.env.get("TWILIO_AUTH_TOKEN");

function ok(body = "ok") {
  return new Response(body, { status: 200, headers: { "Content-Type": "text/plain" } });
}

function validateTwilioSignature(
  url: string,
  params: Record<string, string>,
  signature: string,
): boolean {
  if (!TWILIO_AUTH_TOKEN) return false;
  const sortedKeys = Object.keys(params).sort();
  const data = url + sortedKeys.map((k) => k + params[k]).join("");
  const hmac = createHmac("sha1", TWILIO_AUTH_TOKEN);
  hmac.update(data);
  const expected = hmac.digest("base64");
  return expected === signature;
}

Deno.serve(async (req) => {
  if (req.method !== "POST") return new Response("Method not allowed", { status: 405 });

  const url = new URL(req.url);
  const callSessionId = url.searchParams.get("call_session_id");
  const leg = url.searchParams.get("leg") ?? "unknown";
  if (!callSessionId) return new Response("call_session_id required", { status: 400 });

  const formText = await req.text();
  const params: Record<string, string> = {};
  for (const [k, v] of new URLSearchParams(formText)) params[k] = v;

  if (TWILIO_AUTH_TOKEN) {
    const signature = req.headers.get("X-Twilio-Signature") ?? "";
    if (!validateTwilioSignature(req.url, params, signature)) {
      console.warn("Invalid Twilio signature", { url: req.url });
      return new Response("Forbidden", { status: 403 });
    }
  }

  const admin = createClient(SUPABASE_URL, SERVICE_ROLE_KEY);

  // Idempotency
  const eventId = `${params.CallSid ?? params.ConferenceSid ?? "unknown"}:${
    params.CallStatus ?? params.StatusCallbackEvent ?? "evt"
  }:${params.SequenceNumber ?? params.Timestamp ?? Date.now()}`;
  const env = TWILIO_AUTH_TOKEN ? "live" : "dev";
  const { error: dupErr } = await admin
    .from("webhook_events")
    .insert({ event_id: eventId, event_type: "twilio_status", environment: env });
  if (dupErr && (dupErr as { code?: string }).code === "23505") return ok("duplicate");

  const { data: session } = await admin
    .from("call_sessions")
    .select("id, status, connected_at, hold_released, twilio_conference_sid")
    .eq("id", callSessionId)
    .maybeSingle();
  if (!session) return ok("no session");

  // ================= Conference events =================
  if (leg === "conference") {
    const evt = params.StatusCallbackEvent;
    // Save conference SID first time we see it
    if (params.ConferenceSid && !session.twilio_conference_sid) {
      await admin
        .from("call_sessions")
        .update({ twilio_conference_sid: params.ConferenceSid })
        .eq("id", callSessionId);
    }
    // Conference fully started — both legs joined
    if (evt === "conference-start" && session.status !== "connected") {
      await admin
        .from("call_sessions")
        .update({ status: "connected", connected_at: new Date().toISOString() })
        .eq("id", callSessionId);
    }
    // Conference ended — finalize via DB function (atomic billing + 30/70 split)
    if (evt === "conference-end") {
      if (!["completed", "failed", "cancelled"].includes(session.status)) {
        await admin.rpc("end_call_session", {
          _session_id: callSessionId,
          _ended_by: "system",
          _end_reason: "conference_end",
        });
      }
    }
    return ok();
  }

  // ================= Per-leg call events =================
  const callStatus = params.CallStatus;

  // Astrologer leg failed before connect
  if (
    leg === "astrologer" &&
    callStatus &&
    ["no-answer", "busy", "failed", "canceled"].includes(callStatus)
  ) {
    if (["pending", "ringing_astrologer", "ringing_user"].includes(session.status)) {
      const reason = callStatus === "no-answer" ? "no_answer" : "error";
      const newStatus = callStatus === "no-answer" ? "no_answer" : "failed";
      await admin
        .from("call_sessions")
        .update({ status: newStatus, end_reason: reason, ended_at: new Date().toISOString() })
        .eq("id", callSessionId);
      if (!session.hold_released) {
        await admin.rpc("release_call_hold", { _call_session_id: callSessionId });
      }
    }
    return ok();
  }

  // Customer leg failed
  if (
    leg === "user" &&
    callStatus &&
    ["no-answer", "busy", "failed", "canceled"].includes(callStatus)
  ) {
    if (["ringing_user", "ringing_astrologer"].includes(session.status)) {
      await admin
        .from("call_sessions")
        .update({
          status: callStatus === "no-answer" ? "no_answer" : "failed",
          end_reason: callStatus === "no-answer" ? "user_no_answer" : "error",
          ended_at: new Date().toISOString(),
        })
        .eq("id", callSessionId);
      if (!session.hold_released) {
        await admin.rpc("release_call_hold", { _call_session_id: callSessionId });
      }
    }
    return ok();
  }

  // Per-leg completion: defer to conference-end for actual billing.
  // Just record duration for analytics if we missed conference-end.
  if (callStatus === "completed" && session.status === "connected") {
    // Wait for conference-end to do final billing — but as safety net, finalize after grace period.
    // Here we just mark a soft 'completed' if both legs done. The conference-end path is preferred.
  }

  return ok();
});
