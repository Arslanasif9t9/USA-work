// deno-lint-ignore-file no-explicit-any
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.45.0";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type",
};

const VEDIC_PLANETS = new Set([
  "Sun", "Moon", "Mars", "Mercury", "Jupiter", "Venus", "Saturn", "Rahu", "Ketu",
]);

const ABBR: Record<string, string> = {
  Sun: "Su", Moon: "Mo", Mars: "Ma", Mercury: "Me",
  Jupiter: "Ju", Venus: "Ve", Saturn: "Sa", Rahu: "Ra", Ketu: "Ke",
};

const ALLOWED_DCODES = new Set([
  "D1","D2","D3","D4","D7","D9","D10","D12","D16","D20","D24","D27","D30","D40","D45","D60",
]);

// astrologyapi.com chart_id slugs for /horo_chart endpoint.
const CHART_SLUGS: Record<string, string> = {
  D1:  "D1",
  D2:  "D2",
  D3:  "D3",
  D4:  "D4",
  D7:  "D7",
  D9:  "D9",
  D10: "D10",
  D12: "D12",
  D16: "D16",
  D20: "D20",
  D24: "D24",
  D27: "D27",
  D30: "D30",
  D40: "D40",
  D45: "D45",
  D60: "D60",
};

interface BirthData {
  day: number; month: number; year: number;
  hour: number; min: number;
  lat: number; lon: number; tzone: number;
}

interface VargaPlanetPosition {
  name: string;
  abbrev: string;
  sign: number;        // 1..12
  house: number;       // 1..12 (whole-sign from ascendant)
  degree: number;
  retrograde: boolean;
}

interface VargaChartData {
  chart_id: string;
  planets: VargaPlanetPosition[];
  ascendant: number; // 1..12
}

function jsonResponse(body: unknown, status = 200) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { ...corsHeaders, "Content-Type": "application/json" },
  });
}

function pickBirthData(chart: any): BirthData | null {
  try {
    const [y, m, d] = String(chart.birth_date).split("-").map(Number);
    const timeStr = chart.time_unknown || !chart.birth_time
      ? "12:00" : String(chart.birth_time).slice(0, 5);
    const [hh, mm] = timeStr.split(":").map(Number);
    const tz = chart.timezone || "Asia/Kolkata";
    const tzone = tzOffsetHours(chart.birth_date, timeStr, tz);
    return {
      day: d, month: m, year: y, hour: hh, min: mm,
      lat: Number(chart.latitude), lon: Number(chart.longitude),
      tzone,
    };
  } catch (e) {
    console.error("[shodashvarga] pickBirthData failed", String(e));
    return null;
  }
}

function tzOffsetHours(date: string, time: string, tz: string): number {
  try {
    const isoLocal = `${date}T${time}`;
    const asUtc = new Date(isoLocal + "Z");
    if (isNaN(asUtc.getTime())) return 5.5;
    const dtf = new Intl.DateTimeFormat("en-US", {
      timeZone: tz, hour12: false,
      year: "numeric", month: "2-digit", day: "2-digit",
      hour: "2-digit", minute: "2-digit", second: "2-digit",
    });
    const parts = Object.fromEntries(dtf.formatToParts(asUtc).map(p => [p.type, p.value]));
    const asTz = Date.UTC(+parts.year, +parts.month - 1, +parts.day,
      +parts.hour, +parts.minute, +parts.second);
    return (asTz - asUtc.getTime()) / 3600000;
  } catch {
    return 5.5;
  }
}

const SIGN_INDEX_BY_NAME: Record<string, number> = {
  Aries: 1, Taurus: 2, Gemini: 3, Cancer: 4, Leo: 5, Virgo: 6,
  Libra: 7, Scorpio: 8, Sagittarius: 9, Capricorn: 10, Aquarius: 11, Pisces: 12,
};

async function callHoroChart(slug: string, body: BirthData, language: "en" | "hi"): Promise<any[]> {
  const userId = Deno.env.get("ASTROLOGY_API_USER_ID");
  const apiKey = Deno.env.get("ASTROLOGY_API_KEY");
  if (!userId || !apiKey) throw new Error("astrologyapi credentials not configured");
  const auth = btoa(`${userId}:${apiKey}`);
  const res = await fetch(`https://json.astrologyapi.com/v1/horo_chart/${slug}`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "Accept-Language": language,
      Authorization: `Basic ${auth}`,
    },
    body: JSON.stringify(body),
  });
  const text = await res.text();
  if (!res.ok) {
    throw new Error(`horo_chart/${slug} ${res.status}: ${text.slice(0, 300)}`);
  }
  let data: any;
  try { data = JSON.parse(text); } catch { data = null; }
  if (!Array.isArray(data)) {
    throw new Error(`horo_chart/${slug} returned non-array`);
  }
  return data;
}

function normalizeHoroChart(raw: any[], dCode: string): VargaChartData {
  // raw: array of items { name, sign, house, fullDegree, normDegree, isRetro, ... }
  const ascRaw = raw.find((p) => /asc/i.test(String(p?.name)));
  let ascendantSign = 1;
  if (ascRaw) {
    const signName = String(ascRaw.sign);
    ascendantSign = SIGN_INDEX_BY_NAME[signName] ?? Number(ascRaw.house) ?? 1;
  }

  const planets: VargaPlanetPosition[] = [];
  for (const p of raw) {
    const name = String(p?.name ?? "");
    if (!VEDIC_PLANETS.has(name)) continue; // strip Uranus/Neptune/Pluto/Asc
    const signName = String(p.sign ?? "");
    const sign = SIGN_INDEX_BY_NAME[signName] ?? 0;
    const house = Number(p.house) || (((sign - ascendantSign + 12) % 12) + 1);
    const degree = Number(p.normDegree ?? p.norm_degree ?? p.fullDegree ?? 0);
    const retrograde = Boolean(p.isRetro === true || p.isRetro === "true");
    planets.push({
      name,
      abbrev: ABBR[name] || name.slice(0, 2),
      sign: sign || 1,
      house,
      degree,
      retrograde,
    });
  }
  return { chart_id: dCode, planets, ascendant: ascendantSign };
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL");
    const serviceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
    if (!supabaseUrl || !serviceKey) {
      return jsonResponse({ error: "server_misconfigured" }, 500);
    }

    const body = await req.json().catch(() => ({}));
    const language: "en" | "hi" = body.language === "hi" ? "hi" : "en";
    const dCode = String(body.chart_id || "").toUpperCase();
    if (!ALLOWED_DCODES.has(dCode)) {
      return jsonResponse({ error: "invalid_chart_id", chart_id: dCode }, 400);
    }
    const slug = CHART_SLUGS[dCode];

    const birthChartId = body.birth_chart_id ? String(body.birth_chart_id) : "";
    const birthData: BirthData | null =
      body.birth_data && typeof body.birth_data === "object" ? body.birth_data : null;
    const isAnonymous = !birthChartId && birthData;

    // ========= ANONYMOUS MODE =========
    if (isAnonymous) {
      try {
        const raw = await callHoroChart(slug, birthData, language);
        const chart = normalizeHoroChart(raw, dCode);
        console.log(`[shodashvarga] anonymous ok ${dCode} planets=${chart.planets.length}`);
        return jsonResponse({
          chart, language, source: "astrologyapi", cached: false, anonymous: true,
        });
      } catch (e) {
        console.error(`[shodashvarga] anonymous ${dCode} failed`, String(e));
        return jsonResponse({ error: "provider_failed", message: String(e) }, 502);
      }
    }

    // ========= AUTHENTICATED MODE =========
    const authHeader = req.headers.get("Authorization");
    if (!authHeader) return jsonResponse({ error: "unauthorized" }, 401);

    const userClient = createClient(supabaseUrl, serviceKey, {
      global: { headers: { Authorization: authHeader } },
    });
    const adminClient = createClient(supabaseUrl, serviceKey);

    const { data: userData, error: userErr } = await userClient.auth.getUser();
    if (userErr || !userData?.user) return jsonResponse({ error: "unauthorized" }, 401);
    const userId = userData.user.id;
    if (!birthChartId) return jsonResponse({ error: "missing_birth_chart_id" }, 400);

    const { data: dbChart, error: chartErr } = await adminClient
      .from("birth_charts").select("*")
      .eq("id", birthChartId).eq("user_id", userId).maybeSingle();
    if (chartErr) return jsonResponse({ error: "chart_query_failed", detail: chartErr.message }, 500);
    if (!dbChart) return jsonResponse({ error: "chart_not_found" }, 404);

    // Cache check
    const { data: cached } = await adminClient
      .from("shodashvarga_charts")
      .select("*")
      .eq("birth_chart_id", birthChartId)
      .eq("chart_id", dCode)
      .eq("language", language)
      .maybeSingle();
    if (cached) {
      return jsonResponse({
        chart: cached.chart_data,
        language: cached.language,
        source: cached.source,
        cached: true,
      });
    }

    if (dbChart.time_unknown || !dbChart.birth_time) {
      return jsonResponse({ error: "time_required_for_shodashvarga" }, 422);
    }

    const inputs = pickBirthData(dbChart);
    if (!inputs) return jsonResponse({ error: "chart_inputs_invalid" }, 422);

    let raw: any[];
    try {
      raw = await callHoroChart(slug, inputs, language);
    } catch (e) {
      console.error(`[shodashvarga] auth ${dCode} provider failed`, String(e));
      return jsonResponse({ error: "provider_failed", message: String(e) }, 502);
    }
    const chart = normalizeHoroChart(raw, dCode);

    const { error: insertErr } = await adminClient.from("shodashvarga_charts").insert({
      birth_chart_id: birthChartId,
      chart_id: dCode,
      chart_data: chart,
      language,
      source: "astrologyapi",
    });
    if (insertErr) console.error("[shodashvarga] cache insert failed", insertErr);

    console.log(`[shodashvarga] authenticated ok ${dCode} chart=${birthChartId}`);
    return jsonResponse({
      chart, language, source: "astrologyapi", cached: false,
    });
  } catch (e) {
    console.error("[shodashvarga] unhandled", e instanceof Error ? e.stack : String(e));
    return jsonResponse({ error: "internal_error", message: String(e) }, 500);
  }
});
