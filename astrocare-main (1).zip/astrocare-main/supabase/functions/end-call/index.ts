// User clicks "End Call" — hangs up the Twilio conference.
import { createClient } from "npm:@supabase/supabase-js@2.45.0";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
const SUPABASE_ANON_KEY = Deno.env.get("SUPABASE_ANON_KEY")!;
const SERVICE_ROLE_KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
const TWILIO_ACCOUNT_SID = Deno.env.get("TWILIO_ACCOUNT_SID");
const TWILIO_AUTH_TOKEN = Deno.env.get("TWILIO_AUTH_TOKEN");

function json(body: unknown, status = 200) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { ...corsHeaders, "Content-Type": "application/json" },
  });
}

async function hangupCall(sid: string) {
  if (!TWILIO_ACCOUNT_SID || !TWILIO_AUTH_TOKEN) return;
  await fetch(
    `https://api.twilio.com/2010-04-01/Accounts/${TWILIO_ACCOUNT_SID}/Calls/${sid}.json`,
    {
      method: "POST",
      headers: {
        Authorization: "Basic " + btoa(`${TWILIO_ACCOUNT_SID}:${TWILIO_AUTH_TOKEN}`),
        "Content-Type": "application/x-www-form-urlencoded",
      },
      body: "Status=completed",
    },
  ).catch((e) => console.error("hangup failed", sid, e));
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });
  if (req.method !== "POST") return json({ error: "Method not allowed" }, 405);

  try {
    const authHeader = req.headers.get("Authorization");
    if (!authHeader?.startsWith("Bearer ")) return json({ error: "Unauthorized" }, 401);

    const userClient = createClient(SUPABASE_URL, SUPABASE_ANON_KEY, {
      global: { headers: { Authorization: authHeader } },
    });
    const { data: userData } = await userClient.auth.getUser();
    if (!userData?.user?.id) return json({ error: "Unauthorized" }, 401);
    const uid = userData.user.id;

    const body = await req.json().catch(() => ({}));
    const callSessionId = body?.call_session_id;
    if (!callSessionId) return json({ error: "call_session_id required" }, 400);

    const admin = createClient(SUPABASE_URL, SERVICE_ROLE_KEY);
    const { data: session } = await admin
      .from("call_sessions")
      .select(
        "id, status, user_id, astrologer_id, twilio_astrologer_call_sid, twilio_user_call_sid, astrologers!inner(user_id)",
      )
      .eq("id", callSessionId)
      .maybeSingle();

    if (!session) return json({ error: "Session not found" }, 404);
    const astroUserId = (session as any).astrologers?.user_id;
    if (uid !== session.user_id && uid !== astroUserId) {
      return json({ error: "Not a participant" }, 403);
    }

    const endedBy = uid === session.user_id ? "user" : "astrologer";

    // Hang up Twilio legs (real mode)
    await Promise.all([
      session.twilio_user_call_sid ? hangupCall(session.twilio_user_call_sid) : null,
      session.twilio_astrologer_call_sid ? hangupCall(session.twilio_astrologer_call_sid) : null,
    ].filter(Boolean) as Promise<void>[]);

    // Finalize via DB function (handles billing + hold release + 30/70 split)
    const { data: result, error: rpcErr } = await admin.rpc("end_call_session", {
      _session_id: callSessionId,
      _ended_by: endedBy,
      _end_reason: `${endedBy}_hangup`,
    });
    if (rpcErr) {
      console.error("end_call_session rpc error", rpcErr);
      return json({ error: "Could not end call cleanly" }, 500);
    }
    return json({ ok: true, result });
  } catch (e) {
    console.error("end-call error", e);
    const msg = e instanceof Error ? e.message : "Unknown";
    return json({ error: "Could not end call", details: msg }, 500);
  }
});
