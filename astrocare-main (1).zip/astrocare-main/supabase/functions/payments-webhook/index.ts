// Stripe webhook handler. Receives ?env=sandbox or ?env=live.
//
// Routes purchases by pack_definitions.pack_type (resolved via metadata.price_id):
//   - "wallet_recharge"    -> credit wallet via credit_wallet RPC
//   - "consultation_pack"  -> credit minutes via credit_consultation_minutes RPC
//   - (anything else)      -> insert into user_purchases (future: premium reports)
//
// For custom-amount recharges (purchase_kind=custom), credit equals the amount
// Stripe actually charged (session.amount_total / 100), NOT a client-supplied value.
//
// Webhook events are deduped by event.id via the webhook_events table.
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.45.0";
import {
  createStripeClient,
  getWebhookSecret,
  corsHeaders,
} from "../_shared/stripe.ts";

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  const url = new URL(req.url);
  const env = (url.searchParams.get("env") === "live" ? "live" : "sandbox") as
    | "sandbox"
    | "live";

  const signature = req.headers.get("stripe-signature");
  if (!signature) return new Response("Missing signature", { status: 400 });

  const body = await req.text();
  const stripe = createStripeClient(env);

  let event;
  try {
    event = await stripe.webhooks.constructEventAsync(
      body,
      signature,
      getWebhookSecret(env)
    );
  } catch (err) {
    console.error("Signature verification failed:", err);
    return new Response(`Webhook Error: ${(err as Error).message}`, {
      status: 400,
    });
  }

  console.log("Received event:", event.type, event.id);

  const supabase = createClient(
    Deno.env.get("SUPABASE_URL")!,
    Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!
  );

  // Event-level idempotency: insert event_id, ignore on conflict
  const { error: dedupErr } = await supabase
    .from("webhook_events")
    .insert({ event_id: event.id, event_type: event.type, environment: env });
  if (dedupErr) {
    // 23505 = unique_violation -> already processed
    if ((dedupErr as { code?: string }).code === "23505") {
      console.log("Duplicate event, skipping:", event.id);
      return new Response("Duplicate", { status: 200 });
    }
    console.error("webhook_events insert failed", dedupErr);
    // fall through — we still want to process the event
  }

  if (event.type !== "checkout.session.completed") {
    return new Response("OK", { status: 200 });
  }

  const session = event.data.object as {
    id: string;
    payment_intent: string | null;
    payment_status: string;
    amount_total: number | null;
    currency: string | null;
    metadata: Record<string, string> | null;
  };

  if (session.payment_status !== "paid") {
    return new Response("Not paid", { status: 200 });
  }

  const userId = session.metadata?.user_id;
  const purchaseKind = session.metadata?.purchase_kind ?? "custom";
  if (!userId) {
    console.error("Missing user_id metadata", session.metadata);
    return new Response("Missing metadata", { status: 200 });
  }

  const stripePaymentId = session.payment_intent || session.id;

  try {
    if (purchaseKind === "pack") {
      // Pack purchase: look up pack_definitions
      const priceId = session.metadata?.price_id;
      if (!priceId) {
        console.error("Pack purchase missing price_id metadata");
        return new Response("Missing price_id", { status: 200 });
      }

      const { data: pack, error: packErr } = await supabase
        .from("pack_definitions")
        .select(
          "pack_type, credit_amount, paid_amount, minutes_amount, display_name, product_id"
        )
        .eq("price_id", priceId)
        .maybeSingle();

      if (packErr || !pack) {
        console.error("Unknown pack price_id", priceId, packErr);
        return new Response("Unknown pack", { status: 200 });
      }

      if (pack.pack_type === "wallet_recharge") {
        const creditAmount = Number(pack.credit_amount);
        const bonus = creditAmount - Number(pack.paid_amount);
        const description =
          bonus > 0
            ? `${pack.display_name} pack (₹${pack.paid_amount} + ₹${bonus} bonus)`
            : `${pack.display_name} pack`;

        const { error: rpcErr } = await supabase.rpc("credit_wallet", {
          _user_id: userId,
          _amount: creditAmount,
          _description: description,
          _stripe_payment_id: stripePaymentId,
        });
        if (rpcErr) {
          // Unique violation on stripe_payment_id = already credited
          if ((rpcErr as { code?: string }).code === "23505") {
            console.log("Already credited:", stripePaymentId);
            return new Response("Already processed", { status: 200 });
          }
          throw rpcErr;
        }
        console.log("Wallet credited:", userId, creditAmount);
      } else if (pack.pack_type === "consultation_pack") {
        const minutes = pack.minutes_amount ?? 0;
        if (minutes <= 0) {
          console.error("Consultation pack has no minutes", priceId);
          return new Response("Invalid pack", { status: 200 });
        }
        const description = `${pack.display_name} (+${minutes} min)`;
        const { error: rpcErr } = await supabase.rpc(
          "credit_consultation_minutes",
          {
            _user_id: userId,
            _minutes: minutes,
            _description: description,
            _stripe_payment_id: stripePaymentId,
          }
        );
        if (rpcErr) {
          if ((rpcErr as { code?: string }).code === "23505") {
            console.log("Already credited minutes:", stripePaymentId);
            return new Response("Already processed", { status: 200 });
          }
          throw rpcErr;
        }
        console.log("Minutes credited:", userId, minutes);
      } else {
        // Future product types (premium_report, etc.) -> log to user_purchases
        const { error: purchaseErr } = await supabase
          .from("user_purchases")
          .insert({
            user_id: userId,
            product_id: pack.product_id,
            product_type: pack.pack_type,
            stripe_payment_id: stripePaymentId,
            metadata: { price_id: priceId, display_name: pack.display_name },
          });
        if (purchaseErr && (purchaseErr as { code?: string }).code !== "23505") {
          throw purchaseErr;
        }
        console.log("Purchase logged:", userId, pack.pack_type);
      }
    } else {
      // Custom-amount recharge: trust Stripe's amount_total, not client metadata
      if (!session.amount_total || session.currency?.toLowerCase() !== "inr") {
        console.error("Custom purchase missing amount_total or wrong currency", {
          amount_total: session.amount_total,
          currency: session.currency,
        });
        return new Response("Invalid amount", { status: 200 });
      }
      const creditAmount = session.amount_total / 100;
      const { error: rpcErr } = await supabase.rpc("credit_wallet", {
        _user_id: userId,
        _amount: creditAmount,
        _description: "Wallet recharge (custom)",
        _stripe_payment_id: stripePaymentId,
      });
      if (rpcErr) {
        if ((rpcErr as { code?: string }).code === "23505") {
          console.log("Already credited:", stripePaymentId);
          return new Response("Already processed", { status: 200 });
        }
        throw rpcErr;
      }
      console.log("Custom wallet credited:", userId, creditAmount);
    }

    return new Response("OK", { status: 200 });
  } catch (err) {
    console.error("Webhook processing failed", err);
    // Roll back the dedup row so Stripe's retry can re-process
    await supabase.from("webhook_events").delete().eq("event_id", event.id);
    return new Response("Processing failed", { status: 500 });
  }
});
