// deno-lint-ignore-file no-explicit-any
/**
 * Shared utility for calling astrologyapi.com from edge functions.
 *
 * NOTE on Vedic configuration:
 *   astrologyapi.com's Vedic endpoints (/planet_panchang, /horo_chart/*, etc.)
 *   return SIDEREAL longitudes computed with Lahiri ayanamsa BY DEFAULT.
 *   The API does NOT accept an `ayanamsa` body parameter on these endpoints —
 *   sending one would either be ignored or rejected. House system is also
 *   provider-defined; we derive whole-sign houses client-side from the
 *   ascendant longitude.
 *
 *   Therefore this utility intentionally does NOT inject `ayanamsa` or
 *   `house_system` into the request body. Lahiri/whole-sign is the de facto
 *   standard returned. If we ever switch endpoints (e.g. Western tropical),
 *   override here.
 */

const ASTROLOGY_API_BASE = "https://json.astrologyapi.com/v1";

export interface BirthData {
  day: number;
  month: number;
  year: number;
  hour: number;
  min: number;
  lat: number;
  lon: number;
  tzone: number;
}

export interface CallOptions {
  language?: "en" | "hi";
  /** Extra body fields (e.g. chart_id for /horo_chart). */
  extra?: Record<string, unknown>;
}

export async function callAstrologyApi(
  endpoint: string,
  birthData: BirthData,
  options: CallOptions = {},
): Promise<unknown> {
  const userId = Deno.env.get("ASTROLOGY_API_USER_ID");
  const apiKey = Deno.env.get("ASTROLOGY_API_KEY");
  if (!userId || !apiKey) {
    throw new Error("astrologyapi credentials not configured");
  }
  const auth = btoa(`${userId}:${apiKey}`);
  const language = options.language === "hi" ? "hi" : "en";

  const body = { ...birthData, ...(options.extra ?? {}) };

  const started = Date.now();
  const res = await fetch(`${ASTROLOGY_API_BASE}/${endpoint}`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "Accept-Language": language,
      Authorization: `Basic ${auth}`,
    },
    body: JSON.stringify(body),
  });
  const elapsed = Date.now() - started;

  if (!res.ok) {
    const text = await res.text().catch(() => "");
    console.error(
      `[astrologyApi] ${endpoint} ${res.status} (${elapsed}ms) body=${
        JSON.stringify(body).slice(0, 200)
      } resp=${text.slice(0, 300)}`,
    );
    throw new Error(`astrologyapi ${endpoint} ${res.status}: ${text.slice(0, 200)}`);
  }

  console.log(`[astrologyApi] ${endpoint} ok (${elapsed}ms)`);
  return res.json();
}
