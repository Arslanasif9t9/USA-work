// Shared Stripe client routed through Lovable's connector gateway.
// Use this in every edge function that talks to Stripe.
//
// IMPORTANT: STRIPE_SANDBOX_API_KEY / STRIPE_LIVE_API_KEY are NOT real Stripe
// secret keys — they are opaque gateway connection identifiers. Calling
// api.stripe.com with them directly returns an HTML error page (causing
// "Invalid JSON received from the Stripe API"). All requests must be proxied
// through the connector gateway with both X-Connection-Api-Key and
// Lovable-API-Key headers attached.
import Stripe from "https://esm.sh/stripe@18.5.0";

export type StripeEnv = "sandbox" | "live";

const GATEWAY_STRIPE_BASE = "https://connector-gateway.lovable.dev/stripe";

export function getConnectionApiKey(env: StripeEnv): string {
  const key =
    env === "live"
      ? Deno.env.get("STRIPE_LIVE_API_KEY")
      : Deno.env.get("STRIPE_SANDBOX_API_KEY");
  if (!key) {
    throw new Error(
      `Missing Stripe API key for environment "${env}". Ensure payments are enabled.`
    );
  }
  return key;
}

export function createStripeClient(env: StripeEnv = "sandbox"): Stripe {
  const connectionApiKey = getConnectionApiKey(env);
  const lovableApiKey = Deno.env.get("LOVABLE_API_KEY");
  if (!lovableApiKey) {
    throw new Error("LOVABLE_API_KEY is not configured");
  }

  return new Stripe(connectionApiKey, {
    httpClient: Stripe.createFetchHttpClient(
      (url: string | URL, init?: RequestInit) => {
        const gatewayUrl = url
          .toString()
          .replace("https://api.stripe.com", GATEWAY_STRIPE_BASE);
        return fetch(gatewayUrl, {
          ...init,
          headers: {
            ...Object.fromEntries(new Headers(init?.headers).entries()),
            "X-Connection-Api-Key": connectionApiKey,
            "Lovable-API-Key": lovableApiKey,
          },
        });
      }
    ),
  });
}

export function getWebhookSecret(env: StripeEnv = "sandbox"): string {
  const secret =
    env === "live"
      ? Deno.env.get("PAYMENTS_LIVE_WEBHOOK_SECRET")
      : Deno.env.get("PAYMENTS_SANDBOX_WEBHOOK_SECRET");
  if (!secret) {
    throw new Error(`Missing webhook secret for environment "${env}".`);
  }
  return secret;
}

export const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
  "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
};
