// Bootstrap master admin accounts. Idempotent — safe to call repeatedly.
// Creates the seeded master admin auth users + admin_users rows if missing.
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.45.0";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

const SEED_MASTERS = [
  // Single master admin per requirements (Fix 1)
  { email: "astrolume22@gmail.com",     password: "AstroPsychic28!",     full_name: "AstroLume Master" },
];

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });

  const supabase = createClient(
    Deno.env.get("SUPABASE_URL")!,
    Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!,
  );

  const results: Array<{ email: string; status: string }> = [];

  for (const m of SEED_MASTERS) {
    try {
      // Find or create auth user
      let userId: string | null = null;

      const { data: list } = await supabase.auth.admin.listUsers({ page: 1, perPage: 1000 });
      const existing = list?.users?.find((u) => (u.email || "").toLowerCase() === m.email.toLowerCase());
      if (existing) {
        userId = existing.id;
        // Ensure password is set to the seed password (idempotent reset)
        await supabase.auth.admin.updateUserById(existing.id, {
          password: m.password,
          email_confirm: true,
        });
      } else {
        const { data: created, error } = await supabase.auth.admin.createUser({
          email: m.email,
          password: m.password,
          email_confirm: true,
          user_metadata: { name: m.full_name },
        });
        if (error) throw error;
        userId = created.user!.id;
      }

      // Upsert admin_users row as master_admin
      const { data: existsRow } = await supabase
        .from("admin_users").select("id").eq("user_id", userId!).maybeSingle();

      if (existsRow) {
        await supabase.from("admin_users").update({
          role: "master_admin",
          is_active: true,
          full_name: m.full_name,
          email: m.email,
          permissions: [],
        }).eq("id", existsRow.id);
      } else {
        await supabase.from("admin_users").insert({
          user_id: userId,
          email: m.email,
          full_name: m.full_name,
          role: "master_admin",
          permissions: [],
          is_active: true,
        });
      }
      results.push({ email: m.email, status: "ok" });
    } catch (e: any) {
      results.push({ email: m.email, status: "error: " + (e?.message || String(e)) });
    }
  }

  return new Response(JSON.stringify({ ok: true, results }), {
    headers: { ...corsHeaders, "content-type": "application/json" },
  });
});
