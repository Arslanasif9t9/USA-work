// TwiML returned when astrologer's phone answers.
// Plays a short greeting then puts them in the conference (waiting for customer).
import { createClient } from "npm:@supabase/supabase-js@2.45.0";

const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
const SERVICE_ROLE_KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
const TWILIO_ACCOUNT_SID = Deno.env.get("TWILIO_ACCOUNT_SID");
const TWILIO_AUTH_TOKEN = Deno.env.get("TWILIO_AUTH_TOKEN");
const TWILIO_PHONE_NUMBER = Deno.env.get("TWILIO_PHONE_NUMBER");
const TWILIO_WEBHOOK_BASE_URL = Deno.env.get("TWILIO_WEBHOOK_BASE_URL") ??
  `${SUPABASE_URL}/functions/v1`;

function xmlResponse(body: string) {
  return new Response(body, {
    status: 200,
    headers: { "Content-Type": "text/xml; charset=utf-8" },
  });
}

Deno.serve(async (req) => {
  const url = new URL(req.url);
  const callSessionId = url.searchParams.get("call_session_id");
  if (!callSessionId) {
    return xmlResponse(
      `<?xml version="1.0" encoding="UTF-8"?><Response><Say voice="Polly.Aditi">Invalid call session.</Say><Hangup/></Response>`,
    );
  }

  const conferenceName = `session-${callSessionId}`;
  const holdMusicUrl = `${TWILIO_WEBHOOK_BASE_URL}/twiml-hold-music`;
  const conferenceStatusUrl =
    `${TWILIO_WEBHOOK_BASE_URL}/twilio-status-webhook?call_session_id=${callSessionId}&leg=conference`;

  const twiml = `<?xml version="1.0" encoding="UTF-8"?>
<Response>
  <Say voice="Polly.Aditi">Connecting you to your AstroGuide customer. Please wait a moment.</Say>
  <Dial>
    <Conference
      waitUrl="${holdMusicUrl}"
      startConferenceOnEnter="false"
      endConferenceOnExit="true"
      statusCallback="${conferenceStatusUrl}"
      statusCallbackEvent="join leave end">${conferenceName}</Conference>
  </Dial>
</Response>`;

  // Fire-and-forget: dial the customer leg now (astrologer is being placed in conference)
  if (TWILIO_ACCOUNT_SID && TWILIO_AUTH_TOKEN && TWILIO_PHONE_NUMBER) {
    (async () => {
      try {
        const admin = createClient(SUPABASE_URL, SERVICE_ROLE_KEY);
        const { data: session } = await admin
          .from("call_sessions")
          .select("id, status, user_id, twilio_user_call_sid")
          .eq("id", callSessionId)
          .maybeSingle();

        if (
          !session || session.twilio_user_call_sid ||
          ["completed", "failed", "cancelled", "declined", "no_answer"].includes(session.status)
        ) return;

        const { data: profile } = await admin
          .from("profiles")
          .select("phone_e164")
          .eq("id", session.user_id)
          .maybeSingle();
        if (!profile?.phone_e164) return;

        const userTwimlUrl =
          `${TWILIO_WEBHOOK_BASE_URL}/twiml-user-leg?call_session_id=${callSessionId}`;
        const statusUrl =
          `${TWILIO_WEBHOOK_BASE_URL}/twilio-status-webhook?call_session_id=${callSessionId}&leg=user`;

        const form = new URLSearchParams({
          To: profile.phone_e164,
          From: TWILIO_PHONE_NUMBER,
          Url: userTwimlUrl,
          StatusCallback: statusUrl,
          Timeout: "30",
          Record: "true",
        });
        form.append("StatusCallbackEvent", "initiated");
        form.append("StatusCallbackEvent", "ringing");
        form.append("StatusCallbackEvent", "answered");
        form.append("StatusCallbackEvent", "completed");

        const res = await fetch(
          `https://api.twilio.com/2010-04-01/Accounts/${TWILIO_ACCOUNT_SID}/Calls.json`,
          {
            method: "POST",
            headers: {
              Authorization: "Basic " + btoa(`${TWILIO_ACCOUNT_SID}:${TWILIO_AUTH_TOKEN}`),
              "Content-Type": "application/x-www-form-urlencoded",
            },
            body: form.toString(),
          },
        );
        const data = await res.json();
        if (res.ok) {
          await admin
            .from("call_sessions")
            .update({ status: "ringing_user", twilio_user_call_sid: data.sid })
            .eq("id", callSessionId);
        } else {
          console.error("Failed to dial user", data);
        }
      } catch (e) {
        console.error("Error dialing user leg", e);
      }
    })();
  }

  return xmlResponse(twiml);
});
