import { createClient } from "npm:@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });

  try {
    const authHeader = req.headers.get("Authorization");
    if (!authHeader) return j({ error: "Unauthorized" }, 401);

    const supabase = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!,
    );

    const { data: { user } } = await supabase.auth.getUser(authHeader.replace("Bearer ", ""));
    if (!user) return j({ error: "Unauthorized" }, 401);

    const { session_id, action } = await req.json();
    if (!session_id || !["accept", "reject"].includes(action)) {
      return j({ error: "Invalid input" }, 400);
    }

    const { data: session, error: sessErr } = await supabase
      .from("chat_sessions")
      .select("id, user_id, astrologer_id, status, per_minute_rate, wallet_hold_amount")
      .eq("id", session_id)
      .single();
    if (sessErr || !session) return j({ error: "Session not found" }, 404);

    // Verify caller owns the astrologer
    const { data: astro } = await supabase
      .from("astrologers")
      .select("user_id")
      .eq("id", session.astrologer_id)
      .single();
    if (!astro || astro.user_id !== user.id) return j({ error: "Forbidden" }, 403);
    if (session.status !== "pending") return j({ error: "Session is not pending" }, 400);

    if (action === "reject") {
      await supabase.from("chat_sessions").update({
        status: "rejected",
        ended_at: new Date().toISOString(),
        end_reason: "rejected_by_astrologer",
      }).eq("id", session_id);
      return j({ ok: true });
    }

    const { error: holdErr } = await supabase.rpc("hold_wallet_for_chat", {
      _user_id: session.user_id,
      _amount: Number(session.wallet_hold_amount),
      _chat_session_id: session_id,
    });
    if (holdErr) {
      await supabase.from("chat_sessions").update({
        status: "rejected",
        ended_at: new Date().toISOString(),
        end_reason: `hold_failed: ${holdErr.message}`,
      }).eq("id", session_id);
      return j({ error: `Could not place wallet hold: ${holdErr.message}` }, 400);
    }

    const now = new Date().toISOString();
    await supabase.from("chat_sessions").update({
      status: "active",
      accepted_at: now,
      last_billed_at: now,
    }).eq("id", session_id);

    await supabase.from("chat_messages").insert({
      session_id,
      sender_id: user.id,
      sender_role: "system",
      content: "Chat session started. Charges have begun.",
    });

    return j({ ok: true });
  } catch (e) {
    return j({ error: (e as Error).message }, 500);
  }
});

function j(body: unknown, status = 200) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { ...corsHeaders, "Content-Type": "application/json" },
  });
}
