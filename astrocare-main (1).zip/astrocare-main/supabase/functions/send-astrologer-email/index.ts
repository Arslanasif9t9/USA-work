import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.45.0'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

// Lightweight email sender. Uses Resend if RESEND_API_KEY is set.
// Otherwise logs the email to the notifications table only.
Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders })

  try {
    const auth = req.headers.get('Authorization') ?? ''
    const supa = createClient(
      Deno.env.get('SUPABASE_URL')!,
      Deno.env.get('SUPABASE_ANON_KEY')!,
      { global: { headers: { Authorization: auth } } },
    )
    const { data: { user } } = await supa.auth.getUser()
    if (!user) {
      return new Response(JSON.stringify({ error: 'unauthorized' }), { status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' } })
    }

    const { subject, html, to } = await req.json()
    if (!subject || !html) {
      return new Response(JSON.stringify({ error: 'missing fields' }), { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } })
    }

    // Resolve recipient: explicit `to`, then payout settings notification_email, then auth user email
    let recipient = to as string | undefined
    if (!recipient) {
      const { data: ps } = await supa.from('astrologer_payout_settings').select('notification_email').eq('user_id', user.id).maybeSingle()
      recipient = ps?.notification_email ?? user.email ?? undefined
    }
    if (!recipient) {
      return new Response(JSON.stringify({ error: 'no recipient' }), { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } })
    }

    const resendKey = Deno.env.get('RESEND_API_KEY')
    if (resendKey) {
      const r = await fetch('https://api.resend.com/emails', {
        method: 'POST',
        headers: { Authorization: `Bearer ${resendKey}`, 'Content-Type': 'application/json' },
        body: JSON.stringify({
          from: 'AstroCare <onboarding@resend.dev>',
          to: [recipient],
          subject,
          html,
        }),
      })
      const txt = await r.text()
      if (!r.ok) {
        console.error('resend failed', txt)
      }
    } else {
      console.log('[email-fallback]', recipient, subject)
    }

    return new Response(JSON.stringify({ ok: true, recipient }), { headers: { ...corsHeaders, 'Content-Type': 'application/json' } })
  } catch (e) {
    console.error(e)
    return new Response(JSON.stringify({ error: String((e as Error).message) }), { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } })
  }
})
