// deno-lint-ignore-file no-explicit-any
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.45.0";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type",
};

// Vimshottari sequence + total years for each lord
const SEQUENCE = ["Ketu","Venus","Sun","Moon","Mars","Rahu","Jupiter","Saturn","Mercury"] as const;
type Lord = typeof SEQUENCE[number];
const YEARS: Record<Lord, number> = {
  Ketu: 7, Venus: 20, Sun: 6, Moon: 10, Mars: 7,
  Rahu: 18, Jupiter: 16, Saturn: 19, Mercury: 17,
};
const TOTAL_YEARS = 120;

const NAKSHATRA_LORDS: Lord[] = [
  "Ketu","Venus","Sun","Moon","Mars","Rahu","Jupiter","Saturn","Mercury",
  "Ketu","Venus","Sun","Moon","Mars","Rahu","Jupiter","Saturn","Mercury",
  "Ketu","Venus","Sun","Moon","Mars","Rahu","Jupiter","Saturn","Mercury",
];
const NAKSHATRA_NAMES = [
  "Ashwini","Bharani","Krittika","Rohini","Mrigashira","Ardra",
  "Punarvasu","Pushya","Ashlesha","Magha","Purva Phalguni","Uttara Phalguni",
  "Hasta","Chitra","Swati","Vishakha","Anuradha","Jyeshtha","Mula",
  "Purva Ashadha","Uttara Ashadha","Shravana","Dhanishta","Shatabhisha",
  "Purva Bhadrapada","Uttara Bhadrapada","Revati",
];

const NAK_SPAN = 360 / 27;
const SIDEREAL_YEAR_DAYS = 365.25;

interface DashaNode {
  lord: Lord;
  start: string;
  end: string;
  years: number;
  children?: DashaNode[];
}

function addYears(date: Date, years: number): Date {
  return new Date(date.getTime() + years * SIDEREAL_YEAR_DAYS * 86400 * 1000);
}
function rotated(startLord: Lord): Lord[] {
  const i = SEQUENCE.indexOf(startLord);
  return [...SEQUENCE.slice(i), ...SEQUENCE.slice(0, i)];
}

function buildSubPeriods(
  parentLord: Lord, parentYears: number, parentStart: Date, depth: number, maxDepth: number,
): DashaNode[] {
  if (depth >= maxDepth) return [];
  const order = rotated(parentLord);
  const out: DashaNode[] = [];
  let cursor = parentStart;
  for (const lord of order) {
    const years = (parentYears * YEARS[lord]) / TOTAL_YEARS;
    const end = addYears(cursor, years);
    out.push({
      lord, start: cursor.toISOString(), end: end.toISOString(), years,
      children: buildSubPeriods(lord, years, cursor, depth + 1, maxDepth),
    });
    cursor = end;
  }
  return out;
}

function buildDashaTreeInHouse(birthUtc: Date, moonLongitude: number) {
  const moonNorm = ((moonLongitude % 360) + 360) % 360;
  const nakIdx = Math.floor(moonNorm / NAK_SPAN);
  const withinNak = moonNorm - nakIdx * NAK_SPAN;
  const startLord = NAKSHATRA_LORDS[nakIdx];
  const fraction = withinNak / NAK_SPAN;
  const remainingFirst = YEARS[startLord] * (1 - fraction);

  const mahas: DashaNode[] = [];
  const order = rotated(startLord);
  let cursor = birthUtc;
  for (let i = 0; i < order.length; i++) {
    const lord = order[i];
    const years = i === 0 ? remainingFirst : YEARS[lord];
    const end = addYears(cursor, years);
    mahas.push({
      lord, start: cursor.toISOString(), end: end.toISOString(), years,
      children: buildSubPeriods(lord, years, cursor, 1, 4),
    });
    cursor = end;
  }
  return {
    starting_nakshatra: NAKSHATRA_NAMES[nakIdx],
    starting_lord: startLord,
    moon_longitude: moonNorm,
    birth_utc: birthUtc.toISOString(),
    mahadashas: mahas,
  };
}

interface CurrentPeriod {
  lord: Lord;
  start: string;
  end: string;
}
function findCurrent(nodes: DashaNode[], now: Date): CurrentPeriod | null {
  const t = now.getTime();
  for (const n of nodes) {
    const s = new Date(n.start).getTime();
    const e = new Date(n.end).getTime();
    if (t >= s && t < e) return { lord: n.lord, start: n.start, end: n.end };
  }
  return null;
}

// ============================================================================
// astrologyapi.com primary path
// ============================================================================
const API_BASE = "https://json.astrologyapi.com/v1";

async function callAstrologyApi(path: string, body: unknown): Promise<any> {
  const userId = Deno.env.get("ASTROLOGY_API_USER_ID");
  const apiKey = Deno.env.get("ASTROLOGY_API_KEY");
  if (!userId || !apiKey) throw new Error("astrologyapi credentials not configured");
  const auth = btoa(`${userId}:${apiKey}`);
  const res = await fetch(`${API_BASE}/${path}`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "Authorization": `Basic ${auth}`,
      "Accept-Language": "en",
    },
    body: JSON.stringify(body),
  });
  if (!res.ok) {
    const text = await res.text().catch(() => "");
    throw new Error(`astrologyapi ${path} ${res.status}: ${text.slice(0, 200)}`);
  }
  return res.json();
}

interface ProviderInput {
  day: number; month: number; year: number;
  hour: number; min: number;
  lat: number; lon: number; tzone: number;
}

function tzOffsetHours(date: string, time: string, tz: string): number {
  const isoLocal = `${date}T${time}:00`;
  const asUtc = new Date(isoLocal + "Z");
  const dtf = new Intl.DateTimeFormat("en-US", {
    timeZone: tz, hour12: false,
    year: "numeric", month: "2-digit", day: "2-digit",
    hour: "2-digit", minute: "2-digit", second: "2-digit",
  });
  const parts = Object.fromEntries(dtf.formatToParts(asUtc).map(p => [p.type, p.value]));
  const asTz = Date.UTC(+parts.year, +parts.month - 1, +parts.day,
    +parts.hour, +parts.minute, +parts.second);
  return (asTz - asUtc.getTime()) / 3600000;
}

/**
 * Provider returns mahadasha + antardasha + pratyantardasha as nested arrays.
 * We map those into our DashaNode tree shape.
 *
 * Endpoint shape (vimsottari/maha_dasas_and_antar_dasas):
 *   { mahadasha: [{name, start, end, antardasha: [{name,start,end, pratyantardasha:[...]}, ...]}, ...] }
 * Dates are "YYYY-MM-DD" strings (provider local). We treat them as midnight UTC.
 */
function parseProviderDate(s: string): Date {
  // Accept YYYY-MM-DD or full ISO; coerce to ISO midnight UTC if date-only.
  if (/^\d{4}-\d{2}-\d{2}$/.test(s)) return new Date(`${s}T00:00:00Z`);
  return new Date(s);
}
function yearsBetween(a: Date, b: Date): number {
  return (b.getTime() - a.getTime()) / (SIDEREAL_YEAR_DAYS * 86400 * 1000);
}

function mapProviderTree(
  provider: any,
  birthUtc: Date,
  moonLongitude: number,
): { tree: ReturnType<typeof buildDashaTreeInHouse>; ok: boolean } {
  const list = provider?.mahadasha ?? provider?.maha_dasha ?? provider;
  if (!Array.isArray(list)) {
    return { tree: buildDashaTreeInHouse(birthUtc, moonLongitude), ok: false };
  }
  const moonNorm = ((moonLongitude % 360) + 360) % 360;
  const nakIdx = Math.floor(moonNorm / NAK_SPAN);
  const startLord = NAKSHATRA_LORDS[nakIdx];

  const mapNode = (raw: any): DashaNode | null => {
    const lord = String(raw?.name ?? raw?.lord ?? "") as Lord;
    if (!SEQUENCE.includes(lord)) return null;
    const start = parseProviderDate(String(raw?.start ?? raw?.start_date));
    const end = parseProviderDate(String(raw?.end ?? raw?.end_date));
    const childList = raw?.antardasha ?? raw?.pratyantardasha ?? raw?.children;
    const children = Array.isArray(childList)
      ? childList.map(mapNode).filter((n): n is DashaNode => n !== null)
      : undefined;
    return {
      lord,
      start: start.toISOString(),
      end: end.toISOString(),
      years: yearsBetween(start, end),
      children,
    };
  };

  const mahas = list.map(mapNode).filter((n): n is DashaNode => n !== null);
  if (mahas.length < 9) {
    return { tree: buildDashaTreeInHouse(birthUtc, moonLongitude), ok: false };
  }

  return {
    tree: {
      starting_nakshatra: NAKSHATRA_NAMES[nakIdx],
      starting_lord: startLord,
      moon_longitude: moonNorm,
      birth_utc: birthUtc.toISOString(),
      mahadashas: mahas,
    },
    ok: true,
  };
}

async function buildDashaTreeViaProvider(
  input: ProviderInput,
  birthUtc: Date,
  moonLongitude: number,
) {
  const data = await callAstrologyApi("vimsottari/maha_dasas_and_antar_dasas", input);
  const { tree, ok } = mapProviderTree(data, birthUtc, moonLongitude);
  if (!ok) throw new Error("provider dasha shape unrecognized");
  return tree;
}

function json(body: unknown, status = 200) {
  return new Response(JSON.stringify(body), {
    status, headers: { ...corsHeaders, "Content-Type": "application/json" },
  });
}

// ============================================================================
// Handler
// ============================================================================
function buildPayload(
  birthDate: string,
  birthTimeStr: string,
  timeUnknown: boolean,
  tz: string,
  latitude: number,
  longitude: number,
  moonLongitude: number,
) {
  const birthTime = timeUnknown || !birthTimeStr ? "12:00" : birthTimeStr.slice(0, 5);
  const tzOff = tzOffsetHours(birthDate, birthTime, tz);
  const [yy, mm, dd] = birthDate.split("-").map(Number);
  const [hh, mn] = birthTime.split(":").map(Number);
  const birthUtc = new Date(
    Date.UTC(yy, mm - 1, dd, hh, mn, 0) - tzOff * 3600 * 1000,
  );
  return { yy, mm, dd, hh, mn, tzOff, birthUtc, latitude, longitude, moonLongitude };
}

async function computeTree(p: ReturnType<typeof buildPayload>) {
  let tree: ReturnType<typeof buildDashaTreeInHouse>;
  let source: "astrologyapi" | "inhouse" = "inhouse";
  try {
    tree = await buildDashaTreeViaProvider(
      {
        day: p.dd, month: p.mm, year: p.yy, hour: p.hh, min: p.mn,
        lat: Number(p.latitude), lon: Number(p.longitude), tzone: p.tzOff,
      },
      p.birthUtc,
      p.moonLongitude,
    );
    source = "astrologyapi";
  } catch (provErr) {
    const msg = provErr instanceof Error ? provErr.message : String(provErr);
    console.warn("[compute-dasha] provider failed, using in-house:", msg);
    tree = buildDashaTreeInHouse(p.birthUtc, p.moonLongitude);
  }
  return { tree, source };
}

function currentMarkers(tree: ReturnType<typeof buildDashaTreeInHouse>) {
  const now = new Date();
  const currentMaha = findCurrent(tree.mahadashas, now);
  const currentAntar = currentMaha
    ? findCurrent(
        tree.mahadashas.find(m => m.start === currentMaha.start)?.children ?? [],
        now,
      )
    : null;
  return { currentMaha, currentAntar };
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });
  try {
    const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
    const ANON_KEY = Deno.env.get("SUPABASE_ANON_KEY")!;

    const body = await req.json().catch(() => ({}));
    const birthChartId = body?.birth_chart_id;
    const birthData = body?.birth_data;
    const isAnonymous = !birthChartId && birthData && typeof birthData === "object";

    // ========= ANONYMOUS MODE =========
    if (isAnonymous) {
      const moonLongitude = Number(birthData.moon_longitude);
      if (!Number.isFinite(moonLongitude)) {
        return json({ error: "moon_longitude required in birth_data" }, 422);
      }
      // Accept either decomposed fields or our common shape.
      const yy = Number(birthData.year), mm = Number(birthData.month), dd = Number(birthData.day);
      const hh = Number(birthData.hour ?? 12), mn = Number(birthData.min ?? 0);
      const tzOff = Number(birthData.tzone ?? 5.5);
      const birthUtc = new Date(
        Date.UTC(yy, mm - 1, dd, hh, mn, 0) - tzOff * 3600 * 1000,
      );
      const p = {
        yy, mm, dd, hh, mn, tzOff, birthUtc,
        latitude: Number(birthData.lat ?? 0),
        longitude: Number(birthData.lon ?? 0),
        moonLongitude,
      };
      const { tree, source } = await computeTree(p);
      const { currentMaha, currentAntar } = currentMarkers(tree);
      console.log("[compute-dasha] anonymous mode ok", { source, starting: tree.starting_lord });
      return json({
        success: true, anonymous: true, source,
        dasha_tree: { ...tree, source },
        current_maha_lord: currentMaha?.lord ?? null,
        current_maha_start: currentMaha?.start ?? null,
        current_maha_end: currentMaha?.end ?? null,
        current_antar_lord: currentAntar?.lord ?? null,
        current_antar_start: currentAntar?.start ?? null,
        current_antar_end: currentAntar?.end ?? null,
      });
    }

    // ========= AUTHENTICATED MODE =========
    const auth = req.headers.get("Authorization");
    if (!auth) return json({ error: "Unauthorized" }, 401);

    const userClient = createClient(SUPABASE_URL, ANON_KEY, {
      global: { headers: { Authorization: auth } },
    });
    const { data: { user } } = await userClient.auth.getUser();
    if (!user) return json({ error: "Unauthorized" }, 401);

    if (!birthChartId || typeof birthChartId !== "string") {
      return json({ error: "birth_chart_id required" }, 400);
    }

    const { data: chart, error: chartErr } = await userClient
      .from("birth_charts")
      .select("id, user_id, chart_data, birth_date, birth_time, time_unknown, latitude, longitude, timezone")
      .eq("id", birthChartId)
      .maybeSingle();
    if (chartErr || !chart) return json({ error: "Chart not found" }, 404);

    const moon = (chart.chart_data?.planets ?? []).find((p: any) => p?.name === "Moon");
    if (!moon || typeof moon.longitude !== "number") {
      return json({ error: "Moon longitude not found in chart_data" }, 422);
    }

    const p = buildPayload(
      String(chart.birth_date),
      String(chart.birth_time ?? ""),
      !!chart.time_unknown,
      String(chart.timezone),
      Number(chart.latitude),
      Number(chart.longitude),
      moon.longitude,
    );
    const { tree, source } = await computeTree(p);
    const { currentMaha, currentAntar } = currentMarkers(tree);

    const SERVICE_KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const admin = createClient(SUPABASE_URL, SERVICE_KEY);
    const { data: upserted, error: upErr } = await admin
      .from("vimshottari_dasha")
      .upsert({
        birth_chart_id: birthChartId,
        user_id: chart.user_id,
        dasha_tree: { ...tree, source },
        current_maha_lord: currentMaha?.lord ?? null,
        current_maha_start: currentMaha?.start ?? null,
        current_maha_end: currentMaha?.end ?? null,
        current_antar_lord: currentAntar?.lord ?? null,
        current_antar_start: currentAntar?.start ?? null,
        current_antar_end: currentAntar?.end ?? null,
        computed_at: new Date().toISOString(),
      }, { onConflict: "birth_chart_id" })
      .select("id")
      .single();
    if (upErr) {
      console.error("upsert error", upErr);
      return json({ error: upErr.message }, 500);
    }

    return json({ success: true, dasha_id: upserted.id, source });
  } catch (e) {
    const msg = e instanceof Error ? e.message : String(e);
    console.error("compute-dasha error:", msg);
    return json({ error: msg }, 500);
  }
});
