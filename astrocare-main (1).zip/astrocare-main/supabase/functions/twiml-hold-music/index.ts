// Returns TwiML with Twilio hold music for the conference wait.
const xml = `<?xml version="1.0" encoding="UTF-8"?>
<Response>
  <Play loop="0">https://com.twilio.sounds.music.s3.amazonaws.com/MARKOVICHAMP-Borghestral.mp3</Play>
</Response>`;

Deno.serve(() => {
  return new Response(xml, {
    status: 200,
    headers: { "Content-Type": "text/xml; charset=utf-8" },
  });
});
