// Admin user management — master_admin only.
// Actions: create, update, set_active, reset_password
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.45.0";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });

  try {
    const auth = req.headers.get("Authorization") || "";
    const token = auth.replace("Bearer ", "");
    if (!token) return json({ ok: false, error: "Missing auth" }, 401);

    const url = Deno.env.get("SUPABASE_URL")!;
    const service = createClient(url, Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!);

    // Identify caller via JWT
    const { data: who, error: whoErr } = await service.auth.getUser(token);
    if (whoErr || !who.user) return json({ ok: false, error: "Invalid session" }, 401);

    // Look up caller (any active admin role)
    const { data: caller } = await service
      .from("admin_users").select("*").eq("user_id", who.user.id).maybeSingle();
    if (!caller || !caller.is_active) {
      return json({ ok: false, error: "Not an active admin" }, 403);
    }

    const body = await req.json().catch(() => ({}));
    const action = String(body.action || "");

    // Any active admin can change THEIR OWN password (requires current password)
    if (action === "change_own_password") {
      const { current_password, new_password } = body;
      if (!current_password || !new_password) return json({ ok: false, error: "Missing fields" }, 400);
      if (String(new_password).length < 8) return json({ ok: false, error: "Password must be at least 8 characters" }, 400);

      // Verify current password via a separate anon client
      const anon = createClient(url, Deno.env.get("SUPABASE_ANON_KEY")!);
      const { error: signErr } = await anon.auth.signInWithPassword({
        email: who.user.email!, password: current_password,
      });
      if (signErr) return json({ ok: false, error: "Current password is incorrect" }, 400);

      const { error } = await service.auth.admin.updateUserById(who.user.id, { password: new_password });
      if (error) return json({ ok: false, error: error.message }, 400);

      await logAction(service, caller.id, "admin.change_own_password", "admin_user", caller.id, {});
      return json({ ok: true });
    }

    // All remaining actions require master_admin
    if (caller.role !== "master_admin") {
      return json({ ok: false, error: "Master admin only" }, 403);
    }

    if (action === "create") {
      const { full_name, email, role, permissions, password,
              can_directly_adjust_wallet, max_wallet_adjustment } = body;
      if (!email || !password || !role) return json({ ok: false, error: "Missing fields" }, 400);
      // Hardcoded: only one master admin allowed (Fix 1)
      if (!["admin", "finance_admin"].includes(role)) return json({ ok: false, error: "Cannot create another master admin — only one is allowed" }, 400);

      // Create auth user
      const { data: created, error } = await service.auth.admin.createUser({
        email, password, email_confirm: true, user_metadata: { name: full_name || "" },
      });
      if (error) return json({ ok: false, error: error.message }, 400);

      const { error: insErr } = await service.from("admin_users").insert({
        user_id: created.user!.id,
        email,
        full_name: full_name || "",
        role,
        permissions: Array.isArray(permissions) ? permissions : [],
        is_active: true,
        created_by: caller.id,
        can_directly_adjust_wallet: typeof can_directly_adjust_wallet === "boolean" ? can_directly_adjust_wallet : true,
        max_wallet_adjustment: max_wallet_adjustment != null && max_wallet_adjustment !== "" ? Number(max_wallet_adjustment) : null,
      });
      if (insErr) return json({ ok: false, error: insErr.message }, 400);

      await logAction(service, caller.id, "admin.create", "admin_user", created.user!.id, { email, role });
      return json({ ok: true });
    }

    if (action === "update") {
      const { admin_id, full_name, role, permissions,
              can_directly_adjust_wallet, max_wallet_adjustment } = body;
      const { data: target } = await service.from("admin_users").select("*").eq("id", admin_id).maybeSingle();
      if (!target) return json({ ok: false, error: "Not found" }, 404);
      if (target.role === "master_admin") return json({ ok: false, error: "Cannot edit master admin" }, 403);

      const patch: any = {};
      if (typeof full_name === "string") patch.full_name = full_name;
      if (role && ["admin", "finance_admin"].includes(role)) patch.role = role;
      if (Array.isArray(permissions)) patch.permissions = permissions;
      if (typeof can_directly_adjust_wallet === "boolean") patch.can_directly_adjust_wallet = can_directly_adjust_wallet;
      if (max_wallet_adjustment !== undefined)
        patch.max_wallet_adjustment = max_wallet_adjustment === null || max_wallet_adjustment === "" ? null : Number(max_wallet_adjustment);

      const { error } = await service.from("admin_users").update(patch).eq("id", admin_id);
      if (error) return json({ ok: false, error: error.message }, 400);

      await logAction(service, caller.id, "admin.update", "admin_user", admin_id, patch);
      return json({ ok: true });
    }

    if (action === "set_active") {
      const { admin_id, is_active } = body;
      const { data: target } = await service.from("admin_users").select("*").eq("id", admin_id).maybeSingle();
      if (!target) return json({ ok: false, error: "Not found" }, 404);
      if (target.role === "master_admin") return json({ ok: false, error: "Cannot deactivate master admin" }, 403);
      if (target.user_id === who.user.id) return json({ ok: false, error: "Cannot change your own status" }, 403);

      const { error } = await service.from("admin_users").update({ is_active: !!is_active }).eq("id", admin_id);
      if (error) return json({ ok: false, error: error.message }, 400);

      await logAction(service, caller.id, is_active ? "admin.activate" : "admin.deactivate", "admin_user", admin_id, {});
      return json({ ok: true });
    }

    if (action === "reset_password") {
      const { admin_id, password } = body;
      if (!password) return json({ ok: false, error: "Missing password" }, 400);
      const { data: target } = await service.from("admin_users").select("*").eq("id", admin_id).maybeSingle();
      if (!target) return json({ ok: false, error: "Not found" }, 404);

      const { error } = await service.auth.admin.updateUserById(target.user_id, { password });
      if (error) return json({ ok: false, error: error.message }, 400);

      await logAction(service, caller.id, "admin.reset_password", "admin_user", admin_id, {});
      return json({ ok: true });
    }

    return json({ ok: false, error: "Unknown action" }, 400);
  } catch (e: any) {
    return json({ ok: false, error: e?.message || String(e) }, 500);
  }
});

function json(b: unknown, status = 200) {
  return new Response(JSON.stringify(b), {
    status, headers: { ...corsHeaders, "content-type": "application/json" },
  });
}

async function logAction(svc: any, adminRowId: string, action: string, target_type: string, target_id: string, details: any) {
  await svc.from("admin_activity_log").insert({
    admin_id: adminRowId, action, target_type, target_id, details,
  });
}
