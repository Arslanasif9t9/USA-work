// Receives recording webhook from Twilio after the conference call ends.
import { createClient } from "npm:@supabase/supabase-js@2.45.0";

const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
const SERVICE_ROLE_KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;

Deno.serve(async (req) => {
  if (req.method !== "POST") return new Response("ok", { status: 200 });
  try {
    const url = new URL(req.url);
    const callSessionId = url.searchParams.get("call_session_id");
    const formText = await req.text();
    const params: Record<string, string> = {};
    for (const [k, v] of new URLSearchParams(formText)) params[k] = v;

    if (callSessionId && params.RecordingUrl) {
      const admin = createClient(SUPABASE_URL, SERVICE_ROLE_KEY);
      await admin
        .from("call_sessions")
        .update({
          recording_url: `${params.RecordingUrl}.mp3`,
          recording_sid: params.RecordingSid ?? null,
        })
        .eq("id", callSessionId);
    }
  } catch (e) {
    console.error("recording webhook error", e);
  }
  return new Response("ok", { status: 200 });
});
