// deno-lint-ignore-file no-explicit-any
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.45.0";
import * as Astronomy from "npm:astronomy-engine@2.1.19";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type",
  "Access-Control-Expose-Headers": "x-cache",
};

// Bump this when the response shape changes — old cache entries
// missing this version (or with a lower one) are recomputed.
// v3: switched Lagna + planet positions to astrologyapi.com /planets/extended
//     (Swiss Ephemeris, Lahiri sidereal) — fixes 180° Lagna flip + Pluto drift.
// v4: cache invalidation only (no math change).
// v5: cache invalidation + documented upstream ayanamsa limitation.
// v6: cache invalidation only — confirmed via direct probe that astrologyapi
//     ignores ayanamsa overrides on /planets and /planets/extended.
// v7: drop outer planets (Uranus, Neptune, Pluto) from the response. They
//     are not part of traditional Vedic astrology and were the only bodies
//     showing >1' drift vs AstroSage. Output is now exactly the 9 classical
//     Grahas: Sun, Moon, Mars, Mercury, Jupiter, Venus, Saturn, Rahu, Ketu.
const PAYLOAD_VERSION = 7;

const TITHI_NAMES = [
  "Pratipada","Dwitiya","Tritiya","Chaturthi","Panchami","Shashthi",
  "Saptami","Ashtami","Navami","Dashami","Ekadashi","Dwadashi",
  "Trayodashi","Chaturdashi","Purnima",
  "Pratipada","Dwitiya","Tritiya","Chaturthi","Panchami","Shashthi",
  "Saptami","Ashtami","Navami","Dashami","Ekadashi","Dwadashi",
  "Trayodashi","Chaturdashi","Amavasya",
];
const NAKSHATRAS = [
  "Ashwini","Bharani","Krittika","Rohini","Mrigashira","Ardra",
  "Punarvasu","Pushya","Ashlesha","Magha","Purva Phalguni","Uttara Phalguni",
  "Hasta","Chitra","Swati","Vishakha","Anuradha","Jyeshtha","Mula",
  "Purva Ashadha","Uttara Ashadha","Shravana","Dhanishta","Shatabhisha",
  "Purva Bhadrapada","Uttara Bhadrapada","Revati",
];
const YOGAS = [
  "Vishkambha","Priti","Ayushman","Saubhagya","Shobhana","Atiganda",
  "Sukarma","Dhriti","Shula","Ganda","Vriddhi","Dhruva","Vyaghata","Harshana",
  "Vajra","Siddhi","Vyatipata","Variyana","Parigha","Shiva","Siddha","Sadhya",
  "Shubha","Shukla","Brahma","Indra","Vaidhriti",
];
const KARANA_REPEAT = ["Bava","Balava","Kaulava","Taitila","Garaja","Vanija","Vishti"];
const VAARS = ["Ravivar","Somvar","Mangalvar","Budhvar","Guruvar","Shukravar","Shanivar"];
const SIGN_NAMES = [
  "Aries","Taurus","Gemini","Cancer","Leo","Virgo",
  "Libra","Scorpio","Sagittarius","Capricorn","Aquarius","Pisces",
];

// Weekday → which 1-based slot (out of 8 daytime parts) is Rahu/Yamaganda/Gulika.
// Index 0 = Sunday.
const RAHU_SLOTS     = [8, 2, 7, 5, 6, 4, 3];
const YAMAGANDA_SLOTS= [5, 4, 3, 2, 1, 7, 6];
const GULIKA_SLOTS   = [7, 6, 5, 4, 3, 2, 1];

// Hora: Chaldean order. Index 0 = Sunday's first hora ruler, etc.
// Each weekday's first hora belongs to its planetary lord.
// Order of the cycle: Sun, Venus, Mercury, Moon, Saturn, Jupiter, Mars
const CHALDEAN = ["Sun","Venus","Mercury","Moon","Saturn","Jupiter","Mars"];
const CHALDEAN_SANSKRIT: Record<string,string> = {
  Sun:"Surya", Venus:"Shukra", Mercury:"Budha", Moon:"Chandra",
  Saturn:"Shani", Jupiter:"Guru", Mars:"Mangal",
};
// Day-of-week (Sun=0..Sat=6) → first hora ruler
const WEEKDAY_LORD = ["Sun","Moon","Mars","Mercury","Jupiter","Venus","Saturn"];

const norm360 = (x: number) => ((x % 360) + 360) % 360;

function lahiriAyanamsa(jd: number): number {
  const t = (jd - 2451545.0) / 365.25;
  return 23.85 + (50.29 / 3600) * t;
}

function julianFromDate(d: Date): number {
  let Y = d.getUTCFullYear();
  let M = d.getUTCMonth() + 1;
  const D = d.getUTCDate()
    + (d.getUTCHours() + d.getUTCMinutes()/60 + d.getUTCSeconds()/3600) / 24;
  if (M <= 2) { Y -= 1; M += 12; }
  const A = Math.floor(Y / 100), B = 2 - A + Math.floor(A / 4);
  return Math.floor(365.25 * (Y + 4716)) + Math.floor(30.6001 * (M + 1)) + D + B - 1524.5;
}

function eclipticLon(body: any, date: Date): number {
  const vec = Astronomy.GeoVector(body, date, true);
  const ecl = Astronomy.Ecliptic(vec);
  return norm360(ecl.elon);
}

// Returns the offset (hours) between a given UTC instant and the given IANA timezone.
function tzOffsetHoursAt(utc: Date, tz: string): number {
  const dtf = new Intl.DateTimeFormat("en-US", {
    timeZone: tz, hour12: false,
    year: "numeric", month: "2-digit", day: "2-digit",
    hour: "2-digit", minute: "2-digit", second: "2-digit",
  });
  const parts = Object.fromEntries(dtf.formatToParts(utc).map(p => [p.type, p.value]));
  const asTz = Date.UTC(+parts.year, +parts.month - 1, +parts.day,
    +parts.hour, +parts.minute, +parts.second);
  return (asTz - utc.getTime()) / 3600000;
}

// Convert local Y-M-D in tz to a UTC Date.
function localDateToUtc(date: string, tz: string, hour = 0, minute = 0): Date {
  const [y, m, d] = date.split("-").map(Number);
  const naiveUtc = new Date(Date.UTC(y, m - 1, d, hour, minute, 0));
  // First-pass offset, then refine once
  const off1 = tzOffsetHoursAt(naiveUtc, tz);
  const adj1 = new Date(naiveUtc.getTime() - off1 * 3600 * 1000);
  const off2 = tzOffsetHoursAt(adj1, tz);
  return new Date(naiveUtc.getTime() - off2 * 3600 * 1000);
}

// JS Date.getDay equivalent for a date in given timezone
function weekdayInTz(date: string, tz: string): number {
  const noon = localDateToUtc(date, tz, 12, 0);
  const fmt = new Intl.DateTimeFormat("en-US", { timeZone: tz, weekday: "short" });
  const wd = fmt.format(noon);
  return ["Sun","Mon","Tue","Wed","Thu","Fri","Sat"].indexOf(wd);
}

function searchRiseSet(body: any, observer: any, direction: 1 | -1, dateStart: Date): Date | null {
  const t = Astronomy.SearchRiseSet(body, observer, direction, dateStart, 1);
  if (!t) return null;
  return new Date(t.date.getTime());
}

function slotWindow(sunrise: Date, sunset: Date, slot1Based: number, totalSlots = 8) {
  const dayMs = sunset.getTime() - sunrise.getTime();
  const part = dayMs / totalSlots;
  const start = new Date(sunrise.getTime() + (slot1Based - 1) * part);
  const end = new Date(sunrise.getTime() + slot1Based * part);
  return { start: start.toISOString(), end: end.toISOString() };
}

// Compute mean lunar node (Rahu) longitude in tropical degrees.
// Reference: Meeus "Astronomical Algorithms" formula for mean ascending node.
function meanRahuTrop(date: Date): number {
  const T = (julianFromDate(date) - 2451545.0) / 36525;
  // Mean longitude of ascending node of Moon
  const omega = 125.04452 - 1934.136261 * T + 0.0020708 * T * T + (T * T * T) / 450000;
  return norm360(omega);
}

// Compute sidereal longitude + retrograde flag for a planet at a given UTC date.
function planetSidereal(name: string, date: Date, ayan: number): { lon: number; retro: boolean } {
  const bodyMap: Record<string, any> = {
    Sun: Astronomy.Body.Sun,
    Moon: Astronomy.Body.Moon,
    Mars: Astronomy.Body.Mars,
    Mercury: Astronomy.Body.Mercury,
    Jupiter: Astronomy.Body.Jupiter,
    Venus: Astronomy.Body.Venus,
    Saturn: Astronomy.Body.Saturn,
    Uranus: Astronomy.Body.Uranus,
    Neptune: Astronomy.Body.Neptune,
    Pluto: Astronomy.Body.Pluto,
  };

  if (name === "Rahu") {
    const trop = meanRahuTrop(date);
    return { lon: norm360(trop - ayan), retro: true }; // Rahu is always retrograde (mean node)
  }
  if (name === "Ketu") {
    const trop = meanRahuTrop(date);
    return { lon: norm360(trop - ayan + 180), retro: true };
  }

  const body = bodyMap[name];
  const trop = eclipticLon(body, date);
  // Retrograde detection: compare longitude 1 day later
  const dt = new Date(date.getTime() + 86400 * 1000);
  const tropNext = eclipticLon(body, dt);
  // Account for wrap
  let delta = tropNext - trop;
  if (delta > 180) delta -= 360;
  if (delta < -180) delta += 360;
  // Sun and Moon are never considered retrograde
  const retro = (name === "Sun" || name === "Moon") ? false : delta < 0;
  return { lon: norm360(trop - ayan), retro };
}

// Local Sidereal Time (degrees), simplified Meeus formula.
function localSiderealDeg(date: Date, longitudeDeg: number): number {
  const jd = julianFromDate(date);
  const T = (jd - 2451545.0) / 36525;
  // Greenwich mean sidereal time in degrees
  const gmst =
    280.46061837 +
    360.98564736629 * (jd - 2451545.0) +
    0.000387933 * T * T -
    (T * T * T) / 38710000;
  return norm360(gmst + longitudeDeg);
}

// Compute Ascendant (tropical ecliptic longitude in degrees) using LST + observer lat.
// Standard formula: tan(Asc) = -cos(LST) / (sin(LST)*cos(eps) + tan(lat)*sin(eps))
function ascendantTrop(date: Date, latitudeDeg: number, longitudeDeg: number): number {
  const lstDeg = localSiderealDeg(date, longitudeDeg);
  const lst = (lstDeg * Math.PI) / 180;
  const lat = (latitudeDeg * Math.PI) / 180;
  const eps = (23.4392911 * Math.PI) / 180; // mean obliquity
  const num = -Math.cos(lst);
  const den = Math.sin(lst) * Math.cos(eps) + Math.tan(lat) * Math.sin(eps);
  let asc = (Math.atan2(num, den) * 180) / Math.PI;
  asc = norm360(asc);
  // Bring into the half-circle that lies "ahead" of the MC. Standard adjustment:
  // if Ascendant ends up in wrong half, add 180.
  // Compare with LST: ascendant should normally be > LST (eastward).
  // Empirical correction: if asc < lstDeg - 90 add 180; if asc > lstDeg + 270 subtract 180.
  // Simplest robust fix: keep asc in [0,360) — atan2 already covers correct quadrant
  // when num/den signs are preserved, which they are with atan2.
  return asc;
}

function buildHoraTables(sunrise: Date, sunset: Date, nextSunrise: Date, weekday: number) {
  // Day horas: 12 equal divisions of sunrise→sunset.
  const dayMs = sunset.getTime() - sunrise.getTime();
  const dayPart = dayMs / 12;
  const nightMs = nextSunrise.getTime() - sunset.getTime();
  const nightPart = nightMs / 12;

  const lordOfDay = WEEKDAY_LORD[weekday];
  const startIdx = CHALDEAN.indexOf(lordOfDay);

  const day = Array.from({ length: 12 }, (_, i) => {
    const planet = CHALDEAN[(startIdx + i) % 7];
    const start = new Date(sunrise.getTime() + i * dayPart);
    const end = new Date(sunrise.getTime() + (i + 1) * dayPart);
    return {
      hour: i + 1,
      planet,
      sanskrit: CHALDEAN_SANSKRIT[planet],
      start: start.toISOString(),
      end: end.toISOString(),
    };
  });
  const night = Array.from({ length: 12 }, (_, i) => {
    const planet = CHALDEAN[(startIdx + 12 + i) % 7];
    const start = new Date(sunset.getTime() + i * nightPart);
    const end = new Date(sunset.getTime() + (i + 1) * nightPart);
    return {
      hour: i + 1,
      planet,
      sanskrit: CHALDEAN_SANSKRIT[planet],
      start: start.toISOString(),
      end: end.toISOString(),
    };
  });
  return { day, night };
}

function json(body: unknown, status = 200, extraHeaders: Record<string, string> = {}) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { ...corsHeaders, "Content-Type": "application/json", ...extraHeaders },
  });
}

// 9 classical Vedic Grahas only — outer planets (Uranus, Neptune, Pluto)
// are intentionally excluded from all output.
const PLANET_ORDER = [
  "Sun","Moon","Mars","Mercury","Jupiter","Venus","Saturn","Rahu","Ketu",
];

// ============================================================================
// astrologyapi.com — Swiss Ephemeris primary path for Lagna + 12 planets.
// Fixes (a) the 180° Lagna sign-flip from the in-house ascendant trig and
// (b) the outer-planet drift (Pluto ~12') from the in-house perturbation series.
// ============================================================================
const API_BASE = "https://json.astrologyapi.com/v1";

async function callAstrologyApi(path: string, body: unknown): Promise<any> {
  const userId = Deno.env.get("ASTROLOGY_API_USER_ID");
  const apiKey = Deno.env.get("ASTROLOGY_API_KEY");
  if (!userId || !apiKey) throw new Error("astrologyapi credentials not configured");
  const auth = btoa(`${userId}:${apiKey}`);
  const res = await fetch(`${API_BASE}/${path}`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "Authorization": `Basic ${auth}`,
      "Accept-Language": "en",
    },
    body: JSON.stringify(body),
  });
  if (!res.ok) {
    const text = await res.text().catch(() => "");
    throw new Error(`astrologyapi ${path} ${res.status}: ${text.slice(0, 200)}`);
  }
  return res.json();
}

// Map provider planet name (any casing) to our canonical PLANET_ORDER name.
// Outer planets (Uranus/Neptune/Pluto) are intentionally NOT mapped — when
// the provider returns them they are silently dropped before we build the
// response, keeping the output to the 9 classical Vedic Grahas.
function canonicalPlanetName(raw: string): string | null {
  const n = String(raw || "").toLowerCase();
  if (n.startsWith("sun")) return "Sun";
  if (n.startsWith("moon")) return "Moon";
  if (n.startsWith("mars")) return "Mars";
  if (n.startsWith("mercury")) return "Mercury";
  if (n.startsWith("jupiter")) return "Jupiter";
  if (n.startsWith("venus")) return "Venus";
  if (n.startsWith("saturn")) return "Saturn";
  if (n.startsWith("rahu")) return "Rahu";
  if (n.startsWith("ketu")) return "Ketu";
  return null;
}

interface ProviderPlanet {
  name: string;
  longitude: number;     // sidereal Lahiri 0..360
  sign: number;          // 1..12
  sign_name: string;
  degree: number;        // 0..30 within sign
  nakshatra: number;     // 1..27
  nakshatra_name: string;
  pada: number;          // 1..4
  retrograde: boolean;
  house: number;         // 1..12 from provider (Lagna-relative, whole-sign)
}

interface ProviderResult {
  ascendant: { longitude: number; sign: number; sign_name: string; degree: number };
  planets: ProviderPlanet[];
}

/**
 * Fetch Lagna + 12 planet positions from astrologyapi.com `/planets/extended`
 * for the given UTC instant (typically sunrise). Lahiri sidereal.
 */
async function fetchPlanetsAtMoment(
  utc: Date,
  latitude: number,
  longitude: number,
  timezone: string,
): Promise<ProviderResult> {
  // tzone is a decimal float (e.g. 5.5 for IST). Compute it for the actual instant
  // so DST regions get the correct offset for that date.
  const tzone = tzOffsetHoursAt(utc, timezone);

  // Convert the UTC instant to the *local* wall-clock that the provider expects.
  const dtf = new Intl.DateTimeFormat("en-US", {
    timeZone: timezone, hour12: false,
    year: "numeric", month: "2-digit", day: "2-digit",
    hour: "2-digit", minute: "2-digit",
  });
  const parts = Object.fromEntries(dtf.formatToParts(utc).map(p => [p.type, p.value]));
  const body = {
    day: Number(parts.day),
    month: Number(parts.month),
    year: Number(parts.year),
    hour: Number(parts.hour) % 24, // Intl returns 24h with hour12:false
    min: Number(parts.minute),
    lat: latitude,
    lon: longitude,
    tzone,
  };

  const arr = await callAstrologyApi("planets/extended", body);
  if (!Array.isArray(arr)) throw new Error("planets/extended returned non-array");

  // Find ascendant (provider returns name="Ascendant")
  const ascRaw = arr.find((p) => /asc/i.test(String(p?.name)));
  if (!ascRaw) throw new Error("planets/extended response missing Ascendant");
  const ascLon = norm360(Number(ascRaw.fullDegree));
  const ascSignIdx = Math.floor(ascLon / 30);

  const NAK_SPAN = 360 / 27;
  const planets: ProviderPlanet[] = [];
  for (const raw of arr) {
    const canon = canonicalPlanetName(String(raw?.name));
    if (!canon) continue;
    const lon = norm360(Number(raw.fullDegree));
    const signIdx = Math.floor(lon / 30);
    const within = lon - signIdx * 30;
    const nakNum = Math.min(27, Math.floor(lon / NAK_SPAN) + 1);
    const nakWithin = lon - (nakNum - 1) * NAK_SPAN;
    const pada = Math.min(4, Math.floor(nakWithin / (NAK_SPAN / 4)) + 1);
    // Whole-sign house relative to ascendant (don't trust provider house when
    // we may be using a sunrise moment rather than birth time).
    const house = ((signIdx - ascSignIdx + 12) % 12) + 1;
    // isRetro is "true"/"false" string in provider responses.
    const isRetroRaw = raw?.isRetro;
    const retro = canon === "Rahu" || canon === "Ketu"
      ? true
      : canon === "Sun" || canon === "Moon"
        ? false
        : (isRetroRaw === true || String(isRetroRaw).toLowerCase() === "true");
    planets.push({
      name: canon,
      longitude: lon,
      sign: signIdx + 1,
      sign_name: SIGN_NAMES[signIdx],
      degree: within,
      nakshatra: nakNum,
      nakshatra_name: NAKSHATRAS[nakNum - 1],
      pada,
      retrograde: retro,
      house,
    });
  }

  // Order according to PLANET_ORDER, dropping any unexpected duplicates.
  const byName = new Map(planets.map(p => [p.name, p]));
  const ordered: ProviderPlanet[] = [];
  for (const name of PLANET_ORDER) {
    const p = byName.get(name);
    if (p) ordered.push(p);
  }
  if (ordered.length < 9) {
    throw new Error(`planets/extended returned only ${ordered.length} recognised planets`);
  }

  return {
    ascendant: {
      longitude: ascLon,
      sign: ascSignIdx + 1,
      sign_name: SIGN_NAMES[ascSignIdx],
      degree: ascLon - ascSignIdx * 30,
    },
    planets: ordered,
  };
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });
  try {
    const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
    const SERVICE_KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;

    const body = await req.json().catch(() => ({}));
    const { date, latitude, longitude, timezone } = body ?? {};
    if (
      !date || typeof date !== "string" || !/^\d{4}-\d{2}-\d{2}$/.test(date) ||
      typeof latitude !== "number" || latitude < -90 || latitude > 90 ||
      typeof longitude !== "number" || longitude < -180 || longitude > 180 ||
      !timezone || typeof timezone !== "string"
    ) {
      return json({ error: "Invalid input" }, 400);
    }

    const admin = createClient(SUPABASE_URL, SERVICE_KEY);
    const latR = Math.round(latitude * 100) / 100;
    const lonR = Math.round(longitude * 100) / 100;

    // Cache lookup (uses unique index on date + round(lat,2) + round(lon,2))
    const { data: cached } = await admin
      .from("panchang_cache")
      .select("panchang_data")
      .eq("date", date)
      .eq("latitude", latR)
      .eq("longitude", lonR)
      .maybeSingle();
    const cachedPayload = cached?.panchang_data as any;
    if (cachedPayload && cachedPayload.version === PAYLOAD_VERSION) {
      return json({ ...cachedPayload, cached: true }, 200, { "X-Cache": "HIT" });
    }

    // Compute
    const observer = new Astronomy.Observer(latitude, longitude, 0);
    const dayStartUtc = localDateToUtc(date, timezone, 0, 0);

    const sunrise = searchRiseSet(Astronomy.Body.Sun, observer, +1, dayStartUtc);
    const sunset  = searchRiseSet(Astronomy.Body.Sun, observer, -1, dayStartUtc);
    const moonrise = searchRiseSet(Astronomy.Body.Moon, observer, +1, dayStartUtc);
    const moonset  = searchRiseSet(Astronomy.Body.Moon, observer, -1, dayStartUtc);

    if (!sunrise || !sunset) {
      return json({ error: "Could not compute Panchang", details: "Sunrise/sunset unavailable for this location/date" }, 500);
    }

    // Find next sunrise (for night hora end)
    const nextDayStart = new Date(sunset.getTime() + 60 * 60 * 1000);
    const nextSunrise = searchRiseSet(Astronomy.Body.Sun, observer, +1, nextDayStart) ??
                        new Date(sunrise.getTime() + 24 * 3600 * 1000);

    // Sun + Moon longitudes at sunrise (sidereal via Lahiri) — used as a
    // fallback if astrologyapi.com is unreachable.
    const jdSunrise = julianFromDate(sunrise);
    const ayan = lahiriAyanamsa(jdSunrise);

    // ---- Primary: astrologyapi.com /planets/extended at sunrise ----
    // (Swiss Ephemeris, Lahiri sidereal — fixes Lagna 180° flip + Pluto drift.)
    let ascend: {
      longitude: number; sign: number; sign_name: string; degree: number;
    };
    let planetsWithHouse: Array<{
      name: string; longitude: number; sign: number; sign_name: string;
      degree: number; nakshatra: number; nakshatra_name: string; pada: number;
      retrograde: boolean; house: number;
    }>;
    let engineSource: "astrologyapi" | "inhouse" = "astrologyapi";

    try {
      const provider = await fetchPlanetsAtMoment(sunrise, latitude, longitude, timezone);
      ascend = provider.ascendant;
      planetsWithHouse = provider.planets.map(p => ({
        name: p.name,
        longitude: p.longitude,
        sign: p.sign,
        sign_name: p.sign_name,
        degree: p.degree,
        nakshatra: p.nakshatra,
        nakshatra_name: p.nakshatra_name,
        pada: p.pada,
        retrograde: p.retrograde,
        house: p.house,
      }));
    } catch (provErr) {
      console.warn(
        "compute-panchang: provider failed, falling back to in-house astronomy-engine:",
        provErr instanceof Error ? provErr.message : provErr,
      );
      engineSource = "inhouse";
      const planets = PLANET_ORDER.map((name) => {
        const { lon, retro } = planetSidereal(name, sunrise, ayan);
        const signIdx = Math.floor(lon / 30);
        const within = lon - signIdx * 30;
        const NAK_SPAN = 360 / 27;
        const nakNum = Math.floor(lon / NAK_SPAN) + 1;
        const nakWithin = lon - (nakNum - 1) * NAK_SPAN;
        const pada = Math.min(4, Math.floor(nakWithin / (NAK_SPAN / 4)) + 1);
        return {
          name, longitude: lon, sign: signIdx + 1, sign_name: SIGN_NAMES[signIdx],
          degree: within, nakshatra: nakNum, nakshatra_name: NAKSHATRAS[nakNum - 1],
          pada, retrograde: retro,
        };
      });
      const ascTrop = ascendantTrop(sunrise, latitude, longitude);
      const ascSid = norm360(ascTrop - ayan);
      const ascSignIdx = Math.floor(ascSid / 30);
      ascend = {
        longitude: ascSid,
        sign: ascSignIdx + 1,
        sign_name: SIGN_NAMES[ascSignIdx],
        degree: ascSid - ascSignIdx * 30,
      };
      planetsWithHouse = planets.map((p) => ({
        ...p,
        house: ((p.sign - 1 - ascSignIdx + 12) % 12) + 1,
      }));
    }

    // Sun + Moon used by tithi/yoga/karana — read from the (provider or fallback)
    // results so panchang stays consistent with the chart.
    const sunSid = planetsWithHouse.find(p => p.name === "Sun")!.longitude;
    const moonSid = planetsWithHouse.find(p => p.name === "Moon")!.longitude;

    // Tithi
    const tithiRaw = norm360(moonSid - sunSid) / 12;
    const tithiNum = Math.floor(tithiRaw) + 1; // 1..30
    const tithiName = TITHI_NAMES[tithiNum - 1];
    const paksha = tithiNum <= 15 ? "Shukla" : "Krishna";

    // Nakshatra (moon) + pada
    const NAK_SPAN = 360 / 27;
    const nakRaw = moonSid / NAK_SPAN;
    const nakNum = Math.floor(nakRaw) + 1;
    const within = moonSid - (nakNum - 1) * NAK_SPAN;
    const pada = Math.min(4, Math.floor(within / (NAK_SPAN / 4)) + 1);

    // Yoga
    const yogaRaw = norm360(sunSid + moonSid) / NAK_SPAN;
    const yogaNum = Math.floor(yogaRaw) + 1;

    // Karana 1..60
    const karanaRaw = norm360(moonSid - sunSid) / 6;
    const karanaNum = Math.floor(karanaRaw) + 1;
    let karanaName: string;
    if (karanaNum === 1) karanaName = "Kimstughna";
    else if (karanaNum >= 2 && karanaNum <= 57) karanaName = KARANA_REPEAT[(karanaNum - 2) % 7];
    else karanaName = ["Shakuni","Chatushpada","Naga"][karanaNum - 58];

    // Vaar (weekday in given tz)
    const wd = weekdayInTz(date, timezone);
    const vaar = VAARS[wd];

    // Inauspicious / auspicious windows
    const rahu = slotWindow(sunrise, sunset, RAHU_SLOTS[wd]);
    const yamaganda = slotWindow(sunrise, sunset, YAMAGANDA_SLOTS[wd]);
    const gulika = slotWindow(sunrise, sunset, GULIKA_SLOTS[wd]);
    const abhijit = wd === 3 ? null : slotWindow(sunrise, sunset, 8, 15);

    // Hora
    const hora = buildHoraTables(sunrise, sunset, nextSunrise, wd);

    const result = {
      version: PAYLOAD_VERSION,
      date,
      location: { latitude, longitude, timezone },
      tithi: { number: tithiNum > 15 ? tithiNum - 15 : tithiNum, name: tithiName, paksha, raw: tithiNum },
      nakshatra: { number: nakNum, name: NAKSHATRAS[nakNum - 1], pada },
      yoga: { number: yogaNum, name: YOGAS[yogaNum - 1] },
      karana: { number: karanaNum, name: karanaName },
      vaar,
      sun: { rise: sunrise.toISOString(), set: sunset.toISOString() },
      moon: { rise: moonrise?.toISOString() ?? null, set: moonset?.toISOString() ?? null },
      next_sunrise: nextSunrise.toISOString(),
      rahu_kaal: rahu,
      yamaganda,
      gulika,
      abhijit,
      ascendant: ascend,
      planets: planetsWithHouse,
      hora,
      engine: engineSource,
      cached: false,
    };

    // Upsert (replace if version differs)
    const { error: upErr } = await admin
      .from("panchang_cache")
      .upsert(
        { date, latitude: latR, longitude: lonR, timezone, panchang_data: result, computed_at: new Date().toISOString() },
        { onConflict: "date,latitude,longitude" },
      );
    if (upErr) {
      console.warn("panchang cache upsert warning:", upErr.message);
    }

    return json(result, 200, { "X-Cache": "MISS" });
  } catch (e) {
    const msg = e instanceof Error ? e.message : String(e);
    console.error("compute-panchang error:", msg);
    return json({ error: "Could not compute Panchang", details: msg }, 500);
  }
});
