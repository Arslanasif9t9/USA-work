import { createClient } from "npm:@supabase/supabase-js@2.45.0";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
const SERVICE_ROLE_KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
const TWILIO_ACCOUNT_SID = Deno.env.get("TWILIO_ACCOUNT_SID");
const TWILIO_AUTH_TOKEN = Deno.env.get("TWILIO_AUTH_TOKEN");

async function hashOtp(otp: string, salt: string): Promise<string> {
  const data = new TextEncoder().encode(`${salt}:${otp}`);
  const buf = await crypto.subtle.digest("SHA-256", data);
  return Array.from(new Uint8Array(buf))
    .map((b) => b.toString(16).padStart(2, "0"))
    .join("");
}

function jsonResponse(body: unknown, status = 200) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { ...corsHeaders, "Content-Type": "application/json" },
  });
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });
  if (req.method !== "POST") return jsonResponse({ error: "Method not allowed" }, 405);

  try {
    const authHeader = req.headers.get("Authorization") ?? "";
    const userClient = createClient(SUPABASE_URL, Deno.env.get("SUPABASE_ANON_KEY")!, {
      global: { headers: { Authorization: authHeader } },
    });
    const { data: userData, error: userErr } = await userClient.auth.getUser();
    if (userErr || !userData.user) return jsonResponse({ error: "Not authenticated" }, 401);
    const user = userData.user;

    const body = (await req.json().catch(() => ({}))) as {
      phone_number?: string;
      otp?: string;
      user_type?: "customer" | "astrologer";
    };
    const phone = (body.phone_number ?? "").trim();
    const otp = (body.otp ?? "").trim();
    const userType = body.user_type === "astrologer" ? "astrologer" : "customer";

    if (!/^\d{6}$/.test(otp)) return jsonResponse({ error: "Invalid code" }, 400);

    const admin = createClient(SUPABASE_URL, SERVICE_ROLE_KEY);

    const { data: rows, error: selErr } = await admin
      .from("phone_verifications")
      .select("id, otp_hash, expires_at, verified_at, attempts_count")
      .eq("user_id", user.id)
      .eq("phone_number", phone)
      .order("created_at", { ascending: false })
      .limit(1);
    if (selErr || !rows || rows.length === 0) {
      return jsonResponse({ error: "No verification request found" }, 400);
    }
    const row = rows[0];

    if (row.verified_at) return jsonResponse({ error: "Already verified" }, 400);
    if (new Date(row.expires_at).getTime() < Date.now()) {
      return jsonResponse({ error: "Code expired. Request a new one." }, 400);
    }
    if ((row.attempts_count ?? 0) >= 5) {
      return jsonResponse({ error: "Too many attempts. Request a new code." }, 429);
    }

    const expectedHash = await hashOtp(otp, user.id);
    if (expectedHash !== row.otp_hash) {
      await admin
        .from("phone_verifications")
        .update({ attempts_count: (row.attempts_count ?? 0) + 1 })
        .eq("id", row.id);
      return jsonResponse({ error: "Incorrect code" }, 400);
    }

    // Mark verification row as verified
    await admin
      .from("phone_verifications")
      .update({ verified_at: new Date().toISOString() })
      .eq("id", row.id);

    // Update profile / astrologer
    if (userType === "astrologer") {
      const { data: astro } = await admin
        .from("astrologers")
        .select("id")
        .eq("user_id", user.id)
        .maybeSingle();
      if (astro) {
        await admin
          .from("astrologers")
          .update({
            phone_number: phone,
            phone_verified: true,
            phone_verified_at: new Date().toISOString(),
          })
          .eq("id", astro.id);
      }
    }
    // Always also update profile (covers customer + the astrologer's customer profile)
    await admin
      .from("profiles")
      .update({
        phone: phone,
        phone_e164: phone,
        phone_verified: true,
        phone_verified_at: new Date().toISOString(),
      })
      .eq("id", user.id);

    // Optional: register verified caller ID on Twilio trial accounts
    let twilioRegistration: "skipped" | "requested" | "failed" = "skipped";
    if (TWILIO_ACCOUNT_SID && TWILIO_AUTH_TOKEN) {
      try {
        const url =
          `https://api.twilio.com/2010-04-01/Accounts/${TWILIO_ACCOUNT_SID}/OutgoingCallerIds.json`;
        const auth = btoa(`${TWILIO_ACCOUNT_SID}:${TWILIO_AUTH_TOKEN}`);
        // Check if already registered
        const list = await fetch(`${url}?PhoneNumber=${encodeURIComponent(phone)}`, {
          headers: { Authorization: `Basic ${auth}` },
        });
        const listData = await list.json().catch(() => ({}));
        const already = Array.isArray(listData?.outgoing_caller_ids) &&
          listData.outgoing_caller_ids.length > 0;
        if (!already) {
          // ValidationRequests endpoint triggers Twilio to call/text the number with a code.
          // For paid accounts this is unnecessary; we treat any failure as non-fatal.
          const valUrl =
            `https://api.twilio.com/2010-04-01/Accounts/${TWILIO_ACCOUNT_SID}/OutgoingCallerIds.json`;
          const form = new URLSearchParams({
            PhoneNumber: phone,
            FriendlyName: `AstroGuide ${userType}`,
          });
          const reg = await fetch(valUrl, {
            method: "POST",
            headers: {
              Authorization: `Basic ${auth}`,
              "Content-Type": "application/x-www-form-urlencoded",
            },
            body: form,
          });
          if (reg.ok) twilioRegistration = "requested";
          else {
            const t = await reg.text();
            console.warn("twilio caller-id register non-fatal", reg.status, t);
            twilioRegistration = "failed";
          }
        }
      } catch (e) {
        console.warn("twilio caller-id register threw", e);
        twilioRegistration = "failed";
      }
    }

    return jsonResponse({ ok: true, twilio_registration: twilioRegistration });
  } catch (e) {
    console.error("verify-phone-otp error", e);
    return jsonResponse({ error: "Unexpected error" }, 500);
  }
});
