// deno-lint-ignore-file no-explicit-any
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.45.0";
import * as Astronomy from "https://esm.sh/astronomy-engine@2.1.19";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type",
};

// ============================================================================
// Constants
// ============================================================================
const SIGNS = ["Aries","Taurus","Gemini","Cancer","Leo","Virgo",
  "Libra","Scorpio","Sagittarius","Capricorn","Aquarius","Pisces"];
const SIGN_LORDS: Record<string,string> = {
  Aries:"Mars",Taurus:"Venus",Gemini:"Mercury",Cancer:"Moon",
  Leo:"Sun",Virgo:"Mercury",Libra:"Venus",Scorpio:"Mars",
  Sagittarius:"Jupiter",Capricorn:"Saturn",Aquarius:"Saturn",Pisces:"Jupiter",
};
const NAKSHATRAS = ["Ashwini","Bharani","Krittika","Rohini","Mrigashira","Ardra",
  "Punarvasu","Pushya","Ashlesha","Magha","Purva Phalguni","Uttara Phalguni",
  "Hasta","Chitra","Swati","Vishakha","Anuradha","Jyeshtha","Mula",
  "Purva Ashadha","Uttara Ashadha","Shravana","Dhanishta","Shatabhisha",
  "Purva Bhadrapada","Uttara Bhadrapada","Revati"];
const TITHIS = ["Pratipada","Dwitiya","Tritiya","Chaturthi","Panchami","Shashthi",
  "Saptami","Ashtami","Navami","Dashami","Ekadashi","Dwadashi","Trayodashi",
  "Chaturdashi","Purnima","Pratipada","Dwitiya","Tritiya","Chaturthi","Panchami",
  "Shashthi","Saptami","Ashtami","Navami","Dashami","Ekadashi","Dwadashi",
  "Trayodashi","Chaturdashi","Amavasya"];
const YOGAS = ["Vishkambha","Priti","Ayushman","Saubhagya","Shobhana","Atiganda",
  "Sukarma","Dhriti","Shoola","Ganda","Vriddhi","Dhruva","Vyaghata","Harshana",
  "Vajra","Siddhi","Vyatipata","Variyana","Parigha","Shiva","Siddha","Sadhya",
  "Shubha","Shukla","Brahma","Indra","Vaidhriti"];
const KARANAS = ["Bava","Balava","Kaulava","Taitila","Garaja","Vanija","Vishti",
  "Shakuni","Chatushpada","Naga","Kimstughna"];

// ============================================================================
// Math helpers (used by in-house fallback only)
// ============================================================================
const DEG = Math.PI / 180, RAD = 180 / Math.PI;
const norm360 = (x: number) => ((x % 360) + 360) % 360;

function lahiriAyanamsa(jd: number): number {
  const t = (jd - 2451545.0) / 365.25;
  return 23.85 + (50.29 / 3600) * t;
}
const sidereal = (trop: number, ayan: number) => norm360(trop - ayan);
function signDeg(lon: number) {
  const i = Math.floor(lon / 30);
  return { sign: SIGNS[i], degree: lon - i * 30, signIndex: i };
}
function nakshatraInfo(lon: number) {
  const span = 360 / 27;
  const idx = Math.floor(lon / span);
  const within = lon - idx * span;
  const pada = Math.floor(within / (span / 4)) + 1;
  return { nakshatra: NAKSHATRAS[idx], pada };
}

function tzOffsetHours(date: string, time: string, tz: string): number {
  const isoLocal = `${date}T${time}:00`;
  const asUtc = new Date(isoLocal + "Z");
  const dtf = new Intl.DateTimeFormat("en-US", {
    timeZone: tz, hour12: false,
    year: "numeric", month: "2-digit", day: "2-digit",
    hour: "2-digit", minute: "2-digit", second: "2-digit",
  });
  const parts = Object.fromEntries(dtf.formatToParts(asUtc).map(p => [p.type, p.value]));
  const asTz = Date.UTC(+parts.year, +parts.month - 1, +parts.day,
    +parts.hour, +parts.minute, +parts.second);
  return (asTz - asUtc.getTime()) / 3600000;
}

function julianDay(date: string, time: string, tz: string) {
  const offset = tzOffsetHours(date, time, tz);
  const [y,m,d] = date.split("-").map(Number);
  const [hh,mm] = time.split(":").map(Number);
  const utcMs = Date.UTC(y, m-1, d, hh, mm, 0) - offset * 3600 * 1000;
  const utc = new Date(utcMs);
  let Y = utc.getUTCFullYear(), M = utc.getUTCMonth() + 1;
  const D = utc.getUTCDate()
    + (utc.getUTCHours() + utc.getUTCMinutes()/60 + utc.getUTCSeconds()/3600) / 24;
  if (M <= 2) { Y -= 1; M += 12; }
  const A = Math.floor(Y / 100), B = 2 - A + Math.floor(A / 4);
  const jd = Math.floor(365.25 * (Y + 4716))
           + Math.floor(30.6001 * (M + 1)) + D + B - 1524.5;
  return { jd, utc, offset };
}

const BODIES: Array<[string, any]> = [
  ["Sun", Astronomy.Body.Sun],
  ["Moon", Astronomy.Body.Moon],
  ["Mercury", Astronomy.Body.Mercury],
  ["Venus", Astronomy.Body.Venus],
  ["Mars", Astronomy.Body.Mars],
  ["Jupiter", Astronomy.Body.Jupiter],
  ["Saturn", Astronomy.Body.Saturn],
];
const GEOCENTRIC_OBSERVER = new Astronomy.Observer(0, 0, 0);

function eclipticLon(body: any, date: Date) {
  const eq = Astronomy.Equator(body, date, GEOCENTRIC_OBSERVER, true, true);
  const ecl = Astronomy.Ecliptic(eq.vec);
  const future = new Date(date.getTime() + 86400000);
  const eq2 = Astronomy.Equator(body, future, GEOCENTRIC_OBSERVER, true, true);
  const ecl2 = Astronomy.Ecliptic(eq2.vec);
  let dl = ecl2.elon - ecl.elon;
  if (dl > 180) dl -= 360; if (dl < -180) dl += 360;
  return { lon: norm360(ecl.elon), retro: dl < 0 };
}

function meanNodeLon(jd: number) {
  const T = (jd - 2451545.0) / 36525;
  const omega = 125.04452 - 1934.136261*T + 0.0020708*T*T + (T*T*T)/450000;
  return norm360(omega);
}

function localSiderealTime(jd: number, lonEast: number) {
  const T = (jd - 2451545.0) / 36525;
  const gmst = 280.46061837 + 360.98564736629 * (jd - 2451545.0)
           + 0.000387933*T*T - (T*T*T)/38710000;
  return norm360(norm360(gmst) + lonEast);
}
function obliquity(jd: number) {
  const T = (jd - 2451545.0) / 36525;
  return 23.439291 - 0.0130042*T - 1.64e-7*T*T + 5.04e-7*T*T*T;
}

function ascendantTropical(jd: number, lat: number, lonEast: number) {
  const lst = localSiderealTime(jd, lonEast);
  const eps = obliquity(jd);
  const ramc = lst * DEG, phi = lat * DEG, e = eps * DEG;
  const y = -Math.cos(ramc);
  const x = Math.sin(ramc) * Math.cos(e) + Math.tan(phi) * Math.sin(e);
  return norm360(Math.atan2(y, x) * RAD);
}

// ============================================================================
// astrologyapi.com primary path
// ============================================================================
const API_BASE = "https://json.astrologyapi.com/v1";
const SIGN_INDEX_BY_NAME: Record<string, number> = {
  Aries: 0, Taurus: 1, Gemini: 2, Cancer: 3, Leo: 4, Virgo: 5,
  Libra: 6, Scorpio: 7, Sagittarius: 8, Capricorn: 9, Aquarius: 10, Pisces: 11,
};

function tzoneDecimal(date: string, time: string, tz: string): number {
  return tzOffsetHours(date, time, tz);
}

async function callAstrologyApi(path: string, body: unknown): Promise<any> {
  const userId = Deno.env.get("ASTROLOGY_API_USER_ID");
  const apiKey = Deno.env.get("ASTROLOGY_API_KEY");
  if (!userId || !apiKey) throw new Error("astrologyapi credentials not configured");
  const auth = btoa(`${userId}:${apiKey}`);
  const res = await fetch(`${API_BASE}/${path}`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "Authorization": `Basic ${auth}`,
      "Accept-Language": "en",
    },
    body: JSON.stringify(body),
  });
  if (!res.ok) {
    const text = await res.text().catch(() => "");
    throw new Error(`astrologyapi ${path} ${res.status}: ${text.slice(0, 200)}`);
  }
  return res.json();
}

interface ProviderInput {
  day: number; month: number; year: number;
  hour: number; min: number;
  lat: number; lon: number; tzone: number;
}

/**
 * Combust thresholds (degrees of arc from Sun longitude).
 * AstroSage convention. Mercury/Venus differ when retrograde.
 */
const COMBUST_DEG: Record<string, { direct: number; retro: number }> = {
  Mercury: { direct: 12, retro: 14 },
  Venus:   { direct: 10, retro: 8 },
  Mars:    { direct: 17, retro: 17 },
  Jupiter: { direct: 11, retro: 11 },
  Saturn:  { direct: 15, retro: 15 },
};

function arcDistance(a: number, b: number): number {
  const d = Math.abs(((a - b) % 360 + 540) % 360 - 180);
  return d;
}

function computeCombust(name: string, lon: number, sunLon: number, retro: boolean): boolean {
  const cfg = COMBUST_DEG[name];
  if (!cfg) return false;
  const threshold = retro ? cfg.retro : cfg.direct;
  return arcDistance(lon, sunLon) <= threshold;
}

/**
 * Provider response → our normalized chart payload.
 * Uses `/planet_panchang/` which matches AstroSage's retrograde convention
 * (tighter motion thresholds — does not flag near-stationary planets as R).
 * Each item: { name, fullDegree (0-360), normDegree (0-30, sign-relative),
 *             sign, house, nakshatra, nakshatra_pad, isRetro, is_combust }
 */
async function calculateChartViaProvider(input: ProviderInput) {
  // /planet_panchang/ matches AstroSage's R convention better than /planets.
  const planetsRes: any[] = await callAstrologyApi("planet_panchang", input);
  if (!Array.isArray(planetsRes)) {
    throw new Error("astrologyapi /planet_panchang returned non-array");
  }

  // Find ascendant entry
  const ascRaw = planetsRes.find((p) => /asc/i.test(String(p?.name)));
  if (!ascRaw) throw new Error("astrologyapi response missing Ascendant");

  const ascLon = Number(ascRaw.fullDegree);
  const ascDeg = Number(ascRaw.normDegree ?? (ascLon % 30));
  const ascSign = String(ascRaw.sign);
  const ascNk = nakshatraInfo(ascLon);
  const ascendant = {
    longitude: ascLon,
    sign: ascSign,
    degree: ascDeg,
    nakshatra: ascNk.nakshatra,
    pada: ascNk.pada,
  };

  // Build planets in canonical order; keep raw house from provider
  const ORDER = ["Sun","Moon","Mars","Mercury","Jupiter","Venus","Saturn","Rahu","Ketu"];
  const findPlanet = (n: string) => planetsRes.find(
    (p) => String(p?.name).toLowerCase() === n.toLowerCase()
  );

  // First pass: gather raw retro + Sun longitude (needed for combust calc)
  const truthy = (v: unknown) => v === true || v === "true" || v === 1 || v === "1";
  const sunRaw = findPlanet("Sun");
  const sunLon = sunRaw ? Number(sunRaw.fullDegree) : 0;

  const planets: any[] = [];
  for (const name of ORDER) {
    const r = findPlanet(name);
    if (!r) continue;
    const lon = Number(r.fullDegree);
    const sd = signDeg(lon);
    const nk = nakshatraInfo(lon);
    const retroRaw = truthy(r.isRetro ?? r.is_retro ?? r.retrograde);
    // AstroSage convention: Rahu/Ketu shown as "-" (neither D nor R).
    // We persist retrograde=true for them (astronomically correct) but the UI
    // must render "-" — handled in the React table component.
    const retrograde = name === "Rahu" || name === "Ketu" ? true
                     : name === "Sun" || name === "Moon" ? false
                     : retroRaw;
    // Combust: prefer provider flag if present; otherwise compute from Sun arc.
    const combustProvider = r.combust_planet ?? r.is_combust ?? r.combust;
    const combust = combustProvider !== undefined
      ? truthy(combustProvider)
      : computeCombust(name, lon, sunLon, retrograde);
    planets.push({
      name,
      longitude: lon,
      tropical_longitude: lon, // already sidereal Lahiri
      sign: r.sign ?? sd.sign,
      degree: Number(r.normDegree ?? sd.degree),
      nakshatra: nk.nakshatra,
      pada: nk.pada,
      retrograde,
      combust,
      house: Number(r.house) || undefined, // house number 1-12 from provider (Lagna-relative)
    });
  }

  // Outer planets (Uranus/Neptune/Pluto) are intentionally not included —
  // birth charts only show the 9 classical Vedic Grahas.

  // Whole-sign houses derived from ascendant longitude
  const ascSignIndex = Math.floor(norm360(ascLon) / 30);
  const houses = Array.from({ length: 12 }, (_, i) => {
    const cuspLon = (ascSignIndex * 30 + i * 30) % 360;
    const sd = signDeg(cuspLon);
    return {
      number: i + 1,
      sign: sd.sign,
      degree: 0,
      cusp_longitude: cuspLon,
      lord: SIGN_LORDS[sd.sign],
    };
  });

  // Panchang (sidereal Sun/Moon)
  const sun = planets.find(p => p.name === "Sun")!;
  const moon = planets.find(p => p.name === "Moon")!;
  const tithiIdx = Math.floor(norm360(moon.longitude - sun.longitude) / 12);
  const yogaIdx = Math.floor(norm360(moon.longitude + sun.longitude) / (360/27));
  const moonNk = nakshatraInfo(moon.longitude);
  const k = Math.floor(norm360(moon.longitude - sun.longitude) / 6) % 60;
  let karanaName: string;
  if (k === 0) karanaName = "Kimstughna";
  else if (k >= 1 && k <= 56) karanaName = KARANAS[(k - 1) % 7];
  else karanaName = ["Shakuni","Chatushpada","Naga"][k - 57];
  const panchang = {
    tithi: { name: TITHIS[tithiIdx], index: tithiIdx + 1,
      paksha: tithiIdx < 15 ? "Shukla" : "Krishna" },
    nakshatra: { name: moonNk.nakshatra, pada: moonNk.pada },
    yoga: { name: YOGAS[yogaIdx], index: yogaIdx + 1 },
    karana: { name: karanaName, index: k + 1 },
  };

  return {
    planets, houses, ascendant, panchang,
    meta: {
      ayanamsa: "Lahiri",
      house_system: "Whole Sign",
      engine: "astrologyapi.com /planet_panchang",
      provider: "astrologyapi",
    },
    source: "astrologyapi" as const,
  };
}

// ============================================================================
// In-house fallback (legacy path, retained verbatim)
// ============================================================================
function calculateChartInHouse(opts: {
  birthDate: string; birthTime: string; latitude: number; longitude: number;
  timezone: string; timeUnknown?: boolean;
}) {
  const { birthDate, birthTime, latitude, longitude, timezone, timeUnknown } = opts;
  const { jd, utc } = julianDay(birthDate, birthTime, timezone);
  const ayan = lahiriAyanamsa(jd);

  const ascTrop = ascendantTropical(jd, latitude, longitude);
  const ascSid = sidereal(ascTrop, ayan);
  const ascSignIndex = Math.floor(ascSid / 30);

  // Whole-sign houses
  const sidCusps = Array.from({ length: 12 }, (_, i) =>
    norm360(ascSignIndex * 30 + i * 30));
  const houses = sidCusps.map((c, i) => {
    const sd = signDeg(c);
    return { number: i + 1, sign: sd.sign, degree: 0,
      cusp_longitude: c, lord: SIGN_LORDS[sd.sign] };
  });

  const planets: any[] = [];
  for (const [name, body] of BODIES) {
    const { lon: trop, retro } = eclipticLon(body, utc);
    const sid = sidereal(trop, ayan);
    const sd = signDeg(sid), nk = nakshatraInfo(sid);
    const planetSignIndex = Math.floor(sid / 30);
    planets.push({
      name, longitude: sid, tropical_longitude: trop,
      sign: sd.sign, degree: sd.degree,
      nakshatra: nk.nakshatra, pada: nk.pada,
      retrograde: name === "Sun" || name === "Moon" ? false : retro,
      combust: false, // in-house fallback omits combust calc
      house: ((planetSignIndex - ascSignIndex + 12) % 12) + 1,
    });
  }
  const rahuTrop = meanNodeLon(jd);
  const rahuSid = sidereal(rahuTrop, ayan);
  const ketuSid = norm360(rahuSid + 180);
  for (const [name, sid, trop] of [
    ["Rahu", rahuSid, rahuTrop] as const,
    ["Ketu", ketuSid, norm360(rahuTrop + 180)] as const,
  ]) {
    const sd = signDeg(sid), nk = nakshatraInfo(sid);
    const planetSignIndex = Math.floor(sid / 30);
    planets.push({
      name, longitude: sid, tropical_longitude: trop,
      sign: sd.sign, degree: sd.degree,
      nakshatra: nk.nakshatra, pada: nk.pada,
      retrograde: true,
      combust: false,
      house: ((planetSignIndex - ascSignIndex + 12) % 12) + 1,
    });
  }

  const ascSD = signDeg(ascSid), ascNk = nakshatraInfo(ascSid);
  const ascendant = {
    longitude: ascSid, sign: ascSD.sign, degree: ascSD.degree,
    nakshatra: ascNk.nakshatra, pada: ascNk.pada,
  };

  const sunSid = planets.find(p => p.name === "Sun")!.longitude;
  const moonSid = planets.find(p => p.name === "Moon")!.longitude;
  const tithiIdx = Math.floor(norm360(moonSid - sunSid) / 12);
  const yogaIdx = Math.floor(norm360(moonSid + sunSid) / (360/27));
  const moonNk = nakshatraInfo(moonSid);
  const k = Math.floor(norm360(moonSid - sunSid) / 6) % 60;
  let karanaName: string;
  if (k === 0) karanaName = "Kimstughna";
  else if (k >= 1 && k <= 56) karanaName = KARANAS[(k - 1) % 7];
  else karanaName = ["Shakuni","Chatushpada","Naga"][k - 57];
  const panchang = {
    tithi: { name: TITHIS[tithiIdx], index: tithiIdx + 1,
      paksha: tithiIdx < 15 ? "Shukla" : "Krishna" },
    nakshatra: { name: moonNk.nakshatra, pada: moonNk.pada },
    yoga: { name: YOGAS[yogaIdx], index: yogaIdx + 1 },
    karana: { name: karanaName, index: k + 1 },
  };

  return {
    planets, houses, ascendant, panchang,
    meta: {
      jd, utc: utc.toISOString(), ayanamsa_value: ayan,
      ayanamsa: "Lahiri", house_system: "Whole Sign",
      engine: "in-house astronomy-engine + Lahiri sidereal",
      time_unknown: !!timeUnknown,
    },
    source: "inhouse" as const,
  };
}

// ============================================================================
// Handler
// ============================================================================
const TIME_RE = /^([01]\d|2[0-3]):[0-5]\d$/;

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });
  try {
    // calculate-chart is allowed for anonymous (logged-out) callers — it returns
    // computed chart data only and never writes to the database. Persistence is
    // handled by the frontend (DB for signed-in users, sessionStorage for anon).
    const auth = req.headers.get("Authorization");
    const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
    const ANON_KEY = Deno.env.get("SUPABASE_ANON_KEY")!;
    const SERVICE_KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;

    // If a non-service token is provided we still validate it (so blocked users
    // are rejected), but missing auth is OK for anonymous use.
    if (auth) {
      const token = auth.replace("Bearer ", "");
      if (token !== SERVICE_KEY) {
        const userClient = createClient(SUPABASE_URL, ANON_KEY, {
          global: { headers: { Authorization: auth } },
        });
        const { data: { user } } = await userClient.auth.getUser();
        // Don't fail if token is invalid — just treat as anonymous.
        void user;
      }
    }

    const body = await req.json();
    let { birthDate, birthTime, latitude, longitude, timezone, timeUnknown } = body;
    if (!birthDate || !timezone || typeof latitude !== "number" || typeof longitude !== "number"
      || latitude < -90 || latitude > 90 || longitude < -180 || longitude > 180) {
      return json({ error: "Invalid input" }, 400);
    }
    if (timeUnknown || !birthTime) birthTime = "12:00";

    // Reject 12-hour or unpadded values — caller must always send 24-hour HH:mm.
    if (!TIME_RE.test(birthTime)) {
      return json({ error: `Invalid birthTime '${birthTime}': expected 24-hour HH:mm` }, 400);
    }

    // Build provider input
    const [yy, mm, dd] = birthDate.split("-").map(Number);
    const [hh, mn] = birthTime.split(":").map(Number);
    const tzone = tzoneDecimal(birthDate, birthTime, timezone);
    const provInput: ProviderInput = {
      day: dd, month: mm, year: yy, hour: hh, min: mn,
      lat: latitude, lon: longitude, tzone,
    };

    // Try provider first; on any error fall back to in-house.
    let result: any;
    try {
      result = await calculateChartViaProvider(provInput);
    } catch (provErr) {
      const msg = provErr instanceof Error ? provErr.message : String(provErr);
      console.warn("[calculate-chart] provider failed, using in-house:", msg);
      result = calculateChartInHouse({
        birthDate, birthTime, latitude, longitude, timezone, timeUnknown,
      });
      result.meta = { ...(result.meta ?? {}), provider_error: msg };
    }

    // Always echo back a stable shape including `source`
    return json(result);
  } catch (e) {
    const msg = e instanceof Error ? e.message : String(e);
    console.error("calculate-chart error:", msg);
    return json({ error: msg }, 500);
  }
});

function json(body: unknown, status = 200) {
  return new Response(JSON.stringify(body), {
    status, headers: { ...corsHeaders, "Content-Type": "application/json" },
  });
}
