// Generates an Agora RTC token using the official agora-token npm package.
import { createClient } from "npm:@supabase/supabase-js@2.95.0";
import { RtcTokenBuilder, RtcRole } from "npm:agora-token@2.0.5";
import { z } from "npm:zod@3.23.8";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

const BodySchema = z.object({
  channel_name: z.string().min(1).max(64),
  uid: z.number().int().min(0).max(0xffffffff).optional().default(0),
  role: z.enum(["host", "audience"]).default("audience"),
});

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });
  if (req.method !== "POST") {
    return new Response(JSON.stringify({ error: "Method not allowed" }), {
      status: 405, headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
  try {
    const APP_ID = Deno.env.get("AGORA_APP_ID");
    const APP_CERT = Deno.env.get("AGORA_APP_CERTIFICATE");
    console.log("generate-agora-token: appId len=", APP_ID?.length ?? 0, "cert len=", APP_CERT?.length ?? 0);
    if (!APP_ID || !APP_CERT) {
      return new Response(JSON.stringify({ error: "Agora credentials not configured" }), {
        status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }
    const authHeader = req.headers.get("Authorization");
    if (!authHeader) {
      return new Response(JSON.stringify({ error: "Unauthorized" }), {
        status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }
    const sb = createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_ANON_KEY")!, {
      global: { headers: { Authorization: authHeader } },
    });
    const { data: { user } } = await sb.auth.getUser();
    if (!user) {
      return new Response(JSON.stringify({ error: "Unauthorized" }), {
        status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const parsed = BodySchema.safeParse(await req.json());
    if (!parsed.success) {
      return new Response(JSON.stringify({ error: parsed.error.flatten().fieldErrors }), {
        status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }
    const { channel_name, uid, role } = parsed.data;

    const expireSeconds = 24 * 60 * 60;
    const privilegeExpireTs = Math.floor(Date.now() / 1000) + expireSeconds;
    const agoraRole = role === "host" ? RtcRole.PUBLISHER : RtcRole.SUBSCRIBER;

    const token = RtcTokenBuilder.buildTokenWithUid(
      APP_ID,
      APP_CERT,
      channel_name,
      uid,
      agoraRole,
      privilegeExpireTs,
      privilegeExpireTs,
    );

    return new Response(
      JSON.stringify({
        token, app_id: APP_ID, channel_name, uid,
        expires_at: new Date(privilegeExpireTs * 1000).toISOString(),
      }),
      { headers: { ...corsHeaders, "Content-Type": "application/json" }, status: 200 }
    );
  } catch (err) {
    console.error("generate-agora-token error", err);
    return new Response(JSON.stringify({ error: (err as Error).message ?? "Server error" }), {
      status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
