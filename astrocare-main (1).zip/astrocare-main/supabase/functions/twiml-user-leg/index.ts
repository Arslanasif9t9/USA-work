// TwiML returned when customer's phone answers — joins them to the conference
// and triggers conference start so both phones connect.
const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
const TWILIO_WEBHOOK_BASE_URL = Deno.env.get("TWILIO_WEBHOOK_BASE_URL") ??
  `${SUPABASE_URL}/functions/v1`;

Deno.serve((req) => {
  const url = new URL(req.url);
  const callSessionId = url.searchParams.get("call_session_id");
  if (!callSessionId) {
    const err =
      `<?xml version="1.0" encoding="UTF-8"?><Response><Say voice="Polly.Aditi">Invalid call.</Say><Hangup/></Response>`;
    return new Response(err, {
      status: 200,
      headers: { "Content-Type": "text/xml; charset=utf-8" },
    });
  }

  const conferenceName = `session-${callSessionId}`;
  const holdMusicUrl = `${TWILIO_WEBHOOK_BASE_URL}/twiml-hold-music`;
  const recordingCb =
    `${TWILIO_WEBHOOK_BASE_URL}/twilio-recording-webhook?call_session_id=${callSessionId}`;
  const conferenceStatusUrl =
    `${TWILIO_WEBHOOK_BASE_URL}/twilio-status-webhook?call_session_id=${callSessionId}&leg=conference`;

  const twiml = `<?xml version="1.0" encoding="UTF-8"?>
<Response>
  <Say voice="Polly.Aditi">Connecting you to your astrologer now.</Say>
  <Dial>
    <Conference
      waitUrl="${holdMusicUrl}"
      startConferenceOnEnter="true"
      endConferenceOnExit="true"
      record="record-from-start"
      recordingStatusCallback="${recordingCb}"
      statusCallback="${conferenceStatusUrl}"
      statusCallbackEvent="join leave end">${conferenceName}</Conference>
  </Dial>
</Response>`;

  return new Response(twiml, {
    status: 200,
    headers: { "Content-Type": "text/xml; charset=utf-8" },
  });
});
