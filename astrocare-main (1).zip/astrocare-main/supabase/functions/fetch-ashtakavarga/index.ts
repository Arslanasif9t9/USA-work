// deno-lint-ignore-file no-explicit-any
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.45.0";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type",
};

const PLANETS = ["sun", "moon", "mars", "mercury", "jupiter", "venus", "saturn"] as const;
type PlanetKey = typeof PLANETS[number];

function jsonResponse(body: unknown, status = 200) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { ...corsHeaders, "Content-Type": "application/json" },
  });
}

/* ------------------------------------------------------------------ */
/*  Parashara Ashtakavarga bindu tables (public-domain, BPHS).        */
/*  For each planet (the "subject"), we list which house-positions    */
/*  (counted 1..12 FROM each contributor's sign) earn 1 bindu.        */
/*  Contributors (in this exact order): Sun, Moon, Mars, Mercury,     */
/*  Jupiter, Venus, Saturn, Lagna.                                    */
/*  Per-planet bhinna totals (sum across 8 contributors) match the    */
/*  classical values: Sun 48, Moon 49, Mars 39, Mercury 54,           */
/*  Jupiter 56, Venus 52, Saturn 39  ->  SARVA TOTAL = 337.           */
/* ------------------------------------------------------------------ */
type BinduRow = number[]; // houses 1..12 the contributor benefits

const BINDU_TABLES: Record<PlanetKey, { from: BinduRow[] }> = {
  // Sun (subject) — bhinna 48
  sun: {
    from: [
      [1, 2, 4, 7, 8, 9, 10, 11],            // Sun
      [3, 6, 10, 11],                        // Moon
      [1, 2, 4, 7, 8, 9, 10, 11],            // Mars
      [3, 5, 6, 9, 10, 11, 12],              // Mercury
      [5, 6, 9, 11],                         // Jupiter
      [6, 7, 12],                            // Venus
      [1, 2, 4, 7, 8, 9, 10, 11],            // Saturn
      [3, 4, 6, 10, 11, 12],                 // Lagna
    ],
  },
  // Moon (subject) — bhinna 49
  moon: {
    from: [
      [3, 6, 7, 8, 10, 11],                  // Sun
      [1, 3, 6, 7, 10, 11],                  // Moon
      [2, 3, 5, 6, 9, 10, 11],               // Mars
      [1, 3, 4, 5, 7, 8, 10, 11],            // Mercury
      [1, 4, 7, 8, 10, 11, 12],              // Jupiter
      [3, 4, 5, 7, 9, 10, 11],               // Venus
      [3, 5, 6, 11],                         // Saturn
      [3, 6, 10, 11],                        // Lagna
    ],
  },
  // Mars (subject) — bhinna 39
  mars: {
    from: [
      [3, 5, 6, 10, 11],                     // Sun
      [3, 6, 11],                            // Moon
      [1, 2, 4, 7, 8, 10, 11],               // Mars
      [3, 5, 6, 11],                         // Mercury
      [6, 10, 11, 12],                       // Jupiter
      [6, 8, 11, 12],                        // Venus
      [1, 4, 7, 8, 9, 10, 11],               // Saturn
      [1, 3, 6, 10, 11],                     // Lagna
    ],
  },
  // Mercury (subject) — bhinna 54
  mercury: {
    from: [
      [5, 6, 9, 11, 12],                     // Sun
      [2, 4, 6, 8, 10, 11],                  // Moon
      [1, 2, 4, 7, 8, 9, 10, 11],            // Mars
      [1, 3, 5, 6, 9, 10, 11, 12],           // Mercury
      [6, 8, 11, 12],                        // Jupiter
      [1, 2, 3, 4, 5, 8, 9, 11],             // Venus
      [1, 2, 4, 7, 8, 9, 10, 11],            // Saturn
      [1, 2, 4, 6, 8, 10, 11],               // Lagna
    ],
  },
  // Jupiter (subject) — bhinna 56
  jupiter: {
    from: [
      [1, 2, 3, 4, 7, 8, 9, 10, 11],         // Sun
      [2, 5, 7, 9, 11],                      // Moon
      [1, 2, 4, 7, 8, 10, 11],               // Mars
      [1, 2, 4, 5, 6, 9, 10, 11],            // Mercury
      [1, 2, 3, 4, 7, 8, 10, 11],            // Jupiter
      [2, 5, 6, 9, 10, 11],                  // Venus
      [3, 5, 6, 12],                         // Saturn
      [1, 2, 4, 5, 6, 7, 9, 10, 11],         // Lagna
    ],
  },
  // Venus (subject) — bhinna 52
  venus: {
    from: [
      [8, 11, 12],                           // Sun
      [1, 2, 3, 4, 5, 8, 9, 11, 12],         // Moon
      [3, 5, 6, 9, 11, 12],                  // Mars
      [3, 5, 6, 9, 11],                      // Mercury
      [5, 8, 9, 10, 11],                     // Jupiter
      [1, 2, 3, 4, 5, 8, 9, 10, 11],         // Venus
      [3, 4, 5, 8, 9, 10, 11],               // Saturn
      [1, 2, 3, 4, 5, 8, 9, 11],             // Lagna
    ],
  },
  // Saturn (subject) — bhinna 39
  saturn: {
    from: [
      [1, 2, 4, 7, 8, 10, 11],               // Sun
      [3, 6, 11],                            // Moon
      [3, 5, 6, 10, 11, 12],                 // Mars
      [6, 8, 9, 10, 11, 12],                 // Mercury
      [5, 6, 11, 12],                        // Jupiter
      [6, 11, 12],                           // Venus
      [3, 5, 6, 11],                         // Saturn
      [1, 3, 4, 6, 10, 11],                  // Lagna
    ],
  },
};

const CONTRIBUTORS = ["Sun", "Moon", "Mars", "Mercury", "Jupiter", "Venus", "Saturn"] as const;

function signOf(longitude: number): number {
  // returns 1..12
  const norm = ((longitude % 360) + 360) % 360;
  return Math.floor(norm / 30) + 1;
}

interface PlanetPos { name: string; longitude: number }

/**
 * Compute Bhinna Ashtakavarga for one subject planet.
 * Returns 12 numbers indexed by SIGN (1..12 -> indices 0..11).
 */
function computeBhinnaBySign(
  subject: PlanetKey,
  contributorSigns: number[], // length 8: Sun..Saturn, Lagna
): number[] {
  const out = Array(12).fill(0);
  const rows = BINDU_TABLES[subject].from;
  for (let c = 0; c < 8; c++) {
    const fromSign = contributorSigns[c]; // 1..12
    for (const houseFromContributor of rows[c]) {
      // sign that is `houseFromContributor` houses from the contributor's sign
      const targetSign0 = (fromSign - 1 + (houseFromContributor - 1)) % 12;
      out[targetSign0] += 1;
    }
  }
  return out;
}

/**
 * Convert sign-indexed array (sign 1..12 -> idx 0..11) to house-indexed
 * array (house 1..12 -> idx 0..11) using the chart's Lagna sign.
 * House 1 = Lagna sign, House 2 = next sign, etc.
 */
function signToHouse(arrBySign: number[], lagnaSign: number): number[] {
  const out = Array(12).fill(0);
  for (let h = 0; h < 12; h++) {
    const sign0 = (lagnaSign - 1 + h) % 12;
    out[h] = arrBySign[sign0];
  }
  return out;
}

function computeAshtakavarga(chartData: any): {
  sarvaHouses: number[];
  bhinnaByPlanet: Record<PlanetKey, number[]>;
} | null {
  const ascLon = chartData?.ascendant?.longitude;
  const planets: PlanetPos[] = chartData?.planets ?? [];
  if (typeof ascLon !== "number" || planets.length === 0) return null;

  const lagnaSign = signOf(ascLon);
  const planetSign: Record<string, number> = {};
  for (const p of planets) {
    if (typeof p.longitude === "number") planetSign[p.name] = signOf(p.longitude);
  }
  for (const c of CONTRIBUTORS) {
    if (!planetSign[c]) {
      console.error(`[ashtakavarga] missing planet ${c}`);
      return null;
    }
  }

  // contributor signs in order: Sun..Saturn, Lagna
  const contribSigns = [
    planetSign.Sun, planetSign.Moon, planetSign.Mars, planetSign.Mercury,
    planetSign.Jupiter, planetSign.Venus, planetSign.Saturn,
    lagnaSign,
  ];

  const bhinnaByPlanet: Record<PlanetKey, number[]> = {} as any;
  const sarvaHouses = Array(12).fill(0);
  for (const subject of PLANETS) {
    const bySign = computeBhinnaBySign(subject, contribSigns);
    const byHouse = signToHouse(bySign, lagnaSign);
    bhinnaByPlanet[subject] = byHouse;
    for (let h = 0; h < 12; h++) sarvaHouses[h] += byHouse[h];
  }
  return { sarvaHouses, bhinnaByPlanet };
}

function computeAndPack(chartData: any, language: "en" | "hi") {
  const computed = computeAshtakavarga(chartData || {});
  if (!computed) return null;
  const { sarvaHouses, bhinnaByPlanet } = computed;
  const sarvaTotal = sarvaHouses.reduce((a, b) => a + b, 0);
  const planetTotals: Record<PlanetKey, number> = {} as any;
  PLANETS.forEach((p) => {
    planetTotals[p] = bhinnaByPlanet[p].reduce((a, b) => a + b, 0);
  });
  const houseTotals = sarvaHouses.slice();
  let strongestIdx = 0, weakestIdx = 0;
  for (let h = 1; h < 12; h++) {
    if (sarvaHouses[h] > sarvaHouses[strongestIdx]) strongestIdx = h;
    if (sarvaHouses[h] < sarvaHouses[weakestIdx]) weakestIdx = h;
  }
  const metrics = {
    sarvaStrongestHouse: { house: strongestIdx + 1, bindus: sarvaHouses[strongestIdx] },
    sarvaWeakestHouse: { house: weakestIdx + 1, bindus: sarvaHouses[weakestIdx] },
    planetTotals,
    houseTotals,
  };
  return {
    sarva: { houses: sarvaHouses, total: sarvaTotal },
    bhinna: bhinnaByPlanet,
    metrics,
    language,
    sarvaTotal,
    planetTotals,
  };
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL");
    const serviceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
    if (!supabaseUrl || !serviceKey) {
      console.error("[ashtakavarga] missing supabase env");
      return jsonResponse({ error: "server_misconfigured" }, 500);
    }

    const body = await req.json().catch(() => ({}));
    const birthChartId = String(body.birth_chart_id || "");
    const language: "en" | "hi" = body.language === "hi" ? "hi" : "en";
    const inlineChartData = body.chart_data || (body.birth_data && body.birth_data.chart_data);
    const isAnonymous = !birthChartId && inlineChartData;

    // ========= ANONYMOUS MODE =========
    if (isAnonymous) {
      const packed = computeAndPack(inlineChartData, language);
      if (!packed) {
        console.error("[ashtakavarga] anonymous: chart_data incomplete");
        return jsonResponse({ error: "chart_data_incomplete" }, 422);
      }
      console.log("[ashtakavarga] anonymous computed", { sarvaTotal: packed.sarvaTotal, planetTotals: packed.planetTotals });
      return jsonResponse({
        sarva: packed.sarva, bhinna: packed.bhinna, metrics: packed.metrics,
        language, source: "in_house", cached: false, anonymous: true,
      });
    }

    // ========= AUTHENTICATED MODE =========
    const authHeader = req.headers.get("Authorization");
    if (!authHeader) return jsonResponse({ error: "unauthorized" }, 401);

    const userClient = createClient(supabaseUrl, serviceKey, {
      global: { headers: { Authorization: authHeader } },
    });
    const adminClient = createClient(supabaseUrl, serviceKey);

    const { data: userData, error: userErr } = await userClient.auth.getUser();
    if (userErr || !userData?.user) return jsonResponse({ error: "unauthorized" }, 401);
    const userId = userData.user.id;

    if (!birthChartId) return jsonResponse({ error: "missing_birth_chart_id" }, 400);

    const { data: chart, error: chartErr } = await adminClient
      .from("birth_charts").select("*")
      .eq("id", birthChartId).eq("user_id", userId).maybeSingle();
    if (chartErr) {
      console.error("[ashtakavarga] chart query error", chartErr);
      return jsonResponse({ error: "chart_query_failed", detail: chartErr.message }, 500);
    }
    if (!chart) return jsonResponse({ error: "chart_not_found" }, 404);

    // Cache check
    const { data: cached } = await adminClient
      .from("ashtakavarga_reports").select("*")
      .eq("birth_chart_id", birthChartId).eq("language", language).maybeSingle();
    if (cached) {
      return jsonResponse({
        sarva: cached.sarva_data,
        bhinna: cached.bhinna_data,
        metrics: cached.computed_metrics,
        language: cached.language,
        source: cached.source,
        cached: true,
      });
    }

    if (chart.time_unknown || !chart.birth_time) {
      return jsonResponse({ error: "time_required_for_ashtakavarga" }, 422);
    }

    const packed = computeAndPack(chart.chart_data || {}, language);
    if (!packed) {
      console.error("[ashtakavarga] in-house computation failed: missing planet/ascendant data");
      return jsonResponse({ error: "chart_data_incomplete" }, 422);
    }
    const source = "in_house";
    const { error: insertErr } = await adminClient.from("ashtakavarga_reports").insert({
      birth_chart_id: birthChartId,
      sarva_data: packed.sarva,
      bhinna_data: packed.bhinna,
      computed_metrics: packed.metrics,
      language,
      source,
    });
    if (insertErr) console.error("[ashtakavarga] cache insert failed", insertErr);

    console.log("[ashtakavarga] computed in-house", { birthChartId, sarvaTotal: packed.sarvaTotal, planetTotals: packed.planetTotals });

    return jsonResponse({
      sarva: packed.sarva, bhinna: packed.bhinna, metrics: packed.metrics,
      language, source, cached: false,
    });
  } catch (e) {
    console.error("[ashtakavarga] unhandled error", e instanceof Error ? e.stack : String(e));
    return jsonResponse({ error: "internal_error", message: String(e) }, 500);
  }
});
