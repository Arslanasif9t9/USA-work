import { createClient } from "https://esm.sh/@supabase/supabase-js@2.95.0";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

interface FilterBody {
  specializations?: string[];
  languages?: string[];
  min_experience?: number;
  max_rate?: number;
  status?: "online" | "offline" | "busy" | null;
  is_featured?: boolean;
  is_ai?: boolean;
  search?: string;
  sort?: "recommended" | "price_asc" | "price_desc" | "rating_desc" | "experience_desc";
  limit?: number;
  offset?: number;
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response("ok", { headers: corsHeaders });
  }

  try {
    const body: FilterBody = req.method === "POST" ? await req.json().catch(() => ({})) : {};
    const {
      specializations,
      languages,
      min_experience,
      max_rate,
      status,
      is_featured,
      is_ai,
      search,
      sort = "recommended",
      limit = 24,
      offset = 0,
    } = body;

    const supabase = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!,
    );

    let query = supabase.from("astrologers").select("*", { count: "exact" });

    // Customer-facing: only show admin-approved astrologers
    query = query.eq("approval_status", "approved");

    // Default visibility: show all astrologers (online, busy, offline)
    if (status) query = query.eq("status", status);
    if (is_featured !== undefined) query = query.eq("is_featured", is_featured);
    if (is_ai !== undefined) query = query.eq("is_ai", is_ai);
    if (specializations?.length) query = query.overlaps("specializations", specializations);
    if (languages?.length) query = query.overlaps("languages", languages);
    // Note: overlaps gives OR within a filter; passing both gives AND between filters.
    if (typeof min_experience === "number") query = query.gte("experience_years", min_experience);
    if (typeof max_rate === "number") query = query.lte("discounted_rate_per_min", max_rate);

    if (typeof search === "string" && search.trim()) {
      const q = search.trim().replace(/[%,()]/g, " ");
      query = query.ilike("display_name", `%${q}%`);
    }

    switch (sort) {
      case "price_asc":
        query = query.order("discounted_rate_per_min", { ascending: true, nullsFirst: false });
        break;
      case "price_desc":
        query = query.order("discounted_rate_per_min", { ascending: false, nullsFirst: false });
        break;
      case "rating_desc":
        query = query.order("rating_avg", { ascending: false });
        break;
      case "experience_desc":
        query = query.order("experience_years", { ascending: false });
        break;
      default:
        query = query
          .order("is_featured", { ascending: false })
          .order("status", { ascending: true })
          .order("rating_avg", { ascending: false });
    }

    const { data, error, count } = await query.range(offset, offset + limit - 1);

    if (error) {
      return new Response(JSON.stringify({ error: error.message }), {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    return new Response(JSON.stringify({ data: data ?? [], count: count ?? 0 }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (e) {
    return new Response(JSON.stringify({ error: (e as Error).message }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
