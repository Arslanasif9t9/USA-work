import { createClient } from "npm:@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });

  try {
    const authHeader = req.headers.get("Authorization");
    if (!authHeader) return json({ error: "Unauthorized" }, 401);

    const supabase = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!,
    );

    const { data: { user } } = await supabase.auth.getUser(authHeader.replace("Bearer ", ""));
    if (!user) return json({ error: "Unauthorized" }, 401);

    const { astrologer_id } = await req.json();
    if (!astrologer_id) return json({ error: "Missing astrologer_id" }, 400);

    // Get astrologer
    const { data: astro, error: astroErr } = await supabase
      .from("astrologers")
      .select("id, chat_rate_per_min, accepting_chat, is_chat_online, status, display_name")
      .eq("id", astrologer_id)
      .single();
    if (astroErr || !astro) return json({ error: "Astrologer not found" }, 404);

    if (!astro.accepting_chat || !astro.is_chat_online) {
      return json({ error: "Astrologer is not available for chat right now" }, 400);
    }

    const rate = Number(astro.chat_rate_per_min || 0);
    const holdAmount = rate * 5; // 5-minute minimum

    // Check wallet balance
    const { data: wallet } = await supabase
      .from("wallets")
      .select("balance")
      .eq("user_id", user.id)
      .single();
    if (!wallet || Number(wallet.balance) < holdAmount) {
      return json({ error: `Insufficient wallet balance. Need ₹${holdAmount} for a 5-min minimum chat.` }, 400);
    }

    // Cancel any prior pending session by same user with same astrologer
    await supabase
      .from("chat_sessions")
      .update({ status: "cancelled", ended_at: new Date().toISOString(), end_reason: "superseded" })
      .eq("user_id", user.id)
      .eq("astrologer_id", astrologer_id)
      .eq("status", "pending");

    // Create pending session
    const { data: session, error: sessErr } = await supabase
      .from("chat_sessions")
      .insert({
        user_id: user.id,
        astrologer_id,
        per_minute_rate: rate,
        wallet_hold_amount: holdAmount,
        status: "pending",
      })
      .select()
      .single();
    if (sessErr) return json({ error: sessErr.message }, 500);

    return json({ session });
  } catch (e) {
    return json({ error: (e as Error).message }, 500);
  }
});

function json(body: unknown, status = 200) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { ...corsHeaders, "Content-Type": "application/json" },
  });
}
