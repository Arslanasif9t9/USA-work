import { createClient } from "npm:@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

const SIGNS = ["aries","taurus","gemini","cancer","leo","virgo","libra","scorpio","sagittarius","capricorn","aquarius","pisces"];

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });
  try {
    const { sign } = await req.json();
    const s = String(sign ?? "").toLowerCase();
    if (!SIGNS.includes(s)) return j({ error: "Invalid sign" }, 400);

    const supabase = createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!);
    const today = new Date().toISOString().slice(0, 10);

    const { data: existing } = await supabase.from("horoscope_cache").select("content").eq("sign", s).eq("date", today).maybeSingle();
    if (existing) return j({ sign: s, date: today, content: existing.content, cached: true });

    const apiKey = Deno.env.get("LOVABLE_API_KEY");
    const resp = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: { Authorization: `Bearer ${apiKey}`, "Content-Type": "application/json" },
      body: JSON.stringify({
        model: "google/gemini-3-flash-preview",
        messages: [
          { role: "system", content: "You are a warm, mystical Vedic astrologer. Write a daily horoscope in 3 short paragraphs (love, career, wellness). Keep it positive, specific, and 120-160 words total. No headings, no markdown." },
          { role: "user", content: `Today's horoscope for ${s.charAt(0).toUpperCase() + s.slice(1)} on ${today}.` },
        ],
      }),
    });
    if (!resp.ok) {
      if (resp.status === 429) return j({ error: "Rate limited, try again" }, 429);
      if (resp.status === 402) return j({ error: "AI credits exhausted" }, 402);
      return j({ error: "AI failed" }, 500);
    }
    const data = await resp.json();
    const content = data?.choices?.[0]?.message?.content?.trim() ?? "";
    if (content) {
      await supabase.from("horoscope_cache").upsert({ sign: s, date: today, content }, { onConflict: "sign,date" });
    }
    return j({ sign: s, date: today, content, cached: false });
  } catch (e) {
    return j({ error: (e as Error).message }, 500);
  }
});

function j(b: unknown, status = 200) {
  return new Response(JSON.stringify(b), { status, headers: { ...corsHeaders, "Content-Type": "application/json" } });
}
