// Public endpoint that returns the Agora App ID for the frontend.
// App Certificate stays server-side; only App ID is exposed (it is safe to share).
const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

Deno.serve((req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });
  const appId = Deno.env.get("AGORA_APP_ID") ?? "";
  return new Response(
    JSON.stringify({ app_id: appId, demo_mode: !appId }),
    { headers: { ...corsHeaders, "Content-Type": "application/json" }, status: 200 }
  );
});
