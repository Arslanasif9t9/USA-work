import { createClient } from "npm:@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });

  try {
    const authHeader = req.headers.get("Authorization");
    if (!authHeader) return j({ error: "Unauthorized" }, 401);

    const supabase = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!,
    );

    const { data: { user } } = await supabase.auth.getUser(authHeader.replace("Bearer ", ""));
    if (!user) return j({ error: "Unauthorized" }, 401);

    const { session_id } = await req.json();
    if (!session_id) return j({ error: "Missing session_id" }, 400);

    // Auth check: must be participant
    const { data: session } = await supabase
      .from("chat_sessions")
      .select("user_id, astrologer_id, status, astrologers!inner(user_id)")
      .eq("id", session_id)
      .single();
    if (!session) return j({ error: "Session not found" }, 404);
    // @ts-ignore
    const isParticipant = session.user_id === user.id || session.astrologers.user_id === user.id;
    if (!isParticipant) return j({ error: "Forbidden" }, 403);

    if (session.status === "ended" || session.status === "cancelled" || session.status === "rejected") {
      return j({ ok: true, already_ended: true });
    }

    // @ts-ignore
    const endedBy = session.user_id === user.id ? "customer" : "astrologer";

    // Single source of truth: end_chat_session() does final billing,
    // 30/70 split, astrologer wallet credit, system message.
    const { data, error } = await supabase.rpc("end_chat_session", {
      _session_id: session_id,
      _ended_by: endedBy,
      _end_reason: "user_ended",
    });
    if (error) {
      console.error("end_chat_session rpc err", error);
      return j({ error: error.message }, 500);
    }
    return j({ ok: true, ...(data as object) });
  } catch (e) {
    console.error("end-chat exception", e);
    return j({ error: (e as Error).message }, 500);
  }
});

function j(body: unknown, status = 200) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { ...corsHeaders, "Content-Type": "application/json" },
  });
}
