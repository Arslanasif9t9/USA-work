import { createClient } from "npm:@supabase/supabase-js@2.45.0";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
const SUPABASE_ANON_KEY = Deno.env.get("SUPABASE_ANON_KEY")!;
const SERVICE_ROLE_KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;

const TWILIO_ACCOUNT_SID = Deno.env.get("TWILIO_ACCOUNT_SID");
const TWILIO_AUTH_TOKEN = Deno.env.get("TWILIO_AUTH_TOKEN");
const TWILIO_PHONE_NUMBER = Deno.env.get("TWILIO_PHONE_NUMBER");
const TWILIO_WEBHOOK_BASE_URL = Deno.env.get("TWILIO_WEBHOOK_BASE_URL") ??
  `${SUPABASE_URL}/functions/v1`;

function json(body: unknown, status = 200) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { ...corsHeaders, "Content-Type": "application/json" },
  });
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }
  if (req.method !== "POST") return json({ error: "Method not allowed" }, 405);

  try {
    const authHeader = req.headers.get("Authorization");
    if (!authHeader?.startsWith("Bearer ")) return json({ error: "Unauthorized" }, 401);

    const userClient = createClient(SUPABASE_URL, SUPABASE_ANON_KEY, {
      global: { headers: { Authorization: authHeader } },
    });
    const { data: userData, error: userErr } = await userClient.auth.getUser();
    if (userErr || !userData?.user?.id) return json({ error: "Unauthorized" }, 401);
    const userId = userData.user.id;

    const body = await req.json().catch(() => ({}));
    const astrologerId = body?.astrologer_id;
    if (!astrologerId || typeof astrologerId !== "string") {
      return json({ error: "astrologer_id required" }, 400);
    }

    const admin = createClient(SUPABASE_URL, SERVICE_ROLE_KEY);

    // 1. Profile + phone check
    const { data: profile } = await admin
      .from("profiles")
      .select("phone_e164, phone_verified")
      .eq("id", userId)
      .maybeSingle();
    if (!profile?.phone_e164) {
      return json({ error: "Add your phone number in profile before calling", code: "no_phone" }, 400);
    }

    const twilioConfigured = Boolean(TWILIO_ACCOUNT_SID && TWILIO_AUTH_TOKEN && TWILIO_PHONE_NUMBER);

    // We only require phone-verification if BOTH the customer AND the astrologer have phone
    // numbers set up — i.e. when we'll actually place a real PSTN call. Otherwise we run in
    // simulation mode (the customer's CallSession screen auto-transitions after 3s).
    // This is checked again below once we've loaded the astrologer.

    // 2. Birth chart check
    const { data: chart } = await admin
      .from("birth_charts")
      .select("id")
      .eq("user_id", userId)
      .order("created_at", { ascending: true })
      .limit(1)
      .maybeSingle();
    if (!chart) {
      return json({ error: "Complete your birth chart before calling an astrologer", code: "no_chart" }, 400);
    }

    // 3. Astrologer
    const { data: astro } = await admin
      .from("astrologers")
      .select("id, display_name, phone_number, phone_verified, is_online, accepting_calls, base_rate_per_min, discounted_rate_per_min")
      .eq("id", astrologerId)
      .maybeSingle();
    if (!astro) return json({ error: "Astrologer not found" }, 404);
    if (!astro.is_online) return json({ error: "Astrologer is offline", code: "offline" }, 400);
    if (!astro.accepting_calls) return json({ error: "Astrologer is not accepting calls", code: "not_accepting" }, 400);

    // Real PSTN flow only kicks in if BOTH sides have a verified phone number.
    // If either side is missing, we drop into simulation/mock mode below.
    const willPlacePstnCall = Boolean(
      twilioConfigured &&
      profile.phone_verified &&
      profile.phone_e164 &&
      astro.phone_number &&
      astro.phone_verified,
    );

    // 4. Busy check
    const { data: active } = await admin
      .from("call_sessions")
      .select("id")
      .eq("astrologer_id", astrologerId)
      .in("status", ["pending", "ringing_astrologer", "ringing_user", "connected"])
      .limit(1)
      .maybeSingle();
    if (active) return json({ error: "Astrologer is on another call", code: "busy" }, 409);

    const rate = Number(astro.discounted_rate_per_min ?? astro.base_rate_per_min);
    const minHold = Number((rate * 2).toFixed(2));

    // 5. Wallet check (informational; hold function is the source of truth)
    const { data: wallet } = await admin
      .from("wallets")
      .select("balance")
      .eq("user_id", userId)
      .maybeSingle();
    const balance = Number(wallet?.balance ?? 0);
    if (balance < minHold) {
      return json(
        { error: "Insufficient balance", code: "insufficient_balance", required: minHold, current_balance: balance },
        402,
      );
    }

    // 6. Insert call session
    const { data: session, error: insErr } = await admin
      .from("call_sessions")
      .insert({
        user_id: userId,
        astrologer_id: astrologerId,
        birth_chart_id: chart.id,
        per_minute_rate: rate,
        wallet_hold_amount: minHold,
        status: "pending",
      })
      .select("id")
      .single();

    if (insErr || !session) {
      // unique partial index may collide → race with another caller
      return json({ error: "Astrologer is on another call", code: "busy" }, 409);
    }

    // 7. Place wallet hold (atomic)
    const { error: holdErr } = await admin.rpc("hold_wallet_for_call", {
      _user_id: userId,
      _amount: minHold,
      _call_session_id: session.id,
    });
    if (holdErr) {
      // Roll back the call session; partial unique idx will release
      await admin.from("call_sessions").delete().eq("id", session.id);
      return json(
        { error: "Insufficient balance", code: "insufficient_balance", required: minHold, current_balance: balance },
        402,
      );
    }

    // 8. Twilio outbound to astrologer (only if creds + BOTH phones configured & verified)
    let astroCallSid: string | null = null;
    const twilioReady = willPlacePstnCall && TWILIO_WEBHOOK_BASE_URL;
    let twilioFallbackReason: string | null = null;
    if (twilioReady) {
      try {
        console.log("initiate-call: attempting real Twilio call", { session_id: session.id, astrologer_id: astrologerId });
        const twimlUrl = `${TWILIO_WEBHOOK_BASE_URL}/twiml-astrologer-leg?call_session_id=${session.id}`;
        const statusUrl = `${TWILIO_WEBHOOK_BASE_URL}/twilio-status-webhook?call_session_id=${session.id}&leg=astrologer`;
        const form = new URLSearchParams({
          To: astro.phone_number!,
          From: TWILIO_PHONE_NUMBER!,
          Url: twimlUrl,
          StatusCallback: statusUrl,
          "StatusCallbackEvent": "initiated",
        });
        form.append("StatusCallbackEvent", "ringing");
        form.append("StatusCallbackEvent", "answered");
        form.append("StatusCallbackEvent", "completed");
        const res = await fetch(
          `https://api.twilio.com/2010-04-01/Accounts/${TWILIO_ACCOUNT_SID}/Calls.json`,
          {
            method: "POST",
            headers: {
              Authorization:
                "Basic " + btoa(`${TWILIO_ACCOUNT_SID}:${TWILIO_AUTH_TOKEN}`),
              "Content-Type": "application/x-www-form-urlencoded",
            },
            body: form.toString(),
          },
        );
        const data = await res.json();
        if (!res.ok) throw new Error(data?.message ?? "Twilio call failed");
        astroCallSid = data.sid as string;
      } catch (twilioErr) {
        console.error("twilio error", twilioErr);
        const msg = (twilioErr as Error)?.message ?? "Twilio call failed";
        twilioFallbackReason = /unverified|trial/i.test(msg) ? "twilio_trial_unverified" : "twilio_error";
        console.warn("initiate-call: Twilio failed; falling back to simulation", {
          session_id: session.id,
          reason: twilioFallbackReason,
          message: msg,
        });
      }
    } else {
      console.log("initiate-call: running in simulation mode", {
        twilioConfigured,
        customer_phone_verified: profile.phone_verified,
        astrologer_phone_set: Boolean(astro.phone_number),
        astrologer_phone_verified: astro.phone_verified,
      });
    }

    // Mock-mode: when Twilio isn't ready we leave status as 'pending' so the
    // astrologer's incoming-call popup fires AND the customer's CallSession
    // simulation transitions to 'connected' after a timeout.
    const finalStatus = astroCallSid ? "ringing_astrologer" : "pending";
    if (astroCallSid) {
      await admin
        .from("call_sessions")
        .update({
          status: finalStatus,
          twilio_astrologer_call_sid: astroCallSid,
        })
        .eq("id", session.id);
    }

    return json({
      call_session_id: session.id,
      status: finalStatus,
      per_minute_rate: rate,
      hold_amount: minHold,
      twilio_configured: Boolean(astroCallSid),
      mock: !astroCallSid,
      mode: astroCallSid ? "real_twilio" : "simulation",
      fallback_reason: twilioFallbackReason,
    });
  } catch (e) {
    console.error("initiate-call error", e);
    const msg = e instanceof Error ? e.message : "Unknown error";
    return json({ error: "Could not initiate call", details: msg }, 500);
  }
});
