import { createClient } from "https://esm.sh/@supabase/supabase-js@2.45.0";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type",
};

// Very rough timezone inference from lon/lat. Good enough for India + common cases;
// proper tz lookup library can be swapped in later.
function inferTimezone(lat: number, lon: number, country?: string): string {
  // India bounding box
  if (lat >= 6 && lat <= 36 && lon >= 68 && lon <= 98) return "Asia/Kolkata";
  if (country === "United States" || country === "USA") {
    if (lon < -115) return "America/Los_Angeles";
    if (lon < -100) return "America/Denver";
    if (lon < -85) return "America/Chicago";
    return "America/New_York";
  }
  if (country === "United Kingdom") return "Europe/London";
  if (country === "Australia") return "Australia/Sydney";
  if (country === "United Arab Emirates") return "Asia/Dubai";
  if (country === "Singapore") return "Asia/Singapore";
  if (country === "Canada") return "America/Toronto";
  // Fallback: nearest 15° offset
  const offset = Math.round(lon / 15);
  const sign = offset >= 0 ? "+" : "-";
  return `Etc/GMT${sign}${Math.abs(offset)}`;
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });

  try {
    const auth = req.headers.get("Authorization");
    if (!auth) {
      return new Response(JSON.stringify({ error: "Unauthorized" }), {
        status: 401,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
    const SERVICE_KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const ANON_KEY = Deno.env.get("SUPABASE_ANON_KEY")!;

    // verify user
    const userClient = createClient(SUPABASE_URL, ANON_KEY, {
      global: { headers: { Authorization: auth } },
    });
    const { data: { user } } = await userClient.auth.getUser();
    if (!user) {
      return new Response(JSON.stringify({ error: "Unauthorized" }), {
        status: 401,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const { query } = await req.json();
    if (!query || typeof query !== "string" || query.trim().length < 2) {
      return new Response(JSON.stringify({ error: "Query must be at least 2 chars" }), {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }
    const normalized = query.trim().toLowerCase();

    const admin = createClient(SUPABASE_URL, SERVICE_KEY);

    // cache lookup (<30 days)
    const { data: cached } = await admin
      .from("location_cache")
      .select("results, created_at")
      .eq("query", normalized)
      .maybeSingle();

    if (cached) {
      const ageMs = Date.now() - new Date(cached.created_at).getTime();
      if (ageMs < 30 * 24 * 60 * 60 * 1000) {
        return new Response(JSON.stringify({ results: cached.results, cached: true }), {
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
    }

    // Nominatim
    const url = `https://nominatim.openstreetmap.org/search?format=json&addressdetails=1&limit=10&q=${encodeURIComponent(query)}`;
    const resp = await fetch(url, {
      headers: {
        "User-Agent": "AstroGuide/1.0 (birth-chart geocoding)",
        "Accept-Language": "en",
      },
    });
    if (!resp.ok) {
      const body = await resp.text();
      return new Response(
        JSON.stringify({ error: `Geocoder error ${resp.status}`, details: body }),
        { status: 502, headers: { ...corsHeaders, "Content-Type": "application/json" } },
      );
    }
    const raw = await resp.json();
    const results = (Array.isArray(raw) ? raw : []).map((r: any) => {
      const lat = parseFloat(r.lat);
      const lon = parseFloat(r.lon);
      const country = r.address?.country;
      return {
        display_name: r.display_name as string,
        lat,
        lon,
        timezone: inferTimezone(lat, lon, country),
        country,
      };
    });

    // upsert cache
    await admin.from("location_cache").upsert(
      { query: normalized, results, created_at: new Date().toISOString() },
      { onConflict: "query" },
    );

    return new Response(JSON.stringify({ results, cached: false }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (e) {
    const msg = e instanceof Error ? e.message : String(e);
    return new Response(JSON.stringify({ error: msg }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
