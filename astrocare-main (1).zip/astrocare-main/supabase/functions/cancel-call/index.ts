import { createClient } from "npm:@supabase/supabase-js@2.45.0";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
const SUPABASE_ANON_KEY = Deno.env.get("SUPABASE_ANON_KEY")!;
const SERVICE_ROLE_KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
const TWILIO_ACCOUNT_SID = Deno.env.get("TWILIO_ACCOUNT_SID");
const TWILIO_AUTH_TOKEN = Deno.env.get("TWILIO_AUTH_TOKEN");

function json(body: unknown, status = 200) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { ...corsHeaders, "Content-Type": "application/json" },
  });
}

async function hangupTwilioCall(sid: string) {
  if (!TWILIO_ACCOUNT_SID || !TWILIO_AUTH_TOKEN) return;
  try {
    await fetch(
      `https://api.twilio.com/2010-04-01/Accounts/${TWILIO_ACCOUNT_SID}/Calls/${sid}.json`,
      {
        method: "POST",
        headers: {
          Authorization: "Basic " + btoa(`${TWILIO_ACCOUNT_SID}:${TWILIO_AUTH_TOKEN}`),
          "Content-Type": "application/x-www-form-urlencoded",
        },
        body: "Status=completed",
      },
    );
  } catch (e) {
    console.error("hangup error", sid, e);
  }
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });
  if (req.method !== "POST") return json({ error: "Method not allowed" }, 405);

  try {
    const authHeader = req.headers.get("Authorization");
    if (!authHeader?.startsWith("Bearer ")) return json({ error: "Unauthorized" }, 401);

    const userClient = createClient(SUPABASE_URL, SUPABASE_ANON_KEY, {
      global: { headers: { Authorization: authHeader } },
    });
    const { data: userData, error: userErr } = await userClient.auth.getUser();
    if (userErr || !userData?.user?.id) return json({ error: "Unauthorized" }, 401);
    const userId = userData.user.id;

    const body = await req.json().catch(() => ({}));
    const callSessionId = body?.call_session_id;
    if (!callSessionId) return json({ error: "call_session_id required" }, 400);

    const admin = createClient(SUPABASE_URL, SERVICE_ROLE_KEY);
    const { data: session } = await admin
      .from("call_sessions")
      .select("id, user_id, status, twilio_astrologer_call_sid, twilio_user_call_sid")
      .eq("id", callSessionId)
      .maybeSingle();
    if (!session) return json({ error: "Call not found" }, 404);
    if (session.user_id !== userId) return json({ error: "Forbidden" }, 403);

    if (!["pending", "ringing_astrologer", "ringing_user"].includes(session.status)) {
      return json({ error: "Call already connected, hang up from phone" }, 400);
    }

    if (session.twilio_astrologer_call_sid) await hangupTwilioCall(session.twilio_astrologer_call_sid);
    if (session.twilio_user_call_sid) await hangupTwilioCall(session.twilio_user_call_sid);

    await admin
      .from("call_sessions")
      .update({
        status: "cancelled",
        end_reason: "cancelled_by_user",
        ended_at: new Date().toISOString(),
      })
      .eq("id", callSessionId);

    await admin.rpc("release_call_hold", { _call_session_id: callSessionId });

    return json({ ok: true });
  } catch (e) {
    console.error("cancel-call error", e);
    const msg = e instanceof Error ? e.message : "Unknown error";
    return json({ error: "Could not cancel call", details: msg }, 500);
  }
});
