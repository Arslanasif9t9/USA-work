
-- =========================================================
-- AstroLive Phase 1 schema
-- =========================================================

-- 1. Platform settings — master kill-switch columns
ALTER TABLE public.platform_settings
  ADD COLUMN IF NOT EXISTS astrolive_enabled boolean NOT NULL DEFAULT true,
  ADD COLUMN IF NOT EXISTS astrolive_enabled_web boolean NOT NULL DEFAULT true,
  ADD COLUMN IF NOT EXISTS astrolive_enabled_mobile boolean NOT NULL DEFAULT true;

-- 2. live_streams
CREATE TABLE IF NOT EXISTS public.live_streams (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  astrologer_id uuid NOT NULL REFERENCES public.astrologers(id) ON DELETE CASCADE,
  title text NOT NULL DEFAULT 'Live with astrologer',
  description text,
  thumbnail_url text,
  channel_name text NOT NULL UNIQUE,
  status text NOT NULL DEFAULT 'live' CHECK (status IN ('live','ended','scheduled')),
  viewer_count integer NOT NULL DEFAULT 0,
  peak_viewer_count integer NOT NULL DEFAULT 0,
  total_unique_viewers integer NOT NULL DEFAULT 0,
  total_likes integer NOT NULL DEFAULT 0,
  total_gifts_value numeric NOT NULL DEFAULT 0,
  total_comments integer NOT NULL DEFAULT 0,
  save_recording boolean NOT NULL DEFAULT true,
  ended_reason text,
  ended_by_admin uuid,
  started_at timestamptz NOT NULL DEFAULT now(),
  ended_at timestamptz,
  duration_seconds integer NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_live_streams_status ON public.live_streams(status);
CREATE INDEX IF NOT EXISTS idx_live_streams_astrologer ON public.live_streams(astrologer_id);
CREATE INDEX IF NOT EXISTS idx_live_streams_started_at ON public.live_streams(started_at DESC);

-- 3. live_viewers
CREATE TABLE IF NOT EXISTS public.live_viewers (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  live_stream_id uuid NOT NULL REFERENCES public.live_streams(id) ON DELETE CASCADE,
  user_id uuid NOT NULL,
  joined_at timestamptz NOT NULL DEFAULT now(),
  left_at timestamptz,
  watch_duration_seconds integer NOT NULL DEFAULT 0
);
CREATE INDEX IF NOT EXISTS idx_live_viewers_stream ON public.live_viewers(live_stream_id);
CREATE INDEX IF NOT EXISTS idx_live_viewers_user ON public.live_viewers(user_id);

-- 4. live_comments
CREATE TABLE IF NOT EXISTS public.live_comments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  live_stream_id uuid NOT NULL REFERENCES public.live_streams(id) ON DELETE CASCADE,
  user_id uuid NOT NULL,
  user_name text NOT NULL DEFAULT '',
  user_avatar text,
  is_host boolean NOT NULL DEFAULT false,
  comment_text text NOT NULL,
  is_pinned boolean NOT NULL DEFAULT false,
  is_deleted boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_live_comments_stream ON public.live_comments(live_stream_id, created_at DESC);

-- 5. live_likes
CREATE TABLE IF NOT EXISTS public.live_likes (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  live_stream_id uuid NOT NULL REFERENCES public.live_streams(id) ON DELETE CASCADE,
  user_id uuid NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (live_stream_id, user_id)
);
CREATE INDEX IF NOT EXISTS idx_live_likes_stream ON public.live_likes(live_stream_id);

-- 6. live_followers
CREATE TABLE IF NOT EXISTS public.live_followers (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  follower_id uuid NOT NULL,
  astrologer_id uuid NOT NULL REFERENCES public.astrologers(id) ON DELETE CASCADE,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (follower_id, astrologer_id)
);
CREATE INDEX IF NOT EXISTS idx_live_followers_astro ON public.live_followers(astrologer_id);
CREATE INDEX IF NOT EXISTS idx_live_followers_follower ON public.live_followers(follower_id);

-- =========================================================
-- RLS
-- =========================================================
ALTER TABLE public.live_streams   ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.live_viewers   ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.live_comments  ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.live_likes     ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.live_followers ENABLE ROW LEVEL SECURITY;

-- live_streams
CREATE POLICY "anyone reads live_streams" ON public.live_streams
  FOR SELECT USING (true);
CREATE POLICY "astrologer inserts own stream" ON public.live_streams
  FOR INSERT WITH CHECK (
    astrologer_id IN (SELECT id FROM public.astrologers WHERE user_id = auth.uid())
  );
CREATE POLICY "astrologer updates own stream" ON public.live_streams
  FOR UPDATE USING (
    astrologer_id IN (SELECT id FROM public.astrologers WHERE user_id = auth.uid())
  );
CREATE POLICY "admin updates streams" ON public.live_streams
  FOR UPDATE USING (admin_has_permission(auth.uid(), 'manage_content'));

-- live_viewers
CREATE POLICY "anyone reads viewers" ON public.live_viewers
  FOR SELECT USING (true);
CREATE POLICY "user inserts own viewer row" ON public.live_viewers
  FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "user updates own viewer row" ON public.live_viewers
  FOR UPDATE USING (auth.uid() = user_id);

-- live_comments
CREATE POLICY "anyone reads comments" ON public.live_comments
  FOR SELECT USING (is_deleted = false);
CREATE POLICY "user inserts own comment" ON public.live_comments
  FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "host or admin updates comment" ON public.live_comments
  FOR UPDATE USING (
    auth.uid() = user_id
    OR live_stream_id IN (
      SELECT ls.id FROM public.live_streams ls
      JOIN public.astrologers a ON a.id = ls.astrologer_id
      WHERE a.user_id = auth.uid()
    )
    OR admin_has_permission(auth.uid(), 'manage_content')
  );

-- live_likes
CREATE POLICY "anyone reads likes" ON public.live_likes
  FOR SELECT USING (true);
CREATE POLICY "user inserts own like" ON public.live_likes
  FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "user removes own like" ON public.live_likes
  FOR DELETE USING (auth.uid() = user_id);

-- live_followers
CREATE POLICY "anyone reads followers" ON public.live_followers
  FOR SELECT USING (true);
CREATE POLICY "user inserts own follow" ON public.live_followers
  FOR INSERT WITH CHECK (auth.uid() = follower_id);
CREATE POLICY "user removes own follow" ON public.live_followers
  FOR DELETE USING (auth.uid() = follower_id);

-- =========================================================
-- Realtime
-- =========================================================
ALTER TABLE public.live_streams   REPLICA IDENTITY FULL;
ALTER TABLE public.live_viewers   REPLICA IDENTITY FULL;
ALTER TABLE public.live_comments  REPLICA IDENTITY FULL;
ALTER TABLE public.live_likes     REPLICA IDENTITY FULL;
ALTER TABLE public.live_followers REPLICA IDENTITY FULL;

DO $$
BEGIN
  BEGIN
    ALTER PUBLICATION supabase_realtime ADD TABLE public.live_streams;
  EXCEPTION WHEN duplicate_object THEN NULL; END;
  BEGIN
    ALTER PUBLICATION supabase_realtime ADD TABLE public.live_viewers;
  EXCEPTION WHEN duplicate_object THEN NULL; END;
  BEGIN
    ALTER PUBLICATION supabase_realtime ADD TABLE public.live_comments;
  EXCEPTION WHEN duplicate_object THEN NULL; END;
  BEGIN
    ALTER PUBLICATION supabase_realtime ADD TABLE public.live_likes;
  EXCEPTION WHEN duplicate_object THEN NULL; END;
  BEGIN
    ALTER PUBLICATION supabase_realtime ADD TABLE public.live_followers;
  EXCEPTION WHEN duplicate_object THEN NULL; END;
END $$;

-- =========================================================
-- RPCs
-- =========================================================

-- Start a new live stream (called by astrologer)
CREATE OR REPLACE FUNCTION public.start_live_stream(
  _title text,
  _description text,
  _thumbnail_url text,
  _save_recording boolean
) RETURNS jsonb
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public
AS $$
DECLARE
  _astro_id uuid;
  _enabled boolean;
  _channel text;
  _stream_id uuid;
BEGIN
  IF auth.uid() IS NULL THEN RAISE EXCEPTION 'Not authenticated' USING ERRCODE='28000'; END IF;
  SELECT astrolive_enabled INTO _enabled FROM public.platform_settings WHERE id = 1;
  IF NOT COALESCE(_enabled, false) THEN
    RAISE EXCEPTION 'AstroLive is disabled by admin' USING ERRCODE='42501';
  END IF;
  SELECT id INTO _astro_id FROM public.astrologers WHERE user_id = auth.uid();
  IF _astro_id IS NULL THEN RAISE EXCEPTION 'Not an astrologer' USING ERRCODE='42501'; END IF;

  -- End any previous live streams for this astrologer
  UPDATE public.live_streams
     SET status = 'ended', ended_at = COALESCE(ended_at, now()),
         ended_reason = COALESCE(ended_reason, 'replaced_by_new_stream')
   WHERE astrologer_id = _astro_id AND status = 'live';

  _channel := 'live_' || replace(_astro_id::text, '-', '') || '_' || extract(epoch from now())::bigint;
  INSERT INTO public.live_streams
    (astrologer_id, title, description, thumbnail_url, channel_name, status, save_recording)
  VALUES
    (_astro_id, COALESCE(NULLIF(_title,''),'Live'), _description, _thumbnail_url, _channel, 'live', COALESCE(_save_recording, true))
  RETURNING id INTO _stream_id;

  RETURN jsonb_build_object('ok', true, 'stream_id', _stream_id, 'channel_name', _channel);
END;
$$;

-- End a live stream
CREATE OR REPLACE FUNCTION public.end_live_stream(_stream_id uuid, _reason text)
RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path = public
AS $$
DECLARE
  s record;
  _is_admin boolean;
  _is_owner boolean;
  _duration int;
BEGIN
  SELECT * INTO s FROM public.live_streams WHERE id = _stream_id FOR UPDATE;
  IF s IS NULL THEN RAISE EXCEPTION 'Not found'; END IF;
  IF s.status = 'ended' THEN RETURN jsonb_build_object('ok', true, 'already', true); END IF;

  _is_admin := admin_has_permission(auth.uid(), 'manage_content');
  _is_owner := EXISTS (
    SELECT 1 FROM public.astrologers a WHERE a.id = s.astrologer_id AND a.user_id = auth.uid()
  );
  IF NOT (_is_admin OR _is_owner) THEN
    RAISE EXCEPTION 'Forbidden' USING ERRCODE='42501';
  END IF;

  _duration := GREATEST(0, EXTRACT(EPOCH FROM (now() - s.started_at))::int);
  UPDATE public.live_streams
     SET status = 'ended',
         ended_at = now(),
         duration_seconds = _duration,
         ended_reason = COALESCE(_reason, CASE WHEN _is_admin AND NOT _is_owner THEN 'ended_by_admin' ELSE 'ended_by_host' END),
         ended_by_admin = CASE WHEN _is_admin AND NOT _is_owner THEN auth.uid() ELSE NULL END
   WHERE id = _stream_id;

  -- Mark all open viewer rows as left
  UPDATE public.live_viewers
     SET left_at = now(),
         watch_duration_seconds = GREATEST(0, EXTRACT(EPOCH FROM (now() - joined_at))::int)
   WHERE live_stream_id = _stream_id AND left_at IS NULL;

  RETURN jsonb_build_object('ok', true, 'duration_seconds', _duration);
END;
$$;

-- Customer joins a stream
CREATE OR REPLACE FUNCTION public.join_live_stream(_stream_id uuid)
RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path = public
AS $$
DECLARE _new int; _peak int; _existed boolean;
BEGIN
  IF auth.uid() IS NULL THEN RAISE EXCEPTION 'Not authenticated' USING ERRCODE='28000'; END IF;

  SELECT EXISTS(SELECT 1 FROM public.live_viewers WHERE live_stream_id = _stream_id AND user_id = auth.uid())
    INTO _existed;

  INSERT INTO public.live_viewers (live_stream_id, user_id) VALUES (_stream_id, auth.uid());

  UPDATE public.live_streams
     SET viewer_count = viewer_count + 1,
         total_unique_viewers = total_unique_viewers + CASE WHEN _existed THEN 0 ELSE 1 END,
         peak_viewer_count = GREATEST(peak_viewer_count, viewer_count + 1)
   WHERE id = _stream_id
   RETURNING viewer_count, peak_viewer_count INTO _new, _peak;

  RETURN jsonb_build_object('ok', true, 'viewer_count', _new);
END;
$$;

-- Customer leaves a stream
CREATE OR REPLACE FUNCTION public.leave_live_stream(_stream_id uuid)
RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path = public
AS $$
BEGIN
  IF auth.uid() IS NULL THEN RETURN jsonb_build_object('ok', false); END IF;
  UPDATE public.live_viewers
     SET left_at = now(),
         watch_duration_seconds = GREATEST(0, EXTRACT(EPOCH FROM (now() - joined_at))::int)
   WHERE live_stream_id = _stream_id AND user_id = auth.uid() AND left_at IS NULL;
  UPDATE public.live_streams
     SET viewer_count = GREATEST(0, viewer_count - 1)
   WHERE id = _stream_id AND status = 'live';
  RETURN jsonb_build_object('ok', true);
END;
$$;

-- Like a stream (idempotent)
CREATE OR REPLACE FUNCTION public.like_live_stream(_stream_id uuid)
RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path = public
AS $$
DECLARE _inserted boolean := false;
BEGIN
  IF auth.uid() IS NULL THEN RAISE EXCEPTION 'Not authenticated' USING ERRCODE='28000'; END IF;
  INSERT INTO public.live_likes (live_stream_id, user_id)
  VALUES (_stream_id, auth.uid())
  ON CONFLICT DO NOTHING;
  GET DIAGNOSTICS _inserted = ROW_COUNT;
  IF _inserted THEN
    UPDATE public.live_streams SET total_likes = total_likes + 1 WHERE id = _stream_id;
  END IF;
  RETURN jsonb_build_object('ok', true, 'new_like', _inserted);
END;
$$;

-- Post a comment
CREATE OR REPLACE FUNCTION public.post_live_comment(_stream_id uuid, _text text)
RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path = public
AS $$
DECLARE
  _name text; _avatar text; _is_host boolean; _astro_user uuid; _id uuid;
BEGIN
  IF auth.uid() IS NULL THEN RAISE EXCEPTION 'Not authenticated' USING ERRCODE='28000'; END IF;
  IF length(coalesce(_text, '')) = 0 OR length(_text) > 500 THEN
    RAISE EXCEPTION 'Invalid comment';
  END IF;

  SELECT a.user_id INTO _astro_user
    FROM public.live_streams ls JOIN public.astrologers a ON a.id = ls.astrologer_id
    WHERE ls.id = _stream_id;
  _is_host := (_astro_user = auth.uid());

  IF _is_host THEN
    SELECT display_name, avatar_url INTO _name, _avatar
      FROM public.astrologers WHERE user_id = auth.uid();
  ELSE
    SELECT name, avatar_url INTO _name, _avatar
      FROM public.profiles WHERE id = auth.uid();
  END IF;

  INSERT INTO public.live_comments (live_stream_id, user_id, user_name, user_avatar, is_host, comment_text)
  VALUES (_stream_id, auth.uid(), COALESCE(_name,'Guest'), _avatar, _is_host, _text)
  RETURNING id INTO _id;

  UPDATE public.live_streams SET total_comments = total_comments + 1 WHERE id = _stream_id;
  RETURN jsonb_build_object('ok', true, 'id', _id);
END;
$$;

-- Toggle follow on an astrologer
CREATE OR REPLACE FUNCTION public.toggle_follow_astrologer(_astrologer_id uuid)
RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path = public
AS $$
DECLARE _existed boolean;
BEGIN
  IF auth.uid() IS NULL THEN RAISE EXCEPTION 'Not authenticated' USING ERRCODE='28000'; END IF;
  SELECT EXISTS(SELECT 1 FROM public.live_followers WHERE follower_id = auth.uid() AND astrologer_id = _astrologer_id)
    INTO _existed;
  IF _existed THEN
    DELETE FROM public.live_followers WHERE follower_id = auth.uid() AND astrologer_id = _astrologer_id;
    UPDATE public.astrologers SET follower_count = GREATEST(0, follower_count - 1) WHERE id = _astrologer_id;
    RETURN jsonb_build_object('ok', true, 'following', false);
  ELSE
    INSERT INTO public.live_followers (follower_id, astrologer_id) VALUES (auth.uid(), _astrologer_id);
    UPDATE public.astrologers SET follower_count = follower_count + 1 WHERE id = _astrologer_id;
    RETURN jsonb_build_object('ok', true, 'following', true);
  END IF;
END;
$$;
