-- birth_charts.source already exists; add a recomputed_at marker for tracking re-runs
ALTER TABLE public.birth_charts
  ADD COLUMN IF NOT EXISTS recomputed_at TIMESTAMP WITH TIME ZONE;

-- Index for monitoring queries by source
CREATE INDEX IF NOT EXISTS idx_birth_charts_source ON public.birth_charts(source);

-- profiles.language_preference for site-wide i18n persistence
ALTER TABLE public.profiles
  ADD COLUMN IF NOT EXISTS language_preference TEXT NOT NULL DEFAULT 'en'
    CHECK (language_preference IN ('en', 'hi'));