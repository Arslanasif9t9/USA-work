-- ===== Extend astrologers profile =====
ALTER TABLE public.astrologers
  ADD COLUMN IF NOT EXISTS education text,
  ADD COLUMN IF NOT EXISTS focus_area text,
  ADD COLUMN IF NOT EXISTS systems_known text[] NOT NULL DEFAULT '{}',
  ADD COLUMN IF NOT EXISTS total_consultations integer NOT NULL DEFAULT 0;

-- ===== Roles =====
DO $$ BEGIN
  CREATE TYPE public.app_role AS ENUM ('customer', 'astrologer', 'admin');
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

CREATE TABLE IF NOT EXISTS public.user_roles (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL,
  role public.app_role NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (user_id, role)
);

ALTER TABLE public.user_roles ENABLE ROW LEVEL SECURITY;

CREATE OR REPLACE FUNCTION public.has_role(_user_id uuid, _role public.app_role)
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.user_roles WHERE user_id = _user_id AND role = _role
  );
$$;

DROP POLICY IF EXISTS "Users can read own roles" ON public.user_roles;
CREATE POLICY "Users can read own roles"
ON public.user_roles
FOR SELECT
USING (auth.uid() = user_id);

-- Backfill: existing astrologer records become 'astrologer' role
INSERT INTO public.user_roles (user_id, role)
SELECT user_id, 'astrologer'::public.app_role
FROM public.astrologers
WHERE user_id IS NOT NULL
ON CONFLICT DO NOTHING;