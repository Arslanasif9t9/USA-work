
-- =========================================================================
-- platform_settings: single-row keyed config (using id = 1 singleton pattern)
-- =========================================================================
CREATE TABLE IF NOT EXISTS public.platform_settings (
  id integer PRIMARY KEY DEFAULT 1,
  -- session
  min_billing_seconds integer NOT NULL DEFAULT 60,
  auto_end_below_balance numeric NOT NULL DEFAULT 10,
  max_session_minutes integer NOT NULL DEFAULT 120,
  -- commission
  astrologer_share_percent numeric NOT NULL DEFAULT 30,
  -- wallet
  min_recharge_amount numeric NOT NULL DEFAULT 100,
  max_wallet_balance numeric NOT NULL DEFAULT 100000,
  -- reviews
  reviews_require_approval boolean NOT NULL DEFAULT true,
  min_review_session_seconds integer NOT NULL DEFAULT 60,
  -- withdrawals
  min_withdrawal_amount numeric NOT NULL DEFAULT 200,
  max_withdrawal_amount numeric NOT NULL DEFAULT 50000,
  withdrawal_processing_notice text NOT NULL DEFAULT 'Withdrawals are processed within 2-3 business days.',
  -- maintenance
  maintenance_mode boolean NOT NULL DEFAULT false,
  maintenance_message text NOT NULL DEFAULT 'AstroGuide is undergoing scheduled maintenance. We''ll be back shortly.',
  -- meta
  updated_at timestamptz NOT NULL DEFAULT now(),
  updated_by uuid,
  CONSTRAINT platform_settings_singleton CHECK (id = 1)
);

ALTER TABLE public.platform_settings ENABLE ROW LEVEL SECURITY;

CREATE POLICY "active admins read settings"
  ON public.platform_settings FOR SELECT
  USING (public.is_active_admin(auth.uid()));

CREATE POLICY "anyone reads maintenance flag"
  ON public.platform_settings FOR SELECT
  USING (true);

CREATE POLICY "master updates settings"
  ON public.platform_settings FOR UPDATE
  USING (public.is_master_admin(auth.uid()));

CREATE POLICY "master inserts settings"
  ON public.platform_settings FOR INSERT
  WITH CHECK (public.is_master_admin(auth.uid()));

-- Seed singleton row
INSERT INTO public.platform_settings (id) VALUES (1) ON CONFLICT (id) DO NOTHING;

-- =========================================================================
-- announcements: admin-authored, audience-targeted
-- =========================================================================
CREATE TABLE IF NOT EXISTS public.announcements (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  body text NOT NULL,
  audience text NOT NULL DEFAULT 'all', -- 'all' | 'customers' | 'astrologers' | 'user'
  target_user_id uuid,
  display_type text NOT NULL DEFAULT 'notification', -- 'banner' | 'notification'
  scheduled_at timestamptz NOT NULL DEFAULT now(),
  expires_at timestamptz,
  is_active boolean NOT NULL DEFAULT true,
  delivered boolean NOT NULL DEFAULT false,
  created_by uuid,
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.announcements ENABLE ROW LEVEL SECURITY;

CREATE POLICY "admins read announcements"
  ON public.announcements FOR SELECT
  USING (public.is_active_admin(auth.uid()));

CREATE POLICY "users read active announcements"
  ON public.announcements FOR SELECT
  USING (
    is_active = true
    AND scheduled_at <= now()
    AND (expires_at IS NULL OR expires_at > now())
    AND display_type = 'banner'
    AND (
      audience = 'all'
      OR (audience = 'customers')
      OR (audience = 'astrologers')
      OR (audience = 'user' AND target_user_id = auth.uid())
    )
  );

CREATE POLICY "content admins insert announcements"
  ON public.announcements FOR INSERT
  WITH CHECK (public.admin_has_permission(auth.uid(), 'manage_content'));

CREATE POLICY "content admins update announcements"
  ON public.announcements FOR UPDATE
  USING (public.admin_has_permission(auth.uid(), 'manage_content'));

CREATE INDEX IF NOT EXISTS announcements_active_idx ON public.announcements (is_active, scheduled_at, expires_at);
