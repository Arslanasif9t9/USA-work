
-- Add chat-related columns to astrologers
ALTER TABLE public.astrologers
  ADD COLUMN IF NOT EXISTS chat_rate_per_min numeric NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS accepting_chat boolean NOT NULL DEFAULT true,
  ADD COLUMN IF NOT EXISTS is_chat_online boolean NOT NULL DEFAULT true;

-- Default chat rate to base call rate where not set
UPDATE public.astrologers SET chat_rate_per_min = base_rate_per_min WHERE chat_rate_per_min = 0;

-- Chat sessions
CREATE TABLE IF NOT EXISTS public.chat_sessions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL,
  astrologer_id uuid NOT NULL REFERENCES public.astrologers(id) ON DELETE CASCADE,
  status text NOT NULL DEFAULT 'pending', -- pending | active | ended | rejected | cancelled
  per_minute_rate numeric NOT NULL,
  wallet_hold_amount numeric NOT NULL DEFAULT 0,
  hold_released boolean NOT NULL DEFAULT false,
  requested_at timestamptz NOT NULL DEFAULT now(),
  accepted_at timestamptz,
  ended_at timestamptz,
  end_reason text,
  duration_seconds integer NOT NULL DEFAULT 0,
  last_billed_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_chat_sessions_user ON public.chat_sessions(user_id);
CREATE INDEX IF NOT EXISTS idx_chat_sessions_astro ON public.chat_sessions(astrologer_id);
CREATE INDEX IF NOT EXISTS idx_chat_sessions_status ON public.chat_sessions(status);

ALTER TABLE public.chat_sessions ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users select own chat sessions"
  ON public.chat_sessions FOR SELECT
  USING (auth.uid() = user_id
    OR astrologer_id IN (SELECT id FROM public.astrologers WHERE user_id = auth.uid()));

CREATE POLICY "Users insert own chat sessions"
  ON public.chat_sessions FOR INSERT
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Participants update chat sessions"
  ON public.chat_sessions FOR UPDATE
  USING (auth.uid() = user_id
    OR astrologer_id IN (SELECT id FROM public.astrologers WHERE user_id = auth.uid()));

-- Chat messages
CREATE TABLE IF NOT EXISTS public.chat_messages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  session_id uuid NOT NULL REFERENCES public.chat_sessions(id) ON DELETE CASCADE,
  sender_id uuid NOT NULL,
  sender_role text NOT NULL CHECK (sender_role IN ('customer','astrologer','system')),
  content text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_chat_messages_session ON public.chat_messages(session_id, created_at);

ALTER TABLE public.chat_messages ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Participants select chat messages"
  ON public.chat_messages FOR SELECT
  USING (session_id IN (
    SELECT id FROM public.chat_sessions
    WHERE user_id = auth.uid()
       OR astrologer_id IN (SELECT id FROM public.astrologers WHERE user_id = auth.uid())
  ));

CREATE POLICY "Participants insert chat messages"
  ON public.chat_messages FOR INSERT
  WITH CHECK (
    sender_id = auth.uid()
    AND session_id IN (
      SELECT id FROM public.chat_sessions
      WHERE (user_id = auth.uid()
         OR astrologer_id IN (SELECT id FROM public.astrologers WHERE user_id = auth.uid()))
        AND status = 'active'
    )
  );

-- Gifts
CREATE TABLE IF NOT EXISTS public.gifts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL,
  astrologer_id uuid NOT NULL REFERENCES public.astrologers(id) ON DELETE CASCADE,
  session_id uuid REFERENCES public.chat_sessions(id) ON DELETE SET NULL,
  gift_type text NOT NULL,
  amount numeric NOT NULL,
  message text,
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.gifts ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users select own gifts"
  ON public.gifts FOR SELECT
  USING (auth.uid() = user_id
    OR astrologer_id IN (SELECT id FROM public.astrologers WHERE user_id = auth.uid()));

CREATE POLICY "Users insert own gifts"
  ON public.gifts FOR INSERT
  WITH CHECK (auth.uid() = user_id);

-- Realtime
ALTER PUBLICATION supabase_realtime ADD TABLE public.chat_sessions;
ALTER PUBLICATION supabase_realtime ADD TABLE public.chat_messages;
ALTER TABLE public.chat_sessions REPLICA IDENTITY FULL;
ALTER TABLE public.chat_messages REPLICA IDENTITY FULL;
