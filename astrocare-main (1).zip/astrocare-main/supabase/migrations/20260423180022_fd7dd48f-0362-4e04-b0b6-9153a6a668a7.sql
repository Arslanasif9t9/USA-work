-- 1. New columns on chat_sessions
ALTER TABLE public.chat_sessions
  ADD COLUMN IF NOT EXISTS ended_by text,
  ADD COLUMN IF NOT EXISTS total_cost numeric NOT NULL DEFAULT 0;

-- 2. Per-minute billing RPC: charges 1 minute for every active chat whose
--    last_billed_at was >= 60s ago. If wallet (+ pack minutes) cannot cover
--    the next minute, mark the session ended_low_balance.
CREATE OR REPLACE FUNCTION public.bill_active_chats()
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  r record;
  spend_result jsonb;
  astro_name text;
BEGIN
  FOR r IN
    SELECT cs.id, cs.user_id, cs.astrologer_id, cs.per_minute_rate, cs.last_billed_at, cs.accepted_at
      FROM public.chat_sessions cs
     WHERE cs.status = 'active'
       AND cs.last_billed_at IS NOT NULL
       AND cs.last_billed_at <= now() - interval '60 seconds'
  LOOP
    SELECT display_name INTO astro_name FROM public.astrologers WHERE id = r.astrologer_id;

    BEGIN
      spend_result := public.spend_consultation_time(
        r.user_id, 1, r.per_minute_rate,
        'Chat with ' || COALESCE(astro_name, 'astrologer')
      );
      UPDATE public.chat_sessions
        SET last_billed_at = now(),
            duration_seconds = EXTRACT(EPOCH FROM (now() - r.accepted_at))::int,
            total_cost = total_cost + r.per_minute_rate
       WHERE id = r.id;
    EXCEPTION WHEN OTHERS THEN
      -- Insufficient balance or other error: end the session
      UPDATE public.chat_sessions
        SET status = 'ended',
            end_reason = 'low_balance',
            ended_by = 'system',
            ended_at = now(),
            duration_seconds = EXTRACT(EPOCH FROM (now() - r.accepted_at))::int
       WHERE id = r.id;
      PERFORM public.release_chat_hold(r.id);
      INSERT INTO public.chat_messages (session_id, sender_id, sender_role, content)
      VALUES (r.id, r.user_id, 'system', 'Chat ended: insufficient wallet balance.');
    END;
  END LOOP;
END;
$$;

-- 3. Auto-cancel pending chat requests older than 60s
CREATE OR REPLACE FUNCTION public.expire_pending_chats()
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  UPDATE public.chat_sessions
     SET status = 'cancelled',
         ended_at = now(),
         end_reason = 'request_timeout'
   WHERE status = 'pending'
     AND requested_at < now() - interval '65 seconds';
END;
$$;

-- 4. Schedule cron jobs (require pg_cron)
CREATE EXTENSION IF NOT EXISTS pg_cron;

DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM cron.job WHERE jobname = 'bill_active_chats_every_minute') THEN
    PERFORM cron.schedule('bill_active_chats_every_minute', '* * * * *', $cmd$SELECT public.bill_active_chats();$cmd$);
  END IF;
  IF NOT EXISTS (SELECT 1 FROM cron.job WHERE jobname = 'expire_pending_chats_every_minute') THEN
    PERFORM cron.schedule('expire_pending_chats_every_minute', '* * * * *', $cmd$SELECT public.expire_pending_chats();$cmd$);
  END IF;
END $$;