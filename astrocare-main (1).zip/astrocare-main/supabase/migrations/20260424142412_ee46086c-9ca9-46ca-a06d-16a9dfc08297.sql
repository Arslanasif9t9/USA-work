
-- ===========================================================
-- ADMIN CONTROL PANEL — schema additions
-- ===========================================================

-- 1) Astrologer rejection reason
ALTER TABLE public.astrologers
  ADD COLUMN IF NOT EXISTS rejection_reason text;

-- 2) Profiles: customer block + total spent helper
ALTER TABLE public.profiles
  ADD COLUMN IF NOT EXISTS is_blocked boolean NOT NULL DEFAULT false,
  ADD COLUMN IF NOT EXISTS blocked_reason text,
  ADD COLUMN IF NOT EXISTS blocked_at timestamptz;

-- 3) Reviews moderation
ALTER TABLE public.reviews
  ADD COLUMN IF NOT EXISTS moderation_status text NOT NULL DEFAULT 'pending',
  ADD COLUMN IF NOT EXISTS rejection_reason text,
  ADD COLUMN IF NOT EXISTS moderated_at timestamptz,
  ADD COLUMN IF NOT EXISTS moderated_by uuid;

-- Make existing reviews approved so nothing breaks
UPDATE public.reviews SET moderation_status = 'approved' WHERE moderation_status = 'pending';

-- Recompute astrologer rating to count only approved reviews
CREATE OR REPLACE FUNCTION public.recalc_astrologer_rating()
RETURNS trigger
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public
AS $$
DECLARE
  _astro_id uuid;
  _avg numeric;
  _cnt integer;
BEGIN
  _astro_id := COALESCE(NEW.astrologer_id, OLD.astrologer_id);
  SELECT COALESCE(AVG(rating), 0)::numeric(3,2), COUNT(*)::int
    INTO _avg, _cnt
    FROM public.reviews
    WHERE astrologer_id = _astro_id
      AND moderation_status = 'approved';
  UPDATE public.astrologers
     SET rating_avg = _avg,
         rating_count = _cnt,
         updated_at = now()
   WHERE id = _astro_id;
  RETURN NEW;
END;
$$;

-- 4) Support ticket replies (conversation thread)
CREATE TABLE IF NOT EXISTS public.support_ticket_replies (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  ticket_id uuid NOT NULL REFERENCES public.support_tickets(id) ON DELETE CASCADE,
  author_id uuid NOT NULL,
  author_role text NOT NULL CHECK (author_role IN ('user','admin')),
  message text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE public.support_ticket_replies ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "ticket owner reads replies" ON public.support_ticket_replies;
CREATE POLICY "ticket owner reads replies" ON public.support_ticket_replies
  FOR SELECT USING (
    ticket_id IN (SELECT id FROM public.support_tickets WHERE user_id = auth.uid())
    OR public.is_active_admin(auth.uid())
  );

DROP POLICY IF EXISTS "ticket owner writes replies" ON public.support_ticket_replies;
CREATE POLICY "ticket owner writes replies" ON public.support_ticket_replies
  FOR INSERT WITH CHECK (
    author_id = auth.uid() AND (
      (author_role = 'user'  AND ticket_id IN (SELECT id FROM public.support_tickets WHERE user_id = auth.uid()))
      OR (author_role = 'admin' AND public.admin_has_permission(auth.uid(), 'manage_support'))
    )
  );

-- 5) Allow ticket owner OR admin to update tickets (for status, assignment)
ALTER TABLE public.support_tickets
  ADD COLUMN IF NOT EXISTS assigned_to uuid,
  ADD COLUMN IF NOT EXISTS updated_at timestamptz NOT NULL DEFAULT now();

DROP POLICY IF EXISTS "admin reads tickets" ON public.support_tickets;
CREATE POLICY "admin reads tickets" ON public.support_tickets
  FOR SELECT USING (public.admin_has_permission(auth.uid(), 'manage_support'));

DROP POLICY IF EXISTS "admin updates tickets" ON public.support_tickets;
CREATE POLICY "admin updates tickets" ON public.support_tickets
  FOR UPDATE USING (public.admin_has_permission(auth.uid(), 'manage_support'));

-- 6) Withdrawal requests: admin RLS + transaction reference
ALTER TABLE public.withdrawal_requests
  ADD COLUMN IF NOT EXISTS transaction_reference text,
  ADD COLUMN IF NOT EXISTS processed_by uuid,
  ADD COLUMN IF NOT EXISTS processed_at timestamptz;

DROP POLICY IF EXISTS "admin reads withdrawals" ON public.withdrawal_requests;
CREATE POLICY "admin reads withdrawals" ON public.withdrawal_requests
  FOR SELECT USING (public.admin_has_permission(auth.uid(), 'manage_withdrawals'));

DROP POLICY IF EXISTS "admin updates withdrawals" ON public.withdrawal_requests;
CREATE POLICY "admin updates withdrawals" ON public.withdrawal_requests
  FOR UPDATE USING (public.admin_has_permission(auth.uid(), 'manage_withdrawals'));

-- 7) Admin read RLS for entities they manage
DROP POLICY IF EXISTS "admin reads profiles" ON public.profiles;
CREATE POLICY "admin reads profiles" ON public.profiles
  FOR SELECT USING (public.admin_has_permission(auth.uid(), 'manage_customers'));

DROP POLICY IF EXISTS "admin updates profiles" ON public.profiles;
CREATE POLICY "admin updates profiles" ON public.profiles
  FOR UPDATE USING (public.admin_has_permission(auth.uid(), 'manage_customers'));

DROP POLICY IF EXISTS "admin updates astrologers" ON public.astrologers;
CREATE POLICY "admin updates astrologers" ON public.astrologers
  FOR UPDATE USING (public.admin_has_permission(auth.uid(), 'manage_astrologers'));

DROP POLICY IF EXISTS "admin reads chat_sessions" ON public.chat_sessions;
CREATE POLICY "admin reads chat_sessions" ON public.chat_sessions
  FOR SELECT USING (public.admin_has_permission(auth.uid(), 'manage_sessions'));

DROP POLICY IF EXISTS "admin reads chat_messages" ON public.chat_messages;
CREATE POLICY "admin reads chat_messages" ON public.chat_messages
  FOR SELECT USING (public.admin_has_permission(auth.uid(), 'manage_sessions'));

DROP POLICY IF EXISTS "admin reads call_sessions" ON public.call_sessions;
CREATE POLICY "admin reads call_sessions" ON public.call_sessions
  FOR SELECT USING (public.admin_has_permission(auth.uid(), 'manage_sessions'));

DROP POLICY IF EXISTS "admin reads transactions" ON public.transactions;
CREATE POLICY "admin reads transactions" ON public.transactions
  FOR SELECT USING (
    public.admin_has_permission(auth.uid(), 'manage_wallet')
    OR public.admin_has_permission(auth.uid(), 'manage_sessions')
  );

DROP POLICY IF EXISTS "admin reads wallets" ON public.wallets;
CREATE POLICY "admin reads wallets" ON public.wallets
  FOR SELECT USING (
    public.admin_has_permission(auth.uid(), 'manage_wallet')
    OR public.admin_has_permission(auth.uid(), 'manage_customers')
    OR public.admin_has_permission(auth.uid(), 'manage_astrologers')
  );

DROP POLICY IF EXISTS "admin reads reviews" ON public.reviews;
CREATE POLICY "admin reads reviews" ON public.reviews
  FOR SELECT USING (public.admin_has_permission(auth.uid(), 'manage_reviews'));

DROP POLICY IF EXISTS "admin updates reviews" ON public.reviews;
CREATE POLICY "admin updates reviews" ON public.reviews
  FOR UPDATE USING (public.admin_has_permission(auth.uid(), 'manage_reviews'));

DROP POLICY IF EXISTS "admin deletes reviews" ON public.reviews;
CREATE POLICY "admin deletes reviews" ON public.reviews
  FOR DELETE USING (public.admin_has_permission(auth.uid(), 'manage_reviews'));

-- 8) Admin RPC: adjust wallet
CREATE OR REPLACE FUNCTION public.admin_adjust_wallet(
  _user_id uuid, _amount numeric, _reason text, _direction text
)
RETURNS jsonb
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public
AS $$
DECLARE
  _wallet_id uuid;
  _balance numeric;
  _new_balance numeric;
  _delta numeric;
BEGIN
  IF NOT public.admin_has_permission(auth.uid(), 'manage_wallet') THEN
    RAISE EXCEPTION 'Forbidden' USING ERRCODE = '42501';
  END IF;
  IF _amount <= 0 THEN RAISE EXCEPTION 'Amount must be positive'; END IF;
  IF _direction NOT IN ('credit','debit') THEN RAISE EXCEPTION 'Invalid direction'; END IF;

  SELECT id, balance INTO _wallet_id, _balance
    FROM public.wallets WHERE user_id = _user_id FOR UPDATE;
  IF _wallet_id IS NULL THEN
    INSERT INTO public.wallets (user_id, balance) VALUES (_user_id, 0)
      RETURNING id, balance INTO _wallet_id, _balance;
  END IF;

  IF _direction = 'credit' THEN
    _delta := _amount;
  ELSE
    IF _balance < _amount THEN RAISE EXCEPTION 'Insufficient balance'; END IF;
    _delta := -_amount;
  END IF;

  _new_balance := _balance + _delta;
  UPDATE public.wallets SET balance = _new_balance, updated_at = now() WHERE id = _wallet_id;

  INSERT INTO public.transactions (wallet_id, type, amount, description, balance_after)
  VALUES (
    _wallet_id,
    CASE WHEN _direction = 'credit' THEN 'top_up'::transaction_type ELSE 'consultation_debit'::transaction_type END,
    _amount,
    'Admin ' || _direction || ': ' || COALESCE(_reason, ''),
    _new_balance
  );

  INSERT INTO public.notifications (user_id, type, title, body, link)
  VALUES (
    _user_id,
    'wallet',
    CASE WHEN _direction = 'credit' THEN 'Wallet credited by admin' ELSE 'Wallet debited by admin' END,
    'Amount: ₹' || _amount::text || COALESCE(' — ' || _reason, ''),
    '/wallet'
  );

  RETURN jsonb_build_object('ok', true, 'new_balance', _new_balance);
END;
$$;

-- 9) Admin RPC: refund a session
CREATE OR REPLACE FUNCTION public.admin_refund_session(
  _session_id uuid, _session_kind text, _amount numeric, _reason text
)
RETURNS jsonb
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public
AS $$
DECLARE
  _user_id uuid;
  _wallet_id uuid;
  _balance numeric;
  _new_balance numeric;
BEGIN
  IF NOT public.admin_has_permission(auth.uid(), 'manage_sessions') THEN
    RAISE EXCEPTION 'Forbidden' USING ERRCODE = '42501';
  END IF;
  IF _amount <= 0 THEN RAISE EXCEPTION 'Amount must be positive'; END IF;

  IF _session_kind = 'chat' THEN
    SELECT user_id INTO _user_id FROM public.chat_sessions WHERE id = _session_id;
  ELSIF _session_kind = 'call' THEN
    SELECT user_id INTO _user_id FROM public.call_sessions WHERE id = _session_id;
  ELSE RAISE EXCEPTION 'Invalid session kind'; END IF;
  IF _user_id IS NULL THEN RAISE EXCEPTION 'Session not found'; END IF;

  SELECT id, balance INTO _wallet_id, _balance
    FROM public.wallets WHERE user_id = _user_id FOR UPDATE;
  IF _wallet_id IS NULL THEN
    INSERT INTO public.wallets (user_id, balance) VALUES (_user_id, 0)
      RETURNING id, balance INTO _wallet_id, _balance;
  END IF;

  _new_balance := _balance + _amount;
  UPDATE public.wallets SET balance = _new_balance, updated_at = now() WHERE id = _wallet_id;

  INSERT INTO public.transactions (wallet_id, type, amount, description, balance_after)
  VALUES (_wallet_id, 'refund'::transaction_type, _amount,
          'Refund (' || _session_kind || ' session): ' || COALESCE(_reason, ''), _new_balance);

  INSERT INTO public.notifications (user_id, type, title, body, link)
  VALUES (_user_id, 'wallet', 'Refund issued',
          '₹' || _amount::text || COALESCE(' — ' || _reason, ''), '/wallet');

  RETURN jsonb_build_object('ok', true, 'new_balance', _new_balance);
END;
$$;

-- 10) Admin RPC: process withdrawal
CREATE OR REPLACE FUNCTION public.admin_process_withdrawal(
  _request_id uuid, _action text, _reference text, _reason text
)
RETURNS jsonb
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public
AS $$
DECLARE
  r record;
  _wallet_id uuid;
  _balance numeric;
  _new_balance numeric;
BEGIN
  IF NOT public.admin_has_permission(auth.uid(), 'manage_withdrawals') THEN
    RAISE EXCEPTION 'Forbidden' USING ERRCODE = '42501';
  END IF;

  SELECT * INTO r FROM public.withdrawal_requests WHERE id = _request_id FOR UPDATE;
  IF r IS NULL THEN RAISE EXCEPTION 'Not found'; END IF;

  IF _action = 'processing' THEN
    UPDATE public.withdrawal_requests
       SET status = 'processing', updated_at = now()
     WHERE id = _request_id;

  ELSIF _action = 'completed' THEN
    UPDATE public.withdrawal_requests
       SET status = 'completed',
           updated_at = now(),
           transaction_reference = _reference,
           processed_at = now(),
           processed_by = auth.uid()
     WHERE id = _request_id;
    INSERT INTO public.notifications (user_id, type, title, body, link)
    VALUES (r.astrologer_user_id, 'withdrawal',
            'Withdrawal completed',
            '₹' || r.amount::text || ' transferred. Ref: ' || COALESCE(_reference, '—'),
            '/astrologer/earnings');

  ELSIF _action = 'rejected' THEN
    -- Refund amount back to astrologer wallet
    SELECT id, balance INTO _wallet_id, _balance FROM public.wallets WHERE user_id = r.astrologer_user_id FOR UPDATE;
    IF _wallet_id IS NULL THEN
      INSERT INTO public.wallets (user_id, balance) VALUES (r.astrologer_user_id, 0)
        RETURNING id, balance INTO _wallet_id, _balance;
    END IF;
    _new_balance := _balance + r.amount;
    UPDATE public.wallets SET balance = _new_balance, updated_at = now() WHERE id = _wallet_id;
    INSERT INTO public.transactions (wallet_id, type, amount, description, balance_after)
    VALUES (_wallet_id, 'refund'::transaction_type, r.amount,
            'Withdrawal rejected: ' || COALESCE(_reason, ''), _new_balance);

    UPDATE public.withdrawal_requests
       SET status = 'rejected',
           updated_at = now(),
           notes = _reason,
           processed_at = now(),
           processed_by = auth.uid()
     WHERE id = _request_id;

    INSERT INTO public.notifications (user_id, type, title, body, link)
    VALUES (r.astrologer_user_id, 'withdrawal',
            'Withdrawal rejected',
            COALESCE(_reason, 'Your withdrawal was rejected. Amount refunded.'),
            '/astrologer/earnings');
  ELSE
    RAISE EXCEPTION 'Invalid action';
  END IF;

  RETURN jsonb_build_object('ok', true);
END;
$$;
