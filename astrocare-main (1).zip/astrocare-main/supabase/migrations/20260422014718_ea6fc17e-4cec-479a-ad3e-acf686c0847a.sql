-- Idempotent self-heal RPC: ensures profile + wallet exist for the calling user.
-- Called by the dashboard on mount as a defense-in-depth fallback in case the
-- handle_new_user trigger ever fails to fire (e.g. provider edge cases).
CREATE OR REPLACE FUNCTION public.ensure_user_setup()
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  _uid uuid := auth.uid();
  _email text;
  _name text;
BEGIN
  IF _uid IS NULL THEN
    RAISE EXCEPTION 'Not authenticated' USING ERRCODE = '28000';
  END IF;

  SELECT u.email, COALESCE(u.raw_user_meta_data->>'name', '')
    INTO _email, _name
    FROM auth.users u WHERE u.id = _uid;

  INSERT INTO public.profiles (id, name, email, consultation_minutes)
  VALUES (_uid, COALESCE(_name, ''), _email, 0)
  ON CONFLICT (id) DO NOTHING;

  INSERT INTO public.wallets (user_id, balance)
  VALUES (_uid, 0)
  ON CONFLICT DO NOTHING;
END;
$$;

GRANT EXECUTE ON FUNCTION public.ensure_user_setup() TO authenticated;

-- Make sure wallets cannot have two rows for the same user (defense-in-depth
-- so the ON CONFLICT clause above is meaningful).
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint
    WHERE conname = 'wallets_user_id_key' AND conrelid = 'public.wallets'::regclass
  ) THEN
    ALTER TABLE public.wallets ADD CONSTRAINT wallets_user_id_key UNIQUE (user_id);
  END IF;
END $$;