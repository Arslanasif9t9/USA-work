ALTER TABLE public.call_sessions ADD COLUMN IF NOT EXISTS total_cost numeric NOT NULL DEFAULT 0;
ALTER TABLE public.call_sessions ADD COLUMN IF NOT EXISTS ended_by text;

DO $$ BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies
    WHERE schemaname = 'public' AND tablename = 'call_sessions'
      AND policyname = 'Participants update call sessions'
  ) THEN
    CREATE POLICY "Participants update call sessions"
      ON public.call_sessions FOR UPDATE
      USING (
        (auth.uid() = user_id)
        OR (astrologer_id IN (SELECT astrologers.id FROM astrologers WHERE astrologers.user_id = auth.uid()))
      );
  END IF;
END $$;

DO $$ BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies
    WHERE schemaname = 'public' AND tablename = 'call_sessions'
      AND policyname = 'Users insert own call sessions'
  ) THEN
    CREATE POLICY "Users insert own call sessions"
      ON public.call_sessions FOR INSERT
      WITH CHECK (auth.uid() = user_id);
  END IF;
END $$;

CREATE OR REPLACE FUNCTION public.end_call_session(_session_id uuid, _ended_by text, _end_reason text)
RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path TO 'public'
AS $function$
DECLARE
  s record; astro record;
  _seconds int; _minutes int;
  _total_cost numeric; _astro_share numeric; _company_share numeric;
  _astro_wallet_id uuid; _astro_balance numeric; _new_balance numeric;
  _share_pct numeric;
BEGIN
  SELECT * INTO s FROM public.call_sessions WHERE id = _session_id FOR UPDATE;
  IF s IS NULL THEN RETURN jsonb_build_object('ok', false, 'error', 'not_found'); END IF;

  IF s.status IN ('cancelled', 'declined', 'no_answer', 'failed') THEN
    PERFORM public.release_call_hold(_session_id);
    RETURN jsonb_build_object('ok', true, 'already_ended', true);
  END IF;

  IF s.connected_at IS NULL THEN
    UPDATE public.call_sessions
       SET status = 'cancelled',
           ended_at = COALESCE(s.ended_at, now()),
           ended_by = COALESCE(s.ended_by, _ended_by),
           end_reason = COALESCE(s.end_reason, _end_reason, 'ended_before_connect')
     WHERE id = _session_id;
    PERFORM public.release_call_hold(_session_id);
    RETURN jsonb_build_object('ok', true, 'cancelled', true);
  END IF;

  IF s.status IN ('completed', 'ended') AND s.astrologer_earning > 0 THEN
    RETURN jsonb_build_object('ok', true, 'already_settled', true,
                              'total_cost', s.total_cost,
                              'astrologer_earning', s.astrologer_earning);
  END IF;

  _seconds := COALESCE(NULLIF(s.duration_seconds, 0),
                       EXTRACT(EPOCH FROM (COALESCE(s.ended_at, now()) - s.connected_at))::int);
  IF _seconds < 0 THEN _seconds := 0; END IF;
  _minutes := GREATEST(1, CEIL(_seconds::numeric / 60.0))::int;
  _total_cost := _minutes * s.per_minute_rate;

  SELECT astrologer_share_percent INTO _share_pct FROM public.platform_settings WHERE id = 1;
  _share_pct := COALESCE(_share_pct, 30);

  _astro_share   := ROUND(_total_cost * _share_pct / 100.0, 2);
  _company_share := ROUND(_total_cost - _astro_share, 2);

  SELECT id, user_id, display_name INTO astro FROM public.astrologers WHERE id = s.astrologer_id;
  PERFORM public.release_call_hold(_session_id);

  BEGIN
    PERFORM public.spend_consultation_time(
      s.user_id, _minutes, s.per_minute_rate,
      'Call with ' || COALESCE(astro.display_name, 'astrologer')
    );
  EXCEPTION WHEN OTHERS THEN NULL;
  END;

  IF astro.user_id IS NOT NULL AND _astro_share > 0 THEN
    SELECT id, balance INTO _astro_wallet_id, _astro_balance
      FROM public.wallets WHERE user_id = astro.user_id FOR UPDATE;
    IF _astro_wallet_id IS NULL THEN
      INSERT INTO public.wallets (user_id, balance) VALUES (astro.user_id, 0)
        RETURNING id, balance INTO _astro_wallet_id, _astro_balance;
    END IF;
    _new_balance := _astro_balance + _astro_share;
    UPDATE public.wallets SET balance = _new_balance, updated_at = now() WHERE id = _astro_wallet_id;
    INSERT INTO public.transactions (wallet_id, type, amount, description, balance_after, call_session_id)
    VALUES (_astro_wallet_id, 'consultation_credit', _astro_share,
            'Earnings (' || _share_pct::int || '%) — call session', _new_balance, _session_id);
  END IF;

  UPDATE public.call_sessions
     SET status = 'completed',
         ended_at = COALESCE(s.ended_at, now()),
         ended_by = COALESCE(s.ended_by, _ended_by),
         end_reason = COALESCE(s.end_reason, _end_reason, 'user_ended'),
         duration_seconds = _seconds,
         total_cost = _total_cost,
         astrologer_earning = _astro_share,
         company_earning = _company_share
   WHERE id = _session_id;

  RETURN jsonb_build_object('ok', true, 'duration_seconds', _seconds,
    'total_cost', _total_cost, 'astrologer_earning', _astro_share, 'company_earning', _company_share);
END;
$function$;

CREATE OR REPLACE FUNCTION public.accept_call_session(_session_id uuid)
RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path TO 'public'
AS $function$
DECLARE s record; caller uuid := auth.uid(); astro_user uuid;
BEGIN
  SELECT * INTO s FROM public.call_sessions WHERE id = _session_id FOR UPDATE;
  IF s IS NULL THEN RAISE EXCEPTION 'Call session not found'; END IF;
  SELECT user_id INTO astro_user FROM public.astrologers WHERE id = s.astrologer_id;
  IF astro_user IS NULL OR astro_user <> caller THEN RAISE EXCEPTION 'Forbidden' USING ERRCODE = '42501'; END IF;
  IF s.status NOT IN ('pending', 'ringing_astrologer') THEN
    RETURN jsonb_build_object('ok', false, 'error', 'invalid_state', 'status', s.status);
  END IF;
  UPDATE public.call_sessions
     SET status = 'connected', connected_at = COALESCE(s.connected_at, now())
   WHERE id = _session_id;
  RETURN jsonb_build_object('ok', true);
END;
$function$;

CREATE OR REPLACE FUNCTION public.decline_call_session(_session_id uuid)
RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path TO 'public'
AS $function$
DECLARE s record; caller uuid := auth.uid(); astro_user uuid;
BEGIN
  SELECT * INTO s FROM public.call_sessions WHERE id = _session_id FOR UPDATE;
  IF s IS NULL THEN RAISE EXCEPTION 'Call session not found'; END IF;
  SELECT user_id INTO astro_user FROM public.astrologers WHERE id = s.astrologer_id;
  IF astro_user IS NULL OR astro_user <> caller THEN RAISE EXCEPTION 'Forbidden' USING ERRCODE = '42501'; END IF;
  IF s.status NOT IN ('pending', 'ringing_astrologer') THEN
    RETURN jsonb_build_object('ok', false, 'error', 'invalid_state');
  END IF;
  UPDATE public.call_sessions
     SET status = 'declined', ended_at = now(), end_reason = 'declined_by_astrologer'
   WHERE id = _session_id;
  PERFORM public.release_call_hold(_session_id);
  RETURN jsonb_build_object('ok', true);
END;
$function$;