
-- ============================================================
-- 1. FIX end_chat_session: always run the split, even when the
--    row is already in 'ended' state (the optimistic client
--    update was previously short-circuiting the entire flow).
-- ============================================================
CREATE OR REPLACE FUNCTION public.end_chat_session(_session_id uuid, _ended_by text, _end_reason text)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
DECLARE
  s record;
  astro record;
  _seconds int;
  _minutes int;
  _total_cost numeric;
  _astro_share numeric;
  _company_share numeric;
  _astro_wallet_id uuid;
  _astro_balance numeric;
  _new_balance numeric;
BEGIN
  SELECT * INTO s FROM public.chat_sessions WHERE id = _session_id FOR UPDATE;
  IF s IS NULL THEN
    RETURN jsonb_build_object('ok', false, 'error', 'not_found');
  END IF;

  -- If cancelled/rejected before active, nothing to bill
  IF s.status IN ('cancelled', 'rejected') THEN
    RETURN jsonb_build_object('ok', true, 'already_ended', true);
  END IF;

  -- If never accepted, mark cancelled & release hold
  IF s.accepted_at IS NULL THEN
    UPDATE public.chat_sessions
       SET status = 'cancelled',
           ended_at = COALESCE(s.ended_at, now()),
           ended_by = COALESCE(s.ended_by, _ended_by),
           end_reason = COALESCE(s.end_reason, _end_reason, 'ended_before_active')
     WHERE id = _session_id;
    PERFORM public.release_chat_hold(_session_id);
    RETURN jsonb_build_object('ok', true, 'cancelled', true);
  END IF;

  -- If already ended AND earnings already credited, skip
  IF s.status = 'ended' AND s.astrologer_earning > 0 THEN
    RETURN jsonb_build_object('ok', true, 'already_settled', true,
                              'total_cost', s.total_cost,
                              'astrologer_earning', s.astrologer_earning);
  END IF;

  -- Compute final billing
  _seconds := COALESCE(NULLIF(s.duration_seconds, 0), EXTRACT(EPOCH FROM (COALESCE(s.ended_at, now()) - s.accepted_at))::int);
  IF _seconds < 0 THEN _seconds := 0; END IF;
  _minutes := GREATEST(1, CEIL(_seconds::numeric / 60.0))::int;
  _total_cost := COALESCE(NULLIF(s.total_cost, 0), _minutes * s.per_minute_rate);

  _astro_share   := ROUND(_total_cost * 0.30, 2);
  _company_share := ROUND(_total_cost * 0.70, 2);

  SELECT id, user_id, display_name INTO astro
    FROM public.astrologers WHERE id = s.astrologer_id;

  -- Release hold (idempotent)
  PERFORM public.release_chat_hold(_session_id);

  -- Charge customer ONCE (skip if already charged via prior call)
  IF NOT EXISTS (
    SELECT 1 FROM public.transactions t
    JOIN public.wallets w ON w.id = t.wallet_id
    WHERE w.user_id = s.user_id
      AND t.type = 'consultation_debit'
      AND t.description LIKE 'Chat with %'
      AND t.created_at >= COALESCE(s.accepted_at, s.created_at)
      AND t.created_at <= COALESCE(s.ended_at, now()) + interval '5 minutes'
  ) THEN
    BEGIN
      PERFORM public.spend_consultation_time(
        s.user_id, _minutes, s.per_minute_rate,
        'Chat with ' || COALESCE(astro.display_name, 'astrologer')
      );
    EXCEPTION WHEN OTHERS THEN NULL;
    END;
  END IF;

  -- Credit astrologer's 30% share
  IF astro.user_id IS NOT NULL AND _astro_share > 0 THEN
    SELECT id, balance INTO _astro_wallet_id, _astro_balance
      FROM public.wallets WHERE user_id = astro.user_id FOR UPDATE;
    IF _astro_wallet_id IS NULL THEN
      INSERT INTO public.wallets (user_id, balance) VALUES (astro.user_id, 0)
        RETURNING id, balance INTO _astro_wallet_id, _astro_balance;
    END IF;
    _new_balance := _astro_balance + _astro_share;
    UPDATE public.wallets
       SET balance = _new_balance, updated_at = now()
     WHERE id = _astro_wallet_id;
    INSERT INTO public.transactions (wallet_id, type, amount, description, balance_after)
    VALUES (_astro_wallet_id, 'consultation_credit', _astro_share,
            'Earnings (30%) — chat session', _new_balance);
  END IF;

  -- Mark final state
  UPDATE public.chat_sessions
     SET status = 'ended',
         ended_at = COALESCE(s.ended_at, now()),
         ended_by = COALESCE(s.ended_by, _ended_by),
         end_reason = COALESCE(s.end_reason, _end_reason, 'user_ended'),
         duration_seconds = _seconds,
         total_cost = _total_cost,
         astrologer_earning = _astro_share,
         company_earning = _company_share
   WHERE id = _session_id;

  RETURN jsonb_build_object(
    'ok', true,
    'duration_seconds', _seconds,
    'total_cost', _total_cost,
    'astrologer_earning', _astro_share,
    'company_earning', _company_share
  );
END;
$function$;

-- ============================================================
-- 2. BACKFILL past ended sessions that are missing earnings
-- ============================================================
DO $$
DECLARE
  r record;
  _astro_share numeric;
  _company_share numeric;
  _wid uuid;
  _bal numeric;
  _new_bal numeric;
  _astro_user uuid;
BEGIN
  FOR r IN
    SELECT cs.id, cs.astrologer_id, cs.total_cost, cs.duration_seconds, cs.per_minute_rate
      FROM public.chat_sessions cs
     WHERE cs.status = 'ended'
       AND cs.astrologer_earning = 0
       AND cs.total_cost > 0
  LOOP
    _astro_share   := ROUND(r.total_cost * 0.30, 2);
    _company_share := ROUND(r.total_cost * 0.70, 2);

    SELECT user_id INTO _astro_user FROM public.astrologers WHERE id = r.astrologer_id;

    IF _astro_user IS NOT NULL THEN
      SELECT id, balance INTO _wid, _bal FROM public.wallets WHERE user_id = _astro_user FOR UPDATE;
      IF _wid IS NULL THEN
        INSERT INTO public.wallets (user_id, balance) VALUES (_astro_user, 0)
          RETURNING id, balance INTO _wid, _bal;
      END IF;
      _new_bal := _bal + _astro_share;
      UPDATE public.wallets SET balance = _new_bal, updated_at = now() WHERE id = _wid;
      INSERT INTO public.transactions (wallet_id, type, amount, description, balance_after)
      VALUES (_wid, 'consultation_credit', _astro_share,
              'Earnings (30%) — chat session [backfilled]', _new_bal);
    END IF;

    UPDATE public.chat_sessions
       SET astrologer_earning = _astro_share,
           company_earning = _company_share
     WHERE id = r.id;
  END LOOP;
END $$;

-- ============================================================
-- 3. NEW tables for dashboard features
-- ============================================================

-- Withdrawal requests
CREATE TABLE IF NOT EXISTS public.withdrawal_requests (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  astrologer_user_id uuid NOT NULL,
  amount numeric NOT NULL CHECK (amount > 0),
  method text NOT NULL DEFAULT 'upi' CHECK (method IN ('upi','bank')),
  upi_id text,
  bank_name text,
  bank_account text,
  bank_ifsc text,
  status text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','approved','rejected','paid')),
  notes text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE public.withdrawal_requests ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Astrologers view own withdrawals"
  ON public.withdrawal_requests FOR SELECT
  USING (auth.uid() = astrologer_user_id);
CREATE POLICY "Astrologers create own withdrawals"
  ON public.withdrawal_requests FOR INSERT
  WITH CHECK (auth.uid() = astrologer_user_id);

-- Notifications
CREATE TABLE IF NOT EXISTS public.notifications (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL,
  type text NOT NULL,
  title text NOT NULL,
  body text,
  link text,
  read boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_notifications_user_unread
  ON public.notifications(user_id, read, created_at DESC);
ALTER TABLE public.notifications ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Users view own notifications"
  ON public.notifications FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "Users update own notifications"
  ON public.notifications FOR UPDATE USING (auth.uid() = user_id);

-- Horoscope cache
CREATE TABLE IF NOT EXISTS public.horoscope_cache (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  sign text NOT NULL,
  date date NOT NULL,
  content text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (sign, date)
);
ALTER TABLE public.horoscope_cache ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Anyone authenticated can read horoscopes"
  ON public.horoscope_cache FOR SELECT TO authenticated USING (true);

-- Review replies
CREATE TABLE IF NOT EXISTS public.review_replies (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  review_id uuid NOT NULL UNIQUE,
  astrologer_user_id uuid NOT NULL,
  reply text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE public.review_replies ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Anyone can read review replies"
  ON public.review_replies FOR SELECT USING (true);
CREATE POLICY "Astrologer creates own reply"
  ON public.review_replies FOR INSERT
  WITH CHECK (auth.uid() = astrologer_user_id);
CREATE POLICY "Astrologer updates own reply"
  ON public.review_replies FOR UPDATE USING (auth.uid() = astrologer_user_id);

-- Payout / notification settings
CREATE TABLE IF NOT EXISTS public.astrologer_payout_settings (
  user_id uuid PRIMARY KEY,
  upi_id text,
  bank_name text,
  bank_account text,
  bank_ifsc text,
  notify_new_request boolean NOT NULL DEFAULT true,
  notify_session_reminder boolean NOT NULL DEFAULT true,
  notify_review boolean NOT NULL DEFAULT true,
  notify_earnings boolean NOT NULL DEFAULT true,
  updated_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE public.astrologer_payout_settings ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Astrologer view own payout"
  ON public.astrologer_payout_settings FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "Astrologer upsert own payout"
  ON public.astrologer_payout_settings FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Astrologer update own payout"
  ON public.astrologer_payout_settings FOR UPDATE USING (auth.uid() = user_id);

-- Support tickets
CREATE TABLE IF NOT EXISTS public.support_tickets (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL,
  subject text NOT NULL,
  message text NOT NULL,
  status text NOT NULL DEFAULT 'open' CHECK (status IN ('open','in_progress','resolved','closed')),
  created_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE public.support_tickets ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Users view own tickets"
  ON public.support_tickets FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "Users create own tickets"
  ON public.support_tickets FOR INSERT WITH CHECK (auth.uid() = user_id);

-- Allow astrologers to manage their availability
CREATE POLICY "Astrologers manage own availability ins"
  ON public.astrologer_availability FOR INSERT
  WITH CHECK (astrologer_id IN (SELECT id FROM public.astrologers WHERE user_id = auth.uid()));
CREATE POLICY "Astrologers manage own availability del"
  ON public.astrologer_availability FOR DELETE
  USING (astrologer_id IN (SELECT id FROM public.astrologers WHERE user_id = auth.uid()));
CREATE POLICY "Astrologers manage own availability upd"
  ON public.astrologer_availability FOR UPDATE
  USING (astrologer_id IN (SELECT id FROM public.astrologers WHERE user_id = auth.uid()));

-- Chart deletion (was missing — needed for kundli history "delete")
-- (no-op if already exists)
