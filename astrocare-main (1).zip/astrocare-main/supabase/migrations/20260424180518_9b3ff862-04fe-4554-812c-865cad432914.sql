-- Add columns to gifts table
ALTER TABLE public.gifts
  ADD COLUMN IF NOT EXISTS customer_note text,
  ADD COLUMN IF NOT EXISTS astrologer_earning numeric NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS company_earning numeric NOT NULL DEFAULT 0;

-- Realtime: full row payloads
ALTER TABLE public.support_tickets REPLICA IDENTITY FULL;
ALTER TABLE public.support_ticket_replies REPLICA IDENTITY FULL;
ALTER TABLE public.gifts REPLICA IDENTITY FULL;

-- Add to realtime publication (idempotent)
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_publication_tables WHERE pubname = 'supabase_realtime' AND tablename = 'support_tickets'
  ) THEN
    ALTER PUBLICATION supabase_realtime ADD TABLE public.support_tickets;
  END IF;
  IF NOT EXISTS (
    SELECT 1 FROM pg_publication_tables WHERE pubname = 'supabase_realtime' AND tablename = 'support_ticket_replies'
  ) THEN
    ALTER PUBLICATION supabase_realtime ADD TABLE public.support_ticket_replies;
  END IF;
  IF NOT EXISTS (
    SELECT 1 FROM pg_publication_tables WHERE pubname = 'supabase_realtime' AND tablename = 'gifts'
  ) THEN
    ALTER PUBLICATION supabase_realtime ADD TABLE public.gifts;
  END IF;
END $$;