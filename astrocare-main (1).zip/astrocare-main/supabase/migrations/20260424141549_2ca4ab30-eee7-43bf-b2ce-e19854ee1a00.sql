
-- =========================================================
-- ADMIN PANEL FOUNDATION
-- =========================================================

-- 1. Approval status on astrologers
DO $$ BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_schema='public' AND table_name='astrologers' AND column_name='approval_status'
  ) THEN
    ALTER TABLE public.astrologers
      ADD COLUMN approval_status text NOT NULL DEFAULT 'approved';
  END IF;
END $$;

-- Mark all existing astrologers as approved (safety)
UPDATE public.astrologers SET approval_status = 'approved'
 WHERE approval_status IS NULL OR approval_status NOT IN ('pending','approved','rejected','blocked');

CREATE INDEX IF NOT EXISTS idx_astrologers_approval_status ON public.astrologers(approval_status);

-- 2. admin_users table
CREATE TABLE IF NOT EXISTS public.admin_users (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid UNIQUE NOT NULL,            -- references auth.users.id
  email text UNIQUE NOT NULL,
  full_name text NOT NULL DEFAULT '',
  role text NOT NULL CHECK (role IN ('master_admin','admin','finance_admin')),
  permissions jsonb NOT NULL DEFAULT '[]'::jsonb,
  is_active boolean NOT NULL DEFAULT true,
  created_by uuid REFERENCES public.admin_users(id) ON DELETE SET NULL,
  last_login_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_admin_users_user_id ON public.admin_users(user_id);
CREATE INDEX IF NOT EXISTS idx_admin_users_email ON public.admin_users(email);

ALTER TABLE public.admin_users ENABLE ROW LEVEL SECURITY;

-- 3. admin_activity_log
CREATE TABLE IF NOT EXISTS public.admin_activity_log (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  admin_id uuid REFERENCES public.admin_users(id) ON DELETE SET NULL,
  action text NOT NULL,
  target_type text,
  target_id text,
  details jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_admin_activity_admin ON public.admin_activity_log(admin_id);
CREATE INDEX IF NOT EXISTS idx_admin_activity_created ON public.admin_activity_log(created_at DESC);

ALTER TABLE public.admin_activity_log ENABLE ROW LEVEL SECURITY;

-- 4. Helpers (security definer to bypass RLS recursion)
CREATE OR REPLACE FUNCTION public.is_active_admin(_user_id uuid)
RETURNS boolean
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.admin_users
     WHERE user_id = _user_id AND is_active = true
  );
$$;

CREATE OR REPLACE FUNCTION public.is_master_admin(_user_id uuid)
RETURNS boolean
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.admin_users
     WHERE user_id = _user_id AND is_active = true AND role = 'master_admin'
  );
$$;

CREATE OR REPLACE FUNCTION public.admin_has_permission(_user_id uuid, _permission text)
RETURNS boolean
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.admin_users
     WHERE user_id = _user_id
       AND is_active = true
       AND (role = 'master_admin' OR permissions ? _permission)
  );
$$;

-- 5. RLS policies on admin tables
DROP POLICY IF EXISTS "admins read admin_users" ON public.admin_users;
CREATE POLICY "admins read admin_users" ON public.admin_users
  FOR SELECT USING (public.is_active_admin(auth.uid()));

DROP POLICY IF EXISTS "master inserts admin_users" ON public.admin_users;
CREATE POLICY "master inserts admin_users" ON public.admin_users
  FOR INSERT WITH CHECK (public.is_master_admin(auth.uid()));

DROP POLICY IF EXISTS "master updates admin_users" ON public.admin_users;
CREATE POLICY "master updates admin_users" ON public.admin_users
  FOR UPDATE USING (public.is_master_admin(auth.uid()));

DROP POLICY IF EXISTS "admins read activity_log" ON public.admin_activity_log;
CREATE POLICY "admins read activity_log" ON public.admin_activity_log
  FOR SELECT USING (public.is_active_admin(auth.uid()));

DROP POLICY IF EXISTS "admins insert activity_log" ON public.admin_activity_log;
CREATE POLICY "admins insert activity_log" ON public.admin_activity_log
  FOR INSERT WITH CHECK (public.is_active_admin(auth.uid()));

-- 6. Activity log helper
CREATE OR REPLACE FUNCTION public.log_admin_action(
  _action text, _target_type text, _target_id text, _details jsonb
) RETURNS void
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public
AS $$
DECLARE _admin uuid;
BEGIN
  SELECT id INTO _admin FROM public.admin_users WHERE user_id = auth.uid() AND is_active = true;
  IF _admin IS NULL THEN RETURN; END IF;
  INSERT INTO public.admin_activity_log (admin_id, action, target_type, target_id, details)
  VALUES (_admin, _action, _target_type, _target_id, COALESCE(_details, '{}'::jsonb));
END;
$$;
