-- Default first_chat_free to true for all new astrologers
ALTER TABLE public.astrologers ALTER COLUMN first_chat_free SET DEFAULT true;

-- Backfill existing astrologers
UPDATE public.astrologers SET first_chat_free = true WHERE first_chat_free = false;