-- Vimshottari Dasha table
CREATE TABLE public.vimshottari_dasha (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  birth_chart_id uuid NOT NULL UNIQUE REFERENCES public.birth_charts(id) ON DELETE CASCADE,
  user_id uuid NOT NULL,
  dasha_tree jsonb NOT NULL DEFAULT '{}'::jsonb,
  current_maha_lord text,
  current_maha_start timestamptz,
  current_maha_end timestamptz,
  current_antar_lord text,
  current_antar_start timestamptz,
  current_antar_end timestamptz,
  computed_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX idx_vimshottari_dasha_user_id ON public.vimshottari_dasha(user_id);

ALTER TABLE public.vimshottari_dasha ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users select own dasha"
  ON public.vimshottari_dasha
  FOR SELECT
  USING (auth.uid() = user_id);

CREATE POLICY "Users insert own dasha"
  ON public.vimshottari_dasha
  FOR INSERT
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users update own dasha"
  ON public.vimshottari_dasha
  FOR UPDATE
  USING (auth.uid() = user_id);
