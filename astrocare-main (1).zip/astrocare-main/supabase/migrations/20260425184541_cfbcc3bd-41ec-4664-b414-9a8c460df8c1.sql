-- ============================================================================
-- TASK 4 + 5: Private Live Calls + In-App Notifications
-- ============================================================================

-- ---- 1. live_streams: pause flag + analytics ------------------------------
ALTER TABLE public.live_streams
  ADD COLUMN IF NOT EXISTS is_paused_for_private boolean NOT NULL DEFAULT false,
  ADD COLUMN IF NOT EXISTS paused_at timestamptz,
  ADD COLUMN IF NOT EXISTS private_session_count int NOT NULL DEFAULT 0;

-- ---- 2. live_call_requests: link to call session --------------------------
ALTER TABLE public.live_call_requests
  ADD COLUMN IF NOT EXISTS linked_call_session_id uuid REFERENCES public.call_sessions(id) ON DELETE SET NULL;

-- ---- 3. notification preferences (per astrologer / global) ----------------
CREATE TABLE IF NOT EXISTS public.user_notification_preferences (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  target_id uuid,                       -- astrologer id, or null for 'global'
  target_type text NOT NULL DEFAULT 'astrologer', -- 'astrologer' | 'global'
  notify_on_live boolean NOT NULL DEFAULT true,
  notify_on_message boolean NOT NULL DEFAULT true,
  notify_on_gift boolean NOT NULL DEFAULT true,
  notify_on_announcement boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (user_id, target_id, target_type)
);

ALTER TABLE public.user_notification_preferences ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "users manage own notif prefs" ON public.user_notification_preferences;
CREATE POLICY "users manage own notif prefs"
  ON public.user_notification_preferences
  FOR ALL TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE INDEX IF NOT EXISTS idx_unp_user ON public.user_notification_preferences(user_id);
CREATE INDEX IF NOT EXISTS idx_unp_target ON public.user_notification_preferences(target_id, target_type) WHERE notify_on_live = true;

-- ---- 4. push_subscriptions (stub for Task 5 push delivery later) ----------
CREATE TABLE IF NOT EXISTS public.push_subscriptions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  endpoint text NOT NULL,
  p256dh_key text NOT NULL,
  auth_key text NOT NULL,
  user_agent text,
  created_at timestamptz NOT NULL DEFAULT now(),
  last_used_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (user_id, endpoint)
);

ALTER TABLE public.push_subscriptions ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "users manage own push subs" ON public.push_subscriptions;
CREATE POLICY "users manage own push subs"
  ON public.push_subscriptions FOR ALL TO authenticated
  USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

-- ---- 5. notifications already exists; ensure helpful index + realtime -----
CREATE INDEX IF NOT EXISTS idx_notifications_user_unread
  ON public.notifications(user_id, read, created_at DESC);

ALTER TABLE public.notifications REPLICA IDENTITY FULL;
DO $$ BEGIN
  ALTER PUBLICATION supabase_realtime ADD TABLE public.notifications;
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

ALTER TABLE public.live_streams REPLICA IDENTITY FULL;
DO $$ BEGIN
  ALTER PUBLICATION supabase_realtime ADD TABLE public.live_streams;
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

-- ============================================================================
-- 6. UPDATE request_live_call: enforce 5-min min for 'private'
-- ============================================================================
CREATE OR REPLACE FUNCTION public.request_live_call(
  _live_stream_id uuid,
  _request_type text
) RETURNS jsonb
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public
AS $$
DECLARE
  _customer uuid := auth.uid();
  _stream record;
  _astro record;
  _rate numeric;
  _min_minutes int;
  _hold numeric;
  _wallet_balance numeric;
  _existing uuid;
  _new_id uuid;
BEGIN
  IF _customer IS NULL THEN
    RETURN jsonb_build_object('ok', false, 'error', 'Not authenticated');
  END IF;
  IF _request_type NOT IN ('public','private') THEN
    RETURN jsonb_build_object('ok', false, 'error', 'Invalid request type');
  END IF;

  SELECT * INTO _stream FROM live_streams WHERE id = _live_stream_id;
  IF NOT FOUND OR _stream.status <> 'live' THEN
    RETURN jsonb_build_object('ok', false, 'error', 'Live stream not active');
  END IF;
  IF _stream.is_paused_for_private THEN
    RETURN jsonb_build_object('ok', false, 'error', 'Astrologer is in a private session, please wait');
  END IF;

  SELECT id, user_id, base_rate_per_min, discounted_rate_per_min, accepting_calls
    INTO _astro FROM astrologers WHERE id = _stream.astrologer_id;
  IF NOT FOUND OR COALESCE(_astro.accepting_calls, true) = false THEN
    RETURN jsonb_build_object('ok', false, 'error', 'Astrologer not accepting calls');
  END IF;

  _rate := COALESCE(_astro.discounted_rate_per_min, _astro.base_rate_per_min);
  _min_minutes := CASE WHEN _request_type = 'private' THEN 5 ELSE 2 END;
  _hold := _rate * _min_minutes;

  -- One active request per customer per stream
  SELECT id INTO _existing FROM live_call_requests
   WHERE customer_id = _customer
     AND live_stream_id = _live_stream_id
     AND status IN ('pending','accepted')
   LIMIT 1;
  IF _existing IS NOT NULL THEN
    RETURN jsonb_build_object('ok', false, 'error', 'You already have a pending request');
  END IF;

  -- Wallet check + hold (atomic)
  SELECT balance INTO _wallet_balance FROM wallets WHERE user_id = _customer FOR UPDATE;
  IF _wallet_balance IS NULL OR _wallet_balance < _hold THEN
    RETURN jsonb_build_object('ok', false, 'error',
      'Insufficient balance. Need at least ' || _min_minutes || ' minutes.');
  END IF;

  UPDATE wallets SET balance = balance - _hold, updated_at = now() WHERE user_id = _customer;

  INSERT INTO live_call_requests (
    live_stream_id, customer_id, astrologer_id, request_type,
    rate_per_min, hold_amount, status
  ) VALUES (
    _live_stream_id, _customer, _stream.astrologer_id, _request_type,
    _rate, _hold, 'pending'
  ) RETURNING id INTO _new_id;

  -- Notify astrologer (in-app)
  INSERT INTO notifications (user_id, title, body, type, link)
  VALUES (
    _astro.user_id,
    CASE WHEN _request_type = 'public' THEN 'New public call request' ELSE 'New private call request' END,
    'A viewer wants to ' || (CASE WHEN _request_type = 'public' THEN 'join your live' ELSE 'have a private call' END),
    'live_call_request',
    '/astrologer/live'
  );

  RETURN jsonb_build_object('ok', true, 'request_id', _new_id, 'hold_amount', _hold);
END;
$$;

-- ============================================================================
-- 7. UPDATE respond_live_call_request: handle private (creates call_sessions row + pauses live)
-- ============================================================================
CREATE OR REPLACE FUNCTION public.respond_live_call_request(
  _request_id uuid,
  _action text
) RETURNS jsonb
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public
AS $$
DECLARE
  _astro_user uuid := auth.uid();
  _req record;
  _astro record;
  _new_session_id uuid;
BEGIN
  IF _astro_user IS NULL THEN
    RETURN jsonb_build_object('ok', false, 'error', 'Not authenticated');
  END IF;
  IF _action NOT IN ('accept','reject') THEN
    RETURN jsonb_build_object('ok', false, 'error', 'Invalid action');
  END IF;

  SELECT * INTO _req FROM live_call_requests WHERE id = _request_id FOR UPDATE;
  IF NOT FOUND OR _req.status <> 'pending' THEN
    RETURN jsonb_build_object('ok', false, 'error', 'Request not pending');
  END IF;

  SELECT * INTO _astro FROM astrologers WHERE id = _req.astrologer_id;
  IF NOT FOUND OR _astro.user_id <> _astro_user THEN
    RETURN jsonb_build_object('ok', false, 'error', 'Not your request');
  END IF;

  IF _action = 'reject' THEN
    UPDATE live_call_requests
       SET status = 'rejected', responded_at = now()
     WHERE id = _request_id;
    PERFORM _release_live_call_hold(_request_id);
    RETURN jsonb_build_object('ok', true, 'status', 'rejected');
  END IF;

  -- ACCEPT branch
  IF _req.request_type = 'private' THEN
    -- Create a call_sessions row for billing/UI reuse
    INSERT INTO call_sessions (
      user_id, astrologer_id, per_minute_rate,
      wallet_hold_amount, status, initiated_at, connected_at
    ) VALUES (
      _req.customer_id, _req.astrologer_id, _req.rate_per_min,
      _req.hold_amount, 'active', now(), now()
    ) RETURNING id INTO _new_session_id;

    UPDATE live_call_requests
       SET status = 'accepted', responded_at = now(), accepted_at = now(),
           linked_call_session_id = _new_session_id
     WHERE id = _request_id;

    UPDATE live_streams
       SET is_paused_for_private = true,
           paused_at = now(),
           active_call_request_id = _request_id
     WHERE id = _req.live_stream_id;

    -- Notify customer
    INSERT INTO notifications (user_id, title, body, type, link)
    VALUES (_req.customer_id, 'Private call accepted', 'Your private call is starting now',
            'live_private_accepted', '/call/' || _new_session_id);

    RETURN jsonb_build_object('ok', true, 'status', 'accepted',
      'request_type', 'private', 'call_session_id', _new_session_id);
  ELSE
    -- public: same as before
    UPDATE live_call_requests
       SET status = 'accepted', responded_at = now(), accepted_at = now()
     WHERE id = _request_id;

    UPDATE live_streams
       SET active_co_host_id = _req.customer_id,
           active_call_request_id = _request_id
     WHERE id = _req.live_stream_id;

    INSERT INTO notifications (user_id, title, body, type, link)
    VALUES (_req.customer_id, 'Public call accepted', 'You can now join the live!',
            'live_public_accepted', '/live');

    RETURN jsonb_build_object('ok', true, 'status', 'accepted', 'request_type', 'public');
  END IF;
END;
$$;

-- ============================================================================
-- 8. NEW: end_private_live_call
-- ============================================================================
CREATE OR REPLACE FUNCTION public.end_private_live_call(
  _request_id uuid,
  _ended_by text DEFAULT 'customer'
) RETURNS jsonb
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public
AS $$
DECLARE
  _user uuid := auth.uid();
  _req record;
  _session record;
  _astro record;
  _settings record;
  _duration int;
  _billable_min int;
  _total numeric;
  _astro_share numeric;
  _astro_earn numeric;
  _company_earn numeric;
  _wallet_balance numeric;
  _refund numeric;
BEGIN
  IF _user IS NULL THEN
    RETURN jsonb_build_object('ok', false, 'error', 'Not authenticated');
  END IF;

  SELECT * INTO _req FROM live_call_requests WHERE id = _request_id FOR UPDATE;
  IF NOT FOUND OR _req.status <> 'accepted' OR _req.request_type <> 'private' THEN
    RETURN jsonb_build_object('ok', false, 'error', 'Not an active private call');
  END IF;

  SELECT * INTO _astro FROM astrologers WHERE id = _req.astrologer_id;
  IF _user <> _req.customer_id AND _user <> _astro.user_id THEN
    RETURN jsonb_build_object('ok', false, 'error', 'Not a participant');
  END IF;

  SELECT * INTO _session FROM call_sessions WHERE id = _req.linked_call_session_id FOR UPDATE;
  IF NOT FOUND THEN
    RETURN jsonb_build_object('ok', false, 'error', 'Call session not found');
  END IF;

  SELECT astrologer_share_percent, min_billing_seconds INTO _settings FROM platform_settings WHERE id = 1;
  _astro_share := COALESCE(_settings.astrologer_share_percent, 30) / 100.0;

  _duration := GREATEST(0, EXTRACT(EPOCH FROM (now() - COALESCE(_session.connected_at, _req.accepted_at)))::int);
  _billable_min := GREATEST(1, CEIL(_duration::numeric / 60))::int;
  _total := _billable_min * _req.rate_per_min;

  -- Cap at hold so customer never overcharged beyond what was held
  IF _total > _req.hold_amount THEN
    _total := _req.hold_amount;
  END IF;

  _astro_earn := ROUND(_total * _astro_share, 2);
  _company_earn := ROUND(_total - _astro_earn, 2);
  _refund := _req.hold_amount - _total;

  -- Refund unused hold to customer
  IF _refund > 0 THEN
    UPDATE wallets SET balance = balance + _refund, updated_at = now()
     WHERE user_id = _req.customer_id;
  END IF;

  -- Credit astrologer wallet
  UPDATE wallets SET balance = balance + _astro_earn, updated_at = now()
   WHERE user_id = _astro.user_id;

  -- Mark hold released so cron job won't double-refund
  UPDATE live_call_requests
     SET status = 'ended',
         ended_at = now(),
         duration_seconds = _duration,
         total_cost = _total,
         astrologer_earning = _astro_earn,
         company_earning = _company_earn,
         hold_released = true,
         ended_by = _ended_by
   WHERE id = _request_id;

  UPDATE call_sessions
     SET status = 'completed',
         ended_at = now(),
         duration_seconds = _duration,
         total_cost = _total,
         astrologer_earning = _astro_earn,
         company_earning = _company_earn,
         hold_released = true,
         ended_by = _ended_by,
         end_reason = 'ended_normally'
   WHERE id = _session.id;

  -- Resume the live stream
  UPDATE live_streams
     SET is_paused_for_private = false,
         paused_at = NULL,
         active_call_request_id = NULL,
         private_session_count = COALESCE(private_session_count, 0) + 1
   WHERE id = _req.live_stream_id;

  -- Notify both
  INSERT INTO notifications (user_id, title, body, type, link)
  VALUES
    (_req.customer_id, 'Private call ended',
     'Total: ₹' || _total::text || ' • ' || _billable_min || ' min',
     'live_private_ended', '/live'),
    (_astro.user_id, 'Private call earnings',
     '+₹' || _astro_earn::text || ' from ' || _billable_min || ' min',
     'earning', '/astrologer/earnings');

  RETURN jsonb_build_object(
    'ok', true,
    'total_cost', _total,
    'astrologer_earning', _astro_earn,
    'company_earning', _company_earn,
    'duration_seconds', _duration,
    'refunded', _refund
  );
END;
$$;

-- ============================================================================
-- 9. NEW: notify_live_resumed — used to let viewers know astrologer is back
-- ============================================================================
CREATE OR REPLACE FUNCTION public.notify_live_resumed(_stream_id uuid)
RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path = public
AS $$
DECLARE
  _stream record;
  _astro record;
BEGIN
  SELECT * INTO _stream FROM live_streams WHERE id = _stream_id;
  IF NOT FOUND THEN
    RETURN jsonb_build_object('ok', false);
  END IF;
  SELECT * INTO _astro FROM astrologers WHERE id = _stream.astrologer_id;

  INSERT INTO notifications (user_id, title, body, type, link)
  SELECT lv.user_id,
         '✨ ' || _astro.display_name || ' is back!',
         'The live stream has resumed',
         'live_resumed',
         '/live'
    FROM live_viewers lv
   WHERE lv.live_stream_id = _stream_id
     AND lv.left_at IS NULL
     AND lv.user_id <> _stream.astrologer_id
   ON CONFLICT DO NOTHING;

  RETURN jsonb_build_object('ok', true);
END;
$$;

-- ============================================================================
-- 10. toggle_notify_astrologer — used by Notify-me bell
-- ============================================================================
CREATE OR REPLACE FUNCTION public.toggle_notify_astrologer(_astrologer_id uuid)
RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path = public
AS $$
DECLARE
  _user uuid := auth.uid();
  _existing record;
BEGIN
  IF _user IS NULL THEN
    RETURN jsonb_build_object('ok', false, 'error', 'Not authenticated');
  END IF;

  SELECT * INTO _existing FROM user_notification_preferences
   WHERE user_id = _user AND target_id = _astrologer_id AND target_type = 'astrologer';

  IF FOUND THEN
    IF _existing.notify_on_live THEN
      UPDATE user_notification_preferences SET notify_on_live = false
       WHERE id = _existing.id;
      RETURN jsonb_build_object('ok', true, 'enabled', false);
    ELSE
      UPDATE user_notification_preferences SET notify_on_live = true
       WHERE id = _existing.id;
      RETURN jsonb_build_object('ok', true, 'enabled', true);
    END IF;
  ELSE
    INSERT INTO user_notification_preferences (user_id, target_id, target_type, notify_on_live)
    VALUES (_user, _astrologer_id, 'astrologer', true);
    RETURN jsonb_build_object('ok', true, 'enabled', true);
  END IF;
END;
$$;

-- ============================================================================
-- 11. notify_followers_live_started — call when astrologer goes live
-- ============================================================================
CREATE OR REPLACE FUNCTION public.notify_followers_live_started(_stream_id uuid)
RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path = public
AS $$
DECLARE
  _stream record;
  _astro record;
  _count int;
BEGIN
  SELECT * INTO _stream FROM live_streams WHERE id = _stream_id;
  IF NOT FOUND THEN RETURN jsonb_build_object('ok', false); END IF;
  SELECT * INTO _astro FROM astrologers WHERE id = _stream.astrologer_id;

  WITH targets AS (
    SELECT DISTINCT lf.follower_id AS user_id
      FROM live_followers lf
      LEFT JOIN user_notification_preferences unp
        ON unp.user_id = lf.follower_id
       AND unp.target_id = lf.astrologer_id
       AND unp.target_type = 'astrologer'
     WHERE lf.astrologer_id = _stream.astrologer_id
       AND COALESCE(unp.notify_on_live, true) = true
  )
  INSERT INTO notifications (user_id, title, body, type, link)
  SELECT user_id,
         '🔴 ' || _astro.display_name || ' is live now!',
         _stream.title,
         'live_started',
         '/live'
    FROM targets;

  GET DIAGNOSTICS _count = ROW_COUNT;
  RETURN jsonb_build_object('ok', true, 'sent', _count);
END;
$$;