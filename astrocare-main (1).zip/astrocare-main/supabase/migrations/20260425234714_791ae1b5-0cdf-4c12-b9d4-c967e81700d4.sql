-- Backfill birth_charts.source from inline chart_data.source for any row
-- where the column is still the default 'inhouse' but the JSON shows the
-- chart was actually computed via astrologyapi. This makes monitoring
-- queries (count by source) accurate without re-running calculate-chart.
UPDATE public.birth_charts
SET source = chart_data->>'source'
WHERE chart_data ? 'source'
  AND chart_data->>'source' IN ('astrologyapi', 'inhouse')
  AND source IS DISTINCT FROM (chart_data->>'source');