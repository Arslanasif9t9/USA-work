CREATE TABLE public.ashtakavarga_reports (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  birth_chart_id UUID NOT NULL REFERENCES public.birth_charts(id) ON DELETE CASCADE,
  sarva_data JSONB NOT NULL,
  bhinna_data JSONB NOT NULL,
  computed_metrics JSONB NOT NULL,
  language TEXT NOT NULL DEFAULT 'en' CHECK (language IN ('en','hi')),
  source TEXT NOT NULL DEFAULT 'astrologyapi',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (birth_chart_id, language)
);

ALTER TABLE public.ashtakavarga_reports ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users read own ashtakavarga reports"
  ON public.ashtakavarga_reports
  FOR SELECT
  USING (
    EXISTS (
      SELECT 1 FROM public.birth_charts bc
      WHERE bc.id = ashtakavarga_reports.birth_chart_id
        AND bc.user_id = auth.uid()
    )
  );

CREATE INDEX idx_ashtakavarga_reports_chart ON public.ashtakavarga_reports(birth_chart_id);