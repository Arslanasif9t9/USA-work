-- =============================================================================
-- Phase 2A · Task 3 — Public Call During Live Stream
-- =============================================================================

-- 1) live_call_requests --------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.live_call_requests (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  live_stream_id uuid NOT NULL REFERENCES public.live_streams(id) ON DELETE CASCADE,
  customer_id uuid NOT NULL,
  astrologer_id uuid NOT NULL REFERENCES public.astrologers(id) ON DELETE CASCADE,
  request_type text NOT NULL CHECK (request_type IN ('public','private')),
  status text NOT NULL DEFAULT 'pending'
    CHECK (status IN ('pending','accepted','rejected','expired','ended','cancelled')),
  rate_per_min numeric NOT NULL,
  hold_amount numeric NOT NULL DEFAULT 0,
  hold_released boolean NOT NULL DEFAULT false,
  requested_at timestamptz NOT NULL DEFAULT now(),
  responded_at timestamptz,
  accepted_at timestamptz,
  ended_at timestamptz,
  duration_seconds int NOT NULL DEFAULT 0,
  total_cost numeric NOT NULL DEFAULT 0,
  astrologer_earning numeric NOT NULL DEFAULT 0,
  company_earning numeric NOT NULL DEFAULT 0,
  ended_by text
);

CREATE INDEX IF NOT EXISTS idx_lcr_stream_status
  ON public.live_call_requests (live_stream_id, status);
CREATE INDEX IF NOT EXISTS idx_lcr_astro_status
  ON public.live_call_requests (astrologer_id, status);
CREATE INDEX IF NOT EXISTS idx_lcr_customer_status
  ON public.live_call_requests (customer_id, status);

ALTER TABLE public.live_call_requests REPLICA IDENTITY FULL;
ALTER TABLE public.live_call_requests ENABLE ROW LEVEL SECURITY;

DO $$ BEGIN
  PERFORM 1 FROM pg_publication_tables
   WHERE pubname='supabase_realtime' AND tablename='live_call_requests';
  IF NOT FOUND THEN
    EXECUTE 'ALTER PUBLICATION supabase_realtime ADD TABLE public.live_call_requests';
  END IF;
END $$;

-- RLS
DROP POLICY IF EXISTS "customer reads own call requests" ON public.live_call_requests;
CREATE POLICY "customer reads own call requests" ON public.live_call_requests
  FOR SELECT TO authenticated
  USING (customer_id = auth.uid());

DROP POLICY IF EXISTS "astrologer reads own call requests" ON public.live_call_requests;
CREATE POLICY "astrologer reads own call requests" ON public.live_call_requests
  FOR SELECT TO authenticated
  USING (astrologer_id IN (SELECT id FROM public.astrologers WHERE user_id = auth.uid()));

DROP POLICY IF EXISTS "viewers see active call requests on live streams" ON public.live_call_requests;
CREATE POLICY "viewers see active call requests on live streams" ON public.live_call_requests
  FOR SELECT TO authenticated
  USING (
    status IN ('accepted','ended')
    AND EXISTS (
      SELECT 1 FROM public.live_streams ls
       WHERE ls.id = live_call_requests.live_stream_id
    )
  );

-- Inserts/updates happen exclusively through SECURITY DEFINER RPCs, so
-- no INSERT/UPDATE policies are required.

-- 2) live_streams: track active co-host -----------------------------------------
ALTER TABLE public.live_streams
  ADD COLUMN IF NOT EXISTS active_co_host_id uuid,
  ADD COLUMN IF NOT EXISTS active_call_request_id uuid;

-- 3) RPC: request_live_call ----------------------------------------------------
CREATE OR REPLACE FUNCTION public.request_live_call(
  _live_stream_id uuid,
  _request_type text
) RETURNS jsonb
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE
  _customer uuid := auth.uid();
  _astro_id uuid;
  _astro_user uuid;
  _rate numeric;
  _hold numeric;
  _wallet_id uuid;
  _balance numeric;
  _new_balance numeric;
  _existing uuid;
  _request_id uuid;
  _stream_status text;
  _active_cohost uuid;
BEGIN
  IF _customer IS NULL THEN RAISE EXCEPTION 'Not authenticated' USING ERRCODE='28000'; END IF;
  IF _request_type NOT IN ('public','private') THEN RAISE EXCEPTION 'Invalid request type'; END IF;

  SELECT ls.status, ls.astrologer_id, ls.active_co_host_id, a.user_id, a.base_rate_per_min
    INTO _stream_status, _astro_id, _active_cohost, _astro_user, _rate
    FROM public.live_streams ls
    JOIN public.astrologers a ON a.id = ls.astrologer_id
   WHERE ls.id = _live_stream_id;

  IF _astro_id IS NULL THEN RAISE EXCEPTION 'Stream not found'; END IF;
  IF _stream_status <> 'live' THEN RAISE EXCEPTION 'Stream is not live' USING ERRCODE='22023'; END IF;
  IF _astro_user = _customer THEN RAISE EXCEPTION 'Cannot request your own stream' USING ERRCODE='22023'; END IF;
  IF _request_type = 'public' AND _active_cohost IS NOT NULL THEN
    RAISE EXCEPTION 'Another viewer is currently in a public call' USING ERRCODE='22023';
  END IF;

  SELECT id INTO _existing FROM public.live_call_requests
   WHERE customer_id = _customer
     AND live_stream_id = _live_stream_id
     AND status IN ('pending','accepted')
   LIMIT 1;
  IF _existing IS NOT NULL THEN
    RAISE EXCEPTION 'You already have an active request for this stream' USING ERRCODE='22023';
  END IF;

  _hold := GREATEST(_rate * 2, 0);

  SELECT id, balance INTO _wallet_id, _balance
    FROM public.wallets WHERE user_id = _customer FOR UPDATE;
  IF _wallet_id IS NULL THEN RAISE EXCEPTION 'Wallet not found'; END IF;
  IF _balance < _hold THEN
    RAISE EXCEPTION 'Insufficient balance — need at least 2 minutes' USING ERRCODE='22023';
  END IF;

  _new_balance := _balance - _hold;
  UPDATE public.wallets SET balance = _new_balance, updated_at = now() WHERE id = _wallet_id;
  INSERT INTO public.transactions (wallet_id, type, amount, description, balance_after)
  VALUES (_wallet_id, 'call_hold', _hold,
          'Live ' || _request_type || ' call hold (2-min minimum)', _new_balance);

  INSERT INTO public.live_call_requests
    (live_stream_id, customer_id, astrologer_id, request_type, rate_per_min, hold_amount)
  VALUES (_live_stream_id, _customer, _astro_id, _request_type, _rate, _hold)
  RETURNING id INTO _request_id;

  RETURN jsonb_build_object('ok', true, 'request_id', _request_id, 'rate', _rate, 'hold', _hold);
END;
$$;

-- 4) RPC: respond_live_call_request -------------------------------------------
CREATE OR REPLACE FUNCTION public.respond_live_call_request(
  _request_id uuid,
  _action text
) RETURNS jsonb
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE
  r record;
  _astro_user uuid;
  _active_cohost uuid;
BEGIN
  IF _action NOT IN ('accept','reject') THEN RAISE EXCEPTION 'Invalid action'; END IF;

  SELECT * INTO r FROM public.live_call_requests WHERE id = _request_id FOR UPDATE;
  IF r IS NULL THEN RAISE EXCEPTION 'Request not found'; END IF;

  SELECT user_id INTO _astro_user FROM public.astrologers WHERE id = r.astrologer_id;
  IF _astro_user IS NULL OR _astro_user <> auth.uid() THEN
    RAISE EXCEPTION 'Forbidden' USING ERRCODE='42501';
  END IF;
  IF r.status <> 'pending' THEN
    RETURN jsonb_build_object('ok', false, 'error', 'invalid_state', 'status', r.status);
  END IF;

  IF _action = 'reject' THEN
    UPDATE public.live_call_requests
       SET status='rejected', responded_at=now(), ended_at=now(), ended_by='astrologer'
     WHERE id = _request_id;
    PERFORM public._release_live_call_hold(_request_id);
    RETURN jsonb_build_object('ok', true, 'status', 'rejected');
  END IF;

  -- accept
  IF r.request_type = 'public' THEN
    SELECT active_co_host_id INTO _active_cohost FROM public.live_streams WHERE id = r.live_stream_id FOR UPDATE;
    IF _active_cohost IS NOT NULL THEN
      RAISE EXCEPTION 'Another co-host already active' USING ERRCODE='22023';
    END IF;
    UPDATE public.live_streams
       SET active_co_host_id = r.customer_id,
           active_call_request_id = r.id
     WHERE id = r.live_stream_id;
  END IF;

  UPDATE public.live_call_requests
     SET status='accepted', responded_at=now(), accepted_at=now()
   WHERE id = _request_id;

  RETURN jsonb_build_object('ok', true, 'status', 'accepted');
END;
$$;

-- 5) Internal helper: release hold (idempotent) -------------------------------
CREATE OR REPLACE FUNCTION public._release_live_call_hold(_request_id uuid)
RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE
  r record; _wallet_id uuid; _balance numeric; _new numeric;
BEGIN
  SELECT * INTO r FROM public.live_call_requests WHERE id = _request_id FOR UPDATE;
  IF r IS NULL OR r.hold_released OR r.hold_amount <= 0 THEN RETURN; END IF;

  SELECT id, balance INTO _wallet_id, _balance
    FROM public.wallets WHERE user_id = r.customer_id FOR UPDATE;
  IF _wallet_id IS NULL THEN RETURN; END IF;
  _new := _balance + r.hold_amount;
  UPDATE public.wallets SET balance = _new, updated_at = now() WHERE id = _wallet_id;
  INSERT INTO public.transactions (wallet_id, type, amount, description, balance_after)
  VALUES (_wallet_id, 'call_hold_release', r.hold_amount,
          'Live ' || r.request_type || ' call hold released', _new);
  UPDATE public.live_call_requests SET hold_released = true WHERE id = _request_id;
END;
$$;

-- 6) RPC: cancel_live_call_request --------------------------------------------
CREATE OR REPLACE FUNCTION public.cancel_live_call_request(_request_id uuid)
RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE r record;
BEGIN
  SELECT * INTO r FROM public.live_call_requests WHERE id = _request_id FOR UPDATE;
  IF r IS NULL THEN RAISE EXCEPTION 'Not found'; END IF;
  IF r.customer_id <> auth.uid() THEN RAISE EXCEPTION 'Forbidden' USING ERRCODE='42501'; END IF;
  IF r.status <> 'pending' THEN
    RETURN jsonb_build_object('ok', false, 'error', 'invalid_state');
  END IF;
  UPDATE public.live_call_requests
     SET status='cancelled', ended_at=now(), ended_by='customer'
   WHERE id = _request_id;
  PERFORM public._release_live_call_hold(_request_id);
  RETURN jsonb_build_object('ok', true);
END;
$$;

-- 7) RPC: end_live_call (atomic settle) ---------------------------------------
CREATE OR REPLACE FUNCTION public.end_live_call(_request_id uuid, _ended_by text)
RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE
  r record;
  _astro_user uuid;
  _astro_name text;
  _seconds int;
  _minutes int;
  _total numeric;
  _astro_share numeric;
  _company_share numeric;
  _share_pct numeric;
  _wallet_id uuid; _balance numeric; _new_balance numeric;
  _astro_wallet uuid; _astro_balance numeric; _astro_new numeric;
  _caller uuid := auth.uid();
BEGIN
  IF _caller IS NULL THEN RAISE EXCEPTION 'Not authenticated' USING ERRCODE='28000'; END IF;

  SELECT * INTO r FROM public.live_call_requests WHERE id = _request_id FOR UPDATE;
  IF r IS NULL THEN RAISE EXCEPTION 'Not found'; END IF;

  SELECT user_id, display_name INTO _astro_user, _astro_name
    FROM public.astrologers WHERE id = r.astrologer_id;

  -- Authorize: customer, astrologer, or system_balance/system_timeout
  IF _ended_by NOT IN ('system_balance','system_timeout','admin')
     AND r.customer_id <> _caller AND _astro_user <> _caller THEN
    RAISE EXCEPTION 'Forbidden' USING ERRCODE='42501';
  END IF;

  IF r.status = 'ended' THEN
    RETURN jsonb_build_object('ok', true, 'already_ended', true,
      'total_cost', r.total_cost, 'astrologer_earning', r.astrologer_earning);
  END IF;

  IF r.status <> 'accepted' THEN
    -- Pending/rejected/cancelled: just release hold and mark ended
    UPDATE public.live_call_requests
       SET status='ended', ended_at=now(), ended_by=_ended_by
     WHERE id = _request_id;
    PERFORM public._release_live_call_hold(_request_id);
    RETURN jsonb_build_object('ok', true, 'no_billing', true);
  END IF;

  _seconds := GREATEST(0, EXTRACT(EPOCH FROM (now() - r.accepted_at))::int);
  _minutes := GREATEST(1, CEIL(_seconds::numeric / 60.0))::int;
  _total := _minutes * r.rate_per_min;

  SELECT astrologer_share_percent INTO _share_pct FROM public.platform_settings WHERE id = 1;
  _share_pct := COALESCE(_share_pct, 30);
  _astro_share := ROUND(_total * _share_pct / 100.0, 2);
  _company_share := ROUND(_total - _astro_share, 2);

  -- Release hold first so we have full balance for the settle charge
  PERFORM public._release_live_call_hold(_request_id);

  -- Debit customer
  SELECT id, balance INTO _wallet_id, _balance
    FROM public.wallets WHERE user_id = r.customer_id FOR UPDATE;
  IF _wallet_id IS NULL THEN RAISE EXCEPTION 'Customer wallet missing'; END IF;
  IF _balance < _total THEN
    -- Insufficient at settle: cap to balance (graceful)
    _total := _balance;
    _astro_share := ROUND(_total * _share_pct / 100.0, 2);
    _company_share := ROUND(_total - _astro_share, 2);
  END IF;
  _new_balance := _balance - _total;
  UPDATE public.wallets SET balance = _new_balance, updated_at = now() WHERE id = _wallet_id;
  IF _total > 0 THEN
    INSERT INTO public.transactions (wallet_id, type, amount, description, balance_after)
    VALUES (_wallet_id, 'call_charge', _total,
            'Live ' || r.request_type || ' call (' || _minutes || ' min) with ' || COALESCE(_astro_name,'astrologer'),
            _new_balance);
  END IF;

  -- Credit astrologer
  IF _astro_user IS NOT NULL AND _astro_share > 0 THEN
    SELECT id, balance INTO _astro_wallet, _astro_balance
      FROM public.wallets WHERE user_id = _astro_user FOR UPDATE;
    IF _astro_wallet IS NULL THEN
      INSERT INTO public.wallets (user_id, balance) VALUES (_astro_user, 0)
        RETURNING id, balance INTO _astro_wallet, _astro_balance;
    END IF;
    _astro_new := _astro_balance + _astro_share;
    UPDATE public.wallets SET balance = _astro_new, updated_at = now() WHERE id = _astro_wallet;
    INSERT INTO public.transactions (wallet_id, type, amount, description, balance_after)
    VALUES (_astro_wallet, 'consultation_credit', _astro_share,
            'Earnings (' || _share_pct::int || '%) — live ' || r.request_type || ' call', _astro_new);
  END IF;

  -- Finalize request + clear stream co-host
  UPDATE public.live_call_requests
     SET status='ended',
         ended_at=now(),
         ended_by=_ended_by,
         duration_seconds=_seconds,
         total_cost=_total,
         astrologer_earning=_astro_share,
         company_earning=_company_share
   WHERE id = _request_id;

  UPDATE public.live_streams
     SET active_co_host_id = NULL,
         active_call_request_id = NULL
   WHERE id = r.live_stream_id
     AND active_call_request_id = _request_id;

  RETURN jsonb_build_object('ok', true,
    'duration_seconds', _seconds,
    'total_cost', _total,
    'astrologer_earning', _astro_share,
    'company_earning', _company_share);
END;
$$;

-- 8) Auto-expire stale pending requests (>60s) --------------------------------
CREATE OR REPLACE FUNCTION public.expire_pending_live_call_requests()
RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE r record;
BEGIN
  FOR r IN
    SELECT id FROM public.live_call_requests
     WHERE status = 'pending'
       AND requested_at < now() - interval '65 seconds'
  LOOP
    UPDATE public.live_call_requests
       SET status='expired', ended_at=now(), ended_by='system_timeout'
     WHERE id = r.id;
    PERFORM public._release_live_call_hold(r.id);
  END LOOP;
END;
$$;