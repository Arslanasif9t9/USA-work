CREATE TABLE public.shodashvarga_charts (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  birth_chart_id UUID NOT NULL REFERENCES public.birth_charts(id) ON DELETE CASCADE,
  chart_id TEXT NOT NULL CHECK (chart_id IN ('D1','D2','D3','D4','D7','D9','D10','D12','D16','D20','D24','D27','D30','D40','D45','D60')),
  chart_data JSONB NOT NULL,
  language TEXT NOT NULL DEFAULT 'en' CHECK (language IN ('en','hi')),
  source TEXT NOT NULL DEFAULT 'astrologyapi' CHECK (source IN ('astrologyapi','in_house')),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (birth_chart_id, chart_id, language)
);

CREATE INDEX idx_shodashvarga_charts_birth_chart ON public.shodashvarga_charts(birth_chart_id);

ALTER TABLE public.shodashvarga_charts ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users read own shodashvarga charts"
  ON public.shodashvarga_charts FOR SELECT
  USING (
    EXISTS (
      SELECT 1 FROM public.birth_charts bc
      WHERE bc.id = shodashvarga_charts.birth_chart_id
        AND bc.user_id = auth.uid()
    )
  );