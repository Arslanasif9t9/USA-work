CREATE TABLE public.nakshatra_reports (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  birth_chart_id UUID NOT NULL REFERENCES public.birth_charts(id) ON DELETE CASCADE,
  nakshatra_id INT NOT NULL CHECK (nakshatra_id BETWEEN 1 AND 27),
  pada INT NOT NULL CHECK (pada BETWEEN 1 AND 4),
  api_response JSONB NOT NULL DEFAULT '{}'::jsonb,
  language TEXT NOT NULL DEFAULT 'en' CHECK (language IN ('en', 'hi')),
  source TEXT NOT NULL DEFAULT 'astrologyapi' CHECK (source IN ('astrologyapi', 'static_fallback')),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (birth_chart_id, language)
);

CREATE INDEX idx_nakshatra_reports_chart ON public.nakshatra_reports(birth_chart_id);

ALTER TABLE public.nakshatra_reports ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users read own nakshatra reports"
  ON public.nakshatra_reports
  FOR SELECT
  USING (
    EXISTS (
      SELECT 1 FROM public.birth_charts bc
      WHERE bc.id = nakshatra_reports.birth_chart_id
        AND bc.user_id = auth.uid()
    )
  );