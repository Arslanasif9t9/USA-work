create table if not exists public.favorite_astrologers (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null,
  astrologer_id uuid not null references public.astrologers(id) on delete cascade,
  created_at timestamptz not null default now(),
  unique (user_id, astrologer_id)
);

create index if not exists favorite_astrologers_user_idx on public.favorite_astrologers(user_id);

alter table public.favorite_astrologers enable row level security;

create policy "Users select own favorites"
  on public.favorite_astrologers for select
  using (auth.uid() = user_id);

create policy "Users insert own favorites"
  on public.favorite_astrologers for insert
  with check (auth.uid() = user_id);

create policy "Users delete own favorites"
  on public.favorite_astrologers for delete
  using (auth.uid() = user_id);