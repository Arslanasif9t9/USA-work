
-- ===== FIX 1: only one master admin =====
-- Demote (not delete) the duplicate so we don't break activity log foreign keys.
UPDATE public.admin_users
   SET is_active = false,
       role = 'admin',
       permissions = '[]'::jsonb
 WHERE email = 'masteradmin@astrocare.app'
   AND email <> 'astrolume22@gmail.com';

-- ===== FIX 8: per-admin wallet limits =====
ALTER TABLE public.admin_users
  ADD COLUMN IF NOT EXISTS can_directly_adjust_wallet boolean NOT NULL DEFAULT true,
  ADD COLUMN IF NOT EXISTS max_wallet_adjustment numeric NULL;

-- ===== FIX 7: wallet adjustment requests =====
CREATE TABLE IF NOT EXISTS public.wallet_adjustment_requests (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  requested_by_admin_id uuid NOT NULL REFERENCES public.admin_users(id) ON DELETE CASCADE,
  target_user_id uuid NOT NULL,
  target_user_type text NOT NULL CHECK (target_user_type IN ('customer','astrologer')),
  amount numeric NOT NULL,                -- positive = credit, negative = debit
  reason text,
  status text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','approved','rejected')),
  reviewed_by_admin_id uuid REFERENCES public.admin_users(id),
  reviewed_at timestamptz,
  review_note text,
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.wallet_adjustment_requests ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "admins read wallet adj requests" ON public.wallet_adjustment_requests;
CREATE POLICY "admins read wallet adj requests"
  ON public.wallet_adjustment_requests FOR SELECT
  USING (public.is_active_admin(auth.uid()));

DROP POLICY IF EXISTS "admins insert wallet adj requests" ON public.wallet_adjustment_requests;
CREATE POLICY "admins insert wallet adj requests"
  ON public.wallet_adjustment_requests FOR INSERT
  WITH CHECK (public.is_active_admin(auth.uid()));

CREATE INDEX IF NOT EXISTS idx_wallet_adj_status ON public.wallet_adjustment_requests(status, created_at DESC);

-- ===== FIX 11: dismissed announcements (don't repeatedly show) =====
CREATE TABLE IF NOT EXISTS public.dismissed_announcements (
  user_id uuid NOT NULL,
  announcement_id uuid NOT NULL REFERENCES public.announcements(id) ON DELETE CASCADE,
  dismissed_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (user_id, announcement_id)
);
ALTER TABLE public.dismissed_announcements ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "users manage own dismissals" ON public.dismissed_announcements;
CREATE POLICY "users manage own dismissals"
  ON public.dismissed_announcements FOR ALL
  USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

-- Allow users to read scheduled popup announcements too (existing policy only had banner)
DROP POLICY IF EXISTS "users read active announcements" ON public.announcements;
CREATE POLICY "users read active announcements"
  ON public.announcements FOR SELECT
  USING (
    is_active = true
    AND scheduled_at <= now()
    AND (expires_at IS NULL OR expires_at > now())
    AND display_type IN ('banner','popup','notification')
    AND (
      audience = 'all'
      OR audience = 'customers'
      OR audience = 'astrologers'
      OR (audience = 'user' AND target_user_id = auth.uid())
    )
  );

-- ===== FIX 9: withdrawal completion logs a transaction =====
ALTER TYPE transaction_type ADD VALUE IF NOT EXISTS 'withdrawal';
