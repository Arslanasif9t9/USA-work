-- 1. Slug column
alter table public.astrologers add column if not exists slug text;

update public.astrologers
  set slug = lower(regexp_replace(regexp_replace(display_name, '[^a-zA-Z0-9]+', '-', 'g'), '(^-|-$)', '', 'g')) || '-' || substr(id::text, 1, 6)
  where slug is null;

create unique index if not exists astrologers_slug_unique on public.astrologers(slug);
alter table public.astrologers alter column slug set not null;

-- 2. last_seen_at for presence
alter table public.astrologers add column if not exists last_seen_at timestamptz;

-- 3. Reviews table
create table if not exists public.reviews (
  id uuid primary key default gen_random_uuid(),
  astrologer_id uuid not null references public.astrologers(id) on delete cascade,
  user_id uuid not null,
  rating int not null check (rating between 1 and 5),
  comment text,
  helpful_count int not null default 0,
  created_at timestamptz not null default now()
);

create index if not exists reviews_astrologer_idx on public.reviews(astrologer_id, created_at desc);

alter table public.reviews enable row level security;

create policy "Anyone can read reviews" on public.reviews for select using (true);
create policy "Users insert own reviews" on public.reviews for insert with check (auth.uid() = user_id);
create policy "Users update own reviews" on public.reviews for update using (auth.uid() = user_id);
create policy "Users delete own reviews" on public.reviews for delete using (auth.uid() = user_id);

-- 4. Presence expiry function
create or replace function public.expire_stale_presence()
returns void
language sql
security definer
set search_path = public
as $$
  update public.astrologers
    set status = 'offline'
    where status = 'online'
      and (last_seen_at is null or last_seen_at < now() - interval '60 seconds');
$$;

-- 5. Schedule via pg_cron (extension already enabled in most Lovable Cloud projects)
create extension if not exists pg_cron with schema extensions;

-- Drop existing job if present, then schedule
do $$
declare jid bigint;
begin
  select jobid into jid from cron.job where jobname = 'expire-stale-astrologer-presence';
  if jid is not null then perform cron.unschedule(jid); end if;
  perform cron.schedule('expire-stale-astrologer-presence', '* * * * *', $cron$select public.expire_stale_presence();$cron$);
end $$;