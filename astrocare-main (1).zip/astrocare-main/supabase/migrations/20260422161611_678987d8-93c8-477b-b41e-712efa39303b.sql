-- birth_charts
CREATE TABLE public.birth_charts (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  gender TEXT NOT NULL CHECK (gender IN ('male','female','other')),
  birth_date DATE NOT NULL,
  birth_time TIME NOT NULL,
  birth_place TEXT NOT NULL,
  latitude NUMERIC(10,7) NOT NULL,
  longitude NUMERIC(10,7) NOT NULL,
  timezone TEXT NOT NULL,
  ayanamsa_value NUMERIC(12,7),
  computed_data JSONB NOT NULL DEFAULT '{}'::jsonb,
  is_primary BOOLEAN NOT NULL DEFAULT TRUE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE UNIQUE INDEX birth_charts_one_primary_per_user
  ON public.birth_charts (user_id) WHERE is_primary = TRUE;

CREATE INDEX birth_charts_user_id_idx ON public.birth_charts(user_id);

ALTER TABLE public.birth_charts ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own charts" ON public.birth_charts
  FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "Users can insert own charts" ON public.birth_charts
  FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Users can update own charts" ON public.birth_charts
  FOR UPDATE USING (auth.uid() = user_id);
CREATE POLICY "Users can delete own charts" ON public.birth_charts
  FOR DELETE USING (auth.uid() = user_id);

CREATE TRIGGER update_birth_charts_updated_at
  BEFORE UPDATE ON public.birth_charts
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- location_cache
CREATE TABLE public.location_cache (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  query TEXT NOT NULL UNIQUE,
  results JSONB NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX location_cache_created_at_idx ON public.location_cache(created_at);

ALTER TABLE public.location_cache ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone authenticated can read cache" ON public.location_cache
  FOR SELECT TO authenticated USING (true);