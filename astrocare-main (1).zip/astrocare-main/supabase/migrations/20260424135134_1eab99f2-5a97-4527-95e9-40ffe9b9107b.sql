
CREATE OR REPLACE FUNCTION public.recalc_astrologer_rating()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  _astro_id uuid;
  _avg numeric;
  _cnt integer;
BEGIN
  _astro_id := COALESCE(NEW.astrologer_id, OLD.astrologer_id);
  SELECT COALESCE(AVG(rating), 0)::numeric(3,2), COUNT(*)::int
    INTO _avg, _cnt
    FROM public.reviews WHERE astrologer_id = _astro_id;
  UPDATE public.astrologers
     SET rating_avg = _avg,
         rating_count = _cnt,
         updated_at = now()
   WHERE id = _astro_id;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_reviews_recalc_rating ON public.reviews;
CREATE TRIGGER trg_reviews_recalc_rating
AFTER INSERT OR UPDATE OR DELETE ON public.reviews
FOR EACH ROW EXECUTE FUNCTION public.recalc_astrologer_rating();
