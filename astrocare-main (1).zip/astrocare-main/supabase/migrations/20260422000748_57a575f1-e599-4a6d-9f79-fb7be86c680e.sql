-- Entitlements: user-owned unlocks (reports, features, etc.)
CREATE TABLE public.entitlements (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL,
  kind TEXT NOT NULL,
  product_id TEXT NOT NULL,
  stripe_payment_id TEXT,
  metadata JSONB NOT NULL DEFAULT '{}'::jsonb,
  expires_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX idx_entitlements_user ON public.entitlements(user_id);
CREATE INDEX idx_entitlements_product ON public.entitlements(product_id);
CREATE UNIQUE INDEX uq_entitlements_payment ON public.entitlements(stripe_payment_id) WHERE stripe_payment_id IS NOT NULL;

ALTER TABLE public.entitlements ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can read own entitlements"
  ON public.entitlements FOR SELECT
  USING (user_id = auth.uid());

-- Pack definitions: maps Stripe price_id -> wallet credit amount
CREATE TABLE public.pack_definitions (
  price_id TEXT PRIMARY KEY,
  product_id TEXT NOT NULL,
  pack_type TEXT NOT NULL DEFAULT 'wallet_recharge',
  paid_amount NUMERIC NOT NULL,
  credit_amount NUMERIC NOT NULL,
  display_name TEXT NOT NULL,
  active BOOLEAN NOT NULL DEFAULT true,
  sort_order INTEGER NOT NULL DEFAULT 0,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

ALTER TABLE public.pack_definitions ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can read active packs"
  ON public.pack_definitions FOR SELECT
  USING (active = true);

INSERT INTO public.pack_definitions (price_id, product_id, paid_amount, credit_amount, display_name, sort_order) VALUES
  ('recharge_100_inr',  'recharge_100',   100,  100,  'Starter',     1),
  ('recharge_500_inr',  'recharge_500',   500,  500,  'Popular',     2),
  ('recharge_1000_inr', 'recharge_1000', 1000, 1050,  'Value',       3),
  ('recharge_2000_inr', 'recharge_2000', 2000, 2150,  'Best value',  4),
  ('recharge_5000_inr', 'recharge_5000', 5000, 5500,  'Premium',     5);