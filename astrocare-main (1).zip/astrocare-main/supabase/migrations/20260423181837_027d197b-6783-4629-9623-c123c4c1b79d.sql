-- Ensure UPDATE events broadcast full row data
ALTER TABLE public.chat_sessions REPLICA IDENTITY FULL;

-- Make sure chat_sessions is in the realtime publication (idempotent)
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_publication_tables
    WHERE pubname = 'supabase_realtime' AND tablename = 'chat_sessions'
  ) THEN
    EXECUTE 'ALTER PUBLICATION supabase_realtime ADD TABLE public.chat_sessions';
  END IF;
END $$;