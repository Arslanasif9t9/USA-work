
CREATE OR REPLACE FUNCTION public.send_gift(
  _astrologer_id uuid,
  _gift_type text,
  _amount numeric,
  _gift_label text,
  _customer_note text,
  _session_id uuid
)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  _user_id uuid := auth.uid();
  _wallet_id uuid;
  _balance numeric;
  _new_balance numeric;
  _share_pct numeric;
  _astro_share numeric;
  _company_share numeric;
  _astro_user uuid;
  _astro_wallet_id uuid;
  _astro_balance numeric;
  _astro_new_balance numeric;
  _gift_id uuid;
  _astro_name text;
BEGIN
  IF _user_id IS NULL THEN
    RAISE EXCEPTION 'Not authenticated' USING ERRCODE = '28000';
  END IF;
  IF _amount IS NULL OR _amount <= 0 THEN
    RAISE EXCEPTION 'Gift amount must be positive';
  END IF;

  SELECT astrologer_share_percent INTO _share_pct FROM public.platform_settings WHERE id = 1;
  _share_pct := COALESCE(_share_pct, 30);
  _astro_share := ROUND(_amount * _share_pct / 100.0, 2);
  _company_share := ROUND(_amount - _astro_share, 2);

  SELECT user_id, display_name INTO _astro_user, _astro_name
    FROM public.astrologers WHERE id = _astrologer_id;
  IF _astro_user IS NULL THEN
    RAISE EXCEPTION 'Astrologer not found';
  END IF;

  SELECT id, balance INTO _wallet_id, _balance
    FROM public.wallets WHERE user_id = _user_id FOR UPDATE;
  IF _wallet_id IS NULL THEN
    RAISE EXCEPTION 'Wallet not found';
  END IF;
  IF _balance < _amount THEN
    RAISE EXCEPTION 'Insufficient balance: need %, have %', _amount, _balance USING ERRCODE = '22023';
  END IF;

  _new_balance := _balance - _amount;
  UPDATE public.wallets SET balance = _new_balance, updated_at = now() WHERE id = _wallet_id;

  INSERT INTO public.transactions (wallet_id, type, amount, description, balance_after)
  VALUES (_wallet_id, 'consultation_debit', _amount,
          'Gift sent: ' || COALESCE(_gift_label, _gift_type) || ' → ' || COALESCE(_astro_name, 'astrologer'),
          _new_balance);

  -- Credit astrologer share
  IF _astro_user IS NOT NULL AND _astro_share > 0 THEN
    SELECT id, balance INTO _astro_wallet_id, _astro_balance
      FROM public.wallets WHERE user_id = _astro_user FOR UPDATE;
    IF _astro_wallet_id IS NULL THEN
      INSERT INTO public.wallets (user_id, balance) VALUES (_astro_user, 0)
        RETURNING id, balance INTO _astro_wallet_id, _astro_balance;
    END IF;
    _astro_new_balance := _astro_balance + _astro_share;
    UPDATE public.wallets SET balance = _astro_new_balance, updated_at = now() WHERE id = _astro_wallet_id;
    INSERT INTO public.transactions (wallet_id, type, amount, description, balance_after)
    VALUES (_astro_wallet_id, 'consultation_credit', _astro_share,
            'Gift received: ' || COALESCE(_gift_label, _gift_type) || ' (' || _share_pct::int || '% share)',
            _astro_new_balance);

    INSERT INTO public.notifications (user_id, type, title, body, link)
    VALUES (_astro_user, 'gift',
            'You received a ' || COALESCE(_gift_label, _gift_type) || '!',
            '+₹' || _astro_share::text || COALESCE(' — "' || left(_customer_note, 100) || '"', ''),
            '/astrologer/gifts');
  END IF;

  INSERT INTO public.gifts
    (user_id, astrologer_id, session_id, gift_type, amount, message, customer_note,
     astrologer_earning, company_earning)
  VALUES (_user_id, _astrologer_id, _session_id, _gift_type, _amount, _gift_label, _customer_note,
          _astro_share, _company_share)
  RETURNING id INTO _gift_id;

  RETURN jsonb_build_object(
    'ok', true,
    'gift_id', _gift_id,
    'astrologer_earning', _astro_share,
    'company_earning', _company_share,
    'new_balance', _new_balance
  );
END;
$$;
