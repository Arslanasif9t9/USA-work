ALTER TABLE public.birth_charts
  ADD COLUMN IF NOT EXISTS source TEXT NOT NULL DEFAULT 'inhouse';

COMMENT ON COLUMN public.birth_charts.source IS
  'Which engine produced chart_data: ''astrologyapi'' (third-party) or ''inhouse'' (local astronomy-engine fallback).';