
CREATE OR REPLACE FUNCTION public.hold_wallet_for_chat(_user_id uuid, _amount numeric, _chat_session_id uuid)
RETURNS numeric
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  _wallet_id uuid;
  _balance numeric;
  _new_balance numeric;
BEGIN
  IF _amount <= 0 THEN RETURN 0; END IF;

  SELECT id, balance INTO _wallet_id, _balance
    FROM public.wallets WHERE user_id = _user_id FOR UPDATE;
  IF _wallet_id IS NULL THEN RAISE EXCEPTION 'Wallet not found'; END IF;
  IF _balance < _amount THEN
    RAISE EXCEPTION 'Insufficient balance: need %, have %', _amount, _balance USING ERRCODE='22023';
  END IF;

  _new_balance := _balance - _amount;
  UPDATE public.wallets SET balance = _new_balance, updated_at = now() WHERE id = _wallet_id;

  INSERT INTO public.transactions (wallet_id, type, amount, description, balance_after)
  VALUES (_wallet_id, 'call_hold', _amount, 'Chat hold (5-min minimum)', _new_balance);

  RETURN _new_balance;
END;
$$;

CREATE OR REPLACE FUNCTION public.release_chat_hold(_chat_session_id uuid)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  _user_id uuid;
  _amount numeric;
  _already boolean;
  _wallet_id uuid;
  _balance numeric;
  _new_balance numeric;
BEGIN
  SELECT user_id, wallet_hold_amount, hold_released
    INTO _user_id, _amount, _already
    FROM public.chat_sessions WHERE id = _chat_session_id FOR UPDATE;
  IF _user_id IS NULL THEN RETURN; END IF;
  IF _already THEN RETURN; END IF;

  SELECT id, balance INTO _wallet_id, _balance
    FROM public.wallets WHERE user_id = _user_id FOR UPDATE;
  IF _wallet_id IS NULL THEN RETURN; END IF;

  _new_balance := _balance + _amount;
  UPDATE public.wallets SET balance = _new_balance, updated_at = now() WHERE id = _wallet_id;

  INSERT INTO public.transactions (wallet_id, type, amount, description, balance_after)
  VALUES (_wallet_id, 'call_hold_release', _amount, 'Chat hold released', _new_balance);

  UPDATE public.chat_sessions SET hold_released = true WHERE id = _chat_session_id;
END;
$$;
