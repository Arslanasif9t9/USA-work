CREATE TABLE public.panchang_cache (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  date date NOT NULL,
  latitude numeric NOT NULL,
  longitude numeric NOT NULL,
  timezone text NOT NULL,
  panchang_data jsonb NOT NULL,
  computed_at timestamptz NOT NULL DEFAULT now()
);

-- Unique on (date, lat rounded, lon rounded) so neighbours share cache hits.
CREATE UNIQUE INDEX panchang_cache_date_loc_key
  ON public.panchang_cache (date, round(latitude, 2), round(longitude, 2));

CREATE INDEX panchang_cache_computed_at_idx ON public.panchang_cache (computed_at);

ALTER TABLE public.panchang_cache ENABLE ROW LEVEL SECURITY;

-- Authenticated users can read; no insert/update/delete policies for users
-- (writes go through the edge function using the service-role key).
CREATE POLICY "Authenticated can read panchang_cache"
  ON public.panchang_cache
  FOR SELECT
  TO authenticated
  USING (true);

-- Manual cleanup helper. Not scheduled by default; invoke as needed:
--   SELECT public.cleanup_panchang_cache();
CREATE OR REPLACE FUNCTION public.cleanup_panchang_cache()
RETURNS void
LANGUAGE sql
SECURITY DEFINER
SET search_path = public
AS $$
  DELETE FROM public.panchang_cache
   WHERE computed_at < now() - interval '7 days';
$$;
