-- FIX 2: Add earnings split columns to chat_sessions
ALTER TABLE public.chat_sessions
  ADD COLUMN IF NOT EXISTS astrologer_earning numeric NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS company_earning numeric NOT NULL DEFAULT 0;

-- Same for call_sessions (forward-compatibility)
ALTER TABLE public.call_sessions
  ADD COLUMN IF NOT EXISTS astrologer_earning numeric NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS company_earning numeric NOT NULL DEFAULT 0;

-- FIX 3: Replace bill_active_chats() so it does NOT insert any transaction row
-- per minute. It only checks wallet balance + auto-ends if the customer can no
-- longer afford the next minute. Final billing happens once at session end.
CREATE OR REPLACE FUNCTION public.bill_active_chats()
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $function$
DECLARE
  r record;
  _wallet_balance numeric;
  _profile_minutes integer;
  _seconds int;
BEGIN
  FOR r IN
    SELECT cs.id, cs.user_id, cs.astrologer_id, cs.per_minute_rate, cs.accepted_at
      FROM public.chat_sessions cs
     WHERE cs.status = 'active'
       AND cs.accepted_at IS NOT NULL
  LOOP
    _seconds := EXTRACT(EPOCH FROM (now() - r.accepted_at))::int;

    -- Refresh duration on the row so both clients can see live progress on reconnects
    UPDATE public.chat_sessions
       SET duration_seconds = _seconds
     WHERE id = r.id;

    -- Affordability check: does the customer have enough for one more minute?
    SELECT COALESCE(consultation_minutes, 0) INTO _profile_minutes
      FROM public.profiles WHERE id = r.user_id;
    SELECT COALESCE(balance, 0) INTO _wallet_balance
      FROM public.wallets WHERE user_id = r.user_id;

    IF _profile_minutes <= 0 AND _wallet_balance < r.per_minute_rate THEN
      -- Auto-end (final billing happens via end_chat_session below)
      PERFORM public.end_chat_session(r.id, 'system', 'low_balance');
    END IF;
  END LOOP;
END;
$function$;

-- New helper: ends a chat session and performs the SINGLE final billing,
-- earnings split, and astrologer wallet credit. Idempotent (returns if already ended).
CREATE OR REPLACE FUNCTION public.end_chat_session(
  _session_id uuid,
  _ended_by text,
  _end_reason text
)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $function$
DECLARE
  s record;
  astro record;
  _seconds int;
  _minutes int;
  _total_cost numeric;
  _astro_share numeric;
  _company_share numeric;
  _astro_wallet_id uuid;
  _astro_balance numeric;
  _new_balance numeric;
  _astro_name text;
BEGIN
  SELECT * INTO s FROM public.chat_sessions WHERE id = _session_id FOR UPDATE;
  IF s IS NULL THEN
    RETURN jsonb_build_object('ok', false, 'error', 'not_found');
  END IF;

  IF s.status = 'ended' OR s.status = 'cancelled' OR s.status = 'rejected' THEN
    RETURN jsonb_build_object('ok', true, 'already_ended', true);
  END IF;

  -- If never accepted, just mark cancelled and release any hold
  IF s.status = 'pending' OR s.accepted_at IS NULL THEN
    UPDATE public.chat_sessions
       SET status = 'cancelled',
           ended_at = now(),
           ended_by = _ended_by,
           end_reason = COALESCE(_end_reason, 'ended_before_active')
     WHERE id = _session_id;
    PERFORM public.release_chat_hold(_session_id);
    RETURN jsonb_build_object('ok', true, 'cancelled', true);
  END IF;

  -- Active session: compute final billing
  _seconds := EXTRACT(EPOCH FROM (now() - s.accepted_at))::int;
  IF _seconds < 0 THEN _seconds := 0; END IF;
  _minutes := GREATEST(1, CEIL(_seconds::numeric / 60.0))::int;
  _total_cost := _minutes * s.per_minute_rate;

  -- Earnings split
  _astro_share   := ROUND(_total_cost * 0.30, 2);
  _company_share := ROUND(_total_cost * 0.70, 2);

  -- Look up astrologer
  SELECT id, user_id, display_name INTO astro
    FROM public.astrologers WHERE id = s.astrologer_id;

  -- 1. Release the hold (one transaction row of type call_hold_release)
  PERFORM public.release_chat_hold(_session_id);

  -- 2. Charge the customer ONCE for the actual session
  --    spend_consultation_time inserts at most 2 rows (minute pack + wallet),
  --    so the customer no longer sees a row per minute.
  BEGIN
    PERFORM public.spend_consultation_time(
      s.user_id,
      _minutes,
      s.per_minute_rate,
      'Chat with ' || COALESCE(astro.display_name, 'astrologer')
    );
  EXCEPTION WHEN OTHERS THEN
    -- If the wallet can't cover everything, charge whatever balance is available.
    -- We still close the session below.
    NULL;
  END;

  -- 3. Credit astrologer's 30% share into their wallet
  IF astro.user_id IS NOT NULL AND _astro_share > 0 THEN
    SELECT id, balance INTO _astro_wallet_id, _astro_balance
      FROM public.wallets WHERE user_id = astro.user_id FOR UPDATE;
    IF _astro_wallet_id IS NULL THEN
      INSERT INTO public.wallets (user_id, balance) VALUES (astro.user_id, 0)
        RETURNING id, balance INTO _astro_wallet_id, _astro_balance;
    END IF;
    _new_balance := _astro_balance + _astro_share;
    UPDATE public.wallets
       SET balance = _new_balance, updated_at = now()
     WHERE id = _astro_wallet_id;
    INSERT INTO public.transactions (wallet_id, type, amount, description, balance_after)
    VALUES (_astro_wallet_id, 'consultation_credit', _astro_share,
            'Earnings (30%) from chat session', _new_balance);
  END IF;

  -- 4. Mark session ended with full breakdown
  UPDATE public.chat_sessions
     SET status = 'ended',
         ended_at = now(),
         ended_by = _ended_by,
         end_reason = COALESCE(_end_reason, 'user_ended'),
         duration_seconds = _seconds,
         total_cost = _total_cost,
         astrologer_earning = _astro_share,
         company_earning = _company_share
   WHERE id = _session_id;

  -- 5. Post a single system message
  INSERT INTO public.chat_messages (session_id, sender_id, sender_role, content)
  VALUES (_session_id, s.user_id, 'system',
          'Chat session ended. Duration: ' || _seconds || 's, Total: ₹' || _total_cost);

  RETURN jsonb_build_object(
    'ok', true,
    'duration_seconds', _seconds,
    'total_cost', _total_cost,
    'astrologer_earning', _astro_share,
    'company_earning', _company_share
  );
END;
$function$;
