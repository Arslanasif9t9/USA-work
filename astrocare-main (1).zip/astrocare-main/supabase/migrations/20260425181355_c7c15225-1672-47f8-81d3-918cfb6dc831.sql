-- Add columns to live_streams (idempotent)
ALTER TABLE public.live_streams
  ADD COLUMN IF NOT EXISTS total_gifts_count integer NOT NULL DEFAULT 0;

-- total_gifts_value already exists per schema; ensure it's there
ALTER TABLE public.live_streams
  ADD COLUMN IF NOT EXISTS total_gifts_value numeric NOT NULL DEFAULT 0;

-- Create live_gifts table
CREATE TABLE IF NOT EXISTS public.live_gifts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  live_stream_id uuid NOT NULL REFERENCES public.live_streams(id) ON DELETE CASCADE,
  sender_id uuid NOT NULL,
  astrologer_id uuid NOT NULL REFERENCES public.astrologers(id) ON DELETE CASCADE,
  gift_type text NOT NULL,
  gift_amount numeric NOT NULL,
  astrologer_earning numeric NOT NULL DEFAULT 0,
  company_earning numeric NOT NULL DEFAULT 0,
  customer_note text,
  created_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT live_gifts_gift_type_check CHECK (gift_type IN ('star','rose','diamond','crown','moonlight','blessing')),
  CONSTRAINT live_gifts_note_len CHECK (customer_note IS NULL OR char_length(customer_note) <= 200)
);

CREATE INDEX IF NOT EXISTS idx_live_gifts_stream_created ON public.live_gifts (live_stream_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_live_gifts_astrologer ON public.live_gifts (astrologer_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_live_gifts_sender ON public.live_gifts (sender_id, created_at DESC);

-- Replica identity full for realtime
ALTER TABLE public.live_gifts REPLICA IDENTITY FULL;

-- Add to realtime publication
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_publication_tables
     WHERE pubname = 'supabase_realtime' AND tablename = 'live_gifts'
  ) THEN
    EXECUTE 'ALTER PUBLICATION supabase_realtime ADD TABLE public.live_gifts';
  END IF;
END $$;

-- RLS
ALTER TABLE public.live_gifts ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anyone reads live_gifts on live streams" ON public.live_gifts;
CREATE POLICY "anyone reads live_gifts on live streams"
  ON public.live_gifts FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM public.live_streams ls
       WHERE ls.id = live_gifts.live_stream_id AND ls.status = 'live'
    )
  );

DROP POLICY IF EXISTS "astrologer reads own gifts" ON public.live_gifts;
CREATE POLICY "astrologer reads own gifts"
  ON public.live_gifts FOR SELECT
  TO authenticated
  USING (
    astrologer_id IN (SELECT id FROM public.astrologers WHERE user_id = auth.uid())
  );

DROP POLICY IF EXISTS "sender reads own gifts" ON public.live_gifts;
CREATE POLICY "sender reads own gifts"
  ON public.live_gifts FOR SELECT
  TO authenticated
  USING (sender_id = auth.uid());

-- Note: we do NOT allow direct INSERT — clients must call send_live_gift_atomic RPC,
-- which is SECURITY DEFINER and validates everything. This prevents abuse.

-- Atomic RPC: send_live_gift_atomic
CREATE OR REPLACE FUNCTION public.send_live_gift_atomic(
  _live_stream_id uuid,
  _gift_type text,
  _customer_note text
) RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  _user_id uuid := auth.uid();
  _amount numeric;
  _astro_share numeric;
  _company_share numeric;
  _astrologer_id uuid;
  _astro_user_id uuid;
  _astro_name text;
  _stream_status text;
  _wallet_id uuid;
  _balance numeric;
  _new_balance numeric;
  _astro_wallet_id uuid;
  _astro_balance numeric;
  _astro_new_balance numeric;
  _gift_id uuid;
  _gift_label text;
  _note text;
BEGIN
  IF _user_id IS NULL THEN
    RAISE EXCEPTION 'Not authenticated' USING ERRCODE = '28000';
  END IF;

  -- Map gift_type → amount + label
  CASE _gift_type
    WHEN 'star'      THEN _amount := 21;   _gift_label := 'Star ⭐';
    WHEN 'rose'      THEN _amount := 51;   _gift_label := 'Rose 🌹';
    WHEN 'diamond'   THEN _amount := 101;  _gift_label := 'Diamond 💎';
    WHEN 'crown'     THEN _amount := 251;  _gift_label := 'Crown 👑';
    WHEN 'moonlight' THEN _amount := 501;  _gift_label := 'Moonlight 🌙';
    WHEN 'blessing'  THEN _amount := 1001; _gift_label := 'Blessing ✨';
    ELSE RAISE EXCEPTION 'Invalid gift type' USING ERRCODE = '22023';
  END CASE;

  _note := NULLIF(left(coalesce(_customer_note,''), 200), '');

  -- Validate stream is live, get astrologer
  SELECT ls.status, ls.astrologer_id, a.user_id, a.display_name
    INTO _stream_status, _astrologer_id, _astro_user_id, _astro_name
    FROM public.live_streams ls
    JOIN public.astrologers a ON a.id = ls.astrologer_id
    WHERE ls.id = _live_stream_id;

  IF _astrologer_id IS NULL THEN
    RAISE EXCEPTION 'Stream not found' USING ERRCODE = '22023';
  END IF;
  IF _stream_status <> 'live' THEN
    RAISE EXCEPTION 'Stream is no longer live' USING ERRCODE = '22023';
  END IF;

  _astro_share   := round(_amount * 0.30, 2);
  _company_share := round(_amount - _astro_share, 2);

  -- Lock & debit customer wallet
  SELECT id, balance INTO _wallet_id, _balance
    FROM public.wallets WHERE user_id = _user_id FOR UPDATE;
  IF _wallet_id IS NULL THEN
    RAISE EXCEPTION 'Wallet not found' USING ERRCODE = '22023';
  END IF;
  IF _balance < _amount THEN
    RAISE EXCEPTION 'Insufficient balance' USING ERRCODE = '22023';
  END IF;
  _new_balance := _balance - _amount;
  UPDATE public.wallets SET balance = _new_balance, updated_at = now() WHERE id = _wallet_id;

  INSERT INTO public.transactions (wallet_id, type, amount, description, balance_after)
  VALUES (_wallet_id, 'consultation_debit', _amount,
          'Live gift sent: ' || _gift_label || ' → ' || COALESCE(_astro_name, 'astrologer'),
          _new_balance);

  -- Credit astrologer 30%
  IF _astro_user_id IS NOT NULL AND _astro_share > 0 THEN
    SELECT id, balance INTO _astro_wallet_id, _astro_balance
      FROM public.wallets WHERE user_id = _astro_user_id FOR UPDATE;
    IF _astro_wallet_id IS NULL THEN
      INSERT INTO public.wallets (user_id, balance) VALUES (_astro_user_id, 0)
        RETURNING id, balance INTO _astro_wallet_id, _astro_balance;
    END IF;
    _astro_new_balance := _astro_balance + _astro_share;
    UPDATE public.wallets SET balance = _astro_new_balance, updated_at = now() WHERE id = _astro_wallet_id;
    INSERT INTO public.transactions (wallet_id, type, amount, description, balance_after)
    VALUES (_astro_wallet_id, 'consultation_credit', _astro_share,
            'Live gift received: ' || _gift_label || ' (30% share)', _astro_new_balance);

    INSERT INTO public.notifications (user_id, type, title, body, link)
    VALUES (_astro_user_id, 'gift',
            'You received a ' || _gift_label || ' on Live!',
            '+₹' || _astro_share::text || COALESCE(' — "' || _note || '"', ''),
            '/astrologer/astrolive');
  END IF;

  -- Insert gift record
  INSERT INTO public.live_gifts
    (live_stream_id, sender_id, astrologer_id, gift_type, gift_amount,
     astrologer_earning, company_earning, customer_note)
  VALUES (_live_stream_id, _user_id, _astrologer_id, _gift_type, _amount,
          _astro_share, _company_share, _note)
  RETURNING id INTO _gift_id;

  -- Update stream totals
  UPDATE public.live_streams
     SET total_gifts_count = total_gifts_count + 1,
         total_gifts_value = total_gifts_value + _amount
   WHERE id = _live_stream_id;

  RETURN jsonb_build_object(
    'ok', true,
    'gift_id', _gift_id,
    'gift_amount', _amount,
    'astrologer_earning', _astro_share,
    'company_earning', _company_share,
    'new_balance', _new_balance
  );
END;
$$;

-- Helper: top gifters for a stream (used by Phase 2A Task 2; safe to ship now)
CREATE OR REPLACE FUNCTION public.get_top_gifters_for_live(_stream_id uuid)
RETURNS TABLE(
  sender_id uuid,
  sender_name text,
  sender_avatar text,
  total_gifted numeric,
  gift_count bigint
)
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT g.sender_id,
         COALESCE(p.name, 'Guest') AS sender_name,
         p.avatar_url AS sender_avatar,
         SUM(g.gift_amount)::numeric AS total_gifted,
         COUNT(*)::bigint AS gift_count
    FROM public.live_gifts g
    LEFT JOIN public.profiles p ON p.id = g.sender_id
   WHERE g.live_stream_id = _stream_id
   GROUP BY g.sender_id, p.name, p.avatar_url
   ORDER BY total_gifted DESC
   LIMIT 10;
$$;