-- 1. Add media_type column
ALTER TABLE public.live_call_requests
  ADD COLUMN IF NOT EXISTS media_type text NOT NULL DEFAULT 'video'
  CHECK (media_type IN ('audio','video'));

-- 2. Replace request_live_call to accept media_type and apply 1.5x for video public
CREATE OR REPLACE FUNCTION public.request_live_call(
  _live_stream_id uuid,
  _request_type text,
  _media_type text DEFAULT 'video'
)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $function$
DECLARE
  _customer uuid := auth.uid();
  _stream record;
  _astro record;
  _base_rate numeric;
  _rate numeric;
  _min_minutes int;
  _hold numeric;
  _wallet_balance numeric;
  _existing uuid;
  _new_id uuid;
BEGIN
  IF _customer IS NULL THEN
    RETURN jsonb_build_object('ok', false, 'error', 'Not authenticated');
  END IF;
  IF _request_type NOT IN ('public','private') THEN
    RETURN jsonb_build_object('ok', false, 'error', 'Invalid request type');
  END IF;
  IF _media_type NOT IN ('audio','video') THEN
    _media_type := 'video';
  END IF;

  SELECT * INTO _stream FROM live_streams WHERE id = _live_stream_id;
  IF NOT FOUND OR _stream.status <> 'live' THEN
    RETURN jsonb_build_object('ok', false, 'error', 'Live stream not active');
  END IF;
  IF _stream.is_paused_for_private THEN
    RETURN jsonb_build_object('ok', false, 'error', 'Astrologer is in a private session, please wait');
  END IF;

  SELECT id, user_id, base_rate_per_min, discounted_rate_per_min, accepting_calls
    INTO _astro FROM astrologers WHERE id = _stream.astrologer_id;
  IF NOT FOUND OR COALESCE(_astro.accepting_calls, true) = false THEN
    RETURN jsonb_build_object('ok', false, 'error', 'Astrologer not accepting calls');
  END IF;

  _base_rate := COALESCE(_astro.discounted_rate_per_min, _astro.base_rate_per_min);
  -- Video calls are 1.5x the audio rate (premium tier)
  _rate := CASE WHEN _media_type = 'video' THEN ROUND(_base_rate * 1.5, 2) ELSE _base_rate END;
  _min_minutes := CASE WHEN _request_type = 'private' THEN 5 ELSE 2 END;
  _hold := _rate * _min_minutes;

  SELECT id INTO _existing FROM live_call_requests
   WHERE customer_id = _customer
     AND live_stream_id = _live_stream_id
     AND status IN ('pending','accepted')
   LIMIT 1;
  IF _existing IS NOT NULL THEN
    RETURN jsonb_build_object('ok', false, 'error', 'You already have a pending request');
  END IF;

  SELECT balance INTO _wallet_balance FROM wallets WHERE user_id = _customer FOR UPDATE;
  IF _wallet_balance IS NULL OR _wallet_balance < _hold THEN
    RETURN jsonb_build_object('ok', false, 'error',
      'Insufficient balance. Need at least ' || _min_minutes || ' minutes.');
  END IF;

  UPDATE wallets SET balance = balance - _hold, updated_at = now() WHERE user_id = _customer;

  INSERT INTO live_call_requests (
    live_stream_id, customer_id, astrologer_id, request_type,
    rate_per_min, hold_amount, status, media_type
  )
  VALUES (
    _live_stream_id, _customer, _stream.astrologer_id, _request_type,
    _rate, _hold, 'pending', _media_type
  )
  RETURNING id INTO _new_id;

  RETURN jsonb_build_object(
    'ok', true,
    'request_id', _new_id,
    'rate_per_min', _rate,
    'hold_amount', _hold,
    'media_type', _media_type
  );
END;
$function$;

-- 3. Unlike RPC
CREATE OR REPLACE FUNCTION public.unlike_live_stream(_stream_id uuid)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $function$
DECLARE _deleted int := 0;
BEGIN
  IF auth.uid() IS NULL THEN RAISE EXCEPTION 'Not authenticated' USING ERRCODE='28000'; END IF;
  DELETE FROM public.live_likes WHERE live_stream_id = _stream_id AND user_id = auth.uid();
  GET DIAGNOSTICS _deleted = ROW_COUNT;
  IF _deleted > 0 THEN
    UPDATE public.live_streams SET total_likes = GREATEST(0, total_likes - 1) WHERE id = _stream_id;
  END IF;
  RETURN jsonb_build_object('ok', true, 'removed', _deleted > 0);
END;
$function$;

-- 4. Per-minute live-call billing: debits one minute's rate from customer wallet,
-- credits astrologer their share, and ends the call gracefully when balance runs out.
CREATE OR REPLACE FUNCTION public.bill_live_call_minute(_request_id uuid)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $function$
DECLARE
  r record;
  _astro_user uuid;
  _astro_name text;
  _share_pct numeric;
  _astro_share numeric;
  _company_share numeric;
  _wallet_id uuid;
  _balance numeric;
  _new_balance numeric;
  _astro_wallet uuid;
  _astro_balance numeric;
  _astro_new numeric;
  _caller uuid := auth.uid();
BEGIN
  IF _caller IS NULL THEN RAISE EXCEPTION 'Not authenticated' USING ERRCODE='28000'; END IF;

  SELECT * INTO r FROM public.live_call_requests WHERE id = _request_id FOR UPDATE;
  IF r IS NULL OR r.status <> 'accepted' THEN
    RETURN jsonb_build_object('ok', false, 'error', 'Call not active');
  END IF;
  IF r.customer_id <> _caller THEN
    RAISE EXCEPTION 'Forbidden' USING ERRCODE='42501';
  END IF;

  SELECT user_id, display_name INTO _astro_user, _astro_name
    FROM public.astrologers WHERE id = r.astrologer_id;

  SELECT astrologer_share_percent INTO _share_pct FROM public.platform_settings WHERE id = 1;
  _share_pct := COALESCE(_share_pct, 30);
  _astro_share := ROUND(r.rate_per_min * _share_pct / 100.0, 2);
  _company_share := ROUND(r.rate_per_min - _astro_share, 2);

  SELECT id, balance INTO _wallet_id, _balance
    FROM public.wallets WHERE user_id = r.customer_id FOR UPDATE;
  IF _wallet_id IS NULL THEN
    RETURN jsonb_build_object('ok', false, 'error', 'Wallet missing', 'auto_end', true);
  END IF;

  -- Not enough for a full minute: signal caller to end the call
  IF _balance < r.rate_per_min THEN
    RETURN jsonb_build_object('ok', false, 'error', 'Insufficient balance', 'auto_end', true, 'balance', _balance);
  END IF;

  _new_balance := _balance - r.rate_per_min;
  UPDATE public.wallets SET balance = _new_balance, updated_at = now() WHERE id = _wallet_id;

  INSERT INTO public.transactions (wallet_id, type, amount, description, balance_after)
  VALUES (_wallet_id, 'call_charge', r.rate_per_min,
          'Live ' || r.request_type || ' ' || COALESCE(r.media_type,'video') || ' (1 min) with ' || COALESCE(_astro_name,'astrologer'),
          _new_balance);

  -- Credit astrologer
  IF _astro_user IS NOT NULL AND _astro_share > 0 THEN
    SELECT id, balance INTO _astro_wallet, _astro_balance
      FROM public.wallets WHERE user_id = _astro_user FOR UPDATE;
    IF _astro_wallet IS NULL THEN
      INSERT INTO public.wallets (user_id, balance) VALUES (_astro_user, 0)
        RETURNING id, balance INTO _astro_wallet, _astro_balance;
    END IF;
    _astro_new := _astro_balance + _astro_share;
    UPDATE public.wallets SET balance = _astro_new, updated_at = now() WHERE id = _astro_wallet;
    INSERT INTO public.transactions (wallet_id, type, amount, description, balance_after)
    VALUES (_astro_wallet, 'consultation_credit', _astro_share,
            'Earnings (' || _share_pct::int || '%) — live ' || r.request_type || ' ' || COALESCE(r.media_type,'video'),
            _astro_new);
  END IF;

  -- Bookkeeping on the request row
  UPDATE public.live_call_requests
     SET total_cost = COALESCE(total_cost,0) + r.rate_per_min,
         astrologer_earning = COALESCE(astrologer_earning,0) + _astro_share,
         company_earning = COALESCE(company_earning,0) + _company_share
   WHERE id = _request_id;

  RETURN jsonb_build_object(
    'ok', true,
    'charged', r.rate_per_min,
    'new_balance', _new_balance
  );
END;
$function$;

-- end_live_call already handles final settlement; per-minute billing is additive.
-- We update its description-side semantics in the next step in code (no SQL needed there).