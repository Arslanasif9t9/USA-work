-- Astrologers table
CREATE TABLE public.astrologers (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID UNIQUE,
  display_name TEXT NOT NULL,
  bio TEXT,
  avatar_url TEXT,
  specializations TEXT[] NOT NULL DEFAULT '{}',
  languages TEXT[] NOT NULL DEFAULT '{}',
  experience_years INTEGER NOT NULL DEFAULT 0,
  base_rate_per_min NUMERIC(10,2) NOT NULL,
  discounted_rate_per_min NUMERIC(10,2),
  rating_avg NUMERIC(2,1) NOT NULL DEFAULT 0.0,
  rating_count INTEGER NOT NULL DEFAULT 0,
  follower_count INTEGER NOT NULL DEFAULT 0,
  status TEXT NOT NULL DEFAULT 'offline' CHECK (status IN ('online','offline','busy')),
  is_featured BOOLEAN NOT NULL DEFAULT FALSE,
  is_ai BOOLEAN NOT NULL DEFAULT FALSE,
  first_chat_free BOOLEAN NOT NULL DEFAULT FALSE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE public.astrologer_availability (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  astrologer_id UUID NOT NULL REFERENCES public.astrologers(id) ON DELETE CASCADE,
  day_of_week INTEGER NOT NULL CHECK (day_of_week BETWEEN 0 AND 6),
  start_time TIME NOT NULL,
  end_time TIME NOT NULL,
  timezone TEXT NOT NULL DEFAULT 'Asia/Kolkata'
);

CREATE TABLE public.astrologer_specializations (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  astrologer_id UUID NOT NULL REFERENCES public.astrologers(id) ON DELETE CASCADE,
  specialization TEXT NOT NULL CHECK (specialization IN (
    'vedic','kp_system','lal_kitab','numerology','tarot',
    'marriage_matching','vastu','reiki','feng_shui','horary','nadi'
  ))
);

CREATE INDEX idx_astrologers_status_rating ON public.astrologers(status, rating_avg DESC);
CREATE INDEX idx_astrologers_rate ON public.astrologers(discounted_rate_per_min ASC);
CREATE INDEX idx_astrologers_featured ON public.astrologers(is_featured) WHERE is_featured = TRUE;
CREATE INDEX idx_specializations ON public.astrologer_specializations(specialization, astrologer_id);

ALTER TABLE public.astrologers ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.astrologer_availability ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.astrologer_specializations ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Public can view active astrologers" ON public.astrologers
  FOR SELECT USING (status IN ('online','busy') OR is_featured = TRUE);

CREATE POLICY "Astrologers can update own profile" ON public.astrologers
  FOR UPDATE USING (auth.uid() = user_id);

CREATE POLICY "Public can view availability" ON public.astrologer_availability
  FOR SELECT USING (TRUE);

CREATE POLICY "Public can view specializations" ON public.astrologer_specializations
  FOR SELECT USING (TRUE);

-- updated_at trigger
CREATE TRIGGER update_astrologers_updated_at
BEFORE UPDATE ON public.astrologers
FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- Enable realtime
ALTER TABLE public.astrologers REPLICA IDENTITY FULL;
ALTER PUBLICATION supabase_realtime ADD TABLE public.astrologers;

-- Seed sample astrologers so the directory has content to display
INSERT INTO public.astrologers
  (display_name, bio, avatar_url, specializations, languages, experience_years,
   base_rate_per_min, discounted_rate_per_min, rating_avg, rating_count, follower_count,
   status, is_featured, is_ai, first_chat_free)
VALUES
  ('Acharya Ravi Shastri', 'Vedic astrologer with 20+ years of experience guiding clients on career, marriage and life path.', NULL,
   ARRAY['vedic','marriage_matching'], ARRAY['Hindi','English'], 22,
   45.00, 30.00, 4.8, 1240, 5400, 'online', TRUE, FALSE, TRUE),
  ('Pandit Sunita Devi', 'KP system specialist focused on precise timing of life events.', NULL,
   ARRAY['kp_system','horary'], ARRAY['Hindi','English','Bhojpuri'], 15,
   55.00, 40.00, 4.7, 860, 3200, 'online', TRUE, FALSE, FALSE),
  ('Tarot Reader Meera', 'Intuitive tarot reader helping with love, career and personal growth.', NULL,
   ARRAY['tarot','numerology'], ARRAY['English','Hindi'], 8,
   35.00, 25.00, 4.6, 540, 2100, 'online', FALSE, FALSE, TRUE),
  ('Guru Hariprasad', 'Lal Kitab remedies expert - simple, practical solutions for daily life.', NULL,
   ARRAY['lal_kitab','vedic'], ARRAY['Hindi','Punjabi'], 30,
   60.00, 50.00, 4.9, 2100, 8900, 'busy', TRUE, FALSE, FALSE),
  ('Vastu Expert Anjali', 'Home and workplace harmony through ancient Vastu Shastra principles.', NULL,
   ARRAY['vastu','feng_shui'], ARRAY['English','Hindi','Marathi'], 12,
   40.00, 30.00, 4.5, 420, 1600, 'online', FALSE, FALSE, FALSE),
  ('Numerologist Karthik', 'Decode the numbers shaping your destiny - name, birthdate and beyond.', NULL,
   ARRAY['numerology'], ARRAY['English','Tamil','Hindi'], 10,
   30.00, 20.00, 4.4, 380, 1300, 'online', FALSE, FALSE, TRUE),
  ('AI Jyotish', 'AI-powered Vedic chart analysis available 24x7 for instant guidance.', NULL,
   ARRAY['vedic','numerology','tarot'], ARRAY['English','Hindi'], 0,
   15.00, 10.00, 4.3, 5200, 12000, 'online', TRUE, TRUE, TRUE),
  ('Reiki Master Pooja', 'Energy healing and chakra balancing for emotional well-being.', NULL,
   ARRAY['reiki'], ARRAY['English','Hindi','Gujarati'], 14,
   50.00, 35.00, 4.7, 670, 2400, 'online', FALSE, FALSE, FALSE),
  ('Nadi Reader Subramanian', 'Ancient Nadi leaf readings revealing past, present and future.', NULL,
   ARRAY['nadi','vedic'], ARRAY['Tamil','English'], 25,
   80.00, 60.00, 4.8, 920, 3700, 'offline', TRUE, FALSE, FALSE),
  ('Astrologer Rohan', 'Modern career and finance guidance through Vedic astrology.', NULL,
   ARRAY['vedic','kp_system'], ARRAY['English','Hindi','Marathi'], 7,
   25.00, 18.00, 4.2, 290, 950, 'online', FALSE, FALSE, TRUE),
  ('Marriage Expert Lata', 'Specialized in kundli matching and relationship harmony.', NULL,
   ARRAY['marriage_matching','vedic'], ARRAY['Hindi','English'], 18,
   45.00, 35.00, 4.6, 1100, 4200, 'online', FALSE, FALSE, FALSE),
  ('Feng Shui Consultant Wei', 'Bring prosperity and balance to your space with classical Feng Shui.', NULL,
   ARRAY['feng_shui','vastu'], ARRAY['English','Mandarin'], 11,
   55.00, 45.00, 4.5, 320, 1100, 'offline', TRUE, FALSE, FALSE);

-- Mirror specializations into the lookup table
INSERT INTO public.astrologer_specializations (astrologer_id, specialization)
SELECT a.id, unnest(a.specializations)
FROM public.astrologers a;