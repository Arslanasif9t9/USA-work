-- Extend transaction_type enum
ALTER TYPE public.transaction_type ADD VALUE IF NOT EXISTS 'call_hold';
ALTER TYPE public.transaction_type ADD VALUE IF NOT EXISTS 'call_hold_release';
ALTER TYPE public.transaction_type ADD VALUE IF NOT EXISTS 'call_charge';

-- Extend astrologers
ALTER TABLE public.astrologers
  ADD COLUMN IF NOT EXISTS phone_number text,
  ADD COLUMN IF NOT EXISTS is_online boolean NOT NULL DEFAULT false,
  ADD COLUMN IF NOT EXISTS accepting_calls boolean NOT NULL DEFAULT true;

DO $$ BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint WHERE conname = 'astrologers_phone_e164_chk'
  ) THEN
    ALTER TABLE public.astrologers
      ADD CONSTRAINT astrologers_phone_e164_chk
      CHECK (phone_number IS NULL OR phone_number ~ '^\+[1-9]\d{7,14}$');
  END IF;
END $$;

-- Extend profiles with phone_e164
ALTER TABLE public.profiles
  ADD COLUMN IF NOT EXISTS phone_e164 text;

DO $$ BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint WHERE conname = 'profiles_phone_e164_chk'
  ) THEN
    ALTER TABLE public.profiles
      ADD CONSTRAINT profiles_phone_e164_chk
      CHECK (phone_e164 IS NULL OR phone_e164 ~ '^\+[1-9]\d{7,14}$');
  END IF;
END $$;

-- call_sessions table
CREATE TABLE IF NOT EXISTS public.call_sessions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL,
  astrologer_id uuid NOT NULL REFERENCES public.astrologers(id) ON DELETE RESTRICT,
  birth_chart_id uuid REFERENCES public.birth_charts(id) ON DELETE SET NULL,
  per_minute_rate numeric NOT NULL,
  status text NOT NULL DEFAULT 'pending'
    CHECK (status IN ('pending','ringing_astrologer','ringing_user','connected','completed','failed','declined','no_answer','cancelled')),
  twilio_conference_sid text,
  twilio_user_call_sid text,
  twilio_astrologer_call_sid text,
  initiated_at timestamptz NOT NULL DEFAULT now(),
  connected_at timestamptz,
  ended_at timestamptz,
  duration_seconds integer NOT NULL DEFAULT 0,
  end_reason text,
  recording_sid text,
  recording_url text,
  wallet_hold_amount numeric NOT NULL,
  hold_released boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS call_sessions_user_idx ON public.call_sessions(user_id, created_at DESC);
CREATE INDEX IF NOT EXISTS call_sessions_astrologer_idx ON public.call_sessions(astrologer_id, created_at DESC);
CREATE INDEX IF NOT EXISTS call_sessions_status_idx ON public.call_sessions(status);
CREATE UNIQUE INDEX IF NOT EXISTS call_sessions_conference_sid_uniq
  ON public.call_sessions(twilio_conference_sid)
  WHERE twilio_conference_sid IS NOT NULL;

-- Astrologer-busy guard: at most one active session per astrologer
CREATE UNIQUE INDEX IF NOT EXISTS call_sessions_astrologer_active_uniq
  ON public.call_sessions(astrologer_id)
  WHERE status IN ('pending','ringing_astrologer','ringing_user','connected');

-- Add call_session_id to transactions
ALTER TABLE public.transactions
  ADD COLUMN IF NOT EXISTS call_session_id uuid REFERENCES public.call_sessions(id) ON DELETE SET NULL;

CREATE INDEX IF NOT EXISTS transactions_call_session_idx
  ON public.transactions(call_session_id) WHERE call_session_id IS NOT NULL;

-- RLS
ALTER TABLE public.call_sessions ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "users select own call_sessions" ON public.call_sessions;
CREATE POLICY "users select own call_sessions"
  ON public.call_sessions FOR SELECT
  USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "astrologers select own call_sessions" ON public.call_sessions;
CREATE POLICY "astrologers select own call_sessions"
  ON public.call_sessions FOR SELECT
  USING (astrologer_id IN (SELECT id FROM public.astrologers WHERE user_id = auth.uid()));

-- No insert/update/delete policies => only service role can write.

-- Atomic hold function
CREATE OR REPLACE FUNCTION public.hold_wallet_for_call(
  _user_id uuid,
  _amount numeric,
  _call_session_id uuid
) RETURNS numeric
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  _wallet_id uuid;
  _balance numeric;
  _new_balance numeric;
BEGIN
  IF _amount <= 0 THEN
    RAISE EXCEPTION 'Hold amount must be positive';
  END IF;

  SELECT id, balance INTO _wallet_id, _balance
    FROM public.wallets WHERE user_id = _user_id FOR UPDATE;

  IF _wallet_id IS NULL THEN
    RAISE EXCEPTION 'Wallet not found for user %', _user_id;
  END IF;

  IF _balance < _amount THEN
    RAISE EXCEPTION 'Insufficient balance: need %, have %', _amount, _balance
      USING ERRCODE = '22023';
  END IF;

  _new_balance := _balance - _amount;

  UPDATE public.wallets
    SET balance = _new_balance, updated_at = now()
    WHERE id = _wallet_id;

  INSERT INTO public.transactions
    (wallet_id, type, amount, description, balance_after, call_session_id)
  VALUES
    (_wallet_id, 'call_hold', _amount,
     'Call hold (2-min minimum)', _new_balance, _call_session_id);

  RETURN _new_balance;
END;
$$;

-- Release hold (idempotent)
CREATE OR REPLACE FUNCTION public.release_call_hold(_call_session_id uuid)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  _user_id uuid;
  _amount numeric;
  _already boolean;
  _wallet_id uuid;
  _balance numeric;
  _new_balance numeric;
BEGIN
  SELECT user_id, wallet_hold_amount, hold_released
    INTO _user_id, _amount, _already
    FROM public.call_sessions
    WHERE id = _call_session_id
    FOR UPDATE;

  IF _user_id IS NULL THEN
    RAISE EXCEPTION 'Call session not found';
  END IF;

  IF _already THEN
    RETURN; -- idempotent no-op
  END IF;

  SELECT id, balance INTO _wallet_id, _balance
    FROM public.wallets WHERE user_id = _user_id FOR UPDATE;

  IF _wallet_id IS NULL THEN
    RAISE EXCEPTION 'Wallet not found for user %', _user_id;
  END IF;

  _new_balance := _balance + _amount;

  UPDATE public.wallets
    SET balance = _new_balance, updated_at = now()
    WHERE id = _wallet_id;

  INSERT INTO public.transactions
    (wallet_id, type, amount, description, balance_after, call_session_id)
  VALUES
    (_wallet_id, 'call_hold_release', _amount,
     'Call hold released (call did not connect)', _new_balance, _call_session_id);

  UPDATE public.call_sessions
    SET hold_released = true
    WHERE id = _call_session_id;
END;
$$;