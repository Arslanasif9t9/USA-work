-- Drop old version (return type is changing)
DROP FUNCTION IF EXISTS public.get_top_gifters_for_live(uuid);

CREATE FUNCTION public.get_top_gifters_for_live(_stream_id uuid)
RETURNS TABLE(
  sender_id uuid,
  sender_name text,
  sender_avatar text,
  total_gifted numeric,
  gift_count bigint,
  top_gift_type text
)
LANGUAGE sql
STABLE SECURITY DEFINER
SET search_path TO 'public'
AS $$
  WITH agg AS (
    SELECT g.sender_id,
           SUM(g.gift_amount)::numeric AS total_gifted,
           COUNT(*)::bigint AS gift_count
      FROM public.live_gifts g
     WHERE g.live_stream_id = _stream_id
     GROUP BY g.sender_id
  ),
  top_type AS (
    SELECT DISTINCT ON (g.sender_id)
           g.sender_id, g.gift_type
      FROM public.live_gifts g
     WHERE g.live_stream_id = _stream_id
     ORDER BY g.sender_id, g.gift_amount DESC, g.created_at DESC
  )
  SELECT a.sender_id,
         COALESCE(p.name, 'Guest') AS sender_name,
         p.avatar_url AS sender_avatar,
         a.total_gifted,
         a.gift_count,
         t.gift_type AS top_gift_type
    FROM agg a
    LEFT JOIN public.profiles p ON p.id = a.sender_id
    LEFT JOIN top_type t ON t.sender_id = a.sender_id
   ORDER BY a.total_gifted DESC
   LIMIT 10;
$$;

CREATE OR REPLACE FUNCTION public.get_top_gifters_lifetime(_astrologer_id uuid, _time_range text)
RETURNS TABLE(
  sender_id uuid,
  sender_name text,
  sender_avatar text,
  total_gifted numeric,
  gift_count bigint,
  top_gift_type text
)
LANGUAGE plpgsql
STABLE SECURITY DEFINER
SET search_path TO 'public'
AS $$
DECLARE
  _since timestamptz;
BEGIN
  _since := CASE _time_range
    WHEN 'today'      THEN date_trunc('day', now())
    WHEN 'this_week'  THEN date_trunc('week', now())
    WHEN 'this_month' THEN date_trunc('month', now())
    ELSE 'epoch'::timestamptz
  END;

  RETURN QUERY
  WITH agg AS (
    SELECT g.sender_id,
           SUM(g.gift_amount)::numeric AS total_gifted,
           COUNT(*)::bigint AS gift_count
      FROM public.live_gifts g
     WHERE g.astrologer_id = _astrologer_id
       AND g.created_at >= _since
     GROUP BY g.sender_id
  ),
  top_type AS (
    SELECT DISTINCT ON (g.sender_id)
           g.sender_id, g.gift_type
      FROM public.live_gifts g
     WHERE g.astrologer_id = _astrologer_id
       AND g.created_at >= _since
     ORDER BY g.sender_id, g.gift_amount DESC, g.created_at DESC
  )
  SELECT a.sender_id,
         COALESCE(p.name, 'Guest') AS sender_name,
         p.avatar_url AS sender_avatar,
         a.total_gifted,
         a.gift_count,
         t.gift_type AS top_gift_type
    FROM agg a
    LEFT JOIN public.profiles p ON p.id = a.sender_id
    LEFT JOIN top_type t ON t.sender_id = a.sender_id
   ORDER BY a.total_gifted DESC
   LIMIT 10;
END;
$$;

CREATE OR REPLACE FUNCTION public.get_astrologer_gift_stats(_astrologer_id uuid, _time_range text)
RETURNS jsonb
LANGUAGE plpgsql
STABLE SECURITY DEFINER
SET search_path TO 'public'
AS $$
DECLARE
  _since timestamptz;
  _total_count bigint;
  _total_value numeric;
  _unique_gifters bigint;
  _avg_size numeric;
  _biggest jsonb;
  _breakdown jsonb;
BEGIN
  _since := CASE _time_range
    WHEN 'today'      THEN date_trunc('day', now())
    WHEN 'this_week'  THEN date_trunc('week', now())
    WHEN 'this_month' THEN date_trunc('month', now())
    ELSE 'epoch'::timestamptz
  END;

  SELECT COUNT(*)::bigint,
         COALESCE(SUM(gift_amount), 0)::numeric,
         COUNT(DISTINCT sender_id)::bigint,
         COALESCE(AVG(gift_amount), 0)::numeric
    INTO _total_count, _total_value, _unique_gifters, _avg_size
    FROM public.live_gifts
   WHERE astrologer_id = _astrologer_id
     AND created_at >= _since;

  SELECT jsonb_build_object(
           'amount', g.gift_amount,
           'gift_type', g.gift_type,
           'sender_id', g.sender_id,
           'sender_name', COALESCE(p.name, 'Guest'),
           'sender_avatar', p.avatar_url,
           'created_at', g.created_at
         )
    INTO _biggest
    FROM public.live_gifts g
    LEFT JOIN public.profiles p ON p.id = g.sender_id
   WHERE g.astrologer_id = _astrologer_id
     AND g.created_at >= _since
   ORDER BY g.gift_amount DESC, g.created_at DESC
   LIMIT 1;

  SELECT COALESCE(jsonb_agg(row), '[]'::jsonb)
    INTO _breakdown
    FROM (
      SELECT jsonb_build_object(
               'gift_type', gift_type,
               'count', COUNT(*),
               'total_value', SUM(gift_amount)::numeric
             ) AS row
        FROM public.live_gifts
       WHERE astrologer_id = _astrologer_id
         AND created_at >= _since
       GROUP BY gift_type
       ORDER BY SUM(gift_amount) DESC
    ) sub;

  RETURN jsonb_build_object(
    'total_gifts_received', _total_count,
    'total_gifts_value', _total_value,
    'unique_gifters', _unique_gifters,
    'average_gift_size', ROUND(_avg_size, 2),
    'biggest_single_gift', _biggest,
    'gift_breakdown', _breakdown
  );
END;
$$;