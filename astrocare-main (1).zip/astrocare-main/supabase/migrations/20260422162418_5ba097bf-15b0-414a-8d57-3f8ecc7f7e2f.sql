DROP TABLE IF EXISTS public.birth_charts CASCADE;

CREATE TABLE public.birth_charts (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  chart_name TEXT,
  birth_date DATE NOT NULL,
  birth_time TIME,
  time_unknown BOOLEAN NOT NULL DEFAULT FALSE,
  location_name TEXT NOT NULL,
  latitude NUMERIC(10,7) NOT NULL,
  longitude NUMERIC(10,7) NOT NULL,
  timezone TEXT NOT NULL,
  gender TEXT NOT NULL CHECK (gender IN ('Male','Female','Other')),
  chart_data JSONB NOT NULL DEFAULT '{}'::jsonb,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX birth_charts_user_id_idx ON public.birth_charts(user_id);

ALTER TABLE public.birth_charts ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users select own charts" ON public.birth_charts
  FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "Users insert own charts" ON public.birth_charts
  FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Users update own charts" ON public.birth_charts
  FOR UPDATE USING (auth.uid() = user_id);
CREATE POLICY "Users delete own charts" ON public.birth_charts
  FOR DELETE USING (auth.uid() = user_id);