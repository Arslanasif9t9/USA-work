-- Allow public read of all astrologers (directory is public-facing info)
DROP POLICY IF EXISTS "Public can view active astrologers" ON public.astrologers;

CREATE POLICY "Public can view all astrologers"
ON public.astrologers
FOR SELECT
USING (true);