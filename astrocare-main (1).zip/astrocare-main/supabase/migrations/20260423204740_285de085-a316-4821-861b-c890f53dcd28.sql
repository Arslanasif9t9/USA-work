
-- Add email column for notification routing
ALTER TABLE public.astrologer_payout_settings
  ADD COLUMN IF NOT EXISTS notification_email text;

-- Allow inserting notifications (for own row only)
DROP POLICY IF EXISTS "Users insert own notifications" ON public.notifications;
CREATE POLICY "Users insert own notifications"
  ON public.notifications FOR INSERT
  WITH CHECK (auth.uid() = user_id);

-- Withdrawal: deduct immediately + create pending request + notification
CREATE OR REPLACE FUNCTION public.request_withdrawal(
  _amount numeric,
  _method text,
  _upi_id text,
  _bank_name text,
  _bank_account text,
  _bank_ifsc text
) RETURNS jsonb
  LANGUAGE plpgsql SECURITY DEFINER SET search_path = public
AS $$
DECLARE
  _uid uuid := auth.uid();
  _wallet_id uuid;
  _balance numeric;
  _new_balance numeric;
  _req_id uuid;
BEGIN
  IF _uid IS NULL THEN
    RAISE EXCEPTION 'Not authenticated' USING ERRCODE = '28000';
  END IF;
  IF _amount IS NULL OR _amount < 200 THEN
    RAISE EXCEPTION 'Minimum withdrawal is 200' USING ERRCODE = '22023';
  END IF;

  SELECT id, balance INTO _wallet_id, _balance
    FROM public.wallets WHERE user_id = _uid FOR UPDATE;
  IF _wallet_id IS NULL THEN
    RAISE EXCEPTION 'Wallet not found';
  END IF;
  IF _balance < _amount THEN
    RAISE EXCEPTION 'Insufficient balance: have %, need %', _balance, _amount USING ERRCODE = '22023';
  END IF;

  _new_balance := _balance - _amount;
  UPDATE public.wallets SET balance = _new_balance, updated_at = now() WHERE id = _wallet_id;

  INSERT INTO public.transactions (wallet_id, type, amount, description, balance_after)
  VALUES (_wallet_id, 'consultation_debit', _amount, 'Withdrawal request (pending admin)', _new_balance);

  INSERT INTO public.withdrawal_requests
    (astrologer_user_id, amount, method, upi_id, bank_name, bank_account, bank_ifsc, status)
  VALUES (_uid, _amount, _method, _upi_id, _bank_name, _bank_account, _bank_ifsc, 'pending')
  RETURNING id INTO _req_id;

  INSERT INTO public.notifications (user_id, type, title, body, link)
  VALUES (_uid, 'withdrawal',
          'Withdrawal request submitted',
          'Your withdrawal of ₹' || _amount::text || ' is pending admin approval.',
          '/astrologer/earnings');

  RETURN jsonb_build_object('ok', true, 'request_id', _req_id, 'new_balance', _new_balance);
END;
$$;
