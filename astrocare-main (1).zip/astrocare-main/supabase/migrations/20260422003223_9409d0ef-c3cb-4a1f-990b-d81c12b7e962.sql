
-- 1. Add consultation_minutes to profiles
ALTER TABLE public.profiles
  ADD COLUMN IF NOT EXISTS consultation_minutes integer NOT NULL DEFAULT 0;

-- 2. Extend transaction_type enum for consultation credits + spends
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_enum WHERE enumlabel = 'consultation_credit'
                 AND enumtypid = 'public.transaction_type'::regtype) THEN
    ALTER TYPE public.transaction_type ADD VALUE 'consultation_credit';
  END IF;
END $$;
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_enum WHERE enumlabel = 'consultation_minute_spend'
                 AND enumtypid = 'public.transaction_type'::regtype) THEN
    ALTER TYPE public.transaction_type ADD VALUE 'consultation_minute_spend';
  END IF;
END $$;

-- 3. user_purchases table (future-ready for premium reports etc.)
CREATE TABLE IF NOT EXISTS public.user_purchases (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL,
  product_id text NOT NULL,
  product_type text NOT NULL,
  stripe_payment_id text,
  purchased_at timestamptz NOT NULL DEFAULT now(),
  metadata jsonb NOT NULL DEFAULT '{}'::jsonb,
  UNIQUE (user_id, stripe_payment_id, product_id)
);
CREATE INDEX IF NOT EXISTS idx_user_purchases_user ON public.user_purchases(user_id);
ALTER TABLE public.user_purchases ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Users can read own purchases"
  ON public.user_purchases FOR SELECT
  USING (user_id = auth.uid());

-- 4. Webhook event idempotency table
CREATE TABLE IF NOT EXISTS public.webhook_events (
  event_id text PRIMARY KEY,
  event_type text NOT NULL,
  environment text NOT NULL,
  processed_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE public.webhook_events ENABLE ROW LEVEL SECURITY;
-- No policies: only service role can read/write.

-- 5. Reshape pack_definitions to support consultation packs
ALTER TABLE public.pack_definitions
  ADD COLUMN IF NOT EXISTS minutes_amount integer,
  ADD COLUMN IF NOT EXISTS description text;

-- 6. Atomic wallet credit function (used by webhook)
CREATE OR REPLACE FUNCTION public.credit_wallet(
  _user_id uuid,
  _amount numeric,
  _description text,
  _stripe_payment_id text
)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  _wallet_id uuid;
  _new_balance numeric;
BEGIN
  IF _amount <= 0 THEN
    RAISE EXCEPTION 'Amount must be positive';
  END IF;

  UPDATE public.wallets
    SET balance = balance + _amount,
        updated_at = now()
    WHERE user_id = _user_id
    RETURNING id, balance INTO _wallet_id, _new_balance;

  IF _wallet_id IS NULL THEN
    RAISE EXCEPTION 'Wallet not found for user %', _user_id;
  END IF;

  INSERT INTO public.transactions
    (wallet_id, type, amount, description, stripe_payment_id, balance_after)
  VALUES
    (_wallet_id, 'top_up', _amount, _description, _stripe_payment_id, _new_balance);
END;
$$;

-- 7. Atomic consultation minutes credit
CREATE OR REPLACE FUNCTION public.credit_consultation_minutes(
  _user_id uuid,
  _minutes integer,
  _description text,
  _stripe_payment_id text
)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  _wallet_id uuid;
  _balance numeric;
BEGIN
  IF _minutes <= 0 THEN
    RAISE EXCEPTION 'Minutes must be positive';
  END IF;

  UPDATE public.profiles
    SET consultation_minutes = consultation_minutes + _minutes,
        updated_at = now()
    WHERE id = _user_id;

  IF NOT FOUND THEN
    RAISE EXCEPTION 'Profile not found for user %', _user_id;
  END IF;

  -- log under existing wallet for unified history
  SELECT id, balance INTO _wallet_id, _balance
    FROM public.wallets WHERE user_id = _user_id;
  IF _wallet_id IS NULL THEN
    RAISE EXCEPTION 'Wallet not found for user %', _user_id;
  END IF;

  INSERT INTO public.transactions
    (wallet_id, type, amount, description, stripe_payment_id, balance_after)
  VALUES
    (_wallet_id, 'consultation_credit', _minutes, _description, _stripe_payment_id, _balance);
END;
$$;

-- 8. Spend consultation time: prefer minutes, fall back to wallet ₹.
-- Future consultation feature will call this. Returns a JSON receipt.
CREATE OR REPLACE FUNCTION public.spend_consultation_time(
  _user_id uuid,
  _minutes integer,
  _per_minute_rate numeric,   -- ₹ per minute, fallback price
  _description text
)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  _available_min integer;
  _minutes_used integer := 0;
  _rupees_used numeric := 0;
  _wallet_id uuid;
  _balance numeric;
  _new_balance numeric;
BEGIN
  IF _minutes <= 0 OR _per_minute_rate < 0 THEN
    RAISE EXCEPTION 'Invalid arguments';
  END IF;

  -- Lock the profile + wallet rows to avoid races during a live call
  SELECT consultation_minutes INTO _available_min
    FROM public.profiles WHERE id = _user_id FOR UPDATE;
  IF _available_min IS NULL THEN
    RAISE EXCEPTION 'Profile not found';
  END IF;

  SELECT id, balance INTO _wallet_id, _balance
    FROM public.wallets WHERE user_id = _user_id FOR UPDATE;
  IF _wallet_id IS NULL THEN
    RAISE EXCEPTION 'Wallet not found';
  END IF;

  -- 1. consume from minute pack first
  _minutes_used := LEAST(_available_min, _minutes);
  IF _minutes_used > 0 THEN
    UPDATE public.profiles
      SET consultation_minutes = consultation_minutes - _minutes_used,
          updated_at = now()
      WHERE id = _user_id;

    INSERT INTO public.transactions
      (wallet_id, type, amount, description, balance_after)
    VALUES
      (_wallet_id, 'consultation_minute_spend', _minutes_used,
       _description || ' (' || _minutes_used || ' min from pack)', _balance);
  END IF;

  -- 2. fall back to wallet ₹ for remaining minutes
  IF _minutes - _minutes_used > 0 THEN
    _rupees_used := (_minutes - _minutes_used) * _per_minute_rate;
    IF _balance < _rupees_used THEN
      RAISE EXCEPTION 'Insufficient wallet balance: need ₹%, have ₹%',
        _rupees_used, _balance USING ERRCODE = '22023';
    END IF;
    _new_balance := _balance - _rupees_used;
    UPDATE public.wallets
      SET balance = _new_balance, updated_at = now()
      WHERE id = _wallet_id;
    INSERT INTO public.transactions
      (wallet_id, type, amount, description, balance_after)
    VALUES
      (_wallet_id, 'consultation_debit', _rupees_used,
       _description || ' (₹' || _rupees_used || ' from wallet)', _new_balance);
  END IF;

  RETURN jsonb_build_object(
    'minutes_used', _minutes_used,
    'rupees_used', _rupees_used,
    'wallet_balance_after', COALESCE(_new_balance, _balance),
    'minutes_remaining', _available_min - _minutes_used
  );
END;
$$;

-- 9. Update handle_new_user to set consultation_minutes default (no behavior change, just safety)
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  new_profile_id UUID;
BEGIN
  INSERT INTO public.profiles (id, name, email, phone, consultation_minutes)
  VALUES (
    NEW.id,
    COALESCE(NEW.raw_user_meta_data->>'name', ''),
    NEW.email,
    NEW.phone,
    0
  )
  RETURNING id INTO new_profile_id;

  INSERT INTO public.wallets (user_id, balance) VALUES (new_profile_id, 0);
  RETURN NEW;
END;
$$;
