do $$
declare jid bigint;
begin
  select jobid into jid from cron.job where jobname = 'expire-stale-astrologer-presence';
  if jid is not null then perform cron.unschedule(jid); end if;
end $$;

create or replace function public.expire_stale_presence()
returns void
language sql
security definer
set search_path = public
as $$
  select 1 where false;
$$;