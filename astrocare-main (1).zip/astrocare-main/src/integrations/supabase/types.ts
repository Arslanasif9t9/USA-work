export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.5"
  }
  public: {
    Tables: {
      admin_activity_log: {
        Row: {
          action: string
          admin_id: string | null
          created_at: string
          details: Json
          id: string
          target_id: string | null
          target_type: string | null
        }
        Insert: {
          action: string
          admin_id?: string | null
          created_at?: string
          details?: Json
          id?: string
          target_id?: string | null
          target_type?: string | null
        }
        Update: {
          action?: string
          admin_id?: string | null
          created_at?: string
          details?: Json
          id?: string
          target_id?: string | null
          target_type?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "admin_activity_log_admin_id_fkey"
            columns: ["admin_id"]
            isOneToOne: false
            referencedRelation: "admin_users"
            referencedColumns: ["id"]
          },
        ]
      }
      admin_users: {
        Row: {
          can_directly_adjust_wallet: boolean
          created_at: string
          created_by: string | null
          email: string
          full_name: string
          id: string
          is_active: boolean
          last_login_at: string | null
          max_wallet_adjustment: number | null
          permissions: Json
          role: string
          user_id: string
        }
        Insert: {
          can_directly_adjust_wallet?: boolean
          created_at?: string
          created_by?: string | null
          email: string
          full_name?: string
          id?: string
          is_active?: boolean
          last_login_at?: string | null
          max_wallet_adjustment?: number | null
          permissions?: Json
          role: string
          user_id: string
        }
        Update: {
          can_directly_adjust_wallet?: boolean
          created_at?: string
          created_by?: string | null
          email?: string
          full_name?: string
          id?: string
          is_active?: boolean
          last_login_at?: string | null
          max_wallet_adjustment?: number | null
          permissions?: Json
          role?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "admin_users_created_by_fkey"
            columns: ["created_by"]
            isOneToOne: false
            referencedRelation: "admin_users"
            referencedColumns: ["id"]
          },
        ]
      }
      announcements: {
        Row: {
          audience: string
          body: string
          created_at: string
          created_by: string | null
          delivered: boolean
          display_type: string
          expires_at: string | null
          id: string
          is_active: boolean
          scheduled_at: string
          target_user_id: string | null
          title: string
        }
        Insert: {
          audience?: string
          body: string
          created_at?: string
          created_by?: string | null
          delivered?: boolean
          display_type?: string
          expires_at?: string | null
          id?: string
          is_active?: boolean
          scheduled_at?: string
          target_user_id?: string | null
          title: string
        }
        Update: {
          audience?: string
          body?: string
          created_at?: string
          created_by?: string | null
          delivered?: boolean
          display_type?: string
          expires_at?: string | null
          id?: string
          is_active?: boolean
          scheduled_at?: string
          target_user_id?: string | null
          title?: string
        }
        Relationships: []
      }
      ashtakavarga_reports: {
        Row: {
          bhinna_data: Json
          birth_chart_id: string
          computed_metrics: Json
          created_at: string
          id: string
          language: string
          sarva_data: Json
          source: string
        }
        Insert: {
          bhinna_data: Json
          birth_chart_id: string
          computed_metrics: Json
          created_at?: string
          id?: string
          language?: string
          sarva_data: Json
          source?: string
        }
        Update: {
          bhinna_data?: Json
          birth_chart_id?: string
          computed_metrics?: Json
          created_at?: string
          id?: string
          language?: string
          sarva_data?: Json
          source?: string
        }
        Relationships: [
          {
            foreignKeyName: "ashtakavarga_reports_birth_chart_id_fkey"
            columns: ["birth_chart_id"]
            isOneToOne: false
            referencedRelation: "birth_charts"
            referencedColumns: ["id"]
          },
        ]
      }
      astrologer_availability: {
        Row: {
          astrologer_id: string
          day_of_week: number
          end_time: string
          id: string
          start_time: string
          timezone: string
        }
        Insert: {
          astrologer_id: string
          day_of_week: number
          end_time: string
          id?: string
          start_time: string
          timezone?: string
        }
        Update: {
          astrologer_id?: string
          day_of_week?: number
          end_time?: string
          id?: string
          start_time?: string
          timezone?: string
        }
        Relationships: [
          {
            foreignKeyName: "astrologer_availability_astrologer_id_fkey"
            columns: ["astrologer_id"]
            isOneToOne: false
            referencedRelation: "astrologers"
            referencedColumns: ["id"]
          },
        ]
      }
      astrologer_payout_settings: {
        Row: {
          bank_account: string | null
          bank_ifsc: string | null
          bank_name: string | null
          notification_email: string | null
          notify_earnings: boolean
          notify_new_request: boolean
          notify_review: boolean
          notify_session_reminder: boolean
          updated_at: string
          upi_id: string | null
          user_id: string
        }
        Insert: {
          bank_account?: string | null
          bank_ifsc?: string | null
          bank_name?: string | null
          notification_email?: string | null
          notify_earnings?: boolean
          notify_new_request?: boolean
          notify_review?: boolean
          notify_session_reminder?: boolean
          updated_at?: string
          upi_id?: string | null
          user_id: string
        }
        Update: {
          bank_account?: string | null
          bank_ifsc?: string | null
          bank_name?: string | null
          notification_email?: string | null
          notify_earnings?: boolean
          notify_new_request?: boolean
          notify_review?: boolean
          notify_session_reminder?: boolean
          updated_at?: string
          upi_id?: string | null
          user_id?: string
        }
        Relationships: []
      }
      astrologer_specializations: {
        Row: {
          astrologer_id: string
          id: string
          specialization: string
        }
        Insert: {
          astrologer_id: string
          id?: string
          specialization: string
        }
        Update: {
          astrologer_id?: string
          id?: string
          specialization?: string
        }
        Relationships: [
          {
            foreignKeyName: "astrologer_specializations_astrologer_id_fkey"
            columns: ["astrologer_id"]
            isOneToOne: false
            referencedRelation: "astrologers"
            referencedColumns: ["id"]
          },
        ]
      }
      astrologers: {
        Row: {
          accepting_calls: boolean
          accepting_chat: boolean
          approval_status: string
          avatar_url: string | null
          base_rate_per_min: number
          bio: string | null
          chat_rate_per_min: number
          created_at: string
          discounted_rate_per_min: number | null
          display_name: string
          education: string | null
          experience_years: number
          first_chat_free: boolean
          focus_area: string | null
          follower_count: number
          id: string
          is_ai: boolean
          is_chat_online: boolean
          is_featured: boolean
          is_online: boolean
          languages: string[]
          last_seen_at: string | null
          phone_number: string | null
          phone_verified: boolean
          phone_verified_at: string | null
          rating_avg: number
          rating_count: number
          rejection_reason: string | null
          slug: string
          specializations: string[]
          status: string
          systems_known: string[]
          total_consultations: number
          updated_at: string
          user_id: string | null
        }
        Insert: {
          accepting_calls?: boolean
          accepting_chat?: boolean
          approval_status?: string
          avatar_url?: string | null
          base_rate_per_min: number
          bio?: string | null
          chat_rate_per_min?: number
          created_at?: string
          discounted_rate_per_min?: number | null
          display_name: string
          education?: string | null
          experience_years?: number
          first_chat_free?: boolean
          focus_area?: string | null
          follower_count?: number
          id?: string
          is_ai?: boolean
          is_chat_online?: boolean
          is_featured?: boolean
          is_online?: boolean
          languages?: string[]
          last_seen_at?: string | null
          phone_number?: string | null
          phone_verified?: boolean
          phone_verified_at?: string | null
          rating_avg?: number
          rating_count?: number
          rejection_reason?: string | null
          slug: string
          specializations?: string[]
          status?: string
          systems_known?: string[]
          total_consultations?: number
          updated_at?: string
          user_id?: string | null
        }
        Update: {
          accepting_calls?: boolean
          accepting_chat?: boolean
          approval_status?: string
          avatar_url?: string | null
          base_rate_per_min?: number
          bio?: string | null
          chat_rate_per_min?: number
          created_at?: string
          discounted_rate_per_min?: number | null
          display_name?: string
          education?: string | null
          experience_years?: number
          first_chat_free?: boolean
          focus_area?: string | null
          follower_count?: number
          id?: string
          is_ai?: boolean
          is_chat_online?: boolean
          is_featured?: boolean
          is_online?: boolean
          languages?: string[]
          last_seen_at?: string | null
          phone_number?: string | null
          phone_verified?: boolean
          phone_verified_at?: string | null
          rating_avg?: number
          rating_count?: number
          rejection_reason?: string | null
          slug?: string
          specializations?: string[]
          status?: string
          systems_known?: string[]
          total_consultations?: number
          updated_at?: string
          user_id?: string | null
        }
        Relationships: []
      }
      birth_charts: {
        Row: {
          birth_date: string
          birth_time: string | null
          chart_data: Json
          chart_name: string | null
          created_at: string
          gender: string
          id: string
          latitude: number
          location_name: string
          longitude: number
          recomputed_at: string | null
          source: string
          time_unknown: boolean
          timezone: string
          user_id: string
        }
        Insert: {
          birth_date: string
          birth_time?: string | null
          chart_data?: Json
          chart_name?: string | null
          created_at?: string
          gender: string
          id?: string
          latitude: number
          location_name: string
          longitude: number
          recomputed_at?: string | null
          source?: string
          time_unknown?: boolean
          timezone: string
          user_id: string
        }
        Update: {
          birth_date?: string
          birth_time?: string | null
          chart_data?: Json
          chart_name?: string | null
          created_at?: string
          gender?: string
          id?: string
          latitude?: number
          location_name?: string
          longitude?: number
          recomputed_at?: string | null
          source?: string
          time_unknown?: boolean
          timezone?: string
          user_id?: string
        }
        Relationships: []
      }
      call_sessions: {
        Row: {
          astrologer_earning: number
          astrologer_id: string
          birth_chart_id: string | null
          company_earning: number
          connected_at: string | null
          created_at: string
          duration_seconds: number
          end_reason: string | null
          ended_at: string | null
          ended_by: string | null
          hold_released: boolean
          id: string
          initiated_at: string
          per_minute_rate: number
          recording_sid: string | null
          recording_url: string | null
          status: string
          total_cost: number
          twilio_astrologer_call_sid: string | null
          twilio_conference_sid: string | null
          twilio_user_call_sid: string | null
          user_id: string
          wallet_hold_amount: number
        }
        Insert: {
          astrologer_earning?: number
          astrologer_id: string
          birth_chart_id?: string | null
          company_earning?: number
          connected_at?: string | null
          created_at?: string
          duration_seconds?: number
          end_reason?: string | null
          ended_at?: string | null
          ended_by?: string | null
          hold_released?: boolean
          id?: string
          initiated_at?: string
          per_minute_rate: number
          recording_sid?: string | null
          recording_url?: string | null
          status?: string
          total_cost?: number
          twilio_astrologer_call_sid?: string | null
          twilio_conference_sid?: string | null
          twilio_user_call_sid?: string | null
          user_id: string
          wallet_hold_amount: number
        }
        Update: {
          astrologer_earning?: number
          astrologer_id?: string
          birth_chart_id?: string | null
          company_earning?: number
          connected_at?: string | null
          created_at?: string
          duration_seconds?: number
          end_reason?: string | null
          ended_at?: string | null
          ended_by?: string | null
          hold_released?: boolean
          id?: string
          initiated_at?: string
          per_minute_rate?: number
          recording_sid?: string | null
          recording_url?: string | null
          status?: string
          total_cost?: number
          twilio_astrologer_call_sid?: string | null
          twilio_conference_sid?: string | null
          twilio_user_call_sid?: string | null
          user_id?: string
          wallet_hold_amount?: number
        }
        Relationships: [
          {
            foreignKeyName: "call_sessions_astrologer_id_fkey"
            columns: ["astrologer_id"]
            isOneToOne: false
            referencedRelation: "astrologers"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "call_sessions_birth_chart_id_fkey"
            columns: ["birth_chart_id"]
            isOneToOne: false
            referencedRelation: "birth_charts"
            referencedColumns: ["id"]
          },
        ]
      }
      chat_messages: {
        Row: {
          content: string
          created_at: string
          id: string
          sender_id: string
          sender_role: string
          session_id: string
        }
        Insert: {
          content: string
          created_at?: string
          id?: string
          sender_id: string
          sender_role: string
          session_id: string
        }
        Update: {
          content?: string
          created_at?: string
          id?: string
          sender_id?: string
          sender_role?: string
          session_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "chat_messages_session_id_fkey"
            columns: ["session_id"]
            isOneToOne: false
            referencedRelation: "chat_sessions"
            referencedColumns: ["id"]
          },
        ]
      }
      chat_sessions: {
        Row: {
          accepted_at: string | null
          astrologer_earning: number
          astrologer_id: string
          company_earning: number
          created_at: string
          duration_seconds: number
          end_reason: string | null
          ended_at: string | null
          ended_by: string | null
          hold_released: boolean
          id: string
          last_billed_at: string | null
          per_minute_rate: number
          requested_at: string
          status: string
          total_cost: number
          user_id: string
          wallet_hold_amount: number
        }
        Insert: {
          accepted_at?: string | null
          astrologer_earning?: number
          astrologer_id: string
          company_earning?: number
          created_at?: string
          duration_seconds?: number
          end_reason?: string | null
          ended_at?: string | null
          ended_by?: string | null
          hold_released?: boolean
          id?: string
          last_billed_at?: string | null
          per_minute_rate: number
          requested_at?: string
          status?: string
          total_cost?: number
          user_id: string
          wallet_hold_amount?: number
        }
        Update: {
          accepted_at?: string | null
          astrologer_earning?: number
          astrologer_id?: string
          company_earning?: number
          created_at?: string
          duration_seconds?: number
          end_reason?: string | null
          ended_at?: string | null
          ended_by?: string | null
          hold_released?: boolean
          id?: string
          last_billed_at?: string | null
          per_minute_rate?: number
          requested_at?: string
          status?: string
          total_cost?: number
          user_id?: string
          wallet_hold_amount?: number
        }
        Relationships: [
          {
            foreignKeyName: "chat_sessions_astrologer_id_fkey"
            columns: ["astrologer_id"]
            isOneToOne: false
            referencedRelation: "astrologers"
            referencedColumns: ["id"]
          },
        ]
      }
      dismissed_announcements: {
        Row: {
          announcement_id: string
          dismissed_at: string
          user_id: string
        }
        Insert: {
          announcement_id: string
          dismissed_at?: string
          user_id: string
        }
        Update: {
          announcement_id?: string
          dismissed_at?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "dismissed_announcements_announcement_id_fkey"
            columns: ["announcement_id"]
            isOneToOne: false
            referencedRelation: "announcements"
            referencedColumns: ["id"]
          },
        ]
      }
      entitlements: {
        Row: {
          created_at: string
          expires_at: string | null
          id: string
          kind: string
          metadata: Json
          product_id: string
          stripe_payment_id: string | null
          user_id: string
        }
        Insert: {
          created_at?: string
          expires_at?: string | null
          id?: string
          kind: string
          metadata?: Json
          product_id: string
          stripe_payment_id?: string | null
          user_id: string
        }
        Update: {
          created_at?: string
          expires_at?: string | null
          id?: string
          kind?: string
          metadata?: Json
          product_id?: string
          stripe_payment_id?: string | null
          user_id?: string
        }
        Relationships: []
      }
      favorite_astrologers: {
        Row: {
          astrologer_id: string
          created_at: string
          id: string
          user_id: string
        }
        Insert: {
          astrologer_id: string
          created_at?: string
          id?: string
          user_id: string
        }
        Update: {
          astrologer_id?: string
          created_at?: string
          id?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "favorite_astrologers_astrologer_id_fkey"
            columns: ["astrologer_id"]
            isOneToOne: false
            referencedRelation: "astrologers"
            referencedColumns: ["id"]
          },
        ]
      }
      gifts: {
        Row: {
          amount: number
          astrologer_earning: number
          astrologer_id: string
          company_earning: number
          created_at: string
          customer_note: string | null
          gift_type: string
          id: string
          message: string | null
          session_id: string | null
          user_id: string
        }
        Insert: {
          amount: number
          astrologer_earning?: number
          astrologer_id: string
          company_earning?: number
          created_at?: string
          customer_note?: string | null
          gift_type: string
          id?: string
          message?: string | null
          session_id?: string | null
          user_id: string
        }
        Update: {
          amount?: number
          astrologer_earning?: number
          astrologer_id?: string
          company_earning?: number
          created_at?: string
          customer_note?: string | null
          gift_type?: string
          id?: string
          message?: string | null
          session_id?: string | null
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "gifts_astrologer_id_fkey"
            columns: ["astrologer_id"]
            isOneToOne: false
            referencedRelation: "astrologers"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "gifts_session_id_fkey"
            columns: ["session_id"]
            isOneToOne: false
            referencedRelation: "chat_sessions"
            referencedColumns: ["id"]
          },
        ]
      }
      horoscope_cache: {
        Row: {
          content: string
          created_at: string
          date: string
          id: string
          sign: string
        }
        Insert: {
          content: string
          created_at?: string
          date: string
          id?: string
          sign: string
        }
        Update: {
          content?: string
          created_at?: string
          date?: string
          id?: string
          sign?: string
        }
        Relationships: []
      }
      live_call_requests: {
        Row: {
          accepted_at: string | null
          astrologer_earning: number
          astrologer_id: string
          company_earning: number
          customer_id: string
          duration_seconds: number
          ended_at: string | null
          ended_by: string | null
          hold_amount: number
          hold_released: boolean
          id: string
          linked_call_session_id: string | null
          live_stream_id: string
          media_type: string
          rate_per_min: number
          request_type: string
          requested_at: string
          responded_at: string | null
          status: string
          total_cost: number
        }
        Insert: {
          accepted_at?: string | null
          astrologer_earning?: number
          astrologer_id: string
          company_earning?: number
          customer_id: string
          duration_seconds?: number
          ended_at?: string | null
          ended_by?: string | null
          hold_amount?: number
          hold_released?: boolean
          id?: string
          linked_call_session_id?: string | null
          live_stream_id: string
          media_type?: string
          rate_per_min: number
          request_type: string
          requested_at?: string
          responded_at?: string | null
          status?: string
          total_cost?: number
        }
        Update: {
          accepted_at?: string | null
          astrologer_earning?: number
          astrologer_id?: string
          company_earning?: number
          customer_id?: string
          duration_seconds?: number
          ended_at?: string | null
          ended_by?: string | null
          hold_amount?: number
          hold_released?: boolean
          id?: string
          linked_call_session_id?: string | null
          live_stream_id?: string
          media_type?: string
          rate_per_min?: number
          request_type?: string
          requested_at?: string
          responded_at?: string | null
          status?: string
          total_cost?: number
        }
        Relationships: [
          {
            foreignKeyName: "live_call_requests_astrologer_id_fkey"
            columns: ["astrologer_id"]
            isOneToOne: false
            referencedRelation: "astrologers"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "live_call_requests_linked_call_session_id_fkey"
            columns: ["linked_call_session_id"]
            isOneToOne: false
            referencedRelation: "call_sessions"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "live_call_requests_live_stream_id_fkey"
            columns: ["live_stream_id"]
            isOneToOne: false
            referencedRelation: "live_streams"
            referencedColumns: ["id"]
          },
        ]
      }
      live_comments: {
        Row: {
          comment_text: string
          created_at: string
          id: string
          is_deleted: boolean
          is_host: boolean
          is_pinned: boolean
          live_stream_id: string
          user_avatar: string | null
          user_id: string
          user_name: string
        }
        Insert: {
          comment_text: string
          created_at?: string
          id?: string
          is_deleted?: boolean
          is_host?: boolean
          is_pinned?: boolean
          live_stream_id: string
          user_avatar?: string | null
          user_id: string
          user_name?: string
        }
        Update: {
          comment_text?: string
          created_at?: string
          id?: string
          is_deleted?: boolean
          is_host?: boolean
          is_pinned?: boolean
          live_stream_id?: string
          user_avatar?: string | null
          user_id?: string
          user_name?: string
        }
        Relationships: [
          {
            foreignKeyName: "live_comments_live_stream_id_fkey"
            columns: ["live_stream_id"]
            isOneToOne: false
            referencedRelation: "live_streams"
            referencedColumns: ["id"]
          },
        ]
      }
      live_followers: {
        Row: {
          astrologer_id: string
          created_at: string
          follower_id: string
          id: string
        }
        Insert: {
          astrologer_id: string
          created_at?: string
          follower_id: string
          id?: string
        }
        Update: {
          astrologer_id?: string
          created_at?: string
          follower_id?: string
          id?: string
        }
        Relationships: [
          {
            foreignKeyName: "live_followers_astrologer_id_fkey"
            columns: ["astrologer_id"]
            isOneToOne: false
            referencedRelation: "astrologers"
            referencedColumns: ["id"]
          },
        ]
      }
      live_gifts: {
        Row: {
          astrologer_earning: number
          astrologer_id: string
          company_earning: number
          created_at: string
          customer_note: string | null
          gift_amount: number
          gift_type: string
          id: string
          live_stream_id: string
          sender_id: string
        }
        Insert: {
          astrologer_earning?: number
          astrologer_id: string
          company_earning?: number
          created_at?: string
          customer_note?: string | null
          gift_amount: number
          gift_type: string
          id?: string
          live_stream_id: string
          sender_id: string
        }
        Update: {
          astrologer_earning?: number
          astrologer_id?: string
          company_earning?: number
          created_at?: string
          customer_note?: string | null
          gift_amount?: number
          gift_type?: string
          id?: string
          live_stream_id?: string
          sender_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "live_gifts_astrologer_id_fkey"
            columns: ["astrologer_id"]
            isOneToOne: false
            referencedRelation: "astrologers"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "live_gifts_live_stream_id_fkey"
            columns: ["live_stream_id"]
            isOneToOne: false
            referencedRelation: "live_streams"
            referencedColumns: ["id"]
          },
        ]
      }
      live_likes: {
        Row: {
          created_at: string
          id: string
          live_stream_id: string
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          live_stream_id: string
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          live_stream_id?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "live_likes_live_stream_id_fkey"
            columns: ["live_stream_id"]
            isOneToOne: false
            referencedRelation: "live_streams"
            referencedColumns: ["id"]
          },
        ]
      }
      live_streams: {
        Row: {
          active_call_request_id: string | null
          active_co_host_id: string | null
          astrologer_id: string
          channel_name: string
          created_at: string
          description: string | null
          duration_seconds: number
          ended_at: string | null
          ended_by_admin: string | null
          ended_reason: string | null
          id: string
          is_paused_for_private: boolean
          paused_at: string | null
          peak_viewer_count: number
          private_session_count: number
          save_recording: boolean
          started_at: string
          status: string
          thumbnail_url: string | null
          title: string
          total_comments: number
          total_gifts_count: number
          total_gifts_value: number
          total_likes: number
          total_unique_viewers: number
          viewer_count: number
        }
        Insert: {
          active_call_request_id?: string | null
          active_co_host_id?: string | null
          astrologer_id: string
          channel_name: string
          created_at?: string
          description?: string | null
          duration_seconds?: number
          ended_at?: string | null
          ended_by_admin?: string | null
          ended_reason?: string | null
          id?: string
          is_paused_for_private?: boolean
          paused_at?: string | null
          peak_viewer_count?: number
          private_session_count?: number
          save_recording?: boolean
          started_at?: string
          status?: string
          thumbnail_url?: string | null
          title?: string
          total_comments?: number
          total_gifts_count?: number
          total_gifts_value?: number
          total_likes?: number
          total_unique_viewers?: number
          viewer_count?: number
        }
        Update: {
          active_call_request_id?: string | null
          active_co_host_id?: string | null
          astrologer_id?: string
          channel_name?: string
          created_at?: string
          description?: string | null
          duration_seconds?: number
          ended_at?: string | null
          ended_by_admin?: string | null
          ended_reason?: string | null
          id?: string
          is_paused_for_private?: boolean
          paused_at?: string | null
          peak_viewer_count?: number
          private_session_count?: number
          save_recording?: boolean
          started_at?: string
          status?: string
          thumbnail_url?: string | null
          title?: string
          total_comments?: number
          total_gifts_count?: number
          total_gifts_value?: number
          total_likes?: number
          total_unique_viewers?: number
          viewer_count?: number
        }
        Relationships: [
          {
            foreignKeyName: "live_streams_astrologer_id_fkey"
            columns: ["astrologer_id"]
            isOneToOne: false
            referencedRelation: "astrologers"
            referencedColumns: ["id"]
          },
        ]
      }
      live_viewers: {
        Row: {
          id: string
          joined_at: string
          left_at: string | null
          live_stream_id: string
          user_id: string
          watch_duration_seconds: number
        }
        Insert: {
          id?: string
          joined_at?: string
          left_at?: string | null
          live_stream_id: string
          user_id: string
          watch_duration_seconds?: number
        }
        Update: {
          id?: string
          joined_at?: string
          left_at?: string | null
          live_stream_id?: string
          user_id?: string
          watch_duration_seconds?: number
        }
        Relationships: [
          {
            foreignKeyName: "live_viewers_live_stream_id_fkey"
            columns: ["live_stream_id"]
            isOneToOne: false
            referencedRelation: "live_streams"
            referencedColumns: ["id"]
          },
        ]
      }
      location_cache: {
        Row: {
          created_at: string
          id: string
          query: string
          results: Json
        }
        Insert: {
          created_at?: string
          id?: string
          query: string
          results: Json
        }
        Update: {
          created_at?: string
          id?: string
          query?: string
          results?: Json
        }
        Relationships: []
      }
      nakshatra_reports: {
        Row: {
          api_response: Json
          birth_chart_id: string
          created_at: string
          id: string
          language: string
          nakshatra_id: number
          pada: number
          source: string
        }
        Insert: {
          api_response?: Json
          birth_chart_id: string
          created_at?: string
          id?: string
          language?: string
          nakshatra_id: number
          pada: number
          source?: string
        }
        Update: {
          api_response?: Json
          birth_chart_id?: string
          created_at?: string
          id?: string
          language?: string
          nakshatra_id?: number
          pada?: number
          source?: string
        }
        Relationships: [
          {
            foreignKeyName: "nakshatra_reports_birth_chart_id_fkey"
            columns: ["birth_chart_id"]
            isOneToOne: false
            referencedRelation: "birth_charts"
            referencedColumns: ["id"]
          },
        ]
      }
      notifications: {
        Row: {
          body: string | null
          created_at: string
          id: string
          link: string | null
          read: boolean
          title: string
          type: string
          user_id: string
        }
        Insert: {
          body?: string | null
          created_at?: string
          id?: string
          link?: string | null
          read?: boolean
          title: string
          type: string
          user_id: string
        }
        Update: {
          body?: string | null
          created_at?: string
          id?: string
          link?: string | null
          read?: boolean
          title?: string
          type?: string
          user_id?: string
        }
        Relationships: []
      }
      pack_definitions: {
        Row: {
          active: boolean
          created_at: string
          credit_amount: number
          description: string | null
          display_name: string
          minutes_amount: number | null
          pack_type: string
          paid_amount: number
          price_id: string
          product_id: string
          sort_order: number
        }
        Insert: {
          active?: boolean
          created_at?: string
          credit_amount: number
          description?: string | null
          display_name: string
          minutes_amount?: number | null
          pack_type?: string
          paid_amount: number
          price_id: string
          product_id: string
          sort_order?: number
        }
        Update: {
          active?: boolean
          created_at?: string
          credit_amount?: number
          description?: string | null
          display_name?: string
          minutes_amount?: number | null
          pack_type?: string
          paid_amount?: number
          price_id?: string
          product_id?: string
          sort_order?: number
        }
        Relationships: []
      }
      panchang_cache: {
        Row: {
          computed_at: string
          date: string
          id: string
          latitude: number
          longitude: number
          panchang_data: Json
          timezone: string
        }
        Insert: {
          computed_at?: string
          date: string
          id?: string
          latitude: number
          longitude: number
          panchang_data: Json
          timezone: string
        }
        Update: {
          computed_at?: string
          date?: string
          id?: string
          latitude?: number
          longitude?: number
          panchang_data?: Json
          timezone?: string
        }
        Relationships: []
      }
      phone_verifications: {
        Row: {
          attempts_count: number
          created_at: string
          expires_at: string
          id: string
          otp_hash: string
          phone_number: string
          user_id: string
          user_type: string
          verified_at: string | null
        }
        Insert: {
          attempts_count?: number
          created_at?: string
          expires_at: string
          id?: string
          otp_hash: string
          phone_number: string
          user_id: string
          user_type: string
          verified_at?: string | null
        }
        Update: {
          attempts_count?: number
          created_at?: string
          expires_at?: string
          id?: string
          otp_hash?: string
          phone_number?: string
          user_id?: string
          user_type?: string
          verified_at?: string | null
        }
        Relationships: []
      }
      platform_settings: {
        Row: {
          astrolive_enabled: boolean
          astrolive_enabled_mobile: boolean
          astrolive_enabled_web: boolean
          astrologer_share_percent: number
          auto_end_below_balance: number
          id: number
          maintenance_message: string
          maintenance_mode: boolean
          max_session_minutes: number
          max_wallet_balance: number
          max_withdrawal_amount: number
          min_billing_seconds: number
          min_recharge_amount: number
          min_review_session_seconds: number
          min_withdrawal_amount: number
          reviews_require_approval: boolean
          updated_at: string
          updated_by: string | null
          withdrawal_processing_notice: string
        }
        Insert: {
          astrolive_enabled?: boolean
          astrolive_enabled_mobile?: boolean
          astrolive_enabled_web?: boolean
          astrologer_share_percent?: number
          auto_end_below_balance?: number
          id?: number
          maintenance_message?: string
          maintenance_mode?: boolean
          max_session_minutes?: number
          max_wallet_balance?: number
          max_withdrawal_amount?: number
          min_billing_seconds?: number
          min_recharge_amount?: number
          min_review_session_seconds?: number
          min_withdrawal_amount?: number
          reviews_require_approval?: boolean
          updated_at?: string
          updated_by?: string | null
          withdrawal_processing_notice?: string
        }
        Update: {
          astrolive_enabled?: boolean
          astrolive_enabled_mobile?: boolean
          astrolive_enabled_web?: boolean
          astrologer_share_percent?: number
          auto_end_below_balance?: number
          id?: number
          maintenance_message?: string
          maintenance_mode?: boolean
          max_session_minutes?: number
          max_wallet_balance?: number
          max_withdrawal_amount?: number
          min_billing_seconds?: number
          min_recharge_amount?: number
          min_review_session_seconds?: number
          min_withdrawal_amount?: number
          reviews_require_approval?: boolean
          updated_at?: string
          updated_by?: string | null
          withdrawal_processing_notice?: string
        }
        Relationships: []
      }
      profiles: {
        Row: {
          avatar_url: string | null
          blocked_at: string | null
          blocked_reason: string | null
          consultation_minutes: number
          created_at: string
          dob: string | null
          email: string | null
          id: string
          is_blocked: boolean
          language_preference: string
          name: string
          phone: string | null
          phone_e164: string | null
          phone_verified: boolean
          phone_verified_at: string | null
          pob_city: string | null
          pob_country: string | null
          pob_lat: number | null
          pob_lon: number | null
          pob_state: string | null
          tob: string | null
          updated_at: string
          user_id_display: number
        }
        Insert: {
          avatar_url?: string | null
          blocked_at?: string | null
          blocked_reason?: string | null
          consultation_minutes?: number
          created_at?: string
          dob?: string | null
          email?: string | null
          id: string
          is_blocked?: boolean
          language_preference?: string
          name?: string
          phone?: string | null
          phone_e164?: string | null
          phone_verified?: boolean
          phone_verified_at?: string | null
          pob_city?: string | null
          pob_country?: string | null
          pob_lat?: number | null
          pob_lon?: number | null
          pob_state?: string | null
          tob?: string | null
          updated_at?: string
          user_id_display?: number
        }
        Update: {
          avatar_url?: string | null
          blocked_at?: string | null
          blocked_reason?: string | null
          consultation_minutes?: number
          created_at?: string
          dob?: string | null
          email?: string | null
          id?: string
          is_blocked?: boolean
          language_preference?: string
          name?: string
          phone?: string | null
          phone_e164?: string | null
          phone_verified?: boolean
          phone_verified_at?: string | null
          pob_city?: string | null
          pob_country?: string | null
          pob_lat?: number | null
          pob_lon?: number | null
          pob_state?: string | null
          tob?: string | null
          updated_at?: string
          user_id_display?: number
        }
        Relationships: []
      }
      push_subscriptions: {
        Row: {
          auth_key: string
          created_at: string
          endpoint: string
          id: string
          last_used_at: string
          p256dh_key: string
          user_agent: string | null
          user_id: string
        }
        Insert: {
          auth_key: string
          created_at?: string
          endpoint: string
          id?: string
          last_used_at?: string
          p256dh_key: string
          user_agent?: string | null
          user_id: string
        }
        Update: {
          auth_key?: string
          created_at?: string
          endpoint?: string
          id?: string
          last_used_at?: string
          p256dh_key?: string
          user_agent?: string | null
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "push_subscriptions_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      review_replies: {
        Row: {
          astrologer_user_id: string
          created_at: string
          id: string
          reply: string
          review_id: string
        }
        Insert: {
          astrologer_user_id: string
          created_at?: string
          id?: string
          reply: string
          review_id: string
        }
        Update: {
          astrologer_user_id?: string
          created_at?: string
          id?: string
          reply?: string
          review_id?: string
        }
        Relationships: []
      }
      reviews: {
        Row: {
          astrologer_id: string
          comment: string | null
          created_at: string
          helpful_count: number
          id: string
          moderated_at: string | null
          moderated_by: string | null
          moderation_status: string
          rating: number
          rejection_reason: string | null
          user_id: string
        }
        Insert: {
          astrologer_id: string
          comment?: string | null
          created_at?: string
          helpful_count?: number
          id?: string
          moderated_at?: string | null
          moderated_by?: string | null
          moderation_status?: string
          rating: number
          rejection_reason?: string | null
          user_id: string
        }
        Update: {
          astrologer_id?: string
          comment?: string | null
          created_at?: string
          helpful_count?: number
          id?: string
          moderated_at?: string | null
          moderated_by?: string | null
          moderation_status?: string
          rating?: number
          rejection_reason?: string | null
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "reviews_astrologer_id_fkey"
            columns: ["astrologer_id"]
            isOneToOne: false
            referencedRelation: "astrologers"
            referencedColumns: ["id"]
          },
        ]
      }
      shodashvarga_charts: {
        Row: {
          birth_chart_id: string
          chart_data: Json
          chart_id: string
          created_at: string
          id: string
          language: string
          source: string
        }
        Insert: {
          birth_chart_id: string
          chart_data: Json
          chart_id: string
          created_at?: string
          id?: string
          language?: string
          source?: string
        }
        Update: {
          birth_chart_id?: string
          chart_data?: Json
          chart_id?: string
          created_at?: string
          id?: string
          language?: string
          source?: string
        }
        Relationships: [
          {
            foreignKeyName: "shodashvarga_charts_birth_chart_id_fkey"
            columns: ["birth_chart_id"]
            isOneToOne: false
            referencedRelation: "birth_charts"
            referencedColumns: ["id"]
          },
        ]
      }
      support_ticket_replies: {
        Row: {
          author_id: string
          author_role: string
          created_at: string
          id: string
          message: string
          ticket_id: string
        }
        Insert: {
          author_id: string
          author_role: string
          created_at?: string
          id?: string
          message: string
          ticket_id: string
        }
        Update: {
          author_id?: string
          author_role?: string
          created_at?: string
          id?: string
          message?: string
          ticket_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "support_ticket_replies_ticket_id_fkey"
            columns: ["ticket_id"]
            isOneToOne: false
            referencedRelation: "support_tickets"
            referencedColumns: ["id"]
          },
        ]
      }
      support_tickets: {
        Row: {
          assigned_to: string | null
          created_at: string
          id: string
          message: string
          status: string
          subject: string
          updated_at: string
          user_id: string
        }
        Insert: {
          assigned_to?: string | null
          created_at?: string
          id?: string
          message: string
          status?: string
          subject: string
          updated_at?: string
          user_id: string
        }
        Update: {
          assigned_to?: string | null
          created_at?: string
          id?: string
          message?: string
          status?: string
          subject?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      transactions: {
        Row: {
          amount: number
          balance_after: number
          call_session_id: string | null
          created_at: string
          description: string
          id: string
          stripe_payment_id: string | null
          type: Database["public"]["Enums"]["transaction_type"]
          wallet_id: string
        }
        Insert: {
          amount: number
          balance_after: number
          call_session_id?: string | null
          created_at?: string
          description: string
          id?: string
          stripe_payment_id?: string | null
          type: Database["public"]["Enums"]["transaction_type"]
          wallet_id: string
        }
        Update: {
          amount?: number
          balance_after?: number
          call_session_id?: string | null
          created_at?: string
          description?: string
          id?: string
          stripe_payment_id?: string | null
          type?: Database["public"]["Enums"]["transaction_type"]
          wallet_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "transactions_call_session_id_fkey"
            columns: ["call_session_id"]
            isOneToOne: false
            referencedRelation: "call_sessions"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "transactions_wallet_id_fkey"
            columns: ["wallet_id"]
            isOneToOne: false
            referencedRelation: "wallets"
            referencedColumns: ["id"]
          },
        ]
      }
      user_notification_preferences: {
        Row: {
          created_at: string
          id: string
          notify_on_announcement: boolean
          notify_on_gift: boolean
          notify_on_live: boolean
          notify_on_message: boolean
          target_id: string | null
          target_type: string
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          notify_on_announcement?: boolean
          notify_on_gift?: boolean
          notify_on_live?: boolean
          notify_on_message?: boolean
          target_id?: string | null
          target_type?: string
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          notify_on_announcement?: boolean
          notify_on_gift?: boolean
          notify_on_live?: boolean
          notify_on_message?: boolean
          target_id?: string | null
          target_type?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "user_notification_preferences_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      user_purchases: {
        Row: {
          id: string
          metadata: Json
          product_id: string
          product_type: string
          purchased_at: string
          stripe_payment_id: string | null
          user_id: string
        }
        Insert: {
          id?: string
          metadata?: Json
          product_id: string
          product_type: string
          purchased_at?: string
          stripe_payment_id?: string | null
          user_id: string
        }
        Update: {
          id?: string
          metadata?: Json
          product_id?: string
          product_type?: string
          purchased_at?: string
          stripe_payment_id?: string | null
          user_id?: string
        }
        Relationships: []
      }
      user_roles: {
        Row: {
          created_at: string
          id: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          role?: Database["public"]["Enums"]["app_role"]
          user_id?: string
        }
        Relationships: []
      }
      vimshottari_dasha: {
        Row: {
          birth_chart_id: string
          computed_at: string
          current_antar_end: string | null
          current_antar_lord: string | null
          current_antar_start: string | null
          current_maha_end: string | null
          current_maha_lord: string | null
          current_maha_start: string | null
          dasha_tree: Json
          id: string
          user_id: string
        }
        Insert: {
          birth_chart_id: string
          computed_at?: string
          current_antar_end?: string | null
          current_antar_lord?: string | null
          current_antar_start?: string | null
          current_maha_end?: string | null
          current_maha_lord?: string | null
          current_maha_start?: string | null
          dasha_tree?: Json
          id?: string
          user_id: string
        }
        Update: {
          birth_chart_id?: string
          computed_at?: string
          current_antar_end?: string | null
          current_antar_lord?: string | null
          current_antar_start?: string | null
          current_maha_end?: string | null
          current_maha_lord?: string | null
          current_maha_start?: string | null
          dasha_tree?: Json
          id?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "vimshottari_dasha_birth_chart_id_fkey"
            columns: ["birth_chart_id"]
            isOneToOne: true
            referencedRelation: "birth_charts"
            referencedColumns: ["id"]
          },
        ]
      }
      wallet_adjustment_requests: {
        Row: {
          amount: number
          created_at: string
          id: string
          reason: string | null
          requested_by_admin_id: string
          review_note: string | null
          reviewed_at: string | null
          reviewed_by_admin_id: string | null
          status: string
          target_user_id: string
          target_user_type: string
        }
        Insert: {
          amount: number
          created_at?: string
          id?: string
          reason?: string | null
          requested_by_admin_id: string
          review_note?: string | null
          reviewed_at?: string | null
          reviewed_by_admin_id?: string | null
          status?: string
          target_user_id: string
          target_user_type: string
        }
        Update: {
          amount?: number
          created_at?: string
          id?: string
          reason?: string | null
          requested_by_admin_id?: string
          review_note?: string | null
          reviewed_at?: string | null
          reviewed_by_admin_id?: string | null
          status?: string
          target_user_id?: string
          target_user_type?: string
        }
        Relationships: [
          {
            foreignKeyName: "wallet_adjustment_requests_requested_by_admin_id_fkey"
            columns: ["requested_by_admin_id"]
            isOneToOne: false
            referencedRelation: "admin_users"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "wallet_adjustment_requests_reviewed_by_admin_id_fkey"
            columns: ["reviewed_by_admin_id"]
            isOneToOne: false
            referencedRelation: "admin_users"
            referencedColumns: ["id"]
          },
        ]
      }
      wallets: {
        Row: {
          balance: number
          created_at: string
          currency: string
          id: string
          updated_at: string
          user_id: string
        }
        Insert: {
          balance?: number
          created_at?: string
          currency?: string
          id?: string
          updated_at?: string
          user_id: string
        }
        Update: {
          balance?: number
          created_at?: string
          currency?: string
          id?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "wallets_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: true
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      webhook_events: {
        Row: {
          environment: string
          event_id: string
          event_type: string
          processed_at: string
        }
        Insert: {
          environment: string
          event_id: string
          event_type: string
          processed_at?: string
        }
        Update: {
          environment?: string
          event_id?: string
          event_type?: string
          processed_at?: string
        }
        Relationships: []
      }
      withdrawal_requests: {
        Row: {
          amount: number
          astrologer_user_id: string
          bank_account: string | null
          bank_ifsc: string | null
          bank_name: string | null
          created_at: string
          id: string
          method: string
          notes: string | null
          processed_at: string | null
          processed_by: string | null
          status: string
          transaction_reference: string | null
          updated_at: string
          upi_id: string | null
        }
        Insert: {
          amount: number
          astrologer_user_id: string
          bank_account?: string | null
          bank_ifsc?: string | null
          bank_name?: string | null
          created_at?: string
          id?: string
          method?: string
          notes?: string | null
          processed_at?: string | null
          processed_by?: string | null
          status?: string
          transaction_reference?: string | null
          updated_at?: string
          upi_id?: string | null
        }
        Update: {
          amount?: number
          astrologer_user_id?: string
          bank_account?: string | null
          bank_ifsc?: string | null
          bank_name?: string | null
          created_at?: string
          id?: string
          method?: string
          notes?: string | null
          processed_at?: string | null
          processed_by?: string | null
          status?: string
          transaction_reference?: string | null
          updated_at?: string
          upi_id?: string | null
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      _release_live_call_hold: {
        Args: { _request_id: string }
        Returns: undefined
      }
      accept_call_session: { Args: { _session_id: string }; Returns: Json }
      admin_adjust_wallet: {
        Args: {
          _amount: number
          _direction: string
          _reason: string
          _user_id: string
        }
        Returns: Json
      }
      admin_has_permission: {
        Args: { _permission: string; _user_id: string }
        Returns: boolean
      }
      admin_process_withdrawal: {
        Args: {
          _action: string
          _reason: string
          _reference: string
          _request_id: string
        }
        Returns: Json
      }
      admin_refund_session: {
        Args: {
          _amount: number
          _reason: string
          _session_id: string
          _session_kind: string
        }
        Returns: Json
      }
      bill_active_chats: { Args: never; Returns: undefined }
      bill_live_call_minute: { Args: { _request_id: string }; Returns: Json }
      cancel_live_call_request: { Args: { _request_id: string }; Returns: Json }
      cleanup_panchang_cache: { Args: never; Returns: undefined }
      credit_consultation_minutes: {
        Args: {
          _description: string
          _minutes: number
          _stripe_payment_id: string
          _user_id: string
        }
        Returns: undefined
      }
      credit_wallet: {
        Args: {
          _amount: number
          _description: string
          _stripe_payment_id: string
          _user_id: string
        }
        Returns: undefined
      }
      decline_call_session: { Args: { _session_id: string }; Returns: Json }
      end_call_session: {
        Args: { _end_reason: string; _ended_by: string; _session_id: string }
        Returns: Json
      }
      end_chat_session: {
        Args: { _end_reason: string; _ended_by: string; _session_id: string }
        Returns: Json
      }
      end_live_call: {
        Args: { _ended_by: string; _request_id: string }
        Returns: Json
      }
      end_live_stream: {
        Args: { _reason: string; _stream_id: string }
        Returns: Json
      }
      end_private_live_call: {
        Args: { _ended_by?: string; _request_id: string }
        Returns: Json
      }
      ensure_user_setup: { Args: never; Returns: undefined }
      expire_pending_chats: { Args: never; Returns: undefined }
      expire_pending_live_call_requests: { Args: never; Returns: undefined }
      expire_stale_presence: { Args: never; Returns: undefined }
      get_astrologer_gift_stats: {
        Args: { _astrologer_id: string; _time_range: string }
        Returns: Json
      }
      get_top_gifters_for_live: {
        Args: { _stream_id: string }
        Returns: {
          gift_count: number
          sender_avatar: string
          sender_id: string
          sender_name: string
          top_gift_type: string
          total_gifted: number
        }[]
      }
      get_top_gifters_lifetime: {
        Args: { _astrologer_id: string; _time_range: string }
        Returns: {
          gift_count: number
          sender_avatar: string
          sender_id: string
          sender_name: string
          top_gift_type: string
          total_gifted: number
        }[]
      }
      has_role: {
        Args: {
          _role: Database["public"]["Enums"]["app_role"]
          _user_id: string
        }
        Returns: boolean
      }
      hold_wallet_for_call: {
        Args: { _amount: number; _call_session_id: string; _user_id: string }
        Returns: number
      }
      hold_wallet_for_chat: {
        Args: { _amount: number; _chat_session_id: string; _user_id: string }
        Returns: number
      }
      is_active_admin: { Args: { _user_id: string }; Returns: boolean }
      is_master_admin: { Args: { _user_id: string }; Returns: boolean }
      join_live_stream: { Args: { _stream_id: string }; Returns: Json }
      leave_live_stream: { Args: { _stream_id: string }; Returns: Json }
      like_live_stream: { Args: { _stream_id: string }; Returns: Json }
      log_admin_action: {
        Args: {
          _action: string
          _details: Json
          _target_id: string
          _target_type: string
        }
        Returns: undefined
      }
      notify_followers_live_started: {
        Args: { _stream_id: string }
        Returns: Json
      }
      notify_live_resumed: { Args: { _stream_id: string }; Returns: Json }
      post_live_comment: {
        Args: { _stream_id: string; _text: string }
        Returns: Json
      }
      release_call_hold: {
        Args: { _call_session_id: string }
        Returns: undefined
      }
      release_chat_hold: {
        Args: { _chat_session_id: string }
        Returns: undefined
      }
      request_live_call:
        | {
            Args: { _live_stream_id: string; _request_type: string }
            Returns: Json
          }
        | {
            Args: {
              _live_stream_id: string
              _media_type?: string
              _request_type: string
            }
            Returns: Json
          }
      request_withdrawal: {
        Args: {
          _amount: number
          _bank_account: string
          _bank_ifsc: string
          _bank_name: string
          _method: string
          _upi_id: string
        }
        Returns: Json
      }
      respond_live_call_request: {
        Args: { _action: string; _request_id: string }
        Returns: Json
      }
      send_gift: {
        Args: {
          _amount: number
          _astrologer_id: string
          _customer_note: string
          _gift_label: string
          _gift_type: string
          _session_id: string
        }
        Returns: Json
      }
      send_live_gift_atomic: {
        Args: {
          _customer_note: string
          _gift_type: string
          _live_stream_id: string
        }
        Returns: Json
      }
      spend_consultation_time: {
        Args: {
          _description: string
          _minutes: number
          _per_minute_rate: number
          _user_id: string
        }
        Returns: Json
      }
      start_live_stream: {
        Args: {
          _description: string
          _save_recording: boolean
          _thumbnail_url: string
          _title: string
        }
        Returns: Json
      }
      toggle_follow_astrologer: {
        Args: { _astrologer_id: string }
        Returns: Json
      }
      toggle_notify_astrologer: {
        Args: { _astrologer_id: string }
        Returns: Json
      }
      unlike_live_stream: { Args: { _stream_id: string }; Returns: Json }
    }
    Enums: {
      app_role: "customer" | "astrologer" | "admin"
      transaction_type:
        | "top_up"
        | "consultation_debit"
        | "refund"
        | "consultation_credit"
        | "consultation_minute_spend"
        | "call_hold"
        | "call_hold_release"
        | "call_charge"
        | "withdrawal"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      app_role: ["customer", "astrologer", "admin"],
      transaction_type: [
        "top_up",
        "consultation_debit",
        "refund",
        "consultation_credit",
        "consultation_minute_spend",
        "call_hold",
        "call_hold_release",
        "call_charge",
        "withdrawal",
      ],
    },
  },
} as const
