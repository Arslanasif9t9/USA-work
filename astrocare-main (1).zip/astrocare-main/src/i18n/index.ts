// i18next bootstrap. Defines two languages (en, hi), wires browser detection
// + localStorage persistence, and registers our common/panchang/chart/toasts namespaces.
//
// Add a new namespace by creating files at src/locales/{en,hi}/{namespace}.json
// and adding it to `resources` below.
import i18n from "i18next";
import { initReactI18next } from "react-i18next";
import LanguageDetector from "i18next-browser-languagedetector";

import enCommon from "@/locales/en/common.json";
import hiCommon from "@/locales/hi/common.json";
import enPanchang from "@/locales/en/panchang.json";
import hiPanchang from "@/locales/hi/panchang.json";
import enChart from "@/locales/en/chart.json";
import hiChart from "@/locales/hi/chart.json";
import enToasts from "@/locales/en/toasts.json";
import hiToasts from "@/locales/hi/toasts.json";

export const SUPPORTED_LANGS = ["en", "hi"] as const;
export type SupportedLang = (typeof SUPPORTED_LANGS)[number];

if (!i18n.isInitialized) {
  i18n
    .use(LanguageDetector)
    .use(initReactI18next)
    .init({
      resources: {
        en: { common: enCommon, panchang: enPanchang, chart: enChart, toasts: enToasts },
        hi: { common: hiCommon, panchang: hiPanchang, chart: hiChart, toasts: hiToasts },
      },
      fallbackLng: "en",
      supportedLngs: SUPPORTED_LANGS as unknown as string[],
      defaultNS: "common",
      ns: ["common", "panchang", "chart", "toasts"],
      interpolation: { escapeValue: false },
      detection: {
        order: ["localStorage", "navigator"],
        lookupLocalStorage: "appLang",
        caches: ["localStorage"],
      },
      // Fallback behaviour:
      // - returnNull/returnEmptyString: false → if a key resolves to null/"" use the
      //   fallbackLng value instead. Prevents blank UI when a HI key is empty.
      // - saveMissing: false → never POST missing keys to a backend in production.
      // - missing keys (key not present at all) automatically fall back to `fallbackLng`
      //   ("en") thanks to i18next's default fallback chain.
      returnNull: false,
      returnEmptyString: false,
      saveMissing: false,
    });
}

export default i18n;
