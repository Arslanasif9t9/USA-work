// Vedic terminology lookup tables — used to translate API/server-provided
// English labels (planet/sign/nakshatra/tithi/yoga/karana/paksha/vaar names)
// into Devanagari at render-time. Keep these in one place so every UI surface
// (Panchang, Chart, Hora, dashboards) shares the same vocabulary.
//
// ─────────────────────────────────────────────────────────────────────────────
// Note on retrograde flags (upstream provider behavior)
// ─────────────────────────────────────────────────────────────────────────────
// astrologyapi.com (Swiss Ephemeris) flags slow-moving outer planets as
// "retrograde" when they are near a station — even when technically still
// direct but moving below a small daily-motion threshold. This matches the
// AstroSage convention used as our reference. Do NOT post-process these flags
// client-side; render whatever the provider returns. If a user reports a
// "wrong R", first verify against AstroSage for the same UTC instant before
// considering it a bug.

import {
  PLANET_TABLE_NAME,
  PLANET_TABLE_NAME_HI,
  SIGN_NAMES_EN,
  SIGN_NAMES_HI,
  NAKSHATRA_NAMES_HI,
  type PlanetName,
} from "@/types/panchang";

export type Lang = "en" | "hi";

// English → Hindi nakshatra map (covers the spelling AstroSage / astrologyapi
// returns and a few common variants).
const NAKSHATRA_EN_TO_HI: Record<string, string> = {
  Ashwini: "अश्विनी",
  Ashvini: "अश्विनी",
  Bharani: "भरणी",
  Krittika: "कृत्तिका",
  Krittka: "कृत्तिका",
  Rohini: "रोहिणी",
  Mrigashira: "मृगशिरा",
  Mrigshira: "मृगशिरा",
  Ardra: "आर्द्रा",
  Punarvasu: "पुनर्वसु",
  Pushya: "पुष्य",
  Pushyami: "पुष्य",
  Ashlesha: "आश्लेषा",
  Magha: "मघा",
  "Purva Phalguni": "पूर्व फाल्गुनी",
  "Uttara Phalguni": "उत्तर फाल्गुनी",
  Hasta: "हस्त",
  Chitra: "चित्रा",
  Swati: "स्वाति",
  Vishakha: "विशाखा",
  Anuradha: "अनुराधा",
  Jyeshtha: "ज्येष्ठा",
  Jyeshta: "ज्येष्ठा",
  Mula: "मूल",
  Moola: "मूल",
  "Purva Ashadha": "पूर्वाषाढ़ा",
  "Uttara Ashadha": "उत्तराषाढ़ा",
  Shravana: "श्रवण",
  Sravana: "श्रवण",
  Dhanishta: "धनिष्ठा",
  Dhanishtha: "धनिष्ठा",
  Shatabhisha: "शतभिषा",
  Satabhisa: "शतभिषा",
  Shatabhishak: "शतभिषा",
  "Purva Bhadrapada": "पूर्व भाद्रपद",
  Purvabhadra: "पूर्व भाद्रपद",
  "Uttara Bhadrapada": "उत्तर भाद्रपद",
  Uttarabhadra: "उत्तर भाद्रपद",
  Revati: "रेवती",
};

const TITHI_EN_TO_HI: Record<string, string> = {
  Pratipada: "प्रतिपदा",
  Dwitiya: "द्वितीया",
  Tritiya: "तृतीया",
  Chaturthi: "चतुर्थी",
  Panchami: "पञ्चमी",
  Shashthi: "षष्ठी",
  Saptami: "सप्तमी",
  Ashtami: "अष्टमी",
  Navami: "नवमी",
  Dashami: "दशमी",
  Ekadashi: "एकादशी",
  Dwadashi: "द्वादशी",
  Trayodashi: "त्रयोदशी",
  Chaturdashi: "चतुर्दशी",
  Purnima: "पूर्णिमा",
  Amavasya: "अमावस्या",
};

const YOGA_EN_TO_HI: Record<string, string> = {
  Vishkambha: "विष्कम्भ",
  Priti: "प्रीति",
  Ayushman: "आयुष्मान",
  Saubhagya: "सौभाग्य",
  Shobhana: "शोभन",
  Atiganda: "अतिगण्ड",
  Sukarman: "सुकर्मा",
  Sukarma: "सुकर्मा",
  Dhriti: "धृति",
  Shoola: "शूल",
  Ganda: "गण्ड",
  Vriddhi: "वृद्धि",
  Dhruva: "ध्रुव",
  Vyaghata: "व्याघात",
  Harshana: "हर्षण",
  Vajra: "वज्र",
  Siddhi: "सिद्धि",
  Vyatipata: "व्यतिपात",
  Variyan: "वरीयान्",
  Parigha: "परिघ",
  Shiva: "शिव",
  Siddha: "सिद्ध",
  Sadhya: "साध्य",
  Shubha: "शुभ",
  Shukla: "शुक्ल",
  Brahma: "ब्रह्म",
  Indra: "इन्द्र",
  Vaidhriti: "वैधृति",
};

const KARANA_EN_TO_HI: Record<string, string> = {
  Bava: "बव",
  Balava: "बालव",
  Kaulava: "कौलव",
  Taitila: "तैतिल",
  Garaja: "गरज",
  Vanija: "वणिज",
  Vishti: "विष्टि",
  Bhadra: "भद्रा",
  Shakuni: "शकुनि",
  Chatushpada: "चतुष्पाद",
  Naga: "नाग",
  Kimstughna: "किंस्तुघ्न",
};

const VAAR_EN_TO_HI: Record<string, string> = {
  Sunday: "रविवार",
  Monday: "सोमवार",
  Tuesday: "मंगलवार",
  Wednesday: "बुधवार",
  Thursday: "गुरुवार",
  Friday: "शुक्रवार",
  Saturday: "शनिवार",
};

const PAKSHA_EN_TO_HI: Record<string, string> = {
  Shukla: "शुक्ल",
  Krishna: "कृष्ण",
};

const PLANET_FULL_HI: Record<string, string> = {
  Sun: "सूर्य",
  Moon: "चन्द्र",
  Mars: "मंगल",
  Mercury: "बुध",
  Jupiter: "गुरु",
  Venus: "शुक्र",
  Saturn: "शनि",
  Rahu: "राहु",
  Ketu: "केतु",
};

// ─────────────────────────────────────────────────────────────────────────────
// Public helpers
// ─────────────────────────────────────────────────────────────────────────────

export function tNakshatra(name: string | undefined | null, lang: Lang): string {
  if (!name) return "";
  if (lang === "en") return name;
  return NAKSHATRA_EN_TO_HI[name.trim()] ?? name;
}

export function tNakshatraByIndex(index: number, lang: Lang, fallback?: string): string {
  if (lang === "hi") return NAKSHATRA_NAMES_HI[index - 1] ?? fallback ?? "";
  return fallback ?? "";
}

export function tSignByIndex(index: number, lang: Lang, fallback?: string): string {
  const i = ((index - 1) % 12 + 12) % 12;
  if (lang === "hi") return SIGN_NAMES_HI[i] ?? fallback ?? "";
  return SIGN_NAMES_EN[i] ?? fallback ?? "";
}

export function tSign(name: string | undefined | null, lang: Lang): string {
  if (!name) return "";
  if (lang === "en") return name;
  const idx = SIGN_NAMES_EN.findIndex((s) => s.toLowerCase() === name.trim().toLowerCase());
  if (idx >= 0) return SIGN_NAMES_HI[idx] ?? name;
  return name;
}

export function tTithi(name: string | undefined | null, lang: Lang): string {
  if (!name) return "";
  if (lang === "en") return name;
  return TITHI_EN_TO_HI[name.trim()] ?? name;
}

export function tYoga(name: string | undefined | null, lang: Lang): string {
  if (!name) return "";
  if (lang === "en") return name;
  return YOGA_EN_TO_HI[name.trim()] ?? name;
}

export function tKarana(name: string | undefined | null, lang: Lang): string {
  if (!name) return "";
  if (lang === "en") return name;
  return KARANA_EN_TO_HI[name.trim()] ?? name;
}

export function tVaar(name: string | undefined | null, lang: Lang): string {
  if (!name) return "";
  if (lang === "en") return name;
  return VAAR_EN_TO_HI[name.trim()] ?? name;
}

export function tPaksha(name: string | undefined | null, lang: Lang): string {
  if (!name) return "";
  if (lang === "en") return name;
  return PAKSHA_EN_TO_HI[name.trim()] ?? name;
}

export function tPlanetFull(
  name: PlanetName | string | undefined | null,
  lang: Lang,
): string {
  if (!name) return "";
  if (lang === "en") return PLANET_TABLE_NAME[name as PlanetName] ?? String(name);
  return (
    PLANET_FULL_HI[String(name)] ??
    PLANET_TABLE_NAME_HI[name as PlanetName] ??
    String(name)
  );
}

const HI_MONTHS = [
  "जनवरी","फ़रवरी","मार्च","अप्रैल","मई","जून",
  "जुलाई","अगस्त","सितंबर","अक्तूबर","नवंबर","दिसंबर",
];
const EN_MONTHS = [
  "January","February","March","April","May","June",
  "July","August","September","October","November","December",
];
const HI_WEEKDAYS = [
  "रविवार","सोमवार","मंगलवार","बुधवार","गुरुवार","शुक्रवार","शनिवार",
];

export function formatLongDate(
  isoDate: string,
  timezone: string,
  lang: Lang,
): string {
  const [y, m, d] = isoDate.split("-").map(Number);
  if (!y || !m || !d) return isoDate;
  // Compute weekday in target timezone via Intl
  const noonUtc = new Date(Date.UTC(y, m - 1, d, 12, 0, 0));
  const wkIdx = (() => {
    try {
      const dtf = new Intl.DateTimeFormat("en-US", {
        timeZone: timezone,
        weekday: "short",
      });
      const wk = dtf.format(noonUtc);
      const map: Record<string, number> = {
        Sun: 0, Mon: 1, Tue: 2, Wed: 3, Thu: 4, Fri: 5, Sat: 6,
      };
      return map[wk] ?? 0;
    } catch {
      return 0;
    }
  })();

  if (lang === "hi") {
    return `${HI_WEEKDAYS[wkIdx]}, ${d} ${HI_MONTHS[m - 1]} ${y}`;
  }
  const enWeekdays = ["Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"];
  return `${enWeekdays[wkIdx]}, ${d} ${EN_MONTHS[m - 1]} ${y}`;
}
