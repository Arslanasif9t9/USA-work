// Per-tab auth storage shim MUST be imported before anything that touches
// the Supabase client, so the patched localStorage is in place when Supabase
// captures it. Keep this as the first import.
import "./lib/perTabAuthStorage";

import { createRoot } from "react-dom/client";
import App from "./App.tsx";
import "./index.css";

createRoot(document.getElementById("root")!).render(<App />);
