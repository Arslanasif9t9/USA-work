// Ashtakavarga shared types.

export type AshtakavargaPlanetKey =
  | "sun" | "moon" | "mars" | "mercury" | "jupiter" | "venus" | "saturn";

export const ASHTAKAVARGA_PLANETS: AshtakavargaPlanetKey[] = [
  "sun", "moon", "mars", "mercury", "jupiter", "venus", "saturn",
];

export interface SarvaData {
  /** length 12; each cell 0..56 */
  houses: number[];
  /** Sum of all 12 cells; for valid Sarva should equal 337. */
  total: number;
}

export type BhinnaData = Record<AshtakavargaPlanetKey, number[]>;

export interface AshtakavargaMetrics {
  sarvaStrongestHouse: { house: number; bindus: number };
  sarvaWeakestHouse: { house: number; bindus: number };
  /** Per-planet total bindus across the 12 houses. */
  planetTotals: Record<AshtakavargaPlanetKey, number>;
  /** Sum across planets per house — should match Sarva houses. */
  houseTotals: number[];
}

export interface AshtakavargaReport {
  sarva: SarvaData;
  bhinna: BhinnaData;
  metrics: AshtakavargaMetrics;
  language: "en" | "hi";
  source: "astrologyapi" | "static_fallback";
}

export type StrengthLevel =
  | "very_high" | "high" | "mid" | "low" | "very_low";

/** Strength bucket for a single Sarva (combined) house cell (0..56). */
export function sarvaStrength(bindus: number): StrengthLevel {
  if (bindus >= 35) return "very_high";
  if (bindus >= 28) return "high";
  if (bindus >= 24) return "mid";
  if (bindus >= 20) return "low";
  return "very_low";
}

/** Strength bucket for a single Bhinna (per-planet) house cell (0..8). */
export function bhinnaStrength(bindus: number): StrengthLevel {
  if (bindus >= 7) return "very_high";
  if (bindus >= 5) return "high";
  if (bindus >= 3) return "mid";
  return "low";
}

// ---- Diamond chart view models ---------------------------------------------

export interface DiamondChartData {
  /** length 12; 0..56 for Sarva, 0..8 for Bhinna */
  houses: number[];
  /** for Sarva (sum of all 12 cells) */
  total?: number;
  /** index 0..11 of the strongest house */
  strongestHouseIndex: number;
}

export interface BhinnaPlanetData {
  planet: AshtakavargaPlanetKey;
  /** "Su", "Mo", ... */
  planetCode: string;
  houses: number[]; // length 12, each 0..8
  total: number;
  strongestHouseIndex: number;
}
