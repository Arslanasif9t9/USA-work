// Language-aware planet name helpers.
// Centralizes English + Hindi (Devanagari) abbreviations and full names.

export const PLANET_NAMES = {
  en: {
    Sun:     { abbr: "Su", full: "Sun" },
    Moon:    { abbr: "Mo", full: "Moon" },
    Mars:    { abbr: "Ma", full: "Mars" },
    Mercury: { abbr: "Me", full: "Mercury" },
    Jupiter: { abbr: "Ju", full: "Jupiter" },
    Venus:   { abbr: "Ve", full: "Venus" },
    Saturn:  { abbr: "Sa", full: "Saturn" },
    Rahu:    { abbr: "Ra", full: "Rahu" },
    Ketu:    { abbr: "Ke", full: "Ketu" },
  },
  hi: {
    Sun:     { abbr: "सू", full: "सूर्य" },
    Moon:    { abbr: "चं", full: "चंद्र" },
    Mars:    { abbr: "मं", full: "मंगल" },
    Mercury: { abbr: "बु", full: "बुध" },
    Jupiter: { abbr: "गु", full: "गुरु" },
    Venus:   { abbr: "शु", full: "शुक्र" },
    Saturn:  { abbr: "श",  full: "शनि" },
    Rahu:    { abbr: "रा", full: "राहु" },
    Ketu:    { abbr: "के", full: "केतु" },
  },
} as const;

export type PlanetLang = "en" | "hi";

export function getPlanetAbbr(planetName: string, language: PlanetLang): string {
  const map = PLANET_NAMES[language] ?? PLANET_NAMES.en;
  const entry = map[planetName as keyof typeof PLANET_NAMES.en];
  return entry?.abbr ?? planetName.slice(0, 2);
}

export function getPlanetFull(planetName: string, language: PlanetLang): string {
  const map = PLANET_NAMES[language] ?? PLANET_NAMES.en;
  const entry = map[planetName as keyof typeof PLANET_NAMES.en];
  return entry?.full ?? planetName;
}

/** Font stack tuned per language — Devanagari needs Tiro/Mukta. */
export function planetFontFamily(language: PlanetLang): string {
  return language === "hi"
    ? "'Tiro Devanagari Hindi','Mukta','Noto Sans Devanagari',sans-serif"
    : "'Inter','Roboto',system-ui,sans-serif";
}
