// Static + API merged Nakshatra report types.
// The static dataset (src/data/nakshatras.ts) provides Vedic classification
// fields the AstrologyAPI response may omit (animal, color hex, mantra, padas,
// career, strengths). The API supplies astronomical placement + optional
// personality summary that overrides the static essay when present.

export type Gana = "Deva" | "Manushya" | "Rakshasa";
export type Nadi = "Adi" | "Madhya" | "Antya";
export type Varna =
  | "Brahmin"
  | "Kshatriya"
  | "Vaishya"
  | "Shudra"
  | "Mleccha"
  | "Farmer"
  | "Butcher"
  | "Servant";
export type Tatva = "Earth" | "Water" | "Fire" | "Air" | "Ether";

export interface NakshatraPada {
  syllable: string;
  characteristic: string;
  characteristicHindi: string;
}

export interface NakshatraStaticData {
  id: number; // 1-27
  name: string;
  nameHindi: string;
  symbol: string;
  symbolIcon: string; // emoji glyph fallback
  meaning: string;
  meaningHindi: string;
  lord: string;
  lordHindi: string;
  deity: string;
  deityHindi: string;
  gana: Gana;
  ganaHindi: string;
  yoni: string;
  yoniHindi: string;
  nadi: Nadi;
  nadiHindi: string;
  varna: Varna;
  varnaHindi: string;
  tatva: Tatva;
  tatvaHindi: string;
  direction: string;
  directionHindi: string;
  color: string;
  colorHex: string;
  bodyPart: string;
  bodyPartHindi: string;
  animal: string;
  bird: string;
  tree: string;
  mantra: string;
  mantraTransliteration: string;
  padas: [NakshatraPada, NakshatraPada, NakshatraPada, NakshatraPada];
  personality: string;
  personalityHindi: string;
  career: string[];
  careerHindi: string[];
  strengths: string[];
  strengthsHindi: string[];
}

export interface NakshatraReportPayload {
  nakshatra_id: number;
  pada: number;
  language: "en" | "hi";
  source: "astrologyapi" | "static_fallback";
  api_response: Record<string, unknown>;
  static: NakshatraStaticData;
}
