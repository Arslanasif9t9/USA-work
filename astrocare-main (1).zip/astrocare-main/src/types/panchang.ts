// Shared types for the Panchang feature.

// 9 classical Vedic Grahas only — outer planets (Uranus, Neptune, Pluto)
// are intentionally excluded as they are not part of traditional Vedic
// astrology. This eliminates the upstream ayanamsa drift that affected
// only the outer bodies.
export type PlanetName =
  | "Sun" | "Moon" | "Mars" | "Mercury" | "Jupiter" | "Venus" | "Saturn"
  | "Rahu" | "Ketu";

export interface PanchangPlanet {
  name: PlanetName;
  longitude: number;        // sidereal 0..360
  sign: number;             // 1..12
  sign_name: string;
  degree: number;           // 0..30 within sign
  nakshatra: number;        // 1..27
  nakshatra_name: string;
  pada: number;             // 1..4
  retrograde: boolean;
  house: number;            // 1..12 whole-sign from Lagna
}

export interface PanchangAscendant {
  longitude: number;
  sign: number;
  sign_name: string;
  degree: number;
}

export interface HoraEntry {
  hour: number;             // 1..12
  planet: "Sun" | "Venus" | "Mercury" | "Moon" | "Saturn" | "Jupiter" | "Mars";
  sanskrit: string;
  start: string;            // ISO
  end: string;              // ISO
}

export interface PanchangResult {
  version?: number;
  date: string;
  location: { latitude: number; longitude: number; timezone: string };
  tithi: { number: number; name: string; paksha: "Shukla" | "Krishna"; raw: number };
  nakshatra: { number: number; name: string; pada: number };
  yoga: { number: number; name: string };
  karana: { number: number; name: string };
  vaar: string;
  sun: { rise: string; set: string };
  moon: { rise: string | null; set: string | null };
  next_sunrise?: string;
  rahu_kaal: { start: string; end: string };
  yamaganda: { start: string; end: string };
  gulika: { start: string; end: string };
  abhijit: { start: string; end: string } | null;
  ascendant?: PanchangAscendant;
  planets?: PanchangPlanet[];
  hora?: { day: HoraEntry[]; night: HoraEntry[] };
  cached: boolean;
}

// Traditional Vedic planet colors — every planet uniquely distinguishable.
// Vedic standard palette adjusted to remove same-color collisions
// (Mars≠Venus, Sun≠Saturn, Mercury≠Ketu).
// AstroSage-matched palette — every planet uniquely distinguishable.
export const PLANET_COLORS: Record<PlanetName, string> = {
  Sun:     "#C0392B", // strong warm red
  Moon:    "#7D3C98", // soft calm purple
  Mars:    "#1E8449", // dark green
  Mercury: "#2E86C1", // intellectual blue
  Jupiter: "#A93989", // magenta — AstroSage Vedic convention
  Venus:   "#27AE60", // harmonious green
  Saturn:  "#1B4F72", // heavy serious dark blue
  Rahu:    "#922B21", // intense dark red
  Ketu:    "#C88E45", // tan/copper — traditional Vedic smoky/tawny Ketu
};

export const PLANET_ABBR: Record<PlanetName, string> = {
  Sun: "Su", Moon: "Mo", Mars: "Ma", Mercury: "Me",
  Jupiter: "Ju", Venus: "Ve", Saturn: "Sa",
  Rahu: "Ra", Ketu: "Ke",
};

// Devanagari abbreviations used inside Hindi chart cells.
export const PLANET_ABBR_HI: Record<PlanetName, string> = {
  Sun: "सू", Moon: "चं", Mars: "मं", Mercury: "बु",
  Jupiter: "गु", Venus: "शु", Saturn: "श",
  Rahu: "रा", Ketu: "के",
};

// 4-letter abbreviations used in the planetary position table (English).
export const PLANET_TABLE_NAME: Record<PlanetName, string> = {
  Sun: "Sun", Moon: "Moon", Mars: "Mars", Mercury: "Merc",
  Jupiter: "Jupt", Venus: "Venu", Saturn: "Satn",
  Rahu: "Rahu", Ketu: "Ketu",
};

// Full Hindi/Sanskrit planet names for the planetary position table.
export const PLANET_TABLE_NAME_HI: Record<PlanetName, string> = {
  Sun: "सूर्य", Moon: "चन्द्र", Mars: "मंगल", Mercury: "बुध",
  Jupiter: "गुरु", Venus: "शुक्र", Saturn: "शनि",
  Rahu: "राहु", Ketu: "केतु",
};

// Sign names — index 0 = Aries (sign number 1).
export const SIGN_NAMES_EN: string[] = [
  "Aries","Taurus","Gemini","Cancer","Leo","Virgo",
  "Libra","Scorpio","Sagittarius","Capricorn","Aquarius","Pisces",
];

export const SIGN_NAMES_HI: string[] = [
  "मेष","वृषभ","मिथुन","कर्क","सिंह","कन्या",
  "तुला","वृश्चिक","धनु","मकर","कुम्भ","मीन",
];

// Nakshatra names — index 0 = Ashwini (nakshatra number 1).
export const NAKSHATRA_NAMES_HI: string[] = [
  "अश्विनी","भरणी","कृत्तिका","रोहिणी","मृगशिरा","आर्द्रा",
  "पुनर्वसु","पुष्य","आश्लेषा","मघा","पूर्व फाल्गुनी","उत्तर फाल्गुनी",
  "हस्त","चित्रा","स्वाति","विशाखा","अनुराधा","ज्येष्ठा",
  "मूल","पूर्वाषाढ़ा","उत्तराषाढ़ा","श्रवण","धनिष्ठा","शतभिषा",
  "पूर्व भाद्रपद","उत्तर भाद्रपद","रेवती",
];

// Soft background tint per Hora planet (for table row tinting).
export const HORA_PLANET_TINT: Record<HoraEntry["planet"], string> = {
  Sun:     "rgba(198, 40, 40, 0.08)",
  Venus:   "rgba(46, 125, 50, 0.08)",
  Mercury: "rgba(46, 125, 50, 0.08)",
  Moon:    "rgba(106, 27, 154, 0.08)",
  Saturn:  "rgba(13, 71, 161, 0.08)",
  Jupiter: "rgba(123, 31, 162, 0.08)",
  Mars:    "rgba(27, 94, 32, 0.08)",
};

export const HORA_PLANET_COLOR: Record<HoraEntry["planet"], string> = {
  Sun:     "#C62828",
  Venus:   "#388E3C",
  Mercury: "#1565C0",
  Moon:    "#7E57C2",
  Saturn:  "#1A237E",
  Jupiter: "#7B1FA2",
  Mars:    "#2E7D32",
};

// Format sidereal degree-within-sign as "DD-MM-SS"
export function formatDMSDash(degree: number): string {
  const d = Math.floor(degree);
  const mFloat = (degree - d) * 60;
  const m = Math.floor(mFloat);
  const s = Math.round((mFloat - m) * 60);
  // Handle rounding overflow
  let dd = d, mm = m, ss = s;
  if (ss === 60) { ss = 0; mm += 1; }
  if (mm === 60) { mm = 0; dd += 1; }
  const pad = (n: number) => n.toString().padStart(2, "0");
  return `${pad(dd)}-${pad(mm)}-${pad(ss)}`;
}

// Compact "DD°MM'" display used inside chart cells
export function formatDegMin(degree: number): string {
  const d = Math.floor(degree);
  const m = Math.round((degree - d) * 60);
  let dd = d, mm = m;
  if (mm === 60) { mm = 0; dd += 1; }
  return `${dd}°${mm.toString().padStart(2, "0")}'`;
}

export type ChartLang = "en" | "hi";
