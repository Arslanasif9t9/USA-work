export type DCode =
  | "D1" | "D2" | "D3" | "D4" | "D7" | "D9" | "D10" | "D12"
  | "D16" | "D20" | "D24" | "D27" | "D30" | "D40" | "D45" | "D60";

export interface VargaInfo {
  code: DCode;
  name: string;
  nameHindi: string;
  meaning: string;
  meaningHindi: string;
  description: string;
  descriptionHindi: string;
}

export interface VargaPlanetPosition {
  name: string;       // "Sun", "Moon", ...
  abbrev: string;     // "Su", "Mo"
  sign: number;       // 1..12
  house: number;      // 1..12
  degree: number;
  retrograde: boolean;
}

export interface VargaChartData {
  chart_id: DCode;
  planets: VargaPlanetPosition[];
  ascendant: number; // 1..12
}

export interface ShodashvargaResponse {
  chart: VargaChartData;
  language: "en" | "hi";
  source: "astrologyapi" | "in_house";
  cached?: boolean;
  anonymous?: boolean;
}
