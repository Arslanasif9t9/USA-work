// Lazy-loaded Agora helpers. SDK is dynamically imported so it's only fetched on /live and /astrologer/live.
import { supabase } from "@/integrations/supabase/client";

let cachedAppId: string | null = null;
let appIdPromise: Promise<string> | null = null;

/** Fetch (and cache for the session) the Agora App ID from the public edge function. */
export async function getAgoraAppId(): Promise<string> {
  if (cachedAppId !== null) return cachedAppId;
  if (appIdPromise) return appIdPromise;
  appIdPromise = (async () => {
    try {
      const { data, error } = await supabase.functions.invoke("get-agora-app-id");
      if (error) throw error;
      const id = (data as any)?.app_id ?? "";
      cachedAppId = id;
      return id;
    } catch {
      cachedAppId = "";
      return "";
    } finally {
      appIdPromise = null;
    }
  })();
  return appIdPromise;
}

/** True when no Agora App ID is configured — fall back to the Phase-1 placeholder UI. */
export async function isDemoMode(): Promise<boolean> {
  const id = await getAgoraAppId();
  return !id || id === "demo";
}

export async function fetchAgoraToken(opts: {
  channelName: string;
  uid: number;
  role: "host" | "audience";
}): Promise<{ token: string; appId: string; uid: number; channelName: string }> {
  const { data, error } = await supabase.functions.invoke("generate-agora-token", {
    body: { channel_name: opts.channelName, uid: opts.uid, role: opts.role },
  });
  if (error) throw new Error(error.message || "Failed to fetch Agora token");
  const d = data as any;
  if (!d?.token || !d?.app_id) throw new Error(d?.error || "Invalid token response");
  return { token: d.token, appId: d.app_id, uid: d.uid, channelName: d.channel_name };
}

/** Lazy import of the Agora SDK. Only loaded when this is called. */
export async function loadAgoraSDK() {
  const mod = await import("agora-rtc-sdk-ng");
  return mod.default;
}

/** Generate a stable numeric uid from a UUID string (Agora uids must be uint32). */
export function uidFromUserId(userId: string | null | undefined): number {
  if (!userId) return Math.floor(Math.random() * 0x7fffffff);
  let h = 0;
  for (let i = 0; i < userId.length; i++) {
    h = ((h << 5) - h + userId.charCodeAt(i)) | 0;
  }
  return Math.abs(h) % 0x7fffffff || 1;
}
