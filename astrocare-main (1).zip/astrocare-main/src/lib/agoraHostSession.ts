// Module-level singleton store for the astrologer's active Agora broadcast.
// Survives React unmount/remount (tab switch, dashboard navigation, etc.) so
// returning to the broadcast page does NOT lose the camera/mic or the channel
// connection. Only an explicit endLive() should clear this.

interface HostSession {
  streamId: string;
  channelName: string;
  client: any;
  audioTrack: any;
  videoTrack: any;
}

let current: HostSession | null = null;

export function setHostSession(s: HostSession) {
  current = s;
}

export function getHostSession(streamId: string): HostSession | null {
  if (current && current.streamId === streamId) return current;
  return null;
}

export function clearHostSession() {
  current = null;
}

export function isHostSessionHealthy(streamId: string): boolean {
  const s = getHostSession(streamId);
  if (!s) return false;
  try {
    const state = s.client?.connectionState;
    if (state && state !== "CONNECTED") return false;
    // Tracks expose an internal _enabled / muted; readyState lives on MediaStreamTrack
    const v = s.videoTrack?.getMediaStreamTrack?.();
    const a = s.audioTrack?.getMediaStreamTrack?.();
    if (v && v.readyState === "ended") return false;
    if (a && a.readyState === "ended") return false;
    return true;
  } catch {
    return false;
  }
}
