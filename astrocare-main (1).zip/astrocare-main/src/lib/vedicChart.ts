// Vedic chart math + helpers (client-side, derived from calculate-chart output)

export const SIGNS = [
  "Aries","Taurus","Gemini","Cancer","Leo","Virgo",
  "Libra","Scorpio","Sagittarius","Capricorn","Aquarius","Pisces",
] as const;
export type SignName = typeof SIGNS[number];

export const SIGN_SHORT: Record<SignName, string> = {
  Aries: "Ar", Taurus: "Ta", Gemini: "Ge", Cancer: "Cn",
  Leo: "Le", Virgo: "Vi", Libra: "Li", Scorpio: "Sc",
  Sagittarius: "Sg", Capricorn: "Cp", Aquarius: "Aq", Pisces: "Pi",
};

export const PLANET_ABBR: Record<string, string> = {
  Sun: "Su", Moon: "Mo", Mars: "Ma", Mercury: "Me",
  Jupiter: "Ju", Venus: "Ve", Saturn: "Sa", Rahu: "Ra", Ketu: "Ke",
};

export interface RawPlanet {
  name: string;
  longitude: number; // sidereal 0-359.99
  sign: SignName;
  degree: number;
  retrograde?: boolean;
}

export interface RawAscendant {
  longitude: number;
  sign: SignName;
  degree: number;
}

export interface ChartData {
  planets: RawPlanet[];
  ascendant: RawAscendant;
}

export interface PlacedPlanet {
  name: string;
  abbr: string;
  signIndex: number; // 0-11
  house: number;     // 1-12 (whole-sign from ascendant)
  degree: number;
  retrograde?: boolean;
}

export interface ChartView {
  ascSignIndex: number;
  ascDegree: number;
  planets: PlacedPlanet[];
}

const norm360 = (x: number) => ((x % 360) + 360) % 360;

export function signIndexFromLon(lon: number): number {
  return Math.floor(norm360(lon) / 30) % 12;
}

// Whole-sign houses: house 1 = ascendant sign
function wholeSignHouse(signIndex: number, ascSignIndex: number): number {
  return ((signIndex - ascSignIndex + 12) % 12) + 1;
}

// D9 Navamsa: each sign split into 9 parts of 3°20' (3.3333°).
// Starting sign of navamsa series:
//   movable signs (Ar, Cn, Li, Cp): start from same sign
//   fixed signs (Ta, Le, Sc, Aq):    start from 9th sign
//   dual signs (Ge, Vi, Sg, Pi):     start from 5th sign
function navamsaSignIndex(lon: number): number {
  const sign = signIndexFromLon(lon);
  const within = norm360(lon) - sign * 30;
  const navIdx = Math.floor(within / (30 / 9)); // 0..8
  const mod = sign % 3; // 0 movable, 1 fixed, 2 dual
  const startOffset = mod === 0 ? 0 : mod === 1 ? 8 : 4;
  return (sign + startOffset + navIdx) % 12;
}

export function buildD1(data: ChartData): ChartView {
  const ascSignIndex = signIndexFromLon(data.ascendant.longitude);
  const planets: PlacedPlanet[] = data.planets.map((p) => {
    const signIndex = signIndexFromLon(p.longitude);
    return {
      name: p.name,
      abbr: PLANET_ABBR[p.name] ?? p.name.slice(0, 2),
      signIndex,
      house: wholeSignHouse(signIndex, ascSignIndex),
      degree: p.degree,
      retrograde: p.retrograde,
    };
  });
  return { ascSignIndex, ascDegree: data.ascendant.degree, planets };
}

export function buildD9(data: ChartData): ChartView {
  const ascNav = navamsaSignIndex(data.ascendant.longitude);
  const planets: PlacedPlanet[] = data.planets.map((p) => {
    const signIndex = navamsaSignIndex(p.longitude);
    return {
      name: p.name,
      abbr: PLANET_ABBR[p.name] ?? p.name.slice(0, 2),
      signIndex,
      house: wholeSignHouse(signIndex, ascNav),
      degree: 0, // not meaningful in navamsa visual
      retrograde: p.retrograde,
    };
  });
  return { ascSignIndex: ascNav, ascDegree: 0, planets };
}

// Group planets by house number (1..12)
export function groupByHouse(view: ChartView): Record<number, PlacedPlanet[]> {
  const map: Record<number, PlacedPlanet[]> = {};
  for (let i = 1; i <= 12; i++) map[i] = [];
  for (const p of view.planets) map[p.house].push(p);
  return map;
}

// For South Indian: group planets by sign index (0..11)
export function groupBySign(view: ChartView): Record<number, PlacedPlanet[]> {
  const map: Record<number, PlacedPlanet[]> = {};
  for (let i = 0; i < 12; i++) map[i] = [];
  for (const p of view.planets) map[p.signIndex].push(p);
  return map;
}
