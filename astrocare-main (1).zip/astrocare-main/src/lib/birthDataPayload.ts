/**
 * Build the inline `birth_data` payload edge functions accept in anonymous mode.
 * Used by the dual-mode flow so logged-out users on `local-{uuid}` charts can
 * call edge functions without DB-backed birth_chart_id lookups.
 */
import type { BirthChartRow } from "@/hooks/useBirthCharts";

export interface InlineBirthData {
  day: number; month: number; year: number;
  hour: number; min: number;
  lat: number; lon: number; tzone: number;
  timezone_name: string;
  moon_longitude?: number;
  chart_data?: unknown;
}

/** Compute timezone offset in hours for a given local datetime + IANA zone. */
function tzOffsetHours(date: string, time: string, tz: string): number {
  try {
    const isoLocal = `${date}T${time}`;
    const asUtc = new Date(isoLocal + "Z");
    if (isNaN(asUtc.getTime())) return 5.5;
    const dtf = new Intl.DateTimeFormat("en-US", {
      timeZone: tz, hour12: false,
      year: "numeric", month: "2-digit", day: "2-digit",
      hour: "2-digit", minute: "2-digit", second: "2-digit",
    });
    const parts = Object.fromEntries(dtf.formatToParts(asUtc).map(p => [p.type, p.value]));
    const asTz = Date.UTC(+parts.year, +parts.month - 1, +parts.day,
      +parts.hour, +parts.minute, +parts.second);
    return (asTz - asUtc.getTime()) / 3600000;
  } catch {
    return 5.5;
  }
}

export function birthDataFromChart(chart: BirthChartRow): InlineBirthData {
  const [y, m, d] = String(chart.birth_date).split("-").map(Number);
  const timeStr = chart.time_unknown || !chart.birth_time
    ? "12:00" : String(chart.birth_time).slice(0, 5);
  const [hh, mm] = timeStr.split(":").map(Number);
  const tz = chart.timezone || "Asia/Kolkata";
  const tzone = tzOffsetHours(chart.birth_date, timeStr, tz);
  const cd = chart.chart_data as { planets?: Array<{ name: string; longitude: number }> } | null;
  const moonLon = cd?.planets?.find(p => p.name === "Moon")?.longitude;
  return {
    day: d, month: m, year: y, hour: hh, min: mm,
    lat: Number(chart.latitude), lon: Number(chart.longitude),
    tzone, timezone_name: tz,
    moon_longitude: typeof moonLon === "number" ? moonLon : undefined,
    chart_data: chart.chart_data,
  };
}
