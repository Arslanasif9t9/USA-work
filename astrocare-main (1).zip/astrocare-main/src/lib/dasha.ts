// Dasha helpers: tree types + current-period walker + planet color tokens

export const DASHA_SEQUENCE = [
  "Ketu","Venus","Sun","Moon","Mars","Rahu","Jupiter","Saturn","Mercury",
] as const;
export type DashaLord = typeof DASHA_SEQUENCE[number];

export interface DashaNode {
  lord: DashaLord;
  start: string;
  end: string;
  years: number;
  children?: DashaNode[];
}

export interface DashaTree {
  starting_nakshatra: string;
  starting_lord: DashaLord;
  moon_longitude: number;
  birth_utc: string;
  mahadashas: DashaNode[];
}

export interface DashaRow {
  id: string;
  birth_chart_id: string;
  user_id: string;
  dasha_tree: DashaTree;
  current_maha_lord: DashaLord | null;
  current_maha_start: string | null;
  current_maha_end: string | null;
  current_antar_lord: DashaLord | null;
  current_antar_start: string | null;
  current_antar_end: string | null;
  computed_at: string;
}

// Tailwind-friendly color classes per planet (using Tailwind palette names; semantic enough for chart UI)
export const PLANET_COLORS: Record<DashaLord, { bg: string; text: string; border: string; dot: string }> = {
  Sun:     { bg: "bg-orange-500/15",  text: "text-orange-700 dark:text-orange-300",  border: "border-orange-500/40",  dot: "bg-orange-500" },
  Moon:    { bg: "bg-slate-400/15",   text: "text-slate-700 dark:text-slate-200",    border: "border-slate-400/40",   dot: "bg-slate-400" },
  Mars:    { bg: "bg-red-500/15",     text: "text-red-700 dark:text-red-300",        border: "border-red-500/40",     dot: "bg-red-500" },
  Mercury: { bg: "bg-emerald-500/15", text: "text-emerald-700 dark:text-emerald-300",border: "border-emerald-500/40", dot: "bg-emerald-500" },
  Jupiter: { bg: "bg-yellow-500/15",  text: "text-yellow-700 dark:text-yellow-300",  border: "border-yellow-500/40",  dot: "bg-yellow-500" },
  Venus:   { bg: "bg-pink-400/15",    text: "text-pink-700 dark:text-pink-200",      border: "border-pink-400/40",    dot: "bg-pink-400" },
  Saturn:  { bg: "bg-blue-700/15",    text: "text-blue-800 dark:text-blue-300",      border: "border-blue-700/40",    dot: "bg-blue-700" },
  Rahu:    { bg: "bg-zinc-500/15",    text: "text-zinc-700 dark:text-zinc-300",      border: "border-zinc-500/40",    dot: "bg-zinc-500" },
  Ketu:    { bg: "bg-amber-800/15",   text: "text-amber-800 dark:text-amber-300",    border: "border-amber-700/40",   dot: "bg-amber-800" },
};

export function findCurrent(nodes: DashaNode[] | undefined, now = new Date()): DashaNode | null {
  if (!nodes) return null;
  const t = now.getTime();
  for (const n of nodes) {
    if (t >= new Date(n.start).getTime() && t < new Date(n.end).getTime()) return n;
  }
  return null;
}

export function formatPeriodRange(startISO: string, endISO: string): string {
  const fmt = (s: string) => {
    const d = new Date(s);
    return d.toLocaleDateString(undefined, { day: "2-digit", month: "short", year: "numeric" });
  };
  return `${fmt(startISO)} – ${fmt(endISO)}`;
}

export function formatYears(years: number): string {
  if (years >= 1) {
    const y = Math.floor(years);
    const months = Math.round((years - y) * 12);
    return months ? `${y}y ${months}m` : `${y}y`;
  }
  const days = Math.round(years * 365.25);
  if (days >= 30) return `${Math.round(days / 30)}mo`;
  return `${days}d`;
}
