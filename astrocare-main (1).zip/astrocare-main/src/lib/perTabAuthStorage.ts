/**
 * Per-tab Supabase auth storage shim.
 *
 * The auto-generated `src/integrations/supabase/client.ts` configures Supabase
 * to use `localStorage` for its auth session. localStorage is shared across
 * every tab on the same origin, so signing in on one tab clobbers the session
 * in all other tabs.
 *
 * We need each browser tab to hold its own independent Supabase session
 * (customer in tab A, astrologer in tab B, admin in tab C) for QA and
 * day-to-day multi-role testing.
 *
 * Strategy (Option A — sessionStorage per tab):
 *   - sessionStorage is already scoped to a single tab and survives refresh
 *     within that tab, exactly matching our requirements.
 *   - We install a Proxy on `window.localStorage` that transparently
 *     redirects reads/writes for Supabase auth keys (anything matching
 *     `sb-*-auth-token` or starting with `supabase.auth.`) into
 *     sessionStorage. Every other localStorage key (theme, language, app
 *     preferences, etc.) keeps its normal cross-tab behaviour.
 *   - This module MUST be imported before `src/integrations/supabase/client.ts`
 *     so that when Supabase captures `localStorage`, it captures the proxy.
 *
 * Side benefits:
 *   - Closing a tab clears that tab's session — matches a "fresh" QA tab.
 *   - Sign-out in one tab does not touch any other tab's session.
 *   - Token auto-refresh keeps working because sessionStorage exposes the
 *     same get/set/remove API.
 */

const AUTH_KEY_PATTERNS: Array<RegExp> = [
  /^sb-.*-auth-token(\..+)?$/, // sb-<projectref>-auth-token, sb-...-auth-token-code-verifier, etc.
  /^supabase\.auth\./,
];

function isAuthKey(key: string): boolean {
  return AUTH_KEY_PATTERNS.some((re) => re.test(key));
}

function installPerTabAuthStorage() {
  if (typeof window === "undefined") return;
  // Install only once, even under HMR.
  if ((window as unknown as { __perTabAuthStorageInstalled?: boolean }).__perTabAuthStorageInstalled) {
    return;
  }

  const realLocal = window.localStorage;
  const session = window.sessionStorage;

  // One-time migration: if a previous build left an auth token in
  // localStorage, copy it into this tab's sessionStorage so the user
  // doesn't get unexpectedly logged out on the first load after deploy.
  // Then strip it from localStorage so it stops leaking across tabs.
  try {
    const keysToMigrate: string[] = [];
    for (let i = 0; i < realLocal.length; i++) {
      const k = realLocal.key(i);
      if (k && isAuthKey(k)) keysToMigrate.push(k);
    }
    for (const k of keysToMigrate) {
      if (session.getItem(k) === null) {
        const v = realLocal.getItem(k);
        if (v !== null) session.setItem(k, v);
      }
      realLocal.removeItem(k);
    }
  } catch {
    // ignore — storage may be unavailable in some embedded contexts
  }

  const patched: Storage = {
    getItem(key: string): string | null {
      return isAuthKey(key) ? session.getItem(key) : realLocal.getItem(key);
    },
    setItem(key: string, value: string): void {
      if (isAuthKey(key)) session.setItem(key, value);
      else realLocal.setItem(key, value);
    },
    removeItem(key: string): void {
      if (isAuthKey(key)) session.removeItem(key);
      else realLocal.removeItem(key);
    },
    clear(): void {
      // Only clear non-auth localStorage keys; leave other tabs' auth alone.
      // Auth lives in sessionStorage, which is already tab-scoped.
      realLocal.clear();
    },
    key(index: number): string | null {
      return realLocal.key(index);
    },
    get length(): number {
      return realLocal.length;
    },
  };

  try {
    Object.defineProperty(window, "localStorage", {
      configurable: true,
      get() {
        return patched;
      },
    });
    (window as unknown as { __perTabAuthStorageInstalled?: boolean }).__perTabAuthStorageInstalled = true;
  } catch {
    // Some browsers refuse to redefine window.localStorage. In that case
    // we fall back to monkey-patching the prototype methods so callers that
    // go through localStorage.getItem/setItem still hit our redirector.
    const proto = Object.getPrototypeOf(realLocal) as Storage;
    const origGet = proto.getItem.bind(realLocal);
    const origSet = proto.setItem.bind(realLocal);
    const origRemove = proto.removeItem.bind(realLocal);
    proto.getItem = function (key: string) {
      return isAuthKey(key) ? session.getItem(key) : origGet(key);
    };
    proto.setItem = function (key: string, value: string) {
      if (isAuthKey(key)) session.setItem(key, value);
      else origSet(key, value);
    };
    proto.removeItem = function (key: string) {
      if (isAuthKey(key)) session.removeItem(key);
      else origRemove(key);
    };
    (window as unknown as { __perTabAuthStorageInstalled?: boolean }).__perTabAuthStorageInstalled = true;
  }
}

installPerTabAuthStorage();

export {};
