// Centralized helper for serving astrologer avatar images at the right size & quality.
//
// Why this exists:
// - Source images stored in Supabase Storage can be requested via image transformation
//   query params (?width=&height=&resize=&quality=) on the public render endpoint.
// - Components were rendering raw `avatar_url` at full resolution everywhere — wasteful
//   on cards and (worse) blurry when the source asset itself is small. This helper
//   normalizes both cases: it requests an appropriate size for the visible variant,
//   and gracefully falls back to the original URL for non-Supabase hosts.
// - Astrologers can re-upload higher-resolution headshots (≥1024×1024) at any time;
//   this helper will then serve sharper images automatically without code changes.

export type AvatarVariant = "thumbnail" | "card" | "profile" | "hero";

const SIZES: Record<AvatarVariant, { w: number; h: number; q: number }> = {
  thumbnail: { w: 96, h: 96, q: 85 },
  card: { w: 400, h: 400, q: 90 },
  profile: { w: 800, h: 800, q: 90 },
  hero: { w: 1200, h: 1200, q: 95 },
};

// Public placeholder shipped with the project (saffron silhouette / brand-friendly).
export const DEFAULT_ASTROLOGER_AVATAR = "/placeholder.svg";

function isSupabaseStorageUrl(url: string): boolean {
  // Matches both /storage/v1/object/public/... and any *.supabase.co storage path.
  return /\/storage\/v1\/(object|render\/image)\/(public|sign|authenticated)\//.test(url);
}

function withTransform(url: string, w: number, h: number, q: number): string {
  // Convert /object/ → /render/image/ which supports transformations.
  const rendered = url.replace("/storage/v1/object/", "/storage/v1/render/image/");
  const sep = rendered.includes("?") ? "&" : "?";
  return `${rendered}${sep}width=${w}&height=${h}&resize=cover&quality=${q}`;
}

/**
 * Build a sized avatar URL for the given variant.
 * Falls back to the default avatar when no source URL is provided.
 */
export function getAstrologerImageUrl(
  baseUrl: string | null | undefined,
  variant: AvatarVariant = "card",
): string {
  if (!baseUrl) return DEFAULT_ASTROLOGER_AVATAR;
  const { w, h, q } = SIZES[variant];
  if (isSupabaseStorageUrl(baseUrl)) return withTransform(baseUrl, w, h, q);
  return baseUrl;
}

/**
 * Build a srcSet (1x / 2x) for retina displays.
 */
export function getAstrologerImageSrcSet(
  baseUrl: string | null | undefined,
  variant: AvatarVariant = "card",
): string | undefined {
  if (!baseUrl || !isSupabaseStorageUrl(baseUrl)) return undefined;
  const { w, h, q } = SIZES[variant];
  return `${withTransform(baseUrl, w, h, q)} 1x, ${withTransform(baseUrl, w * 2, h * 2, q)} 2x`;
}
