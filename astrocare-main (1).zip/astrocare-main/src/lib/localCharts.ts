/**
 * Anonymous (logged-out) birth charts live in sessionStorage so cold marketing
 * traffic can try the Free Kundli flow end-to-end without signing up. Each
 * local chart gets a `local-{uuid}` id and is rendered through the same
 * `/chart/:id` view as saved DB charts.
 *
 * sessionStorage (not localStorage) is intentional — matches the existing
 * per-tab auth pattern and ensures the chart doesn't leak across tabs.
 */
import type { BirthChartRow } from "@/hooks/useBirthCharts";

const NS = "anon_birth_charts_v1";
export const LOCAL_PREFIX = "local-";

interface Bag {
  [id: string]: BirthChartRow;
}

function readBag(): Bag {
  if (typeof window === "undefined") return {};
  try {
    const raw = sessionStorage.getItem(NS);
    return raw ? JSON.parse(raw) as Bag : {};
  } catch {
    return {};
  }
}

function writeBag(bag: Bag) {
  try { sessionStorage.setItem(NS, JSON.stringify(bag)); } catch { /* quota */ }
}

export function isLocalChartId(id: string | undefined | null): boolean {
  return !!id && id.startsWith(LOCAL_PREFIX);
}

export function newLocalChartId(): string {
  const uuid = (typeof crypto !== "undefined" && "randomUUID" in crypto)
    ? crypto.randomUUID()
    : Math.random().toString(36).slice(2) + Date.now().toString(36);
  return `${LOCAL_PREFIX}${uuid}`;
}

export function saveLocalChart(row: BirthChartRow): void {
  const bag = readBag();
  bag[row.id] = row;
  writeBag(bag);
}

export function getLocalChart(id: string): BirthChartRow | null {
  return readBag()[id] ?? null;
}

export function listLocalCharts(): BirthChartRow[] {
  return Object.values(readBag()).sort(
    (a, b) => (b.created_at || "").localeCompare(a.created_at || ""),
  );
}

export function deleteLocalChart(id: string): void {
  const bag = readBag();
  delete bag[id];
  writeBag(bag);
}

export function clearAllLocalCharts(): void {
  try { sessionStorage.removeItem(NS); } catch { /* ignore */ }
}

// ============================================================================
// Shareable encoding — embeds the entire chart row in a URL hash so anonymous
// charts can be opened on any device/browser. The hash (`#c=...`) is never
// sent to the server, keeps URLs self-contained, and bypasses sessionStorage.
// ============================================================================

const HASH_KEY = "c";

/** Base64url-encode a UTF-8 string. */
function b64urlEncode(str: string): string {
  // encode UTF-8 → base64 → base64url
  const b64 = btoa(unescape(encodeURIComponent(str)));
  return b64.replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
}

/** Base64url-decode back to a UTF-8 string. */
function b64urlDecode(str: string): string {
  const b64 = str.replace(/-/g, "+").replace(/_/g, "/")
    + "==".slice(0, (4 - (str.length % 4)) % 4);
  return decodeURIComponent(escape(atob(b64)));
}

/** Build a shareable URL that embeds the chart row in the hash. */
export function buildShareableChartUrl(
  chart: BirthChartRow,
  baseUrl: string,
): string {
  try {
    const payload = b64urlEncode(JSON.stringify(chart));
    const sep = baseUrl.includes("#") ? "&" : "#";
    return `${baseUrl}${sep}${HASH_KEY}=${payload}`;
  } catch {
    return baseUrl;
  }
}

/** Read a chart row from the current location hash, if present. */
export function readChartFromHash(): BirthChartRow | null {
  if (typeof window === "undefined") return null;
  const raw = window.location.hash.replace(/^#/, "");
  if (!raw) return null;
  const params = new URLSearchParams(raw);
  const encoded = params.get(HASH_KEY);
  if (!encoded) return null;
  try {
    const json = b64urlDecode(encoded);
    const parsed = JSON.parse(json) as BirthChartRow;
    if (!parsed || typeof parsed !== "object" || !parsed.id) return null;
    return parsed;
  } catch {
    return null;
  }
}

