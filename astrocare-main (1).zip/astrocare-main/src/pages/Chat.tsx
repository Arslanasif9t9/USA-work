import { useEffect, useMemo, useRef, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { useAuth } from "@/contexts/AuthContext";
import { supabase } from "@/integrations/supabase/client";
import { useChatSession, sendChatMessage } from "@/hooks/useChatSession";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Gift, Send, PhoneOff, Loader2, Star, Sparkles } from "lucide-react";
import { GiftModal } from "@/components/chat/GiftModal";
import { EndSessionDialog } from "@/components/chat/EndSessionDialog";
import { SessionEndedOverlay } from "@/components/chat/SessionEndedOverlay";
import { SessionEndedScreen } from "@/components/chat/SessionEndedScreen";
import { EmojiPickerButton } from "@/components/chat/EmojiPickerButton";
import { toast } from "sonner";
import { cn } from "@/lib/utils";

interface AstroLite {
  id: string;
  display_name: string;
  avatar_url: string | null;
  user_id: string | null;
  rating_avg: number;
  rating_count: number;
  specializations: string[];
}

interface CustomerLite {
  id: string;
  name: string;
  avatar_url: string | null;
}

function fmt(s: number) {
  const m = Math.floor(s / 60);
  const sec = s % 60;
  return `${m.toString().padStart(2, "0")}:${sec.toString().padStart(2, "0")}`;
}

const isMobile = () =>
  typeof navigator !== "undefined" && /Mobi|Android|iPhone|iPad|iPod/i.test(navigator.userAgent);

export default function Chat() {
  const { id: sessionId } = useParams();
  const { user } = useAuth();
  const navigate = useNavigate();
  const { session, messages, loading } = useChatSession(sessionId ?? null);
  const [astro, setAstro] = useState<AstroLite | null>(null);
  const [customer, setCustomer] = useState<CustomerLite | null>(null);
  const [input, setInput] = useState("");
  const [sending, setSending] = useState(false);
  const [giftOpen, setGiftOpen] = useState(false);
  const [elapsed, setElapsed] = useState(0);
  const [confirmEnd, setConfirmEnd] = useState(false);
  const [endingNow, setEndingNow] = useState(false);
  const [astroSlug, setAstroSlug] = useState<string | null>(null);
  const scrollRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLTextAreaElement>(null);
  const endingTriggeredRef = useRef(false);

  const isCustomer = user?.id === session?.user_id;
  const isAstrologer = user?.id === astro?.user_id;
  const canChat = session?.status === "active" && (isCustomer || isAstrologer);

  // Load astrologer and customer
  useEffect(() => {
    if (!session) return;
    supabase
      .from("astrologers")
      .select("id, display_name, avatar_url, user_id, rating_avg, rating_count, specializations, slug")
      .eq("id", session.astrologer_id)
      .single()
      .then(({ data }) => {
        setAstro(data as AstroLite);
        setAstroSlug((data as any)?.slug ?? null);
      });
    supabase
      .from("profiles")
      .select("id, name, avatar_url")
      .eq("id", session.user_id)
      .single()
      .then(({ data }) => setCustomer(data as CustomerLite));
  }, [session?.astrologer_id, session?.user_id]);

  // Tick elapsed time when active
  useEffect(() => {
    if (!session || session.status !== "active" || !session.accepted_at) return;
    const start = new Date(session.accepted_at).getTime();
    const id = setInterval(() => setElapsed(Math.floor((Date.now() - start) / 1000)), 1000);
    setElapsed(Math.floor((Date.now() - start) / 1000));
    return () => clearInterval(id);
  }, [session?.status, session?.accepted_at]);

  // Auto-scroll
  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: "smooth" });
  }, [messages.length]);

  // FIX 7: When session ends, redirect to standalone end-session route so
  // the URL is clean and the page is fully interactive (no stuck overlay).
  useEffect(() => {
    if (!session || !sessionId) return;
    const isEnded = session.status === "ended" || session.status === "rejected" || session.status === "cancelled";
    if (!isEnded) return;
    // Wait one tick so EndSessionDialog can show the loading state if user just clicked end
    const t = setTimeout(() => {
      if (isAstrologer) navigate(`/astrologer/chat/endsession?sessionId=${sessionId}`, { replace: true });
      else navigate(`/chat/endsession?sessionId=${sessionId}`, { replace: true });
    }, 250);
    return () => clearTimeout(t);
  }, [session?.status, sessionId, isAstrologer, navigate]);

  // FIX 1 & 5: NO auto-redirect after session ends — user controls navigation.

  // NOTE: We intentionally do NOT auto-end the session on tab close / page hide.
  // Sessions only end when the user explicitly clicks "End Session" or the
  // server-side billing job ends them due to low balance.

  // Auto-focus input after sending (desktop only)
  const focusInput = () => {
    if (isMobile()) return;
    requestAnimationFrame(() => inputRef.current?.focus());
  };

  // Keep focus when session becomes active
  useEffect(() => {
    if (canChat && !isMobile()) {
      requestAnimationFrame(() => inputRef.current?.focus());
    }
  }, [canChat]);

  const onSend = async () => {
    const text = input.trim();
    if (!text || !sessionId || !user || !canChat) return;
    setSending(true);
    setInput("");
    const role = isCustomer ? "customer" : "astrologer";
    const { error } = await sendChatMessage(sessionId, user.id, role, text);
    if (error) toast.error(error.message);
    setSending(false);
    focusInput();
  };

  const onConfirmEnd = async () => {
    if (!sessionId || endingNow) return;
    setEndingNow(true);
    endingTriggeredRef.current = true;
    setConfirmEnd(false);

    // Single source of truth: edge function calls end_chat_session() which
    // handles billing, 30/70 split, astrologer credit, status update.
    // Realtime UPDATE on chat_sessions row syncs both clients automatically.
    const { data, error } = await supabase.functions.invoke("end-chat", {
      body: { session_id: sessionId },
    });
    if (error) {
      console.error("end-chat failed", error);
      toast.error("Could not end the session. Please try again.");
      setEndingNow(false);
      return;
    }
    if ((data as any)?.error) {
      toast.error((data as any).error);
      setEndingNow(false);
    }
  };

  const cost = useMemo(() => {
    if (!session) return 0;
    if (session.status === "ended") {
      return Number((session as any).total_cost ?? 0)
        || Math.max(1, Math.ceil(session.duration_seconds / 60)) * Number(session.per_minute_rate);
    }
    return Math.max(1, Math.ceil(elapsed / 60)) * Number(session.per_minute_rate);
  }, [elapsed, session]);

  if (loading) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-[#0F0A1E] text-white">
        <Loader2 className="h-8 w-8 animate-spin text-amber-400" />
      </div>
    );
  }

  if (!session) {
    return (
      <div className="flex min-h-screen flex-col items-center justify-center gap-4 bg-[#0F0A1E] text-white">
        <p>Chat session not found.</p>
        <Button onClick={() => navigate("/astrologers")} className="bg-amber-500 text-black hover:bg-amber-400">Back to astrologers</Button>
      </div>
    );
  }

  const otherName = isCustomer ? astro?.display_name : customer?.name;
  const otherAvatar = isCustomer ? astro?.avatar_url : customer?.avatar_url;
  const initials = (otherName ?? "U").split(" ").map((p) => p[0]).join("").slice(0, 2).toUpperCase();
  const ended = session.status === "ended" || session.status === "rejected" || session.status === "cancelled";
  const endedByMe =
    (isCustomer && session.ended_by === "customer") || (isAstrologer && session.ended_by === "astrologer");
  const finalDuration = session.status === "ended" ? session.duration_seconds : elapsed;
  const finalCost = Number((session as any).total_cost ?? 0) || cost;

  return (
    <div className="relative min-h-screen overflow-hidden bg-[#0F0A1E] text-white">
      {/* Cosmic background */}
      <div className="pointer-events-none absolute inset-0 [background-image:radial-gradient(white_1px,transparent_1px)] [background-size:32px_32px] opacity-[0.07]" />
      <div className="pointer-events-none absolute -top-40 -left-40 h-96 w-96 rounded-full bg-purple-700/30 blur-3xl" />
      <div className="pointer-events-none absolute -bottom-40 -right-40 h-96 w-96 rounded-full bg-indigo-600/30 blur-3xl" />

      <div className="relative mx-auto grid h-screen w-full max-w-7xl grid-cols-1 gap-4 p-4 md:grid-cols-[1fr_3fr]">
        {/* Sidebar */}
        <aside className="flex flex-col rounded-2xl border border-white/10 bg-white/5 p-5 backdrop-blur-xl">
          <div className="flex flex-col items-center text-center">
            <div className="relative">
              <span className={cn("absolute inset-0 -m-1 rounded-full", session.status === "active" ? "bg-emerald-400/40 animate-ping" : "bg-white/10")} />
              <Avatar className="relative h-24 w-24 ring-4 ring-amber-300/70">
                <AvatarImage src={otherAvatar ?? undefined} alt={otherName} className="object-cover" />
                <AvatarFallback className="bg-purple-700 text-2xl font-semibold">{initials}</AvatarFallback>
              </Avatar>
            </div>
            <h2 className="mt-3 font-serif text-2xl font-bold tracking-wide">{otherName ?? "—"}</h2>
            {isCustomer && astro && (
              <>
                <div className="mt-1 flex items-center gap-1 text-amber-300">
                  <Star className="h-4 w-4 fill-current" />
                  <span className="text-sm font-semibold">{astro.rating_avg.toFixed(1)}</span>
                  <span className="text-xs text-white/60">({astro.rating_count})</span>
                </div>
                {astro.specializations?.length > 0 && (
                  <p className="mt-2 flex flex-wrap justify-center gap-1.5 text-xs">
                    {astro.specializations.slice(0, 4).map((s) => (
                      <span key={s} className="rounded-full bg-white/10 px-2 py-0.5">{s}</span>
                    ))}
                  </p>
                )}
              </>
            )}
            <span
              className={cn(
                "mt-3 inline-flex items-center gap-1.5 rounded-full px-3 py-1 text-xs font-medium",
                session.status === "active"
                  ? "bg-emerald-500/20 text-emerald-200"
                  : ended
                  ? "bg-white/10 text-white/70"
                  : "bg-amber-500/20 text-amber-200",
              )}
            >
              <span className={cn("h-2 w-2 rounded-full", session.status === "active" ? "bg-emerald-400" : "bg-white/40")} />
              {session.status === "active" ? "Session Active" : ended ? "Session Ended" : "Pending"}
            </span>
          </div>

          {/* Session card */}
          <div className="mt-6 space-y-3 rounded-xl border border-white/10 bg-white/5 p-4">
            <div className="flex items-center justify-between text-sm">
              <span className="text-white/60">Rate</span>
              <span className="font-semibold text-amber-200">₹{session.per_minute_rate} / min</span>
            </div>
            <div className="flex items-center justify-between text-sm">
              <span className="text-white/60">Duration</span>
              <span className="font-mono text-lg font-bold tracking-wider">
                {fmt(session.status === "active" ? elapsed : session.duration_seconds)}
              </span>
            </div>
            <div className="flex items-center justify-between text-sm">
              <span className="text-white/60">Cost so far</span>
              <span className="text-lg font-bold text-emerald-300">₹{cost}</span>
            </div>
          </div>

          <div className="mt-auto flex flex-col gap-2 pt-6">
            {isCustomer && session.status === "active" && (
              <Button
                variant="outline"
                className="w-full border-amber-300/40 bg-amber-300/10 text-amber-200 hover:bg-amber-300/20 hover:text-amber-100"
                onClick={() => setGiftOpen(true)}
              >
                <Gift className="h-4 w-4" /> Send Gift
              </Button>
            )}
            {session.status === "active" && (
              <Button
                className="w-full bg-gradient-to-r from-red-500 to-red-600 text-white hover:from-red-400 hover:to-red-500"
                onClick={() => setConfirmEnd(true)}
              >
                <PhoneOff className="h-4 w-4" /> End Session
              </Button>
            )}
          </div>
        </aside>

        {/* Chat panel */}
        <section className="flex flex-col overflow-hidden rounded-2xl border border-white/10 bg-white/5 backdrop-blur-xl">
          <header className="flex items-center justify-between border-b border-white/10 px-5 py-3">
            <div className="flex items-center gap-2">
              <Sparkles className="h-4 w-4 text-amber-300" />
              <h3 className="font-serif text-lg font-semibold">{otherName}</h3>
            </div>
            {session.status === "active" && (
              <span className="inline-flex items-center gap-1.5 rounded-full bg-emerald-500/20 px-2.5 py-1 text-xs font-medium text-emerald-200">
                <span className="h-1.5 w-1.5 rounded-full bg-emerald-400" /> Active
              </span>
            )}
          </header>

          <div ref={scrollRef} className="flex-1 overflow-y-auto px-5 py-4">
            <div className="mx-auto flex max-w-2xl flex-col gap-2.5">
              {messages.length === 0 && session.status === "active" && (
                <div className="mx-auto rounded-2xl bg-white/5 px-4 py-3 text-center text-sm text-white/60">
                  Say hello to start the conversation ✨
                </div>
              )}
              {messages.map((m) => {
                if (m.sender_role === "system") {
                  return (
                    <div key={m.id} className="mx-auto rounded-full bg-white/5 px-3 py-1 text-[11px] text-white/50">
                      {m.content}
                    </div>
                  );
                }
                const mine = m.sender_id === user?.id;
                return (
                  <div key={m.id} className={cn("flex animate-fade-in", mine ? "justify-end" : "justify-start")}>
                    <div
                      className={cn(
                        "max-w-[78%] rounded-2xl px-4 py-2.5 text-sm shadow-lg",
                        mine
                          ? "rounded-br-sm bg-gradient-to-br from-purple-600 to-indigo-600 text-white"
                          : "rounded-bl-sm border border-white/10 bg-white/10 text-white",
                      )}
                    >
                      <p className="whitespace-pre-wrap break-words leading-snug">{m.content}</p>
                      <p className={cn("mt-1 text-[10px]", mine ? "text-white/60" : "text-white/50")}>
                        {new Date(m.created_at).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
                      </p>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          <div className="border-t border-white/10 px-5 py-3">
            <div className="mx-auto flex max-w-2xl items-end gap-2">
              <Textarea
                ref={inputRef}
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === "Enter" && !e.shiftKey) {
                    e.preventDefault();
                    onSend();
                  }
                }}
                onBlur={() => {
                  // Re-focus on desktop unless user is interacting elsewhere
                  if (canChat && !isMobile()) {
                    setTimeout(() => {
                      const ae = document.activeElement;
                      const interactive =
                        ae &&
                        (ae.tagName === "INPUT" ||
                          ae.tagName === "TEXTAREA" ||
                          ae.tagName === "BUTTON" ||
                          ae.tagName === "A");
                      if (!interactive) inputRef.current?.focus();
                    }, 0);
                  }
                }}
                placeholder={canChat ? "Type a message…" : ended ? "Session ended" : "Waiting for session to start…"}
                disabled={!canChat || sending}
                rows={1}
                className="flex-1 min-h-[40px] max-h-32 resize-none rounded-2xl border-white/20 bg-white/10 py-2 text-white placeholder:text-white/40 focus-visible:ring-amber-400"
              />
              <EmojiPickerButton
                onPick={(emoji) => {
                  setInput((v) => v + emoji);
                  // keep focus on input
                  requestAnimationFrame(() => inputRef.current?.focus());
                }}
                disabled={!canChat}
              />
              <Button
                onClick={onSend}
                disabled={!canChat || sending || !input.trim()}
                size="icon"
                className="h-10 w-10 shrink-0 rounded-full bg-gradient-to-br from-amber-400 to-amber-500 text-black hover:from-amber-300 hover:to-amber-400"
              >
                {sending ? <Loader2 className="h-4 w-4 animate-spin" /> : <Send className="h-4 w-4" />}
              </Button>
            </div>
          </div>
        </section>
      </div>

      {astro && (
        <GiftModal
          open={giftOpen}
          onOpenChange={setGiftOpen}
          astrologerId={astro.id}
          astrologerName={astro.display_name}
          sessionId={sessionId}
        />
      )}

      <EndSessionDialog
        open={confirmEnd}
        onOpenChange={(v) => !endingNow && setConfirmEnd(v)}
        onConfirm={onConfirmEnd}
        durationLabel={fmt(elapsed)}
        estimatedCost={cost}
        loading={endingNow}
      />

      {ended && isAstrologer && (
        <SessionEndedOverlay
          endedBy={session.ended_by ?? null}
          durationLabel={fmt(finalDuration)}
          totalCost={finalCost}
          isCurrentUserEnder={endedByMe}
          isAstrologer
          astrologerEarning={Number((session as any).astrologer_earning ?? 0)}
          onBack={() => navigate("/astrologer/overview", { replace: true })}
        />
      )}

      {ended && !isAstrologer && astro && (
        <SessionEndedScreen
          endedBy={session.ended_by ?? null}
          durationLabel={fmt(finalDuration)}
          totalCost={finalCost}
          isCurrentUserEnder={endedByMe}
          astrologerId={astro.id}
          astrologerSlug={astroSlug}
          astrologerName={astro.display_name}
          astrologerAvatar={astro.avatar_url}
          onBack={() => {
            if (astroSlug) navigate(`/astrologer/${astroSlug}`, { replace: true });
            else navigate("/astrologers", { replace: true });
          }}
          onChatAgain={() => astroSlug && navigate(`/astrologer/${astroSlug}?action=chat`, { replace: true })}
          onCallAgain={() => astroSlug && navigate(`/astrologer/${astroSlug}?action=call`, { replace: true })}
          onSendGift={() => astroSlug && navigate(`/astrologer/${astroSlug}?action=gift`, { replace: true })}
        />
      )}
    </div>
  );
}
