import { useEffect, useMemo, useState } from "react";
import { Link, useNavigate, useParams, useSearchParams } from "react-router-dom";
import { AppShell } from "@/components/layout/AppShell";
import { BackButton } from "@/components/layout/BackButton";
import { supabase } from "@/integrations/supabase/client";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { useWallet } from "@/hooks/useWallet";
import { useFavorites } from "@/hooks/useFavorites";
import { toast } from "@/hooks/use-toast";
import { useAuth } from "@/contexts/AuthContext";
import { useAuthDialog } from "@/components/auth/AuthDialog";
import {
  ArrowLeft, GraduationCap, Crosshair, MessageCircle, Phone, Sparkles,
  Star, Users, Heart, BookOpen, Languages as LanguagesIcon, Globe2,
} from "lucide-react";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import { format } from "date-fns";
import type { Astrologer } from "@/components/astrologers/AstrologerCard";
import { ChatRequestModal } from "@/components/chat/ChatRequestModal";
import { getAstrologerImageUrl, getAstrologerImageSrcSet } from "@/lib/astrologerImage";
import { GiftModal } from "@/components/chat/GiftModal";
import { CallConfirmationModal } from "@/components/calls/CallConfirmationModal";
import { PreCallBlockerModal, type BlockerReason } from "@/components/calls/PreCallBlockerModal";

interface AstrologerExt extends Astrologer {
  education?: string | null;
  focus_area?: string | null;
  systems_known?: string[] | null;
  total_consultations?: number | null;
}

interface Review {
  id: string;
  user_id: string;
  rating: number;
  comment: string | null;
  helpful_count: number;
  created_at: string;
}

type ReviewSort = "recent" | "rating" | "helpful";
const REVIEWS_PAGE = 10;

function initials(name: string) {
  return name.split(" ").map((p) => p[0]).filter(Boolean).slice(0, 2).join("").toUpperCase();
}

function maskUserId(id: string) {
  // Display in the style of the reference: numeric-ish prefix + masked tail
  const num = parseInt(id.replace(/[^0-9]/g, "").slice(0, 7) || "0", 10) || 9000000 + Math.abs(id.charCodeAt(0) * 73);
  return `${num}*****`;
}

export default function AstrologerDetail() {
  const { slug } = useParams<{ slug: string }>();
  const navigate = useNavigate();
  const [searchParams, setSearchParams] = useSearchParams();
  const { user } = useAuth();
  const { open: openAuthDialog } = useAuthDialog();
  const { wallet } = useWallet();
  const walletBalance = Number(wallet?.balance ?? 0);
  const { favoriteIds, toggleFavorite } = useFavorites();

  const [astro, setAstro] = useState<AstrologerExt | null>(null);
  const [loading, setLoading] = useState(true);
  const [notFound, setNotFound] = useState(false);
  const [showFullBio, setShowFullBio] = useState(false);
  const [chatOpen, setChatOpen] = useState(false);
  const [giftOpen, setGiftOpen] = useState(false);
  const [callConfirmOpen, setCallConfirmOpen] = useState(false);
  const [isStartingCall, setIsStartingCall] = useState(false);
  const [callBlocker, setCallBlocker] = useState<{ reason: BlockerReason; required?: number; current?: number }>({ reason: null });
  const [userPhone, setUserPhone] = useState<string | null>(null);
  const [hasBirthChart, setHasBirthChart] = useState<boolean | null>(null);

  useEffect(() => {
    if (!user) { setUserPhone(null); setHasBirthChart(null); return; }
    let cancelled = false;
    (async () => {
      const [{ data: profile }, { count }] = await Promise.all([
        supabase.from("profiles").select("phone_e164").eq("id", user.id).maybeSingle(),
        supabase.from("birth_charts").select("id", { count: "exact", head: true }).eq("user_id", user.id),
      ]);
      if (cancelled) return;
      setUserPhone(profile?.phone_e164 ?? null);
      setHasBirthChart((count ?? 0) > 0);
    })();
    return () => { cancelled = true; };
  }, [user]);

  const [reviews, setReviews] = useState<Review[]>([]);
  const [reviewSort, setReviewSort] = useState<ReviewSort>("recent");
  const [reviewsLoading, setReviewsLoading] = useState(true);
  const [reviewsHasMore, setReviewsHasMore] = useState(true);

  useEffect(() => {
    if (!slug) return;
    let cancelled = false;
    setLoading(true);
    setNotFound(false);
    supabase.from("astrologers").select("*").eq("slug", slug).eq("approval_status", "approved").maybeSingle()
      .then(({ data, error }) => {
        if (cancelled) return;
        if (error || !data) setNotFound(true);
        else setAstro(data as unknown as AstrologerExt);
        setLoading(false);
      });
    return () => { cancelled = true; };
  }, [slug]);

  // Auto-open chat/gift modal when ?action= present (from "Chat Again" / "Send Gift" on session-ended overlay)
  useEffect(() => {
    if (!astro || !user) return;
    const action = searchParams.get("action");
    if (!action) return;
    if (action === "chat") setChatOpen(true);
    else if (action === "gift") setGiftOpen(true);
    // call: re-uses chat modal flow for now; users can hit the call button
    // Strip the query param so refresh doesn't re-trigger
    const next = new URLSearchParams(searchParams);
    next.delete("action");
    setSearchParams(next, { replace: true });
  }, [astro, user, searchParams, setSearchParams]);

  useEffect(() => {
    if (!astro?.id) return;
    let cancelled = false;
    setReviewsLoading(true);
    setReviews([]);
    setReviewsHasMore(true);
    let query = supabase.from("reviews")
      .select("id, user_id, rating, comment, helpful_count, created_at")
      .eq("astrologer_id", astro.id)
      .eq("moderation_status", "approved")
      .limit(REVIEWS_PAGE);
    if (reviewSort === "recent") query = query.order("created_at", { ascending: false });
    if (reviewSort === "rating") query = query.order("rating", { ascending: false });
    if (reviewSort === "helpful") query = query.order("helpful_count", { ascending: false });
    query.then(({ data }) => {
      if (cancelled) return;
      const list = (data ?? []) as Review[];
      setReviews(list);
      setReviewsHasMore(list.length === REVIEWS_PAGE);
      setReviewsLoading(false);
    });
    return () => { cancelled = true; };
  }, [astro?.id, reviewSort]);

  const loadMoreReviews = async () => {
    if (!astro?.id || !reviewsHasMore) return;
    let query = supabase.from("reviews")
      .select("id, user_id, rating, comment, helpful_count, created_at")
      .eq("astrologer_id", astro.id)
      .eq("moderation_status", "approved")
      .range(reviews.length, reviews.length + REVIEWS_PAGE - 1);
    if (reviewSort === "recent") query = query.order("created_at", { ascending: false });
    if (reviewSort === "rating") query = query.order("rating", { ascending: false });
    if (reviewSort === "helpful") query = query.order("helpful_count", { ascending: false });
    const { data } = await query;
    const list = (data ?? []) as Review[];
    setReviews((prev) => [...prev, ...list]);
    if (list.length < REVIEWS_PAGE) setReviewsHasMore(false);
  };

  const rate = useMemo(
    () => (astro ? (astro.discounted_rate_per_min ?? astro.base_rate_per_min) : 0),
    [astro],
  );
  const isOnline = astro?.status === "online";
  const isFavorite = !!astro && favoriteIds.has(astro.id);

  const requireAuth = () => {
    if (!user) { openAuthDialog("sign-in"); return false; }
    return true;
  };

  const handleCall = () => {
    if (!astro || !requireAuth()) return;
    if (!isOnline) { setCallBlocker({ reason: "offline" }); return; }
    if ((astro as any).accepting_calls === false) { setCallBlocker({ reason: "offline" }); return; }
    const minHold = rate * 2;
    if (!userPhone) { setCallBlocker({ reason: "no_phone" }); return; }
    if (hasBirthChart === false) { setCallBlocker({ reason: "no_chart" }); return; }
    if (walletBalance < minHold) {
      setCallBlocker({ reason: "insufficient_balance", required: minHold, current: walletBalance });
      return;
    }
    setCallConfirmOpen(true);
  };

  const handleConfirmCall = async () => {
    if (!astro) return;
    setIsStartingCall(true);
    const { data, error } = await supabase.functions.invoke("initiate-call", {
      body: { astrologer_id: astro.id },
    });
    setIsStartingCall(false);
    if (error || !data?.call_session_id) {
      const errBody = (error as { context?: { body?: unknown } } | null)?.context?.body;
      let parsed: { code?: string; required?: number; current_balance?: number; error?: string } = {};
      try { parsed = typeof errBody === "string" ? JSON.parse(errBody) : (errBody as typeof parsed) ?? {}; } catch { /* ignore */ }
      const code = parsed.code;
      if (code === "no_phone") setCallBlocker({ reason: "no_phone" });
      else if (code === "no_chart") setCallBlocker({ reason: "no_chart" });
      else if (code === "insufficient_balance") setCallBlocker({ reason: "insufficient_balance", required: parsed.required, current: parsed.current_balance });
      else if (code === "offline") setCallBlocker({ reason: "offline" });
      else if (code === "busy") setCallBlocker({ reason: "busy" });
      else toast({ title: "Could not start call", description: parsed.error ?? "Please try again.", variant: "destructive" });
      setCallConfirmOpen(false);
      return;
    }
    setCallConfirmOpen(false);
    navigate(`/call/${data.call_session_id as string}`);
  };

  if (loading) {
    return (
      <AppShell>
        <div className="container mx-auto max-w-5xl px-4 py-8 space-y-6">
          <Skeleton className="h-6 w-40" />
          <div className="flex gap-6">
            <Skeleton className="h-56 w-56 rounded-md" />
            <div className="flex-1 space-y-3">
              <Skeleton className="h-10 w-1/2" />
              <Skeleton className="h-4 w-1/3" />
              <Skeleton className="h-4 w-1/4" />
              <Skeleton className="h-24 w-full" />
            </div>
          </div>
          <Skeleton className="h-48 w-full" />
        </div>
      </AppShell>
    );
  }

  if (notFound || !astro) {
    return (
      <AppShell>
        <div className="container py-16 text-center">
          <h1 className="text-2xl font-semibold">Astrologer not found</h1>
          <Link to="/astrologers" className="mt-4 inline-block">
            <Button variant="default">
              <ArrowLeft className="mr-2 h-4 w-4" /> Browse astrologers
            </Button>
          </Link>
        </div>
      </AppShell>
    );
  }

  const hasDiscount =
    astro.discounted_rate_per_min != null &&
    astro.discounted_rate_per_min < astro.base_rate_per_min;

  const bio = astro.bio?.trim();
  const longBio = bio && bio.length > 320;
  const visibleBio = longBio && !showFullBio ? `${bio!.slice(0, 320)}…` : bio;

  return (
    <AppShell>
      <div className="container mx-auto max-w-5xl px-4 py-6 space-y-8">
        <BackButton to="/astrologers" label="All Astrologers" />

        {/* ============ HERO PROFILE CARD ============ */}
        <section className="rounded-xl bg-section border border-border p-4 md:p-6">
          <div className="grid gap-6 md:grid-cols-[260px_1fr] items-start">
            {/* Left: avatar + chat button */}
            <div className="flex flex-col gap-3">
              <div className="relative rounded-lg border bg-background p-3 shadow-sm">
                <div className="relative aspect-square w-full overflow-hidden rounded-md bg-muted">
                  <Avatar className="h-full w-full rounded-md">
                    <AvatarImage
                      src={getAstrologerImageUrl(astro.avatar_url, "profile")}
                      srcSet={getAstrologerImageSrcSet(astro.avatar_url, "profile")}
                      alt={astro.display_name}
                      className="object-cover object-[center_top]"
                    />
                    <AvatarFallback className="rounded-md bg-primary/10 text-primary text-3xl font-semibold">
                      {initials(astro.display_name)}
                    </AvatarFallback>
                  </Avatar>
                  {astro.status === "online" && (
                    <span
                      className="absolute right-3 top-3 inline-flex h-4 w-4 rounded-full bg-emerald-500 ring-2 ring-background"
                      title="Online"
                    />
                  )}
                  {astro.status === "busy" && (
                    <span
                      className="absolute right-3 top-3 inline-flex h-4 w-4 rounded-full bg-amber-500 ring-2 ring-background"
                      title="Busy"
                    />
                  )}
                  {astro.is_ai && (
                    <span className="absolute left-3 top-3 inline-flex items-center gap-1 rounded-full bg-primary px-2 py-0.5 text-xs font-semibold text-primary-foreground">
                      <Sparkles className="h-3 w-3" /> AI
                    </span>
                  )}
                </div>
              </div>

              <Button
                variant="secondary"
                className="h-11 w-full bg-secondary text-secondary-foreground hover:bg-secondary/90 font-semibold"
                onClick={() => requireAuth() && setGiftOpen(true)}
              >
                Gift
              </Button>

              <Button
                className="h-12 w-full rounded-full text-base font-semibold"
                onClick={() => requireAuth() && setChatOpen(true)}
                disabled={!isOnline}
              >
                <MessageCircle className="mr-2 h-5 w-5" /> Chat
              </Button>

              <Button
                variant="outline"
                className="h-11 w-full rounded-full"
                onClick={handleCall}
                disabled={!isOnline}
              >
                <Phone className="mr-2 h-4 w-4" /> Call Now
              </Button>
            </div>

            {/* Right: info */}
            <div className="space-y-4 min-w-0">
              <div className="flex flex-wrap items-start justify-between gap-3">
                <div>
                  <h1 className="font-display text-3xl md:text-4xl font-bold">{astro.display_name}</h1>
                  <ul className="mt-3 space-y-1.5 text-sm md:text-base">
                    <li>
                      <span className="font-semibold">Expertise:</span>{" "}
                      <span className="text-muted-foreground">
                        {astro.specializations.length
                          ? astro.specializations.map((s) => s.replace(/_/g, " ")).join(", ")
                          : "—"}
                      </span>
                    </li>
                    <li>
                      <span className="font-semibold">Experience:</span>{" "}
                      <span className="text-muted-foreground">
                        {astro.experience_years} + Years of Experience
                      </span>
                    </li>
                    <li>
                      <span className="font-semibold">Language:</span>{" "}
                      <span className="text-muted-foreground">
                        {astro.languages.join(", ") || "—"}
                      </span>
                    </li>
                  </ul>
                </div>
                <button
                  type="button"
                  aria-label={isFavorite ? "Remove favorite" : "Save favorite"}
                  onClick={() => requireAuth() && toggleFavorite(astro.id)}
                  className={`shrink-0 inline-flex h-10 w-10 items-center justify-center rounded-full border transition-colors ${
                    isFavorite ? "text-rose-500 border-rose-200 bg-rose-50" : "text-muted-foreground hover:text-rose-500"
                  }`}
                >
                  <Heart className={`h-5 w-5 ${isFavorite ? "fill-rose-500" : ""}`} />
                </button>
              </div>

              <div className="grid gap-3 sm:grid-cols-3">
                <div className="rounded-md border bg-background p-3">
                  <p className="text-xs text-muted-foreground">Consultation Charges</p>
                  <p className="mt-1 text-lg font-bold">
                    ₹{rate}<span className="text-sm font-normal text-muted-foreground">/min</span>
                    {hasDiscount && (
                      <span className="ml-2 text-sm font-normal text-muted-foreground line-through">
                        ₹{astro.base_rate_per_min}
                      </span>
                    )}
                  </p>
                  {astro.first_chat_free && (
                    <span className="mt-1 inline-flex w-fit items-center rounded-full bg-orange-500/15 px-2 py-0.5 text-xs font-semibold text-orange-700">
                      First Chat FREE
                    </span>
                  )}
                </div>
                <div className="rounded-md border bg-background p-3">
                  <p className="text-xs text-muted-foreground">User Rating</p>
                  <div className="mt-1 flex items-center gap-1">
                    {Array.from({ length: 5 }).map((_, i) => (
                      <Star
                        key={i}
                        className={`h-4 w-4 ${
                          i < Math.round(astro.rating_avg) ? "fill-amber-400 text-amber-400" : "text-muted"
                        }`}
                      />
                    ))}
                    <span className="ml-1 text-sm font-semibold">({astro.rating_avg.toFixed(1)})</span>
                  </div>
                  <p className="text-xs text-muted-foreground mt-1">
                    {astro.rating_count.toLocaleString("en-IN")} reviews
                  </p>
                </div>
                <div className="rounded-md border bg-background p-3 flex flex-col">
                  <p className="text-xs text-muted-foreground inline-flex items-center gap-1">
                    <Users className="h-3 w-3" /> Followers
                  </p>
                  <p className="mt-1 text-lg font-bold">
                    {astro.follower_count.toLocaleString("en-IN")}
                  </p>
                  <Button size="sm" variant="secondary" className="mt-2 h-8">Follow</Button>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* ============ ABOUT ============ */}
        <section className="space-y-3">
          <h2 className="font-display text-2xl md:text-3xl font-bold">
            About {astro.display_name}
          </h2>
          {bio ? (
            <p className="text-sm md:text-base text-muted-foreground leading-relaxed">
              {visibleBio}
              {longBio && (
                <button
                  onClick={() => setShowFullBio((v) => !v)}
                  className="ml-2 font-semibold text-primary hover:underline"
                >
                  {showFullBio ? "Show less" : "Read More"}
                </button>
              )}
            </p>
          ) : (
            <p className="text-sm text-muted-foreground">No bio yet.</p>
          )}
        </section>

        {/* ============ EDUCATION & FOCUS AREA ============ */}
        <section className="grid gap-6 md:grid-cols-2">
          <InfoBlock icon={GraduationCap} title="Education">
            {astro.education?.trim() || "—"}
          </InfoBlock>
          <InfoBlock icon={Crosshair} title="Focus Area">
            {astro.focus_area?.trim() ||
              (astro.specializations[0]?.replace(/_/g, " ") ?? "—")}
          </InfoBlock>
        </section>

        {/* ============ SYSTEMS KNOWN ============ */}
        <section className="rounded-lg border bg-section p-4 md:p-5">
          <h3 className="font-semibold flex items-center gap-2 mb-3">
            <BookOpen className="h-4 w-4 text-primary" /> Systems Known:
          </h3>
          {(astro.systems_known?.length ?? 0) === 0 ? (
            <p className="text-sm text-muted-foreground">—</p>
          ) : (
            <div className="flex flex-wrap gap-2">
              {astro.systems_known!.map((s) => (
                <Badge key={s} className="bg-primary text-primary-foreground hover:bg-primary/90">
                  {s.toUpperCase()}
                </Badge>
              ))}
            </div>
          )}
        </section>

        {/* ============ LANGUAGES KNOWN ============ */}
        <section className="rounded-lg border bg-section p-4 md:p-5">
          <h3 className="font-semibold flex items-center gap-2 mb-3">
            <LanguagesIcon className="h-4 w-4 text-primary" /> Languages Known:
          </h3>
          <div className="flex flex-wrap gap-2">
            {astro.languages.length === 0 ? (
              <span className="text-sm text-muted-foreground">—</span>
            ) : (
              astro.languages.map((l) => (
                <span
                  key={l}
                  className="inline-flex items-center gap-1 rounded-md bg-primary px-3 py-1 text-xs font-bold uppercase tracking-wide text-primary-foreground"
                >
                  {l}
                  <span className="ml-1 inline-flex h-1.5 w-1.5 rounded-full bg-primary-foreground" />
                </span>
              ))
            )}
          </div>
        </section>

        {/* ============ RATINGS & REVIEWS ============ */}
        <section className="rounded-lg border bg-section p-4 md:p-5 space-y-4">
          <div className="flex items-center justify-between flex-wrap gap-2">
            <h3 className="font-semibold flex items-center gap-2">
              Ratings and Reviews
              <span className="text-sm text-muted-foreground inline-flex items-center gap-1">
                <Users className="h-3.5 w-3.5" />
                {astro.rating_count.toLocaleString("en-IN")}
              </span>
            </h3>
            <Select value={reviewSort} onValueChange={(v) => setReviewSort(v as ReviewSort)}>
              <SelectTrigger className="w-[160px] bg-background">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="recent">Most Recent</SelectItem>
                <SelectItem value="rating">Highest Rating</SelectItem>
                <SelectItem value="helpful">Most Helpful</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <p className="text-xs text-muted-foreground">
            (Only verified purchase ratings are used for final calculation)
          </p>

          {reviewsLoading ? (
            <div className="space-y-2">
              {Array.from({ length: 4 }).map((_, i) => (
                <Skeleton key={i} className="h-16 w-full" />
              ))}
            </div>
          ) : reviews.length === 0 ? (
            <div className="rounded-md bg-background p-6 text-center text-sm text-muted-foreground">
              No reviews yet. Be the first to share your experience.
            </div>
          ) : (
            <div className="grid gap-3 sm:grid-cols-2">
              {reviews.map((r) => (
                <div key={r.id} className="rounded-md border bg-background p-3">
                  <div className="flex items-start gap-3">
                    <Avatar className="h-9 w-9">
                      <AvatarFallback className="bg-muted text-xs">
                        {maskUserId(r.user_id).slice(0, 2)}
                      </AvatarFallback>
                    </Avatar>
                    <div className="min-w-0 flex-1">
                      <div className="flex flex-wrap items-baseline justify-between gap-2">
                        <p className="text-sm font-semibold tabular-nums">{maskUserId(r.user_id)}</p>
                        <div className="flex">
                          {Array.from({ length: 5 }).map((_, i) => (
                            <Star
                              key={i}
                              className={`h-3.5 w-3.5 ${
                                i < r.rating ? "fill-amber-400 text-amber-400" : "text-muted"
                              }`}
                            />
                          ))}
                        </div>
                      </div>
                      <p className="text-xs text-muted-foreground">
                        {format(new Date(r.created_at), "dd MMM yyyy")}
                      </p>
                      {r.comment && (
                        <p className="mt-1.5 text-sm leading-relaxed">{r.comment}</p>
                      )}
                      <p className="mt-1 text-xs font-semibold text-primary">Verified Purchase</p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}

          {reviewsHasMore && reviews.length > 0 && (
            <Button variant="outline" className="w-full" onClick={loadMoreReviews}>
              Load more reviews
            </Button>
          )}
        </section>
      </div>

      <ChatRequestModal
        open={chatOpen}
        onOpenChange={setChatOpen}
        astrologerId={astro.id}
        astrologerName={astro.display_name}
        astrologerAvatar={astro.avatar_url}
        astrologerSpecializations={astro.specializations ?? []}
        astrologerRating={Number(astro.rating_avg ?? 0)}
        ratePerMin={Number((astro as any).chat_rate_per_min ?? rate)}
      />
      <GiftModal
        open={giftOpen}
        onOpenChange={setGiftOpen}
        astrologerId={astro.id}
        astrologerName={astro.display_name}
      />
      <CallConfirmationModal
        open={callConfirmOpen}
        onClose={() => setCallConfirmOpen(false)}
        astrologer={astro as unknown as Astrologer}
        walletBalance={walletBalance}
        userPhone={userPhone}
        isStarting={isStartingCall}
        onConfirm={handleConfirmCall}
      />
      <PreCallBlockerModal
        open={callBlocker.reason !== null}
        reason={callBlocker.reason}
        required={callBlocker.required}
        currentBalance={callBlocker.current}
        onClose={() => setCallBlocker({ reason: null })}
      />
    </AppShell>
  );
}

function InfoBlock({
  icon: Icon,
  title,
  children,
}: {
  icon: React.ElementType;
  title: string;
  children: React.ReactNode;
}) {
  return (
    <div className="flex items-start gap-3">
      <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-full bg-accent ring-1 ring-secondary/40">
        <Icon className="h-5 w-5 text-primary" />
      </div>
      <div className="flex-1 min-w-0 pt-1">
        <h4 className="font-semibold border-b-2 border-secondary pb-1 inline-block">{title}</h4>
        <p className="mt-2 text-sm text-muted-foreground">{children}</p>
      </div>
    </div>
  );
}
