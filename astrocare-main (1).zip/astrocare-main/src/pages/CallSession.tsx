/**
 * Active call screen — handles both customer and astrologer sides.
 * Routes:
 *   /call/:id            (customer)
 *   /astrologer/call/:id (astrologer)
 *
 * Phases (driven by call_sessions.status):
 *   pending / ringing_astrologer  → "Connecting your call…" (customer side only)
 *   connected                     → live call UI with timer + cost counter
 *   completed/cancelled/declined  → redirect to endsession route
 *
 * SIMULATION MODE: When SIMULATION_MODE is true (Twilio not configured), the
 * call auto-transitions from "connecting" to "connected" after 3 seconds on
 * the customer's screen so QA can see the full lifecycle. When real Twilio
 * is wired up later, flip SIMULATION_MODE to false.
 */
import { useEffect, useMemo, useRef, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { useCallSession } from "@/hooks/useCallSession";
import { useWallet } from "@/hooks/useWallet";
import { useWaitingTone } from "@/hooks/useWaitingTone";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { Loader2, Phone, PhoneOff, AlertCircle } from "lucide-react";
import { EndSessionDialog } from "@/components/chat/EndSessionDialog";
import { toast } from "sonner";
import { fetchAgoraToken, loadAgoraSDK, uidFromUserId } from "@/lib/agora";

// Simulation auto-disables when the initiate-call function reports Twilio is wired.
// We detect by checking the session's twilio sid presence; otherwise fall back to mock.
const SIMULATION_DEFAULT = true;

function initials(name: string) {
  return name.split(" ").map((p) => p[0]).filter(Boolean).slice(0, 2).join("").toUpperCase();
}
function fmtClock(sec: number) {
  const h = Math.floor(sec / 3600);
  const m = Math.floor((sec % 3600) / 60).toString().padStart(2, "0");
  const s = (sec % 60).toString().padStart(2, "0");
  return h > 0 ? `${h}:${m}:${s}` : `${m}:${s}`;
}

interface OtherUser {
  name: string;
  avatar_url: string | null;
  specializations?: string[];
}

export default function CallSession() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { user } = useAuth();
  const { session, loading } = useCallSession(id ?? null);
  const { wallet } = useWallet();
  const balance = Number(wallet?.balance ?? 0);

  const [other, setOther] = useState<OtherUser | null>(null);
  const [now, setNow] = useState(Date.now());
  const [endOpen, setEndOpen] = useState(false);
  const [ending, setEnding] = useState(false);
  const agoraCleanupRef = useRef<(() => Promise<void>) | null>(null);

  const isAstrologerSide = window.location.pathname.startsWith("/astrologer/");
  const isCustomerSide = !isAstrologerSide;

  // Determine remote party
  useEffect(() => {
    if (!session) return;
    let cancelled = false;
    (async () => {
      if (isCustomerSide) {
        const { data } = await supabase
          .from("astrologers")
          .select("display_name, avatar_url, specializations")
          .eq("id", session.astrologer_id)
          .maybeSingle();
        if (!cancelled && data) setOther({ name: data.display_name, avatar_url: data.avatar_url, specializations: data.specializations ?? [] });
      } else {
        const { data: full } = await supabase
          .from("call_sessions")
          .select("user_id, astrologer_id")
          .eq("id", id ?? "")
          .maybeSingle();
        if (!full) return;
        const { data: p } = await supabase
          .from("profiles")
          .select("name, avatar_url")
          .eq("id", full.user_id)
          .maybeSingle();
        if (!cancelled && p) setOther({ name: p.name || "Customer", avatar_url: p.avatar_url });
      }
    })();
    return () => { cancelled = true; };
  }, [session, id, isCustomerSide]);

  const status = session?.status ?? "pending";
  const isConnecting = ["pending", "ringing_astrologer", "ringing_user"].includes(status);
  const isConnected = status === "connected";
  const isOver = ["completed", "ended", "failed", "declined", "no_answer", "cancelled"].includes(status);

  // In-app Agora audio for both customer and astrologer sides. Twilio remains
  // the phone bridge when available; Agora gives real browser-to-browser audio
  // for simulation and portal calls.
  useEffect(() => {
    if (!isConnected || !session || !id || !user) return;
    if (agoraCleanupRef.current) return;

    let cancelled = false;
    (async () => {
      try {
        const AgoraRTC = await loadAgoraSDK();
        if (cancelled) return;
        const uid = uidFromUserId(user.id);
        const channelName = `call-${id}`;
        const { token, appId } = await fetchAgoraToken({ channelName, uid, role: "host" });
        const client = AgoraRTC.createClient({ mode: "rtc", codec: "vp8" });
        client.on("user-published", async (remoteUser: any, mediaType: "audio" | "video") => {
          await client.subscribe(remoteUser, mediaType);
          if (mediaType === "audio") remoteUser.audioTrack?.play();
        });
        await client.join(appId, channelName, token, uid);
        const mic = await AgoraRTC.createMicrophoneAudioTrack();
        await client.publish([mic]);
        agoraCleanupRef.current = async () => {
          try { mic.stop(); mic.close(); } catch {}
          try { await client.leave(); } catch {}
        };
      } catch (err) {
        console.error("Agora call audio failed", err);
        toast.error("Microphone connection failed", { description: "Allow microphone access and rejoin the call." });
      }
    })();

    return () => {
      cancelled = true;
      const cleanup = agoraCleanupRef.current;
      agoraCleanupRef.current = null;
      cleanup?.();
    };
  }, [isConnected, session, id, user]);

  // Tick clock
  useEffect(() => {
    const t = setInterval(() => setNow(Date.now()), 1000);
    return () => clearInterval(t);
  }, []);

  // Waiting tone while connecting
  useWaitingTone(isConnecting && !isOver);

  // Customer-side simulation: after 3s on connecting, auto-connect.
  // Skipped automatically when a Twilio SID is present on the session
  // (meaning real PSTN call is in flight).
  const simRef = useRef(false);
  useEffect(() => {
    if (!SIMULATION_DEFAULT) return;
    if (!isCustomerSide) return;
    if (!session || !id) return;
    // If Twilio is wired the status will move to ringing_user/connected via webhook.
    if ((session as any).twilio_astrologer_call_sid) return;
    if (status !== "pending" && status !== "ringing_astrologer") return;
    if (simRef.current) return;

    simRef.current = true;
    const t = setTimeout(async () => {
      console.log("[SIMULATION] Call would start via Twilio here");
      await supabase
        .from("call_sessions")
        .update({ status: "connected", connected_at: new Date().toISOString() })
        .eq("id", id);
    }, 3000);
    return () => clearTimeout(t);
  }, [session, status, id, isCustomerSide]);

  // Redirect once finished
  useEffect(() => {
    if (!session || !isOver || !id) return;
    const route = isAstrologerSide ? "/astrologer/call/endsession" : "/call/endsession";
    navigate(`${route}?sessionId=${id}`, { replace: true });
  }, [isOver, id, isAstrologerSide, navigate, session]);

  // Live elapsed (since connected_at)
  const elapsedSec = useMemo(() => {
    if (!session?.connected_at) return 0;
    return Math.max(0, Math.floor((now - new Date(session.connected_at).getTime()) / 1000));
  }, [session?.connected_at, now]);

  const liveMinutes = Math.max(1, Math.ceil(elapsedSec / 60));
  const liveCost = isConnected ? liveMinutes * (session?.per_minute_rate ?? 0) : 0;

  // Customer-side balance guard
  const lowBalance = isCustomerSide && isConnected && balance < (session?.per_minute_rate ?? 0);
  const exhausted = isCustomerSide && isConnected && balance <= 0;

  const exhaustedRef = useRef(false);
  useEffect(() => {
    if (exhausted && !exhaustedRef.current && id) {
      exhaustedRef.current = true;
      (async () => {
        await supabase.rpc("end_call_session", {
          _session_id: id,
          _ended_by: "system",
          _end_reason: "low_balance",
        });
        toast.error("Call ended — balance exhausted");
      })();
    }
  }, [exhausted, id]);

  const confirmEnd = async () => {
    if (!id) return;
    setEnding(true);
    const endedBy = isAstrologerSide ? "astrologer" : "customer";
    const { error } = await supabase.rpc("end_call_session", {
      _session_id: id,
      _ended_by: endedBy,
      _end_reason: "user_ended",
    });
    setEnding(false);
    if (error) {
      toast.error(error.message ?? "Could not end call");
      return;
    }
    setEndOpen(false);
    // Redirect handled by realtime status change effect
  };

  if (loading || !session) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-[#0F0A1E] text-white">
        <Loader2 className="h-8 w-8 animate-spin text-amber-400" />
      </div>
    );
  }

  // Verify access
  const isParticipant =
    user && (user.id === (session as any).user_id || isAstrologerSide);
  if (!user) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-[#0F0A1E] text-white">
        <p>Please sign in to view this call.</p>
      </div>
    );
  }

  return (
    <div className="relative min-h-screen overflow-hidden bg-gradient-to-br from-[#1a1233] via-[#0f0a1e] to-[#1a1233] text-white">
      {/* Decorative starfield */}
      <div className="pointer-events-none absolute inset-0 opacity-20 [background-image:radial-gradient(white_1px,transparent_1px)] [background-size:24px_24px]" />

      <div className="relative flex min-h-screen flex-col items-center justify-center p-6">
        {/* Avatar with pulsing ring */}
        <div className="relative mb-6">
          {isConnecting && (
            <span className="absolute inset-0 -m-4 animate-ping rounded-full bg-amber-400/30" />
          )}
          <span className={`absolute inset-0 -m-2 rounded-full bg-gradient-to-br from-amber-300 to-amber-600 ${isConnecting ? "animate-pulse" : "opacity-70"}`} />
          <Avatar className="relative h-40 w-40 ring-4 ring-amber-300/80">
            <AvatarImage src={other?.avatar_url ?? undefined} alt={other?.name ?? ""} className="object-cover" />
            <AvatarFallback className="bg-purple-700 text-4xl font-semibold">
              {initials(other?.name ?? "?")}
            </AvatarFallback>
          </Avatar>
        </div>

        <h1 className="font-serif text-3xl font-bold">{other?.name ?? (isCustomerSide ? "Astrologer" : "Customer")}</h1>
        {other?.specializations && other.specializations.length > 0 && (
          <p className="mt-1 text-sm text-white/60">
            {other.specializations.slice(0, 3).join(" · ")}
          </p>
        )}

        {isConnecting && (
          <div className="mt-6 flex flex-col items-center gap-2">
            <p className="font-medium text-amber-200">Connecting your call…</p>
            <p className="text-xs text-white/60">Please answer your phone when it rings</p>
          </div>
        )}

        {isConnected && (
          <>
            <div className="mt-8 font-serif text-5xl font-bold tracking-wider text-amber-300">
              {fmtClock(elapsedSec)}
            </div>
            <p className="mt-2 text-sm text-white/70">
              <span className="text-amber-200 font-semibold">₹{liveCost}</span>
              {isCustomerSide && (
                <> · Balance: <span className="font-semibold text-white">₹{balance.toFixed(0)}</span></>
              )}
            </p>
            <p className="mt-1 text-xs text-white/50">Your phones are connected</p>

            {lowBalance && (
              <div className="mt-4 flex items-center gap-2 rounded-full bg-red-500/20 px-4 py-2 text-xs text-red-200 ring-1 ring-red-400/40">
                <AlertCircle className="h-4 w-4" />
                Low balance — add credits to continue
                <Button size="sm" variant="ghost" className="h-7 text-amber-300 hover:bg-amber-500/20" onClick={() => navigate("/wallet")}>
                  Add
                </Button>
              </div>
            )}
          </>
        )}

        {/* Bottom actions */}
        <div className="mt-12 flex items-center gap-4">
          {isConnecting && isCustomerSide && (
            <button
              onClick={() => setEndOpen(true)}
              className="text-sm text-white/60 underline-offset-2 hover:text-white hover:underline"
            >
              Cancel
            </button>
          )}
          {(isConnected || (!isCustomerSide && isConnecting)) && (
            <Button
              onClick={() => setEndOpen(true)}
              className="h-16 w-16 rounded-full bg-gradient-to-br from-red-500 to-red-700 text-white shadow-[0_0_30px_rgba(239,68,68,0.6)] hover:from-red-400 hover:to-red-600"
            >
              <PhoneOff className="h-7 w-7" />
            </Button>
          )}
        </div>
      </div>

      <EndSessionDialog
        open={endOpen}
        onOpenChange={(o) => !ending && setEndOpen(o)}
        onConfirm={confirmEnd}
        durationLabel={fmtClock(elapsedSec)}
        estimatedCost={liveCost}
        loading={ending}
      />
    </div>
  );
}
