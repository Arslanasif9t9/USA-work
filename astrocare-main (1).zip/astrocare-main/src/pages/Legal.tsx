/**
 * Single-page legal/info pages: /terms, /privacy, /refund, /about, /contact, /faq.
 * Uses route param to render the right content with consistent layout.
 */
import { useLocation, Link } from "react-router-dom";
import { AppShell } from "@/components/layout/AppShell";
import { Card } from "@/components/ui/card";
import { BackButton } from "@/components/layout/BackButton";

type Doc = { title: string; intro?: string; sections: { h: string; b: string | string[] }[] };

const docs: Record<string, Doc> = {
  terms: {
    title: "Terms of Service",
    intro: "By using AstroGuide you agree to these terms. Please read them carefully.",
    sections: [
      { h: "1. Service", b: "AstroGuide connects users with independent astrologers for guidance and entertainment. Predictions are not guaranteed." },
      { h: "2. Eligibility", b: "You must be 18+ to use the platform and provide accurate information when creating an account." },
      { h: "3. Payments & wallet", b: "All payments are processed via Stripe. Wallet balances are non-transferable. Calls/chats are billed per-minute at the rate displayed." },
      { h: "4. Conduct", b: "Abusive, illegal or harassing behaviour will result in account suspension. Recordings of calls may be retained for safety and dispute resolution." },
      { h: "5. Liability", b: "AstroGuide is not liable for decisions taken based on consultations. Use information for guidance only." },
      { h: "6. Changes", b: "We may update these terms at any time. Continued use of the service indicates acceptance." },
    ],
  },
  privacy: {
    title: "Privacy Policy",
    intro: "Your privacy matters. This page explains what we collect and why.",
    sections: [
      { h: "Data we collect", b: ["Account info (name, email, phone)", "Birth details for chart generation", "Session metadata (duration, rate, recordings)", "Payment metadata via Stripe (we never store card details)"] },
      { h: "How we use it", b: "To deliver consultations, process payments, prevent fraud and improve the platform." },
      { h: "Sharing", b: "We never sell your data. We share only with payment processors (Stripe), telephony provider (Twilio) and law enforcement when legally required." },
      { h: "Your rights", b: "You can request deletion or export of your data at any time by writing to support@astroguide.com." },
    ],
  },
  refund: {
    title: "Refund Policy",
    sections: [
      { h: "Wallet recharges", b: "Wallet credits are non-refundable once added, except in case of duplicate or failed transactions, which are auto-reconciled within 7 days." },
      { h: "Failed sessions", b: "If a session fails to connect or ends due to a technical issue on our side, the held amount is automatically released." },
      { h: "Disputes", b: "Raise a support ticket within 48 hours of the session for a manual review. Refunds (if approved) are credited back to wallet within 3 business days." },
    ],
  },
  about: {
    title: "About AstroGuide",
    intro: "India's trusted platform to talk to verified astrologers — Vedic, KP, Tarot, Numerology and more.",
    sections: [
      { h: "Our mission", b: "To make authentic astrological guidance accessible, transparent and affordable for every seeker." },
      { h: "Our astrologers", b: "Every astrologer is verified, rated and held to high quality standards. Sessions are recorded for your safety." },
      { h: "Why us", b: ["Pay-per-minute, no hidden fees", "Phone-verified astrologers", "Transparent ratings & reviews", "Secure payments via Stripe"] },
    ],
  },
  contact: {
    title: "Contact Us",
    intro: "We're here to help. Reach us via any of the channels below.",
    sections: [
      { h: "Email", b: "support@astroguide.com" },
      { h: "Phone", b: "+91 99999 99999 (10am – 8pm IST)" },
      { h: "Office", b: "Bengaluru, Karnataka, India" },
      { h: "Need help with a session?", b: "Sign in and visit the Support page to open a ticket — our team replies within a few hours." },
    ],
  },
  faq: {
    title: "Frequently Asked Questions",
    sections: [
      { h: "How does pay-per-minute work?", b: "Each astrologer sets their per-minute rate. We hold a small minimum balance from your wallet at the start; you're charged only for the actual time on the call/chat." },
      { h: "Can I get a recording of my call?", b: "Recordings are kept for safety and dispute resolution but aren't shared by default. Contact support if you need one." },
      { h: "How do I become an astrologer?", b: "Sign up as an astrologer from the home page. Our team reviews each application within 2-3 business days." },
      { h: "Is my data safe?", b: "Yes — payments go through Stripe, telephony through Twilio, and we never store card details." },
      { h: "How quickly are withdrawals processed?", b: "Astrologer withdrawals are processed within 2-3 business days." },
    ],
  },
};

export default function Legal() {
  const { pathname } = useLocation();
  const slug = pathname.replace("/", "") || "terms";
  const doc = docs[slug] ?? docs.terms;

  return (
    <AppShell>
      <main className="container max-w-3xl py-10 space-y-6">
        <BackButton />
        <header className="space-y-2">
          <h1 className="text-3xl md:text-4xl font-bold">{doc.title}</h1>
          {doc.intro && <p className="text-muted-foreground">{doc.intro}</p>}
          <p className="text-xs text-muted-foreground">Last updated: {new Date().toLocaleDateString("en-IN", { month: "long", year: "numeric" })}</p>
        </header>

        <Card className="p-6 md:p-8 space-y-6">
          {doc.sections.map((s) => (
            <section key={s.h} className="space-y-2">
              <h2 className="text-lg font-semibold">{s.h}</h2>
              {Array.isArray(s.b) ? (
                <ul className="list-disc pl-5 text-sm text-muted-foreground space-y-1">
                  {s.b.map((line) => <li key={line}>{line}</li>)}
                </ul>
              ) : (
                <p className="text-sm text-muted-foreground leading-relaxed">{s.b}</p>
              )}
            </section>
          ))}
        </Card>

        <nav className="flex flex-wrap gap-3 text-sm text-muted-foreground pt-4">
          {Object.entries(docs).filter(([k]) => k !== slug).map(([k, d]) => (
            <Link key={k} to={`/${k}`} className="hover:text-primary underline-offset-2 hover:underline">
              {d.title}
            </Link>
          ))}
        </nav>
      </main>
    </AppShell>
  );
}
