import { useNavigate } from "react-router-dom";
import { useCallback, useEffect, useState } from "react";
import { useTranslation } from "react-i18next";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";
import {
  Accordion, AccordionContent, AccordionItem, AccordionTrigger,
} from "@/components/ui/accordion";
import {
  Headphones, BadgeCheck, Star as StarIcon, MessageSquare,
  Settings2, ListOrdered, Search, Phone, Heart,
  Coins, Sparkles as SparklesIcon, BookOpen, Mail,
  Facebook, Twitter, Instagram, Youtube, ArrowRight,
} from "lucide-react";
import { AppShell } from "@/components/layout/AppShell";
import { useAuth } from "@/contexts/AuthContext";
import { supabase } from "@/integrations/supabase/client";
import { useWallet } from "@/hooks/useWallet";
import { useFavorites } from "@/hooks/useFavorites";
import { useAstrologerStatus } from "@/hooks/useAstrologerStatus";
import { AstrologerGrid } from "@/components/astrologers/AstrologerGrid";
import type { Astrologer } from "@/components/astrologers/AstrologerCard";
import { CallConfirmationModal } from "@/components/calls/CallConfirmationModal";
import { PreCallBlockerModal, type BlockerReason } from "@/components/calls/PreCallBlockerModal";
import { CallInProgressScreen } from "@/components/calls/CallInProgressScreen";
import { toast } from "@/hooks/use-toast";
import { IndiaFlag } from "@/components/icons/IndiaFlag";
// HERO IMAGE STRATEGY
// Currently using AI illustration until astrologer photos are upgraded to high-quality
// (1024x1024 minimum, professional headshots).
// Once photos are upgraded, swap back to: <HeroAstrologerCarousel />
// HeroAstrologerCarousel component is kept intact in src/components/home/HeroAstrologerCarousel.tsx
import heroAstrologer from "@/assets/hero-astrologer.png";
import { TestimonialsSection } from "@/components/home/TestimonialsSection";
import { LiveActivityTicker } from "@/components/home/LiveActivityTicker";

const PREVIEW_COUNT = 9;

export default function Index() {
  const navigate = useNavigate();
  const { t } = useTranslation("common");
  const { user } = useAuth();
  const { wallet } = useWallet();
  const walletBalance = Number(wallet?.balance ?? 0);
  const { favoriteIds, toggleFavorite } = useFavorites();
  const [searchQuery, setSearchQuery] = useState("");

  const [astrologers, setAstrologers] = useState<Astrologer[]>([]);
  const [loadingAstro, setLoadingAstro] = useState(true);
  const [trustStats, setTrustStats] = useState<{ readings: number; astrologers: number; rating: number; experience: number } | null>(null);

  // Call flow
  const [pendingAstrologer, setPendingAstrologer] = useState<Astrologer | null>(null);
  const [confirmOpen, setConfirmOpen] = useState(false);
  const [blocker, setBlocker] = useState<{ reason: BlockerReason; required?: number; current?: number }>({ reason: null });
  const [activeCallId, setActiveCallId] = useState<string | null>(null);
  const [activeCallAstrologer, setActiveCallAstrologer] = useState<Astrologer | null>(null);
  const [isStartingCall, setIsStartingCall] = useState(false);
  const [userPhone, setUserPhone] = useState<string | null>(null);
  const [hasBirthChart, setHasBirthChart] = useState<boolean | null>(null);

  useEffect(() => {
    if (!user) return;
    let cancelled = false;
    (async () => {
      const [{ data: profile }, { count }] = await Promise.all([
        supabase.from("profiles").select("phone_e164").eq("id", user.id).maybeSingle(),
        supabase.from("birth_charts").select("id", { count: "exact", head: true }).eq("user_id", user.id),
      ]);
      if (cancelled) return;
      setUserPhone(profile?.phone_e164 ?? null);
      setHasBirthChart((count ?? 0) > 0);
    })();
    return () => { cancelled = true; };
  }, [user]);

  // Load preview astrologers (top featured/highest rated)
  useEffect(() => {
    let cancelled = false;
    setLoadingAstro(true);
    supabase.functions.invoke("get-astrologers", {
      body: { is_ai: false, sort: "rating_desc", limit: PREVIEW_COUNT, offset: 0 },
    }).then(({ data, error }) => {
      if (cancelled) return;
      if (error) setAstrologers([]);
      else setAstrologers((data?.data ?? []) as Astrologer[]);
    }).finally(() => !cancelled && setLoadingAstro(false));
    return () => { cancelled = true; };
  }, []);

  // Trust strip — sum of approved astrologer review counts. Cached 5 min in sessionStorage.
  useEffect(() => {
    const CACHE_KEY = "trust_stats_v1";
    const TTL = 5 * 60 * 1000;
    try {
      const cached = sessionStorage.getItem(CACHE_KEY);
      if (cached) {
        const parsed = JSON.parse(cached);
        if (parsed?.ts && Date.now() - parsed.ts < TTL && parsed.value) {
          setTrustStats(parsed.value);
          return;
        }
      }
    } catch { /* ignore */ }

    let cancelled = false;
    (async () => {
      const { data, error, count } = await supabase
        .from("astrologers")
        .select("rating_count, experience_years", { count: "exact" })
        .eq("approval_status", "approved");
      if (cancelled || error || !data) return;
      const readings = data.reduce((sum, r: { rating_count: number | null }) => sum + (r.rating_count ?? 0), 0);
      const totalYears = data.reduce((sum, r: { experience_years: number | null }) => sum + (r.experience_years ?? 0), 0);
      // Round DOWN to nearest 50 for "X+" display
      const experience = Math.floor(totalYears / 50) * 50;
      const value = { readings, astrologers: count ?? data.length, rating: 4.9, experience };
      setTrustStats(value);
      try { sessionStorage.setItem(CACHE_KEY, JSON.stringify({ ts: Date.now(), value })); } catch { /* ignore */ }
    })();
    return () => { cancelled = true; };
  }, []);

  // Format like "12,000+" — round down to nearest thousand.
  const formatReadings = (n: number): string => {
    if (n < 1000) return `${n}+`;
    const thousands = Math.floor(n / 1000);
    return `${thousands.toLocaleString("en-IN")},000+`;
  };

  const handleStatusChange = useCallback((id: string, status: Astrologer["status"]) => {
    setAstrologers((prev) => prev.map((a) => (a.id === id ? { ...a, status } : a)));
  }, []);
  useAstrologerStatus(handleStatusChange);

  const goToAstrologers = () => {
    if (searchQuery.trim()) navigate(`/astrologers?q=${encodeURIComponent(searchQuery.trim())}`);
    else navigate("/astrologers");
  };

  const handleCall = (a: Astrologer) => {
    if (!user) { navigate("/sign-in"); return; }
    const rate = a.discounted_rate_per_min ?? a.base_rate_per_min;
    const minHold = rate * 2;
    if (!userPhone) { setBlocker({ reason: "no_phone" }); return; }
    if (hasBirthChart === false) { setBlocker({ reason: "no_chart" }); return; }
    if (!a.first_chat_free && walletBalance < minHold) {
      setBlocker({ reason: "insufficient_balance", required: minHold, current: walletBalance });
      return;
    }
    setPendingAstrologer(a);
    setConfirmOpen(true);
  };

  const handleConfirmCall = async () => {
    if (!pendingAstrologer) return;
    setIsStartingCall(true);
    const { data, error } = await supabase.functions.invoke("initiate-call", {
      body: { astrologer_id: pendingAstrologer.id },
    });
    setIsStartingCall(false);
    if (error || !data?.call_session_id) {
      const parsed: any = (error as any)?.context?.body ? (() => { try { return JSON.parse((error as any).context.body); } catch { return {}; } })() : (data ?? {});
      toast({ title: "Could not start call", description: parsed?.error ?? "Please try again.", variant: "destructive" });
      setConfirmOpen(false);
      return;
    }
    setActiveCallAstrologer(pendingAstrologer);
    setActiveCallId(data.call_session_id as string);
    setConfirmOpen(false);
    setPendingAstrologer(null);
  };

  return (
    <AppShell hideFooter>
      {/* ============ HERO ============ */}
      <section className="bg-accent border-b border-border">
        <div className="container py-8 md:py-10">
          <div className="grid gap-6 md:grid-cols-[1fr_auto] items-center">
            <div className="text-center md:text-left">
              <h1 className="text-3xl md:text-5xl lg:text-6xl font-bold leading-tight text-foreground">
                {t("home.hero_title")}
              </h1>
              <p className="mt-3 text-base md:text-lg text-muted-foreground">
                {t("home.hero_subtitle")}
              </p>

              {/* Trust strip — real numbers, gold accents, single line that wraps cleanly on mobile. */}
              {trustStats && (
                <div className="mt-4 flex flex-wrap items-center justify-center md:justify-start gap-x-3 gap-y-1 text-xs sm:text-sm text-muted-foreground">
                  <span className="inline-flex items-center gap-1">
                    <span className="text-amber-500" aria-hidden>⭐</span>
                    <span className="font-semibold text-foreground">{trustStats.rating.toFixed(1)}</span>
                    <span>{t("home.trust_rating")}</span>
                  </span>
                  <span className="text-muted-foreground/40" aria-hidden>•</span>
                  <span className="inline-flex items-center gap-1">
                    <span className="text-amber-600" aria-hidden>📿</span>
                    <span className="font-semibold text-foreground">{formatReadings(trustStats.readings)}</span>
                    <span>{t("home.trust_readings")}</span>
                  </span>
                  <span className="text-muted-foreground/40" aria-hidden>•</span>
                  <span className="inline-flex items-center gap-1.5">
                    <IndiaFlag size={14} className="rounded-sm shadow-sm" />
                    <span className="font-semibold text-foreground">{trustStats.astrologers}</span>
                    <span>{t("home.trust_astrologers")}</span>
                  </span>
                  {trustStats.experience > 0 && (
                    <>
                      <span className="text-muted-foreground/40" aria-hidden>•</span>
                      <span className="inline-flex items-center gap-1">
                        <span aria-hidden>🎓</span>
                        <span className="font-semibold text-foreground">{trustStats.experience}+</span>
                        <span>{t("home.trust_experience")}</span>
                      </span>
                    </>
                  )}
                </div>
              )}

              <LiveActivityTicker />

              <div className="mt-6 inline-block">
                <button
                  onClick={() => navigate("/astrologers")}
                  className="rounded-full bg-foreground text-background px-8 py-4 text-xl md:text-2xl font-bold shadow-lg hover:opacity-90 transition-opacity"
                >
                  {t("home.first_chat_free_cta")} <span className="text-secondary">{t("home.free_label")}</span>
                </button>
              </div>
              <p className="mt-2 text-sm text-foreground/60">
                {t("home.cta_subtext")}
              </p>
            </div>
            <div className="flex justify-center md:justify-end">
              <img
                src={heroAstrologer}
                alt={t("home.hero_title")}
                width={400}
                height={400}
                className="h-[260px] w-[260px] sm:h-[300px] sm:w-[300px] lg:h-[400px] lg:w-[400px] rounded-2xl object-cover shadow-lg shadow-black/10"
                loading="eager"
              />
            </div>
          </div>
        </div>

        {/* Search bar → /astrologers */}
        <div className="container pb-8">
          <Card className="flex flex-col gap-3 p-4 md:flex-row md:items-center">
            <div className="flex flex-1 items-center gap-2 rounded-md border bg-background px-3">
              <Search className="h-4 w-4 text-muted-foreground" />
              <Input
                type="search"
                placeholder={t("home.search_placeholder")}
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                onKeyDown={(e) => e.key === "Enter" && goToAstrologers()}
                className="border-0 shadow-none focus-visible:ring-0 px-0"
              />
            </div>
            <Button size="lg" variant="default" className="md:w-auto" onClick={goToAstrologers}>
              <Search className="mr-2 h-4 w-4" /> {t("home.find_astrologer")}
            </Button>
          </Card>
        </div>
      </section>

      {/* ============ FREE SERVICES QUICK-ACCESS BAR ============ */}
      <section className="border-b border-border bg-[#FBF1E2]">
        <div className="container py-6 md:py-8">
          <div className="mb-4 text-center">
            <h2 className="text-base md:text-lg font-bold text-foreground">
              {t("home.free_bar_title", { defaultValue: "Try our free Vedic services" })}
            </h2>
            <p className="text-xs md:text-sm text-muted-foreground mt-1">
              {t("home.free_bar_subtitle", { defaultValue: "No sign-up required" })}
            </p>
          </div>
          <div className="grid grid-cols-2 gap-3 md:grid-cols-4 md:gap-4">
            {[
              {
                icon: BookOpen,
                title: t("home.free_kundli_title", { defaultValue: "Free Kundli" }),
                desc: t("home.free_kundli_desc", { defaultValue: "Get your detailed birth chart in 30 seconds" }),
                cta: t("home.free_kundli_cta", { defaultValue: "Generate Now" }),
                to: "/chart/new",
              },
              {
                icon: SparklesIcon,
                title: t("home.free_panchang_title", { defaultValue: "Daily Panchang" }),
                desc: t("home.free_panchang_desc", { defaultValue: "Today's tithi, nakshatra and muhurat" }),
                cta: t("home.free_panchang_cta", { defaultValue: "View Today" }),
                to: "/panchang",
              },
              {
                icon: BadgeCheck,
                title: t("home.free_hora_title", { defaultValue: "Hora Timing" }),
                desc: t("home.free_hora_desc", { defaultValue: "Find auspicious hours for any activity" }),
                cta: t("home.free_hora_cta", { defaultValue: "Check Hora" }),
                to: "/panchang/hora",
              },
              {
                icon: StarIcon,
                title: t("home.free_horoscope_title", { defaultValue: "Daily Horoscope" }),
                desc: t("home.free_horoscope_desc", { defaultValue: "Today's prediction for your zodiac" }),
                cta: t("home.free_horoscope_cta", { defaultValue: "Read Yours" }),
                to: "/horoscope",
              },
            ].map(({ icon: Icon, title, desc, cta, to }) => (
              <button
                key={title}
                onClick={() => navigate(to)}
                className="group flex flex-col items-start gap-2 rounded-xl border border-border bg-card p-4 text-left transition-all hover:-translate-y-0.5 hover:border-[#ED7B2A] hover:shadow-md"
              >
                <Icon className="h-8 w-8 text-[#ED7B2A]" />
                <div className="text-base font-semibold text-foreground leading-tight">{title}</div>
                <div className="text-xs text-muted-foreground leading-snug line-clamp-2">{desc}</div>
                <div className="mt-1 inline-flex items-center gap-1 text-xs font-semibold text-[#ED7B2A]">
                  {cta} <ArrowRight className="h-3.5 w-3.5" />
                </div>
              </button>
            ))}
          </div>
        </div>
      </section>

      <section className="container py-8 md:py-10" id="all-astrologers">
        <div className="mb-6 flex flex-col items-center gap-2 text-center">
          <h2 className="text-xl md:text-2xl font-bold uppercase tracking-wide">
            {t("home.section_certified_title")}
          </h2>
          <p className="text-sm text-muted-foreground">
            {t("home.section_favorites_hint")}
          </p>
        </div>

        <AstrologerGrid
          astrologers={astrologers}
          walletBalance={walletBalance}
          isLoading={loadingAstro}
          onCall={handleCall}
          onReset={() => navigate("/astrologers")}
          favoriteIds={favoriteIds}
          onToggleFavorite={toggleFavorite}
        />

        <div className="mt-6 flex justify-center">
          <Button
            size="lg"
            variant="outline"
            className="rounded-full px-8"
            onClick={() => navigate("/astrologers")}
          >
            {t("home.view_all_astrologers")} <ArrowRight className="ml-2 h-4 w-4" />
          </Button>
        </div>
      </section>

      {/* ============ SERVICES ============ */}
      <section className="container py-6 md:py-8">
        <h3 className="mb-5 text-center text-lg md:text-xl font-bold uppercase tracking-wide text-muted-foreground">
          {t("home.services_heading")}
        </h3>
        <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 md:grid-cols-6">
          {[
            { label: t("home.service_talk"), icon: Phone, to: "/astrologers" },
            { label: t("home.service_chat"), icon: MessageSquare, to: "/astrologers" },
            { label: t("home.service_kundli"), icon: BookOpen, to: "/chart/new" },
            { label: t("home.service_panchang"), icon: SparklesIcon, to: "/panchang" },
            { label: t("home.service_match"), icon: Heart, to: "/astrologers?expertise=marriage_matching" },
            { label: t("home.service_store"), icon: Coins, to: "/astrologers" },
          ].map(({ label, icon: Icon, to }) => (
            <button
              key={label}
              onClick={() => navigate(to)}
              className="group flex flex-col items-center gap-2 rounded-xl border bg-card p-4 text-center transition-all hover:-translate-y-0.5 hover:border-primary hover:shadow-md"
            >
              <div className="flex h-12 w-12 items-center justify-center rounded-full bg-accent text-primary group-hover:bg-primary group-hover:text-primary-foreground transition-colors">
                <Icon className="h-5 w-5" />
              </div>
              <span className="text-xs md:text-sm font-medium text-foreground">{label}</span>
            </button>
          ))}
        </div>
      </section>

      {/* ============ Testimonials ============ */}
      <TestimonialsSection />

      {/* ============ SEO Sections ============ */}
      <section className="border-t border-border bg-card">
        <div className="container max-w-5xl py-10 space-y-10">
          <article>
            <div className="flex items-center gap-4 mb-4">
              <div className="flex h-16 w-16 shrink-0 items-center justify-center rounded-full bg-accent ring-1 ring-secondary/40">
                <Headphones className="h-8 w-8 text-primary" />
              </div>
              <h2 className="text-xl md:text-2xl font-bold border-b-2 border-secondary pb-1">
                AstroGuide: Consult Astrologer Now
              </h2>
            </div>
            <div className="space-y-3 text-sm leading-relaxed text-muted-foreground">
              <p>
                Talk to Astrologers with AstroGuide — a service devoted to easing the lives of our users. Going through a rough
                patch or worried about your career? Astrology holds the answer to all your questions. Get in touch with live
                astrologers — the top experts in the country, and get instant solutions to your problems.
              </p>
              <p>
                AstroGuide lists the top astrologers in India with expertise across Vedic, KP system, Nadi Shastra, Numerology,
                Palmistry, Tarot Reading, Aura Reading, Vastu Shastra, Spiritual Healing, and more.
              </p>
            </div>
          </article>

          <article>
            <div className="flex items-center gap-4 mb-4 justify-end">
              <h2 className="text-xl md:text-2xl font-bold border-b-2 border-secondary pb-1">
                What Is "AstroGuide Verified"?
              </h2>
              <div className="flex h-16 w-16 shrink-0 items-center justify-center rounded-full bg-accent ring-1 ring-secondary/40">
                <BadgeCheck className="h-8 w-8 text-primary" />
              </div>
            </div>
            <p className="text-sm leading-relaxed text-muted-foreground">
              Every astrologer you see here undergoes AAAP (AstroGuide Astrologer Assessment Program), which strictly ensures
              excellent astrology knowledge, specialization of particular astrological systems, and predictive accuracy.
            </p>
          </article>

          <article>
            <div className="flex items-center gap-4 mb-4">
              <div className="flex h-16 w-16 shrink-0 items-center justify-center rounded-full bg-accent ring-1 ring-secondary/40">
                <StarIcon className="h-8 w-8 text-primary fill-primary/30" />
              </div>
              <h2 className="text-xl md:text-2xl font-bold border-b-2 border-secondary pb-1">
                Authentic Reviews
              </h2>
            </div>
            <p className="text-sm leading-relaxed text-muted-foreground">
              Under the guidance of renowned astrologers, our experts provide high quality astrological services. We ensure that
              every review or rating here presents the true picture.
            </p>
          </article>

          <article>
            <div className="flex items-center gap-4 mb-4 justify-end">
              <h2 className="text-xl md:text-2xl font-bold border-b-2 border-secondary pb-1">
                {t("home.steps_title")}
              </h2>
              <div className="flex h-16 w-16 shrink-0 items-center justify-center rounded-full bg-accent ring-1 ring-secondary/40">
                <Settings2 className="h-8 w-8 text-primary" />
              </div>
            </div>
            <ol className="ml-5 list-decimal space-y-2 text-sm text-muted-foreground">
              <li>{t("home.step_1")}</li>
              <li>{t("home.step_2")}</li>
              <li>{t("home.step_3")}</li>
            </ol>
          </article>

          <article>
            <div className="flex items-center gap-4 mb-4">
              <div className="flex h-16 w-16 shrink-0 items-center justify-center rounded-full bg-accent ring-1 ring-secondary/40">
                <ListOrdered className="h-8 w-8 text-primary" />
              </div>
              <h2 className="text-xl md:text-2xl font-bold border-b-2 border-secondary pb-1">
                {t("home.faq_title")}
              </h2>
            </div>
            <Accordion type="single" collapsible className="w-full">
              {(t("home.faq", { returnObjects: true }) as Array<{ q: string; a: string }>).map((item, i) => (
                <AccordionItem value={`faq-${i}`} key={i}>
                  <AccordionTrigger className="text-left text-base font-bold">
                    {i + 1}. {item.q}
                  </AccordionTrigger>
                  <AccordionContent className="text-sm text-muted-foreground">{item.a}</AccordionContent>
                </AccordionItem>
              ))}
            </Accordion>
          </article>
        </div>
      </section>

      {/* ============ Rich Footer ============ */}
      <section className="bg-foreground text-background mt-4">
        <div className="container py-12 grid gap-10 md:grid-cols-4">
          <div className="space-y-3">
            <div className="flex items-center gap-2 text-xl font-bold">
              <SparklesIcon className="h-6 w-6 text-secondary" />
              <span>AstroGuide</span>
            </div>
            <p className="text-sm text-background/70 leading-relaxed">
              India's trusted platform to talk to verified astrologers — Vedic, KP, Tarot, Numerology and more.
            </p>
            <div className="flex gap-3 pt-2">
              {[Facebook, Twitter, Instagram, Youtube].map((Icon, i) => (
                <a key={i} href="#" aria-label="social" className="flex h-9 w-9 items-center justify-center rounded-full bg-background/10 hover:bg-secondary hover:text-foreground transition-colors">
                  <Icon className="h-4 w-4" />
                </a>
              ))}
            </div>
          </div>

          <div>
            <h3 className="text-sm font-bold uppercase tracking-wide mb-3 text-secondary">Services</h3>
            <ul className="space-y-2 text-sm text-background/80">
              <li><button onClick={() => navigate("/astrologers")} className="hover:text-secondary">Talk to Astrologer</button></li>
              <li><button onClick={() => navigate("/astrologers")} className="hover:text-secondary">Chat with Astrologer</button></li>
              <li><button onClick={() => navigate("/panchang")} className="hover:text-secondary">Today's Panchang</button></li>
              <li><button onClick={() => navigate("/chart/new")} className="hover:text-secondary">Free Kundli</button></li>
              <li><button onClick={() => navigate("/astrologers?expertise=marriage_matching")} className="hover:text-secondary">Marriage Matching</button></li>
            </ul>
          </div>

          <div>
            <h3 className="text-sm font-bold uppercase tracking-wide mb-3 text-secondary">Company</h3>
            <ul className="space-y-2 text-sm text-background/80">
              <li><button onClick={() => navigate("/about")} className="hover:text-secondary">About Us</button></li>
              <li><button onClick={() => navigate("/faq")} className="hover:text-secondary">FAQ</button></li>
              <li><button onClick={() => navigate("/sign-up")} className="hover:text-secondary">Become an Astrologer</button></li>
              <li><button onClick={() => navigate("/privacy")} className="hover:text-secondary">Privacy Policy</button></li>
              <li><button onClick={() => navigate("/terms")} className="hover:text-secondary">Terms & Conditions</button></li>
              <li><button onClick={() => navigate("/refund")} className="hover:text-secondary">Refund Policy</button></li>
              <li><button onClick={() => navigate("/contact")} className="hover:text-secondary">Contact</button></li>
            </ul>
          </div>

          <div>
            <h3 className="text-sm font-bold uppercase tracking-wide mb-3 text-secondary">Get In Touch</h3>
            <ul className="space-y-3 text-sm text-background/80">
              <li className="flex items-start gap-2">
                <Mail className="h-4 w-4 mt-0.5 shrink-0 text-secondary" />
                <span>support@astroguide.com</span>
              </li>
            </ul>
          </div>
        </div>

        <div className="border-t border-background/10">
          <div className="container py-6 flex flex-col gap-2 md:flex-row md:items-center md:justify-between text-xs text-background/60">
            <p>© {new Date().getFullYear()} AstroGuide. All rights reserved.</p>
            <p>Made with ✨ for seekers of clarity.</p>
          </div>
        </div>
      </section>

      <CallConfirmationModal
        open={confirmOpen}
        onClose={() => { setConfirmOpen(false); setPendingAstrologer(null); }}
        astrologer={pendingAstrologer}
        walletBalance={walletBalance}
        userPhone={userPhone}
        isStarting={isStartingCall}
        onConfirm={handleConfirmCall}
      />
      <PreCallBlockerModal
        open={blocker.reason !== null}
        reason={blocker.reason}
        required={blocker.required}
        currentBalance={blocker.current}
        onClose={() => setBlocker({ reason: null })}
      />
      {activeCallId && activeCallAstrologer && (
        <CallInProgressScreen
          callSessionId={activeCallId}
          astrologer={activeCallAstrologer}
          onClose={() => { setActiveCallId(null); setActiveCallAstrologer(null); }}
        />
      )}
    </AppShell>
  );
}
