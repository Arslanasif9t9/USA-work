import { useEffect, useMemo, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Download, IndianRupee, Wallet, Users, TrendingUp } from "lucide-react";
import {
  AdminCard, AdminPageHeader, AdminButton, AdminSelect, AdminInput,
  AdminTabs, EmptyState, fmtINR, fmtDate,
} from "@/admin/ui";

type Range = "today" | "week" | "month" | "last_month" | "custom";
type TxnType = "all" | "top_up" | "consultation_debit" | "refund" | "consultation_credit" | "consultation_minute_spend" | "call_hold" | "call_hold_release" | "call_charge";

function rangeBounds(r: Range, from?: string, to?: string): [Date, Date] {
  const now = new Date();
  if (r === "today") {
    const start = new Date(now); start.setHours(0, 0, 0, 0);
    return [start, now];
  }
  if (r === "week") {
    const start = new Date(now); start.setDate(start.getDate() - 7);
    return [start, now];
  }
  if (r === "month") {
    return [new Date(now.getFullYear(), now.getMonth(), 1), now];
  }
  if (r === "last_month") {
    return [new Date(now.getFullYear(), now.getMonth() - 1, 1), new Date(now.getFullYear(), now.getMonth(), 0, 23, 59, 59)];
  }
  return [from ? new Date(from) : new Date(now.getFullYear(), 0, 1), to ? new Date(to) : now];
}

function csvEscape(v: any) {
  const s = v == null ? "" : String(v);
  return /[",\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
}

export default function AdminFinance() {
  const [range, setRange] = useState<Range>("month");
  const [from, setFrom] = useState("");
  const [to, setTo] = useState("");
  const [summary, setSummary] = useState({ gross: 0, platform: 0, astro: 0, walletHeld: 0 });
  const [revenueByDay, setRevenueByDay] = useState<{ date: string; gross: number; platform: number; astro: number; sessions: number; avg: number }[]>([]);
  const [topAstro, setTopAstro] = useState<any[]>([]);
  const [topCust, setTopCust] = useState<any[]>([]);
  const [txnType, setTxnType] = useState<TxnType>("all");
  const [txns, setTxns] = useState<any[]>([]);

  const [start, end] = useMemo(() => rangeBounds(range, from, to), [range, from, to]);

  async function loadAll() {
    // All-time summary cards
    const [chatAll, callAll, walletAll] = await Promise.all([
      supabase.from("chat_sessions").select("total_cost, astrologer_earning, company_earning"),
      supabase.from("call_sessions").select("astrologer_earning, company_earning, per_minute_rate, duration_seconds"),
      supabase.from("wallets").select("balance"),
    ]);
    const gross = (chatAll.data || []).reduce((s, r: any) => s + Number(r.total_cost || 0), 0)
      + (callAll.data || []).reduce((s, r: any) => s + Number(r.astrologer_earning || 0) + Number(r.company_earning || 0), 0);
    const platform = (chatAll.data || []).reduce((s, r: any) => s + Number(r.company_earning || 0), 0)
      + (callAll.data || []).reduce((s, r: any) => s + Number(r.company_earning || 0), 0);
    const astro = (chatAll.data || []).reduce((s, r: any) => s + Number(r.astrologer_earning || 0), 0)
      + (callAll.data || []).reduce((s, r: any) => s + Number(r.astrologer_earning || 0), 0);
    const walletHeld = (walletAll.data || []).reduce((s, r: any) => s + Number(r.balance || 0), 0);
    setSummary({ gross, platform, astro, walletHeld });

    // Range-scoped session data
    const [chatRng, callRng] = await Promise.all([
      supabase.from("chat_sessions").select("created_at, total_cost, astrologer_earning, company_earning, astrologer_id, user_id")
        .gte("created_at", start.toISOString()).lte("created_at", end.toISOString()),
      supabase.from("call_sessions").select("created_at, astrologer_earning, company_earning, astrologer_id, user_id")
        .gte("created_at", start.toISOString()).lte("created_at", end.toISOString()),
    ]);

    // Per-day breakdown
    const byDay = new Map<string, { gross: number; platform: number; astro: number; sessions: number }>();
    const upd = (k: string, g: number, p: number, a: number) => {
      const cur = byDay.get(k) || { gross: 0, platform: 0, astro: 0, sessions: 0 };
      cur.gross += g; cur.platform += p; cur.astro += a; cur.sessions += 1;
      byDay.set(k, cur);
    };
    (chatRng.data || []).forEach((r: any) => upd(String(r.created_at).slice(0, 10),
      Number(r.total_cost || 0), Number(r.company_earning || 0), Number(r.astrologer_earning || 0)));
    (callRng.data || []).forEach((r: any) => {
      const g = Number(r.astrologer_earning || 0) + Number(r.company_earning || 0);
      upd(String(r.created_at).slice(0, 10), g, Number(r.company_earning || 0), Number(r.astrologer_earning || 0));
    });
    setRevenueByDay(
      Array.from(byDay.entries())
        .sort((a, b) => b[0].localeCompare(a[0]))
        .map(([date, v]) => ({ date, ...v, avg: v.sessions > 0 ? v.gross / v.sessions : 0 }))
    );

    // Top astrologers
    const aMap = new Map<string, { sessions: number; gross: number; earnings: number }>();
    [...(chatRng.data || []), ...(callRng.data || [])].forEach((r: any) => {
      const cur = aMap.get(r.astrologer_id) || { sessions: 0, gross: 0, earnings: 0 };
      cur.sessions += 1;
      cur.gross += Number(r.total_cost || 0) || (Number(r.astrologer_earning || 0) + Number(r.company_earning || 0));
      cur.earnings += Number(r.astrologer_earning || 0);
      aMap.set(r.astrologer_id, cur);
    });
    const topAIds = Array.from(aMap.entries()).sort((a, b) => b[1].earnings - a[1].earnings).slice(0, 10);
    const aProfiles = topAIds.length
      ? await supabase.from("astrologers").select("id, display_name").in("id", topAIds.map((x) => x[0]))
      : { data: [] as any[] };
    setTopAstro(topAIds.map(([id, v]) => ({
      id, name: aProfiles.data?.find((p: any) => p.id === id)?.display_name || "—", ...v,
    })));

    // Top customers
    const cMap = new Map<string, { sessions: number; spent: number }>();
    [...(chatRng.data || []), ...(callRng.data || [])].forEach((r: any) => {
      const cur = cMap.get(r.user_id) || { sessions: 0, spent: 0 };
      cur.sessions += 1;
      cur.spent += Number(r.total_cost || 0) || (Number(r.astrologer_earning || 0) + Number(r.company_earning || 0));
      cMap.set(r.user_id, cur);
    });
    const topCIds = Array.from(cMap.entries()).sort((a, b) => b[1].spent - a[1].spent).slice(0, 10);
    const cProfiles = topCIds.length
      ? await supabase.from("profiles").select("id, name, email").in("id", topCIds.map((x) => x[0]))
      : { data: [] as any[] };
    setTopCust(topCIds.map(([id, v]) => ({
      id, name: cProfiles.data?.find((p: any) => p.id === id)?.name || "—",
      email: cProfiles.data?.find((p: any) => p.id === id)?.email || "—",
      ...v, avg: v.sessions > 0 ? v.spent / v.sessions : 0,
    })));

    // Transactions
    let q = supabase.from("transactions").select("id, type, amount, description, balance_after, created_at, wallet_id")
      .gte("created_at", start.toISOString()).lte("created_at", end.toISOString())
      .order("created_at", { ascending: false }).limit(15);
    if (txnType !== "all") q = q.eq("type", txnType as any);
    const { data: txnData } = await q;
    setTxns(txnData || []);
  }

  useEffect(() => { loadAll(); /* eslint-disable-next-line */ }, [range, from, to, txnType]);

  function exportCsv() {
    const rows = [
      ["Date", "Type", "Amount", "Balance after", "Description"],
      ...txns.map((t) => [t.created_at, t.type, t.amount, t.balance_after, t.description]),
    ];
    const csv = rows.map((r) => r.map(csvEscape).join(",")).join("\n");
    const blob = new Blob([csv], { type: "text/csv" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url; a.download = `transactions_${start.toISOString().slice(0, 10)}_${end.toISOString().slice(0, 10)}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  }

  return (
    <div className="space-y-6">
      <AdminPageHeader
        title="Finance & reports"
        description="Platform revenue, astrologer payouts, top performers, and a full transaction log."
        actions={<AdminButton variant="secondary" onClick={exportCsv}><Download className="h-3.5 w-3.5" /> Export CSV</AdminButton>}
      />

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {[
          { label: "Gross volume (all time)", value: fmtINR(summary.gross), icon: TrendingUp, tone: "bg-indigo-600/20 text-indigo-300" },
          { label: "Platform revenue (all time)", value: fmtINR(summary.platform), icon: IndianRupee, tone: "bg-amber-600/20 text-amber-300" },
          { label: "Astrologer payout (all time)", value: fmtINR(summary.astro), icon: Wallet, tone: "bg-blue-600/20 text-blue-300" },
          { label: "Wallet balance held", value: fmtINR(summary.walletHeld), icon: Users, tone: "bg-emerald-600/20 text-emerald-300" },
        ].map((s) => (
          <div key={s.label} className="rounded-xl border border-slate-800 bg-slate-900/60 p-5">
            <div className="flex items-center justify-between">
              <div className="text-[11px] uppercase tracking-wider text-slate-400">{s.label}</div>
              <div className={`h-8 w-8 rounded-lg flex items-center justify-center ${s.tone}`}><s.icon className="h-4 w-4" /></div>
            </div>
            <div className="mt-3 text-2xl font-semibold tracking-tight">{s.value}</div>
          </div>
        ))}
      </div>

      <AdminCard className="p-4">
        <div className="flex flex-wrap items-center gap-3">
          <span className="text-xs text-slate-400 uppercase tracking-wider">Range</span>
          <AdminTabs
            tabs={[
              { value: "today", label: "Today" },
              { value: "week", label: "This week" },
              { value: "month", label: "This month" },
              { value: "last_month", label: "Last month" },
              { value: "custom", label: "Custom" },
            ]}
            value={range}
            onChange={(v) => setRange(v as Range)}
          />
          {range === "custom" && (
            <div className="flex items-center gap-2">
              <AdminInput type="date" value={from} onChange={(e) => setFrom(e.target.value)} className="w-40" />
              <span className="text-slate-500 text-xs">to</span>
              <AdminInput type="date" value={to} onChange={(e) => setTo(e.target.value)} className="w-40" />
            </div>
          )}
        </div>
      </AdminCard>

      <AdminCard className="p-5">
        <h3 className="font-semibold text-sm mb-3">Revenue breakdown</h3>
        {revenueByDay.length === 0 ? <EmptyState message="No sessions in this range." /> : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="text-[11px] uppercase text-slate-400 border-b border-slate-800">
                <tr><th className="text-left py-2">Date</th><th className="text-right">Gross</th><th className="text-right">Platform 70%</th><th className="text-right">Astrologer 30%</th><th className="text-right">Sessions</th><th className="text-right">Avg value</th></tr>
              </thead>
              <tbody className="divide-y divide-slate-800">
                {revenueByDay.map((r) => (
                  <tr key={r.date}>
                    <td className="py-2">{r.date}</td>
                    <td className="text-right">{fmtINR(r.gross)}</td>
                    <td className="text-right text-amber-300">{fmtINR(r.platform)}</td>
                    <td className="text-right text-blue-300">{fmtINR(r.astro)}</td>
                    <td className="text-right">{r.sessions}</td>
                    <td className="text-right">{fmtINR(r.avg)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </AdminCard>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <AdminCard className="p-5">
          <h3 className="font-semibold text-sm mb-3">Top earning astrologers</h3>
          {topAstro.length === 0 ? <EmptyState /> : (
            <table className="w-full text-sm">
              <thead className="text-[11px] uppercase text-slate-400 border-b border-slate-800">
                <tr><th className="text-left py-2">Name</th><th className="text-right">Sessions</th><th className="text-right">Gross</th><th className="text-right">Earnings</th></tr>
              </thead>
              <tbody className="divide-y divide-slate-800">
                {topAstro.map((a) => (
                  <tr key={a.id}>
                    <td className="py-2">{a.name}</td>
                    <td className="text-right">{a.sessions}</td>
                    <td className="text-right">{fmtINR(a.gross)}</td>
                    <td className="text-right text-blue-300">{fmtINR(a.earnings)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </AdminCard>

        <AdminCard className="p-5">
          <h3 className="font-semibold text-sm mb-3">Top spending customers</h3>
          {topCust.length === 0 ? <EmptyState /> : (
            <table className="w-full text-sm">
              <thead className="text-[11px] uppercase text-slate-400 border-b border-slate-800">
                <tr><th className="text-left py-2">Name</th><th className="text-right">Sessions</th><th className="text-right">Spent</th><th className="text-right">Avg</th></tr>
              </thead>
              <tbody className="divide-y divide-slate-800">
                {topCust.map((c) => (
                  <tr key={c.id}>
                    <td className="py-2">
                      <div>{c.name}</div>
                      <div className="text-[11px] text-slate-500">{c.email}</div>
                    </td>
                    <td className="text-right">{c.sessions}</td>
                    <td className="text-right">{fmtINR(c.spent)}</td>
                    <td className="text-right">{fmtINR(c.avg)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </AdminCard>
      </div>

      <AdminCard className="p-5">
        <div className="flex items-center justify-between mb-3 gap-3 flex-wrap">
          <h3 className="font-semibold text-sm">Transaction log</h3>
          <AdminSelect value={txnType} onChange={(e) => setTxnType(e.target.value as TxnType)}>
            <option value="all">All types</option>
            <option value="top_up">Top up</option>
            <option value="consultation_debit">Consultation debit</option>
            <option value="consultation_credit">Consultation credit</option>
            <option value="consultation_minute_spend">Minute spend</option>
            <option value="refund">Refund</option>
            <option value="call_hold">Call hold</option>
            <option value="call_hold_release">Hold release</option>
            <option value="call_charge">Call charge</option>
          </AdminSelect>
        </div>
        {txns.length === 0 ? <EmptyState message="No transactions in this range." /> : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="text-[11px] uppercase text-slate-400 border-b border-slate-800">
                <tr><th className="text-left py-2">When</th><th className="text-left">Type</th><th className="text-right">Amount</th><th className="text-right">Balance after</th><th className="text-left">Description</th></tr>
              </thead>
              <tbody className="divide-y divide-slate-800">
                {txns.map((t) => (
                  <tr key={t.id}>
                    <td className="py-2 whitespace-nowrap">{fmtDate(t.created_at)}</td>
                    <td className="text-slate-400">{t.type}</td>
                    <td className="text-right">{fmtINR(t.amount)}</td>
                    <td className="text-right text-slate-400">{fmtINR(t.balance_after)}</td>
                    <td className="text-slate-300 truncate max-w-md">{t.description}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </AdminCard>
    </div>
  );
}
