import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { Save, AlertTriangle, RefreshCw } from "lucide-react";
import { AdminCard, AdminPageHeader, AdminInput, AdminButton, AdminTextarea, EmptyState } from "@/admin/ui";
import { useAdminAuth } from "@/admin/AdminAuthContext";
import { callAdminAction } from "@/admin/api";

interface Settings {
  min_billing_seconds: number;
  auto_end_below_balance: number;
  max_session_minutes: number;
  astrologer_share_percent: number;
  min_recharge_amount: number;
  max_wallet_balance: number;
  reviews_require_approval: boolean;
  min_review_session_seconds: number;
  min_withdrawal_amount: number;
  max_withdrawal_amount: number;
  withdrawal_processing_notice: string;
  maintenance_mode: boolean;
  maintenance_message: string;
}

const Section = ({ title, description, children }: { title: string; description?: string; children: React.ReactNode }) => (
  <AdminCard className="p-5">
    <div className="mb-4">
      <h3 className="font-semibold text-sm">{title}</h3>
      {description && <p className="text-xs text-slate-400 mt-1">{description}</p>}
    </div>
    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">{children}</div>
  </AdminCard>
);

const Field = ({ label, children }: { label: string; children: React.ReactNode }) => (
  <div>
    <label className="text-xs text-slate-400 uppercase tracking-wider">{label}</label>
    <div className="mt-1">{children}</div>
  </div>
);

export default function AdminSettings() {
  const { admin } = useAdminAuth();
  const [s, setS] = useState<Settings | null>(null);
  const [saving, setSaving] = useState(false);
  const [recomputing, setRecomputing] = useState(false);
  const [recomputeStatus, setRecomputeStatus] = useState<string | null>(null);

  async function recomputeLegacy() {
    if (!confirm("Recompute up to 500 legacy birth charts using astrologyapi.com? This may take a minute.")) return;
    setRecomputing(true);
    setRecomputeStatus("Recomputing legacy charts…");
    const r = await callAdminAction("recompute_legacy_charts", { limit: 500 });
    setRecomputing(false);
    if (r.ok) {
      const msg = `Recomputed ${r.succeeded ?? 0} of ${r.attempted ?? 0} charts (${r.failed ?? 0} failed)`;
      setRecomputeStatus(msg);
      toast.success(msg);
    } else {
      setRecomputeStatus(`Failed: ${r.error || "unknown error"}`);
      toast.error(r.error || "Recompute failed");
    }
  }

  async function load() {
    const { data } = await supabase.from("platform_settings").select("*").eq("id", 1).maybeSingle();
    if (data) setS(data as any);
  }

  useEffect(() => { load(); }, []);

  if (admin?.role !== "master_admin") {
    return (
      <div>
        <AdminPageHeader title="Settings" description="Platform configuration." />
        <EmptyState message="Only master admins can edit platform settings." />
      </div>
    );
  }
  if (!s) return <EmptyState message="Loading…" />;

  function set<K extends keyof Settings>(k: K, v: Settings[K]) {
    setS((prev) => prev ? { ...prev, [k]: v } : prev);
  }

  async function save() {
    if (!s) return;
    setSaving(true);
    const r = await callAdminAction("settings_update", s as unknown as Record<string, unknown>);
    setSaving(false);
    if (r.ok) { toast.success("Settings saved"); load(); }
    else toast.error(r.error || "Failed");
  }

  return (
    <div className="space-y-6">
      <AdminPageHeader
        title="Platform settings"
        description="Tweak global rules. Changes apply to new sessions and are logged for audit."
        actions={<AdminButton onClick={save} disabled={saving}><Save className="h-3.5 w-3.5" />{saving ? "Saving…" : "Save changes"}</AdminButton>}
      />

      {s.maintenance_mode && (
        <div className="rounded-xl border border-amber-500/40 bg-amber-500/10 text-amber-200 px-4 py-3 text-sm flex items-center gap-2">
          <AlertTriangle className="h-4 w-4" /> Maintenance mode is ON — customers and astrologers see the maintenance page.
        </div>
      )}

      <Section title="Session" description="Live session billing and limits.">
        <Field label="Minimum billing seconds"><AdminInput type="number" value={s.min_billing_seconds} onChange={(e) => set("min_billing_seconds", +e.target.value)} /></Field>
        <Field label="Auto-end below balance (₹)"><AdminInput type="number" value={s.auto_end_below_balance} onChange={(e) => set("auto_end_below_balance", +e.target.value)} /></Field>
        <Field label="Max session minutes"><AdminInput type="number" value={s.max_session_minutes} onChange={(e) => set("max_session_minutes", +e.target.value)} /></Field>
      </Section>

      <Section title="Commission" description="Revenue split between astrologer and platform.">
        <Field label="Astrologer share %"><AdminInput type="number" min={0} max={100} value={s.astrologer_share_percent} onChange={(e) => set("astrologer_share_percent", +e.target.value)} /></Field>
        <Field label="Platform share % (auto)">
          <div className="h-10 rounded-md bg-slate-950 border border-slate-700 px-3 text-sm flex items-center text-slate-400">
            {Math.max(0, 100 - Number(s.astrologer_share_percent || 0))}%
          </div>
        </Field>
      </Section>

      <Section title="Wallet">
        <Field label="Min recharge amount (₹)"><AdminInput type="number" value={s.min_recharge_amount} onChange={(e) => set("min_recharge_amount", +e.target.value)} /></Field>
        <Field label="Max wallet balance per customer (₹)"><AdminInput type="number" value={s.max_wallet_balance} onChange={(e) => set("max_wallet_balance", +e.target.value)} /></Field>
      </Section>

      <Section title="Reviews">
        <Field label="Require admin approval">
          <div className="h-10 flex items-center gap-2">
            <input type="checkbox" className="h-4 w-4 accent-indigo-500" checked={s.reviews_require_approval} onChange={(e) => set("reviews_require_approval", e.target.checked)} />
            <span className="text-sm text-slate-300">Reviews go to pending until approved</span>
          </div>
        </Field>
        <Field label="Min session seconds before review allowed"><AdminInput type="number" value={s.min_review_session_seconds} onChange={(e) => set("min_review_session_seconds", +e.target.value)} /></Field>
      </Section>

      <Section title="Withdrawals">
        <Field label="Min withdrawal amount (₹)"><AdminInput type="number" value={s.min_withdrawal_amount} onChange={(e) => set("min_withdrawal_amount", +e.target.value)} /></Field>
        <Field label="Max withdrawal amount (₹)"><AdminInput type="number" value={s.max_withdrawal_amount} onChange={(e) => set("max_withdrawal_amount", +e.target.value)} /></Field>
        <div className="md:col-span-2">
          <Field label="Processing time notice"><AdminTextarea rows={2} value={s.withdrawal_processing_notice} onChange={(e) => set("withdrawal_processing_notice", e.target.value)} /></Field>
        </div>
      </Section>

      <Section title="Maintenance mode" description="Show a maintenance page to customers and astrologers. Admin panel stays accessible.">
        <Field label="Enable maintenance mode">
          <div className="h-10 flex items-center gap-2">
            <input type="checkbox" className="h-4 w-4 accent-amber-500" checked={s.maintenance_mode} onChange={(e) => set("maintenance_mode", e.target.checked)} />
            <span className="text-sm text-slate-300">{s.maintenance_mode ? "Site is in maintenance" : "Site is live"}</span>
          </div>
        </Field>
        <div className="md:col-span-2">
          <Field label="Maintenance message"><AdminTextarea rows={3} value={s.maintenance_message} onChange={(e) => set("maintenance_message", e.target.value)} /></Field>
        </div>
      </Section>

      <Section title="Birth chart tools" description="Re-run calculate-chart for legacy rows so they pick up the latest astrologyapi.com results.">
        <div className="md:col-span-2 flex flex-col gap-2">
          <AdminButton onClick={recomputeLegacy} disabled={recomputing}>
            <RefreshCw className={`h-3.5 w-3.5 ${recomputing ? "animate-spin" : ""}`} />
            {recomputing ? "Recomputing…" : "Recompute legacy charts"}
          </AdminButton>
          {recomputeStatus && (
            <p className="text-xs text-slate-400">{recomputeStatus}</p>
          )}
        </div>
      </Section>

      <AdminCard className="p-5">
        <div className="mb-3">
          <h3 className="font-semibold text-sm">Calculation notes</h3>
          <p className="text-xs text-slate-400 mt-1">Internal reference for the support team — not shown to customers.</p>
        </div>
        <div className="rounded-lg border border-slate-700 bg-slate-950/60 px-4 py-3 text-xs leading-relaxed text-slate-300">
          Birth chart and Panchang calculations use astrologyapi.com with Lahiri ayanamsa, and
          display only the 9 classical Vedic Grahas: Sun, Moon, Mars, Mercury, Jupiter, Venus,
          Saturn, Rahu and Ketu. Outer planets (Uranus, Neptune, Pluto) are intentionally
          excluded — they are not part of traditional Vedic astrology, and excluding them
          eliminates the only bodies that previously showed minor (~1–12') ayanamsa drift
          versus AstroSage. All sign, house, nakshatra, and pada placements match AstroSage.
        </div>
      </AdminCard>

      <div className="flex justify-end">
        <AdminButton onClick={save} disabled={saving}><Save className="h-3.5 w-3.5" />{saving ? "Saving…" : "Save changes"}</AdminButton>
      </div>
    </div>
  );
}
