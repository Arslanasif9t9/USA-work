import { useEffect, useMemo, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { Loader2, Star, Check, X, Trash2 } from "lucide-react";
import { AdminPageHeader, AdminCard, AdminTabs, AdminButton, AdminModal, AdminTextarea, EmptyState, fmtDate } from "@/admin/ui";
import { callAdminAction } from "@/admin/api";

interface ReviewRow {
  id: string;
  rating: number;
  comment: string | null;
  created_at: string;
  moderation_status: string;
  rejection_reason: string | null;
  user_id: string;
  astrologer_id: string;
  customer_name?: string;
  astrologer_name?: string;
}

export default function AdminReviews() {
  const { toast } = useToast();
  const [tab, setTab] = useState<"pending" | "approved" | "rejected">("pending");
  const [rows, setRows] = useState<ReviewRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [active, setActive] = useState<ReviewRow | null>(null);
  const [reason, setReason] = useState("");

  const PAGE_SIZE = 15;
  const [offset, setOffset] = useState(0);
  const [hasMore, setHasMore] = useState(true);

  const loadPage = async (reset: boolean) => {
    setLoading(true);
    const from = reset ? 0 : offset;
    const { data } = await supabase
      .from("reviews")
      .select("*")
      .order("created_at", { ascending: false })
      .range(from, from + PAGE_SIZE - 1);
    const list = data ?? [];
    const userIds = Array.from(new Set(list.map((r: any) => r.user_id)));
    const astroIds = Array.from(new Set(list.map((r: any) => r.astrologer_id)));
    const [{ data: profiles }, { data: astros }] = await Promise.all([
      userIds.length ? supabase.from("profiles").select("id, name, email").in("id", userIds) : Promise.resolve({ data: [] as any[] }),
      astroIds.length ? supabase.from("astrologers").select("id, display_name").in("id", astroIds) : Promise.resolve({ data: [] as any[] }),
    ]);
    const pn: Record<string, string> = {}; (profiles || []).forEach((p: any) => pn[p.id] = p.name || p.email || "—");
    const an: Record<string, string> = {}; (astros || []).forEach((a: any) => an[a.id] = a.display_name);
    const enriched = list.map((r: any) => ({ ...r, customer_name: pn[r.user_id], astrologer_name: an[r.astrologer_id] }));
    setRows((prev) => (reset ? enriched : [...prev, ...enriched]));
    setOffset(from + list.length);
    setHasMore(list.length === PAGE_SIZE);
    setLoading(false);
  };
  const refresh = () => { setOffset(0); setHasMore(true); loadPage(true); };
  useEffect(() => { refresh(); }, []);

  const counts = useMemo(() => ({
    pending: rows.filter(r => r.moderation_status === "pending").length,
    approved: rows.filter(r => r.moderation_status === "approved").length,
    rejected: rows.filter(r => r.moderation_status === "rejected").length,
  }), [rows]);
  const filtered = rows.filter(r => r.moderation_status === tab);

  const moderate = async (r: ReviewRow, status: string, why?: string) => {
    const res = await callAdminAction("review.moderate", { review_id: r.id, status, reason: why });
    if (!res.ok) return toast({ title: "Failed", description: res.error, variant: "destructive" });
    toast({ title: `Review ${status}` });
    setActive(null); setReason(""); refresh();
  };
  const remove = async (r: ReviewRow) => {
    if (!confirm("Delete this review permanently?")) return;
    const res = await callAdminAction("review.delete", { review_id: r.id });
    if (!res.ok) return toast({ title: "Failed", description: res.error, variant: "destructive" });
    toast({ title: "Review deleted" });
    refresh();
  };

  return (
    <div>
      <AdminPageHeader title="Reviews" description="Moderate customer reviews before they go live." />

      <AdminTabs value={tab} onChange={setTab} tabs={[
        { value: "pending",  label: "Pending",  count: counts.pending },
        { value: "approved", label: "Approved", count: counts.approved },
        { value: "rejected", label: "Rejected", count: counts.rejected },
      ]} />

      <AdminCard>
        {loading ? <div className="p-10 flex justify-center"><Loader2 className="h-5 w-5 animate-spin text-slate-400" /></div>
        : filtered.length === 0 ? <EmptyState message={`No ${tab} reviews.`} />
        : (
          <div className="divide-y divide-slate-800">
            {filtered.map((r) => (
              <div key={r.id} className="p-4 flex items-start gap-4 hover:bg-slate-800/30">
                <div className="flex flex-col items-center min-w-[64px]">
                  <div className="flex items-center gap-0.5 text-amber-400">
                    {Array.from({ length: 5 }).map((_, i) => (
                      <Star key={i} className={`h-3.5 w-3.5 ${i < r.rating ? "fill-amber-400" : "text-slate-700"}`} />
                    ))}
                  </div>
                  <div className="text-xs text-slate-500 mt-1">{r.rating}/5</div>
                </div>
                <div className="flex-1 min-w-0">
                  <div className="text-sm">
                    <span className="font-medium text-slate-100">{r.customer_name}</span>
                    <span className="text-slate-500"> → </span>
                    <span className="text-slate-200">{r.astrologer_name}</span>
                  </div>
                  <div className="text-sm text-slate-300 mt-1">{r.comment || <em className="text-slate-500">No comment</em>}</div>
                  <div className="text-[11px] text-slate-500 mt-2">Submitted {fmtDate(r.created_at)}</div>
                  {r.rejection_reason && <div className="text-xs text-rose-300 mt-1">Rejected: {r.rejection_reason}</div>}
                </div>
                <div className="flex flex-col gap-1.5">
                  {tab !== "approved" && <AdminButton variant="primary" onClick={() => moderate(r, "approved")}><Check className="h-3 w-3" /> Approve</AdminButton>}
                  {tab !== "rejected" && <AdminButton variant="secondary" onClick={() => setActive(r)}><X className="h-3 w-3" /> Reject</AdminButton>}
                  {tab === "approved" && <AdminButton variant="danger" onClick={() => remove(r)}><Trash2 className="h-3 w-3" /> Delete</AdminButton>}
                </div>
              </div>
            ))}
          </div>
        )}
        {hasMore && !loading && (
          <div className="flex justify-center p-4">
            <AdminButton variant="ghost" onClick={() => loadPage(false)}>Load more</AdminButton>
          </div>
        )}
      </AdminCard>

      {active && <AdminModal open onClose={() => setActive(null)} title="Reject review" maxWidth="max-w-md">
        <p className="text-sm text-slate-400 mb-3">Optional reason for rejecting this review.</p>
        <AdminTextarea rows={3} value={reason} onChange={(e) => setReason(e.target.value)} />
        <div className="flex justify-end gap-2 mt-4">
          <AdminButton variant="ghost" onClick={() => setActive(null)}>Cancel</AdminButton>
          <AdminButton variant="danger" onClick={() => moderate(active, "rejected", reason)}>Reject</AdminButton>
        </div>
      </AdminModal>}
    </div>
  );
}
