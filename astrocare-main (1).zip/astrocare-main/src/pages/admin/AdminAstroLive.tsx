// Admin control panel for AstroLive — kill switch + live monitoring.
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { Radio, Eye, Heart, MessageCircle, Gift, X } from "lucide-react";
import { AdminCard, AdminPageHeader, AdminButton, EmptyState } from "@/admin/ui";
import { useAdminAuth } from "@/admin/AdminAuthContext";

interface LiveRow {
  id: string;
  title: string;
  started_at: string;
  viewer_count: number;
  total_likes: number;
  total_comments: number;
  total_gifts_value: number;
  astrologer: { display_name: string; avatar_url: string | null } | null;
}

export default function AdminAstroLive() {
  const { admin } = useAdminAuth();
  const [settings, setSettings] = useState<any>(null);
  const [streams, setStreams] = useState<LiveRow[]>([]);
  const [overall, setOverall] = useState({ total: 0, watchHours: 0, gifts: 0, uniqueViewers: 0 });

  async function loadSettings() {
    const { data } = await supabase.from("platform_settings").select("astrolive_enabled, astrolive_enabled_web, astrolive_enabled_mobile").eq("id", 1).maybeSingle();
    setSettings(data);
  }
  async function loadStreams() {
    const { data } = await supabase
      .from("live_streams")
      .select("id,title,started_at,viewer_count,total_likes,total_comments,total_gifts_value, astrologer:astrologers!live_streams_astrologer_id_fkey(display_name,avatar_url)")
      .eq("status", "live")
      .order("started_at", { ascending: false });
    setStreams((data || []) as any);
  }
  async function loadOverall() {
    const { data } = await supabase.from("live_streams").select("duration_seconds,total_gifts_value,total_unique_viewers");
    if (data) {
      setOverall({
        total: data.length,
        watchHours: Math.round(data.reduce((a, r) => a + (r.duration_seconds || 0), 0) / 3600 * 10) / 10,
        gifts: data.reduce((a, r) => a + Number(r.total_gifts_value || 0), 0),
        uniqueViewers: data.reduce((a, r) => a + (r.total_unique_viewers || 0), 0),
      });
    }
  }

  useEffect(() => {
    loadSettings(); loadStreams(); loadOverall();
    const ch = supabase.channel("admin_astrolive")
      .on("postgres_changes", { event: "*", schema: "public", table: "live_streams" }, () => { loadStreams(); loadOverall(); })
      .subscribe();
    return () => { supabase.removeChannel(ch); };
  }, []);

  async function setFlag(key: "astrolive_enabled" | "astrolive_enabled_web" | "astrolive_enabled_mobile", value: boolean) {
    const patch = { [key]: value } as Record<typeof key, boolean>;
    const { error } = await supabase.from("platform_settings").update(patch).eq("id", 1);
    if (error) { toast.error(error.message); return; }
    if (key === "astrolive_enabled" && !value) {
      // Force-end all live streams
      const { data } = await supabase.from("live_streams").select("id").eq("status", "live");
      for (const r of data || []) {
        await supabase.rpc("end_live_stream", { _stream_id: r.id, _reason: "disabled_by_admin" });
      }
      toast.success("AstroLive disabled — all streams ended");
    } else toast.success("Updated");
    loadSettings(); loadStreams();
  }

  async function endStream(id: string) {
    const reason = window.prompt("Reason for ending this stream?") || "ended_by_admin";
    const { error } = await supabase.rpc("end_live_stream", { _stream_id: id, _reason: reason });
    if (error) toast.error(error.message); else { toast.success("Stream ended"); loadStreams(); }
  }

  if (!admin) return null;

  return (
    <div className="space-y-6">
      <AdminPageHeader title="AstroLive" description="Master controls and live monitoring for live streaming." />

      <AdminCard className="p-5">
        <h3 className="font-semibold text-sm mb-3">Master controls</h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
          {([
            { k: "astrolive_enabled", label: "AstroLive Enabled (Master)" },
            { k: "astrolive_enabled_web", label: "Enabled on Web" },
            { k: "astrolive_enabled_mobile", label: "Enabled on Mobile" },
          ] as const).map(({ k, label }) => (
            <label key={k} className="flex items-center justify-between rounded-lg border border-slate-700 bg-slate-900/40 p-3">
              <span className="text-sm">{label}</span>
              <input
                type="checkbox"
                className="h-5 w-5 accent-indigo-500"
                checked={!!settings?.[k]}
                onChange={(e) => setFlag(k, e.target.checked)}
              />
            </label>
          ))}
        </div>
      </AdminCard>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <AdminCard className="p-4"><div className="text-xs text-slate-400">Total lives</div><div className="text-2xl font-semibold mt-1">{overall.total}</div></AdminCard>
        <AdminCard className="p-4"><div className="text-xs text-slate-400">Watch hours</div><div className="text-2xl font-semibold mt-1">{overall.watchHours}</div></AdminCard>
        <AdminCard className="p-4"><div className="text-xs text-slate-400">Unique viewers</div><div className="text-2xl font-semibold mt-1">{overall.uniqueViewers}</div></AdminCard>
        <AdminCard className="p-4"><div className="text-xs text-slate-400">Gifts value</div><div className="text-2xl font-semibold mt-1">₹{overall.gifts}</div></AdminCard>
      </div>

      <AdminCard className="p-5">
        <h3 className="font-semibold text-sm mb-3 flex items-center gap-2"><Radio className="h-4 w-4 text-red-400" /> Currently live ({streams.length})</h3>
        {streams.length === 0 ? (
          <EmptyState message="No live streams right now." />
        ) : (
          <div className="divide-y divide-slate-800">
            {streams.map((s) => (
              <div key={s.id} className="py-3 flex items-center gap-3">
                <img src={s.astrologer?.avatar_url || "/favicon.ico"} className="h-10 w-10 rounded-full object-cover" alt="" />
                <div className="flex-1 min-w-0">
                  <div className="text-sm font-medium truncate">{s.astrologer?.display_name}</div>
                  <div className="text-xs text-slate-400 truncate">{s.title}</div>
                </div>
                <div className="hidden md:flex items-center gap-3 text-xs text-slate-300">
                  <span className="flex items-center gap-1"><Eye className="h-3 w-3" />{s.viewer_count}</span>
                  <span className="flex items-center gap-1"><Heart className="h-3 w-3" />{s.total_likes}</span>
                  <span className="flex items-center gap-1"><MessageCircle className="h-3 w-3" />{s.total_comments}</span>
                  <span className="flex items-center gap-1"><Gift className="h-3 w-3" />₹{s.total_gifts_value}</span>
                </div>
                <AdminButton onClick={() => endStream(s.id)}><X className="h-3.5 w-3.5" /> End</AdminButton>
              </div>
            ))}
          </div>
        )}
      </AdminCard>
    </div>
  );
}
