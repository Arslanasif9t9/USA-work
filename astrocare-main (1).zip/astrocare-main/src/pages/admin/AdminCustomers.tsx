import { useEffect, useMemo, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { Loader2, Search, Eye, Wallet as WalletIcon, ShieldOff, Shield, History as HistoryIcon } from "lucide-react";
import { AdminPageHeader, AdminCard, AdminTabs, StatusBadge, AdminInput, AdminButton, AdminModal, AdminTextarea, EmptyState, fmtINR, fmtDate } from "@/admin/ui";
import { callAdminAction } from "@/admin/api";
import { useAdminAuth } from "@/admin/AdminAuthContext";
import { adminHasPermission } from "@/admin/permissions";
import { WalletAdjustModal } from "./AdminAstrologers";

interface Customer {
  id: string;
  name: string;
  email: string | null;
  phone: string | null;
  is_blocked: boolean;
  blocked_reason: string | null;
  consultation_minutes: number;
  created_at: string;
}

export default function AdminCustomers() {
  const { admin } = useAdminAuth();
  const { toast } = useToast();
  const [tab, setTab] = useState<"all" | "active" | "blocked">("all");
  const [search, setSearch] = useState("");
  const [list, setList] = useState<Customer[]>([]);
  const [walletMap, setWalletMap] = useState<Record<string, number>>({});
  const [statsMap, setStatsMap] = useState<Record<string, { sessions: number; spent: number }>>({});
  const [loading, setLoading] = useState(true);
  const [active, setActive] = useState<Customer | null>(null);
  const [modal, setModal] = useState<null | "view" | "wallet" | "block" | "history">(null);
  const [reason, setReason] = useState("");

  const refresh = async () => {
    setLoading(true);
    const { data: profiles } = await supabase.from("profiles").select("*").order("created_at", { ascending: false }).limit(15);
    const { data: wallets } = await supabase.from("wallets").select("user_id, balance");
    const ids = (profiles || []).map(p => p.id);
    const wm: Record<string, number> = {};
    (wallets || []).forEach((w: any) => { wm[w.user_id] = Number(w.balance || 0); });
    setWalletMap(wm);

    // Build session/spent stats
    const [{ data: chats }, { data: calls }] = await Promise.all([
      supabase.from("chat_sessions").select("user_id, total_cost").in("user_id", ids),
      supabase.from("call_sessions").select("user_id, wallet_hold_amount, duration_seconds, per_minute_rate").in("user_id", ids),
    ]);
    const sm: Record<string, { sessions: number; spent: number }> = {};
    ids.forEach(id => sm[id] = { sessions: 0, spent: 0 });
    (chats || []).forEach((c: any) => { sm[c.user_id] && (sm[c.user_id].sessions++, sm[c.user_id].spent += Number(c.total_cost || 0)); });
    (calls || []).forEach((c: any) => {
      if (!sm[c.user_id]) return;
      sm[c.user_id].sessions++;
      const cost = Math.max(1, Math.ceil(Number(c.duration_seconds || 0) / 60)) * Number(c.per_minute_rate || 0);
      sm[c.user_id].spent += cost;
    });
    setStatsMap(sm);
    setList((profiles || []) as Customer[]);
    setLoading(false);
  };
  useEffect(() => { refresh(); }, []);

  const filtered = useMemo(() => list.filter((c) => {
    if (tab === "active" && c.is_blocked) return false;
    if (tab === "blocked" && !c.is_blocked) return false;
    if (search) {
      const s = search.toLowerCase();
      if (!`${c.name} ${c.email || ""}`.toLowerCase().includes(s)) return false;
    }
    return true;
  }), [list, tab, search]);

  const counts = useMemo(() => ({
    all: list.length, active: list.filter(c => !c.is_blocked).length, blocked: list.filter(c => c.is_blocked).length,
  }), [list]);

  const setBlock = async (c: Customer, blocked: boolean, why?: string) => {
    const r = await callAdminAction("customer.set_block", { user_id: c.id, blocked, reason: why });
    if (!r.ok) return toast({ title: "Failed", description: r.error, variant: "destructive" });
    toast({ title: blocked ? "Customer blocked" : "Customer unblocked" });
    setModal(null); setReason(""); refresh();
  };

  return (
    <div>
      <AdminPageHeader title="Customers" description="View, edit, and block customers." />

      <div className="flex flex-wrap items-center justify-between gap-3 mb-4">
        <AdminTabs<"all" | "active" | "blocked">
          tabs={[
            { value: "all",     label: "All",     count: counts.all },
            { value: "active",  label: "Active",  count: counts.active },
            { value: "blocked", label: "Blocked", count: counts.blocked },
          ]}
          value={tab} onChange={setTab}
        />
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-500" />
          <AdminInput placeholder="Search name or email…" value={search} onChange={(e) => setSearch(e.target.value)} className="pl-9 w-64" />
        </div>
      </div>

      <AdminCard className="overflow-hidden">
        {loading ? <div className="p-10 flex justify-center"><Loader2 className="h-5 w-5 animate-spin text-slate-400" /></div>
        : filtered.length === 0 ? <EmptyState /> : (
          <div className="overflow-x-auto admin-table-scroll">
            <table className="admin-table w-full text-sm">
              <thead className="bg-slate-900/80 text-xs uppercase text-slate-400">
                <tr>
                  <th className="text-left px-4 py-3 font-medium">Name</th>
                  <th className="text-left px-4 py-3 font-medium">Email</th>
                  <th className="text-left px-4 py-3 font-medium">Phone</th>
                  <th className="text-left px-4 py-3 font-medium">Wallet</th>
                  <th className="text-left px-4 py-3 font-medium">Sessions</th>
                  <th className="text-left px-4 py-3 font-medium">Spent</th>
                  <th className="text-left px-4 py-3 font-medium">Joined</th>
                  <th className="text-left px-4 py-3 font-medium">Status</th>
                  <th className="text-right px-4 py-3 font-medium admin-cell-action">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800">
                {filtered.map((c) => (
                  <tr key={c.id} className="hover:bg-slate-800/40">
                    <td className="px-4 py-3 font-medium">{c.name || "—"}</td>
                    <td className="px-4 py-3 text-slate-300">{c.email || "—"}</td>
                    <td className="px-4 py-3 text-slate-400">{c.phone || "—"}</td>
                    <td className="px-4 py-3 text-slate-200">{fmtINR(walletMap[c.id])}</td>
                    <td className="px-4 py-3 text-slate-300">{statsMap[c.id]?.sessions ?? 0}</td>
                    <td className="px-4 py-3 text-slate-300">{fmtINR(statsMap[c.id]?.spent ?? 0)}</td>
                    <td className="px-4 py-3 text-xs text-slate-400">{fmtDate(c.created_at).split(",")[0]}</td>
                    <td className="px-4 py-3"><StatusBadge status={c.is_blocked ? "blocked" : "active"} /></td>
                    <td className="px-4 py-3 admin-cell-action">
                      <div className="flex items-center justify-end gap-1 whitespace-nowrap">
                        <button onClick={() => { setActive(c); setModal("view"); }} className="p-1.5 rounded text-slate-400 hover:bg-slate-700/60" title="View"><Eye className="h-3.5 w-3.5" /></button>
                        <button onClick={() => { setActive(c); setModal("history"); }} className="p-1.5 rounded text-slate-400 hover:bg-slate-700/60" title="History"><HistoryIcon className="h-3.5 w-3.5" /></button>
                        {adminHasPermission(admin, "manage_wallet") && (
                          <button onClick={() => { setActive(c); setModal("wallet"); }} className="p-1.5 rounded text-slate-400 hover:bg-slate-700/60" title="Adjust wallet"><WalletIcon className="h-3.5 w-3.5" /></button>
                        )}
                        {c.is_blocked
                          ? <AdminButton variant="primary" onClick={() => setBlock(c, false)}><Shield className="h-3 w-3" /> Unblock</AdminButton>
                          : <AdminButton variant="danger" onClick={() => { setActive(c); setModal("block"); }}><ShieldOff className="h-3 w-3" /> Block</AdminButton>}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </AdminCard>

      {active && <AdminModal open={modal === "view"} onClose={() => setModal(null)} title={active.name || active.email || "Customer"} maxWidth="max-w-lg">
        <div className="space-y-2 text-sm">
          <div><span className="text-slate-400">Email:</span> {active.email || "—"}</div>
          <div><span className="text-slate-400">Phone:</span> {active.phone || "—"}</div>
          <div><span className="text-slate-400">Wallet balance:</span> {fmtINR(walletMap[active.id])}</div>
          <div><span className="text-slate-400">Consultation minutes:</span> {active.consultation_minutes}</div>
          <div><span className="text-slate-400">Joined:</span> {fmtDate(active.created_at)}</div>
          {active.is_blocked && <div className="text-rose-400">Blocked: {active.blocked_reason || "—"}</div>}
        </div>
      </AdminModal>}

      {active && <AdminModal open={modal === "block"} onClose={() => setModal(null)} title={`Block ${active.name || active.email}`} maxWidth="max-w-md">
        <p className="text-sm text-slate-400 mb-3">Customer cannot log in or start sessions while blocked.</p>
        <AdminTextarea rows={3} value={reason} onChange={(e) => setReason(e.target.value)} placeholder="Reason" />
        <div className="flex justify-end gap-2 mt-4">
          <AdminButton variant="ghost" onClick={() => setModal(null)}>Cancel</AdminButton>
          <AdminButton variant="danger" onClick={() => setBlock(active, true, reason)}>Block</AdminButton>
        </div>
      </AdminModal>}

      {active && <WalletAdjustModal open={modal === "wallet"} onClose={() => { setModal(null); refresh(); }} userId={active.id} title={active.name || "customer"} userType="customer" />}
      {active && modal === "history" && <CustomerHistoryModal customer={active} onClose={() => setModal(null)} />}
    </div>
  );
}

function CustomerHistoryModal({ customer, onClose }: { customer: Customer; onClose: () => void }) {
  const [tab, setTab] = useState<"sessions" | "transactions">("sessions");
  const [sessions, setSessions] = useState<any[]>([]);
  const [tx, setTx] = useState<any[]>([]);
  useEffect(() => {
    (async () => {
      const [{ data: chats }, { data: calls }, walletRes] = await Promise.all([
        supabase.from("chat_sessions").select("id, status, duration_seconds, total_cost, accepted_at, ended_at").eq("user_id", customer.id),
        supabase.from("call_sessions").select("id, status, duration_seconds, per_minute_rate, connected_at, ended_at").eq("user_id", customer.id),
        supabase.from("wallets").select("id").eq("user_id", customer.id).maybeSingle(),
      ]);
      setSessions([
        ...(chats || []).map((c: any) => ({ ...c, kind: "chat", when: c.ended_at || c.accepted_at, cost: c.total_cost })),
        ...(calls || []).map((c: any) => ({ ...c, kind: "call", when: c.ended_at || c.connected_at, cost: Math.max(1, Math.ceil((c.duration_seconds || 0)/60)) * Number(c.per_minute_rate || 0) })),
      ].sort((a, b) => new Date(b.when || 0).getTime() - new Date(a.when || 0).getTime()));
      if (walletRes.data) {
        const { data } = await supabase.from("transactions").select("*").eq("wallet_id", walletRes.data.id).order("created_at", { ascending: false }).limit(200);
        setTx(data || []);
      }
    })();
  }, [customer.id]);
  return (
    <AdminModal open onClose={onClose} title={`History — ${customer.name || customer.email}`}>
      <AdminTabs value={tab} onChange={setTab} tabs={[{ value: "sessions", label: "Sessions" }, { value: "transactions", label: "Transactions" }]} />
      <div className="max-h-[60vh] overflow-y-auto rounded-md border border-slate-800">
        {tab === "sessions" ? (
          <table className="w-full text-sm">
            <thead className="bg-slate-900/80 text-xs text-slate-400"><tr><th className="text-left px-3 py-2">Type</th><th className="text-left px-3 py-2">When</th><th className="text-left px-3 py-2">Status</th><th className="text-left px-3 py-2">Duration</th><th className="text-right px-3 py-2">Cost</th></tr></thead>
            <tbody className="divide-y divide-slate-800">
              {sessions.length === 0 ? <tr><td colSpan={5}><EmptyState message="No sessions yet." /></td></tr> :
              sessions.map((s) => (
                <tr key={s.kind + s.id}><td className="px-3 py-2 capitalize">{s.kind}</td><td className="px-3 py-2 text-xs text-slate-400">{fmtDate(s.when)}</td><td className="px-3 py-2"><StatusBadge status={s.status} /></td><td className="px-3 py-2">{Math.floor((s.duration_seconds || 0)/60)}m</td><td className="px-3 py-2 text-right">{fmtINR(s.cost)}</td></tr>
              ))}
            </tbody>
          </table>
        ) : (
          <table className="w-full text-sm">
            <thead className="bg-slate-900/80 text-xs text-slate-400"><tr><th className="text-left px-3 py-2">Date</th><th className="text-left px-3 py-2">Type</th><th className="text-left px-3 py-2">Description</th><th className="text-right px-3 py-2">Amount</th><th className="text-right px-3 py-2">Balance</th></tr></thead>
            <tbody className="divide-y divide-slate-800">
              {tx.length === 0 ? <tr><td colSpan={5}><EmptyState message="No transactions." /></td></tr> :
              tx.map((t) => (
                <tr key={t.id}><td className="px-3 py-2 text-xs text-slate-400">{fmtDate(t.created_at)}</td><td className="px-3 py-2 text-xs">{t.type}</td><td className="px-3 py-2 text-slate-300">{t.description}</td><td className="px-3 py-2 text-right">{fmtINR(t.amount)}</td><td className="px-3 py-2 text-right text-slate-400">{fmtINR(t.balance_after)}</td></tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
      <div className="flex justify-end mt-4"><AdminButton variant="ghost" onClick={onClose}>Close</AdminButton></div>
    </AdminModal>
  );
}
