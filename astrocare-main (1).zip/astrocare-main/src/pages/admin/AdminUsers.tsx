import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { Loader2, Plus, KeyRound, Shield, ShieldOff, X, Check, Eye, EyeOff, RefreshCw } from "lucide-react";
import { ADMIN_PERMISSIONS, AdminUser, AdminRole } from "@/admin/permissions";
import { useAdminAuth } from "@/admin/AdminAuthContext";

const ROLE_OPTIONS: { value: AdminRole; label: string }[] = [
  { value: "admin",         label: "Admin" },
  { value: "finance_admin", label: "Finance Admin" },
];

function generatePassword() {
  const chars = "ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnpqrstuvwxyz23456789!@#$";
  let p = "";
  for (let i = 0; i < 14; i++) p += chars[Math.floor(Math.random() * chars.length)];
  return p;
}

export default function AdminUsers() {
  const { admin } = useAdminAuth();
  const { toast } = useToast();
  const [admins, setAdmins] = useState<AdminUser[]>([]);
  const [loading, setLoading] = useState(true);
  const [showCreate, setShowCreate] = useState(false);
  const [editing, setEditing] = useState<AdminUser | null>(null);
  const [credentialModal, setCredentialModal] = useState<{ email: string; password: string } | null>(null);

  const refresh = async () => {
    setLoading(true);
    const { data } = await supabase
      .from("admin_users").select("*").order("created_at", { ascending: false });
    setAdmins((data || []).map((d: any) => ({
      ...d, permissions: Array.isArray(d.permissions) ? d.permissions : [],
    })) as AdminUser[]);
    setLoading(false);
  };

  useEffect(() => { refresh(); }, []);

  const callMgmt = async (action: string, payload: any) => {
    const { data: { session } } = await supabase.auth.getSession();
    const res = await fetch(
      `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/admin-manage`,
      {
        method: "POST",
        headers: {
          "content-type": "application/json",
          Authorization: `Bearer ${session?.access_token}`,
          apikey: import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY,
        },
        body: JSON.stringify({ action, ...payload }),
      },
    );
    return res.json();
  };

  const onCreate = async (form: { full_name: string; email: string; role: AdminRole; permissions: string[]; can_directly_adjust_wallet: boolean; max_wallet_adjustment: string; password: string }) => {
    if (!form.password || form.password.length < 8) {
      toast({ title: "Password too short", description: "Use at least 8 characters.", variant: "destructive" });
      return;
    }
    const r = await callMgmt("create", form);
    if (!r?.ok) { toast({ title: "Failed", description: r?.error || "Could not create admin", variant: "destructive" }); return; }
    toast({ title: "Admin created" });
    setShowCreate(false);
    setCredentialModal({ email: form.email, password: form.password });
    refresh();
  };

  const onEdit = async (id: string, patch: { full_name?: string; role?: AdminRole; permissions?: string[]; can_directly_adjust_wallet?: boolean; max_wallet_adjustment?: string }) => {
    const r = await callMgmt("update", { admin_id: id, ...patch });
    if (!r?.ok) { toast({ title: "Failed", description: r?.error, variant: "destructive" }); return; }
    toast({ title: "Admin updated" });
    setEditing(null);
    refresh();
  };

  const onToggleActive = async (a: AdminUser) => {
    const r = await callMgmt("set_active", { admin_id: a.id, is_active: !a.is_active });
    if (!r?.ok) { toast({ title: "Failed", description: r?.error, variant: "destructive" }); return; }
    toast({ title: a.is_active ? "Deactivated" : "Reactivated" });
    refresh();
  };

  const [resetTarget, setResetTarget] = useState<AdminUser | null>(null);
  const onResetPassword = (a: AdminUser) => setResetTarget(a);
  const submitReset = async (newPassword: string) => {
    if (!resetTarget) return;
    if (!newPassword || newPassword.length < 8) {
      toast({ title: "Password too short", description: "Use at least 8 characters.", variant: "destructive" });
      return;
    }
    const r = await callMgmt("reset_password", { admin_id: resetTarget.id, password: newPassword });
    if (!r?.ok) { toast({ title: "Failed", description: r?.error, variant: "destructive" }); return; }
    toast({ title: "Password updated", description: `New password set for ${resetTarget.email}` });
    setResetTarget(null);
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-semibold">Admin Users</h1>
          <p className="text-sm text-slate-400 mt-1">Master admins can manage who else has admin access.</p>
        </div>
        <button onClick={() => setShowCreate(true)} className="inline-flex items-center gap-2 px-4 h-10 rounded-md bg-indigo-600 hover:bg-indigo-500 text-white text-sm font-medium">
          <Plus className="h-4 w-4" /> New Admin
        </button>
      </div>

      <div className="rounded-xl border border-slate-800 bg-slate-900/60 overflow-hidden">
        {loading ? (
          <div className="p-10 flex items-center justify-center text-slate-400"><Loader2 className="h-5 w-5 animate-spin" /></div>
        ) : admins.length === 0 ? (
          <div className="p-10 text-center text-slate-400 text-sm">No admins yet</div>
        ) : (
          <table className="w-full text-sm">
            <thead className="bg-slate-900/80 text-xs uppercase text-slate-400">
              <tr>
                <th className="text-left px-4 py-3 font-medium">Name</th>
                <th className="text-left px-4 py-3 font-medium">Email</th>
                <th className="text-left px-4 py-3 font-medium">Role</th>
                <th className="text-left px-4 py-3 font-medium">Permissions</th>
                <th className="text-left px-4 py-3 font-medium">Status</th>
                <th className="text-left px-4 py-3 font-medium">Last Login</th>
                <th className="text-right px-4 py-3 font-medium">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800">
              {admins.map((a) => {
                const isMaster = a.role === "master_admin";
                const isSelf = a.user_id === admin?.user_id;
                return (
                  <tr key={a.id} className="hover:bg-slate-800/40">
                    <td className="px-4 py-3">{a.full_name || "—"}</td>
                    <td className="px-4 py-3 text-slate-300">{a.email}</td>
                    <td className="px-4 py-3">
                      <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded text-[11px] font-medium ${isMaster ? "bg-amber-500/15 text-amber-300" : "bg-indigo-500/15 text-indigo-300"}`}>
                        {isMaster ? "Master" : a.role === "finance_admin" ? "Finance" : "Admin"}
                      </span>
                    </td>
                    <td className="px-4 py-3 text-slate-400">{isMaster ? "All (10)" : `${a.permissions.length} of ${ADMIN_PERMISSIONS.filter(p => !p.master_only).length}`}</td>
                    <td className="px-4 py-3">
                      {a.is_active
                        ? <span className="inline-flex items-center gap-1 text-emerald-400 text-xs"><Check className="h-3 w-3" /> Active</span>
                        : <span className="inline-flex items-center gap-1 text-slate-500 text-xs"><X className="h-3 w-3" /> Inactive</span>}
                    </td>
                    <td className="px-4 py-3 text-slate-400 text-xs">{a.last_login_at ? new Date(a.last_login_at).toLocaleString() : "Never"}</td>
                    <td className="px-4 py-3">
                      <div className="flex items-center justify-end gap-1">
                        {!isMaster && (
                          <button onClick={() => setEditing(a)} className="px-2 py-1 rounded text-xs text-slate-300 hover:bg-slate-700/60">Edit</button>
                        )}
                        <button onClick={() => onResetPassword(a)} className="p-1.5 rounded text-slate-400 hover:bg-slate-700/60" title="Reset password"><KeyRound className="h-3.5 w-3.5" /></button>
                        {!isSelf && !isMaster && (
                          <button onClick={() => onToggleActive(a)} className="p-1.5 rounded text-slate-400 hover:bg-slate-700/60" title={a.is_active ? "Deactivate" : "Reactivate"}>
                            {a.is_active ? <ShieldOff className="h-3.5 w-3.5" /> : <Shield className="h-3.5 w-3.5" />}
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        )}
      </div>

      {showCreate && <AdminFormModal title="Create Admin" onClose={() => setShowCreate(false)} onSubmit={(f) => onCreate(f)} />}
      {editing && (
        <AdminFormModal
          title="Edit Admin"
          initial={{
            full_name: editing.full_name, email: editing.email, role: editing.role as AdminRole, permissions: editing.permissions,
            can_directly_adjust_wallet: (editing as any).can_directly_adjust_wallet ?? true,
            max_wallet_adjustment: (editing as any).max_wallet_adjustment != null ? String((editing as any).max_wallet_adjustment) : "",
          }}
          onClose={() => setEditing(null)}
          onSubmit={(f) => onEdit(editing.id, {
            full_name: f.full_name, role: f.role, permissions: f.permissions,
            can_directly_adjust_wallet: f.can_directly_adjust_wallet,
            max_wallet_adjustment: f.max_wallet_adjustment,
          })}
          editMode
        />
      )}
      {credentialModal && (
        <div className="fixed inset-0 z-50 bg-black/70 flex items-center justify-center p-4">
          <div className="w-full max-w-md rounded-xl bg-slate-900 border border-slate-700 p-6 text-slate-100">
            <h3 className="text-lg font-semibold mb-2">Credentials saved</h3>
            <p className="text-sm text-slate-400 mb-4">Share these credentials with the admin. You can change the password anytime from the Reset action.</p>
            <div className="space-y-2 text-sm">
              <div><span className="text-slate-400">Email:</span> <span className="font-mono">{credentialModal.email}</span></div>
              <div><span className="text-slate-400">Password:</span> <span className="font-mono bg-slate-950 px-2 py-1 rounded">{credentialModal.password}</span></div>
            </div>
            <button onClick={() => setCredentialModal(null)} className="mt-5 w-full h-10 rounded-md bg-indigo-600 hover:bg-indigo-500 text-white text-sm font-medium">Done</button>
          </div>
        </div>
      )}

      {resetTarget && (
        <ResetPasswordModal
          target={resetTarget}
          onClose={() => setResetTarget(null)}
          onSubmit={submitReset}
        />
      )}
    </div>
  );
}

function AdminFormModal({
  title, initial, onClose, onSubmit, editMode,
}: {
  title: string;
  initial?: { full_name: string; email: string; role: AdminRole; permissions: string[]; can_directly_adjust_wallet?: boolean; max_wallet_adjustment?: string };
  onClose: () => void;
  onSubmit: (form: { full_name: string; email: string; role: AdminRole; permissions: string[]; can_directly_adjust_wallet: boolean; max_wallet_adjustment: string; password: string }) => void;
  editMode?: boolean;
}) {
  const [full_name, setFullName] = useState(initial?.full_name || "");
  const [email, setEmail] = useState(initial?.email || "");
  const [role, setRole] = useState<AdminRole>(initial?.role || "admin");
  const [perms, setPerms] = useState<string[]>(initial?.permissions || []);
  const [canDirectAdjust, setCanDirectAdjust] = useState<boolean>(initial?.can_directly_adjust_wallet ?? true);
  const [maxAdjust, setMaxAdjust] = useState<string>(initial?.max_wallet_adjustment ?? "");
  const [password, setPassword] = useState("");
  const [showPw, setShowPw] = useState(false);

  const togglePerm = (k: string) => setPerms((cur) => cur.includes(k) ? cur.filter(x => x !== k) : [...cur, k]);

  const assignable = ADMIN_PERMISSIONS.filter((p) => !p.master_only);
  const hasWalletPerm = perms.includes("manage_wallet");

  return (
    <div className="fixed inset-0 z-50 bg-black/70 flex items-center justify-center p-4 overflow-y-auto">
      <div className="w-full max-w-2xl rounded-xl bg-slate-900 border border-slate-700 p-6 text-slate-100 my-8">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-semibold">{title}</h3>
          <button onClick={onClose} className="text-slate-400 hover:text-slate-100"><X className="h-5 w-5" /></button>
        </div>

        <form
          onSubmit={(e) => { e.preventDefault(); onSubmit({ full_name, email, role, permissions: perms, can_directly_adjust_wallet: canDirectAdjust, max_wallet_adjustment: maxAdjust, password }); }}
          className="space-y-4"
        >
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <Field label="Full name">
              <input value={full_name} onChange={(e) => setFullName(e.target.value)} required className="w-full h-10 rounded-md bg-slate-950 border border-slate-700 px-3 text-sm" />
            </Field>
            <Field label="Email">
              <input type="email" value={email} onChange={(e) => setEmail(e.target.value)} required disabled={editMode} className="w-full h-10 rounded-md bg-slate-950 border border-slate-700 px-3 text-sm disabled:opacity-60" />
            </Field>
          </div>

          {!editMode && (
            <Field label="Password (set any password — at least 8 characters)">
              <div className="flex gap-2">
                <div className="relative flex-1">
                  <input
                    type={showPw ? "text" : "password"}
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    required
                    minLength={8}
                    placeholder="e.g. admin123, MySecret!2026"
                    className="w-full h-10 rounded-md bg-slate-950 border border-slate-700 px-3 pr-10 text-sm font-mono"
                  />
                  <button type="button" onClick={() => setShowPw((v) => !v)}
                    className="absolute right-2 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-200" title={showPw ? "Hide" : "Show"}>
                    {showPw ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                  </button>
                </div>
                <button type="button" onClick={() => { setPassword(generatePassword()); setShowPw(true); }}
                  className="h-10 px-3 rounded-md bg-slate-800 hover:bg-slate-700 text-xs text-slate-200 inline-flex items-center gap-1" title="Generate a random password">
                  <RefreshCw className="h-3.5 w-3.5" /> Generate
                </button>
              </div>
            </Field>
          )}

          <Field label="Role">
            <select value={role} onChange={(e) => setRole(e.target.value as AdminRole)} className="w-full h-10 rounded-md bg-slate-950 border border-slate-700 px-3 text-sm">
              {ROLE_OPTIONS.map((r) => <option key={r.value} value={r.value}>{r.label}</option>)}
            </select>
          </Field>

          <div>
            <div className="text-xs uppercase tracking-wider text-slate-400 mb-2">Permissions</div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              {assignable.map((p) => {
                const checked = perms.includes(p.key);
                return (
                  <label key={p.key} className={`flex items-start gap-2 rounded-md border px-3 py-2 cursor-pointer text-sm ${checked ? "border-indigo-500 bg-indigo-500/10" : "border-slate-700 bg-slate-950/50 hover:bg-slate-800/50"}`}>
                    <input type="checkbox" checked={checked} onChange={() => togglePerm(p.key)} className="mt-1" />
                    <div>
                      <div className="font-medium">{p.label}</div>
                      <div className="text-xs text-slate-400">{p.description}</div>
                    </div>
                  </label>
                );
              })}
            </div>
          </div>

          {hasWalletPerm && (
            <div className="rounded-md border border-amber-500/30 bg-amber-500/5 p-3 space-y-3">
              <div className="text-xs uppercase tracking-wider text-amber-300">Wallet adjustment controls</div>
              <label className="flex items-center gap-2 text-sm cursor-pointer">
                <input type="checkbox" checked={canDirectAdjust} onChange={(e) => setCanDirectAdjust(e.target.checked)} />
                <div>
                  <div className="font-medium">Can directly adjust wallet</div>
                  <div className="text-xs text-slate-400">If off, this admin can only submit wallet adjustment requests for finance review.</div>
                </div>
              </label>
              <Field label="Maximum adjustment per transaction (₹) — leave blank for no limit">
                <input type="number" min={0} value={maxAdjust} onChange={(e) => setMaxAdjust(e.target.value)} placeholder="No limit"
                  className="w-full h-10 rounded-md bg-slate-950 border border-slate-700 px-3 text-sm" />
              </Field>
            </div>
          )}

          <div className="flex justify-end gap-2 pt-2">
            <button type="button" onClick={onClose} className="h-10 px-4 rounded-md text-sm text-slate-300 hover:bg-slate-800">Cancel</button>
            <button type="submit" className="h-10 px-4 rounded-md bg-indigo-600 hover:bg-indigo-500 text-white text-sm font-medium">{editMode ? "Save Changes" : "Create Admin"}</button>
          </div>
        </form>
      </div>
    </div>
  );
}

function ResetPasswordModal({ target, onClose, onSubmit }: {
  target: AdminUser; onClose: () => void; onSubmit: (pw: string) => void;
}) {
  const [pw, setPw] = useState("");
  const [show, setShow] = useState(false);
  return (
    <div className="fixed inset-0 z-50 bg-black/70 flex items-center justify-center p-4">
      <div className="w-full max-w-md rounded-xl bg-slate-900 border border-slate-700 p-6 text-slate-100">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-semibold">Reset password</h3>
          <button onClick={onClose} className="text-slate-400 hover:text-slate-100"><X className="h-5 w-5" /></button>
        </div>
        <p className="text-sm text-slate-400 mb-3">Set a new password for <span className="font-mono text-slate-200">{target.email}</span>. You can use any password (admin123, MySecret!2026, etc.).</p>
        <form onSubmit={(e) => { e.preventDefault(); onSubmit(pw); }} className="space-y-3">
          <div className="flex gap-2">
            <div className="relative flex-1">
              <input
                type={show ? "text" : "password"}
                value={pw} onChange={(e) => setPw(e.target.value)}
                required minLength={8}
                placeholder="At least 8 characters"
                className="w-full h-10 rounded-md bg-slate-950 border border-slate-700 px-3 pr-10 text-sm font-mono"
              />
              <button type="button" onClick={() => setShow((v) => !v)} className="absolute right-2 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-200">
                {show ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
              </button>
            </div>
            <button type="button" onClick={() => { setPw(generatePassword()); setShow(true); }}
              className="h-10 px-3 rounded-md bg-slate-800 hover:bg-slate-700 text-xs text-slate-200 inline-flex items-center gap-1">
              <RefreshCw className="h-3.5 w-3.5" /> Generate
            </button>
          </div>
          <div className="flex justify-end gap-2 pt-2">
            <button type="button" onClick={onClose} className="h-10 px-4 rounded-md text-sm text-slate-300 hover:bg-slate-800">Cancel</button>
            <button type="submit" className="h-10 px-4 rounded-md bg-indigo-600 hover:bg-indigo-500 text-white text-sm font-medium">Update Password</button>
          </div>
        </form>
      </div>
    </div>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div>
      <div className="text-xs uppercase tracking-wider text-slate-400 mb-1">{label}</div>
      {children}
    </div>
  );
}
