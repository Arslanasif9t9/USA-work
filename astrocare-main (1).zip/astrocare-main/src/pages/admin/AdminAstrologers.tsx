import { useEffect, useMemo, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { Loader2, Search, Eye, Check, X, Shield, ShieldOff, Pencil, Wallet as WalletIcon, Bell, Star } from "lucide-react";
import { AdminPageHeader, AdminCard, AdminTabs, StatusBadge, AdminInput, AdminButton, AdminModal, AdminTextarea, EmptyState, fmtINR, fmtDate } from "@/admin/ui";
import { callAdminAction } from "@/admin/api";
import { useAdminAuth } from "@/admin/AdminAuthContext";
import { adminHasPermission } from "@/admin/permissions";

type ApprovalStatus = "all" | "pending" | "approved" | "rejected" | "blocked";

interface Astrologer {
  id: string;
  user_id: string | null;
  display_name: string;
  avatar_url: string | null;
  bio: string | null;
  base_rate_per_min: number;
  chat_rate_per_min: number;
  rating_avg: number;
  rating_count: number;
  approval_status: string;
  is_online: boolean;
  total_consultations: number;
  specializations: string[];
  languages: string[];
  experience_years: number;
  focus_area: string | null;
  education: string | null;
  rejection_reason: string | null;
  created_at: string;
}

export default function AdminAstrologers() {
  const { admin } = useAdminAuth();
  const { toast } = useToast();
  const [tab, setTab] = useState<ApprovalStatus>("all");
  const [search, setSearch] = useState("");
  const [list, setList] = useState<Astrologer[]>([]);
  const [loading, setLoading] = useState(true);
  const [active, setActive] = useState<Astrologer | null>(null);
  const [modal, setModal] = useState<null | "view" | "edit" | "reject" | "block" | "wallet" | "notify" | "earnings" | "sessions">(null);
  const [reason, setReason] = useState("");

  const refresh = async () => {
    setLoading(true);
    const { data } = await supabase.from("astrologers").select("*").order("created_at", { ascending: false });
    setList((data || []) as Astrologer[]);
    setLoading(false);
  };
  useEffect(() => { refresh(); }, []);

  const filtered = useMemo(() => {
    return list.filter((a) => {
      if (tab !== "all" && a.approval_status !== tab) return false;
      if (search && !`${a.display_name}`.toLowerCase().includes(search.toLowerCase())) return false;
      return true;
    });
  }, [list, tab, search]);

  const counts = useMemo(() => ({
    all: list.length,
    pending: list.filter(a => a.approval_status === "pending").length,
    approved: list.filter(a => a.approval_status === "approved").length,
    rejected: list.filter(a => a.approval_status === "rejected").length,
    blocked: list.filter(a => a.approval_status === "blocked").length,
  }), [list]);

  const setStatus = async (a: Astrologer, status: string, why?: string) => {
    const r = await callAdminAction("astrologer.set_status", { astrologer_id: a.id, status, reason: why });
    if (!r.ok) return toast({ title: "Failed", description: r.error, variant: "destructive" });
    toast({ title: `Astrologer ${status}` });
    setModal(null); setReason(""); refresh();
  };

  return (
    <div>
      <AdminPageHeader title="Astrologers" description="Approve, reject, block and manage astrologer profiles." />

      <div className="flex flex-wrap items-center justify-between gap-3 mb-4">
        <AdminTabs<ApprovalStatus>
          tabs={[
            { value: "all",      label: "All",      count: counts.all },
            { value: "pending",  label: "Pending",  count: counts.pending },
            { value: "approved", label: "Approved", count: counts.approved },
            { value: "rejected", label: "Rejected", count: counts.rejected },
            { value: "blocked",  label: "Blocked",  count: counts.blocked },
          ]}
          value={tab} onChange={setTab}
        />
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-500" />
          <AdminInput placeholder="Search by name…" value={search} onChange={(e) => setSearch(e.target.value)} className="pl-9 w-64" />
        </div>
      </div>

      <AdminCard className="overflow-hidden">
        {loading ? (
          <div className="p-10 flex items-center justify-center text-slate-400"><Loader2 className="h-5 w-5 animate-spin" /></div>
        ) : filtered.length === 0 ? (
          <EmptyState message="No astrologers match these filters." />
        ) : (
          <div className="overflow-x-auto admin-table-scroll">
            <table className="admin-table w-full text-sm">
              <thead className="bg-slate-900/80 text-xs uppercase text-slate-400">
                <tr>
                  <th className="text-left px-4 py-3 font-medium">Astrologer</th>
                  <th className="text-left px-4 py-3 font-medium">Specialties</th>
                  <th className="text-left px-4 py-3 font-medium">Rate</th>
                  <th className="text-left px-4 py-3 font-medium">Rating</th>
                  <th className="text-left px-4 py-3 font-medium">Status</th>
                  <th className="text-left px-4 py-3 font-medium">Online</th>
                  <th className="text-left px-4 py-3 font-medium">Sessions</th>
                  <th className="text-left px-4 py-3 font-medium">Joined</th>
                  <th className="text-right px-4 py-3 font-medium admin-cell-action">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800">
                {filtered.map((a) => (
                  <tr key={a.id} className="hover:bg-slate-800/40">
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-3">
                        <div className="h-9 w-9 rounded-full overflow-hidden bg-slate-700 flex items-center justify-center text-xs">
                          {a.avatar_url ? <img src={a.avatar_url} alt="" className="h-full w-full object-cover" /> : a.display_name.slice(0,2).toUpperCase()}
                        </div>
                        <div>
                          <div className="font-medium text-slate-100">{a.display_name}</div>
                          <div className="text-xs text-slate-500">{a.experience_years}+ yrs exp</div>
                        </div>
                      </div>
                    </td>
                    <td className="px-4 py-3 text-slate-300 max-w-[200px] truncate">{(a.specializations || []).slice(0,3).join(", ") || "—"}</td>
                    <td className="px-4 py-3 text-slate-300 whitespace-nowrap">{fmtINR(a.base_rate_per_min)}/min</td>
                    <td className="px-4 py-3 text-slate-300 whitespace-nowrap">
                      <span className="inline-flex items-center gap-1"><Star className="h-3 w-3 text-amber-400 fill-amber-400" />{Number(a.rating_avg || 0).toFixed(1)} <span className="text-slate-500 text-xs">({a.rating_count})</span></span>
                    </td>
                    <td className="px-4 py-3"><StatusBadge status={a.approval_status} /></td>
                    <td className="px-4 py-3">
                      <span className={`inline-flex h-2 w-2 rounded-full ${a.is_online ? "bg-emerald-400" : "bg-slate-600"}`} />
                    </td>
                    <td className="px-4 py-3 text-slate-300">{a.total_consultations}</td>
                    <td className="px-4 py-3 text-slate-400 text-xs whitespace-nowrap">{fmtDate(a.created_at).split(",")[0]}</td>
                    <td className="px-4 py-3 admin-cell-action">
                      <div className="flex items-center justify-end gap-1 whitespace-nowrap">
                        <button onClick={() => { setActive(a); setModal("view"); }} className="p-1.5 rounded text-slate-400 hover:bg-slate-700/60" title="View"><Eye className="h-3.5 w-3.5" /></button>
                        <button onClick={() => { setActive(a); setModal("edit"); }} className="p-1.5 rounded text-slate-400 hover:bg-slate-700/60" title="Edit"><Pencil className="h-3.5 w-3.5" /></button>
                        <button onClick={() => { setActive(a); setModal("notify"); }} className="p-1.5 rounded text-slate-400 hover:bg-slate-700/60" title="Notify"><Bell className="h-3.5 w-3.5" /></button>
                        {adminHasPermission(admin, "manage_wallet") && (
                          <button onClick={() => { setActive(a); setModal("wallet"); }} className="p-1.5 rounded text-slate-400 hover:bg-slate-700/60" title="Adjust wallet"><WalletIcon className="h-3.5 w-3.5" /></button>
                        )}
                        {a.approval_status !== "approved" && a.approval_status !== "blocked" && (
                          <AdminButton variant="primary" onClick={() => setStatus(a, "approved")}><Check className="h-3 w-3" /> Approve</AdminButton>
                        )}
                        {a.approval_status !== "rejected" && a.approval_status !== "blocked" && (
                          <AdminButton variant="secondary" onClick={() => { setActive(a); setModal("reject"); }}><X className="h-3 w-3" /> Reject</AdminButton>
                        )}
                        {a.approval_status !== "blocked"
                          ? <AdminButton variant="danger" onClick={() => { setActive(a); setModal("block"); }}><ShieldOff className="h-3 w-3" /> Block</AdminButton>
                          : <AdminButton variant="primary" onClick={() => setStatus(a, "approved")}><Shield className="h-3 w-3" /> Unblock</AdminButton>}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </AdminCard>

      {/* VIEW */}
      {active && <AdminModal open={modal === "view"} onClose={() => setModal(null)} title={active.display_name} maxWidth="max-w-3xl">
        <div className="space-y-4 text-sm">
          <div className="flex items-center gap-4">
            <div className="h-16 w-16 rounded-full overflow-hidden bg-slate-800">
              {active.avatar_url ? <img src={active.avatar_url} className="h-full w-full object-cover" /> : null}
            </div>
            <div>
              <div className="text-lg font-semibold">{active.display_name}</div>
              <div className="text-slate-400">{active.experience_years}+ years • {fmtINR(active.base_rate_per_min)}/min</div>
              <div className="mt-1"><StatusBadge status={active.approval_status} /></div>
            </div>
          </div>
          <Field label="Bio">{active.bio || "—"}</Field>
          <div className="grid grid-cols-2 gap-3">
            <Field label="Specializations">{(active.specializations || []).join(", ") || "—"}</Field>
            <Field label="Languages">{(active.languages || []).join(", ") || "—"}</Field>
            <Field label="Focus">{active.focus_area || "—"}</Field>
            <Field label="Education">{active.education || "—"}</Field>
            <Field label="Total sessions">{active.total_consultations}</Field>
            <Field label="Rating">{Number(active.rating_avg).toFixed(2)} ({active.rating_count})</Field>
          </div>
          {active.rejection_reason && <Field label="Rejection / block reason">{active.rejection_reason}</Field>}
          <div className="flex gap-2 pt-2 border-t border-slate-800">
            <AdminButton variant="secondary" onClick={() => setModal("earnings")}>View earnings</AdminButton>
            <AdminButton variant="secondary" onClick={() => setModal("sessions")}>View sessions</AdminButton>
          </div>
        </div>
      </AdminModal>}

      {/* EDIT */}
      {active && modal === "edit" && <EditAstrologer a={active} onClose={() => setModal(null)} onSaved={refresh} />}

      {/* REJECT */}
      {active && <AdminModal open={modal === "reject"} onClose={() => setModal(null)} title={`Reject ${active.display_name}`}>
        <p className="text-sm text-slate-400 mb-3">This reason will be shown to the astrologer.</p>
        <AdminTextarea rows={4} value={reason} onChange={(e) => setReason(e.target.value)} placeholder="Why are you rejecting this profile?" />
        <div className="flex justify-end gap-2 mt-4">
          <AdminButton variant="ghost" onClick={() => setModal(null)}>Cancel</AdminButton>
          <AdminButton variant="danger" onClick={() => setStatus(active, "rejected", reason)}>Reject</AdminButton>
        </div>
      </AdminModal>}

      {/* BLOCK */}
      {active && <AdminModal open={modal === "block"} onClose={() => setModal(null)} title={`Block ${active.display_name}`}>
        <p className="text-sm text-slate-400 mb-3">Astrologer cannot log in or receive sessions while blocked.</p>
        <AdminTextarea rows={3} value={reason} onChange={(e) => setReason(e.target.value)} placeholder="Reason (shown to astrologer)" />
        <div className="flex justify-end gap-2 mt-4">
          <AdminButton variant="ghost" onClick={() => setModal(null)}>Cancel</AdminButton>
          <AdminButton variant="danger" onClick={() => setStatus(active, "blocked", reason)}>Block</AdminButton>
        </div>
      </AdminModal>}

      {/* WALLET */}
      {active?.user_id && <WalletAdjustModal open={modal === "wallet"} onClose={() => setModal(null)} userId={active.user_id} title={active.display_name} userType="astrologer" />}

      {/* NOTIFY */}
      {active?.user_id && <NotifyModal open={modal === "notify"} onClose={() => setModal(null)} userId={active.user_id} who={active.display_name} />}

      {/* EARNINGS / SESSIONS */}
      {active && modal === "earnings" && <SessionListModal title={`Earnings — ${active.display_name}`} onClose={() => setModal("view")} astrologerId={active.id} mode="earnings" />}
      {active && modal === "sessions" && <SessionListModal title={`Sessions — ${active.display_name}`} onClose={() => setModal("view")} astrologerId={active.id} mode="sessions" />}
    </div>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return <div><div className="text-[11px] uppercase text-slate-500 mb-0.5">{label}</div><div className="text-slate-200">{children}</div></div>;
}

function EditAstrologer({ a, onClose, onSaved }: { a: Astrologer; onClose: () => void; onSaved: () => void }) {
  const { toast } = useToast();
  const [form, setForm] = useState({
    display_name: a.display_name,
    bio: a.bio || "",
    base_rate_per_min: a.base_rate_per_min,
    chat_rate_per_min: a.chat_rate_per_min,
    specializations: (a.specializations || []).join(", "),
    languages: (a.languages || []).join(", "),
    avatar_url: a.avatar_url || "",
    experience_years: a.experience_years,
    focus_area: a.focus_area || "",
    education: a.education || "",
  });
  const [saving, setSaving] = useState(false);

  const save = async () => {
    setSaving(true);
    const r = await callAdminAction("astrologer.update_profile", {
      astrologer_id: a.id,
      patch: {
        ...form,
        base_rate_per_min: Number(form.base_rate_per_min),
        chat_rate_per_min: Number(form.chat_rate_per_min),
        experience_years: Number(form.experience_years),
        specializations: form.specializations.split(",").map(s => s.trim()).filter(Boolean),
        languages: form.languages.split(",").map(s => s.trim()).filter(Boolean),
      },
    });
    setSaving(false);
    if (!r.ok) return toast({ title: "Failed", description: r.error, variant: "destructive" });
    toast({ title: "Profile updated" });
    onSaved(); onClose();
  };

  return (
    <AdminModal open onClose={onClose} title={`Edit ${a.display_name}`}>
      <div className="grid grid-cols-2 gap-3 text-sm">
        <FormRow label="Display name"><AdminInput value={form.display_name} onChange={(e) => setForm({ ...form, display_name: e.target.value })} /></FormRow>
        <FormRow label="Avatar URL"><AdminInput value={form.avatar_url} onChange={(e) => setForm({ ...form, avatar_url: e.target.value })} /></FormRow>
        <FormRow label="Call rate (₹/min)"><AdminInput type="number" value={form.base_rate_per_min} onChange={(e) => setForm({ ...form, base_rate_per_min: Number(e.target.value) })} /></FormRow>
        <FormRow label="Chat rate (₹/min)"><AdminInput type="number" value={form.chat_rate_per_min} onChange={(e) => setForm({ ...form, chat_rate_per_min: Number(e.target.value) })} /></FormRow>
        <FormRow label="Experience (yrs)"><AdminInput type="number" value={form.experience_years} onChange={(e) => setForm({ ...form, experience_years: Number(e.target.value) })} /></FormRow>
        <FormRow label="Focus area"><AdminInput value={form.focus_area} onChange={(e) => setForm({ ...form, focus_area: e.target.value })} /></FormRow>
        <FormRow label="Specializations (comma-sep)" full><AdminInput value={form.specializations} onChange={(e) => setForm({ ...form, specializations: e.target.value })} /></FormRow>
        <FormRow label="Languages (comma-sep)" full><AdminInput value={form.languages} onChange={(e) => setForm({ ...form, languages: e.target.value })} /></FormRow>
        <FormRow label="Education" full><AdminInput value={form.education} onChange={(e) => setForm({ ...form, education: e.target.value })} /></FormRow>
        <FormRow label="Bio" full><AdminTextarea rows={4} value={form.bio} onChange={(e) => setForm({ ...form, bio: e.target.value })} /></FormRow>
      </div>
      <div className="flex justify-end gap-2 mt-4">
        <AdminButton variant="ghost" onClick={onClose}>Cancel</AdminButton>
        <AdminButton variant="primary" onClick={save} disabled={saving}>{saving && <Loader2 className="h-3 w-3 animate-spin" />} Save</AdminButton>
      </div>
    </AdminModal>
  );
}

function FormRow({ label, children, full }: { label: string; children: React.ReactNode; full?: boolean }) {
  return <div className={full ? "col-span-2" : ""}><div className="text-[11px] uppercase text-slate-500 mb-1">{label}</div>{children}</div>;
}

export function WalletAdjustModal({ open, onClose, userId, title, userType = "customer" }: { open: boolean; onClose: () => void; userId: string; title: string; userType?: "customer" | "astrologer" }) {
  const { admin } = useAdminAuth();
  const { toast } = useToast();
  const [direction, setDirection] = useState<"credit" | "debit">("credit");
  const [amount, setAmount] = useState("");
  const [reason, setReason] = useState("");
  const [busy, setBusy] = useState(false);

  // Master + finance can always adjust directly. Regular admins only if explicitly allowed.
  const canDirect =
    admin?.role === "master_admin" ||
    admin?.role === "finance_admin" ||
    (admin as any)?.can_directly_adjust_wallet === true;
  const maxLimit = (admin as any)?.max_wallet_adjustment ? Number((admin as any).max_wallet_adjustment) : null;
  const mustRequest = !canDirect;

  const submit = async () => {
    const amt = Number(amount);
    if (!amt || amt <= 0) return toast({ title: "Enter a valid amount", variant: "destructive" });
    if (maxLimit && amt > maxLimit) {
      return toast({ title: "Over limit", description: `Your max per transaction is ₹${maxLimit}`, variant: "destructive" });
    }
    setBusy(true);
    if (mustRequest) {
      // Sign amount: + for credit, − for debit
      const signed = direction === "credit" ? amt : -amt;
      const r = await callAdminAction("wallet_request.create", {
        target_user_id: userId, target_user_type: userType, amount: signed, reason,
      });
      setBusy(false);
      if (!r.ok) return toast({ title: "Failed", description: r.error, variant: "destructive" });
      toast({ title: "Request submitted", description: "A finance admin will review it." });
    } else {
      const { error } = await supabase.rpc("admin_adjust_wallet", {
        _user_id: userId, _amount: amt, _reason: reason, _direction: direction,
      });
      setBusy(false);
      if (error) return toast({ title: "Failed", description: error.message, variant: "destructive" });
      toast({ title: `Wallet ${direction === "credit" ? "credited" : "debited"}` });
    }
    setAmount(""); setReason(""); onClose();
  };

  return (
    <AdminModal open={open} onClose={onClose} title={`Adjust wallet — ${title}`} maxWidth="max-w-md">
      {mustRequest && (
        <div className="mb-3 p-3 rounded-md bg-amber-500/10 border border-amber-500/30 text-xs text-amber-200">
          You don't have direct adjustment rights. This will be sent to a Finance admin for approval.
        </div>
      )}
      {maxLimit && (
        <div className="mb-3 text-[11px] text-slate-400">Your per-transaction limit: <span className="text-slate-200 font-medium">₹{maxLimit}</span></div>
      )}
      <div className="space-y-3 text-sm">
        <div className="flex gap-2">
          <button onClick={() => setDirection("credit")} className={`flex-1 h-10 rounded-md text-sm font-medium ${direction === "credit" ? "bg-emerald-600 text-white" : "bg-slate-800 text-slate-300"}`}>Credit (+)</button>
          <button onClick={() => setDirection("debit")} className={`flex-1 h-10 rounded-md text-sm font-medium ${direction === "debit" ? "bg-rose-600 text-white" : "bg-slate-800 text-slate-300"}`}>Debit (−)</button>
        </div>
        <FormRow label="Amount (₹)"><AdminInput type="number" min="1" value={amount} onChange={(e) => setAmount(e.target.value)} /></FormRow>
        <FormRow label="Reason"><AdminTextarea rows={3} value={reason} onChange={(e) => setReason(e.target.value)} /></FormRow>
      </div>
      <div className="flex justify-end gap-2 mt-4">
        <AdminButton variant="ghost" onClick={onClose} disabled={busy}>Cancel</AdminButton>
        <AdminButton variant="primary" onClick={submit} disabled={busy}>
          {busy && <Loader2 className="h-3 w-3 animate-spin" />}
          {mustRequest ? "Submit request" : "Apply"}
        </AdminButton>
      </div>
    </AdminModal>
  );
}

export function NotifyModal({ open, onClose, userId, who }: { open: boolean; onClose: () => void; userId: string; who: string }) {
  const { toast } = useToast();
  const [title, setTitle] = useState("");
  const [body, setBody] = useState("");
  const send = async () => {
    if (!title) return toast({ title: "Title required", variant: "destructive" });
    const r = await callAdminAction("send_notification", { user_id: userId, title, body });
    if (!r.ok) return toast({ title: "Failed", description: r.error, variant: "destructive" });
    toast({ title: "Notification sent" });
    setTitle(""); setBody(""); onClose();
  };
  return (
    <AdminModal open={open} onClose={onClose} title={`Send notification — ${who}`} maxWidth="max-w-md">
      <div className="space-y-3">
        <FormRow label="Title"><AdminInput value={title} onChange={(e) => setTitle(e.target.value)} /></FormRow>
        <FormRow label="Message"><AdminTextarea rows={4} value={body} onChange={(e) => setBody(e.target.value)} /></FormRow>
      </div>
      <div className="flex justify-end gap-2 mt-4">
        <AdminButton variant="ghost" onClick={onClose}>Cancel</AdminButton>
        <AdminButton variant="primary" onClick={send}>Send</AdminButton>
      </div>
    </AdminModal>
  );
}

function SessionListModal({ title, onClose, astrologerId, mode }: { title: string; onClose: () => void; astrologerId: string; mode: "earnings" | "sessions" }) {
  const [rows, setRows] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  useEffect(() => {
    (async () => {
      const [{ data: chats }, { data: calls }] = await Promise.all([
        supabase.from("chat_sessions").select("id, status, duration_seconds, total_cost, astrologer_earning, accepted_at, ended_at").eq("astrologer_id", astrologerId).order("created_at", { ascending: false }).limit(100),
        supabase.from("call_sessions").select("id, status, duration_seconds, astrologer_earning, connected_at, ended_at, per_minute_rate").eq("astrologer_id", astrologerId).order("created_at", { ascending: false }).limit(100),
      ]);
      const merged = [
        ...(chats || []).map((c: any) => ({ ...c, kind: "chat", earning: c.astrologer_earning, when: c.ended_at || c.accepted_at })),
        ...(calls || []).map((c: any) => ({ ...c, kind: "call", earning: c.astrologer_earning, when: c.ended_at || c.connected_at })),
      ].sort((a, b) => new Date(b.when || 0).getTime() - new Date(a.when || 0).getTime());
      setRows(merged); setLoading(false);
    })();
  }, [astrologerId]);
  const total = rows.reduce((s, r) => s + Number(r.earning || 0), 0);
  return (
    <AdminModal open onClose={onClose} title={title}>
      {loading ? <div className="p-8 flex justify-center"><Loader2 className="h-5 w-5 animate-spin" /></div>
        : rows.length === 0 ? <EmptyState />
        : (
          <>
            {mode === "earnings" && <div className="mb-3 text-sm text-slate-400">Total earned: <span className="text-emerald-400 font-semibold">{fmtINR(total)}</span></div>}
            <div className="max-h-[60vh] overflow-y-auto rounded-md border border-slate-800">
              <table className="w-full text-sm">
                <thead className="bg-slate-900/80 text-xs text-slate-400">
                  <tr><th className="text-left px-3 py-2">Type</th><th className="text-left px-3 py-2">When</th><th className="text-left px-3 py-2">Status</th><th className="text-left px-3 py-2">Duration</th><th className="text-right px-3 py-2">Earning</th></tr>
                </thead>
                <tbody className="divide-y divide-slate-800">
                  {rows.map((r) => (
                    <tr key={r.kind + r.id}><td className="px-3 py-2 capitalize">{r.kind}</td><td className="px-3 py-2 text-xs text-slate-400">{fmtDate(r.when)}</td><td className="px-3 py-2"><StatusBadge status={r.status} /></td><td className="px-3 py-2">{Math.floor((r.duration_seconds || 0)/60)}m</td><td className="px-3 py-2 text-right text-emerald-400">{fmtINR(r.earning)}</td></tr>
                  ))}
                </tbody>
              </table>
            </div>
          </>
        )}
      <div className="flex justify-end mt-4"><AdminButton variant="ghost" onClick={onClose}>Close</AdminButton></div>
    </AdminModal>
  );
}
