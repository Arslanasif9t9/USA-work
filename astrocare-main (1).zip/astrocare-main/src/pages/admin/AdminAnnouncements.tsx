import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Megaphone, Send, Power } from "lucide-react";
import { toast } from "sonner";
import {
  AdminCard, AdminPageHeader, AdminInput, AdminTextarea, AdminSelect, AdminButton,
  AdminTabs, EmptyState, fmtDate,
} from "@/admin/ui";
import { callAdminAction } from "@/admin/api";

type Audience = "all" | "customers" | "astrologers" | "user";
type Display = "banner" | "notification";

export default function AdminAnnouncements() {
  const [tab, setTab] = useState<"compose" | "list">("compose");
  const [list, setList] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);

  // form state
  const [title, setTitle] = useState("");
  const [body, setBody] = useState("");
  const [audience, setAudience] = useState<Audience>("all");
  const [targetEmail, setTargetEmail] = useState("");
  const [displayType, setDisplayType] = useState<Display>("notification");
  const [scheduleNow, setScheduleNow] = useState(true);
  const [scheduledAt, setScheduledAt] = useState("");
  const [expiresAt, setExpiresAt] = useState("");

  async function loadList() {
    const { data } = await supabase.from("announcements")
      .select("*").order("created_at", { ascending: false }).limit(15);
    setList(data || []);
  }

  useEffect(() => { loadList(); }, []);

  async function submit() {
    if (!title.trim() || !body.trim()) { toast.error("Title and message are required"); return; }
    setLoading(true);
    const r = await callAdminAction("announcement_create", {
      title: title.trim(),
      body: body.trim(),
      audience,
      target_email: audience === "user" ? targetEmail.trim() : null,
      display_type: displayType,
      scheduled_at: scheduleNow ? null : scheduledAt,
      expires_at: expiresAt || null,
    });
    setLoading(false);
    if (r.ok) {
      toast.success("Announcement created");
      setTitle(""); setBody(""); setTargetEmail(""); setExpiresAt(""); setScheduledAt("");
      loadList(); setTab("list");
    } else toast.error(r.error || "Failed");
  }

  async function toggleActive(id: string, isActive: boolean) {
    const r = await callAdminAction("announcement_set_active", { id, is_active: !isActive });
    if (r.ok) { toast.success("Updated"); loadList(); } else toast.error(r.error || "Failed");
  }

  return (
    <div className="space-y-6">
      <AdminPageHeader
        title="Announcements"
        description="Send banners or notifications to customers, astrologers, or specific users."
      />
      <AdminTabs
        tabs={[{ value: "compose", label: "Compose" }, { value: "list", label: `All (${list.length})` }]}
        value={tab} onChange={setTab}
      />

      {tab === "compose" && (
        <AdminCard className="p-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="md:col-span-2">
              <label className="text-xs text-slate-400 uppercase tracking-wider">Title</label>
              <AdminInput value={title} onChange={(e) => setTitle(e.target.value)} placeholder="System maintenance, weekend offers, etc." />
            </div>
            <div className="md:col-span-2">
              <label className="text-xs text-slate-400 uppercase tracking-wider">Message body</label>
              <AdminTextarea rows={4} value={body} onChange={(e) => setBody(e.target.value)} placeholder="Write the announcement message..." />
            </div>

            <div>
              <label className="text-xs text-slate-400 uppercase tracking-wider">Audience</label>
              <AdminSelect value={audience} onChange={(e) => setAudience(e.target.value as Audience)}>
                <option value="all">All users</option>
                <option value="customers">All customers</option>
                <option value="astrologers">All astrologers</option>
                <option value="user">Specific user (email)</option>
              </AdminSelect>
            </div>
            <div>
              <label className="text-xs text-slate-400 uppercase tracking-wider">Display type</label>
              <AdminSelect value={displayType} onChange={(e) => setDisplayType(e.target.value as Display)}>
                <option value="notification">In-app notification</option>
                <option value="banner">Top banner</option>
              </AdminSelect>
            </div>

            {audience === "user" && (
              <div className="md:col-span-2">
                <label className="text-xs text-slate-400 uppercase tracking-wider">Target user email</label>
                <AdminInput type="email" value={targetEmail} onChange={(e) => setTargetEmail(e.target.value)} placeholder="user@example.com" />
              </div>
            )}

            <div className="md:col-span-2 flex items-center gap-2">
              <input id="now" type="checkbox" checked={scheduleNow} onChange={(e) => setScheduleNow(e.target.checked)} className="h-4 w-4 accent-indigo-500" />
              <label htmlFor="now" className="text-sm text-slate-300">Send now</label>
            </div>
            {!scheduleNow && (
              <div>
                <label className="text-xs text-slate-400 uppercase tracking-wider">Scheduled at</label>
                <AdminInput type="datetime-local" value={scheduledAt} onChange={(e) => setScheduledAt(e.target.value)} />
              </div>
            )}
            <div>
              <label className="text-xs text-slate-400 uppercase tracking-wider">Expires at (optional, banners only)</label>
              <AdminInput type="datetime-local" value={expiresAt} onChange={(e) => setExpiresAt(e.target.value)} />
            </div>
          </div>

          <div className="mt-5 flex items-center justify-end gap-2">
            <AdminButton onClick={submit} disabled={loading}>
              <Send className="h-3.5 w-3.5" /> {loading ? "Sending..." : "Create announcement"}
            </AdminButton>
          </div>
        </AdminCard>
      )}

      {tab === "list" && (
        <AdminCard>
          {list.length === 0 ? <EmptyState message="No announcements yet." /> : (
            <ul className="divide-y divide-slate-800">
              {list.map((a) => (
                <li key={a.id} className="p-5 flex items-start justify-between gap-4">
                  <div className="flex items-start gap-3 min-w-0 flex-1">
                    <div className="h-10 w-10 rounded-lg bg-indigo-600/20 text-indigo-300 flex items-center justify-center shrink-0">
                      <Megaphone className="h-5 w-5" />
                    </div>
                    <div className="min-w-0">
                      <div className="text-sm font-semibold">{a.title}</div>
                      <div className="text-xs text-slate-400 mt-0.5">{a.body}</div>
                      <div className="text-[11px] text-slate-500 mt-1.5 flex flex-wrap gap-2">
                        <span>Audience: {a.audience}</span>
                        <span>·</span>
                        <span>Type: {a.display_type}</span>
                        <span>·</span>
                        <span>Scheduled: {fmtDate(a.scheduled_at)}</span>
                        {a.expires_at && <><span>·</span><span>Expires: {fmtDate(a.expires_at)}</span></>}
                      </div>
                    </div>
                  </div>
                  <div className="flex items-center gap-2 shrink-0">
                    <span className={`text-[11px] px-2 py-0.5 rounded ${a.is_active ? "bg-emerald-500/15 text-emerald-300" : "bg-slate-700/40 text-slate-400"}`}>
                      {a.is_active ? "Active" : "Disabled"}
                    </span>
                    <AdminButton variant="secondary" onClick={() => toggleActive(a.id, a.is_active)}>
                      <Power className="h-3.5 w-3.5" /> {a.is_active ? "Disable" : "Enable"}
                    </AdminButton>
                  </div>
                </li>
              ))}
            </ul>
          )}
        </AdminCard>
      )}
    </div>
  );
}
