import { FormEvent, useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { Loader2, ShieldCheck } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";

/**
 * Handles the Supabase password recovery redirect for admins.
 * When `resetPasswordForEmail` is called from /astrocareadmin/login,
 * the user lands here with a recovery session set in the URL hash.
 */
export default function AdminResetPasswordPage() {
  const { toast } = useToast();
  const navigate = useNavigate();

  const [ready, setReady] = useState(false);
  const [recovery, setRecovery] = useState(false);
  const [password, setPassword] = useState("");
  const [confirm, setConfirm] = useState("");
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    // Supabase parses the recovery token from the URL hash automatically and
    // emits a PASSWORD_RECOVERY auth event. We just need a session to exist.
    const sub = supabase.auth.onAuthStateChange((event) => {
      if (event === "PASSWORD_RECOVERY") setRecovery(true);
    });
    supabase.auth.getSession().then(({ data }) => {
      if (data.session) setRecovery(true);
      setReady(true);
    });
    return () => sub.data.subscription.unsubscribe();
  }, []);

  const onSubmit = async (e: FormEvent) => {
    e.preventDefault();
    if (password.length < 8) {
      toast({ title: "Password too short", description: "Use at least 8 characters.", variant: "destructive" });
      return;
    }
    if (password !== confirm) {
      toast({ title: "Passwords do not match", variant: "destructive" });
      return;
    }
    setBusy(true);
    const { error } = await supabase.auth.updateUser({ password });
    setBusy(false);
    if (error) {
      toast({ title: "Could not update password", description: error.message, variant: "destructive" });
      return;
    }
    await supabase.auth.signOut();
    toast({ title: "Password updated", description: "Sign in with your new password." });
    navigate("/astrocareadmin/login", { replace: true });
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-slate-950 px-4 text-slate-100">
      <div className="w-full max-w-md">
        <div className="text-center mb-8">
          <div className="inline-flex h-14 w-14 items-center justify-center rounded-2xl bg-gradient-to-br from-indigo-500 to-violet-600 shadow-lg shadow-indigo-900/40 mb-4">
            <ShieldCheck className="h-7 w-7 text-white" />
          </div>
          <h1 className="text-2xl font-semibold tracking-tight">Set a new password</h1>
          <p className="text-sm text-slate-400 mt-1">Choose a strong password for your admin account.</p>
        </div>

        {!ready ? (
          <div className="text-center text-slate-400"><Loader2 className="h-5 w-5 animate-spin inline" /></div>
        ) : !recovery ? (
          <div className="rounded-xl border border-slate-800 bg-slate-900/70 p-6 text-sm text-slate-300 space-y-3">
            <p>This link is invalid or has expired.</p>
            <button
              onClick={() => navigate("/astrocareadmin/login", { replace: true })}
              className="w-full h-10 rounded-md bg-indigo-600 hover:bg-indigo-500 text-white text-sm font-medium"
            >
              Back to sign-in
            </button>
          </div>
        ) : (
          <form onSubmit={onSubmit} className="rounded-xl border border-slate-800 bg-slate-900/70 backdrop-blur p-6 shadow-xl space-y-4">
            <div className="space-y-1.5">
              <label className="text-xs uppercase tracking-wider text-slate-400">New password</label>
              <input
                type="password"
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full h-11 rounded-md bg-slate-950 border border-slate-700 px-3 text-sm text-slate-100 focus:outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500"
                autoComplete="new-password"
                minLength={8}
              />
            </div>
            <div className="space-y-1.5">
              <label className="text-xs uppercase tracking-wider text-slate-400">Confirm new password</label>
              <input
                type="password"
                required
                value={confirm}
                onChange={(e) => setConfirm(e.target.value)}
                className="w-full h-11 rounded-md bg-slate-950 border border-slate-700 px-3 text-sm text-slate-100 focus:outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500"
                autoComplete="new-password"
                minLength={8}
              />
            </div>
            <button
              type="submit"
              disabled={busy}
              className="w-full h-11 inline-flex items-center justify-center rounded-md bg-indigo-600 hover:bg-indigo-500 text-white font-medium text-sm shadow disabled:opacity-60"
            >
              {busy ? <Loader2 className="h-4 w-4 animate-spin" /> : "Update password"}
            </button>
          </form>
        )}
      </div>
    </div>
  );
}
