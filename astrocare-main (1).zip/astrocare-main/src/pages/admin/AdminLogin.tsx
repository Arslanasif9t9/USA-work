import { FormEvent, useState } from "react";
import { Navigate, useNavigate } from "react-router-dom";
import { Loader2, ShieldCheck, ArrowLeft } from "lucide-react";
import { useAdminAuth } from "@/admin/AdminAuthContext";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";

export default function AdminLoginPage() {
  const { admin, signIn, loading } = useAdminAuth();
  const { toast } = useToast();
  const navigate = useNavigate();

  const [mode, setMode] = useState<"signin" | "forgot">("signin");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [busy, setBusy] = useState(false);

  if (!loading && admin) {
    return <Navigate to="/astrocareadmin/dashboard" replace />;
  }

  const onSubmit = async (e: FormEvent) => {
    e.preventDefault();
    setBusy(true);
    const res = await signIn(email.trim(), password);
    setBusy(false);
    if (res.ok === false) {
      toast({ title: "Sign-in denied", description: res.error, variant: "destructive" });
      return;
    }
    toast({ title: "Welcome, admin" });
    navigate("/astrocareadmin/dashboard", { replace: true });
  };

  const onForgot = async (e: FormEvent) => {
    e.preventDefault();
    if (!email.trim()) {
      toast({ title: "Enter your admin email first", variant: "destructive" });
      return;
    }
    setBusy(true);
    const { error } = await supabase.auth.resetPasswordForEmail(email.trim(), {
      redirectTo: `${window.location.origin}/astrocareadmin/reset-password`,
    });
    setBusy(false);
    if (error) {
      toast({ title: "Could not send reset email", description: error.message, variant: "destructive" });
      return;
    }
    toast({
      title: "Reset link sent",
      description: `Check ${email.trim()} for a secure link to reset your password.`,
    });
    setMode("signin");
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-slate-950 px-4 text-slate-100">
      <div className="w-full max-w-md">
        <div className="text-center mb-8">
          <div className="inline-flex h-14 w-14 items-center justify-center rounded-2xl bg-gradient-to-br from-indigo-500 to-violet-600 shadow-lg shadow-indigo-900/40 mb-4">
            <ShieldCheck className="h-7 w-7 text-white" />
          </div>
          <h1 className="text-2xl font-semibold tracking-tight">AstroGuide Admin</h1>
          <p className="text-sm text-slate-400 mt-1">
            {mode === "signin"
              ? "Restricted area — administrator sign-in only"
              : "Reset your administrator password"}
          </p>
        </div>

        {mode === "signin" ? (
          <form
            onSubmit={onSubmit}
            className="rounded-xl border border-slate-800 bg-slate-900/70 backdrop-blur p-6 shadow-xl space-y-4"
          >
            <div className="space-y-1.5">
              <label className="text-xs uppercase tracking-wider text-slate-400" htmlFor="adm-email">Email</label>
              <input
                id="adm-email"
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full h-11 rounded-md bg-slate-950 border border-slate-700 px-3 text-sm text-slate-100 placeholder:text-slate-500 focus:outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500"
                placeholder="admin@astrocare.app"
                autoComplete="email"
              />
            </div>
            <div className="space-y-1.5">
              <div className="flex items-center justify-between">
                <label className="text-xs uppercase tracking-wider text-slate-400" htmlFor="adm-password">Password</label>
                <button
                  type="button"
                  onClick={() => setMode("forgot")}
                  className="text-[11px] text-indigo-300 hover:text-indigo-200"
                >
                  Forgot password?
                </button>
              </div>
              <input
                id="adm-password"
                type="password"
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full h-11 rounded-md bg-slate-950 border border-slate-700 px-3 text-sm text-slate-100 placeholder:text-slate-500 focus:outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500"
                autoComplete="current-password"
              />
            </div>
            <button
              type="submit"
              disabled={busy}
              className="w-full h-11 inline-flex items-center justify-center rounded-md bg-indigo-600 hover:bg-indigo-500 text-white font-medium text-sm shadow disabled:opacity-60"
            >
              {busy ? <Loader2 className="h-4 w-4 animate-spin" /> : "Sign in to Admin"}
            </button>
            <p className="text-center text-[11px] text-slate-500 pt-2">
              Unauthorized access is monitored and logged.
            </p>
          </form>
        ) : (
          <form
            onSubmit={onForgot}
            className="rounded-xl border border-slate-800 bg-slate-900/70 backdrop-blur p-6 shadow-xl space-y-4"
          >
            <div className="space-y-1.5">
              <label className="text-xs uppercase tracking-wider text-slate-400" htmlFor="adm-forgot-email">Admin email</label>
              <input
                id="adm-forgot-email"
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full h-11 rounded-md bg-slate-950 border border-slate-700 px-3 text-sm text-slate-100 placeholder:text-slate-500 focus:outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500"
                placeholder="astrolume22@gmail.com"
                autoComplete="email"
              />
              <p className="text-[11px] text-slate-500 pt-1">
                We'll email you a secure link to set a new password.
              </p>
            </div>
            <button
              type="submit"
              disabled={busy}
              className="w-full h-11 inline-flex items-center justify-center rounded-md bg-indigo-600 hover:bg-indigo-500 text-white font-medium text-sm shadow disabled:opacity-60"
            >
              {busy ? <Loader2 className="h-4 w-4 animate-spin" /> : "Send reset link"}
            </button>
            <button
              type="button"
              onClick={() => setMode("signin")}
              className="w-full inline-flex items-center justify-center gap-1.5 text-xs text-slate-400 hover:text-slate-200"
            >
              <ArrowLeft className="h-3.5 w-3.5" /> Back to sign-in
            </button>
          </form>
        )}
      </div>
    </div>
  );
}
