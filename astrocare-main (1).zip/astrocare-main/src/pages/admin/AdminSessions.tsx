import { useEffect, useMemo, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { Loader2, Search, Eye, RefreshCw } from "lucide-react";
import { AdminPageHeader, AdminCard, AdminTabs, StatusBadge, AdminInput, AdminButton, AdminModal, AdminTextarea, EmptyState, fmtINR, fmtDate, fmtDuration } from "@/admin/ui";

type SessionRow = {
  id: string; kind: "chat" | "call"; status: string;
  user_id: string; astrologer_id: string;
  duration_seconds: number; total_cost: number;
  astrologer_earning: number; company_earning: number;
  per_minute_rate: number;
  start: string | null; end: string | null;
  customer_name?: string; astrologer_name?: string;
};

export default function AdminSessions() {
  const { toast } = useToast();
  const [tab, setTab] = useState<"all" | "chat" | "call" | "active" | "ended" | "cancelled">("all");
  const [search, setSearch] = useState("");
  const [from, setFrom] = useState("");
  const [to, setTo] = useState("");
  const [rows, setRows] = useState<SessionRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [active, setActive] = useState<SessionRow | null>(null);
  const [showRefund, setShowRefund] = useState(false);

  const refresh = async () => {
    setLoading(true);
    const [{ data: chats }, { data: calls }] = await Promise.all([
      supabase.from("chat_sessions").select("*").order("created_at", { ascending: false }).limit(15),
      supabase.from("call_sessions").select("*").order("created_at", { ascending: false }).limit(15),
    ]);
    const userIds = new Set<string>();
    const astroIds = new Set<string>();
    (chats || []).forEach((c: any) => { userIds.add(c.user_id); astroIds.add(c.astrologer_id); });
    (calls || []).forEach((c: any) => { userIds.add(c.user_id); astroIds.add(c.astrologer_id); });

    const [{ data: profiles }, { data: astros }] = await Promise.all([
      userIds.size ? supabase.from("profiles").select("id, name, email").in("id", Array.from(userIds)) : Promise.resolve({ data: [] as any[] }),
      astroIds.size ? supabase.from("astrologers").select("id, display_name").in("id", Array.from(astroIds)) : Promise.resolve({ data: [] as any[] }),
    ]);
    const pn: Record<string, string> = {}; (profiles || []).forEach((p: any) => pn[p.id] = p.name || p.email || "—");
    const an: Record<string, string> = {}; (astros || []).forEach((a: any) => an[a.id] = a.display_name);

    const merged: SessionRow[] = [
      ...(chats || []).map((c: any): SessionRow => ({
        id: c.id, kind: "chat", status: c.status, user_id: c.user_id, astrologer_id: c.astrologer_id,
        duration_seconds: c.duration_seconds || 0, total_cost: Number(c.total_cost || 0),
        astrologer_earning: Number(c.astrologer_earning || 0), company_earning: Number(c.company_earning || 0),
        per_minute_rate: Number(c.per_minute_rate || 0),
        start: c.accepted_at || c.requested_at, end: c.ended_at,
        customer_name: pn[c.user_id], astrologer_name: an[c.astrologer_id],
      })),
      ...(calls || []).map((c: any): SessionRow => ({
        id: c.id, kind: "call", status: c.status, user_id: c.user_id, astrologer_id: c.astrologer_id,
        duration_seconds: c.duration_seconds || 0,
        total_cost: Math.max(1, Math.ceil((c.duration_seconds || 0)/60)) * Number(c.per_minute_rate || 0),
        astrologer_earning: Number(c.astrologer_earning || 0), company_earning: Number(c.company_earning || 0),
        per_minute_rate: Number(c.per_minute_rate || 0),
        start: c.connected_at || c.initiated_at, end: c.ended_at,
        customer_name: pn[c.user_id], astrologer_name: an[c.astrologer_id],
      })),
    ].sort((a, b) => new Date(b.start || 0).getTime() - new Date(a.start || 0).getTime());

    setRows(merged); setLoading(false);
  };
  useEffect(() => { refresh(); }, []);

  const filtered = useMemo(() => rows.filter((r) => {
    if (tab === "chat" && r.kind !== "chat") return false;
    if (tab === "call" && r.kind !== "call") return false;
    if (tab === "active" && r.status !== "active") return false;
    if (tab === "ended" && r.status !== "ended") return false;
    if (tab === "cancelled" && !["cancelled", "rejected"].includes(r.status)) return false;
    if (from && (!r.start || new Date(r.start) < new Date(from))) return false;
    if (to && (!r.start || new Date(r.start) > new Date(to + "T23:59:59"))) return false;
    if (search) {
      const s = search.toLowerCase();
      if (!`${r.customer_name || ""} ${r.astrologer_name || ""}`.toLowerCase().includes(s)) return false;
    }
    return true;
  }), [rows, tab, search, from, to]);

  return (
    <div>
      <AdminPageHeader title="Sessions" description="Inspect every chat and call across the platform." />

      <div className="flex flex-wrap items-end justify-between gap-3 mb-4">
        <AdminTabs value={tab} onChange={setTab} tabs={[
          { value: "all", label: "All" }, { value: "chat", label: "Chat" }, { value: "call", label: "Call" },
          { value: "active", label: "Active" }, { value: "ended", label: "Ended" }, { value: "cancelled", label: "Cancelled" },
        ]} />
        <div className="flex items-end gap-2">
          <div><div className="text-[10px] uppercase text-slate-500 mb-1">From</div><AdminInput type="date" value={from} onChange={(e) => setFrom(e.target.value)} className="w-36" /></div>
          <div><div className="text-[10px] uppercase text-slate-500 mb-1">To</div><AdminInput type="date" value={to} onChange={(e) => setTo(e.target.value)} className="w-36" /></div>
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-500" />
            <AdminInput placeholder="Search names…" value={search} onChange={(e) => setSearch(e.target.value)} className="pl-9 w-56" />
          </div>
        </div>
      </div>

      <AdminCard className="overflow-hidden">
        {loading ? <div className="p-10 flex justify-center"><Loader2 className="h-5 w-5 animate-spin text-slate-400" /></div>
        : filtered.length === 0 ? <EmptyState />
        : (
          <div className="overflow-x-auto admin-table-scroll">
            <table className="admin-table w-full text-sm">
              <thead className="bg-slate-900/80 text-xs uppercase text-slate-400">
                <tr>
                  <th className="text-left px-4 py-3 font-medium">ID</th>
                  <th className="text-left px-4 py-3 font-medium">Customer</th>
                  <th className="text-left px-4 py-3 font-medium">Astrologer</th>
                  <th className="text-left px-4 py-3 font-medium">Type</th>
                  <th className="text-left px-4 py-3 font-medium">Status</th>
                  <th className="text-left px-4 py-3 font-medium">Duration</th>
                  <th className="text-right px-4 py-3 font-medium">Total</th>
                  <th className="text-right px-4 py-3 font-medium">Earning</th>
                  <th className="text-right px-4 py-3 font-medium">Platform</th>
                  <th className="text-left px-4 py-3 font-medium">Start</th>
                  <th className="text-right px-4 py-3 font-medium admin-cell-action">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800">
                {filtered.map((r) => (
                  <tr key={r.kind + r.id} className="hover:bg-slate-800/40">
                    <td className="px-4 py-3 text-xs font-mono text-slate-500">{r.id.slice(0, 8)}</td>
                    <td className="px-4 py-3">{r.customer_name || "—"}</td>
                    <td className="px-4 py-3">{r.astrologer_name || "—"}</td>
                    <td className="px-4 py-3 capitalize">{r.kind}</td>
                    <td className="px-4 py-3"><StatusBadge status={r.status} /></td>
                    <td className="px-4 py-3 text-slate-300">{fmtDuration(r.duration_seconds)}</td>
                    <td className="px-4 py-3 text-right">{fmtINR(r.total_cost)}</td>
                    <td className="px-4 py-3 text-right text-emerald-400">{fmtINR(r.astrologer_earning)}</td>
                    <td className="px-4 py-3 text-right text-indigo-300">{fmtINR(r.company_earning)}</td>
                    <td className="px-4 py-3 text-xs text-slate-400">{fmtDate(r.start).split(",")[0]}</td>
                    <td className="px-4 py-3 text-right admin-cell-action">
                      <button onClick={() => setActive(r)} className="p-1.5 rounded text-slate-400 hover:bg-slate-700/60" title="View"><Eye className="h-3.5 w-3.5" /></button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </AdminCard>

      {active && <SessionDetail r={active} onClose={() => setActive(null)} onRefund={() => setShowRefund(true)} />}
      {active && showRefund && <RefundModal r={active} onClose={() => setShowRefund(false)} />}
    </div>
  );
}

function SessionDetail({ r, onClose, onRefund }: { r: SessionRow; onClose: () => void; onRefund: () => void }) {
  const [messages, setMessages] = useState<any[]>([]);
  const [recordingUrl, setRecordingUrl] = useState<string | null>(null);
  useEffect(() => {
    if (r.kind === "chat") {
      (async () => {
        const { data } = await supabase.from("chat_messages").select("*").eq("session_id", r.id).order("created_at");
        setMessages(data || []);
      })();
    } else {
      (async () => {
        const { data } = await supabase.from("call_sessions").select("recording_url").eq("id", r.id).maybeSingle();
        setRecordingUrl(data?.recording_url ?? null);
      })();
    }
  }, [r]);
  return (
    <AdminModal open onClose={onClose} title={`${r.kind === "chat" ? "Chat" : "Call"} session details`}>
      <div className="grid grid-cols-2 gap-3 text-sm mb-4">
        <Info label="Customer">{r.customer_name}</Info>
        <Info label="Astrologer">{r.astrologer_name}</Info>
        <Info label="Status"><StatusBadge status={r.status} /></Info>
        <Info label="Type" className="capitalize">{r.kind}</Info>
        <Info label="Duration">{fmtDuration(r.duration_seconds)}</Info>
        <Info label="Per-minute">{fmtINR(r.per_minute_rate)}</Info>
        <Info label="Total cost">{fmtINR(r.total_cost)}</Info>
        <Info label="Astrologer earning">{fmtINR(r.astrologer_earning)}</Info>
        <Info label="Platform earning">{fmtINR(r.company_earning)}</Info>
        <Info label="Started">{fmtDate(r.start)}</Info>
        <Info label="Ended">{fmtDate(r.end)}</Info>
        <Info label="Session ID" className="font-mono text-xs">{r.id}</Info>
      </div>
      {r.kind === "call" && (
        <div className="mb-4">
          <div className="text-xs uppercase text-slate-500 mb-2">Call recording</div>
          {recordingUrl ? (
            <audio controls className="w-full" src={recordingUrl}>
              Your browser does not support audio playback.
            </audio>
          ) : (
            <div className="text-xs text-slate-500 rounded-md border border-slate-800 bg-slate-950 px-3 py-2">
              No recording available (call may not have connected, or recording is still being processed).
            </div>
          )}
        </div>
      )}
      {r.kind === "chat" && (
        <div>
          <div className="text-xs uppercase text-slate-500 mb-2">Conversation ({messages.length} messages)</div>
          <div className="max-h-72 overflow-y-auto rounded-md border border-slate-800 bg-slate-950 p-3 space-y-2">
            {messages.length === 0 ? <div className="text-xs text-slate-500 text-center py-6">No messages</div> :
            messages.map((m: any) => (
              <div key={m.id} className={`flex ${m.sender_role === "astrologer" ? "justify-start" : "justify-end"}`}>
                <div className={`max-w-[75%] px-3 py-2 rounded-lg text-sm ${m.sender_role === "astrologer" ? "bg-slate-800 text-slate-100" : "bg-indigo-600 text-white"}`}>
                  <div className="text-[10px] opacity-70 mb-0.5">{m.sender_role} • {fmtDate(m.created_at)}</div>
                  {m.content}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
      <div className="flex justify-end gap-2 mt-4">
        <AdminButton variant="ghost" onClick={onClose}>Close</AdminButton>
        <AdminButton variant="secondary" onClick={onRefund}><RefreshCw className="h-3 w-3" /> Issue refund</AdminButton>
      </div>
    </AdminModal>
  );
}

function Info({ label, children, className = "" }: { label: string; children: React.ReactNode; className?: string }) {
  return <div><div className="text-[10px] uppercase text-slate-500 mb-0.5">{label}</div><div className={`text-slate-200 ${className}`}>{children}</div></div>;
}

function RefundModal({ r, onClose }: { r: SessionRow; onClose: () => void }) {
  const { toast } = useToast();
  const [amount, setAmount] = useState(String(r.total_cost));
  const [reason, setReason] = useState("");
  const submit = async () => {
    const amt = Number(amount);
    if (!amt || amt <= 0) return toast({ title: "Enter valid amount", variant: "destructive" });
    const { error } = await supabase.rpc("admin_refund_session", {
      _session_id: r.id, _session_kind: r.kind, _amount: amt, _reason: reason,
    });
    if (error) return toast({ title: "Failed", description: error.message, variant: "destructive" });
    toast({ title: "Refund issued" });
    onClose();
  };
  return (
    <AdminModal open onClose={onClose} title="Issue refund" maxWidth="max-w-md">
      <div className="space-y-3 text-sm">
        <div className="text-slate-400">Refund will be credited to <strong className="text-slate-200">{r.customer_name}</strong>'s wallet.</div>
        <div><div className="text-[11px] uppercase text-slate-500 mb-1">Amount (₹)</div><AdminInput type="number" value={amount} onChange={(e) => setAmount(e.target.value)} /></div>
        <div><div className="text-[11px] uppercase text-slate-500 mb-1">Reason</div><AdminTextarea rows={3} value={reason} onChange={(e) => setReason(e.target.value)} /></div>
      </div>
      <div className="flex justify-end gap-2 mt-4">
        <AdminButton variant="ghost" onClick={onClose}>Cancel</AdminButton>
        <AdminButton variant="primary" onClick={submit}>Issue refund</AdminButton>
      </div>
    </AdminModal>
  );
}
