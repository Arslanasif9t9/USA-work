import { Construction } from "lucide-react";

export default function AdminPlaceholder({ title, description }: { title: string; description?: string }) {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-semibold">{title}</h1>
        {description && <p className="text-sm text-slate-400 mt-1">{description}</p>}
      </div>
      <div className="rounded-xl border border-dashed border-slate-700 bg-slate-900/40 p-12 text-center">
        <Construction className="h-8 w-8 text-slate-500 mx-auto mb-3" />
        <div className="text-slate-300 font-medium">Coming soon</div>
        <div className="text-sm text-slate-500 mt-1">This module will be built next.</div>
      </div>
    </div>
  );
}
