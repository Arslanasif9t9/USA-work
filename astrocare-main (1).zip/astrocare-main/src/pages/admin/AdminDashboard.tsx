import { useEffect, useMemo, useState } from "react";
import { Link } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import {
  Users, UserCog, Activity, IndianRupee, Wallet, Hourglass,
  CheckCircle2, XCircle, MessageSquareText, ArrowRight,
} from "lucide-react";
import {
  ResponsiveContainer, LineChart, Line, BarChart, Bar,
  XAxis, YAxis, Tooltip, CartesianGrid, Legend,
} from "recharts";
import { useAdminAuth } from "@/admin/AdminAuthContext";
import { AdminCard, AdminPageHeader, AdminButton, fmtINR, fmtDate } from "@/admin/ui";
import { callAdminAction } from "@/admin/api";
import { toast } from "sonner";

interface Stat { label: string; value: string | number; sub?: string; icon: typeof Users; tone: string; }

function dayKey(d: string | Date) {
  const dt = typeof d === "string" ? new Date(d) : d;
  return dt.toISOString().slice(0, 10);
}

export default function AdminDashboard() {
  const { admin } = useAdminAuth();
  const [stats, setStats] = useState<Stat[]>([]);
  const [revenueSeries, setRevenueSeries] = useState<{ date: string; revenue: number }[]>([]);
  const [sessionSeries, setSessionSeries] = useState<{ date: string; chat: number; call: number }[]>([]);
  const [pendingAstro, setPendingAstro] = useState<any[]>([]);
  const [openTickets, setOpenTickets] = useState<any[]>([]);
  const [pendingWdr, setPendingWdr] = useState<any[]>([]);
  const [feed, setFeed] = useState<{ ts: string; text: string; tone: string }[]>([]);

  async function loadAll() {
    const since30 = new Date(Date.now() - 30 * 24 * 3600 * 1000).toISOString();
    const sinceMonth = new Date(new Date().getFullYear(), new Date().getMonth(), 1).toISOString();
    const todayStart = new Date(); todayStart.setHours(0, 0, 0, 0);

    const [
      customersTotal, customersToday, astroApproved, activeChat, activeCall,
      monthChats, monthCalls, pendingWdrCount,
      chatRows, callRows, pendingAstroRows, ticketsRows, wdrRows,
    ] = await Promise.all([
      supabase.from("profiles").select("id", { count: "exact", head: true }),
      supabase.from("profiles").select("id", { count: "exact", head: true }).gte("created_at", todayStart.toISOString()),
      supabase.from("astrologers").select("id", { count: "exact", head: true }).eq("approval_status", "approved"),
      supabase.from("chat_sessions").select("id", { count: "exact", head: true }).eq("status", "active"),
      supabase.from("call_sessions").select("id", { count: "exact", head: true }).eq("status", "active"),
      supabase.from("chat_sessions").select("total_cost, astrologer_earning, company_earning, created_at, status, ended_at").gte("created_at", sinceMonth),
      supabase.from("call_sessions").select("astrologer_earning, company_earning, per_minute_rate, duration_seconds, created_at, status, ended_at").gte("created_at", sinceMonth),
      supabase.from("withdrawal_requests").select("id", { count: "exact", head: true }).eq("status", "pending"),
      supabase.from("chat_sessions").select("created_at, total_cost, company_earning, astrologer_earning").gte("created_at", since30),
      supabase.from("call_sessions").select("created_at, company_earning, astrologer_earning, per_minute_rate, duration_seconds").gte("created_at", since30),
      supabase.from("astrologers").select("id, display_name, base_rate_per_min, languages, created_at").eq("approval_status", "pending").order("created_at", { ascending: false }).limit(6),
      supabase.from("support_tickets").select("id, subject, status, created_at, user_id").eq("status", "open").order("created_at", { ascending: false }).limit(5),
      supabase.from("withdrawal_requests").select("id, amount, method, astrologer_user_id, created_at").eq("status", "pending").order("created_at", { ascending: false }).limit(5),
    ]);

    const platformMonth = (monthChats.data || []).reduce((s, r: any) => s + Number(r.company_earning || 0), 0)
      + (monthCalls.data || []).reduce((s, r: any) => s + Number(r.company_earning || 0), 0);
    const astroMonth = (monthChats.data || []).reduce((s, r: any) => s + Number(r.astrologer_earning || 0), 0)
      + (monthCalls.data || []).reduce((s, r: any) => s + Number(r.astrologer_earning || 0), 0);

    setStats([
      { label: "Total customers", value: customersTotal.count ?? 0, sub: `+${customersToday.count ?? 0} today`, icon: Users, tone: "indigo" },
      { label: "Approved astrologers", value: astroApproved.count ?? 0, icon: UserCog, tone: "violet" },
      { label: "Active sessions", value: (activeChat.count ?? 0) + (activeCall.count ?? 0), sub: `${activeChat.count ?? 0} chat · ${activeCall.count ?? 0} call`, icon: Activity, tone: "emerald" },
      { label: "Platform revenue (month)", value: fmtINR(platformMonth), icon: IndianRupee, tone: "amber" },
      { label: "Astrologer payout (month)", value: fmtINR(astroMonth), icon: Wallet, tone: "blue" },
      { label: "Pending withdrawals", value: pendingWdrCount.count ?? 0, icon: Hourglass, tone: "rose" },
    ]);

    // Build day-bucketed series
    const revMap = new Map<string, number>();
    const sesMap = new Map<string, { chat: number; call: number }>();
    for (let i = 29; i >= 0; i--) {
      const d = new Date(Date.now() - i * 24 * 3600 * 1000);
      const k = dayKey(d);
      revMap.set(k, 0);
      sesMap.set(k, { chat: 0, call: 0 });
    }
    (chatRows.data || []).forEach((r: any) => {
      const k = dayKey(r.created_at);
      if (revMap.has(k)) revMap.set(k, (revMap.get(k) || 0) + Number(r.company_earning || 0));
      if (sesMap.has(k)) sesMap.get(k)!.chat += 1;
    });
    (callRows.data || []).forEach((r: any) => {
      const k = dayKey(r.created_at);
      if (revMap.has(k)) revMap.set(k, (revMap.get(k) || 0) + Number(r.company_earning || 0));
      if (sesMap.has(k)) sesMap.get(k)!.call += 1;
    });
    setRevenueSeries(Array.from(revMap.entries()).map(([date, revenue]) => ({ date: date.slice(5), revenue: Math.round(revenue) })));
    setSessionSeries(Array.from(sesMap.entries()).map(([date, v]) => ({ date: date.slice(5), ...v })));

    setPendingAstro(pendingAstroRows.data || []);
    setOpenTickets(ticketsRows.data || []);
    setPendingWdr(wdrRows.data || []);

    // Activity feed: combine recent rows from a few tables
    const feedItems: { ts: string; text: string; tone: string }[] = [];
    (chatRows.data || []).slice(-10).forEach((r: any) =>
      feedItems.push({ ts: r.created_at, text: `Chat session started · ${fmtINR(r.total_cost)}`, tone: "indigo" }));
    (pendingAstroRows.data || []).forEach((r: any) =>
      feedItems.push({ ts: r.created_at, text: `New astrologer applied: ${r.display_name}`, tone: "violet" }));
    (wdrRows.data || []).forEach((r: any) =>
      feedItems.push({ ts: r.created_at, text: `Withdrawal requested · ${fmtINR(r.amount)}`, tone: "rose" }));
    feedItems.sort((a, b) => +new Date(b.ts) - +new Date(a.ts));
    setFeed(feedItems.slice(0, 12));
  }

  useEffect(() => {
    loadAll();
    const t = setInterval(loadAll, 30000);
    return () => clearInterval(t);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const toneClass = useMemo(() => ({
    indigo:  "bg-indigo-600/20 text-indigo-300",
    violet:  "bg-violet-600/20 text-violet-300",
    emerald: "bg-emerald-600/20 text-emerald-300",
    amber:   "bg-amber-600/20  text-amber-300",
    blue:    "bg-blue-600/20   text-blue-300",
    rose:    "bg-rose-600/20   text-rose-300",
  } as Record<string, string>), []);

  async function quickApprove(id: string) {
    const r = await callAdminAction("astrologer_set_approval", { astrologer_id: id, approval_status: "approved" });
    if (r.ok) { toast.success("Approved"); loadAll(); } else toast.error(r.error || "Failed");
  }
  async function quickReject(id: string) {
    const reason = prompt("Reason for rejection?") || "";
    const r = await callAdminAction("astrologer_set_approval", { astrologer_id: id, approval_status: "rejected", rejection_reason: reason });
    if (r.ok) { toast.success("Rejected"); loadAll(); } else toast.error(r.error || "Failed");
  }

  return (
    <div className="space-y-6">
      <AdminPageHeader
        title={`Welcome back, ${admin?.full_name || "Admin"}`}
        description="A live snapshot of platform activity. Auto-refreshes every 30 seconds."
      />

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-4">
        {stats.map((s) => (
          <div key={s.label} className="rounded-xl border border-slate-800 bg-slate-900/60 p-5">
            <div className="flex items-center justify-between">
              <div className="text-[11px] uppercase tracking-wider text-slate-400">{s.label}</div>
              <div className={`h-8 w-8 rounded-lg flex items-center justify-center ${toneClass[s.tone]}`}>
                <s.icon className="h-4 w-4" />
              </div>
            </div>
            <div className="mt-3 text-2xl font-semibold tracking-tight">{s.value}</div>
            {s.sub && <div className="text-[11px] text-slate-400 mt-1">{s.sub}</div>}
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <div className="lg:col-span-2 space-y-4">
          <AdminCard className="p-5">
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-semibold text-sm">Platform revenue · last 30 days</h3>
              <span className="text-[11px] text-slate-400">70% share</span>
            </div>
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={revenueSeries}>
                  <CartesianGrid stroke="#1e293b" strokeDasharray="3 3" />
                  <XAxis dataKey="date" stroke="#64748b" fontSize={11} />
                  <YAxis stroke="#64748b" fontSize={11} />
                  <Tooltip contentStyle={{ background: "#0f172a", border: "1px solid #334155", borderRadius: 8, color: "#e2e8f0" }} />
                  <Line type="monotone" dataKey="revenue" stroke="#818cf8" strokeWidth={2} dot={false} />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </AdminCard>

          <AdminCard className="p-5">
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-semibold text-sm">Sessions · last 30 days</h3>
              <span className="text-[11px] text-slate-400">chat vs call</span>
            </div>
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={sessionSeries}>
                  <CartesianGrid stroke="#1e293b" strokeDasharray="3 3" />
                  <XAxis dataKey="date" stroke="#64748b" fontSize={11} />
                  <YAxis stroke="#64748b" fontSize={11} allowDecimals={false} />
                  <Tooltip contentStyle={{ background: "#0f172a", border: "1px solid #334155", borderRadius: 8, color: "#e2e8f0" }} />
                  <Legend wrapperStyle={{ fontSize: 11, color: "#94a3b8" }} />
                  <Bar dataKey="chat" stackId="s" fill="#6366f1" />
                  <Bar dataKey="call" stackId="s" fill="#10b981" />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </AdminCard>

          <AdminCard className="p-5">
            <h3 className="font-semibold text-sm mb-3">Live activity</h3>
            {feed.length === 0 ? (
              <div className="text-xs text-slate-500 py-6 text-center">No recent activity yet.</div>
            ) : (
              <ul className="divide-y divide-slate-800 text-sm">
                {feed.map((f, i) => (
                  <li key={i} className="py-2 flex items-center justify-between gap-3">
                    <span className="text-slate-200">{f.text}</span>
                    <span className="text-[11px] text-slate-500">{fmtDate(f.ts)}</span>
                  </li>
                ))}
              </ul>
            )}
          </AdminCard>
        </div>

        <div className="space-y-4">
          <AdminCard className="p-5">
            <div className="flex items-center justify-between mb-3">
              <h3 className="font-semibold text-sm">Pending approvals</h3>
              <Link to="/astrocareadmin/astrologers" className="text-xs text-indigo-300 hover:text-indigo-200 inline-flex items-center gap-1">
                View all <ArrowRight className="h-3 w-3" />
              </Link>
            </div>
            {pendingAstro.length === 0 ? (
              <div className="text-xs text-slate-500 py-6 text-center">No astrologers waiting.</div>
            ) : (
              <ul className="space-y-2">
                {pendingAstro.map((a) => (
                  <li key={a.id} className="rounded-lg border border-slate-800 p-3">
                    <div className="flex items-center justify-between">
                      <div>
                        <div className="text-sm font-medium">{a.display_name}</div>
                        <div className="text-[11px] text-slate-400">{fmtINR(a.base_rate_per_min)}/min · {(a.languages || []).slice(0, 2).join(", ")}</div>
                      </div>
                      <div className="flex gap-1">
                        <button onClick={() => quickApprove(a.id)} className="h-7 w-7 rounded bg-emerald-600/20 text-emerald-300 hover:bg-emerald-600/30 flex items-center justify-center" title="Approve">
                          <CheckCircle2 className="h-3.5 w-3.5" />
                        </button>
                        <button onClick={() => quickReject(a.id)} className="h-7 w-7 rounded bg-rose-600/20 text-rose-300 hover:bg-rose-600/30 flex items-center justify-center" title="Reject">
                          <XCircle className="h-3.5 w-3.5" />
                        </button>
                      </div>
                    </div>
                  </li>
                ))}
              </ul>
            )}
          </AdminCard>

          <AdminCard className="p-5">
            <div className="flex items-center justify-between mb-3">
              <h3 className="font-semibold text-sm">Open support tickets</h3>
              <Link to="/astrocareadmin/support" className="text-xs text-indigo-300 hover:text-indigo-200 inline-flex items-center gap-1">
                View all <ArrowRight className="h-3 w-3" />
              </Link>
            </div>
            {openTickets.length === 0 ? (
              <div className="text-xs text-slate-500 py-6 text-center">No open tickets.</div>
            ) : (
              <ul className="space-y-2">
                {openTickets.map((t) => (
                  <li key={t.id} className="rounded-lg border border-slate-800 p-3 flex items-center justify-between">
                    <div className="min-w-0">
                      <div className="text-sm font-medium truncate">{t.subject}</div>
                      <div className="text-[11px] text-slate-400">{fmtDate(t.created_at)}</div>
                    </div>
                    <MessageSquareText className="h-4 w-4 text-slate-500" />
                  </li>
                ))}
              </ul>
            )}
          </AdminCard>

          <AdminCard className="p-5">
            <div className="flex items-center justify-between mb-3">
              <h3 className="font-semibold text-sm">Pending withdrawals</h3>
              <Link to="/astrocareadmin/withdrawals" className="text-xs text-indigo-300 hover:text-indigo-200 inline-flex items-center gap-1">
                Process <ArrowRight className="h-3 w-3" />
              </Link>
            </div>
            {pendingWdr.length === 0 ? (
              <div className="text-xs text-slate-500 py-6 text-center">Nothing pending.</div>
            ) : (
              <ul className="space-y-2">
                {pendingWdr.map((w) => (
                  <li key={w.id} className="rounded-lg border border-slate-800 p-3 flex items-center justify-between">
                    <div>
                      <div className="text-sm font-medium">{fmtINR(w.amount)}</div>
                      <div className="text-[11px] text-slate-400 uppercase">{w.method}</div>
                    </div>
                    <div className="text-[11px] text-slate-500">{fmtDate(w.created_at)}</div>
                  </li>
                ))}
              </ul>
            )}
          </AdminCard>
        </div>
      </div>

      <div className="flex items-center justify-end">
        <AdminButton variant="secondary" onClick={loadAll}>Refresh now</AdminButton>
      </div>
    </div>
  );
}
