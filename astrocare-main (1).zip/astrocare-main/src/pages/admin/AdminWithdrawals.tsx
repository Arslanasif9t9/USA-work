import { useCallback, useMemo, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { Eye, Check, X, Loader2 as LoadingIcon } from "lucide-react";
import { AdminPageHeader, AdminCard, AdminTabs, StatusBadge, AdminButton, AdminModal, AdminInput, AdminTextarea, AdminTable, fmtINR, fmtDate } from "@/admin/ui";
import { useInfiniteList } from "@/hooks/useInfiniteList";

interface Withdrawal {
  id: string;
  astrologer_user_id: string;
  amount: number;
  method: string;
  status: string;
  created_at: string;
  upi_id: string | null;
  bank_name: string | null;
  bank_account: string | null;
  bank_ifsc: string | null;
  notes: string | null;
  transaction_reference: string | null;
  astrologer_name?: string;
}

export default function AdminWithdrawals() {
  const { toast } = useToast();
  const [tab, setTab] = useState<"all" | "pending" | "processing" | "completed" | "rejected">("pending");
  const [active, setActive] = useState<Withdrawal | null>(null);
  const [completeRef, setCompleteRef] = useState("");
  const [rejectReason, setRejectReason] = useState("");
  const [busy, setBusy] = useState(false);
  const [reloadKey, setReloadKey] = useState(0);

  const fetchPage = useCallback(async (offset: number, limit: number): Promise<Withdrawal[]> => {
    let q = supabase.from("withdrawal_requests").select("*").order("created_at", { ascending: false }).range(offset, offset + limit - 1);
    if (tab !== "all") q = q.eq("status", tab);
    const { data } = await q;
    const ids = Array.from(new Set((data || []).map((w: any) => w.astrologer_user_id)));
    const { data: astros } = ids.length
      ? await supabase.from("astrologers").select("user_id, display_name").in("user_id", ids)
      : { data: [] as any[] };
    const an: Record<string, string> = {}; (astros || []).forEach((a: any) => an[a.user_id] = a.display_name);
    return (data || []).map((w: any) => ({ ...w, astrologer_name: an[w.astrologer_user_id] || "—" }));
  }, [tab]);

  const { rows: filtered, loading, done, sentinelRef, initialLoading } = useInfiniteList<Withdrawal>(fetchPage, [tab, reloadKey]);

  const action = async (act: "processing" | "completed" | "rejected") => {
    if (!active) return;
    setBusy(true);
    const { error } = await supabase.rpc("admin_process_withdrawal", {
      _request_id: active.id, _action: act,
      _reference: act === "completed" ? completeRef : null,
      _reason: act === "rejected" ? rejectReason : null,
    });
    setBusy(false);
    if (error) return toast({ title: "Failed", description: error.message, variant: "destructive" });
    toast({ title: `Withdrawal ${act}` });
    setActive(null); setCompleteRef(""); setRejectReason("");
    setReloadKey((k) => k + 1);
  };

  const tabs = useMemo(() => ([
    { value: "all" as const, label: "All" },
    { value: "pending" as const, label: "Pending" },
    { value: "processing" as const, label: "Processing" },
    { value: "completed" as const, label: "Completed" },
    { value: "rejected" as const, label: "Rejected" },
  ]), []);

  return (
    <div>
      <AdminPageHeader title="Withdrawals" description="Process astrologer payout requests." />

      <AdminTabs value={tab} onChange={setTab} tabs={tabs} />

      <AdminCard className="overflow-hidden">
        <AdminTable
          loading={loading}
          done={done}
          sentinelRef={sentinelRef}
          emptyMessage={!initialLoading && filtered.length === 0 ? "No withdrawal requests." : undefined}
        >
          {filtered.length > 0 && (
            <table className="admin-table w-full text-sm">
              <thead className="bg-slate-900/80 text-xs uppercase text-slate-400">
                <tr>
                  <th className="text-left px-4 py-3 font-medium">Astrologer</th>
                  <th className="text-right px-4 py-3 font-medium">Amount</th>
                  <th className="text-left px-4 py-3 font-medium">Method</th>
                  <th className="text-left px-4 py-3 font-medium">Details</th>
                  <th className="text-left px-4 py-3 font-medium">Requested</th>
                  <th className="text-left px-4 py-3 font-medium">Status</th>
                  <th className="text-right px-4 py-3 font-medium admin-cell-action">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800">
                {filtered.map((w) => (
                  <tr key={w.id} className="hover:bg-slate-800/40">
                    <td className="px-4 py-3 font-medium">{w.astrologer_name}</td>
                    <td className="px-4 py-3 text-right font-semibold">{fmtINR(w.amount)}</td>
                    <td className="px-4 py-3 uppercase text-xs text-slate-400">{w.method}</td>
                    <td className="px-4 py-3 text-xs text-slate-400">
                      {w.method === "upi" ? w.upi_id : `${w.bank_name || ""} ${w.bank_account ? "····" + w.bank_account.slice(-4) : ""}`}
                    </td>
                    <td className="px-4 py-3 text-xs text-slate-400">{fmtDate(w.created_at)}</td>
                    <td className="px-4 py-3"><StatusBadge status={w.status} /></td>
                    <td className="px-4 py-3 text-right admin-cell-action">
                      <AdminButton variant="secondary" onClick={() => setActive(w)}><Eye className="h-3 w-3" /> View</AdminButton>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </AdminTable>
      </AdminCard>

      {active && <AdminModal open onClose={() => setActive(null)} title={`Withdrawal — ${active.astrologer_name}`} maxWidth="max-w-lg">
        <div className="space-y-2 text-sm">
          <Row label="Amount" value={<span className="font-semibold text-slate-100">{fmtINR(active.amount)}</span>} />
          <Row label="Method" value={<span className="uppercase">{active.method}</span>} />
          {active.method === "upi"
            ? <Row label="UPI ID" value={active.upi_id} />
            : <>
                <Row label="Bank" value={active.bank_name} />
                <Row label="Account" value={active.bank_account} />
                <Row label="IFSC" value={active.bank_ifsc} />
              </>}
          <Row label="Status" value={<StatusBadge status={active.status} />} />
          <Row label="Requested" value={fmtDate(active.created_at)} />
          {active.transaction_reference && <Row label="Reference" value={<span className="font-mono">{active.transaction_reference}</span>} />}
          {active.notes && <Row label="Notes" value={active.notes} />}
        </div>

        {(active.status === "pending" || active.status === "processing") && (
          <div className="mt-5 border-t border-slate-800 pt-4 space-y-3">
            {active.status === "pending" && (
              <AdminButton variant="secondary" onClick={() => action("processing")} disabled={busy} className="w-full">
                {busy ? <LoadingIcon className="h-3 w-3 animate-spin" /> : null} Mark as Processing
              </AdminButton>
            )}
            <div>
              <div className="text-[11px] uppercase text-slate-500 mb-1">Transaction reference</div>
              <AdminInput value={completeRef} onChange={(e) => setCompleteRef(e.target.value)} placeholder="UTR / txn id" />
              <AdminButton variant="primary" onClick={() => action("completed")} disabled={busy || !completeRef.trim()} className="w-full mt-2">
                <Check className="h-3 w-3" /> Mark as Completed
              </AdminButton>
            </div>
            <div>
              <div className="text-[11px] uppercase text-slate-500 mb-1">Reject reason</div>
              <AdminTextarea rows={2} value={rejectReason} onChange={(e) => setRejectReason(e.target.value)} placeholder="Why?" />
              <AdminButton variant="danger" onClick={() => action("rejected")} disabled={busy} className="w-full mt-2">
                <X className="h-3 w-3" /> Reject & Refund
              </AdminButton>
            </div>
          </div>
        )}
      </AdminModal>}
    </div>
  );
}

function Row({ label, value }: { label: string; value: any }) {
  return <div className="flex justify-between gap-4"><span className="text-slate-400">{label}</span><span className="text-slate-200">{value || "—"}</span></div>;
}
