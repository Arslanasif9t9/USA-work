// Wallet adjustment request queue.
// Regular admins create requests via WalletAdjustModal — they show up here.
// Master + Finance admins approve/reject. Regular admins see only their own.
import { useEffect, useMemo, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { Loader2, Check, X } from "lucide-react";
import { AdminPageHeader, AdminCard, AdminTabs, StatusBadge, AdminButton, AdminModal, AdminTextarea, EmptyState, fmtINR, fmtDate, AdminTable } from "@/admin/ui";
import { callAdminAction } from "@/admin/api";
import { useAdminAuth } from "@/admin/AdminAuthContext";

interface Req {
  id: string;
  requested_by_admin_id: string;
  target_user_id: string;
  target_user_type: "customer" | "astrologer";
  amount: number;
  reason: string | null;
  status: "pending" | "approved" | "rejected";
  reviewed_by_admin_id: string | null;
  reviewed_at: string | null;
  review_note: string | null;
  created_at: string;
  requester_name?: string;
  reviewer_name?: string;
  target_name?: string;
}

export default function AdminWalletRequests() {
  const { admin } = useAdminAuth();
  const { toast } = useToast();
  const [tab, setTab] = useState<"pending" | "approved" | "rejected" | "mine">("pending");
  const [rows, setRows] = useState<Req[]>([]);
  const [loading, setLoading] = useState(true);
  const [active, setActive] = useState<Req | null>(null);
  const [decision, setDecision] = useState<"approved" | "rejected" | null>(null);
  const [note, setNote] = useState("");
  const [busy, setBusy] = useState(false);

  const isReviewer = admin?.role === "master_admin" || admin?.role === "finance_admin";

  const refresh = async () => {
    setLoading(true);
    let q = supabase.from("wallet_adjustment_requests").select("*").order("created_at", { ascending: false }).limit(15);
    if (!isReviewer) q = q.eq("requested_by_admin_id", admin?.id || "");
    const { data: requests } = await q;
    const reqs = (requests || []) as any[];

    const adminIds = Array.from(new Set([
      ...reqs.map((r) => r.requested_by_admin_id),
      ...reqs.map((r) => r.reviewed_by_admin_id).filter(Boolean),
    ]));
    const userIds = Array.from(new Set(reqs.map((r) => r.target_user_id)));
    const astroUserIds = reqs.filter(r => r.target_user_type === "astrologer").map(r => r.target_user_id);

    const [{ data: admins }, { data: profs }, { data: astros }] = await Promise.all([
      adminIds.length ? supabase.from("admin_users").select("id, full_name, email").in("id", adminIds) : Promise.resolve({ data: [] as any[] }),
      userIds.length ? supabase.from("profiles").select("id, name, email").in("id", userIds) : Promise.resolve({ data: [] as any[] }),
      astroUserIds.length ? supabase.from("astrologers").select("user_id, display_name").in("user_id", astroUserIds) : Promise.resolve({ data: [] as any[] }),
    ]);
    const am: Record<string, string> = {}; (admins || []).forEach((a: any) => am[a.id] = a.full_name || a.email);
    const pm: Record<string, string> = {}; (profs || []).forEach((p: any) => pm[p.id] = p.name || p.email || "—");
    const an: Record<string, string> = {}; (astros || []).forEach((a: any) => an[a.user_id] = a.display_name);

    setRows(reqs.map((r) => ({
      ...r,
      amount: Number(r.amount),
      requester_name: am[r.requested_by_admin_id] || "—",
      reviewer_name: r.reviewed_by_admin_id ? am[r.reviewed_by_admin_id] : undefined,
      target_name: r.target_user_type === "astrologer" ? (an[r.target_user_id] || pm[r.target_user_id] || "—") : (pm[r.target_user_id] || "—"),
    })));
    setLoading(false);
  };
  useEffect(() => { refresh(); /* eslint-disable-next-line */ }, [admin?.id, isReviewer]);

  const counts = useMemo(() => ({
    pending: rows.filter(r => r.status === "pending").length,
    approved: rows.filter(r => r.status === "approved").length,
    rejected: rows.filter(r => r.status === "rejected").length,
    mine: rows.filter(r => r.requested_by_admin_id === admin?.id).length,
  }), [rows, admin?.id]);

  const filtered = useMemo(() => {
    if (tab === "mine") return rows.filter(r => r.requested_by_admin_id === admin?.id);
    return rows.filter(r => r.status === tab);
  }, [rows, tab, admin?.id]);

  const review = async () => {
    if (!active || !decision) return;
    setBusy(true);
    const r = await callAdminAction("wallet_request.review", {
      request_id: active.id, decision, note,
    });
    setBusy(false);
    if (!r.ok) return toast({ title: "Failed", description: r.error, variant: "destructive" });
    toast({ title: `Request ${decision}` });
    setActive(null); setDecision(null); setNote(""); refresh();
  };

  return (
    <div>
      <AdminPageHeader
        title="Wallet adjustment requests"
        description={isReviewer ? "Approve or reject wallet adjustments requested by other admins." : "Track the status of your submitted adjustment requests."}
      />

      <AdminTabs value={tab} onChange={setTab} tabs={[
        { value: "pending",  label: "Pending",  count: counts.pending },
        { value: "approved", label: "Approved", count: counts.approved },
        { value: "rejected", label: "Rejected", count: counts.rejected },
        { value: "mine",     label: "My requests", count: counts.mine },
      ]} />

      <AdminCard className="overflow-hidden">
        {loading ? <div className="p-10 flex justify-center"><Loader2 className="h-5 w-5 animate-spin text-slate-400" /></div>
        : filtered.length === 0 ? <EmptyState message="Nothing here." />
        : (
          <AdminTable>
            <table className="admin-table w-full text-sm">
              <thead className="bg-slate-900/80 text-xs uppercase text-slate-400">
                <tr>
                  <th className="text-left px-4 py-3 font-medium">Requested by</th>
                  <th className="text-left px-4 py-3 font-medium">Target</th>
                  <th className="text-right px-4 py-3 font-medium">Amount</th>
                  <th className="text-left px-4 py-3 font-medium">Reason</th>
                  <th className="text-left px-4 py-3 font-medium">Status</th>
                  <th className="text-left px-4 py-3 font-medium">Reviewed</th>
                  <th className="text-left px-4 py-3 font-medium">When</th>
                  <th className="text-right px-4 py-3 font-medium admin-cell-action">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800">
                {filtered.map((r) => (
                  <tr key={r.id} className="hover:bg-slate-800/40">
                    <td className="px-4 py-3">{r.requester_name}</td>
                    <td className="px-4 py-3">
                      <div className="text-slate-200">{r.target_name}</div>
                      <div className="text-[10px] uppercase text-slate-500">{r.target_user_type}</div>
                    </td>
                    <td className={`px-4 py-3 text-right font-semibold ${r.amount >= 0 ? "text-emerald-400" : "text-rose-400"}`}>
                      {r.amount >= 0 ? "+" : "−"}{fmtINR(Math.abs(r.amount))}
                    </td>
                    <td className="px-4 py-3 text-slate-300 max-w-[260px] truncate">{r.reason || "—"}</td>
                    <td className="px-4 py-3"><StatusBadge status={r.status} /></td>
                    <td className="px-4 py-3 text-xs text-slate-400">
                      {r.reviewer_name ? <>{r.reviewer_name}<br /><span className="text-[10px] text-slate-500">{fmtDate(r.reviewed_at)}</span></> : "—"}
                    </td>
                    <td className="px-4 py-3 text-xs text-slate-400 whitespace-nowrap">{fmtDate(r.created_at)}</td>
                    <td className="px-4 py-3 admin-cell-action">
                      <div className="flex items-center justify-end gap-1.5 whitespace-nowrap">
                        {isReviewer && r.status === "pending" ? (
                          <>
                            <AdminButton variant="primary" onClick={() => { setActive(r); setDecision("approved"); }}>
                              <Check className="h-3 w-3" /> Approve
                            </AdminButton>
                            <AdminButton variant="danger" onClick={() => { setActive(r); setDecision("rejected"); }}>
                              <X className="h-3 w-3" /> Reject
                            </AdminButton>
                          </>
                        ) : (
                          <span className="text-[11px] text-slate-500">—</span>
                        )}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </AdminTable>
        )}
      </AdminCard>

      {active && decision && (
        <AdminModal open onClose={() => { setActive(null); setDecision(null); setNote(""); }} title={`${decision === "approved" ? "Approve" : "Reject"} request`} maxWidth="max-w-md">
          <div className="space-y-2 text-sm mb-3">
            <div><span className="text-slate-400">Target:</span> {active.target_name} ({active.target_user_type})</div>
            <div><span className="text-slate-400">Amount:</span> <span className={active.amount >= 0 ? "text-emerald-400" : "text-rose-400"}>{active.amount >= 0 ? "+" : "−"}{fmtINR(Math.abs(active.amount))}</span></div>
            <div><span className="text-slate-400">Reason:</span> {active.reason || "—"}</div>
            <div><span className="text-slate-400">Requested by:</span> {active.requester_name}</div>
          </div>
          <div className="text-[11px] uppercase text-slate-500 mb-1">Note (optional)</div>
          <AdminTextarea rows={3} value={note} onChange={(e) => setNote(e.target.value)} placeholder="Visible in audit log" />
          <div className="flex justify-end gap-2 mt-4">
            <AdminButton variant="ghost" onClick={() => { setActive(null); setDecision(null); }} disabled={busy}>Cancel</AdminButton>
            <AdminButton variant={decision === "approved" ? "primary" : "danger"} onClick={review} disabled={busy}>
              {busy && <Loader2 className="h-3 w-3 animate-spin" />}
              {decision === "approved" ? "Approve & adjust" : "Reject"}
            </AdminButton>
          </div>
        </AdminModal>
      )}
    </div>
  );
}
