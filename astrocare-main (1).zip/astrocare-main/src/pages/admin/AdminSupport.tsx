import { useEffect, useMemo, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { Loader2, Send } from "lucide-react";
import { AdminPageHeader, AdminCard, AdminTabs, StatusBadge, AdminButton, AdminModal, AdminTextarea, AdminSelect, EmptyState, fmtDate } from "@/admin/ui";
import { callAdminAction } from "@/admin/api";

interface Ticket {
  id: string;
  subject: string;
  message: string;
  status: string;
  created_at: string;
  user_id: string;
  user_name?: string;
  user_email?: string;
  user_role?: "customer" | "astrologer";
}

export default function AdminSupport() {
  const { toast } = useToast();
  const [tab, setTab] = useState<"all" | "open" | "in_progress" | "resolved">("all");
  const [userTab, setUserTab] = useState<"all" | "customer" | "astrologer">("all");
  const [rows, setRows] = useState<Ticket[]>([]);
  const [loading, setLoading] = useState(true);
  const [active, setActive] = useState<Ticket | null>(null);

  const refresh = async () => {
    setLoading(true);
    const { data } = await supabase.from("support_tickets").select("*").order("created_at", { ascending: false }).limit(300);
    const ids = Array.from(new Set((data || []).map((t: any) => t.user_id)));
    const [{ data: profiles }, { data: astros }] = await Promise.all([
      ids.length ? supabase.from("profiles").select("id, name, email").in("id", ids) : Promise.resolve({ data: [] as any[] }),
      ids.length ? supabase.from("astrologers").select("user_id").in("user_id", ids) : Promise.resolve({ data: [] as any[] }),
    ]);
    const pn: Record<string, { name: string; email: string }> = {};
    (profiles || []).forEach((p: any) => pn[p.id] = { name: p.name, email: p.email });
    const isAstro = new Set((astros || []).map((a: any) => a.user_id));
    setRows((data || []).map((t: any) => ({
      ...t,
      user_name: pn[t.user_id]?.name || "—",
      user_email: pn[t.user_id]?.email,
      user_role: isAstro.has(t.user_id) ? "astrologer" : "customer",
    })));
    setLoading(false);
  };
  useEffect(() => { refresh(); }, []);

  const counts = useMemo(() => ({
    all: rows.length,
    open: rows.filter(r => r.status === "open").length,
    in_progress: rows.filter(r => r.status === "in_progress").length,
    resolved: rows.filter(r => r.status === "resolved").length,
  }), [rows]);

  const filtered = rows.filter(r => {
    if (tab !== "all" && r.status !== tab) return false;
    if (userTab !== "all" && r.user_role !== userTab) return false;
    return true;
  });

  return (
    <div>
      <AdminPageHeader title="Support" description="Reply to customer and astrologer tickets." />

      <div className="flex flex-wrap items-center gap-3 mb-4">
        <AdminTabs value={tab} onChange={setTab} tabs={[
          { value: "all", label: "All", count: counts.all },
          { value: "open", label: "Open", count: counts.open },
          { value: "in_progress", label: "In Progress", count: counts.in_progress },
          { value: "resolved", label: "Resolved", count: counts.resolved },
        ]} />
        <AdminTabs value={userTab} onChange={setUserTab} tabs={[
          { value: "all", label: "Everyone" },
          { value: "customer", label: "Customers" },
          { value: "astrologer", label: "Astrologers" },
        ]} />
      </div>

      <AdminCard>
        {loading ? <div className="p-10 flex justify-center"><Loader2 className="h-5 w-5 animate-spin text-slate-400" /></div>
        : filtered.length === 0 ? <EmptyState />
        : (
          <div className="divide-y divide-slate-800">
            {filtered.map((t) => (
              <button key={t.id} onClick={() => setActive(t)} className="w-full text-left p-4 hover:bg-slate-800/40 flex items-start gap-3">
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 text-sm">
                    <span className="font-medium text-slate-100 truncate">{t.subject}</span>
                    <StatusBadge status={t.status} />
                    <span className="text-[10px] uppercase text-indigo-300">{t.user_role}</span>
                  </div>
                  <div className="text-xs text-slate-400 mt-1 line-clamp-1">{t.message}</div>
                  <div className="text-[11px] text-slate-500 mt-1">{t.user_name} • {fmtDate(t.created_at)}</div>
                </div>
              </button>
            ))}
          </div>
        )}
      </AdminCard>

      {active && <TicketDetailModal ticket={active} onClose={() => { setActive(null); refresh(); }} />}
    </div>
  );
}

function TicketDetailModal({ ticket, onClose }: { ticket: Ticket; onClose: () => void }) {
  const { toast } = useToast();
  const [replies, setReplies] = useState<any[]>([]);
  const [reply, setReply] = useState("");
  const [status, setStatus] = useState(ticket.status);
  const [loading, setLoading] = useState(true);

  const load = async () => {
    setLoading(true);
    const { data } = await supabase.from("support_ticket_replies").select("*").eq("ticket_id", ticket.id).order("created_at");
    setReplies(data || []); setLoading(false);
  };
  useEffect(() => { load(); }, [ticket.id]);

  const send = async () => {
    if (!reply.trim()) return;
    const r = await callAdminAction("support.reply", { ticket_id: ticket.id, message: reply });
    if (!r.ok) return toast({ title: "Failed", description: r.error, variant: "destructive" });
    setReply(""); toast({ title: "Reply sent" }); load();
  };

  const setTicketStatus = async (s: string) => {
    setStatus(s);
    const r = await callAdminAction("support.set_status", { ticket_id: ticket.id, status: s });
    if (!r.ok) return toast({ title: "Failed", description: r.error, variant: "destructive" });
    toast({ title: "Status updated" });
  };

  return (
    <AdminModal open onClose={onClose} title={ticket.subject}>
      <div className="text-xs text-slate-500 mb-3">
        From <span className="text-slate-300">{ticket.user_name}</span> ({ticket.user_role}) • {fmtDate(ticket.created_at)}
      </div>
      <div className="rounded-md border border-slate-800 bg-slate-950 p-3 text-sm text-slate-200 mb-4 whitespace-pre-wrap">{ticket.message}</div>

      <div className="flex items-center gap-3 mb-3">
        <span className="text-xs uppercase text-slate-500">Status</span>
        <AdminSelect value={status} onChange={(e) => setTicketStatus(e.target.value)}>
          <option value="open">Open</option>
          <option value="in_progress">In Progress</option>
          <option value="resolved">Resolved</option>
        </AdminSelect>
      </div>

      <div className="text-xs uppercase text-slate-500 mb-2">Conversation</div>
      <div className="max-h-72 overflow-y-auto rounded-md border border-slate-800 bg-slate-950 p-3 space-y-2 mb-3">
        {loading ? <div className="text-center py-4"><Loader2 className="h-4 w-4 animate-spin inline text-slate-400" /></div>
        : replies.length === 0 ? <div className="text-xs text-slate-500 text-center py-4">No replies yet</div>
        : replies.map((m: any) => (
          <div key={m.id} className={`flex ${m.author_role === "admin" ? "justify-end" : "justify-start"}`}>
            <div className={`max-w-[80%] px-3 py-2 rounded-lg text-sm ${m.author_role === "admin" ? "bg-indigo-600 text-white" : "bg-slate-800 text-slate-100"}`}>
              <div className="text-[10px] opacity-70 mb-0.5 capitalize">{m.author_role} • {fmtDate(m.created_at)}</div>
              {m.message}
            </div>
          </div>
        ))}
      </div>

      <div className="flex gap-2">
        <AdminTextarea rows={2} value={reply} onChange={(e) => setReply(e.target.value)} placeholder="Reply…" className="flex-1" />
        <AdminButton variant="primary" onClick={send}><Send className="h-3 w-3" /> Send</AdminButton>
      </div>
    </AdminModal>
  );
}
