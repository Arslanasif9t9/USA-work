import { useCallback, useEffect, useMemo, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAdminAuth } from "@/admin/AdminAuthContext";
import { AdminCard, AdminPageHeader, AdminInput, AdminSelect, AdminTable, fmtDate } from "@/admin/ui";
import { useInfiniteList } from "@/hooks/useInfiniteList";

export default function AdminActivity() {
  const { admin } = useAdminAuth();
  const [admins, setAdmins] = useState<any[]>([]);
  const [filterAdmin, setFilterAdmin] = useState<string>("all");
  const [filterAction, setFilterAction] = useState<string>("");
  const [from, setFrom] = useState("");
  const [to, setTo] = useState("");

  useEffect(() => {
    (async () => {
      if (admin?.role === "master_admin") {
        const { data } = await supabase.from("admin_users").select("id, full_name, email, role");
        setAdmins(data || []);
      }
    })();
  }, [admin]);

  const fetchPage = useCallback(async (offset: number, limit: number) => {
    let q = supabase.from("admin_activity_log")
      .select("id, action, target_type, target_id, details, created_at, admin_id")
      .order("created_at", { ascending: false })
      .range(offset, offset + limit - 1);
    if (admin?.role !== "master_admin" && admin?.id) q = q.eq("admin_id", admin.id);
    if (filterAdmin !== "all" && admin?.role === "master_admin") q = q.eq("admin_id", filterAdmin);
    if (filterAction.trim()) q = q.ilike("action", `%${filterAction.trim()}%`);
    if (from) q = q.gte("created_at", new Date(from).toISOString());
    if (to)   q = q.lte("created_at", new Date(to + "T23:59:59").toISOString());
    const { data } = await q;
    return data || [];
  }, [admin, filterAdmin, filterAction, from, to]);

  const { rows, loading, done, sentinelRef, initialLoading } = useInfiniteList<any>(fetchPage, [admin?.id, filterAdmin, filterAction, from, to]);

  const adminMap = useMemo(() => {
    const m = new Map<string, any>();
    admins.forEach((a) => m.set(a.id, a));
    return m;
  }, [admins]);

  return (
    <div className="space-y-6">
      <AdminPageHeader
        title="Activity log"
        description={admin?.role === "master_admin" ? "Every action by every admin." : "Your own activity history."}
      />

      <AdminCard className="p-4">
        <div className="flex flex-wrap gap-3 items-center">
          {admin?.role === "master_admin" && (
            <AdminSelect value={filterAdmin} onChange={(e) => setFilterAdmin(e.target.value)} className="min-w-[200px]">
              <option value="all">All admins</option>
              {admins.map((a) => (
                <option key={a.id} value={a.id}>{a.full_name || a.email} · {a.role}</option>
              ))}
            </AdminSelect>
          )}
          <AdminInput placeholder="Filter by action..." value={filterAction} onChange={(e) => setFilterAction(e.target.value)} className="max-w-xs" />
          <AdminInput type="date" value={from} onChange={(e) => setFrom(e.target.value)} className="w-44" />
          <span className="text-xs text-slate-500">to</span>
          <AdminInput type="date" value={to} onChange={(e) => setTo(e.target.value)} className="w-44" />
        </div>
      </AdminCard>

      <AdminCard>
        <AdminTable
          loading={loading}
          done={done}
          sentinelRef={sentinelRef}
          emptyMessage={!initialLoading && rows.length === 0 ? "No activity matches these filters." : undefined}
        >
          {rows.length > 0 && (
            <table className="admin-table w-full text-sm">
              <thead className="text-[11px] uppercase text-slate-400 border-b border-slate-800">
                <tr>
                  <th className="text-left px-5 py-3">When</th>
                  <th className="text-left">Admin</th>
                  <th className="text-left">Action</th>
                  <th className="text-left">Target</th>
                  <th className="text-left">Details</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800">
                {rows.map((r) => {
                  const a = adminMap.get(r.admin_id);
                  return (
                    <tr key={r.id}>
                      <td className="px-5 py-3 whitespace-nowrap text-slate-400">{fmtDate(r.created_at)}</td>
                      <td>
                        <div className="text-sm">{a?.full_name || a?.email || (admin?.id === r.admin_id ? admin.full_name : "—")}</div>
                        <div className="text-[11px] text-slate-500">{a?.role || (admin?.id === r.admin_id ? admin.role : "")}</div>
                      </td>
                      <td><span className="text-xs px-2 py-0.5 rounded bg-indigo-500/15 text-indigo-300 border border-indigo-500/30">{r.action}</span></td>
                      <td className="text-xs text-slate-400">{r.target_type ? `${r.target_type} · ${r.target_id || "—"}` : "—"}</td>
                      <td className="text-[11px] text-slate-500 truncate max-w-md">
                        <code>{r.details ? JSON.stringify(r.details).slice(0, 120) : ""}</code>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          )}
        </AdminTable>
      </AdminCard>
    </div>
  );
}
