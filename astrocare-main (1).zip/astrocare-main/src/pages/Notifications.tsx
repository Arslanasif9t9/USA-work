import { useEffect, useState } from "react";
import { AppShell } from "@/components/layout/AppShell";
import { ProtectedRoute } from "@/components/auth/ProtectedRoute";
import { Card, CardContent } from "@/components/ui/card";
import { useAuth } from "@/contexts/AuthContext";
import { supabase } from "@/integrations/supabase/client";
import { Bell, Inbox } from "lucide-react";
import { format } from "date-fns";

function NotificationsInner() {
  const { user } = useAuth();
  const [items, setItems] = useState<any[]>([]);

  useEffect(() => {
    if (!user) return;
    let cancelled = false;
    supabase.from("notifications").select("*").eq("user_id", user.id).order("created_at", { ascending: false }).limit(100)
      .then(({ data }) => { if (!cancelled) setItems(data ?? []); });
    return () => { cancelled = true; };
  }, [user]);

  useEffect(() => {
    if (!user) return;
    supabase.from("notifications").update({ read: true }).eq("user_id", user.id).eq("read", false).then(() => {});
  }, [user]);

  return (
    <AppShell mobileTitle="Notifications">
      <div className="container max-w-3xl py-4 md:py-8 space-y-4">
        <div className="hidden md:flex items-center gap-2">
          <Bell className="h-6 w-6 text-primary" />
          <h1 className="font-serif text-3xl font-bold">Notifications</h1>
        </div>
        {items.length === 0 ? (
          <Card><CardContent className="flex flex-col items-center gap-3 p-12 text-center">
            <Inbox className="h-10 w-10 text-muted-foreground" />
            <p className="text-sm text-muted-foreground">No notifications yet.</p>
          </CardContent></Card>
        ) : (
          <div className="space-y-2">
            {items.map((n) => (
              <Card key={n.id}><CardContent className="p-4">
                <div className="flex items-start justify-between gap-3">
                  <div className="min-w-0">
                    <p className="font-semibold">{n.title}</p>
                    {n.body && <p className="mt-1 text-sm text-muted-foreground">{n.body}</p>}
                  </div>
                  <p className="text-xs text-muted-foreground whitespace-nowrap">{format(new Date(n.created_at), "dd MMM, hh:mm a")}</p>
                </div>
              </CardContent></Card>
            ))}
          </div>
        )}
      </div>
    </AppShell>
  );
}

export default function Notifications() {
  return <ProtectedRoute><NotificationsInner /></ProtectedRoute>;
}
