import { useEffect } from "react";
import { Link } from "react-router-dom";
import { AppShell } from "@/components/layout/AppShell";
import { Button } from "@/components/ui/button";
import { CheckCircle2 } from "lucide-react";
import { useWallet } from "@/hooks/useWallet";

export default function RechargeSuccess() {
  const { refresh } = useWallet();

  // Webhook may take a moment; refresh balance a few times
  useEffect(() => {
    const timers = [800, 2500, 5000].map((ms) => setTimeout(refresh, ms));
    return () => timers.forEach(clearTimeout);
  }, [refresh]);

  return (
    <AppShell>
      <div className="container py-16 max-w-md text-center space-y-5">
        <div className="mx-auto h-16 w-16 rounded-full bg-success/10 flex items-center justify-center">
          <CheckCircle2 className="h-9 w-9 text-success" />
        </div>
        <h1 className="text-2xl font-bold">Payment successful</h1>
        <p className="text-muted-foreground">
          Your wallet will be credited within a few seconds. You can start your
          consultation now.
        </p>
        <div className="flex gap-3 justify-center">
          <Link to="/history">
            <Button variant="saffron">Go to history</Button>
          </Link>
          <Link to="/transactions">
            <Button variant="outline">View transactions</Button>
          </Link>
        </div>
      </div>
    </AppShell>
  );
}
