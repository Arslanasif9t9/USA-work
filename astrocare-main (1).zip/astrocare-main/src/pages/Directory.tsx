import { useCallback, useEffect, useMemo, useState } from "react";
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetTrigger } from "@/components/ui/sheet";
import { Button } from "@/components/ui/button";
import { Filter } from "lucide-react";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { AppShell } from "@/components/layout/AppShell";
import { ExpertiseFilter } from "@/components/astrologers/ExpertiseFilter";
import { AstrologerGrid } from "@/components/astrologers/AstrologerGrid";
import { useAstrologerStatus } from "@/hooks/useAstrologerStatus";
import type { Astrologer } from "@/components/astrologers/AstrologerCard";
import { supabase } from "@/integrations/supabase/client";
import { useWallet } from "@/hooks/useWallet";
import { useNavigate } from "react-router-dom";
import { toast } from "@/hooks/use-toast";

type SortKey = "recommended" | "price_asc" | "price_desc" | "rating_desc" | "experience_desc";

export default function Directory() {
  const [astrologers, setAstrologers] = useState<Astrologer[]>([]);
  const [totalCount, setTotalCount] = useState<number | null>(null);
  const [specs, setSpecs] = useState<string[]>([]);
  const [onlineOnly, setOnlineOnly] = useState(false);
  const [sort, setSort] = useState<SortKey>("recommended");
  const [isLoading, setIsLoading] = useState(true);
  const [mobileOpen, setMobileOpen] = useState(false);
  const navigate = useNavigate();
  const { wallet } = useWallet();
  const walletBalance = Number(wallet?.balance ?? 0);

  // Total approved astrologers — for "Showing X of Y" display
  useEffect(() => {
    let cancelled = false;
    supabase
      .from("astrologers")
      .select("id", { count: "exact", head: true })
      .eq("approval_status", "approved")
      .then(({ count }) => { if (!cancelled) setTotalCount(count ?? null); });
    return () => { cancelled = true; };
  }, []);

  const filterBody = useMemo(
    () => ({
      specializations: specs.length ? specs : undefined,
      status: onlineOnly ? "online" : undefined,
      sort,
      limit: 48,
    }),
    [specs, onlineOnly, sort],
  );

  useEffect(() => {
    let cancelled = false;
    setIsLoading(true);
    supabase.functions
      .invoke("get-astrologers", { body: filterBody })
      .then(({ data, error }) => {
        if (cancelled) return;
        if (error) {
          console.error("get-astrologers error", error);
          toast({
            title: "Couldn't load astrologers",
            description: error.message ?? String(error),
            variant: "destructive",
          });
          setAstrologers([]);
        } else {
          setAstrologers((data?.data ?? []) as Astrologer[]);
        }
      })
      .finally(() => !cancelled && setIsLoading(false));
    return () => {
      cancelled = true;
    };
  }, [filterBody]);

  const handleStatusChange = useCallback(
    (id: string, status: Astrologer["status"]) => {
      setAstrologers((prev) => prev.map((a) => (a.id === id ? { ...a, status } : a)));
    },
    [],
  );
  useAstrologerStatus(handleStatusChange);

  const handleReset = () => {
    setSpecs([]);
    setOnlineOnly(false);
    setSort("recommended");
  };

  const handleCall = (a: Astrologer) => {
    const rate = a.discounted_rate_per_min ?? a.base_rate_per_min;
    if (a.first_chat_free) {
      toast({ title: "First chat free", description: `Starting session with ${a.display_name}` });
      return;
    }
    if (walletBalance < rate * 5) {
      toast({
        title: "Top up to continue",
        description: `You need at least ₹${(rate * 5).toFixed(0)} to start a 5-minute call.`,
      });
      navigate("/dashboard");
      return;
    }
    toast({ title: "Connecting…", description: `Starting call with ${a.display_name}` });
  };

  const sortControl = (
    <Select value={sort} onValueChange={(v) => setSort(v as SortKey)}>
      <SelectTrigger className="w-[200px]">
        <SelectValue />
      </SelectTrigger>
      <SelectContent>
        <SelectItem value="recommended">Recommended</SelectItem>
        <SelectItem value="price_asc">Price: Low to High</SelectItem>
        <SelectItem value="price_desc">Price: High to Low</SelectItem>
        <SelectItem value="rating_desc">Highest Rated</SelectItem>
        <SelectItem value="experience_desc">Most Experienced</SelectItem>
      </SelectContent>
    </Select>
  );

  return (
    <AppShell>
      <div className="container mx-auto px-4 py-6">
        <header className="mb-6">
          <h1 className="text-2xl font-bold sm:text-3xl">Find Your Guide</h1>
          <p className="mt-1 text-sm text-muted-foreground">
            Connect with expert astrologers for real-time guidance.
          </p>
        </header>

        <div className="flex gap-6">
          {/* Desktop sidebar */}
          <aside className="hidden w-[260px] shrink-0 lg:block">
            <div className="sticky top-20 rounded-lg border bg-card p-4">
              <ExpertiseFilter
                selected={specs}
                onChange={setSpecs}
                onlineOnly={onlineOnly}
                onOnlineOnlyChange={setOnlineOnly}
                onReset={handleReset}
              />
            </div>
          </aside>

          <main className="min-w-0 flex-1">
            <div className="mb-4 flex items-center justify-between gap-3">
              <p className="text-sm text-muted-foreground">
                {isLoading ? "Loading…" : `Showing ${astrologers.length} of ${totalCount ?? astrologers.length} astrologers`}
              </p>
              <div className="flex items-center gap-2">
                <Sheet open={mobileOpen} onOpenChange={setMobileOpen}>
                  <SheetTrigger asChild>
                    <Button variant="outline" size="sm" className="lg:hidden">
                      <Filter className="mr-2 h-4 w-4" />
                      Filter
                    </Button>
                  </SheetTrigger>
                  <SheetContent side="left" className="w-[300px] overflow-y-auto">
                    <SheetHeader>
                      <SheetTitle>Filter & Sort</SheetTitle>
                    </SheetHeader>
                    <div className="mt-6">
                      <ExpertiseFilter
                        selected={specs}
                        onChange={setSpecs}
                        onlineOnly={onlineOnly}
                        onOnlineOnlyChange={setOnlineOnly}
                        onReset={handleReset}
                      />
                    </div>
                  </SheetContent>
                </Sheet>
                {sortControl}
              </div>
            </div>

            <AstrologerGrid
              astrologers={astrologers}
              walletBalance={walletBalance}
              isLoading={isLoading}
              onCall={handleCall}
              onReset={handleReset}
            />
          </main>
        </div>
      </div>
    </AppShell>
  );
}
