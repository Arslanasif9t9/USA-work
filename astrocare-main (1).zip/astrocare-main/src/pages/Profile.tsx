import { AppShell } from "@/components/layout/AppShell";
import { ProtectedRoute } from "@/components/auth/ProtectedRoute";
import { ProfileForm } from "@/components/profile/ProfileForm";
import { useAuth } from "@/contexts/AuthContext";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Calendar, Clock3, IdCard, MapPin, Receipt } from "lucide-react";

import { useProfile } from "@/hooks/useProfile";

function ProfileInner() {
  const { user } = useAuth();
  const [displayId, setDisplayId] = useState<number | null>(null);
  const { profile } = useProfile();

  useEffect(() => {
    if (!user) return;
    supabase
      .from("profiles")
      .select("user_id_display")
      .eq("id", user.id)
      .maybeSingle()
      .then(({ data }) => setDisplayId(data?.user_id_display ?? null));
  }, [user]);

  return (
    <AppShell mobileTitle="Profile">
      <div className="container py-4 md:py-8 max-w-5xl space-y-4 md:space-y-6">
        <div className="grid gap-4 md:gap-6 lg:grid-cols-[320px_1fr]">
          <div className="space-y-4 md:space-y-6">
            <Card className="shadow-card bg-section border-border">
              <CardContent className="space-y-4 p-4 md:py-6">
                <div className="hidden md:block">
                  <h1 className="text-2xl md:text-3xl font-bold">Profile</h1>
                  <p className="text-sm text-muted-foreground mt-1">
                    Manage your personal details, kundli data, and consultation information.
                  </p>
                </div>

                {displayId && (
                  <div className="flex items-center gap-3 rounded-lg border border-border bg-background p-3 md:p-4">
                    <IdCard className="h-5 w-5 text-primary" />
                    <div>
                      <p className="text-xs text-muted-foreground">User ID</p>
                      <p className="font-semibold tabular-nums">#{displayId}</p>
                    </div>
                  </div>
                )}

                <div className="grid gap-2 md:gap-3">
                  <ProfileInfo icon={Calendar} label="Date of birth" value={profile?.dob ?? "Not added"} />
                  <ProfileInfo icon={Clock3} label="Time of birth" value={profile?.tob ?? "Not added"} />
                  <ProfileInfo icon={MapPin} label="Place of birth" value={profile?.pob_city ? `${profile.pob_city}${profile.pob_state ? `, ${profile.pob_state}` : ""}` : "Not added"} />
                </div>

                <div className="grid gap-2 sm:grid-cols-2 lg:grid-cols-1">
                  <Button variant="outline" asChild>
                    <a href="/history"><Receipt className="h-4 w-4" /> View History</a>
                  </Button>
                  <Button variant="saffron" asChild>
                    <a href="/chart/new">Create Kundli</a>
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>

          <Card className="shadow-card">
            <CardContent className="p-4 md:py-6">
              <ProfileForm />
            </CardContent>
          </Card>
        </div>
      </div>
    </AppShell>
  );
}

function ProfileInfo({ icon: Icon, label, value }: { icon: React.ElementType; label: string; value: string }) {
  return (
    <div className="flex items-start gap-3 rounded-lg border border-border bg-background p-3">
      <Icon className="mt-0.5 h-4 w-4 text-primary" />
      <div className="min-w-0">
        <p className="text-xs text-muted-foreground">{label}</p>
        <p className="text-sm font-medium break-words">{value}</p>
      </div>
    </div>
  );
}

export default function Profile() {
  return (
    <ProtectedRoute>
      <ProfileInner />
    </ProtectedRoute>
  );
}
