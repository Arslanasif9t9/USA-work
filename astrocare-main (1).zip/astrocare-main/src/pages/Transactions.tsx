import { AppShell } from "@/components/layout/AppShell";
import { ProtectedRoute } from "@/components/auth/ProtectedRoute";
import { TransactionHistory } from "@/components/wallet/TransactionHistory";
import { useWallet, formatINR } from "@/hooks/useWallet";

function TransactionsInner() {
  const { wallet } = useWallet();
  return (
    <AppShell mobileTitle="Transactions">
      <div className="container py-4 md:py-8 space-y-4 md:space-y-6">
        <div className="hidden md:flex items-end justify-between flex-wrap gap-3">
          <div>
            <h1 className="text-2xl md:text-3xl font-bold">Transactions</h1>
            <p className="text-sm text-muted-foreground mt-1">
              All wallet movements in reverse chronological order.
            </p>
          </div>
          <div className="text-right">
            <p className="text-xs text-muted-foreground">Current balance</p>
            <p className="text-xl font-bold text-primary tabular-nums">
              {formatINR(wallet?.balance ?? 0)}
            </p>
          </div>
        </div>

        {/* Mobile balance card */}
        <div className="md:hidden rounded-2xl bg-gradient-to-br from-primary/10 via-card to-secondary/10 border border-primary/20 p-4">
          <p className="text-[11px] uppercase tracking-wider text-muted-foreground">Current balance</p>
          <p className="mt-1 text-3xl font-bold text-primary tabular-nums">
            {formatINR(wallet?.balance ?? 0)}
          </p>
        </div>

        <TransactionHistory />
      </div>
    </AppShell>
  );
}

export default function Transactions() {
  return (
    <ProtectedRoute>
      <TransactionsInner />
    </ProtectedRoute>
  );
}
