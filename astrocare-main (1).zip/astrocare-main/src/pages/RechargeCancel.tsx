import { Link } from "react-router-dom";
import { AppShell } from "@/components/layout/AppShell";
import { Button } from "@/components/ui/button";
import { XCircle } from "lucide-react";

export default function RechargeCancel() {
  return (
    <AppShell>
      <div className="container py-16 max-w-md text-center space-y-5">
        <div className="mx-auto h-16 w-16 rounded-full bg-muted flex items-center justify-center">
          <XCircle className="h-9 w-9 text-muted-foreground" />
        </div>
        <h1 className="text-2xl font-bold">Payment cancelled</h1>
        <p className="text-muted-foreground">
          No charge was made. You can try again whenever you're ready.
        </p>
        <div className="flex gap-3 justify-center">
          <Link to="/history">
            <Button variant="saffron">Try again</Button>
          </Link>
          <Link to="/">
            <Button variant="outline">Back to home</Button>
          </Link>
        </div>
      </div>
    </AppShell>
  );
}
