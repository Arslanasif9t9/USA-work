import { AppShell } from "@/components/layout/AppShell";
import { ProtectedRoute } from "@/components/auth/ProtectedRoute";
import { useState } from "react";
import { useTranslation } from "react-i18next";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useWallet, formatINR } from "@/hooks/useWallet";
import { TransactionHistory } from "@/components/wallet/TransactionHistory";
import { RechargeModal } from "@/components/wallet/RechargeModal";
import { Sparkles, Wallet as WalletIcon } from "lucide-react";

const PRESETS = [
  { amt: 100, bonus: 0 },
  { amt: 200, bonus: 0 },
  { amt: 500, bonus: 25 },
  { amt: 1000, bonus: 75 },
];

function WalletInner() {
  const { wallet } = useWallet();
  const [open, setOpen] = useState(false);
  const { t } = useTranslation("common");

  return (
    <AppShell mobileTitle={t("nav.wallet")}>
      <div className="container max-w-4xl py-4 md:py-8 space-y-4 md:space-y-6">
        <Card className="overflow-hidden bg-gradient-to-br from-amber-500/10 via-card to-purple-700/10 border-amber-300/30">
          <CardContent className="p-5 md:p-8">
            <div className="flex items-center gap-2 text-amber-500">
              <WalletIcon className="h-5 w-5" />
              <p className="text-xs md:text-sm font-medium uppercase tracking-wider">{t("wallet.your_wallet")}</p>
            </div>
            <p className="mt-2 text-4xl md:text-5xl font-bold tabular-nums">{formatINR(wallet?.balance ?? 0)}</p>
            <p className="mt-1 text-xs md:text-sm text-muted-foreground">{t("wallet.use_for")}</p>
          </CardContent>
        </Card>

        <div>
          <h2 className="mb-3 font-serif text-xl md:text-2xl font-bold">{t("wallet.add_money")}</h2>
          <div className="grid gap-3 grid-cols-2 lg:grid-cols-4">
            {PRESETS.map((p) => (
              <button
                key={p.amt}
                onClick={() => setOpen(true)}
                className="group relative rounded-2xl border-2 border-border bg-card p-4 md:p-5 text-left transition hover:border-primary hover:shadow-lg active:scale-[0.98]"
              >
                {p.bonus > 0 && (
                  <span className="absolute -top-2 -right-2 inline-flex items-center gap-1 rounded-full bg-amber-500 px-2 py-0.5 text-[10px] font-bold uppercase text-black shadow">
                    <Sparkles className="h-3 w-3" /> +₹{p.bonus}
                  </span>
                )}
                <p className="text-2xl md:text-3xl font-bold">₹{p.amt}</p>
                {p.bonus > 0 ? (
                  <p className="mt-1 text-xs md:text-sm text-emerald-600">{t("wallet.get")} ₹{p.amt + p.bonus}</p>
                ) : (
                  <p className="mt-1 text-xs md:text-sm text-muted-foreground">{t("wallet.quick_top_up")}</p>
                )}
              </button>
            ))}
          </div>
          <Button onClick={() => setOpen(true)} className="mt-4 w-full sm:w-auto">{t("wallet.custom_amount")}</Button>
        </div>

        <Card>
          <CardContent className="p-4 md:p-6">
            <h2 className="mb-3 font-serif text-lg md:text-xl font-bold">{t("wallet.recent_transactions")}</h2>
            <TransactionHistory />
          </CardContent>
        </Card>
      </div>
      <RechargeModal open={open} onOpenChange={setOpen} />
    </AppShell>
  );
}

export default function Wallet() {
  return <ProtectedRoute><WalletInner /></ProtectedRoute>;
}
