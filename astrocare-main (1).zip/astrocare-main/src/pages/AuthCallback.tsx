import { useEffect, useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { Loader2, AlertCircle, CheckCircle2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";

/**
 * Handles Supabase email-link redirects: email verification AND password recovery.
 * - For verification: Supabase sets a session via the URL fragment, we land on /dashboard.
 * - For password recovery: a recovery session is set; we forward to /reset-password.
 */
export default function AuthCallback() {
  const navigate = useNavigate();
  const { toast } = useToast();
  const [status, setStatus] = useState<"loading" | "ok" | "error">("loading");
  const [message, setMessage] = useState("");
  const [resending, setResending] = useState(false);

  const callbackData = useMemo(() => {
    const search = new URLSearchParams(window.location.search);
    const hash = new URLSearchParams(window.location.hash.replace(/^#/, ""));

    const getValue = (key: string) => search.get(key) ?? hash.get(key);

    return {
      code: search.get("code"),
      tokenHash: getValue("token_hash"),
      type: getValue("type"),
      error: getValue("error"),
      errorCode: getValue("error_code"),
      errorDescription: getValue("error_description"),
      accessToken: hash.get("access_token"),
      refreshToken: hash.get("refresh_token"),
      email:
        getValue("email") ?? sessionStorage.getItem("auth:lastVerificationEmail"),
    };
  }, []);

  useEffect(() => {
    let active = true;

    const fail = (nextMessage: string) => {
      if (!active) return;
      setStatus("error");
      setMessage(nextMessage);
    };

    const succeed = (destination: "/dashboard" | "/reset-password") => {
      if (!active) return;
      setStatus("ok");
      window.history.replaceState({}, document.title, window.location.pathname);
      setTimeout(() => navigate(destination, { replace: true }), 800);
    };

    const complete = async () => {
      const isRecovery = callbackData.type === "recovery";

      if (callbackData.error || callbackData.errorCode) {
        const description = callbackData.errorDescription
          ? decodeURIComponent(callbackData.errorDescription.replace(/\+/g, " "))
          : "This link is invalid or has expired. Request a new one and try again.";
        fail(description);
        return;
      }

      if (callbackData.code) {
        const { error } = await supabase.auth.exchangeCodeForSession(callbackData.code);
        if (error) {
          fail(error.message);
          return;
        }
        toast({ title: isRecovery ? "Reset link verified" : "Email verified" });
        succeed(isRecovery ? "/reset-password" : "/dashboard");
        return;
      }

      if (callbackData.tokenHash && callbackData.type) {
        const { error } = await supabase.auth.verifyOtp({
          token_hash: callbackData.tokenHash,
          type: callbackData.type as
            | "signup"
            | "recovery"
            | "invite"
            | "email_change"
            | "email"
            | "magiclink",
        });
        if (error) {
          fail(error.message);
          return;
        }
        toast({ title: isRecovery ? "Reset link verified" : "Email verified" });
        succeed(isRecovery ? "/reset-password" : "/dashboard");
        return;
      }

      if (callbackData.accessToken || callbackData.refreshToken) {
        const { data } = await supabase.auth.getSession();
        if (data.session) {
          toast({ title: isRecovery ? "Reset link verified" : "Email verified" });
          succeed(isRecovery ? "/reset-password" : "/dashboard");
          return;
        }
      }

      fail("This link has expired or already been used. Please request a new one.");
    };

    complete();

    return () => {
      active = false;
    };
  }, [callbackData, navigate, toast]);

  const handleResend = async () => {
    if (!callbackData.email) {
      toast({
        title: "Email address needed",
        description: "Go back and enter your email to request a fresh verification link.",
        variant: "destructive",
      });
      navigate("/", { replace: true });
      return;
    }

    setResending(true);
    const { error } = await supabase.auth.resend({
      type: "signup",
      email: callbackData.email,
      options: {
        emailRedirectTo: `${window.location.origin}/auth/callback`,
      },
    });
    setResending(false);

    if (error) {
      toast({
        title: "Couldn't resend verification email",
        description: error.message,
        variant: "destructive",
      });
      return;
    }

    sessionStorage.setItem("auth:lastVerificationEmail", callbackData.email);
    toast({
      title: "Verification email sent",
      description: `We sent a fresh link to ${callbackData.email}.`,
    });
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-background px-4">
      <div className="max-w-md w-full text-center space-y-4 p-8 rounded-lg border border-border bg-card shadow-card">
        {status === "loading" && (
          <>
            <Loader2 className="h-8 w-8 animate-spin text-primary mx-auto" />
            <h1 className="text-xl font-semibold">Verifying your link…</h1>
            <p className="text-sm text-muted-foreground">
              Hang tight — this only takes a moment.
            </p>
          </>
        )}
        {status === "ok" && (
          <>
            <CheckCircle2 className="h-10 w-10 text-success mx-auto" />
            <h1 className="text-xl font-semibold">All set!</h1>
            <p className="text-sm text-muted-foreground">
              Redirecting you to your dashboard…
            </p>
          </>
        )}
        {status === "error" && (
          <>
            <AlertCircle className="h-10 w-10 text-destructive mx-auto" />
            <h1 className="text-xl font-semibold">Link couldn't be verified</h1>
            <p className="text-sm text-muted-foreground">{message}</p>
            <div className="flex flex-col gap-3">
              <Button variant="saffron" onClick={handleResend} disabled={resending}>
                {resending ? (
                  <>
                    <Loader2 className="h-4 w-4 animate-spin" /> Sending…
                  </>
                ) : (
                  "Request new verification link"
                )}
              </Button>
              <Button variant="outline" onClick={() => navigate("/")}>
                Back to home
              </Button>
            </div>
          </>
        )}
      </div>
    </div>
  );
}
