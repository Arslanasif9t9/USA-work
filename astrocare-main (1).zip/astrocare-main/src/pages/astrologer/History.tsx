import { SessionHistoryList } from "@/components/history/SessionHistoryList";
import { Card, CardContent } from "@/components/ui/card";

export default function AstrologerHistory() {
  return (
    <div className="container max-w-6xl space-y-6 p-6">
      <div>
        <h1 className="font-serif text-3xl font-bold text-white">Session history</h1>
        <p className="text-sm text-white/50">Every consultation you've completed, with earnings and ratings.</p>
      </div>
      <Card className="border-white/10 bg-[#0E1628]">
        <CardContent className="p-6">
          <SessionHistoryList perspective="astrologer" theme="dark" />
        </CardContent>
      </Card>
    </div>
  );
}
