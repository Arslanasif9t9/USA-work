import { useEffect, useState } from "react";
import { useAuth } from "@/contexts/AuthContext";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Bell, CheckCheck } from "lucide-react";
import { format } from "date-fns";
import { Link } from "react-router-dom";
import { toast } from "sonner";

interface Notif {
  id: string;
  title: string;
  body: string | null;
  link: string | null;
  type: string;
  read: boolean;
  created_at: string;
}

export default function AstrologerNotifications() {
  const { user } = useAuth();
  const [items, setItems] = useState<Notif[]>([]);
  const [loading, setLoading] = useState(true);

  const load = async () => {
    if (!user) return;
    const { data } = await supabase
      .from("notifications")
      .select("*")
      .eq("user_id", user.id)
      .order("created_at", { ascending: false })
      .limit(100);
    setItems((data ?? []) as Notif[]);
    setLoading(false);
  };

  useEffect(() => {
    load();
    if (!user) return;
    const ch = supabase
      .channel(`notif-page-${user.id}`)
      .on("postgres_changes", { event: "*", schema: "public", table: "notifications", filter: `user_id=eq.${user.id}` }, load)
      .subscribe();
    return () => { supabase.removeChannel(ch); };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [user]);

  const markAllRead = async () => {
    if (!user) return;
    const { error } = await supabase.from("notifications").update({ read: true }).eq("user_id", user.id).eq("read", false);
    if (error) toast.error(error.message);
    else load();
  };

  const markOne = async (id: string) => {
    await supabase.from("notifications").update({ read: true }).eq("id", id);
    setItems((s) => s.map((n) => n.id === id ? { ...n, read: true } : n));
  };

  return (
    <div className="container max-w-4xl space-y-6 p-6">
      <div className="flex items-end justify-between flex-wrap gap-3">
        <div>
          <h1 className="font-serif text-3xl font-bold text-white">Notifications</h1>
          <p className="text-sm text-white/50">Session requests, earnings, reviews, withdrawals.</p>
        </div>
        <Button onClick={markAllRead} variant="outline" className="border-white/20 bg-transparent text-white hover:bg-white/10">
          <CheckCheck className="mr-2 h-4 w-4" /> Mark all read
        </Button>
      </div>

      <Card className="border-white/10 bg-[#0E1628]">
        <CardContent className="p-0">
          {loading ? (
            <p className="p-6 text-white/50">Loading…</p>
          ) : items.length === 0 ? (
            <div className="flex flex-col items-center gap-3 p-12 text-center">
              <div className="rounded-full bg-amber-300/10 p-4 text-amber-300"><Bell className="h-8 w-8" /></div>
              <p className="text-white/70">No notifications yet</p>
              <p className="text-xs text-white/40">You'll be notified about new session requests, earnings, and more.</p>
            </div>
          ) : (
            <ul className="divide-y divide-white/5">
              {items.map((n) => {
                const inner = (
                  <div className="flex items-start gap-3 px-5 py-4 hover:bg-white/5">
                    <div className={`mt-0.5 h-2 w-2 rounded-full ${n.read ? "bg-white/20" : "bg-amber-300"}`} />
                    <div className="min-w-0 flex-1">
                      <p className={`truncate text-sm ${n.read ? "text-white/60" : "text-white font-semibold"}`}>{n.title}</p>
                      {n.body && <p className="mt-0.5 text-xs text-white/50">{n.body}</p>}
                      <p className="mt-1 text-[10px] text-white/30">{format(new Date(n.created_at), "dd MMM, hh:mm a")}</p>
                    </div>
                  </div>
                );
                return (
                  <li key={n.id} onClick={() => !n.read && markOne(n.id)}>
                    {n.link ? <Link to={n.link}>{inner}</Link> : inner}
                  </li>
                );
              })}
            </ul>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
