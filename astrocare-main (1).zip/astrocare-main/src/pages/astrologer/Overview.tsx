import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { useAstrologerAccount } from "@/hooks/useAstrologerAccount";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { toast } from "sonner";
import { TrendingUp, Star, Clock, Wallet, ArrowRight, Activity, Phone } from "lucide-react";
import { format, startOfMonth, subDays, isSameDay } from "date-fns";
import {
  ResponsiveContainer,
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
} from "recharts";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { AllLiveNowSection } from "@/components/live/AllLiveNowSection";

function StatCard({ label, value, icon: Icon, accent = "amber" }: any) {
  const palette: any = {
    amber: "from-amber-500/20 to-amber-500/5 text-amber-200 border-amber-300/20",
    emerald: "from-emerald-500/20 to-emerald-500/5 text-emerald-200 border-emerald-300/20",
    indigo: "from-indigo-500/20 to-indigo-500/5 text-indigo-200 border-indigo-300/20",
    rose: "from-rose-500/20 to-rose-500/5 text-rose-200 border-rose-300/20",
  };
  return (
    <div className={`rounded-2xl border bg-gradient-to-br ${palette[accent]} p-5`}>
      <div className="flex items-center justify-between">
        <p className="text-xs font-medium uppercase tracking-wider opacity-80">{label}</p>
        <Icon className="h-4 w-4 opacity-70" />
      </div>
      <p className="mt-2 text-3xl font-bold">{value}</p>
    </div>
  );
}

export default function AstrologerOverview() {
  const { astro, refresh } = useAstrologerAccount();
  const navigate = useNavigate();
  const [stats, setStats] = useState({ earningsMonth: 0, sessionsMonth: 0, minutesMonth: 0 });
  const [chartData, setChartData] = useState<{ date: string; earnings: number }[]>([]);
  const [recent, setRecent] = useState<any[]>([]);
  const [activeSession, setActiveSession] = useState<any>(null);
  const [savingCallToggle, setSavingCallToggle] = useState(false);

  const toggleAcceptingCalls = async (next: boolean) => {
    if (!astro) return;
    if (next && !astro.phone_number) {
      toast.error("Add your phone number in profile to enable call service");
      return;
    }
    setSavingCallToggle(true);
    const { error } = await supabase
      .from("astrologers")
      .update({ accepting_calls: next })
      .eq("id", astro.id);
    setSavingCallToggle(false);
    if (error) { toast.error(error.message); return; }
    toast.success(next ? "Now accepting calls" : "Calls turned off");
    await refresh();
  };

  useEffect(() => {
    if (!astro) return;
    let cancelled = false;
    (async () => {
      const monthStart = startOfMonth(new Date()).toISOString();
      const [{ data: chats }, { data: calls }, { data: gifts }] = await Promise.all([
        supabase
          .from("chat_sessions")
          .select("id, ended_at, duration_seconds, astrologer_earning, total_cost, user_id, created_at, status")
          .eq("astrologer_id", astro.id)
          .order("created_at", { ascending: false }),
        supabase
          .from("call_sessions")
          .select("id, ended_at, duration_seconds, astrologer_earning, total_cost, user_id, created_at, status")
          .eq("astrologer_id", astro.id)
          .order("created_at", { ascending: false }),
        supabase
          .from("gifts")
          .select("id, astrologer_earning, created_at, user_id")
          .eq("astrologer_id", astro.id)
          .order("created_at", { ascending: false }),
      ]);
      if (cancelled) return;

      const endedChats = (chats ?? []).filter((c: any) => c.status === "ended");
      const endedCalls = (calls ?? []).filter((c: any) => c.status === "ended" || c.status === "completed");

      const allEarnings: { ended_at: string; astrologer_earning: number; duration_seconds?: number }[] = [
        ...endedChats.map((c: any) => ({ ended_at: c.ended_at, astrologer_earning: Number(c.astrologer_earning ?? 0), duration_seconds: c.duration_seconds })),
        ...endedCalls.map((c: any) => ({ ended_at: c.ended_at, astrologer_earning: Number(c.astrologer_earning ?? 0), duration_seconds: c.duration_seconds })),
        ...(gifts ?? []).map((g: any) => ({ ended_at: g.created_at, astrologer_earning: Number(g.astrologer_earning ?? 0) })),
      ];

      const monthEntries = allEarnings.filter((e) => e.ended_at && e.ended_at >= monthStart);
      const earnings = monthEntries.reduce((s, e) => s + e.astrologer_earning, 0);
      const sessionsMonth = endedChats.filter((c: any) => c.ended_at && c.ended_at >= monthStart).length
        + endedCalls.filter((c: any) => c.ended_at && c.ended_at >= monthStart).length;
      const minutes = monthEntries.reduce((s, e) => s + Math.ceil((e.duration_seconds ?? 0) / 60), 0);

      setStats({ earningsMonth: earnings, sessionsMonth, minutesMonth: minutes });

      // 30-day chart from all earning sources
      const days: { date: string; earnings: number }[] = [];
      for (let i = 29; i >= 0; i--) {
        const d = subDays(new Date(), i);
        const total = allEarnings
          .filter((e) => e.ended_at && isSameDay(new Date(e.ended_at), d))
          .reduce((s, e) => s + e.astrologer_earning, 0);
        days.push({ date: format(d, "dd MMM"), earnings: total });
      }
      setChartData(days);

      // Recent sessions w/ customer details (mix chat + call)
      const recentSessions = [...endedChats, ...endedCalls]
        .sort((a: any, b: any) => new Date(b.ended_at ?? b.created_at).getTime() - new Date(a.ended_at ?? a.created_at).getTime())
        .slice(0, 5);
      const userIds = Array.from(new Set(recentSessions.map((c: any) => c.user_id)));
      const { data: profiles } = userIds.length
        ? await supabase.from("profiles").select("id, name, avatar_url").in("id", userIds)
        : { data: [] as any[] };
      const map = new Map((profiles ?? []).map((p: any) => [p.id, p]));
      setRecent(recentSessions.map((c: any) => ({ ...c, customer: map.get(c.user_id) })));

      // Active session
      const active = (chats ?? []).find((c: any) => c.status === "active");
      setActiveSession(active ?? null);
    })();
    return () => {
      cancelled = true;
    };
  }, [astro]);

  return (
    <>
      <div className="container max-w-7xl space-y-6 p-6">
        <div className="flex flex-wrap items-end justify-between gap-3">
          <div>
            <p className="text-sm text-white/50">Welcome back</p>
            <h1 className="font-serif text-3xl font-bold text-white">{astro?.display_name ?? "—"}</h1>
          </div>
          <Button onClick={() => navigate("/astrologer/profile")} variant="outline" className="border-amber-300/30 bg-amber-300/10 text-amber-200 hover:bg-amber-300/20 hover:text-amber-100">
            Edit Profile <ArrowRight className="ml-1 h-4 w-4" />
          </Button>
        </div>

        {activeSession && (
          <div className="flex items-center justify-between rounded-2xl border border-emerald-300/30 bg-emerald-500/10 p-4">
            <div className="flex items-center gap-3">
              <span className="relative flex h-3 w-3">
                <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-emerald-400 opacity-75" />
                <span className="relative inline-flex h-3 w-3 rounded-full bg-emerald-500" />
              </span>
              <p className="font-semibold text-emerald-100">Live session in progress</p>
            </div>
            <Button onClick={() => navigate(`/chat/${activeSession.id}`)} className="bg-emerald-500 text-black hover:bg-emerald-400">
              Return to session <ArrowRight className="ml-1 h-4 w-4" />
            </Button>
          </div>
        )}

        {/* FIX 9: Available for Calls toggle (with phone-number guard) */}
        {astro && (
          <div className="flex items-center justify-between rounded-2xl border border-amber-300/20 bg-amber-500/5 p-4">
            <div className="flex items-center gap-3">
              <div className="flex h-10 w-10 items-center justify-center rounded-full bg-amber-500/20">
                <Phone className="h-5 w-5 text-amber-300" />
              </div>
              <div>
                <p className="font-semibold text-white">Available for Calls</p>
                <p className="text-xs text-white/60">
                  {astro.phone_number
                    ? "Customers can call you when you're online."
                    : "Add your phone number in profile to enable call service"}
                </p>
              </div>
            </div>
            <Switch
              checked={!!astro.accepting_calls && !!astro.phone_number}
              disabled={savingCallToggle || !astro.phone_number}
              onCheckedChange={toggleAcceptingCalls}
            />
          </div>
        )}

        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          <StatCard label="Earnings (this month)" value={`₹${stats.earningsMonth.toFixed(0)}`} icon={Wallet} accent="amber" />
          <StatCard label="Sessions (this month)" value={stats.sessionsMonth} icon={Activity} accent="emerald" />
          <StatCard label="Avg rating" value={Number(astro?.rating_avg ?? 0).toFixed(1)} icon={Star} accent="indigo" />
          <StatCard label="Minutes consulted" value={stats.minutesMonth} icon={Clock} accent="rose" />
        </div>

        <Card className="border-white/10 bg-[#0E1628] text-white">
          <CardContent className="p-6">
            <div className="mb-4 flex items-center justify-between">
              <p className="font-semibold">Earnings — last 30 days</p>
              <TrendingUp className="h-4 w-4 text-emerald-300" />
            </div>
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={chartData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.07)" />
                  <XAxis dataKey="date" stroke="rgba(255,255,255,0.5)" fontSize={11} />
                  <YAxis stroke="rgba(255,255,255,0.5)" fontSize={11} />
                  <Tooltip
                    contentStyle={{ background: "#0E1628", border: "1px solid rgba(255,255,255,0.1)", borderRadius: 8, color: "#fff" }}
                    formatter={(v: any) => [`₹${v}`, "Earnings"]}
                  />
                  <Line type="monotone" dataKey="earnings" stroke="#fbbf24" strokeWidth={2} dot={false} />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>

        <Card className="border-white/10 bg-[#0E1628] text-white">
          <CardContent className="p-6">
            <div className="mb-3 flex items-center justify-between">
              <p className="font-semibold">Recent sessions</p>
              <Button variant="ghost" onClick={() => navigate("/astrologer/sessions")} className="h-7 text-amber-200 hover:bg-white/5">
                View all <ArrowRight className="ml-1 h-3 w-3" />
              </Button>
            </div>
            {recent.length === 0 ? (
              <p className="py-6 text-center text-sm text-white/50">No sessions yet.</p>
            ) : (
              <div className="space-y-2">
                {recent.map((r) => {
                  const cust = r.customer;
                  const initials = (cust?.name ?? "U").split(" ").map((p: string) => p[0]).join("").slice(0, 2).toUpperCase();
                  const min = Math.ceil((r.duration_seconds ?? 0) / 60);
                  return (
                    <div key={r.id} className="flex items-center gap-3 rounded-xl border border-white/5 bg-white/5 p-3">
                      <Avatar className="h-10 w-10">
                        <AvatarImage src={cust?.avatar_url ?? undefined} alt={cust?.name} className="object-cover" />
                        <AvatarFallback className="bg-amber-500/20 text-amber-200">{initials}</AvatarFallback>
                      </Avatar>
                      <div className="min-w-0 flex-1">
                        <p className="truncate text-sm font-semibold">{cust?.name ?? "Customer"}</p>
                        <p className="text-xs text-white/50">{format(new Date(r.created_at), "dd MMM, hh:mm a")} · {min} min</p>
                      </div>
                      <p className="text-sm font-bold text-emerald-300">+ ₹{Number(r.astrologer_earning ?? 0).toFixed(0)}</p>
                    </div>
                  );
                })}
              </div>
            )}
          </CardContent>
        </Card>

        <AllLiveNowSection />
      </div>
    </>
  );
}
