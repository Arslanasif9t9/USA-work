import { useEffect, useRef, useState } from "react";
import { useNavigate } from "react-router-dom";
import { useAstrologerAccount } from "@/hooks/useAstrologerAccount";
import { useAuth } from "@/contexts/AuthContext";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { PhoneVerificationModal } from "@/components/profile/PhoneVerificationModal";
import { Camera, Eye, Loader2, Phone, ShieldCheck, ShieldAlert } from "lucide-react";
import { toast } from "sonner";

export default function AstrologerProfile() {
  const { astro, refresh } = useAstrologerAccount();
  const { user } = useAuth();
  const navigate = useNavigate();
  const [form, setForm] = useState<any>(null);
  const [saving, setSaving] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [phoneOpen, setPhoneOpen] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (!astro) return;
    setForm({
      display_name: astro.display_name,
      bio: astro.bio ?? "",
      avatar_url: astro.avatar_url ?? "",
      experience_years: astro.experience_years,
      base_rate_per_min: astro.base_rate_per_min,
      chat_rate_per_min: astro.chat_rate_per_min,
      specializations: (astro.specializations ?? []).join(", "),
      languages: (astro.languages ?? []).join(", "),
      education: astro.education ?? "",
      focus_area: astro.focus_area ?? "",
      systems_known: (astro.systems_known ?? []).join(", "),
    });
  }, [astro]);

  const onUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !user || !astro) return;
    if (file.size > 5 * 1024 * 1024) { toast.error("Max 5 MB"); return; }
    setUploading(true);
    const ext = file.name.split(".").pop() || "jpg";
    const path = `${user.id}/astro-${Date.now()}.${ext}`;
    const { error: upErr } = await supabase.storage.from("avatars").upload(path, file, { upsert: true, contentType: file.type });
    if (upErr) { setUploading(false); toast.error(upErr.message); return; }
    const { data: pub } = supabase.storage.from("avatars").getPublicUrl(path);
    const url = pub.publicUrl;
    const { error: updErr } = await supabase.from("astrologers").update({ avatar_url: url }).eq("id", astro.id);
    setUploading(false);
    if (updErr) { toast.error(updErr.message); return; }
    setForm((s: any) => ({ ...s, avatar_url: url }));
    refresh();
    toast.success("Profile photo updated — visible to all customers");
  };

  const save = async () => {
    if (!astro || !form) return;
    setSaving(true);
    const { error } = await supabase.from("astrologers").update({
      display_name: form.display_name,
      bio: form.bio || null,
      avatar_url: form.avatar_url || null,
      experience_years: Number(form.experience_years) || 0,
      base_rate_per_min: Number(form.base_rate_per_min) || 0,
      chat_rate_per_min: Number(form.chat_rate_per_min) || 0,
      specializations: form.specializations.split(",").map((s: string) => s.trim()).filter(Boolean),
      languages: form.languages.split(",").map((s: string) => s.trim()).filter(Boolean),
      education: form.education || null,
      focus_area: form.focus_area || null,
      systems_known: form.systems_known.split(",").map((s: string) => s.trim()).filter(Boolean),
    }).eq("id", astro.id);
    setSaving(false);
    if (error) toast.error(error.message);
    else { toast.success("Profile updated"); refresh(); }
  };

  if (!form) return <div className="p-6 text-white/60">Loading…</div>;

  const initials = (form.display_name ?? "A").split(" ").map((p: string) => p[0]).join("").slice(0, 2).toUpperCase();

  return (
    <div className="container max-w-4xl space-y-6 p-6">
      <div className="flex items-end justify-between flex-wrap gap-3">
        <div>
          <h1 className="font-serif text-3xl font-bold text-white">Profile</h1>
          <p className="text-sm text-white/50">Edit how customers see you on AstroCare.</p>
        </div>
        {astro && (
          <Button
            variant="outline"
            onClick={() => window.open(`/astrologer/preview/${astro.slug}`, "_blank")}
            className="border-white/20 bg-transparent text-white hover:bg-white/10"
          >
            <Eye className="mr-2 h-4 w-4" /> Preview public profile
          </Button>
        )}
      </div>

      {/* Photo + identity */}
      <Card className="border-white/10 bg-[#0E1628]">
        <CardContent className="p-6 space-y-5">
          <div className="flex items-center gap-2">
            <span className="h-1.5 w-1.5 rounded-full bg-amber-300" />
            <p className="text-[11px] font-semibold uppercase tracking-wider text-amber-200/80">Profile photo</p>
          </div>
          <div className="flex flex-col sm:flex-row items-start sm:items-center gap-5">
            <div className="relative">
              <Avatar className="h-28 w-28 ring-2 ring-amber-300/40">
                <AvatarImage src={form.avatar_url || undefined} alt={form.display_name} className="object-cover" />
                <AvatarFallback className="bg-amber-500/20 text-amber-200 text-2xl">{initials}</AvatarFallback>
              </Avatar>
              <button
                type="button"
                onClick={() => fileRef.current?.click()}
                disabled={uploading}
                className="absolute -bottom-1 -right-1 grid h-10 w-10 place-items-center rounded-full bg-amber-500 text-black shadow-lg hover:bg-amber-400 disabled:opacity-50"
              >
                {uploading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Camera className="h-4 w-4" />}
              </button>
              <input ref={fileRef} type="file" accept="image/*" className="hidden" onChange={onUpload} />
            </div>
            <div className="space-y-1.5 flex-1">
              <p className="font-semibold text-white">Upload from your computer</p>
              <p className="text-xs text-white/50">JPG or PNG, max 5 MB. This image is shown to all customers across the app.</p>
              <p className="text-[10px] text-white/30">Tip: a clear, smiling close-up performs best.</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Public identity */}
      <Card className="border-white/10 bg-[#0E1628]">
        <CardContent className="p-6 space-y-5">
          <div className="flex items-center gap-2">
            <span className="h-1.5 w-1.5 rounded-full bg-amber-300" />
            <p className="text-[11px] font-semibold uppercase tracking-wider text-amber-200/80">Public identity</p>
          </div>
          <div className="grid gap-4 sm:grid-cols-2">
            <Field label="Display name"><Input value={form.display_name} onChange={(e) => setForm({ ...form, display_name: e.target.value })} className="bg-white/5 border-white/10 text-white" /></Field>
            <Field label="Avatar URL (optional)"><Input value={form.avatar_url} onChange={(e) => setForm({ ...form, avatar_url: e.target.value })} placeholder="Leave blank if you uploaded a photo" className="bg-white/5 border-white/10 text-white" /></Field>
          </div>
          <Field label="Bio"><Textarea rows={5} value={form.bio} onChange={(e) => setForm({ ...form, bio: e.target.value })} placeholder="Tell customers about your journey, style, and what to expect…" className="bg-white/5 border-white/10 text-white" /></Field>
        </CardContent>
      </Card>

      {/* Phone for calls */}
      <Card className="border-white/10 bg-[#0E1628]">
        <CardContent className="p-6 space-y-4">
          <div className="flex items-center gap-2">
            <span className="h-1.5 w-1.5 rounded-full bg-amber-300" />
            <p className="text-[11px] font-semibold uppercase tracking-wider text-amber-200/80">Phone for calls</p>
          </div>
          <div className="flex flex-col sm:flex-row sm:items-center gap-4 justify-between">
            <div className="flex items-center gap-3">
              <Phone className="h-5 w-5 text-amber-300" />
              <div>
                <p className="text-white font-medium">
                  {astro?.phone_number || "No number added"}
                </p>
                <div className="mt-1">
                  {(astro as any)?.phone_verified ? (
                    <Badge className="bg-emerald-500/15 text-emerald-300 border border-emerald-400/30">
                      <ShieldCheck className="mr-1 h-3 w-3" /> Verified — eligible for calls
                    </Badge>
                  ) : (
                    <Badge className="bg-rose-500/15 text-rose-300 border border-rose-400/30">
                      <ShieldAlert className="mr-1 h-3 w-3" /> Not verified — required to receive calls
                    </Badge>
                  )}
                </div>
              </div>
            </div>
            <Button
              onClick={() => setPhoneOpen(true)}
              className="bg-amber-500 text-black hover:bg-amber-400"
            >
              {astro?.phone_number ? ((astro as any)?.phone_verified ? "Re-verify" : "Verify Now") : "Add Phone Number"}
            </Button>
          </div>
          <PhoneVerificationModal
            open={phoneOpen}
            onClose={() => { setPhoneOpen(false); refresh(); }}
            userType="astrologer"
            initialPhone={astro?.phone_number ?? null}
          />
        </CardContent>
      </Card>

      {/* Rates */}
      <Card className="border-white/10 bg-[#0E1628]">
        <CardContent className="p-6 space-y-5">
          <div className="flex items-center gap-2">
            <span className="h-1.5 w-1.5 rounded-full bg-amber-300" />
            <p className="text-[11px] font-semibold uppercase tracking-wider text-amber-200/80">Rates &amp; experience</p>
          </div>
          <div className="grid gap-4 sm:grid-cols-3">
            <Field label="Experience (years)"><Input type="number" value={form.experience_years} onChange={(e) => setForm({ ...form, experience_years: e.target.value })} className="bg-white/5 border-white/10 text-white" /></Field>
            <Field label="Call rate ₹/min"><Input type="number" value={form.base_rate_per_min} onChange={(e) => setForm({ ...form, base_rate_per_min: e.target.value })} className="bg-white/5 border-white/10 text-white" /></Field>
            <Field label="Chat rate ₹/min"><Input type="number" value={form.chat_rate_per_min} onChange={(e) => setForm({ ...form, chat_rate_per_min: e.target.value })} className="bg-white/5 border-white/10 text-white" /></Field>
          </div>
        </CardContent>
      </Card>

      {/* Expertise */}
      <Card className="border-white/10 bg-[#0E1628]">
        <CardContent className="p-6 space-y-5">
          <div className="flex items-center gap-2">
            <span className="h-1.5 w-1.5 rounded-full bg-amber-300" />
            <p className="text-[11px] font-semibold uppercase tracking-wider text-amber-200/80">Expertise</p>
          </div>
          <Field label="Specializations (comma-separated)"><Input value={form.specializations} onChange={(e) => setForm({ ...form, specializations: e.target.value })} placeholder="Love, Career, Marriage…" className="bg-white/5 border-white/10 text-white" /></Field>
          <Field label="Languages (comma-separated)"><Input value={form.languages} onChange={(e) => setForm({ ...form, languages: e.target.value })} placeholder="Hindi, English, Tamil…" className="bg-white/5 border-white/10 text-white" /></Field>
          <Field label="Systems known (comma-separated)"><Input value={form.systems_known} onChange={(e) => setForm({ ...form, systems_known: e.target.value })} placeholder="Vedic, KP, Lal Kitab…" className="bg-white/5 border-white/10 text-white" /></Field>
          <div className="grid gap-4 sm:grid-cols-2">
            <Field label="Education"><Input value={form.education} onChange={(e) => setForm({ ...form, education: e.target.value })} className="bg-white/5 border-white/10 text-white" /></Field>
            <Field label="Focus area"><Input value={form.focus_area} onChange={(e) => setForm({ ...form, focus_area: e.target.value })} className="bg-white/5 border-white/10 text-white" /></Field>
          </div>
        </CardContent>
      </Card>

      <div className="sticky bottom-4 flex justify-end">
        <Button onClick={save} disabled={saving} className="bg-amber-500 text-black hover:bg-amber-400 shadow-lg shadow-amber-500/20">
          {saving ? "Saving…" : "Save all changes"}
        </Button>
      </div>
    </div>
  );
}

function Field({ label, children }: any) {
  return (
    <div className="space-y-1.5">
      <Label className="text-white/80">{label}</Label>
      {children}
    </div>
  );
}
