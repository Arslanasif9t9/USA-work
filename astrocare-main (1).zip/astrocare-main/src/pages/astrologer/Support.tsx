import { useEffect, useState } from "react";
import { useAuth } from "@/contexts/AuthContext";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { toast } from "sonner";
import { format } from "date-fns";

export default function AstrologerSupport() {
  const { user } = useAuth();
  const [subject, setSubject] = useState("");
  const [message, setMessage] = useState("");
  const [tickets, setTickets] = useState<any[]>([]);
  const [submitting, setSubmitting] = useState(false);

  const load = async () => {
    if (!user) return;
    const { data } = await supabase.from("support_tickets").select("*").eq("user_id", user.id).order("created_at", { ascending: false });
    setTickets(data ?? []);
  };

  useEffect(() => { load(); /* eslint-disable-next-line */ }, [user]);

  const submit = async () => {
    if (!user || !subject.trim() || !message.trim()) return;
    setSubmitting(true);
    const { error } = await supabase.from("support_tickets").insert({ user_id: user.id, subject: subject.trim(), message: message.trim() });
    setSubmitting(false);
    if (error) toast.error(error.message);
    else { toast.success("Ticket submitted"); setSubject(""); setMessage(""); load(); }
  };

  return (
    <>
      <div className="container max-w-3xl space-y-6 p-6">
        <div>
          <h1 className="font-serif text-3xl font-bold text-white">Support</h1>
          <p className="text-sm text-white/50">Need help? Send us a message.</p>
        </div>
        <Card className="border-white/10 bg-[#0E1628]">
          <CardContent className="p-6 space-y-3">
            <Input value={subject} onChange={(e) => setSubject(e.target.value)} placeholder="Subject" className="bg-white/5 border-white/10 text-white" />
            <Textarea value={message} onChange={(e) => setMessage(e.target.value)} rows={5} placeholder="How can we help?" className="bg-white/5 border-white/10 text-white" />
            <Button onClick={submit} disabled={submitting} className="bg-amber-500 text-black hover:bg-amber-400">{submitting ? "Sending…" : "Submit ticket"}</Button>
          </CardContent>
        </Card>

        <Card className="border-white/10 bg-[#0E1628]">
          <CardContent className="p-6">
            <p className="mb-3 font-semibold text-white">Your tickets</p>
            {tickets.length === 0 ? (
              <p className="text-sm text-white/50">No tickets yet.</p>
            ) : (
              <div className="space-y-2">
                {tickets.map((t) => (
                  <div key={t.id} className="rounded-lg border border-white/5 bg-white/5 p-3">
                    <div className="flex items-center justify-between">
                      <p className="font-semibold text-white">{t.subject}</p>
                      <span className="text-xs text-amber-200">{t.status}</span>
                    </div>
                    <p className="mt-1 text-sm text-white/70">{t.message}</p>
                    <p className="mt-1 text-[11px] text-white/40">{format(new Date(t.created_at), "dd MMM yyyy, hh:mm a")}</p>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </>
  );
}
