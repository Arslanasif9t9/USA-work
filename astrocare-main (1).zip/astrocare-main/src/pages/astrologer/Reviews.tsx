import { useEffect, useState } from "react";
import { useAstrologerAccount } from "@/hooks/useAstrologerAccount";
import { useAuth } from "@/contexts/AuthContext";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Star } from "lucide-react";
import { format } from "date-fns";
import { toast } from "sonner";

export default function AstrologerReviews() {
  const { astro } = useAstrologerAccount();
  const { user } = useAuth();
  const [reviews, setReviews] = useState<any[]>([]);
  const [replies, setReplies] = useState<Record<string, any>>({});
  const [draft, setDraft] = useState<Record<string, string>>({});

  useEffect(() => {
    if (!astro) return;
    let cancelled = false;
    (async () => {
      const { data: rs } = await supabase
        .from("reviews")
        .select("id, user_id, rating, comment, created_at")
        .eq("astrologer_id", astro.id)
        .eq("moderation_status", "approved")
        .order("created_at", { ascending: false });
      if (cancelled) return;
      const list = rs ?? [];
      const userIds = Array.from(new Set(list.map((r: any) => r.user_id)));
      const { data: profiles } = userIds.length
        ? await supabase.from("profiles").select("id, name, avatar_url").in("id", userIds)
        : { data: [] as any[] };
      const map = new Map((profiles ?? []).map((p: any) => [p.id, p]));
      setReviews(list.map((r: any) => ({ ...r, customer: map.get(r.user_id) })));

      const { data: rep } = await supabase.from("review_replies").select("*").in("review_id", list.map((r: any) => r.id));
      const repMap: any = {};
      (rep ?? []).forEach((x: any) => { repMap[x.review_id] = x; });
      setReplies(repMap);
    })();
    return () => { cancelled = true; };
  }, [astro]);

  const submitReply = async (reviewId: string) => {
    if (!user) return;
    const text = (draft[reviewId] ?? "").trim();
    if (!text) return;
    const { data, error } = await supabase
      .from("review_replies")
      .upsert({ review_id: reviewId, astrologer_user_id: user.id, reply: text }, { onConflict: "review_id" })
      .select("*")
      .single();
    if (error) { toast.error(error.message); return; }
    setReplies((p) => ({ ...p, [reviewId]: data }));
    setDraft((d) => ({ ...d, [reviewId]: "" }));
    toast.success("Reply posted");
  };

  const buckets = [5, 4, 3, 2, 1].map((n) => ({
    n,
    count: reviews.filter((r) => Math.round(r.rating) === n).length,
  }));
  const total = reviews.length;
  const avg = total ? reviews.reduce((s, r) => s + r.rating, 0) / total : 0;

  return (
    <>
      <div className="container max-w-5xl space-y-6 p-6">
        <div>
          <h1 className="font-serif text-3xl font-bold text-white">Reviews</h1>
          <p className="text-sm text-white/50">What customers say about you.</p>
        </div>

        <Card className="border-white/10 bg-[#0E1628]">
          <CardContent className="p-6 grid gap-6 sm:grid-cols-[auto_1fr] items-center">
            <div className="text-center">
              <p className="text-5xl font-bold text-amber-300">{avg.toFixed(1)}</p>
              <div className="mt-1 flex justify-center">
                {Array.from({ length: 5 }).map((_, i) => (
                  <Star key={i} className={`h-4 w-4 ${i < Math.round(avg) ? "fill-amber-400 text-amber-400" : "text-white/20"}`} />
                ))}
              </div>
              <p className="mt-1 text-xs text-white/50">{total} reviews</p>
            </div>
            <div className="space-y-1.5">
              {buckets.map((b) => {
                const pct = total ? (b.count / total) * 100 : 0;
                return (
                  <div key={b.n} className="flex items-center gap-2 text-xs">
                    <span className="w-6 text-white/60">{b.n}★</span>
                    <div className="h-2 flex-1 overflow-hidden rounded bg-white/5">
                      <div className="h-full bg-amber-400" style={{ width: `${pct}%` }} />
                    </div>
                    <span className="w-8 text-right text-white/50">{b.count}</span>
                  </div>
                );
              })}
            </div>
          </CardContent>
        </Card>

        {reviews.length === 0 ? (
          <Card className="border-white/10 bg-[#0E1628]">
            <CardContent className="p-10 text-center text-white/50">No reviews yet.</CardContent>
          </Card>
        ) : (
          <div className="space-y-3">
            {reviews.map((r) => {
              const initials = (r.customer?.name ?? "U").split(" ").map((p: string) => p[0]).join("").slice(0, 2).toUpperCase();
              const reply = replies[r.id];
              return (
                <Card key={r.id} className="border-white/10 bg-[#0E1628]">
                  <CardContent className="p-5 space-y-3">
                    <div className="flex items-start gap-3">
                      <Avatar className="h-10 w-10">
                        <AvatarImage src={r.customer?.avatar_url ?? undefined} className="object-cover" />
                        <AvatarFallback className="bg-amber-500/20 text-amber-200">{initials}</AvatarFallback>
                      </Avatar>
                      <div className="min-w-0 flex-1">
                        <div className="flex items-center justify-between">
                          <p className="font-semibold text-white">{r.customer?.name ?? "Customer"}</p>
                          <p className="text-xs text-white/50">{format(new Date(r.created_at), "dd MMM yyyy")}</p>
                        </div>
                        <div className="mt-0.5 flex">
                          {Array.from({ length: 5 }).map((_, i) => (
                            <Star key={i} className={`h-3.5 w-3.5 ${i < r.rating ? "fill-amber-400 text-amber-400" : "text-white/20"}`} />
                          ))}
                        </div>
                        {r.comment && <p className="mt-2 text-sm text-white/80">{r.comment}</p>}
                      </div>
                    </div>

                    {reply ? (
                      <div className="rounded-lg border border-amber-300/20 bg-amber-300/5 p-3">
                        <p className="text-[11px] font-semibold uppercase tracking-wider text-amber-200/80">Your reply</p>
                        <p className="mt-1 text-sm text-white/90">{reply.reply}</p>
                      </div>
                    ) : (
                      <div className="space-y-2">
                        <Textarea
                          value={draft[r.id] ?? ""}
                          onChange={(e) => setDraft({ ...draft, [r.id]: e.target.value })}
                          placeholder="Reply publicly to this review…"
                          rows={2}
                          className="bg-white/5 border-white/10 text-white placeholder:text-white/30"
                        />
                        <Button size="sm" onClick={() => submitReply(r.id)} className="bg-amber-500 text-black hover:bg-amber-400">Post reply</Button>
                      </div>
                    )}
                  </CardContent>
                </Card>
              );
            })}
          </div>
        )}
      </div>
    </>
  );
}
