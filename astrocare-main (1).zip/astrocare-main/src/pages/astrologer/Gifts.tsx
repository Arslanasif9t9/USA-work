import { useEffect, useMemo, useState } from "react";
import { useAuth } from "@/contexts/AuthContext";
import { supabase } from "@/integrations/supabase/client";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Card, CardContent } from "@/components/ui/card";
import { Gift as GiftIcon, Loader2, Sparkles } from "lucide-react";
import { cn } from "@/lib/utils";
import { TopFansPanel } from "@/components/live/TopFansPanel";

type FilterKey = "all" | "today" | "week" | "month";

const FILTERS: { key: FilterKey; label: string }[] = [
  { key: "all", label: "All" },
  { key: "today", label: "Today" },
  { key: "week", label: "This Week" },
  { key: "month", label: "This Month" },
];

const GIFT_EMOJI: Record<string, string> = {
  star: "⭐",
  rose: "🌹",
  diamond: "💎",
  crown: "👑",
  moonlight: "🌙",
  blessing: "✨",
  // legacy types
  heart: "❤️",
  sparkle: "✨",
  gift: "🎁",
};

const PAGE = 30;

interface GiftRow {
  id: string;
  user_id: string;
  gift_type: string;
  amount: number;
  astrologer_earning: number;
  customer_note: string | null;
  message: string | null;
  created_at: string;
  customer_name?: string;
  customer_avatar?: string | null;
}

function startOfDay(d = new Date()) { const x = new Date(d); x.setHours(0,0,0,0); return x; }
function startOfWeek(d = new Date()) { const x = startOfDay(d); x.setDate(x.getDate() - x.getDay()); return x; }
function startOfMonth(d = new Date()) { const x = startOfDay(d); x.setDate(1); return x; }

function dayLabel(d: Date) {
  const today = startOfDay();
  const yest = new Date(today); yest.setDate(today.getDate() - 1);
  if (d >= today) return "Today";
  if (d >= yest) return "Yesterday";
  return d.toLocaleDateString([], { weekday: "long", month: "short", day: "numeric" });
}

export default function AstrologerGifts() {
  const { user } = useAuth();
  const [astroId, setAstroId] = useState<string | null>(null);
  const [filter, setFilter] = useState<FilterKey>("all");
  const [rows, setRows] = useState<GiftRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [hasMore, setHasMore] = useState(true);
  const [loadingMore, setLoadingMore] = useState(false);

  // Resolve astrologer id
  useEffect(() => {
    if (!user) return;
    let cancelled = false;
    supabase.from("astrologers").select("id").eq("user_id", user.id).maybeSingle()
      .then(({ data }) => { if (!cancelled) setAstroId((data?.id as string) ?? null); });
    return () => { cancelled = true; };
  }, [user]);

  const sinceDate = useMemo(() => {
    if (filter === "today") return startOfDay();
    if (filter === "week") return startOfWeek();
    if (filter === "month") return startOfMonth();
    return null;
  }, [filter]);

  const fetchPage = async (offset: number) => {
    if (!astroId) return [] as GiftRow[];
    let q = supabase.from("gifts")
      .select("id, user_id, gift_type, amount, astrologer_earning, customer_note, message, created_at")
      .eq("astrologer_id", astroId)
      .order("created_at", { ascending: false })
      .range(offset, offset + PAGE - 1);
    if (sinceDate) q = q.gte("created_at", sinceDate.toISOString());
    const { data } = await q;
    const list = (data ?? []) as GiftRow[];
    if (list.length) {
      const ids = Array.from(new Set(list.map((r) => r.user_id)));
      const { data: profs } = await supabase.from("profiles").select("id, name, avatar_url").in("id", ids);
      const map = new Map((profs ?? []).map((p: any) => [p.id, p]));
      list.forEach((r) => {
        const p = map.get(r.user_id);
        r.customer_name = p?.name ?? "Customer";
        r.customer_avatar = p?.avatar_url ?? null;
      });
    }
    return list;
  };

  // Initial load on filter / astrologer change
  useEffect(() => {
    if (!astroId) return;
    let cancelled = false;
    setLoading(true); setHasMore(true);
    fetchPage(0).then((list) => {
      if (cancelled) return;
      setRows(list);
      setHasMore(list.length === PAGE);
      setLoading(false);
    });
    return () => { cancelled = true; };
  }, [astroId, filter]); // eslint-disable-line react-hooks/exhaustive-deps

  // Realtime: prepend new gifts that match astrologer
  useEffect(() => {
    if (!astroId) return;
    const ch = supabase.channel(`gifts-${astroId}`)
      .on("postgres_changes",
        { event: "INSERT", schema: "public", table: "gifts", filter: `astrologer_id=eq.${astroId}` },
        async (p) => {
          const r = p.new as any as GiftRow;
          if (sinceDate && new Date(r.created_at) < sinceDate) return;
          const { data: prof } = await supabase.from("profiles")
            .select("name, avatar_url").eq("id", r.user_id).maybeSingle();
          r.customer_name = prof?.name ?? "Customer";
          r.customer_avatar = prof?.avatar_url ?? null;
          setRows((prev) => prev.some((x) => x.id === r.id) ? prev : [r, ...prev]);
        })
      .subscribe();
    return () => { supabase.removeChannel(ch); };
  }, [astroId, sinceDate]);

  const loadMore = async () => {
    if (loadingMore || !hasMore) return;
    setLoadingMore(true);
    const more = await fetchPage(rows.length);
    setRows((prev) => [...prev, ...more]);
    setHasMore(more.length === PAGE);
    setLoadingMore(false);
  };

  const totals = useMemo(() => {
    const totalEarnings = rows.reduce((s, r) => s + Number(r.astrologer_earning ?? 0), 0);
    return { count: rows.length, earnings: totalEarnings };
  }, [rows]);

  // Group by date label
  const grouped = useMemo(() => {
    const groups: { key: string; label: string; items: GiftRow[] }[] = [];
    for (const r of rows) {
      const d = startOfDay(new Date(r.created_at));
      const key = d.toISOString().slice(0, 10);
      let g = groups.find((x) => x.key === key);
      if (!g) { g = { key, label: dayLabel(d), items: [] }; groups.push(g); }
      g.items.push(r);
    }
    return groups;
  }, [rows]);

  return (
    <div className="container max-w-3xl space-y-5 p-6">
      <div className="flex items-start justify-between gap-4">
        <div>
          <h1 className="flex items-center gap-2 font-serif text-3xl font-bold text-white">
            <GiftIcon className="h-7 w-7 text-amber-300" /> Gifts received
          </h1>
          <p className="text-sm text-white/50">Personal notes and tokens of appreciation from your customers.</p>
        </div>
      </div>

      <Card className="border-amber-300/20 bg-gradient-to-br from-amber-400/10 via-amber-300/5 to-transparent">
        <CardContent className="flex items-center justify-between p-5">
          <div>
            <p className="text-xs uppercase tracking-wider text-amber-200/80">Earnings from gifts ({filter})</p>
            <p className="mt-1 font-mono text-3xl font-bold text-amber-200">₹{totals.earnings.toFixed(2)}</p>
            <p className="text-xs text-white/50">{totals.count} {totals.count === 1 ? "gift" : "gifts"}</p>
          </div>
          <Sparkles className="h-10 w-10 text-amber-300/60" />
        </CardContent>
      </Card>

      {/* Top Fans (live-stream gifts leaderboard & analytics) */}
      {astroId && (
        <section className="space-y-2">
          <h2 className="text-base font-semibold text-white/90 flex items-center gap-2">
            <Sparkles className="h-4 w-4 text-amber-300" /> Top Fans (Live gifts)
          </h2>
          <TopFansPanel astrologerId={astroId} />
        </section>
      )}

      <div className="flex flex-wrap gap-2">
        {FILTERS.map((f) => (
          <button
            key={f.key}
            onClick={() => setFilter(f.key)}
            className={cn(
              "rounded-full border px-3 py-1.5 text-xs font-medium transition",
              filter === f.key
                ? "border-amber-300 bg-amber-300/15 text-amber-200"
                : "border-white/10 text-white/60 hover:border-white/30 hover:text-white",
            )}
          >
            {f.label}
          </button>
        ))}
      </div>

      {loading ? (
        <div className="flex justify-center py-12"><Loader2 className="h-5 w-5 animate-spin text-white/40" /></div>
      ) : rows.length === 0 ? (
        <Card className="border-white/10 bg-white/5">
          <CardContent className="flex flex-col items-center gap-2 p-10 text-center">
            <GiftIcon className="h-10 w-10 text-white/30" />
            <p className="text-sm text-white/60">No gifts in this period yet.</p>
          </CardContent>
        </Card>
      ) : (
        <>
          {grouped.map((g) => (
            <div key={g.key}>
              <div className="mb-2 flex items-center gap-3">
                <span className="text-xs font-semibold uppercase tracking-wider text-white/50">{g.label}</span>
                <span className="h-px flex-1 bg-white/10" />
              </div>
              <div className="space-y-2">
                {g.items.map((r) => (
                  <Card key={r.id} className="border-white/10 bg-white/5 transition hover:bg-white/10">
                    <CardContent className="flex items-start gap-3 p-3">
                      <Avatar className="h-11 w-11 ring-2 ring-amber-300/30">
                        <AvatarImage src={r.customer_avatar ?? undefined} alt={r.customer_name} className="object-cover" />
                        <AvatarFallback className="bg-purple-700 text-white">
                          {(r.customer_name ?? "U").split(" ").map((p) => p[0]).join("").slice(0,2).toUpperCase()}
                        </AvatarFallback>
                      </Avatar>
                      <div className="min-w-0 flex-1">
                        <div className="flex flex-wrap items-center gap-2">
                          <span className="font-semibold text-white">{r.customer_name}</span>
                          <span className="rounded-full bg-amber-300/15 px-2 py-0.5 text-xs font-bold text-amber-300">
                            +₹{Number(r.astrologer_earning ?? 0).toFixed(2)}
                          </span>
                        </div>
                        <p className="mt-0.5 flex items-center gap-1.5 text-sm text-white/80">
                          <span className="text-base">{GIFT_EMOJI[r.gift_type] ?? "🎁"}</span>
                          <span>{r.message ?? r.gift_type}</span>
                          <span className="text-white/40">· ₹{r.amount}</span>
                        </p>
                        {r.customer_note && (
                          <p className="mt-1.5 rounded-lg border border-white/10 bg-white/5 px-2.5 py-1.5 text-xs italic text-white/70">
                            “{r.customer_note}”
                          </p>
                        )}
                        <p className="mt-1 text-[11px] text-white/40">
                          {new Date(r.created_at).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
                        </p>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          ))}

          {hasMore && (
            <div className="flex justify-center pt-2">
              <button
                onClick={loadMore}
                disabled={loadingMore}
                className="rounded-full border border-white/15 bg-white/5 px-4 py-2 text-xs font-medium text-white/80 transition hover:bg-white/10"
              >
                {loadingMore ? <Loader2 className="inline h-3 w-3 animate-spin" /> : "Load more"}
              </button>
            </div>
          )}
        </>
      )}
    </div>
  );
}
