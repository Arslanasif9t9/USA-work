import { useEffect, useState } from "react";
import { useWallet, formatINR } from "@/hooks/useWallet";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent } from "@/components/ui/card";
import { Receipt, ArrowDownLeft, ArrowUpRight } from "lucide-react";
import { format } from "date-fns";

interface Tx {
  id: string;
  type: string;
  amount: number;
  description: string;
  balance_after: number;
  created_at: string;
}

const CREDIT_TYPES = ["consultation_credit", "top_up", "call_hold_release", "refund"];

export default function AstrologerTransactions() {
  const { wallet } = useWallet();
  const [items, setItems] = useState<Tx[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!wallet) return;
    (async () => {
      const { data } = await supabase
        .from("transactions")
        .select("*")
        .eq("wallet_id", wallet.id)
        .order("created_at", { ascending: false })
        .limit(200);
      setItems((data ?? []) as Tx[]);
      setLoading(false);
    })();
  }, [wallet]);

  return (
    <div className="container max-w-4xl space-y-6 p-6">
      <div className="flex items-end justify-between flex-wrap gap-3">
        <div>
          <h1 className="font-serif text-3xl font-bold text-white">Transactions</h1>
          <p className="text-sm text-white/50">Every wallet movement: earnings, withdrawals, refunds.</p>
        </div>
        <div className="rounded-xl border border-amber-300/30 bg-amber-300/10 px-4 py-3">
          <p className="text-[10px] uppercase tracking-wider text-amber-200/80">Current balance</p>
          <p className="text-xl font-bold text-amber-200 tabular-nums">{formatINR(wallet?.balance ?? 0)}</p>
        </div>
      </div>

      <Card className="border-white/10 bg-[#0E1628]">
        <CardContent className="p-0">
          {loading ? (
            <p className="p-6 text-white/50">Loading…</p>
          ) : items.length === 0 ? (
            <div className="flex flex-col items-center gap-3 p-12 text-center">
              <div className="rounded-full bg-amber-300/10 p-4 text-amber-300"><Receipt className="h-8 w-8" /></div>
              <p className="text-white/70">No transactions yet</p>
              <p className="text-xs text-white/40">Your earnings will appear here as soon as your first session ends.</p>
            </div>
          ) : (
            <ul className="divide-y divide-white/5">
              {items.map((t) => {
                const credit = CREDIT_TYPES.includes(t.type);
                return (
                  <li key={t.id} className="flex items-center gap-3 px-5 py-4">
                    <div className={`rounded-full p-2 ${credit ? "bg-emerald-500/10 text-emerald-300" : "bg-rose-500/10 text-rose-300"}`}>
                      {credit ? <ArrowDownLeft className="h-4 w-4" /> : <ArrowUpRight className="h-4 w-4" />}
                    </div>
                    <div className="min-w-0 flex-1">
                      <p className="truncate text-sm text-white">{t.description}</p>
                      <p className="text-[11px] text-white/40">{format(new Date(t.created_at), "dd MMM yyyy, hh:mm a")}</p>
                    </div>
                    <div className="text-right">
                      <p className={`text-sm font-bold tabular-nums ${credit ? "text-emerald-300" : "text-rose-300"}`}>
                        {credit ? "+" : "−"} ₹{Number(t.amount).toFixed(0)}
                      </p>
                      <p className="text-[10px] text-white/40">Bal: ₹{Number(t.balance_after).toFixed(0)}</p>
                    </div>
                  </li>
                );
              })}
            </ul>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
