/**
 * Standalone /astrologer/chat/endsession page (FIX 7, astrologer side).
 */
import { useEffect, useState } from "react";
import { useNavigate, useSearchParams } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { ArrowLeft, Loader2, Sparkles } from "lucide-react";

interface Loaded {
  session: {
    id: string;
    user_id: string;
    astrologer_id: string;
    duration_seconds: number;
    total_cost: number;
    ended_by: string | null;
    astrologer_earning: number;
  };
  customer: { id: string; name: string; avatar_url: string | null } | null;
}

function fmt(s: number) {
  const m = Math.floor(s / 60).toString().padStart(2, "0");
  const sec = (s % 60).toString().padStart(2, "0");
  return `${m}:${sec}`;
}

export default function AstrologerChatSessionEnded() {
  const [params] = useSearchParams();
  const sessionId = params.get("sessionId");
  const navigate = useNavigate();
  const [data, setData] = useState<Loaded | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!sessionId) { setLoading(false); return; }
    let active = true;
    (async () => {
      const { data: s } = await supabase
        .from("chat_sessions")
        .select("id, user_id, astrologer_id, duration_seconds, total_cost, ended_by, astrologer_earning")
        .eq("id", sessionId)
        .maybeSingle();
      if (!s) { if (active) { setData(null); setLoading(false); } return; }
      const { data: c } = await supabase
        .from("profiles")
        .select("id, name, avatar_url")
        .eq("id", s.user_id)
        .maybeSingle();
      if (!active) return;
      setData({ session: s as any, customer: (c as any) ?? null });
      setLoading(false);
    })();
    return () => { active = false; };
  }, [sessionId]);

  if (loading) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-[#080D1B] text-white">
        <Loader2 className="h-8 w-8 animate-spin text-amber-400" />
      </div>
    );
  }
  if (!data) {
    return (
      <div className="flex min-h-screen flex-col items-center justify-center gap-4 bg-[#080D1B] p-6 text-center text-white">
        <p>Session not found.</p>
        <Button onClick={() => navigate("/astrologer/overview")} className="bg-amber-500 text-black hover:bg-amber-400">Back to dashboard</Button>
      </div>
    );
  }

  const { session, customer } = data;
  const subtitle = session.ended_by === "astrologer"
    ? "You ended the session"
    : session.ended_by === "system"
    ? "Session ended automatically"
    : session.ended_by === "customer"
    ? "Customer ended the session"
    : "The session has ended";
  const initials = (customer?.name ?? "U").split(" ").map((p) => p[0]).join("").slice(0, 2).toUpperCase();

  return (
    <div className="relative min-h-screen overflow-y-auto bg-[#080D1B] text-white">
      <div className="pointer-events-none fixed inset-0 [background-image:radial-gradient(rgba(251,191,36,0.06)_1px,transparent_1px)] [background-size:32px_32px]" />

      <div className="sticky top-0 z-10 border-b border-white/5 bg-[#080D1B]/80 backdrop-blur-xl">
        <div className="mx-auto flex max-w-7xl items-center justify-between px-4 py-3 sm:px-6">
          <button
            onClick={() => navigate("/astrologer/overview", { replace: true })}
            className="inline-flex h-10 items-center gap-2 rounded-full border border-white/10 bg-white/5 px-3 text-sm text-white/90 transition hover:bg-white/10"
          >
            <ArrowLeft className="h-4 w-4" /> Dashboard
          </button>
          <span className="inline-flex items-center gap-1.5 rounded-full bg-white/5 px-3 py-1 text-xs text-white/70">
            <Sparkles className="h-3 w-3 text-amber-300" /> Session Ended
          </span>
        </div>
      </div>

      <div className="relative mx-auto grid w-full max-w-7xl grid-cols-1 gap-4 px-4 py-6 sm:px-6 md:grid-cols-[1fr_3fr]">
        {/* Left — customer card */}
        <aside className="rounded-2xl border border-white/10 bg-[#0E1628] p-5">
          <div className="flex flex-col items-center text-center">
            <Avatar className="h-24 w-24 ring-4 ring-amber-300/40">
              <AvatarImage src={customer?.avatar_url ?? undefined} alt={customer?.name} className="object-cover" />
              <AvatarFallback className="bg-purple-700 text-2xl font-semibold">{initials}</AvatarFallback>
            </Avatar>
            <h2 className="mt-3 font-serif text-xl font-bold">{customer?.name ?? "Customer"}</h2>
            <p className="mt-1 text-xs text-white/50">Customer</p>
          </div>
        </aside>

        {/* Right — summary */}
        <section className="rounded-2xl border border-white/10 bg-[#0E1628] p-6">
          <div className="text-center">
            <div className="relative mx-auto mb-4 flex h-20 w-20 items-center justify-center">
              <span className="absolute inset-0 animate-ping rounded-full bg-amber-400/30" />
              <div className="relative flex h-16 w-16 items-center justify-center rounded-full bg-gradient-to-br from-amber-300 to-amber-500 text-black shadow-[0_0_40px_rgba(251,191,36,0.6)]">
                <Sparkles className="h-8 w-8" />
              </div>
            </div>
            <h1 className="font-serif text-3xl font-bold">Session Ended</h1>
            <p className="mt-1 text-sm text-white/60">{subtitle}</p>
          </div>

          <div className="mt-6 grid grid-cols-2 gap-3 rounded-2xl border border-white/10 bg-white/5 p-4">
            <div>
              <p className="text-[11px] uppercase tracking-wider text-white/50">Duration</p>
              <p className="mt-0.5 font-mono text-2xl font-bold">{fmt(session.duration_seconds)}</p>
            </div>
            <div>
              <p className="text-[11px] uppercase tracking-wider text-white/50">Total billed</p>
              <p className="mt-0.5 text-2xl font-bold text-amber-300">₹{Number(session.total_cost ?? 0)}</p>
            </div>
          </div>

          <div className="mt-3 rounded-2xl border border-emerald-400/30 bg-emerald-400/10 p-4 text-center">
            <p className="text-[11px] uppercase tracking-wider text-emerald-200/80">Your earnings</p>
            <p className="mt-1 text-3xl font-bold text-emerald-300">+ ₹{Number(session.astrologer_earning ?? 0)}</p>
            <p className="mt-1 text-[11px] text-white/50">Credited to your wallet</p>
          </div>

          <div className="mt-6 flex flex-col gap-2 sm:flex-row">
            <Button
              onClick={() => navigate("/astrologer/overview", { replace: true })}
              className="flex-1 bg-gradient-to-r from-amber-300 to-amber-500 text-black hover:from-amber-200 hover:to-amber-400"
            >
              Back to Dashboard
            </Button>
            <Button
              variant="outline"
              onClick={() => navigate("/astrologer/earnings")}
              className="flex-1 border-white/15 bg-white/5 text-white hover:bg-white/10"
            >
              View earnings
            </Button>
          </div>
        </section>
      </div>
    </div>
  );
}
