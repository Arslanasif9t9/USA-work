/**
 * Standalone /astrologer/call/endsession page (FIX 7 / FIX 9, astrologer side).
 */
import { useEffect, useState } from "react";
import { useNavigate, useSearchParams } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { ArrowLeft, Loader2, Sparkles } from "lucide-react";

interface Loaded {
  session: {
    id: string;
    user_id: string;
    astrologer_id: string;
    duration_seconds: number;
    total_cost: number;
    ended_by: string | null;
    astrologer_earning: number;
  };
  customer: { id: string; name: string; avatar_url: string | null } | null;
}

function fmt(s: number) {
  const m = Math.floor(s / 60).toString().padStart(2, "0");
  const sec = (s % 60).toString().padStart(2, "0");
  return `${m}:${sec}`;
}

export default function AstrologerCallSessionEnded() {
  const [params] = useSearchParams();
  const sessionId = params.get("sessionId");
  const navigate = useNavigate();
  const [data, setData] = useState<Loaded | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!sessionId) { setLoading(false); return; }
    let active = true;
    (async () => {
      const { data: s } = await supabase
        .from("call_sessions")
        .select("id, user_id, astrologer_id, duration_seconds, total_cost, ended_by, astrologer_earning")
        .eq("id", sessionId)
        .maybeSingle();
      if (!s) { if (active) { setData(null); setLoading(false); } return; }
      const { data: c } = await supabase
        .from("profiles")
        .select("id, name, avatar_url")
        .eq("id", s.user_id)
        .maybeSingle();
      if (!active) return;
      setData({ session: s as any, customer: (c as any) ?? null });
      setLoading(false);
    })();
    return () => { active = false; };
  }, [sessionId]);

  if (loading) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-slate-950 text-white">
        <Loader2 className="h-8 w-8 animate-spin text-amber-400" />
      </div>
    );
  }
  if (!data) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-slate-950 p-6 text-center text-white">
        <p>Call not found.</p>
      </div>
    );
  }

  const { session, customer } = data;
  const initials = (customer?.name ?? "C").split(" ").map((p) => p[0]).join("").slice(0, 2).toUpperCase();

  return (
    <div className="min-h-screen bg-slate-950 text-white">
      <div className="grid min-h-screen grid-cols-1 md:grid-cols-[1fr_3fr]">
        <aside className="border-b border-white/5 bg-slate-900/60 p-6 md:border-b-0 md:border-r">
          <button onClick={() => navigate("/astrologer/overview")} className="mb-6 inline-flex items-center gap-2 text-sm text-slate-300 hover:text-white">
            <ArrowLeft className="h-4 w-4" /> Back to dashboard
          </button>
          <div className="flex flex-col items-center text-center">
            <div className="relative mb-3">
              <span className="absolute inset-0 -m-1 rounded-full bg-gradient-to-br from-amber-300 to-amber-600 opacity-70" />
              <Avatar className="relative h-28 w-28 ring-4 ring-amber-300/80">
                <AvatarImage src={customer?.avatar_url ?? undefined} alt={customer?.name ?? "Customer"} className="object-cover" />
                <AvatarFallback className="bg-purple-700 text-2xl font-semibold">{initials}</AvatarFallback>
              </Avatar>
            </div>
            <h2 className="text-lg font-semibold">{customer?.name ?? "Customer"}</h2>
            <p className="mt-1 text-xs text-slate-400">Call ended</p>
          </div>
        </aside>

        <main className="flex items-center justify-center p-6">
          <div className="w-full max-w-md text-center">
            <div className="mx-auto mb-4 flex h-16 w-16 items-center justify-center rounded-full bg-amber-500/20 ring-4 ring-amber-400/30">
              <Sparkles className="h-8 w-8 text-amber-300" />
            </div>
            <h1 className="font-serif text-3xl font-bold">Session Ended</h1>
            <p className="mt-1 text-sm text-slate-400">Thank you for the consultation.</p>

            <div className="mt-6 rounded-2xl border border-white/10 bg-slate-900/60 p-6">
              <div className="flex items-center justify-between">
                <span className="text-sm text-slate-400">Duration</span>
                <span className="font-mono text-lg font-bold tracking-wider">{fmt(session.duration_seconds)}</span>
              </div>
              <div className="mt-3 flex items-center justify-between">
                <span className="text-sm text-slate-400">Earnings</span>
                <span className="text-lg font-bold text-amber-300">₹{Number(session.astrologer_earning ?? 0).toFixed(2)}</span>
              </div>
            </div>

            <Button
              onClick={() => navigate("/astrologer/overview")}
              className="mt-6 w-full bg-gradient-to-r from-amber-500 to-amber-600 text-black hover:from-amber-400 hover:to-amber-500"
            >
              Back to dashboard
            </Button>
          </div>
        </main>
      </div>
    </div>
  );
}
