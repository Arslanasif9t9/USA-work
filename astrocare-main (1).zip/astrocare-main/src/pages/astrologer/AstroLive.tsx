// Astrologer "Go Live" page — real Agora broadcast with Demo Mode fallback.
import { useEffect, useRef, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAstrologerAccount } from "@/hooks/useAstrologerAccount";
import { usePlatformSettings } from "@/hooks/usePlatformSettings";
import { useAuth } from "@/contexts/AuthContext";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Card } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Radio, X, Eye, Heart, Gift, Camera, Mic, MicOff, Sparkles, Video, VideoOff } from "lucide-react";
import { toast } from "sonner";
import { cn } from "@/lib/utils";
import { fetchAgoraToken, getAgoraAppId, loadAgoraSDK, uidFromUserId } from "@/lib/agora";
import { setHostSession, getHostSession, clearHostSession, isHostSessionHealthy } from "@/lib/agoraHostSession";
import { LiveGiftHost, type LiveGiftEvent } from "@/components/live/LiveGiftHost";
import { giftByType } from "@/components/live/liveGifts";
import { LiveCallRequestPanel } from "@/components/live/LiveCallRequestPanel";
import { Lock } from "lucide-react";

interface ActiveStream { id: string; channel_name: string; title: string; }
interface Comment { id: string; user_name: string; user_avatar: string | null; is_host: boolean; comment_text: string; created_at: string; }
interface StreamStats { viewer_count: number; total_likes: number; total_comments: number; total_gifts_value: number; }

function fmtTime(secs: number) {
  const h = Math.floor(secs / 3600); const m = Math.floor((secs % 3600) / 60); const s = secs % 60;
  return h > 0 ? `${h}:${m.toString().padStart(2, "0")}:${s.toString().padStart(2, "0")}` : `${m}:${s.toString().padStart(2, "0")}`;
}

export default function AstroLivePage() {
  const { astro } = useAstrologerAccount();
  const { user } = useAuth();
  const settings = usePlatformSettings();
  const [active, setActive] = useState<ActiveStream | null>(null);
  const [needsResume, setNeedsResume] = useState(false);
  const [resuming, setResuming] = useState(false);
  const [setupOpen, setSetupOpen] = useState(false);
  const [endOpen, setEndOpen] = useState(false);
  const [title, setTitle] = useState("Daily Horoscope Q&A");
  const [description, setDescription] = useState("");
  const [saveRecording, setSaveRecording] = useState(true);
  const [muted, setMuted] = useState(false);
  const [videoOff, setVideoOff] = useState(false);
  const [demoMode, setDemoMode] = useState<boolean | null>(null);
  const [pastStats, setPastStats] = useState({ total: 0, watchHours: 0, gifts: 0 });
  const [comments, setComments] = useState<Comment[]>([]);
  const [stats, setStats] = useState<StreamStats>({ viewer_count: 0, total_likes: 0, total_comments: 0, total_gifts_value: 0 });
  const [duration, setDuration] = useState(0);
  const [hostMessage, setHostMessage] = useState("");
  const [starting, setStarting] = useState(false);
  const [recentGifts, setRecentGifts] = useState<LiveGiftEvent[]>([]);
  const [streamEarnings, setStreamEarnings] = useState(0);
  const [earningsPulse, setEarningsPulse] = useState(false);
  const [giftsPanelOpen, setGiftsPanelOpen] = useState(false);
  const [isPaused, setIsPaused] = useState(false);
  const [coHostActive, setCoHostActive] = useState(false);
  const wasPausedRef = useRef(false);

  const previewVideoRef = useRef<HTMLDivElement>(null);
  const liveVideoRef = useRef<HTMLDivElement>(null);
  const coHostVideoRef = useRef<HTMLDivElement>(null);
  const remoteCoHostTrackRef = useRef<any>(null);
  const startedAtRef = useRef<number>(0);

  // Agora refs
  const clientRef = useRef<any>(null);
  const localAudioRef = useRef<any>(null);
  const localVideoRef = useRef<any>(null);
  const camerasRef = useRef<MediaDeviceInfo[]>([]);
  const cameraIdxRef = useRef(0);

  const isDisabled = settings && settings.astrolive_enabled === false;

  // Detect demo mode via runtime fetch (cached)
  useEffect(() => { getAgoraAppId().then((id) => setDemoMode(!id)); }, []);

  // Past stats
  useEffect(() => {
    if (!astro) return;
    (async () => {
      const { data } = await supabase.from("live_streams")
        .select("duration_seconds, total_gifts_value")
        .eq("astrologer_id", astro.id).eq("status", "ended");
      if (data) setPastStats({
        total: data.length,
        watchHours: Math.round(data.reduce((a, r) => a + (r.duration_seconds || 0), 0) / 3600 * 10) / 10,
        gifts: data.reduce((a, r) => a + Number(r.total_gifts_value || 0), 0),
      });
    })();
  }, [astro]);

  // Resume existing — but require explicit user action to re-acquire camera/mic.
  // This runs once per astro and does NOT auto-disconnect on tab switch.
  useEffect(() => {
    if (!astro) return;
    (async () => {
      const { data } = await supabase.from("live_streams")
        .select("id, channel_name, title, started_at")
        .eq("astrologer_id", astro.id).eq("status", "live").maybeSingle();
      if (data) {
        setActive({ id: data.id, channel_name: data.channel_name, title: data.title });
        startedAtRef.current = new Date(data.started_at).getTime();
        // If our module-level Agora session is still healthy (tab switch /
        // dashboard navigation), reuse it instead of showing the resume screen.
        const existing = getHostSession(data.id);
        if (existing && isHostSessionHealthy(data.id)) {
          clientRef.current = existing.client;
          localAudioRef.current = existing.audioTrack;
          localVideoRef.current = existing.videoTrack;
          setNeedsResume(false);
          toast.success("Welcome back — your live is still on");
        } else {
          setNeedsResume(true);
        }
      }
    })();
  }, [astro]);

  // Warn before unload while broadcasting
  useEffect(() => {
    if (!active || needsResume) return;
    const handler = (e: BeforeUnloadEvent) => {
      e.preventDefault();
      e.returnValue = "Your live stream is active. Leaving will pause your broadcast.";
      return e.returnValue;
    };
    window.addEventListener("beforeunload", handler);
    return () => window.removeEventListener("beforeunload", handler);
  }, [active, needsResume]);

  // Live timer
  useEffect(() => {
    if (!active) return;
    const tick = () => setDuration(Math.floor((Date.now() - startedAtRef.current) / 1000));
    tick(); const id = setInterval(tick, 1000);
    return () => clearInterval(id);
  }, [active]);

  // Comments + stats subscription
  useEffect(() => {
    if (!active) return;
    let mounted = true;
    (async () => {
      const { data } = await supabase.from("live_comments")
        .select("id, user_name, user_avatar, is_host, comment_text, created_at")
        .eq("live_stream_id", active.id).eq("is_deleted", false)
        .order("created_at", { ascending: false }).limit(40);
      if (data && mounted) setComments((data as Comment[]).reverse());
    })();
    const ch = supabase.channel(`astrolive_host_${active.id}_${Math.random().toString(36).slice(2)}`)
      .on("postgres_changes", { event: "INSERT", schema: "public", table: "live_comments", filter: `live_stream_id=eq.${active.id}` },
        (p) => setComments((prev) => [...prev.slice(-39), p.new as Comment]))
      .on("postgres_changes", { event: "UPDATE", schema: "public", table: "live_streams", filter: `id=eq.${active.id}` },
        (p) => {
          const r = p.new as any;
          setStats({ viewer_count: r.viewer_count, total_likes: r.total_likes, total_comments: r.total_comments, total_gifts_value: Number(r.total_gifts_value || 0) });
          setIsPaused(Boolean(r.is_paused_for_private));
          setCoHostActive(!!r.active_co_host_id);
        })
      .subscribe((status) => { if (status === "SUBSCRIBED") console.log("[AstroLive] host channel SUBSCRIBED"); });
    return () => { mounted = false; supabase.removeChannel(ch); };
  }, [active]);

  // Subscribe to a co-host's remote video on the host's Agora client (split view).
  useEffect(() => {
    if (!active) return;
    const client = clientRef.current;
    if (!client) return;
    const onPub = async (remoteUser: any, mediaType: "audio" | "video") => {
      try {
        await client.subscribe(remoteUser, mediaType);
        if (mediaType === "video") {
          remoteCoHostTrackRef.current = remoteUser.videoTrack;
          if (coHostVideoRef.current) {
            try { remoteUser.videoTrack?.play(coHostVideoRef.current); } catch {}
          }
        } else if (mediaType === "audio") {
          // Astrologer hears co-host audio
          try { remoteUser.audioTrack?.play(); } catch {}
        }
      } catch (e) { console.warn("[AstroLive] co-host subscribe failed", e); }
    };
    const onUnpub = (_u: any, mediaType: string) => {
      if (mediaType === "video") remoteCoHostTrackRef.current = null;
    };
    client.on("user-published", onPub);
    client.on("user-unpublished", onUnpub);
    return () => {
      try { client.off("user-published", onPub); } catch {}
      try { client.off("user-unpublished", onUnpub); } catch {}
    };
  }, [active, coHostActive]);

  // Re-bind remote co-host track when split layout DOM appears
  useEffect(() => {
    if (coHostActive && remoteCoHostTrackRef.current && coHostVideoRef.current) {
      try { remoteCoHostTrackRef.current.play(coHostVideoRef.current); } catch {}
    }
  }, [coHostActive]);

  // Pause/resume local Agora tracks when astrologer enters/exits a private session
  useEffect(() => {
    if (!active) return;
    const wasPaused = wasPausedRef.current;
    wasPausedRef.current = isPaused;
    (async () => {
      try {
        if (isPaused) {
          await localVideoRef.current?.setEnabled(false);
          await localAudioRef.current?.setEnabled(false);
        } else {
          // Only resume if we previously paused (avoids overriding manual mute)
          if (wasPaused) {
            await localVideoRef.current?.setEnabled(!videoOff);
            await localAudioRef.current?.setEnabled(!muted);
            // Notify viewers that the live has resumed
            try { await supabase.rpc("notify_live_resumed", { _stream_id: active.id }); } catch {}
            toast.success("✨ Live resumed — viewers can see you again");
          }
        }
      } catch (e) {
        console.warn("[AstroLive] track pause/resume error", e);
      }
    })();
  }, [isPaused, active, videoOff, muted]);

  // Agora cleanup helper
  async function cleanupAgora() {
    try { localAudioRef.current?.stop(); localAudioRef.current?.close(); } catch {}
    try { localVideoRef.current?.stop(); localVideoRef.current?.close(); } catch {}
    try { await clientRef.current?.leave(); } catch {}
    localAudioRef.current = null;
    localVideoRef.current = null;
    clientRef.current = null;
    clearHostSession();
  }
  // NOTE: Intentionally NOT cleaning up on unmount. Navigating away from the
  // broadcast page (or losing focus) must NOT kill the camera/Agora connection.
  // The stream is only torn down when the astrologer explicitly clicks End Live.

  // Resume an existing broadcast: re-acquire camera/mic and rejoin Agora channel.
  async function resumeBroadcast() {
    if (!active || resuming) return;
    setResuming(true);
    try {
      if (!demoMode) {
        const AgoraRTC = await loadAgoraSDK();
        const uid = uidFromUserId(user?.id);
        const { token, appId } = await fetchAgoraToken({
          channelName: active.channel_name, uid, role: "host",
        });
        const client = AgoraRTC.createClient({ mode: "live", codec: "vp8" });
        await client.setClientRole("host");
        await client.join(appId, active.channel_name, token, uid);
        const [mic, cam] = await Promise.all([
          AgoraRTC.createMicrophoneAudioTrack().catch((e) => { throw new Error(/permission/i.test(e?.message ?? "") ? "Microphone access required" : "Microphone error"); }),
          AgoraRTC.createCameraVideoTrack().catch((e) => { throw new Error(/permission/i.test(e?.message ?? "") ? "Camera access required" : "Camera error"); }),
        ]);
        await client.publish([mic, cam]);
        clientRef.current = client;
        localAudioRef.current = mic;
        localVideoRef.current = cam;
        setHostSession({ streamId: active.id, channelName: active.channel_name, client, audioTrack: mic, videoTrack: cam });
      }
      setNeedsResume(false);
      toast.success("Broadcast resumed");
      try { await supabase.rpc("notify_live_resumed", { _stream_id: active.id }); } catch {}
    } catch (e: any) {
      toast.error(e?.message ?? "Could not resume broadcast");
    } finally {
      setResuming(false);
    }
  }

  // Setup-dialog camera preview (real Agora track)
  useEffect(() => {
    if (!setupOpen || demoMode) return;
    let cancelled = false;
    let track: any = null;
    (async () => {
      try {
        const AgoraRTC = await loadAgoraSDK();
        track = await AgoraRTC.createCameraVideoTrack();
        if (cancelled) { track.stop(); track.close(); return; }
        if (previewVideoRef.current) track.play(previewVideoRef.current);
      } catch (e: any) {
        if (e?.code === "PERMISSION_DENIED" || /permission/i.test(e?.message ?? ""))
          toast.error("Camera access required to go live");
      }
    })();
    return () => { cancelled = true; try { track?.stop(); track?.close(); } catch {} };
  }, [setupOpen, demoMode]);

  async function startLive() {
    if (starting) return;
    setStarting(true);
    try {
      // 1. Create the DB row (also gives us channel_name)
      const { data, error } = await supabase.rpc("start_live_stream", {
        _title: title.trim() || "Live with astrologer",
        _description: description.trim() || null,
        _thumbnail_url: astro?.avatar_url ?? null,
        _save_recording: saveRecording,
      });
      if (error) throw new Error(error.message);
      const r = data as any;
      if (!r?.ok) throw new Error("Could not start live");

      const stream: ActiveStream = { id: r.stream_id, channel_name: r.channel_name, title };

      // 2. If real Agora available, join + publish
      if (!demoMode) {
        const AgoraRTC = await loadAgoraSDK();
        const uid = uidFromUserId(user?.id);
        const { token, appId } = await fetchAgoraToken({ channelName: stream.channel_name, uid, role: "host" });

        const client = AgoraRTC.createClient({ mode: "live", codec: "vp8" });
        await client.setClientRole("host");
        await client.join(appId, stream.channel_name, token, uid);

        const [mic, cam] = await Promise.all([
          AgoraRTC.createMicrophoneAudioTrack().catch((e) => { throw new Error(/permission/i.test(e?.message ?? "") ? "Microphone access required" : "Microphone error"); }),
          AgoraRTC.createCameraVideoTrack().catch((e) => { throw new Error(/permission/i.test(e?.message ?? "") ? "Camera access required to go live" : "Camera error"); }),
        ]);
        await client.publish([mic, cam]);

        clientRef.current = client;
        localAudioRef.current = mic;
        localVideoRef.current = cam;
        setHostSession({ streamId: stream.id, channelName: stream.channel_name, client, audioTrack: mic, videoTrack: cam });
        try {
          const all = await navigator.mediaDevices.enumerateDevices();
          camerasRef.current = all.filter((d) => d.kind === "videoinput");
        } catch {}
      }

      setActive(stream);
      startedAtRef.current = Date.now();
      setSetupOpen(false);
      toast.success("You're live!");

      // Fire follower notifications (in-app; push later)
      try {
        await supabase.rpc("notify_followers_live_started", { _stream_id: stream.id });
      } catch (e) {
        console.warn("[AstroLive] notify_followers_live_started failed", e);
      }
    } catch (e: any) {
      toast.error(e?.message ?? "Failed to start broadcast");
      await cleanupAgora();
    } finally { setStarting(false); }
  }

  // Mount the live preview when broadcasting
  useEffect(() => {
    if (active && localVideoRef.current && liveVideoRef.current) {
      try { localVideoRef.current.play(liveVideoRef.current); } catch {}
    }
  }, [active]);

  async function endLive() {
    if (!active) return;
    await cleanupAgora();
    await supabase.rpc("end_live_stream", { _stream_id: active.id, _reason: "ended_by_host" });
    toast.success("Live ended");
    setActive(null); setEndOpen(false); setDuration(0); setComments([]);
    setStats({ viewer_count: 0, total_likes: 0, total_comments: 0, total_gifts_value: 0 });
  }

  async function postHostMessage() {
    if (!active || !hostMessage.trim()) return;
    const text = hostMessage.trim();
    setHostMessage("");
    const { error } = await supabase.rpc("post_live_comment", { _stream_id: active.id, _text: text });
    if (error) toast.error(error.message);
  }

  async function toggleMic() {
    const next = !muted; setMuted(next);
    try { await localAudioRef.current?.setEnabled(!next); } catch {}
  }
  async function toggleCam() {
    const next = !videoOff; setVideoOff(next);
    try { await localVideoRef.current?.setEnabled(!next); } catch {}
  }
  async function switchCamera() {
    if (!localVideoRef.current || camerasRef.current.length < 2) {
      toast.info("No alternate camera detected"); return;
    }
    cameraIdxRef.current = (cameraIdxRef.current + 1) % camerasRef.current.length;
    try { await localVideoRef.current.setDevice(camerasRef.current[cameraIdxRef.current].deviceId); }
    catch { toast.error("Could not switch camera"); }
  }

  if (isDisabled) return (
    <div className="p-8 max-w-2xl mx-auto">
      <Card className="p-8 text-center">
        <Radio className="h-12 w-12 mx-auto mb-3 text-muted-foreground" />
        <h2 className="text-xl font-semibold">AstroLive is disabled</h2>
        <p className="text-sm text-muted-foreground mt-2">The admin team has temporarily disabled live streaming. Please check back later.</p>
      </Card>
    </div>
  );

  // === RESUME LIVE SCREEN (after refresh / re-mount with active stream) ===
  if (active && needsResume) {
    return (
      <div className="fixed inset-0 z-50 bg-gradient-to-br from-purple-950 via-fuchsia-900 to-black text-white flex items-center justify-center p-6">
        <Card className="max-w-md w-full p-6 bg-black/60 border-amber-300/30 text-white text-center">
          <Radio className="h-12 w-12 mx-auto mb-3 text-amber-300 animate-pulse" />
          <h2 className="text-xl font-bold">Your live is still active</h2>
          <p className="text-sm text-white/70 mt-2">
            Resume broadcasting to continue, or end the live now.
          </p>
          <div className="text-xs text-white/50 mt-1">"{active.title}"</div>
          <div className="flex flex-col gap-2 mt-5">
            <Button
              onClick={resumeBroadcast}
              disabled={resuming}
              className="w-full bg-gradient-to-r from-amber-500 to-fuchsia-500 h-12 font-semibold"
            >
              {resuming ? "Resuming…" : "Resume Broadcasting"}
            </Button>
            <Button
              variant="outline"
              onClick={async () => { await endLive(); setNeedsResume(false); }}
              className="w-full bg-white/5 border-white/20 text-white hover:bg-white/10"
            >
              End Live
            </Button>
          </div>
        </Card>
      </div>
    );
  }

  // === BROADCASTING SCREEN ===
  if (active) {
    return (
      <div className="fixed inset-0 z-50 bg-black text-white flex">
        <div className="relative flex-1">
          {demoMode ? (
            <div className="absolute inset-0 bg-gradient-to-br from-purple-900 via-fuchsia-800 to-amber-700 flex items-center justify-center">
              <div className="text-center">
                <Video className="h-20 w-20 mx-auto mb-3 opacity-70" />
                <p className="text-lg font-semibold">Demo broadcast</p>
                <p className="text-xs opacity-70 mt-1">Add Agora credentials to enable real video</p>
              </div>
            </div>
          ) : (
            <div className={cn(
              "absolute inset-0 grid transition-all duration-300",
              coHostActive ? "grid-rows-2 lg:grid-rows-1 lg:grid-cols-2" : "grid-rows-1"
            )}>
              <div className="relative overflow-hidden">
                <div ref={liveVideoRef} className="absolute inset-0 w-full h-full bg-black" />
                {coHostActive && (
                  <span className="absolute bottom-2 left-2 px-2 py-0.5 rounded-full bg-amber-400/90 text-black text-[10px] font-bold shadow">
                    🔮 You (Host)
                  </span>
                )}
              </div>
              {coHostActive && (
                <div className="relative overflow-hidden border-t-2 lg:border-t-0 lg:border-l-2 border-amber-300 shadow-[0_0_24px_rgba(251,191,36,0.45)]">
                  <div ref={coHostVideoRef} className="absolute inset-0 [&>div]:!w-full [&>div]:!h-full [&_video]:!object-cover bg-black" />
                  <span className="absolute bottom-2 left-2 px-2 py-0.5 rounded-full bg-white/80 text-black text-[10px] font-bold shadow">
                    Guest (Live)
                  </span>
                </div>
              )}
            </div>
          )}

          <div className="absolute top-0 inset-x-0 p-4 flex items-center justify-between bg-gradient-to-b from-black/70 to-transparent">
            <div className="flex items-center gap-3">
              <span className="px-2 py-1 bg-red-600 text-white text-xs font-bold rounded flex items-center gap-1">
                <span className="h-1.5 w-1.5 rounded-full bg-white animate-pulse" /> LIVE
              </span>
              <span className="text-sm tabular-nums">{fmtTime(duration)}</span>
              <span className="text-sm flex items-center gap-1"><Eye className="h-4 w-4" /> {stats.viewer_count}</span>
              <span className="text-sm flex items-center gap-1"><Heart className="h-4 w-4" /> {stats.total_likes}</span>
              <span className="text-sm flex items-center gap-1"><Gift className="h-4 w-4" /> ₹{stats.total_gifts_value}</span>
              <span className={cn("text-sm flex items-center gap-1 font-semibold transition-all", earningsPulse ? "text-amber-300 scale-110" : "text-amber-200")}>
                +₹{streamEarnings.toFixed(2)}
              </span>
              <button onClick={() => setGiftsPanelOpen((v) => !v)} className="ml-1 px-2 py-1 rounded-md bg-white/10 hover:bg-white/20 text-xs">
                Recent Gifts {recentGifts.length > 0 && <span className="ml-1 px-1.5 rounded-full bg-amber-400 text-black text-[10px]">{recentGifts.length}</span>}
              </button>
            </div>
            <button onClick={() => setEndOpen(true)} className="h-9 w-9 rounded-full bg-white/15 hover:bg-white/25 flex items-center justify-center">
              <X className="h-5 w-5" />
            </button>
          </div>

          {/* Persistent paused banner during private session */}
          {isPaused && (
            <div className="absolute top-16 inset-x-4 z-30 rounded-xl bg-gradient-to-r from-purple-700/90 to-indigo-700/90 backdrop-blur-md border border-purple-300/30 px-4 py-2.5 flex items-center gap-2 shadow-lg animate-in fade-in slide-in-from-top-2">
              <Lock className="h-4 w-4 text-purple-100" />
              <span className="text-sm font-semibold text-white">🔒 Live paused — you are in a private session</span>
            </div>
          )}

          {/* Pending live-call requests panel */}
          {astro && <LiveCallRequestPanel astrologerId={astro.id} liveStreamId={active.id} />}

          <div className="absolute right-4 top-1/2 -translate-y-1/2 flex flex-col gap-3">
            <button onClick={switchCamera} className="h-11 w-11 rounded-full bg-white/15 hover:bg-white/25 flex items-center justify-center" title="Switch camera">
              <Camera className="h-5 w-5" />
            </button>
            <button onClick={toggleMic} className="h-11 w-11 rounded-full bg-white/15 hover:bg-white/25 flex items-center justify-center">
              {muted ? <MicOff className="h-5 w-5" /> : <Mic className="h-5 w-5" />}
            </button>
            <button onClick={toggleCam} className="h-11 w-11 rounded-full bg-white/15 hover:bg-white/25 flex items-center justify-center">
              {videoOff ? <VideoOff className="h-5 w-5" /> : <Video className="h-5 w-5" />}
            </button>
            <button className="h-11 w-11 rounded-full bg-white/15 hover:bg-white/25 flex items-center justify-center" title="Beauty filter (Phase 2)">
              <Sparkles className="h-5 w-5" />
            </button>
          </div>

          <div className="absolute bottom-0 inset-x-0 p-4 bg-gradient-to-t from-black/80 to-transparent">
            <div className="max-h-44 overflow-hidden mb-3 space-y-1.5">
              {comments.slice(-6).map((c) => (
                <div key={c.id} className="flex items-start gap-2 text-sm">
                  <Avatar className="h-6 w-6 shrink-0">
                    <AvatarImage src={c.user_avatar ?? undefined} />
                    <AvatarFallback className="text-[10px]">{c.user_name.slice(0, 1).toUpperCase()}</AvatarFallback>
                  </Avatar>
                  <div>
                    <span className={cn("font-semibold mr-1", c.is_host ? "text-amber-300" : "text-white/90")}>
                      {c.user_name}{c.is_host && " · HOST"}:
                    </span>
                    <span className="text-white/85">{c.comment_text}</span>
                  </div>
                </div>
              ))}
            </div>
            <div className="flex gap-2">
              <Input value={hostMessage} onChange={(e) => setHostMessage(e.target.value)}
                onKeyDown={(e) => e.key === "Enter" && postHostMessage()}
                placeholder="Reply to viewers…"
                className="bg-white/10 border-white/20 text-white placeholder:text-white/50" />
              <Button onClick={postHostMessage}>Send</Button>
            </div>
          </div>
        </div>

        {/* Gift overlay (floating cards + premium burst) */}
        <LiveGiftHost
          liveStreamId={active.id}
          onGift={(ev) => {
            const def = giftByType(ev.gift_type);
            const earn = def ? def.amount * 0.30 : 0;
            setStreamEarnings((c) => c + earn);
            setEarningsPulse(true);
            setTimeout(() => setEarningsPulse(false), 800);
            setRecentGifts((cur) => [ev, ...cur].slice(0, 10));
          }}
        />

        {/* Recent Gifts side panel */}
        {giftsPanelOpen && (
          <div className="absolute right-0 top-0 bottom-0 w-72 max-w-[80vw] z-30 bg-black/80 backdrop-blur-md border-l border-amber-300/30 p-4 overflow-y-auto animate-in slide-in-from-right">
            <div className="flex items-center justify-between mb-3">
              <div className="font-semibold text-amber-300 flex items-center gap-2"><Gift className="h-4 w-4" /> Recent Gifts</div>
              <button onClick={() => setGiftsPanelOpen(false)} className="h-7 w-7 rounded-full bg-white/15 hover:bg-white/25 flex items-center justify-center"><X className="h-4 w-4" /></button>
            </div>
            {recentGifts.length === 0 ? (
              <div className="text-xs text-white/50 text-center py-8">No gifts yet — your viewers will surprise you soon ✨</div>
            ) : (
              <div className="space-y-2">
                {recentGifts.map((g) => {
                  const def = giftByType(g.gift_type);
                  const earn = def ? (def.amount * 0.30).toFixed(2) : "0";
                  return (
                    <div key={g.id} className="rounded-xl bg-white/5 border border-white/10 p-2.5">
                      <div className="flex items-center gap-2">
                        <Avatar className="h-7 w-7"><AvatarImage src={g.sender_avatar ?? undefined} /><AvatarFallback className="text-[10px]">{g.sender_name.slice(0,1)}</AvatarFallback></Avatar>
                        <div className="min-w-0 flex-1">
                          <div className="text-xs font-semibold text-white truncate">{g.sender_name}</div>
                          <div className="text-[11px] text-amber-300">{def?.label ?? g.gift_type} {def?.emoji}</div>
                        </div>
                        <div className="text-right">
                          <div className="text-xs font-bold text-amber-300">+₹{earn}</div>
                        </div>
                      </div>
                      {g.customer_note && <div className="mt-1.5 text-[11px] italic text-white/70">"{g.customer_note}"</div>}
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        )}

        <Dialog open={endOpen} onOpenChange={setEndOpen}>
          <DialogContent>
            <DialogHeader><DialogTitle>End your live?</DialogTitle></DialogHeader>
            <div className="grid grid-cols-2 gap-3 text-sm">
              <Card className="p-3"><div className="text-muted-foreground text-xs">Duration</div><div className="text-lg font-semibold">{fmtTime(duration)}</div></Card>
              <Card className="p-3"><div className="text-muted-foreground text-xs">Viewers</div><div className="text-lg font-semibold">{stats.viewer_count}</div></Card>
              <Card className="p-3"><div className="text-muted-foreground text-xs">Likes</div><div className="text-lg font-semibold">{stats.total_likes}</div></Card>
              <Card className="p-3"><div className="text-muted-foreground text-xs">Gifts</div><div className="text-lg font-semibold">₹{stats.total_gifts_value}</div></Card>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setEndOpen(false)}>Cancel</Button>
              <Button variant="destructive" onClick={endLive}>End live</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>
    );
  }

  // === LANDING ===
  return (
    <div className="p-6 max-w-4xl mx-auto space-y-6">
      <div className="rounded-2xl bg-gradient-to-br from-amber-500/15 via-fuchsia-500/10 to-purple-600/15 border border-amber-300/20 p-8">
        <div className="flex items-center gap-2 text-amber-300 text-xs uppercase tracking-wider font-semibold">
          <Radio className="h-4 w-4" /> AstroLive
        </div>
        <h1 className="text-3xl font-bold mt-2">Go Live with AstroLive</h1>
        <p className="text-muted-foreground mt-2">Connect with thousands of viewers in real-time. Earn from gifts, build your following, and grow your brand.</p>
        <Button size="lg" className="mt-5 bg-gradient-to-r from-amber-500 to-fuchsia-500 hover:opacity-90" onClick={() => setSetupOpen(true)}>
          <Radio className="h-5 w-5 mr-2" /> Start New Live
        </Button>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <Card className="p-4"><div className="text-xs text-muted-foreground">Total lives</div><div className="text-2xl font-semibold">{pastStats.total}</div></Card>
        <Card className="p-4"><div className="text-xs text-muted-foreground">Watch hours</div><div className="text-2xl font-semibold">{pastStats.watchHours}</div></Card>
        <Card className="p-4"><div className="text-xs text-muted-foreground">Gifts earned</div><div className="text-2xl font-semibold">₹{pastStats.gifts}</div></Card>
      </div>

      {demoMode && (
        <Card className="p-4 border-amber-500/30 bg-amber-500/5 text-sm text-amber-200">
          <strong>Demo Mode:</strong> Real video streaming is disabled (no Agora App ID configured). All chat, likes, viewers, and admin controls work normally.
        </Card>
      )}

      <Dialog open={setupOpen} onOpenChange={setSetupOpen}>
        <DialogContent className="max-w-lg">
          <DialogHeader><DialogTitle>Set up your live</DialogTitle></DialogHeader>
          <div className="space-y-4">
            <div>
              <label className="text-xs font-medium text-muted-foreground">Live title</label>
              <Input value={title} onChange={(e) => setTitle(e.target.value)} placeholder="What will you talk about?" />
            </div>
            <div>
              <label className="text-xs font-medium text-muted-foreground">Description (optional)</label>
              <Textarea rows={2} value={description} onChange={(e) => setDescription(e.target.value)} />
            </div>
            <div className="aspect-video rounded-lg bg-muted overflow-hidden flex items-center justify-center">
              {demoMode ? (
                <div className="text-center text-muted-foreground text-sm p-4">
                  <Video className="h-8 w-8 mx-auto mb-2 opacity-60" /> Camera preview disabled in Demo Mode
                </div>
              ) : (
                <div ref={previewVideoRef} className="w-full h-full bg-black" />
              )}
            </div>
            <div className="flex items-center justify-between rounded-lg border p-3">
              <div>
                <div className="text-sm font-medium">Save recording for replay</div>
                <div className="text-xs text-muted-foreground">Viewers can watch later (Phase 2)</div>
              </div>
              <Switch checked={saveRecording} onCheckedChange={setSaveRecording} />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setSetupOpen(false)}>Cancel</Button>
            <Button onClick={startLive} disabled={starting} className="bg-gradient-to-r from-amber-500 to-fuchsia-500">
              <Radio className="h-4 w-4 mr-2" /> {starting ? "Starting…" : "Go Live Now"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
