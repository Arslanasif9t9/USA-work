import { useEffect, useState } from "react";
import { useAuth } from "@/contexts/AuthContext";
import { useAstrologerAccount } from "@/hooks/useAstrologerAccount";
import { useWallet, formatINR } from "@/hooks/useWallet";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { startOfMonth, startOfWeek, format } from "date-fns";
import { toast } from "sonner";
import { ResponsiveContainer, PieChart, Pie, Cell, Tooltip, Legend } from "recharts";
import { usePlatformSettings } from "@/hooks/usePlatformSettings";

export default function AstrologerEarnings() {
  const { user } = useAuth();
  const { astro } = useAstrologerAccount();
  const { wallet } = useWallet();
  const settings = usePlatformSettings();
  const MIN_WITHDRAW = settings?.min_withdrawal_amount ?? 200;
  const MAX_WITHDRAW = settings?.max_withdrawal_amount ?? 50000;
  const PROCESSING_NOTICE = settings?.withdrawal_processing_notice ?? "Payouts processed manually within 2-3 business days.";
  const [stats, setStats] = useState({ lifetime: 0, month: 0, week: 0, today: 0, chat: 0, call: 0, gift: 0 });
  const [history, setHistory] = useState<any[]>([]);
  const [withdrawals, setWithdrawals] = useState<any[]>([]);
  const [open, setOpen] = useState(false);
  const [amount, setAmount] = useState("");
  const [method, setMethod] = useState<"upi" | "bank">("upi");
  const [upi, setUpi] = useState("");
  const [bankName, setBankName] = useState("");
  const [bankAcc, setBankAcc] = useState("");
  const [bankIfsc, setBankIfsc] = useState("");
  const [submitting, setSubmitting] = useState(false);

  const reloadWithdrawals = async () => {
    if (!user) return;
    const { data } = await supabase
      .from("withdrawal_requests")
      .select("*")
      .eq("astrologer_user_id", user.id)
      .order("created_at", { ascending: false });
    setWithdrawals(data ?? []);
  };

  useEffect(() => {
    if (!astro || !user) return;
    let cancelled = false;
    (async () => {
      const [{ data: chats }, { data: calls }, { data: gifts }, { data: w }, { data: txs }] = await Promise.all([
        supabase.from("chat_sessions").select("astrologer_earning, ended_at, status").eq("astrologer_id", astro.id).eq("status", "ended"),
        supabase.from("call_sessions").select("astrologer_earning, ended_at, status").eq("astrologer_id", astro.id).in("status", ["ended", "completed"]),
        supabase.from("gifts").select("astrologer_earning, created_at").eq("astrologer_id", astro.id),
        supabase.from("withdrawal_requests").select("*").eq("astrologer_user_id", user.id).order("created_at", { ascending: false }),
        supabase.from("transactions").select("id, type, amount, description, created_at, balance_after").eq("wallet_id", wallet?.id ?? "00000000-0000-0000-0000-000000000000").order("created_at", { ascending: false }).limit(50),
      ]);
      if (cancelled) return;
      const all = [
        ...(chats ?? []).map((r: any) => ({ ...r, kind: "chat", when: r.ended_at })),
        ...(calls ?? []).map((r: any) => ({ ...r, kind: "call", when: r.ended_at })),
        ...(gifts ?? []).map((r: any) => ({ ...r, kind: "gift", when: r.created_at })),
      ];
      const monthStart = startOfMonth(new Date());
      const weekStart = startOfWeek(new Date());
      const today = new Date();
      const sum = (rows: any[]) => rows.reduce((s, r) => s + Number(r.astrologer_earning ?? 0), 0);
      const lifetime = sum(all);
      const month = sum(all.filter((r) => r.when && new Date(r.when) >= monthStart));
      const week = sum(all.filter((r) => r.when && new Date(r.when) >= weekStart));
      const day = sum(all.filter((r) => r.when && format(new Date(r.when), "yyyy-MM-dd") === format(today, "yyyy-MM-dd")));
      const monthFiltered = all.filter((r) => r.when && new Date(r.when) >= monthStart);
      const chat = sum(monthFiltered.filter((r) => r.kind === "chat"));
      const call = sum(monthFiltered.filter((r) => r.kind === "call"));
      const gift = sum(monthFiltered.filter((r) => r.kind === "gift"));
      setStats({ lifetime, month, week, today: day, chat, call, gift });
      setWithdrawals(w ?? []);
      setHistory(txs ?? []);
    })();
    return () => { cancelled = true; };
  }, [astro, user, wallet?.id]);

  const submit = async () => {
    if (!user) return;
    const amt = Number(amount);
    if (!Number.isFinite(amt) || amt < MIN_WITHDRAW) {
      toast.error(`Minimum withdrawal is ₹${MIN_WITHDRAW}`);
      return;
    }
    if (amt > MAX_WITHDRAW) {
      toast.error(`Maximum withdrawal per request is ₹${MAX_WITHDRAW}`);
      return;
    }
    if ((wallet?.balance ?? 0) < amt) {
      toast.error("Insufficient wallet balance");
      return;
    }
    setSubmitting(true);
    // Use RPC so the wallet is debited atomically (refunded automatically on rejection)
    const { data, error } = await supabase.rpc("request_withdrawal", {
      _amount: amt,
      _method: method,
      _upi_id: method === "upi" ? upi : null,
      _bank_name: method === "bank" ? bankName : null,
      _bank_account: method === "bank" ? bankAcc : null,
      _bank_ifsc: method === "bank" ? bankIfsc : null,
    });
    setSubmitting(false);
    if (error || (data as any)?.ok === false) {
      toast.error(error?.message ?? (data as any)?.error ?? "Could not submit");
      return;
    }
    toast.success("Withdrawal request submitted — amount held until processed");
    setOpen(false);
    setAmount("");
    await reloadWithdrawals();
  };

  const pie = [
    { name: "Chat", value: stats.chat, color: "#fbbf24" },
    { name: "Call", value: stats.call, color: "#10b981" },
    { name: "Gifts", value: stats.gift, color: "#a78bfa" },
  ].filter((p) => p.value > 0);

  return (
    <>
      <div className="container max-w-6xl space-y-6 p-6">
        <div>
          <h1 className="font-serif text-3xl font-bold text-white">Earnings</h1>
          <p className="text-sm text-white/50">Your 30% share of every consultation.</p>
        </div>

        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
          {[
            { label: "Lifetime", v: stats.lifetime },
            { label: "This month", v: stats.month },
            { label: "This week", v: stats.week },
            { label: "Today", v: stats.today },
          ].map((s) => (
            <div key={s.label} className="rounded-2xl border border-amber-300/20 bg-gradient-to-br from-amber-500/15 to-amber-500/5 p-5">
              <p className="text-xs uppercase tracking-wider text-amber-200/80">{s.label}</p>
              <p className="mt-2 text-3xl font-bold text-amber-100">₹{s.v.toFixed(0)}</p>
            </div>
          ))}
        </div>

        <div className="grid gap-4 lg:grid-cols-[1fr_auto]">
          <Card className="border-white/10 bg-[#0E1628]">
            <CardContent className="p-6">
              <p className="text-sm text-white/60">Withdrawable balance</p>
              <p className="mt-1 text-4xl font-bold text-white">{formatINR(wallet?.balance ?? 0)}</p>
              <p className="mt-1 text-xs text-white/50">Minimum withdrawal: ₹{MIN_WITHDRAW}. {PROCESSING_NOTICE}</p>
              <Button onClick={() => setOpen(true)} className="mt-4 bg-gradient-to-r from-amber-500 to-amber-400 text-black hover:from-amber-400 hover:to-amber-300">Request Withdrawal</Button>
            </CardContent>
          </Card>
          <Card className="border-white/10 bg-[#0E1628] lg:w-80">
            <CardContent className="p-6">
              <p className="mb-3 text-sm font-semibold text-white">This month by type</p>
              <div className="h-44">
                <ResponsiveContainer>
                  <PieChart>
                    <Pie data={pie} cx="50%" cy="50%" innerRadius={42} outerRadius={64} dataKey="value">
                      {pie.map((p, i) => <Cell key={i} fill={p.color} />)}
                    </Pie>
                    <Tooltip contentStyle={{ background: "#0E1628", border: "1px solid rgba(255,255,255,0.1)", borderRadius: 8, color: "#fff" }} formatter={(v: any) => [`₹${v}`, ""]} />
                    <Legend wrapperStyle={{ color: "rgba(255,255,255,0.7)", fontSize: 11 }} />
                  </PieChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>
        </div>

        <Card className="border-white/10 bg-[#0E1628]">
          <CardContent className="p-6">
            <p className="mb-3 font-semibold text-white">Withdrawal requests</p>
            {withdrawals.length === 0 ? (
              <p className="py-4 text-sm text-white/50">No requests yet.</p>
            ) : (
              <div className="divide-y divide-white/5">
                {withdrawals.map((w) => (
                  <div key={w.id} className="flex items-center justify-between py-3">
                    <div>
                      <p className="text-sm font-medium text-white">₹{Number(w.amount).toFixed(0)} · {w.method.toUpperCase()}</p>
                      <p className="text-xs text-white/50">{format(new Date(w.created_at), "dd MMM yyyy, hh:mm a")}</p>
                    </div>
                    <span className={`rounded-full border px-2 py-0.5 text-xs ${
                      w.status === "paid" ? "border-emerald-300/30 bg-emerald-500/10 text-emerald-200" :
                      w.status === "approved" ? "border-blue-300/30 bg-blue-500/10 text-blue-200" :
                      w.status === "rejected" ? "border-rose-300/30 bg-rose-500/10 text-rose-200" :
                      "border-amber-300/30 bg-amber-500/10 text-amber-200"
                    }`}>{w.status}</span>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        <Card className="border-white/10 bg-[#0E1628]">
          <CardContent className="p-6">
            <p className="mb-3 font-semibold text-white">Wallet activity</p>
            {history.length === 0 ? (
              <p className="py-4 text-sm text-white/50">No transactions yet.</p>
            ) : (
              <div className="divide-y divide-white/5 max-h-96 overflow-y-auto">
                {history.map((t) => (
                  <div key={t.id} className="flex items-center justify-between py-3">
                    <div className="min-w-0">
                      <p className="truncate text-sm text-white">{t.description}</p>
                      <p className="text-[11px] text-white/40">{format(new Date(t.created_at), "dd MMM, hh:mm a")}</p>
                    </div>
                    <p className={`text-sm font-bold tabular-nums ${["consultation_credit","top_up","call_hold_release","refund"].includes(t.type) ? "text-emerald-300" : "text-rose-300"}`}>
                      {["consultation_credit","top_up","call_hold_release","refund"].includes(t.type) ? "+" : "-"} ₹{Number(t.amount).toFixed(0)}
                    </p>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="bg-[#0E1628] border-white/10 text-white">
          <DialogHeader><DialogTitle>Request Withdrawal</DialogTitle></DialogHeader>
          <div className="space-y-3">
            <div>
              <Label>Amount (₹)</Label>
              <Input type="number" value={amount} onChange={(e) => setAmount(e.target.value)} className="bg-white/5 border-white/10 text-white" />
            </div>
            <div>
              <Label>Method</Label>
              <div className="mt-1 grid grid-cols-2 gap-2">
                <button onClick={() => setMethod("upi")} className={`rounded-lg border px-3 py-2 text-sm ${method === "upi" ? "border-amber-300 bg-amber-300/10 text-amber-200" : "border-white/10 text-white/70"}`}>UPI</button>
                <button onClick={() => setMethod("bank")} className={`rounded-lg border px-3 py-2 text-sm ${method === "bank" ? "border-amber-300 bg-amber-300/10 text-amber-200" : "border-white/10 text-white/70"}`}>Bank</button>
              </div>
            </div>
            {method === "upi" ? (
              <div>
                <Label>UPI ID</Label>
                <Input value={upi} onChange={(e) => setUpi(e.target.value)} placeholder="name@upi" className="bg-white/5 border-white/10 text-white" />
              </div>
            ) : (
              <>
                <Input value={bankName} onChange={(e) => setBankName(e.target.value)} placeholder="Bank name" className="bg-white/5 border-white/10 text-white" />
                <Input value={bankAcc} onChange={(e) => setBankAcc(e.target.value)} placeholder="Account number" className="bg-white/5 border-white/10 text-white" />
                <Input value={bankIfsc} onChange={(e) => setBankIfsc(e.target.value)} placeholder="IFSC" className="bg-white/5 border-white/10 text-white" />
              </>
            )}
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setOpen(false)} className="border-white/20 bg-transparent text-white hover:bg-white/10">Cancel</Button>
            <Button onClick={submit} disabled={submitting} className="bg-amber-500 text-black hover:bg-amber-400">Submit</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}
