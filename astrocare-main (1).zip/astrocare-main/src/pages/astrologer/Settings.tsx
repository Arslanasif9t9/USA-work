import { useEffect, useState } from "react";
import { useAuth } from "@/contexts/AuthContext";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { toast } from "sonner";

export default function AstrologerSettings() {
  const { user } = useAuth();
  const [settings, setSettings] = useState<any>({
    upi_id: "",
    bank_name: "",
    bank_account: "",
    bank_ifsc: "",
    notification_email: "",
    notify_new_request: true,
    notify_session_reminder: true,
    notify_review: true,
    notify_earnings: true,
  });
  const [pwd, setPwd] = useState("");
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (!user) return;
    supabase.from("astrologer_payout_settings").select("*").eq("user_id", user.id).maybeSingle().then(({ data }) => {
      if (data) setSettings((s: any) => ({ ...s, ...data, notification_email: (data as any).notification_email ?? user.email ?? "" }));
      else setSettings((s: any) => ({ ...s, notification_email: user.email ?? "" }));
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [user]);

  const save = async () => {
    if (!user) return;
    setSaving(true);
    const { error } = await supabase.from("astrologer_payout_settings").upsert({ ...settings, user_id: user.id });
    if (error) { setSaving(false); toast.error(error.message); return; }

    // Fire-and-forget confirmation email when any toggle is enabled
    const enabled = ["notify_new_request","notify_session_reminder","notify_review","notify_earnings"]
      .filter((k) => settings[k]).length;
    if (enabled > 0 && settings.notification_email) {
      try {
        await supabase.functions.invoke("send-astrologer-email", {
          body: {
            subject: "Your AstroCare notification preferences updated",
            to: settings.notification_email,
            html: `<div style="font-family:sans-serif;padding:24px;background:#0E1628;color:#fff;border-radius:12px">
              <h2 style="color:#fbbf24">Notification preferences updated</h2>
              <p>You'll receive updates at <b>${settings.notification_email}</b> for the channels you enabled (${enabled} active).</p>
              <p style="color:#9ca3af;font-size:12px">— AstroCare</p>
            </div>`,
          },
        });
      } catch (_) { /* silent */ }
    }
    setSaving(false);
    toast.success("Settings saved");
  };

  const changePassword = async () => {
    if (!pwd || pwd.length < 8) { toast.error("Password must be 8+ characters"); return; }
    const { error } = await supabase.auth.updateUser({ password: pwd });
    if (error) toast.error(error.message);
    else { toast.success("Password updated"); setPwd(""); }
  };

  return (
    <div className="container max-w-4xl space-y-6 p-6">
      <div>
        <h1 className="font-serif text-3xl font-bold text-white">Settings</h1>
        <p className="text-sm text-white/50">Account, payouts, and notification preferences.</p>
      </div>

      {/* Account */}
      <Card className="border-white/10 bg-[#0E1628]">
        <CardContent className="p-6 space-y-5">
          <div className="flex items-center gap-2">
            <span className="h-1.5 w-1.5 rounded-full bg-amber-300" />
            <p className="text-[11px] font-semibold uppercase tracking-wider text-amber-200/80">Account</p>
          </div>
          <div className="grid gap-4 sm:grid-cols-[1fr_auto] sm:items-end">
            <div className="space-y-1.5">
              <Label className="text-white/80">New password (8+ characters)</Label>
              <Input type="password" value={pwd} onChange={(e) => setPwd(e.target.value)} placeholder="••••••••" className="bg-white/5 border-white/10 text-white" />
            </div>
            <Button onClick={changePassword} className="bg-amber-500 text-black hover:bg-amber-400">Change password</Button>
          </div>
        </CardContent>
      </Card>

      {/* Payouts */}
      <Card className="border-white/10 bg-[#0E1628]">
        <CardContent className="p-6 space-y-5">
          <div className="flex items-center gap-2">
            <span className="h-1.5 w-1.5 rounded-full bg-amber-300" />
            <p className="text-[11px] font-semibold uppercase tracking-wider text-amber-200/80">Payout details</p>
          </div>
          <div className="space-y-1.5">
            <Label className="text-white/80">UPI ID</Label>
            <Input value={settings.upi_id ?? ""} onChange={(e) => setSettings({ ...settings, upi_id: e.target.value })} placeholder="name@upi" className="bg-white/5 border-white/10 text-white" />
          </div>
          <div className="space-y-1.5">
            <Label className="text-white/80">Bank account</Label>
            <div className="grid gap-3 sm:grid-cols-3">
              <Input value={settings.bank_name ?? ""} onChange={(e) => setSettings({ ...settings, bank_name: e.target.value })} placeholder="Bank name" className="bg-white/5 border-white/10 text-white" />
              <Input value={settings.bank_account ?? ""} onChange={(e) => setSettings({ ...settings, bank_account: e.target.value })} placeholder="Account number" className="bg-white/5 border-white/10 text-white" />
              <Input value={settings.bank_ifsc ?? ""} onChange={(e) => setSettings({ ...settings, bank_ifsc: e.target.value })} placeholder="IFSC" className="bg-white/5 border-white/10 text-white" />
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Notifications */}
      <Card className="border-white/10 bg-[#0E1628]">
        <CardContent className="p-6 space-y-5">
          <div className="flex items-center gap-2">
            <span className="h-1.5 w-1.5 rounded-full bg-amber-300" />
            <p className="text-[11px] font-semibold uppercase tracking-wider text-amber-200/80">Notifications</p>
          </div>
          <div className="space-y-1.5">
            <Label className="text-white/80">Notification email</Label>
            <Input
              type="email"
              value={settings.notification_email ?? ""}
              onChange={(e) => setSettings({ ...settings, notification_email: e.target.value })}
              placeholder="you@example.com"
              className="bg-white/5 border-white/10 text-white"
            />
            <p className="text-xs text-white/40">Updates for the channels below will be sent here.</p>
          </div>
          <div className="grid gap-2 sm:grid-cols-2">
            {[
              ["notify_new_request", "New session requests"],
              ["notify_session_reminder", "Session reminders"],
              ["notify_review", "New review alerts"],
              ["notify_earnings", "Earnings updates"],
            ].map(([k, label]) => (
              <div key={k} className="flex items-center justify-between rounded-lg border border-white/5 bg-white/5 px-3 py-2.5">
                <span className="text-sm text-white/80">{label}</span>
                <Switch checked={!!settings[k as string]} onCheckedChange={(v) => setSettings({ ...settings, [k as string]: v })} />
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      <div className="sticky bottom-4 flex justify-end">
        <Button onClick={save} disabled={saving} className="bg-amber-500 text-black hover:bg-amber-400 shadow-lg shadow-amber-500/20">
          {saving ? "Saving…" : "Save settings"}
        </Button>
      </div>
    </div>
  );
}
