import { useEffect, useState } from "react";
import { AppShell } from "@/components/layout/AppShell";
import { AstrologerChatPanel } from "@/components/chat/AstrologerChatPanel";
import { ProtectedRoute } from "@/components/auth/ProtectedRoute";
import { useAuth } from "@/contexts/AuthContext";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { Loader2, Phone, Save, Star, Users, Wifi, WifiOff } from "lucide-react";
import { SessionHistoryList } from "@/components/history/SessionHistoryList";

type AstroStatus = "online" | "busy" | "offline";

interface AstroRow {
  id: string;
  display_name: string;
  status: string;
  is_online: boolean;
  accepting_calls: boolean;
  rating_avg: number;
  rating_count: number;
  follower_count: number;
  base_rate_per_min: number;
  discounted_rate_per_min: number | null;
  experience_years: number;
  specializations: string[];
  languages: string[];
  bio: string | null;
  avatar_url: string | null;
  phone_number: string | null;
  education: string | null;
  focus_area: string | null;
  systems_known: string[];
  total_consultations: number;
  chat_rate_per_min: number;
  accepting_chat: boolean;
  is_chat_online: boolean;
}

function AstrologerDashboardInner() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [astro, setAstro] = useState<AstroRow | null>(null);
  const [loading, setLoading] = useState(true);
  const [updating, setUpdating] = useState(false);
  const [savingProfile, setSavingProfile] = useState(false);
  const [activeCalls, setActiveCalls] = useState(0);

  // editable form state
  const [form, setForm] = useState({
    display_name: "",
    bio: "",
    avatar_url: "",
    phone_number: "",
    base_rate_per_min: 0,
    discounted_rate_per_min: "" as string | "",
    experience_years: 0,
    specializations: "",
    languages: "",
    education: "",
    focus_area: "",
    systems_known: "",
    total_consultations: 0,
  });

  useEffect(() => {
    if (!user) return;
    let cancelled = false;
    (async () => {
      setLoading(true);
      const { data, error } = await supabase
        .from("astrologers")
        .select("id, display_name, status, is_online, accepting_calls, rating_avg, rating_count, follower_count, base_rate_per_min, discounted_rate_per_min, experience_years, specializations, languages, bio, avatar_url, phone_number, education, focus_area, systems_known, total_consultations, chat_rate_per_min, accepting_chat, is_chat_online")
        .eq("user_id", user.id)
        .maybeSingle();
      if (cancelled) return;
      if (error) {
        toast({ title: "Could not load profile", description: error.message, variant: "destructive" });
      }
      const a = data as AstroRow | null;
      setAstro(a);
      if (a) {
        setForm({
          display_name: a.display_name,
          bio: a.bio ?? "",
          avatar_url: a.avatar_url ?? "",
          phone_number: a.phone_number ?? "",
          base_rate_per_min: Number(a.base_rate_per_min),
          discounted_rate_per_min: a.discounted_rate_per_min == null ? "" : String(a.discounted_rate_per_min),
          experience_years: a.experience_years,
          specializations: (a.specializations ?? []).join(", "),
          languages: (a.languages ?? []).join(", "),
          education: a.education ?? "",
          focus_area: a.focus_area ?? "",
          systems_known: (a.systems_known ?? []).join(", "),
          total_consultations: a.total_consultations ?? 0,
        });
        const { count } = await supabase
          .from("call_sessions")
          .select("id", { count: "exact", head: true })
          .eq("astrologer_id", a.id)
          .in("status", ["pending", "ringing_astrologer", "ringing_user", "connected", "mock_connected"]);
        if (!cancelled) setActiveCalls(count ?? 0);
      }
      setLoading(false);
    })();
    return () => { cancelled = true; };
  }, [user, toast]);

  const setStatus = async (next: AstroStatus) => {
    if (!astro) return;
    setUpdating(true);
    const patch =
      next === "online"
        ? { status: "online", is_online: true, accepting_calls: true, last_seen_at: new Date().toISOString() }
        : next === "busy"
        ? { status: "busy", is_online: true, accepting_calls: false, last_seen_at: new Date().toISOString() }
        : { status: "offline", is_online: false, accepting_calls: false };

    const { error } = await supabase.from("astrologers").update(patch).eq("id", astro.id);
    if (error) {
      toast({ title: "Couldn't update status", description: error.message, variant: "destructive" });
    } else {
      setAstro({ ...astro, ...patch } as AstroRow);
      toast({ title: `You are now ${next}` });
    }
    setUpdating(false);
  };

  const saveProfile = async () => {
    if (!astro) return;
    setSavingProfile(true);
    const patch = {
      display_name: form.display_name.trim(),
      bio: form.bio.trim() || null,
      avatar_url: form.avatar_url.trim() || null,
      phone_number: form.phone_number.trim() || null,
      base_rate_per_min: Number(form.base_rate_per_min) || 0,
      discounted_rate_per_min: form.discounted_rate_per_min === "" ? null : Number(form.discounted_rate_per_min),
      experience_years: Number(form.experience_years) || 0,
      specializations: form.specializations.split(",").map((s) => s.trim()).filter(Boolean),
      languages: form.languages.split(",").map((s) => s.trim()).filter(Boolean),
      education: form.education.trim() || null,
      focus_area: form.focus_area.trim() || null,
      systems_known: form.systems_known.split(",").map((s) => s.trim()).filter(Boolean),
      total_consultations: Number(form.total_consultations) || 0,
    };
    const { error } = await supabase.from("astrologers").update(patch).eq("id", astro.id);
    if (error) {
      toast({ title: "Couldn't save", description: error.message, variant: "destructive" });
    } else {
      setAstro({ ...astro, ...patch } as AstroRow);
      toast({ title: "Profile saved", description: "Customers will see your updated details." });
    }
    setSavingProfile(false);
  };

  if (loading) {
    return (
      <AppShell>
        <div className="container py-16 text-center text-muted-foreground">
          <Loader2 className="h-6 w-6 animate-spin mx-auto mb-2" />
          Loading…
        </div>
      </AppShell>
    );
  }

  if (!astro) {
    return (
      <AppShell>
        <div className="container py-16 max-w-xl text-center">
          <h1 className="text-2xl font-bold mb-2">Not an astrologer account</h1>
          <p className="text-muted-foreground">
            This dashboard is for verified astrologers. If you believe this is a mistake, please contact support.
          </p>
        </div>
      </AppShell>
    );
  }

  const current = (astro.status as AstroStatus) ?? "offline";
  const rate = astro.discounted_rate_per_min ?? astro.base_rate_per_min;

  return (
    <AppShell>
      <section className="container py-8 md:py-12 space-y-6">
        <div className="flex items-start justify-between flex-wrap gap-4">
          <div>
            <p className="text-sm text-muted-foreground">Astrologer dashboard</p>
            <h1 className="text-2xl md:text-3xl font-bold">{astro.display_name}</h1>
          </div>
          <Badge
            variant="secondary"
            className={
              current === "online"
                ? "bg-success/15 text-success border-success/30"
                : current === "busy"
                ? "bg-amber-500/15 text-amber-700 border-amber-500/30"
                : "bg-muted text-muted-foreground"
            }
          >
            {current === "online" ? "Online" : current === "busy" ? "Busy" : "Offline"}
          </Badge>
        </div>

        <Card>
          <CardHeader>
            <CardTitle className="text-base">Availability (manual)</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <p className="text-sm text-muted-foreground">
              Customers can only call you when you're <strong>Online</strong>. Your status will <strong>not</strong> change automatically — only these toggles can change it.
            </p>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <Button
                variant={current === "online" ? "saffron" : "outline"}
                onClick={() => setStatus("online")}
                disabled={updating || current === "online"}
                className="justify-start"
              >
                <Wifi className="h-4 w-4" /> Go Online
              </Button>
              <Button
                variant={current === "busy" ? "saffron" : "outline"}
                onClick={() => setStatus("busy")}
                disabled={updating || current === "busy"}
                className="justify-start"
              >
                <Phone className="h-4 w-4" /> Set Busy
              </Button>
              <Button
                variant={current === "offline" ? "saffron" : "outline"}
                onClick={() => setStatus("offline")}
                disabled={updating || current === "offline"}
                className="justify-start"
              >
                <WifiOff className="h-4 w-4" /> Go Offline
              </Button>
            </div>
          </CardContent>
        </Card>

        <AstrologerChatPanel
          astrologerId={astro.id}
          initialAcceptingChat={astro.accepting_chat ?? true}
          initialChatOnline={astro.is_chat_online ?? true}
          initialChatRate={Number(astro.chat_rate_per_min ?? astro.base_rate_per_min)}
        />

        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          <Card>
            <CardContent className="pt-6">
              <p className="text-xs text-muted-foreground uppercase tracking-wide">Current Rate</p>
              <p className="text-2xl font-bold mt-1">₹{rate}<span className="text-sm font-normal text-muted-foreground">/min</span></p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-6">
              <p className="text-xs text-muted-foreground uppercase tracking-wide flex items-center gap-1">
                <Star className="h-3 w-3" /> Rating
              </p>
              <p className="text-2xl font-bold mt-1">
                {Number(astro.rating_avg).toFixed(1)}
                <span className="text-sm font-normal text-muted-foreground"> ({astro.rating_count})</span>
              </p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-6">
              <p className="text-xs text-muted-foreground uppercase tracking-wide flex items-center gap-1">
                <Users className="h-3 w-3" /> Followers
              </p>
              <p className="text-2xl font-bold mt-1">{astro.follower_count}</p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-6">
              <p className="text-xs text-muted-foreground uppercase tracking-wide">Active calls</p>
              <p className="text-2xl font-bold mt-1">{activeCalls}</p>
            </CardContent>
          </Card>
        </div>

        {/* ===== Session history ===== */}
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Session history</CardTitle>
            <p className="text-sm text-muted-foreground">
              All your past chat and call consultations with earnings.
            </p>
          </CardHeader>
          <CardContent>
            <SessionHistoryList perspective="astrologer" />
          </CardContent>
        </Card>

        {/* ===== Editable public profile ===== */}
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Your public profile</CardTitle>
            <p className="text-sm text-muted-foreground">
              These details are shown to customers on the home page and your detail page.
            </p>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid gap-4 md:grid-cols-2">
              <div className="space-y-1.5">
                <Label htmlFor="display_name">Display name</Label>
                <Input
                  id="display_name"
                  value={form.display_name}
                  onChange={(e) => setForm({ ...form, display_name: e.target.value })}
                />
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="avatar_url">Avatar URL</Label>
                <Input
                  id="avatar_url"
                  placeholder="https://…"
                  value={form.avatar_url}
                  onChange={(e) => setForm({ ...form, avatar_url: e.target.value })}
                />
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="phone_number">Phone (for calls)</Label>
                <Input
                  id="phone_number"
                  placeholder="+91…"
                  value={form.phone_number}
                  onChange={(e) => setForm({ ...form, phone_number: e.target.value })}
                />
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="experience_years">Years of experience</Label>
                <Input
                  id="experience_years"
                  type="number"
                  min={0}
                  value={form.experience_years}
                  onChange={(e) => setForm({ ...form, experience_years: Number(e.target.value) })}
                />
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="base_rate_per_min">Base rate (₹/min)</Label>
                <Input
                  id="base_rate_per_min"
                  type="number"
                  min={0}
                  value={form.base_rate_per_min}
                  onChange={(e) => setForm({ ...form, base_rate_per_min: Number(e.target.value) })}
                />
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="discounted_rate_per_min">Discounted rate (₹/min, optional)</Label>
                <Input
                  id="discounted_rate_per_min"
                  type="number"
                  min={0}
                  value={form.discounted_rate_per_min}
                  onChange={(e) => setForm({ ...form, discounted_rate_per_min: e.target.value })}
                />
              </div>
              <div className="space-y-1.5 md:col-span-2">
                <Label htmlFor="specializations">Specializations (comma separated)</Label>
                <Input
                  id="specializations"
                  placeholder="vedic, tarot, kp_system"
                  value={form.specializations}
                  onChange={(e) => setForm({ ...form, specializations: e.target.value })}
                />
              </div>
              <div className="space-y-1.5 md:col-span-2">
                <Label htmlFor="languages">Languages (comma separated)</Label>
                <Input
                  id="languages"
                  placeholder="English, Hindi, Tamil"
                  value={form.languages}
                  onChange={(e) => setForm({ ...form, languages: e.target.value })}
                />
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="education">Education</Label>
                <Input
                  id="education"
                  placeholder="MA Jyotish, Banaras Hindu University"
                  value={form.education}
                  onChange={(e) => setForm({ ...form, education: e.target.value })}
                />
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="focus_area">Focus area</Label>
                <Input
                  id="focus_area"
                  placeholder="Marriage, Career, Health"
                  value={form.focus_area}
                  onChange={(e) => setForm({ ...form, focus_area: e.target.value })}
                />
              </div>
              <div className="space-y-1.5 md:col-span-2">
                <Label htmlFor="systems_known">Systems known (comma separated)</Label>
                <Input
                  id="systems_known"
                  placeholder="Vedic, KP, Lal Kitab, Nadi"
                  value={form.systems_known}
                  onChange={(e) => setForm({ ...form, systems_known: e.target.value })}
                />
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="total_consultations">Total consultations</Label>
                <Input
                  id="total_consultations"
                  type="number"
                  min={0}
                  value={form.total_consultations}
                  onChange={(e) => setForm({ ...form, total_consultations: Number(e.target.value) })}
                />
              </div>
              <div className="space-y-1.5 md:col-span-2">
                <Label htmlFor="bio">About / Bio</Label>
                <Textarea
                  id="bio"
                  rows={5}
                  placeholder="Tell customers about your expertise, approach and experience…"
                  value={form.bio}
                  onChange={(e) => setForm({ ...form, bio: e.target.value })}
                />
              </div>
            </div>

            <div className="flex justify-end">
              <Button onClick={saveProfile} disabled={savingProfile} variant="saffron">
                {savingProfile ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />}
                Save Profile
              </Button>
            </div>
          </CardContent>
        </Card>
      </section>
    </AppShell>
  );
}

export default function AstrologerDashboard() {
  return (
    <ProtectedRoute>
      <AstrologerDashboardInner />
    </ProtectedRoute>
  );
}
