import { useEffect, useMemo, useState } from "react";
import { useNavigate, useSearchParams } from "react-router-dom";
import { format, parse, isValid, addDays, subDays } from "date-fns";
import { useTranslation } from "react-i18next";
import {
  ArrowLeft, Calendar as CalendarIcon, ChevronLeft, ChevronRight, Clock, MapPin,
} from "lucide-react";
import { AppShell } from "@/components/layout/AppShell";
import { ErrorBoundary } from "@/components/ErrorBoundary";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Skeleton } from "@/components/ui/skeleton";
import { Alert, AlertDescription } from "@/components/ui/alert";
import {
  LocationAutocomplete, type LocationPick,
} from "@/components/birth-chart/LocationAutocomplete";
import { useBirthCharts } from "@/hooks/useBirthCharts";
import { usePanchang } from "@/hooks/usePanchang";
import { useAuth } from "@/contexts/AuthContext";
import { useLanguage } from "@/contexts/LanguageContext";
import { supabase } from "@/integrations/supabase/client";
import { tPlanetFull, formatLongDate } from "@/i18n/vedic";
import { cn } from "@/lib/utils";
import { HORA_PLANET_TINT, HORA_PLANET_COLOR, type HoraEntry } from "@/types/panchang";

const DEFAULT_LOCATION: LocationPick = {
  display_name: "New Delhi, India",
  lat: 28.6139,
  lon: 77.2090,
  timezone: "Asia/Kolkata",
};

function parseDDMMYYYY(s: string): Date | null {
  const parsed = parse(s, "dd-MM-yyyy", new Date());
  return isValid(parsed) ? parsed : null;
}

function parseISODate(s: string | null): Date | null {
  if (!s) return null;
  const parsed = parse(s, "yyyy-MM-dd", new Date());
  return isValid(parsed) ? parsed : null;
}

function formatTime(iso: string, tz: string) {
  return new Date(iso).toLocaleTimeString("en-US", {
    timeZone: tz, hour: "2-digit", minute: "2-digit", hour12: true,
  });
}

function isCurrent(entry: HoraEntry, now: number) {
  const s = new Date(entry.start).getTime();
  const e = new Date(entry.end).getTime();
  return now >= s && now < e;
}

function HoraTable({
  title, rows, timezone, now, lang,
}: { title: string; rows: HoraEntry[]; timezone: string; now: number; lang: "en" | "hi" }) {
  const { t } = useTranslation("panchang");
  return (
    <div className="rounded-md border border-primary/20 overflow-hidden">
      <div className="bg-primary/15 text-primary text-xs font-semibold uppercase tracking-wider px-3 py-2">
        {title}
      </div>
      <table className="w-full text-sm">
        <thead>
          <tr className="text-xs uppercase tracking-wide text-muted-foreground border-b border-border/40">
            <th className="text-left px-3 py-2 font-medium w-12">#</th>
            <th className="text-left px-3 py-2 font-medium">{t("planet")}</th>
            <th className="text-left px-3 py-2 font-medium tabular-nums">{lang === "hi" ? "प्रारम्भ" : "Start"}</th>
            <th className="text-left px-3 py-2 font-medium tabular-nums">{lang === "hi" ? "समाप्ति" : "End"}</th>
          </tr>
        </thead>
        <tbody>
          {rows.map((r) => {
            const cur = isCurrent(r, now);
            const tint = HORA_PLANET_TINT[r.planet];
            const color = HORA_PLANET_COLOR[r.planet];
            const planetLabel = tPlanetFull(r.planet, lang);
            return (
              <tr
                key={r.hour}
                className="border-t border-border/30 relative"
                style={{
                  background: tint,
                  outline: cur ? "2px solid hsl(45 90% 55%)" : "none",
                  outlineOffset: "-2px",
                }}
              >
                <td className="px-3 py-2 font-medium tabular-nums">{r.hour}</td>
                <td className="px-3 py-2">
                  <span className="font-bold" style={{ color }}>{planetLabel}</span>{" "}
                  {lang === "en" && (
                    <span className="text-muted-foreground text-xs">({r.sanskrit})</span>
                  )}
                  {cur && (
                    <span className="ml-2 inline-flex items-center gap-1 text-[10px] font-bold text-primary">
                      <span className="h-1.5 w-1.5 rounded-full bg-primary animate-pulse" />
                      {t("now")}
                    </span>
                  )}
                </td>
                <td className="px-3 py-2 tabular-nums">{formatTime(r.start, timezone)}</td>
                <td className="px-3 py-2 tabular-nums">{formatTime(r.end, timezone)}</td>
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
}

function HoraInner() {
  const { t } = useTranslation("panchang");
  const { lang } = useLanguage();
  const [params, setParams] = useSearchParams();
  const navigate = useNavigate();
  const { user } = useAuth();
  const { charts } = useBirthCharts();
  const primaryChart = charts[0];

  const [isAstro, setIsAstro] = useState(false);
  useEffect(() => {
    if (!user) { setIsAstro(false); return; }
    let cancelled = false;
    supabase
      .from("astrologers")
      .select("id", { head: true, count: "exact" })
      .eq("user_id", user.id)
      .then(({ count }) => { if (!cancelled) setIsAstro((count ?? 0) > 0); });
    return () => { cancelled = true; };
  }, [user]);
  const backTo = isAstro ? "/astrologer/overview" : "/astrologers";

  const [date, setDate] = useState<Date>(() => parseISODate(params.get("date")) ?? new Date());
  const [dateText, setDateText] = useState<string>(() => format(date, "dd-MM-yyyy"));
  const [calendarOpen, setCalendarOpen] = useState(false);

  const [location, setLocation] = useState<LocationPick>(() => {
    const lat = params.get("lat");
    const lon = params.get("lon");
    const tz = params.get("tz");
    const place = params.get("place");
    if (lat && lon && tz && place) {
      return { display_name: place, lat: Number(lat), lon: Number(lon), timezone: tz };
    }
    if (primaryChart) {
      return {
        display_name: primaryChart.location_name,
        lat: Number(primaryChart.latitude),
        lon: Number(primaryChart.longitude),
        timezone: primaryChart.timezone,
      };
    }
    return DEFAULT_LOCATION;
  });

  useEffect(() => {
    setDateText(format(date, "dd-MM-yyyy"));
  }, [date]);

  const isoDate = useMemo(() => format(date, "yyyy-MM-dd"), [date]);

  // Sync state → URL params
  useEffect(() => {
    setParams(
      {
        date: isoDate,
        lat: String(location.lat),
        lon: String(location.lon),
        tz: location.timezone,
        place: location.display_name,
      },
      { replace: true },
    );
  }, [isoDate, location, setParams]);

  // Switching to Panchang preserves date + city
  const panchangHref = useMemo(() => {
    const p = new URLSearchParams({
      date: isoDate,
      lat: String(location.lat),
      lon: String(location.lon),
      tz: location.timezone,
      place: location.display_name,
    });
    return `/panchang?${p.toString()}`;
  }, [isoDate, location]);

  const { data, isLoading, error } = usePanchang({
    date: isoDate,
    latitude: location.lat,
    longitude: location.lon,
    timezone: location.timezone,
  });

  const [now, setNow] = useState(() => Date.now());
  useEffect(() => {
    const id = window.setInterval(() => setNow(Date.now()), 60_000);
    return () => window.clearInterval(id);
  }, []);

  const dayLine = useMemo(() => {
    const longDate = formatLongDate(isoDate, location.timezone, lang);
    return `${t("hora_for")} ${longDate} ${t("in")} ${location.display_name}`;
  }, [isoDate, location, lang, t]);

  const onDateTextChange = (v: string) => {
    setDateText(v);
    const parsed = parseDDMMYYYY(v);
    if (parsed) setDate(parsed);
  };
  const onDateTextBlur = () => {
    const parsed = parseDDMMYYYY(dateText);
    if (!parsed) setDateText(format(date, "dd-MM-yyyy"));
  };

  return (
    <AppShell>
      <div className="container max-w-5xl py-4 md:py-6 space-y-5">
        {/* Top-level Panchang / Hora tabs */}
        <Tabs value="hora" className="w-full">
          <div className="flex items-center gap-2">
            <Button
              type="button"
              size="icon"
              variant="ghost"
              aria-label={t("back_to_panchang")}
              className="shrink-0"
              onClick={() => navigate(backTo)}
            >
              <ArrowLeft className="h-5 w-5" />
            </Button>
            <TabsList className="grid grid-cols-2 flex-1 max-w-md bg-primary/10">
              <TabsTrigger
                value="panchang"
                className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground text-base font-semibold"
                onClick={() => navigate(panchangHref)}
              >
                {t("tab_panchang")}
              </TabsTrigger>
              <TabsTrigger
                value="hora"
                className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground text-base font-semibold"
              >
                {t("tab_hora")}
              </TabsTrigger>
            </TabsList>
          </div>
        </Tabs>

        <header className="space-y-1">
          <h1 className="text-2xl md:text-3xl font-bold flex items-center gap-2">
            <Clock className="h-6 w-6 text-primary" /> {t("hora_planet_hours")}
          </h1>
          <p className="text-xs md:text-sm text-muted-foreground">{t("hora_subtitle")}</p>
        </header>

        <Card className="border-primary/30 bg-gradient-to-br from-card to-card/80 shadow-card">
          <CardContent className="pt-4 pb-4 space-y-3">
            <div className="flex flex-wrap items-center gap-2">
              <div className="relative flex-1 min-w-[150px]">
                <Input
                  value={dateText}
                  onChange={(e) => onDateTextChange(e.target.value)}
                  onBlur={onDateTextBlur}
                  placeholder={t("date_placeholder")}
                  className="pl-8 bg-background/60 border-primary/30 focus-visible:ring-primary tabular-nums"
                  inputMode="numeric"
                />
                <Popover open={calendarOpen} onOpenChange={setCalendarOpen}>
                  <PopoverTrigger asChild>
                    <button
                      type="button"
                      aria-label="Open calendar"
                      className="absolute left-2 top-1/2 -translate-y-1/2 text-primary hover:text-primary/80"
                    >
                      <CalendarIcon className="h-4 w-4" />
                    </button>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0" align="start">
                    <Calendar
                      mode="single"
                      selected={date}
                      onSelect={(d) => {
                        if (d) {
                          setDate(d);
                          setCalendarOpen(false);
                        }
                      }}
                      initialFocus
                      className={cn("p-3 pointer-events-auto")}
                    />
                  </PopoverContent>
                </Popover>
              </div>

              <div className="flex-[2] min-w-[200px]">
                <LocationAutocomplete
                  value={location}
                  onChange={(loc) => loc && setLocation(loc)}
                />
              </div>

              <div className="flex items-center gap-1">
                <Button
                  type="button"
                  size="icon"
                  variant="outline"
                  aria-label="Previous day"
                  className="border-primary/40 hover:bg-primary/10"
                  onClick={() => setDate((d) => subDays(d, 1))}
                >
                  <ChevronLeft className="h-4 w-4" />
                </Button>
                <Button
                  type="button"
                  variant="default"
                  className="bg-gradient-to-r from-primary to-primary/80 text-primary-foreground font-semibold px-4"
                  onClick={() => setDate(new Date())}
                >
                  {t("common:today", "TODAY")}
                </Button>
                <Button
                  type="button"
                  size="icon"
                  variant="outline"
                  aria-label="Next day"
                  className="border-primary/40 hover:bg-primary/10"
                  onClick={() => setDate((d) => addDays(d, 1))}
                >
                  <ChevronRight className="h-4 w-4" />
                </Button>
              </div>
            </div>

            <div className="flex flex-wrap items-center justify-between gap-2 text-[12px]">
              <p className="text-muted-foreground flex items-center gap-1.5">
                <MapPin className="h-3 w-3 text-primary" />
                <span className="font-medium text-foreground">{dayLine}</span>
                <span className="text-muted-foreground">· {location.timezone}</span>
              </p>
              {data?.cached && (
                <span className="inline-flex items-center gap-1 rounded-full bg-primary/15 px-2 py-0.5 text-[10px] font-medium text-primary">
                  {t("served_from_cache")}
                </span>
              )}
            </div>
          </CardContent>
        </Card>

        {isLoading ? (
          <div className="grid gap-4 md:grid-cols-2">
            <Skeleton className="h-96" />
            <Skeleton className="h-96" />
          </div>
        ) : error ? (
          <Alert variant="destructive">
            <AlertDescription>
              {t("could_not_load_hora")} {error instanceof Error ? error.message : ""}
            </AlertDescription>
          </Alert>
        ) : data?.hora ? (
          <Card className="border-primary/20">
            <CardContent className="pt-4">
              <div className="grid gap-4 md:grid-cols-2">
                <HoraTable title={t("day_hora")} rows={data.hora.day} timezone={location.timezone} now={now} lang={lang} />
                <HoraTable title={t("night_hora")} rows={data.hora.night} timezone={location.timezone} now={now} lang={lang} />
              </div>
            </CardContent>
          </Card>
        ) : (
          <Alert>
            <AlertDescription>{t("could_not_load_hora")}</AlertDescription>
          </Alert>
        )}
      </div>
    </AppShell>
  );
}

export default function PanchangHora() {
  return (
    <ErrorBoundary>
      <HoraInner />
    </ErrorBoundary>
  );
}
