// Shown after a user is force-logged-out due to being blocked or rejected.
import { Link, useSearchParams } from "react-router-dom";
import { ShieldAlert } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function Blocked() {
  const [params] = useSearchParams();
  const reason = params.get("reason") || "";
  const kind = params.get("kind") || "blocked"; // blocked | rejected
  const heading = kind === "rejected" ? "Application not approved" : "Account blocked";
  const body = kind === "rejected"
    ? "Your astrologer application was not approved."
    : "Your account has been blocked. You cannot sign in until this is resolved.";

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-[#0F0A1E] via-[#1a1233] to-[#0F0A1E] text-white px-6">
      <div className="max-w-md text-center space-y-5">
        <div className="mx-auto h-16 w-16 rounded-2xl bg-rose-500/20 text-rose-300 flex items-center justify-center">
          <ShieldAlert className="h-8 w-8" />
        </div>
        <h1 className="text-3xl font-serif font-bold">{heading}</h1>
        <p className="text-white/70">{body}</p>
        {reason && (
          <div className="text-sm rounded-lg bg-white/5 border border-white/10 px-4 py-3 text-white/80">
            <div className="text-[11px] uppercase text-white/50 mb-1">Reason</div>
            {reason}
          </div>
        )}
        <p className="text-xs text-white/50">Please contact support if you believe this is a mistake.</p>
        <div className="flex items-center justify-center gap-2">
          <Button asChild variant="outline" className="bg-white/10 border-white/30 text-white hover:bg-white/20 hover:text-white">
            <Link to="/">Back to home</Link>
          </Button>
        </div>
      </div>
    </div>
  );
}
