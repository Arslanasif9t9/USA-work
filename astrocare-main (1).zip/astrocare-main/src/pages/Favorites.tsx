import { useCallback, useEffect, useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import { AppShell } from "@/components/layout/AppShell";

import { Button } from "@/components/ui/button";
import { Heart } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { useWallet } from "@/hooks/useWallet";
import { useFavorites } from "@/hooks/useFavorites";
import { AstrologerGrid } from "@/components/astrologers/AstrologerGrid";
import type { Astrologer } from "@/components/astrologers/AstrologerCard";
import { useAstrologerStatus } from "@/hooks/useAstrologerStatus";
import { toast } from "@/hooks/use-toast";
import { CallConfirmationModal } from "@/components/calls/CallConfirmationModal";
import { PreCallBlockerModal, type BlockerReason } from "@/components/calls/PreCallBlockerModal";
import { CallInProgressScreen } from "@/components/calls/CallInProgressScreen";

export default function Favorites() {
  const { user, loading: authLoading } = useAuth();
  const navigate = useNavigate();
  const { wallet } = useWallet();
  const walletBalance = Number(wallet?.balance ?? 0);
  const { favoriteIds, toggleFavorite, loading: favLoading } = useFavorites();

  const [astrologers, setAstrologers] = useState<Astrologer[]>([]);
  const [loading, setLoading] = useState(true);

  // Call flow
  const [pendingAstrologer, setPendingAstrologer] = useState<Astrologer | null>(null);
  const [confirmOpen, setConfirmOpen] = useState(false);
  const [blocker, setBlocker] = useState<{ reason: BlockerReason; required?: number; current?: number }>({ reason: null });
  const [activeCallId, setActiveCallId] = useState<string | null>(null);
  const [activeCallAstrologer, setActiveCallAstrologer] = useState<Astrologer | null>(null);
  const [isStartingCall, setIsStartingCall] = useState(false);
  const [userPhone, setUserPhone] = useState<string | null>(null);
  const [hasBirthChart, setHasBirthChart] = useState<boolean | null>(null);

  useEffect(() => {
    if (!authLoading && !user) navigate("/sign-in?redirect=/favorites", { replace: true });
  }, [authLoading, user, navigate]);

  useEffect(() => {
    if (!user) return;
    let cancelled = false;
    (async () => {
      const [{ data: profile }, { count }] = await Promise.all([
        supabase.from("profiles").select("phone_e164").eq("id", user.id).maybeSingle(),
        supabase.from("birth_charts").select("id", { count: "exact", head: true }).eq("user_id", user.id),
      ]);
      if (cancelled) return;
      setUserPhone(profile?.phone_e164 ?? null);
      setHasBirthChart((count ?? 0) > 0);
    })();
    return () => { cancelled = true; };
  }, [user]);

  const ids = useMemo(() => Array.from(favoriteIds), [favoriteIds]);

  useEffect(() => {
    if (favLoading) return;
    if (ids.length === 0) {
      setAstrologers([]);
      setLoading(false);
      return;
    }
    let cancelled = false;
    setLoading(true);
    supabase
      .from("astrologers")
      .select("*")
      .in("id", ids)
      .eq("approval_status", "approved")
      .then(({ data, error }) => {
        if (cancelled) return;
        if (error) {
          toast({ title: "Couldn't load favorites", variant: "destructive" });
          setAstrologers([]);
        } else {
          setAstrologers(((data ?? []) as unknown) as Astrologer[]);
        }
        setLoading(false);
      });
    return () => { cancelled = true; };
  }, [ids, favLoading]);

  const handleStatusChange = useCallback((id: string, status: Astrologer["status"]) => {
    setAstrologers((prev) => prev.map((a) => (a.id === id ? { ...a, status } : a)));
  }, []);
  useAstrologerStatus(handleStatusChange);

  const handleCall = (a: Astrologer) => {
    if (!user) { navigate("/sign-in"); return; }
    const rate = a.discounted_rate_per_min ?? a.base_rate_per_min;
    const minHold = rate * 2;
    if (!userPhone) { setBlocker({ reason: "no_phone" }); return; }
    if (hasBirthChart === false) { setBlocker({ reason: "no_chart" }); return; }
    if (!a.first_chat_free && walletBalance < minHold) {
      setBlocker({ reason: "insufficient_balance", required: minHold, current: walletBalance });
      return;
    }
    setPendingAstrologer(a);
    setConfirmOpen(true);
  };

  const handleConfirmCall = async () => {
    if (!pendingAstrologer) return;
    setIsStartingCall(true);
    const { data, error } = await supabase.functions.invoke("initiate-call", {
      body: { astrologer_id: pendingAstrologer.id },
    });
    setIsStartingCall(false);
    if (error || !data?.call_session_id) {
      const parsed: any = (error as any)?.context?.body ? (() => { try { return JSON.parse((error as any).context.body); } catch { return {}; } })() : (data ?? {});
      toast({ title: "Could not start call", description: parsed?.error ?? "Please try again.", variant: "destructive" });
      setConfirmOpen(false);
      return;
    }
    setActiveCallAstrologer(pendingAstrologer);
    setActiveCallId(data.call_session_id as string);
    setConfirmOpen(false);
    setPendingAstrologer(null);
  };

  if (authLoading || !user) {
    return (
      <AppShell>
        <div className="container py-12 text-center text-muted-foreground">Loading…</div>
      </AppShell>
    );
  }

  return (
    <AppShell mobileTitle="Favorites">
      <div className="container py-4 md:py-8 space-y-4 md:space-y-6">
        <header className="flex items-center gap-3">
          <div className="flex h-11 w-11 md:h-12 md:w-12 items-center justify-center rounded-full bg-rose-50 text-rose-500">
            <Heart className="h-5 w-5 md:h-6 md:w-6 fill-rose-500" />
          </div>
          <div>
            <h1 className="text-xl md:text-3xl font-bold">My Favorites</h1>
            <p className="text-xs md:text-sm text-muted-foreground">
              {astrologers.length === 0
                ? "You haven't saved any astrologers yet."
                : `${astrologers.length} saved astrologer${astrologers.length === 1 ? "" : "s"}`}
            </p>
          </div>
        </header>

        {!loading && astrologers.length === 0 ? (
          <div className="rounded-xl border border-dashed p-12 text-center">
            <Heart className="h-10 w-10 mx-auto text-muted-foreground" />
            <h3 className="mt-3 text-lg font-semibold">No favorites yet</h3>
            <p className="mt-1 text-sm text-muted-foreground">
              Tap the heart icon on any astrologer to save them here.
            </p>
            <Button className="mt-4" onClick={() => navigate("/astrologers")}>
              Browse Astrologers
            </Button>
          </div>
        ) : (
          <AstrologerGrid
            astrologers={astrologers}
            walletBalance={walletBalance}
            isLoading={loading}
            onCall={handleCall}
            onReset={() => navigate("/astrologers")}
            favoriteIds={favoriteIds}
            onToggleFavorite={toggleFavorite}
          />
        )}
      </div>

      <CallConfirmationModal
        open={confirmOpen}
        onClose={() => { setConfirmOpen(false); setPendingAstrologer(null); }}
        astrologer={pendingAstrologer}
        walletBalance={walletBalance}
        userPhone={userPhone}
        isStarting={isStartingCall}
        onConfirm={handleConfirmCall}
      />
      <PreCallBlockerModal
        open={blocker.reason !== null}
        reason={blocker.reason}
        required={blocker.required}
        currentBalance={blocker.current}
        onClose={() => setBlocker({ reason: null })}
      />
      {activeCallId && activeCallAstrologer && (
        <CallInProgressScreen
          callSessionId={activeCallId}
          astrologer={activeCallAstrologer}
          onClose={() => { setActiveCallId(null); setActiveCallAstrologer(null); }}
        />
      )}
    </AppShell>
  );
}
