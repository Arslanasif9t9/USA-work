import { useEffect, useState } from "react";
import { AppShell } from "@/components/layout/AppShell";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { useProfile } from "@/hooks/useProfile";
import { Sparkles, Loader2, ArrowRight, X } from "lucide-react";
import { BackButton } from "@/components/layout/BackButton";

const SIGNS = [
  { id: "aries", name: "Aries", hi: "मेष", sym: "♈" },
  { id: "taurus", name: "Taurus", hi: "वृषभ", sym: "♉" },
  { id: "gemini", name: "Gemini", hi: "मिथुन", sym: "♊" },
  { id: "cancer", name: "Cancer", hi: "कर्क", sym: "♋" },
  { id: "leo", name: "Leo", hi: "सिंह", sym: "♌" },
  { id: "virgo", name: "Virgo", hi: "कन्या", sym: "♍" },
  { id: "libra", name: "Libra", hi: "तुला", sym: "♎" },
  { id: "scorpio", name: "Scorpio", hi: "वृश्चिक", sym: "♏" },
  { id: "sagittarius", name: "Sagittarius", hi: "धनु", sym: "♐" },
  { id: "capricorn", name: "Capricorn", hi: "मकर", sym: "♑" },
  { id: "aquarius", name: "Aquarius", hi: "कुम्भ", sym: "♒" },
  { id: "pisces", name: "Pisces", hi: "मीन", sym: "♓" },
];

function zodiacFromDOB(dob: string | null): string | null {
  if (!dob) return null;
  const d = new Date(dob);
  const m = d.getUTCMonth() + 1, day = d.getUTCDate();
  const cuts: [string, number, number][] = [
    ["capricorn", 12, 22], ["sagittarius", 11, 22], ["scorpio", 10, 23], ["libra", 9, 23],
    ["virgo", 8, 23], ["leo", 7, 23], ["cancer", 6, 21], ["gemini", 5, 21],
    ["taurus", 4, 20], ["aries", 3, 21], ["pisces", 2, 19], ["aquarius", 1, 20],
  ];
  for (const [name, mm, dd] of cuts) if (m > mm || (m === mm && day >= dd)) return name;
  return "capricorn";
}

export default function Horoscope() {
  const { user } = useAuth();
  const { profile } = useProfile();
  const navigate = useNavigate();
  const initial = zodiacFromDOB(profile?.dob ?? null) ?? "aries";
  const [sign, setSign] = useState(initial);
  const [content, setContent] = useState("");
  const [loading, setLoading] = useState(false);
  const [dismissedNudge, setDismissedNudge] = useState(false);

  useEffect(() => { if (profile?.dob) { const z = zodiacFromDOB(profile.dob); if (z) setSign(z); } }, [profile?.dob]);

  useEffect(() => {
    let cancelled = false;
    setLoading(true);
    setContent("");
    supabase.functions.invoke("get-horoscope", { body: { sign } }).then(({ data, error }) => {
      if (cancelled) return;
      if (error || (data as any)?.error) setContent("Could not load today's horoscope. Please try again later.");
      else setContent((data as any).content);
      setLoading(false);
    });
    return () => { cancelled = true; };
  }, [sign]);

  const today = new Date().toLocaleDateString("en-IN", { weekday: "long", day: "numeric", month: "long" });

  return (
    <AppShell>
      <div className="container max-w-4xl py-8 space-y-6">
        <BackButton fallbackPath="/" />
        <div className="text-center">
          <p className="text-sm text-muted-foreground">{today}</p>
          <h1 className="font-serif text-3xl md:text-4xl font-bold">Daily Horoscope</h1>
        </div>

        <div className="grid grid-cols-4 gap-2 sm:grid-cols-6 md:grid-cols-12">
          {SIGNS.map((s) => (
            <button
              key={s.id}
              onClick={() => setSign(s.id)}
              className={`flex flex-col items-center gap-1 rounded-xl border p-2 text-xs transition ${
                sign === s.id ? "border-primary bg-primary/10 text-primary" : "border-border bg-card hover:border-primary/40"
              }`}
            >
              <span className="text-2xl">{s.sym}</span>
              <span className="font-medium">{s.name}</span>
            </button>
          ))}
        </div>

        <Card className="overflow-hidden bg-gradient-to-br from-purple-900/20 via-card to-indigo-900/20 border-primary/20">
          <CardContent className="p-6 md:p-8">
            <div className="flex items-center gap-2 text-primary">
              <Sparkles className="h-5 w-5" />
              <p className="font-serif text-2xl font-bold capitalize">{sign}</p>
            </div>
            {loading ? (
              <div className="flex items-center gap-2 py-10 text-muted-foreground"><Loader2 className="h-5 w-5 animate-spin" /> Reading the stars…</div>
            ) : (
              <p className="mt-4 whitespace-pre-line text-base leading-relaxed text-foreground/90">{content}</p>
            )}
          </CardContent>
        </Card>

        {!user && !dismissedNudge && (
          <Card className="border-[#ED7B2A]/30 bg-gradient-to-r from-[#ED7B2A]/10 to-[#FFF6EC]">
            <CardContent className="relative flex flex-col items-start justify-between gap-3 p-5 sm:flex-row sm:items-center">
              <button
                aria-label="Dismiss"
                onClick={() => setDismissedNudge(true)}
                className="absolute right-2 top-2 rounded-full p-1 text-[#5A4A3A]/60 hover:bg-black/5 hover:text-[#5A4A3A]"
              >
                <X className="h-4 w-4" />
              </button>
              <div>
                <p className="font-semibold text-[#5A4A3A]">Save your sign for personalized readings</p>
                <p className="text-sm text-[#5A4A3A]/70">Sign up free — get daily horoscopes tailored to your birth chart.</p>
              </div>
              <Button onClick={() => navigate("/signup")} className="bg-[#ED7B2A] text-white hover:bg-[#D86E20]">
                Sign Up Free <ArrowRight className="ml-1 h-4 w-4" />
              </Button>
            </CardContent>
          </Card>
        )}

        <Card className="bg-gradient-to-r from-amber-500/10 to-amber-300/5 border-amber-300/30">
          <CardContent className="flex flex-col items-center justify-between gap-3 p-5 sm:flex-row">
            <div>
              <p className="font-semibold">Want a personal reading?</p>
              <p className="text-sm text-muted-foreground">Talk to a verified astrologer now.</p>
            </div>
            <Button onClick={() => navigate("/astrologers")} className="bg-amber-500 text-black hover:bg-amber-400">
              Browse astrologers <ArrowRight className="ml-1 h-4 w-4" />
            </Button>
          </CardContent>
        </Card>
      </div>
    </AppShell>
  );
}
