import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { useNavigate, useSearchParams } from "react-router-dom";
import { useTranslation } from "react-i18next";
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetTrigger } from "@/components/ui/sheet";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";
import { Filter, Loader2, Search } from "lucide-react";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import { AppShell } from "@/components/layout/AppShell";
import { ExpertiseFilter } from "@/components/astrologers/ExpertiseFilter";
import { AstrologerGrid } from "@/components/astrologers/AstrologerGrid";
import { LanguageChips } from "@/components/astrologers/LanguageChips";
import { useAstrologerStatus } from "@/hooks/useAstrologerStatus";
import type { Astrologer } from "@/components/astrologers/AstrologerCard";
import { supabase } from "@/integrations/supabase/client";
import { useWallet } from "@/hooks/useWallet";
import { toast } from "@/hooks/use-toast";
import { useAuth } from "@/contexts/AuthContext";
import { CallConfirmationModal } from "@/components/calls/CallConfirmationModal";
import { PreCallBlockerModal, type BlockerReason } from "@/components/calls/PreCallBlockerModal";
import { useLiveStreams } from "@/hooks/useLiveStreams";
import { Radio } from "lucide-react";

import { useFavorites } from "@/hooks/useFavorites";

type SortKey = "price_asc" | "rating_desc" | "experience_desc";
const PAGE_SIZE = 12;

export default function Astrologers() {
  const [searchParams, setSearchParams] = useSearchParams();
  const navigate = useNavigate();
  const { t } = useTranslation("common");
  const { t: tToast } = useTranslation("toasts");
  const { user } = useAuth();
  const { wallet } = useWallet();
  const walletBalance = Number(wallet?.balance ?? 0);
  const [searchQuery, setSearchQuery] = useState(() => searchParams.get("q") ?? "");
  const { favoriteIds, toggleFavorite } = useFavorites();
  const { streams: liveStreams } = useLiveStreams();

  // Call flow state
  const [pendingAstrologer, setPendingAstrologer] = useState<Astrologer | null>(null);
  const [confirmOpen, setConfirmOpen] = useState(false);
  const [blocker, setBlocker] = useState<{ reason: BlockerReason; required?: number; current?: number }>({ reason: null });
  const [isStartingCall, setIsStartingCall] = useState(false);
  const [userPhone, setUserPhone] = useState<string | null>(null);
  const [hasBirthChart, setHasBirthChart] = useState<boolean | null>(null);

  useEffect(() => {
    if (!user) return;
    let cancelled = false;
    (async () => {
      const [{ data: profile }, { count }] = await Promise.all([
        supabase.from("profiles").select("phone_e164").eq("id", user.id).maybeSingle(),
        supabase.from("birth_charts").select("id", { count: "exact", head: true }).eq("user_id", user.id),
      ]);
      if (cancelled) return;
      setUserPhone(profile?.phone_e164 ?? null);
      setHasBirthChart((count ?? 0) > 0);
    })();
    return () => { cancelled = true; };
  }, [user]);

  // URL state
  const specs = useMemo(() => searchParams.get("expertise")?.split(",").filter(Boolean) ?? [], [searchParams]);
  const langs = useMemo(() => searchParams.get("lang")?.split(",").filter(Boolean) ?? [], [searchParams]);
  const sort = (searchParams.get("sort") as SortKey | null) ?? "rating_desc";
  const onlineOnly = searchParams.get("online") === "1";

  const updateParams = useCallback((patch: Record<string, string | null>) => {
    const next = new URLSearchParams(searchParams);
    for (const [k, v] of Object.entries(patch)) {
      if (v === null || v === "") next.delete(k);
      else next.set(k, v);
    }
    setSearchParams(next, { replace: true });
  }, [searchParams, setSearchParams]);

  const setSpecs = (s: string[]) => updateParams({ expertise: s.length ? s.join(",") : null });
  const setLangs = (l: string[]) => updateParams({ lang: l.length ? l.join(",") : null });
  const setSort = (s: SortKey) => updateParams({ sort: s });
  const setOnlineOnly = (v: boolean) => updateParams({ online: v ? "1" : null });
  const handleReset = () => setSearchParams(new URLSearchParams(), { replace: true });

  const [astrologers, setAstrologers] = useState<Astrologer[]>([]);
  const [totalCount, setTotalCount] = useState<number | null>(null);
  const [isInitialLoading, setIsInitialLoading] = useState(true);
  const [isLoadingMore, setIsLoadingMore] = useState(false);
  const [hasMore, setHasMore] = useState(true);
  const [mobileOpen, setMobileOpen] = useState(false);

  // Total approved astrologers (for "Showing X of Y" display)
  useEffect(() => {
    let cancelled = false;
    supabase
      .from("astrologers")
      .select("id", { count: "exact", head: true })
      .eq("approval_status", "approved")
      .then(({ count }) => { if (!cancelled) setTotalCount(count ?? null); });
    return () => { cancelled = true; };
  }, []);

  // Debounce searchQuery -> debouncedSearch (used for server fetch)
  const [debouncedSearch, setDebouncedSearch] = useState(searchQuery);
  useEffect(() => {
    const t = setTimeout(() => setDebouncedSearch(searchQuery.trim()), 300);
    return () => clearTimeout(t);
  }, [searchQuery]);

  // Persist search to URL (?q=)
  useEffect(() => {
    updateParams({ q: debouncedSearch ? debouncedSearch : null });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [debouncedSearch]);

  const filterKey = useMemo(() => JSON.stringify({ specs, langs, sort, onlineOnly, debouncedSearch }), [specs, langs, sort, onlineOnly, debouncedSearch]);

  useEffect(() => {
    let cancelled = false;
    setIsInitialLoading(true);
    setHasMore(true);
    // Clear current results during refetch so we never show a "no results" flash
    // mixed with stale cards.
    setAstrologers([]);
    supabase.functions.invoke("get-astrologers", {
      body: {
        specializations: specs.length ? specs : undefined,
        languages: langs.length ? langs : undefined,
        status: onlineOnly ? "online" : undefined,
        is_ai: false,
        search: debouncedSearch || undefined,
        sort,
        limit: PAGE_SIZE,
        offset: 0,
      },
    }).then(({ data, error }) => {
      if (cancelled) return;
      if (error) {
        toast({ title: tToast("error.load_astrologers"), variant: "destructive" });
        setAstrologers([]);
        setHasMore(false);
      } else {
        const list = (data?.data ?? []) as Astrologer[];
        setAstrologers(list);
        setHasMore(list.length === PAGE_SIZE);
      }
    }).finally(() => !cancelled && setIsInitialLoading(false));
    return () => { cancelled = true; };
  }, [filterKey, specs, langs, sort, onlineOnly, debouncedSearch]);

  const handleStatusChange = useCallback((id: string, status: Astrologer["status"]) => {
    setAstrologers((prev) => prev.map((a) => (a.id === id ? { ...a, status } : a)));
  }, []);
  useAstrologerStatus(handleStatusChange);

  const sentinelRef = useRef<HTMLDivElement | null>(null);
  const loadMore = useCallback(async () => {
    if (isLoadingMore || isInitialLoading || !hasMore) return;
    setIsLoadingMore(true);
    const { data, error } = await supabase.functions.invoke("get-astrologers", {
      body: {
        specializations: specs.length ? specs : undefined,
        languages: langs.length ? langs : undefined,
        status: onlineOnly ? "online" : undefined,
        is_ai: false,
        search: debouncedSearch || undefined,
        sort, limit: PAGE_SIZE, offset: astrologers.length,
      },
    });
    if (!error) {
      const list = (data?.data ?? []) as Astrologer[];
      setAstrologers((prev) => [...prev, ...list]);
      if (list.length < PAGE_SIZE) setHasMore(false);
    } else setHasMore(false);
    setIsLoadingMore(false);
  }, [astrologers.length, hasMore, isInitialLoading, isLoadingMore, langs, onlineOnly, sort, specs, debouncedSearch]);

  useEffect(() => {
    const el = sentinelRef.current;
    if (!el || !hasMore) return;
    const obs = new IntersectionObserver((entries) => entries[0]?.isIntersecting && loadMore(), { rootMargin: "200px" });
    obs.observe(el);
    return () => obs.disconnect();
  }, [loadMore, hasMore]);

  const handleCall = (a: Astrologer) => {
    if (!user) { navigate("/sign-in"); return; }
    const rate = a.discounted_rate_per_min ?? a.base_rate_per_min;
    const minHold = rate * 2;
    if (!userPhone) { setBlocker({ reason: "no_phone" }); return; }
    if (hasBirthChart === false) { setBlocker({ reason: "no_chart" }); return; }
    if (!a.first_chat_free && walletBalance < minHold) {
      setBlocker({ reason: "insufficient_balance", required: minHold, current: walletBalance });
      return;
    }
    setPendingAstrologer(a);
    setConfirmOpen(true);
  };

  const handleConfirmCall = async () => {
    if (!pendingAstrologer) return;
    setIsStartingCall(true);
    const { data, error } = await supabase.functions.invoke("initiate-call", {
      body: { astrologer_id: pendingAstrologer.id },
    });
    setIsStartingCall(false);
    if (error || !data?.call_session_id) {
      // Try hard to surface the real backend error rather than a generic toast.
      const errBody = (error as { context?: { body?: unknown } } | null)?.context?.body;
      let parsed: { code?: string; required?: number; current_balance?: number; error?: string } = {};
      try { parsed = typeof errBody === "string" ? JSON.parse(errBody) : (errBody as typeof parsed) ?? {}; } catch { /* ignore */ }
      // Fall back to data payload (some non-2xx responses come back as data, not error)
      if (!parsed.code && data && typeof data === "object") {
        parsed = { ...(data as typeof parsed), ...parsed };
      }
      console.error("initiate-call failed", { error, data, parsed });
      const code = parsed.code;
      if (code === "no_phone") setBlocker({ reason: "no_phone" });
      else if (code === "no_chart") setBlocker({ reason: "no_chart" });
      else if (code === "insufficient_balance") setBlocker({ reason: "insufficient_balance", required: parsed.required, current: parsed.current_balance });
      else if (code === "offline") setBlocker({ reason: "offline" });
      else if (code === "busy") setBlocker({ reason: "busy" });
      else if (code === "not_accepting") {
        toast({ title: "Astrologer not available", description: "This astrologer isn't accepting calls right now.", variant: "destructive" });
      } else if (code === "twilio_trial_unverified" || code === "twilio_error") {
        toast({ title: "Could not start call", description: parsed.error ?? "Calling service error. Please try another astrologer.", variant: "destructive" });
      } else {
        // Surface the actual backend error message when available
        toast({
          title: tToast("error.start_call"),
          description: parsed.error ?? (error as Error | null)?.message ?? tToast("error.try_again"),
          variant: "destructive",
        });
      }
      setConfirmOpen(false);
      return;
    }
    setConfirmOpen(false);
    setPendingAstrologer(null);
    // FIX 9: navigate to the new full-screen call session route instead of inline overlay
    navigate(`/call/${data.call_session_id as string}`);
  };

  

  const searchedAstrologers = useMemo(() => {
    if (!searchQuery.trim()) return astrologers;
    const q = searchQuery.toLowerCase();
    return astrologers.filter((a) =>
      a.display_name.toLowerCase().includes(q) ||
      a.specializations.some((s) => s.toLowerCase().includes(q)) ||
      a.languages.some((l) => l.toLowerCase().includes(q))
    );
  }, [astrologers, searchQuery]);

  return (
    <AppShell>
      <div className="container py-6 md:py-8 space-y-6">
        <header className="text-center space-y-2">
          <h1 className="text-2xl md:text-4xl font-bold">
            {t("astrologers.page_title")}
            {totalCount !== null && <span className="text-muted-foreground font-semibold ml-2">({totalCount})</span>}
          </h1>
          <p className="text-sm md:text-base text-muted-foreground">
            {t("astrologers.page_subtitle")}
          </p>
        </header>

        {liveStreams.length > 0 && (
          <button
            onClick={() => navigate("/live")}
            className="w-full flex items-center justify-between rounded-xl border border-red-500/30 bg-gradient-to-r from-red-500/10 to-rose-500/10 px-4 py-3 text-left transition hover:from-red-500/15 hover:to-rose-500/15"
          >
            <span className="flex items-center gap-2 text-sm font-semibold">
              <span className="relative flex h-2.5 w-2.5">
                <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-red-500 opacity-75" />
                <span className="relative inline-flex h-2.5 w-2.5 rounded-full bg-red-500" />
              </span>
              <Radio className="h-4 w-4 text-red-500" />
              {t(liveStreams.length === 1 ? "astrologers.live_now_one" : "astrologers.live_now_other", { count: liveStreams.length })}
            </span>
            <span className="text-xs font-medium text-red-500">{t("astrologers.watch_now")}</span>
          </button>
        )}

        {/* Search bar */}
        <Card className="flex flex-col gap-3 p-4 md:flex-row md:items-center">
          <div className="flex flex-1 items-center gap-2 rounded-md border bg-background px-3">
            <Search className="h-4 w-4 text-muted-foreground" />
            <Input
              type="search"
              placeholder={t("astrologers.search_placeholder")}
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="border-0 shadow-none focus-visible:ring-0 px-0"
            />
          </div>
        </Card>

        <div className="flex gap-6">
          <aside className="hidden w-[240px] shrink-0 lg:block">
            <div className="sticky top-20 rounded-lg border bg-card p-4">
              <h3 className="mb-3 text-sm font-bold uppercase">{t("astrologers.filter")}</h3>
              <ExpertiseFilter
                selected={specs}
                onChange={setSpecs}
                onlineOnly={onlineOnly}
                onOnlineOnlyChange={setOnlineOnly}
                onReset={handleReset}
              />
              <div className="mt-6">
                <h4 className="mb-3 text-sm font-semibold">{t("astrologers.language")}</h4>
                <LanguageChips selected={langs} onChange={setLangs} />
              </div>
            </div>
          </aside>

          <main className="min-w-0 flex-1">
            <div className="mb-3 flex flex-wrap items-center justify-between gap-3">
              <p className="text-sm text-muted-foreground">
                {isInitialLoading
                  ? t("astrologers.loading")
                  : totalCount !== null
                    ? `Showing ${searchedAstrologers.length} of ${totalCount} astrologers`
                    : t(searchedAstrologers.length === 1 ? "astrologers.showing_one" : "astrologers.showing_other", { count: searchedAstrologers.length })}
              </p>
              <div className="flex items-center gap-2">
                <Sheet open={mobileOpen} onOpenChange={setMobileOpen}>
                  <SheetTrigger asChild>
                    <Button variant="outline" size="sm" className="lg:hidden">
                      <Filter className="mr-2 h-4 w-4" /> {t("astrologers.filter")}
                    </Button>
                  </SheetTrigger>
                  <SheetContent side="left" className="w-[300px] overflow-y-auto">
                    <SheetHeader>
                      <SheetTitle>{t("astrologers.filter_and_sort")}</SheetTitle>
                    </SheetHeader>
                    <div className="mt-6 space-y-6">
                      <ExpertiseFilter
                        selected={specs}
                        onChange={setSpecs}
                        onlineOnly={onlineOnly}
                        onOnlineOnlyChange={setOnlineOnly}
                        onReset={handleReset}
                      />
                      <div>
                        <h4 className="mb-3 text-sm font-semibold">{t("astrologers.language")}</h4>
                        <LanguageChips selected={langs} onChange={setLangs} />
                      </div>
                    </div>
                  </SheetContent>
                </Sheet>
                <Select value={sort} onValueChange={(v) => setSort(v as SortKey)}>
                  <SelectTrigger className="w-[200px]">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="price_asc">{t("astrologers.sort_price")}</SelectItem>
                    <SelectItem value="rating_desc">{t("astrologers.sort_rating")}</SelectItem>
                    <SelectItem value="experience_desc">{t("astrologers.sort_experience")}</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <AstrologerGrid
              astrologers={searchedAstrologers}
              walletBalance={walletBalance}
              isLoading={isInitialLoading}
              onCall={handleCall}
              onReset={handleReset}
              favoriteIds={favoriteIds}
              onToggleFavorite={toggleFavorite}
            />

            {!isInitialLoading && hasMore && (
              <div ref={sentinelRef} className="flex h-16 items-center justify-center">
                {isLoadingMore && <Loader2 className="h-5 w-5 animate-spin text-muted-foreground" />}
              </div>
            )}
          </main>
        </div>
      </div>

      <CallConfirmationModal
        open={confirmOpen}
        onClose={() => { setConfirmOpen(false); setPendingAstrologer(null); }}
        astrologer={pendingAstrologer}
        walletBalance={walletBalance}
        userPhone={userPhone}
        isStarting={isStartingCall}
        onConfirm={handleConfirmCall}
      />
      <PreCallBlockerModal
        open={blocker.reason !== null}
        reason={blocker.reason}
        required={blocker.required}
        currentBalance={blocker.current}
        onClose={() => setBlocker({ reason: null })}
      />
    </AppShell>
  );
}
