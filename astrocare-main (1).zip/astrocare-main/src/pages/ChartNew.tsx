import { useNavigate } from "react-router-dom";
import { useAuth } from "@/contexts/AuthContext";
import { AppShell } from "@/components/layout/AppShell";
import { BirthChartModal } from "@/components/birth-chart/BirthChartModal";
import { Card, CardContent } from "@/components/ui/card";
import { Sparkles, BadgeCheck } from "lucide-react";
import { useLanguage } from "@/contexts/LanguageContext";
import { CHART_DISCLOSURE_TEXT } from "@/config/chartCalculation";

/**
 * Free Kundli landing page. Opens the BirthChartModal directly.
 * Sign-in required to save (kundli account is free).
 */
export default function ChartNew() {
  const { user, loading } = useAuth();
  const navigate = useNavigate();
  const { lang } = useLanguage();

  // Free Kundli is open to everyone — no auth gating.
  // (Saving still requires sign-in; the modal will surface that error itself.)
  void user; void loading;

  const disclosure = CHART_DISCLOSURE_TEXT[lang === "hi" ? "hi" : "en"];

  // (no loading gate — page is public)

  return (
    <AppShell>
      <div className="container py-8 max-w-2xl">
        <Card className="shadow-card">
          <CardContent className="py-10 text-center space-y-3">
            <Sparkles className="h-10 w-10 text-primary mx-auto" />
            <h1 className="text-2xl font-bold">Free Kundli</h1>
            <p className="text-sm text-muted-foreground">
              Enter your birth details to instantly generate your personalised Vedic kundli — completely free.
            </p>
            <div className="inline-flex items-center gap-1.5 text-xs text-muted-foreground bg-muted/50 rounded-full px-3 py-1">
              <BadgeCheck className="h-3.5 w-3.5 text-primary" />
              <span>{disclosure}</span>
            </div>
          </CardContent>
        </Card>
        <BirthChartModal
          open={true}
          onOpenChange={(o) => { if (!o) navigate("/"); }}
          onChartCreated={() => { /* navigate handled by modal */ }}
        />
      </div>
    </AppShell>
  );
}
