import { useEffect, useState } from "react";
import { AppShell } from "@/components/layout/AppShell";
import { ProtectedRoute } from "@/components/auth/ProtectedRoute";

import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { TransactionHistory } from "@/components/wallet/TransactionHistory";
import { SavedChartsSection } from "@/components/birth-chart/SavedChartsSection";
import { SessionHistoryList } from "@/components/history/SessionHistoryList";
import { useWallet, formatINR } from "@/hooks/useWallet";
import { useBirthCharts } from "@/hooks/useBirthCharts";
import { useAuth } from "@/contexts/AuthContext";
import { supabase } from "@/integrations/supabase/client";
import { MessageCircle, Receipt, Sparkles, ShoppingBag } from "lucide-react";
import { format } from "date-fns";

interface Purchase {
  id: string;
  product_id: string;
  product_type: string;
  purchased_at: string;
}

function HistoryInner() {
  const { user } = useAuth();
  const { wallet } = useWallet();
  const { charts } = useBirthCharts();
  const [purchases, setPurchases] = useState<Purchase[]>([]);

  useEffect(() => {
    if (!user) return;
    let cancelled = false;
    supabase
      .from("user_purchases")
      .select("id, product_id, product_type, purchased_at")
      .eq("user_id", user.id)
      .order("purchased_at", { ascending: false })
      .then(({ data }) => {
        if (!cancelled) setPurchases((data ?? []) as Purchase[]);
      });
    return () => {
      cancelled = true;
    };
  }, [user]);

  return (
    <AppShell mobileTitle="History">
      <div className="container max-w-6xl py-4 md:py-8 space-y-4 md:space-y-6">
        <section className="hidden md:block space-y-2">
          <h1 className="text-2xl md:text-3xl font-bold">History</h1>
          <p className="text-sm text-muted-foreground">
            View your kundli records, wallet history, and purchased services in separate tabs.
          </p>
        </section>

        <section className="grid gap-3 grid-cols-3">
          <Card className="shadow-card">
            <CardContent className="py-3 px-3 md:py-5">
              <p className="text-[10px] md:text-xs text-muted-foreground">Wallet</p>
              <p className="mt-1 text-base md:text-2xl font-bold text-primary tabular-nums">{formatINR(wallet?.balance ?? 0)}</p>
            </CardContent>
          </Card>
          <Card className="shadow-card">
            <CardContent className="py-3 px-3 md:py-5">
              <p className="text-[10px] md:text-xs text-muted-foreground">Kundlis</p>
              <p className="mt-1 text-base md:text-2xl font-bold">{charts.length}</p>
            </CardContent>
          </Card>
          <Card className="shadow-card">
            <CardContent className="py-3 px-3 md:py-5">
              <p className="text-[10px] md:text-xs text-muted-foreground">Purchases</p>
              <p className="mt-1 text-base md:text-2xl font-bold">{purchases.length}</p>
            </CardContent>
          </Card>
        </section>

        <Tabs defaultValue="sessions" className="space-y-4">
          <TabsList className="h-auto w-full grid grid-cols-4 gap-1 rounded-xl p-1">
            <TabsTrigger value="sessions" className="flex-col gap-1 px-1 py-2 text-[10px] md:flex-row md:text-sm">
              <MessageCircle className="h-4 w-4" /> <span>Sessions</span>
            </TabsTrigger>
            <TabsTrigger value="kundli" className="flex-col gap-1 px-1 py-2 text-[10px] md:flex-row md:text-sm">
              <Sparkles className="h-4 w-4" /> <span>Kundli</span>
            </TabsTrigger>
            <TabsTrigger value="wallet" className="flex-col gap-1 px-1 py-2 text-[10px] md:flex-row md:text-sm">
              <Receipt className="h-4 w-4" /> <span>Wallet</span>
            </TabsTrigger>
            <TabsTrigger value="purchases" className="flex-col gap-1 px-1 py-2 text-[10px] md:flex-row md:text-sm">
              <ShoppingBag className="h-4 w-4" /> <span>Buys</span>
            </TabsTrigger>
          </TabsList>

          <TabsContent value="sessions">
            <SessionHistoryList perspective="customer" />
          </TabsContent>

          <TabsContent value="kundli">
            <SavedChartsSection />
          </TabsContent>

          <TabsContent value="wallet">
            <TransactionHistory />
          </TabsContent>

          <TabsContent value="purchases">
            <Card className="shadow-card">
              <CardHeader>
                <CardTitle>Purchased services</CardTitle>
              </CardHeader>
              <CardContent>
                {purchases.length === 0 ? (
                  <div className="rounded-lg border border-dashed border-border p-8 text-center text-sm text-muted-foreground">
                    No purchases yet.
                  </div>
                ) : (
                  <div className="space-y-3">
                    {purchases.map((purchase) => (
                      <div key={purchase.id} className="flex items-center justify-between gap-3 rounded-lg border border-border bg-card p-4">
                        <div className="min-w-0">
                          <p className="font-medium truncate">{purchase.product_id}</p>
                          <p className="text-xs text-muted-foreground">{purchase.product_type}</p>
                        </div>
                        <p className="text-sm text-muted-foreground whitespace-nowrap">
                          {format(new Date(purchase.purchased_at), "dd MMM yyyy")}
                        </p>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </AppShell>
  );
}

export default function History() {
  return (
    <ProtectedRoute>
      <HistoryInner />
    </ProtectedRoute>
  );
}