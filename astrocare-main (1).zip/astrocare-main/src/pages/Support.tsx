import { useEffect, useState } from "react";
import { useAuth } from "@/contexts/AuthContext";
import { supabase } from "@/integrations/supabase/client";
import { AppShell } from "@/components/layout/AppShell";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent } from "@/components/ui/card";
import { LifeBuoy, Loader2, Plus, MessageCircle } from "lucide-react";
import { toast } from "sonner";
import { cn } from "@/lib/utils";
import { TicketThread } from "@/components/support/TicketThread";

interface Ticket {
  id: string;
  subject: string;
  message: string;
  status: string;
  created_at: string;
  user_id: string;
}

const STATUS_CLASS: Record<string, string> = {
  open: "bg-amber-500/15 text-amber-700 dark:text-amber-300",
  in_progress: "bg-blue-500/15 text-blue-700 dark:text-blue-300",
  resolved: "bg-emerald-500/15 text-emerald-700 dark:text-emerald-400",
};

export default function SupportPage() {
  const { user } = useAuth();
  const [tickets, setTickets] = useState<Ticket[]>([]);
  const [loading, setLoading] = useState(true);
  const [creating, setCreating] = useState(false);
  const [openId, setOpenId] = useState<string | null>(null);
  const [subject, setSubject] = useState("");
  const [message, setMessage] = useState("");
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    if (!user) { setLoading(false); return; }
    let active = true;
    (async () => {
      const { data } = await supabase
        .from("support_tickets")
        .select("*")
        .eq("user_id", user.id)
        .order("created_at", { ascending: false });
      if (!active) return;
      setTickets((data ?? []) as Ticket[]);
      setLoading(false);
    })();
    const ch = supabase
      .channel(`my-tickets-${user.id}`)
      .on("postgres_changes",
        { event: "*", schema: "public", table: "support_tickets", filter: `user_id=eq.${user.id}` },
        async () => {
          const { data } = await supabase
            .from("support_tickets").select("*")
            .eq("user_id", user.id).order("created_at", { ascending: false });
          if (active) setTickets((data ?? []) as Ticket[]);
        })
      .subscribe();
    return () => { active = false; supabase.removeChannel(ch); };
  }, [user]);

  const submit = async () => {
    if (!user) return;
    if (subject.trim().length < 3) { toast.error("Subject is too short"); return; }
    if (message.trim().length < 20) { toast.error("Please describe your issue (min 20 chars)"); return; }
    setSubmitting(true);
    const { data, error } = await supabase.from("support_tickets")
      .insert({ user_id: user.id, subject: subject.trim(), message: message.trim() })
      .select("id").single();
    setSubmitting(false);
    if (error) { toast.error(error.message); return; }
    toast.success("Ticket submitted — we'll respond shortly");
    setSubject(""); setMessage(""); setCreating(false);
    setOpenId(data?.id ?? null);
  };

  return (
    <AppShell>
      <div className="container max-w-3xl space-y-6 py-8">
        <div className="flex items-center justify-between gap-4">
          <div>
            <h1 className="flex items-center gap-2 text-2xl font-bold tracking-tight md:text-3xl">
              <LifeBuoy className="h-6 w-6 text-primary" /> Support
            </h1>
            <p className="text-sm text-muted-foreground">
              Get help from our team. We typically reply within a few hours.
            </p>
          </div>
          {!creating && (
            <Button onClick={() => setCreating(true)} variant="saffron">
              <Plus className="h-4 w-4" /> New ticket
            </Button>
          )}
        </div>

        {creating && (
          <Card className="animate-fade-in">
            <CardContent className="space-y-3 p-5">
              <Input
                value={subject}
                onChange={(e) => setSubject(e.target.value.slice(0, 120))}
                placeholder="Subject (e.g. Wallet didn't update after recharge)"
              />
              <Textarea
                value={message}
                onChange={(e) => setMessage(e.target.value.slice(0, 1000))}
                rows={5}
                placeholder="Describe the issue in detail (min 20 characters)…"
              />
              <p className="text-right text-[11px] text-muted-foreground">{message.length}/1000</p>
              <div className="flex justify-end gap-2">
                <Button variant="ghost" onClick={() => { setCreating(false); setSubject(""); setMessage(""); }}>
                  Cancel
                </Button>
                <Button onClick={submit} disabled={submitting} variant="saffron">
                  {submitting ? <><Loader2 className="h-4 w-4 animate-spin" /> Submitting…</> : "Submit ticket"}
                </Button>
              </div>
            </CardContent>
          </Card>
        )}

        <div>
          <h2 className="mb-3 text-sm font-semibold text-muted-foreground">Your tickets</h2>
          {loading ? (
            <div className="flex justify-center py-10"><Loader2 className="h-5 w-5 animate-spin text-muted-foreground" /></div>
          ) : tickets.length === 0 ? (
            <Card>
              <CardContent className="flex flex-col items-center gap-2 p-10 text-center">
                <MessageCircle className="h-8 w-8 text-muted-foreground/60" />
                <p className="text-sm text-muted-foreground">No tickets yet</p>
                {!creating && (
                  <Button size="sm" variant="outline" onClick={() => setCreating(true)}>
                    Open your first ticket
                  </Button>
                )}
              </CardContent>
            </Card>
          ) : (
            <div className="space-y-2">
              {tickets.map((t) => {
                const isOpen = openId === t.id;
                return (
                  <Card key={t.id} className={cn("overflow-hidden transition-all", isOpen && "ring-2 ring-primary/40")}>
                    <button
                      onClick={() => setOpenId(isOpen ? null : t.id)}
                      className="flex w-full items-start gap-3 p-4 text-left hover:bg-muted/30"
                    >
                      <div className="min-w-0 flex-1">
                        <div className="flex flex-wrap items-center gap-2">
                          <span className="font-semibold">{t.subject}</span>
                          <span className={cn("rounded-full px-2 py-0.5 text-[10px] font-medium uppercase tracking-wide", STATUS_CLASS[t.status] ?? "bg-muted text-muted-foreground")}>
                            {t.status === "in_progress" ? "Replied" : t.status}
                          </span>
                        </div>
                        <p className="mt-1 line-clamp-1 text-xs text-muted-foreground">{t.message}</p>
                        <p className="mt-0.5 text-[11px] text-muted-foreground">
                          {new Date(t.created_at).toLocaleString([], { dateStyle: "medium", timeStyle: "short" })}
                        </p>
                      </div>
                    </button>
                    {isOpen && (
                      <div className="border-t bg-muted/20 p-4">
                        <p className="mb-3 whitespace-pre-wrap rounded-lg border bg-background/60 p-3 text-sm">
                          {t.message}
                        </p>
                        <TicketThread
                          ticketId={t.id}
                          ownerUserId={t.user_id}
                          ticketStatus={t.status}
                          variant="customer"
                        />
                      </div>
                    )}
                  </Card>
                );
              })}
            </div>
          )}
        </div>
      </div>
    </AppShell>
  );
}
