import { useState } from "react";
import { useNavigate, Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card } from "@/components/ui/card";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { Loader2, Sparkles } from "lucide-react";

export default function AstrologerLogin() {
  const navigate = useNavigate();
  const { toast } = useToast();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      const { data, error } = await supabase.auth.signInWithPassword({ email, password });
      if (error) {
        toast({ title: "Sign-in failed", description: error.message, variant: "destructive" });
        return;
      }
      const uid = data.user?.id;
      if (!uid) return;
      const { data: roles } = await supabase
        .from("user_roles").select("role").eq("user_id", uid);
      const list = (roles ?? []).map((r) => r.role);
      if (!list.includes("astrologer")) {
        await supabase.auth.signOut();
        toast({
          title: "Not an astrologer account",
          description: "This portal is only for verified astrologers.",
          variant: "destructive",
        });
        return;
      }
      toast({ title: "Welcome back" });
      navigate("/astrologer-dashboard", { replace: true });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-section px-4">
      <Card className="w-full max-w-md p-0 overflow-hidden shadow-card">
        <div className="bg-gradient-saffron px-6 py-6 text-white">
          <div className="flex items-center gap-2 font-display font-bold text-lg">
            <Sparkles className="h-5 w-5" /> AstroGuide
          </div>
          <h1 className="font-display text-2xl font-bold mt-2">Astrologer Portal</h1>
          <p className="text-sm text-white/80">Sign in to manage consultations & availability.</p>
        </div>
        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          <div className="space-y-1.5">
            <Label htmlFor="ast-email">Email</Label>
            <Input id="ast-email" type="email" required value={email} onChange={(e) => setEmail(e.target.value)} />
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="ast-password">Password</Label>
            <Input id="ast-password" type="password" required value={password} onChange={(e) => setPassword(e.target.value)} />
          </div>
          <Button type="submit" className="w-full h-11" disabled={loading}>
            {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : "Sign In as Astrologer"}
          </Button>
          <p className="text-center text-xs text-muted-foreground">
            Customer? <Link to="/" className="text-primary hover:underline">Go to home</Link>
          </p>
        </form>
      </Card>
    </div>
  );
}
