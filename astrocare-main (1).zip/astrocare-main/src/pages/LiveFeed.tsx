// Customer-facing TikTok-style vertical live feed with real Agora subscription.
import { useEffect, useRef, useState, useCallback } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { useLiveStreams, type LiveStreamWithAstro } from "@/hooks/useLiveStreams";
import { usePlatformSettings } from "@/hooks/usePlatformSettings";
import { useAuth } from "@/contexts/AuthContext";
import { useAuthDialog } from "@/components/auth/AuthDialog";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Heart, MessageCircle, Gift, Share2, Star, X, Eye, Send, Radio, Sparkles, Crown, Phone, Lock, Video } from "lucide-react";
import { toast } from "sonner";
import { cn } from "@/lib/utils";
import { fetchAgoraToken, getAgoraAppId, loadAgoraSDK, uidFromUserId } from "@/lib/agora";
import { LiveGiftPicker } from "@/components/live/LiveGiftPicker";
import { LiveGiftHost } from "@/components/live/LiveGiftHost";
import { TopGiftersDrawer } from "@/components/live/TopGiftersDrawer";
import { LiveCallRequestModal } from "@/components/live/LiveCallRequestModal";
import { LivePublicCoHost } from "@/components/live/LivePublicCoHost";
import { LivePauseOverlay } from "@/components/live/LivePauseOverlay";
import { LiveResumedBanner } from "@/components/live/LiveResumedBanner";
import { NotifyMeBell } from "@/components/notifications/NotifyMeBell";
import { NotificationBell } from "@/components/notifications/NotificationBell";
import { useFavorites } from "@/hooks/useFavorites";
import { Dialog, DialogContent } from "@/components/ui/dialog";

interface Comment {
  id: string;
  user_name: string;
  user_avatar: string | null;
  is_host: boolean;
  comment_text: string;
  created_at: string;
}

interface FloatingHeart { id: number; }


function StreamView({ stream, active }: { stream: LiveStreamWithAstro; active: boolean }) {
  const { user } = useAuth();
  const { open: openAuth } = useAuthDialog();
  const { isFavorite, toggleFavorite } = useFavorites();
  const [comments, setComments] = useState<Comment[]>([]);
  const [text, setText] = useState("");
  const [following, setFollowing] = useState(false);
  const [hasLiked, setHasLiked] = useState(false);
  const [hearts, setHearts] = useState<FloatingHeart[]>([]);
  const [demoMode, setDemoMode] = useState<boolean | null>(null);
  const [connState, setConnState] = useState<"idle" | "connecting" | "connected" | "reconnecting" | "failed">("idle");
  const [stats, setStats] = useState({
    viewer_count: stream.viewer_count,
    total_likes: stream.total_likes,
    total_comments: stream.total_comments,
    total_gifts_value: Number(stream.total_gifts_value ?? 0),
  });
  const [giftOpen, setGiftOpen] = useState(false);
  const [topGiftersOpen, setTopGiftersOpen] = useState(false);
  const [commentOverlayOpen, setCommentOverlayOpen] = useState(false);
  const [callOpen, setCallOpen] = useState(false);
  const [callType, setCallType] = useState<"public" | "private">("public");
  const [callMedia, setCallMedia] = useState<"audio" | "video">("video");
  const [coHostRequestId, setCoHostRequestId] = useState<string | null>(null);
  const [coHostMedia, setCoHostMedia] = useState<"audio" | "video">("video");
  const [activeCoHostId, setActiveCoHostId] = useState<string | null>(stream.active_co_host_id ?? null);
  const [isPaused, setIsPaused] = useState<boolean>(Boolean(stream.is_paused_for_private));
  const [showResumed, setShowResumed] = useState(false);
  const navigateRoot = useNavigate();
  const videoContainerRef = useRef<HTMLDivElement>(null);
  const coHostContainerRef = useRef<HTMLDivElement>(null);
  const clientRef = useRef<any>(null);
  // uid -> { track, isHost } so we can re-attach on split-view changes
  const remoteTracksRef = useRef<Map<number, { track: any; uid: number }>>(new Map());
  const hostUidRef = useRef<number | null>(null);
  const coHostUidRef = useRef<number | null>(null);

  const splitView = !!activeCoHostId;
  const favorited = isFavorite(stream.astrologer.id);

  // Re-bind remote video tracks whenever the layout flips between single/split
  function rebindRemoteTracks() {
    const entries = Array.from(remoteTracksRef.current.values());
    // Pick a "host" track: the first one we ever saw, kept stable in hostUidRef
    const host = entries.find((e) => e.uid === hostUidRef.current) ?? entries[0];
    const coHost = entries.find((e) => e.uid !== host?.uid);
    if (host) {
      hostUidRef.current = host.uid;
      try { host.track?.play(videoContainerRef.current!); } catch {}
    }
    if (coHost && splitView && coHostContainerRef.current) {
      coHostUidRef.current = coHost.uid;
      try { coHost.track?.play(coHostContainerRef.current); } catch {}
    }
  }

  // Re-attach when split flag changes (DOM container appears/disappears)
  useEffect(() => {
    rebindRemoteTracks();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [splitView]);

  // Load initial liked state
  useEffect(() => {
    if (!user) { setHasLiked(false); return; }
    let cancelled = false;
    (async () => {
      const { data } = await supabase
        .from("live_likes")
        .select("id")
        .eq("user_id", user.id)
        .eq("live_stream_id", stream.id)
        .maybeSingle();
      if (!cancelled) setHasLiked(!!data);
    })();
    return () => { cancelled = true; };
  }, [user, stream.id]);

  useEffect(() => { getAgoraAppId().then((id) => setDemoMode(!id)); }, []);

  // Track join/leave when this card becomes active
  useEffect(() => {
    if (!active || !user) return;
    let left = false;
    supabase.rpc("join_live_stream", { _stream_id: stream.id });
    return () => {
      if (!left) {
        left = true;
        supabase.rpc("leave_live_stream", { _stream_id: stream.id });
      }
    };
  }, [active, user, stream.id]);

  // Real Agora subscribe — only when active and not demo
  useEffect(() => {
    if (!active || demoMode !== false || !user) return;
    let cancelled = false;
    let attempt = 0;
    let failTimer: ReturnType<typeof setTimeout> | null = null;

    function armFailTimer() {
      if (failTimer) clearTimeout(failTimer);
      // If we're still not connected after 10s of trying, surface the failure
      failTimer = setTimeout(() => {
        if (cancelled) return;
        setConnState((s) => (s === "connected" ? s : "failed"));
      }, 10000);
    }

    async function connect() {
      try {
        setConnState("connecting");
        armFailTimer();
        const AgoraRTC = await loadAgoraSDK();
        const uid = uidFromUserId(user.id) + 1; // avoid uid collision with host
        const { token, appId } = await fetchAgoraToken({ channelName: stream.channel_name, uid, role: "audience" });
        if (cancelled) return;
        const client = AgoraRTC.createClient({ mode: "live", codec: "vp8" });
        await client.setClientRole("audience");

        const handlePublished = async (remoteUser: any, mediaType: "audio" | "video") => {
          try {
            await client.subscribe(remoteUser, mediaType);
            if (mediaType === "video") {
              remoteTracksRef.current.set(remoteUser.uid, { track: remoteUser.videoTrack, uid: remoteUser.uid });
              if (hostUidRef.current === null) hostUidRef.current = remoteUser.uid;
              rebindRemoteTracks();
              setConnState("connected");
              if (failTimer) { clearTimeout(failTimer); failTimer = null; }
            } else if (mediaType === "audio") {
              remoteUser.audioTrack?.play();
              // Audio-only fallback also counts as connected
              setConnState((s) => (s === "connected" ? s : "connected"));
              if (failTimer) { clearTimeout(failTimer); failTimer = null; }
            }
          } catch (subErr) {
            console.warn("[LiveFeed] subscribe failed", subErr);
          }
        };

        client.on("user-published", handlePublished);
        client.on("user-unpublished", (remoteUser: any, mediaType: string) => {
          if (mediaType === "video") {
            remoteTracksRef.current.delete(remoteUser.uid);
            if (coHostUidRef.current === remoteUser.uid) coHostUidRef.current = null;
            rebindRemoteTracks();
          }
        });
        client.on("user-left", () => {
          // If everybody left and we have no remote tracks, surface that
          if (remoteTracksRef.current.size === 0) {
            setConnState((s) => (s === "connected" ? s : s));
          }
        });
        client.on("connection-state-change", (cur: string, _prev: string, reason: string) => {
          if (cur === "RECONNECTING") setConnState("reconnecting");
          if (cur === "CONNECTED") {
            // Only flip to connected once we actually have a remote track playing
            if (remoteTracksRef.current.size > 0) setConnState("connected");
          }
          if (cur === "DISCONNECTED" && reason && reason !== "LEAVE") {
            setConnState("failed");
          }
        });

        await client.join(appId, stream.channel_name, token, uid);
        if (cancelled) { try { await client.leave(); } catch {} return; }
        clientRef.current = client;

        // COLD-START: host may have already published before we attached the listener.
        // Walk current remoteUsers and subscribe to whatever is there.
        for (const ru of client.remoteUsers ?? []) {
          if (ru.hasVideo) await handlePublished(ru, "video");
          if (ru.hasAudio) await handlePublished(ru, "audio");
        }
      } catch (e) {
        if (cancelled) return;
        attempt += 1;
        if (attempt < 3) {
          setConnState("reconnecting");
          setTimeout(connect, 1500 * attempt);
        } else {
          setConnState("failed");
        }
      }
    }
    connect();
    return () => {
      cancelled = true;
      if (failTimer) clearTimeout(failTimer);
      (async () => {
        try { await clientRef.current?.leave(); } catch {}
        clientRef.current = null;
        remoteTracksRef.current.clear();
        hostUidRef.current = null;
        coHostUidRef.current = null;
        setConnState("idle");
      })();
    };
  }, [active, demoMode, user, stream.channel_name]);


  // Initial follow state
  useEffect(() => {
    if (!user) return;
    (async () => {
      const { data } = await supabase
        .from("live_followers")
        .select("id")
        .eq("follower_id", user.id)
        .eq("astrologer_id", stream.astrologer.id)
        .maybeSingle();
      setFollowing(!!data);
    })();
  }, [user, stream.astrologer.id]);

  // Subscribe to comments + stats only when active
  useEffect(() => {
    if (!active) return;
    let mounted = true;
    (async () => {
      const { data } = await supabase
        .from("live_comments")
        .select("id, user_name, user_avatar, is_host, comment_text, created_at")
        .eq("live_stream_id", stream.id)
        .eq("is_deleted", false)
        .order("created_at", { ascending: false })
        .limit(20);
      if (data && mounted) setComments((data as Comment[]).reverse());
    })();
    const ch = supabase
      .channel(`live_view_${stream.id}`)
      .on("postgres_changes",
        { event: "INSERT", schema: "public", table: "live_comments", filter: `live_stream_id=eq.${stream.id}` },
        (p) => setComments((prev) => [...prev.slice(-19), p.new as Comment]))
      .on("postgres_changes",
        { event: "UPDATE", schema: "public", table: "live_streams", filter: `id=eq.${stream.id}` },
        (p) => {
          const r = p.new as any;
          setStats({
            viewer_count: r.viewer_count,
            total_likes: r.total_likes,
            total_comments: r.total_comments,
            total_gifts_value: Number(r.total_gifts_value ?? 0),
          });
          const newPaused = Boolean(r.is_paused_for_private);
          setIsPaused((prev) => {
            if (prev && !newPaused) setShowResumed(true);
            return newPaused;
          });
          setActiveCoHostId(r.active_co_host_id ?? null);
        })
      .subscribe();
    return () => { mounted = false; supabase.removeChannel(ch); };
  }, [active, stream.id]);

  async function like() {
    if (!user) return openAuth();
    if (hasLiked) {
      // Unlike (TikTok-style toggle)
      setHasLiked(false);
      setStats((s) => ({ ...s, total_likes: Math.max(0, s.total_likes - 1) }));
      const { error } = await supabase.rpc("unlike_live_stream", { _stream_id: stream.id });
      if (error) {
        // Revert
        setHasLiked(true);
        setStats((s) => ({ ...s, total_likes: s.total_likes + 1 }));
        toast.error("Couldn't unlike");
      }
      return;
    }
    // Like — optimistic
    setHasLiked(true);
    setStats((s) => ({ ...s, total_likes: s.total_likes + 1 }));
    setHearts((prev) => [...prev, { id: Date.now() + Math.random() }]);
    setTimeout(() => setHearts((prev) => prev.slice(1)), 1500);
    const { error } = await supabase.rpc("like_live_stream", { _stream_id: stream.id });
    if (error) {
      if (!/duplicate|unique/i.test(error.message)) {
        setHasLiked(false);
        setStats((s) => ({ ...s, total_likes: Math.max(0, s.total_likes - 1) }));
        toast.error("Couldn't like");
      }
    }
  }

  async function send() {
    if (!user) return openAuth();
    const t = text.trim();
    if (!t) return;
    setText("");
    const { error } = await supabase.rpc("post_live_comment", { _stream_id: stream.id, _text: t });
    if (error) toast.error(error.message);
  }

  async function toggleFollow() {
    if (!user) return openAuth();
    const { data, error } = await supabase.rpc("toggle_follow_astrologer", { _astrologer_id: stream.astrologer.id });
    if (error) { toast.error(error.message); return; }
    setFollowing((data as any)?.following);
  }

  function share() {
    const url = `${window.location.origin}/astrologer/${stream.astrologer.slug ?? stream.astrologer.id}`;
    if (navigator.share) navigator.share({ title: stream.title, url }).catch(() => {});
    else {
      navigator.clipboard.writeText(url);
      toast.success("Link copied");
    }
  }

  return (
    <section
      className="relative h-screen w-full snap-start snap-always overflow-hidden bg-black text-white"
      style={{ scrollSnapAlign: "start" }}
    >
      {/* Background — Agora remote video when live, gradient/thumbnail fallback otherwise.
          When a Public Call is active, split into 2 cells (top=host, bottom=co-host on
          mobile; left=host, right=co-host on landscape desktop). */}
      <div className="absolute inset-0">
        {stream.thumbnail_url ? (
          <img src={stream.thumbnail_url} alt={stream.title} className="absolute inset-0 w-full h-full object-cover blur-md scale-110 opacity-60" />
        ) : null}
        <div className="absolute inset-0 bg-gradient-to-br from-purple-900 via-fuchsia-900/70 to-amber-700/60" />
        {demoMode === false && (
          <div
            className={cn(
              "absolute inset-0 grid transition-all duration-300",
              splitView ? "grid-rows-2 lg:grid-rows-1 lg:grid-cols-2" : "grid-rows-1"
            )}
          >
            <div className="relative overflow-hidden">
              <div ref={videoContainerRef} className="absolute inset-0 [&>div]:!w-full [&>div]:!h-full [&_video]:!object-cover" />
              {splitView && (
                <span className="absolute bottom-2 left-2 px-2 py-0.5 rounded-full bg-amber-400/90 text-black text-[10px] font-bold shadow">
                  🔮 {stream.astrologer.display_name}
                </span>
              )}
            </div>
            {splitView && (
              <div className="relative overflow-hidden border-t-2 lg:border-t-0 lg:border-l-2 border-amber-300 shadow-[0_0_24px_rgba(251,191,36,0.45)]">
                <div ref={coHostContainerRef} className="absolute inset-0 [&>div]:!w-full [&>div]:!h-full [&_video]:!object-cover bg-black" />
                <span className="absolute bottom-2 left-2 px-2 py-0.5 rounded-full bg-white/80 text-black text-[10px] font-bold shadow">
                  Guest (Live)
                </span>
              </div>
            )}
          </div>
        )}
        {demoMode === false && (connState === "connecting" || connState === "reconnecting") && (
          <div className="absolute inset-0 z-10 flex items-center justify-center bg-black/40 backdrop-blur-sm">
            <div className="text-center">
              <Sparkles className="h-8 w-8 mx-auto animate-pulse mb-2" />
              <div className="text-sm font-medium">
                {connState === "reconnecting" ? "Reconnecting…" : "Connecting to live…"}
              </div>
            </div>
          </div>
        )}
        {demoMode === false && connState === "failed" && (
          <div className="absolute inset-0 z-10 flex items-center justify-center bg-black/70 backdrop-blur-sm p-6">
            <div className="text-center max-w-xs">
              <Radio className="h-10 w-10 mx-auto mb-3 opacity-70" />
              <h3 className="text-base font-semibold">Stream unavailable</h3>
              <p className="text-xs text-white/70 mt-2">The astrologer may have ended the stream or there's a connection issue.</p>
              <Button
                onClick={() => navigateRoot("/live")}
                className="mt-4 bg-white/15 hover:bg-white/25 text-white"
                variant="outline"
              >
                Browse other live streams
              </Button>
            </div>
          </div>
        )}
      </div>

      {/* Floating hearts */}
      <div className="pointer-events-none absolute right-6 bottom-44 z-30">
        {hearts.map((h) => (
          <Heart key={h.id} className="absolute h-6 w-6 text-red-500 fill-red-500 animate-[float_1.4s_ease-out_forwards]" />
        ))}
      </div>

      {/* Top bar */}
      <div className="absolute top-0 inset-x-0 z-20 p-4 pt-[calc(env(safe-area-inset-top)+1rem)] flex items-start justify-between bg-gradient-to-b from-black/60 to-transparent">
        <div className="flex items-center gap-2">
          <Avatar className="h-9 w-9 ring-2 ring-white/40">
            <AvatarImage src={stream.astrologer.avatar_url ?? undefined} />
            <AvatarFallback>{stream.astrologer.display_name.slice(0, 1)}</AvatarFallback>
          </Avatar>
          <div>
            <div className="text-sm font-semibold leading-tight">{stream.astrologer.display_name}</div>
            <div className="text-[10px] flex items-center gap-1.5 mt-0.5">
              <span className="px-1.5 py-0.5 bg-red-600 rounded text-[9px] font-bold flex items-center gap-1">
                <span className="h-1 w-1 rounded-full bg-white animate-pulse" /> LIVE
              </span>
              <span className="flex items-center gap-1"><Eye className="h-3 w-3" /> {stats.viewer_count}</span>
              <button
                onClick={() => setTopGiftersOpen(true)}
                className="flex items-center gap-1 px-1.5 py-0.5 rounded-full bg-white/10 backdrop-blur hover:bg-white/20 transition"
                aria-label="Top gifters"
              >
                <Crown className="h-3 w-3 text-amber-300" />
                <span className="text-[10px] font-semibold">Top</span>
              </button>
              <span className="flex items-center gap-1 text-amber-300"><Gift className="h-3 w-3" /> ₹{stats.total_gifts_value}</span>
            </div>
          </div>
          <button
            onClick={toggleFollow}
            className={cn(
              "ml-2 px-3 py-1 rounded-full text-xs font-semibold",
              following ? "bg-white/20 text-white" : "bg-red-600 text-white hover:bg-red-700"
            )}
          >
            {following ? "Following" : "Follow"}
          </button>
        </div>
      </div>

      {/* Right action rail */}
      <div className="absolute right-3 bottom-32 z-20 flex flex-col items-center gap-4">
        <button onClick={like} className="flex flex-col items-center text-white active:scale-95 transition">
          <span className={cn(
            "h-12 w-12 rounded-full backdrop-blur flex items-center justify-center transition-colors",
            hasLiked ? "bg-red-500/30" : "bg-white/15"
          )}>
            <Heart className={cn("h-6 w-6 transition-all", hasLiked && "fill-red-500 text-red-500 scale-110")} />
          </span>
          <span className="text-[11px] mt-1 tabular-nums">{stats.total_likes}</span>
        </button>
        <button
          onClick={() => { if (!user) return openAuth(); setCommentOverlayOpen(true); }}
          className="flex flex-col items-center text-white active:scale-95 transition"
        >
          <span className="h-12 w-12 rounded-full bg-white/15 backdrop-blur flex items-center justify-center">
            <MessageCircle className="h-6 w-6" />
          </span>
          <span className="text-[11px] mt-1 tabular-nums">{stats.total_comments}</span>
        </button>
        <button onClick={() => { if (!user) return openAuth(); setGiftOpen(true); }} className="flex flex-col items-center text-white active:scale-95 transition">
          <span className="h-12 w-12 rounded-full bg-gradient-to-br from-amber-400 to-fuchsia-500 flex items-center justify-center shadow-lg shadow-amber-900/40">
            <Gift className="h-6 w-6" />
          </span>
          <span className="text-[11px] mt-1">Gift</span>
        </button>
        <button onClick={share} className="flex flex-col items-center text-white active:scale-95 transition">
          <span className="h-12 w-12 rounded-full bg-white/15 backdrop-blur flex items-center justify-center">
            <Share2 className="h-6 w-6" />
          </span>
          <span className="text-[11px] mt-1">Share</span>
        </button>
        <button
          onClick={() => { if (!user) return openAuth(); toggleFavorite(stream.astrologer.id); }}
          className="flex flex-col items-center text-white active:scale-95 transition"
        >
          <span className={cn(
            "h-12 w-12 rounded-full backdrop-blur flex items-center justify-center transition-colors",
            favorited ? "bg-amber-400/30" : "bg-white/15"
          )}>
            <Star className={cn("h-6 w-6 transition-all", favorited && "fill-amber-400 text-amber-400 scale-110")} />
          </span>
          <span className="text-[11px] mt-1">{favorited ? "Saved" : "Save"}</span>
        </button>
      </div>

      {/* Bottom: title, comments, input */}
      <div className="absolute bottom-0 inset-x-0 z-20 p-4 pb-[calc(env(safe-area-inset-bottom)+0.75rem)] bg-gradient-to-t from-black/80 to-transparent pr-20">
        <div className="font-semibold text-sm">{stream.title}</div>
        {stream.astrologer.specializations?.length > 0 && (
          <div className="flex gap-1 mt-1 flex-wrap">
            {stream.astrologer.specializations.slice(0, 3).map((s) => (
              <span key={s} className="text-[10px] px-2 py-0.5 rounded-full bg-white/15">{s}</span>
            ))}
          </div>
        )}

        <div className="mt-3 max-h-32 overflow-hidden space-y-1 mb-3">
          {comments.slice(-4).map((c) => (
            <div key={c.id} className="text-xs animate-in fade-in slide-in-from-bottom-2 duration-300">
              <span className={cn("font-semibold mr-1", c.is_host ? "text-amber-300" : "text-white/90")}>
                {c.user_name}{c.is_host && " · HOST"}:
              </span>
              <span className="text-white/85">{c.comment_text}</span>
            </div>
          ))}
        </div>

        {/* Call action bar — Public Audio, Public Video, Private (above comment input) */}
        {!coHostRequestId && !isPaused && (() => {
          const audioRate = Number(stream.astrologer.base_rate_per_min ?? 0);
          const videoRate = Math.round(audioRate * 1.5);
          return (
            <div className="mb-3 flex gap-1.5 rounded-2xl bg-black/40 backdrop-blur-md p-1.5 border border-white/10 animate-in slide-in-from-bottom-2 duration-300">
              <button
                onClick={() => { if (!user) return openAuth(); setCallType("public"); setCallMedia("audio"); setCallOpen(true); }}
                className="flex-1 flex flex-col items-center justify-center gap-0.5 h-12 rounded-xl bg-gradient-to-r from-emerald-500 to-emerald-400 text-black font-bold shadow-lg shadow-emerald-900/40 active:scale-[0.98] transition"
                aria-label="Request public audio call"
              >
                <span className="flex items-center gap-1.5">
                  <Phone className="h-4 w-4" />
                  <span className="text-xs">Audio Call</span>
                </span>
                <span className="text-[10px] opacity-80">₹{audioRate}/min</span>
              </button>
              <button
                onClick={() => { if (!user) return openAuth(); setCallType("public"); setCallMedia("video"); setCallOpen(true); }}
                className="flex-1 flex flex-col items-center justify-center gap-0.5 h-12 rounded-xl bg-gradient-to-r from-amber-500 to-yellow-400 text-black font-bold shadow-lg shadow-amber-900/40 active:scale-[0.98] transition"
                aria-label="Request public video call"
              >
                <span className="flex items-center gap-1.5">
                  <Video className="h-4 w-4" />
                  <span className="text-xs">Video Call</span>
                </span>
                <span className="text-[10px] opacity-80">₹{videoRate}/min</span>
              </button>
              <button
                onClick={() => { if (!user) return openAuth(); setCallType("private"); setCallMedia("video"); setCallOpen(true); }}
                className="flex-1 flex flex-col items-center justify-center gap-0.5 h-12 rounded-xl bg-gradient-to-r from-purple-600 to-indigo-600 text-white font-bold shadow-lg shadow-purple-900/40 active:scale-[0.98] transition"
                aria-label="Request private call"
              >
                <span className="flex items-center gap-1.5">
                  <Lock className="h-4 w-4" />
                  <span className="text-xs">Private</span>
                </span>
                <span className="text-[10px] opacity-80">₹{videoRate}/min</span>
              </button>
            </div>
          );
        })()}

        <div className="flex gap-2 items-center">
          <Input
            value={text}
            onChange={(e) => setText(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && !isPaused && send()}
            disabled={isPaused}
            placeholder={isPaused ? "Chat paused while astrologer is in private session" : "Add a comment…"}
            className={cn(
              "bg-white/10 border-white/20 text-white placeholder:text-white/60 h-10",
              isPaused && "opacity-60 cursor-not-allowed"
            )}
          />
          <Button size="icon" onClick={send} disabled={isPaused} className="bg-gradient-to-r from-amber-500 to-fuchsia-500 disabled:opacity-50">
            <Send className="h-4 w-4" />
          </Button>
        </div>
      </div>

      {/* Gift overlay (animations) — only when active to save resources */}
      {active && <LiveGiftHost liveStreamId={stream.id} />}

      {/* Gift picker */}
      {user && (
        <LiveGiftPicker
          open={giftOpen}
          onOpenChange={setGiftOpen}
          liveStreamId={stream.id}
          astrologerName={stream.astrologer.display_name}
          astrologerAvatar={stream.astrologer.avatar_url}
        />
      )}

      {/* Top Gifters drawer */}
      <TopGiftersDrawer
        open={topGiftersOpen}
        onOpenChange={setTopGiftersOpen}
        liveStreamId={stream.id}
        astrologerName={stream.astrologer.display_name}
      />

      {/* Notify-me bell + global notification bell (top right, before close X) */}
      <div className="absolute top-4 right-16 z-40 flex items-center gap-2" style={{ marginTop: "env(safe-area-inset-top)" }}>
        <NotifyMeBell astrologerId={stream.astrologer.id} astrologerName={stream.astrologer.display_name} />
        <NotificationBell variant="dark" />
      </div>

      {/* Public/Private call request modal */}
      {user && (
        <LiveCallRequestModal
          open={callOpen}
          onOpenChange={setCallOpen}
          requestType={callType}
          mediaType={callMedia}
          liveStreamId={stream.id}
          astrologerName={stream.astrologer.display_name}
          astrologerAvatar={stream.astrologer.avatar_url}
          ratePerMin={
            callMedia === "video"
              ? Math.round(Number(stream.astrologer.base_rate_per_min ?? 0) * 1.5)
              : Number(stream.astrologer.base_rate_per_min ?? 0)
          }
          onAccepted={async (requestId) => {
            const { data } = await supabase
              .from("live_call_requests")
              .select("request_type, linked_call_session_id, media_type")
              .eq("id", requestId)
              .maybeSingle();
            if (data?.request_type === "private" && data.linked_call_session_id) {
              navigateRoot(`/call/${data.linked_call_session_id}`);
            } else {
              setCoHostMedia((data?.media_type as "audio" | "video") ?? callMedia);
              setCoHostRequestId(requestId);
            }
          }}
        />
      )}

      {/* Public co-host overlay */}
      {coHostRequestId && (
        <LivePublicCoHost
          requestId={coHostRequestId}
          channelName={stream.channel_name}
          ratePerMin={
            coHostMedia === "video"
              ? Math.round(Number(stream.astrologer.base_rate_per_min ?? 0) * 1.5)
              : Number(stream.astrologer.base_rate_per_min ?? 0)
          }
          mediaType={coHostMedia}
          onEnded={() => setCoHostRequestId(null)}
        />
      )}

      {/* Pause overlay for other viewers when astrologer is in private session */}
      {isPaused && active && (
        <LivePauseOverlay astrologerName={stream.astrologer.display_name} />
      )}

      {/* Resumed banner */}
      {showResumed && active && (
        <LiveResumedBanner
          astrologerName={stream.astrologer.display_name}
          onDone={() => setShowResumed(false)}
        />
      )}

      {/* Comment overlay (mobile-friendly dedicated input) */}
      <Dialog open={commentOverlayOpen} onOpenChange={(v) => !isPaused && setCommentOverlayOpen(v)}>
        <DialogContent className="max-w-md p-0 overflow-hidden border-2 border-amber-300/30 bg-gradient-to-b from-[#1a0a2e] to-[#0f0620] text-white sm:rounded-3xl">
          <div className="p-5">
            <div className="text-sm font-semibold mb-3 flex items-center gap-2">
              <MessageCircle className="h-4 w-4 text-amber-300" />
              Comment on {stream.astrologer.display_name}'s live
            </div>
            <Input
              autoFocus
              value={text}
              onChange={(e) => setText(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Enter" && !isPaused && text.trim()) {
                  send();
                  setCommentOverlayOpen(false);
                }
              }}
              disabled={isPaused}
              placeholder={isPaused ? "Chat paused" : "Type your comment…"}
              className="bg-white/10 border-white/20 text-white placeholder:text-white/60 h-12"
            />
            <div className="mt-3 flex justify-end gap-2">
              <Button variant="outline" onClick={() => setCommentOverlayOpen(false)} className="bg-white/5 border-white/20 text-white hover:bg-white/10">
                Cancel
              </Button>
              <Button
                onClick={() => { send(); setCommentOverlayOpen(false); }}
                disabled={isPaused || !text.trim()}
                className="bg-gradient-to-r from-amber-500 to-fuchsia-500"
              >
                <Send className="h-4 w-4" /> Send
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </section>
  );
}

export default function LiveFeed() {
  const navigate = useNavigate();
  const { streams, loading } = useLiveStreams();
  const settings = usePlatformSettings();
  const containerRef = useRef<HTMLDivElement>(null);
  const [activeIndex, setActiveIndex] = useState(0);

  // Lock body scroll while feed is mounted
  useEffect(() => {
    const prev = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => { document.body.style.overflow = prev; };
  }, []);

  // Track which card is in view (snap)
  const onScroll = useCallback(() => {
    const el = containerRef.current;
    if (!el) return;
    const idx = Math.round(el.scrollTop / el.clientHeight);
    if (idx !== activeIndex) setActiveIndex(idx);
  }, [activeIndex]);

  // Block when AstroLive disabled
  if (settings && (settings.astrolive_enabled === false)) {
    return (
      <div className="min-h-screen bg-black text-white flex flex-col items-center justify-center p-8 text-center">
        <Radio className="h-12 w-12 mb-3 opacity-60" />
        <h2 className="text-xl font-semibold">AstroLive is currently unavailable</h2>
        <Button variant="outline" className="mt-4 bg-white/10 text-white border-white/20" onClick={() => navigate("/")}>Back to home</Button>
      </div>
    );
  }

  if (loading) {
    return <div className="min-h-screen bg-black text-white flex items-center justify-center"><Sparkles className="h-6 w-6 animate-pulse" /></div>;
  }

  if (streams.length === 0) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center p-8 text-center" style={{ backgroundColor: "#FBF1E2" }}>
        <Radio className="h-16 w-16 mb-4" style={{ color: "#ED7B2A" }} />
        <h2 className="text-2xl font-bold" style={{ color: "#2D2419" }}>No astrologers are live right now</h2>
        <p className="mt-2 text-sm max-w-md" style={{ color: "#5A4A3A" }}>Check back soon — your favourite astrologers will be live in no time.</p>
        <div className="flex flex-wrap justify-center gap-3 mt-6">
          <Button
            onClick={() => navigate("/astrologers")}
            className="rounded-full px-6 text-white hover:opacity-90"
            style={{ backgroundColor: "#ED7B2A" }}
          >
            Browse astrologers
          </Button>
          <Button
            variant="outline"
            className="rounded-full px-6 bg-transparent"
            style={{ borderColor: "#ED7B2A", color: "#ED7B2A" }}
            onClick={() => navigate("/")}
          >
            Home
          </Button>
        </div>
      </div>
    );
  }

  return (
    <>
      <style>{`@keyframes float { 0%{transform:translateY(0);opacity:1} 100%{transform:translateY(-160px) scale(1.6);opacity:0} }`}</style>
      <button
        onClick={() => navigate(-1)}
        className="fixed top-4 right-4 z-50 h-10 w-10 rounded-full bg-black/50 text-white flex items-center justify-center backdrop-blur"
        style={{ marginTop: "env(safe-area-inset-top)" }}
        aria-label="Close"
      >
        <X className="h-5 w-5" />
      </button>
      {/* On desktop, frame the feed at TikTok 9:16 with black side panels.
          On mobile, the feed fills the full viewport. */}
      <div className="fixed inset-0 z-40 bg-black flex items-center justify-center">
        <div
          ref={containerRef}
          onScroll={onScroll}
          className="
            h-screen w-screen overflow-y-auto snap-y snap-mandatory bg-black
            md:h-[min(100vh,calc((100vw)*16/9))]
            md:w-[min(100vw,calc(100vh*9/16))]
            md:max-w-[480px]
            md:rounded-2xl md:shadow-2xl md:shadow-black/60
            md:overflow-hidden
          "
          style={{ scrollSnapType: "y mandatory" }}
        >
          {streams.map((s, i) => (
            <StreamView key={s.id} stream={s} active={i === activeIndex} />
          ))}
        </div>
      </div>
    </>
  );
}
