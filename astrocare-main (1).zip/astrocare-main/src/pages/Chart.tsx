import { useEffect, useMemo, useState } from "react";
import { useNavigate, useParams, Link } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { useTranslation } from "react-i18next";
import { AppShell } from "@/components/layout/AppShell";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import { Calendar, MapPin, ArrowLeft, AlertTriangle, RefreshCw, Sparkles } from "lucide-react";
import { NorthIndianChart } from "@/components/chart/NorthIndianChart";
import { SouthIndianChart } from "@/components/chart/SouthIndianChart";
import { buildD1, buildD9, type ChartData } from "@/lib/vedicChart";
import type { BirthChartRow } from "@/hooks/useBirthCharts";
import { VimshottariDasha } from "@/components/chart/VimshottariDasha";
import { PlanetPositionsTable, type RawPlanetRow, type RawAscendantRow } from "@/components/chart/PlanetPositionsTable";
import { useDasha } from "@/hooks/useDasha";
import { toast } from "sonner";
import { FeatureRail } from "@/components/chart/FeatureRail";
import { isLocalChartId, getLocalChart, readChartFromHash, saveLocalChart } from "@/lib/localCharts";
import { useAuthDialog } from "@/components/auth/AuthDialog";

type ChartStyle = "north" | "south";
const STYLE_KEY = "preferredChartStyle";

const MONTHS_SHORT = [
  "Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec",
];

function formatBirthDateLabel(isoDate: string): string {
  const [y, m, d] = isoDate.split("-").map(Number);
  if (!y || !m || !d) return isoDate;
  return `${String(d).padStart(2, "0")} ${MONTHS_SHORT[m - 1]} ${y}`;
}

function chartSource(row: BirthChartRow | null): string {
  if (!row) return "inhouse";
  const direct = (row as unknown as { source?: string }).source;
  if (direct) return direct;
  const inJson = (row.chart_data as unknown as { source?: string } | null)?.source;
  return inJson ?? "inhouse";
}

export default function Chart() {
  const { id } = useParams<{ id: string }>();
  const { user, loading: authLoading } = useAuth();
  const navigate = useNavigate();
  const { t } = useTranslation("chart");
  const { open: openAuthDialog } = useAuthDialog();

  const [chart, setChart] = useState<BirthChartRow | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [recomputing, setRecomputing] = useState(false);
  const [savingToProfile, setSavingToProfile] = useState(false);
  const [style, setStyle] = useState<ChartStyle>(() => {
    if (typeof window === "undefined") return "north";
    return (localStorage.getItem(STYLE_KEY) as ChartStyle) ?? "north";
  });

  const isLocal = isLocalChartId(id);

  useEffect(() => {
    localStorage.setItem(STYLE_KEY, style);
  }, [style]);

  useEffect(() => {
    if (!id) return;

    // Local (anonymous) chart: load from sessionStorage. Works for logged-out
    // users so cold marketing traffic can try the Free Kundli flow end-to-end.
    if (isLocal) {
      // 1) Try sessionStorage (chart created in this browser session)
      let local = getLocalChart(id);
      // 2) Fall back to URL hash payload (shared link from another device)
      if (!local) {
        const fromHash = readChartFromHash();
        if (fromHash && fromHash.id === id) {
          local = fromHash;
          // Cache locally so subsequent navigations work without the hash
          try { saveLocalChart(local); } catch { /* ignore quota */ }
        }
      }
      if (!local) {
        setError("This chart link has expired. Local charts only persist for the current browser session.");
      } else {
        setChart(local);
      }
      setLoading(false);
      return;
    }

    // DB-backed chart: requires sign-in (RLS is owner-only).
    if (authLoading) return;
    if (!user) {
      navigate("/sign-in", { replace: true });
      return;
    }
    let cancelled = false;
    (async () => {
      setLoading(true);
      const { data, error } = await (supabase as any)
        .from("birth_charts")
        .select("*")
        .eq("id", id)
        .eq("user_id", user.id)
        .maybeSingle();
      if (cancelled) return;
      if (error || !data) {
        setError("Chart not found or you don't have permission to view it.");
      } else {
        setChart(data as BirthChartRow);
      }
      setLoading(false);
    })();
    return () => { cancelled = true; };
  }, [id, user, authLoading, navigate, isLocal]);

  // Auto-claim a local chart once the user signs in while viewing it.
  useEffect(() => {
    if (!isLocal || !chart || !user || savingToProfile) return;
    let cancelled = false;
    (async () => {
      setSavingToProfile(true);
      const { data, error } = await (supabase as any)
        .from("birth_charts")
        .insert({
          user_id: user.id,
          chart_name: chart.chart_name,
          birth_date: chart.birth_date,
          birth_time: chart.birth_time,
          time_unknown: chart.time_unknown,
          location_name: chart.location_name,
          latitude: chart.latitude,
          longitude: chart.longitude,
          timezone: chart.timezone,
          gender: chart.gender,
          chart_data: chart.chart_data,
          source: chartSource(chart),
        })
        .select("*").single();
      if (cancelled) return;
      if (!error && data) {
        toast.success("Chart saved to your profile!");
        navigate(`/chart/${(data as BirthChartRow).id}`, { replace: true });
      }
      setSavingToProfile(false);
    })();
    return () => { cancelled = true; };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isLocal, user, chart?.id]);

  // Dasha now supports both DB-backed (real UUID) and local (`local-{uuid}`)
  // charts via dual-mode edge function + hook.
  const dasha = useDasha(chart?.id, true);

  const views = useMemo(() => {
    if (!chart?.chart_data) return null;
    const data = chart.chart_data as unknown as ChartData;
    if (!data.planets || !data.ascendant) return null;
    return { d1: buildD1(data), d9: buildD9(data) };
  }, [chart]);

  const isStale = chart ? chartSource(chart) !== "astrologyapi" : false;

  async function handleRecompute() {
    if (!chart) return;
    setRecomputing(true);
    try {
      const { data: calc, error: calcErr } = await supabase.functions.invoke("calculate-chart", {
        body: {
          birthDate: chart.birth_date,
          birthTime: chart.birth_time ?? "12:00",
          latitude: Number(chart.latitude),
          longitude: Number(chart.longitude),
          timezone: chart.timezone,
          timeUnknown: chart.time_unknown,
        },
      });
      if (calcErr || !calc || (calc as { error?: string }).error) {
        throw new Error((calc as { error?: string })?.error || calcErr?.message || "Recompute failed");
      }
      const computed = calc as ChartData & { source?: string };
      const nextSource: "astrologyapi" | "inhouse" =
        computed.source === "astrologyapi" ? "astrologyapi" : "inhouse";

      if (isLocal) {
        const updated = { ...chart, chart_data: computed, source: nextSource } as BirthChartRow;
        const { saveLocalChart } = await import("@/lib/localCharts");
        saveLocalChart(updated);
        setChart(updated);
        toast.success(t("recompute_done"));
        return;
      }

      const { data: updated, error: upErr } = await (supabase as any)
        .from("birth_charts")
        .update({
          chart_data: computed,
          source: nextSource,
          recomputed_at: new Date().toISOString(),
        })
        .eq("id", chart.id)
        .select("*")
        .single();
      if (upErr) throw upErr;

      setChart(updated as BirthChartRow);
      toast.success(t("recompute_done"));
    } catch (err) {
      const msg = err instanceof Error ? err.message : String(err);
      toast.error(`${t("recompute_failed")}: ${msg}`);
    } finally {
      setRecomputing(false);
    }
  }

  return (
    <AppShell>
      <div className="container max-w-6xl py-6 space-y-6">
        <div className="flex items-center gap-2">
          <Button variant="ghost" size="sm" asChild>
            <Link to="/"><ArrowLeft className="h-4 w-4" /> Home</Link>
          </Button>
        </div>

        {loading || authLoading ? (
          <div className="grid gap-4 md:grid-cols-2">
            <Skeleton className="aspect-square w-full" />
            <Skeleton className="aspect-square w-full" />
          </div>
        ) : error ? (
          <Card><CardContent className="py-12 text-center text-muted-foreground">{error}</CardContent></Card>
        ) : chart && views ? (
          <>
            {isLocal && !user && (
              <div className="rounded-lg border border-[#ED7B2A]/40 bg-[#FBF1E2] px-4 py-3 flex flex-col sm:flex-row gap-3 sm:items-center sm:justify-between">
                <div className="flex items-start gap-3 min-w-0">
                  <Sparkles className="h-5 w-5 text-[#ED7B2A] shrink-0 mt-0.5" />
                  <div className="min-w-0">
                    <p className="text-sm font-semibold text-foreground">
                      💎 Save this chart to your profile
                    </p>
                    <p className="text-xs text-muted-foreground">
                      Sign up free to keep this chart forever and unlock daily personalised horoscopes.
                    </p>
                  </div>
                </div>
                <Button
                  size="sm"
                  className="bg-[#ED7B2A] hover:bg-[#D86E20] text-white shrink-0"
                  onClick={() => openAuthDialog("sign-up")}
                >
                  Save & Sign Up Free
                </Button>
              </div>
            )}

            {isStale && (
              <div className="rounded-lg border border-secondary/50 bg-secondary/10 px-4 py-3 flex flex-col sm:flex-row gap-3 sm:items-center sm:justify-between">
                <div className="flex items-start gap-3 min-w-0">
                  <AlertTriangle className="h-5 w-5 text-secondary shrink-0 mt-0.5" />
                  <div className="min-w-0">
                    <p className="text-sm font-semibold text-foreground">
                      {t("stale_banner_title")}
                    </p>
                    <p className="text-xs text-muted-foreground">
                      {t("stale_banner_body")}
                    </p>
                  </div>
                </div>
                <Button
                  size="sm"
                  variant="outline"
                  className="border-secondary text-foreground hover:bg-secondary/20 shrink-0"
                  onClick={handleRecompute}
                  disabled={recomputing}
                >
                  <RefreshCw className={`h-3.5 w-3.5 ${recomputing ? "animate-spin" : ""}`} />
                  {recomputing ? t("recomputing") : t("recompute")}
                </Button>
              </div>
            )}

            <Card>
              <CardHeader className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 space-y-0">
                <div className="space-y-1">
                  <CardTitle className="text-xl">
                    {chart.chart_name || `${t("title")} ${chart.birth_date}`}
                  </CardTitle>
                  <div className="flex flex-wrap gap-x-4 gap-y-1 text-sm text-muted-foreground">
                    <span className="flex items-center gap-1">
                      <Calendar className="h-3.5 w-3.5" />
                      {formatBirthDateLabel(chart.birth_date)}
                      {chart.birth_time && !chart.time_unknown && ` · ${chart.birth_time.slice(0, 5)}`}
                      {chart.timezone && !chart.time_unknown && (
                        <span className="ml-1 text-xs opacity-70">({chart.timezone})</span>
                      )}
                      {chart.time_unknown && (
                        <Badge variant="secondary" className="ml-1 text-[10px]">{t("time_unknown")}</Badge>
                      )}
                    </span>
                    <span className="flex items-center gap-1">
                      <MapPin className="h-3.5 w-3.5" />
                      {chart.location_name}
                    </span>
                  </div>
                  <p className="text-xs text-muted-foreground">
                    {t("lahiri_note")}
                  </p>
                </div>
                <div className="inline-flex rounded-md border border-border p-0.5 bg-muted/40 self-start">
                  <button
                    type="button"
                    onClick={() => setStyle("north")}
                    className={`px-3 py-1.5 text-sm rounded-sm transition-colors ${
                      style === "north" ? "bg-background shadow-sm font-medium" : "text-muted-foreground"
                    }`}
                  >
                    {t("north_indian")}
                  </button>
                  <button
                    type="button"
                    onClick={() => setStyle("south")}
                    className={`px-3 py-1.5 text-sm rounded-sm transition-colors ${
                      style === "south" ? "bg-background shadow-sm font-medium" : "text-muted-foreground"
                    }`}
                  >
                    {t("south_indian")}
                  </button>
                </div>
              </CardHeader>
            </Card>

            <div className="grid gap-6 md:grid-cols-2">
              <Card className="bg-white">
                <CardContent className="pt-6">
                  {style === "north"
                    ? <NorthIndianChart view={views.d1} title={t("d1_rasi")} />
                    : <SouthIndianChart view={views.d1} title={t("d1_rasi")} />}
                </CardContent>
              </Card>
              <Card className="bg-white">
                <CardContent className="pt-6">
                  {style === "north"
                    ? <NorthIndianChart view={views.d9} title={t("d9_navamsa")} />
                    : <SouthIndianChart view={views.d9} title={t("d9_navamsa")} />}
                </CardContent>
              </Card>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-5 gap-6 items-start">
              <div className="lg:col-span-3 min-w-0">
                {chart.chart_data && (chart.chart_data as unknown as { planets?: RawPlanetRow[] }).planets && (chart.chart_data as unknown as { ascendant?: RawAscendantRow }).ascendant && (
                  <PlanetPositionsTable
                    planets={(chart.chart_data as unknown as { planets: RawPlanetRow[] }).planets}
                    ascendant={(chart.chart_data as unknown as { ascendant: RawAscendantRow }).ascendant}
                  />
                )}
              </div>
              <div className="lg:col-span-2 min-w-0">
                <VimshottariDasha
                  status={dasha.status}
                  error={dasha.error}
                  tree={dasha.dasha?.dasha_tree ?? null}
                  onCompute={dasha.compute}
                />
              </div>
            </div>
            <FeatureRail chart={chart} />
          </>
        ) : (
          <Card><CardContent className="py-12 text-center text-muted-foreground">Chart data unavailable.</CardContent></Card>
        )}
      </div>
    </AppShell>
  );
}
