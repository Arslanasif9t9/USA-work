import { useState } from "react";
import { Link } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { Loader2, Mail, Sparkles, ArrowLeft } from "lucide-react";

export default function ForgotPassword() {
  const { toast } = useToast();
  const [email, setEmail] = useState("");
  const [loading, setLoading] = useState(false);
  const [sent, setSent] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      const redirectTo = `${window.location.origin}/auth/callback`;
      // eslint-disable-next-line no-console
      console.info("[forgot-password] requesting reset", { email, redirectTo });

      const { error } = await supabase.auth.resetPasswordForEmail(email, {
        redirectTo,
      });

      if (error) {
        // Always log the actual Supabase error so we can debug delivery issues.
        // eslint-disable-next-line no-console
        console.error("[forgot-password] resetPasswordForEmail error:", {
          message: error.message,
          status: (error as { status?: number }).status,
          name: error.name,
        });

        // Surface rate-limit messages clearly (Supabase returns 429 with
        // "For security purposes, you can only request this after N seconds").
        const status = (error as { status?: number }).status;
        const msg = error.message || "";
        const isRateLimited = status === 429 || /rate|after \d+ seconds/i.test(msg);
        if (isRateLimited) {
          const secMatch = msg.match(/after (\d+) seconds/i);
          const secs = secMatch ? Number(secMatch[1]) : 60;
          toast({
            title: "Too many attempts",
            description: `Please wait ${secs} seconds and try again.`,
            variant: "destructive",
          });
          return;
        }

        // For any other error, still show success (don't leak which emails
        // exist) but the console log above gives us the real reason.
      }

      setSent(true);
    } catch (err) {
      // eslint-disable-next-line no-console
      console.error("[forgot-password] unexpected error:", err);
      toast({
        title: "Couldn't send reset link",
        description: (err as Error).message,
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };


  return (
    <div className="min-h-screen flex items-center justify-center bg-background px-4">
      <div className="max-w-md w-full p-8 rounded-lg border border-border bg-card shadow-card space-y-5">
        <Link
          to="/sign-in"
          className="inline-flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground"
        >
          <ArrowLeft className="h-4 w-4" /> Back to sign in
        </Link>
        <div className="flex items-center gap-2 text-primary">
          <Sparkles className="h-5 w-5" />
          <span className="font-bold tracking-tight">AstroGuide</span>
        </div>

        {sent ? (
          <div className="space-y-3">
            <Mail className="h-10 w-10 text-primary" />
            <h1 className="text-xl font-semibold">Check your email</h1>
            <p className="text-sm text-muted-foreground">
              If an account exists for <strong>{email}</strong>, we've sent a
              password reset link. The link expires in 1 hour.
            </p>
            <p className="text-xs text-muted-foreground">
              Don't see it? Check your spam folder, or make sure you used the
              same email you signed up with.
            </p>
            <div className="flex flex-col gap-2 pt-2">
              <Link to="/sign-in">
                <Button variant="saffron" className="w-full">
                  Back to sign in
                </Button>
              </Link>
              <Button
                variant="outline"
                className="w-full"
                onClick={() => {
                  setSent(false);
                }}
              >
                Try a different email
              </Button>
            </div>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <h1 className="text-xl font-semibold">Forgot your password?</h1>
              <p className="text-sm text-muted-foreground mt-1">
                Enter your email and we'll send you a link to reset it.
              </p>
            </div>
            <div className="space-y-2">
              <Label htmlFor="reset-email">Email</Label>
              <Input
                id="reset-email"
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="you@example.com"
                required
                autoComplete="email"
              />
            </div>
            <Button
              type="submit"
              variant="saffron"
              size="lg"
              className="w-full"
              disabled={loading || !email}
            >
              {loading ? (
                <>
                  <Loader2 className="h-4 w-4 animate-spin" /> Sending…
                </>
              ) : (
                "Send reset link"
              )}
            </Button>
          </form>
        )}
      </div>
    </div>
  );
}
