import { useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { useAuthDialog } from "@/components/auth/AuthDialog";

export default function SignIn() {
  const navigate = useNavigate();
  const { open } = useAuthDialog();
  useEffect(() => {
    navigate("/", { replace: true });
    open("sign-in");
  }, [navigate, open]);
  return null;
}
