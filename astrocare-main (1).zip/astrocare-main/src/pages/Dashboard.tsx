import { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { useWallet, formatINR } from "@/hooks/useWallet";
import { useProfile } from "@/hooks/useProfile";
import { AppShell } from "@/components/layout/AppShell";
import { ProtectedRoute } from "@/components/auth/ProtectedRoute";
import { ErrorBoundary } from "@/components/ErrorBoundary";
import { RechargeModal } from "@/components/wallet/RechargeModal";
import { BirthChartModal } from "@/components/birth-chart/BirthChartModal";
import { useBirthCharts } from "@/hooks/useBirthCharts";
import { PanchangWidget } from "@/components/panchang/PanchangWidget";
import { Sparkles, HeartHandshake } from "lucide-react";
import { BackButton } from "@/components/layout/BackButton";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Calendar,
  Clock,
  MapPin,
  IdCard,
  Wallet as WalletIcon,
  ChevronRight,
  Plus,
  ShoppingBag,
  AlertCircle,
} from "lucide-react";
import { format } from "date-fns";

interface Purchase {
  id: string;
  product_id: string;
  product_type: string;
  purchased_at: string;
  metadata: Record<string, unknown>;
}

function DashboardInner() {
  const { user } = useAuth();
  const { wallet, loading: walletLoading, error: walletError, refresh: refreshWallet } = useWallet();
  const { profile, loading: profileLoading, error: profileError, refresh: refreshProfile } = useProfile();
  const [purchases, setPurchases] = useState<Purchase[]>([]);
  const [purchasesLoading, setPurchasesLoading] = useState(true);
  const [rechargeOpen, setRechargeOpen] = useState(false);
  const [rechargeTab, setRechargeTab] =
    useState<"recharge" | "custom">("recharge");
  const { charts, refresh: refreshCharts } = useBirthCharts();
  const [chartModalOpen, setChartModalOpen] = useState(false);

  const navigate = useNavigate();

  const handleAstroAction = (label: string) => {
    if (charts.length === 0) {
      setChartModalOpen(true);
    } else {
      // Navigate to the primary chart view; horoscope/match are surfaced from chart context.
      navigate(`/chart/${charts[0].id}`);
      toast(`${label} — opening your chart`, {
        description: "Horoscope, Dasha, and matchmaking insights are surfaced from your primary kundli.",
      });
    }
  };
  const [setupRan, setSetupRan] = useState(false);
  const [setupError, setSetupError] = useState<string | null>(null);

  // Self-heal: if profile/wallet rows are missing for any reason, the RPC
  // creates them idempotently. Then refresh both hooks.
  useEffect(() => {
    if (!user || setupRan) return;
    if (walletLoading || profileLoading) return;
    if (wallet && profile) {
      setSetupRan(true);
      return;
    }
    let cancelled = false;
    (async () => {
      const { error } = await supabase.rpc("ensure_user_setup");
      if (cancelled) return;
      if (error) {
        setSetupError(error.message);
      } else {
        await Promise.all([refreshWallet(), refreshProfile()]);
        setSetupError(null);
      }
      setSetupRan(true);
    })();
    return () => {
      cancelled = true;
    };
  }, [user, wallet, profile, walletLoading, profileLoading, setupRan, refreshWallet, refreshProfile]);

  useEffect(() => {
    if (!user) return;
    setPurchasesLoading(true);
    supabase
      .from("user_purchases")
      .select("id, product_id, product_type, purchased_at, metadata")
      .eq("user_id", user.id)
      .order("purchased_at", { ascending: false })
      .limit(10)
      .then(({ data }) => {
        setPurchases((data ?? []) as Purchase[]);
        setPurchasesLoading(false);
      });
  }, [user]);

  const greeting = (() => {
    const h = new Date().getHours();
    if (h < 12) return "Good morning";
    if (h < 17) return "Good afternoon";
    return "Good evening";
  })();

  const formatTOB = (t: string) => {
    const [hh, mm] = t.split(":");
    let h = parseInt(hh, 10);
    const meridiem = h >= 12 ? "PM" : "AM";
    h = h % 12 === 0 ? 12 : h % 12;
    return `${h}:${mm} ${meridiem}`;
  };

  const openRecharge = (tab: "recharge" | "custom") => {
    setRechargeTab(tab);
    setRechargeOpen(true);
  };

  const initialLoading = walletLoading || profileLoading;
  const fatalError = walletError || profileError || setupError;

  // FATAL fetch error → show recoverable error UI (not blank)
  if (fatalError && setupRan) {
    return (
      <AppShell>
        <div className="container py-16">
          <Card className="max-w-md mx-auto text-center">
            <CardContent className="py-10 space-y-4">
              <AlertCircle className="h-10 w-10 text-destructive mx-auto" />
              <h2 className="text-lg font-semibold">Couldn't load your dashboard</h2>
              <p className="text-sm text-muted-foreground break-words">{fatalError}</p>
              <Button
                variant="saffron"
                onClick={() => {
                  setSetupRan(false);
                  setSetupError(null);
                  refreshWallet();
                  refreshProfile();
                }}
              >
                Retry
              </Button>
            </CardContent>
          </Card>
        </div>
      </AppShell>
    );
  }

  return (
    <AppShell>
      <div className="container py-8 space-y-8">
        <BackButton to="/" label="Home" />
        <div>
          <p className="text-sm text-muted-foreground">{greeting},</p>
          {initialLoading ? (
            <Skeleton className="h-8 w-48 mt-1" />
          ) : (
            <h1 className="text-2xl md:text-3xl font-bold">
              {profile?.name?.trim() || "Welcome"}
            </h1>
          )}
          {initialLoading ? (
            <Skeleton className="h-4 w-64 mt-2" />
          ) : (
            <p className="text-sm text-muted-foreground mt-1 tabular-nums">
              {formatINR(wallet?.balance ?? 0)} wallet balance
            </p>
          )}
        </div>

{/* PANCHANG moved below — wallet & profile shown first */}
        {/* BALANCE / HISTORY SECTIONS */}
        <div className="grid gap-4 md:grid-cols-3">
          {/* Wallet — primary, takes 2 cols on md+ */}
          <Card className="shadow-card md:col-span-2 border-primary/20">
            <CardHeader className="pb-3">
              <CardTitle className="flex items-center gap-2 text-base">
                <WalletIcon className="h-5 w-5 text-primary" /> Wallet balance
              </CardTitle>
            </CardHeader>
            <CardContent>
              {walletLoading ? (
                <Skeleton className="h-12 w-40" />
              ) : (
                <p className="text-4xl md:text-5xl font-bold tabular-nums text-primary">
                  {formatINR(wallet?.balance ?? 0)}
                </p>
              )}
              <p className="text-xs text-muted-foreground mt-2">
                Used to pay for consultations at each astrologer's per-minute rate.
              </p>
              <div className="flex gap-2 mt-4">
                <Button
                  variant="saffron"
                  size="sm"
                  onClick={() => openRecharge("recharge")}
                >
                  <Plus className="h-4 w-4" /> Recharge
                </Button>
                <Link to="/transactions" className="ml-auto">
                  <Button variant="ghost" size="sm">
                    History <ChevronRight className="h-4 w-4" />
                  </Button>
                </Link>
              </div>
            </CardContent>
          </Card>

          {/* Purchased items */}
          <Card className="shadow-card">
            <CardHeader className="pb-3">
              <CardTitle className="flex items-center gap-2 text-base">
                <ShoppingBag className="h-5 w-5 text-primary" /> Purchased items
              </CardTitle>
            </CardHeader>
            <CardContent>
              {purchasesLoading ? (
                <div className="space-y-2">
                  <Skeleton className="h-4 w-full" />
                  <Skeleton className="h-4 w-3/4" />
                </div>
              ) : purchases.length === 0 ? (
                <p className="text-sm text-muted-foreground">
                  No premium items yet. Reports and unlocks will appear here.
                </p>
              ) : (
                <ul className="space-y-2 text-sm">
                  {purchases.slice(0, 4).map((p) => (
                    <li key={p.id} className="flex justify-between gap-2">
                      <span className="truncate">{p.product_id}</span>
                      <span className="text-muted-foreground tabular-nums whitespace-nowrap">
                        {format(new Date(p.purchased_at), "dd MMM")}
                      </span>
                    </li>
                  ))}
                </ul>
              )}
            </CardContent>
          </Card>
        </div>

        {/* PROFILE CARD */}
        <Card className="shadow-card">
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center gap-2 text-base">
              <IdCard className="h-5 w-5 text-primary" /> Your profile
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            {profileLoading ? (
              <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-3">
                {Array.from({ length: 4 }).map((_, i) => (
                  <Skeleton key={i} className="h-16" />
                ))}
              </div>
            ) : (
              <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-3 text-sm">
                <InfoRow
                  icon={IdCard}
                  label="User ID"
                  value={
                    profile?.user_id_display
                      ? `#${profile.user_id_display}`
                      : "—"
                  }
                />
                <InfoRow
                  icon={Calendar}
                  label="Date of birth"
                  value={
                    profile?.dob
                      ? format(new Date(profile.dob), "dd MMM yyyy")
                      : "—"
                  }
                />
                <InfoRow
                  icon={Clock}
                  label="Time of birth"
                  value={profile?.tob ? formatTOB(profile.tob) : "—"}
                />
                <InfoRow
                  icon={MapPin}
                  label="Place of birth"
                  value={
                    profile?.pob_city
                      ? `${profile.pob_city}, ${profile.pob_state ?? ""}`
                      : "—"
                  }
                />
              </div>
            )}
            <Link to="/profile">
              <Button variant="saffron" size="sm" className="mt-2">
                Edit profile
              </Button>
            </Link>
          </CardContent>
        </Card>

        <Card className="shadow-card">
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center gap-2 text-base">
              <Sparkles className="h-5 w-5 text-primary" /> Your kundli
            </CardTitle>
          </CardHeader>
          <CardContent className="flex flex-wrap gap-2">
            <Button variant="saffron" size="sm" onClick={() => handleAstroAction("Get Horoscope")}>
              <Sparkles className="h-4 w-4" /> Get Horoscope
            </Button>
            <Button variant="outline" size="sm" onClick={() => handleAstroAction("Match Kundli")}>
              <HeartHandshake className="h-4 w-4" /> Match Kundli
            </Button>
            <Link to="/profile" className="ml-auto">
              <Button variant="ghost" size="sm">
                Manage charts <ChevronRight className="h-4 w-4" />
              </Button>
            </Link>
          </CardContent>
        </Card>

        {/* PANCHANG WIDGET — moved below wallet & profile */}
        {(() => {
          const primaryChart = charts[0];
          const loc = primaryChart
            ? {
                lat: Number(primaryChart.latitude),
                lon: Number(primaryChart.longitude),
                tz: primaryChart.timezone,
                label: primaryChart.location_name,
              }
            : { lat: 28.6139, lon: 77.2090, tz: "Asia/Kolkata", label: "New Delhi, India" };
          const today = (() => {
            const d = new Date();
            return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,"0")}-${String(d.getDate()).padStart(2,"0")}`;
          })();
          return (
            <PanchangWidget
              date={today}
              latitude={loc.lat}
              longitude={loc.lon}
              timezone={loc.tz}
              locationLabel={loc.label}
              showFullLink
            />
          );
        })()}
      </div>

      <RechargeModal
        open={rechargeOpen}
        onOpenChange={setRechargeOpen}
        defaultTab={rechargeTab}
      />
      <BirthChartModal
        open={chartModalOpen}
        onOpenChange={setChartModalOpen}
        onChartCreated={() => refreshCharts()}
      />
    </AppShell>
  );
}

function InfoRow({
  icon: Icon,
  label,
  value,
}: {
  icon: React.ElementType;
  label: string;
  value: string;
}) {
  return (
    <div className="flex items-start gap-3 p-3 rounded-md bg-section">
      <Icon className="h-4 w-4 text-primary mt-0.5 flex-shrink-0" />
      <div className="min-w-0">
        <p className="text-xs text-muted-foreground">{label}</p>
        <p className="font-medium truncate">{value}</p>
      </div>
    </div>
  );
}

export default function Dashboard() {
  return (
    <ProtectedRoute>
      <ErrorBoundary>
        <DashboardInner />
      </ErrorBoundary>
    </ProtectedRoute>
  );
}
