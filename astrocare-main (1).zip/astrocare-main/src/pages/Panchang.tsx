import { useEffect, useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import { format, parse, isValid, addDays, subDays } from "date-fns";
import { useTranslation } from "react-i18next";
import {
  Calendar as CalendarIcon, ChevronLeft, ChevronRight, MapPin, Loader2, ArrowLeft,
} from "lucide-react";
import { AppShell } from "@/components/layout/AppShell";
import { ErrorBoundary } from "@/components/ErrorBoundary";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Skeleton } from "@/components/ui/skeleton";
import { Alert, AlertDescription } from "@/components/ui/alert";
import {
  LocationAutocomplete, type LocationPick,
} from "@/components/birth-chart/LocationAutocomplete";
import { LagnaSunriseChart, type ChartStyle } from "@/components/panchang/LagnaSunriseChart";
import { PlanetaryPositionTable } from "@/components/panchang/PlanetaryPositionTable";
import { useBirthCharts } from "@/hooks/useBirthCharts";
import { usePanchang } from "@/hooks/usePanchang";
import { useLanguage } from "@/contexts/LanguageContext";
import { useAuth } from "@/contexts/AuthContext";
import { supabase } from "@/integrations/supabase/client";
import { formatLongDate } from "@/i18n/vedic";
import { cn } from "@/lib/utils";

const DEFAULT_LOCATION: LocationPick = {
  display_name: "New Delhi, India",
  lat: 28.6139,
  lon: 77.2090,
  timezone: "Asia/Kolkata",
};

function parseDDMMYYYY(s: string): Date | null {
  const parsed = parse(s, "dd-MM-yyyy", new Date());
  return isValid(parsed) ? parsed : null;
}

function PanchangInner() {
  const { t } = useTranslation("panchang");
  const { lang } = useLanguage();
  const { user } = useAuth();
  const navigate = useNavigate();
  const { charts } = useBirthCharts();
  const primaryChart = charts[0];

  // Role-aware back destination
  const [isAstro, setIsAstro] = useState(false);
  useEffect(() => {
    if (!user) { setIsAstro(false); return; }
    let cancelled = false;
    supabase
      .from("astrologers")
      .select("id", { head: true, count: "exact" })
      .eq("user_id", user.id)
      .then(({ count }) => { if (!cancelled) setIsAstro((count ?? 0) > 0); });
    return () => { cancelled = true; };
  }, [user]);
  const backTo = isAstro ? "/astrologer/overview" : "/astrologers";

  const [date, setDate] = useState<Date>(new Date());
  const [dateText, setDateText] = useState<string>(format(new Date(), "dd-MM-yyyy"));
  const [calendarOpen, setCalendarOpen] = useState(false);
  const [chartStyle, setChartStyle] = useState<ChartStyle>("north");
  const [location, setLocation] = useState<LocationPick>(() => {
    if (primaryChart) {
      return {
        display_name: primaryChart.location_name,
        lat: Number(primaryChart.latitude),
        lon: Number(primaryChart.longitude),
        timezone: primaryChart.timezone,
      };
    }
    return DEFAULT_LOCATION;
  });

  useEffect(() => {
    setDateText(format(date, "dd-MM-yyyy"));
  }, [date]);

  const isoDate = useMemo(() => format(date, "yyyy-MM-dd"), [date]);

  // Switching to Hora preserves date + city via query string
  const horaHref = useMemo(() => {
    const params = new URLSearchParams({
      date: isoDate,
      lat: String(location.lat),
      lon: String(location.lon),
      tz: location.timezone,
      place: location.display_name,
    });
    return `/panchang/hora?${params.toString()}`;
  }, [isoDate, location]);

  const { data, isLoading, error } = usePanchang({
    date: isoDate,
    latitude: location.lat,
    longitude: location.lon,
    timezone: location.timezone,
  });

  const dayLine = useMemo(() => {
    const longDate = formatLongDate(isoDate, location.timezone, lang);
    return `${longDate} · ${t("panchang_for")} ${location.display_name}`;
  }, [isoDate, location, lang, t]);

  const onDateTextChange = (v: string) => {
    setDateText(v);
    const parsed = parseDDMMYYYY(v);
    if (parsed) setDate(parsed);
  };
  const onDateTextBlur = () => {
    const parsed = parseDDMMYYYY(dateText);
    if (!parsed) setDateText(format(date, "dd-MM-yyyy"));
  };

  return (
    <AppShell>
      <div className="container max-w-5xl py-4 md:py-6 space-y-5">
        {/* Top-level Panchang / Hora tabs (Hora navigates to /panchang/hora) */}
        <Tabs value="panchang" className="w-full">
          <div className="flex items-center gap-2">
            <Button
              type="button"
              size="icon"
              variant="ghost"
              aria-label="Back"
              className="shrink-0"
              onClick={() => navigate(backTo)}
            >
              <ArrowLeft className="h-5 w-5" />
            </Button>
            <TabsList className="grid grid-cols-2 flex-1 max-w-md bg-primary/10">
              <TabsTrigger
                value="panchang"
                className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground text-base font-semibold"
              >
                {t("tab_panchang")}
              </TabsTrigger>
              <TabsTrigger
                value="hora"
                className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground text-base font-semibold"
                onClick={() => navigate(horaHref)}
              >
                {t("tab_hora")}
              </TabsTrigger>
            </TabsList>
          </div>

          <TabsContent value="panchang" className="mt-4 space-y-5">
            <header className="space-y-1">
              <h1 className="text-2xl md:text-3xl font-bold flex items-center gap-2">
                <CalendarIcon className="h-6 w-6 text-primary" /> {t("page_title")}
              </h1>
              <p className="text-xs md:text-sm text-muted-foreground">
                {t("page_subtitle")}
              </p>
            </header>

            {/* Hero strip — date + city + nav */}
            <Card className="border-primary/30 bg-gradient-to-br from-card to-card/80 shadow-card">
              <CardContent className="pt-4 pb-4 space-y-3">
                <div className="flex flex-wrap items-center gap-2">
                  <div className="relative flex-1 min-w-[150px]">
                    <Input
                      value={dateText}
                      onChange={(e) => onDateTextChange(e.target.value)}
                      onBlur={onDateTextBlur}
                      placeholder={t("date_placeholder")}
                      className="pl-8 bg-background/60 border-primary/30 focus-visible:ring-primary tabular-nums"
                      inputMode="numeric"
                    />
                    <Popover open={calendarOpen} onOpenChange={setCalendarOpen}>
                      <PopoverTrigger asChild>
                        <button
                          type="button"
                          aria-label="Open calendar"
                          className="absolute left-2 top-1/2 -translate-y-1/2 text-primary hover:text-primary/80"
                        >
                          <CalendarIcon className="h-4 w-4" />
                        </button>
                      </PopoverTrigger>
                      <PopoverContent className="w-auto p-0" align="start">
                        <Calendar
                          mode="single"
                          selected={date}
                          onSelect={(d) => {
                            if (d) {
                              setDate(d);
                              setCalendarOpen(false);
                            }
                          }}
                          initialFocus
                          className={cn("p-3 pointer-events-auto")}
                        />
                      </PopoverContent>
                    </Popover>
                  </div>

                  <div className="flex-[2] min-w-[200px]">
                    <LocationAutocomplete
                      value={location}
                      onChange={(loc) => loc && setLocation(loc)}
                    />
                  </div>

                  <div className="flex items-center gap-1">
                    <Button
                      type="button"
                      size="icon"
                      variant="outline"
                      aria-label="Previous day"
                      className="border-primary/40 hover:bg-primary/10"
                      onClick={() => setDate((d) => subDays(d, 1))}
                    >
                      <ChevronLeft className="h-4 w-4" />
                    </Button>
                    <Button
                      type="button"
                      variant="default"
                      className="bg-gradient-to-r from-primary to-primary/80 text-primary-foreground font-semibold px-4"
                      onClick={() => setDate(new Date())}
                    >
                      {t("common:today", "TODAY")}
                    </Button>
                    <Button
                      type="button"
                      size="icon"
                      variant="outline"
                      aria-label="Next day"
                      className="border-primary/40 hover:bg-primary/10"
                      onClick={() => setDate((d) => addDays(d, 1))}
                    >
                      <ChevronRight className="h-4 w-4" />
                    </Button>
                  </div>
                </div>

                <div className="flex flex-wrap items-center justify-between gap-2 text-[12px]">
                  <p className="text-muted-foreground flex items-center gap-1.5">
                    <MapPin className="h-3 w-3 text-primary" />
                    <span className="font-medium text-foreground">{dayLine}</span>
                    <span className="text-muted-foreground">· {location.timezone}</span>
                  </p>
                  {data?.cached && (
                    <span className="inline-flex items-center gap-1 rounded-full bg-primary/15 px-2 py-0.5 text-[10px] font-medium text-primary">
                      {t("served_from_cache")}
                    </span>
                  )}
                </div>
              </CardContent>
            </Card>

            {/* Lagna chart + Planetary position sub-tabs */}
            <Card className="border-primary/20">
              <CardContent className="pt-4">
                {isLoading ? (
                  <div className="space-y-4">
                    <Skeleton className="h-8 w-48" />
                    <Skeleton className="aspect-square w-full max-w-md mx-auto" />
                  </div>
                ) : error ? (
                  <Alert variant="destructive">
                    <AlertDescription>
                      {t("could_not_load")} {error instanceof Error ? error.message : ""}
                    </AlertDescription>
                  </Alert>
                ) : data?.ascendant && data?.planets ? (
                  <Tabs defaultValue="lagna">
                    <TabsList className="grid grid-cols-2 max-w-md mx-auto bg-primary/10">
                      <TabsTrigger value="lagna" className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground">
                        {t("tab_lagna")}
                      </TabsTrigger>
                      <TabsTrigger value="positions" className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground">
                        {t("tab_positions")}
                      </TabsTrigger>
                    </TabsList>

                    <TabsContent value="lagna" className="mt-5">
                      <h2 className="text-center text-sm md:text-base font-normal mb-3 text-foreground">
                        {t("lagna_at_sunrise")}
                      </h2>
                      <div className="max-w-md mx-auto">
                        <LagnaSunriseChart
                          ascendant={data.ascendant}
                          planets={data.planets}
                          lang={lang}
                          style={chartStyle}
                        />
                      </div>
                      {/* North / South / East selector — orange-pill, North default */}
                      <div className="mt-4 flex justify-center">
                        <div className="inline-flex rounded-full border border-primary/40 bg-primary/5 p-0.5">
                          {(["north", "south", "east"] as const).map((s) => (
                            <button
                              key={s}
                              type="button"
                              onClick={() => setChartStyle(s)}
                              className={cn(
                                "px-4 py-1 text-xs md:text-sm font-medium rounded-full transition-colors capitalize",
                                chartStyle === s
                                  ? "bg-primary text-primary-foreground shadow-sm"
                                  : "text-foreground/70 hover:text-foreground",
                              )}
                              aria-pressed={chartStyle === s}
                            >
                              {t(`chart_style_${s}`, s.charAt(0).toUpperCase() + s.slice(1))}
                            </button>
                          ))}
                        </div>
                      </div>
                    </TabsContent>

                    <TabsContent value="positions" className="mt-5">
                      <h2 className="text-center text-base md:text-lg font-semibold mb-3 text-primary">
                        {t("positions_at_sunrise")}
                      </h2>
                      <PlanetaryPositionTable planets={data.planets} lang={lang} />
                    </TabsContent>
                  </Tabs>
                ) : (
                  <Alert>
                    <AlertDescription>
                      {t("computing")} <Loader2 className="inline h-3 w-3 animate-spin" />
                    </AlertDescription>
                  </Alert>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </AppShell>
  );
}

export default function Panchang() {
  return (
    <ErrorBoundary>
      <PanchangInner />
    </ErrorBoundary>
  );
}
