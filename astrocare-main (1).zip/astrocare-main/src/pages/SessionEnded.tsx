/**
 * Standalone /chat/endsession page (FIX 7).
 * Reuses the existing SessionEndedScreen component but wraps it in its own
 * route so the URL is clean and there's no risk of being stuck behind the
 * active chat overlay.
 */
import { useEffect, useState } from "react";
import { useNavigate, useSearchParams } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { Loader2 } from "lucide-react";
import { SessionEndedScreen } from "@/components/chat/SessionEndedScreen";
import { useAuth } from "@/contexts/AuthContext";
import { ChatRequestModal } from "@/components/chat/ChatRequestModal";
import { GiftModal } from "@/components/chat/GiftModal";
import { CallConfirmationModal } from "@/components/calls/CallConfirmationModal";
import { useWallet } from "@/hooks/useWallet";
import { toast } from "sonner";

interface Loaded {
  session: {
    id: string;
    user_id: string;
    astrologer_id: string;
    duration_seconds: number;
    total_cost: number;
    ended_by: string | null;
    per_minute_rate: number;
  };
  astro: {
    id: string;
    slug: string | null;
    display_name: string;
    avatar_url: string | null;
    chat_rate_per_min: number;
    rating_avg: number;
    specializations: string[];
  };
}

function fmt(seconds: number) {
  const m = Math.floor(seconds / 60).toString().padStart(2, "0");
  const s = (seconds % 60).toString().padStart(2, "0");
  return `${m}:${s}`;
}

export default function ChatSessionEnded() {
  const [params] = useSearchParams();
  const sessionId = params.get("sessionId");
  const navigate = useNavigate();
  const { user } = useAuth();
  const { wallet } = useWallet();
  const [data, setData] = useState<Loaded | null>(null);
  const [loading, setLoading] = useState(true);
  const [chatOpen, setChatOpen] = useState(false);
  const [giftOpen, setGiftOpen] = useState(false);
  const [callOpen, setCallOpen] = useState(false);
  const [startingCall, setStartingCall] = useState(false);

  useEffect(() => {
    if (!sessionId) { setLoading(false); return; }
    let active = true;
    (async () => {
      const { data: s } = await supabase
        .from("chat_sessions")
        .select("id, user_id, astrologer_id, duration_seconds, total_cost, ended_by, per_minute_rate")
        .eq("id", sessionId)
        .maybeSingle();
      if (!s) { if (active) { setData(null); setLoading(false); } return; }
      const { data: a } = await supabase
        .from("astrologers")
        .select("id, slug, display_name, avatar_url, chat_rate_per_min, rating_avg, specializations")
        .eq("id", s.astrologer_id)
        .maybeSingle();
      if (!active) return;
      setData({
        session: s as any,
        astro: (a ?? { id: s.astrologer_id, slug: null, display_name: "Astrologer", avatar_url: null, chat_rate_per_min: 0, rating_avg: 0, specializations: [] }) as any,
      });
      setLoading(false);
    })();
    return () => { active = false; };
  }, [sessionId]);

  const startCall = async () => {
    if (!data) return;
    setStartingCall(true);
    const { data: res, error } = await supabase.functions.invoke("initiate-call", {
      body: { astrologer_id: data.astro.id },
    });
    setStartingCall(false);
    if (error || !res?.call_session_id) {
      const errBody = (error as { context?: { body?: unknown } } | null)?.context?.body;
      let parsed: { error?: string } = {};
      try { parsed = typeof errBody === "string" ? JSON.parse(errBody) : (errBody as typeof parsed) ?? {}; } catch { /* ignore */ }
      toast.error(parsed.error ?? "Could not start call");
      return;
    }
    setCallOpen(false);
    navigate(`/call/${res.call_session_id as string}`);
  };

  if (loading) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-[#0F0A1E] text-white">
        <Loader2 className="h-8 w-8 animate-spin text-amber-400" />
      </div>
    );
  }
  if (!data) {
    return (
      <div className="flex min-h-screen flex-col items-center justify-center gap-4 bg-[#0F0A1E] p-6 text-center text-white">
        <p>Session not found.</p>
        <button onClick={() => navigate("/astrologers")} className="rounded-full bg-amber-500 px-4 py-2 font-semibold text-black">
          Browse astrologers
        </button>
      </div>
    );
  }

  const { session, astro } = data;
  const isCustomer = user?.id === session.user_id;
  const endedByMe = (isCustomer && session.ended_by === "customer");
  const callRate = Number(astro.chat_rate_per_min ?? session.per_minute_rate);

  const back = () => {
    if (astro.slug) navigate(`/astrologer/${astro.slug}`);
    else navigate("/astrologers");
  };

  return (
    <>
      <SessionEndedScreen
        endedBy={session.ended_by}
        durationLabel={fmt(session.duration_seconds)}
        totalCost={Number(session.total_cost ?? 0)}
        isCurrentUserEnder={endedByMe}
        astrologerId={astro.id}
        astrologerSlug={astro.slug}
        astrologerName={astro.display_name}
        astrologerAvatar={astro.avatar_url}
        onBack={back}
        onChatAgain={() => setChatOpen(true)}
        onCallAgain={() => setCallOpen(true)}
        onSendGift={() => setGiftOpen(true)}
      />

      <ChatRequestModal
        open={chatOpen}
        onOpenChange={setChatOpen}
        astrologerId={astro.id}
        astrologerName={astro.display_name}
        astrologerAvatar={astro.avatar_url}
        astrologerSpecializations={astro.specializations ?? []}
        astrologerRating={Number(astro.rating_avg ?? 0)}
        ratePerMin={callRate}
      />

      <GiftModal
        open={giftOpen}
        onOpenChange={setGiftOpen}
        astrologerId={astro.id}
        astrologerName={astro.display_name}
      />

      <CallConfirmationModal
        open={callOpen}
        onClose={() => setCallOpen(false)}
        astrologer={{
          id: astro.id,
          slug: astro.slug ?? "",
          display_name: astro.display_name,
          avatar_url: astro.avatar_url,
          specializations: astro.specializations ?? [],
          rating_avg: Number(astro.rating_avg ?? 0),
          base_rate_per_min: callRate,
          discounted_rate_per_min: callRate,
        } as any}
        walletBalance={Number(wallet?.balance ?? 0)}
        userPhone={null}
        isStarting={startingCall}
        onConfirm={startCall}
      />
    </>
  );
}
