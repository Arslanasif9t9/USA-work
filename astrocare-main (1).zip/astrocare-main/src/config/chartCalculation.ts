/**
 * Chart calculation configuration — single source of truth for what astrology
 * standard AstroGuide uses to compute kundli/charts.
 *
 * IMPORTANT: astrologyapi.com's /planet_panchang endpoint (used by
 * supabase/functions/calculate-chart) returns SIDEREAL Lahiri longitudes by
 * default — there is no `ayanamsa` request parameter to set. Whole-sign houses
 * are derived client-side in calculate-chart from the ascendant longitude.
 *
 * If you ever switch providers, update both this file and the provider call.
 */

export const CHART_CALCULATION_CONFIG = {
  ayanamsa: "lahiri",
  houseSystem: "whole_sign", // Traditional Vedic
  ephemeris: "standard",
  calculationProvider: "astrologyapi.com",
  vedicAyanamsa: true,
} as const;

export const CHART_DISCLOSURE_TEXT = {
  en: "Calculated using Lahiri ayanamsa (Vedic Indian standard) · Whole-sign houses",
  hi: "लाहिरी अयनांश का उपयोग करके गणना की गई (भारतीय वैदिक मानक) · पूर्ण राशि भाव",
} as const;

export type CalculationLanguage = keyof typeof CHART_DISCLOSURE_TEXT;
