/**
 * Contact information for AstroGuide.
 * To activate WhatsApp support: replace WHATSAPP_NUMBER with real business number.
 * Format: country code + number, no spaces, no plus sign (e.g. "919876543210")
 */
export const CONTACT_CONFIG = {
  WHATSAPP_NUMBER: "919999999999", // PLACEHOLDER — replace with real number when ready
  WHATSAPP_ENABLED: true,           // set false to hide button until real number is ready
  EMAIL: "support@astroguide.com",  // replace with real support email
} as const;

export const WHATSAPP_URL = `https://wa.me/${CONTACT_CONFIG.WHATSAPP_NUMBER}`;
