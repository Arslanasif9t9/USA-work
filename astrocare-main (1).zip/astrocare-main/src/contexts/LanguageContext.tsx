// Global language provider. Wraps i18next so any component can:
//   const { lang, setLang } = useLanguage();
// Persists choice in localStorage immediately, and (when signed in) syncs to
// `profiles.language_preference` so the preference follows the user across
// devices.
import { createContext, useCallback, useContext, useEffect, useMemo, useState } from "react";
import { useTranslation } from "react-i18next";
import i18n, { SUPPORTED_LANGS, type SupportedLang } from "@/i18n";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";

interface LanguageContextValue {
  lang: SupportedLang;
  setLang: (next: SupportedLang) => void;
  toggle: () => void;
}

const LanguageContext = createContext<LanguageContextValue | undefined>(undefined);

const STORAGE_KEY = "appLang";

function readInitialLang(): SupportedLang {
  if (typeof window === "undefined") return "en";
  const stored = window.localStorage.getItem(STORAGE_KEY);
  if (stored === "en" || stored === "hi") return stored;
  // Detect Hindi browser
  const nav = window.navigator?.language ?? "en";
  return nav.toLowerCase().startsWith("hi") ? "hi" : "en";
}

export function LanguageProvider({ children }: { children: React.ReactNode }) {
  const [lang, setLangState] = useState<SupportedLang>(() => readInitialLang());
  const { user } = useAuth();
  // Keep i18next imported so it bootstraps; useTranslation forces this module to be loaded.
  useTranslation();

  // Apply on mount
  useEffect(() => {
    if (i18n.language !== lang) i18n.changeLanguage(lang);
    if (typeof document !== "undefined") {
      document.documentElement.lang = lang;
    }
  }, [lang]);

  // Hydrate from profile when user signs in
  useEffect(() => {
    if (!user) return;
    let cancelled = false;
    (async () => {
      const { data } = await (supabase as any)
        .from("profiles")
        .select("language_preference")
        .eq("id", user.id)
        .maybeSingle();
      if (cancelled) return;
      const remote = data?.language_preference;
      if ((remote === "en" || remote === "hi") && remote !== lang) {
        setLangState(remote);
        window.localStorage.setItem(STORAGE_KEY, remote);
      }
    })();
    return () => { cancelled = true; };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [user?.id]);

  const setLang = useCallback(
    (next: SupportedLang) => {
      if (!SUPPORTED_LANGS.includes(next)) return;
      setLangState(next);
      try {
        window.localStorage.setItem(STORAGE_KEY, next);
      } catch {
        /* ignore */
      }
      // Best-effort persist for signed-in user
      if (user) {
        (supabase as any)
          .from("profiles")
          .update({ language_preference: next })
          .eq("id", user.id)
          .then(() => {});
      }
    },
    [user],
  );

  const toggle = useCallback(() => {
    setLang(lang === "en" ? "hi" : "en");
  }, [lang, setLang]);

  const value = useMemo(() => ({ lang, setLang, toggle }), [lang, setLang, toggle]);

  return <LanguageContext.Provider value={value}>{children}</LanguageContext.Provider>;
}

export function useLanguage(): LanguageContextValue {
  const ctx = useContext(LanguageContext);
  if (!ctx) {
    // Fall back to a no-op so render doesn't crash if the provider is missing.
    return {
      lang: (typeof window !== "undefined" &&
        (window.localStorage.getItem(STORAGE_KEY) as SupportedLang)) || "en",
      setLang: () => {},
      toggle: () => {},
    };
  }
  return ctx;
}
