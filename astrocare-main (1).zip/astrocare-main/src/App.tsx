import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Navigate, Route, Routes } from "react-router-dom";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { AuthProvider } from "@/contexts/AuthContext";
import { LanguageProvider } from "@/contexts/LanguageContext";
import { AuthDialogProvider } from "@/components/auth/AuthDialog";
import "@/i18n";
import { AstrologerRoute, CustomerOnlyRoute } from "@/components/auth/AstrologerRoute";
import { AstrologerLayout } from "@/components/astrologer/AstrologerLayout";
import Index from "./pages/Index.tsx";
import Directory from "./pages/Directory.tsx";
import Astrologers from "./pages/Astrologers.tsx";
import AstrologerDetail from "./pages/AstrologerDetail.tsx";
import Profile from "./pages/Profile.tsx";
import Transactions from "./pages/Transactions.tsx";
import AuthCallback from "./pages/AuthCallback.tsx";
import SignIn from "./pages/SignIn.tsx";
import SignUp from "./pages/SignUp.tsx";
import ForgotPassword from "./pages/ForgotPassword.tsx";
import ResetPassword from "./pages/ResetPassword.tsx";
import RechargeSuccess from "./pages/RechargeSuccess.tsx";
import Chart from "./pages/Chart.tsx";
import ChartNew from "./pages/ChartNew.tsx";
import Panchang from "./pages/Panchang.tsx";
import PanchangHora from "./pages/PanchangHora.tsx";
import RechargeCancel from "./pages/RechargeCancel.tsx";
import NotFound from "./pages/NotFound.tsx";
import AstrologerLogin from "./pages/AstrologerLogin.tsx";
import AdminLogin from "./pages/admin/AdminLogin.tsx";
import AdminResetPassword from "./pages/admin/AdminResetPassword.tsx";
import AdminDashboard from "./pages/admin/AdminDashboard.tsx";
import AdminUsers from "./pages/admin/AdminUsers.tsx";
import AdminAstrologers from "./pages/admin/AdminAstrologers.tsx";
import AdminCustomers from "./pages/admin/AdminCustomers.tsx";
import AdminSessions from "./pages/admin/AdminSessions.tsx";
import AdminReviews from "./pages/admin/AdminReviews.tsx";
import AdminSupport from "./pages/admin/AdminSupport.tsx";
import AdminWithdrawals from "./pages/admin/AdminWithdrawals.tsx";
import AdminFinance from "./pages/admin/AdminFinance.tsx";
import AdminAnnouncements from "./pages/admin/AdminAnnouncements.tsx";
import AdminSettings from "./pages/admin/AdminSettings.tsx";
import AdminActivity from "./pages/admin/AdminActivity.tsx";
import AdminWalletRequests from "./pages/admin/AdminWalletRequests.tsx";
import Blocked from "./pages/Blocked.tsx";
import { AdminAuthProvider } from "@/admin/AdminAuthContext";
import { AdminProtectedRoute } from "@/admin/AdminProtectedRoute";
import { AdminLayout } from "@/admin/AdminLayout";
import Favorites from "./pages/Favorites.tsx";
import Chat from "./pages/Chat.tsx";
import History from "./pages/History.tsx";
import Wallet from "./pages/Wallet.tsx";
import Horoscope from "./pages/Horoscope.tsx";
import Notifications from "./pages/Notifications.tsx";
// Astrologer dashboard pages
import AstroOverview from "./pages/astrologer/Overview.tsx";
import AstroSessions from "./pages/astrologer/Sessions.tsx";
import AstroEarnings from "./pages/astrologer/Earnings.tsx";
import AstroReviews from "./pages/astrologer/Reviews.tsx";
import AstroProfile from "./pages/astrologer/Profile.tsx";
import AstroSettings from "./pages/astrologer/Settings.tsx";
import AstroSupport from "./pages/astrologer/Support.tsx";
import AstroHistory from "./pages/astrologer/History.tsx";
import AstroNotifications from "./pages/astrologer/Notifications.tsx";
import AstroTransactions from "./pages/astrologer/Transactions.tsx";
import { GlobalAstrologerNotifier } from "@/components/notifications/GlobalAstrologerNotifier";
import { ActiveSessionFAB } from "@/components/session/ActiveSessionFAB";
import Support from "./pages/Support.tsx";
import AstroGifts from "./pages/astrologer/Gifts.tsx";
import ChatSessionEnded from "./pages/SessionEnded.tsx";
import AstrologerChatSessionEnded from "./pages/astrologer/SessionEnded.tsx";
import CallSession from "./pages/CallSession.tsx";
import CallSessionEnded from "./pages/CallSessionEnded.tsx";
import AstrologerCallSessionEnded from "./pages/astrologer/CallSessionEnded.tsx";
import Legal from "./pages/Legal.tsx";
import LiveFeed from "./pages/LiveFeed.tsx";
import AstroLive from "./pages/astrologer/AstroLive.tsx";
import AdminAstroLive from "./pages/admin/AdminAstroLive.tsx";
import { MobileBottomNav } from "@/components/layout/MobileBottomNav";
import { WhatsAppFAB } from "@/components/support/WhatsAppFAB";
import { ScrollToTopButton } from "@/components/layout/ScrollToTopButton";

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      // FIX 3: stop reload on window refocus across the entire app
      refetchOnWindowFocus: false,
      refetchOnReconnect: false,
      staleTime: 5 * 60 * 1000, // 5 minutes
    },
  },
});

const AstroShell = ({ children }: { children: React.ReactNode }) => (
  <AstrologerRoute>
    <AstrologerLayout>{children}</AstrologerLayout>
  </AstrologerRoute>
);

const AdminShell = ({
  children, permission, masterOnly,
}: {
  children: React.ReactNode;
  permission?: Parameters<typeof AdminProtectedRoute>[0]["permission"];
  masterOnly?: boolean;
}) => (
  <AdminProtectedRoute permission={permission} masterOnly={masterOnly}>
    <AdminLayout>{children}</AdminLayout>
  </AdminProtectedRoute>
);

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <Toaster />
      <Sonner />
      <BrowserRouter>
        <AuthProvider>
          <LanguageProvider>
          <AdminAuthProvider>
          <AuthDialogProvider>
            <GlobalAstrologerNotifier />
            <ActiveSessionFAB />
            <MobileBottomNav />
            <WhatsAppFAB />
            <ScrollToTopButton />
            <Routes>
              <Route path="/" element={<CustomerOnlyRoute><Index /></CustomerOnlyRoute>} />
              <Route path="/auth/callback" element={<AuthCallback />} />
              <Route path="/sign-in" element={<SignIn />} />
              <Route path="/sign-up" element={<SignUp />} />
              <Route path="/forgot-password" element={<ForgotPassword />} />
              <Route path="/reset-password" element={<ResetPassword />} />
              <Route path="/dashboard" element={<Navigate to="/history" replace />} />
              <Route path="/astrologer-dashboard" element={<Navigate to="/astrologer/overview" replace />} />

              {/* Customer-facing routes */}
              <Route path="/directory" element={<CustomerOnlyRoute><Directory /></CustomerOnlyRoute>} />
              <Route path="/astrologers" element={<CustomerOnlyRoute><Astrologers /></CustomerOnlyRoute>} />
              <Route path="/astrologer/:slug" element={<CustomerOnlyRoute><AstrologerDetail /></CustomerOnlyRoute>} />
              <Route path="/profile" element={<CustomerOnlyRoute><Profile /></CustomerOnlyRoute>} />
              <Route path="/history" element={<CustomerOnlyRoute><History /></CustomerOnlyRoute>} />
              <Route path="/wallet" element={<CustomerOnlyRoute><Wallet /></CustomerOnlyRoute>} />
              <Route path="/transactions" element={<CustomerOnlyRoute><Transactions /></CustomerOnlyRoute>} />
              <Route path="/horoscope" element={<Horoscope />} />
              <Route path="/notifications" element={<CustomerOnlyRoute><Notifications /></CustomerOnlyRoute>} />
              <Route path="/recharge/success" element={<RechargeSuccess />} />
              <Route path="/recharge/cancel" element={<RechargeCancel />} />
              <Route path="/chart/new" element={<CustomerOnlyRoute><ChartNew /></CustomerOnlyRoute>} />
              <Route path="/chart" element={<Navigate to="/chart/new" replace />} />
              <Route path="/kundli" element={<Navigate to="/chart/new" replace />} />
              <Route path="/chart/:id" element={<CustomerOnlyRoute><Chart /></CustomerOnlyRoute>} />
              <Route path="/panchang" element={<CustomerOnlyRoute><Panchang /></CustomerOnlyRoute>} />
              <Route path="/panchang/hora" element={<CustomerOnlyRoute><PanchangHora /></CustomerOnlyRoute>} />
              <Route path="/favorites" element={<CustomerOnlyRoute><Favorites /></CustomerOnlyRoute>} />
              <Route path="/live" element={<CustomerOnlyRoute><LiveFeed /></CustomerOnlyRoute>} />
              <Route path="/support" element={<CustomerOnlyRoute><Support /></CustomerOnlyRoute>} />
              <Route path="/chat/endsession" element={<ChatSessionEnded />} />
              <Route path="/astrologer/chat/endsession" element={<AstrologerChatSessionEnded />} />
              <Route path="/call/endsession" element={<CallSessionEnded />} />
              <Route path="/astrologer/call/endsession" element={<AstrologerCallSessionEnded />} />
              <Route path="/chat/:id" element={<Chat />} />
              {/* Astrologer-side chat URL — same component, different URL pattern */}
              <Route path="/astrologer/chat/:id" element={<Chat />} />
              <Route path="/call/:id" element={<CallSession />} />
              <Route path="/astrologer/call/:id" element={<CallSession />} />

              {/* Auth entry points */}
              <Route path="/astrologer/login" element={<AstrologerLogin />} />
              <Route path="/astrocareadmin/login" element={<AdminLogin />} />
              <Route path="/astrocareadmin/reset-password" element={<AdminResetPassword />} />
              <Route path="/blocked" element={<Blocked />} />

              {/* Astrologer dashboard */}
              <Route path="/astrologer" element={<Navigate to="/astrologer/overview" replace />} />
              <Route path="/astrologer/overview" element={<AstroShell><AstroOverview /></AstroShell>} />
              <Route path="/astrologer/sessions" element={<AstroShell><AstroSessions /></AstroShell>} />
              <Route path="/astrologer/history" element={<AstroShell><AstroHistory /></AstroShell>} />
              <Route path="/astrologer/earnings" element={<AstroShell><AstroEarnings /></AstroShell>} />
              <Route path="/astrologer/transactions" element={<AstroShell><AstroTransactions /></AstroShell>} />
              <Route path="/astrologer/notifications" element={<AstroShell><AstroNotifications /></AstroShell>} />
              <Route path="/astrologer/schedule" element={<Navigate to="/astrologer/overview" replace />} />
              <Route path="/astrologer/reviews" element={<AstroShell><AstroReviews /></AstroShell>} />
              <Route path="/astrologer/profile" element={<AstroShell><AstroProfile /></AstroShell>} />
              {/* Astrologer self-preview: render the public detail page outside the dashboard shell so astrologers see exactly what customers see */}
              <Route path="/astrologer/preview/:slug" element={<AstrologerDetail />} />
              <Route path="/astrologer/settings" element={<AstroShell><AstroSettings /></AstroShell>} />
              <Route path="/astrologer/support" element={<AstroShell><AstroSupport /></AstroShell>} />
              <Route path="/astrologer/gifts" element={<AstroShell><AstroGifts /></AstroShell>} />
              <Route path="/astrologer/live" element={<AstroShell><AstroLive /></AstroShell>} />

              {/* Admin panel */}
              <Route path="/astrocareadmin" element={<Navigate to="/astrocareadmin/dashboard" replace />} />
              <Route path="/astrocareadmin/dashboard"     element={<AdminShell><AdminDashboard /></AdminShell>} />
              <Route path="/astrocareadmin/astrologers"   element={<AdminShell permission="manage_astrologers"><AdminAstrologers /></AdminShell>} />
              <Route path="/astrocareadmin/customers"     element={<AdminShell permission="manage_customers"><AdminCustomers /></AdminShell>} />
              <Route path="/astrocareadmin/sessions"      element={<AdminShell permission="manage_sessions"><AdminSessions /></AdminShell>} />
              <Route path="/astrocareadmin/finance"       element={<AdminShell permission="view_reports"><AdminFinance /></AdminShell>} />
              <Route path="/astrocareadmin/withdrawals"   element={<AdminShell permission="manage_withdrawals"><AdminWithdrawals /></AdminShell>} />
              <Route path="/astrocareadmin/wallet-requests" element={<AdminShell><AdminWalletRequests /></AdminShell>} />
              <Route path="/astrocareadmin/reviews"       element={<AdminShell permission="manage_reviews"><AdminReviews /></AdminShell>} />
              <Route path="/astrocareadmin/support"       element={<AdminShell permission="manage_support"><AdminSupport /></AdminShell>} />
              <Route path="/astrocareadmin/announcements" element={<AdminShell permission="manage_content"><AdminAnnouncements /></AdminShell>} />
              <Route path="/astrocareadmin/admins"        element={<AdminShell masterOnly><AdminUsers /></AdminShell>} />
              <Route path="/astrocareadmin/activity"      element={<AdminShell><AdminActivity /></AdminShell>} />
              <Route path="/astrocareadmin/settings"      element={<AdminShell><AdminSettings /></AdminShell>} />
              <Route path="/astrocareadmin/astrolive"     element={<AdminShell permission="manage_content"><AdminAstroLive /></AdminShell>} />

              {/* Public legal / info pages */}
              <Route path="/terms" element={<Legal />} />
              <Route path="/privacy" element={<Legal />} />
              <Route path="/refund" element={<Legal />} />
              <Route path="/about" element={<Legal />} />
              <Route path="/contact" element={<Legal />} />
              <Route path="/faq" element={<Legal />} />

              {/* ADD ALL CUSTOM ROUTES ABOVE THE CATCH-ALL "*" ROUTE */}
              <Route path="*" element={<NotFound />} />
            </Routes>
          </AuthDialogProvider>
          </AdminAuthProvider>
          </LanguageProvider>
        </AuthProvider>
      </BrowserRouter>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;
