import { useCallback } from "react";
import {
  EmbeddedCheckoutProvider,
  EmbeddedCheckout,
} from "@stripe/react-stripe-js";
import { getStripe, stripeEnvironment } from "@/lib/stripe";
import { supabase } from "@/integrations/supabase/client";

interface Props {
  /** Stripe price id (e.g. "recharge_500_inr") for a fixed pack */
  priceId?: string;
  /** Custom INR amount (rupees) for the legacy custom recharge flow */
  amount?: number;
  returnUrl?: string;
}

export function StripeEmbeddedCheckout({ priceId, amount, returnUrl }: Props) {
  const fetchClientSecret = useCallback(async (): Promise<string> => {
    const { data, error } = await supabase.functions.invoke(
      "create-checkout-session",
      {
        body: {
          priceId,
          amount,
          returnUrl,
          environment: stripeEnvironment,
        },
      }
    );
    if (error) throw new Error(error.message);
    if (!data?.clientSecret) throw new Error("No client secret returned");
    return data.clientSecret;
  }, [priceId, amount, returnUrl]);

  return (
    <div id="checkout" className="min-h-[480px]">
      <EmbeddedCheckoutProvider
        stripe={getStripe()}
        options={{ fetchClientSecret }}
      >
        <EmbeddedCheckout />
      </EmbeddedCheckoutProvider>
    </div>
  );
}
