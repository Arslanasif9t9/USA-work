import { useState } from "react";
import { useWallet, formatINR } from "@/hooks/useWallet";
import { RechargeModal } from "./RechargeModal";
import { Button } from "@/components/ui/button";
import { AlertTriangle, X } from "lucide-react";

const LOW_BALANCE_THRESHOLD = 50;

export function LowBalanceAlert() {
  const { wallet, loading } = useWallet();
  const [dismissed, setDismissed] = useState(false);
  const [recharge, setRecharge] = useState(false);

  if (loading || !wallet || dismissed) return null;
  if (wallet.balance >= LOW_BALANCE_THRESHOLD) return null;

  return (
    <>
      <div className="bg-warning/95 text-warning-foreground border-b border-warning/40">
        <div className="container flex items-center justify-between gap-3 py-2 text-sm">
          <div className="flex items-center gap-2 min-w-0">
            <AlertTriangle className="h-4 w-4 flex-shrink-0" />
            <p className="truncate font-medium">
              Low balance: {formatINR(wallet.balance)}. Top up to continue consultations.
            </p>
          </div>
          <div className="flex items-center gap-2 flex-shrink-0">
            <Button
              size="sm"
              variant="default"
              className="h-7 text-xs"
              onClick={() => setRecharge(true)}
            >
              Recharge Now
            </Button>
            <button
              onClick={() => setDismissed(true)}
              aria-label="Dismiss"
              className="p-1 rounded hover:bg-black/10 transition-colors"
            >
              <X className="h-4 w-4" />
            </button>
          </div>
        </div>
      </div>
      <RechargeModal open={recharge} onOpenChange={setRecharge} />
    </>
  );
}
