import { useState } from "react";
import { Button } from "@/components/ui/button";
import { useWallet, formatINR } from "@/hooks/useWallet";
import { RechargeModal } from "./RechargeModal";
import { IndianRupee } from "lucide-react";

export function WalletWidget() {
  const { wallet, loading } = useWallet();
  const [open, setOpen] = useState(false);

  return (
    <>
      <div className="flex items-center gap-2 bg-white/15 backdrop-blur-sm rounded-md px-3 py-1.5 border border-white/20">
        <span className="flex h-6 w-6 items-center justify-center rounded-full bg-secondary text-secondary-foreground">
          <IndianRupee className="h-3.5 w-3.5" strokeWidth={3} />
        </span>
        <span className="text-sm font-semibold tabular-nums text-header-foreground">
          {loading ? "…" : formatINR(wallet?.balance ?? 0)}
        </span>
        <Button
          size="sm"
          variant="gold"
          className="h-7 px-3 text-xs"
          onClick={() => setOpen(true)}
        >
          Recharge
        </Button>
      </div>
      <RechargeModal open={open} onOpenChange={setOpen} />
    </>
  );
}
