import { useEffect, useState } from "react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { ArrowLeft, Loader2, Sparkles } from "lucide-react";
import { StripeEmbeddedCheckout } from "@/components/payments/StripeEmbeddedCheckout";
import { usePlatformSettings } from "@/hooks/usePlatformSettings";
import { useWallet } from "@/hooks/useWallet";
import { useTranslation } from "react-i18next";

interface PackDef {
  price_id: string;
  product_id: string;
  pack_type: "wallet_recharge" | "consultation_pack";
  paid_amount: number;
  credit_amount: number;
  minutes_amount: number | null;
  display_name: string;
  description: string | null;
  sort_order: number;
}

interface RechargeModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  /** Kept for backward compatibility — no longer used (single combined view). */
  defaultTab?: "recharge" | "custom";
}

type CheckoutTarget =
  | { kind: "pack"; priceId: string; label: string }
  | { kind: "custom"; amount: number };

export function RechargeModal({
  open,
  onOpenChange,
}: RechargeModalProps) {
  const { toast } = useToast();
  const { t } = useTranslation("common");
  const { t: tToast } = useTranslation("toasts");
  const settings = usePlatformSettings();
  const { wallet } = useWallet();
  const [packs, setPacks] = useState<PackDef[]>([]);
  const [packsLoading, setPacksLoading] = useState(true);
  const [custom, setCustom] = useState("");
  const [target, setTarget] = useState<CheckoutTarget | null>(null);

  const minRecharge = settings?.min_recharge_amount ?? 10;
  const maxWalletBalance = settings?.max_wallet_balance ?? 100000;
  const currentBalance = Number(wallet?.balance ?? 0);
  const remainingHeadroom = Math.max(0, maxWalletBalance - currentBalance);
  const customMax = Math.min(100000, remainingHeadroom || 100000);

  useEffect(() => {
    if (!open) {
      setTarget(null);
      setCustom("");
    }
  }, [open]);

  useEffect(() => {
    if (!open) return;
    setPacksLoading(true);
    supabase
      .from("pack_definitions")
      .select(
        "price_id, product_id, pack_type, paid_amount, credit_amount, minutes_amount, display_name, description, sort_order"
      )
      .eq("active", true)
      .order("sort_order")
      .then(({ data, error }) => {
        if (error) {
          toast({
            title: tToast("error.load_packs"),
            description: error.message,
            variant: "destructive",
          });
        } else {
          setPacks(
            (data ?? []).map((p) => ({
              ...p,
              pack_type: p.pack_type as PackDef["pack_type"],
              paid_amount: Number(p.paid_amount),
              credit_amount: Number(p.credit_amount),
            }))
          );
        }
        setPacksLoading(false);
      });
  }, [open, toast, tToast]);

  const walletPacks = packs.filter((p) => p.pack_type === "wallet_recharge");

  const customAmount = Number(custom);
  const customValid =
    Number.isFinite(customAmount) &&
    customAmount >= minRecharge &&
    customAmount <= customMax;

  const tryPickPack = (priceId: string, label: string, credit: number) => {
    if (currentBalance + credit > maxWalletBalance) {
      toast({
        title: t("wallet.wallet_limit_reached"),
        description: t("wallet.wallet_limit_msg", {
          max: maxWalletBalance.toLocaleString("en-IN"),
          available: remainingHeadroom.toLocaleString("en-IN"),
        }),
        variant: "destructive",
      });
      return;
    }
    setTarget({ kind: "pack", priceId, label });
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-2xl max-h-[90vh] overflow-y-auto">
        {target ? (
          <>
            <DialogHeader>
              <button
                type="button"
                onClick={() => setTarget(null)}
                className="flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground w-fit"
              >
                <ArrowLeft className="h-4 w-4" /> {t("wallet.choose_different")}
              </button>
              <DialogTitle>
                {target.kind === "pack"
                  ? target.label
                  : t("wallet.recharge_amount", { amount: target.amount.toLocaleString("en-IN") })}
              </DialogTitle>
              <DialogDescription>
                {t("wallet.complete_payment")}
              </DialogDescription>
            </DialogHeader>
            <StripeEmbeddedCheckout
              priceId={target.kind === "pack" ? target.priceId : undefined}
              amount={target.kind === "custom" ? target.amount : undefined}
            />
          </>
        ) : (
          <>
            <DialogHeader>
              <DialogTitle>{t("wallet.top_up")}</DialogTitle>
              <DialogDescription>
                {t("wallet.use_for")}
              </DialogDescription>
            </DialogHeader>

            <div className="space-y-6 pt-2">
              {/* Recharge packs */}
              <section className="space-y-3">
                <div className="flex items-baseline justify-between">
                  <h3 className="text-sm font-semibold uppercase tracking-wider text-muted-foreground">
                    {t("wallet.recharge_packs")}
                  </h3>
                  <span className="text-[11px] text-muted-foreground">
                    {t("wallet.bonus_included")}
                  </span>
                </div>
                {packsLoading ? (
                  <Loading />
                ) : walletPacks.length === 0 ? (
                  <Empty label={t("wallet.no_packs")} />
                ) : (
                  <div className="grid gap-3 sm:grid-cols-2">
                    {walletPacks.map((pack) => {
                      const bonus = pack.credit_amount - pack.paid_amount;
                      return (
                        <button
                          key={pack.price_id}
                          type="button"
                          onClick={() =>
                            tryPickPack(
                              pack.price_id,
                              t("wallet.pay_get", {
                                paid: pack.paid_amount.toLocaleString("en-IN"),
                                credit: pack.credit_amount.toLocaleString("en-IN"),
                              }),
                              pack.credit_amount,
                            )
                          }
                          className="text-left rounded-lg border-2 border-border bg-card p-4 transition-all hover:border-primary hover:shadow-md group relative"
                        >
                          {bonus > 0 && (
                            <span className="absolute -top-2 -right-2 rounded-full bg-primary px-2 py-0.5 text-[10px] font-bold uppercase text-primary-foreground shadow-sm flex items-center gap-1">
                              <Sparkles className="h-3 w-3" />
                              {t("wallet.save_amount", { amount: bonus.toLocaleString("en-IN") })}
                            </span>
                          )}
                          <div className="text-xs font-medium uppercase tracking-wider text-muted-foreground">
                            {pack.display_name}
                          </div>
                          <div className="mt-1 text-2xl font-bold text-foreground">
                            {t("wallet.pay", { amount: pack.paid_amount.toLocaleString("en-IN") })}
                          </div>
                          <div className="mt-1 text-sm text-muted-foreground">
                            {t("wallet.get")}{" "}
                            <span className="font-semibold text-success">
                              ₹{pack.credit_amount.toLocaleString("en-IN")}
                            </span>{" "}
                            {t("wallet.in_wallet")}
                          </div>
                        </button>
                      );
                    })}
                  </div>
                )}
              </section>

              {/* Divider */}
              <div className="relative">
                <div className="absolute inset-0 flex items-center">
                  <span className="w-full border-t border-border" />
                </div>
                <div className="relative flex justify-center text-xs uppercase">
                  <span className="bg-background px-2 text-muted-foreground">{t("common.or")}</span>
                </div>
              </div>

              {/* Custom amount */}
              <section className="space-y-3">
                <h3 className="text-sm font-semibold uppercase tracking-wider text-muted-foreground">
                  {t("wallet.custom_amount")}
                </h3>
                <div className="space-y-2">
                  <Label htmlFor="custom-amount" className="text-sm">
                    {t("wallet.enter_amount", {
                      min: `₹${minRecharge.toLocaleString("en-IN")}`,
                      max: `₹${customMax.toLocaleString("en-IN")}`,
                    })}
                  </Label>
                  <Input
                    id="custom-amount"
                    type="number"
                    inputMode="numeric"
                    min={minRecharge}
                    max={customMax}
                    placeholder={`e.g. ${Math.max(minRecharge, 750)}`}
                    value={custom}
                    onChange={(e) => setCustom(e.target.value)}
                  />
                  <p className="text-xs text-muted-foreground">
                    {t("wallet.custom_no_bonus")}
                    {remainingHeadroom < 100000 && ` ${t("wallet.wallet_cap", { cap: maxWalletBalance.toLocaleString("en-IN") })}`}
                  </p>
                </div>
                <Button
                  variant="saffron"
                  size="lg"
                  className="w-full"
                  disabled={!customValid}
                  onClick={() =>
                    setTarget({ kind: "custom", amount: customAmount })
                  }
                >
                  {t("wallet.continue_payment")}
                  {customValid &&
                    ` — ₹${customAmount.toLocaleString("en-IN")}`}
                </Button>
              </section>
            </div>
          </>
        )}
      </DialogContent>
    </Dialog>
  );
}

function Loading() {
  return (
    <div className="flex justify-center py-10 text-muted-foreground">
      <Loader2 className="h-5 w-5 animate-spin" />
    </div>
  );
}
function Empty({ label }: { label: string }) {
  return (
    <div className="text-center py-10 text-sm text-muted-foreground">
      {label}
    </div>
  );
}
