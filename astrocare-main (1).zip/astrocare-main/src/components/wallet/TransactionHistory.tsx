import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { formatINR } from "@/hooks/useWallet";
import { format } from "date-fns";
import { Button } from "@/components/ui/button";
import { ChevronLeft, ChevronRight, ArrowDownCircle, ArrowUpCircle, RefreshCw } from "lucide-react";
import { useTranslation } from "react-i18next";

type TxType =
  | "top_up"
  | "consultation_debit"
  | "refund"
  | "consultation_credit"
  | "consultation_minute_spend";

interface Transaction {
  id: string;
  type: TxType;
  amount: number;
  description: string;
  balance_after: number;
  created_at: string;
}

const PAGE_SIZE = 20;

export function TransactionHistory() {
  const { user } = useAuth();
  const { t } = useTranslation("common");
  const [txs, setTxs] = useState<Transaction[]>([]);
  const [page, setPage] = useState(0);
  const [total, setTotal] = useState(0);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!user) return;
    let cancelled = false;
    (async () => {
      setLoading(true);
      const { data: wallet } = await supabase
        .from("wallets")
        .select("id")
        .eq("user_id", user.id)
        .maybeSingle();
      if (!wallet) {
        if (!cancelled) {
          setTxs([]);
          setTotal(0);
          setLoading(false);
        }
        return;
      }
      const from = page * PAGE_SIZE;
      const to = from + PAGE_SIZE - 1;
      const { data, count } = await supabase
        .from("transactions")
        .select("id, type, amount, description, balance_after, created_at", { count: "exact" })
        .eq("wallet_id", wallet.id)
        .order("created_at", { ascending: false })
        .range(from, to);
      if (!cancelled) {
        setTxs(
          (data ?? []).map((t) => ({
            ...t,
            amount: Number(t.amount),
            balance_after: Number(t.balance_after),
          })) as Transaction[]
        );
        setTotal(count ?? 0);
        setLoading(false);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [user, page]);

  const totalPages = Math.max(1, Math.ceil(total / PAGE_SIZE));

  // Translate the transaction description: prefer a translated tx_type label
  // when our enum recognises the transaction; otherwise fall back to the raw
  // backend-provided description (e.g. session-specific wording).
  const describe = (tx: Transaction) => {
    const key = `wallet.tx_type.${tx.type}`;
    const localized = t(key);
    // If the key resolved (i.e. did not return the path itself), use it.
    return localized && localized !== key ? localized : tx.description;
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center py-16 text-muted-foreground">
        <RefreshCw className="h-5 w-5 animate-spin mr-2" /> {t("wallet.loading_transactions")}
      </div>
    );
  }

  if (txs.length === 0) {
    return (
      <div className="text-center py-16 bg-section rounded-lg border border-border">
        <p className="text-muted-foreground">{t("wallet.no_transactions")}</p>
        <p className="text-sm text-muted-foreground mt-1">
          {t("wallet.recharge_to_start")}
        </p>
      </div>
    );
  }

  const renderRows = () =>
    txs.map((tx) => {
      const isCredit =
        tx.type === "top_up" ||
        tx.type === "refund" ||
        tx.type === "consultation_credit";
      const isMinuteTx =
        tx.type === "consultation_credit" ||
        tx.type === "consultation_minute_spend";
      const formattedAmount = isMinuteTx ? `${tx.amount} ${t("wallet.minutes_short")}` : formatINR(tx.amount);
      return { tx, isCredit, isMinuteTx, formattedAmount, label: describe(tx) };
    });

  const items = renderRows();

  return (
    <div className="space-y-4">
      {/* Mobile card list */}
      <ul className="sm:hidden divide-y divide-border overflow-hidden rounded-2xl border border-border bg-card shadow-card">
        {items.map(({ tx, isCredit, isMinuteTx, formattedAmount, label }) => (
          <li key={tx.id} className="flex items-center gap-3 px-4 py-3">
            <div
              className={`shrink-0 h-10 w-10 rounded-full flex items-center justify-center ${
                isCredit ? "bg-success/15 text-success" : "bg-destructive/15 text-destructive"
              }`}
            >
              {isCredit ? <ArrowDownCircle className="h-5 w-5" /> : <ArrowUpCircle className="h-5 w-5" />}
            </div>
            <div className="min-w-0 flex-1">
              <p className="truncate text-sm font-medium text-foreground">{label}</p>
              <p className="mt-0.5 text-[11px] text-muted-foreground tabular-nums">
                {format(new Date(tx.created_at), "dd MMM, HH:mm")}
                {!isMinuteTx && <> · {t("wallet.balance")} {formatINR(tx.balance_after)}</>}
              </p>
            </div>
            <div
              className={`shrink-0 text-right text-sm font-semibold tabular-nums ${
                isCredit ? "text-success" : "text-destructive"
              }`}
            >
              {isCredit ? "+" : "−"}
              {formattedAmount}
            </div>
          </li>
        ))}
      </ul>

      {/* Desktop table */}
      <div className="hidden sm:block overflow-hidden rounded-lg border border-border bg-card shadow-card">
        <table className="w-full text-sm">
          <thead>
            <tr className="bg-section text-muted-foreground">
              <th className="text-left px-4 py-3 font-medium">{t("wallet.date")}</th>
              <th className="text-left px-4 py-3 font-medium">{t("wallet.description")}</th>
              <th className="text-right px-4 py-3 font-medium">{t("wallet.amount")}</th>
              <th className="text-right px-4 py-3 font-medium">{t("wallet.balance")}</th>
            </tr>
          </thead>
          <tbody>
            {items.map(({ tx, isCredit, isMinuteTx, formattedAmount, label }) => (
              <tr key={tx.id} className="border-t border-border hover:bg-section/50 transition-colors">
                <td className="px-4 py-3 text-muted-foreground tabular-nums whitespace-nowrap">
                  {format(new Date(tx.created_at), "dd MMM yyyy, HH:mm")}
                </td>
                <td className="px-4 py-3">
                  <div className="flex items-center gap-2">
                    {isCredit ? (
                      <ArrowDownCircle className="h-4 w-4 text-success flex-shrink-0" />
                    ) : (
                      <ArrowUpCircle className="h-4 w-4 text-destructive flex-shrink-0" />
                    )}
                    <span>{label}</span>
                  </div>
                </td>
                <td
                  className={`px-4 py-3 text-right tabular-nums font-semibold ${
                    isCredit ? "text-success" : "text-destructive"
                  }`}
                >
                  {isCredit ? "+" : "−"}
                  {formattedAmount}
                </td>
                <td className="px-4 py-3 text-right tabular-nums text-muted-foreground">
                  {isMinuteTx ? "—" : formatINR(tx.balance_after)}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {totalPages > 1 && (
        <div className="flex items-center justify-between gap-2">
          <p className="text-xs sm:text-sm text-muted-foreground">
            {t("wallet.page_of", { page: page + 1, total: totalPages, count: total })}
          </p>
          <div className="flex gap-2">
            <Button
              variant="outline"
              size="sm"
              disabled={page === 0}
              onClick={() => setPage((p) => Math.max(0, p - 1))}
            >
              <ChevronLeft className="h-4 w-4" /> {t("common.prev")}
            </Button>
            <Button
              variant="outline"
              size="sm"
              disabled={page >= totalPages - 1}
              onClick={() => setPage((p) => p + 1)}
            >
              {t("common.next")} <ChevronRight className="h-4 w-4" />
            </Button>
          </div>
        </div>
      )}
    </div>
  );
}
