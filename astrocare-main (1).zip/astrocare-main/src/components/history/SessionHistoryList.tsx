import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { MessageCircle, Phone, Loader2, Inbox } from "lucide-react";
import { format, isToday, isYesterday } from "date-fns";

interface SessionRow {
  id: string;
  kind: "chat" | "call";
  created_at: string;
  ended_at: string | null;
  duration_seconds: number;
  status: string;
  total_cost: number;
  astrologer_earning: number;
  per_minute_rate: number;
  user_id: string;
  astrologer_id: string;
  end_reason: string | null;
  // joined
  other_name: string;
  other_avatar: string | null;
}

interface Props {
  /** "customer" view shows total_cost; "astrologer" view shows earnings */
  perspective: "customer" | "astrologer";
  /** Visual theme. "dark" matches astrologer dashboard (transactions/notifications). Default "light". */
  theme?: "light" | "dark";
}

function fmtDur(s: number) {
  if (!s) return "0m 00s";
  const m = Math.floor(s / 60);
  const sec = s % 60;
  return `${m}m ${sec.toString().padStart(2, "0")}s`;
}

function dateLabel(d: Date) {
  if (isToday(d)) return "Today";
  if (isYesterday(d)) return "Yesterday";
  return format(d, "EEE, dd MMM yyyy");
}

function statusBadge(status: string, end_reason: string | null) {
  if (status === "ended") return { label: "Completed", cls: "bg-emerald-500/15 text-emerald-300 border-emerald-400/30" };
  if (status === "cancelled" && end_reason === "request_timeout")
    return { label: "Missed", cls: "bg-amber-500/15 text-amber-300 border-amber-400/30" };
  if (status === "cancelled") return { label: "Cancelled", cls: "bg-white/10 text-white/70 border-white/15" };
  if (status === "rejected") return { label: "Declined", cls: "bg-rose-500/15 text-rose-300 border-rose-400/30" };
  return { label: status, cls: "bg-white/10 text-white/70 border-white/15" };
}

export function SessionHistoryList({ perspective, theme = "light" }: Props) {
  const { user } = useAuth();
  const [rows, setRows] = useState<SessionRow[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!user) return;
    let cancelled = false;
    (async () => {
      setLoading(true);

      // For astrologer perspective, look up astrologer.id first
      let astroId: string | null = null;
      if (perspective === "astrologer") {
        const { data: a } = await supabase
          .from("astrologers")
          .select("id")
          .eq("user_id", user.id)
          .maybeSingle();
        astroId = (a as any)?.id ?? null;
        if (!astroId) {
          if (!cancelled) {
            setRows([]);
            setLoading(false);
          }
          return;
        }
      }

      const chatQ = supabase
        .from("chat_sessions")
        .select("id, created_at, ended_at, duration_seconds, status, total_cost, astrologer_earning, per_minute_rate, user_id, astrologer_id, end_reason")
        .order("created_at", { ascending: false })
        .limit(100);
      const callQ = supabase
        .from("call_sessions")
        .select("id, created_at, ended_at, duration_seconds, status, per_minute_rate, user_id, astrologer_id, end_reason, astrologer_earning")
        .order("created_at", { ascending: false })
        .limit(100);

      const filtered =
        perspective === "customer"
          ? [chatQ.eq("user_id", user.id), callQ.eq("user_id", user.id)]
          : [chatQ.eq("astrologer_id", astroId!), callQ.eq("astrologer_id", astroId!)];

      const [{ data: chats }, { data: calls }] = await Promise.all(filtered as any);

      const otherIds = new Set<string>();
      const astroIds = new Set<string>();
      const userIds = new Set<string>();
      (chats ?? []).forEach((r: any) => {
        if (perspective === "customer") astroIds.add(r.astrologer_id);
        else userIds.add(r.user_id);
      });
      (calls ?? []).forEach((r: any) => {
        if (perspective === "customer") astroIds.add(r.astrologer_id);
        else userIds.add(r.user_id);
      });

      const [{ data: astros }, { data: profiles }] = await Promise.all([
        astroIds.size
          ? supabase.from("astrologers").select("id, display_name, avatar_url").in("id", Array.from(astroIds))
          : Promise.resolve({ data: [] as any[] }),
        userIds.size
          ? supabase.from("profiles").select("id, name, avatar_url").in("id", Array.from(userIds))
          : Promise.resolve({ data: [] as any[] }),
      ]);
      const astroMap = new Map((astros as any[] ?? []).map((a) => [a.id, a]));
      const userMap = new Map((profiles as any[] ?? []).map((p) => [p.id, p]));

      const merge = (r: any, kind: "chat" | "call"): SessionRow => {
        const other =
          perspective === "customer"
            ? astroMap.get(r.astrologer_id)
            : userMap.get(r.user_id);
        return {
          id: r.id,
          kind,
          created_at: r.created_at,
          ended_at: r.ended_at,
          duration_seconds: r.duration_seconds ?? 0,
          status: r.status,
          total_cost: Number(r.total_cost ?? (r.duration_seconds ? Math.ceil(r.duration_seconds / 60) * Number(r.per_minute_rate) : 0)),
          astrologer_earning: Number(r.astrologer_earning ?? 0),
          per_minute_rate: Number(r.per_minute_rate),
          user_id: r.user_id,
          astrologer_id: r.astrologer_id,
          end_reason: r.end_reason,
          other_name: other?.display_name ?? other?.name ?? "Unknown",
          other_avatar: other?.avatar_url ?? null,
        };
      };

      const all = [
        ...(chats ?? []).map((r: any) => merge(r, "chat")),
        ...(calls ?? []).map((r: any) => merge(r, "call")),
      ].sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime());

      if (!cancelled) {
        setRows(all);
        setLoading(false);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [user, perspective]);

  const isDark = theme === "dark";

  if (loading) {
    return (
      <div className={`flex items-center justify-center py-16 ${isDark ? "text-white/50" : "text-muted-foreground"}`}>
        <Loader2 className="mr-2 h-5 w-5 animate-spin" /> Loading history…
      </div>
    );
  }

  if (rows.length === 0) {
    return isDark ? (
      <div className="flex flex-col items-center gap-3 p-12 text-center">
        <div className="rounded-full bg-amber-300/10 p-4 text-amber-300"><Inbox className="h-8 w-8" /></div>
        <p className="text-white/70">No sessions yet</p>
        <p className="text-xs text-white/40 max-w-xs">
          Your chat &amp; call consultations will appear here once you complete your first session.
        </p>
      </div>
    ) : (
      <div className="flex flex-col items-center justify-center gap-3 rounded-2xl border border-dashed border-border bg-card/50 py-16 text-center">
        <div className="flex h-14 w-14 items-center justify-center rounded-full bg-muted">
          <Inbox className="h-7 w-7 text-muted-foreground" />
        </div>
        <p className="text-sm font-medium">No sessions yet</p>
        <p className="max-w-xs text-xs text-muted-foreground">
          Your chat and call session history will appear here once you've had your first consultation.
        </p>
      </div>
    );
  }

  // Group by date label
  const groups = new Map<string, SessionRow[]>();
  rows.forEach((r) => {
    const key = dateLabel(new Date(r.created_at));
    const arr = groups.get(key) ?? [];
    arr.push(r);
    groups.set(key, arr);
  });

  if (isDark) {
    // Dark theme — matches transactions/notifications list style on the astrologer dashboard
    return (
      <div className="space-y-6">
        {Array.from(groups.entries()).map(([label, items]) => (
          <div key={label} className="space-y-2">
            <p className="px-1 text-[10px] font-semibold uppercase tracking-wider text-white/40">{label}</p>
            <ul className="divide-y divide-white/5 overflow-hidden rounded-xl border border-white/5 bg-white/[0.02]">
              {items.map((r) => {
                const initials = r.other_name.split(" ").map((p) => p[0]).join("").slice(0, 2).toUpperCase();
                const sb = statusBadge(r.status, r.end_reason);
                const time = format(new Date(r.created_at), "hh:mm a");
                return (
                  <li key={`${r.kind}-${r.id}`} className="flex items-center gap-3 px-5 py-4 hover:bg-white/[0.03] transition">
                    <div className={`rounded-full p-2 ${r.kind === "chat" ? "bg-emerald-500/10 text-emerald-300" : "bg-sky-500/10 text-sky-300"}`}>
                      {r.kind === "chat" ? <MessageCircle className="h-4 w-4" /> : <Phone className="h-4 w-4" />}
                    </div>
                    <Avatar className="h-10 w-10 shrink-0 ring-1 ring-white/10">
                      <AvatarImage src={r.other_avatar ?? undefined} alt={r.other_name} className="object-cover" />
                      <AvatarFallback className="bg-amber-500/15 text-amber-200 text-xs">{initials}</AvatarFallback>
                    </Avatar>
                    <div className="min-w-0 flex-1">
                      <div className="flex flex-wrap items-center gap-2">
                        <p className="truncate text-sm font-semibold text-white">{r.other_name}</p>
                        <span className={`inline-flex items-center rounded-full border px-2 py-0 text-[10px] ${sb.cls}`}>
                          {sb.label}
                        </span>
                      </div>
                      <p className="mt-0.5 text-[11px] text-white/40">
                        {time} · {r.kind === "chat" ? "Chat" : "Call"} · {fmtDur(r.duration_seconds)}
                      </p>
                    </div>
                    <div className="text-right shrink-0">
                      {perspective === "customer" ? (
                        <>
                          <p className="text-sm font-bold text-amber-200 tabular-nums">₹{r.total_cost}</p>
                          <p className="text-[10px] text-white/40">@ ₹{r.per_minute_rate}/min</p>
                        </>
                      ) : (
                        <>
                          <p className="text-sm font-bold text-emerald-300 tabular-nums">+ ₹{r.astrologer_earning}</p>
                          <p className="text-[10px] text-white/40">earnings (30%)</p>
                        </>
                      )}
                    </div>
                  </li>
                );
              })}
            </ul>
          </div>
        ))}
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {Array.from(groups.entries()).map(([label, items]) => (
        <div key={label} className="space-y-2">
          <p className="px-1 text-xs font-semibold uppercase tracking-wider text-muted-foreground">{label}</p>
          <div className="space-y-2">
            {items.map((r) => {
              const initials = r.other_name.split(" ").map((p) => p[0]).join("").slice(0, 2).toUpperCase();
              const sb = statusBadge(r.status, r.end_reason);
              const time = format(new Date(r.created_at), "hh:mm a");
              return (
                <div
                  key={`${r.kind}-${r.id}`}
                  className="group flex items-center gap-3 rounded-2xl border border-border bg-card p-3 transition hover:border-primary/30 hover:shadow-md sm:gap-4 sm:p-4"
                >
                  <Avatar className="h-12 w-12 shrink-0">
                    <AvatarImage src={r.other_avatar ?? undefined} alt={r.other_name} className="object-cover" />
                    <AvatarFallback className="bg-primary/15 text-primary">{initials}</AvatarFallback>
                  </Avatar>

                  <div className="min-w-0 flex-1">
                    <div className="flex flex-wrap items-center gap-2">
                      <p className="truncate font-semibold">{r.other_name}</p>
                      <Badge variant="secondary" className="gap-1 px-1.5 py-0 text-[10px]">
                        {r.kind === "chat" ? <MessageCircle className="h-3 w-3" /> : <Phone className="h-3 w-3" />}
                        {r.kind === "chat" ? "Chat" : "Call"}
                      </Badge>
                      <span className={`inline-flex items-center rounded-full border px-2 py-0 text-[10px] ${sb.cls}`}>
                        {sb.label}
                      </span>
                    </div>
                    <p className="mt-0.5 text-xs text-muted-foreground">
                      {time} · Duration {fmtDur(r.duration_seconds)}
                    </p>
                  </div>

                  <div className="shrink-0 text-right">
                    {perspective === "customer" ? (
                      <>
                        <p className="text-base font-bold text-foreground tabular-nums">₹{r.total_cost}</p>
                        <p className="text-[10px] text-muted-foreground">@ ₹{r.per_minute_rate}/min</p>
                      </>
                    ) : (
                      <>
                        <p className="text-base font-bold text-emerald-500 tabular-nums">+ ₹{r.astrologer_earning}</p>
                        <p className="text-[10px] text-muted-foreground">earnings (30%)</p>
                      </>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      ))}
    </div>
  );
}
