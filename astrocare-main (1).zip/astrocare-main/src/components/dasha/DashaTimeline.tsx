import { useMemo, useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { ChevronRight, Loader2, Sparkles, AlertTriangle } from "lucide-react";
import { cn } from "@/lib/utils";
import {
  PLANET_COLORS, findCurrent, formatPeriodRange, formatYears,
  type DashaNode, type DashaTree,
} from "@/lib/dasha";

interface Props {
  status: "idle" | "loading" | "computing" | "ready" | "error";
  error: string | null;
  tree: DashaTree | null;
  currentMahaLord: string | null;
  currentMahaStart: string | null;
  currentMahaEnd: string | null;
  onCompute: () => void;
}

interface DrillState {
  maha?: DashaNode;
  antar?: DashaNode;
  pratyantar?: DashaNode;
}

function PeriodBlock({
  node, active, selected, onClick, compact,
}: {
  node: DashaNode; active: boolean; selected: boolean; onClick: () => void; compact?: boolean;
}) {
  const c = PLANET_COLORS[node.lord];
  return (
    <button
      type="button"
      onClick={onClick}
      className={cn(
        "shrink-0 text-left rounded-md border px-3 py-2 transition-all",
        c.bg, c.border, c.text,
        compact ? "min-w-[140px]" : "min-w-[160px]",
        active && "ring-2 ring-primary ring-offset-1 ring-offset-background",
        selected && !active && "ring-1 ring-foreground/40",
        "hover:translate-y-[-1px]",
      )}
    >
      <div className="flex items-center justify-between gap-2">
        <span className="font-semibold text-sm">{node.lord}</span>
        {active && <Badge variant="default" className="text-[9px] h-4 px-1.5">Current</Badge>}
      </div>
      <div className="text-[11px] opacity-80 mt-0.5">{formatYears(node.years)}</div>
      <div className="text-[10px] opacity-70 mt-0.5">{formatPeriodRange(node.start, node.end)}</div>
    </button>
  );
}

function Row({
  label, nodes, selectedStart, onSelect, now,
}: {
  label: string;
  nodes: DashaNode[];
  selectedStart?: string;
  onSelect: (n: DashaNode) => void;
  now: Date;
}) {
  return (
    <div className="space-y-1.5">
      <div className="flex items-center gap-1.5 text-xs font-medium text-muted-foreground uppercase tracking-wide">
        <ChevronRight className="h-3 w-3" /> {label}
      </div>
      <div className="flex gap-2 overflow-x-auto pb-2 -mx-1 px-1">
        {nodes.map((n) => {
          const isCurrent = now >= new Date(n.start) && now < new Date(n.end);
          return (
            <PeriodBlock
              key={n.start}
              node={n}
              active={isCurrent}
              selected={selectedStart === n.start}
              onClick={() => onSelect(n)}
              compact={label !== "Mahadasha"}
            />
          );
        })}
      </div>
    </div>
  );
}

export function DashaTimeline({
  status, error, tree, currentMahaLord, currentMahaStart, currentMahaEnd, onCompute,
}: Props) {
  const now = useMemo(() => new Date(), []);
  const [drill, setDrill] = useState<DrillState>({});

  // Auto-select current path on first ready render
  const initialDrill = useMemo<DrillState>(() => {
    if (!tree) return {};
    const m = findCurrent(tree.mahadashas, now) ?? undefined;
    const a = m ? findCurrent(m.children, now) ?? undefined : undefined;
    const p = a ? findCurrent(a.children, now) ?? undefined : undefined;
    return { maha: m, antar: a, pratyantar: p };
  }, [tree, now]);

  // Use drill if user clicked something, else default to current path
  const view: DrillState = {
    maha: drill.maha ?? initialDrill.maha,
    antar: drill.antar ?? (drill.maha ? undefined : initialDrill.antar),
    pratyantar: drill.pratyantar ?? (drill.maha || drill.antar ? undefined : initialDrill.pratyantar),
  };

  const currentSummary = useMemo(() => {
    if (!tree) return null;
    const m = findCurrent(tree.mahadashas, now);
    const a = m ? findCurrent(m.children, now) : null;
    const p = a ? findCurrent(a.children, now) : null;
    const s = p ? findCurrent(p.children, now) : null;
    return { m, a, p, s };
  }, [tree, now]);

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-lg">
          <Sparkles className="h-5 w-5 text-primary" />
          Vimshottari Dasha
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {(status === "loading" || status === "computing") && (
          <div className="space-y-3">
            <div className="flex items-center gap-2 text-sm text-muted-foreground">
              <Loader2 className="h-4 w-4 animate-spin" />
              {status === "computing" ? "Computing your 120-year planetary timeline…" : "Loading Dasha…"}
            </div>
            <div className="flex gap-2 overflow-hidden">
              {Array.from({ length: 6 }).map((_, i) => (
                <Skeleton key={i} className="h-16 w-40 shrink-0" />
              ))}
            </div>
          </div>
        )}

        {status === "error" && (
          <div className="space-y-3">
            <Alert variant="destructive">
              <AlertTriangle className="h-4 w-4" />
              <AlertDescription>
                {error || "Could not compute Dasha. Please verify your birth time is accurate."}
              </AlertDescription>
            </Alert>
            <Button variant="outline" size="sm" onClick={onCompute}>
              Retry
            </Button>
          </div>
        )}

        {status === "idle" && (
          <div className="text-center py-6 space-y-3">
            <p className="text-sm text-muted-foreground">
              Compute your full Vimshottari Dasha — a 120-year map of planetary periods.
            </p>
            <Button variant="saffron" onClick={onCompute}>
              <Sparkles className="h-4 w-4" /> Compute Vimshottari Dasha
            </Button>
          </div>
        )}

        {status === "ready" && tree && (
          <>
            {/* Current period summary */}
            {currentSummary?.m && (
              <div className="rounded-md border border-primary/30 bg-primary/5 p-3">
                <div className="text-xs text-muted-foreground uppercase tracking-wide">Current period</div>
                <div className="font-semibold mt-1">
                  {[currentSummary.m.lord, currentSummary.a?.lord, currentSummary.p?.lord, currentSummary.s?.lord]
                    .filter(Boolean).join(" – ")}
                </div>
                {currentSummary.s ? (
                  <div className="text-xs text-muted-foreground mt-0.5">
                    Sookshma {formatPeriodRange(currentSummary.s.start, currentSummary.s.end)}
                  </div>
                ) : currentMahaStart && currentMahaEnd && (
                  <div className="text-xs text-muted-foreground mt-0.5">
                    Mahadasha {formatPeriodRange(currentMahaStart, currentMahaEnd)}
                  </div>
                )}
                <div className="text-[11px] text-muted-foreground mt-1">
                  Birth nakshatra: {tree.starting_nakshatra} (lord: {tree.starting_lord})
                </div>
              </div>
            )}

            {/* Mahadashas */}
            <Row
              label="Mahadasha"
              nodes={tree.mahadashas}
              selectedStart={view.maha?.start}
              onSelect={(n) => setDrill({ maha: n })}
              now={now}
            />

            {/* Antardashas */}
            {view.maha?.children && view.maha.children.length > 0 && (
              <Row
                label={`Antardasha · within ${view.maha.lord}`}
                nodes={view.maha.children}
                selectedStart={view.antar?.start}
                onSelect={(n) => setDrill({ maha: view.maha, antar: n })}
                now={now}
              />
            )}

            {/* Pratyantar */}
            {view.antar?.children && view.antar.children.length > 0 && (
              <Row
                label={`Pratyantar · within ${view.maha!.lord}-${view.antar.lord}`}
                nodes={view.antar.children}
                selectedStart={view.pratyantar?.start}
                onSelect={(n) => setDrill({ maha: view.maha, antar: view.antar, pratyantar: n })}
                now={now}
              />
            )}

            {/* Sookshma */}
            {view.pratyantar?.children && view.pratyantar.children.length > 0 && (
              <Row
                label={`Sookshma · within ${view.maha!.lord}-${view.antar!.lord}-${view.pratyantar.lord}`}
                nodes={view.pratyantar.children}
                onSelect={() => { /* leaf */ }}
                now={now}
              />
            )}

            <p className="text-[11px] text-muted-foreground pt-1">
              Click any period to drill down. Periods computed using Lahiri ayanamsa, Moon nakshatra at birth.
            </p>
          </>
        )}
      </CardContent>
    </Card>
  );
}
