import Select from "react-select";
import { INDIAN_CITIES, type IndianCity } from "@/data/indianCities";

interface POBOption {
  value: string;
  label: string;
  data: IndianCity;
}

const OPTIONS: POBOption[] = INDIAN_CITIES.map((c) => ({
  value: `${c.city}|${c.state}`,
  label: `${c.city}, ${c.state}`,
  data: c,
}));

interface POBAutocompleteProps {
  value?: { city: string; state: string; country: string; lat: number | null; lon: number | null } | null;
  onChange: (v: { city: string; state: string; country: string; lat: number; lon: number } | null) => void;
}

export function POBAutocomplete({ value, onChange }: POBAutocompleteProps) {
  const selected = value?.city
    ? OPTIONS.find((o) => o.data.city === value.city && o.data.state === value.state) ?? null
    : null;

  return (
    <Select<POBOption>
      options={OPTIONS}
      value={selected}
      onChange={(opt) => {
        if (!opt) {
          onChange(null);
          return;
        }
        const c = opt.data;
        onChange({ city: c.city, state: c.state, country: c.country, lat: c.lat, lon: c.lon });
      }}
      isClearable
      placeholder="Search city…"
      classNames={{
        control: ({ isFocused }) =>
          `!min-h-10 !rounded-md !border ${
            isFocused ? "!border-primary !ring-2 !ring-ring/30" : "!border-input"
          } !bg-background !shadow-none`,
        valueContainer: () => "!px-3",
        input: () => "!text-foreground",
        singleValue: () => "!text-foreground",
        placeholder: () => "!text-muted-foreground",
        menu: () => "!bg-popover !border !border-border !rounded-md !shadow-card-hover !z-50",
        option: ({ isFocused, isSelected }) =>
          `!px-3 !py-2 !text-sm cursor-pointer ${
            isSelected
              ? "!bg-primary !text-primary-foreground"
              : isFocused
              ? "!bg-accent !text-accent-foreground"
              : "!bg-transparent !text-foreground"
          }`,
      }}
      styles={{
        // Reset some defaults so Tailwind classes win
        control: (base) => ({ ...base, boxShadow: "none" }),
      }}
    />
  );
}
