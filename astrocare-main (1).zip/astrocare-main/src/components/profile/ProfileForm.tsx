import { useEffect, useRef, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { POBAutocomplete } from "./POBAutocomplete";
import { PhoneVerificationModal } from "./PhoneVerificationModal";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { Loader2, Camera, ShieldCheck, ShieldAlert } from "lucide-react";

const MONTHS = [
  "January", "February", "March", "April", "May", "June",
  "July", "August", "September", "October", "November", "December",
];

const CURRENT_YEAR = new Date().getFullYear();
const YEARS = Array.from({ length: CURRENT_YEAR - 1900 + 1 }, (_, i) => CURRENT_YEAR - i);
const DAYS = Array.from({ length: 31 }, (_, i) => i + 1);
const HOURS = Array.from({ length: 12 }, (_, i) => i + 1);
const MINUTES = Array.from({ length: 60 }, (_, i) => i);

interface ProfileFormProps {
  onSaved?: () => void;
}

interface ProfileState {
  name: string;
  email: string;
  phone: string;
  avatarUrl: string | null;
  dobDay: string;
  dobMonth: string;
  dobYear: string;
  tobHour: string;
  tobMinute: string;
  tobMeridiem: "AM" | "PM";
  pob: { city: string; state: string; country: string; lat: number; lon: number } | null;
}

const EMPTY: ProfileState = {
  name: "",
  email: "",
  phone: "+91",
  avatarUrl: null,
  dobDay: "",
  dobMonth: "",
  dobYear: "",
  tobHour: "",
  tobMinute: "",
  tobMeridiem: "AM",
  pob: null,
};

const E164 = /^\+[1-9]\d{7,14}$/;

export function ProfileForm({ onSaved }: ProfileFormProps) {
  const { user } = useAuth();
  const { toast } = useToast();
  const [state, setState] = useState<ProfileState>(EMPTY);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [uploadingAvatar, setUploadingAvatar] = useState(false);
  const [phoneVerified, setPhoneVerified] = useState(false);
  const [verifyOpen, setVerifyOpen] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleAvatarSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !user) return;
    if (file.size > 5 * 1024 * 1024) {
      toast({ title: "Image too large", description: "Max 5 MB.", variant: "destructive" });
      return;
    }
    setUploadingAvatar(true);
    const ext = file.name.split(".").pop() || "jpg";
    const path = `${user.id}/avatar-${Date.now()}.${ext}`;
    const { error: upErr } = await supabase.storage
      .from("avatars")
      .upload(path, file, { upsert: true, contentType: file.type });
    if (upErr) {
      setUploadingAvatar(false);
      toast({ title: "Upload failed", description: upErr.message, variant: "destructive" });
      return;
    }
    const { data: pub } = supabase.storage.from("avatars").getPublicUrl(path);
    const url = pub.publicUrl;
    const { error: updErr } = await supabase
      .from("profiles")
      .update({ avatar_url: url } as never)
      .eq("id", user.id);
    setUploadingAvatar(false);
    if (updErr) {
      toast({ title: "Save failed", description: updErr.message, variant: "destructive" });
      return;
    }
    setState((s) => ({ ...s, avatarUrl: url }));
    toast({ title: "Profile picture updated" });
  };

  useEffect(() => {
    if (!user) return;
    let cancelled = false;
    (async () => {
      setLoading(true);
      const { data } = await supabase
        .from("profiles")
        .select("*")
        .eq("id", user.id)
        .maybeSingle();
      if (cancelled || !data) {
        if (!cancelled) setLoading(false);
        return;
      }

      const next: ProfileState = { ...EMPTY };
      next.name = data.name || "";
      next.email = data.email || user.email || "";
      next.phone = data.phone_e164 || "+91";
      next.avatarUrl = (data as { avatar_url?: string | null }).avatar_url ?? null;
      setPhoneVerified(Boolean((data as { phone_verified?: boolean }).phone_verified));
      if (data.dob) {
        const [y, m, d] = data.dob.split("-");
        next.dobYear = y;
        next.dobMonth = String(parseInt(m, 10));
        next.dobDay = String(parseInt(d, 10));
      }

      if (data.tob) {
        const [hh, mm] = data.tob.split(":");
        const hour24 = parseInt(hh, 10);
        const meridiem: "AM" | "PM" = hour24 >= 12 ? "PM" : "AM";
        const hour12 = hour24 % 12 === 0 ? 12 : hour24 % 12;
        next.tobHour = String(hour12);
        next.tobMinute = String(parseInt(mm, 10));
        next.tobMeridiem = meridiem;
      }

      if (data.pob_city) {
        next.pob = {
          city: data.pob_city,
          state: data.pob_state || "",
          country: data.pob_country || "India",
          lat: Number(data.pob_lat) || 0,
          lon: Number(data.pob_lon) || 0,
        };
      }

      setState(next);
      setLoading(false);
    })();
    return () => {
      cancelled = true;
    };
  }, [user]);

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) return;
    if (!state.name.trim()) {
      toast({ title: "Name is required", variant: "destructive" });
      return;
    }
    const phoneTrimmed = state.phone.trim();
    if (phoneTrimmed && phoneTrimmed !== "+91" && !E164.test(phoneTrimmed)) {
      toast({
        title: "Invalid phone number",
        description: "Use international format e.g. +919876543210",
        variant: "destructive",
      });
      return;
    }

    setSaving(true);
    let dob: string | null = null;
    if (state.dobDay && state.dobMonth && state.dobYear) {
      const m = String(state.dobMonth).padStart(2, "0");
      const d = String(state.dobDay).padStart(2, "0");
      dob = `${state.dobYear}-${m}-${d}`;
    }

    let tob: string | null = null;
    if (state.tobHour && state.tobMinute !== "") {
      let h = parseInt(state.tobHour, 10);
      if (state.tobMeridiem === "PM" && h !== 12) h += 12;
      if (state.tobMeridiem === "AM" && h === 12) h = 0;
      const mm = String(state.tobMinute).padStart(2, "0");
      tob = `${String(h).padStart(2, "0")}:${mm}:00`;
    }

    const { error } = await supabase
      .from("profiles")
      .update({
        name: state.name.trim(),
        email: state.email.trim() || null,
        phone_e164: phoneTrimmed && phoneTrimmed !== "+91" ? phoneTrimmed : null,
        dob,
        tob,
        pob_city: state.pob?.city ?? null,
        pob_state: state.pob?.state ?? null,
        pob_country: state.pob?.country ?? "India",
        pob_lat: state.pob?.lat ?? null,
        pob_lon: state.pob?.lon ?? null,
      })
      .eq("id", user.id);
    setSaving(false);
    if (error) {
      toast({ title: "Save failed", description: error.message, variant: "destructive" });
      return;
    }
    toast({ title: "Profile saved" });
    onSaved?.();
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center py-16 text-muted-foreground">
        <Loader2 className="h-5 w-5 animate-spin mr-2" /> Loading profile…
      </div>
    );
  }

  return (
    <form onSubmit={handleSave} className="space-y-6">
      <section className="flex items-center gap-4">
        <div className="relative">
          <Avatar className="h-20 w-20">
            <AvatarImage src={state.avatarUrl ?? undefined} alt={state.name || "Profile"} />
            <AvatarFallback className="bg-primary/10 text-primary font-semibold text-lg">
              {(state.name || user?.email || "U").slice(0, 2).toUpperCase()}
            </AvatarFallback>
          </Avatar>
          <button
            type="button"
            onClick={() => fileInputRef.current?.click()}
            className="absolute -bottom-1 -right-1 h-7 w-7 rounded-full bg-primary text-primary-foreground flex items-center justify-center shadow-md hover:bg-primary/90"
            aria-label="Change profile picture"
          >
            <Camera className="h-3.5 w-3.5" />
          </button>
        </div>
        <div className="flex-1">
          <p className="text-sm font-medium">Profile picture</p>
          <p className="text-xs text-muted-foreground">JPG or PNG, up to 5 MB.</p>
          <Button
            type="button"
            variant="outline"
            size="sm"
            className="mt-2"
            onClick={() => fileInputRef.current?.click()}
            disabled={uploadingAvatar}
          >
            {uploadingAvatar ? (
              <><Loader2 className="h-3.5 w-3.5 animate-spin" /> Uploading…</>
            ) : (
              "Upload new picture"
            )}
          </Button>
          <input
            ref={fileInputRef}
            type="file"
            accept="image/*"
            className="hidden"
            onChange={handleAvatarSelect}
          />
        </div>
      </section>

      <section className="grid gap-4 sm:grid-cols-2">
        <div className="space-y-2">
          <Label htmlFor="name">Full name *</Label>
          <Input
            id="name"
            value={state.name}
            onChange={(e) => setState({ ...state, name: e.target.value })}
            required
          />
        </div>
        <div className="space-y-2">
          <Label htmlFor="email">Email</Label>
          <Input
            id="email"
            type="email"
            value={state.email}
            onChange={(e) => setState({ ...state, email: e.target.value })}
          />
        </div>
      </section>

      <section className="space-y-2">
        <div className="flex items-center justify-between gap-2 flex-wrap">
          <Label htmlFor="phone">Phone number (for consultation calls)</Label>
          {state.phone && state.phone !== "+91" && (
            phoneVerified ? (
              <Badge variant="secondary" className="bg-emerald-500/15 text-emerald-600 border-emerald-500/30">
                <ShieldCheck className="mr-1 h-3 w-3" /> Verified
              </Badge>
            ) : (
              <Badge variant="secondary" className="bg-destructive/15 text-destructive border-destructive/30">
                <ShieldAlert className="mr-1 h-3 w-3" /> Not verified
              </Badge>
            )
          )}
        </div>
        <div className="flex gap-2">
          <Input
            id="phone"
            type="tel"
            inputMode="tel"
            value={state.phone}
            onChange={(e) => setState({ ...state, phone: e.target.value })}
            placeholder="+919876543210"
          />
          <Button
            type="button"
            variant={phoneVerified ? "outline" : "saffron"}
            onClick={() => setVerifyOpen(true)}
          >
            {phoneVerified ? "Re-verify" : "Verify"}
          </Button>
        </div>
        <p className="text-xs text-muted-foreground">
          Use international format with country code (e.g. +91 for India). A verified phone is required for calls.
        </p>
        <PhoneVerificationModal
          open={verifyOpen}
          onClose={() => setVerifyOpen(false)}
          userType="customer"
          initialPhone={state.phone && state.phone !== "+91" ? state.phone : null}
          onVerified={(p) => {
            setPhoneVerified(true);
            setState((s) => ({ ...s, phone: p }));
          }}
        />
      </section>

      <section className="space-y-3">
        <h3 className="text-sm font-semibold text-foreground">Date of birth</h3>
        <div className="grid grid-cols-3 gap-3">
          <Select value={state.dobDay} onValueChange={(v) => setState({ ...state, dobDay: v })}>
            <SelectTrigger><SelectValue placeholder="Day" /></SelectTrigger>
            <SelectContent className="max-h-64">
              {DAYS.map((d) => <SelectItem key={d} value={String(d)}>{d}</SelectItem>)}
            </SelectContent>
          </Select>
          <Select value={state.dobMonth} onValueChange={(v) => setState({ ...state, dobMonth: v })}>
            <SelectTrigger><SelectValue placeholder="Month" /></SelectTrigger>
            <SelectContent className="max-h-64">
              {MONTHS.map((m, i) => <SelectItem key={m} value={String(i + 1)}>{m}</SelectItem>)}
            </SelectContent>
          </Select>
          <Select value={state.dobYear} onValueChange={(v) => setState({ ...state, dobYear: v })}>
            <SelectTrigger><SelectValue placeholder="Year" /></SelectTrigger>
            <SelectContent className="max-h-64">
              {YEARS.map((y) => <SelectItem key={y} value={String(y)}>{y}</SelectItem>)}
            </SelectContent>
          </Select>
        </div>
      </section>

      <section className="space-y-3">
        <h3 className="text-sm font-semibold text-foreground">Time of birth</h3>
        <div className="grid grid-cols-3 gap-3">
          <Select value={state.tobHour} onValueChange={(v) => setState({ ...state, tobHour: v })}>
            <SelectTrigger><SelectValue placeholder="Hour" /></SelectTrigger>
            <SelectContent className="max-h-64">
              {HOURS.map((h) => <SelectItem key={h} value={String(h)}>{h}</SelectItem>)}
            </SelectContent>
          </Select>
          <Select value={state.tobMinute} onValueChange={(v) => setState({ ...state, tobMinute: v })}>
            <SelectTrigger><SelectValue placeholder="Minute" /></SelectTrigger>
            <SelectContent className="max-h-64">
              {MINUTES.map((m) => (
                <SelectItem key={m} value={String(m)}>{String(m).padStart(2, "0")}</SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Select
            value={state.tobMeridiem}
            onValueChange={(v) => setState({ ...state, tobMeridiem: v as "AM" | "PM" })}
          >
            <SelectTrigger><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="AM">AM</SelectItem>
              <SelectItem value="PM">PM</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </section>

      <section className="space-y-3">
        <h3 className="text-sm font-semibold text-foreground">Place of birth</h3>
        <POBAutocomplete value={state.pob} onChange={(v) => setState({ ...state, pob: v })} />
        {state.pob && (
          <p className="text-xs text-muted-foreground">
            {state.pob.city}, {state.pob.state}, {state.pob.country}
            {" · "}
            {state.pob.lat.toFixed(4)}°N, {state.pob.lon.toFixed(4)}°E
          </p>
        )}
      </section>

      <Button type="submit" variant="saffron" size="lg" disabled={saving}>
        {saving ? <><Loader2 className="h-4 w-4 animate-spin" /> Saving…</> : "Save profile"}
      </Button>
    </form>
  );
}
