import { useEffect, useRef, useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { InputOTP, InputOTPGroup, InputOTPSlot } from "@/components/ui/input-otp";
import { Loader2, Phone, ShieldCheck, Sparkles } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "@/hooks/use-toast";

type Step = "enter" | "code" | "success";

interface Props {
  open: boolean;
  onClose: () => void;
  userType: "customer" | "astrologer";
  initialPhone?: string | null;
  onVerified?: (phone: string) => void;
}

const COUNTRY_CODES = [
  { code: "+91", label: "🇮🇳 +91" },
  { code: "+1", label: "🇺🇸 +1" },
  { code: "+44", label: "🇬🇧 +44" },
  { code: "+61", label: "🇦🇺 +61" },
  { code: "+971", label: "🇦🇪 +971" },
];

export function PhoneVerificationModal({
  open,
  onClose,
  userType,
  initialPhone,
  onVerified,
}: Props) {
  const [step, setStep] = useState<Step>("enter");
  const [country, setCountry] = useState("+91");
  const [local, setLocal] = useState("");
  const [otp, setOtp] = useState("");
  const [loading, setLoading] = useState(false);
  const [resendIn, setResendIn] = useState(0);
  const [devOtp, setDevOtp] = useState<string | null>(null);
  const tickRef = useRef<number | null>(null);

  useEffect(() => {
    if (!open) {
      setStep("enter");
      setLocal("");
      setOtp("");
      setLoading(false);
      setResendIn(0);
      setDevOtp(null);
      return;
    }
    if (initialPhone) {
      const m = initialPhone.match(/^(\+\d{1,4})(\d+)$/);
      if (m) {
        setCountry(m[1]);
        setLocal(m[2]);
      } else {
        setLocal(initialPhone.replace(/^\+?/, ""));
      }
    }
  }, [open, initialPhone]);

  useEffect(() => {
    if (resendIn <= 0) {
      if (tickRef.current) {
        clearInterval(tickRef.current);
        tickRef.current = null;
      }
      return;
    }
    tickRef.current = window.setInterval(() => setResendIn((s) => s - 1), 1000);
    return () => {
      if (tickRef.current) clearInterval(tickRef.current);
    };
  }, [resendIn]);

  const fullPhone = `${country}${local.replace(/\D/g, "")}`;

  const sendOtp = async () => {
    if (!/^\+[1-9]\d{7,14}$/.test(fullPhone)) {
      toast({ title: "Enter a valid phone number", variant: "destructive" });
      return;
    }
    setLoading(true);
    const { data, error } = await supabase.functions.invoke("send-phone-otp", {
      body: { phone_number: fullPhone, user_type: userType },
    });
    setLoading(false);
    if (error || (data && data.error)) {
      toast({
        title: "Could not send code",
        description: (data?.error as string) ?? error?.message ?? "Please try again",
        variant: "destructive",
      });
      return;
    }
    const receivedOtp = (data?.dev_otp as string) ?? null;
    if (receivedOtp) {
      // eslint-disable-next-line no-console
      console.log(`[OTP] Verification code for ${fullPhone}: ${receivedOtp}`);
    }
    setDevOtp(receivedOtp);
    setStep("code");
    setResendIn(30);
    setOtp("");
  };

  const verify = async (code: string) => {
    if (code.length !== 6) return;
    setLoading(true);
    const { data, error } = await supabase.functions.invoke("verify-phone-otp", {
      body: { phone_number: fullPhone, otp: code, user_type: userType },
    });
    setLoading(false);
    if (error || (data && data.error)) {
      toast({
        title: "Verification failed",
        description: (data?.error as string) ?? error?.message ?? "Try again",
        variant: "destructive",
      });
      setOtp("");
      return;
    }
    setStep("success");
    onVerified?.(fullPhone);
    setTimeout(() => onClose(), 1800);
  };

  return (
    <Dialog open={open} onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Phone className="h-5 w-5 text-primary" />
            {step === "success" ? "Phone Verified" : "Verify Phone Number"}
          </DialogTitle>
        </DialogHeader>

        {step === "enter" && (
          <div className="space-y-4">
            <p className="text-sm text-muted-foreground">
              We'll text a 6-digit code to confirm this number.
            </p>
            <div className="flex gap-2">
              <select
                value={country}
                onChange={(e) => setCountry(e.target.value)}
                className="rounded-md border bg-background px-2 text-sm"
              >
                {COUNTRY_CODES.map((c) => (
                  <option key={c.code} value={c.code}>
                    {c.label}
                  </option>
                ))}
              </select>
              <Input
                placeholder="Phone number"
                inputMode="numeric"
                value={local}
                onChange={(e) => setLocal(e.target.value.replace(/\D/g, ""))}
                disabled={loading}
              />
            </div>
            <Button
              onClick={sendOtp}
              disabled={loading || local.length < 6}
              className="w-full"
              variant="saffron"
            >
              {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : "Send Code"}
            </Button>
          </div>
        )}

        {step === "code" && (
          <div className="space-y-4">
            <p className="text-sm text-muted-foreground">
              Code sent to <span className="font-medium text-foreground">{fullPhone}</span>
            </p>
            {devOtp && (
              <div className="rounded-md border border-amber-500/40 bg-amber-500/10 p-2 text-xs text-muted-foreground">
                Code sent. (Dev mode: check the browser console for the OTP.)
              </div>
            )}
            <div className="flex justify-center">
              <InputOTP
                maxLength={6}
                value={otp}
                onChange={(v) => {
                  setOtp(v);
                  if (v.length === 6) verify(v);
                }}
                disabled={loading}
              >
                <InputOTPGroup>
                  {[0, 1, 2, 3, 4, 5].map((i) => (
                    <InputOTPSlot key={i} index={i} />
                  ))}
                </InputOTPGroup>
              </InputOTP>
            </div>
            <div className="flex items-center justify-between text-xs">
              <button
                onClick={() => setStep("enter")}
                className="text-muted-foreground hover:text-foreground"
              >
                Change number
              </button>
              {resendIn > 0 ? (
                <span className="text-muted-foreground">
                  Resend in 0:{String(resendIn).padStart(2, "0")}
                </span>
              ) : (
                <button
                  onClick={sendOtp}
                  disabled={loading}
                  className="text-primary font-medium hover:underline"
                >
                  Resend code
                </button>
              )}
            </div>
            <Button
              onClick={() => verify(otp)}
              disabled={loading || otp.length !== 6}
              className="w-full"
              variant="saffron"
            >
              {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : "Verify"}
            </Button>
          </div>
        )}

        {step === "success" && (
          <div className="flex flex-col items-center gap-3 py-6 text-center">
            <div className="relative">
              <div className="absolute inset-0 -m-3 rounded-full bg-emerald-500/20 animate-ping" />
              <div className="relative rounded-full bg-emerald-500 p-3">
                <ShieldCheck className="h-8 w-8 text-white" />
              </div>
            </div>
            <h3 className="text-lg font-semibold flex items-center gap-1">
              Phone verified <Sparkles className="h-4 w-4 text-amber-400" />
            </h3>
            <p className="text-sm text-muted-foreground">
              {fullPhone} is ready to receive call connections.
            </p>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}
