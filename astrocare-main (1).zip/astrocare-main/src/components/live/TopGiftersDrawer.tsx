// Top Gifters leaderboard drawer for live streams.
// Shows podium for top 3 + list for #4-10 with real-time updates.
import { useEffect, useMemo, useRef, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { Drawer, DrawerContent, DrawerHeader, DrawerTitle, DrawerDescription } from "@/components/ui/drawer";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Crown, Gift as GiftIcon, Sparkles, X } from "lucide-react";
import { cn } from "@/lib/utils";
import { giftByType } from "./liveGifts";

export interface TopGifter {
  sender_id: string;
  sender_name: string;
  sender_avatar: string | null;
  total_gifted: number;
  gift_count: number;
  top_gift_type: string | null;
}

interface Props {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  liveStreamId: string;
  astrologerName: string;
}

const fmt = (n: number) =>
  "₹" + Number(n || 0).toLocaleString("en-IN", { maximumFractionDigits: 0 });

export function TopGiftersDrawer({ open, onOpenChange, liveStreamId, astrologerName }: Props) {
  const { user } = useAuth();
  const [gifters, setGifters] = useState<TopGifter[]>([]);
  const [loading, setLoading] = useState(false);
  const debounceRef = useRef<number | null>(null);

  async function fetchTop() {
    setLoading(true);
    const { data, error } = await supabase.rpc("get_top_gifters_for_live", { _stream_id: liveStreamId });
    if (!error && data) setGifters(data as TopGifter[]);
    setLoading(false);
  }

  // Initial fetch on open
  useEffect(() => {
    if (!open || !liveStreamId) return;
    fetchTop();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open, liveStreamId]);

  // Realtime: refresh on new gifts (debounced 500ms)
  useEffect(() => {
    if (!open || !liveStreamId) return;
    const ch = supabase
      .channel(`top_gifters_${liveStreamId}_${Math.random().toString(36).slice(2)}`)
      .on(
        "postgres_changes",
        { event: "INSERT", schema: "public", table: "live_gifts", filter: `live_stream_id=eq.${liveStreamId}` },
        () => {
          if (debounceRef.current) window.clearTimeout(debounceRef.current);
          debounceRef.current = window.setTimeout(() => { fetchTop(); }, 500);
        }
      )
      .subscribe();
    return () => {
      if (debounceRef.current) window.clearTimeout(debounceRef.current);
      supabase.removeChannel(ch);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open, liveStreamId]);

  const top3 = useMemo(() => gifters.slice(0, 3), [gifters]);
  const rest = useMemo(() => gifters.slice(3, 10), [gifters]);

  return (
    <Drawer open={open} onOpenChange={onOpenChange}>
      <DrawerContent className="bg-gradient-to-b from-[#1a0a2e] to-[#0f0620] border-amber-500/30 text-white max-h-[85vh] sm:max-w-md sm:mx-auto">
        <DrawerHeader className="text-center relative pb-2">
          <button
            onClick={() => onOpenChange(false)}
            className="absolute right-3 top-3 h-8 w-8 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center"
            aria-label="Close"
          >
            <X className="h-4 w-4" />
          </button>
          <DrawerTitle className="text-xl text-amber-300 flex items-center justify-center gap-2">
            <Crown className="h-5 w-5" /> Top Gifters
          </DrawerTitle>
          <DrawerDescription className="text-white/60 text-xs">
            {astrologerName}'s biggest supporters
          </DrawerDescription>
        </DrawerHeader>

        <div className="overflow-y-auto px-4 pb-6">
          {loading && gifters.length === 0 ? (
            <div className="py-12 text-center text-white/60 text-sm">Loading…</div>
          ) : gifters.length === 0 ? (
            <EmptyState />
          ) : (
            <>
              {/* Podium */}
              <Podium top3={top3} currentUserId={user?.id ?? null} />
              {/* Rest */}
              {rest.length > 0 && (
                <ul className="mt-5 space-y-2">
                  {rest.map((g, idx) => {
                    const isMe = g.sender_id === user?.id;
                    return (
                      <li
                        key={g.sender_id}
                        className={cn(
                          "flex items-center gap-3 rounded-xl bg-white/5 px-3 py-2.5 transition",
                          "hover:bg-white/10",
                          isMe && "ring-2 ring-amber-400/70 bg-amber-500/10"
                        )}
                      >
                        <span className="w-6 text-center text-xs font-bold text-white/70">#{idx + 4}</span>
                        <Avatar className="h-9 w-9">
                          <AvatarImage src={g.sender_avatar ?? undefined} />
                          <AvatarFallback className="bg-purple-900 text-amber-200 text-xs">
                            {g.sender_name.slice(0, 1).toUpperCase()}
                          </AvatarFallback>
                        </Avatar>
                        <div className="flex-1 min-w-0">
                          <div className="text-sm font-medium truncate">
                            {g.sender_name} {isMe && <span className="text-[10px] text-amber-300">(You)</span>}
                          </div>
                          <div className="text-[10px] text-white/50 flex items-center gap-1">
                            <GiftIcon className="h-2.5 w-2.5" /> {g.gift_count} gift{g.gift_count !== 1 ? "s" : ""}
                          </div>
                        </div>
                        <div className="text-amber-300 font-bold text-sm tabular-nums">{fmt(g.total_gifted)}</div>
                      </li>
                    );
                  })}
                </ul>
              )}
            </>
          )}
        </div>
      </DrawerContent>
    </Drawer>
  );
}

function EmptyState() {
  return (
    <div className="py-10 text-center">
      <div className="mx-auto h-20 w-20 rounded-full bg-gradient-to-br from-amber-400 to-fuchsia-500 flex items-center justify-center shadow-lg shadow-amber-900/40">
        <Sparkles className="h-10 w-10 text-white" />
      </div>
      <div className="mt-4 text-base font-semibold text-amber-200">Be the first to send a gift!</div>
      <div className="mt-1 text-xs text-white/60">Your name will appear here</div>
    </div>
  );
}

function Podium({ top3, currentUserId }: { top3: TopGifter[]; currentUserId: string | null }) {
  if (top3.length === 0) return null;
  // Render order: 2 / 1 / 3 visually; pad with nulls if fewer than 3
  const second = top3[1] ?? null;
  const first = top3[0] ?? null;
  const third = top3[2] ?? null;

  return (
    <div className="grid grid-cols-3 gap-2 items-end">
      <PodiumSlot rank={2} gifter={second} currentUserId={currentUserId} />
      <PodiumSlot rank={1} gifter={first} currentUserId={currentUserId} />
      <PodiumSlot rank={3} gifter={third} currentUserId={currentUserId} />
    </div>
  );
}

const podiumStyles: Record<number, { gradient: string; ring: string; crown: string; height: string; avatar: string; nameSize: string }> = {
  1: {
    gradient: "from-amber-400/40 to-amber-600/20",
    ring: "ring-amber-300",
    crown: "text-amber-300 drop-shadow-[0_0_8px_rgba(252,211,77,0.9)]",
    height: "min-h-[170px]",
    avatar: "h-16 w-16",
    nameSize: "text-sm",
  },
  2: {
    gradient: "from-slate-300/30 to-slate-500/10",
    ring: "ring-slate-200",
    crown: "text-slate-200",
    height: "min-h-[140px]",
    avatar: "h-12 w-12",
    nameSize: "text-xs",
  },
  3: {
    gradient: "from-amber-700/30 to-amber-900/10",
    ring: "ring-amber-700",
    crown: "text-amber-600",
    height: "min-h-[125px]",
    avatar: "h-12 w-12",
    nameSize: "text-xs",
  },
};

function PodiumSlot({ rank, gifter, currentUserId }: { rank: number; gifter: TopGifter | null; currentUserId: string | null }) {
  const s = podiumStyles[rank];
  const isMe = gifter && gifter.sender_id === currentUserId;
  return (
    <div
      className={cn(
        "rounded-2xl bg-gradient-to-b p-3 flex flex-col items-center text-center border border-white/10",
        s.gradient,
        s.height,
        rank === 1 && "relative overflow-hidden",
        isMe && "ring-2 ring-amber-400/80"
      )}
    >
      {rank === 1 && (
        <span
          aria-hidden
          className="pointer-events-none absolute inset-0 bg-gradient-to-r from-transparent via-white/20 to-transparent -translate-x-full animate-[shimmer_2.5s_ease-in-out_infinite]"
          style={{ animationName: "shimmer" }}
        />
      )}
      <Crown className={cn("h-5 w-5 mb-1", s.crown)} />
      {gifter ? (
        <>
          <Avatar className={cn(s.avatar, "ring-2", s.ring)}>
            <AvatarImage src={gifter.sender_avatar ?? undefined} />
            <AvatarFallback className="bg-purple-900 text-amber-200">
              {gifter.sender_name.slice(0, 1).toUpperCase()}
            </AvatarFallback>
          </Avatar>
          <div className={cn("mt-1.5 font-semibold truncate w-full", s.nameSize)}>
            {gifter.sender_name}
            {isMe && <span className="ml-1 text-[10px] text-amber-300">(You)</span>}
          </div>
          <div className="text-amber-300 font-bold text-sm tabular-nums leading-tight">{fmt(gifter.total_gifted)}</div>
          <div className="text-[10px] text-white/60">{gifter.gift_count} gift{gifter.gift_count !== 1 ? "s" : ""}</div>
        </>
      ) : (
        <div className="flex-1 flex items-center justify-center text-[10px] text-white/40">—</div>
      )}
      <div className="mt-auto pt-2 text-[10px] font-bold text-white/70">#{rank}</div>
      <style>{`@keyframes shimmer { 0% { transform: translateX(-100%);} 100% { transform: translateX(100%);} }`}</style>
    </div>
  );
}

// Safe re-export so callers don't need to know gift label internals
export { giftByType };
