// Astrologer-side lifetime Top Fans panel with time-range filter and stats.
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Crown, Gift as GiftIcon, Users, TrendingUp, Award } from "lucide-react";
import { cn } from "@/lib/utils";
import type { TopGifter } from "./TopGiftersDrawer";

type Range = "today" | "this_week" | "this_month" | "all_time";

interface GiftStats {
  total_gifts_received: number;
  total_gifts_value: number;
  unique_gifters: number;
  average_gift_size: number;
  biggest_single_gift: {
    amount: number;
    gift_type: string;
    sender_name: string;
    sender_avatar: string | null;
  } | null;
  gift_breakdown: { gift_type: string; count: number; total_value: number }[];
}

const fmt = (n: number) =>
  "₹" + Number(n || 0).toLocaleString("en-IN", { maximumFractionDigits: 0 });

export function TopFansPanel({ astrologerId }: { astrologerId: string }) {
  const [range, setRange] = useState<Range>("this_month");
  const [fans, setFans] = useState<TopGifter[]>([]);
  const [stats, setStats] = useState<GiftStats | null>(null);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (!astrologerId) return;
    let cancelled = false;
    setLoading(true);
    Promise.all([
      supabase.rpc("get_top_gifters_lifetime", { _astrologer_id: astrologerId, _time_range: range }),
      supabase.rpc("get_astrologer_gift_stats", { _astrologer_id: astrologerId, _time_range: range }),
    ]).then(([fansRes, statsRes]) => {
      if (cancelled) return;
      if (!fansRes.error && fansRes.data) setFans(fansRes.data as TopGifter[]);
      if (!statsRes.error && statsRes.data) setStats(statsRes.data as unknown as GiftStats);
      setLoading(false);
    });
    return () => { cancelled = true; };
  }, [astrologerId, range]);

  return (
    <div className="space-y-4">
      <Tabs value={range} onValueChange={(v) => setRange(v as Range)}>
        <TabsList className="grid grid-cols-4 w-full">
          <TabsTrigger value="today">Today</TabsTrigger>
          <TabsTrigger value="this_week">Week</TabsTrigger>
          <TabsTrigger value="this_month">Month</TabsTrigger>
          <TabsTrigger value="all_time">All time</TabsTrigger>
        </TabsList>
      </Tabs>

      {/* Stats grid */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <StatCard icon={<GiftIcon className="h-4 w-4" />} label="Total gifts" value={String(stats?.total_gifts_received ?? 0)} />
        <StatCard icon={<TrendingUp className="h-4 w-4" />} label="Total value" value={fmt(stats?.total_gifts_value ?? 0)} accent />
        <StatCard icon={<Users className="h-4 w-4" />} label="Unique fans" value={String(stats?.unique_gifters ?? 0)} />
        <StatCard icon={<Award className="h-4 w-4" />} label="Avg gift" value={fmt(stats?.average_gift_size ?? 0)} />
      </div>

      {/* Biggest gift */}
      {stats?.biggest_single_gift && (
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm flex items-center gap-2">
              <Crown className="h-4 w-4 text-amber-500" /> Biggest single gift
            </CardTitle>
          </CardHeader>
          <CardContent className="flex items-center gap-3">
            <Avatar className="h-10 w-10">
              <AvatarImage src={stats.biggest_single_gift.sender_avatar ?? undefined} />
              <AvatarFallback>{stats.biggest_single_gift.sender_name.slice(0, 1)}</AvatarFallback>
            </Avatar>
            <div className="flex-1 min-w-0">
              <div className="text-sm font-medium truncate">{stats.biggest_single_gift.sender_name}</div>
              <div className="text-xs text-muted-foreground capitalize">{stats.biggest_single_gift.gift_type}</div>
            </div>
            <div className="text-amber-600 dark:text-amber-400 font-bold">{fmt(stats.biggest_single_gift.amount)}</div>
          </CardContent>
        </Card>
      )}

      {/* Top fans list */}
      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="text-sm">Top Fans</CardTitle>
        </CardHeader>
        <CardContent>
          {loading ? (
            <div className="py-8 text-center text-sm text-muted-foreground">Loading…</div>
          ) : fans.length === 0 ? (
            <div className="py-8 text-center text-sm text-muted-foreground">
              No gifts received yet for this period.
            </div>
          ) : (
            <ul className="space-y-2">
              {fans.map((f, idx) => (
                <li key={f.sender_id} className={cn(
                  "flex items-center gap-3 rounded-lg px-2 py-2",
                  idx < 3 && "bg-amber-500/5"
                )}>
                  <span className="w-6 text-center text-xs font-bold text-muted-foreground">#{idx + 1}</span>
                  <Avatar className="h-8 w-8">
                    <AvatarImage src={f.sender_avatar ?? undefined} />
                    <AvatarFallback>{f.sender_name.slice(0, 1)}</AvatarFallback>
                  </Avatar>
                  <div className="flex-1 min-w-0">
                    <div className="text-sm font-medium truncate">{f.sender_name}</div>
                    <div className="text-[11px] text-muted-foreground">{f.gift_count} gift{f.gift_count !== 1 ? "s" : ""}</div>
                  </div>
                  <div className="text-amber-600 dark:text-amber-400 font-bold tabular-nums text-sm">
                    {fmt(f.total_gifted)}
                  </div>
                </li>
              ))}
            </ul>
          )}
        </CardContent>
      </Card>

      {/* Gift breakdown */}
      {stats?.gift_breakdown && stats.gift_breakdown.length > 0 && (
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm">Gift breakdown</CardTitle>
          </CardHeader>
          <CardContent>
            <ul className="grid grid-cols-2 sm:grid-cols-3 gap-2">
              {stats.gift_breakdown.map((b) => (
                <li key={b.gift_type} className="rounded-md border bg-card px-2.5 py-2">
                  <div className="text-xs capitalize font-medium">{b.gift_type}</div>
                  <div className="text-[11px] text-muted-foreground">{b.count} sent</div>
                  <div className="text-amber-600 dark:text-amber-400 font-semibold text-sm">{fmt(b.total_value)}</div>
                </li>
              ))}
            </ul>
          </CardContent>
        </Card>
      )}
    </div>
  );
}

function StatCard({ icon, label, value, accent }: { icon: React.ReactNode; label: string; value: string; accent?: boolean }) {
  return (
    <div className={cn(
      "rounded-xl border bg-card px-3 py-3",
      accent && "bg-amber-500/5 border-amber-500/30"
    )}>
      <div className="flex items-center gap-1.5 text-xs text-muted-foreground">{icon} {label}</div>
      <div className={cn("mt-1 text-lg font-bold tabular-nums", accent && "text-amber-600 dark:text-amber-400")}>
        {value}
      </div>
    </div>
  );
}
