// Floating "Live in progress" indicator shown across the astrologer dashboard
// when the astrologer has an active live_streams row. Tapping returns them to /astrologer/live.
import { useEffect, useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { useAstrologerAccount } from "@/hooks/useAstrologerAccount";
import { Radio } from "lucide-react";

export function AstrologerLiveIndicator() {
  const { astro } = useAstrologerAccount();
  const navigate = useNavigate();
  const location = useLocation();
  const [hasLive, setHasLive] = useState(false);

  useEffect(() => {
    if (!astro) { setHasLive(false); return; }
    let cancelled = false;
    async function check() {
      const { data } = await supabase
        .from("live_streams")
        .select("id")
        .eq("astrologer_id", astro!.id)
        .eq("status", "live")
        .maybeSingle();
      if (!cancelled) setHasLive(!!data);
    }
    check();
    const ch = supabase
      .channel(`astro_live_indicator_${astro.id}`)
      .on(
        "postgres_changes",
        { event: "*", schema: "public", table: "live_streams", filter: `astrologer_id=eq.${astro.id}` },
        check,
      )
      .subscribe();
    return () => { cancelled = true; supabase.removeChannel(ch); };
  }, [astro]);

  // Hide on the broadcast page itself
  if (!hasLive || location.pathname.startsWith("/astrologer/live")) return null;

  return (
    <button
      onClick={() => navigate("/astrologer/live")}
      className="fixed bottom-4 right-4 z-40 flex items-center gap-2 rounded-full bg-red-600 px-4 py-2 text-sm font-semibold text-white shadow-lg shadow-red-900/40 hover:bg-red-700 animate-pulse"
    >
      <Radio className="h-4 w-4" />
      <span>Live in progress · Return</span>
    </button>
  );
}
