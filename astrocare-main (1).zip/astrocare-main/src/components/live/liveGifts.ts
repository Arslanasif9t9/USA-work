// Gift catalog for AstroLive. Shared between picker and animations.
import { Crown, Flower2, Gem, Moon, Sparkles, Star, type LucideIcon } from "lucide-react";

export type LiveGiftType = "star" | "rose" | "diamond" | "crown" | "moonlight" | "blessing";

export interface LiveGiftDef {
  type: LiveGiftType;
  label: string;
  amount: number;
  emoji: string;
  Icon: LucideIcon;
  /** Tailwind gradient class for card background */
  gradient: string;
  /** Tailwind glow / accent color */
  accent: string;
  /** Premium gifts trigger full-screen burst */
  premium?: boolean;
}

export const LIVE_GIFTS: LiveGiftDef[] = [
  { type: "star",      label: "Star",      amount: 21,   emoji: "⭐", Icon: Star,     gradient: "from-violet-500/30 to-purple-700/20", accent: "text-violet-300" },
  { type: "rose",      label: "Rose",      amount: 51,   emoji: "🌹", Icon: Flower2,  gradient: "from-rose-500/30 to-pink-700/20",     accent: "text-rose-300" },
  { type: "diamond",   label: "Diamond",   amount: 101,  emoji: "💎", Icon: Gem,      gradient: "from-cyan-400/30 to-sky-700/20",      accent: "text-cyan-300" },
  { type: "crown",     label: "Crown",     amount: 251,  emoji: "👑", Icon: Crown,    gradient: "from-amber-400/40 to-yellow-700/20",  accent: "text-amber-300", premium: true },
  { type: "moonlight", label: "Moonlight", amount: 501,  emoji: "🌙", Icon: Moon,     gradient: "from-indigo-400/30 to-blue-900/20",   accent: "text-indigo-200", premium: true },
  { type: "blessing",  label: "Blessing",  amount: 1001, emoji: "✨", Icon: Sparkles, gradient: "from-amber-200/40 to-amber-600/20",   accent: "text-amber-200", premium: true },
];

export const giftByType = (t: string): LiveGiftDef | undefined =>
  LIVE_GIFTS.find((g) => g.type === t);

/** Soft chime via Web Audio API (no asset required) */
export function playGiftChime() {
  try {
    const Ctx = (window.AudioContext || (window as any).webkitAudioContext);
    if (!Ctx) return;
    const ctx = new Ctx();
    const now = ctx.currentTime;
    [880, 1320, 1760].forEach((freq, i) => {
      const o = ctx.createOscillator();
      const g = ctx.createGain();
      o.type = "sine"; o.frequency.value = freq;
      g.gain.setValueAtTime(0.0001, now + i * 0.08);
      g.gain.exponentialRampToValueAtTime(0.18, now + i * 0.08 + 0.02);
      g.gain.exponentialRampToValueAtTime(0.0001, now + i * 0.08 + 0.4);
      o.connect(g).connect(ctx.destination);
      o.start(now + i * 0.08); o.stop(now + i * 0.08 + 0.45);
    });
    setTimeout(() => ctx.close().catch(() => {}), 1200);
  } catch { /* noop */ }
}
