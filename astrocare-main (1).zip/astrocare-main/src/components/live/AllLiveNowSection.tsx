// "🔴 Live on AstroGuide" + "Your Recent Lives" sections for the astrologer dashboard.
import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { useAstrologerAccount } from "@/hooks/useAstrologerAccount";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Card } from "@/components/ui/card";
import { Eye, Radio, Gift } from "lucide-react";
import { format, formatDistanceToNowStrict } from "date-fns";
import { getAstrologerImageUrl, getAstrologerImageSrcSet } from "@/lib/astrologerImage";

interface LiveRow {
  id: string;
  title: string;
  viewer_count: number;
  started_at: string;
  astrologer: { id: string; display_name: string; avatar_url: string | null } | null;
}

interface PastRow {
  id: string;
  title: string;
  started_at: string;
  ended_at: string | null;
  duration_seconds: number;
  peak_viewer_count: number;
  total_gifts_value: number;
}

export function AllLiveNowSection() {
  const { astro } = useAstrologerAccount();
  const navigate = useNavigate();
  const [lives, setLives] = useState<LiveRow[]>([]);
  const [past, setPast] = useState<PastRow[]>([]);

  useEffect(() => {
    let cancelled = false;
    async function loadLives() {
      const { data } = await supabase
        .from("live_streams")
        .select("id, title, viewer_count, started_at, astrologer:astrologers!live_streams_astrologer_id_fkey(id, display_name, avatar_url)")
        .eq("status", "live")
        .order("viewer_count", { ascending: false })
        .limit(20);
      if (cancelled || !data) return;
      const filtered = (data as unknown as LiveRow[]).filter((r) => r.astrologer?.id !== astro?.id);
      setLives(filtered);
    }
    loadLives();
    const ch = supabase
      .channel(`all_live_now_${Math.random().toString(36).slice(2)}`)
      .on("postgres_changes", { event: "*", schema: "public", table: "live_streams" }, loadLives)
      .subscribe();
    return () => { cancelled = true; supabase.removeChannel(ch); };
  }, [astro?.id]);

  useEffect(() => {
    if (!astro) return;
    let cancelled = false;
    (async () => {
      const { data } = await supabase
        .from("live_streams")
        .select("id, title, started_at, ended_at, duration_seconds, peak_viewer_count, total_gifts_value")
        .eq("astrologer_id", astro.id)
        .eq("status", "ended")
        .order("started_at", { ascending: false })
        .limit(10);
      if (!cancelled && data) setPast(data as PastRow[]);
    })();
    return () => { cancelled = true; };
  }, [astro?.id]);

  return (
    <div className="space-y-6">
      <Card className="border-white/10 bg-[#0E1628] text-white p-6">
        <div className="mb-3 flex items-center gap-2">
          <span className="relative flex h-2.5 w-2.5">
            <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-red-400 opacity-75" />
            <span className="relative inline-flex h-2.5 w-2.5 rounded-full bg-red-500" />
          </span>
          <p className="font-semibold">Live on AstroGuide</p>
        </div>
        {lives.length === 0 ? (
          <p className="text-sm text-white/50 py-4 text-center">No one is live right now. Be the first!</p>
        ) : (
          <div className="flex gap-3 overflow-x-auto pb-2 -mx-1 px-1">
            {lives.map((l) => (
              <button
                key={l.id}
                onClick={() => navigate("/live")}
                className="shrink-0 w-44 rounded-xl bg-white/5 border border-white/10 hover:border-amber-300/50 transition p-3 text-left"
              >
                <div className="relative mx-auto w-fit">
                  <Avatar className="h-16 w-16 ring-2 ring-amber-400 ring-offset-2 ring-offset-[#0E1628] animate-pulse">
                    <AvatarImage src={getAstrologerImageUrl(l.astrologer?.avatar_url, "thumbnail")} srcSet={getAstrologerImageSrcSet(l.astrologer?.avatar_url, "thumbnail")} loading="lazy" className="object-cover object-[center_top]" />
                    <AvatarFallback>{l.astrologer?.display_name?.slice(0, 1) ?? "?"}</AvatarFallback>
                  </Avatar>
                  <span className="absolute -bottom-1 left-1/2 -translate-x-1/2 px-1.5 py-0.5 rounded text-[9px] font-bold bg-red-600 text-white">LIVE</span>
                </div>
                <div className="mt-3 truncate text-sm font-semibold">{l.astrologer?.display_name ?? "—"}</div>
                <div className="text-[11px] text-white/60 truncate">{l.title}</div>
                <div className="mt-1.5 flex items-center justify-between text-[11px] text-white/70">
                  <span className="flex items-center gap-1"><Eye className="h-3 w-3" /> {l.viewer_count}</span>
                  <span>{formatDistanceToNowStrict(new Date(l.started_at))}</span>
                </div>
              </button>
            ))}
          </div>
        )}
      </Card>

      <Card className="border-white/10 bg-[#0E1628] text-white p-6">
        <p className="font-semibold mb-3">Your Recent Lives</p>
        {past.length === 0 ? (
          <p className="text-sm text-white/50 py-4 text-center">No past lives yet.</p>
        ) : (
          <div className="space-y-2">
            {past.map((p) => {
              const min = Math.round(p.duration_seconds / 60);
              const earnings = Number(p.total_gifts_value ?? 0) * 0.30;
              return (
                <div key={p.id} className="flex items-center justify-between rounded-xl border border-white/5 bg-white/5 p-3">
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-sm font-semibold">{p.title}</p>
                    <p className="text-[11px] text-white/50">
                      {format(new Date(p.started_at), "dd MMM, hh:mm a")} · {min} min · 👁 peak {p.peak_viewer_count}
                    </p>
                  </div>
                  <div className="text-right">
                    <div className="text-xs text-amber-300 flex items-center gap-1 justify-end">
                      <Gift className="h-3 w-3" /> ₹{Number(p.total_gifts_value ?? 0).toFixed(0)}
                    </div>
                    <div className="text-xs text-emerald-300 font-semibold">+ ₹{earnings.toFixed(0)}</div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </Card>
    </div>
  );
}
