// Customer-facing gift selection popup for AstroLive.
import { useEffect, useMemo, useState } from "react";
import { Dialog, DialogContent, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { useWallet, formatINR } from "@/hooks/useWallet";
import { Gift, Loader2, Lock, Plus, Sparkles, Wallet } from "lucide-react";
import { toast } from "sonner";
import { cn } from "@/lib/utils";
import { LIVE_GIFTS, type LiveGiftDef } from "./liveGifts";
import { useNavigate } from "react-router-dom";

interface Props {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  liveStreamId: string;
  astrologerName: string;
  astrologerAvatar?: string | null;
}

export function LiveGiftPicker({ open, onOpenChange, liveStreamId, astrologerName, astrologerAvatar }: Props) {
  const { user } = useAuth();
  const { wallet } = useWallet();
  const navigate = useNavigate();
  const balance = wallet?.balance ?? 0;
  const [selected, setSelected] = useState<LiveGiftDef | null>(null);
  const [note, setNote] = useState("");
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    if (!open) {
      const t = setTimeout(() => { setSelected(null); setNote(""); setSubmitting(false); }, 200);
      return () => clearTimeout(t);
    }
  }, [open]);

  const cheapest = LIVE_GIFTS[0].amount;
  const lowBalance = balance < cheapest;

  const isAffordable = useMemo(() => (g: LiveGiftDef) => balance >= g.amount, [balance]);

  async function send() {
    if (!user) { toast.error("Please sign in first"); return; }
    if (!selected) return;
    if (!isAffordable(selected)) { toast.error("Add credits to send this gift"); return; }
    console.log("[LiveGift] sending", { liveStreamId, type: selected.type, amount: selected.amount });
    setSubmitting(true);
    const { data, error } = await supabase.rpc("send_live_gift_atomic", {
      _live_stream_id: liveStreamId,
      _gift_type: selected.type,
      _customer_note: note.trim() || null,
    });
    setSubmitting(false);
    if (error) {
      console.error("[LiveGift] RPC error", error);
      const m = error.message || "";
      if (/insufficient/i.test(m)) toast.error("Add credits to send this gift");
      else if (/no longer live/i.test(m)) toast.error("Stream is no longer live");
      else toast.error(m || "Could not send gift");
      return;
    }
    console.log("[LiveGift] sent OK", data);
    toast.success(`Sent ${selected.label} ${selected.emoji}`);
    onOpenChange(false);
  }

  return (
    <Dialog open={open} onOpenChange={(v) => !submitting && onOpenChange(v)}>
      <DialogContent
        onInteractOutside={(e) => submitting && e.preventDefault()}
        onEscapeKeyDown={(e) => submitting && e.preventDefault()}
        className="
          max-w-md w-full overflow-hidden border-2 border-amber-500/40
          bg-gradient-to-b from-[#1a0a2e] to-[#0f0620] p-0 text-white shadow-2xl shadow-purple-900/50
          sm:rounded-3xl
          fixed bottom-0 left-1/2 -translate-x-1/2 translate-y-0 top-auto
          rounded-t-3xl rounded-b-none
          max-h-[88vh] overflow-y-auto
          data-[state=open]:animate-in data-[state=closed]:animate-out
          data-[state=closed]:slide-out-to-bottom data-[state=open]:slide-in-from-bottom
          sm:bottom-auto sm:top-1/2 sm:-translate-y-1/2 sm:rounded-3xl
          sm:data-[state=open]:zoom-in-95 sm:data-[state=closed]:zoom-out-95
          sm:data-[state=open]:slide-in-from-top-0 sm:data-[state=closed]:slide-out-to-top-0
        "
      >
        {/* Decorative bg */}
        <div className="pointer-events-none absolute inset-0 opacity-30 [background-image:radial-gradient(white_1px,transparent_1px)] [background-size:24px_24px]" />
        <div className="pointer-events-none absolute -top-24 -left-24 h-56 w-56 rounded-full bg-amber-500/30 blur-3xl" />
        <div className="pointer-events-none absolute -bottom-24 -right-24 h-56 w-56 rounded-full bg-purple-600/40 blur-3xl" />

        {/* Drag handle (mobile sheet affordance) */}
        <div className="sm:hidden flex justify-center pt-2">
          <span className="h-1.5 w-12 rounded-full bg-white/30" />
        </div>

        <div className="relative px-5 pb-[calc(env(safe-area-inset-bottom)+1.25rem)] pt-4 sm:pt-6">
          {/* Header */}
          <div className="flex items-start justify-between gap-3">
            <div className="flex items-center gap-2.5 min-w-0">
              <Avatar className="h-10 w-10 ring-2 ring-amber-300/50">
                <AvatarImage src={astrologerAvatar ?? undefined} />
                <AvatarFallback>{astrologerName.slice(0, 1)}</AvatarFallback>
              </Avatar>
              <div className="min-w-0">
                <DialogTitle className="font-serif text-base font-bold leading-tight truncate">
                  Send a gift to <span className="text-amber-300">{astrologerName}</span>
                </DialogTitle>
                <DialogDescription className="text-[11px] text-white/60 mt-0.5">
                  Show your appreciation on Live
                </DialogDescription>
              </div>
            </div>
            <div className="text-right shrink-0">
              <div className="flex items-center justify-end gap-1 text-[10px] text-white/60">
                <Wallet className="h-3 w-3" /> Wallet
              </div>
              <div className="text-sm font-semibold text-amber-300 tabular-nums">{formatINR(balance)}</div>
              {lowBalance && (
                <button
                  onClick={() => { onOpenChange(false); navigate("/wallet"); }}
                  className="mt-0.5 inline-flex items-center gap-0.5 text-[10px] font-semibold text-amber-200 underline-offset-2 hover:underline"
                >
                  <Plus className="h-3 w-3" /> Add Credits
                </button>
              )}
            </div>
          </div>

          {/* Gift grid */}
          <div className="mt-4 grid grid-cols-3 gap-2">
            {LIVE_GIFTS.map((g) => {
              const sel = selected?.type === g.type;
              const aff = isAffordable(g);
              const Icon = g.Icon;
              return (
                <button
                  key={g.type}
                  type="button"
                  disabled={!aff}
                  onClick={() => setSelected(g)}
                  className={cn(
                    "group relative aspect-square rounded-2xl border bg-gradient-to-br p-2 transition-all overflow-hidden",
                    g.gradient,
                    sel
                      ? "border-amber-300 border-2 scale-105 shadow-[0_0_24px_rgba(251,191,36,0.55)]"
                      : "border-white/10 hover:border-amber-300/60 hover:scale-[1.02] hover:brightness-110",
                    !aff && "opacity-40 cursor-not-allowed grayscale"
                  )}
                >
                  {sel && (
                    <span className="pointer-events-none absolute inset-0 animate-pulse bg-gradient-to-tr from-transparent via-amber-200/20 to-transparent" />
                  )}
                  {!aff && (
                    <Lock className="absolute right-1.5 top-1.5 h-3 w-3 text-white/70" />
                  )}
                  <div className="flex h-full flex-col items-center justify-center gap-1">
                    <Icon className={cn("h-7 w-7 drop-shadow-[0_0_8px_currentColor]", g.accent)} />
                    <div className="text-[11px] font-semibold leading-none text-white">{g.label}</div>
                    <div className="text-[11px] font-bold leading-none text-amber-300 tabular-nums">₹{g.amount}</div>
                  </div>
                </button>
              );
            })}
          </div>

          {/* Note */}
          <div className="mt-4">
            <Textarea
              value={note}
              onChange={(e) => setNote(e.target.value.slice(0, 200))}
              placeholder={`Write a message for ${astrologerName}… (optional)`}
              rows={2}
              className="resize-none rounded-xl border-white/15 bg-white/10 text-sm text-white placeholder:text-white/40 focus-visible:ring-amber-300"
            />
            <p className="mt-1 text-right text-[10px] text-white/40">{note.length}/200</p>
          </div>

          {/* Action */}
          <Button
            onClick={send}
            disabled={!selected || submitting || (selected != null && !isAffordable(selected))}
            className="mt-3 h-12 w-full rounded-xl bg-gradient-to-r from-amber-300 via-amber-400 to-amber-500 text-base font-bold text-black shadow-lg shadow-amber-900/30 hover:from-amber-200 hover:to-amber-400 disabled:opacity-50"
          >
            {submitting ? (
              <><Loader2 className="h-4 w-4 animate-spin" /> Sending…</>
            ) : selected ? (
              <><Gift className="h-4 w-4" /> Send {selected.label} · ₹{selected.amount}</>
            ) : lowBalance ? (
              <><Plus className="h-4 w-4" /> Add Credits to Send Gifts</>
            ) : (
              <><Sparkles className="h-4 w-4" /> Choose a gift</>
            )}
          </Button>
          <button
            onClick={() => onOpenChange(false)}
            className="mt-2 block w-full text-center text-xs font-medium text-white/50 transition hover:text-white/80"
          >
            Cancel
          </button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
