// Customer co-host overlay — shown to a viewer who is currently on a Public Call
// inside a live stream. Publishes the customer's mic + camera to the same Agora
// channel as the host, shows duration / live cost / wallet, and lets them end.
import { useEffect, useRef, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { useWallet, formatINR } from "@/hooks/useWallet";
import { Button } from "@/components/ui/button";
import { Mic, MicOff, Video, VideoOff, Camera, PhoneOff, Wallet } from "lucide-react";
import { toast } from "sonner";
import { cn } from "@/lib/utils";
import { fetchAgoraToken, loadAgoraSDK, uidFromUserId } from "@/lib/agora";

interface Props {
  requestId: string;
  channelName: string;
  ratePerMin: number;
  /** "audio" => publish mic only; "video" => publish mic + cam. Defaults to video. */
  mediaType?: "audio" | "video";
  /** Called once cleanup is complete and we're back to audience role. */
  onEnded: () => void;
}

function fmtTime(sec: number) {
  const m = Math.floor(sec / 60), s = sec % 60;
  return `${m}:${s.toString().padStart(2, "0")}`;
}

export function LivePublicCoHost({ requestId, channelName, ratePerMin, mediaType = "video", onEnded }: Props) {
  const { user } = useAuth();
  const { wallet, refresh: refreshWallet } = useWallet();
  const [muted, setMuted] = useState(false);
  const [videoOff, setVideoOff] = useState(false);
  const [duration, setDuration] = useState(0);
  const [ending, setEnding] = useState(false);
  const [confirmEnd, setConfirmEnd] = useState(false);
  const previewRef = useRef<HTMLDivElement>(null);
  const clientRef = useRef<any>(null);
  const audioRef = useRef<any>(null);
  const videoRef = useRef<any>(null);
  const camerasRef = useRef<MediaDeviceInfo[]>([]);
  const camIdxRef = useRef(0);
  const startedAtRef = useRef<number>(Date.now());
  const endingRef = useRef(false);

  // Connect to Agora as host
  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const AgoraRTC = await loadAgoraSDK();
        const uid = uidFromUserId(user?.id) + 100000;
        const { token, appId } = await fetchAgoraToken({ channelName, uid, role: "host" });
        if (cancelled) return;
        const client = AgoraRTC.createClient({ mode: "live", codec: "vp8" });
        await client.setClientRole("host");
        await client.join(appId, channelName, token, uid);

        const mic = await AgoraRTC.createMicrophoneAudioTrack();
        let cam: any = null;
        if (mediaType === "video") {
          cam = await AgoraRTC.createCameraVideoTrack();
        }
        if (cancelled) {
          try { mic.close(); cam?.close(); await client.leave(); } catch {}
          return;
        }
        const tracks = cam ? [mic, cam] : [mic];
        await client.publish(tracks);
        clientRef.current = client;
        audioRef.current = mic;
        videoRef.current = cam;
        if (cam && previewRef.current) cam.play(previewRef.current);
        if (mediaType === "video") {
          try {
            const all = await navigator.mediaDevices.enumerateDevices();
            camerasRef.current = all.filter((d) => d.kind === "videoinput");
          } catch {}
        } else {
          // audio-only: keep camera UI off
          setVideoOff(true);
        }
      } catch (e: any) {
        toast.error(
          /permission/i.test(e?.message ?? "") ? "Microphone permission required"
            : (e?.message ?? "Could not start co-host stream")
        );
        await endCall("system_balance");
      }
    })();

    return () => {
      cancelled = true;
      cleanup();
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [channelName, mediaType]);

  function cleanup() {
    try { audioRef.current?.stop(); audioRef.current?.close(); } catch {}
    try { videoRef.current?.stop(); videoRef.current?.close(); } catch {}
    try { clientRef.current?.leave(); } catch {}
    audioRef.current = null;
    videoRef.current = null;
    clientRef.current = null;
  }

  // Duration ticker
  useEffect(() => {
    const id = setInterval(() => setDuration(Math.floor((Date.now() - startedAtRef.current) / 1000)), 1000);
    return () => clearInterval(id);
  }, []);

  // Periodic wallet refresh + auto-end on insufficient balance
  useEffect(() => {
    const id = setInterval(() => { refreshWallet(); }, 15000);
    return () => clearInterval(id);
  }, [refreshWallet]);

  // Per-minute billing tick: charge customer wallet every 60s during the call
  useEffect(() => {
    const id = setInterval(async () => {
      if (endingRef.current) return;
      const { data, error } = await supabase.rpc("bill_live_call_minute", { _request_id: requestId });
      if (error) { console.warn("[CoHost] bill failed", error); return; }
      const r = data as any;
      if (r?.auto_end) {
        endCall("system_balance");
      } else {
        refreshWallet();
      }
    }, 60000);
    return () => clearInterval(id);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [requestId]);

  const liveMinutes = Math.max(1, Math.ceil(duration / 60));
  const liveCost = liveMinutes * ratePerMin;
  const balance = wallet?.balance ?? 0;
  const lowBalance = balance < ratePerMin; // less than 1 more minute

  // Auto-end when customer can no longer afford next minute
  useEffect(() => {
    if (!wallet) return;
    if (balance < ratePerMin && duration > 30 && !endingRef.current) {
      endCall("system_balance");
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [balance, duration]);

  // Listen for the request being ended remotely (astrologer ends or admin)
  useEffect(() => {
    const ch = supabase
      .channel(`lcr_cohost_${requestId}`)
      .on(
        "postgres_changes",
        { event: "UPDATE", schema: "public", table: "live_call_requests", filter: `id=eq.${requestId}` },
        (p) => {
          const r = p.new as any;
          if (r.status === "ended" && !endingRef.current) {
            endingRef.current = true;
            cleanup();
            const total = Number(r.total_cost ?? 0);
            toast.success(`Call ended. Total: ${formatINR(total)}`);
            refreshWallet();
            onEnded();
          }
        }
      )
      .subscribe();
    return () => { supabase.removeChannel(ch); };
  }, [requestId, onEnded, refreshWallet]);

  async function endCall(reason: "customer" | "system_balance" = "customer") {
    if (endingRef.current) return;
    endingRef.current = true;
    setEnding(true);
    cleanup();
    const { data, error } = await supabase.rpc("end_live_call", {
      _request_id: requestId, _ended_by: reason,
    });
    if (error) { toast.error(error.message); }
    else {
      const r = data as any;
      const total = Number(r?.total_cost ?? 0);
      if (reason === "system_balance")
        toast.error(`Call ended — balance exhausted. Total ${formatINR(total)}`);
      else
        toast.success(`Call ended. Total: ${formatINR(total)} · ${fmtTime(duration)}`);
    }
    refreshWallet();
    onEnded();
  }

  async function toggleMic() {
    const next = !muted; setMuted(next);
    try { await audioRef.current?.setEnabled(!next); } catch {}
  }
  async function toggleCam() {
    const next = !videoOff; setVideoOff(next);
    try { await videoRef.current?.setEnabled(!next); } catch {}
  }
  async function switchCamera() {
    if (!videoRef.current || camerasRef.current.length < 2) {
      toast.info("No alternate camera detected"); return;
    }
    camIdxRef.current = (camIdxRef.current + 1) % camerasRef.current.length;
    try { await videoRef.current.setDevice(camerasRef.current[camIdxRef.current].deviceId); }
    catch { toast.error("Could not switch camera"); }
  }

  return (
    <div className="fixed inset-0 z-[60] bg-black text-white flex flex-col">
      {/* Top status bar */}
      <div className="px-4 pt-[calc(env(safe-area-inset-top)+0.75rem)] pb-3 bg-gradient-to-b from-black/80 to-transparent flex items-center justify-between">
        <span className="px-2 py-1 bg-amber-400 text-black text-xs font-bold rounded inline-flex items-center gap-1.5">
          <span className="h-1.5 w-1.5 rounded-full bg-black animate-pulse" />
          🔴 You're Live
        </span>
        <div className="text-xs flex items-center gap-3">
          <span className="tabular-nums">⏱ {fmtTime(duration)}</span>
          <span className="text-amber-300 font-semibold tabular-nums">{formatINR(liveCost)}</span>
          <span className={cn("flex items-center gap-1 tabular-nums", lowBalance ? "text-red-300" : "text-emerald-300")}>
            <Wallet className="h-3 w-3" /> {formatINR(balance)}
          </span>
        </div>
      </div>

      {/* Local self-preview */}
      <div className="relative flex-1 bg-black">
        <div ref={previewRef} className="absolute inset-0 [&>div]:!w-full [&>div]:!h-full [&_video]:!object-cover" />
        {videoOff && (
          <div className="absolute inset-0 flex items-center justify-center bg-gradient-to-br from-purple-900 to-fuchsia-900 text-center">
            <div>
              <VideoOff className="h-12 w-12 mx-auto opacity-70" />
              <p className="text-sm mt-2 text-white/70">Camera off</p>
            </div>
          </div>
        )}
        {lowBalance && (
          <div className="absolute top-4 left-1/2 -translate-x-1/2 px-3 py-1.5 rounded-full bg-red-500/90 text-xs font-semibold animate-pulse">
            Low balance — call will end soon
          </div>
        )}
      </div>

      {/* Bottom controls */}
      <div className="p-4 pb-[calc(env(safe-area-inset-bottom)+1rem)] bg-gradient-to-t from-black/90 to-transparent">
        <div className="flex items-center justify-center gap-4">
          <button onClick={toggleMic}
            className={cn(
              "h-14 w-14 rounded-full flex items-center justify-center",
              muted ? "bg-red-500" : "bg-white/15 hover:bg-white/25"
            )}>
            {muted ? <MicOff className="h-6 w-6" /> : <Mic className="h-6 w-6" />}
          </button>
          <button onClick={toggleCam}
            className={cn(
              "h-14 w-14 rounded-full flex items-center justify-center",
              videoOff ? "bg-red-500" : "bg-white/15 hover:bg-white/25"
            )}>
            {videoOff ? <VideoOff className="h-6 w-6" /> : <Video className="h-6 w-6" />}
          </button>
          <button onClick={switchCamera}
            className="h-14 w-14 rounded-full bg-white/15 hover:bg-white/25 flex items-center justify-center">
            <Camera className="h-6 w-6" />
          </button>
          <button onClick={() => setConfirmEnd(true)} disabled={ending}
            className="h-16 w-16 rounded-full bg-red-600 hover:bg-red-700 flex items-center justify-center shadow-xl shadow-red-900/50">
            <PhoneOff className="h-7 w-7" />
          </button>
        </div>
        <div className="text-center text-[11px] text-white/50 mt-3">
          Tap red phone to end the call
        </div>
      </div>

      {confirmEnd && (
        <div className="absolute inset-0 z-10 bg-black/70 backdrop-blur-sm flex items-center justify-center p-6">
          <div className="rounded-2xl bg-gradient-to-b from-[#1a0a2e] to-[#0f0620] border border-white/10 p-6 max-w-sm w-full text-center">
            <PhoneOff className="h-10 w-10 mx-auto text-red-400 mb-3" />
            <h3 className="font-semibold text-lg">End the call?</h3>
            <p className="text-sm text-white/60 mt-1">You'll be charged {formatINR(liveCost)} for {liveMinutes} min.</p>
            <div className="grid grid-cols-2 gap-2 mt-5">
              <Button variant="outline" onClick={() => setConfirmEnd(false)} className="bg-white/5 border-white/20 text-white">Stay</Button>
              <Button onClick={() => endCall("customer")} disabled={ending} className="bg-red-600 hover:bg-red-700 text-white">
                {ending ? "Ending…" : "End Call"}
              </Button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
