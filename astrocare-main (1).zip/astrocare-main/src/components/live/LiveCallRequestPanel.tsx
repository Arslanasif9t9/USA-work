// Astrologer-side floating panel showing pending public/private call requests.
import { useEffect, useRef, useState } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { Radio, Lock, Phone, X, ChevronRight } from "lucide-react";
import { toast } from "sonner";
import { cn } from "@/lib/utils";

interface RequestRow {
  id: string;
  customer_id: string;
  request_type: "public" | "private";
  media_type: "audio" | "video";
  rate_per_min: number;
  requested_at: string;
  customer_name: string;
  customer_avatar: string | null;
}

interface Props {
  astrologerId: string;
  liveStreamId: string;
}

/** Tiny chime via WebAudio (no asset). */
function chime() {
  try {
    const Ctx = (window as any).AudioContext || (window as any).webkitAudioContext;
    if (!Ctx) return;
    const ctx = new Ctx();
    const o = ctx.createOscillator();
    const g = ctx.createGain();
    o.type = "sine";
    o.frequency.value = 880;
    g.gain.value = 0.0001;
    o.connect(g).connect(ctx.destination);
    o.start();
    g.gain.exponentialRampToValueAtTime(0.18, ctx.currentTime + 0.05);
    o.frequency.exponentialRampToValueAtTime(1320, ctx.currentTime + 0.25);
    g.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + 0.7);
    setTimeout(() => { try { o.stop(); ctx.close(); } catch {} }, 800);
  } catch {}
}

export function LiveCallRequestPanel({ astrologerId, liveStreamId }: Props) {
  const [requests, setRequests] = useState<RequestRow[]>([]);
  const [open, setOpen] = useState(true);
  const [now, setNow] = useState(Date.now());
  const knownIds = useRef<Set<string>>(new Set());

  // 1s ticker for "Xs remaining" counter
  useEffect(() => {
    const id = setInterval(() => setNow(Date.now()), 1000);
    return () => clearInterval(id);
  }, []);

  // Hydrate profiles for a list of pending rows
  async function hydrate(rows: any[]): Promise<RequestRow[]> {
    if (!rows.length) return [];
    const ids = Array.from(new Set(rows.map((r) => r.customer_id)));
    const { data: profiles } = await supabase
      .from("profiles")
      .select("id, name, avatar_url")
      .in("id", ids);
    const map = new Map((profiles ?? []).map((p) => [p.id, p]));
    return rows.map((r) => ({
      id: r.id,
      customer_id: r.customer_id,
      request_type: r.request_type,
      media_type: (r.media_type ?? "video") as "audio" | "video",
      rate_per_min: Number(r.rate_per_min),
      requested_at: r.requested_at,
      customer_name: map.get(r.customer_id)?.name ?? "Viewer",
      customer_avatar: map.get(r.customer_id)?.avatar_url ?? null,
    }));
  }

  // Initial load + realtime subscription
  useEffect(() => {
    let mounted = true;
    (async () => {
      const { data } = await supabase
        .from("live_call_requests")
        .select("id, customer_id, request_type, media_type, rate_per_min, requested_at")
        .eq("astrologer_id", astrologerId)
        .eq("live_stream_id", liveStreamId)
        .eq("status", "pending")
        .order("requested_at", { ascending: true });
      if (!mounted) return;
      const hydrated = await hydrate(data ?? []);
      hydrated.forEach((r) => knownIds.current.add(r.id));
      setRequests(hydrated);
    })();

    const ch = supabase
      .channel(`lcr_panel_${liveStreamId}_${Math.random().toString(36).slice(2)}`)
      .on(
        "postgres_changes",
        { event: "INSERT", schema: "public", table: "live_call_requests", filter: `astrologer_id=eq.${astrologerId}` },
        async (p) => {
          const row = p.new as any;
          if (row.live_stream_id !== liveStreamId || row.status !== "pending") return;
          if (knownIds.current.has(row.id)) return;
          knownIds.current.add(row.id);
          const [hydrated] = await hydrate([row]);
          if (hydrated) {
            setRequests((cur) => [...cur, hydrated]);
            chime();
            setOpen(true);
          }
        }
      )
      .on(
        "postgres_changes",
        { event: "UPDATE", schema: "public", table: "live_call_requests", filter: `astrologer_id=eq.${astrologerId}` },
        (p) => {
          const r = p.new as any;
          if (r.status !== "pending") {
            setRequests((cur) => cur.filter((x) => x.id !== r.id));
          }
        }
      )
      .subscribe();
    return () => { mounted = false; supabase.removeChannel(ch); };
  }, [astrologerId, liveStreamId]);

  // Auto-cleanup expired (after 60s) on the client too
  useEffect(() => {
    setRequests((cur) => cur.filter((r) => (now - new Date(r.requested_at).getTime()) < 65000));
  }, [now]);

  const navigate = useNavigate();
  async function respond(id: string, action: "accept" | "reject") {
    const req = requests.find((x) => x.id === id);
    if (action === "accept" && req?.request_type === "private") {
      const proceed = window.confirm("Accepting will pause your live for other viewers. Continue?");
      if (!proceed) return;
    }
    const { data, error } = await supabase.rpc("respond_live_call_request", {
      _request_id: id, _action: action,
    });
    if (error) { toast.error(error.message); return; }
    const r = data as any;
    if (!r?.ok) { toast.error(r?.error ?? "Failed"); return; }
    setRequests((cur) => cur.filter((x) => x.id !== id));
    if (action === "accept" && r.request_type === "private" && r.call_session_id) {
      toast.success("Private call accepted — entering session…");
      navigate(`/astrologer/call/${r.call_session_id}`);
    }
  }

  if (requests.length === 0) return null;

  return (
    <div className="absolute right-0 top-24 z-40 max-w-[88vw]">
      {!open ? (
        <button
          onClick={() => setOpen(true)}
          className="flex items-center gap-2 px-3 py-2 rounded-l-xl bg-amber-500 text-black font-semibold shadow-xl animate-pulse"
        >
          <Phone className="h-4 w-4" />
          {requests.length} Request{requests.length > 1 ? "s" : ""}
          <ChevronRight className="h-4 w-4 rotate-180" />
        </button>
      ) : (
        <div className="w-80 max-w-[88vw] rounded-l-2xl bg-gradient-to-b from-[#1a0a2e]/95 to-[#0f0620]/95 backdrop-blur-xl border-l border-y border-amber-300/30 shadow-2xl text-white">
          <div className="flex items-center justify-between px-4 py-3 border-b border-white/10">
            <div className="font-semibold flex items-center gap-2">
              <Phone className="h-4 w-4 text-amber-300" />
              Pending Requests
              <span className="px-1.5 py-0.5 rounded-full bg-amber-400 text-black text-[10px] font-bold">
                {requests.length}
              </span>
            </div>
            <button onClick={() => setOpen(false)} className="h-7 w-7 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center">
              <X className="h-4 w-4" />
            </button>
          </div>
          <div className="max-h-[60vh] overflow-y-auto p-3 space-y-2">
            {requests.map((r) => {
              const elapsed = Math.floor((now - new Date(r.requested_at).getTime()) / 1000);
              const remaining = Math.max(0, 60 - elapsed);
              const isPublic = r.request_type === "public";
              return (
                <div key={r.id} className="rounded-xl bg-white/5 border border-white/10 p-3 space-y-2.5">
                  <div className="flex items-center gap-2.5">
                    <Avatar className="h-9 w-9 ring-2 ring-amber-300/40">
                      <AvatarImage src={r.customer_avatar ?? undefined} />
                      <AvatarFallback className="bg-purple-700 text-xs">{r.customer_name.slice(0, 1).toUpperCase()}</AvatarFallback>
                    </Avatar>
                    <div className="min-w-0 flex-1">
                      <div className="text-sm font-semibold truncate">{r.customer_name}</div>
                      <div className="flex items-center gap-1.5 mt-0.5">
                        <span className={cn(
                          "text-[10px] font-bold px-1.5 py-0.5 rounded inline-flex items-center gap-1",
                          isPublic ? "bg-amber-400 text-black" : "bg-purple-500 text-white"
                        )}>
                          {isPublic ? <Radio className="h-2.5 w-2.5" /> : <Lock className="h-2.5 w-2.5" />}
                          {isPublic ? "Public" : "Private"} {r.media_type === "audio" ? "Audio" : "Video"}
                        </span>
                        <span className="text-[10px] text-white/60 tabular-nums">₹{r.rate_per_min}/min</span>
                        <span className="text-[10px] text-white/50 tabular-nums">{remaining}s</span>
                      </div>
                    </div>
                  </div>
                  <div className="flex gap-2">
                    <Button
                      size="sm"
                      onClick={() => respond(r.id, "accept")}
                      className="flex-1 bg-emerald-500 hover:bg-emerald-600 text-white font-semibold"
                    >
                      Accept
                    </Button>
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => respond(r.id, "reject")}
                      className="flex-1 bg-transparent border-red-400/40 text-red-300 hover:bg-red-500/10"
                    >
                      Decline
                    </Button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
}
