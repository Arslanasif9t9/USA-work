// Shown to viewers (not the customer in the private call) while astrologer is in
// a private 1-on-1 session. Auto-disappears when live_streams.is_paused_for_private flips back.
import { Sparkles } from "lucide-react";

interface Props {
  astrologerName: string;
}

export function LivePauseOverlay({ astrologerName }: Props) {
  return (
    <div className="absolute inset-0 z-30 flex flex-col items-center justify-center bg-black/65 backdrop-blur-md text-center px-6 animate-in fade-in duration-300">
      <div className="relative mb-5">
        <span className="absolute inset-0 -m-3 rounded-full bg-amber-300/20 animate-ping" />
        <span className="absolute inset-0 -m-1 rounded-full bg-amber-300/30 animate-pulse" />
        <div className="relative h-20 w-20 rounded-full bg-gradient-to-br from-amber-400 to-amber-600 flex items-center justify-center shadow-2xl shadow-amber-900/50">
          <Sparkles className="h-9 w-9 text-white" />
        </div>
      </div>
      <h2 className="text-xl font-bold text-white">{astrologerName} is in a private session</h2>
      <p className="text-sm text-white/70 mt-2 max-w-xs">Will be back soon — please stay tuned.</p>
      <div className="mt-4 flex items-center gap-1.5">
        <span className="h-2 w-2 rounded-full bg-amber-300 animate-bounce" />
        <span className="h-2 w-2 rounded-full bg-amber-300 animate-bounce [animation-delay:0.2s]" />
        <span className="h-2 w-2 rounded-full bg-amber-300 animate-bounce [animation-delay:0.4s]" />
      </div>
      <p className="text-[11px] text-white/50 mt-4">Usually back within 5–10 minutes</p>
    </div>
  );
}
