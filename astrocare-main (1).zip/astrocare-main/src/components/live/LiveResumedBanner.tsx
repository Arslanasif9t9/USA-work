// Brief celebratory banner shown when the live resumes after a private session.
import { useEffect, useState } from "react";
import { Sparkles } from "lucide-react";

interface Props {
  astrologerName: string;
  onDone: () => void;
}

export function LiveResumedBanner({ astrologerName, onDone }: Props) {
  const [visible, setVisible] = useState(true);
  useEffect(() => {
    const t = setTimeout(() => setVisible(false), 3500);
    const t2 = setTimeout(onDone, 4000);
    return () => { clearTimeout(t); clearTimeout(t2); };
  }, [onDone]);

  return (
    <div
      className={`absolute top-20 left-1/2 -translate-x-1/2 z-40 px-5 py-2.5 rounded-full bg-gradient-to-r from-amber-400 to-fuchsia-500 text-white text-sm font-semibold shadow-xl shadow-amber-900/40 flex items-center gap-2 transition-all duration-500 ${
        visible ? "opacity-100 translate-y-0" : "opacity-0 -translate-y-4"
      }`}
    >
      <Sparkles className="h-4 w-4 animate-spin-slow" />
      ✨ {astrologerName} is back!
    </div>
  );
}
