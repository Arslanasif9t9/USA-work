// Customer popup for requesting a Public or Private call during a live stream.
// Handles confirmation → waiting state → response (accepted/rejected/expired).
import { useEffect, useRef, useState } from "react";
import { Dialog, DialogContent } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { useWallet, formatINR } from "@/hooks/useWallet";
import { useWaitingTone } from "@/hooks/useWaitingTone";
import { Phone, PhoneOff, Radio, Lock, Wallet, X } from "lucide-react";
import { toast } from "sonner";
import { useNavigate } from "react-router-dom";
import { cn } from "@/lib/utils";

type RequestType = "public" | "private";

interface Props {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  requestType: RequestType;
  /** "audio" or "video" — defaults to video for back-compat. */
  mediaType?: "audio" | "video";
  liveStreamId: string;
  astrologerName: string;
  astrologerAvatar: string | null;
  ratePerMin: number;
  /** Notified when astrologer accepts — parent should switch to co-host UI. */
  onAccepted: (requestId: string) => void;
}

type Phase = "confirm" | "waiting" | "rejected" | "expired";

export function LiveCallRequestModal({
  open, onOpenChange, requestType, mediaType = "video", liveStreamId,
  astrologerName, astrologerAvatar, ratePerMin, onAccepted,
}: Props) {
  const { user } = useAuth();
  const { wallet } = useWallet();
  const navigate = useNavigate();
  const [phase, setPhase] = useState<Phase>("confirm");
  const [requestId, setRequestId] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [secondsLeft, setSecondsLeft] = useState(60);
  const balance = wallet?.balance ?? 0;
  const minBalance = ratePerMin * 2;
  const lowBalance = balance < minBalance;
  const phaseRef = useRef<Phase>("confirm");
  phaseRef.current = phase;

  useWaitingTone(open && phase === "waiting");

  // Reset whenever closed
  useEffect(() => {
    if (!open) {
      setPhase("confirm");
      setRequestId(null);
      setSecondsLeft(60);
      setBusy(false);
    }
  }, [open]);

  // 60s countdown during waiting
  useEffect(() => {
    if (phase !== "waiting" || !requestId) return;
    setSecondsLeft(60);
    const id = setInterval(() => {
      setSecondsLeft((s) => {
        if (s <= 1) {
          clearInterval(id);
          // Auto-cancel
          (async () => {
            await supabase.rpc("cancel_live_call_request", { _request_id: requestId });
            if (phaseRef.current === "waiting") {
              setPhase("expired");
              setTimeout(() => onOpenChange(false), 1800);
            }
          })();
          return 0;
        }
        return s - 1;
      });
    }, 1000);
    return () => clearInterval(id);
  }, [phase, requestId, onOpenChange]);

  // Subscribe to status changes on this request
  useEffect(() => {
    if (!requestId || phase !== "waiting") return;
    const ch = supabase
      .channel(`lcr_${requestId}`)
      .on(
        "postgres_changes",
        { event: "UPDATE", schema: "public", table: "live_call_requests", filter: `id=eq.${requestId}` },
        (p) => {
          const r = p.new as any;
          if (r.status === "accepted") {
            onAccepted(requestId);
            onOpenChange(false);
          } else if (r.status === "rejected") {
            setPhase("rejected");
            setTimeout(() => onOpenChange(false), 2000);
          } else if (r.status === "cancelled" || r.status === "expired" || r.status === "ended") {
            onOpenChange(false);
          }
        }
      )
      .subscribe();
    return () => { supabase.removeChannel(ch); };
  }, [requestId, phase, onAccepted, onOpenChange]);

  async function submit() {
    if (busy) return;
    setBusy(true);
    const { data, error } = await supabase.rpc("request_live_call", {
      _live_stream_id: liveStreamId,
      _request_type: requestType,
      _media_type: mediaType,
    });
    setBusy(false);
    if (error) {
      toast.error(error.message ?? "Could not send request");
      return;
    }
    const r = data as any;
    if (!r?.ok) {
      toast.error(r?.error ?? "Request failed");
      return;
    }
    setRequestId(r.request_id);
    setPhase("waiting");
  }

  async function cancel() {
    if (!requestId) { onOpenChange(false); return; }
    await supabase.rpc("cancel_live_call_request", { _request_id: requestId });
    onOpenChange(false);
  }

  const isPublic = requestType === "public";
  const accentClass = isPublic
    ? "from-amber-500/20 to-fuchsia-500/20 border-amber-300/40"
    : "from-purple-600/20 to-indigo-600/20 border-purple-300/40";

  return (
    <Dialog open={open} onOpenChange={(v) => { if (!v && phase === "waiting") cancel(); else onOpenChange(v); }}>
      <DialogContent
        className={cn(
          "max-w-md p-0 overflow-hidden border-2 rounded-3xl",
          "bg-gradient-to-b from-[#1a0a2e] to-[#0f0620] text-white",
          isPublic ? "border-amber-300/40" : "border-purple-300/40"
        )}
      >
        {phase === "confirm" && (
          <div className="p-6 space-y-5">
            <div className="flex flex-col items-center text-center">
              <div className={cn(
                "h-20 w-20 rounded-full flex items-center justify-center mb-3 bg-gradient-to-br shadow-lg shadow-purple-900/40",
                accentClass
              )}>
                {isPublic
                  ? <Radio className="h-10 w-10 text-amber-300" />
                  : <Lock className="h-10 w-10 text-purple-200" />}
              </div>
              <h2 className="text-xl font-bold">
                {isPublic ? "Join the Live Publicly" : `Private Call with ${astrologerName}`}
              </h2>
              <p className="text-sm text-white/70 mt-2">
                {isPublic
                  ? `You'll talk with ${astrologerName} and ALL viewers will see and hear you. Your camera and microphone will be on.`
                  : `Have a private 1-on-1 conversation. The live stream will pause for other viewers.`}
              </p>
              {isPublic && (
                <div className="mt-3 text-[11px] text-white/50">
                  💡 Be respectful. The astrologer can end the call anytime.
                </div>
              )}
            </div>

            <div className="rounded-2xl bg-white/5 backdrop-blur border border-white/10 p-4 space-y-1.5">
              <div className="flex justify-between text-sm">
                <span className="text-white/60">Rate</span>
                <span className="font-semibold text-amber-300">{formatINR(ratePerMin)}/min</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-white/60">Minimum balance</span>
                <span className="font-semibold">{formatINR(minBalance)} (2 min)</span>
              </div>
              <div className="flex justify-between text-sm pt-1.5 border-t border-white/10">
                <span className="text-white/60 flex items-center gap-1.5"><Wallet className="h-3.5 w-3.5" /> Your wallet</span>
                <span className={cn("font-semibold", lowBalance ? "text-red-300" : "text-emerald-300")}>
                  {formatINR(balance)}
                </span>
              </div>
            </div>

            {lowBalance ? (
              <Button
                size="lg"
                className="w-full bg-gradient-to-r from-amber-500 to-fuchsia-500 text-white font-semibold h-12 rounded-xl"
                onClick={() => { onOpenChange(false); navigate("/wallet"); }}
              >
                Add Credits
              </Button>
            ) : (
              <Button
                size="lg"
                disabled={busy || !user}
                onClick={submit}
                className="w-full bg-gradient-to-r from-amber-500 to-amber-400 text-black font-bold h-12 rounded-xl shadow-lg shadow-amber-900/40 hover:opacity-95"
              >
                {busy ? "Sending request…" : (isPublic ? "Request to Join" : "Request Private Call")}
              </Button>
            )}
            <button onClick={() => onOpenChange(false)} className="block mx-auto text-xs text-white/50 hover:text-white/80">
              Cancel
            </button>
          </div>
        )}

        {phase === "waiting" && (
          <div className="p-8 flex flex-col items-center text-center">
            <div className="relative h-32 w-32 mb-6">
              <span className="absolute inset-0 rounded-full bg-amber-400/20 animate-ping" />
              <span className="absolute inset-2 rounded-full bg-amber-400/30 animate-ping [animation-delay:0.4s]" />
              <span className="absolute inset-4 rounded-full bg-amber-400/40 animate-ping [animation-delay:0.8s]" />
              <Avatar className="absolute inset-6 h-20 w-20 ring-4 ring-amber-300/60">
                <AvatarImage src={astrologerAvatar ?? undefined} />
                <AvatarFallback>{astrologerName.slice(0, 1)}</AvatarFallback>
              </Avatar>
            </div>
            <h2 className="text-lg font-semibold">Waiting for {astrologerName}…</h2>
            <p className="text-sm text-white/60 mt-1">Your request has been sent</p>
            <p className="text-xs text-white/50 mt-4 tabular-nums">
              Auto-cancels in 0:{secondsLeft.toString().padStart(2, "0")}
            </p>
            <Button
              variant="outline"
              onClick={cancel}
              className="mt-6 bg-white/5 border-white/20 text-white hover:bg-white/10"
            >
              <X className="h-4 w-4 mr-1.5" /> Cancel Request
            </Button>
          </div>
        )}

        {phase === "rejected" && (
          <div className="p-8 flex flex-col items-center text-center">
            <PhoneOff className="h-12 w-12 text-red-400 mb-3" />
            <h2 className="text-lg font-semibold">Astrologer declined</h2>
            <p className="text-sm text-white/60 mt-1">
              Your hold has been refunded. Try again later or send a gift instead.
            </p>
          </div>
        )}

        {phase === "expired" && (
          <div className="p-8 flex flex-col items-center text-center">
            <Phone className="h-12 w-12 text-white/40 mb-3" />
            <h2 className="text-lg font-semibold">No response</h2>
            <p className="text-sm text-white/60 mt-1">The astrologer didn't respond. Hold refunded.</p>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}
