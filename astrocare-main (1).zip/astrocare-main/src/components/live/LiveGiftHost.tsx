// Live gift overlay: floating cards + premium full-screen burst.
// Subscribes to live_gifts inserts for a stream and queues animations.
import { useEffect, useRef, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { giftByType, playGiftChime } from "./liveGifts";
import { cn } from "@/lib/utils";

export interface LiveGiftEvent {
  id: string;
  gift_type: string;
  customer_note: string | null;
  sender_id: string;
  sender_name: string;
  sender_avatar: string | null;
  created_at: string;
}

interface Props {
  liveStreamId: string;
  /** Called whenever a new gift arrives (after enrichment) */
  onGift?: (g: LiveGiftEvent) => void;
}

const FLOAT_DURATION_MS = 4000;
const PREMIUM_DURATION_MS = 2200;
const MAX_VISIBLE = 2;

export function LiveGiftHost({ liveStreamId, onGift }: Props) {
  const [floats, setFloats] = useState<LiveGiftEvent[]>([]);
  const [premium, setPremium] = useState<LiveGiftEvent | null>(null);
  const queueRef = useRef<LiveGiftEvent[]>([]);
  const seenRef = useRef<Set<string>>(new Set());

  // Realtime subscription
  useEffect(() => {
    if (!liveStreamId) return;
    const ch = supabase
      .channel(`live_gifts_${liveStreamId}_${Math.random().toString(36).slice(2)}`)
      .on(
        "postgres_changes",
        { event: "INSERT", schema: "public", table: "live_gifts", filter: `live_stream_id=eq.${liveStreamId}` },
        async (p) => {
          const row = p.new as any;
          if (seenRef.current.has(row.id)) return;
          seenRef.current.add(row.id);
          // Enrich sender (best-effort)
          let name = "Guest"; let avatar: string | null = null;
          try {
            const { data } = await supabase
              .from("profiles").select("name, avatar_url")
              .eq("id", row.sender_id).maybeSingle();
            if (data) { name = data.name || "Guest"; avatar = data.avatar_url ?? null; }
          } catch { /* ignore */ }
          const ev: LiveGiftEvent = {
            id: row.id,
            gift_type: row.gift_type,
            customer_note: row.customer_note ?? null,
            sender_id: row.sender_id,
            sender_name: name,
            sender_avatar: avatar,
            created_at: row.created_at,
          };
          onGift?.(ev);
          enqueue(ev);
        }
      )
      .subscribe();
    return () => { supabase.removeChannel(ch); };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [liveStreamId]);

  function enqueue(ev: LiveGiftEvent) {
    const def = giftByType(ev.gift_type);
    if (def?.premium) {
      // Show premium burst then chain to standard float
      setPremium(ev);
      try { playGiftChime(); } catch { /* noop */ }
      setTimeout(() => {
        setPremium((cur) => (cur?.id === ev.id ? null : cur));
        pushFloat(ev);
      }, PREMIUM_DURATION_MS);
    } else {
      pushFloat(ev);
    }
  }

  function pushFloat(ev: LiveGiftEvent) {
    setFloats((cur) => {
      if (cur.length < MAX_VISIBLE) return [...cur, ev];
      queueRef.current.push(ev);
      return cur;
    });
    setTimeout(() => {
      setFloats((cur) => cur.filter((x) => x.id !== ev.id));
      const next = queueRef.current.shift();
      if (next) setTimeout(() => pushFloat(next), 150);
    }, FLOAT_DURATION_MS);
  }

  return (
    <>
      {/* Floating cards stack — bottom-left, above input */}
      <div className="pointer-events-none absolute left-3 bottom-28 z-30 flex flex-col gap-2 max-w-[260px]">
        {floats.map((ev) => {
          const def = giftByType(ev.gift_type);
          if (!def) return null;
          const Icon = def.Icon;
          return (
            <div
              key={ev.id}
              className={cn(
                "rounded-xl border border-amber-300/40 bg-black/60 backdrop-blur-md p-2.5 shadow-lg",
                "animate-in slide-in-from-left-8 fade-in duration-300"
              )}
            >
              <div className="flex items-center gap-2">
                <div className={cn("flex h-9 w-9 items-center justify-center rounded-full bg-gradient-to-br", def.gradient, "shadow-[0_0_12px_currentColor]", def.accent)}>
                  <Icon className="h-5 w-5" />
                </div>
                <Avatar className="h-6 w-6 shrink-0">
                  <AvatarImage src={ev.sender_avatar ?? undefined} />
                  <AvatarFallback className="text-[9px]">{ev.sender_name.slice(0, 1).toUpperCase()}</AvatarFallback>
                </Avatar>
                <div className="min-w-0 text-[11px] leading-tight">
                  <div className="truncate font-semibold text-white">{ev.sender_name}</div>
                  <div className="text-amber-300">sent a {def.label} {def.emoji}</div>
                </div>
              </div>
              {ev.customer_note && (
                <div className="mt-1.5 italic text-[11px] text-white/70 line-clamp-2">"{ev.customer_note}"</div>
              )}
            </div>
          );
        })}
      </div>

      {/* Premium burst overlay */}
      {premium && (() => {
        const def = giftByType(premium.gift_type);
        if (!def) return null;
        const Icon = def.Icon;
        return (
          <div className="pointer-events-none fixed inset-0 z-40 flex items-center justify-center bg-black/40 animate-in fade-in zoom-in duration-300">
            {/* Confetti dots */}
            <div className="absolute inset-0 overflow-hidden">
              {Array.from({ length: 24 }).map((_, i) => (
                <span
                  key={i}
                  className="absolute h-1.5 w-1.5 rounded-full bg-amber-300 shadow-[0_0_6px_rgba(251,191,36,0.9)]"
                  style={{
                    left: "50%", top: "50%",
                    animation: `gift-burst 1.6s ease-out forwards`,
                    transform: `rotate(${i * 15}deg) translateY(0)`,
                    animationDelay: `${(i % 6) * 0.04}s`,
                  }}
                />
              ))}
            </div>
            <div className="relative flex flex-col items-center text-center">
              <div className={cn("flex h-44 w-44 items-center justify-center rounded-full bg-gradient-to-br shadow-[0_0_60px_rgba(251,191,36,0.7)] animate-[spin_2s_linear]", def.gradient)}>
                <Icon className={cn("h-24 w-24 drop-shadow-[0_0_20px_currentColor]", def.accent)} />
              </div>
              <div className="mt-4 px-5 py-2 rounded-full bg-black/60 border border-amber-300/40 backdrop-blur">
                <div className="text-sm font-bold text-white">
                  <span className="text-amber-300">{premium.sender_name}</span> sent a {def.label} {def.emoji}
                </div>
                {premium.customer_note && (
                  <div className="mt-1 text-xs italic text-white/80 max-w-[280px] truncate">"{premium.customer_note}"</div>
                )}
              </div>
            </div>
            <style>{`@keyframes gift-burst {
              0% { transform: rotate(var(--r,0)) translateY(0); opacity:1; }
              100% { transform: translate(calc(cos(var(--a,0deg)) * 240px), calc(sin(var(--a,0deg)) * 240px)) scale(0.4); opacity:0; }
            }`}</style>
          </div>
        );
      })()}
    </>
  );
}
