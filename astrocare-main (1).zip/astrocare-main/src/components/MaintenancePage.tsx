import { ShieldAlert } from "lucide-react";

export function MaintenancePage({ message }: { message: string }) {
  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-[#0F0A1E] via-[#1a1233] to-[#0F0A1E] text-white px-6">
      <div className="max-w-md text-center space-y-4">
        <div className="mx-auto h-16 w-16 rounded-2xl bg-amber-500/20 text-amber-300 flex items-center justify-center">
          <ShieldAlert className="h-8 w-8" />
        </div>
        <h1 className="text-3xl font-serif font-bold">We're upgrading the stars ✨</h1>
        <p className="text-white/70 whitespace-pre-wrap">{message}</p>
        <p className="text-xs text-white/40">If you're an admin, you can still access the admin panel.</p>
      </div>
    </div>
  );
}
