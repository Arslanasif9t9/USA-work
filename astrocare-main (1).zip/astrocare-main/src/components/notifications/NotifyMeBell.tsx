// Small bell button to opt in/out of "go-live" notifications for one astrologer.
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { useAuthDialog } from "@/components/auth/AuthDialog";
import { Bell, BellOff } from "lucide-react";
import { toast } from "sonner";
import { cn } from "@/lib/utils";

interface Props {
  astrologerId: string;
  astrologerName: string;
  className?: string;
  /** "icon" = small circular button (live header), "pill" = label + icon (profile page). */
  variant?: "icon" | "pill";
}

export function NotifyMeBell({ astrologerId, astrologerName, className, variant = "icon" }: Props) {
  const { user } = useAuth();
  const { open: openAuth } = useAuthDialog();
  const [enabled, setEnabled] = useState(false);
  const [busy, setBusy] = useState(false);
  const [shake, setShake] = useState(false);

  useEffect(() => {
    if (!user) return;
    let cancelled = false;
    (async () => {
      const { data } = await supabase
        .from("user_notification_preferences")
        .select("notify_on_live")
        .eq("user_id", user.id)
        .eq("target_id", astrologerId)
        .eq("target_type", "astrologer")
        .maybeSingle();
      if (!cancelled) setEnabled(Boolean(data?.notify_on_live));
    })();
    return () => { cancelled = true; };
  }, [user, astrologerId]);

  async function toggle() {
    if (!user) return openAuth();
    if (busy) return;
    setBusy(true);
    setShake(true);
    setTimeout(() => setShake(false), 400);
    const { data, error } = await supabase.rpc("toggle_notify_astrologer", { _astrologer_id: astrologerId });
    setBusy(false);
    if (error) { toast.error(error.message); return; }
    const next = Boolean((data as any)?.enabled);
    setEnabled(next);
    toast.success(
      next
        ? `You'll be notified when ${astrologerName} goes live`
        : `Notifications turned off for ${astrologerName}`
    );
  }

  if (variant === "pill") {
    return (
      <button
        onClick={toggle}
        disabled={busy}
        className={cn(
          "inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-semibold transition",
          enabled
            ? "bg-amber-400 text-black hover:bg-amber-300"
            : "bg-white/10 text-white border border-white/20 hover:bg-white/20",
          shake && "animate-bell-shake",
          className
        )}
      >
        {enabled ? <Bell className="h-3.5 w-3.5 fill-black" /> : <Bell className="h-3.5 w-3.5" />}
        {enabled ? "Notifying" : "Notify me"}
      </button>
    );
  }

  return (
    <button
      onClick={toggle}
      disabled={busy}
      aria-label={enabled ? "Stop notifications" : "Notify me when live"}
      className={cn(
        "h-8 w-8 rounded-full flex items-center justify-center transition",
        enabled
          ? "bg-amber-400 text-black"
          : "bg-white/15 backdrop-blur text-white hover:bg-white/25",
        shake && "animate-bell-shake",
        className
      )}
    >
      {enabled ? <Bell className="h-4 w-4 fill-black" /> : <BellOff className="h-4 w-4" />}
    </button>
  );
}
