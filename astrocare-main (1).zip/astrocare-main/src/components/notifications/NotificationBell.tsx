// Top-bar bell with unread count + dropdown list. Customer-side.
import { useEffect, useRef, useState } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { Bell, X, CheckCheck, Sparkles, Phone, Gift, Megaphone } from "lucide-react";
import { cn } from "@/lib/utils";
import { formatDistanceToNow } from "date-fns";

interface Notif {
  id: string;
  title: string;
  body: string | null;
  type: string;
  link: string | null;
  read: boolean;
  created_at: string;
}

const ICON: Record<string, JSX.Element> = {
  live_started: <Sparkles className="h-4 w-4 text-amber-300" />,
  live_resumed: <Sparkles className="h-4 w-4 text-amber-300" />,
  live_call_request: <Phone className="h-4 w-4 text-emerald-300" />,
  live_public_accepted: <Phone className="h-4 w-4 text-emerald-300" />,
  live_private_accepted: <Phone className="h-4 w-4 text-purple-300" />,
  live_private_ended: <Phone className="h-4 w-4 text-white/60" />,
  earning: <Gift className="h-4 w-4 text-amber-300" />,
  announcement: <Megaphone className="h-4 w-4 text-fuchsia-300" />,
};

interface Props {
  variant?: "dark" | "light";
  className?: string;
}

export function NotificationBell({ variant = "dark", className }: Props) {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [open, setOpen] = useState(false);
  const [items, setItems] = useState<Notif[]>([]);
  const [loading, setLoading] = useState(true);
  const containerRef = useRef<HTMLDivElement>(null);

  const unread = items.filter((n) => !n.read).length;

  // Initial load + realtime
  useEffect(() => {
    if (!user) { setItems([]); setLoading(false); return; }
    let mounted = true;
    (async () => {
      const { data } = await supabase
        .from("notifications")
        .select("id, title, body, type, link, read, created_at")
        .eq("user_id", user.id)
        .order("created_at", { ascending: false })
        .limit(40);
      if (mounted) {
        setItems((data ?? []) as Notif[]);
        setLoading(false);
      }
    })();

    let ch: ReturnType<typeof supabase.channel> | null = null;
    let isSubscribed = false;
    // CRITICAL: Realtime channels require this exact order:
    // 1. Create channel with supabase.channel(...)
    // 2. Register ALL .on('postgres_changes', ...) handlers
    // 3. ONLY THEN call .subscribe()
    // 4. Adding .on() after .subscribe() throws an error that breaks the bell
    // This has regressed multiple times — do NOT change this order.
    try {
      ch = supabase.channel(`notif_bell_${user.id}_${Date.now()}`);

      // Register ALL postgres_changes callbacks BEFORE calling subscribe()
      ch.on(
        "postgres_changes",
        { event: "INSERT", schema: "public", table: "notifications", filter: `user_id=eq.${user.id}` },
        (p) => {
          try {
            setItems((cur) => [p.new as Notif, ...cur].slice(0, 40));
          } catch (e) {
            console.warn("[NotificationBell] insert handler error", e);
          }
        }
      );

      ch.on(
        "postgres_changes",
        { event: "UPDATE", schema: "public", table: "notifications", filter: `user_id=eq.${user.id}` },
        (p) => {
          try {
            const n = p.new as Notif;
            setItems((cur) => cur.map((x) => x.id === n.id ? n : x));
          } catch (e) {
            console.warn("[NotificationBell] update handler error", e);
          }
        }
      );

      // Subscribe LAST. After this point, do NOT add more .on() handlers.
      ch.subscribe((status) => {
        if (status === "SUBSCRIBED") isSubscribed = true;
        if (status === "CHANNEL_ERROR" || status === "TIMED_OUT") {
          console.warn("[NotificationBell] subscribe status:", status);
        }
      });
    } catch (e) {
      console.error("[NotificationBell] failed to set up realtime channel", e);
    }
    return () => {
      mounted = false;
      if (ch) {
        try { supabase.removeChannel(ch); } catch (e) { console.warn("[NotificationBell] removeChannel error", e); }
      }
      void isSubscribed;
    };
  }, [user]);

  // Click outside to close
  useEffect(() => {
    if (!open) return;
    const onDoc = (e: MouseEvent) => {
      if (!containerRef.current?.contains(e.target as Node)) setOpen(false);
    };
    document.addEventListener("mousedown", onDoc);
    return () => document.removeEventListener("mousedown", onDoc);
  }, [open]);

  async function markAllRead() {
    if (!user || unread === 0) return;
    const ids = items.filter((n) => !n.read).map((n) => n.id);
    setItems((cur) => cur.map((n) => ({ ...n, read: true })));
    await supabase.from("notifications").update({ read: true }).in("id", ids);
  }

  async function openItem(n: Notif) {
    if (!n.read) {
      setItems((cur) => cur.map((x) => x.id === n.id ? { ...x, read: true } : x));
      await supabase.from("notifications").update({ read: true }).eq("id", n.id);
    }
    setOpen(false);
    if (n.link) navigate(n.link);
  }

  if (!user) return null;

  const btnBase = variant === "light"
    ? "text-foreground hover:bg-muted"
    : "text-white hover:bg-white/10";

  return (
    <div ref={containerRef} className={cn("relative", className)}>
      <button
        onClick={() => setOpen((v) => !v)}
        aria-label="Notifications"
        className={cn(
          "relative h-9 w-9 rounded-full flex items-center justify-center transition",
          btnBase
        )}
      >
        <Bell className="h-5 w-5" />
        {unread > 0 && (
          <span className="absolute top-0.5 right-0.5 min-w-[16px] h-4 px-1 rounded-full bg-red-500 text-white text-[10px] font-bold flex items-center justify-center">
            {unread > 9 ? "9+" : unread}
          </span>
        )}
      </button>

      {open && (
        <div className="absolute right-0 top-full mt-2 w-80 max-w-[calc(100vw-2rem)] z-50 rounded-2xl bg-card border border-border shadow-2xl overflow-hidden animate-in fade-in slide-in-from-top-2 duration-150">
          <div className="px-4 py-3 flex items-center justify-between border-b border-border">
            <div className="font-semibold text-sm text-foreground">Notifications</div>
            <div className="flex items-center gap-1">
              {unread > 0 && (
                <button
                  onClick={markAllRead}
                  className="text-[11px] text-muted-foreground hover:text-foreground inline-flex items-center gap-1"
                >
                  <CheckCheck className="h-3 w-3" /> Mark all read
                </button>
              )}
              <button onClick={() => setOpen(false)} className="ml-1 h-6 w-6 rounded-full hover:bg-muted flex items-center justify-center">
                <X className="h-3.5 w-3.5" />
              </button>
            </div>
          </div>
          <div className="max-h-96 overflow-y-auto">
            {loading ? (
              <div className="p-6 text-center text-xs text-muted-foreground">Loading…</div>
            ) : items.length === 0 ? (
              <div className="p-8 text-center">
                <Bell className="h-8 w-8 mx-auto text-muted-foreground/40 mb-2" />
                <div className="text-sm font-medium text-foreground">No notifications yet</div>
                <div className="text-xs text-muted-foreground mt-1">We'll let you know when something happens.</div>
              </div>
            ) : (
              <ul className="divide-y divide-border">
                {items.map((n) => (
                  <li key={n.id}>
                    <button
                      onClick={() => openItem(n)}
                      className={cn(
                        "w-full text-left px-4 py-3 flex items-start gap-3 hover:bg-muted/60 transition",
                        !n.read && "bg-amber-500/5"
                      )}
                    >
                      <div className="mt-0.5 shrink-0">
                        {ICON[n.type] ?? <Bell className="h-4 w-4 text-muted-foreground" />}
                      </div>
                      <div className="min-w-0 flex-1">
                        <div className="text-sm font-semibold text-foreground truncate flex items-center gap-2">
                          {n.title}
                          {!n.read && <span className="h-1.5 w-1.5 rounded-full bg-amber-500 shrink-0" />}
                        </div>
                        {n.body && <div className="text-xs text-muted-foreground line-clamp-2 mt-0.5">{n.body}</div>}
                        <div className="text-[10px] text-muted-foreground/70 mt-1">
                          {formatDistanceToNow(new Date(n.created_at), { addSuffix: true })}
                        </div>
                      </div>
                    </button>
                  </li>
                ))}
              </ul>
            )}
          </div>
          <div className="px-4 py-2 border-t border-border bg-muted/30">
            <button
              onClick={() => { setOpen(false); navigate("/notifications"); }}
              className="text-xs text-muted-foreground hover:text-foreground w-full text-center"
            >
              View all
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
