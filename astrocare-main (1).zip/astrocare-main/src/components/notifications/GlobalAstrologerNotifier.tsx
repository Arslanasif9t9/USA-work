import { useEffect, useRef, useState } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "@/contexts/AuthContext";
import { supabase } from "@/integrations/supabase/client";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { Check, X, MessageSquare, Phone, Loader2 } from "lucide-react";
import { toast } from "sonner";

type Kind = "chat" | "call";
interface IncomingRequest {
  kind: Kind;
  sessionId: string;
  customerId: string;
  customerName: string;
  customerAvatar: string | null;
  rate: number;
  requestedAt: string;
}

const RING_SIZE = 56;
const RING_RADIUS = 26;
const RING_CIRC = 2 * Math.PI * RING_RADIUS;

export function GlobalAstrologerNotifier() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [astrologerId, setAstrologerId] = useState<string | null>(null);
  const [request, setRequest] = useState<IncomingRequest | null>(null);
  const [secondsLeft, setSecondsLeft] = useState(60);
  const [acting, setActing] = useState<"accept" | "reject" | null>(null);
  const audioRef = useRef<HTMLAudioElement | null>(null);

  // Resolve astrologer row for this user (if any)
  useEffect(() => {
    if (!user) {
      setAstrologerId(null);
      return;
    }
    let cancelled = false;
    supabase
      .from("astrologers")
      .select("id")
      .eq("user_id", user.id)
      .maybeSingle()
      .then(({ data }) => {
        if (!cancelled) setAstrologerId((data?.id as string) ?? null);
      });
    return () => {
      cancelled = true;
    };
  }, [user]);

  // Subscribe to incoming chat (and call) requests for this astrologer
  // Use a ref so we don't resubscribe each time `request` changes.
  const requestRef = useRef<IncomingRequest | null>(null);
  useEffect(() => {
    requestRef.current = request;
  }, [request]);

  useEffect(() => {
    if (!astrologerId) return;

    const handleChatInsert = async (row: any) => {
      if (row.status !== "pending") return;
      if (requestRef.current) return; // one popup at a time
      const { data: prof } = await supabase
        .from("profiles")
        .select("name, avatar_url")
        .eq("id", row.user_id)
        .maybeSingle();
      setRequest({
        kind: "chat",
        sessionId: row.id,
        customerId: row.user_id,
        customerName: prof?.name || "Customer",
        customerAvatar: prof?.avatar_url ?? null,
        rate: Number(row.per_minute_rate),
        requestedAt: row.requested_at,
      });
    };

    const handleCallInsertOrUpdate = async (row: any) => {
      // Show popup as soon as call session is pending or ringing astrologer
      if (!["pending", "ringing_astrologer"].includes(row.status)) return;
      if (requestRef.current) return;
      const { data: prof } = await supabase
        .from("profiles")
        .select("name, avatar_url")
        .eq("id", row.user_id)
        .maybeSingle();
      setRequest({
        kind: "call",
        sessionId: row.id,
        customerId: row.user_id,
        customerName: prof?.name || "Customer",
        customerAvatar: prof?.avatar_url ?? null,
        rate: Number(row.per_minute_rate),
        requestedAt: row.initiated_at ?? row.created_at,
      });
    };

    const handleStatusChange = (row: any) => {
      const cur = requestRef.current;
      if (!cur || row.id !== cur.sessionId) return;
      const closed =
        cur.kind === "chat"
          ? row.status !== "pending"
          : !["pending", "ringing_astrologer"].includes(row.status);
      if (closed) setRequest(null);
    };

    let ch: ReturnType<typeof supabase.channel> | null = null;
    try {
      ch = supabase
        .channel(`astro-notify:${astrologerId}:${Date.now()}`)
        .on(
          "postgres_changes",
          { event: "INSERT", schema: "public", table: "chat_sessions", filter: `astrologer_id=eq.${astrologerId}` },
          (p) => { try { handleChatInsert(p.new); } catch (e) { console.warn("[AstroNotifier] chat insert error", e); } },
        )
        .on(
          "postgres_changes",
          { event: "UPDATE", schema: "public", table: "chat_sessions", filter: `astrologer_id=eq.${astrologerId}` },
          (p) => { try { handleStatusChange(p.new); } catch (e) { console.warn("[AstroNotifier] chat status error", e); } },
        )
        .on(
          "postgres_changes",
          { event: "INSERT", schema: "public", table: "call_sessions", filter: `astrologer_id=eq.${astrologerId}` },
          (p) => { try { handleCallInsertOrUpdate(p.new); } catch (e) { console.warn("[AstroNotifier] call insert error", e); } },
        )
        .on(
          "postgres_changes",
          { event: "UPDATE", schema: "public", table: "call_sessions", filter: `astrologer_id=eq.${astrologerId}` },
          (p) => {
            try {
              if (requestRef.current) handleStatusChange(p.new);
              else handleCallInsertOrUpdate(p.new);
            } catch (e) { console.warn("[AstroNotifier] call update error", e); }
          },
        )
        .subscribe((status) => {
          console.log("[AstroNotifier] subscribe status:", status);
        });
    } catch (e) {
      console.error("[AstroNotifier] failed to set up realtime channel", e);
    }

    // Also poll for any pending requests we may have missed (e.g. just logged in)
    const fetchPending = async () => {
      if (requestRef.current) return;
      const { data: chat } = await supabase
        .from("chat_sessions")
        .select("id, user_id, per_minute_rate, requested_at, status")
        .eq("astrologer_id", astrologerId)
        .eq("status", "pending")
        .order("requested_at", { ascending: false })
        .limit(1);
      if (chat && chat[0]) { handleChatInsert(chat[0]); return; }
      const { data: call } = await supabase
        .from("call_sessions")
        .select("id, user_id, per_minute_rate, initiated_at, created_at, status")
        .eq("astrologer_id", astrologerId)
        .in("status", ["pending", "ringing_astrologer"])
        .order("initiated_at", { ascending: false })
        .limit(1);
      if (call && call[0]) handleCallInsertOrUpdate(call[0]);
    };
    fetchPending();

    return () => {
      if (ch) {
        try { supabase.removeChannel(ch); } catch (e) { console.warn("[AstroNotifier] removeChannel error", e); }
      }
    };
  }, [astrologerId]);

  // Countdown
  useEffect(() => {
    if (!request) return;
    const startedAt = new Date(request.requestedAt).getTime();
    const tick = () => {
      const remaining = 60 - Math.floor((Date.now() - startedAt) / 1000);
      if (remaining <= 0) {
        setSecondsLeft(0);
        setRequest(null);
        toast.message("Request timed out", { description: "The customer was not answered in time." });
        return;
      }
      setSecondsLeft(remaining);
    };
    tick();
    const id = setInterval(tick, 500);
    return () => clearInterval(id);
  }, [request]);

  // Subtle ringtone
  useEffect(() => {
    if (!request) return;
    try {
      audioRef.current?.play().catch(() => {});
    } catch {}
  }, [request]);

  const respond = async (action: "accept" | "reject") => {
    if (!request) return;
    setActing(action);

    if (request.kind === "call") {
      const rpc = action === "accept" ? "accept_call_session" : "decline_call_session";
      const { data, error } = await supabase.rpc(rpc, { _session_id: request.sessionId });
      setActing(null);
      if (error || (data as any)?.error) {
        toast.error((data as any)?.error ?? error?.message ?? "Failed to respond");
        return;
      }
      const sid = request.sessionId;
      setRequest(null);
      if (action === "accept") navigate(`/astrologer/call/${sid}`);
      else toast.success("Call declined");
      return;
    }

    const { data, error } = await supabase.functions.invoke("respond-chat", {
      body: { session_id: request.sessionId, action },
    });
    setActing(null);
    if (error || (data as any)?.error) {
      toast.error((data as any)?.error ?? error?.message ?? "Failed to respond");
      return;
    }
    if (action === "accept") {
      const sid = request.sessionId;
      setRequest(null);
      navigate(`/astrologer/chat/${sid}`);
    } else {
      setRequest(null);
      toast.success("Request declined");
    }
  };

  if (!request) return null;

  const initials = request.customerName.split(" ").map((p) => p[0]).join("").slice(0, 2).toUpperCase();
  const dashOffset = RING_CIRC * (1 - secondsLeft / 60);

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center bg-black/70 px-4 backdrop-blur-md animate-fade-in">
      <div className="relative w-full max-w-sm overflow-hidden rounded-3xl border border-white/10 bg-gradient-to-br from-[#1a1233] via-[#0f0a1e] to-[#1a1233] p-6 text-white shadow-2xl animate-scale-in">
        {/* Decorative starfield */}
        <div className="pointer-events-none absolute inset-0 opacity-30 [background-image:radial-gradient(white_1px,transparent_1px)] [background-size:24px_24px]" />

        <div className="relative flex flex-col items-center text-center">
          {/* Pulsing ring + avatar */}
          <div className="relative mb-4">
            <span className="absolute inset-0 -m-2 animate-ping rounded-full bg-amber-400/40" />
            <span className="absolute inset-0 -m-1 rounded-full bg-gradient-to-br from-amber-300 to-amber-600 opacity-80" />
            <Avatar className="relative h-24 w-24 ring-4 ring-amber-300/80">
              <AvatarImage src={request.customerAvatar ?? undefined} alt={request.customerName} className="object-cover" />
              <AvatarFallback className="bg-purple-700 text-2xl font-semibold">{initials}</AvatarFallback>
            </Avatar>
          </div>

          <span className="mb-1 inline-flex items-center gap-1.5 rounded-full bg-white/10 px-3 py-1 text-xs font-medium tracking-wide backdrop-blur">
            {request.kind === "chat" ? (
              <>
                <MessageSquare className="h-3.5 w-3.5 text-amber-300" /> Chat Request
              </>
            ) : (
              <>
                <Phone className="h-3.5 w-3.5 text-amber-300" /> Call Request
              </>
            )}
          </span>

          <h3 className="font-serif text-2xl font-bold tracking-wide">{request.customerName}</h3>
          <p className="mt-1 text-sm text-white/70">wants to connect with you</p>

          <div className="mt-3 inline-flex items-center gap-2 rounded-full bg-amber-400/10 px-3 py-1 text-sm font-semibold text-amber-200">
            ₹{request.rate} / min
          </div>

          {/* Countdown ring */}
          <div className="my-5 flex items-center gap-3">
            <div className="relative">
              <svg width={RING_SIZE} height={RING_SIZE} className="-rotate-90">
                <circle
                  cx={RING_SIZE / 2}
                  cy={RING_SIZE / 2}
                  r={RING_RADIUS}
                  stroke="rgba(255,255,255,0.15)"
                  strokeWidth="4"
                  fill="none"
                />
                <circle
                  cx={RING_SIZE / 2}
                  cy={RING_SIZE / 2}
                  r={RING_RADIUS}
                  stroke="hsl(var(--secondary))"
                  strokeWidth="4"
                  fill="none"
                  strokeLinecap="round"
                  strokeDasharray={RING_CIRC}
                  strokeDashoffset={dashOffset}
                  className="transition-[stroke-dashoffset] duration-500 ease-linear"
                />
              </svg>
              <span className="absolute inset-0 flex items-center justify-center text-sm font-bold">{secondsLeft}s</span>
            </div>
            <p className="text-left text-xs text-white/60">Auto-declines in<br />{secondsLeft} seconds</p>
          </div>

          <div className="grid w-full grid-cols-2 gap-3">
            <Button
              variant="outline"
              className="h-12 border-red-400/40 bg-red-500/10 text-red-200 hover:bg-red-500/20 hover:text-red-100"
              onClick={() => respond("reject")}
              disabled={!!acting}
            >
              {acting === "reject" ? <Loader2 className="h-4 w-4 animate-spin" /> : <X className="h-5 w-5" />}
              Decline
            </Button>
            <Button
              className="h-12 bg-gradient-to-r from-emerald-500 to-emerald-600 text-white hover:from-emerald-400 hover:to-emerald-500"
              onClick={() => respond("accept")}
              disabled={!!acting}
            >
              {acting === "accept" ? <Loader2 className="h-4 w-4 animate-spin" /> : <Check className="h-5 w-5" />}
              Accept
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}
