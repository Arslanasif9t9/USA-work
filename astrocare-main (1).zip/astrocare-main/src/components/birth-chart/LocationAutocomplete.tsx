import { useEffect, useRef, useState } from "react";
import { Input } from "@/components/ui/input";
import { Loader2, MapPin, AlertCircle } from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import tzlookup from "tz-lookup";

export interface LocationPick {
  display_name: string;
  lat: number;
  lon: number;
  timezone: string;
  country?: string;
}

interface NominatimAddress {
  city?: string;
  town?: string;
  village?: string;
  hamlet?: string;
  suburb?: string;
  state?: string;
  state_district?: string;
  county?: string;
  country?: string;
  country_code?: string;
}

interface NominatimResult {
  display_name: string;
  lat: string;
  lon: string;
  address?: NominatimAddress;
}

interface Props {
  value: LocationPick | null;
  onChange: (loc: LocationPick | null) => void;
  disabled?: boolean;
  placeholder?: string;
}

const NOMINATIM_URL = "https://nominatim.openstreetmap.org/search";
const DEBOUNCE_MS = 400;
const REQUEST_TIMEOUT_MS = 5000;
const CACHE_KEY = "ag_geocode_cache_v1";

// session-scoped cache to avoid duplicate calls per their fair-use policy
function readCache(): Record<string, LocationPick[]> {
  try {
    const raw = sessionStorage.getItem(CACHE_KEY);
    return raw ? JSON.parse(raw) : {};
  } catch {
    return {};
  }
}
function writeCache(cache: Record<string, LocationPick[]>) {
  try {
    sessionStorage.setItem(CACHE_KEY, JSON.stringify(cache));
  } catch {
    /* ignore quota */
  }
}

function safeTimezoneFor(lat: number, lon: number): string {
  try {
    return tzlookup(lat, lon);
  } catch {
    // Fallback: rough UTC offset
    const offset = Math.round(lon / 15);
    const sign = offset >= 0 ? "+" : "-";
    return `Etc/GMT${sign}${Math.abs(offset)}`;
  }
}

function formatDisplay(r: NominatimResult): string {
  const a = r.address ?? {};
  const place =
    a.city || a.town || a.village || a.hamlet || a.suburb || a.county;
  const parts = [place, a.state, a.country].filter(Boolean);
  return parts.length ? parts.join(", ") : r.display_name;
}

function mapResults(raw: NominatimResult[]): LocationPick[] {
  return raw.map((r) => {
    const lat = parseFloat(r.lat);
    const lon = parseFloat(r.lon);
    return {
      display_name: formatDisplay(r),
      lat,
      lon,
      timezone: safeTimezoneFor(lat, lon),
      country: r.address?.country,
    };
  });
}

// Major IANA zones for the manual fallback
const COMMON_TIMEZONES = [
  "Asia/Kolkata",
  "Asia/Dubai",
  "Asia/Karachi",
  "Asia/Dhaka",
  "Asia/Kathmandu",
  "Asia/Colombo",
  "Asia/Singapore",
  "Asia/Hong_Kong",
  "Asia/Tokyo",
  "Asia/Shanghai",
  "Asia/Bangkok",
  "Australia/Sydney",
  "Europe/London",
  "Europe/Paris",
  "Europe/Berlin",
  "Europe/Moscow",
  "America/New_York",
  "America/Chicago",
  "America/Denver",
  "America/Los_Angeles",
  "America/Toronto",
  "America/Sao_Paulo",
  "Africa/Johannesburg",
  "Pacific/Auckland",
  "UTC",
];

export function LocationAutocomplete({
  value,
  onChange,
  disabled,
  placeholder,
}: Props) {
  const [query, setQuery] = useState(value?.display_name ?? "");
  const [results, setResults] = useState<LocationPick[]>([]);
  const [loading, setLoading] = useState(false);
  const [open, setOpen] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [manualOpen, setManualOpen] = useState(false);
  const debounceRef = useRef<number | null>(null);
  const abortRef = useRef<AbortController | null>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  // Keep input text in sync if parent updates value (e.g. preload)
  useEffect(() => {
    if (value?.display_name && value.display_name !== query) {
      setQuery(value.display_name);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [value?.display_name]);

  useEffect(() => {
    if (debounceRef.current) window.clearTimeout(debounceRef.current);
    if (abortRef.current) abortRef.current.abort();

    const trimmed = query.trim();
    if (!trimmed || trimmed.length < 2 || trimmed === value?.display_name) {
      setResults([]);
      setLoading(false);
      setErrorMsg(null);
      return;
    }

    const cache = readCache();
    if (cache[trimmed.toLowerCase()]) {
      setResults(cache[trimmed.toLowerCase()]);
      setOpen(true);
      setErrorMsg(null);
      return;
    }

    debounceRef.current = window.setTimeout(async () => {
      setLoading(true);
      setErrorMsg(null);
      const controller = new AbortController();
      abortRef.current = controller;
      const timeoutId = window.setTimeout(
        () => controller.abort(),
        REQUEST_TIMEOUT_MS,
      );
      try {
        const url = `${NOMINATIM_URL}?q=${encodeURIComponent(
          trimmed,
        )}&format=json&addressdetails=1&limit=8`;
        // Browsers forbid setting User-Agent; Referer is auto-attached and
        // satisfies Nominatim's identification requirement.
        const resp = await fetch(url, {
          signal: controller.signal,
          headers: { Accept: "application/json" },
        });
        if (!resp.ok) throw new Error(`Search failed (${resp.status})`);
        const raw: NominatimResult[] = await resp.json();
        const mapped = mapResults(Array.isArray(raw) ? raw : []);
        setResults(mapped);
        setOpen(true);
        // cache it
        const next = readCache();
        next[trimmed.toLowerCase()] = mapped;
        writeCache(next);
      } catch (e: unknown) {
        if ((e as Error).name === "AbortError") {
          setErrorMsg(
            "Search timed out. Try again or enter coordinates manually.",
          );
        } else {
          setErrorMsg(
            "Couldn't search right now. Try again or enter coordinates manually.",
          );
        }
        setResults([]);
        setOpen(true);
      } finally {
        window.clearTimeout(timeoutId);
        setLoading(false);
      }
    }, DEBOUNCE_MS);

    return () => {
      if (debounceRef.current) window.clearTimeout(debounceRef.current);
    };
  }, [query, value?.display_name]);

  const handlePick = (loc: LocationPick) => {
    onChange(loc);
    setQuery(loc.display_name);
    setResults([]);
    setOpen(false);
    setErrorMsg(null);
    // Dismiss mobile keyboard
    inputRef.current?.blur();
  };

  return (
    <div className="relative">
      <div className="relative">
        <MapPin className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground pointer-events-none" />
        <Input
          ref={inputRef}
          value={query}
          onChange={(e) => {
            setQuery(e.target.value);
            if (value) onChange(null);
          }}
          onFocus={() => {
            if (results.length > 0 || errorMsg) setOpen(true);
          }}
          onBlur={() => setTimeout(() => setOpen(false), 200)}
          placeholder={placeholder ?? "Start typing your birth city…"}
          className="pl-9 h-11"
          disabled={disabled}
          autoComplete="off"
          inputMode="search"
        />
        {loading && (
          <Loader2 className="absolute right-3 top-1/2 -translate-y-1/2 h-4 w-4 animate-spin text-muted-foreground" />
        )}
      </div>

      {open && (results.length > 0 || errorMsg) && (
        <div className="absolute z-50 mt-1 w-full max-h-72 overflow-auto rounded-md border border-border bg-popover shadow-card-hover">
          {errorMsg ? (
            <div className="flex items-start gap-2 px-3 py-3 text-sm text-muted-foreground">
              <AlertCircle className="h-4 w-4 mt-0.5 text-destructive shrink-0" />
              <span>{errorMsg}</span>
            </div>
          ) : (
            results.map((r, i) => (
              <button
                key={`${r.lat}-${r.lon}-${i}`}
                type="button"
                onMouseDown={(e) => {
                  e.preventDefault();
                  handlePick(r);
                }}
                onTouchStart={(e) => {
                  e.preventDefault();
                  handlePick(r);
                }}
                className="block w-full text-left px-3 py-3 min-h-[44px] text-sm hover:bg-accent hover:text-accent-foreground active:bg-accent border-b border-border/50 last:border-b-0"
              >
                <div className="truncate font-medium">{r.display_name}</div>
                <div className="text-xs text-muted-foreground tabular-nums">
                  {r.lat.toFixed(4)}, {r.lon.toFixed(4)} · {r.timezone}
                </div>
              </button>
            ))
          )}
        </div>
      )}

      {open &&
        !loading &&
        !errorMsg &&
        query.trim().length >= 2 &&
        results.length === 0 &&
        query.trim() !== value?.display_name && (
          <div className="absolute z-50 mt-1 w-full rounded-md border border-border bg-popover px-3 py-2 text-sm text-muted-foreground shadow-card">
            No matching cities found.
          </div>
        )}

      <button
        type="button"
        onClick={() => setManualOpen(true)}
        disabled={disabled}
        className="mt-1.5 text-xs text-primary hover:underline disabled:opacity-50"
      >
        Can't find your city? Enter coordinates manually
      </button>

      <ManualLocationDialog
        open={manualOpen}
        onOpenChange={setManualOpen}
        initial={value}
        onSave={(loc) => {
          handlePick(loc);
          setManualOpen(false);
        }}
      />
    </div>
  );
}

/* ------------------------------ manual entry ----------------------------- */

interface ManualDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  initial: LocationPick | null;
  onSave: (loc: LocationPick) => void;
}

function ManualLocationDialog({
  open,
  onOpenChange,
  initial,
  onSave,
}: ManualDialogProps) {
  const [name, setName] = useState(initial?.display_name ?? "");
  const [country, setCountry] = useState(initial?.country ?? "");
  const [lat, setLat] = useState(initial?.lat?.toString() ?? "");
  const [lon, setLon] = useState(initial?.lon?.toString() ?? "");
  const [tz, setTz] = useState(initial?.timezone ?? "Asia/Kolkata");
  const [err, setErr] = useState<string | null>(null);

  useEffect(() => {
    if (open) {
      setName(initial?.display_name ?? "");
      setCountry(initial?.country ?? "");
      setLat(initial?.lat?.toString() ?? "");
      setLon(initial?.lon?.toString() ?? "");
      setTz(initial?.timezone ?? "Asia/Kolkata");
      setErr(null);
    }
  }, [open, initial]);

  // Auto-suggest a timezone from coords
  useEffect(() => {
    const la = parseFloat(lat);
    const lo = parseFloat(lon);
    if (!Number.isFinite(la) || !Number.isFinite(lo)) return;
    if (la < -90 || la > 90 || lo < -180 || lo > 180) return;
    try {
      const guessed = tzlookup(la, lo);
      if (guessed && !COMMON_TIMEZONES.includes(tz)) setTz(guessed);
    } catch {
      /* ignore */
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [lat, lon]);

  const handleSave = () => {
    setErr(null);
    if (!name.trim()) return setErr("Please enter a place name.");
    const la = parseFloat(lat);
    const lo = parseFloat(lon);
    if (!Number.isFinite(la) || la < -90 || la > 90)
      return setErr("Latitude must be a number between -90 and 90.");
    if (!Number.isFinite(lo) || lo < -180 || lo > 180)
      return setErr("Longitude must be a number between -180 and 180.");
    if (!tz) return setErr("Please pick a timezone.");
    onSave({
      display_name: name.trim(),
      lat: la,
      lon: lo,
      timezone: tz,
      country: country.trim() || undefined,
    });
  };

  // Build full timezone list — start with common, then any other from Intl
  const allZones = (() => {
    const base = new Set(COMMON_TIMEZONES);
    try {
      // @ts-expect-error - supportedValuesOf is widely shipped
      const more = Intl.supportedValuesOf?.("timeZone") as string[] | undefined;
      if (more) more.forEach((z) => base.add(z));
    } catch {
      /* ignore */
    }
    return Array.from(base).sort();
  })();

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle>Enter location manually</DialogTitle>
          <DialogDescription>
            Use this if your birth city isn't in our search results.
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-3">
          <div className="space-y-1.5">
            <Label htmlFor="ml-name">Place name</Label>
            <Input
              id="ml-name"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="e.g. My Village, District, India"
            />
          </div>

          <div className="grid grid-cols-2 gap-2">
            <div className="space-y-1.5">
              <Label htmlFor="ml-lat">Latitude</Label>
              <Input
                id="ml-lat"
                inputMode="decimal"
                value={lat}
                onChange={(e) => setLat(e.target.value)}
                placeholder="28.6139"
              />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="ml-lon">Longitude</Label>
              <Input
                id="ml-lon"
                inputMode="decimal"
                value={lon}
                onChange={(e) => setLon(e.target.value)}
                placeholder="77.2090"
              />
            </div>
          </div>

          <div className="space-y-1.5">
            <Label htmlFor="ml-country">Country (optional)</Label>
            <Input
              id="ml-country"
              value={country}
              onChange={(e) => setCountry(e.target.value)}
              placeholder="India"
            />
          </div>

          <div className="space-y-1.5">
            <Label>Timezone</Label>
            <Select value={tz} onValueChange={setTz}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent className="max-h-72">
                {allZones.map((z) => (
                  <SelectItem key={z} value={z}>
                    {z}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {err && (
            <p className="text-xs text-destructive">{err}</p>
          )}
        </div>

        <DialogFooter className="gap-2">
          <Button variant="ghost" onClick={() => onOpenChange(false)}>
            Cancel
          </Button>
          <Button onClick={handleSave}>Save location</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
