import { useState } from "react";
import { Link } from "react-router-dom";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Sparkles, MapPin, Calendar, Trash2, Pencil, Plus, Eye } from "lucide-react";
import { format } from "date-fns";
import { useBirthCharts, type BirthChartRow } from "@/hooks/useBirthCharts";
import { BirthChartModal } from "./BirthChartModal";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { Skeleton } from "@/components/ui/skeleton";

export function SavedChartsSection() {
  const { charts, loading, refresh } = useBirthCharts();
  const [modalOpen, setModalOpen] = useState(false);
  const [editing, setEditing] = useState<BirthChartRow | null>(null);
  const [confirmDelete, setConfirmDelete] = useState<BirthChartRow | null>(null);

  const openNew = () => { setEditing(null); setModalOpen(true); };
  const openEdit = (c: BirthChartRow) => { setEditing(c); setModalOpen(true); };

  const doDelete = async () => {
    if (!confirmDelete) return;
    const { error } = await (supabase as any)
      .from("birth_charts").delete().eq("id", confirmDelete.id);
    if (error) {
      toast.error("Couldn't delete chart", { description: error.message });
    } else {
      toast.success("Chart deleted");
      refresh();
    }
    setConfirmDelete(null);
  };

  return (
    <Card className="shadow-card">
      <CardHeader className="flex-row items-center justify-between space-y-0 pb-3">
        <CardTitle className="flex items-center gap-2 text-base">
          <Sparkles className="h-5 w-5 text-primary" /> Birth charts
        </CardTitle>
        <Button variant="saffron" size="sm" onClick={openNew}>
          <Plus className="h-4 w-4" /> New chart
        </Button>
      </CardHeader>
      <CardContent>
        {loading ? (
          <div className="space-y-2">
            <Skeleton className="h-16" />
            <Skeleton className="h-16" />
          </div>
        ) : charts.length === 0 ? (
          <div className="text-center py-8 space-y-3">
            <p className="text-sm text-muted-foreground">
              You haven't created a birth chart yet.
            </p>
            <p className="text-xs text-muted-foreground">
              Your kundli powers personalised horoscopes, matchmaking, and astrologer readings.
            </p>
            <Button variant="saffron" onClick={openNew}>
              <Sparkles className="h-4 w-4" /> Enter Birth Details
            </Button>
          </div>
        ) : (
          <ul className="space-y-2">
            {charts.map((c) => {
              const asc = c.chart_data?.ascendant?.sign;
              const sun = c.chart_data?.planets?.find((p: any) => p.name === "Sun")?.sign;
              const moon = c.chart_data?.planets?.find((p: any) => p.name === "Moon")?.sign;
              return (
                <li key={c.id} className="flex flex-col sm:flex-row sm:items-center gap-3 p-3 rounded-md bg-section">
                  <div className="flex-1 min-w-0 space-y-1">
                    <div className="flex items-center gap-2 flex-wrap">
                      <p className="font-medium truncate">{c.chart_name || `Chart ${c.birth_date}`}</p>
                      {c.time_unknown && <Badge variant="secondary" className="text-xs">Time unknown</Badge>}
                    </div>
                    <div className="flex flex-wrap gap-x-3 gap-y-1 text-xs text-muted-foreground">
                      <span className="flex items-center gap-1">
                        <Calendar className="h-3 w-3" />
                        {format(new Date(c.birth_date), "dd MMM yyyy")}
                        {c.birth_time && !c.time_unknown && ` · ${c.birth_time.slice(0,5)}`}
                      </span>
                      <span className="flex items-center gap-1 truncate max-w-[260px]">
                        <MapPin className="h-3 w-3 flex-shrink-0" />
                        <span className="truncate">{c.location_name}</span>
                      </span>
                    </div>
                    {(asc || sun || moon) && (
                      <div className="flex flex-wrap gap-1 pt-1">
                        {asc && <Badge variant="outline" className="text-[10px]">Asc {asc}</Badge>}
                        {sun && <Badge variant="outline" className="text-[10px]">☉ {sun}</Badge>}
                        {moon && <Badge variant="outline" className="text-[10px]">☾ {moon}</Badge>}
                      </div>
                    )}
                  </div>
                  <div className="flex gap-2">
                    <Button variant="saffron" size="sm" asChild>
                      <Link to={`/chart/${c.id}`}><Eye className="h-4 w-4" /> View</Link>
                    </Button>
                    <Button variant="ghost" size="sm" onClick={() => openEdit(c)}>
                      <Pencil className="h-4 w-4" /> Edit
                    </Button>
                    <Button
                      variant="ghost" size="sm"
                      onClick={() => setConfirmDelete(c)}
                      className="text-destructive hover:text-destructive"
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </li>
              );
            })}
          </ul>
        )}
      </CardContent>

      <BirthChartModal
        open={modalOpen}
        onOpenChange={setModalOpen}
        initialChart={editing}
        onChartCreated={() => refresh()}
      />

      <AlertDialog open={!!confirmDelete} onOpenChange={(o) => !o && setConfirmDelete(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete this chart?</AlertDialogTitle>
            <AlertDialogDescription>
              This will permanently remove "{confirmDelete?.chart_name || confirmDelete?.birth_date}".
              This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={doDelete} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </Card>
  );
}
