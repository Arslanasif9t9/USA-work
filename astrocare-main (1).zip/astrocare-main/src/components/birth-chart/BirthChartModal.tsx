import { useEffect, useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Loader2, Sparkles } from "lucide-react";
import { LocationAutocomplete, type LocationPick } from "./LocationAutocomplete";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { toast } from "sonner";
import type { BirthChartRow } from "@/hooks/useBirthCharts";
import { LanguageToggle } from "@/components/layout/LanguageToggle";

interface Props {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  initialChart?: BirthChartRow | null;
  onChartCreated?: (chart: BirthChartRow) => void;
}

const MONTHS = [
  "January","February","March","April","May","June",
  "July","August","September","October","November","December",
];
const CURRENT_YEAR = new Date().getFullYear();
const YEARS = Array.from({ length: CURRENT_YEAR - 1900 + 1 }, (_, i) => 1900 + i);

function daysInMonth(month: number, year: number) {
  return new Date(year, month, 0).getDate();
}

export function BirthChartModal({ open, onOpenChange, initialChart, onChartCreated }: Props) {
  const { user } = useAuth();
  const navigate = useNavigate();
  const editing = !!initialChart;

  const [chartName, setChartName] = useState("");
  const [day, setDay] = useState<string>("");
  const [month, setMonth] = useState<string>("");
  const [year, setYear] = useState<string>("");
  const [hour, setHour] = useState<string>("");
  const [minute, setMinute] = useState<string>("");
  const [timeUnknown, setTimeUnknown] = useState(false);
  const [location, setLocation] = useState<LocationPick | null>(null);
  const [gender, setGender] = useState<"Male" | "Female" | "Other">("Male");

  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Reset / preload
  useEffect(() => {
    if (!open) return;
    setError(null);
    if (initialChart) {
      setChartName(initialChart.chart_name ?? "");
      const [y, m, d] = initialChart.birth_date.split("-");
      setYear(y); setMonth(m); setDay(d);
      setTimeUnknown(initialChart.time_unknown);
      if (initialChart.birth_time && !initialChart.time_unknown) {
        const [hh, mm] = initialChart.birth_time.split(":");
        setHour(String(parseInt(hh, 10)).padStart(2, "0"));
        setMinute(mm);
      } else {
        setHour(""); setMinute("");
      }
      setLocation({
        display_name: initialChart.location_name,
        lat: Number(initialChart.latitude),
        lon: Number(initialChart.longitude),
        timezone: initialChart.timezone,
      });
      setGender(initialChart.gender);
    } else {
      setChartName(""); setDay(""); setMonth(""); setYear("");
      setHour(""); setMinute("");
      setTimeUnknown(false); setLocation(null); setGender("Male");
    }
  }, [open, initialChart]);

  const maxDay = useMemo(() => {
    if (!month || !year) return 31;
    return daysInMonth(parseInt(month, 10), parseInt(year, 10));
  }, [month, year]);

  // Auto-fix day if month/year change makes it invalid
  useEffect(() => {
    if (day && parseInt(day, 10) > maxDay) setDay(String(maxDay).padStart(2, "0"));
  }, [maxDay, day]);

  const useNowHelper = () => {
    const now = new Date();
    setYear(String(now.getFullYear()));
    setMonth(String(now.getMonth() + 1).padStart(2, "0"));
    setDay(String(now.getDate()).padStart(2, "0"));
    setHour(String(now.getHours()).padStart(2, "0"));
    setMinute(String(now.getMinutes()).padStart(2, "0"));
    setTimeUnknown(false);
  };

  const validate = (): string | null => {
    if (!day || !month || !year) return "Please select your full birth date.";
    const d = parseInt(day, 10), m = parseInt(month, 10), y = parseInt(year, 10);
    if (d > daysInMonth(m, y)) return "That date doesn't exist (e.g. Feb 30). Please re-check.";
    if (!timeUnknown && (!hour || !minute)) return "Please enter your birth time, or check 'Time unknown'.";
    if (!location) return "Please tap a city from the dropdown to confirm your birth place, or use the manual entry link.";
    if (!gender) return "Please select gender.";
    // Future date check
    const dateStr = `${y}-${String(m).padStart(2,"0")}-${String(d).padStart(2,"0")}`;
    if (new Date(dateStr) > new Date()) return "Birth date cannot be in the future.";
    return null;
  };

  const handleSubmit = async () => {
    setError(null);
    const v = validate();
    if (v) { setError(v); return; }

    setSubmitting(true);
    try {
      const birthDate = `${year}-${month.padStart(2,"0")}-${day.padStart(2,"0")}`;
      let birthTime24: string | null = null;
      if (!timeUnknown) {
        const h = parseInt(hour, 10);
        birthTime24 = `${String(h).padStart(2,"0")}:${minute.padStart(2,"0")}`;
      }

      const { data: calc, error: calcErr } = await supabase.functions.invoke("calculate-chart", {
        body: {
          birthDate,
          birthTime: birthTime24 ?? "12:00",
          latitude: location!.lat,
          longitude: location!.lon,
          timezone: location!.timezone,
          timeUnknown,
        },
      });
      if (calcErr || !calc || calc.error) {
        throw new Error(calc?.error || calcErr?.message || "Unable to calculate chart.");
      }

      const finalName = chartName.trim() || `Chart ${birthDate}`;
      // Track which engine produced the data (provider vs in-house fallback)
      const source: "astrologyapi" | "inhouse" = calc?.source === "astrologyapi"
        ? "astrologyapi" : "inhouse";

      // ─────────────────────────────────────────────────────────────────────
      // ANONYMOUS PATH — logged-out users get a sessionStorage-backed chart so
      // the Free Kundli flow works end-to-end without sign-up. Persistence to
      // the DB only happens once the user signs in.
      // ─────────────────────────────────────────────────────────────────────
      if (!user) {
        const { newLocalChartId, saveLocalChart } = await import("@/lib/localCharts");
        const localId = newLocalChartId();
        const row = {
          id: localId,
          user_id: "",
          chart_name: finalName,
          birth_date: birthDate,
          birth_time: birthTime24,
          time_unknown: timeUnknown,
          location_name: location!.display_name,
          latitude: location!.lat,
          longitude: location!.lon,
          timezone: location!.timezone,
          gender,
          chart_data: { ...calc, source },
          created_at: new Date().toISOString(),
        } as unknown as BirthChartRow;
        saveLocalChart(row);
        toast.success("Your chart is ready!", {
          description: "Sign up to save it to your profile.",
        });
        onChartCreated?.(row);
        onOpenChange(false);
        navigate(`/chart/${localId}`);
        return;
      }

      let savedRow: BirthChartRow;
      if (editing && initialChart) {
        const { data, error: upErr } = await (supabase as any)
          .from("birth_charts")
          .update({
            chart_name: finalName,
            birth_date: birthDate,
            birth_time: birthTime24,
            time_unknown: timeUnknown,
            location_name: location!.display_name,
            latitude: location!.lat,
            longitude: location!.lon,
            timezone: location!.timezone,
            gender,
            chart_data: calc,
            source,
          })
          .eq("id", initialChart.id)
          .select("*")
          .single();
        if (upErr) throw upErr;
        savedRow = data as BirthChartRow;
      } else {
        const { data, error: insErr } = await (supabase as any)
          .from("birth_charts")
          .insert({
            user_id: user.id,
            chart_name: finalName,
            birth_date: birthDate,
            birth_time: birthTime24,
            time_unknown: timeUnknown,
            location_name: location!.display_name,
            latitude: location!.lat,
            longitude: location!.lon,
            timezone: location!.timezone,
            gender,
            chart_data: calc,
            source,
          })
          .select("*")
          .single();
        if (insErr) throw insErr;
        savedRow = data as BirthChartRow;
      }

      toast.success("Your chart is ready!", {
        description: "Birth chart calculated and saved successfully.",
      });
      onChartCreated?.(savedRow);
      onOpenChange(false);
      navigate(`/chart/${savedRow.id}`);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Unable to calculate chart.");
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <Dialog
      open={open}
      onOpenChange={(o) => { if (!submitting) onOpenChange(o); }}
    >
      <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <div className="flex items-start justify-between gap-2">
            <DialogTitle className="flex items-center gap-2">
              <Sparkles className="h-5 w-5 text-primary" />
              {editing ? "Edit Birth Chart" : "Create Your Birth Chart"}
            </DialogTitle>
            <LanguageToggle tone="neutral" className="shrink-0 mr-6" />
          </div>
          <DialogDescription>
            AstroGuide uses Vedic methods with the Lahiri ayanamsa (sidereal zodiac).
            Accurate birth details give the most precise reading.
          </DialogDescription>
        </DialogHeader>

        {submitting && (
          <div className="absolute inset-0 z-10 flex flex-col items-center justify-center gap-3 bg-background/85 rounded-lg">
            <Loader2 className="h-8 w-8 animate-spin text-primary" />
            <p className="text-sm font-medium">Calculating your chart…</p>
            <p className="text-xs text-muted-foreground italic max-w-xs text-center">
              "The stars at your birth are the seed of your story."
            </p>
          </div>
        )}

        <div className="space-y-5">
          {/* Chart name */}
          <div className="space-y-1.5">
            <Label htmlFor="chart-name">Chart name (optional)</Label>
            <Input
              id="chart-name"
              value={chartName}
              onChange={(e) => setChartName(e.target.value)}
              placeholder="e.g. My birth chart"
              disabled={submitting}
            />
          </div>

          {/* Date */}
          <div className="space-y-1.5">
            <Label>Birth date</Label>
            <div className="grid grid-cols-3 gap-2">
              <Select value={day} onValueChange={setDay} disabled={submitting}>
                <SelectTrigger><SelectValue placeholder="Day" /></SelectTrigger>
                <SelectContent>
                  {Array.from({ length: maxDay }, (_, i) => String(i + 1).padStart(2, "0")).map((d) => (
                    <SelectItem key={d} value={d}>{d}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <Select value={month} onValueChange={setMonth} disabled={submitting}>
                <SelectTrigger><SelectValue placeholder="Month" /></SelectTrigger>
                <SelectContent>
                  {MONTHS.map((m, i) => (
                    <SelectItem key={m} value={String(i + 1).padStart(2, "0")}>{m}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <Select value={year} onValueChange={setYear} disabled={submitting}>
                <SelectTrigger><SelectValue placeholder="Year" /></SelectTrigger>
                <SelectContent className="max-h-64">
                  {YEARS.slice().reverse().map((y) => (
                    <SelectItem key={y} value={String(y)}>{y}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          {/* Time */}
          <div className="space-y-1.5">
            <div className="flex items-center justify-between">
              <Label>Birth time</Label>
              <div className="flex items-center gap-2">
                <Checkbox
                  id="time-unknown"
                  checked={timeUnknown}
                  onCheckedChange={(v) => setTimeUnknown(!!v)}
                  disabled={submitting}
                />
                <Label htmlFor="time-unknown" className="text-xs font-normal text-muted-foreground cursor-pointer">
                  Time unknown — use noon
                </Label>
              </div>
            </div>
            <div className={`grid grid-cols-2 gap-2 ${timeUnknown ? "opacity-50" : ""}`}>
              <Select value={hour} onValueChange={setHour} disabled={timeUnknown || submitting}>
                <SelectTrigger><SelectValue placeholder="Hour (00–23)" /></SelectTrigger>
                <SelectContent className="max-h-64">
                  {Array.from({ length: 24 }, (_, i) => String(i).padStart(2, "0")).map((h) => (
                    <SelectItem key={h} value={h}>{h}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <Select value={minute} onValueChange={setMinute} disabled={timeUnknown || submitting}>
                <SelectTrigger><SelectValue placeholder="Min" /></SelectTrigger>
                <SelectContent className="max-h-64">
                  {Array.from({ length: 60 }, (_, i) => String(i).padStart(2, "0")).map((m) => (
                    <SelectItem key={m} value={m}>{m}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <p className="text-[11px] text-muted-foreground">24-hour format. Examples: 00:00 = midnight, 12:00 = noon, 23:30 = 11:30 PM.</p>
          </div>

          {/* Location */}
          <div className="space-y-1.5">
            <Label>Birth place</Label>
            <LocationAutocomplete value={location} onChange={setLocation} disabled={submitting} />
          </div>

          {/* Gender */}
          <div className="space-y-1.5">
            <Label>Gender</Label>
            <RadioGroup
              value={gender}
              onValueChange={(v) => setGender(v as "Male" | "Female" | "Other")}
              className="flex gap-4"
            >
              {(["Male","Female","Other"] as const).map((g) => (
                <div key={g} className="flex items-center gap-2">
                  <RadioGroupItem value={g} id={`g-${g}`} disabled={submitting} />
                  <Label htmlFor={`g-${g}`} className="font-normal cursor-pointer">{g}</Label>
                </div>
              ))}
            </RadioGroup>
          </div>

          {error && (
            <Alert variant="destructive">
              <AlertDescription>{error}</AlertDescription>
            </Alert>
          )}

          <div className="flex flex-wrap gap-2 pt-2">
            <Button variant="saffron" onClick={handleSubmit} disabled={submitting} className="flex-1 min-w-[140px]">
              {submitting ? <Loader2 className="h-4 w-4 animate-spin" /> : (editing ? "Recalculate Chart" : "Calculate My Chart")}
            </Button>
            <Button type="button" variant="ghost" onClick={useNowHelper} disabled={submitting}>
              Use current date & time
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
