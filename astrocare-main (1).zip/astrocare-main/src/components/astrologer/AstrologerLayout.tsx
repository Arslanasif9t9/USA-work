import { NavLink, useNavigate } from "react-router-dom";
import { useAstrologerAccount } from "@/hooks/useAstrologerAccount";
import { useWallet, formatINR } from "@/hooks/useWallet";
import { useAuth } from "@/contexts/AuthContext";
import { supabase } from "@/integrations/supabase/client";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Switch } from "@/components/ui/switch";
import { GlobalAstrologerNotifier } from "@/components/notifications/GlobalAstrologerNotifier";
import { NotificationBell } from "@/components/notifications/NotificationBell";
import { AnnouncementsHost } from "@/components/announcements/AnnouncementsHost";
import { AstrologerLiveIndicator } from "@/components/live/AstrologerLiveIndicator";
import { LanguageToggle } from "@/components/layout/LanguageToggle";
import {
  LayoutDashboard,
  History as HistoryIcon,
  Wallet,
  Receipt,
  Bell,
  Star,
  UserCog,
  Settings,
  LifeBuoy,
  LogOut,
  Sparkles,
  Menu,
  Gift,
  Radio,
} from "lucide-react";
import { useEffect, useState } from "react";
import { cn } from "@/lib/utils";
import { toast } from "sonner";

const NAV = [
  { to: "/astrologer/overview", label: "Overview", icon: LayoutDashboard },
  { to: "/astrologer/live", label: "AstroLive", icon: Radio, badge: "live" as const },
  { to: "/astrologer/sessions", label: "Sessions", icon: HistoryIcon },
  { to: "/astrologer/history", label: "History", icon: HistoryIcon },
  { to: "/astrologer/earnings", label: "Earnings", icon: Wallet },
  { to: "/astrologer/gifts", label: "Gifts", icon: Gift },
  { to: "/astrologer/transactions", label: "Transactions", icon: Receipt },
  { to: "/astrologer/notifications", label: "Notifications", icon: Bell },
  { to: "/astrologer/reviews", label: "Reviews", icon: Star },
  { to: "/astrologer/profile", label: "Profile", icon: UserCog },
  { to: "/astrologer/settings", label: "Settings", icon: Settings },
  { to: "/astrologer/support", label: "Support", icon: LifeBuoy },
];

export function AstrologerLayout({ children }: { children: React.ReactNode }) {
  const { astro, setAstro } = useAstrologerAccount();
  const { wallet } = useWallet();
  const { signOut, user } = useAuth();
  const navigate = useNavigate();
  const [mobileOpen, setMobileOpen] = useState(false);
  const [unread, setUnread] = useState(0);

  const isOnline = astro?.is_online && astro?.status === "online";

  useEffect(() => {
    if (!user) return;
    const fetchUnread = async () => {
      const { count } = await supabase
        .from("notifications")
        .select("id", { count: "exact", head: true })
        .eq("user_id", user.id)
        .eq("read", false);
      setUnread(count ?? 0);
    };
    fetchUnread();
    const ch = supabase
      .channel(`notif-${user.id}`)
      .on("postgres_changes", { event: "*", schema: "public", table: "notifications", filter: `user_id=eq.${user.id}` }, fetchUnread)
      .subscribe();
    return () => { supabase.removeChannel(ch); };
  }, [user]);

  const toggleOnline = async (next: boolean) => {
    if (!astro) return;
    const patch = next
      ? { status: "online", is_online: true, accepting_calls: true, accepting_chat: true, is_chat_online: true, last_seen_at: new Date().toISOString() }
      : { status: "offline", is_online: false, accepting_calls: false, accepting_chat: false, is_chat_online: false };
    const { error } = await supabase.from("astrologers").update(patch).eq("id", astro.id);
    if (error) toast.error(error.message);
    else {
      setAstro({ ...astro, ...patch } as any);
      toast.success(next ? "You're now online" : "You're offline");
    }
  };

  const handleSignOut = async () => {
    await signOut();
    navigate("/");
  };

  const initials = (astro?.display_name ?? "A").split(" ").map((p) => p[0]).join("").slice(0, 2).toUpperCase();

  const Sidebar = (
    <aside className="flex h-full w-64 flex-col border-r border-white/5 bg-[#0E1628] text-white/90">
      <div className="border-b border-white/5 px-5 py-5">
        <NavLink to="/astrologer/overview" className="flex items-center gap-2 text-amber-300">
          <Sparkles className="h-5 w-5" />
          <span className="font-serif text-lg font-bold tracking-wide">AstroPanel</span>
        </NavLink>
      </div>

      <div className="border-b border-white/5 px-5 py-5">
        <div className="flex items-center gap-3">
          <Avatar className="h-12 w-12 ring-2 ring-amber-300/40">
            <AvatarImage src={astro?.avatar_url ?? undefined} alt={astro?.display_name} className="object-cover" />
            <AvatarFallback className="bg-amber-500/20 text-amber-200">{initials}</AvatarFallback>
          </Avatar>
          <div className="min-w-0">
            <p className="truncate font-semibold">{astro?.display_name}</p>
            <p className="text-xs text-white/50">Astrologer</p>
          </div>
        </div>
        <div className="mt-4 flex items-center justify-between rounded-lg border border-white/10 bg-white/5 px-3 py-2">
          <div className="flex items-center gap-2 text-xs">
            <span className={cn("h-2 w-2 rounded-full", isOnline ? "bg-emerald-400" : "bg-white/30")} />
            <span className="font-medium">{isOnline ? "Online" : "Offline"}</span>
          </div>
          <Switch checked={!!isOnline} onCheckedChange={toggleOnline} />
        </div>
        <div className="mt-3 rounded-lg border border-amber-300/20 bg-amber-300/5 px-3 py-2">
          <p className="text-[10px] uppercase tracking-wider text-amber-200/80">Wallet balance</p>
          <p className="mt-0.5 text-lg font-bold text-amber-200 tabular-nums">{formatINR(wallet?.balance ?? 0)}</p>
        </div>
      </div>

      <nav className="flex-1 overflow-y-auto px-3 py-4">
        {NAV.map(({ to, label, icon: Icon }) => (
          <NavLink
            key={to}
            to={to}
            onClick={() => setMobileOpen(false)}
            className={({ isActive }) =>
              cn(
                "mb-1 flex items-center gap-3 rounded-lg px-3 py-2 text-sm font-medium transition",
                isActive
                  ? "bg-gradient-to-r from-amber-500/20 to-amber-400/10 text-amber-100 shadow-inner"
                  : "text-white/65 hover:bg-white/5 hover:text-white",
              )
            }
          >
            <Icon className="h-4 w-4" />
            <span className="flex-1">{label}</span>
            {to === "/astrologer/notifications" && unread > 0 && (
              <span className="ml-auto rounded-full bg-rose-500 px-2 py-0.5 text-[10px] font-bold text-white">{unread}</span>
            )}
          </NavLink>
        ))}
      </nav>

      <div className="border-t border-white/5 p-3 space-y-2">
        <div className="flex justify-center">
          <LanguageToggle tone="dark" />
        </div>
        <button
          onClick={handleSignOut}
          className="flex w-full items-center gap-3 rounded-lg px-3 py-2 text-sm font-medium text-white/60 transition hover:bg-rose-500/10 hover:text-rose-300"
        >
          <LogOut className="h-4 w-4" /> Sign out
        </button>
      </div>
    </aside>
  );

  return (
    <div className="flex min-h-screen bg-[#080D1B] text-white">
      {/* GlobalAstrologerNotifier mounted at App root — no need here */}

      {/* Desktop sidebar */}
      <div className="hidden md:flex">{Sidebar}</div>

      {/* Mobile drawer */}
      {mobileOpen && (
        <div className="fixed inset-0 z-40 flex md:hidden" onClick={() => setMobileOpen(false)}>
          <div className="h-full w-64 animate-slide-in-right" onClick={(e) => e.stopPropagation()}>
            {Sidebar}
          </div>
          <div className="flex-1 bg-black/60" />
        </div>
      )}

      <div className="flex min-w-0 flex-1 flex-col">
        <header className="flex items-center justify-between border-b border-white/5 bg-[#0E1628]/80 px-4 py-3 md:hidden">
          <button onClick={() => setMobileOpen(true)} className="rounded-lg p-2 text-white/80 hover:bg-white/10">
            <Menu className="h-5 w-5" />
          </button>
          <p className="font-serif text-lg text-amber-300">AstroPanel</p>
          <div className="flex items-center gap-2">
            <LanguageToggle tone="dark" />
            <NotificationBell variant="dark" />
          </div>
        </header>
        <main className="min-w-0 flex-1 overflow-x-hidden">
          <AnnouncementsHost audience="astrologer" />
          {children}
        </main>
        <AstrologerLiveIndicator />
      </div>
    </div>
  );
}
