// Floating WhatsApp support button — bottom-right on every page.
// Hidden on session/live screens to avoid covering call/chat UI.
import { useLocation } from "react-router-dom";
import { WHATSAPP_URL, CONTACT_CONFIG } from "@/config/contact";

function isHiddenPath(path: string): boolean {
  // Active session screens — keep them clean.
  if (path.startsWith("/chat/") && path !== "/chat/endsession") return true;
  if (path.startsWith("/astrologer/chat/") && !path.endsWith("/endsession")) return true;
  if (path.startsWith("/call/") && path !== "/call/endsession") return true;
  if (path.startsWith("/astrologer/call/") && !path.endsWith("/endsession")) return true;
  if (path === "/live") return true;
  if (path.startsWith("/astrologer/live")) return true;
  // Admin panel — out of scope for customer support.
  if (path.startsWith("/astrocareadmin")) return true;
  return false;
}

export function WhatsAppFAB() {
  const location = useLocation();
  if (!CONTACT_CONFIG.WHATSAPP_ENABLED) return null;
  if (isHiddenPath(location.pathname)) return null;

  return (
    <a
      href={WHATSAPP_URL}
      target="_blank"
      rel="noopener noreferrer"
      aria-label="Chat with support on WhatsApp"
      // z-50 keeps it above the mobile bottom nav (z-40).
      // Mobile lifts above the bottom nav (~80px); desktop sits at the corner.
      className="fixed z-50 flex items-center justify-center rounded-full bg-[#25D366] text-white shadow-lg shadow-black/20 transition-transform duration-150 hover:scale-105 active:scale-95
                 h-14 w-14 right-4 bottom-[88px]
                 md:h-16 md:w-16 md:right-6 md:bottom-6"
      style={{ marginBottom: "env(safe-area-inset-bottom)" }}
    >
      {/* Official WhatsApp glyph */}
      <svg
        xmlns="http://www.w3.org/2000/svg"
        viewBox="0 0 32 32"
        className="h-7 w-7 md:h-8 md:w-8"
        fill="currentColor"
        aria-hidden="true"
      >
        <path d="M19.11 17.205c-.372 0-1.088 1.39-1.518 1.39a.63.63 0 0 1-.315-.1c-.802-.402-1.504-.817-2.163-1.447-.545-.516-1.146-1.29-1.46-1.963a.426.426 0 0 1-.073-.215c0-.33.99-.945.99-1.49 0-.143-.73-2.39-.832-2.654-.143-.372-.214-.487-.6-.487-.187 0-.36-.043-.53-.043-.302 0-.53.115-.746.315-.688.645-1.032 1.318-1.06 2.234v.114c-.015.99.472 1.977 1.017 2.78 1.23 1.82 2.561 3.41 4.554 4.34.616.287 2.035.946 2.722.946.817 0 2.15-.515 2.478-1.318.13-.3.13-.6.13-.886 0-.214-.043-.444-.13-.616-.286-.515-1.733-1.13-2.348-1.358-.084-.014-.244-.014-.328-.014-.114 0-.229.014-.329.043-.115.03-.66.844-.808.844-.043 0-.086-.014-.12-.043l-.43-.358Z"/>
        <path d="M16.04 0C7.181 0 0 7.181 0 16.04c0 2.85.755 5.633 2.196 8.072L0 32l8.118-2.131a16 16 0 0 0 7.922 2.087h.007C24.911 31.956 32 24.866 32 16.007 32 11.715 30.317 7.69 27.298 4.673A15.95 15.95 0 0 0 16.04 0Zm0 29.292h-.005a13.27 13.27 0 0 1-6.766-1.853l-.485-.288-5.024 1.319 1.34-4.898-.316-.502a13.25 13.25 0 0 1-2.029-7.03c.003-7.32 5.962-13.279 13.29-13.279 3.55 0 6.886 1.385 9.394 3.898 2.508 2.513 3.886 5.851 3.884 9.402-.003 7.32-5.962 13.231-13.283 13.231Z"/>
      </svg>
    </a>
  );
}
