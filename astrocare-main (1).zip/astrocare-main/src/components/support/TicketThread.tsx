import { useEffect, useRef, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Loader2, Send } from "lucide-react";
import { toast } from "sonner";

interface Reply {
  id: string;
  ticket_id: string;
  author_id: string;
  author_role: "user" | "admin" | string;
  message: string;
  created_at: string;
}

interface Props {
  ticketId: string;
  ownerUserId: string;
  ticketStatus: string;
  /** Theme: customer (purple cosmic) or astrologer (slate dark) */
  variant?: "customer" | "astrologer";
}

export function TicketThread({ ticketId, ownerUserId, ticketStatus, variant = "customer" }: Props) {
  const { user } = useAuth();
  const [replies, setReplies] = useState<Reply[]>([]);
  const [loading, setLoading] = useState(true);
  const [text, setText] = useState("");
  const [sending, setSending] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);
  const isOwner = user?.id === ownerUserId;
  const closed = ticketStatus === "resolved";

  useEffect(() => {
    let active = true;
    (async () => {
      const { data } = await supabase
        .from("support_ticket_replies")
        .select("*")
        .eq("ticket_id", ticketId)
        .order("created_at");
      if (!active) return;
      setReplies((data ?? []) as Reply[]);
      setLoading(false);
    })();

    const ch = supabase
      .channel(`ticket-${ticketId}`)
      .on("postgres_changes",
        { event: "INSERT", schema: "public", table: "support_ticket_replies", filter: `ticket_id=eq.${ticketId}` },
        (p) => {
          const r = p.new as Reply;
          setReplies((prev) => prev.some((x) => x.id === r.id) ? prev : [...prev, r]);
        })
      .subscribe();
    return () => { active = false; supabase.removeChannel(ch); };
  }, [ticketId]);

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: "smooth" });
  }, [replies.length]);

  const send = async () => {
    const msg = text.trim();
    if (!msg || !user || !isOwner || closed) return;
    setSending(true);
    const { error } = await supabase.from("support_ticket_replies").insert({
      ticket_id: ticketId,
      author_id: user.id,
      author_role: "user",
      message: msg,
    });
    setSending(false);
    if (error) { toast.error(error.message); return; }
    setText("");
  };

  // Theme classes
  const isCustomer = variant === "customer";
  const wrapperBg = isCustomer ? "bg-white/5" : "bg-slate-900";
  const bubbleAdmin = isCustomer
    ? "bg-gradient-to-br from-amber-400/30 to-amber-500/20 text-amber-50 border border-amber-300/30"
    : "bg-indigo-600 text-white";
  const bubbleUser = isCustomer
    ? "bg-gradient-to-br from-purple-600 to-indigo-600 text-white"
    : "bg-slate-800 text-slate-100";
  const inputCls = isCustomer
    ? "bg-white/10 border-white/15 text-white placeholder:text-white/40 focus-visible:ring-amber-300"
    : "bg-slate-950 border-slate-800 text-slate-100";

  return (
    <div className={`rounded-xl border ${isCustomer ? "border-white/10" : "border-slate-800"} p-3 ${wrapperBg}`}>
      <div ref={scrollRef} className="max-h-72 overflow-y-auto pr-1">
        {loading ? (
          <div className="py-6 text-center"><Loader2 className={`inline h-4 w-4 animate-spin ${isCustomer ? "text-white/50" : "text-slate-400"}`} /></div>
        ) : replies.length === 0 ? (
          <p className={`py-4 text-center text-xs ${isCustomer ? "text-white/50" : "text-slate-500"}`}>
            No replies yet. Our team will respond soon.
          </p>
        ) : (
          <div className="space-y-2">
            {replies.map((r) => {
              const mine = r.author_role === "user";
              return (
                <div key={r.id} className={`flex ${mine ? "justify-end" : "justify-start"}`}>
                  <div className={`max-w-[80%] rounded-2xl px-3 py-2 text-sm ${mine ? bubbleUser : bubbleAdmin}`}>
                    <p className="whitespace-pre-wrap break-words leading-snug">{r.message}</p>
                    <p className="mt-0.5 text-[10px] opacity-70">
                      {r.author_role === "admin" ? "Support team · " : ""}
                      {new Date(r.created_at).toLocaleString([], { dateStyle: "short", timeStyle: "short" })}
                    </p>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {closed ? (
        <p className={`mt-3 text-center text-xs ${isCustomer ? "text-white/50" : "text-slate-500"}`}>
          This ticket is resolved. Open a new one if you need more help.
        </p>
      ) : isOwner ? (
        <div className="mt-3 flex gap-2">
          <Textarea
            value={text}
            onChange={(e) => setText(e.target.value.slice(0, 1000))}
            placeholder="Reply…"
            rows={2}
            className={`flex-1 resize-none rounded-xl text-sm ${inputCls}`}
          />
          <Button
            onClick={send}
            disabled={sending || !text.trim()}
            className={isCustomer
              ? "h-auto rounded-xl bg-gradient-to-r from-amber-300 to-amber-500 text-black hover:from-amber-200 hover:to-amber-400"
              : "h-auto rounded-xl bg-indigo-600 text-white hover:bg-indigo-500"}
          >
            {sending ? <Loader2 className="h-4 w-4 animate-spin" /> : <Send className="h-4 w-4" />}
          </Button>
        </div>
      ) : null}
    </div>
  );
}
