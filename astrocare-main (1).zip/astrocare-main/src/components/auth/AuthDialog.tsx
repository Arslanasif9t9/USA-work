import { createContext, useCallback, useContext, useEffect, useMemo, useState, type ReactNode } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Loader2, Sparkles } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { Link, useNavigate } from "react-router-dom";

type Mode = "sign-in" | "sign-up";

interface AuthDialogContextValue {
  open: (mode?: Mode) => void;
  close: () => void;
}

const AuthDialogContext = createContext<AuthDialogContextValue | undefined>(undefined);

export function useAuthDialog() {
  const ctx = useContext(AuthDialogContext);
  if (!ctx) throw new Error("useAuthDialog must be used within AuthDialogProvider");
  return ctx;
}

export function AuthDialogProvider({ children }: { children: ReactNode }) {
  const [isOpen, setIsOpen] = useState(false);
  const [mode, setMode] = useState<Mode>("sign-in");

  const open = useCallback((m: Mode = "sign-in") => {
    setMode(m);
    setIsOpen(true);
  }, []);
  const close = useCallback(() => setIsOpen(false), []);

  const value = useMemo(() => ({ open, close }), [open, close]);

  return (
    <AuthDialogContext.Provider value={value}>
      {children}
      <AuthDialog open={isOpen} onOpenChange={setIsOpen} mode={mode} setMode={setMode} />
    </AuthDialogContext.Provider>
  );
}

function AuthDialog({
  open,
  onOpenChange,
  mode,
  setMode,
}: {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  mode: Mode;
  setMode: (m: Mode) => void;
}) {
  const { toast } = useToast();
  const navigate = useNavigate();

  // Sign-in state
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);

  // Sign-up state
  const [name, setName] = useState("");
  const [signupEmail, setSignupEmail] = useState("");
  const [signupPassword, setSignupPassword] = useState("");

  useEffect(() => {
    if (!open) {
      setLoading(false);
    }
  }, [open]);

  const handleSignIn = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      const { data, error } = await supabase.auth.signInWithPassword({ email, password });
      if (error) {
        toast({ title: "Sign-in failed", description: error.message, variant: "destructive" });
        return;
      }
      const uid = data.user?.id;
      if (uid) {
        // Customer popup must reject astrologer/admin accounts
        const { data: roles } = await supabase
          .from("user_roles")
          .select("role")
          .eq("user_id", uid);
        const list = (roles ?? []).map((r) => r.role);
        if (list.includes("astrologer") || list.includes("admin")) {
          await supabase.auth.signOut();
          toast({
            title: "Wrong account type",
            description: "Please use the dedicated portal for your account.",
            variant: "destructive",
          });
          return;
        }
      }
      toast({ title: "Signed in" });
      onOpenChange(false);
    } finally {
      setLoading(false);
    }
  };

  const handleSignUp = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      const redirectUrl = `${window.location.origin}/auth/callback`;
      const { data, error } = await supabase.auth.signUp({
        email: signupEmail,
        password: signupPassword,
        options: { emailRedirectTo: redirectUrl, data: { name } },
      });
      if (error) {
        toast({ title: "Sign-up failed", description: error.message, variant: "destructive" });
        return;
      }
      // Tag this user as a customer
      if (data.user?.id) {
        await supabase.from("user_roles").insert({
          user_id: data.user.id,
          role: "customer",
        });
      }
      toast({
        title: "Check your email",
        description: "We sent a verification link to confirm your account.",
      });
      onOpenChange(false);
    } finally {
      setLoading(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md p-0 overflow-hidden">
        <div className="bg-gradient-saffron px-6 py-5 text-white">
          <div className="flex items-center gap-2 font-display font-bold text-lg">
            <Sparkles className="h-5 w-5" />
            AstroGuide
          </div>
          <DialogHeader className="mt-2">
            <DialogTitle className="text-white text-xl">
              {mode === "sign-in" ? "Welcome back" : "Create your account"}
            </DialogTitle>
            <DialogDescription className="text-white/80">
              {mode === "sign-in"
                ? "Sign in to talk to verified astrologers."
                : "Join AstroGuide and get your first chat free."}
            </DialogDescription>
          </DialogHeader>
        </div>

        <div className="p-6">
          <Tabs value={mode} onValueChange={(v) => setMode(v as Mode)}>
            <TabsList className="grid w-full grid-cols-2 mb-4">
              <TabsTrigger value="sign-in">Sign In</TabsTrigger>
              <TabsTrigger value="sign-up">Sign Up</TabsTrigger>
            </TabsList>

            <TabsContent value="sign-in">
              <form className="space-y-3" onSubmit={handleSignIn}>
                <div className="space-y-1.5">
                  <Label htmlFor="auth-email">Email</Label>
                  <Input
                    id="auth-email"
                    type="email"
                    autoComplete="email"
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                  />
                </div>
                <div className="space-y-1.5">
                  <div className="flex items-center justify-between">
                    <Label htmlFor="auth-password">Password</Label>
                    <Link
                      to="/forgot-password"
                      onClick={() => onOpenChange(false)}
                      className="text-xs text-primary hover:underline"
                    >
                      Forgot password?
                    </Link>
                  </div>
                  <Input
                    id="auth-password"
                    type="password"
                    autoComplete="current-password"
                    required
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                  />
                </div>
                <Button type="submit" className="w-full h-11" disabled={loading}>
                  {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : "Sign In"}
                </Button>
              </form>
            </TabsContent>

            <TabsContent value="sign-up">
              <form className="space-y-3" onSubmit={handleSignUp}>
                <div className="space-y-1.5">
                  <Label htmlFor="auth-name">Full name</Label>
                  <Input
                    id="auth-name"
                    required
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                  />
                </div>
                <div className="space-y-1.5">
                  <Label htmlFor="auth-signup-email">Email</Label>
                  <Input
                    id="auth-signup-email"
                    type="email"
                    autoComplete="email"
                    required
                    value={signupEmail}
                    onChange={(e) => setSignupEmail(e.target.value)}
                  />
                </div>
                <div className="space-y-1.5">
                  <Label htmlFor="auth-signup-password">Password</Label>
                  <Input
                    id="auth-signup-password"
                    type="password"
                    autoComplete="new-password"
                    minLength={6}
                    required
                    value={signupPassword}
                    onChange={(e) => setSignupPassword(e.target.value)}
                  />
                </div>
                <Button type="submit" className="w-full h-11" disabled={loading}>
                  {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : "Create Account"}
                </Button>
              </form>
            </TabsContent>
          </Tabs>

          <div className="mt-5 pt-4 border-t text-center text-xs text-muted-foreground space-y-1">
            <p>
              Are you an astrologer?{" "}
              <button
                onClick={() => { onOpenChange(false); navigate("/astrologer/login"); }}
                className="text-primary hover:underline font-medium"
              >
                Sign in here
              </button>
            </p>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
