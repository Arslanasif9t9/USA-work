import { useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "@/contexts/AuthContext";
import { useAstrologerAccount } from "@/hooks/useAstrologerAccount";
import { useForceLogoutOnBlock } from "@/hooks/useForceLogoutOnBlock";
import { Loader2 } from "lucide-react";

export function AstrologerRoute({ children }: { children: React.ReactNode }) {
  const { user, loading: authLoading } = useAuth();
  const { astro, loading } = useAstrologerAccount();
  const navigate = useNavigate();
  useForceLogoutOnBlock();

  useEffect(() => {
    if (authLoading || loading) return;
    if (!user) navigate("/astrologer/login", { replace: true });
    else if (!astro) navigate("/", { replace: true });
  }, [user, astro, authLoading, loading, navigate]);

  if (authLoading || loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-[#0B1020] text-white/80">
        <Loader2 className="h-6 w-6 animate-spin text-amber-400" />
      </div>
    );
  }
  if (!user || !astro) return null;
  return <>{children}</>;
}

/** Blocks astrologers from customer-only pages. Renders children for non-astrologers. */
export function CustomerOnlyRoute({ children }: { children: React.ReactNode }) {
  const { astro, loading } = useAstrologerAccount();
  const navigate = useNavigate();
  useForceLogoutOnBlock();
  useEffect(() => {
    if (!loading && astro) navigate("/astrologer/overview", { replace: true });
  }, [astro, loading, navigate]);
  if (loading) return null;
  if (astro) return null;
  return <>{children}</>;
}
