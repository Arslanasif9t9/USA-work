// Compact EN | हिन्दी pill toggle. Used in customer header, mobile header,
// astrologer dashboard header, and admin header. Theme via the `tone` prop.
import { useLanguage } from "@/contexts/LanguageContext";
import { cn } from "@/lib/utils";

type Tone = "light" | "dark" | "neutral";

interface Props {
  tone?: Tone;
  className?: string;
}

const toneClasses: Record<Tone, { wrap: string; active: string; idle: string }> = {
  // light = on dark cosmic header (customer side)
  light: {
    wrap: "border-white/30 bg-white/10",
    active: "bg-white text-header shadow-sm",
    idle: "text-white/80 hover:text-white",
  },
  // dark = on slate astrologer / admin header
  dark: {
    wrap: "border-amber-300/30 bg-white/5",
    active: "bg-amber-300/90 text-slate-900 shadow-sm",
    idle: "text-white/70 hover:text-white",
  },
  // neutral = on light backgrounds
  neutral: {
    wrap: "border-border bg-muted/40",
    active: "bg-primary text-primary-foreground shadow-sm",
    idle: "text-muted-foreground hover:text-foreground",
  },
};

export function LanguageToggle({ tone = "light", className }: Props) {
  const { lang, setLang } = useLanguage();
  const t = toneClasses[tone];
  return (
    <div
      role="group"
      aria-label="Language"
      className={cn(
        "inline-flex items-center rounded-full border p-0.5 text-[11px] font-semibold leading-none",
        t.wrap,
        className,
      )}
    >
      <button
        type="button"
        onClick={() => setLang("en")}
        aria-pressed={lang === "en"}
        className={cn(
          "px-2.5 py-1 rounded-full transition-colors",
          lang === "en" ? t.active : t.idle,
        )}
      >
        EN
      </button>
      <button
        type="button"
        onClick={() => setLang("hi")}
        aria-pressed={lang === "hi"}
        className={cn(
          "px-2.5 py-1 rounded-full transition-colors",
          lang === "hi" ? t.active : t.idle,
        )}
      >
        हिं
      </button>
    </div>
  );
}
