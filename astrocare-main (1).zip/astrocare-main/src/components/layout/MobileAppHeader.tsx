// Native-app style mobile header used on inner pages.
// Renders: back arrow + page title + optional right action.
// Visible only on small screens. The desktop header continues to live in <AppShell>.
import { ReactNode } from "react";
import { useNavigate } from "react-router-dom";
import { ArrowLeft } from "lucide-react";
import { cn } from "@/lib/utils";

interface MobileAppHeaderProps {
  title: string;
  /** Where to go on back press (defaults to history.back, then "/"). */
  backTo?: string;
  /** Optional element rendered at the right (e.g. a wallet chip or notification bell). */
  right?: ReactNode;
  /** Hide the back button entirely (root-level pages). */
  hideBack?: boolean;
  className?: string;
}

export function MobileAppHeader({
  title,
  backTo,
  right,
  hideBack = false,
  className,
}: MobileAppHeaderProps) {
  const navigate = useNavigate();

  const onBack = () => {
    if (backTo) {
      navigate(backTo);
      return;
    }
    if (window.history.length > 1) navigate(-1);
    else navigate("/");
  };

  return (
    <header
      className={cn(
        "md:hidden sticky top-0 z-30 bg-header text-header-foreground shadow-sm",
        className
      )}
      style={{ paddingTop: "env(safe-area-inset-top)" }}
    >
      <div className="relative flex h-14 items-center justify-between px-2">
        <div className="flex items-center min-w-0">
          {!hideBack && (
            <button
              onClick={onBack}
              aria-label="Back"
              className="-ml-1 h-10 w-10 rounded-full inline-flex items-center justify-center hover:bg-white/15 active:bg-white/25 transition"
            >
              <ArrowLeft className="h-5 w-5" />
            </button>
          )}
        </div>
        <div className="absolute left-1/2 -translate-x-1/2 max-w-[60%] truncate text-base font-semibold tracking-tight">
          {title}
        </div>
        <div className="flex items-center gap-1 min-w-0">{right}</div>
      </div>
    </header>
  );
}
