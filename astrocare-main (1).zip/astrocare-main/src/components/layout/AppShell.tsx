import { useEffect, useState } from "react";
import { Link, useLocation, useNavigate } from "react-router-dom";
import { useAuth } from "@/contexts/AuthContext";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { WalletWidget } from "@/components/wallet/WalletWidget";
import { LowBalanceAlert } from "@/components/wallet/LowBalanceAlert";
import { PaymentTestModeBanner } from "@/components/PaymentTestModeBanner";
import { AnnouncementsHost } from "@/components/announcements/AnnouncementsHost";
import { NotificationBell } from "@/components/notifications/NotificationBell";
import { MobileAppHeader } from "@/components/layout/MobileAppHeader";
import { LanguageToggle } from "@/components/layout/LanguageToggle";
import { useAuthDialog } from "@/components/auth/AuthDialog";
import { useProfile } from "@/hooks/useProfile";
import { useTranslation } from "react-i18next";
import { LogOut, User as UserIcon, Receipt, Sparkles, Briefcase, Heart, BookOpen, LifeBuoy, Radio, LayoutDashboard, Users } from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

interface AppShellProps {
  children: React.ReactNode;
  hideFooter?: boolean;
  /** Optional mobile-only title shown in the native-app header on inner pages. */
  mobileTitle?: string;
  /** Hide back button on the mobile header (root-level pages). */
  mobileHideBack?: boolean;
  /** Where the mobile back button should go (defaults to history.back / "/"). */
  mobileBackTo?: string;
}

// Routes treated as "root" mobile pages (no back arrow, but still get the compact header).
const MOBILE_ROOT_PATHS = new Set(["/", "/astrologers", "/wallet", "/profile"]);

export function AppShell({
  children,
  hideFooter = false,
  mobileTitle,
  mobileHideBack,
  mobileBackTo,
}: AppShellProps) {
  const { user, signOut } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const { open: openAuthDialog } = useAuthDialog();
  const { profile } = useProfile();
  const { t } = useTranslation("common");
  const [isAstrologer, setIsAstrologer] = useState(false);

  useEffect(() => {
    if (!user) {
      setIsAstrologer(false);
      return;
    }
    let cancelled = false;
    supabase
      .from("astrologers")
      .select("id", { head: true, count: "exact" })
      .eq("user_id", user.id)
      .then(({ count }) => {
        if (!cancelled) setIsAstrologer((count ?? 0) > 0);
      });
    return () => {
      cancelled = true;
    };
  }, [user]);

  const handleSignOut = async () => {
    await signOut();
    navigate("/");
  };

  const initials = (user?.user_metadata?.name || user?.email || "U").toString().slice(0, 2).toUpperCase();

  // Auto-derive a sensible mobile title from the route if not passed in.
  const path = location.pathname;
  const derivedTitle = (() => {
    if (mobileTitle) return mobileTitle;
    if (path === "/") return "AstroGuide";
    if (path.startsWith("/astrologers")) return "Astrologers";
    if (path.startsWith("/wallet")) return "Wallet";
    if (path.startsWith("/transactions")) return "Transactions";
    if (path.startsWith("/history")) return "History";
    if (path.startsWith("/profile")) return "Profile";
    if (path.startsWith("/notifications")) return "Notifications";
    if (path.startsWith("/support")) return "Support";
    if (path.startsWith("/favorites")) return "Favorites";
    if (path.startsWith("/horoscope")) return "Horoscope";
    if (path.startsWith("/panchang")) return "Panchang";
    if (path.startsWith("/chart")) return "Kundli";
    return "AstroGuide";
  })();

  const isMobileRoot = mobileHideBack ?? MOBILE_ROOT_PATHS.has(path);

  // Compact right-side actions for the mobile header
  const mobileRight = user ? (
    <>
      <LanguageToggle tone="light" className="hidden sm:inline-flex" />
      <NotificationBell variant="light" />
      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <button
            className="h-9 w-9 rounded-full ring-2 ring-white/30 overflow-hidden"
            aria-label="Account menu"
          >
            <Avatar className="h-full w-full">
              <AvatarImage
                src={profile?.avatar_url ?? user.user_metadata?.avatar_url ?? undefined}
                alt={profile?.name ?? user.email ?? "Account"}
                className="object-cover"
              />
              <AvatarFallback className="bg-white/20 text-white text-xs font-semibold">
                {initials}
              </AvatarFallback>
            </Avatar>
          </button>
        </DropdownMenuTrigger>
        <DropdownMenuContent align="end" className="w-56">
          {isAstrologer && (
            <DropdownMenuItem onClick={() => navigate("/astrologer-dashboard")}>
              <Briefcase className="h-4 w-4" /> Astrologer Dashboard
            </DropdownMenuItem>
          )}
          <DropdownMenuItem onClick={() => navigate("/favorites")}>
            <Heart className="h-4 w-4" /> Favorites
          </DropdownMenuItem>
          <DropdownMenuItem onClick={() => navigate("/profile")}>
            <UserIcon className="h-4 w-4" /> Profile
          </DropdownMenuItem>
          <DropdownMenuItem onClick={() => navigate("/transactions")}>
            <Receipt className="h-4 w-4" /> Transactions
          </DropdownMenuItem>
          <DropdownMenuItem onClick={() => navigate("/history")}>
            <BookOpen className="h-4 w-4" /> History
          </DropdownMenuItem>
          <DropdownMenuItem onClick={() => navigate("/support")}>
            <LifeBuoy className="h-4 w-4" /> Support
          </DropdownMenuItem>
          <DropdownMenuSeparator />
          <DropdownMenuItem onClick={handleSignOut} className="text-destructive">
            <LogOut className="h-4 w-4" /> Sign out
          </DropdownMenuItem>
        </DropdownMenuContent>
      </DropdownMenu>
    </>
  ) : (
    <Button
      size="sm"
      variant="gold"
      className="h-8 px-3 text-xs"
      onClick={() => openAuthDialog("sign-in")}
    >
      Sign In
    </Button>
  );

  return (
    <div className="min-h-screen flex flex-col bg-background">
      <PaymentTestModeBanner />
      {user && <AnnouncementsHost audience="customer" />}

      {/* Mobile native-app header */}
      <MobileAppHeader
        title={derivedTitle}
        hideBack={isMobileRoot}
        backTo={mobileBackTo}
        right={mobileRight}
      />

      {/* Desktop header — hidden on mobile */}
      <header className="hidden md:block bg-header text-header-foreground sticky top-0 z-30 shadow-md backdrop-blur supports-[backdrop-filter]:bg-header/95">
        <div className="container flex items-center justify-between h-16">
          <Link to="/" className="flex items-center gap-2 font-bold text-lg hover:opacity-90 transition-opacity">
            <Sparkles className="h-5 w-5 text-secondary" />
            <span className="tracking-tight">AstroGuide</span>
          </Link>

          <nav className="flex items-center gap-1">
            <Link
              to="/astrologers"
              className="px-3 py-2 text-sm font-medium rounded-md hover:bg-white/10 transition-colors"
            >
              {t("nav.astrologers")}
            </Link>
            <Link
              to="/live"
              className="px-3 py-2 text-sm font-medium rounded-md hover:bg-white/10 transition-colors inline-flex items-center gap-1.5"
            >
              <Radio className="h-4 w-4" />
              {t("nav.live")}
            </Link>
            <Link
              to="/panchang"
              className="px-3 py-2 text-sm font-medium rounded-md hover:bg-white/10 transition-colors"
            >
              {t("nav.panchang")}
            </Link>
            <Link
              to="/chart/new"
              className="px-3 py-2 text-sm font-medium rounded-md hover:bg-white/10 transition-colors"
            >
              {t("nav.kundli")}
            </Link>
          </nav>

          <div className="flex items-center gap-3">
            <LanguageToggle tone="light" />
            {isAstrologer ? (
              <Button
                variant="gold"
                size="sm"
                className="hidden lg:inline-flex"
                onClick={() => navigate("/astrologer/overview")}
              >
                <LayoutDashboard className="h-4 w-4" /> {t("nav.dashboard")}
              </Button>
            ) : (
              <Button
                variant="gold"
                size="sm"
                className="hidden lg:inline-flex"
                onClick={() => navigate("/astrologers")}
              >
                <Users className="h-4 w-4" /> {t("nav.all_astrologers")}
              </Button>
            )}
            {user ? (
              <>
                <NotificationBell variant="light" />
                <WalletWidget />
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <button
                      className="h-9 w-9 rounded-full ring-2 ring-white/30 hover:ring-white/60 transition-all overflow-hidden"
                      aria-label="Account menu"
                    >
                      <Avatar className="h-full w-full">
                        <AvatarImage
                          src={profile?.avatar_url ?? user.user_metadata?.avatar_url ?? undefined}
                          alt={profile?.name ?? user.email ?? "Account"}
                          className="object-cover"
                        />
                        <AvatarFallback className="bg-white/20 text-white text-sm font-semibold">
                          {initials}
                        </AvatarFallback>
                      </Avatar>
                    </button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end" className="w-56">
                    {isAstrologer && (
                      <DropdownMenuItem onClick={() => navigate("/astrologer-dashboard")}>
                        <Briefcase className="h-4 w-4" /> Astrologer Dashboard
                      </DropdownMenuItem>
                    )}
                    <DropdownMenuItem onClick={() => navigate("/favorites")}>
                      <Heart className="h-4 w-4" /> Favorites
                    </DropdownMenuItem>
                    <DropdownMenuItem onClick={() => navigate("/profile")}>
                      <UserIcon className="h-4 w-4" /> Profile
                    </DropdownMenuItem>
                    <DropdownMenuItem onClick={() => navigate("/transactions")}>
                      <Receipt className="h-4 w-4" /> Transactions
                    </DropdownMenuItem>
                    <DropdownMenuItem onClick={() => navigate("/history")}>
                      <BookOpen className="h-4 w-4" /> History
                    </DropdownMenuItem>
                    <DropdownMenuItem onClick={() => navigate("/support")}>
                      <LifeBuoy className="h-4 w-4" /> Support
                    </DropdownMenuItem>
                    <DropdownMenuSeparator />
                    <DropdownMenuItem onClick={handleSignOut} className="text-destructive">
                      <LogOut className="h-4 w-4" /> {t("nav.sign_out")}
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              </>
            ) : (
              <div className="flex items-center gap-2">
                <Button
                  variant="outline"
                  size="sm"
                  className="bg-white/10 border-white/40 text-white hover:bg-white/20 hover:text-white"
                  onClick={() => openAuthDialog("sign-in")}
                >
                  {t("nav.sign_in")}
                </Button>
                <Button variant="gold" size="sm" onClick={() => openAuthDialog("sign-up")}>
                  {t("nav.sign_up")}
                </Button>
              </div>
            )}
          </div>
        </div>
      </header>

      {user && <LowBalanceAlert />}

      <main className="flex-1">{children}</main>

      {!hideFooter && (
        <footer className="hidden md:block bg-section border-t border-border py-6 mt-auto">
          <div className="container text-center text-sm text-muted-foreground">
            © {new Date().getFullYear()} AstroGuide · Vedic astrology &amp; psychic guidance
          </div>
        </footer>
      )}
    </div>
  );
}
