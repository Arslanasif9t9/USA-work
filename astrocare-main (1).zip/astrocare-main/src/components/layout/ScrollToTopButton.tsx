import { useEffect, useState } from "react";
import { ArrowUp } from "lucide-react";

interface Props {
  /** Pixel scroll threshold before button appears. */
  threshold?: number;
}

/**
 * Floating "scroll to top" button.
 *
 * Stacking with other floating UI:
 *   - WhatsApp FAB (z-50): mobile right-4 bottom-[88px] (h-14), desktop right-6 bottom-6 (h-16)
 *   - Mobile bottom nav (z-40): 64px tall at bottom
 *   - This button (z-40): sits ABOVE the WhatsApp FAB with ~12px gap
 *       mobile  -> right-4, bottom-[156px]  (88 + 56 + 12)
 *       desktop -> right-6, bottom-[92px]   (24 + 64 +  4)
 */
export function ScrollToTopButton({ threshold = 400 }: Props) {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const onScroll = () => setVisible(window.pageYOffset > threshold);
    window.addEventListener("scroll", onScroll, { passive: true });
    onScroll();
    return () => window.removeEventListener("scroll", onScroll);
  }, [threshold]);

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  return (
    <button
      type="button"
      onClick={scrollToTop}
      aria-label="Scroll to top"
      style={{ marginBottom: "env(safe-area-inset-bottom)" }}
      className={`fixed z-40 flex items-center justify-center rounded-full bg-[#ED7B2A] text-white shadow-lg shadow-black/20 transition-all duration-300 hover:bg-[#D86E20] hover:scale-105 active:scale-95
        h-12 w-12 right-4 bottom-[156px]
        md:h-12 md:w-12 md:right-6 md:bottom-[92px]
        ${visible ? "opacity-100 translate-y-0 pointer-events-auto" : "opacity-0 translate-y-2 pointer-events-none"}`}
    >
      <ArrowUp className="h-5 w-5" strokeWidth={2.4} />
    </button>
  );
}
