import { ArrowLeft } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { useTranslation } from "react-i18next";

interface BackButtonProps {
  /** Explicit destination. If omitted, uses browser history (with fallback). */
  to?: string;
  /** Fallback path when no browser history is available (only used when `to` is not set). */
  fallbackPath?: string;
  label?: string;
  className?: string;
}

export function BackButton({ to, fallbackPath = "/", label, className }: BackButtonProps) {
  const navigate = useNavigate();
  const { t } = useTranslation("common");
  const text = label ?? t("common.back", { defaultValue: "Back" });

  const handleClick = () => {
    if (to) {
      navigate(to);
      return;
    }
    if (typeof window !== "undefined" && window.history.length > 1) {
      navigate(-1);
    } else {
      navigate(fallbackPath);
    }
  };

  return (
    <button
      type="button"
      onClick={handleClick}
      aria-label={text}
      className={`inline-flex min-h-[44px] items-center gap-2 -ml-1 px-2 py-2 text-sm font-medium text-[#5A4A3A] hover:text-[#ED7B2A] transition-colors ${className ?? ""}`}
    >
      <ArrowLeft className="h-4 w-4" />
      <span>{text}</span>
    </button>
  );
}
