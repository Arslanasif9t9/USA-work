// Mobile bottom navigation — visible on small screens (<768px) only.
// 5 tabs: Home, Astrologers, Live (center primary), Chat, Profile.
// Lifts above the iOS home indicator using safe-area-inset-bottom.
import { NavLink, useLocation, useNavigate } from "react-router-dom";
import { Home, Radio, Users, MessageCircle, User } from "lucide-react";
import { useIsMobile } from "@/hooks/use-mobile";
import { useAstrologerLiveMap } from "@/hooks/useLiveStreams";
import { usePlatformSettings } from "@/hooks/usePlatformSettings";
import { cn } from "@/lib/utils";

interface NavItem {
  to: string;
  label: string;
  icon: typeof Home;
  exact?: boolean;
}

const LEFT_ITEMS: NavItem[] = [
  { to: "/", label: "Home", icon: Home, exact: true },
  { to: "/astrologers", label: "Browse", icon: Users },
];

const RIGHT_ITEMS: NavItem[] = [
  { to: "/history", label: "Chat", icon: MessageCircle },
  { to: "/profile", label: "Profile", icon: User },
];

export function MobileBottomNav() {
  const isMobile = useIsMobile();
  const location = useLocation();
  const navigate = useNavigate();
  const liveMap = useAstrologerLiveMap();
  const settings = usePlatformSettings();
  const liveCount = Object.keys(liveMap).length;

  const path = location.pathname;
  const hidden =
    !isMobile ||
    path.startsWith("/astrocareadmin") ||
    path.startsWith("/astrologer/") ||
    path.startsWith("/sign-") ||
    path.startsWith("/forgot-") ||
    path.startsWith("/reset-") ||
    path.startsWith("/auth/") ||
    path.startsWith("/blocked") ||
    path.startsWith("/chat/") ||
    path.startsWith("/call/") ||
    path === "/live";

  if (hidden) return null;

  const liveDisabled =
    settings &&
    (settings.astrolive_enabled === false || settings.astrolive_enabled_mobile === false);

  const renderItem = (item: NavItem) => {
    const Icon = item.icon;
    return (
      <NavLink
        key={item.to}
        to={item.to}
        end={item.exact}
        className={({ isActive }) =>
          cn(
            "flex flex-col items-center justify-center gap-0.5 py-2 text-[10px] font-medium transition-colors min-h-[56px] flex-1 active:scale-95",
            isActive ? "text-primary" : "text-muted-foreground hover:text-foreground"
          )
        }
      >
        <Icon className="h-[22px] w-[22px]" strokeWidth={2.2} />
        <span>{item.label}</span>
      </NavLink>
    );
  };

  return (
    <>
      <nav
        className="fixed bottom-0 inset-x-0 z-40 md:hidden bg-background/95 backdrop-blur border-t border-border"
        style={{ paddingBottom: "env(safe-area-inset-bottom)" }}
      >
        <div className="flex items-stretch h-[64px] relative">
          {LEFT_ITEMS.map(renderItem)}

          {/* Center primary "Live" action — raised pill with red pulse. */}
          <div className="flex-1 flex items-start justify-center relative">
            {!liveDisabled && (
              <button
                onClick={() => navigate("/live")}
                aria-label="Open live"
                className="absolute -top-5 h-14 w-14 rounded-full bg-gradient-to-br from-primary via-primary to-secondary text-primary-foreground shadow-lg shadow-primary/30 flex items-center justify-center ring-4 ring-background active:scale-95 transition"
              >
                <Radio className="h-6 w-6" strokeWidth={2.4} />
                {liveCount > 0 && (
                  <span className="absolute top-1 right-1 h-2.5 w-2.5 rounded-full bg-background border-2 border-primary animate-pulse" />
                )}
              </button>
            )}
            <span
              className={cn(
                "absolute bottom-2 text-[10px] font-medium",
                path === "/live" ? "text-primary" : "text-muted-foreground"
              )}
            >
              Live
            </span>
          </div>

          {RIGHT_ITEMS.map(renderItem)}
        </div>
      </nav>
      {/* Spacer so content isn't covered */}
      <div
        className="md:hidden"
        style={{ height: "calc(64px + env(safe-area-inset-bottom))" }}
      />
    </>
  );
}
