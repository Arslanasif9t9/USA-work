// Inline India flag SVG — reliable rendering across browsers regardless of emoji font support.
interface Props {
  className?: string;
  size?: number;
}

export function IndiaFlag({ className = "", size = 16 }: Props) {
  const h = size;
  const w = Math.round(size * 1.5);
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      viewBox="0 0 30 20"
      width={w}
      height={h}
      className={className}
      role="img"
      aria-label="India"
    >
      <rect width="30" height="20" fill="#FFFFFF" />
      <rect width="30" height="6.667" y="0" fill="#FF9933" />
      <rect width="30" height="6.667" y="13.333" fill="#138808" />
      <circle cx="15" cy="10" r="2" fill="none" stroke="#000080" strokeWidth="0.4" />
      <circle cx="15" cy="10" r="0.5" fill="#000080" />
    </svg>
  );
}
