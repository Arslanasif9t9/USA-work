import { Checkbox } from "@/components/ui/checkbox";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { useTranslation } from "react-i18next";

export const SPECIALIZATIONS = [
  "vedic",
  "kp_system",
  "lal_kitab",
  "numerology",
  "tarot",
  "marriage_matching",
  "vastu",
  "reiki",
  "feng_shui",
  "horary",
  "nadi",
] as const;

interface Props {
  selected: string[];
  onChange: (next: string[]) => void;
  onlineOnly: boolean;
  onOnlineOnlyChange: (v: boolean) => void;
  onReset: () => void;
}

export function ExpertiseFilter({
  selected,
  onChange,
  onlineOnly,
  onOnlineOnlyChange,
  onReset,
}: Props) {
  const { t } = useTranslation("common");
  const toggle = (value: string) => {
    onChange(
      selected.includes(value) ? selected.filter((v) => v !== value) : [...selected, value],
    );
  };

  return (
    <div className="space-y-6">
      <div>
        <div className="mb-3 flex items-center justify-between">
          <h3 className="text-sm font-semibold">{t("astrologers.availability")}</h3>
        </div>
        <div className="flex items-center space-x-2">
          <Checkbox
            id="online-only"
            checked={onlineOnly}
            onCheckedChange={(v) => onOnlineOnlyChange(v === true)}
          />
          <Label htmlFor="online-only" className="text-sm font-normal cursor-pointer">
            {t("astrologers.online_only")}
          </Label>
        </div>
      </div>

      <div>
        <h3 className="mb-3 text-sm font-semibold">{t("astrologers.expertise")}</h3>
        <div className="space-y-2.5">
          {SPECIALIZATIONS.map((value) => (
            <div key={value} className="flex items-center space-x-2">
              <Checkbox
                id={`spec-${value}`}
                checked={selected.includes(value)}
                onCheckedChange={() => toggle(value)}
              />
              <Label
                htmlFor={`spec-${value}`}
                className="text-sm font-normal cursor-pointer"
              >
                {t(`astrologers.spec.${value}`)}
              </Label>
            </div>
          ))}
        </div>
      </div>

      {(selected.length > 0 || onlineOnly) && (
        <Button variant="outline" size="sm" className="w-full" onClick={onReset}>
          {t("astrologers.reset_filters")}
        </Button>
      )}
    </div>
  );
}
