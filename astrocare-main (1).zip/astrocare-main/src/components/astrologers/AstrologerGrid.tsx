import { AstrologerCard, type Astrologer } from "./AstrologerCard";
import { Skeleton } from "@/components/ui/skeleton";
import { Button } from "@/components/ui/button";
import { useTranslation } from "react-i18next";

interface Props {
  astrologers: Astrologer[];
  walletBalance: number;
  isLoading: boolean;
  onCall: (a: Astrologer) => void;
  onReset: () => void;
  favoriteIds?: Set<string>;
  onToggleFavorite?: (id: string) => void;
}

export function AstrologerGrid({
  astrologers, walletBalance, isLoading, onCall, onReset,
  favoriteIds, onToggleFavorite,
}: Props) {
  const { t } = useTranslation("common");
  if (isLoading) {
    return (
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-3">
        {Array.from({ length: 6 }).map((_, i) => (
          <Skeleton key={i} className="h-72 w-full rounded-lg" />
        ))}
      </div>
    );
  }

  if (astrologers.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center rounded-lg border border-dashed p-12 text-center">
        <h3 className="text-lg font-semibold">{t("astrologers.no_results_title")}</h3>
        <p className="mt-1 max-w-md text-sm text-muted-foreground">
          {t("astrologers.no_results_body")}
        </p>
        <Button className="mt-4" onClick={onReset}>
          {t("astrologers.reset_filters")}
        </Button>
      </div>
    );
  }

  return (
    <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-3">
      {astrologers.map((a) => (
        <AstrologerCard
          key={a.id}
          astrologer={a}
          walletBalance={walletBalance}
          onCall={onCall}
          isFavorite={favoriteIds?.has(a.id)}
          onToggleFavorite={onToggleFavorite}
        />
      ))}
    </div>
  );
}
