import { memo, useState } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Star, Sparkles, Users, Heart, MessageSquare, Gift, Phone, Radio } from "lucide-react";
import { Link, useNavigate } from "react-router-dom";
import { ChatRequestModal } from "@/components/chat/ChatRequestModal";
import { GiftModal } from "@/components/chat/GiftModal";
import { useAuth } from "@/contexts/AuthContext";
import { useAuthDialog } from "@/components/auth/AuthDialog";
import { useAstrologerLiveMap } from "@/hooks/useLiveStreams";
import { getAstrologerImageUrl, getAstrologerImageSrcSet } from "@/lib/astrologerImage";
import { useTranslation } from "react-i18next";

import { cn } from "@/lib/utils";

export interface Astrologer {
  id: string;
  slug?: string | null;
  display_name: string;
  bio?: string | null;
  avatar_url: string | null;
  specializations: string[];
  languages: string[];
  experience_years: number;
  base_rate_per_min: number;
  discounted_rate_per_min: number | null;
  chat_rate_per_min?: number | null;
  rating_avg: number;
  rating_count: number;
  follower_count: number;
  status: "online" | "offline" | "busy";
  is_featured: boolean;
  is_ai: boolean;
  first_chat_free: boolean;
}

interface Props {
  astrologer: Astrologer;
  walletBalance: number;
  onCall: (a: Astrologer) => void;
  isFavorite?: boolean;
  onToggleFavorite?: (id: string) => void;
}

const SPEC_KEYS = [
  "vedic",
  "kp_system",
  "lal_kitab",
  "numerology",
  "tarot",
  "marriage_matching",
  "vastu",
  "reiki",
  "feng_shui",
  "horary",
  "nadi",
] as const;

function initials(name: string) {
  return name
    .split(" ")
    .map((p) => p[0])
    .filter(Boolean)
    .slice(0, 2)
    .join("")
    .toUpperCase();
}

function AstrologerCardImpl({ astrologer: a, walletBalance, onCall, isFavorite, onToggleFavorite }: Props) {
  const navigate = useNavigate();
  const { user } = useAuth();
  const { open: openAuth } = useAuthDialog();
  const { t } = useTranslation("common");
  const [chatOpen, setChatOpen] = useState(false);
  const [giftOpen, setGiftOpen] = useState(false);
  const liveMap = useAstrologerLiveMap();
  const liveStreamId = liveMap[a.id];

  const specLabel = (s: string) =>
    (SPEC_KEYS as readonly string[]).includes(s) ? t(`astrologers.spec.${s}`) : s;

  const callRate = a.discounted_rate_per_min ?? a.base_rate_per_min;
  const chatRate = a.chat_rate_per_min ?? a.base_rate_per_min;
  const isOnline = a.status === "online";
  const hasDiscount = a.discounted_rate_per_min != null && a.discounted_rate_per_min < a.base_rate_per_min;

  const target = a.slug ? `/astrologer/${a.slug}` : `/astrologer/${a.id}`;

  const stop = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
  };

  const requireAuth = (cb: () => void) => {
    if (!user) {
      openAuth("sign-in");
      return;
    }
    cb();
  };

  return (
    <>
      <Card
        onClick={() => liveStreamId ? navigate(`/live?stream=${liveStreamId}`) : navigate(target)}
        className={cn(
          "relative flex cursor-pointer flex-col gap-3 p-4 transition-all hover:-translate-y-0.5 hover:shadow-lg",
          a.is_featured && "ring-1 ring-primary/40",
        )}
      >
        {liveStreamId && (
          <span className="absolute left-3 top-3 z-10 inline-flex items-center gap-1 rounded-full bg-red-600 px-2 py-0.5 text-[10px] font-bold uppercase tracking-wide text-white shadow animate-pulse">
            <Radio className="h-2.5 w-2.5" /> {t("astrologers.live")}
          </span>
        )}
        {onToggleFavorite && (
          <button
            type="button"
            aria-label={isFavorite ? t("astrologers.remove_favorite") : t("astrologers.add_favorite")}
            onClick={(e) => { stop(e); onToggleFavorite(a.id); }}
            className={cn(
              "absolute right-3 top-3 z-10 flex h-8 w-8 items-center justify-center rounded-full border bg-background/90 backdrop-blur transition-colors hover:bg-background",
              isFavorite ? "text-rose-500 border-rose-200" : "text-muted-foreground border-border hover:text-rose-500",
            )}
          >
            <Heart className={cn("h-4 w-4", isFavorite && "fill-rose-500")} />
          </button>
        )}

        <div className="flex items-start gap-3">
          <div className="relative">
            <Avatar className="h-16 w-16">
              <AvatarImage
                src={getAstrologerImageUrl(a.avatar_url, "card")}
                srcSet={getAstrologerImageSrcSet(a.avatar_url, "card")}
                alt={a.display_name}
                loading="lazy"
                className="object-cover object-[center_top]"
              />
              <AvatarFallback className="bg-primary/10 text-primary font-semibold">
                {initials(a.display_name)}
              </AvatarFallback>
            </Avatar>
            {a.status === "online" && (
              <span className="absolute bottom-0 right-0 h-4 w-4 rounded-full bg-emerald-500 ring-2 ring-background" aria-label={t("astrologers.online")} />
            )}
            {a.status === "busy" && (
              <span className="absolute bottom-0 right-0 h-4 w-4 rounded-full bg-amber-500 ring-2 ring-background" aria-label={t("astrologers.busy")} />
            )}
            {a.is_ai && (
              <span className="absolute -top-1 -left-1 inline-flex items-center gap-0.5 rounded-full bg-primary px-1.5 py-0.5 text-[10px] font-semibold text-primary-foreground">
                <Sparkles className="h-2.5 w-2.5" /> AI
              </span>
            )}
          </div>
          <div className="min-w-0 flex-1">
            <Link
              to={target}
              onClick={stop}
              className="block truncate text-base font-semibold leading-tight hover:text-primary"
            >
              {a.display_name}
            </Link>
            <div className="mt-1 flex items-center gap-1 text-xs text-muted-foreground">
              <Star className="h-3 w-3 fill-amber-400 text-amber-400" />
              <span className="font-medium text-foreground">{a.rating_avg.toFixed(1)}</span>
              <span>({a.rating_count.toLocaleString("en-IN")})</span>
              <span className="mx-1">·</span>
              <Users className="h-3 w-3" />
              <span>{a.follower_count.toLocaleString("en-IN")}</span>
            </div>
          </div>
        </div>

        <div className="flex flex-wrap gap-1">
          {a.specializations.slice(0, 3).map((s) => (
            <Badge key={s} variant="secondary" className="text-xs font-normal">
              {specLabel(s)}
            </Badge>
          ))}
        </div>

        <div className="text-xs text-muted-foreground">
          <div className="truncate">
            <span className="font-medium text-foreground">{t("astrologers.languages_label")}</span>{" "}
            {a.languages.slice(0, 3).join(", ")}
            {a.languages.length > 3 && ` +${a.languages.length - 3}`}
          </div>
          <div className="mt-0.5">
            <span className="font-medium text-foreground">{a.experience_years}</span> {t("astrologers.years_experience")}
          </div>
        </div>

        <div className="flex items-baseline gap-2">
          <span className="text-lg font-bold text-foreground">₹{callRate}</span>
          <span className="text-xs text-muted-foreground">{t("astrologers.rate_per_min")}</span>
          {hasDiscount && (
            <span className="text-xs text-muted-foreground line-through">₹{a.base_rate_per_min}</span>
          )}
        </div>

        {a.first_chat_free && (
          <span className="inline-flex w-fit items-center rounded-full bg-orange-500/15 px-2 py-0.5 text-xs font-semibold text-orange-700 dark:text-orange-400">
            {t("astrologers.first_chat_free")}
          </span>
        )}

        <div className="mt-auto grid grid-cols-3 gap-2" onClick={stop}>
          <Button
            variant="outline"
            size="sm"
            className="border-primary/30 text-primary hover:bg-primary/10"
            disabled={!isOnline}
            onClick={() => requireAuth(() => setChatOpen(true))}
          >
            <MessageSquare className="h-4 w-4" /> {t("astrologers.chat")}
          </Button>
          <Button
            variant="outline"
            size="sm"
            className="border-amber-300 text-amber-700 hover:bg-amber-50 dark:text-amber-400 dark:hover:bg-amber-950/30"
            onClick={() => requireAuth(() => setGiftOpen(true))}
          >
            <Gift className="h-4 w-4" /> {t("astrologers.gift")}
          </Button>
          <Button
            size="sm"
            disabled={!isOnline}
            onClick={() => onCall(a)}
          >
            <Phone className="h-4 w-4" /> {t("astrologers.call")}
          </Button>
        </div>
        {!isOnline && (
          <p className="text-center text-[11px] text-muted-foreground">
            {a.status === "busy" ? t("astrologers.on_another_consultation") : t("astrologers.currently_unavailable")}
          </p>
        )}
      </Card>

      <ChatRequestModal
        open={chatOpen}
        onOpenChange={setChatOpen}
        astrologerId={a.id}
        astrologerName={a.display_name}
        astrologerAvatar={a.avatar_url}
        astrologerSpecializations={a.specializations ?? []}
        astrologerRating={Number(a.rating_avg ?? 0)}
        ratePerMin={chatRate}
      />
      <GiftModal
        open={giftOpen}
        onOpenChange={setGiftOpen}
        astrologerId={a.id}
        astrologerName={a.display_name}
      />
    </>
  );
}

export const AstrologerCard = memo(AstrologerCardImpl);
