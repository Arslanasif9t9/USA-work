import { Link } from "react-router-dom";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Skeleton } from "@/components/ui/skeleton";
import { Sparkles } from "lucide-react";
import type { Astrologer } from "./AstrologerCard";

interface Props {
  astrologers: Pick<Astrologer, "id" | "display_name" | "avatar_url">[] & { slug?: string }[];
  isLoading?: boolean;
}

function initials(name: string) {
  return name
    .split(" ")
    .map((p) => p[0])
    .filter(Boolean)
    .slice(0, 2)
    .join("")
    .toUpperCase();
}

export function AIAstrologerCarousel({
  astrologers,
  isLoading,
}: {
  astrologers: Array<{ id: string; slug: string; display_name: string; avatar_url: string | null }>;
  isLoading?: boolean;
}) {
  return (
    <section>
      <div className="mb-3 flex items-center gap-2">
        <Sparkles className="h-4 w-4 text-primary" />
        <h2 className="text-lg font-semibold">AI-Powered Insights – Instant & Accurate</h2>
      </div>
      <div
        className="flex gap-4 overflow-x-auto pb-2 [scroll-snap-type:x_mandatory] [-ms-overflow-style:none] [scrollbar-width:thin]"
      >
        {isLoading
          ? Array.from({ length: 8 }).map((_, i) => (
              <div key={i} className="flex w-[88px] shrink-0 flex-col items-center gap-2 [scroll-snap-align:start]">
                <Skeleton className="h-20 w-20 rounded-full" />
                <Skeleton className="h-3 w-16" />
              </div>
            ))
          : astrologers.map((a) => (
              <Link
                key={a.id}
                to={`/astrologer/${a.slug}`}
                className="flex w-[88px] shrink-0 flex-col items-center gap-2 [scroll-snap-align:start]"
              >
                <div className="relative">
                  <Avatar className="h-20 w-20 ring-2 ring-primary/30 transition-transform hover:scale-105">
                    <AvatarImage src={a.avatar_url ?? undefined} alt={a.display_name} />
                    <AvatarFallback className="bg-primary/10 text-primary font-semibold">
                      {initials(a.display_name)}
                    </AvatarFallback>
                  </Avatar>
                  <span className="absolute -bottom-1 -right-1 inline-flex items-center gap-0.5 rounded-full bg-primary px-1.5 py-0.5 text-[10px] font-semibold text-primary-foreground">
                    <Sparkles className="h-2.5 w-2.5" /> AI
                  </span>
                </div>
                <span className="line-clamp-2 text-center text-xs font-medium leading-tight">
                  {a.display_name}
                </span>
              </Link>
            ))}
      </div>
    </section>
  );
}
