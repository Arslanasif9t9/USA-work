import { Link } from "react-router-dom";
import { Card } from "@/components/ui/card";
import { Phone, MessageCircle, ShoppingBag } from "lucide-react";
import type { LucideIcon } from "lucide-react";

interface Service {
  icon: LucideIcon;
  title: string;
  subtitle: string;
  to: string;
  gradient: string;
}

const services: Service[] = [
  {
    icon: Phone,
    title: "Speak with Experts Live",
    subtitle: "Get instant clarity over a personal call",
    to: "/astrologers",
    gradient: "bg-gradient-to-br from-primary to-primary-hover",
  },
  {
    icon: MessageCircle,
    title: "Chat Anytime, Anywhere",
    subtitle: "Discreet guidance in your own time",
    to: "/astrologers",
    gradient: "bg-gradient-to-br from-secondary to-warning",
  },
  {
    icon: ShoppingBag,
    title: "Remedies & Gemstones",
    subtitle: "Authentic spiritual products delivered",
    to: "/astrologers",
    gradient: "bg-gradient-to-br from-accent-foreground to-primary",
  },
];

export function FeaturedServiceCards() {
  return (
    <div className="grid grid-cols-1 gap-4 md:grid-cols-3">
      {services.map((s) => (
        <Link key={s.title} to={s.to} className="group">
          <Card
            className={`${s.gradient} flex h-full items-center gap-4 p-5 text-primary-foreground shadow-card transition-all hover:-translate-y-0.5 hover:shadow-card-hover`}
          >
            <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-full bg-white/20">
              <s.icon className="h-6 w-6" />
            </div>
            <div className="min-w-0">
              <h3 className="text-base font-semibold leading-tight">{s.title}</h3>
              <p className="mt-0.5 text-xs opacity-90">{s.subtitle}</p>
            </div>
          </Card>
        </Link>
      ))}
    </div>
  );
}
