import { cn } from "@/lib/utils";

interface Props {
  status: "online" | "offline" | "busy";
  className?: string;
}

const labelMap = { online: "Online", busy: "Busy", offline: "Offline" } as const;

export function OnlineStatusBadge({ status, className }: Props) {
  if (status === "offline") {
    return (
      <span
        className={cn(
          "inline-flex items-center gap-1.5 rounded-full bg-muted px-2 py-0.5 text-xs font-medium text-muted-foreground",
          className,
        )}
      >
        <span className="h-2 w-2 rounded-full bg-muted-foreground/50" />
        {labelMap[status]}
      </span>
    );
  }

  const isOnline = status === "online";
  return (
    <span
      className={cn(
        "inline-flex items-center gap-1.5 rounded-full px-2 py-0.5 text-xs font-medium",
        isOnline
          ? "bg-emerald-500/15 text-emerald-700 dark:text-emerald-400"
          : "bg-amber-500/15 text-amber-700 dark:text-amber-400",
        className,
      )}
    >
      <span className="relative flex h-2 w-2">
        <span
          className={cn(
            "absolute inline-flex h-full w-full animate-ping rounded-full opacity-60",
            isOnline ? "bg-emerald-500" : "bg-amber-500",
          )}
        />
        <span
          className={cn(
            "relative inline-flex h-2 w-2 rounded-full",
            isOnline ? "bg-emerald-500" : "bg-amber-500",
          )}
        />
      </span>
      {labelMap[status]}
    </span>
  );
}
