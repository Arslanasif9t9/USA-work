// Language filter — multi-select chips with live counts, OR logic via overlaps() in get-astrologers.
import { useEffect, useState } from "react";
import { useTranslation } from "react-i18next";
import { cn } from "@/lib/utils";
import { supabase } from "@/integrations/supabase/client";

// Order from most to least common; keep stable list so UI doesn't reflow.
const LANGUAGES = [
  "Hindi", "English", "Punjabi", "Bhojpuri", "Tamil", "Telugu",
  "Bengali", "Marathi", "Gujarati", "Urdu", "Kannada", "Malayalam",
] as const;

interface Props {
  selected: string[];
  onChange: (next: string[]) => void;
}

export function LanguageChips({ selected, onChange }: Props) {
  const { t } = useTranslation("common");
  const [counts, setCounts] = useState<Record<string, number>>({});

  useEffect(() => {
    let cancelled = false;
    (async () => {
      const { data } = await supabase
        .from("astrologers")
        .select("languages")
        .eq("approval_status", "approved");
      if (cancelled || !data) return;
      const c: Record<string, number> = {};
      for (const row of data as { languages: string[] | null }[]) {
        for (const l of row.languages ?? []) {
          c[l] = (c[l] ?? 0) + 1;
        }
      }
      setCounts(c);
    })();
    return () => { cancelled = true; };
  }, []);

  const toggle = (lang: string) => {
    onChange(selected.includes(lang) ? selected.filter((l) => l !== lang) : [...selected, lang]);
  };

  // Hide languages with zero astrologers (graceful when DB grows or shrinks).
  const visible = LANGUAGES.filter((l) => (counts[l] ?? 0) > 0);
  if (visible.length === 0) {
    // First load: show common ones so UI isn't empty
    return (
      <div className="flex flex-wrap gap-2">
        {(["Hindi", "English"] as const).map((lang) => (
          <span key={lang} className="rounded-full border border-border bg-card px-3 py-1 text-xs text-muted-foreground">
            {t(`languages.${lang.toLowerCase()}`, { defaultValue: lang })}
          </span>
        ))}
      </div>
    );
  }

  return (
    <div className="flex flex-wrap gap-2">
      {visible.map((lang) => {
        const active = selected.includes(lang);
        const count = counts[lang] ?? 0;
        return (
          <button
            key={lang}
            type="button"
            onClick={() => toggle(lang)}
            className={cn(
              "inline-flex items-center gap-1 rounded-full border px-3 py-1 text-xs font-medium transition-colors",
              active
                ? "border-primary bg-primary text-primary-foreground"
                : "border-border bg-card text-foreground hover:border-primary/40 hover:bg-accent",
            )}
          >
            <span>{t(`languages.${lang.toLowerCase()}`, { defaultValue: lang })}</span>
            <span className={cn("text-[10px] tabular-nums", active ? "text-primary-foreground/80" : "text-muted-foreground")}>
              ({count})
            </span>
          </button>
        );
      })}
    </div>
  );
}
