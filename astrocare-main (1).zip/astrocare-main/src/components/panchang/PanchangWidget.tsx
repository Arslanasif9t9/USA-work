import { Link } from "react-router-dom";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Sun, Moon, MapPin, Calendar, AlertTriangle, ChevronRight } from "lucide-react";
import { usePanchang, type PanchangResult } from "@/hooks/usePanchang";
import { cn } from "@/lib/utils";

interface Props {
  date: string;             // YYYY-MM-DD
  latitude: number;
  longitude: number;
  timezone: string;
  locationLabel: string;
  showFullLink?: boolean;   // dashboard card mode
}

function formatLocalTime(iso: string | null | undefined, timezone: string): string {
  if (!iso) return "—";
  return new Date(iso).toLocaleTimeString("en-US", {
    timeZone: timezone, hour: "2-digit", minute: "2-digit", hour12: true,
  });
}

function formatLocalDateLong(date: string, timezone: string): string {
  // Build noon-local instant, then format the weekday + date in tz
  const [y, m, d] = date.split("-").map(Number);
  const noon = new Date(Date.UTC(y, m - 1, d, 12, 0, 0));
  return noon.toLocaleDateString("en-US", {
    timeZone: timezone, weekday: "long", day: "2-digit", month: "long", year: "numeric",
  });
}

function Tile({ label, value, sub, number }: {
  label: string; value: string; sub?: string; number?: number | string;
}) {
  return (
    <div className="rounded-md border border-border bg-card p-3 flex flex-col items-start gap-1 min-w-0">
      <div className="flex items-center justify-between w-full gap-2">
        <span className="text-[10px] uppercase tracking-wide text-muted-foreground font-medium">{label}</span>
        {number !== undefined && (
          <span className="inline-flex items-center justify-center h-5 min-w-5 px-1.5 rounded-full bg-primary text-primary-foreground text-[10px] font-semibold">
            {number}
          </span>
        )}
      </div>
      <span className="text-sm font-semibold text-foreground truncate w-full">{value}</span>
      {sub && <span className="text-[11px] text-muted-foreground">{sub}</span>}
    </div>
  );
}

function WindowBar({ label, start, end, timezone, tone }: {
  label: string; start: string; end: string; timezone: string;
  tone: "rahu" | "yama" | "gulika" | "abhijit";
}) {
  const toneClasses: Record<typeof tone, string> = {
    rahu:    "bg-red-500/10 border-red-500/30 text-red-700 dark:text-red-300",
    yama:    "bg-orange-500/10 border-orange-500/30 text-orange-700 dark:text-orange-300",
    gulika:  "bg-yellow-500/10 border-yellow-500/30 text-yellow-700 dark:text-yellow-300",
    abhijit: "bg-emerald-500/10 border-emerald-500/30 text-emerald-700 dark:text-emerald-300",
  };
  return (
    <div className={cn("flex items-center justify-between rounded-md border px-3 py-2 text-sm", toneClasses[tone])}>
      <span className="font-medium">{label}</span>
      <span className="tabular-nums">{formatLocalTime(start, timezone)} – {formatLocalTime(end, timezone)}</span>
    </div>
  );
}

function PanchangSkeleton() {
  return (
    <div className="space-y-4">
      <div className="grid grid-cols-2 sm:grid-cols-5 gap-2">
        {Array.from({ length: 5 }).map((_, i) => <Skeleton key={i} className="h-16" />)}
      </div>
      <div className="grid grid-cols-2 gap-2">
        <Skeleton className="h-12" /><Skeleton className="h-12" />
      </div>
      <div className="space-y-2">
        {Array.from({ length: 4 }).map((_, i) => <Skeleton key={i} className="h-9" />)}
      </div>
    </div>
  );
}

export function PanchangWidget({ date, latitude, longitude, timezone, locationLabel, showFullLink }: Props) {
  const { data, isLoading, error, refetch, isFetching } = usePanchang({
    date, latitude, longitude, timezone,
  });

  return (
    <Card className="shadow-card">
      <CardHeader className="pb-3 space-y-1">
        <div className="flex flex-wrap items-start justify-between gap-2">
          <div className="space-y-1 min-w-0">
            <CardTitle className="text-base flex items-center gap-2">
              <Calendar className="h-4 w-4 text-primary" />
              <span className="truncate">{formatLocalDateLong(date, timezone)}</span>
            </CardTitle>
            <div className="flex items-center gap-1 text-xs text-muted-foreground">
              <MapPin className="h-3 w-3" /> <span className="truncate">{locationLabel}</span>
            </div>
          </div>
          {showFullLink && (
            <Link
              to="/panchang"
              className="text-xs font-medium text-primary hover:underline inline-flex items-center gap-0.5 whitespace-nowrap"
            >
              View full Panchang <ChevronRight className="h-3 w-3" />
            </Link>
          )}
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        {isLoading ? (
          <PanchangSkeleton />
        ) : error ? (
          <div className="space-y-2">
            <Alert variant="destructive">
              <AlertTriangle className="h-4 w-4" />
              <AlertDescription>
                Could not load Panchang. {error instanceof Error ? error.message : ""}
              </AlertDescription>
            </Alert>
            <Button variant="outline" size="sm" onClick={() => refetch()} disabled={isFetching}>
              Retry
            </Button>
          </div>
        ) : data ? (
          <PanchangBody data={data} />
        ) : null}
      </CardContent>
    </Card>
  );
}

function PanchangBody({ data }: { data: PanchangResult }) {
  const tz = data.location.timezone;
  return (
    <>
      {/* 5 tiles */}
      <div className="grid grid-cols-2 sm:grid-cols-5 gap-2">
        <Tile label="Tithi" value={data.tithi.name} number={data.tithi.number} sub={`${data.tithi.paksha} Paksha`} />
        <Tile label="Nakshatra" value={data.nakshatra.name} number={data.nakshatra.number} sub={`Pada ${data.nakshatra.pada}`} />
        <Tile label="Yoga" value={data.yoga.name} number={data.yoga.number} />
        <Tile label="Karana" value={data.karana.name} number={data.karana.number} />
        <Tile label="Vaar" value={data.vaar} />
      </div>

      {/* Sunrise/sunset + moon */}
      <div className="grid grid-cols-2 gap-2">
        <div className="rounded-md border border-border bg-card p-3 flex items-center gap-3">
          <Sun className="h-5 w-5 text-amber-500 flex-shrink-0" />
          <div className="min-w-0">
            <div className="text-[10px] uppercase tracking-wide text-muted-foreground">Sunrise / Sunset</div>
            <div className="text-sm font-medium tabular-nums">
              {formatLocalTime(data.sun.rise, tz)} · {formatLocalTime(data.sun.set, tz)}
            </div>
          </div>
        </div>
        <div className="rounded-md border border-border bg-card p-3 flex items-center gap-3">
          <Moon className="h-5 w-5 text-slate-400 flex-shrink-0" />
          <div className="min-w-0">
            <div className="text-[10px] uppercase tracking-wide text-muted-foreground">Moonrise / Moonset</div>
            <div className="text-sm font-medium tabular-nums">
              {formatLocalTime(data.moon.rise, tz)} · {formatLocalTime(data.moon.set, tz)}
            </div>
          </div>
        </div>
      </div>

      {/* Inauspicious */}
      <div className="space-y-2">
        <div className="text-xs font-medium text-muted-foreground uppercase tracking-wide">Inauspicious windows</div>
        <WindowBar label="Rahu Kaal" {...data.rahu_kaal} timezone={tz} tone="rahu" />
        <WindowBar label="Yamaganda" {...data.yamaganda} timezone={tz} tone="yama" />
        <WindowBar label="Gulika Kaal" {...data.gulika} timezone={tz} tone="gulika" />
      </div>

      {/* Auspicious */}
      <div className="space-y-2">
        <div className="text-xs font-medium text-muted-foreground uppercase tracking-wide">Auspicious window</div>
        {data.abhijit ? (
          <WindowBar label="Abhijit Muhurta" {...data.abhijit} timezone={tz} tone="abhijit" />
        ) : (
          <div className="flex items-center justify-between rounded-md border border-border bg-muted/40 px-3 py-2 text-sm text-muted-foreground">
            <span className="font-medium">Abhijit Muhurta</span>
            <Badge variant="secondary" className="text-[10px]">Not available today</Badge>
          </div>
        )}
      </div>

      {data.cached && (
        <p className="text-[10px] text-muted-foreground">Served from shared cache</p>
      )}
    </>
  );
}
