// Planetary Position table — at sunrise, sidereal Lahiri.
// AstroSage-style white table with traditional Vedic colors and EN/HI labels.
import {
  NAKSHATRA_NAMES_HI,
  PLANET_COLORS,
  PLANET_TABLE_NAME,
  PLANET_TABLE_NAME_HI,
  SIGN_NAMES_EN,
  SIGN_NAMES_HI,
  formatDMSDash,
  type ChartLang,
  type PanchangPlanet,
  type PlanetName,
} from "@/types/panchang";

interface Props {
  planets: PanchangPlanet[];
  lang?: ChartLang;
}

// 9 classical Vedic Grahas only — outer planets are not part of
// traditional Vedic astrology and are intentionally excluded.
const ORDER: PlanetName[] = [
  "Sun","Moon","Mars","Mercury","Jupiter","Venus","Saturn","Rahu","Ketu",
];

const HEADERS = {
  en: { planet: "Planets", rashi: "Rashi", lon: "Longitude", nak: "Nakshatra", pada: "Pada", retro: "R" },
  hi: { planet: "ग्रह", rashi: "राशि", lon: "देशान्तर", nak: "नक्षत्र", pada: "पाद", retro: "व" },
};

function signLabel(p: PanchangPlanet, lang: ChartLang): string {
  if (lang === "hi") return SIGN_NAMES_HI[(p.sign - 1) % 12] ?? p.sign_name;
  return SIGN_NAMES_EN[(p.sign - 1) % 12] ?? p.sign_name;
}

function nakLabel(p: PanchangPlanet, lang: ChartLang): string {
  if (lang === "hi") return NAKSHATRA_NAMES_HI[(p.nakshatra - 1) % 27] ?? p.nakshatra_name;
  return p.nakshatra_name;
}

export function PlanetaryPositionTable({ planets, lang = "en" }: Props) {
  const byName = new Map(planets.map((p) => [p.name, p] as const));
  const rows = ORDER.map((name) => byName.get(name)).filter(Boolean) as PanchangPlanet[];
  const h = HEADERS[lang];
  const nameMap = lang === "hi" ? PLANET_TABLE_NAME_HI : PLANET_TABLE_NAME;

  return (
    <div className="w-full overflow-x-auto rounded-md border border-slate-300 bg-white">
      <table className="w-full text-sm text-slate-800">
        <thead>
          <tr className="bg-slate-100 text-slate-700 text-xs uppercase tracking-wide">
            <th className="text-left px-3 py-2 font-semibold">{h.planet}</th>
            <th className="text-left px-3 py-2 font-semibold">{h.rashi}</th>
            <th className="text-left px-3 py-2 font-semibold tabular-nums">{h.lon}</th>
            <th className="text-left px-3 py-2 font-semibold">{h.nak}</th>
            <th className="text-center px-3 py-2 font-semibold">{h.pada}</th>
            <th className="text-center px-3 py-2 font-semibold">{h.retro}</th>
          </tr>
        </thead>
        <tbody>
          {rows.map((p, i) => {
            const color = PLANET_COLORS[p.name as PlanetName];
            return (
              <tr
                key={p.name}
                className="border-t border-slate-200"
                style={{ background: i % 2 === 0 ? "#ffffff" : "#fafafa" }}
              >
                <td className="px-3 py-2 font-bold" style={{ color }}>
                  {nameMap[p.name as PlanetName]}
                </td>
                <td className="px-3 py-2">{signLabel(p, lang)}</td>
                <td className="px-3 py-2 tabular-nums font-medium">{formatDMSDash(p.degree)}</td>
                <td className="px-3 py-2">{nakLabel(p, lang)}</td>
                <td className="px-3 py-2 text-center">{p.pada}</td>
                <td className="px-3 py-2 text-center">
                  {p.retrograde && (
                    <span className="inline-flex h-5 min-w-5 items-center justify-center rounded-full bg-red-100 px-1.5 text-[10px] font-bold text-red-700">
                      R
                    </span>
                  )}
                </td>
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
}
