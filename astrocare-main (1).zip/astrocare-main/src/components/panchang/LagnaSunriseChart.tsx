// Lagna chart — AstroSage-classic visual theme.
// • Cream/pale-orange background with faint diagonal zodiac-glyph watermark.
// • Warm-orange hairline strokes for diamond + diagonals (no fills, no Lagna highlight).
// • Small dark house numbers at the inner vertex of each cell.
// • Planet glyphs are 2-letter abbreviations only (no degree text, no "R" superscript).
// • North-Indian (default), South-Indian, and East-Indian renderers all share theme.
import { useMemo } from "react";
import {
  PLANET_ABBR,
  PLANET_ABBR_HI,
  PLANET_COLORS,
  type ChartLang,
  type PanchangAscendant,
  type PanchangPlanet,
  type PlanetName,
} from "@/types/panchang";

export type ChartStyle = "north" | "south" | "east";

interface Props {
  ascendant: PanchangAscendant;
  planets: PanchangPlanet[];
  /** Language for planet abbreviations. Defaults to "en". */
  lang?: ChartLang;
  /** Visual layout. Defaults to "north". */
  style?: ChartStyle;
}

// AstroSage-classic palette
const BG = "#FFFFFF";          // white card (saffron strokes preserved)
const STROKE = "#E07A1F";      // warm orange hairline
const HOUSE_NUM = "#555555";   // neutral dark gray
const WATERMARK = "#E07A1F";   // same orange, drawn at low opacity
const PLANET_FONT = "'Inter','Roboto',system-ui,sans-serif";

// Symbols used by the watermark — visually distinctive zodiac-style glyphs.
const ZODIAC_GLYPHS = ["♈","♉","♊","♋","♌","♍","♎","♏","♐","♑","♒","♓"];

/** Tiled, very-low-opacity zodiac watermark used as a card background. */
function ZodiacWatermark() {
  return (
    <defs>
      <pattern
        id="zodiac-watermark"
        patternUnits="userSpaceOnUse"
        width="80"
        height="80"
        patternTransform="rotate(-20)"
      >
        <text
          x="10" y="40"
          fontSize="22"
          fill={WATERMARK}
          fillOpacity="0.07"
          fontFamily="serif"
        >
          {ZODIAC_GLYPHS[0]}
        </text>
        <text
          x="50" y="70"
          fontSize="22"
          fill={WATERMARK}
          fillOpacity="0.07"
          fontFamily="serif"
        >
          {ZODIAC_GLYPHS[6]}
        </text>
      </pattern>
    </defs>
  );
}

// ============================================================================
// NORTH INDIAN — diamond inside a square, ascendant at top.
// ============================================================================

const A: [number, number] = [0, 0];
const B: [number, number] = [400, 0];
const C: [number, number] = [400, 400];
const D: [number, number] = [0, 400];
const M_AB: [number, number] = [200, 0];
const M_BC: [number, number] = [400, 200];
const M_CD: [number, number] = [200, 400];
const M_DA: [number, number] = [0, 200];
const CENTER: [number, number] = [200, 200];

interface NorthHouse {
  number: number;
  /** Where the house number digit sits — at the inner vertex (closest to centre). */
  numAt: [number, number];
  /** Where the planet stack starts (just outward of the digit). */
  glyphAt: [number, number];
}

// Standard North-Indian layout, counter-clockwise from H1 (top).
const NORTH_HOUSES: NorthHouse[] = [
  { number: 1,  numAt: [200, 175], glyphAt: [200, 90]  },
  { number: 2,  numAt: [130, 105], glyphAt: [100, 55]  },
  { number: 3,  numAt: [105, 130], glyphAt: [55, 100]  },
  { number: 4,  numAt: [175, 200], glyphAt: [100, 200] },
  { number: 5,  numAt: [105, 270], glyphAt: [55, 300]  },
  { number: 6,  numAt: [130, 295], glyphAt: [100, 345] },
  { number: 7,  numAt: [200, 225], glyphAt: [200, 320] },
  { number: 8,  numAt: [270, 295], glyphAt: [300, 345] },
  { number: 9,  numAt: [295, 270], glyphAt: [345, 300] },
  { number: 10, numAt: [225, 200], glyphAt: [300, 200] },
  { number: 11, numAt: [295, 130], glyphAt: [345, 100] },
  { number: 12, numAt: [270, 105], glyphAt: [300, 55]  },
];

function NorthChart({
  ascendant, planets, lang,
}: { ascendant: PanchangAscendant; planets: PanchangPlanet[]; lang: ChartLang }) {
  const ascSignIndex = ascendant.sign - 1;
  const planetsByHouse = useMemo(() => {
    const map: Record<number, PanchangPlanet[]> = {};
    for (let i = 1; i <= 12; i++) map[i] = [];
    for (const p of planets) map[p.house]?.push(p);
    return map;
  }, [planets]);
  const abbrMap = lang === "hi" ? PLANET_ABBR_HI : PLANET_ABBR;

  return (
    <svg viewBox="0 0 400 400" className="w-full h-full" role="img" aria-label="Lagna chart">
      <ZodiacWatermark />
      <rect x="0" y="0" width="400" height="400" fill={BG} />
      <rect x="0" y="0" width="400" height="400" fill="url(#zodiac-watermark)" />

      {/* Outer square + diagonals + inner diamond — single warm-orange hairline */}
      <rect x="0" y="0" width="400" height="400" fill="none" stroke={STROKE} strokeWidth="2" />
      <line x1="0" y1="0" x2="400" y2="400" stroke={STROKE} strokeWidth="1.6" />
      <line x1="400" y1="0" x2="0" y2="400" stroke={STROKE} strokeWidth="1.6" />
      <polygon points="200,0 400,200 200,400 0,200" fill="none" stroke={STROKE} strokeWidth="1.6" />

      {NORTH_HOUSES.map((h) => {
        const signIdx = (ascSignIndex + h.number - 1) % 12;
        const housePlanets = planetsByHouse[h.number] ?? [];
        const [nx, ny] = h.numAt;
        const [gx, gy] = h.glyphAt;
        return (
          <g key={h.number}>
            {/* Sign number sits at the inner vertex */}
            <text
              x={nx}
              y={ny}
              textAnchor="middle"
              fontSize="11"
              fontWeight="500"
              fill={HOUSE_NUM}
              fontFamily="'Trebuchet MS', 'Lucida Sans Unicode', sans-serif"
            >
              {signIdx + 1}
            </text>
            {/* Planet glyphs — 2 letters only, stacked vertically */}
            {housePlanets.map((p, idx) => {
              const color = PLANET_COLORS[p.name as PlanetName] ?? "#212121";
              return (
                <text
                  key={p.name}
                  x={gx}
                  y={gy + idx * 16}
                  textAnchor="middle"
                  fontSize="13"
                  fontWeight="600"
                  fill={color}
                  fontFamily="'Trebuchet MS', 'Lucida Sans Unicode', sans-serif"
                >
                  {abbrMap[p.name as PlanetName] ?? p.name.slice(0, 2)}
                </text>
              );
            })}
          </g>
        );
      })}
    </svg>
  );
}

// ============================================================================
// SOUTH INDIAN — fixed sign positions in a 4×4 grid, houses rotate.
// Sign positions (clockwise from Pisces top-left): row 0: Pi Ar Ta Ge,
// row 1: Aq . . Ca, row 2: Cp . . Le, row 3: Sa Sc Li Vi
// ============================================================================

// Map sign index (0=Aries..11=Pisces) → (row, col) cell in the 4×4 grid.
const SOUTH_SIGN_CELL: Record<number, [number, number]> = {
  0: [0, 1],   // Aries
  1: [0, 2],   // Taurus
  2: [0, 3],   // Gemini
  3: [1, 3],   // Cancer
  4: [2, 3],   // Leo
  5: [3, 3],   // Virgo
  6: [3, 2],   // Libra
  7: [3, 1],   // Scorpio
  8: [3, 0],   // Sagittarius
  9: [2, 0],   // Capricorn
  10: [1, 0],  // Aquarius
  11: [0, 0],  // Pisces
};

function SouthChart({
  ascendant, planets, lang,
}: { ascendant: PanchangAscendant; planets: PanchangPlanet[]; lang: ChartLang }) {
  const ascSignIndex = ascendant.sign - 1;
  const planetsBySign = useMemo(() => {
    const map: Record<number, PanchangPlanet[]> = {};
    for (let i = 0; i < 12; i++) map[i] = [];
    for (const p of planets) map[p.sign - 1]?.push(p);
    return map;
  }, [planets]);
  const abbrMap = lang === "hi" ? PLANET_ABBR_HI : PLANET_ABBR;

  const cell = 100; // 4×4 grid in 400×400 viewBox

  return (
    <svg viewBox="0 0 400 400" className="w-full h-full" role="img" aria-label="South Indian chart">
      <ZodiacWatermark />
      <rect x="0" y="0" width="400" height="400" fill={BG} />
      <rect x="0" y="0" width="400" height="400" fill="url(#zodiac-watermark)" />

      {/* Outer border */}
      <rect x="0" y="0" width="400" height="400" fill="none" stroke={STROKE} strokeWidth="2" />
      {/* Inner cross at 1/4 and 3/4 marks (the centre 2×2 stays empty as is convention) */}
      <line x1={cell} y1="0" x2={cell} y2="400" stroke={STROKE} strokeWidth="1.6" />
      <line x1={3 * cell} y1="0" x2={3 * cell} y2="400" stroke={STROKE} strokeWidth="1.6" />
      <line x1="0" y1={cell} x2="400" y2={cell} stroke={STROKE} strokeWidth="1.6" />
      <line x1="0" y1={3 * cell} x2="400" y2={3 * cell} stroke={STROKE} strokeWidth="1.6" />
      {/* Inner cross dividing the row/column edge cells */}
      <line x1={2 * cell} y1="0" x2={2 * cell} y2={cell} stroke={STROKE} strokeWidth="1.6" />
      <line x1={2 * cell} y1={3 * cell} x2={2 * cell} y2="400" stroke={STROKE} strokeWidth="1.6" />
      <line x1="0" y1={2 * cell} x2={cell} y2={2 * cell} stroke={STROKE} strokeWidth="1.6" />
      <line x1={3 * cell} y1={2 * cell} x2="400" y2={2 * cell} stroke={STROKE} strokeWidth="1.6" />

      {Object.entries(SOUTH_SIGN_CELL).map(([signStr, [row, col]]) => {
        const signIdx = Number(signStr);
        const houseNum = ((signIdx - ascSignIndex + 12) % 12) + 1;
        const x = col * cell;
        const y = row * cell;
        const housePlanets = planetsBySign[signIdx] ?? [];
        return (
          <g key={signIdx}>
            {/* House number in top-left corner of cell */}
            <text
              x={x + 8}
              y={y + 16}
              fontSize="11"
              fontWeight="500"
              fill={HOUSE_NUM}
              fontFamily="'Trebuchet MS', 'Lucida Sans Unicode', sans-serif"
            >
              {houseNum}
            </text>
            {/* Planet glyphs centred */}
            {housePlanets.map((p, idx) => {
              const color = PLANET_COLORS[p.name as PlanetName] ?? "#212121";
              return (
                <text
                  key={p.name}
                  x={x + cell / 2}
                  y={y + 45 + idx * 16}
                  textAnchor="middle"
                  fontSize="13"
                  fontWeight="600"
                  fill={color}
                  fontFamily="'Trebuchet MS', 'Lucida Sans Unicode', sans-serif"
                >
                  {abbrMap[p.name as PlanetName] ?? p.name.slice(0, 2)}
                </text>
              );
            })}
          </g>
        );
      })}
    </svg>
  );
}

// ============================================================================
// EAST INDIAN — diamond cells laid out in a 3×3-ish pattern. Simplified version
// using the standard "cross + diamonds" Bengali layout. House numbers rotate
// from Lagna (top).
// ============================================================================

interface EastHouse {
  number: number;
  /** Polygon points for the cell. */
  points: Array<[number, number]>;
  /** Where the house number digit sits. */
  numAt: [number, number];
  /** Where the planet glyphs stack. */
  glyphAt: [number, number];
}

const EAST_HOUSES: EastHouse[] = [
  // top row (left → right): H2, H1, H12
  { number: 2,  points: [[0, 0], [133, 0], [133, 133], [0, 133]], numAt: [12, 18], glyphAt: [66, 75] },
  { number: 1,  points: [[133, 0], [267, 0], [267, 133], [133, 133]], numAt: [145, 18], glyphAt: [200, 75] },
  { number: 12, points: [[267, 0], [400, 0], [400, 133], [267, 133]], numAt: [279, 18], glyphAt: [333, 75] },
  // middle row (left → right): H3, centre cross, H11
  { number: 3,  points: [[0, 133], [133, 133], [133, 267], [0, 267]], numAt: [12, 151], glyphAt: [66, 205] },
  { number: 11, points: [[267, 133], [400, 133], [400, 267], [267, 267]], numAt: [279, 151], glyphAt: [333, 205] },
  // bottom row: H4, H7-bottom-cell? In simplified East Indian we use:
  { number: 4,  points: [[0, 267], [133, 267], [133, 400], [0, 400]], numAt: [12, 285], glyphAt: [66, 340] },
  { number: 7,  points: [[133, 267], [267, 267], [267, 400], [133, 400]], numAt: [145, 285], glyphAt: [200, 340] },
  { number: 10, points: [[267, 267], [400, 267], [400, 400], [267, 400]], numAt: [279, 285], glyphAt: [333, 340] },
  // centre column extras (split centre into 4 inner triangles for H5/H6/H8/H9)
  { number: 5,  points: [[133, 133], [200, 200], [133, 267]], numAt: [148, 200], glyphAt: [155, 200] },
  { number: 6,  points: [[133, 267], [200, 200], [267, 267]], numAt: [200, 252], glyphAt: [200, 245] },
  { number: 8,  points: [[267, 267], [200, 200], [267, 133]], numAt: [252, 200], glyphAt: [245, 200] },
  { number: 9,  points: [[267, 133], [200, 200], [133, 133]], numAt: [200, 148], glyphAt: [200, 155] },
];

function EastChart({
  ascendant, planets, lang,
}: { ascendant: PanchangAscendant; planets: PanchangPlanet[]; lang: ChartLang }) {
  const ascSignIndex = ascendant.sign - 1;
  const planetsByHouse = useMemo(() => {
    const map: Record<number, PanchangPlanet[]> = {};
    for (let i = 1; i <= 12; i++) map[i] = [];
    for (const p of planets) map[p.house]?.push(p);
    return map;
  }, [planets]);
  const abbrMap = lang === "hi" ? PLANET_ABBR_HI : PLANET_ABBR;

  return (
    <svg viewBox="0 0 400 400" className="w-full h-full" role="img" aria-label="East Indian chart">
      <ZodiacWatermark />
      <rect x="0" y="0" width="400" height="400" fill={BG} />
      <rect x="0" y="0" width="400" height="400" fill="url(#zodiac-watermark)" />

      {/* Outer border */}
      <rect x="0" y="0" width="400" height="400" fill="none" stroke={STROKE} strokeWidth="2" />
      {/* Cell outlines */}
      {EAST_HOUSES.map((h) => (
        <polygon
          key={`outline-${h.number}`}
          points={h.points.map(([x, y]) => `${x},${y}`).join(" ")}
          fill="none"
          stroke={STROKE}
          strokeWidth="1.6"
        />
      ))}

      {EAST_HOUSES.map((h) => {
        const signIdx = (ascSignIndex + h.number - 1) % 12;
        const housePlanets = planetsByHouse[h.number] ?? [];
        const [nx, ny] = h.numAt;
        const [gx, gy] = h.glyphAt;
        return (
          <g key={h.number}>
            <text
              x={nx}
              y={ny}
              fontSize="10"
              fontWeight="500"
              fill={HOUSE_NUM}
              fontFamily="'Trebuchet MS', 'Lucida Sans Unicode', sans-serif"
            >
              {signIdx + 1}
            </text>
            {housePlanets.map((p, idx) => {
              const color = PLANET_COLORS[p.name as PlanetName] ?? "#212121";
              return (
                <text
                  key={p.name}
                  x={gx}
                  y={gy + idx * 14}
                  textAnchor="middle"
                  fontSize="12"
                  fontWeight="600"
                  fill={color}
                  fontFamily="'Trebuchet MS', 'Lucida Sans Unicode', sans-serif"
                >
                  {abbrMap[p.name as PlanetName] ?? p.name.slice(0, 2)}
                </text>
              );
            })}
          </g>
        );
      })}
    </svg>
  );
}

export function LagnaSunriseChart({ ascendant, planets, lang = "en", style = "north" }: Props) {
  return (
    <div className="w-full">
      <div
        className="aspect-square w-full mx-auto rounded-md overflow-hidden border"
        style={{ borderColor: STROKE, background: BG }}
      >
        {style === "south" ? (
          <SouthChart ascendant={ascendant} planets={planets} lang={lang} />
        ) : style === "east" ? (
          <EastChart ascendant={ascendant} planets={planets} lang={lang} />
        ) : (
          <NorthChart ascendant={ascendant} planets={planets} lang={lang} />
        )}
      </div>
    </div>
  );
}
