// Customer testimonials — pulls real approved reviews; falls back to curated list.
import { useEffect, useState } from "react";
import { useTranslation } from "react-i18next";
import { Quote, BadgeCheck, Star } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";

interface Testimonial {
  name: string;
  city: string;
  rating: number;
  comment: string;
}

function initials(name: string): string {
  const parts = name.trim().split(/\s+/);
  return ((parts[0]?.[0] ?? "") + (parts[1]?.[0] ?? "")).toUpperCase() || "U";
}

export function TestimonialsSection() {
  const { t, i18n } = useTranslation("common");
  const [items, setItems] = useState<Testimonial[] | null>(null);

  useEffect(() => {
    let cancelled = false;
    (async () => {
      const { data } = await supabase
        .from("reviews")
        .select("rating, comment")
        .eq("moderation_status", "approved")
        .not("comment", "is", null)
        .gte("rating", 4)
        .order("rating", { ascending: false })
        .order("created_at", { ascending: false })
        .limit(6);
      if (cancelled) return;
      if (data && data.length >= 4) {
        // Real reviews — comment is anonymized to first name only via fallback display
        setItems(data.map((r) => ({
          name: "Verified Customer",
          city: "",
          rating: r.rating,
          comment: r.comment ?? "",
        })));
      } else {
        const fb = t("home.testimonials.fallback", { returnObjects: true }) as Testimonial[];
        setItems(Array.isArray(fb) ? fb : []);
      }
    })();
    return () => { cancelled = true; };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [i18n.language]);

  if (!items || items.length === 0) return null;

  return (
    <section className="border-t border-border" style={{ backgroundColor: "#FBF1E2" }}>
      <div className="container py-10 md:py-14">
        <div className="mb-8 text-center">
          <h2 className="text-2xl md:text-3xl font-bold text-foreground">
            {t("home.testimonials.heading", { defaultValue: "What our customers say" })}
          </h2>
          <p className="mt-2 text-sm text-muted-foreground">
            {t("home.testimonials.subheading", { defaultValue: "Real stories from people who found clarity with AstroGuide" })}
          </p>
        </div>

        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {items.map((tst, i) => (
            <article
              key={i}
              className="relative rounded-xl bg-white p-6 shadow-sm"
              style={{ borderColor: "#E5DDD3", borderWidth: 1 }}
            >
              <Quote className="absolute -top-2 -left-2 h-6 w-6 text-[#ED7B2A]" fill="#ED7B2A" />
              <div className="flex items-center gap-3">
                <div
                  className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full text-sm font-bold text-white"
                  style={{ backgroundColor: "#ED7B2A" }}
                  aria-hidden
                >
                  {initials(tst.name)}
                </div>
                <div className="min-w-0">
                  <div className="text-sm font-semibold text-foreground truncate">
                    {tst.name}{tst.city ? `, ${tst.city}` : ""}
                  </div>
                  <div className="flex items-center gap-0.5" aria-label={`${tst.rating} out of 5 stars`}>
                    {Array.from({ length: 5 }).map((_, s) => (
                      <Star
                        key={s}
                        className="h-3.5 w-3.5"
                        fill={s < tst.rating ? "#ED7B2A" : "transparent"}
                        color="#ED7B2A"
                      />
                    ))}
                  </div>
                </div>
              </div>

              <p className="mt-4 text-sm italic text-foreground/80 leading-relaxed">
                "{tst.comment}"
              </p>

              <div className="mt-4 inline-flex items-center gap-1.5 text-[11px] font-medium text-emerald-700">
                <BadgeCheck className="h-3.5 w-3.5" />
                {t("home.testimonials.verified", { defaultValue: "Verified Customer" })}
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}
