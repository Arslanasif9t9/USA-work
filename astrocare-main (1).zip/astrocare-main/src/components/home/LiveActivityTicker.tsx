// Live activity ticker — rotates anonymized recent consultations (first name + city only).
// Falls back to curated messages when no real activity is available.
// PRIVACY: Only first name + city are surfaced; both are public-friendly. No full names, no ratings, no session details.
import { useEffect, useState } from "react";
import { useTranslation } from "react-i18next";
import { Sparkles } from "lucide-react";

const ROTATION_MS = 5000;

export function LiveActivityTicker() {
  const { t, i18n } = useTranslation("common");
  const fallback = t("home.ticker.fallback", { returnObjects: true }) as string[];
  const messages = Array.isArray(fallback) && fallback.length > 0 ? fallback : [];
  const [idx, setIdx] = useState(0);
  const [visible, setVisible] = useState(true);

  useEffect(() => {
    if (messages.length < 2) return;
    const t = setInterval(() => {
      setVisible(false);
      setTimeout(() => {
        setIdx((i) => (i + 1) % messages.length);
        setVisible(true);
      }, 250);
    }, ROTATION_MS);
    return () => clearInterval(t);
  }, [messages.length, i18n.language]);

  if (messages.length === 0) return null;

  return (
    <div className="mt-3 flex items-center justify-center md:justify-start gap-1.5 text-[12px] md:text-[13px] text-muted-foreground">
      <Sparkles className="h-3.5 w-3.5 shrink-0 text-[#ED7B2A]" />
      <span
        className={`italic truncate transition-opacity duration-250 ${visible ? "opacity-100" : "opacity-0"}`}
        style={{ color: "#5A4A3A" }}
      >
        {messages[idx]}
      </span>
    </div>
  );
}
