// Hero photo carousel — rotates through top 3 real astrologers.
// Replaces the AI illustration with credible human faces for FB ad trust.
import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { getAstrologerImageUrl, getAstrologerImageSrcSet } from "@/lib/astrologerImage";

interface HeroAstrologer {
  id: string;
  slug: string | null;
  display_name: string;
  avatar_url: string | null;
  specializations: string[];
  is_online: boolean;
  status: string;
}

const ROTATION_MS = 5000;

export function HeroAstrologerCarousel() {
  const navigate = useNavigate();
  const [astros, setAstros] = useState<HeroAstrologer[]>([]);
  const [index, setIndex] = useState(0);
  const [paused, setPaused] = useState(false);

  useEffect(() => {
    let cancelled = false;
    (async () => {
      const { data } = await supabase
        .from("astrologers")
        .select("id, slug, display_name, avatar_url, specializations, is_online, status")
        .eq("approval_status", "approved")
        .not("avatar_url", "is", null)
        .order("rating_count", { ascending: false, nullsFirst: false })
        .order("rating_avg", { ascending: false, nullsFirst: false })
        .limit(3);
      if (!cancelled && data) setAstros(data as HeroAstrologer[]);
    })();
    return () => { cancelled = true; };
  }, []);

  useEffect(() => {
    if (paused || astros.length < 2) return;
    const t = setInterval(() => setIndex((i) => (i + 1) % astros.length), ROTATION_MS);
    return () => clearInterval(t);
  }, [paused, astros.length]);

  if (astros.length === 0) {
    return <div className="h-56 w-56 lg:h-72 lg:w-72 rounded-2xl bg-accent animate-pulse" />;
  }

  const current = astros[index];
  const goTo = () => navigate(`/astrologer/${current.slug ?? current.id}`);

  return (
    <div
      className="flex flex-col items-center gap-3"
      onMouseEnter={() => setPaused(true)}
      onMouseLeave={() => setPaused(false)}
    >
      <button
        onClick={goTo}
        className="group relative block rounded-2xl overflow-hidden shadow-lg shadow-black/10 transition-all hover:ring-2 hover:ring-[#ED7B2A]"
        aria-label={`View ${current.display_name}'s profile`}
      >
        <div className="relative h-[260px] w-[260px] sm:h-[300px] sm:w-[300px] lg:h-[400px] lg:w-[400px]">
          {astros.map((a, i) => (
            <img
              key={a.id}
              src={getAstrologerImageUrl(a.avatar_url, "hero")}
              srcSet={getAstrologerImageSrcSet(a.avatar_url, "hero")}
              alt={a.display_name}
              width={400}
              height={400}
              className={`absolute inset-0 h-full w-full object-cover transition-opacity duration-300 ${i === index ? "opacity-100" : "opacity-0"}`}
              loading={i === 0 ? "eager" : "lazy"}
            />
          ))}
          {current.is_online && (
            <span className="absolute top-3 right-3 inline-flex items-center gap-1.5 rounded-full bg-white/95 px-2.5 py-1 text-[11px] font-semibold text-emerald-700 shadow-sm">
              <span className="relative flex h-2 w-2">
                <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-emerald-500 opacity-75" />
                <span className="relative inline-flex h-2 w-2 rounded-full bg-emerald-500" />
              </span>
              Live now
            </span>
          )}
        </div>
      </button>

      <div className="text-center max-w-[300px] lg:max-w-[400px]">
        <div className="text-sm font-semibold text-foreground truncate">{current.display_name}</div>
        <div className="text-xs text-muted-foreground truncate">
          {current.specializations.slice(0, 2).join(" · ")}
        </div>
      </div>

      <div className="flex gap-1.5" role="tablist" aria-label="Astrologer carousel">
        {astros.map((_, i) => (
          <button
            key={i}
            onClick={() => setIndex(i)}
            aria-label={`Show astrologer ${i + 1}`}
            className={`h-2 rounded-full transition-all ${i === index ? "w-6 bg-[#ED7B2A]" : "w-2 bg-muted-foreground/30"}`}
          />
        ))}
      </div>
    </div>
  );
}
