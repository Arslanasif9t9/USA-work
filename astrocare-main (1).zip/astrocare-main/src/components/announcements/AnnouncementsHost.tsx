// Mounts banner(s) at top of screen and modal popup(s) for active announcements
// targeted at the current user. Persists dismissals server-side so users don't
// see the same announcement repeatedly.
import { useEffect, useMemo, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { Megaphone, X } from "lucide-react";
import { Dialog, DialogContent, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";

interface Announcement {
  id: string;
  title: string;
  body: string;
  display_type: string;
  audience: string;
  scheduled_at: string;
  expires_at: string | null;
  target_user_id: string | null;
  is_active: boolean;
}

type Audience = "customer" | "astrologer" | null;

export function AnnouncementsHost({ audience }: { audience: Audience }) {
  const { user } = useAuth();
  const [items, setItems] = useState<Announcement[]>([]);
  const [dismissed, setDismissed] = useState<Set<string>>(new Set());

  useEffect(() => {
    if (!user || !audience) return;
    let cancelled = false;

    async function load() {
      const nowIso = new Date().toISOString();
      const { data: anns } = await supabase
        .from("announcements")
        .select("*")
        .eq("is_active", true)
        .lte("scheduled_at", nowIso)
        .or(`expires_at.is.null,expires_at.gt.${nowIso}`)
        .order("created_at", { ascending: false })
        .limit(30);
      const { data: dis } = await supabase
        .from("dismissed_announcements" as any)
        .select("announcement_id")
        .eq("user_id", user!.id);
      if (cancelled) return;
      const dset = new Set<string>(((dis as any) || []).map((d: any) => d.announcement_id));
      const audienceMatch = (a: Announcement) =>
        a.audience === "all" ||
        (a.audience === "customers" && audience === "customer") ||
        (a.audience === "astrologers" && audience === "astrologer") ||
        (a.audience === "user" && a.target_user_id === user!.id);
      setItems(((anns as any) || []).filter(audienceMatch).filter((a: any) => a.display_type === "banner" || a.display_type === "popup"));
      setDismissed(dset);
    }

    load();
    const ch = supabase
      .channel(`announcements-${user.id}`)
      .on("postgres_changes",
        { event: "*", schema: "public", table: "announcements" },
        load)
      .subscribe();
    return () => { cancelled = true; supabase.removeChannel(ch); };
  }, [user, audience]);

  const dismiss = async (id: string) => {
    setDismissed((s) => new Set(s).add(id));
    if (!user) return;
    await supabase.from("dismissed_announcements" as any).upsert({ user_id: user.id, announcement_id: id });
  };

  const banner = useMemo(
    () => items.find((a) => a.display_type === "banner" && !dismissed.has(a.id)),
    [items, dismissed],
  );
  const popup = useMemo(
    () => items.find((a) => a.display_type === "popup" && !dismissed.has(a.id)),
    [items, dismissed],
  );

  if (!audience) return null;

  return (
    <>
      {banner && (
        <div
          className={
            audience === "astrologer"
              ? "w-full bg-gradient-to-r from-amber-500/15 via-amber-400/10 to-amber-500/15 border-b border-amber-300/30 px-4 py-2.5 text-sm text-amber-100 flex items-start gap-3"
              : "w-full bg-gradient-to-r from-purple-600/20 via-indigo-600/15 to-purple-600/20 border-b border-purple-400/30 px-4 py-2.5 text-sm text-foreground flex items-start gap-3"
          }
        >
          <Megaphone className="h-4 w-4 mt-0.5 shrink-0" />
          <div className="min-w-0 flex-1">
            <div className="font-semibold">{banner.title}</div>
            <div className="text-xs opacity-80 line-clamp-2">{banner.body}</div>
          </div>
          <button onClick={() => dismiss(banner.id)} aria-label="Dismiss" className="opacity-70 hover:opacity-100">
            <X className="h-4 w-4" />
          </button>
        </div>
      )}

      {popup && (
        <Dialog open onOpenChange={(o) => { if (!o) dismiss(popup.id); }}>
          <DialogContent
            className={
              audience === "astrologer"
                ? "max-w-md overflow-hidden border-amber-300/30 bg-gradient-to-br from-[#1a1233] via-[#0f0a1e] to-[#1a1233] p-0 text-white shadow-[0_0_60px_rgba(251,191,36,0.25)] sm:rounded-3xl"
                : "max-w-md overflow-hidden border-purple-500/30 bg-gradient-to-br from-[#1a1233] via-[#0f0a1e] to-[#1a1233] p-0 text-white shadow-[0_0_60px_rgba(139,92,246,0.35)] sm:rounded-3xl"
            }
          >
            <div className="pointer-events-none absolute inset-0 opacity-30 [background-image:radial-gradient(white_1px,transparent_1px)] [background-size:24px_24px]" />
            <div className="pointer-events-none absolute -top-24 -left-24 h-56 w-56 rounded-full bg-purple-600/40 blur-3xl" />
            <div className="pointer-events-none absolute -bottom-24 -right-24 h-56 w-56 rounded-full bg-indigo-600/30 blur-3xl" />
            <div className="relative px-6 pt-7 pb-6 text-center">
              <div className="mx-auto mb-3 inline-flex h-14 w-14 items-center justify-center rounded-2xl bg-gradient-to-br from-amber-300 to-amber-600 shadow-lg shadow-amber-900/40">
                <Megaphone className="h-7 w-7 text-white" />
              </div>
              <DialogTitle className="font-serif text-2xl font-bold tracking-wide">{popup.title}</DialogTitle>
              <DialogDescription className="mt-2 text-sm text-white/70 whitespace-pre-wrap">
                {popup.body}
              </DialogDescription>
              <Button
                onClick={() => dismiss(popup.id)}
                className="mt-5 h-12 w-full rounded-xl bg-gradient-to-r from-purple-600 to-indigo-600 text-base font-semibold text-white shadow-lg shadow-purple-900/40 hover:from-purple-500 hover:to-indigo-500"
              >
                Got it
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      )}
    </>
  );
}
