/**
 * Floating "Return to active session" button.
 * Visible whenever the signed-in user has an active chat OR call session
 * AND is not currently on that session's page. Shown for both customers
 * and astrologers.
 */
import { useEffect, useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { MessageCircle, Phone } from "lucide-react";

interface Active {
  kind: "chat" | "call";
  sessionId: string;
  isAstrologer: boolean;
}

export function ActiveSessionFAB() {
  const { user } = useAuth();
  const { pathname } = useLocation();
  const navigate = useNavigate();
  const [active, setActive] = useState<Active | null>(null);

  useEffect(() => {
    if (!user) {
      setActive(null);
      return;
    }
    let cancelled = false;

    const load = async () => {
      // 1. Resolve astrologer row (if any) for this user
      const { data: astro } = await supabase
        .from("astrologers")
        .select("id")
        .eq("user_id", user.id)
        .maybeSingle();
      const astrologerId = astro?.id ?? null;

      // 2. Active chat as customer
      const { data: chatAsUser } = await supabase
        .from("chat_sessions")
        .select("id")
        .eq("user_id", user.id)
        .eq("status", "active")
        .order("accepted_at", { ascending: false })
        .limit(1)
        .maybeSingle();
      if (chatAsUser && !cancelled) {
        setActive({ kind: "chat", sessionId: chatAsUser.id, isAstrologer: false });
        return;
      }

      // 3. Active chat as astrologer
      if (astrologerId) {
        const { data: chatAsAstro } = await supabase
          .from("chat_sessions")
          .select("id")
          .eq("astrologer_id", astrologerId)
          .eq("status", "active")
          .order("accepted_at", { ascending: false })
          .limit(1)
          .maybeSingle();
        if (chatAsAstro && !cancelled) {
          setActive({ kind: "chat", sessionId: chatAsAstro.id, isAstrologer: true });
          return;
        }
      }

      // 4. Active call as customer
      const { data: callAsUser } = await supabase
        .from("call_sessions")
        .select("id")
        .eq("user_id", user.id)
        .in("status", ["pending", "ringing_astrologer", "ringing_user", "connected"])
        .order("initiated_at", { ascending: false })
        .limit(1)
        .maybeSingle();
      if (callAsUser && !cancelled) {
        setActive({ kind: "call", sessionId: callAsUser.id, isAstrologer: false });
        return;
      }

      // 5. Active call as astrologer
      if (astrologerId) {
        const { data: callAsAstro } = await supabase
          .from("call_sessions")
          .select("id")
          .eq("astrologer_id", astrologerId)
          .in("status", ["pending", "ringing_astrologer", "ringing_user", "connected"])
          .order("initiated_at", { ascending: false })
          .limit(1)
          .maybeSingle();
        if (callAsAstro && !cancelled) {
          setActive({ kind: "call", sessionId: callAsAstro.id, isAstrologer: true });
          return;
        }
      }

      if (!cancelled) setActive(null);
    };

    load();

    // Realtime: refresh whenever any related session row changes for this user/astro
    const channel = supabase
      .channel(`active-session-fab:${user.id}`)
      .on("postgres_changes", { event: "*", schema: "public", table: "chat_sessions" }, load)
      .on("postgres_changes", { event: "*", schema: "public", table: "call_sessions" }, load)
      .subscribe();

    return () => {
      cancelled = true;
      supabase.removeChannel(channel);
    };
  }, [user?.id]);

  if (!user || !active) return null;

  const targetPath =
    active.kind === "chat"
      ? active.isAstrologer
        ? `/astrologer/chat/${active.sessionId}`
        : `/chat/${active.sessionId}`
      : active.isAstrologer
        ? `/astrologer/call/${active.sessionId}`
        : `/call/${active.sessionId}`;

  // Hide the button when already on (or on the end-session page of) the active session
  if (pathname === targetPath) return null;
  if (
    (active.kind === "chat" &&
      (pathname.startsWith("/chat/endsession") || pathname.startsWith("/astrologer/chat/endsession"))) ||
    (active.kind === "call" &&
      (pathname.startsWith("/call/endsession") || pathname.startsWith("/astrologer/call/endsession")))
  ) {
    return null;
  }

  const Icon = active.kind === "chat" ? MessageCircle : Phone;
  const label = active.kind === "chat" ? "Resume chat" : "Resume call";

  return (
    <button
      onClick={() => navigate(targetPath)}
      className="fixed bottom-6 right-6 z-[90] flex items-center gap-2 rounded-full border border-amber-300/40 bg-gradient-to-br from-amber-400 to-amber-500 px-4 py-3 text-sm font-semibold text-black shadow-[0_0_30px_rgba(251,191,36,0.5)] transition hover:scale-105 hover:from-amber-300 hover:to-amber-400 animate-fade-in"
      aria-label={label}
    >
      <span className="relative flex h-3 w-3">
        <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-emerald-500 opacity-75" />
        <span className="relative inline-flex h-3 w-3 rounded-full bg-emerald-500" />
      </span>
      <Icon className="h-4 w-4" />
      <span className="hidden sm:inline">{label}</span>
    </button>
  );
}
