import { useEffect, useState } from "react";
import { Sheet, SheetContent, SheetTitle, SheetDescription } from "@/components/ui/sheet";
import { Button } from "@/components/ui/button";
import { X, Info, Share2, Printer } from "lucide-react";
import { useTranslation } from "react-i18next";

import type { BirthChartRow } from "@/hooks/useBirthCharts";
import { useAshtakavargaReport } from "@/hooks/useAshtakavargaReport";
import { useShare } from "@/hooks/useShare";
import { usePrint } from "@/hooks/usePrint";
import { SarvaTable } from "./ashtakavarga/SarvaTable";
import { BhinnaTable } from "./ashtakavarga/BhinnaTable";
import { AshtakavargaChartTab } from "./ashtakavarga/AshtakavargaChartTab";
import { AshtakavargaExplainerModal } from "./ashtakavarga/AshtakavargaExplainerModal";

type AshTab = "sarva" | "bhinna" | "chart";
const TAB_TO_PARAM: Record<AshTab, string> = {
  sarva: "sarva-table",
  bhinna: "bhinna-table",
  chart: "chart",
};
const PARAM_TO_TAB: Record<string, AshTab> = {
  "sarva-table": "sarva",
  "bhinna-table": "bhinna",
  chart: "chart",
};

interface Props {
  chart: BirthChartRow;
  open: boolean;
  onOpenChange: (open: boolean) => void;
  initialTab?: AshTab;
}

function DrawerInner({ chart, onClose, initialTab }: { chart: BirthChartRow; onClose: () => void; initialTab?: AshTab }) {
  const { t, i18n } = useTranslation("common");
  const language: "en" | "hi" = i18n.language?.startsWith("hi") ? "hi" : "en";
  const [tab, setTab] = useState<AshTab>(initialTab ?? "sarva");
  const [explainerOpen, setExplainerOpen] = useState(false);
  const share = useShare();
  const { triggerPrint } = usePrint();

  useEffect(() => {
    if (initialTab) setTab(initialTab);
  }, [initialTab]);

  const { data, loading, error, reload } = useAshtakavargaReport({
    birthChartId: chart.id, language, enabled: true,
  });

  const handleShare = () => {
    const url = `${window.location.origin}/chart/${chart.id}?view=ashtakavarga&tab=${TAB_TO_PARAM[tab]}`;
    share({
      url,
      title: t("ashtakavarga.title", { defaultValue: "Ashtakavarga" }) + " Analysis",
      text: t("share.share_text_default", { defaultValue: "Check out my chart on AstroGuide" }),
    });
  };

  const handlePrint = () => {
    triggerPrint(
      `[data-print-section="ashtakavarga"]`,
      `${t("ashtakavarga.title", { defaultValue: "Ashtakavarga" })} — ${
        tab === "sarva"
          ? t("ashtakavarga.tab_sarva_table", { defaultValue: "Sarva Table" })
          : tab === "bhinna"
            ? t("ashtakavarga.tab_bhinna_table", { defaultValue: "Bhinna Table" })
            : t("ashtakavarga.tab_chart", { defaultValue: "Chart View" })
      }`
    );
  };

  return (
    <div
      className="ashtakavarga-drawer flex h-full flex-col"
      style={{
        ["--bg" as string]: "#FBF1E2",
        ["--text-primary" as string]: "#2D2419",
        ["--text-secondary" as string]: "#5A4A3A",
        ["--saffron" as string]: "#ED7B2A",
        ["--maroon" as string]: "#7A2A1E",
        ["--gold" as string]: "#D4A24C",
        ["--cell-very-high" as string]: "#F5C30A",
        ["--cell-high" as string]: "#FBF1E2",
        ["--cell-mid" as string]: "#F8F2EB",
        ["--cell-low" as string]: "#EFEAE2",
        ["--cell-very-low" as string]: "#E8E4DC",
        ["--header-bg" as string]: "#7A2A1E",
        ["--header-text" as string]: "#FBF1E2",
        ["--border" as string]: "#E5DDD3",
        ["--table-outer-border" as string]: "#ED7B2A",
        backgroundColor: "var(--bg)",
        color: "var(--text-primary)",
      }}
    >
      {/* Sticky header */}
      <header className="sticky top-0 z-10 flex items-center justify-between gap-3 border-b border-[var(--saffron)]/30 bg-[var(--bg)] px-4 py-3">
        <button type="button" onClick={onClose} className="rounded-md p-1.5 hover:bg-black/5" aria-label="Close">
          <X className="h-5 w-5" />
        </button>
        <div className="flex-1 text-center">
          <div className="text-[20px] sm:text-[24px] font-bold leading-tight">
            {t("ashtakavarga.title", { defaultValue: "Ashtakavarga" })}
          </div>
          <div
            className="text-[16px] sm:text-[18px] opacity-80"
            style={{ fontFamily: "'Tiro Devanagari Hindi', serif" }}
          >
            अष्टकवर्ग
          </div>
        </div>
        <button
          type="button"
          onClick={() => setExplainerOpen(true)}
          className="rounded-md p-1.5 hover:bg-black/5"
          aria-label="About Ashtakavarga"
        >
          <Info className="h-5 w-5 text-[var(--maroon)]" />
        </button>
      </header>

      {/* Tabs */}
      <div className="flex border-b border-[var(--saffron)]/30 bg-[var(--bg)]">
        {(["sarva", "bhinna", "chart"] as const).map((key) => {
          const active = tab === key;
          const label =
            key === "sarva"
              ? t("ashtakavarga.tab_sarva_table", { defaultValue: "Sarva Table" })
              : key === "bhinna"
                ? t("ashtakavarga.tab_bhinna_table", { defaultValue: "Bhinna Table" })
                : t("ashtakavarga.tab_chart", { defaultValue: "Chart View" });
          return (
            <button
              key={key}
              type="button"
              onClick={() => setTab(key)}
              className="flex-1 px-2 py-3 text-[13px] sm:text-[14px] transition-colors"
              style={{
                fontWeight: active ? 700 : 500,
                color: active ? "var(--saffron)" : "var(--text-secondary)",
                borderBottom: active ? "2px solid var(--saffron)" : "2px solid transparent",
              }}
            >
              {label}
            </button>
          );
        })}
      </div>

      {/* Body */}
      <div className="flex-1 overflow-y-auto px-4 py-4" data-print-section="ashtakavarga">
        {loading && !data && (
          <div className="py-10 text-center text-sm text-[var(--text-secondary)]">
            {t("ashtakavarga.loading", { defaultValue: "Calculating Ashtakavarga..." })}
          </div>
        )}
        {error && !data && (
          <div className="py-10 text-center text-sm">
            <div className="text-destructive mb-3">
              {t("ashtakavarga.error", { defaultValue: "Could not load Ashtakavarga data. Please try again." })}
            </div>
            <Button variant="outline" size="sm" onClick={reload}>
              {t("common.retry", { defaultValue: "Retry" })}
            </Button>
          </div>
        )}
        {data && (
          <>
            {tab === "sarva" && <SarvaTable sarva={data.sarva} metrics={data.metrics} />}
            {tab === "bhinna" && <BhinnaTable bhinna={data.bhinna} metrics={data.metrics} />}
            {tab === "chart" && <AshtakavargaChartTab data={data} />}
          </>
        )}
      </div>

      {/* Footer */}
      <footer
        className="sticky bottom-0 border-t border-[var(--saffron)]/30 bg-[var(--bg)] px-4 py-3 flex flex-col sm:flex-row gap-2"
        data-print-hide
      >
        <Button variant="outline" onClick={() => setExplainerOpen(true)} className="flex-1">
          <Info className="h-4 w-4" />{" "}
          {t("ashtakavarga.explainer_button", { defaultValue: "What is Ashtakavarga?" })}
        </Button>
        <Button variant="outline" onClick={handlePrint} className="flex-1">
          <Printer className="h-4 w-4" />{" "}
          {t("ashtakavarga.print_pdf", { defaultValue: "Print PDF" })}
        </Button>
        <Button variant="outline" onClick={handleShare} className="flex-1">
          <Share2 className="h-4 w-4" /> {t("ashtakavarga.share", { defaultValue: "Share" })}
        </Button>
      </footer>

      <AshtakavargaExplainerModal open={explainerOpen} onOpenChange={setExplainerOpen} />
    </div>
  );
}

export function AshtakavargaDrawer({ chart, open, onOpenChange, initialTab }: Props) {
  return (
    <Sheet open={open} onOpenChange={onOpenChange}>
      <SheetContent side="right" className="w-full sm:max-w-[480px] p-0 overflow-hidden">
        <SheetTitle className="sr-only">Ashtakavarga</SheetTitle>
        <SheetDescription className="sr-only">
          Vedic astrology bindu strength analysis showing planetary points across the twelve houses
        </SheetDescription>
        <DrawerInner chart={chart} onClose={() => onOpenChange(false)} initialTab={initialTab} />
      </SheetContent>
    </Sheet>
  );
}

export { PARAM_TO_TAB as ASHTAKAVARGA_PARAM_TO_TAB };
