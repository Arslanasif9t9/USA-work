import type { ReactNode } from "react";

// Reusable North Indian diamond skeleton with 12 house cells.
// Same geometry as src/components/chart/NorthIndianChart.tsx, but accepts
// a render-prop for cell content so it can be used for planets, bindus, etc.
//
// House numbers are FIXED to the standard North Indian convention
// (1 = top diamond, counter-clockwise). The component renders nothing
// inside cells by default — pass `renderCell` to draw bindus, planet
// labels, or anything else, anchored at each house's centroid.

const A: [number, number] = [0, 0];
const B: [number, number] = [400, 0];
const C: [number, number] = [400, 400];
const D: [number, number] = [0, 400];
const M_AB: [number, number] = [200, 0];
const M_BC: [number, number] = [400, 200];
const M_CD: [number, number] = [200, 400];
const M_DA: [number, number] = [0, 200];
const CENTER: [number, number] = [200, 200];

export interface DiamondHouseCell {
  number: number; // 1..12
  /** Polygon points (geometry only; not used by render-prop, kept for layout). */
  points: Array<[number, number]>;
  /** Centroid where labels / circles should be anchored. */
  center: [number, number];
  /** Where the small house number label sits (corner of the cell). */
  numberAnchor: [number, number];
}

// Centroid + number-anchor positions for each house. Centroids tuned so a
// round bindu circle fits comfortably; number anchors hug the outer corner.
export const DIAMOND_HOUSES: DiamondHouseCell[] = [
  { number: 1,  points: [M_DA, M_AB, CENTER],     center: [200, 130], numberAnchor: [200, 80]  },
  { number: 2,  points: [A, M_AB, M_DA],          center: [110, 75],  numberAnchor: [40, 30]   },
  { number: 3,  points: [A, M_DA, CENTER],        center: [80, 130],  numberAnchor: [30, 60]   },
  { number: 4,  points: [M_DA, CENTER, M_CD, D],  center: [130, 200], numberAnchor: [60, 200]  },
  { number: 5,  points: [D, M_DA, CENTER],        center: [80, 270],  numberAnchor: [30, 340]  },
  { number: 6,  points: [D, CENTER, M_CD],        center: [110, 325], numberAnchor: [40, 380]  },
  { number: 7,  points: [M_CD, CENTER, M_BC],     center: [200, 270], numberAnchor: [200, 340] },
  { number: 8,  points: [C, M_CD, CENTER],        center: [290, 325], numberAnchor: [360, 380] },
  { number: 9,  points: [C, CENTER, M_BC],        center: [320, 270], numberAnchor: [370, 340] },
  { number: 10, points: [M_BC, B, M_AB, CENTER],  center: [270, 200], numberAnchor: [340, 200] },
  { number: 11, points: [B, M_BC, CENTER],        center: [320, 130], numberAnchor: [370, 60]  },
  { number: 12, points: [B, CENTER, M_AB],        center: [290, 75],  numberAnchor: [360, 30]  },
];

interface Props {
  /** CSS pixel size. Component renders a square SVG. */
  size?: number;
  strokeColor?: string;
  strokeWidth?: number;
  /** Optional fill behind the diamond (defaults to transparent). */
  background?: string;
  /** Render house number labels at corners. Default true. */
  showHouseNumbers?: boolean;
  houseNumberColor?: string;
  houseNumberFontSize?: number;
  /** Per-cell content; centered at cell.center. */
  renderCell?: (cell: DiamondHouseCell) => ReactNode;
  /** Wrap each house number in a hover/tap-target group (for tooltips). */
  renderHouseNumberWrapper?: (cell: DiamondHouseCell, label: ReactNode) => ReactNode;
  ariaLabel?: string;
  className?: string;
}

export function NorthIndianDiamond({
  size = 340,
  strokeColor = "currentColor",
  strokeWidth = 2,
  background = "transparent",
  showHouseNumbers = true,
  houseNumberColor = "#3F2A1A",
  houseNumberFontSize = 11,
  renderCell,
  renderHouseNumberWrapper,
  ariaLabel = "North Indian chart",
  className,
}: Props) {
  return (
    <svg
      viewBox="0 0 400 400"
      width={size}
      height={size}
      role="img"
      aria-label={ariaLabel}
      className={className}
    >
      {/* Outer square */}
      <rect
        x="0"
        y="0"
        width="400"
        height="400"
        fill={background}
        stroke={strokeColor}
        strokeWidth={strokeWidth}
      />
      {/* Diagonals */}
      <line x1="0" y1="0" x2="400" y2="400" stroke={strokeColor} strokeWidth={strokeWidth} />
      <line x1="400" y1="0" x2="0" y2="400" stroke={strokeColor} strokeWidth={strokeWidth} />
      {/* Inner diamond */}
      <polygon
        points="200,0 400,200 200,400 0,200"
        fill="none"
        stroke={strokeColor}
        strokeWidth={strokeWidth}
      />

      {DIAMOND_HOUSES.map((cell) => {
        const numberLabel = showHouseNumbers ? (
          <text
            x={cell.numberAnchor[0]}
            y={cell.numberAnchor[1]}
            textAnchor="middle"
            fontSize={houseNumberFontSize}
            fontWeight="600"
            fill={houseNumberColor}
            dominantBaseline="middle"
            style={{ userSelect: "none" }}
          >
            {cell.number}
          </text>
        ) : null;

        return (
          <g key={cell.number}>
            {showHouseNumbers && renderHouseNumberWrapper
              ? renderHouseNumberWrapper(cell, numberLabel)
              : numberLabel}
            {renderCell?.(cell)}
          </g>
        );
      })}
    </svg>
  );
}
