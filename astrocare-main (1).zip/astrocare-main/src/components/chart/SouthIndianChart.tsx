import { groupBySign, type ChartView, SIGNS, SIGN_SHORT } from "@/lib/vedicChart";
import { PLANET_COLORS, type PlanetName } from "@/types/panchang";
import { getPlanetAbbr, planetFontFamily, type PlanetLang } from "@/types/planetTranslations";
import { useLanguage } from "@/contexts/LanguageContext";

interface Props {
  view: ChartView;
  title?: string;
}

// AstroSage-classic Vedic palette: white card, saffron strokes.
const BG = "#FFFFFF";
const STROKE = "#ED7B2A";
const HOUSE_NUM = "#555555";
const ASC_TINT = "#FFF7EC";

const VEDIC_PLANETS = new Set<string>([
  "Sun","Moon","Mars","Mercury","Jupiter","Venus","Saturn","Rahu","Ketu",
]);

// South Indian: 4x4 grid, signs FIXED.
const SIGN_GRID: Array<[number, number, number]> = [
  [11, 0, 0], [0, 1, 0], [1, 2, 0], [2, 3, 0],
  [10, 0, 1],                       [3, 3, 1],
  [9,  0, 2],                       [4, 3, 2],
  [8,  0, 3], [7, 1, 3], [6, 2, 3], [5, 3, 3],
];

const CELL = 100;

export function SouthIndianChart({ view, title }: Props) {
  const { lang: appLang } = useLanguage();
  const lang: PlanetLang = appLang === "hi" ? "hi" : "en";
  const planetFont = planetFontFamily(lang);
  const planetSize = 24;
  const bySign = groupBySign(view);

  return (
    <div className="w-full">
      {title && (
        <p
          className="text-center mb-2"
          style={{
            fontFamily: "'Inter','Roboto',system-ui,sans-serif",
            fontSize: 15,
            fontWeight: 600,
            color: "#333333",
          }}
        >
          {title}
        </p>
      )}
      <div
        className="aspect-square w-full max-w-[420px] mx-auto rounded-md overflow-hidden border"
        style={{ borderColor: "#E5E7EB", background: BG }}
      >
        <svg viewBox="0 0 400 400" className="w-full h-full" role="img" aria-label={title ?? "South Indian chart"}>
          <rect x="0" y="0" width="400" height="400" fill={BG} stroke={STROKE} strokeWidth="2" />
          <rect x={CELL} y={CELL} width={CELL * 2} height={CELL * 2} fill={BG} stroke={STROKE} strokeWidth="2" />

          {SIGN_GRID.map(([signIdx, col, row]) => {
            const x = col * CELL;
            const y = row * CELL;
            const isAsc = signIdx === view.ascSignIndex;
            const planets = (bySign[signIdx] ?? []).filter((p) => VEDIC_PLANETS.has(p.name));
            return (
              <g key={signIdx}>
                <rect
                  x={x} y={y} width={CELL} height={CELL}
                  fill="transparent"
                  stroke={STROKE}
                  strokeWidth="2"
                />
                <text x={x + 6} y={y + 14} fontSize="11" fill={HOUSE_NUM} fontWeight="400" fontFamily="'Inter','Roboto',system-ui,sans-serif">
                  {SIGN_SHORT[SIGNS[signIdx]]}
                </text>
                {isAsc && (
                  <text x={x + CELL - 6} y={y + 14} textAnchor="end" fontSize="11" fontWeight="600" fill={STROKE} fontFamily="'Inter','Roboto',system-ui,sans-serif">
                    Asc
                  </text>
                )}
                {planets.slice(0, 8).map((p, i) => {
                  const pcol = i % 2;
                  const prow = Math.floor(i / 2);
                  const color = PLANET_COLORS[p.name as PlanetName] ?? "#212121";
                  const px = x + 25 + pcol * 50;
                  const py = y + 45 + prow * 20;
                  const degLabel = p.degree > 0 ? `${Math.floor(p.degree)}` : "";
                  const abbrText = getPlanetAbbr(p.name, lang);
                  return (
                    <text
                      key={p.name}
                      x={px}
                      y={py}
                      textAnchor="middle"
                      fontSize={planetSize}
                      fontWeight="700"
                      fill={color}
                      fontFamily={planetFont}
                      textRendering="geometricPrecision"
                    >
                      {abbrText}
                      {degLabel && (
                        <tspan fontSize="10" baselineShift="super" dx="1" fontWeight="600">{degLabel}</tspan>
                      )}
                      {p.retrograde && (
                        <tspan fontSize="10" dx="2" fontWeight="600">(R)</tspan>
                      )}
                    </text>
                  );
                })}
              </g>
            );
          })}
        </svg>
      </div>
      <p
        className="text-center mt-2"
        style={{
          fontFamily: "'Inter','Roboto',system-ui,sans-serif",
          fontSize: 12,
          fontWeight: 400,
          color: "#777777",
        }}
      >
        Asc: {SIGNS[view.ascSignIndex]}
      </p>
    </div>
  );
}
