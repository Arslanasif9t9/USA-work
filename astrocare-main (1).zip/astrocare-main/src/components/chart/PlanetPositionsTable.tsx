import { useTranslation } from "react-i18next";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { useLanguage } from "@/contexts/LanguageContext";
import { tNakshatra, tPlanetFull, tSign } from "@/i18n/vedic";

// ─────────────────────────────────────────────────────────────────────────────
// Types — mirror the shape calculate-chart writes into birth_charts.chart_data
// ─────────────────────────────────────────────────────────────────────────────
export interface RawPlanetRow {
  name: string;
  longitude: number;
  sign: string;
  degree: number;
  nakshatra: string;
  pada: number;
  retrograde?: boolean;
  combust?: boolean;
}
export interface RawAscendantRow {
  longitude: number;
  sign: string;
  degree: number;
  nakshatra?: string;
  pada?: number;
}

interface Props {
  planets: RawPlanetRow[];
  ascendant: RawAscendantRow;
}

// ─────────────────────────────────────────────────────────────────────────────
// Vedic sign-relation lookup tables (Brihat Parashara)
// ─────────────────────────────────────────────────────────────────────────────
const SIGN_LORD: Record<string, string> = {
  Aries: "Mars", Taurus: "Venus", Gemini: "Mercury", Cancer: "Moon",
  Leo: "Sun", Virgo: "Mercury", Libra: "Venus", Scorpio: "Mars",
  Sagittarius: "Jupiter", Capricorn: "Saturn", Aquarius: "Saturn", Pisces: "Jupiter",
};
const FRIENDS: Record<string, string[]> = {
  Sun:     ["Moon", "Mars", "Jupiter"],
  Moon:    ["Sun", "Mercury"],
  Mars:    ["Sun", "Moon", "Jupiter"],
  Mercury: ["Sun", "Venus"],
  Jupiter: ["Sun", "Moon", "Mars"],
  Venus:   ["Mercury", "Saturn"],
  Saturn:  ["Mercury", "Venus"],
};
const ENEMIES: Record<string, string[]> = {
  Sun:     ["Venus", "Saturn"],
  Moon:    [],
  Mars:    ["Mercury"],
  Mercury: ["Moon"],
  Jupiter: ["Mercury", "Venus"],
  Venus:   ["Sun", "Moon"],
  Saturn:  ["Sun", "Moon", "Mars"],
};
const OWN: Record<string, string[]> = {
  Sun: ["Leo"], Moon: ["Cancer"], Mars: ["Aries", "Scorpio"],
  Mercury: ["Gemini", "Virgo"], Jupiter: ["Sagittarius", "Pisces"],
  Venus: ["Taurus", "Libra"], Saturn: ["Capricorn", "Aquarius"],
};
const EXALTED: Record<string, string> = {
  Sun: "Aries", Moon: "Taurus", Mars: "Capricorn", Mercury: "Virgo",
  Jupiter: "Cancer", Venus: "Pisces", Saturn: "Libra",
};
const DEBILITATED: Record<string, string> = {
  Sun: "Libra", Moon: "Scorpio", Mars: "Cancer", Mercury: "Pisces",
  Jupiter: "Capricorn", Venus: "Virgo", Saturn: "Aries",
};

type RelKey =
  | "rel_friendly" | "rel_enemy" | "rel_neutral"
  | "rel_own" | "rel_exalted" | "rel_debilitated"
  | null;

function relationKey(planet: string, sign: string): RelKey {
  if (planet === "Rahu" || planet === "Ketu") return null;
  if (EXALTED[planet] === sign) return "rel_exalted";
  if (DEBILITATED[planet] === sign) return "rel_debilitated";
  if ((OWN[planet] ?? []).includes(sign)) return "rel_own";
  const lord = SIGN_LORD[sign];
  if (!lord || lord === planet) return "rel_neutral";
  if ((FRIENDS[planet] ?? []).includes(lord)) return "rel_friendly";
  if ((ENEMIES[planet] ?? []).includes(lord)) return "rel_enemy";
  return "rel_neutral";
}

// ─────────────────────────────────────────────────────────────────────────────
// Formatting helpers
// ─────────────────────────────────────────────────────────────────────────────

/** Convert a decimal-degrees value (within a sign, 0–30) to "DD-MM-SS". */
function formatDmS(degrees: number): string {
  const total = Math.max(0, degrees);
  const d = Math.floor(total);
  const minFloat = (total - d) * 60;
  const m = Math.floor(minFloat);
  let s = Math.round((minFloat - m) * 60);
  let dd = d, mm = m;
  if (s === 60) { s = 0; mm += 1; }
  if (mm === 60) { mm = 0; dd += 1; }
  const pad = (n: number) => String(n).padStart(2, "0");
  return `${pad(dd)}-${pad(mm)}-${pad(s)}`;
}

/**
 * AstroSage uses older transliterations for some nakshatras. Normalize at
 * render-time so customers comparing against AstroSage see the same spelling.
 * This does NOT mutate the saved chart_data.
 */
const NAKSHATRA_DISPLAY_OVERRIDE: Record<string, string> = {
  "Purva Bhadrapada": "Purvabhadra",
  "Uttara Bhadrapada": "Uttarabhadra",
  "Shatabhisha": "Satabhisa",
  "Shravana": "Sravana",
  "Pushya": "Pushyami",
  "Mrigashira": "Mrigshira",
};

function displayNakshatra(name: string, lang: "en" | "hi"): string {
  if (lang === "hi") return tNakshatra(name, "hi");
  return NAKSHATRA_DISPLAY_OVERRIDE[name] ?? name;
}

/** Retrograde marker: D / R / "-" for nodes (AstroSage convention). */
function retroMarker(planet: string, retrograde: boolean | undefined): string {
  if (planet === "Rahu" || planet === "Ketu") return "–";
  return retrograde ? "R" : "D";
}

// ─────────────────────────────────────────────────────────────────────────────
// Component
// ─────────────────────────────────────────────────────────────────────────────
const ORDER = [
  "Sun", "Moon", "Mars", "Mercury", "Jupiter", "Venus", "Saturn", "Rahu", "Ketu",
];

export function PlanetPositionsTable({ planets, ascendant }: Props) {
  const { t } = useTranslation("chart");
  const { lang } = useLanguage();

  const ordered = ORDER
    .map((name) => planets.find((p) => p.name === name))
    .filter((p): p is RawPlanetRow => Boolean(p));

  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-lg">{t("planet_positions")}</CardTitle>
      </CardHeader>
      <CardContent className="px-0 sm:px-6">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead className="w-[110px]">{t("col_planets")}</TableHead>
              <TableHead className="w-[40px] text-center">{t("col_combust")}</TableHead>
              <TableHead className="w-[40px] text-center">{t("col_retro")}</TableHead>
              <TableHead>{t("col_rashi")}</TableHead>
              <TableHead className="font-mono">{t("col_longitude")}</TableHead>
              <TableHead>{t("col_nakshatra")}</TableHead>
              <TableHead className="w-[60px] text-center">{t("col_pada")}</TableHead>
              <TableHead>{t("col_relation")}</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {/* Ascendant row */}
            <TableRow>
              <TableCell className="font-medium">{t("ascendant")}</TableCell>
              <TableCell />
              <TableCell />
              <TableCell>{tSign(ascendant.sign, lang)}</TableCell>
              <TableCell className="font-mono tabular-nums">
                {formatDmS(ascendant.degree)}
              </TableCell>
              <TableCell>
                {ascendant.nakshatra ? displayNakshatra(ascendant.nakshatra, lang) : ""}
              </TableCell>
              <TableCell className="text-center">{ascendant.pada ?? ""}</TableCell>
              <TableCell />
            </TableRow>

            {ordered.map((p) => {
              const relKey = relationKey(p.name, p.sign);
              return (
                <TableRow key={p.name}>
                  <TableCell className="font-medium">
                    {tPlanetFull(p.name, lang)}
                  </TableCell>
                  <TableCell className="text-center">
                    {p.combust ? "C" : ""}
                  </TableCell>
                  <TableCell className="text-center">
                    {retroMarker(p.name, p.retrograde)}
                  </TableCell>
                  <TableCell>{tSign(p.sign, lang)}</TableCell>
                  <TableCell className="font-mono tabular-nums">
                    {formatDmS(p.degree)}
                  </TableCell>
                  <TableCell>{displayNakshatra(p.nakshatra, lang)}</TableCell>
                  <TableCell className="text-center">{p.pada}</TableCell>
                  <TableCell>{relKey ? t(relKey) : ""}</TableCell>
                </TableRow>
              );
            })}
          </TableBody>
        </Table>
      </CardContent>
    </Card>
  );
}
