import { useEffect, useState } from "react";
import { Sheet, SheetContent, SheetTitle, SheetDescription } from "@/components/ui/sheet";
import { Button } from "@/components/ui/button";
import { X, Info, Share2, Printer } from "lucide-react";
import { useTranslation } from "react-i18next";

import type { BirthChartRow } from "@/hooks/useBirthCharts";
import type { DCode } from "@/types/shodashvarga";
import { useShare } from "@/hooks/useShare";
import { usePrint } from "@/hooks/usePrint";
import { VargaChartSlot } from "./shodashvarga/VargaChartSlot";
import { SwapButton } from "./shodashvarga/SwapButton";
import { HowToReadModal } from "./shodashvarga/HowToReadModal";

interface Props {
  chart: BirthChartRow;
  open: boolean;
  onOpenChange: (open: boolean) => void;
  initialLeft?: DCode;
  initialRight?: DCode;
}

function DrawerInner({
  chart,
  onClose,
  initialLeft,
  initialRight,
}: {
  chart: BirthChartRow;
  onClose: () => void;
  initialLeft?: DCode;
  initialRight?: DCode;
}) {
  const { t, i18n } = useTranslation("common");
  const language: "en" | "hi" = i18n.language?.startsWith("hi") ? "hi" : "en";
  const [left, setLeft] = useState<DCode>(initialLeft ?? "D1");
  const [right, setRight] = useState<DCode>(initialRight ?? "D9");
  const [explainerOpen, setExplainerOpen] = useState(false);
  const share = useShare();
  const { triggerPrint } = usePrint();

  useEffect(() => {
    if (initialLeft) setLeft(initialLeft);
  }, [initialLeft]);
  useEffect(() => {
    if (initialRight) setRight(initialRight);
  }, [initialRight]);

  const handleSwap = () => {
    setLeft(right);
    setRight(left);
  };

  const handleShare = () => {
    const url = `${window.location.origin}/chart/${chart.id}?view=shodashvarga&left=${left}&right=${right}`;
    share({
      url,
      title: `${t("shodashvarga.title", { defaultValue: "Shodashvarga" })} — ${left} vs ${right}`,
      text: t("share.share_text_default", { defaultValue: "Check out my chart on AstroGuide" }),
    });
  };

  const handlePrint = () => {
    triggerPrint(
      `[data-print-section="shodashvarga"]`,
      `${t("shodashvarga.title", { defaultValue: "Shodashvarga" })} — ${left} vs ${right}`
    );
  };

  return (
    <div
      className="shodashvarga-drawer flex h-full flex-col"
      style={{
        ["--bg" as string]: "#FBF1E2",
        ["--text-primary" as string]: "#2D2419",
        ["--text-secondary" as string]: "#5A4A3A",
        ["--saffron" as string]: "#ED7B2A",
        ["--maroon" as string]: "#7A2A1E",
        ["--gold" as string]: "#D4A24C",
        backgroundColor: "var(--bg)",
        color: "var(--text-primary)",
      }}
    >
      {/* Sticky header */}
      <header className="sticky top-0 z-10 flex items-center justify-between gap-3 border-b border-[var(--saffron)]/30 bg-[var(--bg)] px-4 py-3">
        <button type="button" onClick={onClose} className="rounded-md p-1.5 hover:bg-black/5" aria-label="Close" data-print-hide>
          <X className="h-5 w-5" />
        </button>
        <div className="flex-1 text-center">
          <div className="text-[20px] sm:text-[24px] font-bold leading-tight">
            {t("shodashvarga.title", { defaultValue: "Shodashvarga" })}
          </div>
          <div
            className="text-[16px] sm:text-[18px] opacity-80"
            style={{ fontFamily: "'Tiro Devanagari Hindi', serif" }}
          >
            षोडशवर्ग
          </div>
        </div>
        <button
          type="button"
          onClick={() => setExplainerOpen(true)}
          className="rounded-md p-1.5 hover:bg-black/5"
          aria-label="About Shodashvarga"
          data-print-hide
        >
          <Info className="h-5 w-5 text-[var(--maroon)]" />
        </button>
      </header>

      {/* Body */}
      <div className="flex-1 overflow-y-auto px-3 py-4" data-print-section="shodashvarga">
        <VargaChartSlot
          birthChartId={chart.id}
          selected={left}
          onSelect={setLeft}
          language={language}
          ariaLabel={t("shodashvarga.select_varga", { defaultValue: "Choose chart" }) + " (1)"}
        />
        <SwapButton
          onClick={handleSwap}
          ariaLabel={t("shodashvarga.swap", { defaultValue: "Swap charts" })}
        />
        <VargaChartSlot
          birthChartId={chart.id}
          selected={right}
          onSelect={setRight}
          language={language}
          ariaLabel={t("shodashvarga.select_varga", { defaultValue: "Choose chart" }) + " (2)"}
        />
      </div>

      {/* Footer */}
      <footer
        className="sticky bottom-0 border-t border-[var(--saffron)]/30 bg-[var(--bg)] px-4 py-3 flex flex-col sm:flex-row gap-2"
        data-print-hide
      >
        <Button variant="outline" onClick={() => setExplainerOpen(true)} className="flex-1">
          <Info className="h-4 w-4" /> {t("shodashvarga.how_to_read", { defaultValue: "How to read this" })}
        </Button>
        <Button variant="outline" onClick={handlePrint} className="flex-1">
          <Printer className="h-4 w-4" /> {t("shodashvarga.print", { defaultValue: "Print" })}
        </Button>
        <Button variant="outline" onClick={handleShare} className="flex-1">
          <Share2 className="h-4 w-4" /> {t("shodashvarga.share", { defaultValue: "Share" })}
        </Button>
      </footer>

      <HowToReadModal open={explainerOpen} onOpenChange={setExplainerOpen} />
    </div>
  );
}

export function ShodashvargaDrawer({ chart, open, onOpenChange, initialLeft, initialRight }: Props) {
  return (
    <Sheet open={open} onOpenChange={onOpenChange}>
      <SheetContent side="right" className="w-full sm:max-w-[480px] p-0 overflow-hidden">
        <SheetTitle className="sr-only">Shodashvarga</SheetTitle>
        <SheetDescription className="sr-only">
          Vedic divisional chart comparison — view two divisional charts side by side
        </SheetDescription>
        <DrawerInner chart={chart} onClose={() => onOpenChange(false)} initialLeft={initialLeft} initialRight={initialRight} />
      </SheetContent>
    </Sheet>
  );
}
