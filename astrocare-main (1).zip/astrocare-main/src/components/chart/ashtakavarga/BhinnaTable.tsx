import { useTranslation } from "react-i18next";
import { StrengthCell } from "./StrengthCell";
import {
  ASHTAKAVARGA_PLANETS, bhinnaStrength,
  type AshtakavargaPlanetKey, type BhinnaData, type AshtakavargaMetrics, type StrengthLevel,
} from "@/types/ashtakavarga";
import { PLANET_COLORS, PLANET_ABBR, type PlanetName } from "@/types/panchang";

interface Props {
  bhinna: BhinnaData;
  metrics: AshtakavargaMetrics;
}

const PLANET_DISPLAY: Record<AshtakavargaPlanetKey, PlanetName> = {
  sun: "Sun", moon: "Moon", mars: "Mars", mercury: "Mercury",
  jupiter: "Jupiter", venus: "Venus", saturn: "Saturn",
};

const PLANET_HI: Record<AshtakavargaPlanetKey, string> = {
  sun: "सूर्य", moon: "चंद्र", mars: "मंगल", mercury: "बुध",
  jupiter: "गुरु", venus: "शुक्र", saturn: "शनि",
};

export function BhinnaTable({ bhinna, metrics }: Props) {
  const { t, i18n } = useTranslation("common");
  const isHi = i18n.language?.startsWith("hi");
  const strengthLabel = (lv: StrengthLevel) =>
    t(`ashtakavarga.strength_${lv}`, { defaultValue: lv.replace("_", " ") });

  return (
    <div className="space-y-3">
      <div className="text-[11px] text-[var(--text-secondary)] sm:hidden">
        ← {t("ashtakavarga.scroll_hint", { defaultValue: "Scroll horizontally to see all houses" })} →
      </div>

      <div className="relative rounded-md border-[1.5px] border-[var(--table-outer-border)] overflow-hidden">
        <div className="overflow-x-auto">
          <table className="border-collapse" style={{ minWidth: "100%" }}>
            <thead>
              <tr>
                <th
                  className="sticky left-0 z-20 h-8 px-2 text-left text-[11px] uppercase font-semibold border-r border-[var(--border)]"
                  style={{ backgroundColor: "var(--header-bg)", color: "var(--header-text)" }}
                >
                  {t("ashtakavarga.planet", { defaultValue: "Planet" })}
                </th>
                {Array.from({ length: 12 }, (_, i) => (
                  <th
                    key={i}
                    className="h-8 w-8 sm:w-9 text-[11px] font-semibold border-r border-[var(--border)]"
                    style={{ backgroundColor: "var(--header-bg)", color: "var(--header-text)" }}
                  >
                    {i + 1}
                  </th>
                ))}
                <th
                  className="h-8 px-2 text-[11px] uppercase font-semibold"
                  style={{ backgroundColor: "var(--header-bg)", color: "var(--header-text)" }}
                >
                  {t("ashtakavarga.total", { defaultValue: "Total" })}
                </th>
              </tr>
            </thead>
            <tbody>
              {ASHTAKAVARGA_PLANETS.map((p) => {
                const display = PLANET_DISPLAY[p];
                const color = PLANET_COLORS[display];
                const label = isHi ? PLANET_HI[p] : PLANET_ABBR[display];
                return (
                  <tr key={p}>
                    <th
                      className="sticky left-0 z-10 h-8 px-2 text-left text-[12px] font-semibold border-r border-[var(--border)]"
                      style={{ backgroundColor: "var(--bg)" }}
                    >
                      <span className="inline-flex items-center gap-1.5">
                        <span className="h-2.5 w-2.5 rounded-full" style={{ backgroundColor: color }} />
                        <span style={{ color }}>{label}</span>
                      </span>
                    </th>
                    {bhinna[p].map((v, h) => {
                      const lv = bhinnaStrength(v);
                      const tip = t("ashtakavarga.cell_bhinna_tip", {
                        defaultValue: `${isHi ? PLANET_HI[p] : display}, House ${h + 1} — ${v} bindus (${strengthLabel(lv)})`,
                        planet: isHi ? PLANET_HI[p] : display,
                        house: h + 1, bindus: v, strength: strengthLabel(lv),
                      });
                      return (
                        <td key={h} className="p-0">
                          <StrengthCell value={v} strength={lv} tooltip={tip} size="sm" />
                        </td>
                      );
                    })}
                    <td
                      className="h-7 px-2 text-center text-[12px] font-semibold border-l border-[var(--border)]"
                      style={{ backgroundColor: "var(--cell-mid)" }}
                    >
                      {metrics.planetTotals[p]}
                    </td>
                  </tr>
                );
              })}
              {/* Bottom totals row */}
              <tr>
                <th
                  className="sticky left-0 z-10 h-7 px-2 text-left text-[11px] uppercase font-semibold border-r border-[var(--border)] border-t"
                  style={{ backgroundColor: "var(--cell-high)" }}
                >
                  {t("ashtakavarga.total", { defaultValue: "Total" })}
                </th>
                {metrics.houseTotals.map((v, i) => (
                  <td
                    key={i}
                    className="h-7 text-center text-[12px] font-semibold border-r border-t border-[var(--border)]"
                    style={{ backgroundColor: "var(--cell-high)" }}
                  >
                    {v}
                  </td>
                ))}
                <td
                  className="h-7 text-center text-[12px] font-bold border-l border-t border-[var(--border)]"
                  style={{ backgroundColor: "var(--cell-very-high)" }}
                >
                  {metrics.houseTotals.reduce((a, b) => a + b, 0)}
                </td>
              </tr>
            </tbody>
          </table>
        </div>
        {/* Right edge scroll-hint gradient on mobile */}
        <div
          className="sm:hidden pointer-events-none absolute top-0 right-0 bottom-0 w-6"
          style={{ background: "linear-gradient(to left, rgba(251,241,226,0.95), rgba(251,241,226,0))" }}
        />
      </div>
    </div>
  );
}
