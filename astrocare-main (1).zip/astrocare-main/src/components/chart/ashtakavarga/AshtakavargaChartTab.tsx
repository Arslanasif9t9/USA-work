import { useState } from "react";
import { useTranslation } from "react-i18next";
import { IndicatorLegend } from "./IndicatorLegend";
import { SarvaDiamondChart } from "./SarvaDiamondChart";
import { BhinnaDiamondGrid } from "./BhinnaDiamondGrid";
import type { AshtakavargaReport } from "@/types/ashtakavarga";

interface Props {
  data: AshtakavargaReport;
}

export function AshtakavargaChartTab({ data }: Props) {
  const { t } = useTranslation("common");
  const [view, setView] = useState<"sarva" | "bhinna">("sarva");

  return (
    <div className="space-y-4">
      {/* Sub-toggle */}
      <div
        className="inline-flex w-full rounded-md border border-[var(--saffron)]/30 overflow-hidden"
        role="tablist"
      >
        {(["sarva", "bhinna"] as const).map((key) => {
          const active = view === key;
          const label =
            key === "sarva"
              ? t("ashtakavarga.subtoggle_sarva", { defaultValue: "Sarva" })
              : t("ashtakavarga.subtoggle_bhinna", { defaultValue: "Bhinna" });
          return (
            <button
              key={key}
              type="button"
              role="tab"
              aria-selected={active}
              onClick={() => setView(key)}
              className="flex-1 px-3 py-2 text-[13px] transition-colors"
              style={{
                fontWeight: active ? 700 : 500,
                color: active ? "var(--saffron)" : "var(--text-secondary)",
                backgroundColor: active ? "rgba(237,123,42,0.10)" : "transparent",
                borderBottom: active ? "2px solid var(--saffron)" : "2px solid transparent",
              }}
            >
              {label}
            </button>
          );
        })}
      </div>

      {/* Legend */}
      <IndicatorLegend variant={view} />

      {/* Chart area with cross-fade */}
      <div className="relative" key={view}>
        <div className="animate-in fade-in duration-200">
          {view === "sarva" ? (
            <SarvaDiamondChart sarva={data.sarva} metrics={data.metrics} />
          ) : (
            <BhinnaDiamondGrid bhinna={data.bhinna} metrics={data.metrics} />
          )}
        </div>
      </div>
    </div>
  );
}
