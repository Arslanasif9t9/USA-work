import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { useTranslation } from "react-i18next";

interface Props {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export function AshtakavargaExplainerModal({ open, onOpenChange }: Props) {
  const { t } = useTranslation("common");
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-[480px]">
        <DialogHeader>
          <DialogTitle>{t("ashtakavarga.explainer_title", { defaultValue: "Understanding Ashtakavarga" })}</DialogTitle>
          <DialogDescription className="sr-only">
            {t("ashtakavarga.explainer_a11y", { defaultValue: "Explanation of how Sarva and Bhinna Ashtakavarga bindus quantify planetary strength across houses" })}
          </DialogDescription>
        </DialogHeader>
        <div className="text-[15px] leading-[1.6] whitespace-pre-line text-foreground">
          {t("ashtakavarga.explainer_body", {
            defaultValue:
              "Ashtakavarga is a Vedic astrology system that quantifies planetary strength across the 12 houses of your chart. Each planet contributes 'bindus' (auspicious points) to each house — more bindus mean greater auspiciousness for that life area.\n\nSarva (Combined) shows the total bindus per house from all 7 planets. Houses with 30+ bindus are strong life areas; below 25 are weaker.\n\nBhinna (Per-Planet) shows how each planet individually contributes to each house. A planet with 7-8 bindus in its associated house indicates strong manifestation of that planet's significations.",
          })}
        </div>
      </DialogContent>
    </Dialog>
  );
}
