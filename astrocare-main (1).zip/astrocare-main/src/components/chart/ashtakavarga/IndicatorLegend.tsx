import { useTranslation } from "react-i18next";
import { ASHTAKAVARGA_CHART_COLORS } from "@/constants/ashtakavargaChartColors";

interface Props {
  variant: "sarva" | "bhinna";
}

const C = ASHTAKAVARGA_CHART_COLORS.bindu;

export function IndicatorLegend({ variant }: Props) {
  const { t } = useTranslation("common");

  const items =
    variant === "sarva"
      ? [
          {
            color: C.auspicious,
            label: t("ashtakavarga.legend_auspicious", { defaultValue: "Auspicious" }),
            range: t("ashtakavarga.legend_sarva_threshold", { defaultValue: "≥30 bindus" }),
          },
          {
            color: C.mixed,
            label: t("ashtakavarga.legend_mixed", { defaultValue: "Mixed" }),
            range: t("ashtakavarga.legend_sarva_mixed", { defaultValue: "28-29" }),
          },
          {
            color: C.inauspicious,
            label: t("ashtakavarga.legend_inauspicious", { defaultValue: "Inauspicious" }),
            range: t("ashtakavarga.legend_sarva_low", { defaultValue: "≤27" }),
          },
        ]
      : [
          {
            color: C.auspicious,
            label: t("ashtakavarga.legend_auspicious", { defaultValue: "Auspicious" }),
            range: t("ashtakavarga.legend_bhinna_threshold", { defaultValue: "≥6 bindus" }),
          },
          {
            color: C.mixed,
            label: t("ashtakavarga.legend_mixed", { defaultValue: "Mixed" }),
            range: t("ashtakavarga.legend_bhinna_mixed", { defaultValue: "4-5" }),
          },
          {
            color: C.inauspicious,
            label: t("ashtakavarga.legend_inauspicious", { defaultValue: "Inauspicious" }),
            range: t("ashtakavarga.legend_bhinna_low", { defaultValue: "≤3" }),
          },
        ];

  return (
    <div className="flex flex-wrap items-center justify-center gap-x-4 gap-y-1.5 text-[12px]">
      {items.map((it) => (
        <div key={it.label} className="inline-flex items-center gap-1.5">
          <span
            className="inline-block h-2.5 w-2.5 rounded-full"
            style={{ backgroundColor: it.color }}
            aria-hidden
          />
          <span style={{ color: "var(--text-primary)", fontWeight: 600 }}>{it.label}</span>
          <span style={{ color: "var(--text-secondary)" }}>{it.range}</span>
        </div>
      ))}
    </div>
  );
}
