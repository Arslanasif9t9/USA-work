import type { CSSProperties } from "react";
import {
  type BinduStrength,
  binduFill,
  binduTextFill,
  ASHTAKAVARGA_CHART_COLORS,
} from "@/constants/ashtakavargaChartColors";

interface Props {
  cx: number;
  cy: number;
  r: number;
  value: number;
  strength: BinduStrength;
  fontSize: number;
  /** Show pulsing saffron ring (one-shot). */
  highlight?: boolean;
  /** Show static subtle ring (no animation) — for Bhinna mini diamonds. */
  staticRing?: boolean;
  /** Tooltip text; rendered as <title> for native hover/tap. */
  tooltip?: string;
  onClick?: () => void;
}

const pulseStyle: CSSProperties = {
  transformOrigin: "center",
  animation: "ashtakavarga-ring-pulse 2s ease-out 1 forwards",
};

export function BinduCircle({
  cx,
  cy,
  r,
  value,
  strength,
  fontSize,
  highlight,
  staticRing,
  tooltip,
  onClick,
}: Props) {
  const fill = binduFill(strength);
  const textFill = binduTextFill(strength);
  const ringColor = ASHTAKAVARGA_CHART_COLORS.strongestHouseRing;

  return (
    <g
      onClick={onClick}
      style={{ cursor: onClick ? "pointer" : "default" }}
    >
      {tooltip && <title>{tooltip}</title>}
      {highlight && (
        <circle
          cx={cx}
          cy={cy}
          r={r + 5}
          fill="none"
          stroke={ringColor}
          strokeWidth={4}
          opacity={0}
          style={pulseStyle}
        />
      )}
      {staticRing && !highlight && (
        <circle
          cx={cx}
          cy={cy}
          r={r + 3}
          fill="none"
          stroke={ringColor}
          strokeWidth={2}
          opacity={0.5}
        />
      )}
      <circle cx={cx} cy={cy} r={r} fill={fill} />
      <text
        x={cx}
        y={cy}
        textAnchor="middle"
        dominantBaseline="central"
        fontSize={fontSize}
        fontWeight={700}
        fill={textFill}
        style={{ userSelect: "none", pointerEvents: "none" }}
      >
        {value}
      </text>
    </g>
  );
}
