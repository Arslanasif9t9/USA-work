import { useState } from "react";
import { useTranslation } from "react-i18next";
import { ChevronLeft } from "lucide-react";
import { BhinnaMiniDiamond } from "./BhinnaMiniDiamond";
import { ASHTAKAVARGA_PLANETS, type BhinnaData, type AshtakavargaPlanetKey, type AshtakavargaMetrics } from "@/types/ashtakavarga";

interface Props {
  bhinna: BhinnaData;
  metrics: AshtakavargaMetrics;
}

export function BhinnaDiamondGrid({ bhinna, metrics }: Props) {
  const { t } = useTranslation("common");
  const [expanded, setExpanded] = useState<AshtakavargaPlanetKey | null>(null);

  if (expanded) {
    return (
      <div className="flex flex-col items-center gap-3">
        <button
          type="button"
          onClick={() => setExpanded(null)}
          className="self-start inline-flex items-center gap-1 rounded-md px-2 py-1 text-[13px] font-medium hover:bg-black/5"
          style={{ color: "var(--maroon)" }}
        >
          <ChevronLeft className="h-4 w-4" />
          {t("ashtakavarga.back_to_grid", { defaultValue: "Back to all planets" })}
        </button>
        <BhinnaMiniDiamond
          planetKey={expanded}
          houses={bhinna[expanded]}
          total={metrics.planetTotals[expanded]}
          expanded
          onExpand={() => setExpanded(null)}
        />
      </div>
    );
  }

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 gap-x-3 gap-y-5">
      {ASHTAKAVARGA_PLANETS.map((p) => (
        <BhinnaMiniDiamond
          key={p}
          planetKey={p}
          houses={bhinna[p]}
          total={metrics.planetTotals[p]}
          onExpand={() => setExpanded(p)}
        />
      ))}
    </div>
  );
}
