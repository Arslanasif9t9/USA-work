import { useTranslation } from "react-i18next";
import { StrengthCell } from "./StrengthCell";
import { sarvaStrength, type SarvaData, type AshtakavargaMetrics, type StrengthLevel } from "@/types/ashtakavarga";

interface Props {
  sarva: SarvaData;
  metrics: AshtakavargaMetrics;
}

export function SarvaTable({ sarva, metrics }: Props) {
  const { t } = useTranslation("common");
  const strengthLabel = (lv: StrengthLevel) =>
    t(`ashtakavarga.strength_${lv}`, { defaultValue: lv.replace("_", " ") });

  return (
    <div className="space-y-4">
      <div className="rounded-md overflow-hidden border-[1.5px] border-[var(--table-outer-border)]">
        {/* Header row */}
        <div className="grid grid-cols-12">
          {Array.from({ length: 12 }, (_, i) => (
            <div
              key={i}
              className="h-8 flex items-center justify-center text-[11px] sm:text-[12px] uppercase font-semibold border-r border-[var(--border)] last:border-r-0"
              style={{ backgroundColor: "var(--header-bg)", color: "var(--header-text)" }}
            >
              {i + 1}
            </div>
          ))}
        </div>
        {/* Body row */}
        <div className="grid grid-cols-12">
          {sarva.houses.map((bindus, i) => {
            const lv = sarvaStrength(bindus);
            const tip = t("ashtakavarga.cell_sarva_tip", {
              defaultValue: `House ${i + 1} — ${bindus} bindus (${strengthLabel(lv)})`,
              house: i + 1, bindus, strength: strengthLabel(lv),
            });
            return <StrengthCell key={i} value={bindus} strength={lv} tooltip={tip} />;
          })}
        </div>
      </div>

      {/* Total */}
      <div className="text-center text-sm">
        <span className="font-semibold">{t("ashtakavarga.total", { defaultValue: "Total" })}:</span>{" "}
        <span className={sarva.total === 337 ? "" : "text-destructive"} style={{ fontWeight: 600 }}>
          {sarva.total}
        </span>
        {sarva.total === 337 && <span className="ml-1 opacity-60">✓</span>}
      </div>

      {/* Strongest / Weakest callouts */}
      <div className="flex flex-col sm:flex-row gap-2">
        <div
          className="flex-1 rounded-full px-4 py-2 text-sm font-medium text-center animate-pulse-once"
          style={{ backgroundColor: "var(--cell-very-high)", color: "var(--text-primary)" }}
        >
          {t("ashtakavarga.strongest_house", { defaultValue: "Strongest house" })}:{" "}
          <strong>{metrics.sarvaStrongestHouse.house}</strong>{" "}
          ({metrics.sarvaStrongestHouse.bindus} {t("ashtakavarga.bindus", { defaultValue: "bindus" })})
        </div>
        <div
          className="flex-1 rounded-full px-4 py-2 text-sm font-medium text-center"
          style={{ backgroundColor: "var(--cell-low)", color: "var(--text-secondary)" }}
        >
          {t("ashtakavarga.weakest_house", { defaultValue: "Weakest house" })}:{" "}
          <strong>{metrics.sarvaWeakestHouse.house}</strong>{" "}
          ({metrics.sarvaWeakestHouse.bindus} {t("ashtakavarga.bindus", { defaultValue: "bindus" })})
        </div>
      </div>
    </div>
  );
}
