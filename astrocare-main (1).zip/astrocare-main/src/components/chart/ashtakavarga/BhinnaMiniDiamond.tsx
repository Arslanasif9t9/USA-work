import { useMemo } from "react";
import { useTranslation } from "react-i18next";
import { NorthIndianDiamond } from "../NorthIndianDiamond";
import { BinduCircle } from "./BinduCircle";
import {
  ASHTAKAVARGA_CHART_COLORS,
  getBhinnaStrength,
} from "@/constants/ashtakavargaChartColors";
import { HOUSE_MEANINGS_EN, HOUSE_MEANINGS_HI } from "@/constants/houseMeanings";
import { PLANET_COLORS, PLANET_ABBR, type PlanetName } from "@/types/panchang";
import type { AshtakavargaPlanetKey } from "@/types/ashtakavarga";

interface Props {
  planetKey: AshtakavargaPlanetKey;
  houses: number[];
  total: number;
  /** Render larger when expanded on mobile. */
  expanded?: boolean;
  onExpand?: () => void;
}

const PLANET_DISPLAY: Record<AshtakavargaPlanetKey, PlanetName> = {
  sun: "Sun", moon: "Moon", mars: "Mars", mercury: "Mercury",
  jupiter: "Jupiter", venus: "Venus", saturn: "Saturn",
};

const PLANET_HI: Record<AshtakavargaPlanetKey, string> = {
  sun: "सूर्य", moon: "चंद्र", mars: "मंगल", mercury: "बुध",
  jupiter: "गुरु", venus: "शुक्र", saturn: "शनि",
};

export function BhinnaMiniDiamond({
  planetKey,
  houses,
  total,
  expanded,
  onExpand,
}: Props) {
  const { t, i18n } = useTranslation("common");
  const isHi = i18n.language?.startsWith("hi");
  const meanings = isHi ? HOUSE_MEANINGS_HI : HOUSE_MEANINGS_EN;

  const display = PLANET_DISPLAY[planetKey];
  const color = PLANET_COLORS[display];
  const code = PLANET_ABBR[display];
  const planetName = isHi ? PLANET_HI[planetKey] : display;

  const strongestIdx = houses.reduce(
    (best, v, i, arr) => (v > arr[best] ? i : best),
    0,
  );

  // viewBox is fixed 400; just scale the SVG render size.
  const size = expanded ? 320 : 140;
  const r = expanded ? 32 : 30;
  const fontSize = expanded ? 18 : 16;

  const strengthLabel = (s: ReturnType<typeof getBhinnaStrength>) =>
    t(`ashtakavarga.legend_${s}`, {
      defaultValue: s === "auspicious" ? "Auspicious" : s === "mixed" ? "Mixed" : "Inauspicious",
    });

  const tipFor = useMemo(
    () => (house: number, v: number) => {
      const s = getBhinnaStrength(v);
      return t("ashtakavarga.tooltip_planet_house_bindus", {
        defaultValue: `${planetName}, House ${house} — ${v} bindus (${strengthLabel(s)})`,
        planet: planetName,
        house,
        bindus: v,
        strength: strengthLabel(s),
      });
    },
    [t, planetName, i18n.language],
  );

  const headerInteractive = !!onExpand;

  return (
    <div className="flex flex-col items-center gap-1.5">
      <button
        type="button"
        disabled={!headerInteractive}
        onClick={onExpand}
        className="flex items-center gap-2 text-left disabled:cursor-default"
        aria-label={
          expanded
            ? t("ashtakavarga.back_to_grid", { defaultValue: "Back to all planets" })
            : t("ashtakavarga.expand_planet", { defaultValue: "Tap to expand" })
        }
      >
        <span
          className="inline-flex items-center justify-center rounded-md px-1.5 py-0.5 text-[11px] font-bold"
          style={{ backgroundColor: color, color: "#fff" }}
        >
          {code}
        </span>
        <span className="text-[12px] font-semibold" style={{ color: "var(--text-primary)" }}>
          {planetName}
        </span>
        <span className="text-[11px]" style={{ color: "var(--text-secondary)" }}>
          {t("ashtakavarga.planet_total", {
            defaultValue: `${planetName}: ${total} total`,
            planet: planetName,
            total,
          })}
        </span>
      </button>

      <div style={{ width: size, height: size }}>
        <NorthIndianDiamond
          size={size}
          strokeColor={ASHTAKAVARGA_CHART_COLORS.diamondStroke}
          strokeWidth={1.5}
          houseNumberColor={ASHTAKAVARGA_CHART_COLORS.houseNumber}
          houseNumberFontSize={expanded ? 11 : 10}
          ariaLabel={`${planetName} Bhinna Ashtakavarga`}
          className="w-full h-full"
          renderHouseNumberWrapper={(cell, label) => (
            <g>
              <title>{`${t("ashtakavarga.house", { defaultValue: "House" })} ${cell.number}: ${meanings[cell.number]}`}</title>
              {label}
            </g>
          )}
          renderCell={(cell) => {
            const i = cell.number - 1;
            const v = houses[i] ?? 0;
            const s = getBhinnaStrength(v);
            return (
              <BinduCircle
                cx={cell.center[0]}
                cy={cell.center[1]}
                r={r}
                value={v}
                strength={s}
                fontSize={fontSize}
                staticRing={i === strongestIdx}
                tooltip={tipFor(cell.number, v)}
              />
            );
          }}
        />
      </div>
    </div>
  );
}
