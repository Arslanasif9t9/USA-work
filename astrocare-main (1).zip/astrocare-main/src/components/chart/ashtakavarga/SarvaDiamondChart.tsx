import { useMemo } from "react";
import { useTranslation } from "react-i18next";
import { NorthIndianDiamond } from "../NorthIndianDiamond";
import { BinduCircle } from "./BinduCircle";
import {
  ASHTAKAVARGA_CHART_COLORS,
  getSarvaStrength,
} from "@/constants/ashtakavargaChartColors";
import { HOUSE_MEANINGS_EN, HOUSE_MEANINGS_HI } from "@/constants/houseMeanings";
import type { SarvaData, AshtakavargaMetrics } from "@/types/ashtakavarga";

interface Props {
  sarva: SarvaData;
  metrics: AshtakavargaMetrics;
}

export function SarvaDiamondChart({ sarva, metrics }: Props) {
  const { t, i18n } = useTranslation("common");
  const isHi = i18n.language?.startsWith("hi");
  const meanings = isHi ? HOUSE_MEANINGS_HI : HOUSE_MEANINGS_EN;

  const strongestIdx = metrics.sarvaStrongestHouse.house - 1;

  // r is the bindu circle radius in the 400x400 viewBox.
  // ~36px on a ~340px-wide chart → 36 / 340 * 400 ≈ 42.
  const r = 32;
  const fontSize = 18;

  const strengthLabel = (s: ReturnType<typeof getSarvaStrength>) =>
    t(`ashtakavarga.strength_${s}`, {
      defaultValue: s === "auspicious" ? "Auspicious" : s === "mixed" ? "Mixed" : "Inauspicious",
    });

  const tipForHouse = useMemo(
    () => (house: number, value: number) => {
      const s = getSarvaStrength(value);
      return t("ashtakavarga.tooltip_house_bindus", {
        defaultValue: `House ${house} — ${value} bindus (${strengthLabel(s)})`,
        house,
        bindus: value,
        strength: strengthLabel(s),
      });
    },
    [t, i18n.language],
  );

  return (
    <div className="w-full flex justify-center">
      <div className="w-full max-w-[360px]">
        <NorthIndianDiamond
          size={340}
          strokeColor={ASHTAKAVARGA_CHART_COLORS.diamondStroke}
          strokeWidth={2}
          houseNumberColor={ASHTAKAVARGA_CHART_COLORS.houseNumber}
          houseNumberFontSize={11}
          ariaLabel="Sarva Ashtakavarga diamond chart"
          className="w-full h-auto"
          renderHouseNumberWrapper={(cell, label) => (
            <g>
              <title>
                {`${t("ashtakavarga.house", { defaultValue: "House" })} ${cell.number}: ${meanings[cell.number]}`}
              </title>
              {label}
            </g>
          )}
          renderCell={(cell) => {
            const i = cell.number - 1;
            const value = sarva.houses[i] ?? 0;
            const s = getSarvaStrength(value);
            return (
              <BinduCircle
                cx={cell.center[0]}
                cy={cell.center[1]}
                r={r}
                value={value}
                strength={s}
                fontSize={fontSize}
                highlight={i === strongestIdx}
                tooltip={tipForHouse(cell.number, value)}
              />
            );
          }}
        />
      </div>
    </div>
  );
}
