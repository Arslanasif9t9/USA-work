import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import type { StrengthLevel } from "@/types/ashtakavarga";

const BG_BY_STRENGTH: Record<StrengthLevel, string> = {
  very_high: "var(--cell-very-high)",
  high: "var(--cell-high)",
  mid: "var(--cell-mid)",
  low: "var(--cell-low)",
  very_low: "var(--cell-very-low)",
};

interface Props {
  value: number;
  strength: StrengthLevel;
  tooltip: string;
  size?: "sm" | "md";
  bold?: boolean;
}

export function StrengthCell({ value, strength, tooltip, size = "md", bold }: Props) {
  const isVH = strength === "very_high";
  const fontWeight = bold || isVH ? 700 : 500;
  const dim =
    size === "sm" ? "h-7 min-w-[28px] text-[12px]" : "h-9 min-w-[36px] text-[13px] sm:text-[14px]";
  return (
    <TooltipProvider delayDuration={150}>
      <Tooltip>
        <TooltipTrigger asChild>
          <div
            className={`${dim} flex items-center justify-center border border-[var(--border)] cursor-default transition-colors`}
            style={{
              backgroundColor: BG_BY_STRENGTH[strength],
              color: strength === "very_low" ? "var(--text-secondary)" : "var(--text-primary)",
              fontWeight,
            }}
          >
            {value}
          </div>
        </TooltipTrigger>
        <TooltipContent className="text-xs max-w-[220px]">{tooltip}</TooltipContent>
      </Tooltip>
    </TooltipProvider>
  );
}
