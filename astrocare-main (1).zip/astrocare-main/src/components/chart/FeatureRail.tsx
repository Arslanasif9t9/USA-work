import { useEffect, useState } from "react";
import { useSearchParams } from "react-router-dom";
import { Sheet, SheetContent, SheetTitle, SheetDescription } from "@/components/ui/sheet";
import { Button } from "@/components/ui/button";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { Sparkles, Grid3x3, Layers, Printer, Share2, MoreVertical, X, Info } from "lucide-react";
import { useTranslation } from "react-i18next";
import { useNakshatraReport } from "@/hooks/useNakshatraReport";
import { useShare } from "@/hooks/useShare";
import { usePrint } from "@/hooks/usePrint";
import type { BirthChartRow } from "@/hooks/useBirthCharts";
import type { ChartData } from "@/lib/vedicChart";
import type { DCode } from "@/types/shodashvarga";
import { AshtakavargaDrawer } from "./AshtakavargaDrawer";
import { ShodashvargaDrawer } from "./ShodashvargaDrawer";
import { isLocalChartId, buildShareableChartUrl } from "@/lib/localCharts";

type AshTab = "sarva" | "bhinna" | "chart";
const ASH_PARAM_TO_TAB: Record<string, AshTab> = {
  "sarva-table": "sarva",
  "bhinna-table": "bhinna",
  chart: "chart",
};

interface Props {
  chart: BirthChartRow;
}

const PLANET_COLOR: Record<string, string> = {
  Sun: "#E94E1B", Moon: "#7B5FB0", Mars: "#C0392B", Mercury: "#2E8B57",
  Jupiter: "#D4A24C", Venus: "#D87CB0", Saturn: "#34495E",
  Rahu: "#5D4037", Ketu: "#6B4226",
};

function ComingSoonButton({ icon: Icon, label }: { icon: React.ComponentType<{ className?: string }>; label: string }) {
  const { t } = useTranslation("common");
  return (
    <TooltipProvider>
      <Tooltip>
        <TooltipTrigger asChild>
          <span>
            <Button variant="outline" size="icon" disabled className="opacity-60 cursor-not-allowed">
              <Icon className="h-4 w-4" />
              <span className="sr-only">{label}</span>
            </Button>
          </span>
        </TooltipTrigger>
        <TooltipContent>{label} — {t("nakshatra.coming_soon", { defaultValue: "Coming soon" })}</TooltipContent>
      </Tooltip>
    </TooltipProvider>
  );
}

function JargonChip({ label, value, tooltip }: { label: string; value: string; tooltip: string }) {
  return (
    <TooltipProvider>
      <Tooltip>
        <TooltipTrigger asChild>
          <button type="button" className="flex flex-col items-start gap-1 rounded-lg border border-[var(--divider)] bg-[var(--card-bg)] p-3 text-left hover:border-[var(--saffron)] transition-colors min-w-0 flex-1">
            <span className="text-[11px] font-semibold uppercase tracking-wide text-[var(--text-secondary)] flex items-center gap-1">
              {label} <Info className="h-3 w-3 opacity-60" />
            </span>
            <span className="text-[13px] font-medium text-[var(--text-primary)] truncate w-full">{value}</span>
          </button>
        </TooltipTrigger>
        <TooltipContent className="max-w-[260px] text-xs">{tooltip}</TooltipContent>
      </Tooltip>
    </TooltipProvider>
  );
}

function NakshatraDrawerContent({ chart, onClose }: { chart: BirthChartRow; onClose: () => void }) {
  const { t, i18n } = useTranslation("common");
  const language: "en" | "hi" = i18n.language?.startsWith("hi") ? "hi" : "en";
  const isHi = language === "hi";

  const cd = chart.chart_data as unknown as ChartData | null;
  const moonLon = cd?.planets?.find(p => p.name === "Moon")?.longitude ?? null;

  const { data, loading, error } = useNakshatraReport({
    birthChartId: chart.id,
    language,
    enabled: true,
    moonLongitude: moonLon,
  });

  const share = useShare();
  const { triggerPrint } = usePrint();

  const nakshatraName = data?.static
    ? (isHi ? data.static.nameHindi : data.static.name)
    : "";

  const handleShare = () => {
    const baseUrl = `${window.location.origin}/chart/${chart.id}?view=nakshatra`;
    // For anonymous (local-) charts, embed the chart in the URL hash so the
    // recipient can open the link on any device — sessionStorage is per-browser.
    const url = isLocalChartId(chart.id)
      ? buildShareableChartUrl(chart, baseUrl)
      : baseUrl;
    share({
      url,
      title: `${t("nakshatra.title", { defaultValue: "Nakshatra Report" })}${nakshatraName ? " — " + nakshatraName : ""}`,
      text: t("share.share_text_default", { defaultValue: "Check out my chart on AstroGuide" }),
    });
  };

  const handlePrint = () => {
    triggerPrint(
      `[data-print-section="nakshatra-report"]`,
      `${t("nakshatra.title", { defaultValue: "Nakshatra Report" })}${nakshatraName ? " — " + nakshatraName : ""}`
    );
  };

  if (loading && !data) {
    return <div className="p-6 text-center text-sm text-[var(--text-secondary)]">{t("common.loading", { defaultValue: "Loading…" })}</div>;
  }
  if (error && !data) {
    return <div className="p-6 text-center text-sm text-destructive">{error}</div>;
  }
  if (!data) {
    return <div className="p-6 text-center text-sm">{t("nakshatra.unavailable", { defaultValue: "Nakshatra unavailable" })}</div>;
  }

  const s = data.static;
  const apiPersonality = (data.api_response as { description?: string; personality?: string })?.description
    || (data.api_response as { description?: string; personality?: string })?.personality;
  const personality = apiPersonality || (isHi ? s.personalityHindi : s.personality);
  const planetColor = PLANET_COLOR[s.lord] || "var(--saffron)";

  const dispName = isHi ? s.nameHindi : s.name;
  const dispMeaning = isHi ? s.meaningHindi : s.meaning;
  const dispLord = isHi ? s.lordHindi : s.lord;
  const dispDeity = isHi ? s.deityHindi : s.deity;
  const dispBody = isHi ? s.bodyPartHindi : s.bodyPart;

  return (
    <div className="nakshatra-drawer flex h-full flex-col" style={{
      ["--bg" as string]: "#FBF1E2",
      ["--text-primary" as string]: "#2D2419",
      ["--text-secondary" as string]: "#5A4A3A",
      ["--saffron" as string]: "#ED7B2A",
      ["--maroon" as string]: "#7A2A1E",
      ["--gold" as string]: "#D4A24C",
      ["--pada-active-bg" as string]: "#F5C30A",
      ["--pada-rest-bg" as string]: "#FFF6EB",
      ["--divider" as string]: "rgba(237, 123, 42, 0.3)",
      ["--card-bg" as string]: "#FFFFFF",
      backgroundColor: "var(--bg)",
      color: "var(--text-primary)",
    }}>
      {/* Sticky header */}
      <header className="sticky top-0 z-10 flex items-center justify-between gap-3 border-b border-[var(--divider)] bg-[var(--bg)] px-4 py-3">
        <button type="button" onClick={onClose} className="rounded-md p-1.5 hover:bg-black/5" aria-label="Close">
          <X className="h-5 w-5" />
        </button>
        <div className="flex-1 text-center">
          <div className="text-[20px] sm:text-[24px] font-bold leading-tight">{dispName}</div>
          <div className="text-[16px] sm:text-[18px] opacity-80">{isHi ? s.name : s.nameHindi}</div>
        </div>
        <div className="h-12 w-12 rounded-full border-2 border-[var(--saffron)] bg-[var(--card-bg)] flex items-center justify-center text-2xl">
          {s.symbolIcon}
        </div>
      </header>

      {/* Scrollable body */}
      <div className="flex-1 overflow-y-auto px-4 py-4 space-y-5" data-print-section="nakshatra-report">
        {/* 1. Symbol & meaning */}
        <section className="flex items-center gap-3 border-b border-[var(--divider)] pb-4">
          <div className="text-4xl">{s.symbolIcon}</div>
          <div>
            <div className="text-sm font-semibold">{s.symbol}</div>
            <div className="text-xs italic text-[var(--text-secondary)]">{dispMeaning}</div>
          </div>
        </section>

        {/* 2. Pada */}
        <section>
          <h3 className="text-[12px] font-semibold uppercase tracking-wide mb-2">{t("nakshatra.your_pada", { defaultValue: "Your Pada" })}</h3>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
            {s.padas.map((p, i) => {
              const active = i + 1 === data.pada;
              return (
                <div key={i} className="rounded-lg border p-2 text-center" style={{
                  backgroundColor: active ? "var(--pada-active-bg)" : "var(--pada-rest-bg)",
                  borderColor: active ? "var(--gold)" : "var(--divider)",
                }}>
                  <div className="text-[11px] uppercase opacity-70">Pada {i + 1}</div>
                  <div className="text-lg font-bold">{p.syllable}</div>
                  <div className="text-[10px] mt-1">{isHi ? p.characteristicHindi : p.characteristic}</div>
                </div>
              );
            })}
          </div>
        </section>

        {/* 3. Ruling planet */}
        <section className="rounded-lg border border-[var(--divider)] bg-[var(--card-bg)] p-3">
          <div className="text-[12px] uppercase font-semibold tracking-wide mb-1">{t("nakshatra.ruling_planet", { defaultValue: "Ruling Planet" })}</div>
          <div className="flex items-center gap-2">
            <span className="h-3 w-3 rounded-full" style={{ backgroundColor: planetColor }} />
            <span className="text-base font-semibold" style={{ color: planetColor }}>{dispLord}</span>
          </div>
        </section>

        {/* 4. Deity */}
        <section className="rounded-lg border border-[var(--divider)] bg-[var(--card-bg)] p-3">
          <div className="text-[12px] uppercase font-semibold tracking-wide mb-1">{t("nakshatra.deity", { defaultValue: "Deity" })}</div>
          <div className="text-base font-semibold">{dispDeity}</div>
        </section>

        {/* 5. Classification row 1 */}
        <section className="flex gap-2 flex-wrap">
          <JargonChip label={t("nakshatra.gana", { defaultValue: "GANA" })} value={isHi ? s.ganaHindi : s.gana} tooltip={t("nakshatra.tooltip_gana", { defaultValue: "Temperament category." })} />
          <JargonChip label={t("nakshatra.yoni", { defaultValue: "YONI" })} value={isHi ? s.yoniHindi : s.yoni} tooltip={t("nakshatra.tooltip_yoni", { defaultValue: "Animal symbol used for compatibility." })} />
          <JargonChip label={t("nakshatra.nadi", { defaultValue: "NADI" })} value={isHi ? s.nadiHindi : s.nadi} tooltip={t("nakshatra.tooltip_nadi", { defaultValue: "Pulse classification." })} />
        </section>

        {/* 6. Classification row 2 */}
        <section className="flex gap-2 flex-wrap">
          <JargonChip label={t("nakshatra.varna", { defaultValue: "VARNA" })} value={isHi ? s.varnaHindi : s.varna} tooltip={t("nakshatra.tooltip_varna", { defaultValue: "Cultural classification." })} />
          <JargonChip label={t("nakshatra.tatva", { defaultValue: "TATVA" })} value={isHi ? s.tatvaHindi : s.tatva} tooltip={t("nakshatra.tooltip_tatva", { defaultValue: "Element." })} />
          <JargonChip label={t("nakshatra.direction", { defaultValue: "DIRECTION" })} value={isHi ? s.directionHindi : s.direction} tooltip={t("nakshatra.tooltip_direction", { defaultValue: "Associated direction." })} />
        </section>

        {/* 7. Symbol / Color / Body */}
        <section className="grid grid-cols-3 gap-2">
          <div className="rounded-lg border border-[var(--divider)] bg-[var(--card-bg)] p-3 text-center">
            <div className="text-2xl">{s.symbolIcon}</div>
            <div className="text-[10px] uppercase mt-1 opacity-70">{t("nakshatra.symbol", { defaultValue: "Symbol" })}</div>
            <div className="text-[12px] font-medium">{s.animal}</div>
          </div>
          <div className="rounded-lg border border-[var(--divider)] bg-[var(--card-bg)] p-3 text-center">
            <div className="mx-auto h-6 w-6 rounded-full border" style={{ backgroundColor: s.colorHex }} />
            <div className="text-[10px] uppercase mt-1 opacity-70">{t("nakshatra.color", { defaultValue: "Color" })}</div>
            <div className="text-[12px] font-medium">{s.color}</div>
          </div>
          <div className="rounded-lg border border-[var(--divider)] bg-[var(--card-bg)] p-3 text-center">
            <div className="text-xl">🦴</div>
            <div className="text-[10px] uppercase mt-1 opacity-70">{t("nakshatra.body_part", { defaultValue: "Body Part" })}</div>
            <div className="text-[12px] font-medium">{dispBody}</div>
          </div>
        </section>

        {/* 8. Mantra */}
        <section className="rounded-lg bg-[var(--card-bg)] p-4 border-l-4" style={{ borderLeftColor: "var(--maroon)" }}>
          <div className="text-[11px] uppercase font-semibold tracking-wide opacity-70 mb-2">{t("nakshatra.mantra", { defaultValue: "Mantra" })}</div>
          <div className="text-[18px] font-medium" style={{ fontFamily: "'Tiro Devanagari Sanskrit', 'Tiro Devanagari Hindi', serif" }}>{s.mantra}</div>
          <div className="text-[13px] italic opacity-80 mt-1">{s.mantraTransliteration}</div>
        </section>

        {/* 9. Personality */}
        <section>
          <h3 className="text-[12px] uppercase font-semibold tracking-wide mb-2">{t("nakshatra.personality", { defaultValue: "Personality" })}</h3>
          <p className="text-[15px] leading-[1.6]" style={isHi ? { fontFamily: "'Mukta', 'Tiro Devanagari Hindi', serif" } : undefined}>
            {personality}
          </p>
        </section>

        {/* 10. Career & Strengths */}
        {(s.career.length > 0 || s.strengths.length > 0) && (
          <section className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {s.career.length > 0 && (
              <div>
                <h4 className="text-[12px] uppercase font-semibold tracking-wide mb-2">{t("nakshatra.career", { defaultValue: "Career" })}</h4>
                <ul className="text-sm space-y-1 list-disc list-inside">
                  {(isHi ? s.careerHindi : s.career).map((c, i) => <li key={i}>{c}</li>)}
                </ul>
              </div>
            )}
            {s.strengths.length > 0 && (
              <div>
                <h4 className="text-[12px] uppercase font-semibold tracking-wide mb-2">{t("nakshatra.strengths", { defaultValue: "Strengths" })}</h4>
                <ul className="text-sm space-y-1 list-disc list-inside">
                  {(isHi ? s.strengthsHindi : s.strengths).map((c, i) => <li key={i}>{c}</li>)}
                </ul>
              </div>
            )}
          </section>
        )}
      </div>

      {/* Sticky footer */}
      <footer
        className="sticky bottom-0 border-t border-[var(--divider)] bg-[var(--bg)] px-4 py-3 flex flex-col sm:flex-row gap-2"
        data-print-hide
      >
        <Button variant="outline" onClick={handlePrint} className="flex-1">
          <Printer className="h-4 w-4" /> {t("nakshatra.print", { defaultValue: "Print" })}
        </Button>
        <Button variant="outline" onClick={handleShare} className="flex-1">
          <Share2 className="h-4 w-4" /> {t("nakshatra.share", { defaultValue: "Share" })}
        </Button>
      </footer>
    </div>
  );
}

export function FeatureRail({ chart }: Props) {
  const [open, setOpen] = useState(false);
  const [ashtakaOpen, setAshtakaOpen] = useState(false);
  const [shodashOpen, setShodashOpen] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  const [searchParams, setSearchParams] = useSearchParams();
  const { t } = useTranslation("common");
  const ashtakaLabel = t("ashtakavarga.title", { defaultValue: "Ashtakavarga" });
  const shodashLabel = t("shodashvarga.title", { defaultValue: "Shodashvarga" });

  const viewParam = searchParams.get("view");
  const tabParam = searchParams.get("tab");
  const leftParam = searchParams.get("left") as DCode | null;
  const rightParam = searchParams.get("right") as DCode | null;

  const initialAshTab: AshTab | undefined = tabParam ? ASH_PARAM_TO_TAB[tabParam] : undefined;

  // Deep-link: open relevant drawer on mount / when view param changes
  useEffect(() => {
    if (viewParam === "nakshatra") setOpen(true);
    else if (viewParam === "ashtakavarga") setAshtakaOpen(true);
    else if (viewParam === "shodashvarga") setShodashOpen(true);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [viewParam]);

  const cleanDeepLinkParams = () => {
    const next = new URLSearchParams(searchParams);
    let changed = false;
    ["view", "tab", "left", "right"].forEach((k) => {
      if (next.has(k)) {
        next.delete(k);
        changed = true;
      }
    });
    if (changed) setSearchParams(next, { replace: true });
  };

  const handleNakshatraOpenChange = (next: boolean) => {
    setOpen(next);
    if (!next) cleanDeepLinkParams();
  };
  const handleAshtakaOpenChange = (next: boolean) => {
    setAshtakaOpen(next);
    if (!next) cleanDeepLinkParams();
  };
  const handleShodashOpenChange = (next: boolean) => {
    setShodashOpen(next);
    if (!next) cleanDeepLinkParams();
  };

  const NakshatraButton = (
    <Button
      variant="outline"
      size="icon"
      onClick={() => { setOpen(true); setMobileOpen(false); }}
      className="border-[#ED7B2A]/40 hover:bg-[#FBF1E2] hover:border-[#ED7B2A]"
      title={t("nakshatra.title", { defaultValue: "Nakshatra Report" })}
    >
      <Sparkles className="h-4 w-4 text-[#ED7B2A]" />
    </Button>
  );

  const AshtakaButton = (
    <Button
      variant="outline"
      size="icon"
      onClick={() => { setAshtakaOpen(true); setMobileOpen(false); }}
      className="border-[#ED7B2A]/40 hover:bg-[#FBF1E2] hover:border-[#ED7B2A]"
      title={ashtakaLabel}
    >
      <Grid3x3 className="h-4 w-4 text-[#ED7B2A]" />
    </Button>
  );

  const ShodashButton = (
    <Button
      variant="outline"
      size="icon"
      onClick={() => { setShodashOpen(true); setMobileOpen(false); }}
      className="border-[#ED7B2A]/40 hover:bg-[#FBF1E2] hover:border-[#ED7B2A]"
      title={shodashLabel}
    >
      <Layers className="h-4 w-4 text-[#ED7B2A]" />
    </Button>
  );

  return (
    <>
      {/* Desktop vertical rail */}
      <div className="hidden md:flex fixed right-4 top-1/2 -translate-y-1/2 z-30 flex-col gap-2 rounded-full border border-border bg-card/95 backdrop-blur p-2 shadow-lg">
        {NakshatraButton}
        {AshtakaButton}
        {ShodashButton}
      </div>

      {/* Mobile floating More button */}
      <div className="md:hidden fixed bottom-20 right-4 z-30">
        <Button size="icon" onClick={() => setMobileOpen(true)} className="rounded-full h-12 w-12 shadow-lg bg-[#ED7B2A] hover:bg-[#D86E20]">
          <MoreVertical className="h-5 w-5" />
        </Button>
      </div>

      {/* Mobile bottom sheet for feature picker */}
      <Sheet open={mobileOpen} onOpenChange={setMobileOpen}>
        <SheetContent side="bottom" className="h-auto pb-6">
          <SheetTitle className="sr-only">{t("chart.features", { defaultValue: "Chart features" })}</SheetTitle>
          <SheetDescription className="sr-only">{t("chart.features_desc", { defaultValue: "Open Nakshatra report, Ashtakavarga, and other chart tools" })}</SheetDescription>
          <div className="grid grid-cols-2 gap-3 pt-4">
            <Button variant="outline" onClick={() => { setOpen(true); setMobileOpen(false); }} className="h-20 flex-col gap-1">
              <Sparkles className="h-5 w-5 text-[#ED7B2A]" />
              <span className="text-xs">{t("nakshatra.title", { defaultValue: "Nakshatra Report" })}</span>
            </Button>
            <Button variant="outline" onClick={() => { setAshtakaOpen(true); setMobileOpen(false); }} className="h-20 flex-col gap-1">
              <Grid3x3 className="h-5 w-5 text-[#ED7B2A]" />
              <span className="text-xs">{ashtakaLabel}</span>
            </Button>
            <Button variant="outline" onClick={() => { setShodashOpen(true); setMobileOpen(false); }} className="h-20 flex-col gap-1">
              <Layers className="h-5 w-5 text-[#ED7B2A]" />
              <span className="text-xs">{shodashLabel}</span>
            </Button>
          </div>
        </SheetContent>
      </Sheet>

      {/* Nakshatra report drawer */}
      <Sheet open={open} onOpenChange={handleNakshatraOpenChange}>
        <SheetContent side="right" className="w-full sm:max-w-[480px] p-0 overflow-hidden">
          <SheetTitle className="sr-only">{t("nakshatra.title", { defaultValue: "Nakshatra Report" })}</SheetTitle>
          <SheetDescription className="sr-only">{t("nakshatra.description_a11y", { defaultValue: "Detailed Vedic nakshatra report including classifications, mantras, and personality essay" })}</SheetDescription>
          <NakshatraDrawerContent chart={chart} onClose={() => handleNakshatraOpenChange(false)} />
        </SheetContent>
      </Sheet>

      {/* Ashtakavarga drawer */}
      <AshtakavargaDrawer
        chart={chart}
        open={ashtakaOpen}
        onOpenChange={handleAshtakaOpenChange}
        initialTab={initialAshTab}
      />

      {/* Shodashvarga drawer */}
      <ShodashvargaDrawer
        chart={chart}
        open={shodashOpen}
        onOpenChange={handleShodashOpenChange}
        initialLeft={leftParam ?? undefined}
        initialRight={rightParam ?? undefined}
      />
    </>
  );
}
