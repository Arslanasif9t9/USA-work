import { groupByHouse, type ChartView, SIGN_SHORT, SIGNS } from "@/lib/vedicChart";
import { PLANET_COLORS, type PlanetName } from "@/types/panchang";
import { getPlanetAbbr, planetFontFamily, type PlanetLang } from "@/types/planetTranslations";
import { useLanguage } from "@/contexts/LanguageContext";

interface Props {
  view: ChartView;
  title?: string;
}

// AstroSage-classic Vedic palette: white card, saffron strokes.
const BG = "#FFFFFF";
const STROKE = "#ED7B2A";        // saffron brand
const HOUSE_NUM = "#555555";     // neutral dark gray
const ASC_TINT = "#FFF7EC";      // very subtle saffron tint for asc cell

// 9 classical Vedic Grahas only — outer planets are intentionally excluded.
const VEDIC_PLANETS = new Set<string>([
  "Sun","Moon","Mars","Mercury","Jupiter","Venus","Saturn","Rahu","Ketu",
]);

// Rectangular 700x500 viewBox (1.4:1).
const A: [number, number] = [0, 0];
const B: [number, number] = [700, 0];
const C: [number, number] = [700, 500];
const D: [number, number] = [0, 500];
const M_AB: [number, number] = [350, 0];
const M_BC: [number, number] = [700, 250];
const M_CD: [number, number] = [350, 500];
const M_DA: [number, number] = [0, 250];
const CENTER: [number, number] = [350, 250];

interface HouseDef {
  number: number;
  points: Array<[number, number]>;
  /** Where the sign-number digit sits — at the inner vertex (closest to centre). */
  numAt: [number, number];
  /** Where the planet glyph stack starts. */
  glyphAt: [number, number];
}

// Coordinates scaled from the original 400x400 layout: x*1.75, y*1.25.
const HOUSES: HouseDef[] = [
  { number: 1,  points: [M_DA, M_AB, CENTER],            numAt: [350, 219], glyphAt: [350, 113] },
  { number: 2,  points: [A, M_AB, M_DA],                 numAt: [228, 131], glyphAt: [175, 69]  },
  { number: 3,  points: [A, M_DA, CENTER],               numAt: [184, 163], glyphAt: [96,  125] },
  { number: 4,  points: [M_DA, CENTER, M_CD, D],         numAt: [306, 250], glyphAt: [175, 250] },
  { number: 5,  points: [D, M_DA, CENTER],               numAt: [184, 338], glyphAt: [96,  375] },
  { number: 6,  points: [D, CENTER, M_CD],               numAt: [228, 369], glyphAt: [175, 431] },
  { number: 7,  points: [M_CD, CENTER, M_BC],            numAt: [350, 281], glyphAt: [350, 400] },
  { number: 8,  points: [C, M_CD, CENTER],               numAt: [472, 369], glyphAt: [525, 431] },
  { number: 9,  points: [C, CENTER, M_BC],               numAt: [516, 338], glyphAt: [604, 375] },
  { number: 10, points: [M_BC, B, M_AB, CENTER],         numAt: [394, 250], glyphAt: [525, 250] },
  { number: 11, points: [B, M_BC, CENTER],               numAt: [516, 163], glyphAt: [604, 125] },
  { number: 12, points: [B, CENTER, M_AB],               numAt: [472, 131], glyphAt: [525, 69]  },
];

function pointsAttr(pts: Array<[number, number]>) {
  return pts.map(([x, y]) => `${x},${y}`).join(" ");
}

export function NorthIndianChart({ view, title }: Props) {
  const { lang: appLang } = useLanguage();
  const lang: PlanetLang = appLang === "hi" ? "hi" : "en";
  const planetFont = planetFontFamily(lang);
  const planetSize = 26;
  const byHouse = groupByHouse(view);
  const signForHouse = (h: number) => (view.ascSignIndex + h - 1) % 12;

  return (
    <div className="w-full">
      {title && (
        <p
          className="text-center mb-2"
          style={{
            fontFamily: "'Inter','Roboto',system-ui,sans-serif",
            fontSize: 15,
            fontWeight: 600,
            color: "#333333",
          }}
        >
          {title}
        </p>
      )}
      <div
        className="w-full mx-auto rounded-md overflow-hidden border"
        style={{ borderColor: "#E5E7EB", background: BG, maxWidth: 700, aspectRatio: "7 / 5" }}
      >
        <svg viewBox="0 0 700 500" className="w-full h-full" role="img" aria-label={title ?? "North Indian chart"}>
          <rect x="0" y="0" width="700" height="500" fill={BG} />


          {/* Outer rectangle + diagonals + inner diamond — saffron hairlines */}
          <rect x="0" y="0" width="700" height="500" fill="none" stroke={STROKE} strokeWidth="2" />
          <line x1="0" y1="0" x2="700" y2="500" stroke={STROKE} strokeWidth="1.5" />
          <line x1="700" y1="0" x2="0" y2="500" stroke={STROKE} strokeWidth="1.5" />
          <polygon points="350,0 700,250 350,500 0,250" fill="none" stroke={STROKE} strokeWidth="1.5" />

          {HOUSES.map((h) => {
            const planets = (byHouse[h.number] ?? []).filter((p) => VEDIC_PLANETS.has(p.name));
            const signIdx = signForHouse(h.number);
            const [nx, ny] = h.numAt;
            const [gx, gy] = h.glyphAt;
            return (
              <g key={h.number}>
                <text
                  x={nx}
                  y={ny}
                  textAnchor="middle"
                  fontSize="11"
                  fontWeight="400"
                  fill={HOUSE_NUM}
                  fontFamily="'Inter','Roboto',system-ui,sans-serif"
                >
                  {signIdx + 1}
                </text>
                {planets.map((p, idx) => {
                  const color = PLANET_COLORS[p.name as PlanetName] ?? "#212121";
                  const degLabel = p.degree > 0 ? `${Math.floor(p.degree)}` : "";
                  const abbrText = getPlanetAbbr(p.name, lang);
                  return (
                    <text
                      key={p.name}
                      x={gx}
                      y={gy + idx * 24}
                      textAnchor="middle"
                      fontSize={planetSize}
                      fontWeight="700"
                      fill={color}
                      fontFamily={planetFont}
                      textRendering="geometricPrecision"
                    >
                      {abbrText}
                      {degLabel && (
                        <tspan fontSize="13" baselineShift="super" dx="1" fontWeight="600">{degLabel}</tspan>
                      )}
                      {p.retrograde && (
                        <tspan fontSize="13" dx="2" fontWeight="600">(R)</tspan>
                      )}
                    </text>
                  );
                })}
              </g>
            );
          })}
        </svg>
      </div>
      <p
        className="text-center mt-2"
        style={{
          fontFamily: "'Inter','Roboto',system-ui,sans-serif",
          fontSize: 12,
          fontWeight: 400,
          color: "#777777",
        }}
      >
        Asc: {SIGNS[view.ascSignIndex]} ({SIGN_SHORT[SIGNS[view.ascSignIndex]]})
      </p>
    </div>
  );
}
