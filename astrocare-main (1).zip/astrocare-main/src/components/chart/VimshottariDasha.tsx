import { useMemo, useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Sparkles, AlertTriangle, Loader2, ArrowUp } from "lucide-react";
import { cn } from "@/lib/utils";
import {
  PLANET_COLORS, type DashaNode, type DashaTree, type DashaLord,
} from "@/lib/dasha";
import { useTranslation } from "react-i18next";
import {
  getPlanetAbbr, getPlanetFull, planetFontFamily, type PlanetLang,
} from "@/types/planetTranslations";

type Status = "idle" | "loading" | "computing" | "ready" | "error";
type Level = "maha" | "antar" | "pratyantar" | "sookshma";

interface Props {
  status: Status;
  error: string | null;
  tree: DashaTree | null;
  onCompute: () => void;
}

interface Crumb {
  level: Level;
  lord: DashaLord;
  startKey: string;
}

const NEXT_LEVEL: Record<Level, Level | null> = {
  maha: "antar",
  antar: "pratyantar",
  pratyantar: "sookshma",
  sookshma: null,
};

function formatDDMMYYYY(iso: string): string {
  const d = new Date(iso);
  if (isNaN(d.getTime())) return iso;
  return `${d.getDate()}/${d.getMonth() + 1}/${d.getFullYear()}`;
}

function isCurrent(node: DashaNode, now: Date): boolean {
  const t = now.getTime();
  return t >= new Date(node.start).getTime() && t < new Date(node.end).getTime();
}

/** Compute remaining balance of the current outermost dasha as Y M D. */
function computeBalance(currentEnd: string, now: Date) {
  const end = new Date(currentEnd);
  let years = end.getFullYear() - now.getFullYear();
  let months = end.getMonth() - now.getMonth();
  let days = end.getDate() - now.getDate();
  if (days < 0) { months -= 1; days += 30; }
  if (months < 0) { years -= 1; months += 12; }
  return { years: Math.max(0, years), months: Math.max(0, months), days: Math.max(0, days) };
}

export function VimshottariDasha({ status, error, tree, onCompute }: Props) {
  const { i18n } = useTranslation();
  const lang: PlanetLang = i18n.language?.startsWith("hi") ? "hi" : "en";
  const planetFont = planetFontFamily(lang);
  const now = useMemo(() => new Date(), []);
  const [crumbs, setCrumbs] = useState<Crumb[]>([]);

  const { displayNodes, currentLevel } = useMemo(() => {
    if (!tree) return { displayNodes: [] as DashaNode[], currentLevel: "maha" as Level };
    let nodes: DashaNode[] = tree.mahadashas;
    let level: Level = "maha";
    for (const c of crumbs) {
      const found = nodes.find((n) => n.start === c.startKey);
      if (!found || !found.children?.length) break;
      nodes = found.children;
      level = NEXT_LEVEL[c.level] ?? level;
    }
    return { displayNodes: nodes, currentLevel: level };
  }, [tree, crumbs]);

  function drillInto(node: DashaNode) {
    if (!node.children?.length) return;
    setCrumbs((prev) => [
      ...prev,
      { level: currentLevel, lord: node.lord, startKey: node.start },
    ]);
  }

  function levelUp() {
    setCrumbs((prev) => prev.slice(0, -1));
  }

  // Header label changes per level for clarity.
  const titleByLevel: Record<Level, { en: string; hi: string }> = {
    maha:       { en: "Vimshottari Dasha",          hi: "विंशोत्तरी दशा" },
    antar:      { en: "Antar Dasha",                hi: "अंतर दशा" },
    pratyantar: { en: "Pratyantar Dasha",           hi: "प्रत्यंतर दशा" },
    sookshma:   { en: "Sookshma Dasha",             hi: "सूक्ष्म दशा" },
  };

  // Balance: derived from the current outermost (Maha) dasha if at root,
  // otherwise from the parent we drilled into.
  const balanceRow: { lord: DashaLord; end: string } | null = useMemo(() => {
    if (!tree) return null;
    if (crumbs.length === 0) {
      const cur = tree.mahadashas.find((n) => isCurrent(n, now));
      return cur ? { lord: cur.lord, end: cur.end } : null;
    }
    const last = crumbs[crumbs.length - 1];
    return { lord: last.lord, end: "" }; // end shown at row level instead
  }, [tree, crumbs, now]);

  // Hierarchy prefix (e.g. ["Ra","Sa"]) for current view derived from breadcrumbs.
  const ancestorAbbrs = crumbs.map((c) => getPlanetAbbr(c.lord, lang));

  const labels = {
    balanceOf: lang === "hi" ? "दशा का शेष:" : "Balance Of Dasha:",
    note:      lang === "hi" ? "नोट:" : "Note:",
    tap:       lang === "hi"
      ? "उप-दशा देखने के लिए किसी भी पंक्ति पर क्लिक करें।"
      : "Please tap any row to show sub-dasha.",
    levelUp:   lang === "hi" ? "स्तर बढ़ाएं" : "LEVEL UP",
    fullLink:  lang === "hi" ? "पूर्ण विंशोत्तरी दशा प्राप्त करें" : "Get full Vimshottari Dasha",
    nowTag:    lang === "hi" ? "अभी" : "NOW",
    yShort:    lang === "hi" ? "व" : "Y",
    mShort:    lang === "hi" ? "मा" : "M",
    dShort:    lang === "hi" ? "दि" : "D",
    compute:   lang === "hi" ? "विंशोत्तरी दशा गणना करें" : "Compute Vimshottari Dasha",
    intro:     lang === "hi"
      ? "अपनी पूर्ण विंशोत्तरी दशा की गणना करें — 120 वर्षों का ग्रह कालखंड।"
      : "Compute your full Vimshottari Dasha — a 120-year map of planetary periods.",
    loading:   lang === "hi" ? "दशा लोड हो रही है…" : "Loading Dasha…",
    computing: lang === "hi" ? "आपकी 120-वर्षीय ग्रह समय-रेखा की गणना…" : "Computing your 120-year planetary timeline…",
    retry:     lang === "hi" ? "पुनः प्रयास" : "Retry",
    errorMsg:  lang === "hi"
      ? "दशा की गणना नहीं हो सकी। कृपया जन्म समय की पुष्टि करें।"
      : "Could not compute Dasha. Please verify your birth time is accurate.",
  };

  return (
    <Card className="bg-white max-w-[420px] mx-auto p-0 overflow-hidden border border-[#E5E7EB]">
      {/* Cream header */}
      <div className="bg-[#FFF8E7] px-4 py-3 border-b border-[#E5E7EB]">
        <h3
          className="text-[18px] font-semibold text-[#3F2A1A]"
          style={{ fontFamily: "'Fraunces', Georgia, serif" }}
        >
          {titleByLevel[currentLevel][lang]}
        </h3>
      </div>

      <CardContent className="p-0">
        {(status === "loading" || status === "computing") && (
          <div className="p-4 space-y-3">
            <div className="flex items-center gap-2 text-sm text-muted-foreground">
              <Loader2 className="h-4 w-4 animate-spin" />
              {status === "computing" ? labels.computing : labels.loading}
            </div>
            <div className="space-y-2">
              {Array.from({ length: 6 }).map((_, i) => (
                <Skeleton key={i} className="h-10 w-full" />
              ))}
            </div>
          </div>
        )}

        {status === "error" && (
          <div className="p-4 space-y-3">
            <Alert variant="destructive">
              <AlertTriangle className="h-4 w-4" />
              <AlertDescription>{error || labels.errorMsg}</AlertDescription>
            </Alert>
            <Button variant="outline" size="sm" onClick={onCompute}>{labels.retry}</Button>
          </div>
        )}

        {status === "idle" && (
          <div className="text-center py-6 px-4 space-y-3">
            <p className="text-sm text-muted-foreground">{labels.intro}</p>
            <Button
              className="bg-[#ED7B2A] hover:bg-[#D86E20] text-white"
              onClick={onCompute}
            >
              <Sparkles className="h-4 w-4 mr-1" />
              {labels.compute}
            </Button>
          </div>
        )}

        {status === "ready" && tree && (
          <>
            {/* Balance Of Dasha */}
            {balanceRow && balanceRow.end && (() => {
              const bal = computeBalance(balanceRow.end, now);
              const lordFull = getPlanetFull(balanceRow.lord, lang).toUpperCase();
              return (
                <div className="px-4 py-3 border-b border-[#E5E7EB] bg-white">
                  <div className="text-[13px] text-[#3F2A1A]">
                    <span className="font-medium">{labels.balanceOf}</span>{" "}
                    <span style={{ fontFamily: planetFont }} className="font-semibold">
                      {lordFull}
                    </span>{" "}
                    <span>
                      {bal.years} {labels.yShort} {bal.months} {labels.mShort} {bal.days} {labels.dShort}
                    </span>
                  </div>
                </div>
              );
            })()}

            {/* Hint */}
            {NEXT_LEVEL[currentLevel] && (
              <div className="px-4 py-2 text-[11px] text-muted-foreground border-b border-[#F0F0F0]">
                <span className="font-semibold">{labels.note}</span> {labels.tap}
              </div>
            )}

            {/* Table */}
            <div className="bg-white">
              {displayNodes.map((node, idx) => {
                const active = isCurrent(node, now);
                const c = PLANET_COLORS[node.lord];
                const drillable = !!node.children?.length;
                const ownAbbr = getPlanetAbbr(node.lord, lang);
                const labelChain = [...ancestorAbbrs, ownAbbr].join(" - ");
                const zebra = idx % 2 === 1;
                return (
                  <div
                    key={node.start}
                    onClick={() => drillable && drillInto(node)}
                    className={cn(
                      "flex items-center justify-between px-4 py-3 border-b border-[#F0F0F0] transition-colors min-h-[40px]",
                      zebra && !active && "bg-[#FAFAFA]",
                      drillable && "cursor-pointer hover:bg-[#FFF6EB]",
                      active && "bg-[#FFF6E7]",
                    )}
                  >
                    <div className="flex items-center gap-2 min-w-0">
                      <span className={cn("inline-block h-2 w-2 rounded-full shrink-0", c.dot)} />
                      <span
                        className="text-[14px] font-semibold text-[#3F2A1A] truncate"
                        style={{ fontFamily: planetFont }}
                      >
                        {labelChain}
                      </span>
                      {active && (
                        <Badge className="h-4 px-1 text-[9px] bg-[#ED7B2A] hover:bg-[#ED7B2A] text-white">
                          {labels.nowTag}
                        </Badge>
                      )}
                    </div>
                    <span className="text-[14px] text-[#3F2A1A] tabular-nums whitespace-nowrap">
                      {formatDDMMYYYY(node.end)}
                    </span>
                  </div>
                );
              })}
            </div>

            {/* LEVEL UP (back) button */}
            <div className="flex flex-col items-center gap-2 py-4 px-4 bg-white">
              <Button
                disabled={crumbs.length === 0}
                onClick={levelUp}
                className={cn(
                  "bg-[#ED7B2A] hover:bg-[#D86E20] text-white font-bold text-[16px] px-6 py-3 rounded-md shadow-sm",
                  "disabled:opacity-50 disabled:cursor-not-allowed",
                )}
                title={crumbs.length === 0
                  ? (lang === "hi" ? "पहले से शीर्ष स्तर पर हैं" : "Already at top level")
                  : labels.levelUp}
              >
                <ArrowUp className="h-4 w-4 mr-1" />
                {labels.levelUp}
              </Button>
              <button
                type="button"
                className="text-[13px] text-[#ED7B2A] underline underline-offset-2 hover:text-[#D86E20]"
                onClick={() => setCrumbs([])}
              >
                {labels.fullLink}
              </button>
            </div>
          </>
        )}
      </CardContent>
    </Card>
  );
}
