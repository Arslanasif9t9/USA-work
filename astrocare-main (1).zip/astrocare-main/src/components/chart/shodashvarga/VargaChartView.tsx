import { useMemo } from "react";
import { NorthIndianDiamond } from "@/components/chart/NorthIndianDiamond";
import { PLANET_COLORS, PLANET_ABBR, PLANET_ABBR_HI, SIGN_NAMES_EN, SIGN_NAMES_HI, type PlanetName } from "@/types/panchang";
import { HOUSE_MEANINGS_EN, HOUSE_MEANINGS_HI } from "@/constants/houseMeanings";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import type { VargaChartData, VargaPlanetPosition } from "@/types/shodashvarga";

interface Props {
  chart: VargaChartData;
  size?: number;
  language: "en" | "hi";
}

const VEDIC: ReadonlySet<string> = new Set([
  "Sun","Moon","Mars","Mercury","Jupiter","Venus","Saturn","Rahu","Ketu",
]);

export function VargaChartView({ chart, size = 320, language }: Props) {
  const isHi = language === "hi";
  // Group planets by house, filter to 9 Vedic Grahas only.
  const byHouse = useMemo(() => {
    const m: Record<number, VargaPlanetPosition[]> = {};
    for (const p of chart.planets) {
      if (!VEDIC.has(p.name)) continue;
      const h = p.house >= 1 && p.house <= 12 ? p.house : 1;
      (m[h] ||= []).push(p);
    }
    return m;
  }, [chart]);

  const signForHouse = (h: number) =>
    (((chart.ascendant - 1) + (h - 1)) % 12) + 1;

  return (
    <TooltipProvider delayDuration={120}>
      <div className="mx-auto" style={{ width: size }}>
        <NorthIndianDiamond
          size={size}
          strokeColor="#ED7B2A"
          strokeWidth={2}
          background="#FBF1E2"
          houseNumberColor="#3F2A1A"
          houseNumberFontSize={11}
          renderHouseNumberWrapper={(cell, label) => {
            const meaning = isHi ? HOUSE_MEANINGS_HI[cell.number] : HOUSE_MEANINGS_EN[cell.number];
            const sign = signForHouse(cell.number);
            const signName = isHi ? SIGN_NAMES_HI[sign - 1] : SIGN_NAMES_EN[sign - 1];
            return (
              <Tooltip>
                <TooltipTrigger asChild>
                  <g style={{ cursor: "help" }}>{label}</g>
                </TooltipTrigger>
                <TooltipContent className="text-xs">
                  <div className="font-semibold">House {cell.number} · {signName}</div>
                  <div className="opacity-80">{meaning}</div>
                </TooltipContent>
              </Tooltip>
            );
          }}
          renderCell={(cell) => {
            const planets = byHouse[cell.number] || [];
            if (planets.length === 0) return null;
            return (
              <>
                {planets.map((p, idx) => {
                  const color = PLANET_COLORS[p.name as PlanetName] || "#3F2A1A";
                  const abbr = isHi
                    ? PLANET_ABBR_HI[p.name as PlanetName]
                    : PLANET_ABBR[p.name as PlanetName];
                  const signIdx = p.sign - 1;
                  const signName = isHi ? SIGN_NAMES_HI[signIdx] : SIGN_NAMES_EN[signIdx];
                  const fullName = p.name; // English name is canonical
                  return (
                    <Tooltip key={`${p.name}-${idx}`}>
                      <TooltipTrigger asChild>
                        <text
                          x={cell.center[0]}
                          y={cell.center[1] + idx * 14}
                          textAnchor="middle"
                          fontSize="13"
                          fontWeight="700"
                          fill={color}
                          dominantBaseline="middle"
                          style={{ cursor: "help", userSelect: "none" }}
                        >
                          {abbr}{p.retrograde ? "(R)" : ""}
                        </text>
                      </TooltipTrigger>
                      <TooltipContent className="text-xs">
                        <div className="font-semibold">{abbr} · {fullName}</div>
                        <div className="opacity-80">{signName} · {p.degree.toFixed(2)}°{p.retrograde ? " (R)" : ""}</div>
                      </TooltipContent>
                    </Tooltip>
                  );
                })}
              </>
            );
          }}
        />
      </div>
    </TooltipProvider>
  );
}
