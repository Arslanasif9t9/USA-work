import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { PHASE_1_VARGAS } from "@/data/vargas";
import type { DCode } from "@/types/shodashvarga";

interface Props {
  value: DCode;
  onChange: (code: DCode) => void;
  language: "en" | "hi";
  ariaLabel?: string;
}

export function VargaDropdown({ value, onChange, language, ariaLabel }: Props) {
  const isHi = language === "hi";
  return (
    <Select value={value} onValueChange={(v) => onChange(v as DCode)}>
      <SelectTrigger
        aria-label={ariaLabel}
        className="w-full bg-white border-[#E5DDD3] text-[#2D2419] hover:border-[#ED7B2A] focus:ring-[#ED7B2A]"
      >
        <SelectValue />
      </SelectTrigger>
      <SelectContent className="z-[60] bg-white">
        {PHASE_1_VARGAS.map((v) => {
          const name = isHi ? v.nameHindi : v.name;
          const meaning = isHi ? v.meaningHindi : v.meaning;
          return (
            <SelectItem key={v.code} value={v.code} className="text-[#2D2419]">
              <span className="font-semibold">{v.code}</span>
              <span className="opacity-60"> — </span>
              <span>{name}</span>
              <span className="opacity-60"> ({meaning})</span>
            </SelectItem>
          );
        })}
      </SelectContent>
    </Select>
  );
}
