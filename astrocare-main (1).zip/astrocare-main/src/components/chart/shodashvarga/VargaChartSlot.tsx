import { useTranslation } from "react-i18next";
import { VargaDropdown } from "./VargaDropdown";
import { VargaChartView } from "./VargaChartView";
import { getVarga } from "@/data/vargas";
import { useShodashvargaChart } from "@/hooks/useShodashvargaChart";
import type { DCode } from "@/types/shodashvarga";

interface Props {
  birthChartId: string;
  selected: DCode;
  onSelect: (code: DCode) => void;
  language: "en" | "hi";
  size?: number;
  ariaLabel?: string;
}

export function VargaChartSlot({
  birthChartId, selected, onSelect, language, size = 280, ariaLabel,
}: Props) {
  const { t } = useTranslation("common");
  const isHi = language === "hi";
  const info = getVarga(selected);
  const { data, loading, error, reload } = useShodashvargaChart({
    birthChartId, dCode: selected, language, enabled: true,
  });

  const name = info ? (isHi ? info.nameHindi : info.name) : selected;
  const meaning = info ? (isHi ? info.meaningHindi : info.meaning) : "";
  const desc = info ? (isHi ? info.descriptionHindi : info.description) : "";

  return (
    <div className="rounded-lg border border-[#E5DDD3] bg-[#FFF6EB]/40 p-3">
      <VargaDropdown value={selected} onChange={onSelect} language={language} ariaLabel={ariaLabel} />
      <div className="mt-2 text-center text-[13px] font-semibold text-[#2D2419]">
        {selected} — {name} <span className="font-normal opacity-70">({meaning})</span>
      </div>

      <div className="mt-3 min-h-[260px] flex items-center justify-center">
        {loading && !data && (
          <div className="text-sm text-[#5A4A3A] py-8">
            {t("shodashvarga.loading", { defaultValue: "Loading chart..." })}
          </div>
        )}
        {error && !data && (
          <div className="text-center text-sm text-destructive py-8">
            <div className="mb-2">{t("shodashvarga.error", { defaultValue: "Could not load chart. Please try again." })}</div>
            <button
              type="button"
              onClick={reload}
              className="rounded border border-[#ED7B2A] px-3 py-1 text-[#ED7B2A] hover:bg-[#FFF6EB]"
            >
              {t("common.retry", { defaultValue: "Retry" })}
            </button>
          </div>
        )}
        {data && <VargaChartView chart={data.chart} size={size} language={language} />}
      </div>

      {desc && (
        <div className="mt-2 text-center text-[12px] italic text-[#5A4A3A]">{desc}</div>
      )}
    </div>
  );
}
