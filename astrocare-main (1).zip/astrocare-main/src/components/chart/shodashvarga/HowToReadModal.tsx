import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { useTranslation } from "react-i18next";

interface Props {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export function HowToReadModal({ open, onOpenChange }: Props) {
  const { t, i18n } = useTranslation("common");
  const isHi = i18n.language?.startsWith("hi");

  const titleEn = "Understanding Divisional Charts";
  const titleHi = "विभाजित कुंडली को समझें";

  const bodyEn = (
    <>
      <p>
        Vedic astrology divides each zodiac sign into smaller portions to reveal specific
        life areas. The main birth chart (D1) shows your overall life path, while divisional
        charts (D2–D60) zoom into specific themes:
      </p>
      <ul className="list-disc list-inside space-y-1 mt-3">
        <li><strong>D1 Lagna</strong> — Self, body, overall life</li>
        <li><strong>D2 Hora</strong> — Wealth and financial gains</li>
        <li><strong>D3 Drekkana</strong> — Siblings and personal courage</li>
        <li><strong>D7 Saptamsa</strong> — Children and creative expression</li>
        <li><strong>D9 Navamsa</strong> — Marriage and dharmic path</li>
        <li><strong>D10 Dasamsa</strong> — Career and professional achievements</li>
        <li><strong>D12 Dwadasamsa</strong> — Parents and ancestry</li>
      </ul>
      <p className="mt-3">
        Astrologers typically compare two or three charts together to get a complete picture
        of any life question. For example, marriage analysis uses D1 + D9, and career uses
        D1 + D10.
      </p>
    </>
  );

  const bodyHi = (
    <>
      <p>
        वैदिक ज्योतिष में प्रत्येक राशि को छोटे भागों में विभाजित किया जाता है ताकि जीवन के विशिष्ट
        क्षेत्र प्रकट हो सकें। मुख्य जन्म कुंडली (D1) आपके समग्र जीवन पथ को दर्शाती है, जबकि विभाजित
        कुंडलियाँ (D2–D60) विशेष विषयों पर केंद्रित होती हैं:
      </p>
      <ul className="list-disc list-inside space-y-1 mt-3">
        <li><strong>D1 लग्न</strong> — स्व, शरीर, समग्र जीवन</li>
        <li><strong>D2 होरा</strong> — धन और आर्थिक लाभ</li>
        <li><strong>D3 द्रेक्काण</strong> — भाई-बहन और व्यक्तिगत साहस</li>
        <li><strong>D7 सप्तांश</strong> — संतान और रचनात्मक अभिव्यक्ति</li>
        <li><strong>D9 नवांश</strong> — विवाह और धर्म पथ</li>
        <li><strong>D10 दशांश</strong> — करियर और व्यावसायिक उपलब्धियाँ</li>
        <li><strong>D12 द्वादशांश</strong> — माता-पिता और वंशावली</li>
      </ul>
      <p className="mt-3">
        ज्योतिषी सामान्यतः किसी प्रश्न का पूर्ण उत्तर पाने के लिए दो या तीन कुंडलियों की एक साथ तुलना
        करते हैं। उदाहरण के लिए, विवाह विश्लेषण में D1 + D9 और करियर के लिए D1 + D10 देखी जाती है।
      </p>
    </>
  );

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-lg z-[70]">
        <DialogHeader>
          <DialogTitle>{t("shodashvarga.explainer_title", { defaultValue: isHi ? titleHi : titleEn })}</DialogTitle>
          <DialogDescription className="sr-only">Divisional chart explainer</DialogDescription>
        </DialogHeader>
        <div className="text-sm leading-relaxed text-foreground space-y-2">
          {isHi ? bodyHi : bodyEn}
        </div>
      </DialogContent>
    </Dialog>
  );
}
