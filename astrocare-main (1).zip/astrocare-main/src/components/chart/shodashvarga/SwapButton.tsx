import { ArrowLeftRight } from "lucide-react";

interface Props {
  onClick: () => void;
  ariaLabel: string;
}

export function SwapButton({ onClick, ariaLabel }: Props) {
  return (
    <div className="flex items-center justify-center my-2">
      <button
        type="button"
        onClick={onClick}
        aria-label={ariaLabel}
        title={ariaLabel}
        className="rounded-full border border-[#ED7B2A] bg-white p-2 text-[#ED7B2A] shadow-sm hover:bg-[#FFF6EB] transition-colors"
      >
        <ArrowLeftRight className="h-4 w-4" />
      </button>
    </div>
  );
}
