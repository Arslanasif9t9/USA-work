import { useEffect, useState } from "react";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { Phone, PhoneOff, Loader2 } from "lucide-react";
import { useCallSession } from "@/hooks/useCallSession";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "@/hooks/use-toast";
import type { Astrologer } from "@/components/astrologers/AstrologerCard";
import { getAstrologerImageUrl, getAstrologerImageSrcSet } from "@/lib/astrologerImage";

interface Props {
  callSessionId: string;
  astrologer: Astrologer;
  onClose: () => void;
}

function initials(name: string) {
  return name.split(" ").map((p) => p[0]).filter(Boolean).slice(0, 2).join("").toUpperCase();
}

function fmtElapsed(ms: number) {
  const s = Math.max(0, Math.floor(ms / 1000));
  const m = Math.floor(s / 60);
  const ss = String(s % 60).padStart(2, "0");
  return `${m}:${ss}`;
}

export function CallInProgressScreen({ callSessionId, astrologer, onClose }: Props) {
  const { session } = useCallSession(callSessionId);
  const [now, setNow] = useState(Date.now());
  const [cancelling, setCancelling] = useState(false);

  useEffect(() => {
    const id = setInterval(() => setNow(Date.now()), 1000);
    return () => clearInterval(id);
  }, []);

  const status = session?.status ?? "pending";
  const isRinging = ["pending", "ringing_astrologer", "ringing_user"].includes(status);
  const isConnected = status === "connected";
  const isOver = ["completed", "failed", "declined", "no_answer", "cancelled"].includes(status);

  const elapsedRing = session ? now - new Date(session.initiated_at).getTime() : 0;
  const elapsedTalk = session?.connected_at ? now - new Date(session.connected_at).getTime() : 0;

  const handleCancel = async () => {
    setCancelling(true);
    const { error } = await supabase.functions.invoke("cancel-call", {
      body: { call_session_id: callSessionId },
    });
    setCancelling(false);
    if (error) {
      toast({ title: "Could not cancel", variant: "destructive" });
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-background/95 backdrop-blur-sm p-4">
      <div className="w-full max-w-md rounded-xl border bg-card shadow-card p-6 space-y-6 text-center">
        <div className="relative mx-auto w-fit">
          {isRinging && (
            <span className="absolute inset-0 -m-3 rounded-full border-2 border-primary/40 animate-ping" />
          )}
          <Avatar className="h-24 w-24 mx-auto">
            <AvatarImage src={getAstrologerImageUrl(astrologer.avatar_url, "thumbnail")} srcSet={getAstrologerImageSrcSet(astrologer.avatar_url, "thumbnail")} alt={astrologer.display_name} className="object-cover object-[center_top]" />
            <AvatarFallback className="bg-primary/10 text-primary font-semibold text-2xl">
              {initials(astrologer.display_name)}
            </AvatarFallback>
          </Avatar>
        </div>

        <div>
          <h2 className="text-lg font-semibold">{astrologer.display_name}</h2>
          {status === "pending" && (
            <p className="text-sm text-muted-foreground mt-1 inline-flex items-center gap-1">
              <Loader2 className="h-3 w-3 animate-spin" /> Setting up call…
            </p>
          )}
          {status === "ringing_astrologer" && (
            <p className="text-sm text-muted-foreground mt-1">
              Ringing astrologer… {fmtElapsed(elapsedRing)}
            </p>
          )}
          {status === "ringing_user" && (
            <p className="text-sm text-muted-foreground mt-1">
              Astrologer joined. Your phone will ring now.
            </p>
          )}
          {isConnected && (
            <p className="text-sm font-medium text-primary mt-1 inline-flex items-center gap-1">
              <Phone className="h-3 w-3" /> Connected · {fmtElapsed(elapsedTalk)}
            </p>
          )}
        </div>

        {isConnected && (
          <div className="rounded-lg bg-muted/40 p-3 text-xs text-muted-foreground">
            📞 Your phones are connected. Hang up here or from your phone to end the call.
          </div>
        )}

        {status === "declined" && (
          <p className="text-sm text-destructive">Astrologer declined the call.</p>
        )}
        {status === "no_answer" && (
          <p className="text-sm text-destructive">No answer. Please try again.</p>
        )}
        {status === "failed" && (
          <p className="text-sm text-destructive">Call failed. Your hold has been refunded.</p>
        )}
        {status === "cancelled" && (
          <p className="text-sm text-muted-foreground">Call cancelled. Your hold has been refunded.</p>
        )}
        {status === "completed" && session && (
          <p className="text-sm">
            Call ended · Duration {fmtElapsed(session.duration_seconds * 1000)}
          </p>
        )}

        <div className="flex gap-2 justify-center">
          {isRinging && (
            <Button variant="destructive" onClick={handleCancel} disabled={cancelling}>
              <PhoneOff className="h-4 w-4" /> {cancelling ? "Cancelling…" : "Cancel Call"}
            </Button>
          )}
          {isConnected && (
            <Button
              variant="destructive"
              size="lg"
              onClick={async () => {
                setCancelling(true);
                const { error } = await supabase.functions.invoke("end-call", {
                  body: { call_session_id: callSessionId },
                });
                setCancelling(false);
                if (error) toast({ title: "Could not end call", variant: "destructive" });
              }}
              disabled={cancelling}
              className="rounded-full h-14 w-14 p-0"
            >
              <PhoneOff className="h-6 w-6" />
            </Button>
          )}
          {isOver && (
            <Button variant="saffron" onClick={onClose}>Back to Astrologers</Button>
          )}
        </div>
      </div>
    </div>
  );
}
