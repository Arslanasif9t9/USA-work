import { Dialog, DialogContent } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Loader2, Phone, Star, Wallet } from "lucide-react";
import { Link } from "react-router-dom";
import type { Astrologer } from "@/components/astrologers/AstrologerCard";
import { getAstrologerImageUrl, getAstrologerImageSrcSet } from "@/lib/astrologerImage";

interface Props {
  open: boolean;
  onClose: () => void;
  astrologer: Astrologer | null;
  walletBalance: number;
  userPhone: string | null;
  isStarting: boolean;
  onConfirm: () => void;
}

function initials(name: string) {
  return name.split(" ").map((p) => p[0]).filter(Boolean).slice(0, 2).join("").toUpperCase();
}

export function CallConfirmationModal({
  open,
  onClose,
  astrologer,
  walletBalance,
  userPhone,
  isStarting,
  onConfirm,
}: Props) {
  if (!astrologer) return null;
  const rate = astrologer.discounted_rate_per_min ?? astrologer.base_rate_per_min;
  const minutesAvailable = rate > 0 ? Math.floor(walletBalance / rate) : 0;

  return (
    <Dialog open={open} onOpenChange={(o) => !o && !isStarting && onClose()}>
      <DialogContent className="max-w-md overflow-hidden border-white/10 bg-gradient-to-br from-[#1a1233] via-[#0f0a1e] to-[#1a1233] p-0 text-white">
        <div className="pointer-events-none absolute inset-0 opacity-30 [background-image:radial-gradient(white_1px,transparent_1px)] [background-size:24px_24px]" />

        <div className="relative p-6 text-center">
          {/* Avatar with gold ring */}
          <div className="relative mx-auto mb-3 h-24 w-24">
            <span className="absolute inset-0 -m-1 rounded-full bg-gradient-to-br from-amber-300 to-amber-600 opacity-90" />
            <Avatar className="relative h-24 w-24 ring-4 ring-amber-300/80">
              <AvatarImage src={getAstrologerImageUrl(astrologer.avatar_url, "thumbnail")} srcSet={getAstrologerImageSrcSet(astrologer.avatar_url, "thumbnail")} alt={astrologer.display_name} className="object-cover object-[center_top]" />
              <AvatarFallback className="bg-purple-700 text-2xl font-semibold">
                {initials(astrologer.display_name)}
              </AvatarFallback>
            </Avatar>
          </div>

          <h3 className="font-serif text-2xl font-bold tracking-wide">{astrologer.display_name}</h3>
          {astrologer.specializations?.length > 0 && (
            <p className="mt-1 text-sm text-white/60 truncate px-4">
              {astrologer.specializations.slice(0, 3).map((s) => s.replace(/_/g, " ")).join(" · ")}
            </p>
          )}
          <div className="mt-2 inline-flex items-center gap-1 text-amber-200/90 text-sm">
            <Star className="h-3.5 w-3.5 fill-amber-300 text-amber-300" />
            <span className="font-semibold">{Number(astrologer.rating_avg ?? 0).toFixed(1)}</span>
            <span className="text-white/50">({astrologer.rating_count})</span>
          </div>

          {/* Rate pill */}
          <div className="mt-5 inline-flex items-center gap-2 rounded-full bg-gradient-to-r from-amber-300 to-amber-500 px-5 py-2 text-base font-bold text-black shadow-lg shadow-amber-500/30">
            <Phone className="h-4 w-4" />
            ₹{rate} / min
          </div>

          {/* Wallet info */}
          <div className="mt-5 grid grid-cols-2 gap-3 text-left">
            <div className="rounded-xl border border-white/10 bg-white/5 p-3">
              <div className="flex items-center gap-1.5 text-xs text-white/60">
                <Wallet className="h-3 w-3" /> Wallet
              </div>
              <p className="mt-1 text-lg font-bold">₹{walletBalance.toFixed(0)}</p>
            </div>
            <div className="rounded-xl border border-white/10 bg-white/5 p-3">
              <div className="text-xs text-white/60">Estimated</div>
              <p className="mt-1 text-lg font-bold">{minutesAvailable} min</p>
            </div>
          </div>

          <div className="mt-4 rounded-xl border border-white/10 bg-white/5 p-3 text-left text-sm flex items-center justify-between">
            <div className="min-w-0">
              <p className="text-xs text-white/50">We&apos;ll call you on</p>
              <p className="font-medium truncate">{userPhone ?? "No number set"}</p>
            </div>
            <Link to="/profile" className="text-xs text-amber-200 hover:underline">Change</Link>
          </div>

          <Button
            onClick={onConfirm}
            disabled={isStarting}
            className="mt-5 h-12 w-full rounded-full bg-gradient-to-r from-amber-300 to-amber-500 text-base font-bold text-black hover:from-amber-200 hover:to-amber-400 shadow-lg shadow-amber-500/30"
          >
            {isStarting ? (
              <><Loader2 className="h-5 w-5 animate-spin" /> Starting…</>
            ) : (
              <><Phone className="h-5 w-5" /> Call Now</>
            )}
          </Button>
          <button
            onClick={onClose}
            disabled={isStarting}
            className="mt-2 text-sm text-white/60 hover:text-white disabled:opacity-50"
          >
            Cancel
          </button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
