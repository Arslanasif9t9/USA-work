import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { useNavigate } from "react-router-dom";
import { AlertCircle } from "lucide-react";

export type BlockerReason = "no_phone" | "no_chart" | "insufficient_balance" | "offline" | "busy" | null;

interface Props {
  open: boolean;
  reason: BlockerReason;
  required?: number;
  currentBalance?: number;
  onClose: () => void;
  onOpenBirthChart?: () => void;
}

export function PreCallBlockerModal({ open, reason, required, currentBalance, onClose, onOpenBirthChart }: Props) {
  const navigate = useNavigate();
  if (!reason) return null;

  const config: Record<NonNullable<BlockerReason>, { title: string; body: string; cta: string; action: () => void }> = {
    no_phone: {
      title: "Add your phone number",
      body: "We need a phone number to ring you for the consultation. Add it in your profile.",
      cta: "Go to Profile",
      action: () => { onClose(); navigate("/profile"); },
    },
    no_chart: {
      title: "Complete your birth chart",
      body: "Astrologers reference your birth chart during the consultation. Add your birth details first.",
      cta: "Add Birth Chart",
      action: () => { onClose(); onOpenBirthChart ? onOpenBirthChart() : navigate("/profile"); },
    },
    insufficient_balance: {
      title: "Insufficient wallet balance",
      body: `You need at least ₹${required?.toFixed(2) ?? "0"} to start a 2-minute call. Your balance: ₹${currentBalance?.toFixed(2) ?? "0"}.`,
      cta: "Recharge Wallet",
      action: () => { onClose(); navigate("/history"); },
    },
    offline: {
      title: "Astrologer is offline",
      body: "This astrologer isn't online right now. Try again later or pick another expert.",
      cta: "Browse Astrologers",
      action: () => { onClose(); },
    },
    busy: {
      title: "Astrologer is on another call",
      body: "Please try again in a few minutes or pick another astrologer.",
      cta: "Browse Astrologers",
      action: () => { onClose(); },
    },
  };

  const c = config[reason];

  return (
    <Dialog open={open} onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="max-w-sm">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <AlertCircle className="h-5 w-5 text-destructive" />
            {c.title}
          </DialogTitle>
          <DialogDescription>{c.body}</DialogDescription>
        </DialogHeader>
        <DialogFooter className="gap-2 sm:gap-2">
          <Button variant="outline" onClick={onClose}>Close</Button>
          <Button variant="saffron" onClick={c.action}>{c.cta}</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
