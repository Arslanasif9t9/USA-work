import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { ArrowLeft, Gift, MessageCircle, Phone, Sparkles, Star, Wallet, Plus, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { supabase } from "@/integrations/supabase/client";
import { ReviewModal } from "./ReviewModal";
import { getAstrologerImageUrl, getAstrologerImageSrcSet } from "@/lib/astrologerImage";

interface RecAstrologer {
  id: string;
  slug: string;
  display_name: string;
  avatar_url: string | null;
  rating_avg: number;
  chat_rate_per_min: number;
  specializations: string[];
}

interface Props {
  endedBy: string | null;
  durationLabel: string;
  totalCost: number;
  isCurrentUserEnder: boolean;
  astrologerId: string;
  astrologerSlug: string | null;
  astrologerName: string;
  astrologerAvatar: string | null;
  onBack: () => void;
  onChatAgain?: () => void;
  onCallAgain?: () => void;
  onSendGift?: () => void;
}

export function SessionEndedScreen({
  endedBy,
  durationLabel,
  totalCost,
  isCurrentUserEnder,
  astrologerId,
  astrologerSlug,
  astrologerName,
  astrologerAvatar,
  onBack,
  onChatAgain,
  onCallAgain,
  onSendGift,
}: Props) {
  const navigate = useNavigate();
  const [recs, setRecs] = useState<RecAstrologer[]>([]);
  const [loadingRecs, setLoadingRecs] = useState(true);
  const [reviewOpen, setReviewOpen] = useState(false);
  const [reviewSubmitted, setReviewSubmitted] = useState(false);

  // Open review prompt automatically
  useEffect(() => {
    const t = setTimeout(() => setReviewOpen(true), 600);
    return () => clearTimeout(t);
  }, []);

  // Fetch recommended astrologers (top-rated, excluding the current one)
  useEffect(() => {
    let active = true;
    (async () => {
      const { data } = await supabase
        .from("astrologers")
        .select("id, slug, display_name, avatar_url, rating_avg, chat_rate_per_min, specializations")
        .eq("approval_status", "approved")
        .neq("id", astrologerId)
        .order("rating_avg", { ascending: false })
        .order("rating_count", { ascending: false })
        .limit(3);
      if (!active) return;
      setRecs((data ?? []) as RecAstrologer[]);
      setLoadingRecs(false);
    })();
    return () => { active = false; };
  }, [astrologerId]);

  const subtitle = isCurrentUserEnder
    ? "You ended the session"
    : endedBy === "system"
    ? "Session ended automatically"
    : endedBy === "astrologer"
    ? "Session ended by astrologer"
    : "The session has ended";

  return (
    <div className="relative min-h-screen w-full overflow-y-auto bg-[#0F0A1E] text-white animate-fade-in">
      {/* Cosmic background — same as /chat page */}
      <div className="pointer-events-none fixed inset-0 [background-image:radial-gradient(white_1px,transparent_1px)] [background-size:32px_32px] opacity-[0.07]" />
      <div className="pointer-events-none fixed -top-40 -left-40 h-96 w-96 rounded-full bg-purple-700/30 blur-3xl" />
      <div className="pointer-events-none fixed -bottom-40 -right-40 h-96 w-96 rounded-full bg-indigo-600/30 blur-3xl" />

      {/* Top bar */}
      <div className="sticky top-0 z-10 flex items-center justify-between border-b border-white/10 bg-[#0F0A1E]/80 px-4 py-3 backdrop-blur-xl sm:px-6">
        <button
          onClick={onBack}
          className="inline-flex h-10 items-center gap-2 rounded-full border border-white/15 bg-white/5 px-3 text-sm text-white/90 transition hover:bg-white/10"
        >
          <ArrowLeft className="h-4 w-4" /> Back
        </button>
        <span className="inline-flex items-center gap-1.5 rounded-full bg-white/5 px-3 py-1 text-xs text-white/70">
          <Sparkles className="h-3 w-3 text-amber-300" /> Session Ended
        </span>
      </div>

      <div className="relative mx-auto w-full max-w-2xl space-y-5 px-4 py-6 sm:px-6">
        {/* Hero summary card */}
        <div className="relative overflow-hidden rounded-3xl border border-white/10 bg-gradient-to-br from-[#1a1233] via-[#0f0a1e] to-[#1a1233] p-6 text-center shadow-2xl">
          <div className="pointer-events-none absolute inset-0 opacity-30 [background-image:radial-gradient(white_1px,transparent_1px)] [background-size:24px_24px]" />
          <div className="relative">
            <div className="relative mx-auto mb-4 flex h-20 w-20 items-center justify-center">
              <span className="absolute inset-0 animate-ping rounded-full bg-amber-400/40" />
              <span className="absolute inset-2 rounded-full bg-gradient-to-br from-amber-300 to-amber-600 opacity-80 blur-md" />
              <div className="relative flex h-16 w-16 items-center justify-center rounded-full bg-gradient-to-br from-amber-300 to-amber-500 shadow-[0_0_40px_rgba(251,191,36,0.7)]">
                <Sparkles className="h-8 w-8 text-black" />
              </div>
            </div>
            <h1 className="font-serif text-3xl font-bold tracking-wide">Session Ended</h1>
            <p className="mt-1 text-sm text-white/60">{subtitle}</p>

            <div className="mt-5 grid grid-cols-2 gap-3 rounded-2xl border border-white/10 bg-white/5 p-4">
              <div>
                <p className="text-[11px] uppercase tracking-wider text-white/50">Duration</p>
                <p className="mt-0.5 font-mono text-2xl font-bold">{durationLabel}</p>
              </div>
              <div>
                <p className="text-[11px] uppercase tracking-wider text-white/50">Total</p>
                <p className="mt-0.5 text-2xl font-bold text-amber-300">₹{totalCost}</p>
              </div>
            </div>
          </div>
        </div>

        {/* Action grid */}
        <div className="grid grid-cols-2 gap-2.5 sm:grid-cols-4">
          <ActionTile onClick={onChatAgain} icon={<MessageCircle className="h-5 w-5" />} label="Chat Again" />
          <ActionTile onClick={onCallAgain} icon={<Phone className="h-5 w-5" />} label="Call Again" />
          <ActionTile onClick={onSendGift} icon={<Gift className="h-5 w-5" />} label="Send Gift" />
          <ActionTile onClick={() => setReviewOpen(true)} icon={<Star className="h-5 w-5" />} label={reviewSubmitted ? "Reviewed ✓" : "Review"} />
        </div>

        {/* Add credits CTA */}
        <button
          onClick={() => navigate("/wallet")}
          className="group flex w-full items-center justify-between rounded-2xl border border-emerald-400/30 bg-gradient-to-r from-emerald-500/15 to-emerald-400/5 p-4 text-left transition hover:from-emerald-500/25"
        >
          <div className="flex items-center gap-3">
            <span className="flex h-11 w-11 items-center justify-center rounded-xl bg-emerald-400/20 text-emerald-300">
              <Wallet className="h-5 w-5" />
            </span>
            <div>
              <p className="text-sm font-semibold text-white">Add Credits</p>
              <p className="text-xs text-white/60">Top up your wallet for the next session</p>
            </div>
          </div>
          <span className="flex h-9 w-9 items-center justify-center rounded-full bg-emerald-400/20 text-emerald-200 transition group-hover:bg-emerald-400/30">
            <Plus className="h-4 w-4" />
          </span>
        </button>

        {/* Recommended astrologers */}
        <div>
          <div className="mb-3 flex items-center justify-between">
            <h2 className="font-serif text-lg font-semibold">Recommended for you</h2>
            <button
              onClick={() => navigate("/astrologers")}
              className="text-xs font-medium text-amber-300 hover:text-amber-200"
            >
              See all →
            </button>
          </div>

          {loadingRecs ? (
            <div className="flex justify-center py-6">
              <Loader2 className="h-5 w-5 animate-spin text-white/40" />
            </div>
          ) : recs.length === 0 ? (
            <p className="rounded-xl border border-white/10 bg-white/5 p-4 text-center text-sm text-white/50">
              No recommendations right now.
            </p>
          ) : (
            <div className="space-y-2.5">
              {recs.map((a) => {
                const init = a.display_name.split(" ").map((p) => p[0]).join("").slice(0, 2).toUpperCase();
                return (
                  <button
                    key={a.id}
                    onClick={() => navigate(`/astrologer/${a.slug}`)}
                    className="flex w-full items-center gap-3 rounded-2xl border border-white/10 bg-white/5 p-3 text-left transition hover:border-amber-300/40 hover:bg-white/10"
                  >
                    <Avatar className="h-12 w-12 ring-2 ring-amber-300/40">
                      <AvatarImage src={getAstrologerImageUrl(a.avatar_url, "thumbnail")} srcSet={getAstrologerImageSrcSet(a.avatar_url, "thumbnail")} loading="lazy" className="object-cover object-[center_top]" />
                      <AvatarFallback className="bg-purple-700 text-sm font-semibold">{init}</AvatarFallback>
                    </Avatar>
                    <div className="min-w-0 flex-1">
                      <p className="truncate font-semibold text-white">{a.display_name}</p>
                      <div className="mt-0.5 flex items-center gap-2 text-xs text-white/60">
                        <span className="inline-flex items-center gap-0.5 text-amber-300">
                          <Star className="h-3 w-3 fill-current" /> {Number(a.rating_avg).toFixed(1)}
                        </span>
                        <span>·</span>
                        <span className="truncate">{(a.specializations ?? []).slice(0, 2).join(" • ")}</span>
                      </div>
                    </div>
                    <span className="shrink-0 rounded-full bg-amber-400/15 px-2.5 py-1 text-xs font-semibold text-amber-200">
                      ₹{a.chat_rate_per_min}/min
                    </span>
                  </button>
                );
              })}
            </div>
          )}
        </div>

        <Button
          onClick={onBack}
          variant="outline"
          className="w-full border-white/15 bg-white/5 text-white hover:bg-white/10"
        >
          Back to astrologers
        </Button>
      </div>

      <ReviewModal
        open={reviewOpen}
        onOpenChange={setReviewOpen}
        astrologerId={astrologerId}
        astrologerName={astrologerName}
        astrologerAvatar={astrologerAvatar}
        onSubmitted={() => setReviewSubmitted(true)}
      />
    </div>
  );
}

function ActionTile({
  onClick,
  icon,
  label,
}: {
  onClick?: () => void;
  icon: React.ReactNode;
  label: string;
}) {
  return (
    <button
      onClick={onClick}
      className="group flex flex-col items-center gap-2 rounded-2xl border border-white/10 bg-white/5 px-3 py-4 text-xs font-semibold text-white/90 transition hover:border-amber-300/40 hover:bg-amber-300/10 hover:text-amber-200"
    >
      <span className="flex h-10 w-10 items-center justify-center rounded-full bg-gradient-to-br from-purple-600/40 to-indigo-600/40 text-white transition group-hover:from-amber-400/60 group-hover:to-amber-600/60 group-hover:text-black">
        {icon}
      </span>
      {label}
    </button>
  );
}
