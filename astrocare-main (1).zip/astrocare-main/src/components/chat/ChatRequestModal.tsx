import { useEffect, useState } from "react";
import { Dialog, DialogContent, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { useNavigate } from "react-router-dom";
import { Loader2, MessageSquare, Star, Wallet, CheckCircle2, XCircle } from "lucide-react";
import { toast } from "sonner";
import { useWallet, formatINR } from "@/hooks/useWallet";

interface Props {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  astrologerId: string;
  astrologerName: string;
  astrologerAvatar?: string | null;
  astrologerSpecializations?: string[];
  astrologerRating?: number;
  ratePerMin: number;
}

const RING = 88;
const R = 38;
const C = 2 * Math.PI * R;

type Phase = "confirm" | "waiting" | "accepted" | "rejected" | "timeout";

export function ChatRequestModal({
  open,
  onOpenChange,
  astrologerId,
  astrologerName,
  astrologerAvatar,
  astrologerSpecializations = [],
  astrologerRating,
  ratePerMin,
}: Props) {
  const { user } = useAuth();
  const navigate = useNavigate();
  const { wallet } = useWallet();
  const [phase, setPhase] = useState<Phase>("confirm");
  const [sessionId, setSessionId] = useState<string | null>(null);
  const [requestedAt, setRequestedAt] = useState<number>(0);
  const [secondsLeft, setSecondsLeft] = useState(60);
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    if (!open) {
      // small delay so closing animation looks clean
      const t = setTimeout(() => {
        setPhase("confirm");
        setSessionId(null);
        setSecondsLeft(60);
        setSubmitting(false);
      }, 200);
      return () => clearTimeout(t);
    }
  }, [open]);

  // Listen for status changes when waiting (realtime + polling fallback)
  useEffect(() => {
    if (!sessionId || phase !== "waiting") return;
    let stopped = false;

    const handleStatus = (status: string) => {
      if (stopped) return;
      if (status === "active") {
        stopped = true;
        setPhase("accepted");
        setTimeout(() => {
          onOpenChange(false);
          navigate(`/chat/${sessionId}`);
        }, 600);
      } else if (status === "rejected") {
        stopped = true;
        setPhase("rejected");
        setTimeout(() => onOpenChange(false), 2000);
      } else if (status === "cancelled") {
        stopped = true;
        setPhase("timeout");
        setTimeout(() => onOpenChange(false), 2000);
      }
    };

    const ch = supabase
      .channel(`req:${sessionId}`)
      .on(
        "postgres_changes",
        { event: "UPDATE", schema: "public", table: "chat_sessions", filter: `id=eq.${sessionId}` },
        (payload) => handleStatus((payload.new as any).status),
      )
      .subscribe();

    // Polling fallback in case realtime drops
    const poll = setInterval(async () => {
      if (stopped) return;
      const { data } = await supabase
        .from("chat_sessions")
        .select("status")
        .eq("id", sessionId)
        .maybeSingle();
      if (data?.status) handleStatus(data.status);
    }, 2000);

    return () => {
      stopped = true;
      clearInterval(poll);
      supabase.removeChannel(ch);
    };
  }, [sessionId, phase, navigate, onOpenChange]);

  // 60s countdown — auto cancel on client too
  useEffect(() => {
    if (phase !== "waiting" || !requestedAt || !sessionId) return;
    const tick = async () => {
      const remaining = 60 - Math.floor((Date.now() - requestedAt) / 1000);
      if (remaining <= 0) {
        await supabase
          .from("chat_sessions")
          .update({ status: "cancelled", ended_at: new Date().toISOString(), end_reason: "request_timeout" })
          .eq("id", sessionId)
          .eq("status", "pending");
        setPhase("timeout");
        setTimeout(() => onOpenChange(false), 2000);
        return;
      }
      setSecondsLeft(remaining);
    };
    tick();
    const id = setInterval(tick, 500);
    return () => clearInterval(id);
  }, [phase, requestedAt, sessionId, onOpenChange]);

  const requestChat = async () => {
    if (!user) {
      toast.error("Please sign in first");
      return;
    }
    setSubmitting(true);
    const { data, error } = await supabase.functions.invoke("request-chat", {
      body: { astrologer_id: astrologerId },
    });
    setSubmitting(false);
    if (error || (data as any)?.error) {
      toast.error((data as any)?.error ?? error?.message ?? "Failed to request chat");
      return;
    }
    setSessionId((data as any).session.id);
    setRequestedAt(Date.now());
    setSecondsLeft(60);
    setPhase("waiting");
  };

  const cancelRequest = async () => {
    if (sessionId && phase === "waiting") {
      await supabase
        .from("chat_sessions")
        .update({ status: "cancelled", ended_at: new Date().toISOString(), end_reason: "cancelled_by_user" })
        .eq("id", sessionId)
        .eq("status", "pending");
    }
    onOpenChange(false);
  };

  const dashOffset = C * (1 - secondsLeft / 60);
  const initials = astrologerName.split(" ").map((p) => p[0]).join("").slice(0, 2).toUpperCase();
  const minutesAffordable = wallet ? Math.floor(Number(wallet.balance) / Math.max(1, ratePerMin)) : 0;

  // While waiting, prevent overlay/ESC from closing the dialog — only the
  // explicit Cancel Request button cancels. Before sending the request, the
  // user can freely close the dialog.
  const handleOpenChange = (v: boolean) => {
    if (!v && phase === "waiting") return; // ignore close attempts during waiting
    onOpenChange(v);
  };

  return (
    <Dialog open={open} onOpenChange={handleOpenChange}>
      <DialogContent
        onInteractOutside={(e) => {
          if (phase === "waiting") e.preventDefault();
        }}
        onEscapeKeyDown={(e) => {
          if (phase === "waiting") e.preventDefault();
        }}
        className="max-w-sm overflow-hidden border-purple-500/30 bg-gradient-to-br from-[#1a1233] via-[#0f0a1e] to-[#1a1233] p-0 text-white shadow-[0_0_60px_rgba(139,92,246,0.35)] sm:rounded-3xl"
      >
        <div className="pointer-events-none absolute inset-0 opacity-30 [background-image:radial-gradient(white_1px,transparent_1px)] [background-size:24px_24px]" />
        <div className="pointer-events-none absolute -top-24 -left-24 h-56 w-56 rounded-full bg-purple-600/40 blur-3xl" />
        <div className="pointer-events-none absolute -bottom-24 -right-24 h-56 w-56 rounded-full bg-indigo-600/30 blur-3xl" />

        {/* CONFIRM PHASE */}
        {phase === "confirm" && (
          <div className="relative flex flex-col items-center px-6 pb-6 pt-8 text-center">
            <div className="relative mb-4">
              <span className="absolute inset-0 -m-1.5 rounded-full bg-gradient-to-br from-amber-300 to-amber-600 opacity-90" />
              <Avatar className="relative h-24 w-24 ring-4 ring-amber-300/80">
                <AvatarImage src={astrologerAvatar ?? undefined} alt={astrologerName} className="object-cover" />
                <AvatarFallback className="bg-purple-700 text-2xl font-semibold">{initials}</AvatarFallback>
              </Avatar>
            </div>

            <DialogTitle className="font-serif text-2xl font-bold tracking-wide">{astrologerName}</DialogTitle>
            {typeof astrologerRating === "number" && astrologerRating > 0 && (
              <div className="mt-1 flex items-center gap-1 text-amber-300">
                <Star className="h-4 w-4 fill-current" />
                <span className="text-sm font-semibold">{astrologerRating.toFixed(1)}</span>
              </div>
            )}
            {astrologerSpecializations.length > 0 && (
              <div className="mt-2 flex flex-wrap justify-center gap-1.5">
                {astrologerSpecializations.slice(0, 4).map((s) => (
                  <span key={s} className="rounded-full bg-white/10 px-2.5 py-0.5 text-xs text-white/80">
                    {s}
                  </span>
                ))}
              </div>
            )}

            <DialogDescription className="sr-only">Send a chat request</DialogDescription>

            <div className="mt-5 inline-flex items-center gap-2 rounded-full border border-amber-300/30 bg-amber-400/10 px-4 py-1.5 text-sm font-semibold text-amber-200 backdrop-blur">
              <MessageSquare className="h-3.5 w-3.5" />
              ₹{ratePerMin} / min
            </div>

            <div className="mt-3 flex items-center gap-2 text-xs text-white/60">
              <Wallet className="h-3.5 w-3.5 text-white/50" />
              <span>
                Balance: <span className="font-semibold text-white/90">{wallet ? formatINR(Number(wallet.balance)) : "—"}</span>
                {wallet && minutesAffordable > 0 && <span className="text-white/40"> · ~{minutesAffordable} min</span>}
              </span>
            </div>

            <p className="mt-4 text-xs leading-relaxed text-white/50">
              A 5-minute hold (₹{ratePerMin * 5}) will be placed on your wallet until the chat ends. Final billing is pro-rated by minute.
            </p>

            <Button
              onClick={requestChat}
              disabled={submitting}
              className="mt-5 h-12 w-full rounded-xl bg-gradient-to-r from-purple-600 to-indigo-600 text-base font-semibold text-white shadow-lg shadow-purple-900/40 hover:from-purple-500 hover:to-indigo-500"
            >
              {submitting ? <Loader2 className="h-4 w-4 animate-spin" /> : <MessageSquare className="h-4 w-4" />}
              Send Chat Request
            </Button>
            <button
              onClick={() => onOpenChange(false)}
              className="mt-3 text-xs font-medium text-white/50 transition hover:text-white/80"
            >
              Cancel
            </button>
          </div>
        )}

        {/* WAITING PHASE */}
        {phase === "waiting" && (
          <div className="relative flex flex-col items-center px-6 pb-6 pt-8 text-center">
            <DialogTitle className="font-serif text-xl font-bold tracking-wide">Waiting for {astrologerName}</DialogTitle>
            <DialogDescription className="mt-1 text-sm text-white/60">
              Your request has been sent — please hold on.
            </DialogDescription>

            {/* Pulsing ring stack */}
            <div className="relative my-8 flex items-center justify-center" style={{ width: RING, height: RING }}>
              <span className="absolute inset-0 animate-ping rounded-full bg-amber-400/30" style={{ animationDuration: "2s" }} />
              <span
                className="absolute inset-2 animate-ping rounded-full bg-amber-400/40"
                style={{ animationDuration: "2.4s", animationDelay: "0.3s" }}
              />
              <svg width={RING} height={RING} className="-rotate-90">
                <circle cx={RING / 2} cy={RING / 2} r={R} stroke="rgba(255,255,255,0.12)" strokeWidth="5" fill="none" />
                <circle
                  cx={RING / 2}
                  cy={RING / 2}
                  r={R}
                  stroke="rgb(251, 191, 36)"
                  strokeWidth="5"
                  fill="none"
                  strokeLinecap="round"
                  strokeDasharray={C}
                  strokeDashoffset={dashOffset}
                  className="transition-[stroke-dashoffset] duration-500 ease-linear"
                />
              </svg>
              <span className="absolute inset-0 flex items-center justify-center text-xl font-bold text-amber-200">
                {secondsLeft}s
              </span>
            </div>

            <p className="text-sm font-medium text-white/80">Waiting for astrologer to accept…</p>
            <p className="mt-1 text-xs text-white/50">
              Auto-cancels in 0:{secondsLeft.toString().padStart(2, "0")}
            </p>

            <button
              onClick={cancelRequest}
              className="mt-6 text-sm font-medium text-red-300 underline-offset-4 transition hover:text-red-200 hover:underline"
            >
              Cancel Request
            </button>
          </div>
        )}

        {/* ACCEPTED PHASE */}
        {phase === "accepted" && (
          <div className="relative flex flex-col items-center px-6 pb-8 pt-10 text-center">
            <div className="mb-3 flex h-16 w-16 items-center justify-center rounded-full bg-gradient-to-br from-emerald-400 to-emerald-600 shadow-[0_0_30px_rgba(16,185,129,0.6)]">
              <CheckCircle2 className="h-8 w-8 text-white" />
            </div>
            <DialogTitle className="font-serif text-2xl font-bold">Request Accepted</DialogTitle>
            <p className="mt-2 text-sm text-white/70">Connecting you to {astrologerName}…</p>
          </div>
        )}

        {/* REJECTED PHASE */}
        {phase === "rejected" && (
          <div className="relative flex flex-col items-center px-6 pb-8 pt-10 text-center">
            <div className="mb-3 flex h-16 w-16 items-center justify-center rounded-full bg-gradient-to-br from-red-500 to-red-700 shadow-[0_0_30px_rgba(239,68,68,0.6)]">
              <XCircle className="h-8 w-8 text-white" />
            </div>
            <DialogTitle className="font-serif text-2xl font-bold">Request Declined</DialogTitle>
            <p className="mt-2 text-sm text-white/70">{astrologerName} can't take your chat right now.</p>
          </div>
        )}

        {/* TIMEOUT PHASE */}
        {phase === "timeout" && (
          <div className="relative flex flex-col items-center px-6 pb-8 pt-10 text-center">
            <div className="mb-3 flex h-16 w-16 items-center justify-center rounded-full bg-white/10 backdrop-blur">
              <Loader2 className="h-8 w-8 text-white/70" />
            </div>
            <DialogTitle className="font-serif text-2xl font-bold">Request Timed Out</DialogTitle>
            <p className="mt-2 text-sm text-white/70">The astrologer didn't respond in time. Please try again.</p>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}
