import { lazy, Suspense, useEffect, useRef, useState } from "react";
import { Button } from "@/components/ui/button";
import { Smile } from "lucide-react";
import { cn } from "@/lib/utils";

const EmojiPicker = lazy(() => import("emoji-picker-react"));

interface Props {
  onPick: (emoji: string) => void;
  /** dark | light theme for the picker */
  theme?: "dark" | "light";
  className?: string;
  disabled?: boolean;
}

export function EmojiPickerButton({ onPick, theme = "dark", className, disabled }: Props) {
  const [open, setOpen] = useState(false);
  const wrapRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!open) return;
    const onDoc = (e: MouseEvent) => {
      if (!wrapRef.current?.contains(e.target as Node)) setOpen(false);
    };
    const onEsc = (e: KeyboardEvent) => { if (e.key === "Escape") setOpen(false); };
    document.addEventListener("mousedown", onDoc);
    document.addEventListener("keydown", onEsc);
    return () => {
      document.removeEventListener("mousedown", onDoc);
      document.removeEventListener("keydown", onEsc);
    };
  }, [open]);

  return (
    <div ref={wrapRef} className={cn("relative", className)}>
      <Button
        type="button"
        variant="ghost"
        size="icon"
        disabled={disabled}
        onMouseDown={(e) => {
          // Keep textarea focus on toggle
          e.preventDefault();
          setOpen((v) => !v);
        }}
        className={cn(
          "h-10 w-10 shrink-0 rounded-full text-amber-300 hover:bg-white/10 hover:text-amber-200",
          open && "bg-white/10",
        )}
        aria-label="Insert emoji"
      >
        <Smile className="h-5 w-5" />
      </Button>
      {open && (
        <div
          className="absolute bottom-12 right-0 z-50 origin-bottom-right animate-scale-in rounded-2xl border border-white/10 bg-[#1a1233]/95 p-1 shadow-2xl backdrop-blur-xl"
          // prevent input blur when interacting
          onMouseDown={(e) => e.preventDefault()}
        >
          <Suspense fallback={<div className="p-6 text-xs text-white/60">Loading…</div>}>
            <EmojiPicker
              theme={theme as any}
              width={320}
              height={380}
              lazyLoadEmojis
              skinTonesDisabled
              previewConfig={{ showPreview: false }}
              searchDisabled={false}
              onEmojiClick={(d) => {
                onPick(d.emoji);
              }}
            />
          </Suspense>
        </div>
      )}
    </div>
  );
}
