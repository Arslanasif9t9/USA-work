import { ArrowLeft, Gift, MessageCircle, Phone, Sparkles, Star } from "lucide-react";
import { Button } from "@/components/ui/button";

interface Props {
  endedBy: string | null;
  durationLabel: string;
  totalCost: number;
  isCurrentUserEnder: boolean;
  /** When true, render the astrologer-side summary (earnings) */
  isAstrologer?: boolean;
  astrologerEarning?: number;
  onBack: () => void;
  /** Customer-only actions */
  onChatAgain?: () => void;
  onCallAgain?: () => void;
  onSendGift?: () => void;
  onRecommended?: () => void;
}

export function SessionEndedOverlay({
  endedBy,
  durationLabel,
  totalCost,
  isCurrentUserEnder,
  isAstrologer = false,
  astrologerEarning = 0,
  onBack,
  onChatAgain,
  onCallAgain,
  onSendGift,
  onRecommended,
}: Props) {
  const subtitle = isCurrentUserEnder
    ? "You ended the session"
    : endedBy === "system"
    ? "Session ended automatically"
    : endedBy === "customer"
    ? "Session ended by customer"
    : endedBy === "astrologer"
    ? "Session ended by astrologer"
    : "The session has ended";

  return (
    <div className="fixed inset-0 z-[120] flex items-start justify-center overflow-y-auto bg-black/85 px-4 py-8 backdrop-blur-xl animate-fade-in">
      {/* Top-left back arrow */}
      <button
        onClick={onBack}
        className="fixed left-4 top-4 z-10 inline-flex h-10 items-center gap-2 rounded-full border border-white/15 bg-white/10 px-3 text-sm text-white/90 backdrop-blur-md transition hover:bg-white/20"
        aria-label="Back"
      >
        <ArrowLeft className="h-4 w-4" /> Back
      </button>

      <div className="relative my-auto w-full max-w-md overflow-hidden rounded-3xl border border-white/10 bg-gradient-to-br from-[#1a1233] via-[#0f0a1e] to-[#1a1233] p-7 text-center text-white shadow-2xl animate-scale-in">
        <div className="pointer-events-none absolute inset-0 opacity-30 [background-image:radial-gradient(white_1px,transparent_1px)] [background-size:24px_24px]" />

        <div className="relative">
          {/* Glowing star */}
          <div className="relative mx-auto mb-5 flex h-20 w-20 items-center justify-center">
            <span className="absolute inset-0 animate-ping rounded-full bg-amber-400/40" />
            <span className="absolute inset-2 rounded-full bg-gradient-to-br from-amber-300 to-amber-600 opacity-80 blur-md" />
            <div className="relative flex h-16 w-16 items-center justify-center rounded-full bg-gradient-to-br from-amber-300 to-amber-500 shadow-[0_0_40px_rgba(251,191,36,0.7)]">
              <Sparkles className="h-8 w-8 text-black" />
            </div>
          </div>

          <h2 className="font-serif text-3xl font-bold tracking-wide">Session Ended</h2>
          <p className="mt-1 text-sm text-white/70">{subtitle}</p>

          {/* Summary */}
          <div className="mt-5 rounded-2xl border border-white/10 bg-white/5 p-5 backdrop-blur-xl">
            <p className="text-xs uppercase tracking-widest text-white/50">Summary</p>
            <div className="mt-3 grid grid-cols-2 gap-3">
              <div>
                <p className="text-[11px] uppercase tracking-wider text-white/50">Duration</p>
                <p className="mt-0.5 font-mono text-xl font-bold">{durationLabel}</p>
              </div>
              <div>
                <p className="text-[11px] uppercase tracking-wider text-white/50">
                  {isAstrologer ? "Total" : "Total"}
                </p>
                <p className="mt-0.5 text-xl font-bold text-amber-300">₹{totalCost}</p>
              </div>
            </div>

            {isAstrologer && (
              <div className="mt-3 rounded-xl border border-emerald-400/30 bg-emerald-400/10 p-3">
                <p className="text-[11px] uppercase tracking-wider text-emerald-200/80">Your earnings (30%)</p>
                <p className="mt-0.5 text-2xl font-bold text-emerald-300">+ ₹{astrologerEarning}</p>
                <p className="mt-1 text-[10px] text-white/50">Credited to your wallet</p>
              </div>
            )}
          </div>

          {/* Customer actions */}
          {!isAstrologer && (
            <div className="mt-5 grid grid-cols-2 gap-2.5">
              <ActionButton onClick={onChatAgain} icon={<MessageCircle className="h-4 w-4" />} label="Chat Again" />
              <ActionButton onClick={onCallAgain} icon={<Phone className="h-4 w-4" />} label="Call Again" />
              <ActionButton onClick={onSendGift} icon={<Gift className="h-4 w-4" />} label="Send Gift" />
              <ActionButton onClick={onRecommended} icon={<Star className="h-4 w-4" />} label="Recommended" />
            </div>
          )}

          {isAstrologer && (
            <Button
              onClick={onBack}
              className="mt-5 w-full bg-gradient-to-r from-purple-600 to-indigo-600 text-white hover:from-purple-500 hover:to-indigo-500"
            >
              Back to Dashboard
            </Button>
          )}
        </div>
      </div>
    </div>
  );
}

function ActionButton({
  onClick,
  icon,
  label,
}: {
  onClick?: () => void;
  icon: React.ReactNode;
  label: string;
}) {
  return (
    <button
      onClick={onClick}
      className="group flex flex-col items-center gap-1.5 rounded-2xl border border-white/10 bg-white/5 px-3 py-3 text-xs font-semibold text-white/90 transition hover:border-amber-300/40 hover:bg-amber-300/10 hover:text-amber-200"
    >
      <span className="flex h-9 w-9 items-center justify-center rounded-full bg-gradient-to-br from-purple-600/40 to-indigo-600/40 text-white group-hover:from-amber-400/60 group-hover:to-amber-600/60 group-hover:text-black">
        {icon}
      </span>
      {label}
    </button>
  );
}
