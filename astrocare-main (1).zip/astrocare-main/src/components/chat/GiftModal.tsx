import { useEffect, useState } from "react";
import { Dialog, DialogContent, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { Gift, Loader2, Sparkles } from "lucide-react";
import { toast } from "sonner";
import { cn } from "@/lib/utils";


interface Props {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  astrologerId: string;
  astrologerName: string;
  sessionId?: string | null;
}

interface GiftDef {
  type: string;
  label: string;
  amount: number;
  emoji: string;
}

const GIFTS: GiftDef[] = [
  { type: "star",       label: "Star",      amount: 21,   emoji: "⭐" },
  { type: "rose",       label: "Rose",      amount: 51,   emoji: "🌹" },
  { type: "diamond",    label: "Diamond",   amount: 101,  emoji: "💎" },
  { type: "crown",      label: "Crown",     amount: 251,  emoji: "👑" },
  { type: "moonlight",  label: "Moonlight", amount: 501,  emoji: "🌙" },
  { type: "blessing",   label: "Blessing",  amount: 1001, emoji: "✨" },
];

export function GiftModal({ open, onOpenChange, astrologerId, astrologerName, sessionId }: Props) {
  const { user } = useAuth();
  const [selected, setSelected] = useState<GiftDef | null>(null);
  const [note, setNote] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [showSuccess, setShowSuccess] = useState(false);

  useEffect(() => {
    if (!open) {
      const t = setTimeout(() => {
        setSelected(null);
        setNote("");
        setShowSuccess(false);
        setSubmitting(false);
      }, 200);
      return () => clearTimeout(t);
    }
  }, [open]);

  const send = async () => {
    if (!selected || !user) {
      if (!user) toast.error("Please sign in first");
      return;
    }
    setSubmitting(true);

    // Single RPC handles wallet debit, astrologer credit, gift insert, and notification
    const { data: rpcData, error: rpcErr } = await supabase.rpc("send_gift", {
      _astrologer_id: astrologerId,
      _gift_type: selected.type,
      _amount: selected.amount,
      _gift_label: `${selected.label} ${selected.emoji}`,
      _customer_note: note.trim() || null,
      _session_id: sessionId ?? null,
    });

    if (rpcErr) {
      setSubmitting(false);
      const msg = rpcErr.message || "Could not send gift";
      if (msg.toLowerCase().includes("insufficient")) {
        toast.error(`Need ₹${selected.amount} in wallet`, {
          description: "Top up your wallet to send this gift.",
        });
      } else {
        toast.error(msg);
      }
      return;
    }
    void rpcData;

    // System message in chat if active session
    if (sessionId) {
      await supabase.from("chat_messages").insert({
        session_id: sessionId,
        sender_id: user.id,
        sender_role: "system",
        content: `🎁 Sent a ${selected.label} ${selected.emoji} (₹${selected.amount})${note.trim() ? `\n💬 “${note.trim()}”` : ""}`,
      });
    }

    setShowSuccess(true);
    setTimeout(() => {
      setSubmitting(false);
      onOpenChange(false);
    }, 1400);
  };

  return (
    <Dialog open={open} onOpenChange={(v) => !submitting && onOpenChange(v)}>
      <DialogContent
        onInteractOutside={(e) => { if (submitting) e.preventDefault(); }}
        onEscapeKeyDown={(e) => { if (submitting) e.preventDefault(); }}
        className="max-w-md overflow-hidden border-amber-300/30 bg-gradient-to-br from-[#1a1233] via-[#0f0a1e] to-[#1a1233] p-0 text-white shadow-[0_0_60px_rgba(251,191,36,0.25)] sm:rounded-3xl"
      >
        <div className="pointer-events-none absolute inset-0 opacity-30 [background-image:radial-gradient(white_1px,transparent_1px)] [background-size:24px_24px]" />
        <div className="pointer-events-none absolute -top-24 -left-24 h-56 w-56 rounded-full bg-amber-500/30 blur-3xl" />
        <div className="pointer-events-none absolute -bottom-24 -right-24 h-56 w-56 rounded-full bg-purple-600/30 blur-3xl" />

        {showSuccess ? (
          <div className="relative flex flex-col items-center justify-center px-6 py-12 text-center animate-fade-in">
            <div className="relative mb-3">
              <span className="absolute inset-0 -m-3 animate-ping rounded-full bg-amber-300/40" />
              <div className="relative flex h-20 w-20 items-center justify-center rounded-full bg-gradient-to-br from-amber-300 to-amber-500 text-4xl shadow-[0_0_40px_rgba(251,191,36,0.7)]">
                {selected?.emoji}
              </div>
              <Sparkles className="absolute -right-2 -top-2 h-6 w-6 animate-pulse text-amber-300" />
              <Sparkles className="absolute -left-2 -bottom-2 h-5 w-5 animate-pulse text-amber-200" />
            </div>
            <DialogTitle className="font-serif text-2xl font-bold">Gift sent! 🎉</DialogTitle>
            <DialogDescription className="mt-1 text-sm text-white/70">
              {astrologerName} will love it.
            </DialogDescription>
          </div>
        ) : (
          <div className="relative px-6 pb-6 pt-7">
            <div className="text-center">
              <div className="mx-auto mb-2 flex h-12 w-12 items-center justify-center rounded-full bg-gradient-to-br from-amber-300/30 to-amber-500/20 text-amber-200">
                <Gift className="h-6 w-6" />
              </div>
              <DialogTitle className="font-serif text-xl font-bold tracking-wide">
                Send a gift to <span className="text-amber-300">{astrologerName}</span>
              </DialogTitle>
              <DialogDescription className="mt-1 text-xs text-white/60">
                Show your appreciation — debited from your wallet
              </DialogDescription>
            </div>

            <div className="mt-5 grid grid-cols-3 gap-2.5">
              {GIFTS.map((g) => {
                const isSel = selected?.type === g.type;
                return (
                  <button
                    key={g.type}
                    type="button"
                    onClick={() => setSelected(g)}
                    className={cn(
                      "group relative flex flex-col items-center gap-1 rounded-2xl border bg-white/5 p-3 transition-all",
                      isSel
                        ? "border-amber-300 bg-amber-300/15 shadow-[0_0_20px_rgba(251,191,36,0.4)]"
                        : "border-white/10 hover:border-amber-300/50 hover:bg-white/10",
                    )}
                  >
                    <span className="text-3xl leading-none transition-transform group-hover:scale-110">{g.emoji}</span>
                    <span className="text-xs font-semibold text-white">{g.label}</span>
                    <span className="text-[11px] font-bold text-amber-300">₹{g.amount}</span>
                  </button>
                );
              })}
            </div>

            <div className="mt-5">
              <Textarea
                value={note}
                onChange={(e) => setNote(e.target.value.slice(0, 200))}
                placeholder={`Write a message for ${astrologerName}… (optional)`}
                rows={2}
                className="resize-none rounded-xl border-white/15 bg-white/10 text-sm text-white placeholder:text-white/40 focus-visible:ring-amber-300"
              />
              <p className="mt-1 text-right text-[10px] text-white/40">{note.length}/200</p>
            </div>

            <Button
              onClick={send}
              disabled={!selected || submitting}
              className="mt-4 h-12 w-full rounded-xl bg-gradient-to-r from-amber-300 via-amber-400 to-amber-500 text-base font-bold text-black shadow-lg shadow-amber-900/30 hover:from-amber-200 hover:to-amber-400 disabled:opacity-50"
            >
              {submitting ? (
                <Loader2 className="h-4 w-4 animate-spin" />
              ) : selected ? (
                <>
                  <Gift className="h-4 w-4" /> Send {selected.label} · ₹{selected.amount}
                </>
              ) : (
                "Choose a gift"
              )}
            </Button>
            <button
              onClick={() => onOpenChange(false)}
              className="mt-2 block w-full text-center text-xs font-medium text-white/50 transition hover:text-white/80"
            >
              Cancel
            </button>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}
