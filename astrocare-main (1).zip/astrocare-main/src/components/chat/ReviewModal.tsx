import { useState } from "react";
import { Dialog, DialogContent, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Textarea } from "@/components/ui/textarea";
import { Star, Loader2, CheckCircle2 } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { toast } from "sonner";

interface Props {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  astrologerId: string;
  astrologerName: string;
  astrologerAvatar?: string | null;
  onSubmitted?: () => void;
}

export function ReviewModal({
  open,
  onOpenChange,
  astrologerId,
  astrologerName,
  astrologerAvatar,
  onSubmitted,
}: Props) {
  const { user } = useAuth();
  const [rating, setRating] = useState(0);
  const [hover, setHover] = useState(0);
  const [comment, setComment] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [done, setDone] = useState(false);

  const initials = astrologerName.split(" ").map((p) => p[0]).join("").slice(0, 2).toUpperCase();

  const submit = async () => {
    if (!user) {
      toast.error("Please sign in");
      return;
    }
    if (rating < 1) {
      toast.error("Please select a star rating");
      return;
    }
    setSubmitting(true);
    const { error } = await supabase.from("reviews").insert({
      astrologer_id: astrologerId,
      user_id: user.id,
      rating,
      comment: comment.trim() || null,
    });
    setSubmitting(false);
    if (error) {
      toast.error(error.message);
      return;
    }
    setDone(true);
    toast.success("Thanks! Your review will appear after moderation.");
    onSubmitted?.();
    setTimeout(() => onOpenChange(false), 1400);
  };

  const labels = ["", "Poor", "Fair", "Good", "Great", "Excellent"];

  return (
    <Dialog open={open} onOpenChange={(v) => !submitting && onOpenChange(v)}>
      <DialogContent
        className="max-w-sm overflow-hidden border-purple-500/30 bg-gradient-to-br from-[#1a1233] via-[#0f0a1e] to-[#1a1233] p-0 text-white shadow-[0_0_60px_rgba(139,92,246,0.35)] sm:rounded-3xl"
      >
        <div className="pointer-events-none absolute inset-0 opacity-30 [background-image:radial-gradient(white_1px,transparent_1px)] [background-size:24px_24px]" />
        <div className="pointer-events-none absolute -top-24 -left-24 h-56 w-56 rounded-full bg-purple-600/40 blur-3xl" />
        <div className="pointer-events-none absolute -bottom-24 -right-24 h-56 w-56 rounded-full bg-indigo-600/30 blur-3xl" />

        {!done ? (
          <div className="relative flex flex-col items-center px-6 pb-6 pt-8 text-center">
            <div className="relative mb-4">
              <span className="absolute inset-0 -m-1.5 rounded-full bg-gradient-to-br from-amber-300 to-amber-600 opacity-90" />
              <Avatar className="relative h-20 w-20 ring-4 ring-amber-300/80">
                <AvatarImage src={astrologerAvatar ?? undefined} alt={astrologerName} className="object-cover" />
                <AvatarFallback className="bg-purple-700 text-xl font-semibold">{initials}</AvatarFallback>
              </Avatar>
            </div>

            <DialogTitle className="font-serif text-2xl font-bold tracking-wide">Rate your session</DialogTitle>
            <DialogDescription className="mt-1 text-sm text-white/60">
              How was your chat with {astrologerName}?
            </DialogDescription>

            <div className="mt-5 flex items-center gap-1.5">
              {[1, 2, 3, 4, 5].map((n) => {
                const active = (hover || rating) >= n;
                return (
                  <button
                    key={n}
                    type="button"
                    onMouseEnter={() => setHover(n)}
                    onMouseLeave={() => setHover(0)}
                    onClick={() => setRating(n)}
                    className="p-1 transition hover:scale-110"
                    aria-label={`${n} star${n > 1 ? "s" : ""}`}
                  >
                    <Star
                      className={`h-9 w-9 transition ${
                        active ? "fill-amber-400 text-amber-400 drop-shadow-[0_0_10px_rgba(251,191,36,0.6)]" : "text-white/25"
                      }`}
                    />
                  </button>
                );
              })}
            </div>
            <p className="mt-1.5 h-5 text-xs font-semibold text-amber-300">
              {labels[hover || rating] ?? ""}
            </p>

            <Textarea
              value={comment}
              onChange={(e) => setComment(e.target.value)}
              placeholder="Share a few words about your experience (optional)"
              rows={3}
              className="mt-4 resize-none border-white/15 bg-white/5 text-sm text-white placeholder:text-white/40 focus-visible:ring-amber-400"
            />

            <Button
              onClick={submit}
              disabled={submitting || rating < 1}
              className="mt-5 h-12 w-full rounded-xl bg-gradient-to-r from-purple-600 to-indigo-600 text-base font-semibold text-white shadow-lg shadow-purple-900/40 hover:from-purple-500 hover:to-indigo-500"
            >
              {submitting ? <Loader2 className="h-4 w-4 animate-spin" /> : <Star className="h-4 w-4" />}
              Submit Review
            </Button>
            <button
              onClick={() => onOpenChange(false)}
              disabled={submitting}
              className="mt-3 text-xs font-medium text-white/50 transition hover:text-white/80"
            >
              Skip for now
            </button>
          </div>
        ) : (
          <div className="relative flex flex-col items-center px-6 pb-8 pt-10 text-center">
            <div className="mb-3 flex h-16 w-16 items-center justify-center rounded-full bg-gradient-to-br from-emerald-400 to-emerald-600 shadow-[0_0_30px_rgba(16,185,129,0.6)]">
              <CheckCircle2 className="h-8 w-8 text-white" />
            </div>
            <DialogTitle className="font-serif text-2xl font-bold">Thank you!</DialogTitle>
            <p className="mt-2 text-sm text-white/70">Your review helps the community.</p>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}
