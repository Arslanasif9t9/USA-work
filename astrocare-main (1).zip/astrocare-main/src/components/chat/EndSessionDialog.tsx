import { Dialog, DialogContent, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { AlertTriangle, Loader2, PhoneOff } from "lucide-react";

interface Props {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  onConfirm: () => void;
  durationLabel: string;
  estimatedCost: number;
  loading?: boolean;
}

export function EndSessionDialog({ open, onOpenChange, onConfirm, durationLabel, estimatedCost, loading }: Props) {
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent
        className="max-w-sm overflow-hidden border-white/10 bg-gradient-to-br from-[#1a1233] via-[#0f0a1e] to-[#1a1233] p-6 text-white shadow-2xl sm:rounded-3xl"
      >
        <div className="pointer-events-none absolute inset-0 opacity-20 [background-image:radial-gradient(white_1px,transparent_1px)] [background-size:24px_24px]" />
        <div className="relative flex flex-col items-center text-center">
          <div className="relative mb-4">
            <span className="absolute inset-0 -m-2 animate-ping rounded-full bg-red-500/40" />
            <div className="relative flex h-16 w-16 items-center justify-center rounded-full bg-gradient-to-br from-red-500 to-red-700 shadow-[0_0_30px_rgba(239,68,68,0.6)]">
              <AlertTriangle className="h-8 w-8 text-white" />
            </div>
          </div>

          <DialogTitle className="font-serif text-2xl font-bold tracking-wide">End Session?</DialogTitle>
          <DialogDescription className="mt-2 text-sm text-white/70">
            Billing will be finalized immediately and you won't be able to reconnect.
          </DialogDescription>

          <div className="mt-5 w-full rounded-2xl border border-white/10 bg-white/5 p-4 backdrop-blur-xl">
            <div className="flex items-center justify-between text-sm">
              <span className="text-white/60">Duration so far</span>
              <span className="font-mono text-base font-bold tracking-wider text-white">{durationLabel}</span>
            </div>
            <div className="mt-2 flex items-center justify-between text-sm">
              <span className="text-white/60">Estimated cost</span>
              <span className="text-base font-bold text-amber-300">₹{estimatedCost}</span>
            </div>
          </div>

          <div className="mt-6 flex w-full flex-col gap-2.5">
            <Button
              onClick={onConfirm}
              disabled={loading}
              className="h-12 w-full rounded-xl bg-gradient-to-r from-red-500 to-red-600 text-base font-semibold text-white shadow-lg shadow-red-900/40 hover:from-red-400 hover:to-red-500"
            >
              {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : <PhoneOff className="h-4 w-4" />}
              Yes, End Session
            </Button>
            <Button
              variant="outline"
              onClick={() => onOpenChange(false)}
              disabled={loading}
              className="h-11 w-full rounded-xl border-white/20 bg-transparent text-white/80 hover:bg-white/10 hover:text-white"
            >
              Continue Session
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
