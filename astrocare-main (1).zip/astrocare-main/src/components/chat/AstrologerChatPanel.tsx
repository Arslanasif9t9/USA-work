import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { MessageSquare, Check, X, Loader2 } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { toast } from "sonner";

interface Props {
  astrologerId: string;
  initialAcceptingChat: boolean;
  initialChatOnline: boolean;
  initialChatRate: number;
}

interface PendingSession {
  id: string;
  user_id: string;
  per_minute_rate: number;
  requested_at: string;
  customer_name: string | null;
}

export function AstrologerChatPanel({ astrologerId, initialAcceptingChat, initialChatOnline, initialChatRate }: Props) {
  const navigate = useNavigate();
  const [accepting, setAccepting] = useState(initialAcceptingChat);
  const [online, setOnline] = useState(initialChatOnline);
  const [rate, setRate] = useState(initialChatRate);
  const [savingRate, setSavingRate] = useState(false);
  const [pending, setPending] = useState<PendingSession[]>([]);
  const [actioning, setActioning] = useState<string | null>(null);

  // Load pending requests
  useEffect(() => {
    const load = async () => {
      const { data } = await supabase
        .from("chat_sessions")
        .select("id, user_id, per_minute_rate, requested_at")
        .eq("astrologer_id", astrologerId)
        .eq("status", "pending")
        .order("requested_at", { ascending: false });
      const sessions = (data ?? []) as PendingSession[];
      // Fetch names
      const ids = [...new Set(sessions.map((s) => s.user_id))];
      if (ids.length) {
        const { data: profs } = await supabase.from("profiles").select("id, name").in("id", ids);
        const map = new Map((profs ?? []).map((p) => [p.id, p.name]));
        sessions.forEach((s) => (s.customer_name = map.get(s.user_id) ?? null));
      }
      setPending(sessions);
    };
    load();

    const ch = supabase
      .channel(`astro-chat:${astrologerId}`)
      .on(
        "postgres_changes",
        { event: "*", schema: "public", table: "chat_sessions", filter: `astrologer_id=eq.${astrologerId}` },
        () => load(),
      )
      .subscribe();
    return () => {
      supabase.removeChannel(ch);
    };
  }, [astrologerId]);

  const toggleAccepting = async (v: boolean) => {
    setAccepting(v);
    await supabase.from("astrologers").update({ accepting_chat: v }).eq("id", astrologerId);
  };
  const toggleOnline = async (v: boolean) => {
    setOnline(v);
    await supabase.from("astrologers").update({ is_chat_online: v }).eq("id", astrologerId);
  };
  const saveRate = async () => {
    setSavingRate(true);
    await supabase.from("astrologers").update({ chat_rate_per_min: rate }).eq("id", astrologerId);
    setSavingRate(false);
    toast.success("Chat rate updated");
  };

  const respond = async (sessionId: string, action: "accept" | "reject") => {
    setActioning(sessionId);
    const { data, error } = await supabase.functions.invoke("respond-chat", {
      body: { session_id: sessionId, action },
    });
    setActioning(null);
    if (error || (data as any)?.error) {
      toast.error((data as any)?.error ?? error?.message ?? "Failed");
      return;
    }
    if (action === "accept") {
      navigate(`/astrologer/chat/${sessionId}`);
    } else {
      toast.success("Request declined");
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-base">
          <MessageSquare className="h-4 w-4 text-primary" /> Chat — settings & requests
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-5">
        <div className="grid gap-4 sm:grid-cols-3">
          <div className="flex items-center justify-between rounded-lg border border-border p-3">
            <div>
              <Label className="text-sm">Available for chat</Label>
              <p className="text-xs text-muted-foreground">Accept incoming chats</p>
            </div>
            <Switch checked={accepting} onCheckedChange={toggleAccepting} />
          </div>
          <div className="flex items-center justify-between rounded-lg border border-border p-3">
            <div>
              <Label className="text-sm">Chat online</Label>
              <p className="text-xs text-muted-foreground">Show as online for chat</p>
            </div>
            <Switch checked={online} onCheckedChange={toggleOnline} />
          </div>
          <div className="space-y-1.5 rounded-lg border border-border p-3">
            <Label className="text-sm">Chat rate (₹/min)</Label>
            <div className="flex gap-2">
              <Input type="number" min={0} value={rate} onChange={(e) => setRate(Number(e.target.value))} />
              <Button size="sm" onClick={saveRate} disabled={savingRate}>
                {savingRate ? <Loader2 className="h-4 w-4 animate-spin" /> : "Save"}
              </Button>
            </div>
          </div>
        </div>

        <div>
          <h3 className="mb-2 text-sm font-semibold">Incoming requests {pending.length > 0 && <Badge className="ml-1">{pending.length}</Badge>}</h3>
          {pending.length === 0 ? (
            <p className="text-sm text-muted-foreground">No pending chat requests.</p>
          ) : (
            <div className="space-y-2">
              {pending.map((p) => (
                <div key={p.id} className="flex items-center justify-between rounded-lg border border-border bg-card p-3">
                  <div>
                    <p className="text-sm font-medium">{p.customer_name ?? "Customer"}</p>
                    <p className="text-xs text-muted-foreground">
                      ₹{p.per_minute_rate}/min · requested {new Date(p.requested_at).toLocaleTimeString()}
                    </p>
                  </div>
                  <div className="flex gap-2">
                    <Button
                      size="sm"
                      variant="outline"
                      disabled={actioning === p.id}
                      onClick={() => respond(p.id, "reject")}
                    >
                      <X className="h-4 w-4" /> Decline
                    </Button>
                    <Button size="sm" disabled={actioning === p.id} onClick={() => respond(p.id, "accept")}>
                      {actioning === p.id ? <Loader2 className="h-4 w-4 animate-spin" /> : <Check className="h-4 w-4" />}
                      Accept
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}
