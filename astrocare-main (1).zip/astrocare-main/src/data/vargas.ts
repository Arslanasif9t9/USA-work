import type { VargaInfo, DCode } from "@/types/shodashvarga";

export const VARGAS: VargaInfo[] = [
  {
    code: "D1", name: "Lagna", nameHindi: "लग्न",
    meaning: "Self, body, life path", meaningHindi: "स्व, शरीर, जीवन पथ",
    description: "The main birth chart showing your overall life and personality.",
    descriptionHindi: "आपकी समग्र जीवन और व्यक्तित्व को दर्शाने वाली मुख्य जन्म कुंडली।",
  },
  {
    code: "D2", name: "Hora", nameHindi: "होरा",
    meaning: "Wealth, finance", meaningHindi: "धन, वित्त",
    description: "Reveals financial prosperity and ability to accumulate wealth.",
    descriptionHindi: "आर्थिक समृद्धि और धन संचय की क्षमता को दर्शाती है।",
  },
  {
    code: "D3", name: "Drekkana", nameHindi: "द्रेक्काण",
    meaning: "Siblings, courage", meaningHindi: "भाई-बहन, साहस",
    description: "Shows siblings, personal courage and inner strength.",
    descriptionHindi: "भाई-बहन, व्यक्तिगत साहस और आंतरिक शक्ति को दर्शाती है।",
  },
  {
    code: "D4", name: "Chaturthamsa", nameHindi: "चतुर्थांश",
    meaning: "Property, fortune", meaningHindi: "संपत्ति, भाग्य",
    description: "Reveals property, real estate and fixed assets.",
    descriptionHindi: "संपत्ति, अचल संपत्ति और स्थायी परिसंपत्तियों को दर्शाती है।",
  },
  {
    code: "D7", name: "Saptamsa", nameHindi: "सप्तांश",
    meaning: "Children, progeny", meaningHindi: "संतान, वंश",
    description: "Shows children and creative progeny.",
    descriptionHindi: "संतान और रचनात्मक वंश को दर्शाती है।",
  },
  {
    code: "D9", name: "Navamsa", nameHindi: "नवांश",
    meaning: "Marriage, dharma", meaningHindi: "विवाह, धर्म",
    description: "Reveals marriage, spouse and the dharmic path of the soul.",
    descriptionHindi: "विवाह, जीवनसाथी और आत्मा के धार्मिक पथ को दर्शाती है।",
  },
  {
    code: "D10", name: "Dasamsa", nameHindi: "दशांश",
    meaning: "Career, profession", meaningHindi: "करियर, व्यवसाय",
    description: "Shows career, profession and public achievements.",
    descriptionHindi: "करियर, व्यवसाय और सार्वजनिक उपलब्धियों को दर्शाती है।",
  },
  {
    code: "D12", name: "Dwadasamsa", nameHindi: "द्वादशांश",
    meaning: "Parents, ancestry", meaningHindi: "माता-पिता, वंशावली",
    description: "Reveals parents, lineage and inherited karma.",
    descriptionHindi: "माता-पिता, वंशावली और पैतृक कर्म को दर्शाती है।",
  },
  {
    code: "D16", name: "Shodasamsa", nameHindi: "षोडशांश",
    meaning: "Vehicles, comforts", meaningHindi: "वाहन, सुख",
    description: "Shows vehicles, conveyances and material comforts.",
    descriptionHindi: "वाहन, सवारी और भौतिक सुखों को दर्शाती है।",
  },
  {
    code: "D20", name: "Vimsamsa", nameHindi: "विंशांश",
    meaning: "Spiritual progress", meaningHindi: "आध्यात्मिक प्रगति",
    description: "Reveals spiritual practice, sadhana and inner growth.",
    descriptionHindi: "आध्यात्मिक साधना और आंतरिक विकास को दर्शाती है।",
  },
  {
    code: "D24", name: "Chaturvimsamsa", nameHindi: "चतुर्विंशांश",
    meaning: "Education, learning", meaningHindi: "शिक्षा, ज्ञान",
    description: "Shows education, academic success and knowledge.",
    descriptionHindi: "शिक्षा, शैक्षणिक सफलता और ज्ञान को दर्शाती है।",
  },
  {
    code: "D27", name: "Bhamsa", nameHindi: "भांश",
    meaning: "Strengths, weaknesses", meaningHindi: "शक्तियाँ, कमजोरियाँ",
    description: "Reveals overall strengths and weaknesses.",
    descriptionHindi: "समग्र शक्तियों और कमजोरियों को दर्शाती है।",
  },
  {
    code: "D30", name: "Trimsamsa", nameHindi: "त्रिंशांश",
    meaning: "Misfortunes, evils", meaningHindi: "दुर्भाग्य, अरिष्ट",
    description: "Shows misfortunes, troubles and afflictions.",
    descriptionHindi: "दुर्भाग्य, कष्ट और पीड़ाओं को दर्शाती है।",
  },
  {
    code: "D40", name: "Khavedamsa", nameHindi: "खवेदांश",
    meaning: "Maternal legacy", meaningHindi: "मातृ विरासत",
    description: "Reveals maternal lineage and auspicious results.",
    descriptionHindi: "मातृ वंश और शुभ फलों को दर्शाती है।",
  },
  {
    code: "D45", name: "Akshavedamsa", nameHindi: "अक्षवेदांश",
    meaning: "Paternal legacy", meaningHindi: "पितृ विरासत",
    description: "Reveals paternal lineage and overall character.",
    descriptionHindi: "पितृ वंश और समग्र चरित्र को दर्शाती है।",
  },
  {
    code: "D60", name: "Shashtiamsa", nameHindi: "षष्ट्यंश",
    meaning: "Past karma, all events", meaningHindi: "पूर्व कर्म, सर्व विषय",
    description: "Shows past life karma and overall life events.",
    descriptionHindi: "पूर्व जन्म के कर्म और समग्र जीवन घटनाओं को दर्शाती है।",
  },
];

export const PHASE_1_DCODES: DCode[] = ["D1", "D2", "D3", "D7", "D9", "D10", "D12"];

export const PHASE_1_VARGAS: VargaInfo[] =
  VARGAS.filter((v) => PHASE_1_DCODES.includes(v.code));

export function getVarga(code: DCode): VargaInfo | undefined {
  return VARGAS.find((v) => v.code === code);
}
