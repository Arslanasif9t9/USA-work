import type { NakshatraStaticData } from "@/types/nakshatra";

/**
 * Nakshatra static reference data.
 *
 * Phase A: full content for nakshatras 1–9 (Ashwini through Ashlesha) including
 *   original 200–250 word personality essays in English and Hindi.
 * Phase B: nakshatras 10–27 ship as minimal stubs (classification + mantra +
 *   padas + short personality). The drawer renders gracefully — sections that
 *   need rich copy fall back to a "Coming soon" line and we lean on the API
 *   response when available.
 *
 * Source: Brihat Parashara Hora Shastra public-domain attributes (lord, deity,
 * symbol, gana, yoni, nadi, varna, tatva, direction, color, body part, padas,
 * mantra). Personality essays are original prose synthesizing those classical
 * attributes — explicitly NOT copied from AstroSage or any commercial site.
 */

const FULL_RAHU_PLACEHOLDER = "तपस्या";

// ---------------------------------------------------------------------------
// Phase A — full entries (1–9)
// ---------------------------------------------------------------------------

const ASHWINI: NakshatraStaticData = {
  id: 1,
  name: "Ashwini",
  nameHindi: "अश्विनी",
  symbol: "Horse's head",
  symbolIcon: "🐎",
  meaning: "Born of a mare; the swift one",
  meaningHindi: "घोड़ी से उत्पन्न; द्रुतगामी",
  lord: "Ketu",
  lordHindi: "केतु",
  deity: "Ashwini Kumaras (twin physicians of the gods)",
  deityHindi: "अश्विनी कुमार",
  gana: "Deva",
  ganaHindi: "देव",
  yoni: "Horse (Male)",
  yoniHindi: "अश्व (नर)",
  nadi: "Adi",
  nadiHindi: "आदि",
  varna: "Vaishya",
  varnaHindi: "वैश्य",
  tatva: "Earth",
  tatvaHindi: "पृथ्वी",
  direction: "South",
  directionHindi: "दक्षिण",
  color: "Blood Red",
  colorHex: "#8B0000",
  bodyPart: "Knees",
  bodyPartHindi: "घुटने",
  animal: "Horse",
  bird: "Eagle",
  tree: "Strychnine (Kuchla)",
  mantra: "ॐ अश्विनी कुमाराय नमः",
  mantraTransliteration: "Om Ashwini Kumaraya Namah",
  padas: [
    { syllable: "Chu", characteristic: "Pioneering and physical", characteristicHindi: "अग्रणी एवं सक्रिय" },
    { syllable: "Che", characteristic: "Communicative and curious", characteristicHindi: "वाचाल एवं जिज्ञासु" },
    { syllable: "Cho", characteristic: "Devoted and emotional", characteristicHindi: "भावुक एवं समर्पित" },
    { syllable: "La", characteristic: "Idealistic and reformative", characteristicHindi: "आदर्शवादी एवं सुधारक" },
  ],
  personality:
    "Ashwini people carry the restless, healing energy of the divine twin horsemen who race ahead of the dawn. You are the first to act, the first to speak, and often the first to recover from setbacks that would slow others down. There is a clean, almost athletic quality to your decision-making — you don't deliberate, you move. This makes you a natural starter of projects, friendships, and adventures, but you can lose interest the moment the novelty fades. Your face usually shows what you feel within seconds, and you wear honesty as armor. People sense that you genuinely want to help, especially when someone is in physical or emotional pain — Ashwini's deepest pull is toward healing. You may be drawn to medicine, sports, emergency response, or any field where speed and care intersect. The shadow of this nakshatra is impatience: you may bolt from situations that ask for slow, sustained attention, and you can be blunt to the point of bruising. When you learn to pair your speed with follow-through and your honesty with tact, you become one of the rarest kinds of people — someone who actually arrives when others are still talking about leaving. Independence is sacred to you; freedom of movement is non-negotiable.",
  personalityHindi:
    "अश्विनी जातक दिव्य अश्विनी कुमारों की चंचल, उपचारक ऊर्जा वहन करते हैं जो भोर से पहले दौड़ पड़ते हैं। आप सबसे पहले कार्य आरंभ करते हैं, सबसे पहले बोलते हैं, और प्रायः उन प्रहारों से भी सबसे पहले उबर जाते हैं जो दूसरों को रोक देते हैं। आपके निर्णयों में एक स्वच्छ, लगभग खिलाड़ी-जैसी गुणवत्ता होती है — आप विचारते नहीं, आप चलते हैं। इसी कारण आप परियोजनाओं, मित्रताओं और साहसिक कार्यों के स्वाभाविक प्रवर्तक बनते हैं, परंतु नवीनता समाप्त होते ही रुचि खो सकते हैं। लोग समझते हैं कि आप सच्चे मन से सहायता करना चाहते हैं, विशेषकर जब कोई पीड़ा में हो — अश्विनी की गहरी प्रवृत्ति उपचार की ओर है। चिकित्सा, खेल, आपातकालीन सेवा अथवा किसी भी ऐसे क्षेत्र की ओर आप आकर्षित हो सकते हैं जहाँ गति और करुणा मिलती है। इस नक्षत्र की छाया अधीरता है: आप उन स्थितियों से भाग सकते हैं जो धैर्य माँगती हैं, और कभी-कभी इतने स्पष्टवक्ता हो जाते हैं कि चोट पहुँचा देते हैं। जब आप अपनी गति को निरंतरता से और अपनी ईमानदारी को विवेक से जोड़ देते हैं, तब आप उस दुर्लभ प्रकार के व्यक्ति बनते हैं — जो वस्तुतः पहुँच जाते हैं जब अन्य अब भी जाने की बात कर रहे होते हैं। स्वतंत्रता आपके लिए पवित्र है।",
  career: ["Medicine and surgery", "Sports and athletics", "Emergency services", "Entrepreneurship", "Veterinary practice"],
  careerHindi: ["चिकित्सा और शल्यकर्म", "खेल एवं व्यायाम", "आपातकालीन सेवा", "उद्यमिता", "पशु-चिकित्सा"],
  strengths: ["Quick action", "Healing instinct", "Honesty", "Pioneering spirit", "Resilience"],
  strengthsHindi: ["त्वरित निर्णय", "उपचार क्षमता", "स्पष्टवादिता", "अग्रगामी प्रवृत्ति", "लचीलापन"],
};

const BHARANI: NakshatraStaticData = {
  id: 2,
  name: "Bharani",
  nameHindi: "भरणी",
  symbol: "Yoni (vulva)",
  symbolIcon: "⚱️",
  meaning: "She who bears; the bearer",
  meaningHindi: "जो धारण करती है",
  lord: "Venus",
  lordHindi: "शुक्र",
  deity: "Yama (lord of death and dharma)",
  deityHindi: "यम",
  gana: "Manushya",
  ganaHindi: "मनुष्य",
  yoni: "Elephant (Male)",
  yoniHindi: "गज (नर)",
  nadi: "Madhya",
  nadiHindi: "मध्य",
  varna: "Mleccha",
  varnaHindi: "म्लेच्छ",
  tatva: "Earth",
  tatvaHindi: "पृथ्वी",
  direction: "West",
  directionHindi: "पश्चिम",
  color: "Blood Red",
  colorHex: "#A52A2A",
  bodyPart: "Soles of feet",
  bodyPartHindi: "पैर के तलवे",
  animal: "Elephant",
  bird: "Crow",
  tree: "Indian Gooseberry (Amla)",
  mantra: "ॐ यमाय नमः",
  mantraTransliteration: "Om Yamaya Namah",
  padas: [
    { syllable: "Li", characteristic: "Ambitious and pleasure-seeking", characteristicHindi: "महत्त्वाकांक्षी एवं भोगप्रिय" },
    { syllable: "Lu", characteristic: "Hard-working and disciplined", characteristicHindi: "परिश्रमी एवं अनुशासित" },
    { syllable: "Le", characteristic: "Charitable and generous", characteristicHindi: "उदार एवं दानशील" },
    { syllable: "Lo", characteristic: "Restrained and dharmic", characteristicHindi: "संयमी एवं धार्मिक" },
  ],
  personality:
    "Bharani is the womb of transformation, ruled by Venus and presided over by Yama, the lord of death — a paradox that defines you. You carry both creative fire and the discipline of endings. People feel a magnetic pull toward you because you radiate vitality, but those who get close discover a deeply moral spine underneath the warmth. You are unusually sensitive to questions of fairness, debt, and consequence; you don't forget who behaved well and who didn't, and you take pride in keeping your own ledger clean. Pleasure attracts you — beauty, taste, music, intimacy — and you rarely apologize for enjoying life fully. Yet Bharani also makes you a born custodian: of children, of wounded friends, of unfinished projects others abandoned. You can carry burdens that would crush most people because you understand instinctively that bearing weight is the price of meaning. The shadow side appears when desire outpaces discipline; jealousy, possessiveness, and power struggles can consume you. When you channel Yama's clarity into your Venusian appetites, you become someone who knows exactly when to indulge and when to renounce. That balance — earthy enjoyment paired with moral seriousness — is your signature, and it is what makes you trustworthy with both pleasure and pain.",
  personalityHindi:
    "भरणी परिवर्तन का गर्भ है, शुक्र द्वारा शासित और मृत्यु तथा धर्म के अधिपति यम द्वारा अधिष्ठित — यही विरोधाभास आपको परिभाषित करता है। आप में सृजन की अग्नि भी है और अंत का अनुशासन भी। लोग आपकी ओर चुम्बक की भाँति खिंचे चले आते हैं, क्योंकि आप जीवंतता बिखेरते हैं; परंतु जो निकट आते हैं वे भीतर एक दृढ़ नैतिक आधार पाते हैं। न्याय, ऋण और परिणाम के प्रश्नों के प्रति आप असाधारण रूप से संवेदनशील हैं। सुख-सौंदर्य, स्वाद, संगीत और स्नेह आपको आकर्षित करते हैं और आप जीवन का पूर्ण आनंद लेने में संकोच नहीं करते। फिर भी भरणी आपको जन्म से ही पालक बनाती है — बच्चों का, घायल मित्रों का, अधूरे कार्यों का जिन्हें औरों ने त्याग दिया। आप वह भार उठा सकते हैं जो अधिकांश को कुचल दे, क्योंकि आप समझते हैं कि भार वहन करना ही अर्थ का मूल्य है। छाया तब प्रकट होती है जब इच्छा अनुशासन से आगे निकल जाए — ईर्ष्या, अधिकार-भाव और सत्ता-संघर्ष आपको ग्रस सकते हैं। जब आप यम की स्पष्टता को शुक्र की रुचियों में पिरो देते हैं, तब आप वह व्यक्ति बनते हैं जो जानता है कि कब भोगना है और कब त्यागना। यही संतुलन आपकी पहचान है।",
  career: ["Arts and entertainment", "Hospitality and luxury", "Childcare and obstetrics", "Law and justice", "Hospice and end-of-life care"],
  careerHindi: ["कला एवं मनोरंजन", "आतिथ्य एवं विलासिता", "शिशु-देखभाल एवं प्रसूति", "विधि एवं न्याय", "अंतिम-काल सेवा"],
  strengths: ["Strong willpower", "Creative fertility", "Moral integrity", "Endurance", "Magnetic charm"],
  strengthsHindi: ["दृढ़ इच्छाशक्ति", "रचनात्मक उर्वरता", "नैतिक निष्ठा", "सहनशीलता", "चुम्बकीय आकर्षण"],
};

const KRITTIKA: NakshatraStaticData = {
  id: 3,
  name: "Krittika",
  nameHindi: "कृत्तिका",
  symbol: "Razor / flame",
  symbolIcon: "🔥",
  meaning: "The cutter; the one who burns away impurity",
  meaningHindi: "कर्तन करनेवाली; अशुद्धि का दहन",
  lord: "Sun",
  lordHindi: "सूर्य",
  deity: "Agni (fire god)",
  deityHindi: "अग्नि",
  gana: "Rakshasa",
  ganaHindi: "राक्षस",
  yoni: "Sheep (Female)",
  yoniHindi: "मेष (मादा)",
  nadi: "Madhya",
  nadiHindi: "मध्य",
  varna: "Brahmin",
  varnaHindi: "ब्राह्मण",
  tatva: "Earth",
  tatvaHindi: "पृथ्वी",
  direction: "North",
  directionHindi: "उत्तर",
  color: "White",
  colorHex: "#F5F5F5",
  bodyPart: "Head and eyebrows",
  bodyPartHindi: "सिर एवं भौंहें",
  animal: "Sheep",
  bird: "Peacock",
  tree: "Fig (Udumbara)",
  mantra: "ॐ अग्नये नमः",
  mantraTransliteration: "Om Agnaye Namah",
  padas: [
    { syllable: "A", characteristic: "Sharp and ambitious", characteristicHindi: "तीक्ष्ण एवं महत्त्वाकांक्षी" },
    { syllable: "Ee", characteristic: "Materially driven", characteristicHindi: "भौतिक उन्मुख" },
    { syllable: "U", characteristic: "Communicative and intellectual", characteristicHindi: "बौद्धिक एवं वाचाल" },
    { syllable: "Ay", characteristic: "Compassionate and dutiful", characteristicHindi: "दयालु एवं कर्तव्यनिष्ठ" },
  ],
  personality:
    "Krittika gives you the sharpness of Agni's flame — clean, purifying, and impossible to ignore. You see through pretense quickly and have little tolerance for falsehood, in others or yourself. This blade-like discernment is your greatest gift, but it can wound those who aren't ready for honesty served at full temperature. Ruled by the Sun and connected to fire, you carry natural authority; people look to you to make the call, set the standard, or end an ambiguity that has dragged on too long. You take your responsibilities seriously and feel deeply uncomfortable when others shirk theirs. There is a strong protective streak in you — Krittika is the constellation of warriors and mothers — and you will burn down what threatens those you love. Your tastes lean toward refinement: clean lines, well-made things, food prepared with care. The shadow appears as criticism, perfectionism, and a quick temper that scorches people who only needed correction, not combustion. When you learn that discernment paired with patience is more powerful than discernment alone, your influence multiplies. You are meant to refine the world around you, not just judge it. The fire that purifies the gold is also the fire that warms the household.",
  personalityHindi:
    "कृत्तिका आपको अग्नि की लौ-सी तीक्ष्णता देती है — स्वच्छ, शुद्ध करने वाली और जिसे अनदेखा करना असंभव हो। आप दिखावे को शीघ्र भेद देते हैं और झूठ — चाहे अपना हो या औरों का — आपको असहनीय है। यह कुशाग्र विवेक आपका सबसे बड़ा वरदान है, परंतु पूरी तीव्रता में परोसी गई यह सच्चाई कभी-कभी आहत भी करती है। सूर्य के स्वामित्व और अग्नि से जुड़ी होने के कारण आप में स्वाभाविक अधिकार है; लोग निर्णय लेने, मानक स्थापित करने अथवा लंबे समय से चली आ रही अस्पष्टता को समाप्त करने के लिए आपकी ओर देखते हैं। आप अपने उत्तरदायित्व को गंभीरता से लेते हैं और दूसरों के टालमटोल पर असहज हो जाते हैं। आपमें प्रबल रक्षक-वृत्ति है — कृत्तिका योद्धाओं और माताओं का नक्षत्र है — और जो आपके प्रियजनों के लिए संकट हो, उसे आप जलाकर नष्ट कर देंगे। आपकी रुचियाँ परिष्कृत हैं: स्वच्छ रेखाएँ, श्रम से बनी वस्तुएँ, स्नेह से तैयार भोजन। छाया आलोचना, पूर्णतावाद और शीघ्र क्रोध के रूप में प्रकट होती है। जब आप विवेक के साथ धैर्य भी जोड़ते हैं, आपका प्रभाव कई गुना बढ़ जाता है। जो अग्नि स्वर्ण को शुद्ध करती है, वही अग्नि घर को उष्णता भी देती है।",
  career: ["Military and defense", "Surgery and dentistry", "Teaching and academia", "Culinary arts", "Metallurgy and engineering"],
  careerHindi: ["सेना एवं रक्षा", "शल्यकर्म एवं दंतचिकित्सा", "शिक्षण एवं विद्या", "पाककला", "धातुकर्म एवं अभियांत्रिकी"],
  strengths: ["Clarity of thought", "Natural leadership", "Discipline", "Protective courage", "Refined taste"],
  strengthsHindi: ["विचारों की स्पष्टता", "नेतृत्व क्षमता", "अनुशासन", "रक्षक-साहस", "परिष्कृत रुचि"],
};

const ROHINI: NakshatraStaticData = {
  id: 4,
  name: "Rohini",
  nameHindi: "रोहिणी",
  symbol: "Ox-cart / banyan tree",
  symbolIcon: "🌳",
  meaning: "The reddish one; the rising star",
  meaningHindi: "लालिमायुक्त; उदीयमान तारा",
  lord: "Moon",
  lordHindi: "चंद्र",
  deity: "Brahma / Prajapati (creator)",
  deityHindi: "ब्रह्मा / प्रजापति",
  gana: "Manushya",
  ganaHindi: "मनुष्य",
  yoni: "Serpent (Male)",
  yoniHindi: "सर्प (नर)",
  nadi: "Antya",
  nadiHindi: "अंत्य",
  varna: "Shudra",
  varnaHindi: "शूद्र",
  tatva: "Earth",
  tatvaHindi: "पृथ्वी",
  direction: "East",
  directionHindi: "पूर्व",
  color: "White",
  colorHex: "#FFFAF0",
  bodyPart: "Forehead and shins",
  bodyPartHindi: "मस्तक एवं पिंडली",
  animal: "Serpent",
  bird: "Owl",
  tree: "Jamun (Indian Blackberry)",
  mantra: "ॐ ब्रह्मणे नमः",
  mantraTransliteration: "Om Brahmane Namah",
  padas: [
    { syllable: "O", characteristic: "Status-oriented and proud", characteristicHindi: "प्रतिष्ठा-केंद्रित" },
    { syllable: "Va", characteristic: "Hardworking and earthy", characteristicHindi: "परिश्रमी एवं भौतिक" },
    { syllable: "Vi", characteristic: "Communicative and clever", characteristicHindi: "वाचाल एवं चतुर" },
    { syllable: "Vu", characteristic: "Spiritual and idealistic", characteristicHindi: "आध्यात्मिक एवं आदर्शवादी" },
  ],
  personality:
    "Rohini is the most fertile nakshatra in the zodiac, presided over by Brahma the creator and ruled by the gentle Moon. You carry an unmistakable physical magnetism — people find your presence soothing, your voice pleasant, your sense of beauty refined. You belong to the world of growing things: gardens, families, recipes that take hours, businesses built slowly over decades. You don't chase results; you cultivate them. There is patience in you that other nakshatras lack, and a deep, almost stubborn loyalty toward whatever you have decided to grow. Sensual pleasure matters to you in a healthy way — good food, soft fabrics, music, the company of those you love. Yet under the warmth lives an ox-cart's quiet determination. Once you commit to a path, very little can move you off it, and your judgments about people, while slow to form, are slow to revise. The shadow of Rohini is materialism, possessiveness, and a tendency to envy what others have grown. You can also become so attached to comfort that you avoid necessary change. When you remember that even Brahma must release what he creates, your life softens into one of generous abundance — you become a source from which others draw, rather than a vault that fears withdrawal.",
  personalityHindi:
    "रोहिणी राशिचक्र का सर्वाधिक उर्वर नक्षत्र है, जिसके अधिष्ठाता सृष्टिकर्ता ब्रह्मा हैं और स्वामी कोमल चंद्र। आप में एक स्पष्ट शारीरिक चुम्बकत्व है — लोगों को आपकी उपस्थिति शांतिदायक, आपका स्वर मधुर, आपकी सौंदर्य-दृष्टि परिष्कृत लगती है। आप उगते हुए जीवन के संसार के हैं: उपवन, परिवार, घंटों में पकने वाले व्यंजन, दशकों में बनते व्यवसाय। आप परिणाम का पीछा नहीं करते — आप उन्हें पोषित करते हैं। आपमें वह धैर्य है जो अन्य नक्षत्रों में दुर्लभ है, और जो आपने पोषित करना ठान लिया, उसके प्रति गहरी, लगभग जिद्दी निष्ठा। ऐंद्रिक सुख आपके लिए स्वस्थ अर्थ रखता है — अच्छा भोजन, मृदु वस्त्र, संगीत, प्रियजनों का साथ। फिर भी इस उष्णता के नीचे बैलगाड़ी-सी मौन दृढ़ता बसती है। एक बार आप किसी मार्ग पर चल पड़ें, तो आपको हटाना कठिन है। रोहिणी की छाया है — भौतिकता, अधिकार-भाव और दूसरों की उपलब्धियों से ईर्ष्या। आप सुख से इतने जुड़ सकते हैं कि आवश्यक परिवर्तन से बचें। जब आप स्मरण रखें कि ब्रह्मा को भी अपनी सृष्टि का त्याग करना पड़ता है, तो आपका जीवन उदार समृद्धि में बदल जाता है — आप वह स्रोत बन जाते हैं जिससे औरों को मिलता है।",
  career: ["Agriculture and horticulture", "Fashion and textiles", "Hospitality and food", "Banking and finance", "Music and performing arts"],
  careerHindi: ["कृषि एवं उद्यान", "वस्त्र एवं फैशन", "आतिथ्य एवं भोजन", "बैंकिंग एवं वित्त", "संगीत एवं प्रदर्शन-कला"],
  strengths: ["Patience", "Sensual refinement", "Loyalty", "Creative fertility", "Steady growth"],
  strengthsHindi: ["धैर्य", "ऐंद्रिक परिष्कार", "निष्ठा", "रचनात्मक उर्वरता", "स्थिर प्रगति"],
};

const MRIGASHIRA: NakshatraStaticData = {
  id: 5,
  name: "Mrigashira",
  nameHindi: "मृगशिरा",
  symbol: "Deer's head",
  symbolIcon: "🦌",
  meaning: "Deer-headed; the searching one",
  meaningHindi: "मृगमुख; अन्वेषक",
  lord: "Mars",
  lordHindi: "मंगल",
  deity: "Soma (moon god / nectar)",
  deityHindi: "सोम",
  gana: "Deva",
  ganaHindi: "देव",
  yoni: "Serpent (Female)",
  yoniHindi: "सर्प (मादा)",
  nadi: "Madhya",
  nadiHindi: "मध्य",
  varna: "Farmer",
  varnaHindi: "कृषक",
  tatva: "Earth",
  tatvaHindi: "पृथ्वी",
  direction: "South",
  directionHindi: "दक्षिण",
  color: "Silver Grey",
  colorHex: "#C0C0C0",
  bodyPart: "Eyes",
  bodyPartHindi: "आँखें",
  animal: "Serpent",
  bird: "Curlew",
  tree: "Khair (Acacia Catechu)",
  mantra: "ॐ सोमाय नमः",
  mantraTransliteration: "Om Somaya Namah",
  padas: [
    { syllable: "Ve", characteristic: "Searching and active", characteristicHindi: "खोजी एवं सक्रिय" },
    { syllable: "Vo", characteristic: "Practical and grounded", characteristicHindi: "व्यावहारिक एवं स्थिर" },
    { syllable: "Ka", characteristic: "Communicative and witty", characteristicHindi: "वाचाल एवं विनोदी" },
    { syllable: "Ki", characteristic: "Emotional and sensitive", characteristicHindi: "भावुक एवं संवेदनशील" },
  ],
  personality:
    "Mrigashira gives you the wandering eye and gentle curiosity of a deer in a forest at dawn. You are looking for something — a perfect idea, a perfect place, a perfect partner — and your life often takes the shape of that search. You read widely, travel often, change subjects mid-conversation, and rarely settle for the first answer offered. People love your light touch and your willingness to consider any viewpoint, but they sometimes wonder whether you will ever commit to anything fully. Ruled by Mars but presided over by Soma, the moon's nectar, you balance restlessness with sweetness. You are seldom aggressive; instead you persuade through charm, intelligence, and a kind of melodic articulation that makes complex ideas easy to follow. There is a romantic streak in you — you fall in love with possibilities, with cities, with songs, sometimes more than with the actual humans in front of you. The shadow side is suspicion, fickleness, and a tendency to talk yourself out of things you actually want. You can also exhaust yourself by chasing the next thing before fully tasting the present one. When you learn that the deer's gift is not in finding the perfect grove but in moving gracefully through many of them, your life becomes a beautiful, exploratory poem rather than an anxious quest.",
  personalityHindi:
    "मृगशिरा आपको प्रातःकालीन वन में विचरते मृग की भाँति विचरणशील दृष्टि और कोमल जिज्ञासा देती है। आप किसी पूर्ण विचार, पूर्ण स्थान, पूर्ण साथी की तलाश में हैं — और आपका जीवन प्रायः उसी खोज का रूप ले लेता है। आप विस्तार से पढ़ते हैं, बहुत यात्रा करते हैं, बातचीत के बीच विषय बदल देते हैं, और पहली प्रस्तुत उत्तर पर सहमत नहीं होते। लोग आपकी हल्की उपस्थिति और किसी भी मत पर विचार करने की तत्परता को पसंद करते हैं, परंतु कभी-कभी सोचते हैं कि क्या आप किसी एक चीज़ के प्रति पूर्णतः प्रतिबद्ध भी होंगे। मंगल द्वारा शासित परंतु चंद्र-अमृत सोम के अधिष्ठान में, आप चंचलता को मृदुलता से संतुलित करते हैं। आप शायद ही आक्रामक हों; आप आकर्षण, बुद्धिमत्ता और संगीतमय अभिव्यक्ति से मनाते हैं। आप में रोमांटिक प्रवृत्ति है — आप संभावनाओं, नगरों, गीतों से प्रेम करते हैं, कभी-कभी सम्मुख व्यक्तियों से भी अधिक। छाया है शंका, चंचलता और स्वयं को उन वस्तुओं से वंचित कर देना जिन्हें आप वस्तुतः चाहते हैं। जब आप समझते हैं कि मृग का वरदान उत्तम वन ढूँढ़ने में नहीं, अपितु अनेक वनों में ससम्मान विचरने में है, तब जीवन एक सुंदर अन्वेषणात्मक काव्य बन जाता है।",
  career: ["Research and academia", "Travel and exploration", "Writing and journalism", "Teaching", "Acting and music"],
  careerHindi: ["अनुसंधान एवं विद्या", "यात्रा एवं अन्वेषण", "लेखन एवं पत्रकारिता", "शिक्षण", "अभिनय एवं संगीत"],
  strengths: ["Curiosity", "Adaptability", "Charm", "Intellectual range", "Gentle persuasion"],
  strengthsHindi: ["जिज्ञासा", "अनुकूलनशीलता", "आकर्षण", "बौद्धिक विस्तार", "मृदु अनुनय"],
};

const ARDRA: NakshatraStaticData = {
  id: 6,
  name: "Ardra",
  nameHindi: "आर्द्रा",
  symbol: "Teardrop / diamond",
  symbolIcon: "💧",
  meaning: "The moist one; the green one",
  meaningHindi: "आर्द्र; हरित",
  lord: "Rahu",
  lordHindi: "राहु",
  deity: "Rudra (storm form of Shiva)",
  deityHindi: "रुद्र",
  gana: "Manushya",
  ganaHindi: "मनुष्य",
  yoni: "Dog (Female)",
  yoniHindi: "श्वान (मादा)",
  nadi: "Adi",
  nadiHindi: "आदि",
  varna: "Butcher",
  varnaHindi: "बधिक",
  tatva: "Water",
  tatvaHindi: "जल",
  direction: "West",
  directionHindi: "पश्चिम",
  color: "Green",
  colorHex: "#228B22",
  bodyPart: "Hair",
  bodyPartHindi: "केश",
  animal: "Dog",
  bird: "Andhril",
  tree: "Krishna Kamal",
  mantra: "ॐ रुद्राय नमः",
  mantraTransliteration: "Om Rudraya Namah",
  padas: [
    { syllable: "Ku", characteristic: "Mentally restless", characteristicHindi: "मानसिक रूप से चंचल" },
    { syllable: "Gha", characteristic: "Practical and ambitious", characteristicHindi: "व्यावहारिक एवं महत्त्वाकांक्षी" },
    { syllable: "Ng", characteristic: "Intellectually intense", characteristicHindi: "बौद्धिक रूप से तीव्र" },
    { syllable: "Cha", characteristic: "Compassionate after struggle", characteristicHindi: "संघर्ष के बाद करुणामय" },
  ],
  personality:
    "Ardra is the storm cloud and the cleansing tear, ruled by Rahu and presided over by Rudra — the wild, weeping form of Shiva who dances through destruction toward renewal. You feel things at a depth that startles people, including yourself. Joy, grief, anger, devotion arrive in you as full weather systems, not passing moods. This emotional intensity makes you unusually perceptive about suffering, both your own and others'; you see the cracks in things before anyone else does. You may be drawn to fields that involve breakdown and repair — psychology, surgery, social reform, technology that disrupts old systems. There is a brilliant, sometimes electrical mind in you that connects ideas no one else thought to put together. The shadow appears as overthinking, paranoia, sudden destructive moods, and a tendency to push away the very people you most need. Ardra natives often go through one or two life-shattering passages — the storm comes, and what was false in you is washed away. Those who survive these initiations become some of the most compassionate, transformative people on earth, because they know firsthand that grief can be a doorway. Your task is not to avoid the storm but to learn to dance in it as Rudra does, finding strange joy in the wildness rather than only its loss.",
  personalityHindi:
    "आर्द्रा झंझा-मेघ है और शुद्ध करनेवाला अश्रु, राहु द्वारा शासित और रुद्र — शिव के क्रंदनशील, जंगली रूप — के अधिष्ठान में, जो विनाश से नवीनीकरण की ओर नृत्य करते हैं। आप जिस गहराई में अनुभव करते हैं, वह स्वयं आपको भी चकित करती है। हर्ष, शोक, क्रोध, भक्ति आपमें पूर्ण ऋतु-तंत्र की भाँति आते हैं, क्षणिक मनःस्थिति की तरह नहीं। यह भावनात्मक तीव्रता आपको पीड़ा के प्रति असाधारण रूप से सजग बनाती है — अपनी और दूसरों की भी। आप अन्य से पहले दरारों को देख लेते हैं। आप उन क्षेत्रों की ओर खिंच सकते हैं जो टूटन और मरम्मत से जुड़े हैं — मनोविज्ञान, शल्यकर्म, सामाजिक सुधार, विघटनकारी प्रौद्योगिकी। आपमें एक उज्ज्वल, कभी-कभी विद्युत-सी बुद्धि है। छाया है — अति-चिंतन, संदेह, अकस्मात् विनाशक मनोवृत्ति, और जिनकी आपको सबसे अधिक आवश्यकता है उन्हें ठेल देना। आर्द्रा-जातक प्रायः जीवन में एक-दो ध्वंसक अनुभव से गुजरते हैं; तूफ़ान आता है और जो असत्य है वह बह जाता है। जो उत्तीर्ण होते हैं वे पृथ्वी के सर्वाधिक करुणामय व्यक्तियों में बन जाते हैं। आपका कर्तव्य तूफ़ान से बचना नहीं, अपितु रुद्र की भाँति उसमें नृत्य सीखना है।",
  career: ["Psychology and counseling", "Research and innovation", "Surgery", "Social activism", "Technology and engineering"],
  careerHindi: ["मनोविज्ञान एवं परामर्श", "अनुसंधान एवं नवाचार", "शल्यकर्म", "सामाजिक सक्रियता", "प्रौद्योगिकी एवं अभियांत्रिकी"],
  strengths: ["Deep perception", "Transformative courage", "Original thinking", "Empathy from experience", "Mental brilliance"],
  strengthsHindi: ["गहरी अंतर्दृष्टि", "परिवर्तनकारी साहस", "मौलिक चिंतन", "अनुभव-जनित सहानुभूति", "मानसिक प्रतिभा"],
};

const PUNARVASU: NakshatraStaticData = {
  id: 7,
  name: "Punarvasu",
  nameHindi: "पुनर्वसु",
  symbol: "Quiver of arrows / house",
  symbolIcon: "🏹",
  meaning: "Return of the light; renewal",
  meaningHindi: "प्रकाश की वापसी; नवीनीकरण",
  lord: "Jupiter",
  lordHindi: "बृहस्पति",
  deity: "Aditi (mother of the gods)",
  deityHindi: "अदिति",
  gana: "Deva",
  ganaHindi: "देव",
  yoni: "Cat (Female)",
  yoniHindi: "मार्जार (मादा)",
  nadi: "Adi",
  nadiHindi: "आदि",
  varna: "Vaishya",
  varnaHindi: "वैश्य",
  tatva: "Water",
  tatvaHindi: "जल",
  direction: "North",
  directionHindi: "उत्तर",
  color: "Lead Grey",
  colorHex: "#778899",
  bodyPart: "Fingers and nose",
  bodyPartHindi: "अँगुलियाँ एवं नासिका",
  animal: "Cat",
  bird: "Goose",
  tree: "Bamboo",
  mantra: "ॐ अदित्यै नमः",
  mantraTransliteration: "Om Adityai Namah",
  padas: [
    { syllable: "Ke", characteristic: "Spiritual and idealistic", characteristicHindi: "आध्यात्मिक एवं आदर्शवादी" },
    { syllable: "Ko", characteristic: "Practical and grounded", characteristicHindi: "व्यावहारिक एवं स्थिर" },
    { syllable: "Ha", characteristic: "Communicative and intelligent", characteristicHindi: "वाचाल एवं बुद्धिमान" },
    { syllable: "Hi", characteristic: "Compassionate and nurturing", characteristicHindi: "करुणामय एवं पालक" },
  ],
  personality:
    "Punarvasu means 'the return of the light,' and that is the theme of your life — you fall, you lose, you wander, and you come back wiser. Ruled by Jupiter and presided over by Aditi, the boundless mother, you carry an unusual capacity for renewal that makes other people trust you with second chances. You are typically warm, philosophical, generous with your time, and you instinctively believe that things will work out — and surprisingly often, they do, partly because your optimism is contagious. There is a teacher in you, even if you never stand in a classroom; people leave conversations with you feeling lifted. Travel, scripture, and family all hold deep meaning, and you may move repeatedly between cities, ideas, or relationships before finding the home that finally fits. The shadow side is restlessness, indecision, and a tendency to forgive the same people for the same offenses one too many times. You can also disperse your considerable gifts across too many projects. When you learn that returning to the light requires choosing where to plant your feet, your wisdom stops being abstract and becomes a refuge that others actually inhabit. Your gift is not avoiding loss; your gift is showing the world that loss is not the final word.",
  personalityHindi:
    "पुनर्वसु का अर्थ है 'प्रकाश की वापसी,' और यही आपके जीवन का स्वर है — आप गिरते हैं, खोते हैं, भटकते हैं, और अधिक बुद्धिमान बनकर लौटते हैं। बृहस्पति द्वारा शासित और असीम माता अदिति के अधिष्ठान में, आप में नवीनीकरण की असाधारण क्षमता है। आप प्रायः उष्ण, दार्शनिक, समय में उदार होते हैं और सहज रूप से मानते हैं कि सब ठीक हो जाएगा — और आश्चर्यजनक रूप से प्रायः ऐसा होता भी है। आप में एक शिक्षक है, चाहे आप कक्षा में न खड़े हों; लोग आपसे बात करने के बाद हल्का अनुभव करते हैं। यात्रा, शास्त्र और परिवार में आपके लिए गहरा अर्थ है, और स्थायी निवास पाने से पहले आप कई नगरों, विचारों या संबंधों के बीच विचरण कर सकते हैं। छाया है — चंचलता, अनिर्णय, और एक ही व्यक्ति को बार-बार क्षमा करना। आप अपनी प्रतिभाएँ बहुत-सी परियोजनाओं में बिखरा सकते हैं। जब आप समझते हैं कि प्रकाश की वापसी के लिए चरण रखना भी आवश्यक है, तब आपका विवेक अमूर्त नहीं रहता — वह दूसरों के लिए सच्चा आश्रय बन जाता है। आपकी देन हानि टालना नहीं, अपितु यह दिखाना है कि हानि अंतिम शब्द नहीं।",
  career: ["Teaching and philosophy", "Counseling and coaching", "Travel and tourism", "Publishing and writing", "Spiritual guidance"],
  careerHindi: ["शिक्षण एवं दर्शन", "परामर्श एवं प्रशिक्षण", "यात्रा एवं पर्यटन", "प्रकाशन एवं लेखन", "आध्यात्मिक मार्गदर्शन"],
  strengths: ["Resilience", "Optimism", "Wisdom from experience", "Generosity", "Capacity to begin again"],
  strengthsHindi: ["लचीलापन", "आशावाद", "अनुभव-जनित विवेक", "उदारता", "पुनरारंभ की क्षमता"],
};

const PUSHYA: NakshatraStaticData = {
  id: 8,
  name: "Pushya",
  nameHindi: "पुष्य",
  symbol: "Cow's udder / lotus / arrow",
  symbolIcon: "🪷",
  meaning: "The nourisher; the most auspicious",
  meaningHindi: "पोषक; सर्वाधिक शुभ",
  lord: "Saturn",
  lordHindi: "शनि",
  deity: "Brihaspati (guru of the gods)",
  deityHindi: "बृहस्पति",
  gana: "Deva",
  ganaHindi: "देव",
  yoni: "Sheep (Male)",
  yoniHindi: "मेष (नर)",
  nadi: "Madhya",
  nadiHindi: "मध्य",
  varna: "Kshatriya",
  varnaHindi: "क्षत्रिय",
  tatva: "Water",
  tatvaHindi: "जल",
  direction: "East",
  directionHindi: "पूर्व",
  color: "Blackish Red",
  colorHex: "#5C2E2E",
  bodyPart: "Mouth and face",
  bodyPartHindi: "मुख एवं चेहरा",
  animal: "Sheep",
  bird: "Crow Pheasant",
  tree: "Sacred Fig (Peepal)",
  mantra: "ॐ बृहस्पतये नमः",
  mantraTransliteration: "Om Brihaspataye Namah",
  padas: [
    { syllable: "Hu", characteristic: "Spiritual seeker", characteristicHindi: "आध्यात्मिक साधक" },
    { syllable: "He", characteristic: "Materially supportive", characteristicHindi: "भौतिक रूप से सहायक" },
    { syllable: "Ho", characteristic: "Communicative and ethical", characteristicHindi: "वाचाल एवं नैतिक" },
    { syllable: "Da", characteristic: "Compassionate and devoted", characteristicHindi: "करुणामय एवं समर्पित" },
  ],
  personality:
    "Pushya is considered the most auspicious of all nakshatras — the nurturer, the protector, the warm hand on the shoulder. Ruled by Saturn and presided over by Brihaspati, the guru of the gods, you carry a rare combination of discipline and benevolence. People bring their problems to you, even when you didn't ask, because something in your presence promises that you will not abandon them mid-sentence. You are usually traditional in your values, careful with your reputation, and unwilling to take shortcuts that compromise your integrity. There is a quiet, almost priestly authority in you; even when you are not the loudest in the room, you are often the most listened to. Family and ancestors matter; you may feel a strong duty toward parents, teachers, and the lineage you came from. The shadow side is over-caution, self-righteousness, and a tendency to give so much that you secretly resent the receivers. You may also become so attached to being the responsible one that you forget to ask for nourishment yourself. When you let others tend to you in return — when you allow Pushya's milk to flow toward you, not only outward — your generosity becomes sustainable rather than depleting. Your role on earth is to feed something larger than yourself: a family, a craft, a tradition, a community.",
  personalityHindi:
    "पुष्य सभी नक्षत्रों में सर्वाधिक शुभ माना जाता है — पोषक, रक्षक, कंधे पर रखा वह उष्ण हाथ। शनि द्वारा शासित और देव-गुरु बृहस्पति के अधिष्ठान में, आपमें अनुशासन और कल्याण का दुर्लभ संयोग है। लोग बिना पूछे आपके पास अपनी समस्याएँ ले आते हैं, क्योंकि आपकी उपस्थिति में यह आश्वासन रहता है कि आप उन्हें बीच में अकेला नहीं छोड़ेंगे। आप प्रायः मूल्यों में पारंपरिक, प्रतिष्ठा के प्रति सजग और सत्यनिष्ठा से समझौते के विरुद्ध रहते हैं। आपमें एक मौन, लगभग पुरोहित जैसा अधिकार है। कुल और पूर्वज महत्त्व रखते हैं। छाया है — अति-सतर्कता, आत्म-धार्मिकता, और इतना देना कि भीतर लेने वालों के प्रति रोष पनप जाए। आप उत्तरदायी होने के भाव से इतने जुड़ सकते हैं कि स्वयं के पोषण को भूल जाएँ। जब आप दूसरों को भी अपनी देखभाल करने देते हैं — जब पुष्य का दुग्ध आप तक भी आता है — तब आपकी उदारता टिकाऊ बनती है, क्षीणकारी नहीं। आपकी पृथ्वी पर भूमिका स्वयं से बड़े किसी को पोषित करना है: परिवार, कला, परंपरा अथवा समुदाय।",
  career: ["Teaching and mentorship", "Healthcare and nursing", "Public service", "Spiritual leadership", "Childcare and education"],
  careerHindi: ["शिक्षण एवं मार्गदर्शन", "स्वास्थ्य-सेवा एवं नर्सिंग", "लोक-सेवा", "आध्यात्मिक नेतृत्व", "शिशु-देखभाल एवं शिक्षा"],
  strengths: ["Reliability", "Nurturing instinct", "Ethical clarity", "Discipline", "Inner authority"],
  strengthsHindi: ["विश्वसनीयता", "पालन-वृत्ति", "नैतिक स्पष्टता", "अनुशासन", "आंतरिक अधिकार"],
};

const ASHLESHA: NakshatraStaticData = {
  id: 9,
  name: "Ashlesha",
  nameHindi: "आश्लेषा",
  symbol: "Coiled serpent",
  symbolIcon: "🐍",
  meaning: "The embracer; the entwiner",
  meaningHindi: "आलिंगन करने वाली; लिपटने वाली",
  lord: "Mercury",
  lordHindi: "बुध",
  deity: "Nagas (serpent deities)",
  deityHindi: "नाग देवता",
  gana: "Rakshasa",
  ganaHindi: "राक्षस",
  yoni: "Cat (Male)",
  yoniHindi: "मार्जार (नर)",
  nadi: "Antya",
  nadiHindi: "अंत्य",
  varna: "Mleccha",
  varnaHindi: "म्लेच्छ",
  tatva: "Water",
  tatvaHindi: "जल",
  direction: "South",
  directionHindi: "दक्षिण",
  color: "Blackish Red",
  colorHex: "#3B0A0A",
  bodyPart: "Joints and nails",
  bodyPartHindi: "जोड़ एवं नाखून",
  animal: "Cat",
  bird: "Magpie",
  tree: "Indian Beech (Naga Champa)",
  mantra: "ॐ नागदेवताभ्यो नमः",
  mantraTransliteration: "Om Naga Devatabhyo Namah",
  padas: [
    { syllable: "Di", characteristic: "Mentally penetrating", characteristicHindi: "बुद्धि से भेदी" },
    { syllable: "Du", characteristic: "Materially shrewd", characteristicHindi: "भौतिक रूप से चतुर" },
    { syllable: "De", characteristic: "Communicatively persuasive", characteristicHindi: "वाक्-कुशल" },
    { syllable: "Do", characteristic: "Emotionally intense", characteristicHindi: "भावनात्मक रूप से तीव्र" },
  ],
  personality:
    "Ashlesha is the coiled serpent's wisdom — patient, watchful, and deeply intuitive about hidden currents. Ruled by Mercury and presided over by the Nagas, you perceive what people are not saying as clearly as what they are. This makes you an exceptional reader of motives, a natural strategist, and often the person others underestimate just before realizing how thoroughly you understood the situation. You think in layers; few decisions are simple for you, because you can usually see four or five consequences others missed. There is a hypnotic, magnetic quality to your presence when you choose to deploy it, and your influence often works through subtle means rather than direct confrontation. The shadow of Ashlesha is well-known in classical texts — manipulation, possessiveness, secrecy, and a venomous tongue when wounded. You may struggle with trust because your perception of others' shadows is so accurate that you forget to look for their light. Healing, traditional medicine, deep psychology, and esoteric studies suit you, because you are unafraid of what most people refuse to look at. When you direct the serpent's wisdom toward truth rather than control, you become a kind of guardian of hidden knowledge — someone who sees clearly, speaks carefully, and uses their perception to protect rather than to entangle.",
  personalityHindi:
    "आश्लेषा कुंडलित सर्प की बुद्धि है — धैर्यवान, सजग, और छिपी धाराओं के प्रति गहरी अंतर्दृष्टि से युक्त। बुध द्वारा शासित और नाग देवताओं के अधिष्ठान में, आप उतना ही समझते हैं जितना कहा जाता है, और उतना ही जितना नहीं कहा जाता। इससे आप मनोभावों के असाधारण पाठक, स्वाभाविक रणनीतिकार और प्रायः वह व्यक्ति बनते हैं जिसे लोग कम आँक लेते हैं — फिर समझते हैं कि आप पूर्ण स्थिति समझ चुके थे। आप परतों में सोचते हैं; कोई निर्णय आपके लिए सरल नहीं, क्योंकि आप चार-पाँच परिणाम देख लेते हैं जो औरों से छूट गए। आपकी उपस्थिति में चुम्बकीय आकर्षण है। आश्लेषा की छाया शास्त्रों में सुप्रसिद्ध है — हेरफेर, अधिकार-भाव, गुप्तता और घायल होने पर विषैली वाणी। आप विश्वास से जूझ सकते हैं, क्योंकि दूसरों की छायाओं की आपकी समझ इतनी सटीक है कि आप उनके प्रकाश को देखना भूल जाते हैं। उपचार, पारंपरिक औषधि, गहरा मनोविज्ञान और गूढ़ अध्ययन आपको रुचते हैं। जब आप सर्प की बुद्धि को सत्य की ओर मोड़ देते हैं, तब आप गुप्त ज्ञान के संरक्षक बनते हैं।",
  career: ["Psychology and therapy", "Investigation and research", "Traditional medicine", "Law", "Strategy and intelligence"],
  careerHindi: ["मनोविज्ञान एवं चिकित्सा", "अन्वेषण एवं शोध", "पारंपरिक औषधि", "विधि", "रणनीति एवं गुप्तचर्या"],
  strengths: ["Deep insight", "Strategic thinking", "Persuasive intelligence", "Emotional perception", "Resilience under pressure"],
  strengthsHindi: ["गहरी अंतर्दृष्टि", "रणनीतिक चिंतन", "अनुनायी बुद्धि", "भावनात्मक प्रत्यक्षता", "दबाव में स्थिरता"],
};

// ---------------------------------------------------------------------------
// Phase B — minimal stubs (10–27). These ship with classification + mantra +
// padas, but use a short personality. The drawer treats `personality.length <
// 200` as a hint to lean on the API response when present.
// ---------------------------------------------------------------------------

const STUB_PADAS = (s: [string, string, string, string]): NakshatraStaticData["padas"] => [
  { syllable: s[0], characteristic: "Pada characteristics — coming soon", characteristicHindi: "पाद विवरण — शीघ्र आ रहा है" },
  { syllable: s[1], characteristic: "Pada characteristics — coming soon", characteristicHindi: "पाद विवरण — शीघ्र आ रहा है" },
  { syllable: s[2], characteristic: "Pada characteristics — coming soon", characteristicHindi: "पाद विवरण — शीघ्र आ रहा है" },
  { syllable: s[3], characteristic: "Pada characteristics — coming soon", characteristicHindi: "पाद विवरण — शीघ्र आ रहा है" },
];

const COMING_SOON_EN = "Detailed personality reading for this nakshatra is coming soon. Refer to the classifications above and consult an astrologer for personalised insight.";
// ---------------------------------------------------------------------------
// Phase B — full entries (10–27)
// ---------------------------------------------------------------------------

const MAGHA: NakshatraStaticData = {
  id: 10, name: "Magha", nameHindi: "मघा",
  symbol: "Royal throne", symbolIcon: "👑",
  meaning: "The mighty, the magnificent", meaningHindi: "महान, ऐश्वर्यशाली",
  lord: "Ketu", lordHindi: "केतु",
  deity: "Pitris (ancestral fathers)", deityHindi: "पितर",
  gana: "Rakshasa", ganaHindi: "राक्षस",
  yoni: "Rat (Male)", yoniHindi: "मूषक (नर)",
  nadi: "Antya", nadiHindi: "अंत्य",
  varna: "Shudra", varnaHindi: "शूद्र",
  tatva: "Water", tatvaHindi: "जल",
  direction: "West", directionHindi: "पश्चिम",
  color: "Ivory", colorHex: "#FFFFF0",
  bodyPart: "Lips and chin", bodyPartHindi: "होंठ एवं ठोड़ी",
  animal: "Rat", bird: "Falcon", tree: "Banyan",
  mantra: "ॐ पितृभ्यो नमः मघायै नमः", mantraTransliteration: "Om Pitribhyo Namah Maghayai Namah",
  padas: [
    { syllable: "Maa", characteristic: "Ambitious and ceremonial", characteristicHindi: "महत्त्वाकांक्षी एवं औपचारिक" },
    { syllable: "Mee", characteristic: "Generous and devoted", characteristicHindi: "उदार एवं समर्पित" },
    { syllable: "Moo", characteristic: "Studious and traditional", characteristicHindi: "अध्ययनशील एवं परंपरागत" },
    { syllable: "Me",  characteristic: "Service-minded and proud", characteristicHindi: "सेवाभावी एवं स्वाभिमानी" },
  ],
  personality:
    "Magha natives carry the unmistakable weight of lineage. Born under the throne of the ancestors and ruled by Ketu, you walk into rooms with a quiet authority that others register before you say a word. There is a regal seriousness to how you treat tradition, family name, and inherited duties — you sense that the people who came before you are watching, and you want to make them proud. This gives you an unusual capacity for ceremony, leadership, and protecting those weaker than yourself. You give generously to dependents, retainers, and causes you adopt as your own. Yet the rajasic Rakshasa undercurrent and the rat yoni mean you can also be sharply territorial, slow to forget a slight, and prone to pride that hardens into arrogance when unchecked. You crave recognition more than you admit, and you can withdraw into a cold, kingly silence when you feel disrespected. Your relationships do best with partners who acknowledge your stature without trying to compete with it. Career success often arrives through positions of authority, custodianship of legacy, or work tied to history and culture. Your spiritual lesson is that true royalty lies in humility — that the throne is a seat of service, not separation. When you bow your inner head, the world bows back.",
  personalityHindi:
    "मघा जातक वंश-परंपरा का अदृश्य भार गरिमा से वहन करते हैं। पितरों के सिंहासन के नीचे जन्मे और केतु से शासित, आप कक्ष में मौन अधिकार के साथ प्रवेश करते हैं जिसे दूसरे शब्दों से पूर्व अनुभव कर लेते हैं। परंपरा, कुलनाम तथा आनुवंशिक कर्तव्यों के प्रति आपका आदर राजसी एवं गंभीर होता है — आप मानते हैं कि पूर्वज देख रहे हैं और उन्हें गौरवान्वित करना आपका धर्म है। यह आपको समारोह, नेतृत्व तथा निर्बलों की रक्षा की असाधारण क्षमता देता है। आप आश्रितों एवं स्वीकृत कार्यों पर उदारता से व्यय करते हैं। परंतु राक्षस गण और मूषक योनि की धारा कभी-कभी आपको क्षेत्रीय, अपमान-स्मरणी तथा अहंकार की ओर झुका देती है। आप मान्यता की कामना करते हैं और अनादर पर शीतल मौन में डूब सकते हैं। संबंध उन्हीं साथियों से सफल होते हैं जो आपके गौरव को स्वीकार करें, उससे प्रतिस्पर्धा न करें। अधिकार-पद, सांस्कृतिक धरोहर अथवा इतिहास-संबंधी कार्यों में सफलता मिलती है। आध्यात्मिक पाठ यह है कि सच्चा राजत्व विनम्रता में बसता है — सिंहासन सेवा का आसन है, पृथक्ता का नहीं। जब अंतःकरण झुकता है तब संसार नमन करता है।",
  career: ["Government and civil leadership", "Custodian of heritage and museums", "Historian or archivist", "Cultural and ceremonial arts", "Family business stewardship"],
  careerHindi: ["शासन एवं नेतृत्व", "धरोहर-संरक्षण", "इतिहासकार", "सांस्कृतिक कला", "पारिवारिक उद्यम-संचालन"],
  strengths: ["Authority", "Loyalty to lineage", "Ceremony", "Generosity", "Dignity"],
  strengthsHindi: ["अधिकार", "कुल-निष्ठा", "शिष्टाचार", "औदार्य", "गरिमा"],
};

const PURVA_PHALGUNI: NakshatraStaticData = {
  id: 11, name: "Purva Phalguni", nameHindi: "पूर्व फाल्गुनी",
  symbol: "Front legs of a bed / hammock", symbolIcon: "🛋️",
  meaning: "The former reddish one", meaningHindi: "पूर्व लालिमायुक्त",
  lord: "Venus", lordHindi: "शुक्र",
  deity: "Bhaga (Aditya of fortune and delight)", deityHindi: "भग",
  gana: "Manushya", ganaHindi: "मनुष्य",
  yoni: "Rat (Female)", yoniHindi: "मूषक (मादा)",
  nadi: "Madhya", nadiHindi: "मध्य",
  varna: "Brahmin", varnaHindi: "ब्राह्मण",
  tatva: "Water", tatvaHindi: "जल",
  direction: "North", directionHindi: "उत्तर",
  color: "Light Brown", colorHex: "#A0522D",
  bodyPart: "Right hand", bodyPartHindi: "दाहिना हाथ",
  animal: "Rat", bird: "Female parrot", tree: "Indian Butter Tree (Palash)",
  mantra: "ॐ भगाय नमः पूर्व फाल्गुन्यै नमः", mantraTransliteration: "Om Bhagaya Namah Purva Phalgunyai Namah",
  padas: [
    { syllable: "Mo", characteristic: "Loving and creative", characteristicHindi: "स्नेहमय एवं सर्जनशील" },
    { syllable: "Ta", characteristic: "Persuasive and sociable", characteristicHindi: "विनम्र-वक्ता एवं मिलनसार" },
    { syllable: "Tee", characteristic: "Pleasure-loving and refined", characteristicHindi: "रसिक एवं सुसंस्कृत" },
    { syllable: "Too", characteristic: "Disciplined and dutiful", characteristicHindi: "अनुशासित एवं कर्तव्यपरायण" },
  ],
  personality:
    "Purva Phalguni is the nakshatra of rest after labour, presided over by Bhaga, the deity of conjugal joy and fortunate distribution. You carry an unmistakable warmth that puts people instantly at ease — you are the friend who hosts, the lover who lingers, the colleague who turns a tense room into a welcoming one. Venus rules here, and you have a finely tuned aesthetic sense, whether expressed through clothing, food, music, or the way you arrange a living space. You believe pleasure is sacred and that life without celebration is wasted. This makes you generous to a fault and capable of profound romantic loyalty when matched with the right partner. The shadow side appears as indolence, vanity, or a tendency to coast on charm rather than effort. You may avoid hard conversations because they disturb the harmony you cherish, and you can seek admiration in ways that drain your dignity. Career flows when you align your taste with commerce — fashion, hospitality, the arts, event design, counseling couples. Your spiritual path teaches that true rest is earned, not stolen, and that real love is built in the unglamorous hours after the celebration ends. When you marry your softness with steady effort, you become someone whose presence is itself a gift to those around you.",
  personalityHindi:
    "पूर्व फाल्गुनी श्रम के पश्चात विश्राम का नक्षत्र है, जिसके अधिष्ठाता भग देव हैं। आप ऐसी ऊष्मा वहन करते हैं जो दूसरों को तत्क्षण सहज कर देती है — आप आतिथेय मित्र, स्नेही प्रेमी तथा कक्ष का तनाव हरने वाले सहकर्मी होते हैं। शुक्र का शासन आपको सूक्ष्म सौंदर्य-दृष्टि देता है, चाहे वह वस्त्र, भोजन, संगीत अथवा गृह-सज्जा में प्रकट हो। आप मानते हैं कि आनंद पवित्र है और उत्सवहीन जीवन व्यर्थ है। यह गुण आपको उदार बनाता है और सच्चे साथी के साथ गहरी दांपत्य-निष्ठा भी देता है। छाया-पक्ष आलस्य, अहंकार अथवा परिश्रम के स्थान पर केवल आकर्षण पर निर्भरता के रूप में प्रकट होता है। आप कठिन वार्तालाप टाल सकते हैं क्योंकि वे सामंजस्य भंग करते हैं, और प्रशंसा की खोज में स्वाभिमान कम हो सकता है। फैशन, आतिथ्य, कला, समारोह-संयोजन तथा युगल-परामर्श में सफलता मिलती है। आध्यात्मिक पाठ यह है कि वास्तविक विश्राम अर्जित किया जाता है, चुराया नहीं जाता; और सच्चा प्रेम उत्सव के बाद के सामान्य घंटों में बनता है। जब आप कोमलता को निरंतर परिश्रम से जोड़ते हैं, आप ऐसे हो जाते हैं जिसकी उपस्थिति ही उपहार बन जाती है।",
  career: ["Fashion and design", "Hospitality and event planning", "Performing arts and music", "Marriage and relationship counseling", "Luxury and beauty business"],
  careerHindi: ["फैशन एवं डिज़ाइन", "आतिथ्य एवं समारोह-संयोजन", "अभिनय एवं संगीत", "वैवाहिक परामर्श", "सौंदर्य-व्यवसाय"],
  strengths: ["Charm", "Warmth", "Creativity", "Generosity", "Aesthetic taste"],
  strengthsHindi: ["आकर्षण", "ऊष्मा", "सर्जनशीलता", "औदार्य", "सौंदर्य-बोध"],
};

const UTTARA_PHALGUNI: NakshatraStaticData = {
  id: 12, name: "Uttara Phalguni", nameHindi: "उत्तर फाल्गुनी",
  symbol: "Back legs of a bed / hammock", symbolIcon: "🛏️",
  meaning: "The latter reddish one", meaningHindi: "उत्तर लालिमायुक्त",
  lord: "Sun", lordHindi: "सूर्य",
  deity: "Aryaman (Aditya of patronage and contracts)", deityHindi: "अर्यमा",
  gana: "Manushya", ganaHindi: "मनुष्य",
  yoni: "Cow (Male / Bull)", yoniHindi: "गौ (नर)",
  nadi: "Antya", nadiHindi: "अंत्य",
  varna: "Kshatriya", varnaHindi: "क्षत्रिय",
  tatva: "Fire", tatvaHindi: "अग्नि",
  direction: "North", directionHindi: "उत्तर",
  color: "Bright Blue", colorHex: "#1E90FF",
  bodyPart: "Left hand", bodyPartHindi: "बायाँ हाथ",
  animal: "Bull", bird: "Heron", tree: "Pipal (Sacred Fig)",
  mantra: "ॐ अर्यम्णे नमः उत्तर फाल्गुन्यै नमः", mantraTransliteration: "Om Aryamne Namah Uttara Phalgunyai Namah",
  padas: [
    { syllable: "Te", characteristic: "Steady and reliable", characteristicHindi: "स्थिर एवं विश्वसनीय" },
    { syllable: "To", characteristic: "Helpful and dutiful", characteristicHindi: "सहयोगी एवं कर्तव्यपरायण" },
    { syllable: "Pa", characteristic: "Disciplined and refined", characteristicHindi: "अनुशासित एवं संस्कारित" },
    { syllable: "Pi", characteristic: "Charitable and humane", characteristicHindi: "दानशील एवं मानवीय" },
  ],
  personality:
    "Uttara Phalguni is the nakshatra of contracts, patronage, and steady noble effort. Where Purva Phalguni rests, Uttara rises and gets to work. Ruled by the Sun and presided over by Aryaman — the divine guarantor of fair dealings — you carry a deeply ethical core. People bring you their negotiations, partnership disputes, and matters of trust because they sense you will not break your word. There is a quiet kingliness in how you treat agreements, friends, and married life; you are built for long-term commitments and you take pride in being someone others can lean on across decades. The bull yoni gives you stamina and physical generosity, while the manushya gana keeps you accessible and humane. The shadow side is rigidity — you can become legalistic, judgmental of those who break codes you respect, and slow to forgive perceived betrayals. You may also push yourself to exhaustion in service of others before noticing your own needs. Career flows in law, governance, philanthropy, marriage broking, contract-heavy industries, and any work where reputation matters more than speed. The spiritual lesson of Uttara Phalguni is that giving must be balanced with receiving, and that flexibility is not weakness. When you let warmth temper your principles, your sun shines without scorching anyone in its light.",
  personalityHindi:
    "उत्तर फाल्गुनी संधि, संरक्षण तथा स्थिर श्रेष्ठ-प्रयास का नक्षत्र है। जहाँ पूर्व फाल्गुनी विश्राम करती है, वहाँ उत्तर उठकर कार्य आरंभ करती है। सूर्य द्वारा शासित और अर्यमा से अधिष्ठित — जो उचित व्यवहार के दिव्य संरक्षक हैं — आप गहन नैतिक चरित्र वहन करते हैं। लोग संधि-वार्ता, साझेदारी विवाद तथा विश्वास के विषय आपके पास लाते हैं क्योंकि उन्हें ज्ञात है कि आप वचन नहीं तोड़ेंगे। आपका करार, मित्रता तथा दांपत्य के प्रति व्यवहार राजसी होता है; आप दीर्घकालिक प्रतिबद्धता हेतु बने हैं और दशकों तक विश्वसनीय रहने पर गर्व करते हैं। वृषभ योनि आपको सहनशक्ति देती है, तथा मनुष्य गण आपको सुलभ रखता है। छाया-पक्ष कठोरता है — आप विधि-वादी, निर्णयात्मक तथा क्षमा में मंद हो सकते हैं। आप अपनी आवश्यकताओं की उपेक्षा कर थक भी सकते हैं। न्याय, शासन, परोपकार, विवाह-संयोजन तथा संधि-प्रधान उद्योगों में सफलता मिलती है। आध्यात्मिक पाठ यह है कि देने और लेने में संतुलन हो, तथा लचीलापन दुर्बलता नहीं है। जब आप ऊष्मा को सिद्धांत से जोड़ते हैं, आपका सूर्य प्रकाशित होता है, झुलसाता नहीं।",
  career: ["Law and judiciary", "Government administration", "Philanthropy and trusts", "Marriage and contract brokerage", "Long-term consultancy"],
  careerHindi: ["विधि एवं न्यायपालिका", "प्रशासनिक सेवा", "परोपकारी संस्थान", "विवाह-संयोजन", "दीर्घकालिक परामर्श"],
  strengths: ["Reliability", "Integrity", "Endurance", "Generosity", "Leadership"],
  strengthsHindi: ["विश्वसनीयता", "नैतिकता", "सहनशक्ति", "औदार्य", "नेतृत्व"],
};

const HASTA: NakshatraStaticData = {
  id: 13, name: "Hasta", nameHindi: "हस्त",
  symbol: "Open hand / fist", symbolIcon: "🤚",
  meaning: "The hand", meaningHindi: "हाथ",
  lord: "Moon", lordHindi: "चंद्र",
  deity: "Savitar (solar deity of inspiration)", deityHindi: "सविता",
  gana: "Deva", ganaHindi: "देव",
  yoni: "Buffalo (Female)", yoniHindi: "महिषी (मादा)",
  nadi: "Adi", nadiHindi: "आदि",
  varna: "Vaishya", varnaHindi: "वैश्य",
  tatva: "Fire", tatvaHindi: "अग्नि",
  direction: "West", directionHindi: "पश्चिम",
  color: "Deep Green", colorHex: "#006400",
  bodyPart: "Hands", bodyPartHindi: "हाथ",
  animal: "Buffalo", bird: "Sparrow", tree: "Reetha (Soapnut)",
  mantra: "ॐ सवित्रे नमः हस्तायै नमः", mantraTransliteration: "Om Savitre Namah Hastayai Namah",
  padas: [
    { syllable: "Pu",  characteristic: "Skilled and inventive", characteristicHindi: "निपुण एवं आविष्कारक" },
    { syllable: "Sha", characteristic: "Witty and articulate", characteristicHindi: "वाक्-चतुर एवं विनोदी" },
    { syllable: "Na",  characteristic: "Service-oriented and warm", characteristicHindi: "सेवाभावी एवं स्नेही" },
    { syllable: "Tha", characteristic: "Practical and resourceful", characteristicHindi: "व्यवहारकुशल एवं युक्तिशील" },
  ],
  personality:
    "Hasta natives are blessed with the gift the symbol announces — a skilful hand and the deft mind that moves it. Ruled by the Moon and inspired by Savitar, the rising sun, you bring craft and clarity to whatever you touch. People notice that things you handle simply work better — a meal, a document, a wounded animal, a difficult conversation. You hold a quiet wit, and you can defuse tension with a joke that lands without ever wounding the target. The buffalo yoni gives you steady earning power and a warm familial nature; the deva gana makes you genuinely kind even when you tease. You enjoy being useful, and that desire to help is your fastest route to dignity. The shadow side is restlessness — you fidget when underused, can manipulate situations subtly with charm, and may grow critical of those whose hands move slower than yours. You may also struggle with self-care because you spend so much energy serving others. Career flows in healing, surgery, fine crafts, writing, teaching, astrology, and any field where deftness matters more than brute force. The spiritual path of Hasta is to use your skilled hands to lift others without quietly counting the favours owed in return. When you give freely, the universe places more gifts into your open palm.",
  personalityHindi:
    "हस्त जातकों को उनके प्रतीक के अनुरूप वरदान प्राप्त होता है — निपुण हाथ और चपल मन। चंद्र द्वारा शासित और उदित सूर्य सविता से प्रेरित, आप जिस वस्तु को स्पर्श करते हैं वही उत्तम बन जाती है — भोजन, दस्तावेज़, घायल पशु अथवा कठिन वार्तालाप। आपके पास शांत हास्य है, और आप ऐसा विनोद कर सकते हैं जो लक्ष्य को आहत किए बिना तनाव दूर करे। महिषी योनि आपको स्थिर अर्जन-शक्ति तथा पारिवारिक स्नेह देती है; देव गण आपको हास्य में भी सच्चा-दयालु रखता है। आप उपयोगी होने में आनंद पाते हैं, और यह सहायता-प्रवृत्ति आपकी गरिमा का मार्ग है। छाया-पक्ष चंचलता है — खाली बैठने पर आप बेचैन हो जाते हैं, आकर्षण से सूक्ष्म प्रबंधन कर सकते हैं, तथा मंद हाथों के प्रति कठोर हो सकते हैं। दूसरों की सेवा में लीन होकर आत्म-देखभाल भी कठिन हो जाती है। चिकित्सा, शल्य-कर्म, सूक्ष्म कला, लेखन, अध्यापन तथा ज्योतिष में सफलता मिलती है। आध्यात्मिक पाठ यह है कि अपने कुशल हाथों से दूसरों को उठाएँ — गणना के बिना। जब आप मुक्त भाव से देते हैं, ब्रह्मांड आपकी खुली हथेली में और उपहार रखता है।",
  career: ["Healing and surgery", "Fine crafts and skilled trades", "Writing and editing", "Astrology and counseling", "Trade and skilled commerce"],
  careerHindi: ["चिकित्सा एवं शल्यकर्म", "हस्तकला", "लेखन एवं संपादन", "ज्योतिष एवं परामर्श", "व्यापार"],
  strengths: ["Skill", "Discernment", "Wit", "Service", "Practicality"],
  strengthsHindi: ["निपुणता", "विवेक", "विनोद", "सेवा-भाव", "व्यवहारिकता"],
};

const CHITRA: NakshatraStaticData = {
  id: 14, name: "Chitra", nameHindi: "चित्रा",
  symbol: "Bright pearl / shining jewel", symbolIcon: "💎",
  meaning: "The brilliant, the picture", meaningHindi: "उज्ज्वल, चित्रवत्",
  lord: "Mars", lordHindi: "मंगल",
  deity: "Tvashtar / Vishvakarma (celestial architect)", deityHindi: "त्वष्टा / विश्वकर्मा",
  gana: "Rakshasa", ganaHindi: "राक्षस",
  yoni: "Tigress (Female)", yoniHindi: "व्याघ्री (मादा)",
  nadi: "Madhya", nadiHindi: "मध्य",
  varna: "Vaishya", varnaHindi: "वैश्य",
  tatva: "Fire", tatvaHindi: "अग्नि",
  direction: "East", directionHindi: "पूर्व",
  color: "Black", colorHex: "#000000",
  bodyPart: "Forehead", bodyPartHindi: "मस्तक",
  animal: "Tiger", bird: "Peacock", tree: "Bel (Bilva)",
  mantra: "ॐ त्वष्ट्रे नमः चित्रायै नमः", mantraTransliteration: "Om Tvashtre Namah Chitrayai Namah",
  padas: [
    { syllable: "Pe",  characteristic: "Magnetic and ambitious", characteristicHindi: "आकर्षक एवं महत्त्वाकांक्षी" },
    { syllable: "Po",  characteristic: "Tactical and powerful", characteristicHindi: "रणनीतिक एवं प्रभावशाली" },
    { syllable: "Ra",  characteristic: "Artistic and refined", characteristicHindi: "कलात्मक एवं संस्कारित" },
    { syllable: "Ree", characteristic: "Spiritual and detached", characteristicHindi: "आध्यात्मिक एवं विरक्त" },
  ],
  personality:
    "Chitra is the nakshatra of the celestial architect — Tvashtar himself fashioned the world's beautiful forms here. You carry an unmistakable visual signature; people notice you across rooms before you have introduced yourself. There is a striking, almost designed quality to your presence, whether through your eyes, your voice, your style, or the way you arrange the spaces you occupy. Mars rules here, giving you ambition with edge, while the tigress yoni grants you a powerful, solitary courage that does not need a pack. You build, you compose, you stage; you have an instinct for how things should look and feel, and you can transform ordinary environments into ones people remember. The Rakshasa gana brings intensity and a willingness to break what is broken. The shadow side is vanity, illusion-making, and a tendency to confuse the surface for the substance — both in yourself and in others. You may also be magnetic to drama, drawing chaotic partners. Career thrives in design, architecture, fashion, photography, jewellery, surgery, and any work that requires both aesthetic mastery and tactical execution. The spiritual lesson of Chitra is to remember that the maker is greater than the made — that you are the soul behind the dazzling image, not the image itself. When you create from inner stillness, your outer brilliance becomes a true offering rather than a performance.",
  personalityHindi:
    "चित्रा दिव्य शिल्पी का नक्षत्र है — त्वष्टा ने यहीं संसार के सुंदर रूप गढ़े। आप विशिष्ट दृश्य-छवि वहन करते हैं; लोग आपको परिचय से पूर्व ही पहचान लेते हैं। आपकी उपस्थिति में नेत्र, स्वर, वेश-भूषा अथवा स्थान-सज्जा में एक 'रचित' गुणवत्ता होती है। मंगल का शासन आपको तीक्ष्ण महत्त्वाकांक्षा देता है, और व्याघ्री योनि एकल साहस प्रदान करती है। आप निर्माण करते हैं, रचना करते हैं, दृश्य संयोजित करते हैं; आपके पास सहज दृष्टि है कि वस्तुएँ कैसी होनी चाहिए। राक्षस गण तीव्रता तथा जो टूटा है उसे तोड़ देने का साहस देता है। छाया-पक्ष व्यर्थ अहंकार, मिथ्या-सर्जन तथा सतह को सत्व समझने की प्रवृत्ति है — स्वयं में भी और दूसरों में भी। नाटकीय व्यक्तियों की ओर भी आकर्षण होता है। डिज़ाइन, वास्तुकला, फैशन, छायांकन, आभूषण, शल्य-कर्म तथा ऐसे कार्यों में सफलता मिलती है जहाँ सौंदर्य और रणनीति दोनों चाहिए। आध्यात्मिक पाठ यह है कि स्मरण रखें — रचयिता रचना से बड़ा है। जब आप भीतरी मौन से सर्जन करते हैं, आपकी बाह्य चमक प्रदर्शन नहीं अर्पण बन जाती है।",
  career: ["Design and architecture", "Fashion and jewelry", "Photography and visual arts", "Surgery and precision crafts", "Strategic consulting"],
  careerHindi: ["डिज़ाइन एवं वास्तुकला", "फैशन एवं आभूषण", "छायांकन एवं दृश्यकला", "शल्य-कर्म", "रणनीति-परामर्श"],
  strengths: ["Magnetism", "Aesthetic mastery", "Courage", "Vision", "Precision"],
  strengthsHindi: ["आकर्षण", "सौंदर्य-कौशल", "साहस", "दृष्टि", "सटीकता"],
};

const SWATI: NakshatraStaticData = {
  id: 15, name: "Swati", nameHindi: "स्वाति",
  symbol: "Coral / young sprout in the wind", symbolIcon: "🌱",
  meaning: "The independent, the self-going one", meaningHindi: "स्वतंत्र, स्वच्छंद",
  lord: "Rahu", lordHindi: "राहु",
  deity: "Vayu (god of wind)", deityHindi: "वायु",
  gana: "Deva", ganaHindi: "देव",
  yoni: "Buffalo (Male)", yoniHindi: "महिष (नर)",
  nadi: "Antya", nadiHindi: "अंत्य",
  varna: "Shudra", varnaHindi: "शूद्र",
  tatva: "Fire", tatvaHindi: "अग्नि",
  direction: "North", directionHindi: "उत्तर",
  color: "Black", colorHex: "#1C1C1C",
  bodyPart: "Teeth", bodyPartHindi: "दंत",
  animal: "Buffalo", bird: "Bee-eater", tree: "Arjuna",
  mantra: "ॐ वायवे नमः स्वात्यै नमः", mantraTransliteration: "Om Vayave Namah Swatyai Namah",
  padas: [
    { syllable: "Ru", characteristic: "Independent and exploratory", characteristicHindi: "स्वतंत्र एवं अन्वेषक" },
    { syllable: "Re", characteristic: "Diplomatic and balanced", characteristicHindi: "कूटनीतिक एवं संतुलित" },
    { syllable: "Ro", characteristic: "Commercial and shrewd", characteristicHindi: "व्यापारी एवं चतुर" },
    { syllable: "Ta", characteristic: "Spiritual and detached", characteristicHindi: "आध्यात्मिक एवं विरक्त" },
  ],
  personality:
    "Swati is wind itself — light, mobile, and impossible to hold. Ruled by Rahu and presided over by Vayu, you carry a deeply rooted need for personal freedom. You will tolerate poverty, distance, even loneliness more easily than you will tolerate someone trying to control you. The image of a young sprout bending in wind captures your essence: flexible, alive, never breaking, always finding the next direction. You have natural diplomatic skill and can move between worlds — cultures, classes, professions — without losing your own scent. People trust you to broker deals because you genuinely see all sides and rarely take things personally. Your mind moves faster than most, hungry for travel, ideas, and commerce. The shadow side appears as restlessness, indecision, and an inability to commit; you may keep options open so long that the choices themselves expire. Rahu can also pull you into unconventional appetites you struggle to govern. Career thrives in trade, business, diplomacy, aviation, transport, yoga, and any field where movement and balance matter. Swati's spiritual teaching is paradoxical: true freedom is found not in escaping all bonds but in choosing what to belong to. When you root yourself voluntarily in dharma, the wind that once scattered you becomes the breath that lifts you upward.",
  personalityHindi:
    "स्वाति स्वयं वायु है — हल्की, गतिशील तथा बंधन-रहित। राहु से शासित और वायु देव से अधिष्ठित, आप स्वतंत्रता को परम धन मानते हैं। आप दरिद्रता, दूरी अथवा एकाकीपन तो सह सकते हैं किंतु नियंत्रण नहीं। पवन में झूमता कोमल अंकुर आपका सार है: लचीला, जीवित, टूटे बिना नई दिशा खोजता हुआ। आपमें सहज कूटनीतिक कौशल है और आप संस्कृतियों, वर्गों तथा व्यवसायों के बीच अपनी पहचान खोए बिना संचरण करते हैं। लोग आपको संधि-कार्य सौंपते हैं क्योंकि आप सब पक्ष देखते हैं। आपका मन तीव्र है, यात्रा, विचार तथा व्यापार के लिए लालायित। छाया-पक्ष चंचलता एवं अनिर्णय है; आप विकल्प इतने दीर्घ खुले रखते हैं कि वे स्वयं समाप्त हो जाते हैं। राहु अपरंपरागत आदतों की ओर भी खींच सकता है। व्यापार, कूटनीति, विमानन, परिवहन, योग तथा गत्यात्मक कार्यों में सफलता। आध्यात्मिक पाठ विरोधाभासी है: सच्ची मुक्ति समस्त बंधन त्यागने में नहीं, बल्कि स्वेच्छा से धर्म चुनने में है। जब आप स्वयं को धर्म में आरोपित करते हैं, जो वायु आपको बिखेरती थी वही आपको ऊपर उठाती है।",
  career: ["Trade and commerce", "Diplomacy and law", "Aviation and transport", "Yoga and breathwork teaching", "Independent entrepreneurship"],
  careerHindi: ["व्यापार", "कूटनीति एवं विधि", "विमानन एवं परिवहन", "योग-शिक्षण", "स्वतंत्र उद्यमिता"],
  strengths: ["Independence", "Diplomacy", "Adaptability", "Balance", "Curiosity"],
  strengthsHindi: ["स्वतंत्रता", "कूटनीति", "अनुकूलन", "संतुलन", "जिज्ञासा"],
};

const VISHAKHA: NakshatraStaticData = {
  id: 16, name: "Vishakha", nameHindi: "विशाखा",
  symbol: "Triumphal arch / potter's wheel", symbolIcon: "🏛️",
  meaning: "The forked, the two-branched", meaningHindi: "द्विशाखी",
  lord: "Jupiter", lordHindi: "बृहस्पति",
  deity: "Indra and Agni (king of gods and fire)", deityHindi: "इंद्र-अग्नि",
  gana: "Rakshasa", ganaHindi: "राक्षस",
  yoni: "Tiger (Male)", yoniHindi: "व्याघ्र (नर)",
  nadi: "Adi", nadiHindi: "आदि",
  varna: "Shudra", varnaHindi: "शूद्र",
  tatva: "Earth", tatvaHindi: "पृथ्वी",
  direction: "East", directionHindi: "पूर्व",
  color: "Gold", colorHex: "#DAA520",
  bodyPart: "Lower arms", bodyPartHindi: "बाहु का निचला भाग",
  animal: "Tiger", bird: "Drongo", tree: "Wood Apple (Kaith)",
  mantra: "ॐ इन्द्राग्निभ्यां नमः विशाखायै नमः", mantraTransliteration: "Om Indragnibhyam Namah Vishakhayai Namah",
  padas: [
    { syllable: "Tee", characteristic: "Goal-driven and ambitious", characteristicHindi: "लक्ष्योन्मुख एवं महत्त्वाकांक्षी" },
    { syllable: "Too", characteristic: "Strategic and persistent", characteristicHindi: "रणनीतिक एवं दृढ़" },
    { syllable: "Te",  characteristic: "Eloquent and persuasive", characteristicHindi: "वाग्मी एवं प्रेरक" },
    { syllable: "To",  characteristic: "Transformative and bold", characteristicHindi: "परिवर्तनकारी एवं साहसी" },
  ],
  personality:
    "Vishakha is the nakshatra of the triumphal arch — you are built to walk through gates of achievement that others find impossible to approach. Co-ruled by Indra and Agni, with Jupiter as planetary lord, you carry both fire and royal authority. Your defining trait is purposeful ambition; once you fix on a goal, you channel everything toward it with a single-minded heat that can burn for years. You are the late bloomer who arrives at the top long after the early-rising peers have given up. The forked symbol points to your dual capacity — you can hold a worldly aim and a spiritual one, and your richest seasons come when both branches grow together. The tiger yoni gives you solitary striking power; the Rakshasa gana lends an intensity that can intimidate gentler souls. The shadow side is jealousy, possessiveness, and an inner heat that turns into resentment when goals are blocked. You may push partners harder than they wish to be pushed, and you can become impatient with people who lack your hunger. Career flows in leadership, politics, sales, religion, scholarship, military, and entrepreneurship. The spiritual lesson of Vishakha is to learn that the gate is not the destination — that arriving at any arch is only the beginning of the next path. When ambition is married to devotion, your fire becomes a lamp others walk by.",
  personalityHindi:
    "विशाखा विजय-तोरण का नक्षत्र है — आप ऐसे द्वारों से निकलने हेतु बने हैं जिनके निकट जाना भी अन्य कठिन समझते हैं। इंद्र और अग्नि के सह-अधिष्ठान तथा बृहस्पति के स्वामित्व में, आप अग्नि एवं राजसी अधिकार दोनों वहन करते हैं। आपका मुख्य गुण लक्ष्य-केंद्रित महत्त्वाकांक्षा है; एक बार लक्ष्य तय करने पर आप वर्षों तक एकाग्र ताप के साथ बढ़ते हैं। आप विलंबित विजेता होते हैं जो शीघ्र-उठे साथियों के थकने पर शिखर पर पहुँचते हैं। द्विशाखा प्रतीक आपकी द्वैत-क्षमता दर्शाता है — सांसारिक एवं आध्यात्मिक लक्ष्य साथ धारण करने की। व्याघ्र योनि एकल प्रहार-शक्ति देती है; राक्षस गण तीव्रता प्रदान करता है। छाया-पक्ष ईर्ष्या, स्वामित्व-भाव तथा लक्ष्य-अवरुद्ध होने पर आक्रोश है। आप साथियों पर आवश्यकता से अधिक दबाव डाल सकते हैं। नेतृत्व, राजनीति, विक्रय, धर्म, विद्वत्ता, सेना तथा उद्यमिता में सफलता मिलती है। आध्यात्मिक पाठ यह है कि द्वार स्वयं गंतव्य नहीं है — प्रत्येक तोरण अगले मार्ग का प्रारंभ है। जब महत्त्वाकांक्षा भक्ति से मिलती है, आपकी अग्नि दूसरों के लिए दीप बन जाती है।",
  career: ["Leadership and politics", "Sales and marketing", "Religious teaching and scholarship", "Military and strategy", "Entrepreneurship"],
  careerHindi: ["नेतृत्व एवं राजनीति", "विक्रय एवं विपणन", "धर्म-शिक्षण", "सैन्य एवं रणनीति", "उद्यमिता"],
  strengths: ["Ambition", "Focus", "Eloquence", "Persistence", "Strategic vision"],
  strengthsHindi: ["महत्त्वाकांक्षा", "एकाग्रता", "वाक्-कौशल", "दृढ़ता", "रणनीतिक-दृष्टि"],
};

const ANURADHA: NakshatraStaticData = {
  id: 17, name: "Anuradha", nameHindi: "अनुराधा",
  symbol: "Lotus / triumphal archway", symbolIcon: "🪷",
  meaning: "The follower of Radha, the disciple of devotion", meaningHindi: "राधा की अनुगामिनी",
  lord: "Saturn", lordHindi: "शनि",
  deity: "Mitra (Aditya of friendship)", deityHindi: "मित्र",
  gana: "Deva", ganaHindi: "देव",
  yoni: "Deer (Female)", yoniHindi: "हरिणी (मादा)",
  nadi: "Madhya", nadiHindi: "मध्य",
  varna: "Shudra", varnaHindi: "शूद्र",
  tatva: "Earth", tatvaHindi: "पृथ्वी",
  direction: "South", directionHindi: "दक्षिण",
  color: "Reddish Brown", colorHex: "#A0522D",
  bodyPart: "Stomach", bodyPartHindi: "उदर",
  animal: "Deer", bird: "Wagtail", tree: "Bakula (Maulsari)",
  mantra: "ॐ मित्राय नमः अनुराधायै नमः", mantraTransliteration: "Om Mitraya Namah Anuradhayai Namah",
  padas: [
    { syllable: "Na",  characteristic: "Devoted and friendly", characteristicHindi: "समर्पित एवं मित्रवत्" },
    { syllable: "Nee", characteristic: "Disciplined and tender", characteristicHindi: "अनुशासित एवं स्नेही" },
    { syllable: "Noo", characteristic: "Adventurous and group-loving", characteristicHindi: "साहसी एवं समूहप्रिय" },
    { syllable: "Ne",  characteristic: "Spiritual and balanced", characteristicHindi: "आध्यात्मिक एवं संतुलित" },
  ],
  personality:
    "Anuradha is the nakshatra of devoted friendship and the slow, beautiful work of building communities. Ruled by Saturn and presided over by Mitra — the deity who guards bonds between equals — you have an unusual gift for loyalty that does not depend on circumstance. People feel safe in your company because they sense you will not turn on them when fashion or convenience changes. The lotus symbol points to spiritual unfolding through patient devotion; the deer yoni gives you a soft, alert grace. You are at your best in groups — you organize circles of friends, support networks, study groups, and spiritual gatherings as naturally as breathing. There is a quiet international quality to your soul; you make friends easily across cultures and often travel or live far from your birthplace. The shadow side comes from Saturn's restraint mixed with deep emotion: you can suffer in silence, hold disappointment too long, and become melancholy when your devotion is not returned in kind. You may also struggle with food and overeating during stress. Career flows in counseling, group leadership, international business, occult studies, religious work, and projects requiring sustained patience. The spiritual lesson of Anuradha is that devotion is its own reward, and that love freely given purifies the giver even when the receiver does not yet understand.",
  personalityHindi:
    "अनुराधा समर्पित मित्रता तथा समुदाय-निर्माण के धैर्यपूर्ण सौंदर्य का नक्षत्र है। शनि से शासित और मित्र देव से अधिष्ठित, आपके पास परिस्थिति-निरपेक्ष निष्ठा का असाधारण उपहार है। लोग आपकी संगति में सुरक्षित अनुभव करते हैं क्योंकि वे जानते हैं कि सुविधा बदलने पर आप विमुख नहीं होंगे। कमल प्रतीक धैर्यपूर्ण भक्ति से आध्यात्मिक खिलने का संकेत है; हरिणी योनि कोमल, सतर्क लालित्य देती है। आप समूहों में श्रेष्ठ होते हैं — मित्र-मंडली, सहायता-संजाल, अध्ययन-वर्ग तथा सत्संग सहज रूप से संयोजित करते हैं। आत्मा में अंतरराष्ट्रीय भाव है; संस्कृतियों के पार आसानी से मित्रता बनती है, और जन्मस्थान से दूर रहना संभव है। छाया-पक्ष शनि के संयम और गहन भाव का मिश्रण है: मौन पीड़ा, चिर निराशा तथा अप्रत्युत्तरित स्नेह पर विषाद। तनाव में आहार-असंतुलन भी संभव है। परामर्श, समूह-नेतृत्व, अंतरराष्ट्रीय व्यवसाय, गूढ़-विद्या तथा धार्मिक कार्य में सफलता मिलती है। आध्यात्मिक पाठ यह है कि भक्ति स्वयं अपना पुरस्कार है — मुक्त-भाव से दिया प्रेम देने वाले को पवित्र करता है, चाहे ग्रहीता समझे या न समझे।",
  career: ["Counseling and group facilitation", "International business and travel", "Occult studies and astrology", "Religious and devotional work", "Long-term research"],
  careerHindi: ["परामर्श एवं समूह-संयोजन", "अंतरराष्ट्रीय व्यवसाय", "गूढ़-विद्या", "धार्मिक सेवा", "दीर्घकालिक अनुसंधान"],
  strengths: ["Loyalty", "Devotion", "Patience", "Friendliness", "Resilience"],
  strengthsHindi: ["निष्ठा", "भक्ति", "धैर्य", "मित्रता", "सहनशक्ति"],
};

const JYESHTHA: NakshatraStaticData = {
  id: 18, name: "Jyeshtha", nameHindi: "ज्येष्ठा",
  symbol: "Earring / umbrella", symbolIcon: "👂",
  meaning: "The eldest, the senior", meaningHindi: "ज्येष्ठ",
  lord: "Mercury", lordHindi: "बुध",
  deity: "Indra (king of the gods)", deityHindi: "इंद्र",
  gana: "Rakshasa", ganaHindi: "राक्षस",
  yoni: "Deer (Male)", yoniHindi: "मृग (नर)",
  nadi: "Antya", nadiHindi: "अंत्य",
  varna: "Vaishya", varnaHindi: "वैश्य",
  tatva: "Air", tatvaHindi: "वायु",
  direction: "West", directionHindi: "पश्चिम",
  color: "Cream", colorHex: "#FFFDD0",
  bodyPart: "Right side of trunk", bodyPartHindi: "धड़ का दाहिना भाग",
  animal: "Deer", bird: "Indian Roller", tree: "Vishala (Semal silk-cotton)",
  mantra: "ॐ इन्द्राय नमः ज्येष्ठायै नमः", mantraTransliteration: "Om Indraya Namah Jyeshthayai Namah",
  padas: [
    { syllable: "No", characteristic: "Resourceful and protective", characteristicHindi: "साधन-सम्पन्न एवं रक्षक" },
    { syllable: "Ya", characteristic: "Strategic and authoritative", characteristicHindi: "रणनीतिक एवं अधिकारपूर्ण" },
    { syllable: "Yi", characteristic: "Communicative and witty", characteristicHindi: "वाक्-चतुर एवं विनोदी" },
    { syllable: "Yu", characteristic: "Reformative and intense", characteristicHindi: "सुधारक एवं तीव्र" },
  ],
  personality:
    "Jyeshtha bears the title of 'eldest' — and you carry the weight that goes with it. Whether you were born first in your family or simply ended up shouldering responsibility before your peers, you know what it is to be the one others lean on. Mercury rules here, giving you sharp speech and quick analytical power, while Indra-the-king grants you natural authority over situations and groups. You have a strong sense of how things should be ordered, and you can be brilliantly effective when given command. The earring symbol hints at what you hear — secrets, complaints, requests — and the umbrella shows what you offer in return: protection. There is a hidden, guarded side to Jyeshtha; you keep your real thoughts close and reveal them slowly to those who earn trust. The Rakshasa gana and intense Mula-adjacent placement bring shadow tendencies of pride, isolation, and a secret bitterness about how heavy your load has been. You may overwork, distrust easily, and resent younger or carefree people. Career flows in management, investigation, occult research, military intelligence, and reform work. The spiritual lesson of Jyeshtha is to release the inner orphan and accept that asking for help is not abdication. When you let yourself be cared for, your eldership matures from burden into blessing.",
  personalityHindi:
    "ज्येष्ठा 'ज्येष्ठ' की उपाधि वहन करती है — और आप उसी भार के साथ जीते हैं। चाहे आप परिवार के बड़े संतान हों या स्वयं उत्तरदायित्व को शीघ्र अपना लिया हो, आप जानते हैं कि सहारा देने वाला होना क्या है। बुध का शासन तीव्र वाणी और विश्लेषण देता है, और इंद्र राजा सहज अधिकार। आपके पास व्यवस्था-दृष्टि है और नेतृत्व मिलने पर असाधारण फल देते हैं। कुंडल प्रतीक संकेत करता है कि आप क्या सुनते हैं — रहस्य, शिकायतें — और छत्र दर्शाता है कि आप क्या देते हैं: रक्षण। ज्येष्ठा में गुप्त, सुरक्षित पक्ष है; अपने वास्तविक विचार धीरे-धीरे उन्हीं को बताते हैं जो विश्वास अर्जित करें। राक्षस गण से अहंकार, एकाकीपन तथा गुप्त कटुता आ सकती है। आप अति-परिश्रम कर सकते हैं, सहज विश्वास नहीं करते, तथा निश्चिंत व्यक्तियों से ईर्ष्या होती है। प्रबंधन, अन्वेषण, गूढ़-शोध, सैन्य-गुप्तचर्या तथा सुधार-कार्य में सफलता। आध्यात्मिक पाठ यह है कि भीतरी अनाथ-भाव त्यागें और सहायता माँगना कोई पराजय नहीं है। जब आप स्वयं की देखभाल स्वीकार करते हैं, आपका ज्येष्ठत्व भार से वरदान बन जाता है।",
  career: ["Senior management", "Investigation and intelligence", "Occult and esoteric research", "Reform and activism", "Engineering and analysis"],
  careerHindi: ["वरिष्ठ प्रबंधन", "अन्वेषण एवं गुप्तचर्या", "गूढ़-शोध", "सुधार-कार्य", "अभियांत्रिकी"],
  strengths: ["Authority", "Sharp intellect", "Protective instinct", "Resilience", "Strategic insight"],
  strengthsHindi: ["अधिकार", "तीक्ष्ण बुद्धि", "रक्षक-वृत्ति", "सहनशीलता", "रणनीतिक-दृष्टि"],
};

const MULA: NakshatraStaticData = {
  id: 19, name: "Mula", nameHindi: "मूल",
  symbol: "Tied bunch of roots", symbolIcon: "🌿",
  meaning: "The root, the foundation", meaningHindi: "जड़, मूल",
  lord: "Ketu", lordHindi: "केतु",
  deity: "Nirriti (goddess of dissolution)", deityHindi: "निरृति",
  gana: "Rakshasa", ganaHindi: "राक्षस",
  yoni: "Dog (Male)", yoniHindi: "श्वान (नर)",
  nadi: "Adi", nadiHindi: "आदि",
  varna: "Butcher", varnaHindi: "बधिक",
  tatva: "Air", tatvaHindi: "वायु",
  direction: "South", directionHindi: "दक्षिण",
  color: "Brown Yellow", colorHex: "#996633",
  bodyPart: "Left side of trunk", bodyPartHindi: "धड़ का बायाँ भाग",
  animal: "Dog", bird: "Vulture", tree: "Sarja / Sal",
  mantra: "ॐ निरृत्यै नमः मूलायै नमः", mantraTransliteration: "Om Nirrityai Namah Mulayai Namah",
  padas: [
    { syllable: "Ye",  characteristic: "Investigative and probing", characteristicHindi: "अन्वेषक एवं गहराई-प्रिय" },
    { syllable: "Yo",  characteristic: "Philosophical and intense", characteristicHindi: "दार्शनिक एवं तीव्र" },
    { syllable: "Bha", characteristic: "Reformative and bold", characteristicHindi: "सुधारक एवं साहसी" },
    { syllable: "Bhee", characteristic: "Detached and visionary", characteristicHindi: "विरक्त एवं दूरदर्शी" },
  ],
  personality:
    "Mula is the nakshatra of getting to the bottom of things. Ruled by Ketu and presided over by Nirriti — the goddess who dissolves illusions — you came into life with a built-in instinct to dig past surfaces until you reach the root. Whether the field is medicine, philosophy, research, or human nature, you cannot rest with a partial answer. This makes you a powerful seeker of truth, and many Mula natives experience early life upheavals that strip away inherited certainties so they can build their understanding from scratch. The dog yoni gives you fierce loyalty to the small circle you trust; the Rakshasa gana lends intensity that can both inspire and frighten others. You speak directly, sometimes brutally, and you have little patience for pretense. The shadow side appears as restlessness, willingness to destroy what is merely uncomfortable rather than truly broken, and a tendency to attract sudden losses or relocations. You may also struggle with attachment, swinging between deep loyalty and abrupt withdrawal. Career flows in research, surgery, investigation, philosophy, occult and tantric studies, herbal medicine, and any work that requires fearless excavation. The spiritual lesson of Mula is that dissolution is the gate to liberation — every loss you survive teaches you that the eternal root is within. When you stop fearing endings, you begin to live freely.",
  personalityHindi:
    "मूल जड़ तक पहुँचने का नक्षत्र है। केतु से शासित और निरृति से अधिष्ठित — जो भ्रमों को विघटित करती हैं — आप जन्म से ही सतह से नीचे जाने की प्रवृत्ति वहन करते हैं। चिकित्सा, दर्शन, अनुसंधान अथवा मानव-स्वभाव — किसी भी क्षेत्र में आप अधूरे उत्तर से संतुष्ट नहीं होते। आप सत्य के शक्तिशाली अन्वेषक हैं, और कई मूल जातक प्रारंभिक जीवन में ऐसे उथल-पुथल अनुभव करते हैं जो आनुवंशिक निश्चयों को छीनकर पुनर्निर्माण की भूमि देते हैं। श्वान योनि छोटे विश्वस्त वर्ग के प्रति प्रचंड निष्ठा देती है; राक्षस गण तीव्रता प्रदान करता है। आप सीधे, कभी-कभी कठोर बोलते हैं, और आडंबर के प्रति धैर्य नहीं रखते। छाया-पक्ष चंचलता, असहज वस्तुओं को नष्ट कर देने की प्रवृत्ति तथा अकस्मात् हानि या स्थानांतरण है। आसक्ति में दोलन भी संभव है। अनुसंधान, शल्य-कर्म, अन्वेषण, दर्शन, गूढ़-तंत्र, औषधि-वनस्पति तथा निर्भीक खुदाई वाले कार्यों में सफलता। आध्यात्मिक पाठ यह है कि विघटन मुक्ति का द्वार है — प्रत्येक उत्तरजीवी हानि सिखाती है कि शाश्वत जड़ भीतर है। जब आप अंतों से भयभीत होना छोड़ते हैं, मुक्त-जीवन प्रारंभ होता है।",
  career: ["Research and investigation", "Philosophy and spiritual teaching", "Occult and tantric studies", "Herbal medicine and pharmacology", "Surgery and forensics"],
  careerHindi: ["अनुसंधान एवं अन्वेषण", "दर्शन एवं अध्यात्म-शिक्षण", "गूढ़-तंत्र", "वनौषधि एवं औषधि-शास्त्र", "शल्य-कर्म"],
  strengths: ["Truth-seeking", "Courage", "Depth", "Loyalty", "Independence"],
  strengthsHindi: ["सत्यान्वेषण", "साहस", "गहराई", "निष्ठा", "स्वतंत्रता"],
};

const PURVA_ASHADHA: NakshatraStaticData = {
  id: 20, name: "Purva Ashadha", nameHindi: "पूर्व आषाढ़ा",
  symbol: "Fan / winnowing basket", symbolIcon: "🪭",
  meaning: "The former invincible one", meaningHindi: "पूर्व अपराजेय",
  lord: "Venus", lordHindi: "शुक्र",
  deity: "Apah (waters)", deityHindi: "जल देवता",
  gana: "Manushya", ganaHindi: "मनुष्य",
  yoni: "Monkey (Male)", yoniHindi: "वानर (नर)",
  nadi: "Madhya", nadiHindi: "मध्य",
  varna: "Brahmin", varnaHindi: "ब्राह्मण",
  tatva: "Air", tatvaHindi: "वायु",
  direction: "West", directionHindi: "पश्चिम",
  color: "Black", colorHex: "#000000",
  bodyPart: "Back", bodyPartHindi: "पीठ",
  animal: "Monkey", bird: "Cuckoo", tree: "Vetasa (Indian rattan)",
  mantra: "ॐ अद्भ्यो नमः पूर्वाषाढायै नमः", mantraTransliteration: "Om Adbhyo Namah Purvashadhayai Namah",
  padas: [
    { syllable: "Bhoo", characteristic: "Inspiring and persuasive", characteristicHindi: "प्रेरक एवं वाक्-कुशल" },
    { syllable: "Dha",  characteristic: "Bold and adventurous", characteristicHindi: "साहसी एवं उद्यमी" },
    { syllable: "Pha",  characteristic: "Philosophical and reflective", characteristicHindi: "दार्शनिक एवं चिंतनशील" },
    { syllable: "Dha",  characteristic: "Resilient and emotional", characteristicHindi: "लचीला एवं भावुक" },
  ],
  personality:
    "Purva Ashadha is the nakshatra of invincible spirit — the early surge that refuses to be dismissed. Ruled by Venus and presided over by Apah, the cosmic waters, you carry an emotional buoyancy that lifts you back to the surface no matter how many waves break over you. The fan symbol points to your power of cleansing and circulation; the winnowing basket shows your ability to separate what nourishes from what merely weighs. You are persuasive, optimistic, and carry a passionate belief in your own destiny that infects others. People follow you not because you reason them into it but because you make them feel that something larger is possible. The monkey yoni gives you wit, restlessness, and a love of social play; the manushya gana keeps you grounded in human concerns. The shadow side is stubbornness, an unwillingness to admit defeat even when it is wise to retreat, and a tendency toward emotional excess that exhausts those around you. You may also fall in love with your own rhetoric. Career thrives in oratory, debate, law, motivational work, water-related industries, fine arts, and any field requiring emotional persuasion. The spiritual lesson of Purva Ashadha is that true invincibility is not the absence of being broken, but the willingness to be remade by the very waters that submerged you.",
  personalityHindi:
    "पूर्व आषाढ़ा अपराजेय भाव का नक्षत्र है — वह प्रथम तरंग जो टलने को तैयार नहीं। शुक्र से शासित और जल-देवता से अधिष्ठित, आप ऐसी भावनात्मक उत्प्लावकता वहन करते हैं जो किसी भी लहर के बाद आपको ऊपर ले आती है। पंखा प्रतीक आपकी शुद्धिकरण-शक्ति दर्शाता है; सूप दिखाता है कि आप पोषक को व्यर्थ से अलग कर सकते हैं। आप प्रेरक, आशावादी हैं, और स्वयं के भाग्य में आपका आस्था-भाव दूसरों को संक्रमित करता है। लोग आपके तर्क से नहीं, उस अनुभूति से अनुसरण करते हैं कि कुछ बड़ा संभव है। वानर योनि चपलता, चंचलता तथा सामाजिक हास्य देती है; मनुष्य गण आपको मानवीय रखता है। छाया-पक्ष हठ, पराजय न स्वीकारने की प्रवृत्ति तथा अति-भावुकता है। अपनी ही वाणी पर मोहित हो सकते हैं। वक्तृत्व, वाद-विवाद, विधि, प्रेरणा-कार्य, जल-संबंधी उद्योग तथा कला में सफलता मिलती है। आध्यात्मिक पाठ यह है कि सच्ची अपराजेयता न-टूटना नहीं, बल्कि उन्हीं जलों से पुनर्निर्मित होने की तत्परता है जिन्होंने आपको डुबोया था।",
  career: ["Public speaking and law", "Motivational and devotional teaching", "Performing arts and music", "Water-related industries", "Diplomacy and advocacy"],
  careerHindi: ["वक्तृत्व एवं विधि", "प्रेरक-शिक्षण", "अभिनय एवं संगीत", "जल-उद्योग", "कूटनीति"],
  strengths: ["Persuasion", "Optimism", "Resilience", "Creativity", "Passion"],
  strengthsHindi: ["प्रेरण-शक्ति", "आशावाद", "सहनशीलता", "सर्जनशीलता", "उत्साह"],
};

const UTTARA_ASHADHA: NakshatraStaticData = {
  id: 21, name: "Uttara Ashadha", nameHindi: "उत्तर आषाढ़ा",
  symbol: "Elephant tusk / planks of a bed", symbolIcon: "🦣",
  meaning: "The latter invincible one", meaningHindi: "उत्तर अपराजेय",
  lord: "Sun", lordHindi: "सूर्य",
  deity: "Vishvedevas (universal gods)", deityHindi: "विश्वेदेवा",
  gana: "Manushya", ganaHindi: "मनुष्य",
  yoni: "Mongoose", yoniHindi: "नेवला",
  nadi: "Antya", nadiHindi: "अंत्य",
  varna: "Kshatriya", varnaHindi: "क्षत्रिय",
  tatva: "Air", tatvaHindi: "वायु",
  direction: "South", directionHindi: "दक्षिण",
  color: "Copper", colorHex: "#B87333",
  bodyPart: "Waist", bodyPartHindi: "कमर",
  animal: "Mongoose", bird: "Mongoose-bird (Coucal)", tree: "Jackfruit",
  mantra: "ॐ विश्वेभ्यो देवेभ्यो नमः उत्तराषाढायै नमः", mantraTransliteration: "Om Vishvebhyo Devebhyo Namah Uttarashadhayai Namah",
  padas: [
    { syllable: "Bhe", characteristic: "Principled and authoritative", characteristicHindi: "सिद्धांतवादी एवं अधिकारपूर्ण" },
    { syllable: "Bho", characteristic: "Diligent and responsible", characteristicHindi: "परिश्रमी एवं उत्तरदायी" },
    { syllable: "Ja",  characteristic: "Tactful and benevolent", characteristicHindi: "नीतिज्ञ एवं हितैषी" },
    { syllable: "Ji",  characteristic: "Steadfast and truthful", characteristicHindi: "दृढ़ एवं सत्यनिष्ठ" },
  ],
  personality:
    "Uttara Ashadha is the nakshatra of the unshakeable, lasting victory — the kind that cannot be reversed because it was earned through honest effort. Ruled by the Sun and presided over by the Vishvedevas, the universal council of gods, you carry a steady moral seriousness that becomes more impressive the longer people know you. Where Purva Ashadha sprints, Uttara Ashadha walks — and arrives. You take your time, evaluate carefully, and commit fully. There is something of the patient elephant in your style; you do not need to roar to be respected. People notice your reliability, your willingness to think about long-term outcomes, and your refusal to cut corners. The mongoose yoni gives you a sharp protective instinct against deception and corruption. The shadow side is stubbornness, slowness to begin, and a perfectionism that can paralyze action. You may also be lonely at the top, since few people can match your endurance. Career flows in government, judiciary, large institutions, ethics-driven leadership, scholarship, and any work requiring sustained credibility. The spiritual lesson of Uttara Ashadha is that lasting success is built one honest brick at a time, and that the universe rewards those who refuse to compromise their dharma even when shortcuts beckon. Your light shines longest because it was lit slowly.",
  personalityHindi:
    "उत्तर आषाढ़ा अटल विजय का नक्षत्र है — वह विजय जो सच्चे श्रम से अर्जित होने के कारण उलटी नहीं जा सकती। सूर्य से शासित और विश्वेदेवों से अधिष्ठित, आप स्थिर नैतिक गंभीरता वहन करते हैं जो समय के साथ और प्रभावशाली होती जाती है। जहाँ पूर्व आषाढ़ा दौड़ती है, वहाँ उत्तर आषाढ़ा चलती है — और पहुँचती है। आप समय लेते हैं, सावधानी से मूल्यांकन करते हैं, तथा पूर्ण समर्पण से प्रतिबद्ध होते हैं। आपमें धैर्यशील गज की शैली है; सम्मान पाने के लिए गर्जन की आवश्यकता नहीं। लोग आपकी विश्वसनीयता तथा दीर्घकालिक दृष्टि से प्रभावित होते हैं। नेवले की योनि छल और भ्रष्टाचार के विरुद्ध तीक्ष्ण रक्षक-वृत्ति देती है। छाया-पक्ष हठ, मंद-आरंभ तथा पूर्णता-वाद से उत्पन्न जड़ता है। शिखर पर एकाकीपन भी हो सकता है। शासन, न्यायपालिका, बड़े संस्थान, नैतिक नेतृत्व तथा विद्वत्ता में सफलता मिलती है। आध्यात्मिक पाठ यह है कि स्थायी सफलता एक-एक सत्य-ईंट से बनती है, और ब्रह्मांड उन्हीं को पुरस्कृत करता है जो धर्म के साथ समझौता नहीं करते। आपका प्रकाश दीर्घतम काल तक जलता है क्योंकि वह धीरे प्रज्वलित हुआ था।",
  career: ["Government and judiciary", "Institutional leadership", "Academic scholarship", "Ethics and policy work", "Long-cycle business"],
  careerHindi: ["शासन एवं न्यायपालिका", "संस्थागत नेतृत्व", "विद्वत्ता", "नीति-निर्माण", "दीर्घ-कालिक उद्यम"],
  strengths: ["Integrity", "Endurance", "Leadership", "Patience", "Foresight"],
  strengthsHindi: ["नैतिकता", "सहनशक्ति", "नेतृत्व", "धैर्य", "दूरदृष्टि"],
};

const SHRAVANA: NakshatraStaticData = {
  id: 22, name: "Shravana", nameHindi: "श्रवण",
  symbol: "Three footprints / ear", symbolIcon: "👣",
  meaning: "The hearer, the listener", meaningHindi: "श्रवणकर्ता",
  lord: "Moon", lordHindi: "चंद्र",
  deity: "Vishnu (the preserver)", deityHindi: "विष्णु",
  gana: "Deva", ganaHindi: "देव",
  yoni: "Monkey (Female)", yoniHindi: "वानरी (मादा)",
  nadi: "Adi", nadiHindi: "आदि",
  varna: "Shudra", varnaHindi: "शूद्र",
  tatva: "Air", tatvaHindi: "वायु",
  direction: "North", directionHindi: "उत्तर",
  color: "Light Blue", colorHex: "#ADD8E6",
  bodyPart: "Genitals", bodyPartHindi: "जननांग",
  animal: "Monkey", bird: "Sparrow", tree: "Arka (Madar)",
  mantra: "ॐ विष्णवे नमः श्रवणाय नमः", mantraTransliteration: "Om Vishnave Namah Shravanaya Namah",
  padas: [
    { syllable: "Khi", characteristic: "Eloquent and learned", characteristicHindi: "वाग्मी एवं विद्वान्" },
    { syllable: "Khu", characteristic: "Service-oriented and charitable", characteristicHindi: "सेवाभावी एवं दानशील" },
    { syllable: "Khe", characteristic: "Diplomatic and refined", characteristicHindi: "कूटनीतिक एवं संस्कारित" },
    { syllable: "Kho", characteristic: "Spiritually inclined and gentle", characteristicHindi: "आध्यात्मिक एवं सौम्य" },
  ],
  personality:
    "Shravana is the nakshatra of the listener — the one whose primary mode of learning is to hear. Ruled by the Moon and presided over by Vishnu the preserver, you carry a quiet receptive intelligence that absorbs more than people realize. Conversations stay with you; you remember tones, phrasings, names of strangers introduced years ago. This makes you a natural counselor, teacher, journalist, and keeper of stories. People feel deeply heard in your presence, and you have a gift for connecting them across time and space. The three footprints of Vishnu remind us that you walk between worlds — the past you preserve, the present you witness, and the future you quietly imagine. The monkey yoni gives you intellectual playfulness; the deva gana keeps your heart open. The shadow side appears as gossip, hyper-sensitivity to criticism, and a tendency to absorb others' moods until you cannot find your own. You may also become anxious when you must speak before listening enough. Career flows in education, journalism, languages, music, counseling, religious teaching, library and archive work. The spiritual lesson of Shravana is that hearing is itself a sacred act — that the universe speaks constantly to those who can quiet their own noise long enough to receive. When you listen deeply, even silence becomes scripture.",
  personalityHindi:
    "श्रवण श्रोता का नक्षत्र है — वह जो सुनकर सीखता है। चंद्र से शासित और विष्णु से अधिष्ठित, आप मौन ग्राह्य बुद्धि वहन करते हैं जो जितना ग्रहण करती है, बाहर से उतना दिखाई नहीं देता। संभाषण आपके साथ बने रहते हैं; आप स्वर, शब्द-विन्यास तथा वर्षों पूर्व मिले अपरिचित का नाम भी याद रखते हैं। आप स्वाभाविक परामर्शदाता, शिक्षक, पत्रकार तथा कथा-संरक्षक हैं। आपके सान्निध्य में लोग गहराई से सुने जाते हैं। विष्णु के तीन पद-चिह्न संकेत करते हैं कि आप तीन लोकों के बीच चलते हैं — संरक्षित अतीत, साक्षी वर्तमान तथा कल्पित भविष्य। वानरी योनि बौद्धिक हास्य देती है; देव गण हृदय को खुला रखता है। छाया-पक्ष परचर्चा, अत्यधिक संवेदनशीलता तथा दूसरों के भावों को आत्मसात करने की प्रवृत्ति है। पर्याप्त सुने बिना बोलने पर चिंता उत्पन्न हो सकती है। शिक्षा, पत्रकारिता, भाषा-शास्त्र, संगीत, परामर्श, धार्मिक शिक्षण तथा ग्रंथालय-कार्य में सफलता मिलती है। आध्यात्मिक पाठ यह है कि श्रवण स्वयं पवित्र कर्म है — ब्रह्मांड निरंतर उनसे बात करता है जो स्व-स्वर शांत कर सकें। गहन श्रवण से मौन भी शास्त्र बन जाता है।",
  career: ["Education and teaching", "Journalism and languages", "Music and audio production", "Counseling and therapy", "Library and archival work"],
  careerHindi: ["शिक्षण", "पत्रकारिता एवं भाषा-शास्त्र", "संगीत", "परामर्श एवं चिकित्सा", "ग्रंथालय-कार्य"],
  strengths: ["Listening", "Memory", "Wisdom", "Empathy", "Communication"],
  strengthsHindi: ["श्रवण-कौशल", "स्मृति", "ज्ञान", "सहानुभूति", "संप्रेषण"],
};

const DHANISHTA: NakshatraStaticData = {
  id: 23, name: "Dhanishta", nameHindi: "धनिष्ठा",
  symbol: "Drum / flute", symbolIcon: "🥁",
  meaning: "The wealthiest, the most musical", meaningHindi: "धनवान, संगीतज्ञ",
  lord: "Mars", lordHindi: "मंगल",
  deity: "Eight Vasus (elemental gods)", deityHindi: "अष्टवसु",
  gana: "Rakshasa", ganaHindi: "राक्षस",
  yoni: "Lion (Female)", yoniHindi: "सिंहिनी (मादा)",
  nadi: "Madhya", nadiHindi: "मध्य",
  varna: "Vaishya", varnaHindi: "वैश्य",
  tatva: "Ether", tatvaHindi: "आकाश",
  direction: "East", directionHindi: "पूर्व",
  color: "Silver Grey", colorHex: "#C0C0C0",
  bodyPart: "Back", bodyPartHindi: "पीठ",
  animal: "Lion", bird: "Mynah", tree: "Shami (Khejri)",
  mantra: "ॐ वसुभ्यो नमः धनिष्ठायै नमः", mantraTransliteration: "Om Vasubhyo Namah Dhanishthayai Namah",
  padas: [
    { syllable: "Ga", characteristic: "Energetic and ambitious", characteristicHindi: "ऊर्जावान एवं महत्त्वाकांक्षी" },
    { syllable: "Gi", characteristic: "Performative and rhythmic", characteristicHindi: "प्रदर्शनकारी एवं लयबद्ध" },
    { syllable: "Gu", characteristic: "Materially driven and bold", characteristicHindi: "सांसारिक एवं साहसी" },
    { syllable: "Ge", characteristic: "Spiritual and disciplined", characteristicHindi: "आध्यात्मिक एवं अनुशासित" },
  ],
  personality:
    "Dhanishta is the nakshatra of rhythm and abundance. Ruled by Mars and presided over by the eight Vasus — the elemental treasures of the universe — you came into this life with a built-in sense of timing. You can read a room, a market, a crowd, a song; you know when to enter and when to hold back. Music, dance, percussion, and sport often draw you naturally because they all reward this internal metronome. There is a quietly proud, lion-hearted quality to your presence, and you set your standards high — for status, comfort, and competence. People sense that you carry wealth even before you have it, because abundance for you is a vibration before it is a bank balance. The Rakshasa gana brings competitive intensity; the lioness yoni gives independence and a refusal to be domesticated. The shadow side appears as materialism, status anxiety, and a coldness when others fail to keep up with your tempo. You may also confuse worth with worthiness. Career flows in music, performance, sports, real estate, finance, military, and any work requiring rhythm under pressure. The spiritual lesson of Dhanishta is that the truest wealth is the inner pulse that no loss can take away. When you tune to that inner drum, the outer drums of the world play in your favour without you needing to chase them.",
  personalityHindi:
    "धनिष्ठा लय एवं समृद्धि का नक्षत्र है। मंगल से शासित और अष्टवसुओं से अधिष्ठित — जो ब्रह्मांड के मौलिक खज़ाने हैं — आप जन्मजात समय-बोध वहन करते हैं। आप कक्ष, बाज़ार, भीड़ अथवा गीत को पढ़ सकते हैं; जानते हैं कब प्रवेश करना है और कब रुकना है। संगीत, नृत्य, ताल-वाद्य तथा खेल आपको स्वाभाविक रूप से आकर्षित करते हैं। आपकी उपस्थिति में सिंह-हृदय की मौन आभा होती है, तथा प्रतिष्ठा एवं योग्यता के प्रति आपके मानक उच्च हैं। लोग अनुभव करते हैं कि आप बैंक-शेष से पूर्व ही समृद्धि वहन करते हैं, क्योंकि आपके लिए धन एक आवृत्ति है। राक्षस गण प्रतिस्पर्धी तीव्रता देता है; सिंहिनी योनि स्वतंत्रता प्रदान करती है। छाया-पक्ष भौतिकता, प्रतिष्ठा-चिंता तथा शीतलता है जब अन्य आपकी गति नहीं रख पाते। मूल्य और मूल्यवत्ता को भ्रमित कर सकते हैं। संगीत, अभिनय, खेल, स्थावर-संपदा, वित्त तथा सैन्य-कार्य में सफलता मिलती है। आध्यात्मिक पाठ यह है कि सच्चा धन वह आंतरिक स्पंदन है जिसे कोई हानि छीन नहीं सकती। जब आप उस आंतरिक मृदंग पर सम होते हैं, बाह्य ताल स्वयं आपके पक्ष में बजते हैं।",
  career: ["Music and performance arts", "Sports and athletics", "Real estate and finance", "Military and tactical roles", "Event production"],
  careerHindi: ["संगीत एवं अभिनय", "खेल", "स्थावर-संपदा एवं वित्त", "सैन्य-कार्य", "समारोह-निर्माण"],
  strengths: ["Rhythm", "Confidence", "Generosity", "Ambition", "Resilience"],
  strengthsHindi: ["लय-बोध", "आत्म-विश्वास", "औदार्य", "महत्त्वाकांक्षा", "सहनशक्ति"],
};

const SHATABHISHA: NakshatraStaticData = {
  id: 24, name: "Shatabhisha", nameHindi: "शतभिषा",
  symbol: "Empty circle / hundred stars", symbolIcon: "⭕",
  meaning: "The hundred healers / the hundred-fold mystery", meaningHindi: "सौ वैद्य, सौ-तारा",
  lord: "Rahu", lordHindi: "राहु",
  deity: "Varuna (god of cosmic waters and oaths)", deityHindi: "वरुण",
  gana: "Rakshasa", ganaHindi: "राक्षस",
  yoni: "Mare (Female horse)", yoniHindi: "अश्विनी (मादा)",
  nadi: "Antya", nadiHindi: "अंत्य",
  varna: "Butcher", varnaHindi: "बधिक",
  tatva: "Ether", tatvaHindi: "आकाश",
  direction: "West", directionHindi: "पश्चिम",
  color: "Blue Green", colorHex: "#5F9EA0",
  bodyPart: "Right thigh", bodyPartHindi: "दाहिनी जंघा",
  animal: "Horse", bird: "Mynah", tree: "Kadamba",
  mantra: "ॐ वरुणाय नमः शतभिषायै नमः", mantraTransliteration: "Om Varunaya Namah Shatabhishayai Namah",
  padas: [
    { syllable: "Go", characteristic: "Independent and inventive", characteristicHindi: "स्वतंत्र एवं आविष्कारक" },
    { syllable: "Sa", characteristic: "Mysterious and probing", characteristicHindi: "रहस्यमय एवं अन्वेषक" },
    { syllable: "Si", characteristic: "Healing and analytical", characteristicHindi: "उपचारक एवं विश्लेषणात्मक" },
    { syllable: "Su", characteristic: "Visionary and detached", characteristicHindi: "दूरदर्शी एवं विरक्त" },
  ],
  personality:
    "Shatabhisha is the nakshatra of the hundred healers and the empty circle that holds all mysteries. Ruled by Rahu and presided over by Varuna, the cosmic ocean keeper of oaths and hidden law, you carry a profoundly private, investigative mind. You are drawn to what most people avoid — dark fluids, secrets, statistics, the underbelly of cities, the unspoken corners of relationships. Yet your motive is rarely cynical; you believe that truth, however uncomfortable, is itself medicine. The empty circle suggests both isolation and infinite possibility — you contain a great deal that others do not see, and you may struggle to share it because you sense most people cannot hold it. You make a fine healer, technologist, statistician, astrologer, and researcher of unconventional fields. The mare yoni gives swift, solitary movement; the Rakshasa gana lends fierceness when your boundaries are crossed. The shadow side appears as secrecy that becomes loneliness, addictive escape into intellect or substances, and stubbornness that refuses help. You may also struggle to express affection even when you feel it deeply. Career flows in medicine, technology, astrology, statistics, alcohol or pharma research, espionage, and large-scale humanitarian work. The spiritual lesson of Shatabhisha is that the cosmic ocean within you is meant to flow outward in service. When you let people drink from your depths, your isolation transforms into the gift of healing.",
  personalityHindi:
    "शतभिषा सौ वैद्यों तथा रहस्यों को धारण करने वाले शून्य-वृत्त का नक्षत्र है। राहु से शासित और वरुण से अधिष्ठित — जो ब्रह्मांडीय जल एवं गुप्त नियमों के संरक्षक हैं — आप गहन निजी, अन्वेषक मन वहन करते हैं। आप उन विषयों की ओर आकर्षित होते हैं जिन्हें अन्य टालते हैं — गहन द्रव, रहस्य, सांख्यिकी, नगरों के अंधेरे कोने, संबंधों के अनकहे कोण। फिर भी आपका भाव शायद ही निंदात्मक हो; आप मानते हैं कि सत्य स्वयं औषधि है। शून्य-वृत्त एकाकीपन एवं अनंत संभावना दोनों का संकेत है — आप बहुत कुछ धारण करते हैं जो दूसरों को दिखाई नहीं देता। आप उत्तम चिकित्सक, प्रौद्योगिकीविद्, सांख्यिकीविद्, ज्योतिषी तथा अप्रचलित विषयों के अनुसंधाता बनते हैं। अश्विनी योनि शीघ्र, एकल गति देती है; राक्षस गण सीमा-उल्लंघन पर प्रचंडता प्रदान करता है। छाया-पक्ष गुप्तता-जनित एकाकीपन, बौद्धिक/मादक पलायन तथा सहायता न लेने का हठ है। स्नेह व्यक्त करने में कठिनाई हो सकती है। चिकित्सा, प्रौद्योगिकी, ज्योतिष, सांख्यिकी, गुप्तचर्या तथा बृहत्-मानवीय कार्य में सफलता मिलती है। आध्यात्मिक पाठ यह है कि भीतर का ब्रह्मांडीय सागर सेवा में बहना चाहिए। जब आप अपनी गहराई से दूसरों को पीने देते हैं, एकाकीपन उपचार-वरदान बन जाता है।",
  career: ["Medicine and pharmacology", "Technology and data science", "Astrology and esoteric research", "Statistics and analytics", "Humanitarian and water-related work"],
  careerHindi: ["चिकित्सा एवं औषधि-शास्त्र", "प्रौद्योगिकी एवं डेटा-विज्ञान", "ज्योतिष एवं गूढ़-शोध", "सांख्यिकी", "मानवीय-जल कार्य"],
  strengths: ["Healing insight", "Independence", "Analytical depth", "Discretion", "Vision"],
  strengthsHindi: ["उपचार-दृष्टि", "स्वतंत्रता", "विश्लेषण-गहराई", "विवेक", "दूरदर्शिता"],
};

const PURVA_BHADRAPADA: NakshatraStaticData = {
  id: 25, name: "Purva Bhadrapada", nameHindi: "पूर्व भाद्रपद",
  symbol: "Front legs of a funeral cot / two-faced man", symbolIcon: "🔥",
  meaning: "The former auspicious feet", meaningHindi: "पूर्व कल्याण-पाद",
  lord: "Jupiter", lordHindi: "बृहस्पति",
  deity: "Aja Ekapada (one-footed serpent / Rudra form)", deityHindi: "अज एकपाद",
  gana: "Manushya", ganaHindi: "मनुष्य",
  yoni: "Lion (Male)", yoniHindi: "सिंह (नर)",
  nadi: "Adi", nadiHindi: "आदि",
  varna: "Brahmin", varnaHindi: "ब्राह्मण",
  tatva: "Ether", tatvaHindi: "आकाश",
  direction: "East", directionHindi: "पूर्व",
  color: "Silver Grey", colorHex: "#A8A8A8",
  bodyPart: "Sides of body", bodyPartHindi: "शरीर के पार्श्व",
  animal: "Lion", bird: "Eagle", tree: "Mango",
  mantra: "ॐ अजैकपदे नमः पूर्वभाद्रपदायै नमः", mantraTransliteration: "Om Aja Ekapade Namah Purvabhadrapadayai Namah",
  padas: [
    { syllable: "Se", characteristic: "Spiritual and intense", characteristicHindi: "आध्यात्मिक एवं तीव्र" },
    { syllable: "So", characteristic: "Idealistic and reformative", characteristicHindi: "आदर्शवादी एवं सुधारक" },
    { syllable: "Da", characteristic: "Prophetic and unconventional", characteristicHindi: "अंतर्दृष्टि-संपन्न एवं अप्रचलित" },
    { syllable: "Di", characteristic: "Compassionate and detached", characteristicHindi: "करुणामय एवं विरक्त" },
  ],
  personality:
    "Purva Bhadrapada is the nakshatra of the sacred fire that purifies — the cremation flame that destroys what is no longer needed and the inner fire that fuels prophetic vision. Ruled by Jupiter and presided over by Aja Ekapada, the one-footed Rudra-form, you carry a serious, almost ascetic spiritual intensity. Even when you live a worldly life, there is a part of you that watches everything from a distance, asking the larger questions: what is truly real, what is worth burning down, what survives? You are unusually idealistic, capable of fierce passion for causes you adopt, and you can see hypocrisy long before others notice it. The lion yoni gives you a regal, solitary courage; the manushya gana keeps you connected to humanity even when your gaze is fixed on the eternal. You can be a powerful speaker, healer, ascetic, or reformer. The shadow side appears as anxiety, insomnia, eccentricity, and a tendency to push yourself to extremes — physical, emotional, or financial. You may also alternate between deep sociability and abrupt withdrawal. Career flows in spiritual teaching, occult work, philosophy, healing, cremation rites, journalism uncovering truth, and visionary leadership. The spiritual lesson of Purva Bhadrapada is to befriend the inner fire — to let it cook your impurities slowly rather than consume you in flashes. When the fire is held with discipline, your two faces unite into one steady gaze.",
  personalityHindi:
    "पूर्व भाद्रपद पवित्र अग्नि का नक्षत्र है — वह श्मशान-ज्वाला जो अनावश्यक को नष्ट करती है तथा वह आंतरिक अग्नि जो दिव्य-दृष्टि को ईंधन देती है। बृहस्पति से शासित और अज एकपाद रुद्र-स्वरूप से अधिष्ठित, आप गंभीर, तापसी आध्यात्मिक तीव्रता वहन करते हैं। संसार में रहकर भी आपका एक भाग दूर से सब देखता रहता है, बड़े प्रश्न पूछता है: क्या वस्तुतः सत्य है, क्या जलाने योग्य है, क्या बचता है? आप असामान्य रूप से आदर्शवादी हैं, अंगीकृत कारणों के प्रति प्रबल आवेग धारण करते हैं, तथा पाखंड को बहुत पहले देख लेते हैं। सिंह योनि एकल राजसी साहस देती है; मनुष्य गण मानवता से जोड़े रखता है। आप शक्तिशाली वक्ता, उपचारक, तपस्वी अथवा सुधारक हो सकते हैं। छाया-पक्ष चिंता, अनिद्रा, विलक्षणता तथा भौतिक/भावनात्मक/आर्थिक अति-प्रवृत्ति है। मिलनसारिता एवं विरक्ति में दोलन भी संभव है। आध्यात्मिक शिक्षण, गूढ़-कार्य, दर्शन, उपचार, श्मशान-कर्म, सत्यान्वेषी पत्रकारिता तथा दूरदर्शी नेतृत्व में सफलता मिलती है। आध्यात्मिक पाठ यह है कि आंतरिक अग्नि से मित्रता करें — उसे अपनी अशुद्धियाँ धीरे पकाने दें, क्षण में भस्म न होने दें। अनुशासन से धारण की गई अग्नि से दोनों मुख एक स्थिर दृष्टि में एक हो जाते हैं।",
  career: ["Spiritual teaching and asceticism", "Occult and esoteric studies", "Philosophy and writing", "Healing and energy work", "Investigative journalism"],
  careerHindi: ["आध्यात्मिक शिक्षण", "गूढ़-शोध", "दर्शन एवं लेखन", "ऊर्जा-उपचार", "सत्यान्वेषी पत्रकारिता"],
  strengths: ["Vision", "Idealism", "Courage", "Spiritual depth", "Reformative zeal"],
  strengthsHindi: ["दूरदृष्टि", "आदर्शवाद", "साहस", "आध्यात्मिक-गहराई", "सुधार-वृत्ति"],
};

const UTTARA_BHADRAPADA: NakshatraStaticData = {
  id: 26, name: "Uttara Bhadrapada", nameHindi: "उत्तर भाद्रपद",
  symbol: "Back legs of a funeral cot / twins", symbolIcon: "🐍",
  meaning: "The latter auspicious feet", meaningHindi: "उत्तर कल्याण-पाद",
  lord: "Saturn", lordHindi: "शनि",
  deity: "Ahir Budhnya (serpent of the cosmic deep)", deityHindi: "अहिर्बुध्न्य",
  gana: "Manushya", ganaHindi: "मनुष्य",
  yoni: "Cow (Female)", yoniHindi: "गौ (मादा)",
  nadi: "Madhya", nadiHindi: "मध्य",
  varna: "Kshatriya", varnaHindi: "क्षत्रिय",
  tatva: "Ether", tatvaHindi: "आकाश",
  direction: "North", directionHindi: "उत्तर",
  color: "Purple", colorHex: "#800080",
  bodyPart: "Shins", bodyPartHindi: "पिंडली",
  animal: "Cow", bird: "Stork", tree: "Neem",
  mantra: "ॐ अहिर्बुध्न्याय नमः उत्तरभाद्रपदायै नमः", mantraTransliteration: "Om Ahir Budhnyaya Namah Uttarabhadrapadayai Namah",
  padas: [
    { syllable: "Du",  characteristic: "Wise and calm", characteristicHindi: "विज्ञ एवं शांत" },
    { syllable: "Tha", characteristic: "Compassionate and giving", characteristicHindi: "करुणामय एवं दानशील" },
    { syllable: "Jha", characteristic: "Mystical and reflective", characteristicHindi: "रहस्यमय एवं चिंतनशील" },
    { syllable: "Tra", characteristic: "Steady and protective", characteristicHindi: "स्थिर एवं रक्षक" },
  ],
  personality:
    "Uttara Bhadrapada is the nakshatra of the deep serpent coiled in the cosmic ocean — silent, ancient, and immensely powerful. Ruled by Saturn and presided over by Ahir Budhnya, you carry an unusual stillness that often surprises people who first take you for ordinary. Where Purva Bhadrapada burns, Uttara Bhadrapada absorbs and contains. You can hold pain — your own and others' — for long periods without breaking, and you possess a natural gravitas that makes you a refuge during crisis. The cow yoni gives you patience, fertility of mind, and an instinct for nourishing what you steward. The manushya gana keeps you anchored in service. People come to you with complicated problems and leave feeling lighter, even when nothing was solved on paper. Career flows in spiritual teaching, deep healing, psychotherapy, hospice care, philosophical writing, water-related industries, and any role requiring quiet endurance. The shadow side is procrastination, hidden anger, melancholy, and a tendency to absorb darkness from others until it weighs you down. You may also speak too rarely about what you yourself need. The spiritual lesson of Uttara Bhadrapada is that the deep is itself sacred — that you do not need to perform brilliance to be valuable. When you trust your own quiet wisdom, you become a still pool in which others see themselves clearly for the first time.",
  personalityHindi:
    "उत्तर भाद्रपद ब्रह्मांडीय सागर में कुंडलित गहन सर्प का नक्षत्र है — मौन, प्राचीन तथा अत्यंत शक्तिशाली। शनि से शासित और अहिर्बुध्न्य से अधिष्ठित, आप ऐसी असाधारण स्थिरता वहन करते हैं जो प्रथम भेंट में सामान्य प्रतीत होने वाले लोगों को आश्चर्यचकित करती है। जहाँ पूर्व भाद्रपद जलती है, वहाँ उत्तर भाद्रपद अवशोषित कर धारण करती है। आप अपनी एवं दूसरों की पीड़ा को टूटे बिना दीर्घ काल तक रख सकते हैं, तथा संकट में स्वाभाविक गांभीर्य के साथ शरण-स्थल बनते हैं। गौ योनि धैर्य, मानसिक उर्वरता तथा पोषण-वृत्ति देती है। मनुष्य गण आपको सेवा से जोड़ता है। लोग जटिल समस्याएँ लाते हैं और हलके होकर लौटते हैं, चाहे कागज़ पर कुछ न सुलझा हो। आध्यात्मिक शिक्षण, गहन उपचार, मनो-चिकित्सा, मरणासन्न-सेवा, दार्शनिक लेखन तथा जल-उद्योग में सफलता मिलती है। छाया-पक्ष विलंब, गुप्त क्रोध, विषाद तथा दूसरों का अंधकार आत्मसात कर भारित हो जाने की प्रवृत्ति है। अपनी आवश्यकताएँ कम बताते हैं। आध्यात्मिक पाठ यह है कि गहराई स्वयं पवित्र है — मूल्यवान होने हेतु प्रदर्शन की आवश्यकता नहीं। जब आप अपनी मौन प्रज्ञा पर विश्वास करते हैं, आप स्थिर कुंड बनते हैं जिसमें अन्य प्रथम बार स्वयं को स्पष्ट देखते हैं।",
  career: ["Spiritual teaching and counseling", "Psychotherapy and hospice care", "Philosophical writing", "Water and oceanic industries", "Long-form research"],
  careerHindi: ["आध्यात्मिक परामर्श", "मनो-चिकित्सा", "दार्शनिक लेखन", "जल-उद्योग", "दीर्घ-शोध"],
  strengths: ["Wisdom", "Compassion", "Endurance", "Stability", "Depth"],
  strengthsHindi: ["प्रज्ञा", "करुणा", "सहनशक्ति", "स्थिरता", "गहराई"],
};

const REVATI: NakshatraStaticData = {
  id: 27, name: "Revati", nameHindi: "रेवती",
  symbol: "Fish / drum", symbolIcon: "🐟",
  meaning: "The wealthy, the prosperous, the nourisher", meaningHindi: "ऐश्वर्यवती, पोषिका",
  lord: "Mercury", lordHindi: "बुध",
  deity: "Pushan (the nourisher and pathfinder)", deityHindi: "पूषा",
  gana: "Deva", ganaHindi: "देव",
  yoni: "Elephant (Female)", yoniHindi: "गजी (मादा)",
  nadi: "Antya", nadiHindi: "अंत्य",
  varna: "Shudra", varnaHindi: "शूद्र",
  tatva: "Ether", tatvaHindi: "आकाश",
  direction: "East", directionHindi: "पूर्व",
  color: "Brown", colorHex: "#8B4513",
  bodyPart: "Ankles", bodyPartHindi: "टखने",
  animal: "Elephant", bird: "Parrot", tree: "Mahua",
  mantra: "ॐ पूष्णे नमः रेवत्यै नमः", mantraTransliteration: "Om Pushne Namah Revatyai Namah",
  padas: [
    { syllable: "De",  characteristic: "Compassionate and creative", characteristicHindi: "करुणामय एवं सर्जनशील" },
    { syllable: "Do",  characteristic: "Diplomatic and sociable", characteristicHindi: "कूटनीतिक एवं मिलनसार" },
    { syllable: "Cha", characteristic: "Spiritual and gentle", characteristicHindi: "आध्यात्मिक एवं सौम्य" },
    { syllable: "Chee", characteristic: "Mystical and otherworldly", characteristicHindi: "रहस्यमय एवं अलौकिक" },
  ],
  personality:
    "Revati is the final nakshatra — the gentle finisher of the zodiac wheel, the fish swimming in the ocean of consciousness just before liberation. Ruled by Mercury and presided over by Pushan, the nourisher and protector of travellers, you carry an unmistakable sweetness that puts both children and animals at ease in your presence. There is something quietly transcendent about you; even in mundane conversation, people sense that you are partly somewhere else, listening to a music others cannot hear. You are protective of those weaker than yourself — strays, juniors, lost souls, anyone who needs safe passage. The elephant yoni gives you a strong, steady tenderness; the deva gana keeps your heart open and your motives pure. Career flows in teaching young children, veterinary care, travel-related work, music, spiritual counseling, hospice support, and creative arts. The shadow side comes from being too soft for the rougher edges of life: you can be naive, taken advantage of by sharper personalities, and prone to spacey indecision when forced to make hard practical choices. You may also struggle with goodbyes, since Revati is the nakshatra of endings. The spiritual lesson of Revati is that to nourish well, one must not dissolve oneself entirely in others. When you protect your own gentle light along with everyone else's, you become a true guide across the final waters.",
  personalityHindi:
    "रेवती अंतिम नक्षत्र है — राशि-चक्र की कोमल समापिका, मुक्ति से ठीक पूर्व चेतना-सागर में तैरती मछली। बुध से शासित और पूषा देव से अधिष्ठित — जो पथिकों के पोषक एवं रक्षक हैं — आप ऐसी मधुरता वहन करते हैं जो बालकों एवं पशुओं को आपकी संगति में सहज कर देती है। आपमें मौन पारमार्थिक गुण है; साधारण बातचीत में भी लोग अनुभव करते हैं कि आप अंशतः कहीं और हैं, ऐसा संगीत सुनते हुए जो दूसरों को नहीं सुनाई देता। आप दुर्बलों के रक्षक हैं — गृहहीन पशु, कनिष्ठ, खोई हुई आत्माएँ, सुरक्षित मार्ग चाहने वाले सभी। गजी योनि स्थिर कोमलता देती है; देव गण हृदय एवं मनोरथ शुद्ध रखता है। बाल-शिक्षण, पशु-चिकित्सा, यात्रा-कार्य, संगीत, आध्यात्मिक परामर्श, मरणासन्न-सेवा तथा कला में सफलता मिलती है। छाया-पक्ष यह है कि आप जीवन के कठोर पक्ष के लिए अति-कोमल हो सकते हैं: भोले, चालाक व्यक्तियों द्वारा शोषित, तथा कठोर निर्णयों में अनिश्चित। विदाई कठिन होती है, क्योंकि रेवती अंतों का नक्षत्र है। आध्यात्मिक पाठ यह है कि उत्तम पोषण हेतु स्वयं को पूर्णतः विसर्जित न करें। जब आप दूसरों के साथ अपनी कोमल ज्योति की भी रक्षा करते हैं, आप अंतिम जल-यात्रा के सच्चे मार्गदर्शक बनते हैं।",
  career: ["Teaching young children", "Veterinary and animal care", "Travel and pilgrimage work", "Music and creative arts", "Spiritual counseling and hospice"],
  careerHindi: ["बाल-शिक्षण", "पशु-चिकित्सा", "यात्रा-कार्य", "संगीत एवं कला", "आध्यात्मिक परामर्श"],
  strengths: ["Compassion", "Gentleness", "Spiritual sensitivity", "Nurturing", "Imagination"],
  strengthsHindi: ["करुणा", "सौम्यता", "आध्यात्मिक संवेदनशीलता", "पोषण-वृत्ति", "कल्पना"],
};

export const NAKSHATRAS: NakshatraStaticData[] = [
  ASHWINI, BHARANI, KRITTIKA, ROHINI, MRIGASHIRA, ARDRA, PUNARVASU, PUSHYA, ASHLESHA,
  MAGHA, PURVA_PHALGUNI, UTTARA_PHALGUNI, HASTA, CHITRA, SWATI, VISHAKHA, ANURADHA, JYESHTHA,
  MULA, PURVA_ASHADHA, UTTARA_ASHADHA, SHRAVANA, DHANISHTA, SHATABHISHA, PURVA_BHADRAPADA, UTTARA_BHADRAPADA, REVATI,
];

export function getNakshatraById(id: number): NakshatraStaticData {
  const found = NAKSHATRAS.find(n => n.id === id);
  if (!found) return NAKSHATRAS[0];
  return found;
}

export function nakshatraIdFromMoonLongitude(moonLongitude: number): { id: number; pada: number } {
  const span = 360 / 27;
  const norm = ((moonLongitude % 360) + 360) % 360;
  const idx = Math.floor(norm / span);
  const within = norm - idx * span;
  const pada = Math.floor(within / (span / 4)) + 1;
  return { id: idx + 1, pada: Math.min(4, Math.max(1, pada)) };
}
