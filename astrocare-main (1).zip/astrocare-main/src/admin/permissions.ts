// Admin permission keys + metadata. Master admin always has all permissions.

export const ADMIN_PERMISSIONS = [
  { key: "manage_admins",       label: "Manage Admins",       master_only: true,  description: "Create, edit, deactivate other admins" },
  { key: "manage_astrologers",  label: "Manage Astrologers",  master_only: false, description: "Approve, reject, block, edit astrologers" },
  { key: "manage_customers",    label: "Manage Customers",    master_only: false, description: "View, edit, block customers" },
  { key: "manage_sessions",     label: "Manage Sessions",     master_only: false, description: "View any session history and chat logs" },
  { key: "manage_wallet",       label: "Manage Wallet",       master_only: false, description: "Add or adjust balance for any user" },
  { key: "manage_withdrawals",  label: "Manage Withdrawals",  master_only: false, description: "Process and mark withdrawal requests" },
  { key: "manage_reviews",      label: "Manage Reviews",      master_only: false, description: "Approve or reject reviews" },
  { key: "manage_support",      label: "Manage Support",      master_only: false, description: "View and reply to support tickets" },
  { key: "view_reports",        label: "View Reports",        master_only: false, description: "Access analytics and financial reports" },
  { key: "manage_content",      label: "Manage Content",      master_only: false, description: "Edit site content and announcements" },
] as const;

export type AdminPermissionKey = typeof ADMIN_PERMISSIONS[number]["key"];

export type AdminRole = "master_admin" | "admin" | "finance_admin";

export interface AdminUser {
  id: string;
  user_id: string;
  email: string;
  full_name: string;
  role: AdminRole;
  permissions: string[];
  is_active: boolean;
  created_by: string | null;
  last_login_at: string | null;
  created_at: string;
}

export function adminHasPermission(admin: AdminUser | null, key: AdminPermissionKey): boolean {
  if (!admin || !admin.is_active) return false;
  if (admin.role === "master_admin") return true;
  return Array.isArray(admin.permissions) && admin.permissions.includes(key);
}
