import { Navigate, useLocation } from "react-router-dom";
import { useAdminAuth } from "./AdminAuthContext";
import type { AdminPermissionKey } from "./permissions";
import { adminHasPermission } from "./permissions";
import { Loader2 } from "lucide-react";

export function AdminProtectedRoute({
  children,
  permission,
  masterOnly,
}: {
  children: React.ReactNode;
  permission?: AdminPermissionKey;
  masterOnly?: boolean;
}) {
  const { admin, loading } = useAdminAuth();
  const location = useLocation();

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-950">
        <Loader2 className="h-6 w-6 animate-spin text-slate-400" />
      </div>
    );
  }

  if (!admin) {
    return <Navigate to="/astrocareadmin/login" replace state={{ from: location.pathname }} />;
  }

  if (masterOnly && admin.role !== "master_admin") {
    return <Navigate to="/astrocareadmin/dashboard" replace />;
  }

  if (permission && !adminHasPermission(admin, permission)) {
    return <Navigate to="/astrocareadmin/dashboard" replace />;
  }

  return <>{children}</>;
}
