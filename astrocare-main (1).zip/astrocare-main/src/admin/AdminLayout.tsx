import { ReactNode, useState } from "react";
import { NavLink, useNavigate } from "react-router-dom";
import {
  LayoutDashboard, Users, UserCog, MessageSquareText, Wallet, Star,
  LifeBuoy, BarChart3, ShieldCheck, Settings, LogOut, Sparkles,
  Megaphone, Hourglass, Activity, ClipboardList, KeyRound, Radio,
} from "lucide-react";
import { useAdminAuth } from "./AdminAuthContext";
import { adminHasPermission, AdminPermissionKey } from "./permissions";
import { ChangePasswordModal } from "./ChangePasswordModal";
import { cn } from "@/lib/utils";

interface NavItem {
  label: string;
  to: string;
  icon: typeof LayoutDashboard;
  permission?: AdminPermissionKey;
  masterOnly?: boolean;
  any?: AdminPermissionKey[];
}

const NAV: NavItem[] = [
  { label: "Dashboard",      to: "/astrocareadmin/dashboard",     icon: LayoutDashboard },
  { label: "Astrologers",    to: "/astrocareadmin/astrologers",   icon: UserCog,           permission: "manage_astrologers" },
  { label: "Customers",      to: "/astrocareadmin/customers",     icon: Users,             permission: "manage_customers" },
  { label: "Sessions",       to: "/astrocareadmin/sessions",      icon: MessageSquareText, permission: "manage_sessions" },
  { label: "Finance & Reports", to: "/astrocareadmin/finance",    icon: BarChart3,         permission: "view_reports" },
  { label: "Withdrawals",    to: "/astrocareadmin/withdrawals",   icon: Hourglass,         permission: "manage_withdrawals" },
  { label: "Wallet Requests", to: "/astrocareadmin/wallet-requests", icon: ClipboardList,   permission: "manage_wallet" },
  { label: "Reviews",        to: "/astrocareadmin/reviews",       icon: Star,              permission: "manage_reviews" },
  { label: "Support",        to: "/astrocareadmin/support",       icon: LifeBuoy,          permission: "manage_support" },
  { label: "Announcements",  to: "/astrocareadmin/announcements", icon: Megaphone,         permission: "manage_content" },
  { label: "AstroLive",      to: "/astrocareadmin/astrolive",     icon: Radio,             permission: "manage_content" },
  { label: "Admin Users",    to: "/astrocareadmin/admins",        icon: ShieldCheck,       masterOnly: true },
  { label: "Activity Log",   to: "/astrocareadmin/activity",      icon: Activity },
  { label: "Settings",       to: "/astrocareadmin/settings",      icon: Settings },
];

const ROLE_LABEL: Record<string, string> = {
  master_admin:  "Master Admin",
  admin:         "Admin",
  finance_admin: "Finance Admin",
};

export function AdminLayout({ children }: { children: ReactNode }) {
  const { admin, signOut } = useAdminAuth();
  const navigate = useNavigate();
  const [showChangePw, setShowChangePw] = useState(false);

  if (!admin) return null;

  const visible = NAV.filter((item) => {
    if (item.masterOnly) return admin.role === "master_admin";
    if (item.permission) return adminHasPermission(admin, item.permission);
    if (item.any)        return item.any.some((p) => adminHasPermission(admin, p));
    return true;
  });

  const initials = (admin.full_name || admin.email).slice(0, 2).toUpperCase();

  return (
    <div className="min-h-screen flex bg-slate-950 text-slate-100">
      {/* Sidebar — sticky full-viewport height, scrollbar shown only on hover */}
      <aside className="w-64 shrink-0 border-r border-slate-800 bg-slate-900/60 sticky top-0 h-screen flex flex-col">
        {/* Brand */}
        <div className="px-5 py-4 border-b border-slate-800 flex items-center gap-2 shrink-0">
          <div className="h-9 w-9 rounded-lg bg-gradient-to-br from-indigo-500 to-violet-600 flex items-center justify-center">
            <Sparkles className="h-5 w-5 text-white" />
          </div>
          <div>
            <div className="font-semibold tracking-tight">AstroGuide</div>
            <div className="text-[11px] uppercase tracking-wider text-slate-400">Admin Console</div>
          </div>
        </div>

        {/* Single scroll area: nav + compact profile footer */}
        <div className="admin-sidebar-scroll flex-1 overflow-y-auto flex flex-col">
          <nav className="p-3 space-y-1 flex-1">
            {visible.map((item) => (
              <NavLink
                key={item.to}
                to={item.to}
                end={item.to === "/astrocareadmin/dashboard"}
                className={({ isActive }) => cn(
                  "flex items-center gap-3 px-3 py-2 rounded-md text-sm transition-colors",
                  "text-slate-300 hover:text-white hover:bg-slate-800/70",
                  isActive && "bg-indigo-600/20 text-white border border-indigo-500/30",
                )}
              >
                <item.icon className="h-4 w-4" />
                <span>{item.label}</span>
              </NavLink>
            ))}
          </nav>

          {/* Compact admin profile pinned at bottom of scroll content */}
          <div className="border-t border-slate-800 p-2 mt-auto">
            <div className="flex items-center gap-2 px-2 py-1.5">
              <div className="h-7 w-7 rounded-full bg-slate-700 text-slate-100 flex items-center justify-center text-[10px] font-semibold shrink-0">
                {initials}
              </div>
              <div className="min-w-0 flex-1">
                <div className="text-xs font-medium truncate leading-tight">{admin.full_name || admin.email}</div>
                <div className="text-[9px] uppercase tracking-wider text-indigo-300 leading-tight">
                  {ROLE_LABEL[admin.role] || admin.role}
                </div>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-1 mt-1">
              <button
                onClick={() => setShowChangePw(true)}
                className="flex items-center justify-center gap-1 text-[10px] px-2 py-1.5 rounded bg-slate-800 hover:bg-slate-700 text-slate-200"
                title="Change password"
              >
                <KeyRound className="h-3 w-3" /> Password
              </button>
              <button
                onClick={async () => { await signOut(); navigate("/astrocareadmin/login", { replace: true }); }}
                className="flex items-center justify-center gap-1 text-[10px] px-2 py-1.5 rounded bg-slate-800 hover:bg-slate-700 text-slate-200"
                title="Sign out"
              >
                <LogOut className="h-3 w-3" /> Sign out
              </button>
            </div>
          </div>
        </div>
      </aside>

      {/* Main */}
      <main className="flex-1 overflow-x-hidden">
        <div className="max-w-7xl mx-auto px-6 py-8">{children}</div>
      </main>

      {showChangePw && <ChangePasswordModal onClose={() => setShowChangePw(false)} />}
    </div>
  );
}
