import { FormEvent, useState } from "react";
import { Loader2, X } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";

export function ChangePasswordModal({ onClose }: { onClose: () => void }) {
  const { toast } = useToast();
  const [current, setCurrent] = useState("");
  const [next, setNext] = useState("");
  const [confirm, setConfirm] = useState("");
  const [busy, setBusy] = useState(false);

  const onSubmit = async (e: FormEvent) => {
    e.preventDefault();
    if (next.length < 8) {
      toast({ title: "Password too short", description: "Use at least 8 characters.", variant: "destructive" });
      return;
    }
    if (next !== confirm) {
      toast({ title: "Passwords do not match", variant: "destructive" });
      return;
    }
    setBusy(true);
    const { data: { session } } = await supabase.auth.getSession();
    const res = await fetch(
      `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/admin-manage`,
      {
        method: "POST",
        headers: {
          "content-type": "application/json",
          Authorization: `Bearer ${session?.access_token}`,
          apikey: import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY,
        },
        body: JSON.stringify({
          action: "change_own_password",
          current_password: current,
          new_password: next,
        }),
      },
    );
    const r = await res.json();
    setBusy(false);
    if (!r?.ok) {
      toast({ title: "Could not change password", description: r?.error || "Try again", variant: "destructive" });
      return;
    }
    toast({ title: "Password changed", description: "Use your new password next time you sign in." });
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/70 flex items-center justify-center p-4">
      <div className="w-full max-w-md rounded-xl bg-slate-900 border border-slate-700 p-6 text-slate-100">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-semibold">Change my password</h3>
          <button onClick={onClose} className="text-slate-400 hover:text-slate-100"><X className="h-5 w-5" /></button>
        </div>
        <form onSubmit={onSubmit} className="space-y-4">
          <Field label="Current password">
            <input type="password" required value={current} onChange={(e) => setCurrent(e.target.value)}
              className="w-full h-10 rounded-md bg-slate-950 border border-slate-700 px-3 text-sm" autoComplete="current-password" />
          </Field>
          <Field label="New password (min 8 chars)">
            <input type="password" required minLength={8} value={next} onChange={(e) => setNext(e.target.value)}
              className="w-full h-10 rounded-md bg-slate-950 border border-slate-700 px-3 text-sm" autoComplete="new-password" />
          </Field>
          <Field label="Confirm new password">
            <input type="password" required minLength={8} value={confirm} onChange={(e) => setConfirm(e.target.value)}
              className="w-full h-10 rounded-md bg-slate-950 border border-slate-700 px-3 text-sm" autoComplete="new-password" />
          </Field>
          <div className="flex justify-end gap-2 pt-2">
            <button type="button" onClick={onClose} className="h-10 px-4 rounded-md text-sm text-slate-300 hover:bg-slate-800">Cancel</button>
            <button type="submit" disabled={busy} className="h-10 px-4 rounded-md bg-indigo-600 hover:bg-indigo-500 text-white text-sm font-medium inline-flex items-center gap-2 disabled:opacity-60">
              {busy && <Loader2 className="h-4 w-4 animate-spin" />} Update password
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div>
      <div className="text-xs uppercase tracking-wider text-slate-400 mb-1">{label}</div>
      {children}
    </div>
  );
}
