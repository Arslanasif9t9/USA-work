import { createContext, useContext, useEffect, useState, ReactNode, useCallback } from "react";
import { supabase } from "@/integrations/supabase/client";
import type { AdminUser } from "./permissions";

interface AdminAuthContextValue {
  admin: AdminUser | null;
  loading: boolean;
  signIn: (email: string, password: string) => Promise<{ ok: true } | { ok: false; error: string }>;
  signOut: () => Promise<void>;
  refresh: () => Promise<void>;
}

const AdminAuthContext = createContext<AdminAuthContextValue | undefined>(undefined);

export function AdminAuthProvider({ children }: { children: ReactNode }) {
  const [admin, setAdmin] = useState<AdminUser | null>(null);
  const [loading, setLoading] = useState(true);

  const loadAdmin = useCallback(async (userId: string | null) => {
    if (!userId) { setAdmin(null); return; }
    const { data } = await supabase
      .from("admin_users")
      .select("*")
      .eq("user_id", userId)
      .maybeSingle();
    if (data && data.is_active) {
      setAdmin({
        ...data,
        permissions: Array.isArray(data.permissions) ? (data.permissions as string[]) : [],
      } as AdminUser);
    } else {
      setAdmin(null);
    }
  }, []);

  useEffect(() => {
    const { data: sub } = supabase.auth.onAuthStateChange((_e, session) => {
      // Defer the admin load to avoid recursive calls inside the listener
      setTimeout(() => { loadAdmin(session?.user?.id ?? null); }, 0);
    });
    supabase.auth.getSession().then(async ({ data }) => {
      await loadAdmin(data.session?.user?.id ?? null);
      setLoading(false);
    });
    return () => sub.subscription.unsubscribe();
  }, [loadAdmin]);

  const signIn = useCallback(async (email: string, password: string) => {
    const { data, error } = await supabase.auth.signInWithPassword({ email, password });
    if (error) return { ok: false as const, error: error.message };
    const uid = data.user?.id;
    if (!uid) return { ok: false as const, error: "Sign-in failed" };
    const { data: row } = await supabase
      .from("admin_users").select("*").eq("user_id", uid).maybeSingle();
    if (!row || !row.is_active) {
      await supabase.auth.signOut();
      setAdmin(null);
      return { ok: false as const, error: "This account is not an active administrator." };
    }
    // Update last_login_at (best effort)
    await supabase.from("admin_users").update({ last_login_at: new Date().toISOString() }).eq("id", row.id);
    setAdmin({
      ...row,
      permissions: Array.isArray(row.permissions) ? (row.permissions as string[]) : [],
    } as AdminUser);
    return { ok: true as const };
  }, []);

  const signOut = useCallback(async () => {
    await supabase.auth.signOut();
    setAdmin(null);
  }, []);

  const refresh = useCallback(async () => {
    const { data } = await supabase.auth.getSession();
    await loadAdmin(data.session?.user?.id ?? null);
  }, [loadAdmin]);

  return (
    <AdminAuthContext.Provider value={{ admin, loading, signIn, signOut, refresh }}>
      {children}
    </AdminAuthContext.Provider>
  );
}

export function useAdminAuth() {
  const ctx = useContext(AdminAuthContext);
  if (!ctx) throw new Error("useAdminAuth must be used inside AdminAuthProvider");
  return ctx;
}
