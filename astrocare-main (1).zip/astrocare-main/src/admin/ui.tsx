// Shared admin UI primitives — reuse across all admin pages for consistent look.
import { ReactNode, useEffect, useRef, useState } from "react";
import { Loader2, ChevronRight } from "lucide-react";

export function AdminPageHeader({ title, description, actions }: { title: string; description?: string; actions?: ReactNode }) {
  return (
    <div className="flex items-start justify-between gap-4 mb-6">
      <div>
        <h1 className="text-2xl font-semibold">{title}</h1>
        {description && <p className="text-sm text-slate-400 mt-1">{description}</p>}
      </div>
      {actions && <div className="flex items-center gap-2">{actions}</div>}
    </div>
  );
}

export function AdminCard({ children, className = "" }: { children: ReactNode; className?: string }) {
  return <div className={`rounded-xl border border-slate-800 bg-slate-900/60 ${className}`}>{children}</div>;
}

export function AdminTabs<T extends string>({
  tabs, value, onChange,
}: { tabs: ReadonlyArray<{ value: T; label: string; count?: number }>; value: T; onChange: (v: any) => void }) {
  return (
    <div className="flex flex-wrap gap-1 p-1 rounded-lg bg-slate-900/60 border border-slate-800 mb-4 w-fit">
      {tabs.map((t) => (
        <button
          key={t.value}
          onClick={() => onChange(t.value)}
          className={`px-3 h-8 rounded-md text-xs font-medium transition-colors ${
            value === t.value
              ? "bg-indigo-600 text-white"
              : "text-slate-300 hover:bg-slate-800/70"
          }`}
        >
          {t.label}{typeof t.count === "number" && <span className="ml-1.5 opacity-70">({t.count})</span>}
        </button>
      ))}
    </div>
  );
}

export function StatusBadge({ status }: { status: string }) {
  const map: Record<string, string> = {
    approved: "bg-emerald-500/15 text-emerald-300 border border-emerald-500/30",
    pending:  "bg-amber-500/15  text-amber-300  border border-amber-500/30",
    rejected: "bg-rose-500/15   text-rose-300   border border-rose-500/30",
    blocked:  "bg-slate-700/40  text-slate-300  border border-slate-600/40",
    active:   "bg-emerald-500/15 text-emerald-300 border border-emerald-500/30",
    completed:"bg-emerald-500/15 text-emerald-300 border border-emerald-500/30",
    processing:"bg-blue-500/15  text-blue-300   border border-blue-500/30",
    cancelled:"bg-slate-700/40  text-slate-300  border border-slate-600/40",
    ended:    "bg-slate-700/40  text-slate-300  border border-slate-600/40",
    open:     "bg-amber-500/15  text-amber-300  border border-amber-500/30",
    in_progress: "bg-blue-500/15 text-blue-300  border border-blue-500/30",
    resolved: "bg-emerald-500/15 text-emerald-300 border border-emerald-500/30",
  };
  const cls = map[status] || "bg-slate-700/40 text-slate-300 border border-slate-600/40";
  return <span className={`inline-flex items-center px-2 py-0.5 rounded text-[11px] font-medium ${cls}`}>{status.replace("_", " ")}</span>;
}

export function AdminInput(props: React.InputHTMLAttributes<HTMLInputElement>) {
  return <input {...props} className={`w-full h-10 rounded-md bg-slate-950 border border-slate-700 px-3 text-sm focus:outline-none focus:border-indigo-500 ${props.className || ""}`} />;
}
export function AdminTextarea(props: React.TextareaHTMLAttributes<HTMLTextAreaElement>) {
  return <textarea {...props} className={`w-full rounded-md bg-slate-950 border border-slate-700 px-3 py-2 text-sm focus:outline-none focus:border-indigo-500 ${props.className || ""}`} />;
}
export function AdminSelect(props: React.SelectHTMLAttributes<HTMLSelectElement>) {
  return <select {...props} className={`h-10 rounded-md bg-slate-950 border border-slate-700 px-3 text-sm focus:outline-none focus:border-indigo-500 ${props.className || ""}`} />;
}
export function AdminButton({
  children, variant = "primary", className = "", ...props
}: { variant?: "primary" | "secondary" | "danger" | "ghost" } & React.ButtonHTMLAttributes<HTMLButtonElement>) {
  const v = {
    primary:   "bg-indigo-600 hover:bg-indigo-500 text-white",
    secondary: "bg-slate-800 hover:bg-slate-700 text-slate-100 border border-slate-700",
    danger:    "bg-rose-600 hover:bg-rose-500 text-white",
    ghost:     "text-slate-300 hover:bg-slate-800",
  }[variant];
  return <button {...props} className={`inline-flex items-center justify-center gap-2 h-9 px-3 rounded-md text-xs font-medium transition-colors disabled:opacity-50 disabled:cursor-not-allowed ${v} ${className}`}>{children}</button>;
}

export function AdminModal({
  open, onClose, title, children, maxWidth = "max-w-2xl",
}: { open: boolean; onClose: () => void; title: string; children: ReactNode; maxWidth?: string }) {
  if (!open) return null;
  return (
    <div className="fixed inset-0 z-50 bg-black/70 flex items-start justify-center p-4 overflow-y-auto" onClick={onClose}>
      <div className={`w-full ${maxWidth} rounded-xl bg-slate-900 border border-slate-700 my-8`} onClick={(e) => e.stopPropagation()}>
        <div className="px-5 py-4 border-b border-slate-800 flex items-center justify-between">
          <h3 className="text-base font-semibold text-slate-100">{title}</h3>
          <button onClick={onClose} className="text-slate-400 hover:text-slate-100 text-2xl leading-none">×</button>
        </div>
        <div className="p-5 text-slate-100">{children}</div>
      </div>
    </div>
  );
}

export function EmptyState({ message = "Nothing here yet." }: { message?: string }) {
  return <div className="p-10 text-center text-sm text-slate-500">{message}</div>;
}

export function fmtINR(n: number | null | undefined) {
  return `₹${Number(n || 0).toLocaleString("en-IN", { maximumFractionDigits: 2 })}`;
}
export function fmtDate(d: string | null | undefined) {
  if (!d) return "—";
  return new Date(d).toLocaleString("en-IN", { dateStyle: "medium", timeStyle: "short" });
}
export function fmtDuration(seconds: number | null | undefined) {
  const s = Number(seconds || 0);
  const m = Math.floor(s / 60);
  const r = s % 60;
  return `${m}m ${r}s`;
}

/**
 * Wraps long admin tables. Adds horizontal scroll, a sticky-right action column,
 * a "More →" hint when there's overflow, and a sentinel for infinite scroll.
 *
 * Usage:
 *   <AdminTable sentinelRef={sentinelRef} loading={loading} done={done}>
 *     <table className="admin-table w-full text-sm">
 *       <thead> ... </thead>
 *       <tbody> ... rows where the LAST <td> uses className="admin-cell-action" ... </tbody>
 *     </table>
 *   </AdminTable>
 */
export function AdminTable({
  children, loading, done, sentinelRef, emptyMessage,
}: {
  children: ReactNode;
  loading?: boolean;
  done?: boolean;
  sentinelRef?: React.RefObject<HTMLDivElement>;
  emptyMessage?: string;
}) {
  const wrapRef = useRef<HTMLDivElement>(null);
  const [showHint, setShowHint] = useState(false);

  useEffect(() => {
    const el = wrapRef.current;
    if (!el) return;
    const check = () => setShowHint(el.scrollWidth > el.clientWidth + 4 && el.scrollLeft < el.scrollWidth - el.clientWidth - 4);
    check();
    el.addEventListener("scroll", check, { passive: true });
    const ro = new ResizeObserver(check); ro.observe(el);
    return () => { el.removeEventListener("scroll", check); ro.disconnect(); };
  }, [children]);

  return (
    <div className="relative">
      <div ref={wrapRef} className="overflow-x-auto admin-table-scroll">
        {children}
      </div>
      {showHint && (
        <div className="pointer-events-none absolute right-2 top-1/2 -translate-y-1/2 hidden sm:flex items-center gap-1 text-[10px] text-slate-400 bg-slate-900/90 border border-slate-700 px-2 py-1 rounded-full shadow-lg">
          More <ChevronRight className="h-3 w-3" />
        </div>
      )}
      {sentinelRef && !done && (
        <div ref={sentinelRef} className="flex items-center justify-center py-4 text-xs text-slate-500">
          {loading ? <span className="inline-flex items-center gap-2"><Loader2 className="h-3.5 w-3.5 animate-spin" /> Loading…</span> : "Scroll for more"}
        </div>
      )}
      {sentinelRef && done && (
        <div className="text-center py-4 text-[11px] text-slate-600">— End of list —</div>
      )}
      {emptyMessage && <EmptyState message={emptyMessage} />}
    </div>
  );
}

/** Stats card row (small, dense) — shown above tables to highlight aggregates. */
export function StatPills({ items }: { items: { label: string; value: string | number; tone?: "default" | "good" | "warn" | "info" }[] }) {
  const tones = {
    default: "bg-slate-900/60 border-slate-800 text-slate-200",
    good: "bg-emerald-500/10 border-emerald-500/30 text-emerald-200",
    warn: "bg-amber-500/10 border-amber-500/30 text-amber-200",
    info: "bg-indigo-500/10 border-indigo-500/30 text-indigo-200",
  };
  return (
    <div className="flex flex-wrap gap-2 mb-4">
      {items.map((it, i) => (
        <div key={i} className={`px-3 py-2 rounded-lg border text-xs ${tones[it.tone || "default"]}`}>
          <div className="text-[10px] uppercase opacity-70">{it.label}</div>
          <div className="font-semibold text-sm">{it.value}</div>
        </div>
      ))}
    </div>
  );
}
