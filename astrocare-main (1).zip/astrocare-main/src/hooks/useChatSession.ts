import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";

export interface ChatSession {
  id: string;
  user_id: string;
  astrologer_id: string;
  status: "pending" | "active" | "ended" | "rejected" | "cancelled";
  per_minute_rate: number;
  wallet_hold_amount: number;
  accepted_at: string | null;
  ended_at: string | null;
  end_reason: string | null;
  duration_seconds: number;
  requested_at: string;
  ended_by: string | null;
  total_cost: number;
}

export interface ChatMessage {
  id: string;
  session_id: string;
  sender_id: string;
  sender_role: "customer" | "astrologer" | "system";
  content: string;
  created_at: string;
}

export function useChatSession(sessionId: string | null) {
  const [session, setSession] = useState<ChatSession | null>(null);
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!sessionId) {
      setSession(null);
      setMessages([]);
      setLoading(false);
      return;
    }
    let active = true;

    (async () => {
      setLoading(true);
      const [{ data: s }, { data: m }] = await Promise.all([
        supabase.from("chat_sessions").select("*").eq("id", sessionId).maybeSingle(),
        supabase.from("chat_messages").select("*").eq("session_id", sessionId).order("created_at"),
      ]);
      if (!active) return;
      setSession((s as ChatSession) ?? null);
      setMessages((m as ChatMessage[]) ?? []);
      setLoading(false);
    })();

    const ch = supabase
      .channel(`chat:${sessionId}`)
      .on(
        "postgres_changes",
        { event: "*", schema: "public", table: "chat_sessions", filter: `id=eq.${sessionId}` },
        (payload) => {
          if (payload.new) setSession(payload.new as ChatSession);
        },
      )
      .on(
        "postgres_changes",
        { event: "INSERT", schema: "public", table: "chat_messages", filter: `session_id=eq.${sessionId}` },
        (payload) => {
          setMessages((prev) => {
            const next = payload.new as ChatMessage;
            if (prev.some((p) => p.id === next.id)) return prev;
            return [...prev, next];
          });
        },
      )
      .subscribe();

    return () => {
      active = false;
      supabase.removeChannel(ch);
    };
  }, [sessionId]);

  return { session, messages, loading };
}

export async function sendChatMessage(sessionId: string, senderId: string, role: "customer" | "astrologer", content: string) {
  return supabase.from("chat_messages").insert({
    session_id: sessionId,
    sender_id: senderId,
    sender_role: role,
    content,
  });
}
