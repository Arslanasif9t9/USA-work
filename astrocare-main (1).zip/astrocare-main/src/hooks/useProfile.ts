import { useEffect, useState, useCallback, useRef } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";

export interface Profile {
  id: string;
  user_id_display: number;
  name: string;
  email: string | null;
  dob: string | null;
  tob: string | null;
  pob_city: string | null;
  pob_state: string | null;
  consultation_minutes: number;
  avatar_url: string | null;
}

export function useProfile(pollMs = 30000) {
  const { user } = useAuth();
  const userId = user?.id ?? null;
  const [profile, setProfile] = useState<Profile | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchProfile = useCallback(async () => {
    if (!userId) {
      setProfile(null);
      setLoading(false);
      return;
    }
    const { data, error: err } = await supabase
      .from("profiles")
      .select(
        "id, user_id_display, name, email, dob, tob, pob_city, pob_state, consultation_minutes, avatar_url"
      )
      .eq("id", userId)
      .maybeSingle();
    if (err) {
      setError(err.message);
    } else {
      setError(null);
      if (data) setProfile(data as Profile);
    }
    setLoading(false);
  }, [userId]);

  const fetchRef = useRef(fetchProfile);
  useEffect(() => {
    fetchRef.current = fetchProfile;
  }, [fetchProfile]);

  useEffect(() => {
    fetchProfile();
  }, [fetchProfile]);

  useEffect(() => {
    if (!userId || !pollMs) return;
    const id = setInterval(() => fetchRef.current(), pollMs);
    return () => clearInterval(id);
  }, [userId, pollMs]);

  useEffect(() => {
    if (!userId) return;
    const channelName = `profile:${userId}:${Math.random().toString(36).slice(2, 10)}`;
    const channel = supabase
      .channel(channelName)
      .on(
        "postgres_changes",
        {
          event: "*",
          schema: "public",
          table: "profiles",
          filter: `id=eq.${userId}`,
        },
        () => fetchRef.current()
      )
      .subscribe();
    return () => {
      supabase.removeChannel(channel);
    };
  }, [userId]);

  return { profile, loading, error, refresh: fetchProfile };
}
