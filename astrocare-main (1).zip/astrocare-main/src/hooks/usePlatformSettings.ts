// Lightweight reader for the singleton platform_settings row.
// Cached in module memory and revalidated whenever the row changes.
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";

export interface PlatformSettings {
  min_billing_seconds: number;
  auto_end_below_balance: number;
  max_session_minutes: number;
  astrologer_share_percent: number;
  min_recharge_amount: number;
  max_wallet_balance: number;
  reviews_require_approval: boolean;
  min_review_session_seconds: number;
  min_withdrawal_amount: number;
  max_withdrawal_amount: number;
  withdrawal_processing_notice: string;
  maintenance_mode: boolean;
  maintenance_message: string;
  astrolive_enabled: boolean;
  astrolive_enabled_web: boolean;
  astrolive_enabled_mobile: boolean;
}

let cache: PlatformSettings | null = null;
const subscribers = new Set<(s: PlatformSettings) => void>();

async function refresh() {
  const { data } = await supabase.from("platform_settings").select("*").eq("id", 1).maybeSingle();
  if (data) {
    cache = data as unknown as PlatformSettings;
    subscribers.forEach((cb) => cb(cache!));
  }
}

let realtimeBound = false;
function bindRealtime() {
  if (realtimeBound) return;
  realtimeBound = true;
  supabase.channel("platform_settings_changes")
    .on("postgres_changes", { event: "*", schema: "public", table: "platform_settings" }, refresh)
    .subscribe();
}

export function usePlatformSettings() {
  const [settings, setSettings] = useState<PlatformSettings | null>(cache);
  useEffect(() => {
    bindRealtime();
    if (!cache) refresh();
    const cb = (s: PlatformSettings) => setSettings(s);
    subscribers.add(cb);
    return () => { subscribers.delete(cb); };
  }, []);
  return settings;
}
