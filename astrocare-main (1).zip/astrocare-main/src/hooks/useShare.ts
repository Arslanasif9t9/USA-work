import { useTranslation } from "react-i18next";
import { toast } from "sonner";

interface ShareOptions {
  url: string;
  title: string;
  text?: string;
}

export function useShare() {
  const { t } = useTranslation("common");

  return async (options: ShareOptions) => {
    // Try native Web Share API on mobile (gives WhatsApp, SMS, etc. native sheet)
    if (
      typeof navigator !== "undefined" &&
      typeof navigator.share === "function" &&
      /Mobi|Android|iPhone/i.test(navigator.userAgent)
    ) {
      try {
        await navigator.share({
          title: options.title,
          text: options.text,
          url: options.url,
        });
        return;
      } catch (err) {
        if ((err as Error)?.name === "AbortError") return;
        // fall through to clipboard
      }
    }

    try {
      await navigator.clipboard.writeText(options.url);
      toast.success(t("share.link_copied", { defaultValue: "Link copied to clipboard" }));
    } catch {
      toast.error(t("share.copy_failed", { defaultValue: "Could not copy link" }));
    }
  };
}
