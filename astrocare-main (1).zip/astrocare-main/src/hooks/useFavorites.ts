import { useCallback, useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { toast } from "@/hooks/use-toast";

/**
 * Manages the current user's favorite astrologers.
 * Returns a Set of astrologer ids and a toggle function.
 */
export function useFavorites() {
  const { user } = useAuth();
  const [favoriteIds, setFavoriteIds] = useState<Set<string>>(new Set());
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (!user) {
      setFavoriteIds(new Set());
      return;
    }
    let cancelled = false;
    setLoading(true);
    (async () => {
      const { data } = await (supabase as any)
        .from("favorite_astrologers")
        .select("astrologer_id")
        .eq("user_id", user.id);
      if (cancelled) return;
      setFavoriteIds(new Set((data ?? []).map((r: { astrologer_id: string }) => r.astrologer_id)));
      setLoading(false);
    })();
    return () => {
      cancelled = true;
    };
  }, [user]);

  const toggle = useCallback(
    async (astrologerId: string) => {
      if (!user) {
        toast({ title: "Sign in to save favorites", variant: "destructive" });
        return;
      }
      const isFav = favoriteIds.has(astrologerId);
      // optimistic
      setFavoriteIds((prev) => {
        const next = new Set(prev);
        if (isFav) next.delete(astrologerId);
        else next.add(astrologerId);
        return next;
      });
      if (isFav) {
        const { error } = await (supabase as any)
          .from("favorite_astrologers")
          .delete()
          .eq("user_id", user.id)
          .eq("astrologer_id", astrologerId);
        if (error) {
          setFavoriteIds((prev) => new Set(prev).add(astrologerId));
          toast({ title: "Couldn't remove favorite", variant: "destructive" });
        }
      } else {
        const { error } = await (supabase as any)
          .from("favorite_astrologers")
          .insert({ user_id: user.id, astrologer_id: astrologerId });
        if (error) {
          setFavoriteIds((prev) => {
            const next = new Set(prev);
            next.delete(astrologerId);
            return next;
          });
          toast({ title: "Couldn't save favorite", variant: "destructive" });
        }
      }
    },
    [user, favoriteIds],
  );

  return { favoriteIds, toggleFavorite: toggle, isFavorite: (id: string) => favoriteIds.has(id), loading };
}
