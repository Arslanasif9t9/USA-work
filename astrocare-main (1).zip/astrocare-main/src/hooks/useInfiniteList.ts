// Generic infinite-scroll hook. Caller provides a fetchPage(offset, limit).
// Returns rows, sentinelRef to mount at the list bottom, plus loading/done flags.
import { useCallback, useEffect, useRef, useState } from "react";

const PAGE_SIZE = 20;

export interface InfiniteListResult<T> {
  rows: T[];
  loading: boolean;
  initialLoading: boolean;
  done: boolean;
  reload: () => void;
  sentinelRef: React.RefObject<HTMLDivElement>;
}

export function useInfiniteList<T>(
  fetchPage: (offset: number, limit: number) => Promise<T[]>,
  deps: React.DependencyList = [],
): InfiniteListResult<T> {
  const [rows, setRows] = useState<T[]>([]);
  const [offset, setOffset] = useState(0);
  const [loading, setLoading] = useState(false);
  const [initialLoading, setInitialLoading] = useState(true);
  const [done, setDone] = useState(false);
  const sentinelRef = useRef<HTMLDivElement>(null);
  const fetchRef = useRef(fetchPage);
  fetchRef.current = fetchPage;

  const loadMore = useCallback(async () => {
    if (loading || done) return;
    setLoading(true);
    try {
      const next = await fetchRef.current(offset, PAGE_SIZE);
      setRows((prev) => [...prev, ...next]);
      setOffset((o) => o + next.length);
      if (next.length < PAGE_SIZE) setDone(true);
    } finally {
      setLoading(false);
      setInitialLoading(false);
    }
  }, [loading, done, offset]);

  // Reset when deps change
  useEffect(() => {
    setRows([]); setOffset(0); setDone(false); setInitialLoading(true);
    // initial fetch right away
    (async () => {
      setLoading(true);
      try {
        const first = await fetchRef.current(0, PAGE_SIZE);
        setRows(first);
        setOffset(first.length);
        if (first.length < PAGE_SIZE) setDone(true);
      } finally {
        setLoading(false);
        setInitialLoading(false);
      }
    })();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, deps);

  // IntersectionObserver triggers next page
  useEffect(() => {
    const node = sentinelRef.current;
    if (!node) return;
    const io = new IntersectionObserver((entries) => {
      if (entries[0]?.isIntersecting) loadMore();
    }, { rootMargin: "200px" });
    io.observe(node);
    return () => io.disconnect();
  }, [loadMore]);

  const reload = useCallback(() => {
    setRows([]); setOffset(0); setDone(false); setInitialLoading(true);
    (async () => {
      setLoading(true);
      try {
        const first = await fetchRef.current(0, PAGE_SIZE);
        setRows(first);
        setOffset(first.length);
        if (first.length < PAGE_SIZE) setDone(true);
      } finally {
        setLoading(false);
        setInitialLoading(false);
      }
    })();
  }, []);

  return { rows, loading, initialLoading, done, reload, sentinelRef };
}
