import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import type { PanchangResult } from "@/types/panchang";

export type { PanchangResult } from "@/types/panchang";

interface Args {
  date: string; // YYYY-MM-DD
  latitude: number;
  longitude: number;
  timezone: string;
  enabled?: boolean;
}

export function usePanchang({ date, latitude, longitude, timezone, enabled = true }: Args) {
  const latR = Math.round(latitude * 100) / 100;
  const lonR = Math.round(longitude * 100) / 100;
  return useQuery<PanchangResult>({
    queryKey: ["panchang", date, latR, lonR, timezone],
    enabled: enabled && !!date && !!timezone,
    staleTime: 60 * 60 * 1000, // 1 hour
    queryFn: async () => {
      const { data, error } = await supabase.functions.invoke("compute-panchang", {
        body: { date, latitude, longitude, timezone },
      });
      if (error) throw new Error(error.message);
      if ((data as { error?: string })?.error) throw new Error((data as { error: string }).error);
      return data as PanchangResult;
    },
    retry: 1,
  });
}
