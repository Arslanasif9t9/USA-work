import { useEffect, useRef } from "react";

/**
 * Plays a gentle, looping ambient drone using the WebAudio API while `active` is true.
 * Designed to evoke a soft Indian flute / tanpura without needing an audio file.
 * Volume is held around 30%. Auto-stops on cleanup, page hide and unload.
 */
export function useWaitingTone(active: boolean) {
  const ctxRef = useRef<AudioContext | null>(null);
  const stopRef = useRef<(() => void) | null>(null);

  useEffect(() => {
    if (!active) return;

    let cancelled = false;
    const start = async () => {
      try {
        const Ctx: typeof AudioContext =
          (window as any).AudioContext || (window as any).webkitAudioContext;
        if (!Ctx) return;
        const ctx = new Ctx();
        ctxRef.current = ctx;
        if (ctx.state === "suspended") {
          try { await ctx.resume(); } catch {}
        }
        if (cancelled) { try { ctx.close(); } catch {} return; }

        // Master gain — soft (30%)
        const master = ctx.createGain();
        master.gain.value = 0.0;
        master.connect(ctx.destination);

        // Smooth fade in
        const TARGET = 0.3;
        master.gain.linearRampToValueAtTime(TARGET, ctx.currentTime + 1.2);

        // Tanpura-like drone: two soft sines + a low pulse + reverb-ish biquad
        const filter = ctx.createBiquadFilter();
        filter.type = "lowpass";
        filter.frequency.value = 900;
        filter.Q.value = 0.6;
        filter.connect(master);

        const oscA = ctx.createOscillator();
        oscA.type = "sine";
        oscA.frequency.value = 196; // G3 root
        const gA = ctx.createGain(); gA.gain.value = 0.45;
        oscA.connect(gA).connect(filter);

        const oscB = ctx.createOscillator();
        oscB.type = "sine";
        oscB.frequency.value = 293.66; // D4 fifth
        const gB = ctx.createGain(); gB.gain.value = 0.25;
        oscB.connect(gB).connect(filter);

        // Slow LFO on filter cutoff for breathing effect
        const lfo = ctx.createOscillator();
        lfo.type = "sine";
        lfo.frequency.value = 0.18;
        const lfoGain = ctx.createGain();
        lfoGain.gain.value = 200;
        lfo.connect(lfoGain).connect(filter.frequency);

        oscA.start(); oscB.start(); lfo.start();

        stopRef.current = () => {
          try {
            const now = ctx.currentTime;
            master.gain.cancelScheduledValues(now);
            master.gain.setValueAtTime(master.gain.value, now);
            master.gain.linearRampToValueAtTime(0, now + 0.4);
            setTimeout(() => {
              try { oscA.stop(); oscB.stop(); lfo.stop(); } catch {}
              try { ctx.close(); } catch {}
            }, 500);
          } catch {}
        };
      } catch {
        /* no-op: audio not available */
      }
    };
    start();

    const onHide = () => {
      if (document.hidden) stopRef.current?.();
    };
    document.addEventListener("visibilitychange", onHide);
    window.addEventListener("pagehide", () => stopRef.current?.());
    window.addEventListener("beforeunload", () => stopRef.current?.());

    return () => {
      cancelled = true;
      document.removeEventListener("visibilitychange", onHide);
      stopRef.current?.();
      stopRef.current = null;
      ctxRef.current = null;
    };
  }, [active]);
}
