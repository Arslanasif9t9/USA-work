import { useCallback, useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import type { DashaRow, DashaLord, DashaTree } from "@/lib/dasha";
import { isLocalChartId, getLocalChart } from "@/lib/localCharts";
import { birthDataFromChart } from "@/lib/birthDataPayload";

type Status = "idle" | "loading" | "computing" | "ready" | "error";

/**
 * Loads vimshottari dasha for either a DB-backed chart (real UUID, persisted in
 * `vimshottari_dasha`) or an anonymous local chart (`local-{uuid}`, computed
 * fresh by the edge function and held in component state only).
 */
export function useDasha(birthChartId: string | undefined, autoCompute = true) {
  const [dasha, setDasha] = useState<DashaRow | null>(null);
  const [status, setStatus] = useState<Status>("loading");
  const [error, setError] = useState<string | null>(null);
  const isLocal = isLocalChartId(birthChartId);

  const fetchDasha = useCallback(async (): Promise<DashaRow | null> => {
    if (!birthChartId || isLocal) return null;
    const { data, error } = await (supabase as any)
      .from("vimshottari_dasha")
      .select("*")
      .eq("birth_chart_id", birthChartId)
      .maybeSingle();
    if (error) {
      setError(error.message);
      return null;
    }
    return (data as DashaRow | null) ?? null;
  }, [birthChartId, isLocal]);

  const compute = useCallback(async () => {
    if (!birthChartId) return;
    setStatus("computing");
    setError(null);

    if (isLocal) {
      const local = getLocalChart(birthChartId);
      if (!local) {
        setError("local_chart_not_found");
        setStatus("error");
        return;
      }
      const { data, error } = await supabase.functions.invoke("compute-dasha", {
        body: { birth_data: birthDataFromChart(local) },
      });
      if (error || (data as any)?.error) {
        setError((data as any)?.error || error?.message || "Could not compute Dasha.");
        setStatus("error");
        return;
      }
      // Synthesize a DashaRow shape from the inline response.
      const row: DashaRow = {
        id: birthChartId,
        birth_chart_id: birthChartId,
        user_id: "",
        dasha_tree: (data as any).dasha_tree as DashaTree,
        current_maha_lord: ((data as any).current_maha_lord ?? null) as DashaLord | null,
        current_maha_start: (data as any).current_maha_start ?? null,
        current_maha_end: (data as any).current_maha_end ?? null,
        current_antar_lord: ((data as any).current_antar_lord ?? null) as DashaLord | null,
        current_antar_start: (data as any).current_antar_start ?? null,
        current_antar_end: (data as any).current_antar_end ?? null,
        computed_at: new Date().toISOString(),
      };
      setDasha(row);
      setStatus("ready");
      return;
    }

    // Authenticated mode: edge function persists to vimshottari_dasha; refetch.
    const { data, error } = await supabase.functions.invoke("compute-dasha", {
      body: { birth_chart_id: birthChartId },
    });
    if (error || (data as any)?.error) {
      setError((data as any)?.error || error?.message || "Could not compute Dasha.");
      setStatus("error");
      return;
    }
    const row = await fetchDasha();
    if (row) {
      setDasha(row);
      setStatus("ready");
    } else {
      setStatus("error");
      setError("Computed but could not load Dasha.");
    }
  }, [birthChartId, fetchDasha, isLocal]);

  useEffect(() => {
    if (!birthChartId) return;
    let cancelled = false;
    (async () => {
      setStatus("loading");
      if (isLocal) {
        // No persisted row for anonymous; compute fresh if allowed.
        if (autoCompute) await compute();
        else setStatus("idle");
        return;
      }
      const row = await fetchDasha();
      if (cancelled) return;
      if (row) {
        setDasha(row);
        setStatus("ready");
      } else if (autoCompute) {
        await compute();
      } else {
        setStatus("idle");
      }
    })();
    return () => { cancelled = true; };
  }, [birthChartId, autoCompute, fetchDasha, compute, isLocal]);

  return { dasha, status, error, compute, refresh: fetchDasha };
}
