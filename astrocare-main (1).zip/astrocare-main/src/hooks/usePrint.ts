import { useState } from "react";
import { useTranslation } from "react-i18next";
import { toast } from "sonner";

export function usePrint() {
  const [printing, setPrinting] = useState(false);
  const { t } = useTranslation("common");

  const triggerPrint = (elementSelector: string, title: string) => {
    setPrinting(true);

    const sourceElement = document.querySelector(elementSelector);
    if (!sourceElement) {
      setPrinting(false);
      return;
    }

    const printWindow = window.open("", "_blank", "width=900,height=700");
    if (!printWindow) {
      setPrinting(false);
      toast.error(
        t("print.blocked", { defaultValue: "Pop-up blocked. Please allow pop-ups to print." })
      );
      return;
    }

    // Copy stylesheets from current document
    const styles = Array.from(document.styleSheets)
      .map((sheet) => {
        try {
          return Array.from(sheet.cssRules).map((r) => r.cssText).join("\n");
        } catch {
          return "";
        }
      })
      .join("\n");

    // Clone source content and strip elements marked data-print-hide
    const clone = sourceElement.cloneNode(true) as HTMLElement;
    clone.querySelectorAll("[data-print-hide]").forEach((el) => el.remove());

    const dateStr = new Date().toLocaleDateString("en-IN", {
      year: "numeric",
      month: "long",
      day: "numeric",
    });

    printWindow.document.write(`<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8" />
    <title>${title}</title>
    <style>${styles}</style>
    <style>
      body {
        background: #ffffff;
        padding: 32px;
        font-family: system-ui, -apple-system, "Segoe UI", Roboto, sans-serif;
        color: #2D2419;
      }
      .print-header {
        text-align: center;
        margin-bottom: 24px;
        padding-bottom: 16px;
        border-bottom: 2px solid #ED7B2A;
      }
      .print-header h1 {
        font-size: 22px;
        color: #7A2A1E;
        margin: 0 0 4px;
      }
      .print-header p { margin: 0; font-size: 12px; color: #5A4A3A; }
      .print-footer {
        margin-top: 32px;
        padding-top: 16px;
        border-top: 1px solid #E5DDD3;
        text-align: center;
        color: #5A4A3A;
        font-size: 12px;
      }
      .print-body { background: #FBF1E2; padding: 16px; border-radius: 8px; }
      button, [role="button"], select, [data-print-hide] { display: none !important; }
      .sticky { position: static !important; }
      @media print {
        body { padding: 12px; }
        @page { margin: 1.4cm; }
      }
    </style>
  </head>
  <body>
    <div class="print-header">
      <h1>${title}</h1>
      <p>AstroGuide • Vedic Astrology Insights</p>
    </div>
    <div class="print-body">${clone.innerHTML}</div>
    <div class="print-footer">Generated ${dateStr} • astrocare.lovable.app</div>
  </body>
</html>`);
    printWindow.document.close();

    setTimeout(() => {
      try {
        printWindow.focus();
        printWindow.print();
      } catch {
        // ignore
      }
      setPrinting(false);
    }, 600);
  };

  return { triggerPrint, printing };
}
