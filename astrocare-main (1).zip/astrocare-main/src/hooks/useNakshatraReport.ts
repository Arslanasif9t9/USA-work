import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import type { NakshatraReportPayload } from "@/types/nakshatra";
import { getNakshatraById, nakshatraIdFromMoonLongitude } from "@/data/nakshatras";
import { isLocalChartId, getLocalChart } from "@/lib/localCharts";
import { birthDataFromChart } from "@/lib/birthDataPayload";

interface UseNakshatraReportArgs {
  birthChartId: string | null;
  language: "en" | "hi";
  enabled: boolean;
  /** If chart_data is already loaded client-side, we can derive nakshatra/pada
   *  immediately and render from static data while the API call is in flight. */
  moonLongitude?: number | null;
}

interface UseNakshatraReportResult {
  data: NakshatraReportPayload | null;
  loading: boolean;
  error: string | null;
  partial: boolean; // true when only static fallback was used
}

/**
 * Loads the merged nakshatra report for a birth chart. Uses an in-memory cache
 * keyed by `${birthChartId}:${language}` so reopening the drawer is instant.
 *
 * Dual mode: a `local-{uuid}` chartId routes through anonymous edge function
 * mode (inline birth_data), while real UUIDs use the DB-backed flow.
 */
const memCache = new Map<string, NakshatraReportPayload>();

export function useNakshatraReport({
  birthChartId, language, enabled, moonLongitude,
}: UseNakshatraReportArgs): UseNakshatraReportResult {
  const [data, setData] = useState<NakshatraReportPayload | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!enabled || !birthChartId) return;
    const cacheKey = `${birthChartId}:${language}`;
    const cached = memCache.get(cacheKey);
    if (cached) { setData(cached); return; }

    // Optimistic static render
    if (typeof moonLongitude === "number") {
      const { id, pada } = nakshatraIdFromMoonLongitude(moonLongitude);
      setData({
        nakshatra_id: id, pada, language,
        source: "static_fallback",
        api_response: {},
        static: getNakshatraById(id),
      });
    }

    let cancelled = false;
    setLoading(true);
    setError(null);
    (async () => {
      try {
        const isLocal = isLocalChartId(birthChartId);
        let invokeBody: Record<string, unknown>;
        if (isLocal) {
          const local = getLocalChart(birthChartId);
          if (!local) throw new Error("local_chart_not_found");
          invokeBody = { birth_data: birthDataFromChart(local), language };
        } else {
          invokeBody = { birth_chart_id: birthChartId, language };
        }
        const { data: resp, error: invokeErr } = await supabase.functions.invoke(
          "fetch-nakshatra-report",
          { body: invokeBody },
        );
        if (cancelled) return;
        if (invokeErr || !resp || resp.error) {
          throw new Error(resp?.error || invokeErr?.message || "unknown_error");
        }
        const merged: NakshatraReportPayload = {
          nakshatra_id: resp.nakshatra_id,
          pada: resp.pada,
          language: resp.language,
          source: resp.source,
          api_response: resp.api_response || {},
          static: getNakshatraById(resp.nakshatra_id),
        };
        memCache.set(cacheKey, merged);
        setData(merged);
      } catch (e) {
        if (cancelled) return;
        setError(e instanceof Error ? e.message : String(e));
      } finally {
        if (!cancelled) setLoading(false);
      }
    })();

    return () => { cancelled = true; };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [birthChartId, language, enabled]);

  return {
    data,
    loading,
    error,
    partial: data?.source === "static_fallback",
  };
}

