import { useEffect, useState } from "react";
import { useAuth } from "@/contexts/AuthContext";
import { supabase } from "@/integrations/supabase/client";

export interface AstrologerAccount {
  id: string;
  display_name: string;
  avatar_url: string | null;
  status: string;
  is_online: boolean;
  is_chat_online: boolean;
  accepting_calls: boolean;
  accepting_chat: boolean;
  rating_avg: number;
  rating_count: number;
  follower_count: number;
  base_rate_per_min: number;
  chat_rate_per_min: number;
  user_id: string | null;
  slug: string;
  bio: string | null;
  specializations: string[];
  languages: string[];
  experience_years: number;
  education: string | null;
  focus_area: string | null;
  systems_known: string[];
  total_consultations: number;
  discounted_rate_per_min: number | null;
  phone_number: string | null;
}

/** Returns the astrologer profile for the current user, if any. */
export function useAstrologerAccount() {
  const { user, loading: authLoading } = useAuth();
  const [astro, setAstro] = useState<AstrologerAccount | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (authLoading) return;
    if (!user) {
      setAstro(null);
      setLoading(false);
      return;
    }
    let cancelled = false;
    setLoading(true);
    supabase
      .from("astrologers")
      .select("*")
      .eq("user_id", user.id)
      .maybeSingle()
      .then(({ data }) => {
        if (cancelled) return;
        setAstro((data as unknown as AstrologerAccount) ?? null);
        setLoading(false);
      });
    return () => {
      cancelled = true;
    };
  }, [user, authLoading]);

  const refresh = async () => {
    if (!user) return;
    const { data } = await supabase.from("astrologers").select("*").eq("user_id", user.id).maybeSingle();
    setAstro((data as unknown as AstrologerAccount) ?? null);
  };

  return { astro, loading, refresh, setAstro };
}
