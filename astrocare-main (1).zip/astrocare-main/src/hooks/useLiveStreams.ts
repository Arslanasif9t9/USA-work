// Hook for the customer-facing live streams feed.
import { useEffect, useState, useCallback } from "react";
import { supabase } from "@/integrations/supabase/client";

export interface LiveStreamRow {
  id: string;
  astrologer_id: string;
  title: string;
  description: string | null;
  thumbnail_url: string | null;
  channel_name: string;
  status: "live" | "ended" | "scheduled";
  viewer_count: number;
  total_likes: number;
  total_comments: number;
  total_gifts_value: number;
  started_at: string;
  active_co_host_id?: string | null;
  is_paused_for_private?: boolean;
}

export interface LiveStreamWithAstro extends LiveStreamRow {
  astrologer: {
    id: string;
    display_name: string;
    avatar_url: string | null;
    slug: string | null;
    follower_count: number;
    specializations: string[];
    base_rate_per_min: number;
  };
}

export function useLiveStreams() {
  const [streams, setStreams] = useState<LiveStreamWithAstro[]>([]);
  const [loading, setLoading] = useState(true);

  const refresh = useCallback(async () => {
    const { data } = await supabase
      .from("live_streams")
      .select(
        `id, astrologer_id, title, description, thumbnail_url, channel_name, status,
         viewer_count, total_likes, total_comments, total_gifts_value, started_at,
         active_co_host_id, is_paused_for_private,
         astrologer:astrologers!live_streams_astrologer_id_fkey (
           id, display_name, avatar_url, slug, follower_count, specializations, base_rate_per_min
         )`
      )
      .eq("status", "live")
      .order("viewer_count", { ascending: false })
      .limit(50);
    if (data) setStreams(data as unknown as LiveStreamWithAstro[]);
    setLoading(false);
  }, []);

  useEffect(() => {
    refresh();
    const ch = supabase
      .channel(`live_streams_feed_${Math.random().toString(36).slice(2)}`)
      .on("postgres_changes", { event: "*", schema: "public", table: "live_streams" }, refresh)
      .subscribe();
    return () => { supabase.removeChannel(ch); };
  }, [refresh]);

  return { streams, loading, refresh };
}

export function useAstrologerLiveMap() {
  // Map astrologer_id -> live stream id (for showing LIVE badge on cards)
  const [map, setMap] = useState<Record<string, string>>({});

  useEffect(() => {
    let active = true;
    async function load() {
      const { data } = await supabase
        .from("live_streams")
        .select("id, astrologer_id")
        .eq("status", "live");
      if (!active || !data) return;
      const next: Record<string, string> = {};
      for (const r of data) next[r.astrologer_id] = r.id;
      setMap(next);
    }
    load();
    const ch = supabase
      .channel(`live_streams_map_${Math.random().toString(36).slice(2)}`)
      .on("postgres_changes", { event: "*", schema: "public", table: "live_streams" }, load)
      .subscribe();
    return () => { active = false; supabase.removeChannel(ch); };
  }, []);

  return map;
}
