import { useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";

type StatusValue = "online" | "offline" | "busy";

export function useAstrologerStatus(
  onStatusChange: (astrologerId: string, status: StatusValue, changes: Record<string, unknown>) => void,
) {
  useEffect(() => {
    const channel = supabase
      .channel(`astrologer-status-${Date.now()}`)
      .on(
        "postgres_changes",
        { event: "UPDATE", schema: "public", table: "astrologers" },
        (payload) => {
          const next = payload.new as { id: string; status: StatusValue } & Record<string, unknown>;
          if (next?.id && next?.status) onStatusChange(next.id, next.status, next);
        },
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [onStatusChange]);
}
