import { useCallback, useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";

export interface BirthChartRow {
  id: string;
  user_id: string;
  chart_name: string | null;
  birth_date: string;
  birth_time: string | null;
  time_unknown: boolean;
  location_name: string;
  latitude: number;
  longitude: number;
  timezone: string;
  gender: "Male" | "Female" | "Other";
  chart_data: any;
  created_at: string;
}

export function useBirthCharts() {
  const { user } = useAuth();
  const [charts, setCharts] = useState<BirthChartRow[]>([]);
  const [loading, setLoading] = useState(true);

  const refresh = useCallback(async () => {
    if (!user) {
      setCharts([]);
      setLoading(false);
      return;
    }
    setLoading(true);
    const { data } = await supabase
      .from("birth_charts" as any)
      .select("*")
      .eq("user_id", user.id)
      .order("created_at", { ascending: false });
    setCharts((data ?? []) as unknown as BirthChartRow[]);
    setLoading(false);
  }, [user]);

  useEffect(() => {
    refresh();
  }, [refresh]);

  return { charts, loading, refresh };
}
