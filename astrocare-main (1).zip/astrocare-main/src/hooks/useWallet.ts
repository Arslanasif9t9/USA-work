import { useEffect, useState, useCallback, useRef } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";

interface Wallet {
  id: string;
  balance: number;
  currency: string;
}

export function useWallet(pollMs = 30000) {
  const { user } = useAuth();
  const userId = user?.id ?? null;
  const [wallet, setWallet] = useState<Wallet | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchWallet = useCallback(async () => {
    if (!userId) {
      setWallet(null);
      setLoading(false);
      return;
    }
    const { data, error: err } = await supabase
      .from("wallets")
      .select("id, balance, currency")
      .eq("user_id", userId)
      .maybeSingle();
    if (err) {
      setError(err.message);
    } else {
      setError(null);
      if (data) setWallet({ ...data, balance: Number(data.balance) });
    }
    setLoading(false);
  }, [userId]);

  // Keep latest fetcher in a ref so realtime/poll effects don't depend on it
  const fetchRef = useRef(fetchWallet);
  useEffect(() => {
    fetchRef.current = fetchWallet;
  }, [fetchWallet]);

  useEffect(() => {
    fetchWallet();
  }, [fetchWallet]);

  // Poll for balance updates
  useEffect(() => {
    if (!userId || !pollMs) return;
    const id = setInterval(() => fetchRef.current(), pollMs);
    return () => clearInterval(id);
  }, [userId, pollMs]);

  // Realtime subscription as a faster path. Unique channel name per hook
  // instance so multiple components mounting useWallet don't collide.
  useEffect(() => {
    if (!userId) return;
    const channelName = `wallet:${userId}:${Math.random().toString(36).slice(2, 10)}`;
    const channel = supabase
      .channel(channelName)
      .on(
        "postgres_changes",
        { event: "*", schema: "public", table: "wallets", filter: `user_id=eq.${userId}` },
        () => fetchRef.current()
      )
      .subscribe();
    return () => {
      supabase.removeChannel(channel);
    };
  }, [userId]);

  return { wallet, loading, error, refresh: fetchWallet };
}

export function formatINR(amount: number): string {
  return new Intl.NumberFormat("en-IN", {
    style: "currency",
    currency: "INR",
    maximumFractionDigits: 2,
  }).format(amount);
}
