import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";

export type CallStatus =
  | "pending"
  | "ringing_astrologer"
  | "ringing_user"
  | "connected"
  | "completed"
  | "failed"
  | "declined"
  | "no_answer"
  | "cancelled";

export interface CallSession {
  id: string;
  user_id: string;
  astrologer_id: string;
  status: CallStatus;
  per_minute_rate: number;
  wallet_hold_amount: number;
  initiated_at: string;
  connected_at: string | null;
  ended_at: string | null;
  duration_seconds: number;
  end_reason: string | null;
  twilio_astrologer_call_sid: string | null;
  twilio_user_call_sid: string | null;
  recording_url: string | null;
}

export function useCallSession(callSessionId: string | null) {
  const [session, setSession] = useState<CallSession | null>(null);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (!callSessionId) {
      setSession(null);
      return;
    }
    let cancelled = false;
    setLoading(true);

    const fetchOnce = async () => {
      const { data } = await supabase
        .from("call_sessions")
        .select(
          "id, user_id, astrologer_id, status, per_minute_rate, wallet_hold_amount, initiated_at, connected_at, ended_at, duration_seconds, end_reason, twilio_astrologer_call_sid, twilio_user_call_sid, recording_url",
        )
        .eq("id", callSessionId)
        .maybeSingle();
      if (!cancelled && data) {
        setSession({
          ...data,
          per_minute_rate: Number(data.per_minute_rate),
          wallet_hold_amount: Number(data.wallet_hold_amount),
        } as CallSession);
      }
      if (!cancelled) setLoading(false);
    };
    fetchOnce();

    const channelName = `call-${callSessionId}-${Math.random().toString(36).slice(2, 8)}`;
    const channel = supabase
      .channel(channelName)
      .on(
        "postgres_changes",
        {
          event: "UPDATE",
          schema: "public",
          table: "call_sessions",
          filter: `id=eq.${callSessionId}`,
        },
        () => fetchOnce(),
      )
      .subscribe();

    return () => {
      cancelled = true;
      supabase.removeChannel(channel);
    };
  }, [callSessionId]);

  return { session, loading };
}
