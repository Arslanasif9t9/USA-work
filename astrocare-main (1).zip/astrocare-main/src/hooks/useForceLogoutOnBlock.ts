// Listens to the current user's profile + astrologer row via realtime.
// If the customer is blocked OR the astrologer becomes rejected/blocked,
// signs them out immediately and redirects to a friendly explainer page.
import { useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { toast } from "sonner";

export function useForceLogoutOnBlock() {
  const { user, signOut } = useAuth();
  const navigate = useNavigate();

  useEffect(() => {
    if (!user) return;
    let cancelled = false;

    async function checkOnce() {
      const [{ data: prof }, { data: astro }] = await Promise.all([
        supabase.from("profiles").select("is_blocked, blocked_reason").eq("id", user.id).maybeSingle(),
        supabase.from("astrologers").select("approval_status, rejection_reason").eq("user_id", user.id).maybeSingle(),
      ]);
      if (cancelled) return;
      if (prof?.is_blocked) return forceOut("blocked", prof.blocked_reason || undefined);
      if (astro && (astro.approval_status === "blocked" || astro.approval_status === "rejected")) {
        return forceOut(astro.approval_status, astro.rejection_reason || undefined);
      }
    }

    function forceOut(why: string, reason?: string) {
      const msg =
        why === "blocked"
          ? "Your account has been blocked. Contact support for details."
          : why === "rejected"
            ? "Your astrologer application was rejected. Contact support for details."
            : "Your account is no longer active.";
      toast.error(reason ? `${msg} (${reason})` : msg, { duration: 6000 });
      const params = new URLSearchParams({ kind: why, reason: reason || "" });
      signOut().finally(() => {
        navigate(`/blocked?${params.toString()}`, { replace: true });
      });
    }

    checkOnce();

    const ch = supabase
      .channel(`force-logout-${user.id}`)
      .on("postgres_changes",
        { event: "UPDATE", schema: "public", table: "profiles", filter: `id=eq.${user.id}` },
        (p: any) => { if (p.new?.is_blocked) forceOut("blocked", p.new.blocked_reason); })
      .on("postgres_changes",
        { event: "UPDATE", schema: "public", table: "astrologers", filter: `user_id=eq.${user.id}` },
        (p: any) => {
          const s = p.new?.approval_status;
          if (s === "blocked" || s === "rejected") forceOut(s, p.new?.rejection_reason);
        })
      .subscribe();

    return () => { cancelled = true; supabase.removeChannel(ch); };
  }, [user, navigate, signOut]);
}
