import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import type { DCode, ShodashvargaResponse } from "@/types/shodashvarga";
import { isLocalChartId, getLocalChart } from "@/lib/localCharts";
import { birthDataFromChart } from "@/lib/birthDataPayload";

interface Args {
  birthChartId: string | null;
  dCode: DCode;
  language: "en" | "hi";
  enabled: boolean;
}

interface Result {
  data: ShodashvargaResponse | null;
  loading: boolean;
  error: string | null;
  reload: () => void;
}

const memCache = new Map<string, ShodashvargaResponse>();

export function useShodashvargaChart({ birthChartId, dCode, language, enabled }: Args): Result {
  const [data, setData] = useState<ShodashvargaResponse | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [tick, setTick] = useState(0);

  useEffect(() => {
    if (!enabled || !birthChartId) return;
    const cacheKey = `${birthChartId}:${dCode}:${language}`;
    const cached = memCache.get(cacheKey);
    if (cached && tick === 0) {
      setData(cached);
      return;
    }

    let cancelled = false;
    setLoading(true);
    setError(null);
    (async () => {
      try {
        const isLocal = isLocalChartId(birthChartId);
        let invokeBody: Record<string, unknown>;
        if (isLocal) {
          const local = getLocalChart(birthChartId);
          if (!local) throw new Error("local_chart_not_found");
          invokeBody = {
            birth_data: birthDataFromChart(local),
            chart_id: dCode,
            language,
          };
        } else {
          invokeBody = { birth_chart_id: birthChartId, chart_id: dCode, language };
        }
        const { data: resp, error: invokeErr } = await supabase.functions.invoke(
          "fetch-shodashvarga",
          { body: invokeBody },
        );
        if (cancelled) return;
        if (invokeErr || !resp || resp.error) {
          throw new Error(resp?.error || invokeErr?.message || "unknown_error");
        }
        const merged: ShodashvargaResponse = {
          chart: resp.chart,
          language: resp.language,
          source: resp.source,
          cached: !!resp.cached,
          anonymous: !!resp.anonymous,
        };
        memCache.set(cacheKey, merged);
        setData(merged);
      } catch (e) {
        if (cancelled) return;
        setError(e instanceof Error ? e.message : String(e));
      } finally {
        if (!cancelled) setLoading(false);
      }
    })();

    return () => { cancelled = true; };
  }, [birthChartId, dCode, language, enabled, tick]);

  return { data, loading, error, reload: () => setTick((n) => n + 1) };
}
