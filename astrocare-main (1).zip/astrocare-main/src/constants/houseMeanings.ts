// House meaning labels (English + Hindi) used in chart tooltips.
// Translations are also mirrored under ashtakavarga.house_meanings in i18n
// for components that prefer t() — this constant is a fallback / quick lookup.

export const HOUSE_MEANINGS_EN: Record<number, string> = {
  1: "Self, Personality",
  2: "Wealth, Family, Speech",
  3: "Siblings, Courage, Communication",
  4: "Mother, Home, Comforts",
  5: "Children, Education, Romance",
  6: "Enemies, Health, Service",
  7: "Marriage, Partnership",
  8: "Longevity, Transformation, Hidden Things",
  9: "Father, Higher Learning, Religion",
  10: "Career, Status, Action",
  11: "Income, Gains, Friends",
  12: "Loss, Liberation, Foreign",
};

export const HOUSE_MEANINGS_HI: Record<number, string> = {
  1: "स्वयं, व्यक्तित्व",
  2: "धन, परिवार, वाणी",
  3: "भाई-बहन, साहस, संप्रेषण",
  4: "माता, गृह, सुख",
  5: "संतान, शिक्षा, प्रेम",
  6: "शत्रु, स्वास्थ्य, सेवा",
  7: "विवाह, साझेदारी",
  8: "आयु, परिवर्तन, गूढ़ रहस्य",
  9: "पिता, उच्च शिक्षा, धर्म",
  10: "करियर, प्रतिष्ठा, कर्म",
  11: "आय, लाभ, मित्र",
  12: "हानि, मोक्ष, विदेश",
};
