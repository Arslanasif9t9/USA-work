// Single source of truth for Ashtakavarga visual chart colors and thresholds.

export const ASHTAKAVARGA_CHART_COLORS = {
  diamondStroke: "#ED7B2A", // saffron — matches Lagna chart
  houseNumber: "#3F2A1A",
  bindu: {
    auspicious: "#ED7B2A",
    auspiciousText: "#FFFFFF",
    mixed: "#D4A24C",
    mixedText: "#FFFFFF",
    inauspicious: "#7A8B99",
    inauspiciousText: "#FBEFE5",
  },
  strongestHouseRing: "#ED7B2A",
} as const;

export const ASHTAKAVARGA_THRESHOLDS = {
  sarva: { auspicious: 30, mixed: [28, 29] as number[] },
  bhinna: { auspicious: 6, mixed: [4, 5] as number[] },
};

export type BinduStrength = "auspicious" | "mixed" | "inauspicious";

export function getSarvaStrength(bindu: number): BinduStrength {
  if (bindu >= ASHTAKAVARGA_THRESHOLDS.sarva.auspicious) return "auspicious";
  if (ASHTAKAVARGA_THRESHOLDS.sarva.mixed.includes(bindu)) return "mixed";
  return "inauspicious";
}

export function getBhinnaStrength(bindu: number): BinduStrength {
  if (bindu >= ASHTAKAVARGA_THRESHOLDS.bhinna.auspicious) return "auspicious";
  if (ASHTAKAVARGA_THRESHOLDS.bhinna.mixed.includes(bindu)) return "mixed";
  return "inauspicious";
}

export function binduFill(strength: BinduStrength): string {
  return ASHTAKAVARGA_CHART_COLORS.bindu[
    strength === "auspicious"
      ? "auspicious"
      : strength === "mixed"
        ? "mixed"
        : "inauspicious"
  ];
}

export function binduTextFill(strength: BinduStrength): string {
  return ASHTAKAVARGA_CHART_COLORS.bindu[
    strength === "auspicious"
      ? "auspiciousText"
      : strength === "mixed"
        ? "mixedText"
        : "inauspiciousText"
  ];
}
