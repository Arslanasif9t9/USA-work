// Call Recap — minimal pass-through service worker.
// No caching: every request goes to the network so deploys stay fresh.
self.addEventListener('install', (event) => {
  self.skipWaiting();
});

self.addEventListener('activate', (event) => {
  event.waitUntil((async () => {
    // Drop any caches a previous version may have created.
    try {
      const names = await caches.keys();
      await Promise.all(names.map((n) => caches.delete(n)));
    } catch (_) {}
    await self.clients.claim();
  })());
});

self.addEventListener('fetch', (event) => {
  // Pure pass-through — do not call respondWith so the browser handles it normally.
});
