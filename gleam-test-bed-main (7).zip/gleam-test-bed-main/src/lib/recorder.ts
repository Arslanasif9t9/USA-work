/**
 * MediaRecorder wrapper (PLAN.md §2, §5).
 *
 * Records the real microphone audio for the whole session and returns ONE
 * audio Blob (audio/webm;codecs=opus when supported) on stop. This is the
 * source of truth — there is deliberately NO live Web Speech / SpeechRecognition
 * here, because that approach dropped audio in the prototype.
 *
 * Phase 4 will send the returned Blob to Gemini for transcription.
 */

/** Thrown when the user denies (or the browser blocks) microphone access. */
export class MicPermissionError extends Error {
  constructor(message: string) {
    super(message)
    this.name = 'MicPermissionError'
  }
}

/** Picks the best supported audio mime type, preferring Opus in WebM. */
export function pickMimeType(): string {
  if (typeof MediaRecorder === 'undefined') return ''
  const candidates = [
    'audio/webm;codecs=opus',
    'audio/webm',
    'audio/ogg;codecs=opus',
  ]
  for (const type of candidates) {
    if (MediaRecorder.isTypeSupported(type)) return type
  }
  return '' // let the browser choose its default
}

export class AudioRecorder {
  private recorder: MediaRecorder | null = null
  private stream: MediaStream | null = null
  private chunks: Blob[] = []
  private mimeType = ''

  // Web Audio bits for the mic-level meter (visual feedback only).
  private audioCtx: AudioContext | null = null
  private analyser: AnalyserNode | null = null
  private levelBuffer: Uint8Array<ArrayBuffer> | null = null

  /** Requests mic access and begins recording. */
  async start(): Promise<void> {
    try {
      this.stream = await navigator.mediaDevices.getUserMedia({ audio: true })
    } catch (err) {
      const name = (err as DOMException)?.name
      if (name === 'NotAllowedError' || name === 'SecurityError') {
        throw new MicPermissionError(
          'Microphone access was blocked. Please allow microphone access in your browser and try again.',
        )
      }
      if (name === 'NotFoundError' || name === 'DevicesNotFoundError') {
        throw new MicPermissionError(
          'No microphone was found. Please connect a microphone and try again.',
        )
      }
      throw new MicPermissionError(
        'Could not access the microphone. Please check your device and try again.',
      )
    }

    this.mimeType = pickMimeType()
    this.recorder = new MediaRecorder(
      this.stream,
      this.mimeType ? { mimeType: this.mimeType } : undefined,
    )
    this.chunks = []
    this.recorder.ondataavailable = (e) => {
      if (e.data && e.data.size > 0) this.chunks.push(e.data)
    }
    // Timeslice keeps data flowing so nothing is lost on a long recording.
    this.recorder.start(1000)

    this.setupLevelMeter()
  }

  pause(): void {
    if (this.recorder?.state === 'recording') this.recorder.pause()
  }

  resume(): void {
    if (this.recorder?.state === 'paused') this.recorder.resume()
  }

  /** Stops recording and resolves with the complete audio Blob. */
  stop(): Promise<Blob> {
    return new Promise((resolve, reject) => {
      const rec = this.recorder
      if (!rec) {
        reject(new Error('Recorder is not active.'))
        return
      }
      rec.onstop = () => {
        const blob = new Blob(this.chunks, {
          type: this.mimeType || 'audio/webm',
        })
        this.cleanup()
        resolve(blob)
      }
      rec.requestData()
      rec.stop()
    })
  }

  /** Returns a normalized mic level (0..1) for visual feedback. */
  getLevel(): number {
    if (!this.analyser || !this.levelBuffer) return 0
    this.analyser.getByteTimeDomainData(this.levelBuffer)
    let sumSquares = 0
    for (let i = 0; i < this.levelBuffer.length; i++) {
      const v = (this.levelBuffer[i] - 128) / 128 // center on 0
      sumSquares += v * v
    }
    const rms = Math.sqrt(sumSquares / this.levelBuffer.length)
    return Math.min(1, rms * 2.5) // scale up so normal speech reads well
  }

  /** Releases the mic and tears everything down. Safe to call repeatedly. */
  dispose(): void {
    if (this.recorder && this.recorder.state !== 'inactive') {
      try {
        this.recorder.stop()
      } catch {
        /* ignore */
      }
    }
    this.cleanup()
  }

  private setupLevelMeter(): void {
    if (!this.stream) return
    try {
      const Ctx =
        window.AudioContext ||
        (window as unknown as { webkitAudioContext: typeof AudioContext })
          .webkitAudioContext
      this.audioCtx = new Ctx()
      const source = this.audioCtx.createMediaStreamSource(this.stream)
      this.analyser = this.audioCtx.createAnalyser()
      this.analyser.fftSize = 512
      this.levelBuffer = new Uint8Array(new ArrayBuffer(this.analyser.fftSize))
      source.connect(this.analyser)
    } catch {
      // Level meter is non-essential; recording still works without it.
      this.analyser = null
    }
  }

  private cleanup(): void {
    this.stream?.getTracks().forEach((t) => t.stop())
    this.stream = null
    this.recorder = null
    if (this.audioCtx) {
      void this.audioCtx.close().catch(() => {})
      this.audioCtx = null
    }
    this.analyser = null
    this.levelBuffer = null
  }
}
