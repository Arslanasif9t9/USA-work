import { supabase, SUPABASE_URL, SUPABASE_PUBLISHABLE_KEY } from './supabase'

const FUNCTIONS_BASE = `${SUPABASE_URL}/functions/v1`
const ANON_KEY = SUPABASE_PUBLISHABLE_KEY

/**
 * Sends the full recorded audio to the `transcribe` Edge Function and returns
 * the complete transcript. Gemini runs server-side (the key never reaches the
 * browser). The audio is uploaded for this request only and is never stored.
 */
export async function transcribeAudio(
  blob: Blob,
  model?: string,
): Promise<string> {
  const {
    data: { session },
  } = await supabase.auth.getSession()
  if (!session) throw new Error('You are not signed in.')

  const form = new FormData()
  form.append('audio', blob, 'recording.webm')
  if (model) form.append('model', model)

  const res = await fetch(`${FUNCTIONS_BASE}/transcribe`, {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${session.access_token}`,
      apikey: ANON_KEY,
      // Note: do NOT set Content-Type for FormData — the browser adds the
      // multipart boundary automatically.
    },
    body: form,
  })

  const data = await res.json().catch(() => ({}))
  if (!res.ok) {
    throw new Error(data?.error || `Transcription failed (${res.status}).`)
  }
  if (!data?.transcript) {
    throw new Error('No transcript was returned.')
  }
  return data.transcript as string
}

export interface SummaryResult {
  title: string
  summary: string
}

/**
 * Sends the transcript to the `summarize` Edge Function and returns the
 * worker-facing { title, summary }. A custom `instruction` overrides the
 * default bullet format (used by Regenerate).
 */
export async function summarizeTranscript(
  transcript: string,
  instruction?: string,
  model?: string,
): Promise<SummaryResult> {
  const {
    data: { session },
  } = await supabase.auth.getSession()
  if (!session) throw new Error('You are not signed in.')

  const res = await fetch(`${FUNCTIONS_BASE}/summarize`, {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${session.access_token}`,
      apikey: ANON_KEY,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      transcript,
      instruction: instruction || undefined,
      model: model || undefined,
    }),
  })

  const data = await res.json().catch(() => ({}))
  if (!res.ok) {
    throw new Error(data?.error || `Summary failed (${res.status}).`)
  }
  if (!data?.summary) {
    throw new Error('No summary was returned.')
  }
  return { title: data.title ?? '', summary: data.summary as string }
}

export type AiProvider = 'groq' | 'gemini'

export interface AiKeyStatus {
  groq: boolean
  gemini: boolean
}

/**
 * Reports which provider keys are configured server-side (Groq primary, Gemini
 * fallback). Never returns the key values themselves (write-only design).
 */
export async function getAiKeyStatus(): Promise<AiKeyStatus> {
  const {
    data: { session },
  } = await supabase.auth.getSession()
  if (!session) throw new Error('You are not signed in.')

  const res = await fetch(`${FUNCTIONS_BASE}/set-ai-key`, {
    headers: {
      Authorization: `Bearer ${session.access_token}`,
      apikey: ANON_KEY,
    },
  })
  const data = await res.json().catch(() => ({}))
  if (!res.ok) throw new Error(data?.error || `Request failed (${res.status}).`)
  return { groq: Boolean(data.groq), gemini: Boolean(data.gemini) }
}

/**
 * Sends a pasted provider API key to the server, which stores it as the
 * GROQ_API_KEY / GEMINI_API_KEY secret. The key never touches the database or
 * the frontend bundle.
 */
export async function setAiKey(provider: AiProvider, key: string): Promise<void> {
  const {
    data: { session },
  } = await supabase.auth.getSession()
  if (!session) throw new Error('You are not signed in.')

  const res = await fetch(`${FUNCTIONS_BASE}/set-ai-key`, {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${session.access_token}`,
      apikey: ANON_KEY,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({ provider, key }),
  })
  const data = await res.json().catch(() => ({}))
  if (!res.ok) throw new Error(data?.error || `Could not save the key (${res.status}).`)
}
