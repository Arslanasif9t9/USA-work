// Lovable Cloud Supabase client.
//
// We build the client here (instead of re-exporting the auto-generated
// `src/integrations/supabase/client.ts`) so the published production bundle
// keeps working even when Vite's import.meta.env.VITE_SUPABASE_* values are
// not inlined at build time. The publishable/anon key is intentionally public
// (it only grants what RLS allows), so shipping it as a fallback constant is
// safe and matches what Cloud injects into the preview.
import { createClient } from '@supabase/supabase-js'
import type { Database } from '../integrations/supabase/types'

const FALLBACK_URL = 'https://klsugocuvvsjufrxzwnf.supabase.co'
const FALLBACK_PUBLISHABLE_KEY =
  'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Imtsc3Vnb2N1dnZzanVmcnh6d25mIiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODIwMjcxOTUsImV4cCI6MjA5NzYwMzE5NX0.N2GL6Wc5O4Xrpp8gJuJxbe7xM0C2qgcHBbsO8zn89Sc'

export const SUPABASE_URL =
  (import.meta.env.VITE_SUPABASE_URL as string | undefined) || FALLBACK_URL
export const SUPABASE_PUBLISHABLE_KEY =
  (import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY as string | undefined) ||
  (import.meta.env.VITE_SUPABASE_ANON_KEY as string | undefined) ||
  FALLBACK_PUBLISHABLE_KEY

export const supabase = createClient<Database>(
  SUPABASE_URL,
  SUPABASE_PUBLISHABLE_KEY,
  {
    auth: {
      storage: typeof window !== 'undefined' ? window.localStorage : undefined,
      persistSession: true,
      autoRefreshToken: true,
    },
  },
)
