/**
 * Ready-to-paste instruction for any other AI, used by the fallback when our
 * own summarize call fails (§ Phase 9 fallback). Prefixes the transcript so the
 * user can get a worker-facing summary elsewhere.
 */
export const SUMMARY_PROMPT_PREFIX =
  'Summarize this meeting into a worker-facing task list — what to do, details, deadlines, things said only once. Reply in English, or Roman Urdu if the meeting was in Urdu; never use Nastaliq script. Transcript:'

/** Builds the transcript prefixed with the ready-to-use summary instruction. */
export function transcriptWithPrompt(transcript: string): string {
  return `${SUMMARY_PROMPT_PREFIX}\n\n${transcript}`
}

/** Copies text to the clipboard. Returns true on success. */
export async function copyText(text: string): Promise<boolean> {
  try {
    await navigator.clipboard.writeText(text)
    return true
  } catch {
    // Fallback for older/insecure contexts.
    try {
      const ta = document.createElement('textarea')
      ta.value = text
      ta.style.position = 'fixed'
      ta.style.opacity = '0'
      document.body.appendChild(ta)
      ta.select()
      const ok = document.execCommand('copy')
      document.body.removeChild(ta)
      return ok
    } catch {
      return false
    }
  }
}

/** Makes a safe-ish filename base from a title. */
function safeName(title: string): string {
  const base = title.trim().replace(/[^\w\d -]+/g, '').replace(/\s+/g, '-')
  return base || 'eia-summary'
}

function triggerDownload(blob: Blob, filename: string) {
  const url = URL.createObjectURL(blob)
  const a = document.createElement('a')
  a.href = url
  a.download = filename
  document.body.appendChild(a)
  a.click()
  document.body.removeChild(a)
  URL.revokeObjectURL(url)
}

/** Downloads the summary as a .txt file. */
export function downloadTxt(title: string, summary: string) {
  const body = title ? `${title}\n\n${summary}\n` : `${summary}\n`
  triggerDownload(new Blob([body], { type: 'text/plain;charset=utf-8' }), `${safeName(title)}.txt`)
}

/** Downloads the summary as a PDF (title heading + wrapped body).
 *  jsPDF is imported lazily so it stays out of the initial bundle. */
export async function downloadPdf(title: string, summary: string) {
  const { jsPDF } = await import('jspdf')
  const doc = new jsPDF({ unit: 'pt', format: 'a4' })
  const margin = 56
  const pageWidth = doc.internal.pageSize.getWidth()
  const pageHeight = doc.internal.pageSize.getHeight()
  const maxWidth = pageWidth - margin * 2
  let y = margin

  if (title) {
    doc.setFont('helvetica', 'bold')
    doc.setFontSize(18)
    for (const line of doc.splitTextToSize(title, maxWidth)) {
      doc.text(line, margin, y)
      y += 24
    }
    y += 8
  }

  doc.setFont('helvetica', 'normal')
  doc.setFontSize(12)
  const lineHeight = 17
  const lines = doc.splitTextToSize(summary, maxWidth)
  for (const line of lines) {
    if (y > pageHeight - margin) {
      doc.addPage()
      y = margin
    }
    doc.text(line, margin, y)
    y += lineHeight
  }

  doc.save(`${safeName(title)}.pdf`)
}

/** mailto: URL prefilled with the title as subject and summary as body. */
export function mailtoUrl(title: string, summary: string): string {
  const subject = encodeURIComponent(title || 'Meeting summary')
  const body = encodeURIComponent(summary)
  return `mailto:?subject=${subject}&body=${body}`
}

/** wa.me URL prefilled with the title + summary. */
export function whatsappUrl(title: string, summary: string): string {
  const text = encodeURIComponent(title ? `${title}\n\n${summary}` : summary)
  return `https://wa.me/?text=${text}`
}
