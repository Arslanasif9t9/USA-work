import { supabase } from './supabase'

export interface MeetingInput {
  title: string
  summary: string
  transcript: string
  durationSec: number
  wordCount: number
  /** Retention window in days; used to compute expires_at on insert. */
  retentionDays?: number
  /** Optional browser-side live caption text (Web Speech), display-derived. */
  liveCaption?: string
}

/**
 * Inserts a meeting row (PLAN.md §6) and returns its id. Audio is never stored
 * — only the transcript + summary. expires_at is set from the retention window
 * so the 3-day (configurable) auto-delete applies.
 */
export async function createMeeting(
  userId: string,
  m: MeetingInput,
): Promise<string> {
  const expiresAt =
    m.retentionDays && m.retentionDays > 0
      ? new Date(Date.now() + m.retentionDays * 86400000).toISOString()
      : undefined

  const { data, error } = await supabase
    .from('meetings')
    .insert({
      user_id: userId,
      title: m.title,
      summary: m.summary,
      transcript: m.transcript,
      duration_sec: m.durationSec,
      word_count: m.wordCount,
      live_caption: m.liveCaption ?? null,
      ...(expiresAt ? { expires_at: expiresAt } : {}),
    })
    .select('id')
    .single()

  if (error) throw new Error(error.message)
  return data.id as string
}

/** Updates an existing meeting's editable fields. RLS scopes to owner. */
export async function updateMeeting(
  id: string,
  fields: {
    title?: string
    summary?: string
    transcript?: string
    live_caption?: string
    duration_sec?: number
    word_count?: number
  },
): Promise<void> {
  const { error } = await supabase.from('meetings').update(fields).eq('id', id)
  if (error) throw new Error(error.message)
}

export interface MeetingRow {
  id: string
  title: string
  summary: string
  duration_sec: number
  word_count: number
  created_at: string
  expires_at: string
  transcript?: string | null
  live_caption?: string | null
}

/**
 * Lists the user's non-expired meetings, newest first (PLAN.md §4/§6).
 * RLS already scopes to the current user; the expires_at filter ensures
 * nothing expired is shown between hourly pg_cron purges.
 */
export async function listMeetings(userId: string): Promise<MeetingRow[]> {
  const { data, error } = await supabase
    .from('meetings')
    .select('id, title, summary, duration_sec, word_count, created_at, expires_at, transcript, live_caption')
    .eq('user_id', userId)
    .gt('expires_at', new Date().toISOString())
    .order('created_at', { ascending: false })

  if (error) throw new Error(error.message)
  return (data ?? []) as MeetingRow[]
}

/** Hard-deletes a meeting row (RLS restricts this to the owner). */
export async function deleteMeeting(id: string): Promise<void> {
  const { error } = await supabase.from('meetings').delete().eq('id', id)
  if (error) throw new Error(error.message)
}

/** Hard-deletes multiple meeting rows in one request. RLS restricts to owner. */
export async function deleteMeetings(ids: string[]): Promise<void> {
  if (ids.length === 0) return
  const { error } = await supabase.from('meetings').delete().in('id', ids)
  if (error) throw new Error(error.message)
}

/** Hard-deletes every meeting belonging to the given user. RLS double-scopes. */
export async function deleteAllMeetings(userId: string): Promise<void> {
  const { error } = await supabase
    .from('meetings')
    .delete()
    .eq('user_id', userId)
  if (error) throw new Error(error.message)
}

/** Admin-only: reassign a meeting to one of the two preset target accounts. */
export const REASSIGN_TARGETS = [
  { id: 'dc60bcbd-df90-49f1-8571-e876adf78d61', label: 'Meeting account' },
  { id: 'b4039103-1c1f-4c29-a48f-b60e312dd856', label: 'Developer account' },
] as const

export async function adminReassignMeeting(
  meetingId: string,
  targetUserId: string,
): Promise<void> {
  const { error } = await supabase.rpc('admin_reassign_meeting', {
    p_meeting_id: meetingId,
    p_target_user_id: targetUserId,
  })
  if (error) throw new Error(error.message)
}

/** Admin-only row returned by admin_list_all_meetings (every user's rows). */
export interface AdminMeetingRow extends MeetingRow {
  user_id: string
  owner_username: string
  uploaded_by?: string | null
}

/** Admin-only: list EVERY meeting in the database with the owner's username. */
export async function adminListAllMeetings(): Promise<AdminMeetingRow[]> {
  const { data, error } = await supabase.rpc('admin_list_all_meetings')
  if (error) throw new Error(error.message)
  return (data ?? []) as AdminMeetingRow[]
}

/** Admin-only: hard-delete any meeting, regardless of owner (bypasses RLS). */
export async function adminDeleteMeeting(id: string): Promise<void> {
  const { error } = await supabase.rpc('admin_delete_meeting', {
    p_meeting_id: id,
  })
  if (error) throw new Error(error.message)
}

/** Admin-only: hard-delete many meetings, regardless of owner. */
export async function adminDeleteMeetings(ids: string[]): Promise<void> {
  if (ids.length === 0) return
  const { error } = await supabase.rpc('admin_delete_meetings', { p_ids: ids })
  if (error) throw new Error(error.message)
}

/** Admin-only: wipe EVERY meeting in the database (all users). */
export async function adminDeleteAllMeetings(): Promise<void> {
  const { error } = await supabase.rpc('admin_delete_all_meetings')
  if (error) throw new Error(error.message)
}
