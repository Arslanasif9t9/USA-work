import { supabase } from './supabase'

export const COMPANY_DEFAULT = 'EIA — Intuitive Expert Advisor Inc.'
// Groq is the primary engine; this is the Gemini FALLBACK model. Default
// stays gemini-2.5-flash-lite.
export const DEFAULT_MODEL = 'gemini-2.5-flash-lite'
export const DEFAULT_MAX_MINUTES = 30
export const DEFAULT_RETENTION_DAYS = 3

/** Selectable Gemini fallback models (PLAN.md §5/§7). */
export const AI_MODELS = [
  'gemini-2.5-flash-lite',
  'gemini-2.5-flash',
  'gemini-3.5-flash',
] as const

export interface ProfileSettings {
  ai_model: string
  max_minutes: number
  retention_days: number
  default_prompt: string
  company: string
}

/** Loads the current profile's settings (PLAN.md §7). */
export async function getProfileSettings(userId: string): Promise<ProfileSettings> {
  const { data, error } = await supabase
    .from('profiles')
    .select('ai_model, max_minutes, retention_days, default_prompt, company')
    .eq('id', userId)
    .single()

  if (error) throw new Error(error.message)
  return {
    ai_model: data.ai_model ?? DEFAULT_MODEL,
    max_minutes: data.max_minutes ?? DEFAULT_MAX_MINUTES,
    retention_days: data.retention_days ?? DEFAULT_RETENTION_DAYS,
    default_prompt: data.default_prompt ?? '',
    company: data.company ?? COMPANY_DEFAULT,
  }
}

/** Persists the Settings fields back to the profile. */
export async function updateProfileSettings(
  userId: string,
  s: ProfileSettings,
): Promise<void> {
  const { error } = await supabase
    .from('profiles')
    .update({
      ai_model: s.ai_model,
      max_minutes: s.max_minutes,
      retention_days: s.retention_days,
      default_prompt: s.default_prompt,
      company: s.company,
    })
    .eq('id', userId)

  if (error) throw new Error(error.message)
}
