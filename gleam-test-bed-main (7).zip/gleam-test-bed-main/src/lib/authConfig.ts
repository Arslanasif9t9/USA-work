/**
 * Single fixed login (no public sign-up).
 *
 * Supabase Auth requires an email, so the Landing form shows a "Username"
 * field and we map the username to a fixed internal email behind the scenes.
 * Only the "admin" user exists — create it once in the Supabase dashboard
 * (Authentication → Users → Add user) with this email + password.
 */
const INTERNAL_EMAIL_DOMAIN = 'eia.local'

/** The admin user's internal email. Only this account can access Settings. */
export const ADMIN_EMAIL = 'admin@eia.local'

/** Maps a typed username (e.g. "admin") to its internal Supabase email. */
export function usernameToEmail(username: string): string {
  return `${username.trim().toLowerCase()}@${INTERNAL_EMAIL_DOMAIN}`
}
