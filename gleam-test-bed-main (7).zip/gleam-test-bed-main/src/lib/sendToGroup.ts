import { supabase, SUPABASE_URL, SUPABASE_PUBLISHABLE_KEY } from './supabase'

const FUNCTIONS_BASE = `${SUPABASE_URL}/functions/v1`
const ANON_KEY = SUPABASE_PUBLISHABLE_KEY

export interface PmsGroup {
  id: string
  name: string
  color?: string
}

export interface CreatedTask {
  task_id: string
  task_code: string
}

/** POSTs to the send-to-group Edge Function with the user's session token. */
async function callBridge(payload: Record<string, unknown>): Promise<any> {
  const {
    data: { session },
  } = await supabase.auth.getSession()
  if (!session) throw new Error('You are not signed in.')

  const res = await fetch(`${FUNCTIONS_BASE}/send-to-group`, {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${session.access_token}`,
      apikey: ANON_KEY,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(payload),
  })
  const data = await res.json().catch(() => ({}))
  if (!res.ok || data?.ok === false) {
    throw new Error(data?.error || `Request failed (${res.status}).`)
  }
  return data
}

/** Lists the PMS Tessera groups for the picker (server-side via the bridge). */
export async function listGroups(): Promise<PmsGroup[]> {
  const data = await callBridge({ action: 'list' })
  return (data.groups ?? []) as PmsGroup[]
}

/** Creates a task in the chosen PMS group: name = title, body = summary. */
export async function sendToGroup(
  groupId: string,
  name: string,
  body: string,
): Promise<CreatedTask> {
  const data = await callBridge({
    action: 'create',
    group_id: groupId,
    name,
    body,
  })
  return { task_id: data.task_id, task_code: data.task_code }
}
