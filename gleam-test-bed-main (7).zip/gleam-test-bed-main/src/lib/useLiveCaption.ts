import { useCallback, useEffect, useRef, useState } from 'react'

/**
 * Live on-screen caption via the browser's Web Speech API — DISPLAY ONLY.
 *
 * This is deliberately separate from the audio recording. Its text is ephemeral
 * and must NEVER be saved, summarized, or treated as the real transcript: the
 * source of truth stays the full-audio → Groq result. Web Speech alone drops
 * words on long sessions, which is exactly why it is not the saved transcript.
 *
 * The hook never touches the recorder, the audio Blob, ai.ts, the transcribe
 * function, transcript state, or createMeeting.
 */

type SpeechRecognitionLike = {
  continuous: boolean
  interimResults: boolean
  lang: string
  onresult: ((e: any) => void) | null
  onerror: ((e: any) => void) | null
  onend: (() => void) | null
  onstart: (() => void) | null
  start: () => void
  stop: () => void
  abort: () => void
}

function getCtor(): (new () => SpeechRecognitionLike) | null {
  if (typeof window === 'undefined') return null
  const w = window as unknown as {
    SpeechRecognition?: new () => SpeechRecognitionLike
    webkitSpeechRecognition?: new () => SpeechRecognitionLike
  }
  return w.SpeechRecognition ?? w.webkitSpeechRecognition ?? null
}

export type LiveCaptionStatus = 'idle' | 'listening' | 'paused' | 'denied'

export function useLiveCaption() {
  const supported = useRef(getCtor() != null).current
  const [liveText, setLiveText] = useState('')
  const [status, setStatus] = useState<LiveCaptionStatus>('idle')
  const recRef = useRef<SpeechRecognitionLike | null>(null)
  const activeRef = useRef(false) // true while we want it listening
  const finalRef = useRef('') // accumulated finalized text (persists across relaunches)
  const interimRef = useRef('') // current (not-yet-final) text
  const restartTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null)

  const render = () =>
    setLiveText(`${finalRef.current} ${interimRef.current}`.trim())

  const clearRestartTimer = () => {
    if (restartTimerRef.current != null) {
      clearTimeout(restartTimerRef.current)
      restartTimerRef.current = null
    }
  }

  // Single guarded relaunch path. Always clears the existing timer first so
  // overlapping onerror + onend events can't stack two pending relaunches.
  const scheduleRelaunch = useCallback(() => {
    clearRestartTimer()
    if (activeRef.current) setStatus('paused')
    restartTimerRef.current = setTimeout(() => {
      restartTimerRef.current = null
      if (activeRef.current) launch()
    }, 400)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  // Creates a fresh recognition instance and starts it. Web Speech ends itself
  // periodically (silence/timeouts), so onend relaunches while still active.
  const launch = useCallback(() => {
    const Ctor = getCtor()
    if (!Ctor) return
    let rec: SpeechRecognitionLike
    try {
      rec = new Ctor()
    } catch {
      return
    }
    rec.continuous = true
    rec.interimResults = true
    // Lock to en-US: handles English + most code-switched speech on Chrome's
    // engine. Leaving lang unset previously caused locale drift.
    rec.lang = 'en-US'
    rec.onstart = () => {
      if (activeRef.current) setStatus('listening')
    }
    rec.onresult = (e: any) => {
      let interim = ''
      for (let i = e.resultIndex; i < e.results.length; i++) {
        const seg = e.results[i]
        const text = seg?.[0]?.transcript ?? ''
        // Append finalized segments (with a separating space) so words don't
        // run together; keep interim separate so it can be flushed on restart.
        if (seg?.isFinal) finalRef.current = `${finalRef.current} ${text}`.trim()
        else interim += text
      }
      interimRef.current = interim
      render()
    }
    rec.onerror = (e: any) => {
      const code = e?.error
      // ONLY a real permanent denial kills the session. Everything else
      // ('service-not-allowed', 'no-speech', 'audio-capture', 'network',
      // 'aborted') is transient — mic contention with MediaRecorder, brief
      // silence, flaky network — self-heal directly rather than relying on
      // onend, which the browser may never fire after some errors.
      if (code === 'not-allowed') {
        activeRef.current = false
        setStatus('denied')
        return
      }
      if (activeRef.current) {
        setStatus('paused')
        scheduleRelaunch()
      }
    }
    rec.onend = () => {
      // Orphan-race guard: only clear recRef if it still points at THIS
      // instance. A stale onend firing after a newer rec was assigned must
      // not null out the live engine.
      if (recRef.current === rec) recRef.current = null
      // Preserve any pending interim across the restart so it never vanishes.
      // finalRef intentionally persists across relaunches for the whole
      // session — only reset() clears it.
      if (interimRef.current) {
        finalRef.current = `${finalRef.current} ${interimRef.current}`.trim()
        interimRef.current = ''
        render()
      }
      if (!activeRef.current) return
      scheduleRelaunch()
    }
    recRef.current = rec
    try {
      rec.start()
    } catch {
      // start() can throw if a previous instance is still ending. Don't
      // dead-end: drop this instance and reschedule so we always recover.
      if (recRef.current === rec) recRef.current = null
      if (activeRef.current) scheduleRelaunch()
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [scheduleRelaunch])


  const start = useCallback(() => {
    if (!getCtor()) return
    activeRef.current = true
    setStatus('paused') // will flip to 'listening' on rec.onstart
    if (!recRef.current) launch()
  }, [launch])

  const stop = useCallback(() => {
    activeRef.current = false
    clearRestartTimer()
    const rec = recRef.current
    recRef.current = null
    if (rec) {
      try {
        rec.stop()
      } catch {
        /* ignore */
      }
    }
    setStatus('idle')
  }, [])

  const reset = useCallback(() => {
    finalRef.current = ''
    interimRef.current = ''
    setLiveText('')
    if (!activeRef.current) setStatus('idle')
  }, [])

  // Tear down on unmount.
  useEffect(() => {
    return () => {
      activeRef.current = false
      clearRestartTimer()
      const rec = recRef.current
      recRef.current = null
      if (rec) {
        try {
          rec.abort()
        } catch {
          /* ignore */
        }
      }
    }
  }, [])

  return { liveText, supported, status, start, stop, reset }
}
