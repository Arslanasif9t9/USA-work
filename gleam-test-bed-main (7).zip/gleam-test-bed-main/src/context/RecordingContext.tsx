import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useRef,
  useState,
  type ReactNode,
  type RefObject,
} from 'react'
import { AudioRecorder, MicPermissionError } from '../lib/recorder'
import { transcribeAudio } from '../lib/ai'
import { createMeeting, updateMeeting } from '../lib/meetings'
import { useLiveCaption, type LiveCaptionStatus } from '../lib/useLiveCaption'
import { useAuth } from './AuthContext'
import { supabase } from '../lib/supabase'
import type { RecordState } from '../components/RecordButton'

const DEFAULT_MAX_MINUTES = 30

function countWords(text: string): number {
  return text.trim().split(/\s+/).filter(Boolean).length
}

interface RecordingContextValue {
  // Recording state
  state: RecordState
  elapsed: number
  level: number
  error: string | null
  maxMinutes: number
  capSeconds: number

  // Live caption (Web Speech, display-only)
  liveText: string
  liveStatus: LiveCaptionStatus
  liveSupported: boolean
  liveBoxRef: RefObject<HTMLDivElement>


  // Post-stop transcript (Groq Whisper)
  transcript: string | null
  transcribing: boolean
  transcribeError: string | null
  audioBlob: Blob | null

  // Meeting row id (created at recording start)
  meetingId: string | null

  // Settings cache exposed for consumers
  retentionDays: number
  defaultPrompt: string
  model: string | undefined

  // Actions
  start: () => Promise<void>
  pause: () => void
  resume: () => void
  stop: () => Promise<void>
  retryTranscription: (blob: Blob) => Promise<void>
  /** Clears post-stop transcript/blob/meeting refs so the next session is fresh. */
  resetPostStop: () => void
}

const RecordingContext = createContext<RecordingContextValue | undefined>(
  undefined,
)

export function RecordingProvider({ children }: { children: ReactNode }) {
  const { user, isAdmin } = useAuth()

  // ---- Live caption (Web Speech, display-only) ----
  const live = useLiveCaption()
  const liveBoxRef = useRef<HTMLDivElement>(null)
  const liveTextRef = useRef('')
  useEffect(() => {
    liveTextRef.current = live.liveText
    const el = liveBoxRef.current
    if (el) el.scrollTop = el.scrollHeight
  }, [live.liveText])

  // ---- Recording state ----
  const [maxMinutes, setMaxMinutes] = useState(DEFAULT_MAX_MINUTES)
  const [retentionDays, setRetentionDays] = useState(3)
  const [state, setState] = useState<RecordState>('idle')
  const [elapsed, setElapsed] = useState(0)
  const [level, setLevel] = useState(0)
  const [error, setError] = useState<string | null>(null)

  // ---- Post-stop ----
  const [audioBlob, setAudioBlob] = useState<Blob | null>(null)
  const [transcript, setTranscript] = useState<string | null>(null)
  const [transcribing, setTranscribing] = useState(false)
  const [transcribeError, setTranscribeError] = useState<string | null>(null)
  const [meetingId, setMeetingId] = useState<string | null>(null)

  // ---- Refs ----
  const recorderRef = useRef<AudioRecorder | null>(null)
  const elapsedMsRef = useRef(0)
  const lastTickRef = useRef(0)
  const tickRef = useRef<number | null>(null)
  const saveIntervalRef = useRef<ReturnType<typeof setInterval> | null>(null)
  const beaconFiredRef = useRef(false)
  const accessTokenRef = useRef<string | null>(null)
  const stateRef = useRef<RecordState>('idle')
  stateRef.current = state

  const meetingIdRef = useRef<string | null>(null)
  const transcriptRef = useRef('')
  const durationRef = useRef(0)

  const defaultPromptRef = useRef('')
  const modelRef = useRef<string | undefined>(undefined)
  const [defaultPrompt, setDefaultPrompt] = useState('')
  const [model, setModel] = useState<string | undefined>(undefined)

  const capSeconds = maxMinutes * 60
  const capSecondsRef = useRef(capSeconds)
  capSecondsRef.current = capSeconds

  // ---- Load Settings (same logic as Recorder.tsx had) ----
  useEffect(() => {
    if (!user) return
    const apply = (data: {
      max_minutes?: number | null
      retention_days?: number | null
      default_prompt?: string | null
      ai_model?: string | null
    } | null) => {
      if (!data) return
      if (data.max_minutes) setMaxMinutes(data.max_minutes)
      if (data.retention_days) setRetentionDays(data.retention_days)
      defaultPromptRef.current = data.default_prompt ?? ''
      modelRef.current = data.ai_model ?? undefined
      setDefaultPrompt(defaultPromptRef.current)
      setModel(modelRef.current)
    }
    if (isAdmin) {
      supabase
        .from('profiles')
        .select('max_minutes, retention_days, default_prompt, ai_model')
        .eq('id', user.id)
        .single()
        .then(({ data }) => apply(data))
    } else {
      supabase.rpc('get_admin_profile').then(({ data }) => {
        const row = Array.isArray(data) ? data[0] : data
        apply(row ?? null)
      })
    }
  }, [user, isAdmin])

  const stopTicking = useCallback(() => {
    if (tickRef.current !== null) {
      cancelAnimationFrame(tickRef.current)
      tickRef.current = null
    }
  }, [])

  // Forward declare stop so tick can call it for auto-cap.
  const stopRef = useRef<() => Promise<void>>(async () => {})

  const tick = useCallback(() => {
    const now = performance.now()
    const delta = now - lastTickRef.current
    lastTickRef.current = now

    if (stateRef.current === 'recording') {
      elapsedMsRef.current += delta
      const secs = elapsedMsRef.current / 1000
      setElapsed(secs)
      setLevel(recorderRef.current?.getLevel() ?? 0)

      if (secs >= capSecondsRef.current) {
        void stopRef.current()
        return
      }
    }
    tickRef.current = requestAnimationFrame(tick)
  }, [])

  // ---- Groq Whisper transcribe + update existing row (lifted verbatim) ----
  const runTranscription = useCallback(async (blob: Blob) => {
    setTranscribeError(null)
    setTranscript(null)
    setTranscribing(true)
    try {
      const text = await transcribeAudio(blob, modelRef.current)
      setTranscript(text)
      transcriptRef.current = text
      durationRef.current = Math.round(elapsedMsRef.current / 1000)
      // Persist transcript onto the row created at recording start.
      // Summary is NOT auto-generated — gated behind the Get Summary button.
      if (meetingIdRef.current) {
        try {
          await updateMeeting(meetingIdRef.current, {
            transcript: transcriptRef.current,
            duration_sec: durationRef.current,
            word_count: countWords(transcriptRef.current),
            live_caption: liveTextRef.current,
          })
        } catch (e) {
          console.error('[recorder] failed to persist transcript', e)
        }
      }
    } catch (e) {
      setTranscribeError(
        e instanceof Error ? e.message : 'Transcription failed. Please try again.',
      )
    } finally {
      setTranscribing(false)
    }
  }, [])

  // ---- Actions ----
  // start() — iOS-safe: recorder.start() runs synchronously from the click,
  // NO await before it. createMeeting runs LAST, after mic + rAF + setState.
  const start = useCallback(async () => {
    if (stateRef.current !== 'idle') return // idempotent / Strict-mode safe
    setError(null)
    const recorder = new AudioRecorder()
    try {
      await recorder.start()
    } catch (err) {
      if (err instanceof MicPermissionError) setError(err.message)
      else setError('Could not start recording. Please try again.')
      recorder.dispose()
      return
    }
    recorderRef.current = recorder
    elapsedMsRef.current = 0
    lastTickRef.current = performance.now()
    setElapsed(0)
    // Reset post-stop state for the new session.
    setAudioBlob(null)
    setTranscript(null)
    setTranscribeError(null)
    transcriptRef.current = ''
    durationRef.current = 0
    meetingIdRef.current = null
    setMeetingId(null)
    live.reset()
    live.start()
    setState('recording')
    stateRef.current = 'recording'
    tickRef.current = requestAnimationFrame(tick)
    beaconFiredRef.current = false

    // 30s autosave of the live caption to the existing meeting row. Guarded so
    // it only fires while a session is active and a row id exists. Keeps
    // firing through PAUSE on purpose (harmless re-write; protects a crash-
    // while-paused). Cleared in stop() and on provider unmount, NOT on pause.
    if (saveIntervalRef.current !== null) {
      clearInterval(saveIntervalRef.current)
      saveIntervalRef.current = null
    }
    saveIntervalRef.current = setInterval(() => {
      if (
        stateRef.current !== 'idle' &&
        meetingIdRef.current &&
        liveTextRef.current
      ) {
        updateMeeting(meetingIdRef.current, {
          live_caption: liveTextRef.current,
        }).catch((e) =>
          console.error('[recorder] periodic live_caption save failed', e),
        )
      }
    }, 30000)

    // Create the meeting row immediately so the live session has a stable id
    // for incremental writes. DB call comes LAST, after mic + state flip.
    if (user && !meetingIdRef.current) {
      try {
        const id = await createMeeting(user.id, {
          title: '',
          summary: '',
          transcript: '',
          durationSec: 0,
          wordCount: 0,
          retentionDays,
          liveCaption: '',
        })
        meetingIdRef.current = id
        setMeetingId(id)
      } catch (e) {
        console.error('[recorder] failed to create meeting row at start', e)
      }
    }
  }, [live, retentionDays, tick, user])

  const pause = useCallback(() => {
    recorderRef.current?.pause()
    live.stop()
    setState('paused')
    stateRef.current = 'paused'
    setLevel(0)
  }, [live])

  const resume = useCallback(() => {
    recorderRef.current?.resume()
    live.start()
    lastTickRef.current = performance.now()
    setState('recording')
    stateRef.current = 'recording'
  }, [live])

  const stop = useCallback(async () => {
    stopTicking()
    if (saveIntervalRef.current !== null) {
      clearInterval(saveIntervalRef.current)
      saveIntervalRef.current = null
    }
    live.stop()
    const recorder = recorderRef.current
    if (!recorder) return
    try {
      const blob = await recorder.stop()
      setAudioBlob(blob)
      void runTranscription(blob)
    } catch {
      setError('Something went wrong while finishing the recording.')
    } finally {
      recorderRef.current = null
      setState('idle')
      stateRef.current = 'idle'
      setLevel(0)
    }
  }, [live, runTranscription, stopTicking])

  stopRef.current = stop

  const retryTranscription = useCallback(
    (blob: Blob) => runTranscription(blob),
    [runTranscription],
  )

  const resetPostStop = useCallback(() => {
    setAudioBlob(null)
    setTranscript(null)
    setTranscribeError(null)
    setElapsed(0)
    elapsedMsRef.current = 0
    transcriptRef.current = ''
    durationRef.current = 0
    meetingIdRef.current = null
    setMeetingId(null)
    setError(null)
    live.reset()
  }, [live])

  // App-root unmount only (effectively never during normal use).
  // DELIBERATELY no per-route cleanup here — that was the unmount bug.
  useEffect(() => {
    return () => {
      stopTicking()
      if (saveIntervalRef.current !== null) {
        clearInterval(saveIntervalRef.current)
        saveIntervalRef.current = null
      }
      recorderRef.current?.dispose()
    }
  }, [stopTicking])

  // Keep the current access token in a ref so the pagehide flush below can
  // build an authed sendBeacon request synchronously. Uses the existing
  // supabase client — NO second client created.
  useEffect(() => {
    supabase.auth.getSession().then(({ data }) => {
      accessTokenRef.current = data.session?.access_token ?? null
    })
    const { data: sub } = supabase.auth.onAuthStateChange((_evt, session) => {
      accessTokenRef.current = session?.access_token ?? null
    })
    return () => {
      sub.subscription.unsubscribe()
    }
  }, [])

  // Browser-close / crash flush. On 'pagehide' (and visibility→hidden) fire
  // a final live_caption save via sendBeacon, because supabase-js fetch is
  // killed mid-flight on real tab-close. Fire-once guarded per page lifetime.
  useEffect(() => {
    const flush = () => {
      if (beaconFiredRef.current) return
      if (
        stateRef.current === 'idle' ||
        !meetingIdRef.current ||
        !liveTextRef.current
      )
        return
      const url = `${import.meta.env.VITE_SUPABASE_URL}/rest/v1/meetings?id=eq.${meetingIdRef.current}`
      const apikey = import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY as string
      const token = accessTokenRef.current ?? apikey
      const payload = JSON.stringify({ live_caption: liveTextRef.current })
      beaconFiredRef.current = true
      try {
        // sendBeacon can't set custom headers, so fall through to keepalive
        // fetch which can — required for the apikey + bearer pair.
        void fetch(url, {
          method: 'PATCH',
          keepalive: true,
          headers: {
            'Content-Type': 'application/json',
            apikey,
            Authorization: `Bearer ${token}`,
            Prefer: 'return=minimal',
          },
          body: payload,
        })
      } catch {
        // last-ditch: untyped beacon (will likely 401 without auth, but try)
        if (typeof navigator !== 'undefined' && navigator.sendBeacon) {
          navigator.sendBeacon(url, new Blob([payload], { type: 'application/json' }))
        }
      }
    }
    const onVisibility = () => {
      if (document.visibilityState === 'hidden') flush()
    }
    window.addEventListener('pagehide', flush)
    document.addEventListener('visibilitychange', onVisibility)
    return () => {
      window.removeEventListener('pagehide', flush)
      document.removeEventListener('visibilitychange', onVisibility)
    }
  }, [])

  const value: RecordingContextValue = {
    state,
    elapsed,
    level,
    error,
    maxMinutes,
    capSeconds,
    liveText: live.liveText,
    liveStatus: live.status,
    liveSupported: live.supported,
    liveBoxRef,
    transcript,
    transcribing,
    transcribeError,
    audioBlob,
    meetingId,
    retentionDays,
    defaultPrompt,
    model,
    start,
    pause,
    resume,
    stop,
    retryTranscription,
    resetPostStop,
  }

  return (
    <RecordingContext.Provider value={value}>
      {children}
    </RecordingContext.Provider>
  )
}

export function useRecording(): RecordingContextValue {
  const ctx = useContext(RecordingContext)
  if (!ctx) throw new Error('useRecording must be used within RecordingProvider')
  return ctx
}
