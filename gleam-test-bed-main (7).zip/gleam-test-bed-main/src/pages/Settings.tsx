import { useEffect, useState } from 'react'
import AppShell from '../components/AppShell'
import { useAuth } from '../context/AuthContext'
import { getAiKeyStatus, setAiKey, type AiProvider } from '../lib/ai'
import {
  AI_MODELS,
  COMPANY_DEFAULT,
  DEFAULT_MAX_MINUTES,
  DEFAULT_RETENTION_DAYS,
  getProfileSettings,
  updateProfileSettings,
  type ProfileSettings,
} from '../lib/profile'

const EMPTY: ProfileSettings = {
  ai_model: AI_MODELS[0],
  max_minutes: DEFAULT_MAX_MINUTES,
  retention_days: DEFAULT_RETENTION_DAYS,
  default_prompt: '',
  company: COMPANY_DEFAULT,
}

function clampInt(value: number, min: number, max: number, fallback: number) {
  if (!Number.isFinite(value)) return fallback
  return Math.min(max, Math.max(min, Math.round(value)))
}

export default function Settings() {
  const { user, refreshProfile } = useAuth()

  const [form, setForm] = useState<ProfileSettings>(EMPTY)
  const [loading, setLoading] = useState(true)
  const [loadError, setLoadError] = useState<string | null>(null)
  const [saving, setSaving] = useState(false)
  const [saved, setSaved] = useState(false)
  const [saveError, setSaveError] = useState<string | null>(null)

  // Provider key status (write-only — we only learn whether each one is set).
  const [groqConfigured, setGroqConfigured] = useState<boolean | null>(null)
  const [geminiConfigured, setGeminiConfigured] = useState<boolean | null>(null)

  // Load current values on open (§8).
  useEffect(() => {
    if (!user) return
    let cancelled = false
    setLoading(true)
    getProfileSettings(user.id)
      .then((s) => {
        if (!cancelled) {
          setForm(s)
          setLoadError(null)
        }
      })
      .catch(() => {
        if (!cancelled) setLoadError('Could not load your settings.')
      })
      .finally(() => {
        if (!cancelled) setLoading(false)
      })
    return () => {
      cancelled = true
    }
  }, [user])

  // Load which provider keys are configured (status only, never the values).
  useEffect(() => {
    if (!user) return
    let cancelled = false
    getAiKeyStatus()
      .then((s) => {
        if (!cancelled) {
          setGroqConfigured(s.groq)
          setGeminiConfigured(s.gemini)
        }
      })
      .catch(() => {
        if (!cancelled) {
          setGroqConfigured(null)
          setGeminiConfigured(null)
        }
      })
    return () => {
      cancelled = true
    }
  }, [user])

  const set = <K extends keyof ProfileSettings>(
    key: K,
    value: ProfileSettings[K],
  ) => {
    setForm((f) => ({ ...f, [key]: value }))
    setSaved(false)
  }

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!user) return
    setSaveError(null)
    setSaving(true)
    const cleaned: ProfileSettings = {
      ...form,
      max_minutes: clampInt(form.max_minutes, 1, 120, DEFAULT_MAX_MINUTES),
      retention_days: clampInt(form.retention_days, 1, 90, DEFAULT_RETENTION_DAYS),
      company: form.company.trim() || COMPANY_DEFAULT,
    }
    try {
      await updateProfileSettings(user.id, cleaned)
      setForm(cleaned)
      await refreshProfile() // update the header company immediately
      setSaved(true)
      window.setTimeout(() => setSaved(false), 2500)
    } catch {
      setSaveError('Could not save your settings. Please try again.')
    } finally {
      setSaving(false)
    }
  }

  return (
    <AppShell>
      <div className="reveal mx-auto max-w-2xl">
        <h1 className="font-display text-4xl font-600 tracking-tight text-ink">
          Settings
        </h1>
        <p className="mt-3 text-muted">
          These preferences are saved to your account.
        </p>

        {loading ? (
          <div className="mt-10 rounded-card border border-line bg-surface p-8 text-sm text-muted shadow-card">
            Loading…
          </div>
        ) : loadError ? (
          <div className="mt-10 rounded-card border border-line bg-rec/10 p-8 text-sm font-500 text-rec shadow-card">
            {loadError}
          </div>
        ) : (
          <form
            onSubmit={handleSave}
            className="mt-10 space-y-7 rounded-card border border-line bg-surface p-8 shadow-card"
          >
            <p className="rounded-xl bg-accent-soft/60 px-4 py-3 text-sm text-ink-2">
              Groq is the primary engine; Gemini is used automatically if Groq is
              rate-limited.
            </p>

            <Field
              label="Fallback (Gemini) model"
              help="Groq models are fixed for the primary engine (whisper-large-v3-turbo + llama-3.3-70b-versatile). This dropdown only selects the Gemini fallback model."
            >
              <select
                value={form.ai_model}
                onChange={(e) => set('ai_model', e.target.value)}
                className="w-full rounded-xl border border-line bg-paper/50 px-4 py-3 text-ink"
              >
                {AI_MODELS.map((m) => (
                  <option key={m} value={m}>
                    {m}
                  </option>
                ))}
              </select>
            </Field>

            <Field
              label="Max recording (minutes)"
              help="The recorder auto-stops at this length."
            >
              <input
                type="number"
                min={1}
                max={120}
                value={form.max_minutes}
                onChange={(e) => set('max_minutes', Number(e.target.value))}
                className="w-full rounded-xl border border-line bg-paper/50 px-4 py-3 text-ink"
              />
            </Field>

            <Field
              label="Retention (days)"
              help="New meetings auto-delete after this many days."
            >
              <input
                type="number"
                min={1}
                max={90}
                value={form.retention_days}
                onChange={(e) => set('retention_days', Number(e.target.value))}
                className="w-full rounded-xl border border-line bg-paper/50 px-4 py-3 text-ink"
              />
            </Field>

            <Field
              label="Default summary instruction"
              help="Leave empty for the standard bullet summary."
            >
              <textarea
                value={form.default_prompt}
                onChange={(e) => set('default_prompt', e.target.value)}
                placeholder="e.g. always keep it short and formal"
                className="h-24 w-full resize-y rounded-xl border border-line bg-paper/50 px-4 py-3 text-ink placeholder:text-muted/70"
              />
            </Field>

            <Field label="Company name" help="Shown in the app header.">
              <input
                type="text"
                value={form.company}
                onChange={(e) => set('company', e.target.value)}
                placeholder={COMPANY_DEFAULT}
                className="w-full rounded-xl border border-line bg-paper/50 px-4 py-3 text-ink placeholder:text-muted/70"
              />
            </Field>

            {saveError && (
              <p className="rounded-xl bg-rec/10 px-4 py-2.5 text-sm font-500 text-rec">
                {saveError}
              </p>
            )}

            <div className="flex items-center gap-4">
              <button
                type="submit"
                disabled={saving}
                className="rounded-full bg-accent px-7 py-3 text-base font-600 text-white shadow-lift transition-transform hover:-translate-y-0.5 disabled:cursor-not-allowed disabled:opacity-60"
              >
                {saving ? 'Saving…' : 'Save'}
              </button>
              {saved && (
                <span className="text-sm font-600 text-good">Saved</span>
              )}
            </div>
          </form>
        )}

        {/* Provider API keys — write-only; stored keys are never displayed. */}
        <ApiKeyCard
          provider="groq"
          title="Groq API key (primary)"
          subtitle="The primary engine for transcription and summaries. Stored securely on the server; never shown here."
          placeholder="Paste your Groq API key (gsk_…)"
          configured={groqConfigured}
          onSaved={() => setGroqConfigured(true)}
        />

        <ApiKeyCard
          provider="gemini"
          title="Gemini API key (fallback)"
          subtitle="Used automatically only if Groq is rate-limited. Stored securely on the server; never shown here."
          placeholder="Paste a Gemini API key"
          configured={geminiConfigured}
          onSaved={() => setGeminiConfigured(true)}
        />
      </div>
    </AppShell>
  )
}

/** Write-only API-key card for one provider (status + paste + save). */
function ApiKeyCard({
  provider,
  title,
  subtitle,
  placeholder,
  configured,
  onSaved,
}: {
  provider: AiProvider
  title: string
  subtitle: string
  placeholder: string
  configured: boolean | null
  onSaved: () => void
}) {
  const [input, setInput] = useState('')
  const [saving, setSaving] = useState(false)
  const [saved, setSaved] = useState(false)
  const [error, setError] = useState<string | null>(null)

  const submit = async (e: React.FormEvent) => {
    e.preventDefault()
    setError(null)
    setSaving(true)
    try {
      await setAiKey(provider, input.trim())
      setInput('')
      onSaved()
      setSaved(true)
      window.setTimeout(() => setSaved(false), 2500)
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Could not save the key.')
    } finally {
      setSaving(false)
    }
  }

  return (
    <form
      onSubmit={submit}
      className="mt-8 rounded-card border border-line bg-surface p-8 shadow-card"
    >
      <h2 className="font-display text-xl font-600 tracking-tight text-ink">
        {title}
      </h2>
      <p className="mt-1 text-sm text-muted">{subtitle}</p>

      <p className="mt-3 text-sm font-600">
        {configured === null ? (
          <span className="text-muted">Checking key status…</span>
        ) : configured ? (
          <span className="text-good">A key is configured.</span>
        ) : (
          <span className="text-amber">No key set yet.</span>
        )}
      </p>

      <label className="mt-4 block">
        <span className="mb-1.5 block text-sm font-600 text-ink-2">
          {configured ? 'Replace key' : 'Set key'}
        </span>
        <input
          type="password"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder={placeholder}
          autoComplete="off"
          className="w-full rounded-xl border border-line bg-paper/50 px-4 py-3 text-ink placeholder:text-muted/70"
        />
      </label>

      {error && (
        <p className="mt-4 rounded-xl bg-rec/10 px-4 py-2.5 text-sm font-500 text-rec">
          {error}
        </p>
      )}

      <div className="mt-5 flex items-center gap-4">
        <button
          type="submit"
          disabled={saving || !input.trim()}
          className="rounded-full bg-ink px-7 py-3 text-base font-600 text-white transition-transform hover:-translate-y-0.5 disabled:cursor-not-allowed disabled:opacity-60"
        >
          {saving ? 'Saving…' : 'Save key'}
        </button>
        {saved && <span className="text-sm font-600 text-good">Key saved</span>}
      </div>
    </form>
  )
}

function Field({
  label,
  help,
  children,
}: {
  label: string
  help?: string
  children: React.ReactNode
}) {
  return (
    <label className="block">
      <span className="mb-1.5 block text-sm font-600 text-ink-2">{label}</span>
      {children}
      {help && <span className="mt-1.5 block text-xs text-muted">{help}</span>}
    </label>
  )
}
