import { useCallback, useEffect, useRef, useState } from 'react'
import AppShell from '../components/AppShell'
import ProgressRing from '../components/ProgressRing'
import RecordButton from '../components/RecordButton'
import { summarizeTranscript } from '../lib/ai'
import {
  createMeeting,
  updateMeeting,
  adminReassignMeeting,
  REASSIGN_TARGETS,
} from '../lib/meetings'
import SummaryCard, { type SaveState } from '../components/SummaryCard'
import RegenerateBox from '../components/RegenerateBox'
import TranscriptPanel from '../components/TranscriptPanel'
import CopyButton from '../components/CopyButton'
import { transcriptWithPrompt } from '../lib/exports'
import { useAuth } from '../context/AuthContext'
import { useRecording } from '../context/RecordingContext'

function formatTime(totalSeconds: number): string {
  const s = Math.max(0, Math.floor(totalSeconds))
  const mm = String(Math.floor(s / 60)).padStart(2, '0')
  const ss = String(s % 60).padStart(2, '0')
  return `${mm}:${ss}`
}

function countWords(text: string): number {
  return text.trim().split(/\s+/).filter(Boolean).length
}

export default function Recorder() {
  const { user, isAdmin } = useAuth()
  const rec = useRecording()
  const {
    state,
    elapsed,
    level,
    error,
    capSeconds,
    liveText,
    liveStatus,
    liveSupported,
    liveBoxRef,
    transcript,
    transcribing,
    transcribeError,
    audioBlob,
    meetingId,
    retentionDays,
    defaultPrompt,
    model,
    start,
    pause,
    resume,
    stop,
    retryTranscription,
    resetPostStop,
  } = rec

  // Page-local post-stop state (audio URL preview, summary UI).
  const [audioUrl, setAudioUrl] = useState<string | null>(null)
  const [summarizing, setSummarizing] = useState(false)
  const [regenerating, setRegenerating] = useState(false)
  const [summary, setSummary] = useState<string | null>(null)
  const [summaryTitle, setSummaryTitle] = useState<string | null>(null)
  const [summaryError, setSummaryError] = useState<string | null>(null)
  const [saveState, setSaveState] = useState<SaveState>('idle')
  const [sentTargetId, setSentTargetId] = useState<string | null>(null)
  const [sendError, setSendError] = useState<string | null>(null)
  const [sending, setSending] = useState(false)

  // Refs for debounced summary autosave.
  const titleRef = useRef('')
  const summaryRef = useRef('')
  const saveTimerRef = useRef<number | null>(null)
  // Local mirror of meeting id so persistSummary can insert a fresh row if
  // the provider's row was never created (e.g. start happened pre-auth).
  const localMeetingIdRef = useRef<string | null>(null)
  useEffect(() => {
    localMeetingIdRef.current = meetingId
  }, [meetingId])

  // Build an object URL whenever a new blob arrives.
  useEffect(() => {
    if (!audioBlob) {
      setAudioUrl((prev) => {
        if (prev) URL.revokeObjectURL(prev)
        return null
      })
      return
    }
    const url = URL.createObjectURL(audioBlob)
    setAudioUrl((prev) => {
      if (prev) URL.revokeObjectURL(prev)
      return url
    })
    return () => {
      URL.revokeObjectURL(url)
    }
  }, [audioBlob])

  // Reset summary UI whenever a new transcription cycle starts.
  useEffect(() => {
    if (transcribing) {
      setSummary(null)
      setSummaryTitle(null)
      setSummaryError(null)
      titleRef.current = ''
      summaryRef.current = ''
      setSaveState('idle')
    }
  }, [transcribing])

  // Persist after a (re)generation: update the row created at start, or
  // insert a fresh one if for some reason it doesn't exist.
  const persistSummary = useCallback(
    async (title: string, summaryText: string) => {
      if (!user) return
      try {
        setSaveState('saving')
        if (localMeetingIdRef.current) {
          await updateMeeting(localMeetingIdRef.current, {
            title,
            summary: summaryText,
          })
        } else {
          const id = await createMeeting(user.id, {
            title,
            summary: summaryText,
            transcript: transcript ?? '',
            durationSec: Math.round(elapsed),
            wordCount: countWords(transcript ?? ''),
            retentionDays,
          })
          localMeetingIdRef.current = id
        }
        setSaveState('saved')
      } catch {
        setSaveState('error')
      }
    },
    [user, retentionDays, transcript, elapsed],
  )

  const generateSummary = useCallback(
    async (transcriptText: string, instruction = '', regenerate = false) => {
      setSummaryError(null)
      if (regenerate) {
        setRegenerating(true)
      } else {
        setSummary(null)
        setSummaryTitle(null)
        setSummarizing(true)
      }
      try {
        const { title, summary } = await summarizeTranscript(
          transcriptText,
          instruction,
          model,
        )
        setSummaryTitle(title)
        setSummary(summary)
        titleRef.current = title
        summaryRef.current = summary
        await persistSummary(title, summary)
      } catch (e) {
        setSummaryError(
          e instanceof Error ? e.message : 'Could not generate the summary.',
        )
      } finally {
        setSummarizing(false)
        setRegenerating(false)
      }
    },
    [persistSummary, model],
  )

  const scheduleSave = useCallback(() => {
    if (saveTimerRef.current) window.clearTimeout(saveTimerRef.current)
    setSaveState('saving')
    saveTimerRef.current = window.setTimeout(async () => {
      if (!localMeetingIdRef.current) {
        setSaveState('idle')
        return
      }
      try {
        await updateMeeting(localMeetingIdRef.current, {
          title: titleRef.current,
          summary: summaryRef.current,
        })
        setSaveState('saved')
      } catch {
        setSaveState('error')
      }
    }, 800)
  }, [])

  const handleEditTitle = (t: string) => {
    setSummaryTitle(t)
    titleRef.current = t
    scheduleSave()
  }
  const handleEditSummary = (s: string) => {
    setSummary(s)
    summaryRef.current = s
    scheduleSave()
  }

  const handleReset = () => {
    setSummary(null)
    setSummaryTitle(null)
    setSummaryError(null)
    titleRef.current = ''
    summaryRef.current = ''
    setSaveState('idle')
    setSentTargetId(null)
    setSendError(null)
    if (saveTimerRef.current) window.clearTimeout(saveTimerRef.current)
    resetPostStop()
  }

  const handleSendTo = async (targetId: string) => {
    const id = localMeetingIdRef.current
    if (!id) return
    setSending(true)
    setSendError(null)
    try {
      await adminReassignMeeting(id, targetId)
      setSentTargetId(targetId)
    } catch (e) {
      setSendError(
        e instanceof Error ? e.message : 'Could not send this meeting.',
      )
    } finally {
      setSending(false)
    }
  }

  const handleMainButton = () => {
    if (state === 'idle') void start()
    else void stop()
  }

  // Spacebar starts/stops recording (unless typing in a field/button).
  const mainButtonRef = useRef(handleMainButton)
  mainButtonRef.current = handleMainButton
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.code !== 'Space') return
      const el = document.activeElement as HTMLElement | null
      const tag = el?.tagName
      if (
        tag === 'INPUT' ||
        tag === 'TEXTAREA' ||
        tag === 'SELECT' ||
        tag === 'BUTTON' ||
        el?.isContentEditable
      ) {
        return
      }
      e.preventDefault()
      mainButtonRef.current()
    }
    window.addEventListener('keydown', onKey)
    return () => window.removeEventListener('keydown', onKey)
  }, [])

  // Page-local cleanup ONLY: revoke audioUrl + clear the page's save timer.
  // The recorder lifecycle is owned by RecordingProvider — do NOT dispose it
  // here, that was the unmount bug.
  useEffect(() => {
    return () => {
      if (saveTimerRef.current) window.clearTimeout(saveTimerRef.current)
    }
  }, [])

  const inSession = state !== 'idle'
  const progress = capSeconds > 0 ? elapsed / capSeconds : 0
  const ringColor =
    state === 'recording'
      ? 'var(--color-rec)'
      : state === 'paused'
        ? 'var(--color-amber)'
        : 'var(--color-accent)'

  return (
    <AppShell>
      <div className="reveal mx-auto flex max-w-xl flex-col items-center text-center">
        <h1 className="font-display text-3xl font-600 tracking-tight text-ink">
          {inSession ? 'Recording your briefing' : 'New recording'}
        </h1>
        <p className="mt-2 max-w-md text-sm text-muted">
          {inSession
            ? 'Speak naturally — every word is being captured. Press the button to finish.'
            : 'Press the button and talk through the task. The full audio is recorded so nothing is missed.'}
        </p>

        {error && (
          <p className="mt-4 w-full rounded-xl bg-rec/10 px-4 py-3 text-sm font-500 text-rec">
            {error}
          </p>
        )}

        <div className="mt-6">
          <ProgressRing progress={progress} color={ringColor} size={224}>
            <RecordButton
              state={state}
              level={level}
              onClick={handleMainButton}
            />
          </ProgressRing>
        </div>

        <p className="mt-5 font-mono text-lg font-500 text-ink-2">
          {formatTime(elapsed)}{' '}
          <span className="text-muted">/ {formatTime(capSeconds)}</span>
        </p>

        <p className="mt-2 text-xs text-muted">
          Tip: press{' '}
          <kbd className="rounded border border-line bg-paper px-1.5 py-0.5 font-mono text-[0.7rem] text-ink-2">
            Space
          </kbd>{' '}
          to {inSession ? 'stop' : 'start'}.
        </p>

        {inSession && (
          <div className="mt-6">
            {state === 'recording' ? (
              <button
                onClick={pause}
                className="rounded-full border border-line bg-surface px-6 py-2.5 text-sm font-600 text-ink-2 shadow-card transition-transform hover:-translate-y-0.5"
              >
                Pause
              </button>
            ) : (
              <button
                onClick={resume}
                className="rounded-full border border-amber/40 bg-amber/10 px-6 py-2.5 text-sm font-600 text-amber shadow-card transition-transform hover:-translate-y-0.5"
              >
                Resume
              </button>
            )}
          </div>
        )}

        {inSession &&
          (liveSupported ? (
            <div className="mt-6 w-full">
              <div className="mb-1 text-xs font-600 text-muted">
                Live preview — the final transcript is generated after you stop.
              </div>
              <div
                ref={liveBoxRef}
                className="max-h-32 w-full overflow-y-auto rounded-xl border border-line bg-paper/40 px-4 py-3 text-left text-sm leading-relaxed text-ink-2"
              >
                {liveText || (
                  <span className="text-muted">
                    {liveStatus === 'paused'
                      ? 'Captions paused — reconnecting…'
                      : liveStatus === 'denied'
                        ? 'Microphone access is blocked. Captions are off, but your interview is still recording.'
                        : 'Listening…'}
                  </span>
                )}
              </div>
            </div>
          ) : (
            <p className="mt-4 text-xs text-muted">
              Live preview isn't supported in this browser.
            </p>
          ))}
      </div>

      {!inSession && audioBlob && (
        <section className="reveal mt-8">
          <div className="mb-4 flex flex-wrap items-center justify-end gap-2">
            {isAdmin && localMeetingIdRef.current && (
              <>
                {REASSIGN_TARGETS.map((t) => {
                  const label =
                    t.label === 'Meeting account'
                      ? 'Send to Meeting'
                      : 'Send to Developer'
                  const isSent = sentTargetId === t.id
                  return (
                    <button
                      key={t.id}
                      onClick={() => void handleSendTo(t.id)}
                      disabled={sending || sentTargetId !== null}
                      className="rounded-full border border-line bg-surface px-5 py-2.5 text-sm font-600 text-ink-2 shadow-card transition-transform hover:-translate-y-0.5 disabled:opacity-60"
                    >
                      {isSent ? '✓ Sent' : label}
                    </button>
                  )
                })}
              </>
            )}
            <button
              onClick={handleReset}
              className="rounded-full bg-accent px-6 py-2.5 text-sm font-600 text-white transition-transform hover:-translate-y-0.5"
            >
              Record again
            </button>
          </div>
          {sendError && (
            <p className="mb-3 rounded-xl bg-rec/10 px-4 py-2.5 text-right text-sm font-500 text-rec">
              {sendError}
            </p>
          )}

          <div className="grid grid-cols-1 gap-4 lg:grid-cols-[1fr_1.4fr] lg:items-start">
            <div className="rounded-card border border-line bg-surface p-5 text-left shadow-card">
              <div className="flex items-center gap-2">
                <span className="h-2.5 w-2.5 rounded-full bg-good" />
                <h2 className="font-display text-lg font-600 text-ink">
                  Recording captured
                </h2>
              </div>
              <p className="mt-1 text-sm text-muted">
                {formatTime(elapsed)} of audio captured.
              </p>

              {audioUrl && (
                <audio controls src={audioUrl} className="mt-4 w-full">
                  Your browser does not support audio playback.
                </audio>
              )}

              {transcribing && (
                <div className="mt-4 flex items-center gap-3 rounded-xl bg-accent-soft/60 px-4 py-3 text-sm font-500 text-accent">
                  <span className="h-4 w-4 animate-spin rounded-full border-2 border-accent/30 border-t-accent" />
                  Transcribing the full recording…
                </div>
              )}

              {transcribeError && !transcribing && (
                <div className="mt-4 rounded-xl bg-rec/10 px-4 py-3 text-sm font-500 text-rec">
                  {transcribeError}
                  <button
                    onClick={() => void retryTranscription(audioBlob)}
                    className="ml-2 underline underline-offset-2 hover:no-underline"
                  >
                    Try again
                  </button>
                </div>
              )}

              {transcript !== null && !transcribing && (
                <div className="mt-4">
                  <TranscriptPanel transcript={transcript} />
                </div>
              )}
            </div>

            <div className="rounded-card border border-line bg-surface p-5 text-left shadow-card">
              {transcript === null ? (
                <p className="text-sm text-muted">
                  Your summary will appear here once the transcript is ready.
                </p>
              ) : summarizing ? (
                <div className="flex items-center gap-3 rounded-xl bg-accent-soft/60 px-4 py-3 text-sm font-500 text-accent">
                  <span className="h-4 w-4 animate-spin rounded-full border-2 border-accent/30 border-t-accent" />
                  Writing the summary…
                </div>
              ) : summaryError ? (
                <div className="rounded-xl border border-rec/30 bg-rec/10 px-4 py-4">
                  <p className="text-sm font-500 text-rec">{summaryError}</p>
                  <p className="mt-2 text-sm text-ink-2">
                    No problem — your full transcript is safe on the left. You
                    can retry, or copy the transcript into any other AI to get
                    the summary yourself.
                  </p>
                  <div className="mt-3 flex flex-wrap gap-2">
                    <button
                      onClick={() => void generateSummary(transcript)}
                      className="rounded-full bg-accent px-5 py-2.5 text-sm font-600 text-white transition-transform hover:-translate-y-0.5"
                    >
                      Try again
                    </button>
                    <CopyButton
                      text={transcript}
                      label="Copy full transcript"
                      className="rounded-full border border-line bg-surface px-5 py-2.5 text-sm font-600 text-ink-2 transition-transform hover:-translate-y-0.5"
                    />
                    <CopyButton
                      text={() => transcriptWithPrompt(transcript)}
                      label="Copy transcript + summary prompt"
                      className="rounded-full border border-line bg-surface px-5 py-2.5 text-sm font-600 text-ink-2 transition-transform hover:-translate-y-0.5"
                    />
                  </div>
                </div>
              ) : summary !== null ? (
                <SummaryCard
                  title={summaryTitle ?? ''}
                  summary={summary}
                  durationSec={Math.round(elapsed)}
                  wordCount={countWords(transcript)}
                  saveState={saveState}
                  onChangeTitle={handleEditTitle}
                  onChangeSummary={handleEditSummary}
                />
              ) : (
                <div>
                  <button
                    onClick={() =>
                      void generateSummary(transcript, defaultPrompt)
                    }
                    className="rounded-full bg-accent px-6 py-2.5 text-sm font-600 text-white transition-transform hover:-translate-y-0.5"
                  >
                    Get Summary
                  </button>
                  <p className="mt-2 text-sm text-muted">
                    Transcript saved. Generate the worker-facing summary when ready.
                  </p>
                </div>
              )}
            </div>
          </div>

          <div className="mt-4 rounded-card border border-line bg-surface p-5 text-left shadow-card">
            <RegenerateBox
              regenerating={regenerating}
              disabled={transcript === null}
              onRegenerate={(instruction) =>
                void generateSummary(transcript ?? '', instruction, true)
              }
            />
          </div>
        </section>
      )}
    </AppShell>
  )
}
