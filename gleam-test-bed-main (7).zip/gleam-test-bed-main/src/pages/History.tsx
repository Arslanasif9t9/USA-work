import { useEffect, useMemo, useRef, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { Trash2, CheckSquare, Square, Send } from 'lucide-react'
import AppShell from '../components/AppShell'
import MeetingModal from '../components/MeetingModal'
import { useAuth } from '../context/AuthContext'
import {
  listMeetings,
  deleteMeeting,
  deleteMeetings,
  deleteAllMeetings,
  adminListAllMeetings,
  adminDeleteMeeting,
  adminDeleteMeetings,
  adminDeleteAllMeetings,
  adminReassignMeeting,
  REASSIGN_TARGETS,
  type MeetingRow,
  type AdminMeetingRow,
} from '../lib/meetings'
import { formatDate, formatDuration } from '../lib/format'

/** History page (§7): all saved meetings as a responsive card grid. */
export default function History() {
  const { user, isAdmin } = useAuth()
  const navigate = useNavigate()
  const [items, setItems] = useState<(MeetingRow | AdminMeetingRow)[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [query, setQuery] = useState('')
  const [selected, setSelected] = useState<(MeetingRow | AdminMeetingRow) | null>(null)
  const [selectionMode, setSelectionMode] = useState(false)
  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set())
  const [busy, setBusy] = useState(false)
  const [actionError, setActionError] = useState<string | null>(null)
  const [flash, setFlash] = useState<string | null>(null)
  const [reassignOpenId, setReassignOpenId] = useState<string | null>(null)
  const reassignRef = useRef<HTMLDivElement | null>(null)

  useEffect(() => {
    if (!reassignOpenId) return
    const onDoc = (e: MouseEvent) => {
      if (reassignRef.current && !reassignRef.current.contains(e.target as Node)) {
        setReassignOpenId(null)
      }
    }
    document.addEventListener('mousedown', onDoc)
    return () => document.removeEventListener('mousedown', onDoc)
  }, [reassignOpenId])

  useEffect(() => {
    if (!flash) return
    const t = setTimeout(() => setFlash(null), 2800)
    return () => clearTimeout(t)
  }, [flash])

  const reload = async () => {
    if (!user) return
    const rows = isAdmin ? await adminListAllMeetings() : await listMeetings(user.id)
    setItems(rows)
  }

  const handleReassign = async (meetingId: string, targetId: string, label: string) => {
    setReassignOpenId(null)
    setActionError(null)
    setBusy(true)
    try {
      await adminReassignMeeting(meetingId, targetId)
      await reload()
      setFlash(`Sent to ${label}.`)
    } catch {
      setActionError('Could not reassign this meeting. Please try again.')
    } finally {
      setBusy(false)
    }
  }

  useEffect(() => {
    if (!user) return
    let cancelled = false
    setLoading(true)
    const fetcher = isAdmin
      ? adminListAllMeetings()
      : listMeetings(user.id)
    fetcher
      .then((rows) => {
        if (!cancelled) {
          setItems(rows)
          setError(null)
        }
      })
      .catch(() => {
        if (!cancelled) setError('Could not load your saved meetings.')
      })
      .finally(() => {
        if (!cancelled) setLoading(false)
      })
    return () => {
      cancelled = true
    }
  }, [user, isAdmin])

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase()
    if (!q) return items
    return items.filter(
      (m) =>
        m.title.toLowerCase().includes(q) ||
        m.summary.toLowerCase().includes(q),
    )
  }, [items, query])

  const handleDeleted = (id: string) => {
    setItems((prev) => prev.filter((m) => m.id !== id))
    setSelectedIds((prev) => {
      if (!prev.has(id)) return prev
      const next = new Set(prev)
      next.delete(id)
      return next
    })
    setSelected(null)
  }

  const toggleSelected = (id: string) => {
    setSelectedIds((prev) => {
      const next = new Set(prev)
      if (next.has(id)) next.delete(id)
      else next.add(id)
      return next
    })
  }

  const handleSelectAll = () => {
    setSelectedIds(new Set(filtered.map((m) => m.id)))
  }

  const handleClearSelection = () => setSelectedIds(new Set())

  const handleToggleSelectionMode = () => {
    setSelectionMode((m) => {
      if (m) setSelectedIds(new Set())
      return !m
    })
  }

  const handleDeleteOne = async (id: string) => {
    if (!window.confirm('Delete this meeting permanently?')) return
    setActionError(null)
    setBusy(true)
    try {
      if (isAdmin) await adminDeleteMeeting(id)
      else await deleteMeeting(id)
      handleDeleted(id)
    } catch {
      setActionError('Could not delete this meeting. Please try again.')
    } finally {
      setBusy(false)
    }
  }

  const handleDeleteSelected = async () => {
    const ids = [...selectedIds]
    if (ids.length === 0) return
    if (
      !window.confirm(
        `Delete ${ids.length} selected meeting${ids.length === 1 ? '' : 's'} permanently?`,
      )
    )
      return
    setActionError(null)
    setBusy(true)
    try {
      if (isAdmin) await adminDeleteMeetings(ids)
      else await deleteMeetings(ids)
      const idSet = new Set(ids)
      setItems((prev) => prev.filter((m) => !idSet.has(m.id)))
      setSelectedIds(new Set())
    } catch {
      setActionError('Could not delete the selected meetings. Please try again.')
    } finally {
      setBusy(false)
    }
  }

  const handleDeleteAll = async () => {
    if (!user) return
    if (items.length === 0) return
    if (
      !window.confirm(
        `This will permanently delete ALL ${items.length} of your saved meetings. This cannot be undone. Continue?`,
      )
    )
      return
    setActionError(null)
    setBusy(true)
    try {
      if (isAdmin) await adminDeleteAllMeetings()
      else await deleteAllMeetings(user.id)
      setItems([])
      setSelectedIds(new Set())
      setSelectionMode(false)
    } catch {
      setActionError('Could not delete all meetings. Please try again.')
    } finally {
      setBusy(false)
    }
  }

  const selectedCount = selectedIds.size
  const allFilteredSelected =
    filtered.length > 0 && filtered.every((m) => selectedIds.has(m.id))

  return (
    <AppShell>
      <div className="reveal mx-auto max-w-5xl">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <h1 className="font-display text-3xl font-600 tracking-tight text-ink">
            History
          </h1>
          <input
            type="search"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search by title or text…"
            className="w-full max-w-xs rounded-full border border-line bg-surface px-4 py-2 text-sm text-ink placeholder:text-muted/70"
          />
        </div>

        {items.length > 0 && (
          <div className="mt-4 flex flex-wrap items-center gap-2">
            <button
              onClick={handleToggleSelectionMode}
              disabled={busy}
              className={`rounded-full border px-4 py-2 text-sm font-600 transition-colors disabled:opacity-60 ${
                selectionMode
                  ? 'border-accent bg-accent/10 text-accent'
                  : 'border-line bg-surface text-ink-2 hover:bg-line/40'
              }`}
            >
              {selectionMode ? 'Done selecting' : 'Select'}
            </button>
            {selectionMode && (
              <>
                <button
                  onClick={
                    allFilteredSelected ? handleClearSelection : handleSelectAll
                  }
                  disabled={busy}
                  className="rounded-full border border-line bg-surface px-4 py-2 text-sm font-600 text-ink-2 transition-colors hover:bg-line/40 disabled:opacity-60"
                >
                  {allFilteredSelected ? 'Clear' : 'Select all'}
                </button>
                <button
                  onClick={handleDeleteSelected}
                  disabled={busy || selectedCount === 0}
                  className="rounded-full bg-rec px-5 py-2 text-sm font-600 text-white transition-transform hover:-translate-y-0.5 disabled:opacity-50"
                >
                  Delete selected ({selectedCount})
                </button>
              </>
            )}
            <span className="flex-1" />
            <button
              onClick={handleDeleteAll}
              disabled={busy}
              className="rounded-full border border-rec/40 bg-rec/10 px-4 py-2 text-sm font-600 text-rec transition-colors hover:bg-rec/15 disabled:opacity-60"
            >
              Delete all
            </button>
          </div>
        )}

        {flash && (
          <p className="mt-3 rounded-xl bg-accent/10 px-4 py-2.5 text-sm font-500 text-accent">
            {flash}
          </p>
        )}

        {actionError && (
          <p className="mt-3 rounded-xl bg-rec/10 px-4 py-2.5 text-sm font-500 text-rec">
            {actionError}
          </p>
        )}

        <div className="mt-6">
          {loading ? (
            <p className="rounded-card border border-line bg-surface px-5 py-12 text-center text-sm text-muted">
              Loading…
            </p>
          ) : error ? (
            <p className="rounded-card border border-line bg-rec/10 px-5 py-12 text-center text-sm font-500 text-rec">
              {error}
            </p>
          ) : items.length === 0 ? (
            <div className="rounded-card border border-dashed border-line bg-surface/60 px-5 py-16 text-center">
              <p className="text-sm text-muted">
                No saved meetings yet. Record a briefing and your summaries will
                appear here.
              </p>
              <button
                onClick={() => navigate('/record')}
                className="mt-4 rounded-full bg-accent px-6 py-2.5 text-sm font-600 text-white transition-transform hover:-translate-y-0.5"
              >
                Start recording
              </button>
            </div>
          ) : filtered.length === 0 ? (
            <p className="rounded-card border border-dashed border-line bg-surface/60 px-5 py-16 text-center text-sm text-muted">
              No meetings match “{query}”.
            </p>
          ) : (
            <ul className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
              {filtered.map((m) => {
                const isChecked = selectedIds.has(m.id)
                return (
                  <li key={m.id} className="relative">
                    <button
                      onClick={() =>
                        selectionMode ? toggleSelected(m.id) : setSelected(m)
                      }
                      className={`flex h-full w-full flex-col rounded-card border bg-surface p-5 text-left shadow-card transition-transform hover:-translate-y-0.5 ${
                        isChecked ? 'border-accent ring-2 ring-accent/40' : 'border-line'
                      }`}
                    >
                      <span className="font-display text-lg font-600 leading-snug tracking-tight text-ink line-clamp-2 pr-8">
                        {m.title || 'Untitled summary'}
                      </span>
                      {isAdmin && 'owner_username' in m && (
                        <span className="mt-2 flex flex-wrap items-center gap-1.5">
                          <span className="inline-flex w-fit items-center rounded-full border border-line bg-paper/60 px-2 py-0.5 font-mono text-[0.65rem] uppercase tracking-wide text-ink-2">
                            {(m as AdminMeetingRow).owner_username}
                          </span>
                          {(m as AdminMeetingRow).uploaded_by === 'dev' && (
                            <span className="inline-flex w-fit items-center rounded-full border border-emerald-500/40 bg-emerald-500/15 px-2 py-0.5 font-mono text-[0.65rem] uppercase tracking-wide text-emerald-700 dark:text-emerald-300">
                              Uploaded by dev
                            </span>
                          )}
                          {(m as AdminMeetingRow).uploaded_by === 'meeting' && (
                            <span className="inline-flex w-fit items-center rounded-full border border-violet-500/40 bg-violet-500/15 px-2 py-0.5 font-mono text-[0.65rem] uppercase tracking-wide text-violet-700 dark:text-violet-300">
                              Uploaded by meeting
                            </span>
                          )}
                        </span>
                      )}
                      <span className="mt-2 line-clamp-3 flex-1 text-sm text-muted">
                        {m.summary}
                      </span>
                      <span className="mt-3 font-mono text-xs text-muted">
                        {formatDate(m.created_at)} · {formatDuration(m.duration_sec)}{' '}
                        · {m.word_count} words
                      </span>
                    </button>

                    {selectionMode && (
                      <button
                        type="button"
                        aria-label={isChecked ? 'Deselect meeting' : 'Select meeting'}
                        onClick={(e) => {
                          e.stopPropagation()
                          toggleSelected(m.id)
                        }}
                        className="absolute left-3 top-3 grid h-8 w-8 place-items-center rounded-full bg-surface/90 text-ink-2 shadow-card hover:text-accent"
                      >
                        {isChecked ? (
                          <CheckSquare size={18} className="text-accent" />
                        ) : (
                          <Square size={18} />
                        )}
                      </button>
                    )}

                    <div className="absolute right-3 top-3 flex items-center gap-2">
                      {isAdmin && (
                        <div className="relative" ref={reassignOpenId === m.id ? reassignRef : undefined}>
                          <button
                            type="button"
                            aria-label="Send to account"
                            disabled={busy}
                            onClick={(e) => {
                              e.stopPropagation()
                              setReassignOpenId((cur) => (cur === m.id ? null : m.id))
                            }}
                            className="grid h-8 w-8 place-items-center rounded-full bg-surface/90 text-muted shadow-card transition-colors hover:bg-accent/10 hover:text-accent disabled:opacity-50"
                          >
                            <Send size={15} />
                          </button>
                          {reassignOpenId === m.id && (
                            <div
                              onClick={(e) => e.stopPropagation()}
                              className="absolute right-0 top-10 z-10 w-48 overflow-hidden rounded-xl border border-line bg-surface shadow-card"
                            >
                              <p className="border-b border-line px-3 py-2 text-xs font-600 text-muted">
                                Send to account
                              </p>
                              {REASSIGN_TARGETS.map((t) => (
                                <button
                                  key={t.id}
                                  type="button"
                                  disabled={busy}
                                  onClick={(e) => {
                                    e.stopPropagation()
                                    void handleReassign(m.id, t.id, t.label)
                                  }}
                                  className="block w-full px-3 py-2 text-left text-sm text-ink hover:bg-accent/10 disabled:opacity-50"
                                >
                                  {t.label}
                                </button>
                              ))}
                            </div>
                          )}
                        </div>
                      )}
                      <button
                        type="button"
                        aria-label="Delete meeting"
                        disabled={busy}
                        onClick={(e) => {
                          e.stopPropagation()
                          void handleDeleteOne(m.id)
                        }}
                        className="grid h-8 w-8 place-items-center rounded-full bg-surface/90 text-muted shadow-card transition-colors hover:bg-rec/10 hover:text-rec disabled:opacity-50"
                      >
                        <Trash2 size={16} />
                      </button>
                    </div>
                  </li>
                )
              })}
            </ul>
          )}
        </div>
      </div>

      {selected && (
        <MeetingModal
          meeting={selected}
          onClose={() => setSelected(null)}
          onDeleted={handleDeleted}
        />
      )}
    </AppShell>
  )
}
