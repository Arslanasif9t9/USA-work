import { useCallback, useEffect, useState } from 'react'
import AppShell from '../components/AppShell'
import { useAuth } from '../context/AuthContext'
import { supabase } from '../lib/supabase'

type AdminUser = {
  id: string
  username: string
  email: string
  created_at: string
  is_admin: boolean
}

type Flash = { kind: 'success' | 'error'; msg: string } | null

export default function UsersAdmin() {
  const { user } = useAuth()
  const [users, setUsers] = useState<AdminUser[]>([])
  const [loading, setLoading] = useState(true)
  const [loadError, setLoadError] = useState<string | null>(null)

  const [flash, setFlash] = useState<Flash>(null)
  const toast = {
    success: (msg: string) => {
      setFlash({ kind: 'success', msg })
      window.setTimeout(() => setFlash(null), 2800)
    },
    error: (msg: string) => {
      setFlash({ kind: 'error', msg })
      window.setTimeout(() => setFlash(null), 4000)
    },
  }

  const [newUsername, setNewUsername] = useState('')
  const [newPassword, setNewPassword] = useState('')
  const [creating, setCreating] = useState(false)

  const [resetFor, setResetFor] = useState<string | null>(null)
  const [resetValue, setResetValue] = useState('')
  const [resetBusy, setResetBusy] = useState(false)

  const [deletingId, setDeletingId] = useState<string | null>(null)

  const [ownPw, setOwnPw] = useState('')
  const [ownPw2, setOwnPw2] = useState('')
  const [ownBusy, setOwnBusy] = useState(false)

  const refresh = useCallback(async () => {
    setLoading(true)
    const { data, error } = await supabase.rpc('admin_list_users')
    if (error) {
      setLoadError(error.message)
      setUsers([])
    } else {
      setLoadError(null)
      setUsers((data as AdminUser[]) || [])
    }
    setLoading(false)
  }, [])

  useEffect(() => {
    void refresh()
  }, [refresh])

  const onCreate = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!newUsername.trim() || !newPassword) return
    setCreating(true)
    const { error } = await supabase.rpc('admin_create_user', {
      p_username: newUsername,
      p_password: newPassword,
    })
    setCreating(false)
    if (error) {
      toast.error(error.message)
      return
    }
    toast.success(`User "${newUsername.trim().toLowerCase()}" created`)
    setNewUsername('')
    setNewPassword('')
    await refresh()
  }

  const openReset = (id: string) => {
    setResetFor(id)
    setResetValue('')
  }

  const submitReset = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!resetFor || !resetValue) return
    setResetBusy(true)
    const { error } = await supabase.rpc('admin_reset_password', {
      p_user_id: resetFor,
      p_new_password: resetValue,
    })
    setResetBusy(false)
    if (error) {
      toast.error(error.message)
      return
    }
    toast.success('Password reset')
    setResetFor(null)
    setResetValue('')
  }

  const onDelete = async (u: AdminUser) => {
    if (u.is_admin) return
    const ok = window.confirm(
      `Delete user "${u.username}"?\n\nThis permanently destroys their account AND all of their recordings. This cannot be undone.`,
    )
    if (!ok) return
    setDeletingId(u.id)
    const { error } = await supabase.rpc('admin_delete_user', {
      p_user_id: u.id,
    })
    setDeletingId(null)
    if (error) {
      toast.error(error.message)
      return
    }
    toast.success(`User "${u.username}" deleted`)
    await refresh()
  }

  const onChangeOwn = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!ownPw || ownPw !== ownPw2) {
      toast.error('Passwords do not match')
      return
    }
    setOwnBusy(true)
    const { error } = await supabase.auth.updateUser({ password: ownPw })
    setOwnBusy(false)
    if (error) {
      toast.error(error.message)
      return
    }
    toast.success('Your password was updated')
    setOwnPw('')
    setOwnPw2('')
  }

  return (
    <AppShell>
      <div className="reveal mx-auto max-w-3xl">
        <h1 className="font-display text-4xl font-600 tracking-tight text-ink">
          Users
        </h1>
        <p className="mt-3 text-muted">
          Manage who can sign in to {`Call Recap`}. Only the master admin can see this page.
        </p>

        {flash && (
          <div
            className={
              'mt-6 rounded-xl px-4 py-3 text-sm font-600 ' +
              (flash.kind === 'success'
                ? 'bg-good/10 text-good'
                : 'bg-rec/10 text-rec')
            }
          >
            {flash.msg}
          </div>
        )}


        {/* Users list */}
        <div className="mt-10 rounded-card border border-line bg-surface p-8 shadow-card">
          <h2 className="font-display text-xl font-600 tracking-tight text-ink">
            All users
          </h2>
          {loading ? (
            <p className="mt-4 text-sm text-muted">Loading…</p>
          ) : loadError ? (
            <p className="mt-4 rounded-xl bg-rec/10 px-4 py-2.5 text-sm font-500 text-rec">
              {loadError}
            </p>
          ) : (
            <ul className="mt-4 divide-y divide-line">
              {users.map((u) => {
                const isMe = user?.id === u.id
                return (
                  <li key={u.id} className="py-4">
                    <div className="flex flex-wrap items-center justify-between gap-3">
                      <div className="min-w-0">
                        <div className="flex items-center gap-2">
                          <span className="font-600 text-ink">{u.username}</span>
                          {u.is_admin && (
                            <span className="rounded-full bg-accent-soft px-2 py-0.5 text-xs font-600 text-accent">
                              Admin
                            </span>
                          )}
                          {isMe && (
                            <span className="rounded-full bg-line/60 px-2 py-0.5 text-xs font-600 text-muted">
                              You
                            </span>
                          )}
                        </div>
                        <div className="mt-0.5 text-xs text-muted">
                          {u.email} · created{' '}
                          {new Date(u.created_at).toLocaleDateString()}
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        <button
                          onClick={() => openReset(u.id)}
                          className="rounded-full border border-line px-3 py-1.5 text-sm font-600 text-ink-2 hover:bg-line/40"
                        >
                          Reset password
                        </button>
                        {!u.is_admin && (
                          <button
                            onClick={() => onDelete(u)}
                            disabled={deletingId === u.id}
                            className="rounded-full bg-rec/10 px-3 py-1.5 text-sm font-600 text-rec hover:bg-rec/20 disabled:opacity-60"
                          >
                            {deletingId === u.id ? 'Deleting…' : 'Delete'}
                          </button>
                        )}
                      </div>
                    </div>

                    {resetFor === u.id && (
                      <form
                        onSubmit={submitReset}
                        className="mt-3 flex flex-wrap items-center gap-2 rounded-xl border border-line bg-paper/50 p-3"
                      >
                        <input
                          type="password"
                          autoFocus
                          value={resetValue}
                          onChange={(e) => setResetValue(e.target.value)}
                          placeholder="New password"
                          className="min-w-0 flex-1 rounded-lg border border-line bg-paper px-3 py-2 text-sm text-ink"
                        />
                        <button
                          type="submit"
                          disabled={resetBusy || !resetValue}
                          className="rounded-full bg-ink px-4 py-2 text-sm font-600 text-white disabled:opacity-60"
                        >
                          {resetBusy ? 'Saving…' : 'Set password'}
                        </button>
                        <button
                          type="button"
                          onClick={() => setResetFor(null)}
                          className="rounded-full px-3 py-2 text-sm font-600 text-muted hover:bg-line/40"
                        >
                          Cancel
                        </button>
                      </form>
                    )}
                  </li>
                )
              })}
              {users.length === 0 && (
                <li className="py-4 text-sm text-muted">No users.</li>
              )}
            </ul>
          )}
        </div>

        {/* Create user */}
        <form
          onSubmit={onCreate}
          className="mt-8 rounded-card border border-line bg-surface p-8 shadow-card"
        >
          <h2 className="font-display text-xl font-600 tracking-tight text-ink">
            Create user
          </h2>
          <p className="mt-1 text-sm text-muted">
            Username becomes the login (mapped to <code>username@eia.local</code>).
          </p>
          <div className="mt-4 grid gap-4 sm:grid-cols-2">
            <label className="block">
              <span className="mb-1.5 block text-sm font-600 text-ink-2">
                Username
              </span>
              <input
                type="text"
                value={newUsername}
                onChange={(e) => setNewUsername(e.target.value)}
                placeholder="e.g. sarah"
                autoComplete="off"
                className="w-full rounded-xl border border-line bg-paper/50 px-4 py-3 text-ink"
              />
            </label>
            <label className="block">
              <span className="mb-1.5 block text-sm font-600 text-ink-2">
                Password
              </span>
              <input
                type="password"
                value={newPassword}
                onChange={(e) => setNewPassword(e.target.value)}
                placeholder="Set a starting password"
                autoComplete="new-password"
                className="w-full rounded-xl border border-line bg-paper/50 px-4 py-3 text-ink"
              />
            </label>
          </div>
          <div className="mt-5">
            <button
              type="submit"
              disabled={creating || !newUsername.trim() || !newPassword}
              className="rounded-full bg-accent px-7 py-3 text-base font-600 text-white shadow-lift transition-transform hover:-translate-y-0.5 disabled:cursor-not-allowed disabled:opacity-60"
            >
              {creating ? 'Creating…' : 'Create user'}
            </button>
          </div>
        </form>

        {/* Change own password */}
        <form
          onSubmit={onChangeOwn}
          className="mt-8 rounded-card border border-line bg-surface p-8 shadow-card"
        >
          <h2 className="font-display text-xl font-600 tracking-tight text-ink">
            Change my password
          </h2>
          <p className="mt-1 text-sm text-muted">
            Updates your own admin password. You'll stay logged in on this device.
          </p>
          <div className="mt-4 grid gap-4 sm:grid-cols-2">
            <label className="block">
              <span className="mb-1.5 block text-sm font-600 text-ink-2">
                New password
              </span>
              <input
                type="password"
                value={ownPw}
                onChange={(e) => setOwnPw(e.target.value)}
                autoComplete="new-password"
                className="w-full rounded-xl border border-line bg-paper/50 px-4 py-3 text-ink"
              />
            </label>
            <label className="block">
              <span className="mb-1.5 block text-sm font-600 text-ink-2">
                Confirm new password
              </span>
              <input
                type="password"
                value={ownPw2}
                onChange={(e) => setOwnPw2(e.target.value)}
                autoComplete="new-password"
                className="w-full rounded-xl border border-line bg-paper/50 px-4 py-3 text-ink"
              />
            </label>
          </div>
          <div className="mt-5">
            <button
              type="submit"
              disabled={ownBusy || !ownPw || ownPw !== ownPw2}
              className="rounded-full bg-ink px-7 py-3 text-base font-600 text-white transition-transform hover:-translate-y-0.5 disabled:cursor-not-allowed disabled:opacity-60"
            >
              {ownBusy ? 'Updating…' : 'Update password'}
            </button>
          </div>
        </form>
      </div>
    </AppShell>
  )
}
