import { useEffect, useState } from 'react'
import { Navigate, useNavigate } from 'react-router-dom'
import Brand from '../components/Brand'
import { useAuth } from '../context/AuthContext'
import { usernameToEmail } from '../lib/authConfig'

export default function Landing() {
  const navigate = useNavigate()
  const { session, loading, signIn } = useAuth()

  const [username, setUsername] = useState('')
  const [password, setPassword] = useState('')
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState<string | null>(null)

  // Redirect once a session appears after a successful sign-in.
  useEffect(() => {
    if (session) navigate('/record', { replace: true })
  }, [session, navigate])

  // Already signed in → straight to the recorder (avoids a flash of the form).
  if (!loading && session) return <Navigate to="/record" replace />

  const onSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setError(null)
    setBusy(true)

    // Username is mapped to a fixed internal email behind the scenes.
    const { error } = await signIn(usernameToEmail(username), password)

    setBusy(false)

    if (error) {
      setError('Incorrect username or password.')
      return
    }
    // The effect above handles the redirect once the session is set.
  }

  return (
    <div className="relative min-h-full overflow-hidden">
      {/* Background: dotted grid + soft indigo radial glows (§8) */}
      <div
        aria-hidden
        className="pointer-events-none absolute inset-0 opacity-60"
        style={{
          backgroundImage:
            'radial-gradient(rgba(21,23,42,0.07) 1px, transparent 1px)',
          backgroundSize: '22px 22px',
        }}
      />
      <div
        aria-hidden
        className="pointer-events-none absolute -left-40 -top-40 h-[36rem] w-[36rem] rounded-full blur-3xl"
        style={{ background: 'radial-gradient(circle, rgba(124,116,255,0.22), transparent 60%)' }}
      />
      <div
        aria-hidden
        className="pointer-events-none absolute -bottom-48 right-[-12rem] h-[40rem] w-[40rem] rounded-full blur-3xl"
        style={{ background: 'radial-gradient(circle, rgba(79,70,229,0.16), transparent 60%)' }}
      />

      <div className="relative mx-auto max-w-6xl px-6">
        <header className="reveal flex items-center justify-between py-7" style={{ animationDelay: '0ms' }}>
          <Brand />
        </header>

        <div className="grid items-center gap-12 py-12 lg:grid-cols-[1.1fr_0.9fr] lg:py-20">
          {/* Hero */}
          <div>
            <p
              className="reveal mb-5 inline-flex items-center gap-2 rounded-full border border-line bg-surface/70 px-4 py-1.5 text-xs font-600 text-muted"
              style={{ animationDelay: '80ms' }}
            >
              <span className="h-2 w-2 rounded-full bg-good" />
              Briefings, captured to the last word
            </p>
            <h1
              className="reveal font-display text-5xl font-600 leading-[1.05] tracking-tight text-ink sm:text-6xl"
              style={{ animationDelay: '160ms' }}
            >
              Never lose what was
              <br />
              said only once.
            </h1>
            <p
              className="reveal mt-6 max-w-md text-lg leading-relaxed text-muted"
              style={{ animationDelay: '240ms' }}
            >
              Press record, talk through the task, and EIA turns your briefing
              into a clean, worker-ready summary — what to do, the details, the
              deadlines. Ready to copy, download, or send.
            </p>
          </div>

          {/* Sign-in card — feels like a product home, not a login form (§8) */}
          <div
            className="reveal rounded-card border border-line bg-surface p-8 shadow-lift"
            style={{ animationDelay: '400ms' }}
          >
            <h2 className="font-display text-2xl font-600 tracking-tight text-ink">
              Sign in
            </h2>
            <p className="mt-1 text-sm text-muted">
              Your meetings stay private and auto-delete in 3 days.
            </p>

            <form onSubmit={onSubmit} className="mt-6 space-y-4">
              <Field label="Username">
                <input
                  type="text"
                  required
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  placeholder="Your username"
                  autoComplete="username"
                  autoFocus
                  className="w-full rounded-xl border border-line bg-paper/50 px-4 py-3 text-ink placeholder:text-muted/70"
                />
              </Field>
              <Field label="Password">
                <input
                  type="password"
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="Your password"
                  autoComplete="current-password"
                  className="w-full rounded-xl border border-line bg-paper/50 px-4 py-3 text-ink placeholder:text-muted/70"
                />
              </Field>

              {error && (
                <p className="rounded-xl bg-rec/10 px-4 py-2.5 text-sm font-500 text-rec">
                  {error}
                </p>
              )}

              <button
                type="submit"
                disabled={busy}
                className="w-full rounded-xl bg-ink px-5 py-3.5 text-base font-600 text-white transition-transform hover:-translate-y-0.5 disabled:cursor-not-allowed disabled:opacity-60"
              >
                {busy ? 'Signing in…' : 'Sign In'}
              </button>
            </form>
          </div>
        </div>
      </div>
    </div>
  )
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <label className="block">
      <span className="mb-1.5 block text-sm font-600 text-ink-2">{label}</span>
      {children}
    </label>
  )
}
