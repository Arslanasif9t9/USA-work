// Guarded service-worker registration for Call Recap.
// Registers /sw.js only in production browser contexts. Never in the Lovable
// editor preview, iframes, dev, or when ?sw=off is present.
export function registerPWA() {
  if (typeof window === 'undefined') return;
  if (!('serviceWorker' in navigator)) return;

  const url = new URL(window.location.href);
  const host = window.location.hostname;
  const inIframe = window.self !== window.top;
  const swOff = url.searchParams.get('sw') === 'off';

  const isPreviewHost =
    host.startsWith('id-preview--') ||
    host.startsWith('preview--') ||
    host === 'lovableproject.com' ||
    host.endsWith('.lovableproject.com') ||
    host === 'lovableproject-dev.com' ||
    host.endsWith('.lovableproject-dev.com') ||
    host === 'beta.lovable.dev' ||
    host.endsWith('.beta.lovable.dev');

  const shouldRefuse = !import.meta.env.PROD || inIframe || isPreviewHost || swOff;

  if (shouldRefuse) {
    // Unregister any matching app SW from prior visits so preview stays fresh.
    navigator.serviceWorker.getRegistrations().then((regs) => {
      regs.forEach((reg) => {
        const scriptURL = reg.active?.scriptURL || reg.installing?.scriptURL || reg.waiting?.scriptURL || '';
        if (scriptURL.endsWith('/sw.js')) reg.unregister().catch(() => {});
      });
    }).catch(() => {});
    return;
  }

  window.addEventListener('load', () => {
    navigator.serviceWorker.register('/sw.js').catch(() => {});
  });
}
