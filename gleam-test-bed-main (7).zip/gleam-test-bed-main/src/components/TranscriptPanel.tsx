import CopyButton from './CopyButton'
import AutoTextarea from './AutoTextarea'
import { downloadPdf, downloadTxt } from '../lib/exports'

const TRANSCRIPT_TITLE = 'Transcript'

function countWords(text: string): number {
  return text.trim().split(/\s+/).filter(Boolean).length
}

/**
 * Always-available full transcript (Phase 9 fallback): read-only text plus
 * Copy / PDF / .txt, so the user is never blocked even if the AI summary fails.
 */
export default function TranscriptPanel({ transcript }: { transcript: string }) {
  return (
    <div>
      <div className="mb-2 flex items-center justify-between">
        <span className="text-sm font-600 text-ink-2">Transcript</span>
        <span className="font-mono text-xs text-muted">
          {countWords(transcript)} words
        </span>
      </div>
      <AutoTextarea
        readOnly
        value={transcript}
        maxHeight={360}
        className="w-full rounded-xl border border-line bg-paper/40 px-4 py-3 text-sm leading-relaxed text-ink-2"
      />
      <div className="mt-3 flex flex-wrap gap-2">
        <CopyButton
          text={transcript}
          label="Copy transcript"
          className="rounded-full border border-line bg-surface px-5 py-2.5 text-sm font-600 text-ink-2 transition-transform hover:-translate-y-0.5"
        />
        <button
          onClick={() => void downloadPdf(TRANSCRIPT_TITLE, transcript)}
          className="rounded-full border border-line bg-surface px-5 py-2.5 text-sm font-600 text-ink-2 transition-transform hover:-translate-y-0.5"
        >
          Download PDF
        </button>
        <button
          onClick={() => downloadTxt(TRANSCRIPT_TITLE, transcript)}
          className="rounded-full border border-line bg-surface px-5 py-2.5 text-sm font-600 text-ink-2 transition-transform hover:-translate-y-0.5"
        >
          Download .txt
        </button>
      </div>
    </div>
  )
}
