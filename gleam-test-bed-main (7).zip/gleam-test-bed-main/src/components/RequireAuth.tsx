import type { ReactNode } from 'react'
import { Navigate } from 'react-router-dom'
import { useAuth } from '../context/AuthContext'

/** Gates in-app pages: redirects to the landing page when not signed in. */
export default function RequireAuth({ children }: { children: ReactNode }) {
  const { session, loading } = useAuth()

  if (loading) {
    return (
      <div className="grid min-h-full place-items-center">
        <p className="font-mono text-sm text-muted">Loading…</p>
      </div>
    )
  }

  if (!session) return <Navigate to="/" replace />

  return <>{children}</>
}
