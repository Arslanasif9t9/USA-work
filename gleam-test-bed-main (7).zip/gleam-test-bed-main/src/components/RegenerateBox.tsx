import { useState } from 'react'

const PRESETS: { label: string; instruction: string }[] = [
  { label: 'As a paragraph', instruction: 'Rewrite as a detailed paragraph instead of bullet points.' },
  { label: 'Remove personal details', instruction: 'Remove any personal or sensitive details.' },
  { label: 'Tasks only', instruction: 'List only the tasks / action items, nothing else.' },
  { label: 'Shorter', instruction: 'Make it shorter and more concise.' },
  { label: 'Formal English', instruction: 'Rewrite in formal English.' },
]

interface Props {
  regenerating: boolean
  disabled?: boolean
  onRegenerate: (instruction: string) => void
}

/**
 * Full-width "Regenerate with AI" row: instruction input + button on one line,
 * with preset chips wrapping horizontally beneath.
 */
export default function RegenerateBox({
  regenerating,
  disabled = false,
  onRegenerate,
}: Props) {
  const [instruction, setInstruction] = useState('')
  const busy = regenerating || disabled

  return (
    <div>
      <div className="text-sm font-600 text-ink-2">Regenerate with AI</div>
      <p className="mt-0.5 text-xs text-muted">
        Leave empty for the default summary, or type how you want it rewritten.
      </p>

      <form
        onSubmit={(e) => {
          e.preventDefault()
          if (!busy) onRegenerate(instruction.trim())
        }}
        className="mt-3 flex flex-col gap-2 sm:flex-row"
      >
        <input
          type="text"
          value={instruction}
          onChange={(e) => setInstruction(e.target.value)}
          placeholder="e.g. as a detailed paragraph, tasks only, shorter…"
          className="flex-1 rounded-xl border border-line bg-surface px-4 py-2.5 text-sm text-ink placeholder:text-muted/70"
        />
        <button
          type="submit"
          disabled={busy}
          className="rounded-xl bg-ink px-6 py-2.5 text-sm font-600 text-white transition-transform hover:-translate-y-0.5 disabled:cursor-not-allowed disabled:opacity-60"
        >
          {regenerating ? 'Regenerating…' : 'Regenerate'}
        </button>
      </form>

      {/* Preset chips, wrapping horizontally */}
      <div className="mt-3 flex flex-wrap gap-2">
        {PRESETS.map((p) => (
          <button
            key={p.label}
            disabled={busy}
            onClick={() => {
              setInstruction(p.instruction)
              onRegenerate(p.instruction)
            }}
            className="rounded-full border border-line bg-surface px-3 py-1.5 text-xs font-600 text-ink-2 transition-colors hover:bg-accent-soft hover:text-accent disabled:opacity-50"
          >
            {p.label}
          </button>
        ))}
      </div>
    </div>
  )
}
