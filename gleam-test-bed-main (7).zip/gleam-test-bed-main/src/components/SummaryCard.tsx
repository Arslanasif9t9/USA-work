import { useState } from 'react'
import AutoTextarea from './AutoTextarea'
import { listGroups, sendToGroup, type PmsGroup } from '../lib/sendToGroup'
import {
  copyText,
  downloadPdf,
  downloadTxt,
  mailtoUrl,
  whatsappUrl,
} from '../lib/exports'

export type SaveState = 'idle' | 'saving' | 'saved' | 'error'

function formatTime(totalSeconds: number): string {
  const s = Math.max(0, Math.floor(totalSeconds))
  const mm = String(Math.floor(s / 60)).padStart(2, '0')
  const ss = String(s % 60).padStart(2, '0')
  return `${mm}:${ss}`
}

interface Props {
  title: string
  summary: string
  durationSec: number
  wordCount: number
  saveState: SaveState
  onChangeTitle: (t: string) => void
  onChangeSummary: (s: string) => void
}

export default function SummaryCard({
  title,
  summary,
  durationSec,
  wordCount,
  saveState,
  onChangeTitle,
  onChangeSummary,
}: Props) {
  const [copied, setCopied] = useState(false)

  // "Send to group" (push the summary into a PMS Tessera group as a task).
  const [pickerOpen, setPickerOpen] = useState(false)
  const [groups, setGroups] = useState<PmsGroup[]>([])
  const [loadingGroups, setLoadingGroups] = useState(false)
  const [groupsError, setGroupsError] = useState<string | null>(null)
  const [sendingId, setSendingId] = useState<string | null>(null)
  const [sendResult, setSendResult] = useState<
    { ok: boolean; text: string } | null
  >(null)

  const handleCopy = async () => {
    const ok = await copyText(summary)
    if (ok) {
      setCopied(true)
      window.setTimeout(() => setCopied(false), 1800)
    }
  }

  const togglePicker = async () => {
    if (pickerOpen) {
      setPickerOpen(false)
      return
    }
    setPickerOpen(true)
    setSendResult(null)
    if (groups.length === 0) {
      setLoadingGroups(true)
      setGroupsError(null)
      try {
        setGroups(await listGroups())
      } catch (e) {
        setGroupsError(e instanceof Error ? e.message : 'Could not load groups.')
      } finally {
        setLoadingGroups(false)
      }
    }
  }

  const pickGroup = async (g: PmsGroup) => {
    setSendingId(g.id)
    setSendResult(null)
    try {
      const name = title.trim() || 'Meeting summary'
      const { task_code } = await sendToGroup(g.id, name, summary)
      setSendResult({ ok: true, text: `Sent to ${g.name} as ${task_code}` })
      setPickerOpen(false)
    } catch (e) {
      setSendResult({
        ok: false,
        text: e instanceof Error ? e.message : 'Could not send to the group.',
      })
    } finally {
      setSendingId(null)
    }
  }

  const saveLabel =
    saveState === 'saving'
      ? 'Saving…'
      : saveState === 'saved'
        ? 'Saved'
        : saveState === 'error'
          ? 'Save failed'
          : ''

  return (
    <div className="w-full text-left">
      {/* Editable title */}
      <input
        type="text"
        value={title}
        onChange={(e) => onChangeTitle(e.target.value)}
        placeholder="Untitled summary"
        className="w-full rounded-xl border border-transparent bg-transparent font-display text-2xl font-600 tracking-tight text-ink hover:border-line focus:border-line"
      />

      {/* Meta: duration · word count · save state */}
      <div className="mt-1 flex items-center gap-3 px-1 font-mono text-xs text-muted">
        <span>{formatTime(durationSec)}</span>
        <span aria-hidden>·</span>
        <span>{wordCount} words</span>
        {saveLabel && (
          <>
            <span aria-hidden>·</span>
            <span className={saveState === 'error' ? 'text-rec' : saveState === 'saved' ? 'text-good' : ''}>
              {saveLabel}
            </span>
          </>
        )}
      </div>

      {/* Editable summary — auto-grows to fit its text */}
      <AutoTextarea
        value={summary}
        onChange={onChangeSummary}
        maxHeight={360}
        className="mt-4 w-full rounded-xl border border-line bg-paper/40 px-4 py-3 text-sm leading-relaxed text-ink-2"
      />

      {/* Actions — Copy is the most prominent (§4) */}
      <div className="mt-4 flex flex-wrap items-center gap-2">
        <button
          onClick={handleCopy}
          className="rounded-full bg-accent px-7 py-3 text-base font-600 text-white shadow-lift transition-transform hover:-translate-y-0.5"
        >
          {copied ? 'Copied!' : 'Copy'}
        </button>

        <a
          href={mailtoUrl(title, summary)}
          className="rounded-full border border-line bg-surface px-5 py-3 text-sm font-600 text-ink-2 transition-transform hover:-translate-y-0.5"
        >
          Email
        </a>
        <a
          href={whatsappUrl(title, summary)}
          target="_blank"
          rel="noopener noreferrer"
          className="rounded-full border border-line bg-surface px-5 py-3 text-sm font-600 text-ink-2 transition-transform hover:-translate-y-0.5"
        >
          WhatsApp
        </a>
        <button
          onClick={() => void downloadPdf(title, summary)}
          className="rounded-full border border-line bg-surface px-5 py-3 text-sm font-600 text-ink-2 transition-transform hover:-translate-y-0.5"
        >
          Download PDF
        </button>
        <button
          onClick={() => downloadTxt(title, summary)}
          className="rounded-full border border-line bg-surface px-5 py-3 text-sm font-600 text-ink-2 transition-transform hover:-translate-y-0.5"
        >
          Download .txt
        </button>

        {/* Send to group → PMS Tessera */}
        <div className="relative">
          <button
            onClick={() => void togglePicker()}
            disabled={sendingId !== null}
            className="rounded-full border border-line bg-surface px-5 py-3 text-sm font-600 text-ink-2 transition-transform hover:-translate-y-0.5 disabled:opacity-60"
          >
            {sendingId !== null ? 'Sending…' : 'Send to group'}
          </button>

          {pickerOpen && (
            <div className="absolute left-0 z-20 mt-2 w-72 rounded-2xl border border-line bg-surface p-2 shadow-lift">
              <div className="px-2 py-1.5 text-xs font-600 text-muted">
                Pick a group
              </div>
              {loadingGroups ? (
                <div className="px-2 py-3 text-sm text-muted">Loading groups…</div>
              ) : groupsError ? (
                <div className="px-2 py-3 text-sm font-500 text-rec">
                  {groupsError}
                </div>
              ) : groups.length === 0 ? (
                <div className="px-2 py-3 text-sm text-muted">
                  No groups found.
                </div>
              ) : (
                <ul className="max-h-64 overflow-y-auto">
                  {groups.map((g) => (
                    <li key={g.id}>
                      <button
                        onClick={() => void pickGroup(g)}
                        disabled={sendingId !== null}
                        className="flex w-full items-center gap-2 rounded-xl px-2 py-2 text-left text-sm text-ink-2 transition-colors hover:bg-accent-soft disabled:opacity-60"
                      >
                        <span
                          aria-hidden
                          className="h-2.5 w-2.5 shrink-0 rounded-full"
                          style={{ backgroundColor: g.color || 'var(--color-muted)' }}
                        />
                        <span className="truncate">{g.name}</span>
                        {sendingId === g.id && (
                          <span className="ml-auto text-xs text-muted">Sending…</span>
                        )}
                      </button>
                    </li>
                  ))}
                </ul>
              )}
            </div>
          )}
        </div>
      </div>

      {sendResult && (
        <p
          className={`mt-3 rounded-xl px-4 py-2.5 text-sm font-500 ${
            sendResult.ok ? 'bg-good/10 text-good' : 'bg-rec/10 text-rec'
          }`}
        >
          {sendResult.text}
        </p>
      )}
    </div>
  )
}
