import { useState } from 'react'
import { copyText } from '../lib/exports'

/**
 * Copy-to-clipboard button with transient "Copied!" feedback.
 * `text` may be a string or a lazy getter (e.g. to build large text on click).
 */
export default function CopyButton({
  text,
  label,
  className,
}: {
  text: string | (() => string)
  label: string
  className?: string
}) {
  const [copied, setCopied] = useState(false)

  const onClick = async () => {
    const value = typeof text === 'function' ? text() : text
    if (await copyText(value)) {
      setCopied(true)
      window.setTimeout(() => setCopied(false), 1800)
    }
  }

  return (
    <button type="button" onClick={onClick} className={className}>
      {copied ? 'Copied!' : label}
    </button>
  )
}
