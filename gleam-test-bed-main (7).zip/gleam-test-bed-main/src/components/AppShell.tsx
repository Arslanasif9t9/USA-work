import type { ReactNode } from 'react'
import { NavLink, useNavigate } from 'react-router-dom'
import Brand from './Brand'
import { useAuth } from '../context/AuthContext'

const navItem = ({ isActive }: { isActive: boolean }) =>
  [
    'rounded-full px-3 py-2 text-sm font-600 transition-colors sm:px-4',
    isActive
      ? 'bg-accent-soft text-accent'
      : 'text-muted hover:text-ink hover:bg-line/50',
  ].join(' ')

/** Shared chrome for the in-app pages (Recorder / Settings). */
export default function AppShell({ children }: { children: ReactNode }) {
  const navigate = useNavigate()
  const { signOut, company, isAdmin } = useAuth()

  const onSignOut = async () => {
    await signOut()
    navigate('/', { replace: true })
  }

  return (
    <div className="min-h-full">
      <header className="sticky top-0 z-10 border-b border-line/70 bg-paper/80 backdrop-blur">
        <div className="mx-auto flex max-w-5xl items-center justify-between gap-4 px-6 py-4">
          <button
            onClick={() => navigate('/')}
            className="rounded-2xl transition-transform hover:-translate-y-0.5"
            aria-label="Go to home"
          >
            <Brand company={company} />
          </button>
          <nav className="flex items-center gap-0.5 sm:gap-1">
            <NavLink to="/record" className={navItem}>
              Record
            </NavLink>
            <NavLink to="/history" className={navItem}>
              History
            </NavLink>
            {isAdmin && (
              <NavLink to="/users" className={navItem}>
                Users
              </NavLink>
            )}
            {isAdmin && (
              <NavLink to="/settings" className={navItem}>
                Settings
              </NavLink>
            )}
            <button
              onClick={onSignOut}
              className="rounded-full px-3 py-2 text-sm font-600 text-muted transition-colors hover:bg-line/50 hover:text-ink sm:px-4"
            >
              Sign out
            </button>
          </nav>
        </div>
      </header>
      <main className="mx-auto max-w-6xl px-4 py-6 sm:px-6">{children}</main>
    </div>
  )
}
