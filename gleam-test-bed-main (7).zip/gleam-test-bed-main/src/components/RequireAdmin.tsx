import type { ReactNode } from 'react'
import { Navigate } from 'react-router-dom'
import { useAuth } from '../context/AuthContext'

/** Gates admin-only pages (currently /settings). Non-admin → /record. */
export default function RequireAdmin({ children }: { children: ReactNode }) {
  const { isAdmin, loading } = useAuth()

  if (loading) {
    return (
      <div className="grid min-h-full place-items-center">
        <p className="font-mono text-sm text-muted">Loading…</p>
      </div>
    )
  }

  if (!isAdmin) return <Navigate to="/record" replace />

  return <>{children}</>
}
