import { useEffect, useRef } from 'react'

/**
 * A textarea that grows to fit its content. With no `maxHeight` it expands
 * fully (no scrollbar). With `maxHeight` it caps there and scrolls internally.
 * Used for the transcript (read-only) and the editable summary.
 */
export default function AutoTextarea({
  value,
  onChange,
  readOnly = false,
  placeholder,
  className = '',
  minHeight = 96,
  maxHeight,
}: {
  value: string
  onChange?: (v: string) => void
  readOnly?: boolean
  placeholder?: string
  className?: string
  minHeight?: number
  maxHeight?: number
}) {
  const ref = useRef<HTMLTextAreaElement>(null)

  const resize = () => {
    const el = ref.current
    if (!el) return
    el.style.height = 'auto'
    const h = Math.min(maxHeight ?? Infinity, Math.max(minHeight, el.scrollHeight))
    el.style.height = `${h}px`
    el.style.overflowY = maxHeight && el.scrollHeight > maxHeight ? 'auto' : 'hidden'
  }

  // Re-fit when the text changes…
  useEffect(resize, [value, minHeight, maxHeight])
  // …and when the viewport width changes (wrapping changes the height).
  useEffect(() => {
    window.addEventListener('resize', resize)
    return () => window.removeEventListener('resize', resize)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  return (
    <textarea
      ref={ref}
      value={value}
      readOnly={readOnly}
      placeholder={placeholder}
      onChange={onChange ? (e) => onChange(e.target.value) : undefined}
      className={`resize-none overflow-hidden ${className}`}
    />
  )
}
