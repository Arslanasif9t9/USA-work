import { useEffect, useState } from 'react'
import { createPortal } from 'react-dom'
import { Check, Copy as CopyIcon } from 'lucide-react'
import type { MeetingRow } from '../lib/meetings'
import { deleteMeeting, updateMeeting } from '../lib/meetings'
import { summarizeTranscript } from '../lib/ai'
import { getProfileSettings } from '../lib/profile'
import { useAuth } from '../context/AuthContext'
import {
  copyText,
  downloadPdf,
  downloadTxt,
  mailtoUrl,
  whatsappUrl,
} from '../lib/exports'
import { formatDate, formatDuration } from '../lib/format'

interface Props {
  meeting: MeetingRow
  onClose: () => void
  onDeleted: (id: string) => void
}

/** Small copy icon button used in the top-right of transcript/summary boxes. */
function CornerCopyButton({
  getText,
  ariaLabel,
}: {
  getText: () => string
  ariaLabel: string
}) {
  const [copied, setCopied] = useState(false)
  const onClick = async () => {
    const value = getText()
    if (!value) return
    if (await copyText(value)) {
      setCopied(true)
      window.setTimeout(() => setCopied(false), 1600)
    }
  }
  return (
    <button
      type="button"
      onClick={onClick}
      aria-label={ariaLabel}
      className="absolute right-2 top-2 grid h-8 w-8 place-items-center rounded-lg border border-line bg-surface/90 p-1.5 text-muted shadow-sm backdrop-blur transition-colors hover:bg-line/40 hover:text-ink"
    >
      {copied ? <Check size={16} /> : <CopyIcon size={16} />}
    </button>
  )
}

/** Read-only viewer for a saved meeting: full summary + actions + delete. */
export default function MeetingModal({ meeting, onClose, onDeleted }: Props) {
  const { user } = useAuth()
  const [copied, setCopied] = useState(false)
  const [confirmDelete, setConfirmDelete] = useState(false)
  const [deleting, setDeleting] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [title, setTitle] = useState(meeting.title)
  const [summary, setSummary] = useState(meeting.summary)
  const [summarizing, setSummarizing] = useState(false)
  const [summaryError, setSummaryError] = useState<string | null>(null)

  const transcriptSource =
    (meeting.transcript && meeting.transcript.trim()) ||
    (meeting.live_caption && meeting.live_caption.trim()) ||
    ''
  const hasSummary = summary && summary.trim() !== ''
  const canGenerate = !hasSummary && transcriptSource !== ''
  const hasFinalTranscript =
    !!meeting.transcript && meeting.transcript.trim() !== ''

  const handleGenerate = async () => {
    setSummaryError(null)
    setSummarizing(true)
    try {
      let model: string | undefined
      if (user) {
        try {
          const settings = await getProfileSettings(user.id)
          model = settings.ai_model
        } catch {
          // fall back to server default
        }
      }
      const result = await summarizeTranscript(transcriptSource, '', model)
      setTitle(result.title)
      setSummary(result.summary)
      await updateMeeting(meeting.id, {
        title: result.title,
        summary: result.summary,
      })
    } catch (e) {
      setSummaryError(
        e instanceof Error ? e.message : 'Could not generate the summary.',
      )
    } finally {
      setSummarizing(false)
    }
  }

  // Close on Esc and lock background scroll while the dialog is open.
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose()
    }
    window.addEventListener('keydown', onKey)
    const prevOverflow = document.body.style.overflow
    document.body.style.overflow = 'hidden'
    return () => {
      window.removeEventListener('keydown', onKey)
      document.body.style.overflow = prevOverflow
    }
  }, [onClose])

  const handleCopy = async () => {
    // Primary Copy now copies the FINAL TRANSCRIPT, falling back to summary.
    const text =
      (meeting.transcript && meeting.transcript.trim()) ||
      summary ||
      ''
    if (!text) return
    if (await copyText(text)) {
      setCopied(true)
      window.setTimeout(() => setCopied(false), 1800)
    }
  }

  const handleDelete = async () => {
    setError(null)
    setDeleting(true)
    try {
      await deleteMeeting(meeting.id)
      onDeleted(meeting.id)
    } catch {
      setError('Could not delete this meeting. Please try again.')
      setDeleting(false)
    }
  }

  return createPortal(
    <div
      role="dialog"
      aria-modal="true"
      className="fixed inset-0 z-50 flex items-center justify-center bg-ink/50 p-4 backdrop-blur-sm"
      onClick={onClose}
    >
      <div
        className="relative flex max-h-[90vh] w-full max-w-2xl flex-col overflow-hidden rounded-card border border-line bg-surface shadow-lift"
        onClick={(e) => e.stopPropagation()}
      >
        <button
          onClick={onClose}
          aria-label="Close"
          className="absolute right-4 top-4 z-10 grid h-9 w-9 place-items-center rounded-full bg-surface/80 text-muted transition-colors hover:bg-line/50 hover:text-ink"
        >
          ✕
        </button>

        {/* 1. Header — fixed, does not scroll */}
        <div className="shrink-0 border-b border-line px-7 pb-4 pt-7">
          <h2 className="pr-10 font-display text-2xl font-600 tracking-tight text-ink">
            {title || 'Untitled summary'}
          </h2>
          <div className="mt-1 flex flex-wrap items-center gap-3 font-mono text-xs text-muted">
            <span>{formatDate(meeting.created_at)}</span>
            <span aria-hidden>·</span>
            <span>{formatDuration(meeting.duration_sec)}</span>
            <span aria-hidden>·</span>
            <span>{meeting.word_count} words</span>
          </div>
        </div>

        {/* Body — scrolls inside the dialog */}
        <div className="min-h-0 flex-1 overflow-y-auto px-7 py-5">
          {/* 2. Actions — moved to the top, directly under the heading */}
          <div className="flex flex-wrap items-center gap-2">
            <button
              onClick={handleCopy}
              className="rounded-full bg-accent px-7 py-3 text-base font-600 text-white shadow-lift transition-transform hover:-translate-y-0.5"
            >
              {copied ? 'Copied!' : 'Copy'}
            </button>
            <a
              href={mailtoUrl(title, summary)}
              className="rounded-full border border-line bg-surface px-5 py-3 text-sm font-600 text-ink-2 transition-transform hover:-translate-y-0.5"
            >
              Email
            </a>
            <a
              href={whatsappUrl(title, summary)}
              target="_blank"
              rel="noopener noreferrer"
              className="rounded-full border border-line bg-surface px-5 py-3 text-sm font-600 text-ink-2 transition-transform hover:-translate-y-0.5"
            >
              WhatsApp
            </a>
            <button
              onClick={() => void downloadPdf(title, summary)}
              className="rounded-full border border-line bg-surface px-5 py-3 text-sm font-600 text-ink-2 transition-transform hover:-translate-y-0.5"
            >
              Download PDF
            </button>
            <button
              onClick={() => downloadTxt(title, summary)}
              className="rounded-full border border-line bg-surface px-5 py-3 text-sm font-600 text-ink-2 transition-transform hover:-translate-y-0.5"
            >
              Download .txt
            </button>
          </div>

          {/* 3. Final transcript */}
          {hasFinalTranscript && (
            <div className="mt-5">
              <h3 className="mb-2 font-display text-sm font-600 tracking-tight text-ink">
                Final transcript
              </h3>
              <div className="relative">
                <CornerCopyButton
                  getText={() => meeting.transcript || ''}
                  ariaLabel="Copy final transcript"
                />
                <div className="max-h-72 overflow-y-auto whitespace-pre-wrap rounded-xl border border-line bg-paper/40 px-4 py-3 pr-12 text-sm leading-relaxed text-ink-2">
                  {meeting.transcript}
                </div>
              </div>
            </div>
          )}

          {/* 4. Summary */}
          <div className="mt-5">
            <h3 className="mb-2 font-display text-sm font-600 tracking-tight text-ink">
              Summary
            </h3>
            {hasSummary ? (
              <div className="relative">
                <CornerCopyButton
                  getText={() => summary || ''}
                  ariaLabel="Copy summary"
                />
                <div className="whitespace-pre-wrap rounded-xl border border-line bg-paper/40 px-4 py-3 pr-12 text-sm leading-relaxed text-ink-2">
                  {summary}
                </div>
              </div>
            ) : summarizing ? (
              <div className="rounded-xl border border-line bg-paper/40 px-4 py-6 text-center text-sm text-muted">
                Writing the summary…
              </div>
            ) : canGenerate ? (
              <div className="rounded-xl border border-dashed border-line bg-paper/40 px-4 py-6 text-center">
                <p className="mb-3 text-sm text-muted">
                  No summary yet for this meeting.
                </p>
                <button
                  onClick={() => void handleGenerate()}
                  className="rounded-full bg-accent px-6 py-2.5 text-sm font-600 text-white transition-transform hover:-translate-y-0.5"
                >
                  Get Summary
                </button>
                {summaryError && (
                  <p className="mt-3 text-xs font-500 text-rec">
                    {summaryError}{' '}
                    <button
                      onClick={() => void handleGenerate()}
                      className="underline"
                    >
                      Try again
                    </button>
                  </p>
                )}
              </div>
            ) : (
              <div className="rounded-xl border border-dashed border-line bg-paper/40 px-4 py-6 text-center text-sm text-muted">
                No summary or transcript available.
              </div>
            )}
          </div>

          {/* 5. Live caption — unchanged, last content box */}
          {meeting.live_caption && meeting.live_caption.trim() !== '' && (
            <div className="mt-5">
              <h3 className="mb-2 font-display text-sm font-600 tracking-tight text-ink">
                Live caption
              </h3>
              <div className="max-h-72 overflow-y-auto whitespace-pre-wrap rounded-xl border border-line bg-paper/40 px-4 py-3 text-sm leading-relaxed text-ink-2">
                {meeting.live_caption}
              </div>
            </div>
          )}

          {error && (
            <p className="mt-4 rounded-xl bg-rec/10 px-4 py-2.5 text-sm font-500 text-rec">
              {error}
            </p>
          )}

          {/* 6. Delete — stays at the very bottom */}
          <div className="mt-6 border-t border-line pt-4">
            {!confirmDelete ? (
              <button
                onClick={() => setConfirmDelete(true)}
                className="text-sm font-600 text-rec transition-colors hover:underline"
              >
                Delete this meeting
              </button>
            ) : (
              <div className="flex items-center gap-3">
                <span className="text-sm text-ink-2">Delete permanently?</span>
                <button
                  onClick={handleDelete}
                  disabled={deleting}
                  className="rounded-full bg-rec px-5 py-2 text-sm font-600 text-white transition-transform hover:-translate-y-0.5 disabled:opacity-60"
                >
                  {deleting ? 'Deleting…' : 'Yes, delete'}
                </button>
                <button
                  onClick={() => setConfirmDelete(false)}
                  disabled={deleting}
                  className="rounded-full px-4 py-2 text-sm font-600 text-muted transition-colors hover:text-ink"
                >
                  Cancel
                </button>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>,
    document.body,
  )
}
