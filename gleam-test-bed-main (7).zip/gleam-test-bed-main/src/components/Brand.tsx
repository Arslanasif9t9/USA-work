import { COMPANY_DEFAULT } from '../lib/profile'

/**
 * EIA brand mark (§8):
 *  - Monogram badge "EIA" — rounded square, ink background, white serif.
 *  - Wordmark "EIA" + the company name as the subtitle (configurable in
 *    Settings; defaults to "EIA — Intuitive Expert Advisor Inc.").
 */
export default function Brand({
  company = COMPANY_DEFAULT,
  showSubtitle = true,
}: {
  company?: string
  showSubtitle?: boolean
}) {
  return (
    <div className="flex items-center gap-3">
      <div className="grid h-11 w-11 place-items-center rounded-2xl bg-ink text-surface shadow-card">
        <span className="font-display text-lg font-600 leading-none tracking-tight">
          EIA
        </span>
      </div>
      <div className="leading-tight">
        <div className="font-display text-xl font-600 tracking-tight text-ink">
          EIA
        </div>
        {showSubtitle && (
          <div className="hidden max-w-[16rem] truncate text-xs font-500 text-muted sm:block">
            {company}
          </div>
        )}
      </div>
    </div>
  )
}
