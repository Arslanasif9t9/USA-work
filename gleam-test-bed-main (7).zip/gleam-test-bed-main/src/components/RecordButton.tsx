export type RecordState = 'idle' | 'recording' | 'paused'

/**
 * The big circular record button (§8):
 *   idle      → indigo, mic icon
 *   recording → red with a soft pulse, stop icon
 *   paused    → amber, stop icon
 * Clicking starts (when idle) or stops (when recording/paused) — pausing has
 * its own separate control.
 */
export default function RecordButton({
  state,
  level = 0,
  onClick,
}: {
  state: RecordState
  level?: number
  onClick: () => void
}) {
  const active = state !== 'idle'
  const bg =
    state === 'recording'
      ? 'bg-rec'
      : state === 'paused'
        ? 'bg-amber'
        : 'bg-accent'

  // Mic level gives the recording button a subtle, live "breathing" glow.
  const glow =
    state === 'recording'
      ? `0 0 0 ${6 + level * 22}px rgba(229,72,77,0.12)`
      : 'none'

  return (
    <button
      type="button"
      onClick={onClick}
      aria-label={active ? 'Stop recording' : 'Start recording'}
      className={[
        'grid h-40 w-40 place-items-center rounded-full text-white transition-all duration-300',
        bg,
        'shadow-lift hover:scale-105 active:scale-100',
        state === 'recording' ? 'rec-pulse' : '',
      ].join(' ')}
      style={{ boxShadow: glow }}
    >
      {active ? (
        // Stop icon (rounded square)
        <span className="block h-12 w-12 rounded-lg bg-white" />
      ) : (
        // Mic icon
        <svg viewBox="0 0 24 24" className="h-16 w-16 fill-white" aria-hidden>
          <path d="M12 14a3 3 0 0 0 3-3V6a3 3 0 1 0-6 0v5a3 3 0 0 0 3 3Z" />
          <path d="M18 11a1 1 0 1 0-2 0 4 4 0 0 1-8 0 1 1 0 1 0-2 0 6 6 0 0 0 5 5.91V19H8a1 1 0 1 0 0 2h8a1 1 0 1 0 0-2h-3v-2.09A6 6 0 0 0 18 11Z" />
        </svg>
      )}
    </button>
  )
}
