import { Routes, Route, Navigate } from 'react-router-dom'
import { AuthProvider } from './context/AuthContext'
import { RecordingProvider } from './context/RecordingContext'
import RequireAuth from './components/RequireAuth'
import RequireAdmin from './components/RequireAdmin'
import Landing from './pages/Landing'
import Recorder from './pages/Recorder'
import History from './pages/History'
import Settings from './pages/Settings'
import UsersAdmin from './pages/UsersAdmin'

export default function App() {
  return (
    <AuthProvider>
      <RecordingProvider>
        <Routes>
          <Route path="/" element={<Landing />} />
        <Route
          path="/record"
          element={
            <RequireAuth>
              <Recorder />
            </RequireAuth>
          }
        />
        <Route
          path="/history"
          element={
            <RequireAuth>
              <History />
            </RequireAuth>
          }
        />
        <Route
          path="/settings"
          element={
            <RequireAuth>
              <RequireAdmin>
                <Settings />
              </RequireAdmin>
            </RequireAuth>
          }
        />
        <Route
          path="/users"
          element={
            <RequireAuth>
              <RequireAdmin>
                <UsersAdmin />
              </RequireAdmin>
            </RequireAuth>
          }
        />
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
      </RecordingProvider>
    </AuthProvider>
  )
}
