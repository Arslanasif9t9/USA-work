/**
 * One-off Supabase setup (run with: npm run setup:supabase)
 *
 * Does, automatically and idempotently:
 *   1. Runs the §6 schema + RLS migration (supabase/migrations/0001_init.sql).
 *   2. Creates the admin auth user (admin@eia.local / admin1234, email confirmed).
 *   3. Enables pg_cron + schedules the hourly purge (0002_cron_purge.sql).
 *   4. (Best effort) turns the Email "Confirm email" requirement off.
 *
 * Credentials are read from .env.local (gitignored, never bundled — none of
 * the secrets here are VITE_-prefixed). The service_role key is used ONLY for
 * the Auth Admin API; it cannot run SQL/DDL, so SQL runs via the Management API
 * (Personal Access Token) or a direct Postgres connection.
 */
import { readFileSync } from 'node:fs'
import { fileURLToPath } from 'node:url'
import { dirname, join } from 'node:path'
import { createClient } from '@supabase/supabase-js'

const __dirname = dirname(fileURLToPath(import.meta.url))
const root = join(__dirname, '..')

// ── tiny .env.local parser (last value wins) ────────────────────────────────
function loadEnv(file) {
  const out = {}
  try {
    const txt = readFileSync(join(root, file), 'utf8')
    for (const line of txt.split(/\r?\n/)) {
      const m = line.match(/^\s*([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.*?)\s*$/)
      if (!m || line.trim().startsWith('#')) continue
      let v = m[2]
      if (
        (v.startsWith('"') && v.endsWith('"')) ||
        (v.startsWith("'") && v.endsWith("'"))
      )
        v = v.slice(1, -1)
      out[m[1]] = v
    }
  } catch {
    /* file may not exist */
  }
  return out
}

const env = { ...loadEnv('.env.local'), ...process.env }

const URL = env.VITE_SUPABASE_URL
const SERVICE_KEY = env.SUPABASE_SERVICE_ROLE_KEY
const REF =
  env.SUPABASE_PROJECT_REF ||
  (URL && new RegExp('https?://([^.]+)\\.supabase\\.co').exec(URL)?.[1])
const PAT = env.SUPABASE_ACCESS_TOKEN
const DB_URL = env.SUPABASE_DB_URL

const ADMIN_EMAIL = 'admin@eia.local'
const ADMIN_PASSWORD = 'admin1234'

const ok = (m) => console.log(`  ✓ ${m}`)
const skip = (m) => console.log(`  → ${m}`)
const fail = (m) => console.log(`  ✗ ${m}`)

const results = { schema: 'pending', admin: 'pending', cron: 'pending', confirmEmail: 'pending' }

function sqlFile(name) {
  return readFileSync(join(root, 'supabase', 'migrations', name), 'utf8')
}

// ── SQL execution: Management API (PAT) preferred, else direct pg ────────────
async function runSqlViaMgmt(query) {
  const res = await fetch(
    `https://api.supabase.com/v1/projects/${REF}/database/query`,
    {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${PAT}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ query }),
    },
  )
  if (!res.ok) {
    const text = await res.text()
    throw new Error(`Management API ${res.status}: ${text}`)
  }
}

async function runSqlViaPg(query) {
  let pg
  try {
    pg = (await import('pg')).default
  } catch {
    throw new Error(
      'SUPABASE_DB_URL is set but the "pg" package is not installed. Run: npm i pg',
    )
  }
  const client = new pg.Client({
    connectionString: DB_URL,
    ssl: { rejectUnauthorized: false },
  })
  await client.connect()
  try {
    await client.query(query)
  } finally {
    await client.end()
  }
}

const canRunSql = Boolean(PAT || DB_URL)
async function runSql(query) {
  if (PAT) return runSqlViaMgmt(query)
  if (DB_URL) return runSqlViaPg(query)
  throw new Error('no SQL credential')
}

function isAlreadyExists(err) {
  return /already exists|duplicate/i.test(String(err?.message))
}

// ── 1. Schema + RLS ─────────────────────────────────────────────────────────
async function setupSchema() {
  console.log('\n[1/4] Schema + RLS (0001_init.sql)')
  if (!canRunSql) {
    skip('No SUPABASE_ACCESS_TOKEN or SUPABASE_DB_URL — cannot run SQL. Skipped.')
    results.schema = 'needs-credential'
    return
  }
  try {
    await runSql(sqlFile('0001_init.sql'))
    ok('profiles + meetings tables, indexes and RLS policies created.')
    results.schema = 'done'
  } catch (err) {
    if (isAlreadyExists(err)) {
      skip('Schema objects already exist — treating as already applied.')
      results.schema = 'already'
    } else {
      fail(`Schema migration failed: ${err.message}`)
      results.schema = 'error'
    }
  }
}

// ── 2. Admin auth user (service_role) ────────────────────────────────────────
async function setupAdminUser() {
  console.log('\n[2/4] Admin user (admin@eia.local)')
  if (!URL || !SERVICE_KEY) {
    fail('Missing VITE_SUPABASE_URL or SUPABASE_SERVICE_ROLE_KEY.')
    results.admin = 'error'
    return
  }
  const admin = createClient(URL, SERVICE_KEY, {
    auth: { autoRefreshToken: false, persistSession: false },
  })
  const { error } = await admin.auth.admin.createUser({
    email: ADMIN_EMAIL,
    password: ADMIN_PASSWORD,
    email_confirm: true,
  })
  if (!error) {
    ok('Admin user created (email confirmed).')
    results.admin = 'done'
    return
  }
  if (/already|exists|registered/i.test(error.message)) {
    skip('Admin user already exists — skipped.')
    results.admin = 'already'
  } else {
    fail(`Could not create admin user: ${error.message}`)
    results.admin = 'error'
  }
}

// ── 3. pg_cron + purge schedule ───────────────────────────────────────────────
async function setupCron() {
  console.log('\n[3/4] pg_cron purge job (0002_cron_purge.sql)')
  if (!canRunSql) {
    skip('No SQL credential — skipped.')
    results.cron = 'needs-credential'
    return
  }
  try {
    await runSql(sqlFile('0002_cron_purge.sql'))
    ok('pg_cron enabled and hourly purge scheduled.')
    results.cron = 'done'
  } catch (err) {
    skip(`Could not enable pg_cron automatically (${err.message.slice(0, 120)}).`)
    skip(
      'Enable it later with one click: Dashboard → Database → Extensions → enable "pg_cron", then re-run this script.',
    )
    skip(
      'Meanwhile the frontend already filters expires_at > now(), so expired meetings are never shown.',
    )
    results.cron = 'needs-extension'
  }
}

// ── 4. Confirm-email off (best effort, Management API only) ────────────────────
async function setConfirmEmailOff() {
  console.log('\n[4/4] Email "Confirm email" setting')
  if (!PAT) {
    skip('Needs a Personal Access Token to change via API — left as-is.')
    skip(
      'Not required for the single admin login (the admin user is already email-confirmed).',
    )
    results.confirmEmail = 'skipped'
    return
  }
  try {
    const res = await fetch(
      `https://api.supabase.com/v1/projects/${REF}/config/auth`,
      {
        method: 'PATCH',
        headers: {
          Authorization: `Bearer ${PAT}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ mailer_autoconfirm: true }),
      },
    )
    if (!res.ok) throw new Error(`${res.status}: ${await res.text()}`)
    ok('"Confirm email" turned off (mailer_autoconfirm = true).')
    results.confirmEmail = 'done'
  } catch (err) {
    skip(`Could not change the setting automatically (${err.message.slice(0, 80)}).`)
    results.confirmEmail = 'error'
  }
}

// ── run ───────────────────────────────────────────────────────────────────────
async function main() {
  console.log('EIA Recap — Supabase setup')
  console.log(`Project ref: ${REF ?? '(unknown)'}`)
  if (!REF) {
    fail('Could not determine the project ref. Set SUPABASE_PROJECT_REF in .env.local.')
    process.exit(1)
  }

  await setupSchema()
  await setupAdminUser()
  await setupCron()
  await setConfirmEmailOff()

  console.log('\n── Summary ─────────────────────────────')
  console.log(`  Schema + RLS:   ${results.schema}`)
  console.log(`  Admin user:     ${results.admin}`)
  console.log(`  pg_cron purge:  ${results.cron}`)
  console.log(`  Confirm email:  ${results.confirmEmail}`)
  console.log('────────────────────────────────────────')
}

main().catch((err) => {
  console.error('\nUnexpected error:', err)
  process.exit(1)
})
