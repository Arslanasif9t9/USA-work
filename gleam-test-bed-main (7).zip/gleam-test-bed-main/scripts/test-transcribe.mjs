/**
 * Acceptance-test harness for the transcribe Edge Function (PLAN.md §2).
 *
 * Usage:
 *   node scripts/test-transcribe.mjs <path-to-audio-file>
 *   npm run test:transcribe -- ./my-3min-talk.webm
 *
 * Signs in as the admin user, sends the FULL audio file to the deployed
 * `transcribe` function, and reports the word count plus the first/last lines
 * so you can confirm the WHOLE talk came back — not just the opening sentence.
 */
import { readFileSync } from 'node:fs'
import { basename, extname } from 'node:path'
import { createClient } from '@supabase/supabase-js'

function loadEnv(file) {
  const out = {}
  try {
    for (const line of readFileSync(file, 'utf8').split(/\r?\n/)) {
      if (line.trim().startsWith('#')) continue
      const m = line.match(/^\s*([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.*?)\s*$/)
      if (m) out[m[1]] = m[2]
    }
  } catch {
    /* ignore */
  }
  return out
}

const MIME = {
  '.webm': 'audio/webm',
  '.ogg': 'audio/ogg',
  '.mp3': 'audio/mpeg',
  '.m4a': 'audio/mp4',
  '.mp4': 'audio/mp4',
  '.wav': 'audio/wav',
  '.aac': 'audio/aac',
  '.flac': 'audio/flac',
}

const env = { ...loadEnv('.env.local'), ...process.env }
const URL = env.VITE_SUPABASE_URL
const ANON = env.VITE_SUPABASE_ANON_KEY

const file = process.argv[2]
if (!file) {
  console.error('Usage: node scripts/test-transcribe.mjs <path-to-audio-file>')
  process.exit(1)
}

const bytes = readFileSync(file)
const mime = MIME[extname(file).toLowerCase()] ?? 'audio/webm'
console.log(`Audio: ${file}  (${(bytes.length / 1024 / 1024).toFixed(2)} MB, ${mime})`)

const supabase = createClient(URL, ANON, {
  auth: { persistSession: false },
})

const { data: auth, error: authErr } = await supabase.auth.signInWithPassword({
  email: 'admin@eia.local',
  password: 'admin1234',
})
if (authErr || !auth.session) {
  console.error('Sign-in failed:', authErr?.message)
  process.exit(1)
}

const form = new FormData()
form.append('audio', new Blob([bytes], { type: mime }), basename(file))

console.log('Uploading to transcribe… (this can take a while for long audio)')
const res = await fetch(`${URL}/functions/v1/transcribe`, {
  method: 'POST',
  headers: { Authorization: `Bearer ${auth.session.access_token}`, apikey: ANON },
  body: form,
})

const data = await res.json().catch(() => ({}))
if (!res.ok) {
  console.error(`\n✗ HTTP ${res.status}:`, data.error ?? data, data.detail ?? '')
  process.exit(1)
}

const transcript = String(data.transcript ?? '')
const words = transcript.trim().split(/\s+/).filter(Boolean).length
const head = transcript.slice(0, 300)
const tail = transcript.slice(-300)

console.log('\n── Result ──────────────────────────────')
console.log(`Word count: ${words}`)
console.log(`Characters: ${transcript.length}`)
console.log('\nFIRST 300 chars:\n' + head)
console.log('\nLAST 300 chars:\n' + tail)
console.log('────────────────────────────────────────')
console.log(
  '\nAcceptance check: the LAST lines should be the actual end of your talk,',
)
console.log('not a cut-off near the beginning.')
