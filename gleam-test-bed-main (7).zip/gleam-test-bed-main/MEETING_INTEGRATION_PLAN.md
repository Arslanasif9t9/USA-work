# MEETING INTEGRATION PLAN — "EIA Recap" (Meeting Intelligence)

> For the Meeting Intelligence Claude Code session. Repo
> `astrolume22/meeting_inteligence`, Supabase `jhbguzknzatpseinapbj`,
> live https://meeting-inteligence.vercel.app. Read this and stay ready.
> Do NOT change code until handed a phase prompt. Cross-app context is in
> `CONNECTED_BUILD_PLAN.md`.

---

## GROUND TRUTH (verified against the current repo snapshot)

- React + Vite + TS, React Router. Routes in `src/App.tsx`:
  `/` Landing, `/record` Recorder, `/history` History, `/settings` Settings.
- Single fixed admin login: username "admin" -> `admin@eia.local`
  (`src/lib/authConfig.ts`, `src/context/AuthContext.tsx`).
- Summary output is `{ title, summary }` (worker-facing bullets). Summary UI in
  `src/components/SummaryCard.tsx`; recording flow in `src/pages/Recorder.tsx`.
- Meetings persistence in `src/lib/meetings.ts` (`createMeeting`, `listMeetings`).
  Tables: profiles, meetings. No audio stored. 3-day auto-delete.
- Supabase client: `src/lib/supabase.ts`. AI engine: `src/lib/ai.ts`.

---

## THE ONLY FEATURE THAT TOUCHES THIS APP

### #5 Send call-notes -> a PMS group as a task (Phase 2)

Goal: on the summary result, add a "Send to group" action. The user picks a PMS
group (on the Tessera board); the summary is created as a NEW task in that group,
and the task body shows the call notes / summary text.

How it connects (no DB merge — HTTP bridge into PMS):
1. **List groups for the picker** — call PMS `GET /api/list-groups` with header
   `x-eia-key: <EIA_BRIDGE_KEY>`. It returns `{ ok, groups:[{id,name,color}] }`
   for the Tessera board. Populate the dropdown from this.
2. **Create the task** — push the summary into the chosen group via the PMS write
   bridge (`api/mcp.ts` `create_task`, auth `Authorization: Bearer <MCP_BEARER>`
   or `?token=<MCP_BEARER>`). The task name = the summary title; the task body /
   first update = the summary text.
3. The exact write path (reuse MCP `create_task` vs. a small dedicated
   `api/create-task-from-notes.ts` bridge mirroring the `list-groups` pattern)
   will be decided in the Phase 2 prompt after a read-only check of both apps.

Cross-app requirements to handle in Phase 2:
- **CORS:** PMS `api/list-groups.ts` (and whichever write endpoint is used) must
  add the Meeting app origin `https://meeting-inteligence.vercel.app` (plus
  localhost dev origins) to its allow-list. This is a PMS-side change, done in
  the PMS session.
- **Secrets:** the Meeting app needs `EIA_BRIDGE_KEY` (and the write token) as
  server-side env on Vercel — never in the frontend bundle. The browser must not
  hold these; route the calls through a Meeting-side serverless function or keep
  the keys server-side.
- **Target board:** Tessera (`28472783-6d7a-4de9-8834-2354f62856c5`), the board
  `list-groups` is already pinned to.

What does NOT change here:
- The recorder, transcription, summary generation, history, settings, and the
  admin login all stay exactly as they are. #5 is purely additive — one new
  action on the summary result.

---

## STANDING RULES FOR THIS REPO
- Open every prompt with `git pull`; close with commit + `git push` to main.
- Diagnose read-only first; smallest verified fix; demand proof.
- Do NOT burn AI quota on test calls without explicit approval.
- Keys are server-side secrets only — never in the frontend bundle or committed.
- ON DELETE SET NULL on user FKs, never CASCADE; single-row writes; no
  destructive data ops without confirmation.
- UI copy in English; only summary CONTENT may be Roman Urdu (never Nastaliq).
- CLAUDE.md at repo root carries the per-session rules — keep following it.
