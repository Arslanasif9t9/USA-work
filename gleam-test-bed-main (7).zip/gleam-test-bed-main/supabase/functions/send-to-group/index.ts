// EIA Recap — `send-to-group` Edge Function (Phase 2 / feature #5)
//
// Server-side bridge to PMS ("EIA Projects"). Lets the signed-in admin push a
// meeting summary into a PMS Tessera group as a new task — WITHOUT the shared
// bridge key ever reaching the browser.
//
//   POST { action: "list" }
//        -> { ok, groups: [{ id, name, color }] }   (Tessera groups for the picker)
//   POST { action: "create", group_id, name, body }
//        -> { ok, task_id, task_code, update_id? }
//
// Reads EIA_BRIDGE_KEY from secrets and authenticates to PMS with the
// `x-eia-key` header. Verifies the caller's Supabase JWT, same as the other
// functions. Never returns the key.

import { createClient } from 'jsr:@supabase/supabase-js@2'

const EIA_BRIDGE_KEY = Deno.env.get('EIA_BRIDGE_KEY') ?? ''

// Canonical PMS production alias (never the preview).
const PMS_BASE = 'https://p-m-system.vercel.app'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers':
    'authorization, x-client-info, apikey, content-type',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
}

function json(body: unknown, status = 200): Response {
  return new Response(JSON.stringify(body), {
    status,
    headers: { ...corsHeaders, 'Content-Type': 'application/json' },
  })
}

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders })
  if (req.method !== 'POST') return json({ ok: false, error: 'Method not allowed.' }, 405)

  // Verify the caller's Supabase JWT (must be signed in).
  const authHeader = req.headers.get('Authorization') ?? ''
  const supabase = createClient(
    Deno.env.get('SUPABASE_URL') ?? '',
    Deno.env.get('SUPABASE_ANON_KEY') ?? '',
    { global: { headers: { Authorization: authHeader } } },
  )
  const { data: { user }, error: authError } = await supabase.auth.getUser()
  if (authError || !user) {
    return json({ ok: false, error: 'Unauthorized. Please sign in and try again.' }, 401)
  }

  if (!EIA_BRIDGE_KEY) {
    return json({ ok: false, error: 'Server is not configured: EIA_BRIDGE_KEY is missing.' }, 500)
  }

  let payload: {
    action?: string
    group_id?: string
    name?: string
    body?: string
  }
  try {
    payload = await req.json()
  } catch {
    return json({ ok: false, error: 'Invalid request body.' }, 400)
  }

  const action = payload.action
  if (action !== 'list' && action !== 'create') {
    return json({ ok: false, error: 'Unknown action. Use "list" or "create".' }, 400)
  }

  // ── action: list ────────────────────────────────────────────────────────────
  if (action === 'list') {
    try {
      const res = await fetch(`${PMS_BASE}/api/list-groups`, {
        method: 'GET',
        headers: { 'x-eia-key': EIA_BRIDGE_KEY },
      })
      const data = await res.json().catch(() => ({}))
      if (!res.ok) {
        return json(
          { ok: false, error: data?.error || `PMS list-groups failed (${res.status}).` },
          res.status,
        )
      }
      return json(data) // { ok, groups: [{ id, name, color }] }
    } catch (e) {
      return json({ ok: false, error: 'Could not reach PMS to list groups.', detail: String(e) }, 502)
    }
  }

  // ── action: create ──────────────────────────────────────────────────────────
  const groupId = String(payload.group_id ?? '').trim()
  const name = String(payload.name ?? '').trim()
  const body = String(payload.body ?? '')
  if (!groupId) return json({ ok: false, error: 'A group is required.' }, 400)
  if (!name || name.length > 200) {
    return json({ ok: false, error: 'A task name (1–200 characters) is required.' }, 400)
  }

  try {
    const res = await fetch(`${PMS_BASE}/api/create-task-from-notes`, {
      method: 'POST',
      headers: { 'x-eia-key': EIA_BRIDGE_KEY, 'Content-Type': 'application/json' },
      body: JSON.stringify({ group_id: groupId, name, body }),
    })
    const data = await res.json().catch(() => ({}))
    if (!res.ok) {
      return json(
        { ok: false, error: data?.error || `PMS create-task failed (${res.status}).` },
        res.status,
      )
    }
    return json(data) // { ok, task_id, task_code, update_id? }
  } catch (e) {
    return json({ ok: false, error: 'Could not reach PMS to create the task.', detail: String(e) }, 502)
  }
})
