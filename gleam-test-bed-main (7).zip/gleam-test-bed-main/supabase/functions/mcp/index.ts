// EIA Recap — `mcp` Edge Function (read-only MCP server / custom connector)
//
// A JSON-RPC 2.0 MCP server that lets Claude read meeting transcripts and
// summaries from this project as a custom connector. 100% additive and READ
// ONLY — it never writes, and it does not touch any other function or table.
//
// AUTH: deploy this function with verify_jwt = false (e.g.
//   `npx supabase functions deploy mcp --no-verify-jwt --project-ref <ref>`)
// because Claude authenticates with our own bearer token (MCP_BEARER), not a
// Supabase JWT. The bearer is checked inside the handler, before any DB work.
//
// BOOT-SAFE: nothing runs at module load except this import and plain constants.
// Every Deno.env.get(...) and the service-role client are created INSIDE the
// request handler; the whole handler is wrapped in try/catch and always returns
// JSON, so a missing secret returns a clean error and the function stays booted.

import { createClient } from 'jsr:@supabase/supabase-js@2'

// ── Module-scope constants only (cannot throw) ────────────────────────────────
const MCP_PROTOCOL_VERSION = '2024-11-05'
const SERVER_INFO = { name: 'callrecap-mcp', version: '1.2.0' }

// Default-admin uid (matches get_admin_profile). Used when a username is
// omitted from the *_by_user tools.
const ADMIN_UID = 'f23f202f-6122-4bd6-b8ed-f9aa9528273d'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers':
    'authorization, x-client-info, apikey, content-type',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
}

const TOOLS = [
  {
    name: 'list_meetings',
    description:
      'List saved meetings across ALL users (most recent first). Lightweight: returns id, title, created_at, duration_sec, word_count, username, and live_caption — no transcript.',
    inputSchema: {
      type: 'object',
      properties: {
        limit: {
          type: 'number',
          description: 'Max rows (default 20, max 50).',
        },
      },
    },
  },
  {
    name: 'get_meeting',
    description:
      'Get one meeting by id, including its full summary, Groq Whisper transcript, browser live_caption, and the owner username.',
    inputSchema: {
      type: 'object',
      properties: {
        id: { type: 'string', description: 'Meeting UUID.' },
      },
      required: ['id'],
    },
  },
  {
    name: 'search_meetings',
    description:
      'Search meetings whose transcript, summary, or title matches the query (case-insensitive), across ALL users. Lightweight: returns id, title, created_at, username, live_caption, and a short summary snippet — no transcript.',
    inputSchema: {
      type: 'object',
      properties: {
        query: { type: 'string', description: 'Text to search for.' },
        limit: {
          type: 'number',
          description: 'Max rows (default 20, max 50).',
        },
      },
      required: ['query'],
    },
  },
  {
    name: 'get_latest_meeting',
    description:
      'Get the single most recent meeting across ALL users, including its full summary, Groq Whisper transcript, browser live_caption, and the owner username.',
    inputSchema: { type: 'object', properties: {} },
  },
  {
    name: 'list_users',
    description:
      'List every user that has at least one saved meeting. Returns [{ username, user_id }]. username is derived from the email local-part (admin@eia.local → "admin").',
    inputSchema: { type: 'object', properties: {} },
  },
  {
    name: 'get_latest_meeting_by_user',
    description:
      'Get the most recent meeting for a specific user. Input: optional { username }. If username is omitted/empty, defaults to admin. Returns title, summary, transcript (Groq Whisper), live_caption (browser Web Speech), duration_sec, word_count, created_at, username.',
    inputSchema: {
      type: 'object',
      properties: {
        username: {
          type: 'string',
          description: 'Username (email local-part). Omit to default to admin.',
        },
      },
    },
  },
  {
    name: 'list_meetings_by_user',
    description:
      "List a specific user's meetings, most recent first. Input: optional { username, limit }. If username is omitted/empty, defaults to admin. Each row includes title, summary, transcript, live_caption, created_at, duration_sec, word_count, username.",
    inputSchema: {
      type: 'object',
      properties: {
        username: {
          type: 'string',
          description: 'Username (email local-part). Omit to default to admin.',
        },
        limit: {
          type: 'number',
          description: 'Max rows (default 20, max 50).',
        },
      },
    },
  },
  {
    name: 'create_meeting',
    description:
      'Insert a new meeting/recap into the meetings store from supplied text (title + notes). Returns the created row including its new id.',
    inputSchema: {
      type: 'object',
      properties: {
        title: { type: 'string', description: 'Required. Non-empty, max ~300 chars.' },
        transcript: { type: 'string', description: 'Optional main note/body text.' },
        summary: { type: 'string', description: 'Optional summary text.' },
        live_caption: { type: 'string', description: 'Optional live caption text.' },
        username: {
          type: 'string',
          description: 'Optional email local-part (e.g. "admin"). Omit to default to admin.',
        },
        created_at: { type: 'string', description: 'Optional ISO 8601 timestamp; defaults to now().' },
        duration_sec: { type: 'number', description: 'Optional duration in seconds; defaults to 0.' },
      },
      required: ['title'],
    },
  },
  {
    name: 'update_meeting',
    description:
      'Update an existing meeting/recap by id. Only the fields you pass are changed; omitted fields are left as-is. Returns the updated row.',
    inputSchema: {
      type: 'object',
      properties: {
        id: { type: 'string', description: 'Required. The meeting row id to update.' },
        title: { type: 'string', description: 'Optional new title.' },
        transcript: { type: 'string', description: 'Optional new transcript (recomputes word_count).' },
        summary: { type: 'string', description: 'Optional new summary.' },
        live_caption: { type: 'string', description: 'Optional new live caption.' },
        duration_sec: { type: 'number', description: 'Optional new duration in seconds.' },
        created_at: { type: 'string', description: 'Optional ISO 8601 timestamp to overwrite created_at.' },
      },
      required: ['id'],
    },
  },
  {
    name: 'move_meeting',
    description:
      'Move (reassign) an existing meeting/recap to a different user, in place — changes the owner, does NOT copy or delete. Input: { id, target_username }. id is the meeting UUID; target_username is the destination user (email local-part, e.g. "meeting", "dev", "admin", "call"). Returns the updated row with its new owner username.',
    inputSchema: {
      type: 'object',
      properties: {
        id: { type: 'string', description: 'Required. The meeting row id to move.' },
        target_username: {
          type: 'string',
          description: 'Required. Destination username (email local-part), e.g. "meeting", "dev", "admin", "call".',
        },
      },
      required: ['id', 'target_username'],
    },
  },
]

// ── Small JSON helpers ────────────────────────────────────────────────────────
function respond(body: unknown, status = 200): Response {
  return new Response(JSON.stringify(body), {
    status,
    headers: { ...corsHeaders, 'Content-Type': 'application/json' },
  })
}
const rpcResult = (id: unknown, result: unknown) => ({ jsonrpc: '2.0', id: id ?? null, result })
const rpcError = (id: unknown, code: number, message: string) => ({
  jsonrpc: '2.0',
  id: id ?? null,
  error: { code, message },
})
// A tools/call success wraps the data as a single MCP text content item.
const toolContent = (data: unknown) => ({
  content: [{ type: 'text', text: JSON.stringify(data, null, 2) }],
})

const clampLimit = (n: unknown) => {
  const v = typeof n === 'number' && Number.isFinite(n) ? Math.floor(n) : 20
  return Math.min(50, Math.max(1, v))
}

// ── Username resolution helpers (service-role) ────────────────────────────────
// Batch-resolve user_id → username (email local-part) using auth.admin.listUsers.
// supabase-js v2 doesn't expose a direct id-IN query on auth.users, so we
// paginate once and cache. The user count here is tiny (admin + call), so a
// single page is plenty.
async function loadUserIndex(supabase: any): Promise<Map<string, string>> {
  const map = new Map<string, string>()
  try {
    const { data, error } = await supabase.auth.admin.listUsers({ page: 1, perPage: 1000 })
    if (error) return map
    for (const u of data?.users ?? []) {
      const email = String(u?.email ?? '')
      if (!email) continue
      map.set(u.id, email.split('@')[0])
    }
  } catch {
    /* swallow — callers tolerate empty map */
  }
  return map
}

function attachUsernames<T extends { user_id?: string }>(
  rows: T[],
  index: Map<string, string>,
): Array<T & { username: string | null }> {
  return rows.map((r) => ({ ...r, username: r.user_id ? index.get(r.user_id) ?? null : null }))
}

async function resolveUsernameToUid(
  supabase: any,
  username: string,
): Promise<string | null> {
  const index = await loadUserIndex(supabase)
  for (const [uid, uname] of index.entries()) {
    if (uname === username) return uid
  }
  return null
}

Deno.serve(async (req) => {
  // CORS preflight.
  if (req.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders })

  try {
    if (req.method !== 'POST') {
      return respond(rpcError(null, -32600, 'Only POST is supported.'), 405)
    }

    // Parse the JSON-RPC request (needed to echo the id).
    let rpc: { id?: unknown; method?: string; params?: any }
    try {
      rpc = await req.json()
    } catch {
      return respond(rpcError(null, -32700, 'Parse error: invalid JSON.'), 400)
    }
    const id = rpc?.id ?? null
    const method = rpc?.method

    // ── Bearer auth (before any DB work) ──────────────────────────────────────
    const expected = Deno.env.get('MCP_BEARER') ?? ''
    if (!expected) {
      return respond(rpcError(id, -32000, 'Server is not configured: MCP_BEARER is missing.'), 500)
    }
    // Accept the token from the ?token= query param first, then fall back to the
    // Authorization: Bearer <token> header.
    const queryToken = new URL(req.url).searchParams.get('token') ?? ''
    const authHeader = req.headers.get('Authorization') ?? ''
    const headerToken = authHeader.startsWith('Bearer ') ? authHeader.slice(7).trim() : ''
    const token = queryToken || headerToken
    if (!token || token !== expected) {
      return respond(rpcError(id, -32001, 'Unauthorized.'), 401)
    }

    // ── MCP method dispatch ───────────────────────────────────────────────────
    if (method === 'initialize') {
      return respond(
        rpcResult(id, {
          protocolVersion: MCP_PROTOCOL_VERSION,
          capabilities: { tools: {} },
          serverInfo: SERVER_INFO,
        }),
      )
    }

    if (method === 'notifications/initialized') {
      return respond(rpcResult(id, {}))
    }

    if (method === 'tools/list') {
      return respond(rpcResult(id, { tools: TOOLS }))
    }

    if (method === 'tools/call') {
      const name = rpc?.params?.name as string
      const args = (rpc?.params?.arguments ?? {}) as Record<string, unknown>

      // Service-role client built INSIDE the handler, only when needed, so reads
      // are not blocked by RLS. SELECT only — this connector never writes.
      const url = Deno.env.get('SUPABASE_URL') ?? ''
      const serviceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
      if (!url || !serviceKey) {
        return respond(rpcError(id, -32000, 'Server is not configured: Supabase env missing.'), 500)
      }
      const supabase = createClient(url, serviceKey, {
        auth: { persistSession: false, autoRefreshToken: false },
      })

      try {
        if (name === 'list_meetings') {
          const limit = clampLimit(args.limit)
          const { data, error } = await supabase
            .from('meetings')
            .select('id, user_id, title, created_at, duration_sec, word_count, live_caption')
            .order('created_at', { ascending: false })
            .limit(limit)
          if (error) throw new Error(error.message)
          const index = await loadUserIndex(supabase)
          return respond(rpcResult(id, toolContent(attachUsernames(data ?? [], index))))
        }

        if (name === 'get_meeting') {
          const mid = String(args.id ?? '').trim()
          if (!mid) return respond(rpcResult(id, toolContent({ error: 'id is required.' })))
          const { data, error } = await supabase
            .from('meetings')
            .select('id, user_id, title, summary, transcript, live_caption, duration_sec, word_count, created_at')
            .eq('id', mid)
            .maybeSingle()
          if (error) throw new Error(error.message)
          if (!data) return respond(rpcResult(id, toolContent({ error: `No meeting found with id ${mid}.` })))
          const index = await loadUserIndex(supabase)
          return respond(rpcResult(id, toolContent(attachUsernames([data], index)[0])))
        }

        if (name === 'search_meetings') {
          const query = String(args.query ?? '').trim()
          if (!query) return respond(rpcResult(id, toolContent({ error: 'query is required.' })))
          const limit = clampLimit(args.limit)
          // Sanitize: strip characters that would break the PostgREST or-filter.
          const safe = query.replace(/[,()%*\\]/g, ' ').trim()
          const pattern = `%${safe}%`
          const { data, error } = await supabase
            .from('meetings')
            .select('id, user_id, title, created_at, summary, live_caption')
            .or(`transcript.ilike.${pattern},summary.ilike.${pattern},title.ilike.${pattern}`)
            .order('created_at', { ascending: false })
            .limit(limit)
          if (error) throw new Error(error.message)
          const index = await loadUserIndex(supabase)
          const rows = (data ?? []).map((m: any) => ({
            id: m.id,
            user_id: m.user_id,
            title: m.title,
            created_at: m.created_at,
            snippet: String(m.summary ?? '').slice(0, 200),
            live_caption: m.live_caption ?? null,
          }))
          return respond(rpcResult(id, toolContent(attachUsernames(rows, index))))
        }

        if (name === 'get_latest_meeting') {
          const { data, error } = await supabase
            .from('meetings')
            .select('id, user_id, title, summary, transcript, live_caption, duration_sec, word_count, created_at')
            .order('created_at', { ascending: false })
            .limit(1)
            .maybeSingle()
          if (error) throw new Error(error.message)
          if (!data) return respond(rpcResult(id, toolContent({ error: 'No meetings found.' })))
          const index = await loadUserIndex(supabase)
          return respond(rpcResult(id, toolContent(attachUsernames([data], index)[0])))
        }

        if (name === 'list_users') {
          // All distinct user_ids that have at least one meeting.
          const { data, error } = await supabase
            .from('meetings')
            .select('user_id')
          if (error) throw new Error(error.message)
          const uids = Array.from(new Set((data ?? []).map((r: any) => r.user_id).filter(Boolean)))
          const index = await loadUserIndex(supabase)
          const users = uids.map((uid) => ({
            user_id: uid,
            username: index.get(uid) ?? null,
          }))
          return respond(rpcResult(id, toolContent(users)))
        }

        if (name === 'get_latest_meeting_by_user') {
          const usernameArg = String(args.username ?? '').trim()
          let uid: string | null = null
          let resolvedUsername = usernameArg
          if (!usernameArg) {
            uid = ADMIN_UID
            resolvedUsername = 'admin'
          } else {
            uid = await resolveUsernameToUid(supabase, usernameArg)
            if (!uid) {
              return respond(rpcResult(id, toolContent({ error: `Unknown username: ${usernameArg}` })))
            }
          }
          const { data, error } = await supabase
            .from('meetings')
            .select('id, user_id, title, summary, transcript, live_caption, duration_sec, word_count, created_at')
            .eq('user_id', uid)
            .order('created_at', { ascending: false })
            .limit(1)
            .maybeSingle()
          if (error) throw new Error(error.message)
          if (!data) return respond(rpcResult(id, toolContent({ error: `No meetings found for ${resolvedUsername}.` })))
          const index = await loadUserIndex(supabase)
          return respond(rpcResult(id, toolContent(attachUsernames([data], index)[0])))
        }

        if (name === 'list_meetings_by_user') {
          const usernameArg = String(args.username ?? '').trim()
          const limit = clampLimit(args.limit)
          let uid: string | null = null
          let resolvedUsername = usernameArg
          if (!usernameArg) {
            uid = ADMIN_UID
            resolvedUsername = 'admin'
          } else {
            uid = await resolveUsernameToUid(supabase, usernameArg)
            if (!uid) {
              return respond(rpcResult(id, toolContent({ error: `Unknown username: ${usernameArg}` })))
            }
          }
          const { data, error } = await supabase
            .from('meetings')
            .select('id, user_id, title, summary, transcript, live_caption, duration_sec, word_count, created_at')
            .eq('user_id', uid)
            .order('created_at', { ascending: false })
            .limit(limit)
          if (error) throw new Error(error.message)
          if (!data || data.length === 0) {
            return respond(rpcResult(id, toolContent({ error: `No meetings found for ${resolvedUsername}.` })))
          }
          const index = await loadUserIndex(supabase)
          return respond(rpcResult(id, toolContent(attachUsernames(data, index))))
        }


        if (name === 'create_meeting') {
          const title = String(args.title ?? '').trim()
          if (!title) return respond(rpcResult(id, toolContent({ error: 'title is required.' })))
          if (title.length > 300) return respond(rpcResult(id, toolContent({ error: 'title exceeds 300 chars.' })))
          const transcript = args.transcript == null ? '' : String(args.transcript)
          const summary = args.summary == null ? '' : String(args.summary)
          const liveCaption = args.live_caption == null ? '' : String(args.live_caption)
          if (!transcript.trim() && !summary.trim() && !liveCaption.trim()) {
            return respond(rpcResult(id, toolContent({ error: 'At least one of transcript/summary/live_caption must be non-empty.' })))
          }
          const totalBytes = transcript.length + summary.length + liveCaption.length
          if (totalBytes > 1_000_000) {
            return respond(rpcResult(id, toolContent({ error: `Body too large (${totalBytes} chars); max ~1,000,000.` })))
          }

          const usernameArg = String(args.username ?? '').trim()
          let uid: string
          if (!usernameArg) {
            uid = ADMIN_UID
          } else {
            const resolved = await resolveUsernameToUid(supabase, usernameArg)
            if (!resolved) {
              return respond(rpcResult(id, toolContent({ error: `Unknown username: ${usernameArg}` })))
            }
            uid = resolved
          }

          const wordCount = transcript.trim() ? transcript.trim().split(/\s+/).length : 0
          const durationSec = typeof args.duration_sec === 'number' && Number.isFinite(args.duration_sec)
            ? Math.max(0, Math.floor(args.duration_sec))
            : 0

          const row: Record<string, unknown> = {
            user_id: uid,
            title,
            summary: summary.trim() ? summary : (transcript.trim() ? transcript : liveCaption),
            transcript: transcript || null,
            live_caption: liveCaption || null,
            duration_sec: durationSec,
            word_count: wordCount,
          }
          // If caller passes created_at, also set expires_at = created_at + 3 days to mirror the table default.
          if (args.created_at != null && String(args.created_at).trim() !== '') {
            const createdAt = new Date(String(args.created_at))
            if (Number.isNaN(createdAt.getTime())) {
              return respond(rpcResult(id, toolContent({ error: 'created_at must be a valid ISO 8601 timestamp.' })))
            }
            row.created_at = createdAt.toISOString()
            row.expires_at = new Date(createdAt.getTime() + 3 * 24 * 60 * 60 * 1000).toISOString()
          }

          const { data, error } = await supabase
            .from('meetings')
            .insert(row)
            .select('id, user_id, title, summary, transcript, live_caption, duration_sec, word_count, created_at, expires_at')
            .single()
          if (error) throw new Error(error.message)
          const index = await loadUserIndex(supabase)
          return respond(rpcResult(id, toolContent(attachUsernames([data], index)[0])))
        }

        if (name === 'update_meeting') {
          const mid = String(args.id ?? '').trim()
          if (!mid) return respond(rpcResult(id, toolContent({ error: 'id is required.' })))

          const has = (k: string) => Object.prototype.hasOwnProperty.call(args, k) && args[k] !== undefined
          const updatable = ['title', 'transcript', 'summary', 'live_caption', 'duration_sec', 'created_at']
          const present = updatable.filter(has)
          if (present.length === 0) {
            return respond(rpcResult(id, toolContent({ error: 'At least one field to update must be provided (title/transcript/summary/live_caption/duration_sec/created_at).' })))
          }

          const patch: Record<string, unknown> = {}

          if (has('title')) {
            const t = String(args.title ?? '').trim()
            if (!t) return respond(rpcResult(id, toolContent({ error: 'title cannot be empty.' })))
            if (t.length > 300) return respond(rpcResult(id, toolContent({ error: 'title exceeds 300 chars.' })))
            patch.title = t
          }

          let newTranscript: string | null = null
          if (has('transcript')) {
            newTranscript = String(args.transcript ?? '')
            patch.transcript = newTranscript || null
          }
          if (has('summary')) {
            patch.summary = String(args.summary ?? '')
          }
          if (has('live_caption')) {
            const lc = String(args.live_caption ?? '')
            patch.live_caption = lc || null
          }

          // Enforce ~1MB cap on the (new) text fields combined.
          const textBytes =
            (has('transcript') ? String(args.transcript ?? '').length : 0) +
            (has('summary') ? String(args.summary ?? '').length : 0) +
            (has('live_caption') ? String(args.live_caption ?? '').length : 0)
          if (textBytes > 1_000_000) {
            return respond(rpcResult(id, toolContent({ error: `Body too large (${textBytes} chars); max ~1,000,000.` })))
          }

          if (has('duration_sec')) {
            const d = args.duration_sec
            if (typeof d !== 'number' || !Number.isFinite(d)) {
              return respond(rpcResult(id, toolContent({ error: 'duration_sec must be a finite number.' })))
            }
            patch.duration_sec = Math.max(0, Math.floor(d))
          }

          if (has('created_at')) {
            const raw = String(args.created_at ?? '').trim()
            if (!raw) return respond(rpcResult(id, toolContent({ error: 'created_at cannot be empty.' })))
            const createdAt = new Date(raw)
            if (Number.isNaN(createdAt.getTime())) {
              return respond(rpcResult(id, toolContent({ error: 'created_at must be a valid ISO 8601 timestamp.' })))
            }
            patch.created_at = createdAt.toISOString()
          }

          // Recompute word_count ONLY when transcript is being updated.
          if (newTranscript !== null) {
            const trimmed = newTranscript.trim()
            patch.word_count = trimmed ? trimmed.split(/\s+/).length : 0
          }

          const { data, error } = await supabase
            .from('meetings')
            .update(patch)
            .eq('id', mid)
            .select('id, user_id, title, summary, transcript, live_caption, duration_sec, word_count, created_at, expires_at')
            .maybeSingle()
          if (error) throw new Error(error.message)
          if (!data) return respond(rpcResult(id, toolContent({ error: `No meeting found with id ${mid}.` })))
          const index = await loadUserIndex(supabase)
          return respond(rpcResult(id, toolContent(attachUsernames([data], index)[0])))
        }



        if (name === 'move_meeting') {
          const mid = String(args.id ?? '').trim()
          if (!mid) return respond(rpcResult(id, toolContent({ error: 'id is required.' })))
          const targetArg = String(args.target_username ?? '').trim()
          if (!targetArg) return respond(rpcResult(id, toolContent({ error: 'target_username is required.' })))

          // Resolve destination username -> uid
          const targetUid = await resolveUsernameToUid(supabase, targetArg)
          if (!targetUid) {
            return respond(rpcResult(id, toolContent({ error: `Unknown target_username: ${targetArg}` })))
          }

          // Confirm the meeting exists first (clear error if not)
          const { data: existing, error: findErr } = await supabase
            .from('meetings')
            .select('id, user_id')
            .eq('id', mid)
            .maybeSingle()
          if (findErr) throw new Error(findErr.message)
          if (!existing) return respond(rpcResult(id, toolContent({ error: `No meeting found with id ${mid}.` })))

          // Move in place: change the owner. Service-role bypasses RLS.
          const { data, error } = await supabase
            .from('meetings')
            .update({ user_id: targetUid })
            .eq('id', mid)
            .select('id, user_id, title, summary, transcript, live_caption, duration_sec, word_count, created_at, expires_at')
            .maybeSingle()
          if (error) throw new Error(error.message)
          if (!data) return respond(rpcResult(id, toolContent({ error: `Move failed for id ${mid}.` })))
          const index = await loadUserIndex(supabase)
          return respond(rpcResult(id, toolContent(attachUsernames([data], index)[0])))
        }

        return respond(rpcError(id, -32602, `Unknown tool: ${name}`))
      } catch (e) {
        return respond(rpcError(id, -32603, `Tool error: ${String(e)}`))
      }
    }

    // Unknown method.
    return respond(rpcError(id, -32601, `Method not found: ${method}`))
  } catch (e) {
    // Last-resort guard: always return JSON, never crash the worker.
    return respond(rpcError(null, -32603, `Internal error: ${String(e)}`), 500)
  }
})
