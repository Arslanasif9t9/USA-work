// EIA Recap — `summarize` Edge Function (Path A: Groq primary, Gemini fallback)
//
// Input:  { transcript, instruction?, model? }
// Output: { title, summary }   (unchanged shape; same TITLE: parsing)
//
// - PRIMARY: Groq "llama-3.3-70b-versatile" (OpenAI-compatible chat).
// - FALLBACK: existing Gemini path, used automatically on a Groq 429/quota (or
//   any other Groq failure) when GEMINI_API_KEY is set.
// - Keeps ALL behavior: worker-facing brief, the §3 sections, NO speaker
//   labels, English or ROMAN URDU (never Nastaliq), date-based title fallback,
//   JWT verification, CORS, clear 429/error messages.
// - Long transcripts are chunked (map-reduce) so we stay within model limits.
//
// Summarization is kept separate from transcription; the provider is swappable
// via the `summarizeRaw()` orchestrator below.

import { createClient } from 'jsr:@supabase/supabase-js@2'

const NVIDIA_API_KEY = Deno.env.get('NVIDIA_API_KEY') ?? ''
const GROQ_API_KEY = Deno.env.get('GROQ_API_KEY') ?? ''
const GEMINI_API_KEY = Deno.env.get('GEMINI_API_KEY') ?? ''
const GEMINI_MODEL = Deno.env.get('GEMINI_MODEL') ?? 'gemini-2.5-flash'

const NVIDIA_BASE = 'https://integrate.api.nvidia.com/v1'
const NVIDIA_CHAT_MODEL = 'meta/llama-3.3-70b-instruct'
const GROQ_BASE = 'https://api.groq.com/openai/v1'
const GEMINI_BASE = 'https://generativelanguage.googleapis.com'
const GROQ_CHAT_MODEL = 'llama-3.3-70b-versatile'

// Chunk transcripts longer than this many characters (~12k tokens) before
// summarizing, then summarize the combined notes. Normal ≤30-min talks are far
// shorter, so this path stays dormant for typical use.
const SUMMARIZE_CHAR_LIMIT = 48000

const ALLOWED_MODELS = new Set([
  'gemini-2.5-flash',
  'gemini-2.5-flash-lite',
  'gemini-3.5-flash',
])
const resolveModel = (m: unknown) =>
  typeof m === 'string' && ALLOWED_MODELS.has(m) ? m : GEMINI_MODEL

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers':
    'authorization, x-client-info, apikey, content-type',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
}

const BASE_RULES = `You are writing a clear brief that a manager is sending to a worker, based ONLY on the transcript of the manager speaking.

Hard rules (never break these):
- The audience is the WORKER. Write it as the brief the worker receives — what they need to do and know.
- NEVER mention speakers, "Speaker 1", "Speaker 2", speaker detection, or how many people were talking. There is only the brief.
- Language: write in clear ENGLISH. If the transcript is clearly in Urdu, write the summary in ROMAN URDU (Urdu using English/Latin letters, e.g. "kal tak report bhej dena"). NEVER use Urdu/Arabic (Nastaliq) script. Everything in Latin letters, left-to-right.
- Be concise but complete. No preamble, no closing remarks, no commentary about the transcript or the audio.

Output format:
- The VERY FIRST line must be exactly: TITLE: <a short 3 to 6 word title>
- Then the summary body.`

const DEFAULT_BODY = `For the body, use these sections. Each section is a heading on its own line, followed by "• " bullet points. Only include a section if it has relevant content, but ALWAYS include "What you need to do".

What you need to do
Key points / context
Details to remember
Deadlines
Don't forget (said once)

Guidance per section:
- What you need to do: the tasks/instructions. This is the most important section.
- Key points / context: why, background, anything explaining the task.
- Details to remember: numbers, names, dates, links, references.
- Deadlines: only if a time or date was mentioned.
- Don't forget (said once): things mentioned only a single time that are easy to forget.`

const customBody = (instruction: string) =>
  `For the body, IGNORE the default section format. Instead, produce the summary by following this instruction exactly:
"""
${instruction}
"""
Still obey every hard rule above (worker-facing, no speakers, the language rule, and the "TITLE:" first line).`

function json(body: unknown, status = 200): Response {
  return new Response(JSON.stringify(body), {
    status,
    headers: { ...corsHeaders, 'Content-Type': 'application/json' },
  })
}

class ProviderError extends Error {
  status: number
  retryable: boolean
  provider: string
  constructor(status: number, message: string, provider: string) {
    super(message)
    this.status = status
    this.provider = provider
    this.retryable = status === 429 || status >= 500
    this.name = 'ProviderError'
  }
}

// ── NVIDIA (primary) ────────────────────────────────────────────────────────
async function nvidiaChat(system: string, user: string): Promise<string> {
  const res = await fetch(`${NVIDIA_BASE}/chat/completions`, {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${NVIDIA_API_KEY}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      model: NVIDIA_CHAT_MODEL,
      temperature: 0.2,
      messages: [
        { role: 'system', content: system },
        { role: 'user', content: user },
      ],
    }),
  })
  if (!res.ok) {
    throw new ProviderError(res.status, `NVIDIA chat ${res.status}: ${await res.text()}`, 'nvidia')
  }
  const data = await res.json()
  const text = String(data?.choices?.[0]?.message?.content ?? '').trim()
  if (!text) throw new ProviderError(502, 'NVIDIA returned no text.', 'nvidia')
  return text
}

// ── GROQ (fallback #1) ──────────────────────────────────────────────────────
async function groqChat(system: string, user: string): Promise<string> {
  const res = await fetch(`${GROQ_BASE}/chat/completions`, {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${GROQ_API_KEY}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      model: GROQ_CHAT_MODEL,
      temperature: 0.2,
      messages: [
        { role: 'system', content: system },
        { role: 'user', content: user },
      ],
    }),
  })
  if (!res.ok) {
    throw new ProviderError(res.status, `Groq chat ${res.status}: ${await res.text()}`, 'groq')
  }
  const data = await res.json()
  const text = String(data?.choices?.[0]?.message?.content ?? '').trim()
  if (!text) throw new ProviderError(502, 'Groq returned no text.', 'groq')
  return text
}

// ── GEMINI (fallback #2) ─────────────────────────────────────────────────────
async function geminiGenerate(model: string, prompt: string): Promise<string> {
  const res = await fetch(
    `${GEMINI_BASE}/v1beta/models/${model}:generateContent?key=${GEMINI_API_KEY}`,
    {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        contents: [{ parts: [{ text: prompt }] }],
        generationConfig: {
          temperature: 0.2,
          maxOutputTokens: 8192,
          thinkingConfig: { thinkingBudget: 0 },
        },
      }),
    },
  )
  if (!res.ok) {
    throw new ProviderError(res.status, `Gemini ${res.status}: ${await res.text()}`, 'gemini')
  }
  const data = await res.json()
  const parts = data?.candidates?.[0]?.content?.parts ?? []
  const text = parts.map((p: any) => p?.text ?? '').join('').trim()
  if (!text) {
    const reason = data?.candidates?.[0]?.finishReason ?? 'unknown'
    throw new ProviderError(502, `Gemini returned no text (finishReason: ${reason})`, 'gemini')
  }
  return text
}

/** Runs a (system,user) prompt through NVIDIA, then Groq, then Gemini. */
async function complete(system: string, user: string, geminiModel: string): Promise<string> {
  if (NVIDIA_API_KEY) {
    try {
      return await nvidiaChat(system, user)
    } catch (e) {
      console.error('NVIDIA summarize failed; falling back to Groq:', String(e))
      if (!GROQ_API_KEY && !GEMINI_API_KEY) throw e
    }
  }
  if (GROQ_API_KEY) {
    try {
      return await groqChat(system, user)
    } catch (e) {
      console.error('Groq summarize failed; falling back to Gemini:', String(e))
      if (!GEMINI_API_KEY) throw e
    }
  }
  if (GEMINI_API_KEY) return geminiGenerate(geminiModel, `${system}\n\n${user}`)
  throw new ProviderError(503, 'No summary provider is configured.', 'none')
}

// ── Long-transcript chunking (map-reduce) ─────────────────────────────────────
function chunkText(text: string, max: number): string[] {
  const chunks: string[] = []
  let buf = ''
  for (const para of text.split(/\n+/)) {
    if (buf.length + para.length + 1 > max && buf) {
      chunks.push(buf)
      buf = ''
    }
    // A single oversized paragraph is hard-split.
    if (para.length > max) {
      for (let i = 0; i < para.length; i += max) chunks.push(para.slice(i, i + max))
    } else {
      buf = buf ? `${buf}\n${para}` : para
    }
  }
  if (buf) chunks.push(buf)
  return chunks
}

const CONDENSE_SYSTEM =
  'Extract the key points from this part of a meeting transcript as concise plain bullet notes: tasks/instructions, context, important details (numbers, names, dates), deadlines, and anything said only once. Keep the original language (English or Roman Urdu in Latin letters; never Nastaliq). Output only the notes.'

const fallbackTitle = () => {
  const date = new Date().toLocaleDateString('en-US', {
    month: 'short',
    day: 'numeric',
    year: 'numeric',
  })
  return `Briefing — ${date}`
}

function splitTitle(raw: string): { title: string; summary: string } {
  const text = raw.trim()
  const lines = text.split('\n')
  const match = (lines[0]?.trim() ?? '').match(/^TITLE:\s*(.+)$/i)
  if (match) {
    const title = match[1].replace(/[*_`#]/g, '').trim()
    const summary = lines.slice(1).join('\n').trim()
    return { title: title || fallbackTitle(), summary: summary || text }
  }
  return { title: fallbackTitle(), summary: text }
}

async function summarize(
  instruction: string,
  transcript: string,
  geminiModel: string,
): Promise<{ title: string; summary: string }> {
  const system = `${BASE_RULES}\n\n${instruction ? customBody(instruction) : DEFAULT_BODY}`

  // Short transcript → one pass.
  if (transcript.length <= SUMMARIZE_CHAR_LIMIT) {
    const raw = await complete(system, `Transcript:\n"""\n${transcript}\n"""`, geminiModel)
    return splitTitle(raw)
  }

  // Long transcript → condense each chunk, then summarize the combined notes.
  const chunks = chunkText(transcript, SUMMARIZE_CHAR_LIMIT)
  const notes: string[] = []
  for (const chunk of chunks) {
    notes.push(await complete(CONDENSE_SYSTEM, chunk, geminiModel))
  }
  const raw = await complete(
    system,
    `These are notes extracted from a long meeting. Write the final brief from them:\n"""\n${notes.join('\n\n')}\n"""`,
    geminiModel,
  )
  return splitTitle(raw)
}

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders })
  if (req.method !== 'POST') return json({ error: 'Method not allowed.' }, 405)

  const authHeader = req.headers.get('Authorization') ?? ''
  const supabase = createClient(
    Deno.env.get('SUPABASE_URL') ?? '',
    Deno.env.get('SUPABASE_ANON_KEY') ?? '',
    { global: { headers: { Authorization: authHeader } } },
  )
  const { data: { user }, error: authError } = await supabase.auth.getUser()
  if (authError || !user) {
    return json({ error: 'Unauthorized. Please sign in and try again.' }, 401)
  }

  if (!NVIDIA_API_KEY && !GROQ_API_KEY && !GEMINI_API_KEY) {
    return json({ error: 'Server is not configured: no AI provider key set.' }, 500)
  }

  let payload: { transcript?: string; instruction?: string; model?: string }
  try {
    payload = await req.json()
  } catch {
    return json({ error: 'Invalid request body.' }, 400)
  }

  const transcript = (payload.transcript ?? '').trim()
  const instruction = (payload.instruction ?? '').trim()
  const geminiModel = resolveModel(payload.model)
  if (!transcript) return json({ error: 'No transcript was provided.' }, 400)

  try {
    const { title, summary } = await summarize(instruction, transcript, geminiModel)
    return json({ title, summary })
  } catch (e) {
    console.error('Summarize error:', e)
    if (e instanceof ProviderError && e.status === 429) {
      return json(
        {
          error:
            'The AI service is rate-limited or out of quota right now. Please wait a minute and try again.',
        },
        429,
      )
    }
    if (e instanceof ProviderError && (e.status === 401 || e.status === 403)) {
      return json({ error: 'The AI service rejected the request (check the API keys).' }, 502)
    }
    return json({ error: 'Could not generate the summary. Please try again.', detail: String(e) }, 502)
  }
})
