// EIA Recap — `set-ai-key` Edge Function (Lovable Cloud mode)
//
// On Lovable Cloud, API keys (GROQ_API_KEY / GEMINI_API_KEY) are managed
// directly as Cloud edge-function secrets — not via the Supabase Management
// API. This function therefore:
//
//   GET  -> { groq, gemini }     // whether each secret is currently set
//   POST -> { ok: false, managed: true, message }  // 200 with friendly note
//
// It never errors out, so the Settings screen renders cleanly.

import { createClient } from 'jsr:@supabase/supabase-js@2'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers':
    'authorization, x-client-info, apikey, content-type',
  'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
}

function json(body: unknown, status = 200): Response {
  return new Response(JSON.stringify(body), {
    status,
    headers: { ...corsHeaders, 'Content-Type': 'application/json' },
  })
}

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders })

  // Verify the caller's Supabase JWT (must be signed in).
  const authHeader = req.headers.get('Authorization') ?? ''
  const supabase = createClient(
    Deno.env.get('SUPABASE_URL') ?? '',
    Deno.env.get('SUPABASE_ANON_KEY') ?? '',
    { global: { headers: { Authorization: authHeader } } },
  )
  const { data: { user }, error: authError } = await supabase.auth.getUser()
  if (authError || !user) {
    return json({ error: 'Unauthorized. Please sign in and try again.' }, 401)
  }

  if (req.method === 'GET') {
    return json({
      groq: Boolean(Deno.env.get('GROQ_API_KEY')),
      gemini: Boolean(Deno.env.get('GEMINI_API_KEY')),
      managed: true,
    })
  }

  if (req.method === 'POST') {
    return json({
      ok: false,
      managed: true,
      error:
        'AI keys are managed via Lovable Cloud secrets. Update GROQ_API_KEY or GEMINI_API_KEY in the backend secrets panel.',
    })
  }

  return json({ error: 'Method not allowed.' }, 405)
})
