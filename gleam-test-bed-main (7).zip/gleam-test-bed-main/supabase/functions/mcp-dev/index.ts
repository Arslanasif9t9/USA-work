// EIA Recap — `mcp-dev` Edge Function (read-only MCP server, DEV-USER SCOPED)
//
// Structurally identical to `mcp-call/index.ts`, locked to the dev user.
// Every meetings query has `.eq('user_id', DEV_UID)` appended, so this server
// physically cannot return any other user's records.
//
// AUTH: bearer MCP_DEV_BEARER via ?token= or Authorization header.

import { createClient } from 'jsr:@supabase/supabase-js@2'

const MCP_PROTOCOL_VERSION = '2024-11-05'
const SERVER_INFO = { name: 'callrecap-mcp-dev', version: '1.0.0' }

// Hardcoded "dev" user. Every query in this server is scoped to this uid.
const DEV_UID = 'b4039103-1c1f-4c29-a48f-b60e312dd856'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers':
    'authorization, x-client-info, apikey, content-type',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
}

const TOOLS = [
  {
    name: 'list_meetings',
    description:
      "List the dev user's own saved meetings (most recent first). Lightweight: returns id, title, created_at, duration_sec, word_count, and live_caption — no transcript. Scoped to the dev user only.",
    inputSchema: {
      type: 'object',
      properties: {
        limit: { type: 'number', description: 'Max rows (default 20, max 50).' },
      },
    },
  },
  {
    name: 'get_meeting',
    description:
      "Get one of the dev user's meetings by id, including its full summary, Groq Whisper transcript, and browser live_caption. Returns nothing if the id belongs to another user.",
    inputSchema: {
      type: 'object',
      properties: { id: { type: 'string', description: 'Meeting UUID.' } },
      required: ['id'],
    },
  },
  {
    name: 'get_latest_meeting',
    description:
      "Get the dev user's single most recent meeting, including its full summary, Groq Whisper transcript, and browser live_caption. Scoped to the dev user only.",
    inputSchema: { type: 'object', properties: {} },
  },
  {
    name: 'search_meetings',
    description:
      "Search the dev user's own meetings whose transcript, summary, or title matches the query (case-insensitive). Lightweight: returns id, title, created_at, live_caption, and a short summary snippet — no transcript. Scoped to the dev user only.",
    inputSchema: {
      type: 'object',
      properties: {
        query: { type: 'string', description: 'Text to search for.' },
        limit: { type: 'number', description: 'Max rows (default 20, max 50).' },
      },
      required: ['query'],
    },
  },
  {
    name: 'create_meeting',
    description:
      'Save a note/recap into the developer account. Returns the created row.',
    inputSchema: {
      type: 'object',
      properties: {
        title: { type: 'string', description: 'Meeting title (required, max ~300 chars).' },
        transcript: { type: 'string', description: 'Full transcript text (optional).' },
        summary: { type: 'string', description: 'Summary text (optional).' },
        live_caption: { type: 'string', description: 'Browser live caption (optional).' },
        created_at: { type: 'string', description: 'ISO 8601 timestamp (optional, defaults to now).' },
        duration_sec: { type: 'number', description: 'Duration in seconds (optional, default 0).' },
      },
      required: ['title'],
    },
  },
]

function respond(body: unknown, status = 200): Response {
  return new Response(JSON.stringify(body), {
    status,
    headers: { ...corsHeaders, 'Content-Type': 'application/json' },
  })
}
const rpcResult = (id: unknown, result: unknown) => ({ jsonrpc: '2.0', id: id ?? null, result })
const rpcError = (id: unknown, code: number, message: string) => ({
  jsonrpc: '2.0',
  id: id ?? null,
  error: { code, message },
})
const toolContent = (data: unknown) => ({
  content: [{ type: 'text', text: JSON.stringify(data, null, 2) }],
})

const clampLimit = (n: unknown) => {
  const v = typeof n === 'number' && Number.isFinite(n) ? Math.floor(n) : 20
  return Math.min(50, Math.max(1, v))
}

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders })

  try {
    if (req.method !== 'POST') {
      return respond(rpcError(null, -32600, 'Only POST is supported.'), 405)
    }

    let rpc: { id?: unknown; method?: string; params?: any }
    try {
      rpc = await req.json()
    } catch {
      return respond(rpcError(null, -32700, 'Parse error: invalid JSON.'), 400)
    }
    const id = rpc?.id ?? null
    const method = rpc?.method

    const expected = Deno.env.get('MCP_DEV_BEARER') ?? ''
    if (!expected) {
      return respond(rpcError(id, -32000, 'Server is not configured: MCP_DEV_BEARER is missing.'), 500)
    }
    const queryToken = new URL(req.url).searchParams.get('token') ?? ''
    const authHeader = req.headers.get('Authorization') ?? ''
    const headerToken = authHeader.startsWith('Bearer ') ? authHeader.slice(7).trim() : ''
    const token = queryToken || headerToken
    if (!token || token !== expected) {
      return respond(rpcError(id, -32001, 'Unauthorized.'), 401)
    }

    if (method === 'initialize') {
      return respond(
        rpcResult(id, {
          protocolVersion: MCP_PROTOCOL_VERSION,
          capabilities: { tools: {} },
          serverInfo: SERVER_INFO,
        }),
      )
    }

    if (method === 'notifications/initialized') {
      return respond(rpcResult(id, {}))
    }

    if (method === 'tools/list') {
      return respond(rpcResult(id, { tools: TOOLS }))
    }

    if (method === 'tools/call') {
      const name = rpc?.params?.name as string
      const args = (rpc?.params?.arguments ?? {}) as Record<string, unknown>

      const url = Deno.env.get('SUPABASE_URL') ?? ''
      const serviceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
      if (!url || !serviceKey) {
        return respond(rpcError(id, -32000, 'Server is not configured: Supabase env missing.'), 500)
      }
      const supabase = createClient(url, serviceKey, {
        auth: { persistSession: false, autoRefreshToken: false },
      })

      try {
        if (name === 'list_meetings') {
          const limit = clampLimit(args.limit)
          const { data, error } = await supabase
            .from('meetings')
            .select('id, title, created_at, duration_sec, word_count, live_caption')
            .eq('user_id', DEV_UID)
            .order('created_at', { ascending: false })
            .limit(limit)
          if (error) throw new Error(error.message)
          return respond(rpcResult(id, toolContent(data ?? [])))
        }

        if (name === 'get_meeting') {
          const mid = String(args.id ?? '').trim()
          if (!mid) return respond(rpcResult(id, toolContent({ error: 'id is required.' })))
          const { data, error } = await supabase
            .from('meetings')
            .select('id, title, summary, transcript, live_caption, duration_sec, word_count, created_at')
            .eq('id', mid)
            .eq('user_id', DEV_UID)
            .maybeSingle()
          if (error) throw new Error(error.message)
          if (!data) {
            return respond(
              rpcResult(id, toolContent({ error: `No meeting found with id ${mid} for the dev user.` })),
            )
          }
          return respond(rpcResult(id, toolContent(data)))
        }

        if (name === 'get_latest_meeting') {
          const { data, error } = await supabase
            .from('meetings')
            .select('id, title, summary, transcript, live_caption, duration_sec, word_count, created_at')
            .eq('user_id', DEV_UID)
            .order('created_at', { ascending: false })
            .limit(1)
            .maybeSingle()
          if (error) throw new Error(error.message)
          if (!data) {
            return respond(rpcResult(id, toolContent({ error: 'No meetings found for the dev user.' })))
          }
          return respond(rpcResult(id, toolContent(data)))
        }

        if (name === 'search_meetings') {
          const query = String(args.query ?? '').trim()
          if (!query) return respond(rpcResult(id, toolContent({ error: 'query is required.' })))
          const limit = clampLimit(args.limit)
          const safe = query.replace(/[,()%*\\]/g, ' ').trim()
          const pattern = `%${safe}%`
          const { data, error } = await supabase
            .from('meetings')
            .select('id, title, created_at, summary, live_caption')
            .eq('user_id', DEV_UID)
            .or(`transcript.ilike.${pattern},summary.ilike.${pattern},title.ilike.${pattern}`)
            .order('created_at', { ascending: false })
            .limit(limit)
          if (error) throw new Error(error.message)
          const rows = (data ?? []).map((m: any) => ({
            id: m.id,
            title: m.title,
            created_at: m.created_at,
            snippet: String(m.summary ?? '').slice(0, 200),
            live_caption: m.live_caption ?? null,
          }))
          return respond(rpcResult(id, toolContent(rows)))
        }

        if (name === 'create_meeting') {
          const title = String(args.title ?? '').trim()
          const transcript = typeof args.transcript === 'string' ? args.transcript : ''
          const summary = typeof args.summary === 'string' ? args.summary : ''
          const liveCaption = typeof args.live_caption === 'string' ? args.live_caption : ''
          const createdAt = typeof args.created_at === 'string' && args.created_at.trim()
            ? args.created_at.trim()
            : null
          const durationSec =
            typeof args.duration_sec === 'number' && Number.isFinite(args.duration_sec)
              ? Math.max(0, Math.floor(args.duration_sec))
              : 0

          if (!title) {
            return respond(rpcResult(id, toolContent({ error: 'title is required.' })))
          }
          if (title.length > 300) {
            return respond(rpcResult(id, toolContent({ error: 'title must be 300 chars or fewer.' })))
          }
          if (!transcript && !summary && !liveCaption) {
            return respond(
              rpcResult(
                id,
                toolContent({ error: 'At least one of transcript, summary, or live_caption is required.' }),
              ),
            )
          }
          const totalBytes = (title.length + transcript.length + summary.length + liveCaption.length) * 2
          if (totalBytes > 1_000_000) {
            return respond(rpcResult(id, toolContent({ error: 'Body too large (~1MB cap).' })))
          }

          const wordCount = transcript.trim()
            ? transcript.trim().split(/\s+/).length
            : 0

          const row: Record<string, unknown> = {
            user_id: DEV_UID,
            uploaded_by: 'dev',
            title,
            transcript: transcript || null,
            summary: summary || '',
            live_caption: liveCaption || null,
            duration_sec: durationSec,
            word_count: wordCount,
          }
          if (createdAt) row.created_at = createdAt

          const { data, error } = await supabase
            .from('meetings')
            .insert(row)
            .select('id, user_id, title, summary, transcript, live_caption, duration_sec, word_count, created_at, expires_at, uploaded_by')
            .single()
          if (error) throw new Error(error.message)
          return respond(rpcResult(id, toolContent(data)))
        }

        return respond(rpcError(id, -32602, `Unknown tool: ${name}`))
      } catch (e) {
        return respond(rpcError(id, -32603, `Tool error: ${String(e)}`))
      }
    }

    return respond(rpcError(id, -32601, `Method not found: ${method}`))
  } catch (e) {
    return respond(rpcError(null, -32603, `Internal error: ${String(e)}`), 500)
  }
})
