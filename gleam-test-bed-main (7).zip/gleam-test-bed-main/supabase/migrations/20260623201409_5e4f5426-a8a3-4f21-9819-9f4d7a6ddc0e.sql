ALTER TABLE public.meetings ADD COLUMN IF NOT EXISTS uploaded_by text;

DROP FUNCTION IF EXISTS public.admin_list_all_meetings();

CREATE OR REPLACE FUNCTION public.admin_list_all_meetings()
 RETURNS TABLE(id uuid, user_id uuid, owner_username text, title text, summary text, created_at timestamp with time zone, expires_at timestamp with time zone, duration_sec integer, word_count integer, live_caption text, uploaded_by text)
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
BEGIN
  IF (SELECT u.email FROM auth.users u WHERE u.id = auth.uid()) <> 'admin@eia.local' THEN
    RAISE EXCEPTION 'not authorized';
  END IF;
  RETURN QUERY
    SELECT m.id,
           m.user_id,
           split_part((SELECT u.email::text FROM auth.users u WHERE u.id = m.user_id), '@', 1) AS owner_username,
           m.title,
           m.summary,
           m.created_at,
           m.expires_at,
           m.duration_sec,
           m.word_count,
           m.live_caption,
           m.uploaded_by
    FROM public.meetings m
    ORDER BY m.created_at DESC;
END;
$function$;