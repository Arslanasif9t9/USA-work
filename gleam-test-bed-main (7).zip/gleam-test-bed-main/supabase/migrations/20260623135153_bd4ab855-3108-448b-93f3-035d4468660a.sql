-- Master-admin user management RPCs.
-- All SECURITY DEFINER, first line admin-gates on auth.uid()'s email.

CREATE OR REPLACE FUNCTION public.admin_list_users()
RETURNS TABLE(id uuid, username text, email text, created_at timestamptz, is_admin boolean)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF (SELECT u.email FROM auth.users u WHERE u.id = auth.uid()) <> 'admin@eia.local' THEN
    RAISE EXCEPTION 'not authorized';
  END IF;
  RETURN QUERY
    SELECT u.id,
           split_part(u.email::text, '@', 1) AS username,
           u.email::text AS email,
           u.created_at,
           (u.email = 'admin@eia.local') AS is_admin
    FROM auth.users u
    ORDER BY u.created_at;
END;
$$;

CREATE OR REPLACE FUNCTION public.admin_create_user(p_username text, p_password text)
RETURNS uuid
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_username text;
  v_email    text;
  v_id       uuid;
BEGIN
  IF (SELECT u.email FROM auth.users u WHERE u.id = auth.uid()) <> 'admin@eia.local' THEN
    RAISE EXCEPTION 'not authorized';
  END IF;
  v_username := lower(trim(coalesce(p_username, '')));
  IF v_username = '' OR coalesce(p_password, '') = '' THEN
    RAISE EXCEPTION 'username and password required';
  END IF;
  v_email := v_username || '@eia.local';
  IF EXISTS (SELECT 1 FROM auth.users WHERE email = v_email) THEN
    RAISE EXCEPTION 'user already exists';
  END IF;
  v_id := gen_random_uuid();

  INSERT INTO auth.users (
    instance_id, id, aud, role, email, encrypted_password,
    email_confirmed_at, created_at, updated_at,
    raw_app_meta_data, raw_user_meta_data,
    confirmation_token, recovery_token,
    email_change_token_new, email_change_token_current, email_change,
    phone_change, phone_change_token, reauthentication_token
  ) VALUES (
    '00000000-0000-0000-0000-000000000000', v_id, 'authenticated', 'authenticated',
    v_email, crypt(p_password, gen_salt('bf')),
    now(), now(), now(),
    '{"provider":"email","providers":["email"]}'::jsonb, '{}'::jsonb,
    '', '', '', '', '', '', '', ''
  );

  INSERT INTO auth.identities (
    provider_id, user_id, identity_data, provider, last_sign_in_at, created_at, updated_at
  ) VALUES (
    v_id::text, v_id,
    jsonb_build_object('sub', v_id::text, 'email', v_email),
    'email', now(), now(), now()
  );

  INSERT INTO public.profiles (id) VALUES (v_id) ON CONFLICT (id) DO NOTHING;

  RETURN v_id;
END;
$$;

CREATE OR REPLACE FUNCTION public.admin_reset_password(p_user_id uuid, p_new_password text)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF (SELECT u.email FROM auth.users u WHERE u.id = auth.uid()) <> 'admin@eia.local' THEN
    RAISE EXCEPTION 'not authorized';
  END IF;
  IF coalesce(p_new_password, '') = '' THEN
    RAISE EXCEPTION 'password required';
  END IF;
  UPDATE auth.users
     SET encrypted_password = crypt(p_new_password, gen_salt('bf')),
         updated_at = now(),
         confirmation_token = '',
         recovery_token = '',
         email_change_token_new = '',
         email_change_token_current = '',
         email_change = '',
         phone_change = '',
         phone_change_token = '',
         reauthentication_token = ''
   WHERE id = p_user_id;
END;
$$;

CREATE OR REPLACE FUNCTION public.admin_delete_user(p_user_id uuid)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF (SELECT u.email FROM auth.users u WHERE u.id = auth.uid()) <> 'admin@eia.local' THEN
    RAISE EXCEPTION 'not authorized';
  END IF;
  IF (SELECT u.email FROM auth.users u WHERE u.id = p_user_id) = 'admin@eia.local' THEN
    RAISE EXCEPTION 'cannot delete master admin';
  END IF;

  DELETE FROM public.meetings    WHERE user_id = p_user_id;
  DELETE FROM auth.identities    WHERE user_id = p_user_id;
  DELETE FROM public.profiles    WHERE id      = p_user_id;
  DELETE FROM auth.users         WHERE id      = p_user_id;
END;
$$;

GRANT EXECUTE ON FUNCTION public.admin_list_users()                       TO authenticated;
GRANT EXECUTE ON FUNCTION public.admin_create_user(text, text)            TO authenticated;
GRANT EXECUTE ON FUNCTION public.admin_reset_password(uuid, text)         TO authenticated;
GRANT EXECUTE ON FUNCTION public.admin_delete_user(uuid)                  TO authenticated;
