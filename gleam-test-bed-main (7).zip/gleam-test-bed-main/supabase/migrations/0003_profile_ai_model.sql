-- EIA Recap — add the AI model preference to profiles (PLAN.md §7).
-- The §6 schema had no column for the Settings "AI model" dropdown.
alter table public.profiles
  add column if not exists ai_model text not null default 'gemini-2.5-flash';
