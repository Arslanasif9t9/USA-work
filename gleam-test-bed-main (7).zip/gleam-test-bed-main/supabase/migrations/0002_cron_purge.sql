-- EIA Recap — 3-day hard delete via pg_cron (PLAN.md §6)
--
-- Prerequisite: enable the pg_cron extension first
--   Supabase Dashboard → Database → Extensions → enable "pg_cron".
-- Then run this file.

create extension if not exists pg_cron;

select cron.schedule(
  'purge-expired-meetings',
  '0 * * * *',                       -- hourly
  $$ delete from public.meetings where expires_at < now(); $$
);
