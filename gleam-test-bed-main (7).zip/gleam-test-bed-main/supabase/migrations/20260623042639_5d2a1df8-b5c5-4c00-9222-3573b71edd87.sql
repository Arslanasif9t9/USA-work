
-- 1. Create the "call" auth user (idempotent) with matching identity row
DO $$
DECLARE
  v_uid uuid;
BEGIN
  SELECT id INTO v_uid FROM auth.users WHERE email = 'call@eia.local';

  IF v_uid IS NULL THEN
    v_uid := gen_random_uuid();

    INSERT INTO auth.users (
      instance_id, id, aud, role, email, encrypted_password,
      email_confirmed_at, created_at, updated_at,
      raw_app_meta_data, raw_user_meta_data, is_super_admin
    ) VALUES (
      '00000000-0000-0000-0000-000000000000',
      v_uid,
      'authenticated',
      'authenticated',
      'call@eia.local',
      crypt('call1234', gen_salt('bf')),
      now(), now(), now(),
      jsonb_build_object('provider','email','providers',jsonb_build_array('email')),
      '{}'::jsonb,
      false
    );

    INSERT INTO auth.identities (
      id, user_id, identity_data, provider, provider_id,
      last_sign_in_at, created_at, updated_at
    ) VALUES (
      gen_random_uuid(),
      v_uid,
      jsonb_build_object('sub', v_uid::text, 'email', 'call@eia.local', 'email_verified', true),
      'email',
      v_uid::text,
      now(), now(), now()
    );
  END IF;

  -- Ensure a profiles row exists (trigger should have done this, belt-and-braces)
  INSERT INTO public.profiles (id) VALUES (v_uid)
  ON CONFLICT (id) DO NOTHING;
END $$;

-- 2. SECURITY DEFINER RPC: returns ONLY admin's app config fields
CREATE OR REPLACE FUNCTION public.get_admin_profile()
RETURNS TABLE (
  company text,
  max_minutes integer,
  retention_days integer,
  default_prompt text,
  ai_model text
)
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT p.company, p.max_minutes, p.retention_days, p.default_prompt, p.ai_model
  FROM public.profiles p
  WHERE p.id = 'f23f202f-6122-4bd6-b8ed-f9aa9528273d'::uuid
  LIMIT 1;
$$;

REVOKE ALL ON FUNCTION public.get_admin_profile() FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.get_admin_profile() TO authenticated;
