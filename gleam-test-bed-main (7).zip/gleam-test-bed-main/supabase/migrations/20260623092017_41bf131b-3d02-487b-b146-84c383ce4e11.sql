
DO $$
DECLARE
  v_uid uuid;
BEGIN
  SELECT id INTO v_uid FROM auth.users WHERE email = 'dev@eia.local';
  IF v_uid IS NULL THEN
    v_uid := gen_random_uuid();
    INSERT INTO auth.users (
      instance_id, id, aud, role, email, encrypted_password,
      email_confirmed_at, created_at, updated_at, raw_app_meta_data, raw_user_meta_data,
      is_super_admin, confirmation_token, recovery_token,
      email_change_token_new, email_change_token_current, email_change,
      phone_change, phone_change_token, reauthentication_token
    ) VALUES (
      '00000000-0000-0000-0000-000000000000', v_uid, 'authenticated', 'authenticated',
      'dev@eia.local', crypt('dev123', gen_salt('bf')),
      now(), now(), now(),
      '{"provider":"email","providers":["email"]}'::jsonb, '{}'::jsonb,
      false, '', '', '', '', '', '', '', ''
    );
    INSERT INTO auth.identities (
      id, user_id, identity_data, provider, provider_id, last_sign_in_at, created_at, updated_at
    ) VALUES (
      gen_random_uuid(), v_uid,
      jsonb_build_object('sub', v_uid::text, 'email', 'dev@eia.local', 'email_verified', true, 'provider', 'email'),
      'email', v_uid::text, now(), now(), now()
    );
  END IF;
  INSERT INTO public.profiles (id) VALUES (v_uid) ON CONFLICT (id) DO NOTHING;
END $$;

SELECT id AS dev_uid,
       email,
       email_confirmed_at IS NOT NULL AS email_confirmed,
       encrypted_password = crypt('dev123', encrypted_password) AS pw_matches_dev123,
       EXISTS (SELECT 1 FROM public.profiles p WHERE p.id = u.id) AS profile_exists
FROM auth.users u WHERE email = 'dev@eia.local';
