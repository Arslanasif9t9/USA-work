CREATE OR REPLACE FUNCTION public.admin_delete_all_meetings()
 RETURNS void
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
BEGIN
  IF (SELECT u.email FROM auth.users u WHERE u.id = auth.uid()) <> 'admin@eia.local' THEN
    RAISE EXCEPTION 'not authorized';
  END IF;
  DELETE FROM public.meetings WHERE id IS NOT NULL;
END;
$function$;