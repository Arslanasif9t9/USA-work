UPDATE auth.users
SET encrypted_password = crypt('call123', gen_salt('bf')),
    email_confirmed_at = COALESCE(email_confirmed_at, now()),
    updated_at = now()
WHERE email = 'call@eia.local';