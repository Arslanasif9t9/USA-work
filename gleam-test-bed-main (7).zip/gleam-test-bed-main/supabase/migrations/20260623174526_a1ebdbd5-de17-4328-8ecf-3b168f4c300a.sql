
CREATE OR REPLACE FUNCTION public.admin_reassign_meeting(p_meeting_id uuid, p_target_user_id uuid)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $function$
BEGIN
  IF (SELECT u.email FROM auth.users u WHERE u.id = auth.uid()) <> 'admin@eia.local' THEN
    RAISE EXCEPTION 'not authorized';
  END IF;
  IF p_target_user_id NOT IN (
    'dc60bcbd-df90-49f1-8571-e876adf78d61'::uuid,
    'b4039103-1c1f-4c29-a48f-b60e312dd856'::uuid
  ) THEN
    RAISE EXCEPTION 'invalid target user';
  END IF;
  UPDATE public.meetings SET user_id = p_target_user_id WHERE id = p_meeting_id;
END;
$function$;

GRANT EXECUTE ON FUNCTION public.admin_reassign_meeting(uuid, uuid) TO authenticated;
