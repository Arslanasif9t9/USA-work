-- EIA Recap — initial schema (PLAN.md §6)
-- Run this in the Supabase SQL editor (or via the Supabase CLI).

-- ── PROFILES ────────────────────────────────────────────────────────────────
create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  name text,
  company text default 'EIA — Intuitive Expert Advisor Inc.',
  max_minutes int default 30,
  retention_days int default 3,
  default_prompt text default '',
  created_at timestamptz default now()
);

-- ── MEETINGS (no audio stored) ────────────────────────────────────────────────
create table public.meetings (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  title text not null,
  summary text not null,
  transcript text,
  duration_sec int default 0,
  word_count int default 0,
  created_at timestamptz default now(),
  expires_at timestamptz not null default (now() + interval '3 days')
);
create index on public.meetings (user_id, created_at desc);

-- ── ROW LEVEL SECURITY ────────────────────────────────────────────────────────
alter table public.profiles enable row level security;
alter table public.meetings enable row level security;

create policy "own profile"
  on public.profiles for all
  using (auth.uid() = id) with check (auth.uid() = id);

create policy "own meetings"
  on public.meetings for all
  using (auth.uid() = user_id) with check (auth.uid() = user_id);
