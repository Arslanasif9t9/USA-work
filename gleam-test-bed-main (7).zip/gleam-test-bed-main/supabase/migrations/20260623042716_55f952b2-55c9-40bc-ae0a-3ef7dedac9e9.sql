REVOKE EXECUTE ON FUNCTION public.get_admin_profile() FROM anon, PUBLIC;
GRANT EXECUTE ON FUNCTION public.get_admin_profile() TO authenticated;