CREATE OR REPLACE FUNCTION public.admin_list_all_meetings()
RETURNS TABLE (
  id uuid,
  user_id uuid,
  owner_username text,
  title text,
  summary text,
  created_at timestamptz,
  expires_at timestamptz,
  duration_sec int,
  word_count int,
  live_caption text
)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF (SELECT u.email FROM auth.users u WHERE u.id = auth.uid()) <> 'admin@eia.local' THEN
    RAISE EXCEPTION 'not authorized';
  END IF;
  RETURN QUERY
    SELECT m.id,
           m.user_id,
           split_part((SELECT u.email::text FROM auth.users u WHERE u.id = m.user_id), '@', 1) AS owner_username,
           m.title,
           m.summary,
           m.created_at,
           m.expires_at,
           m.duration_sec,
           m.word_count,
           m.live_caption
    FROM public.meetings m
    ORDER BY m.created_at DESC;
END;
$$;

GRANT EXECUTE ON FUNCTION public.admin_list_all_meetings() TO authenticated;

CREATE OR REPLACE FUNCTION public.admin_delete_meeting(p_meeting_id uuid)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF (SELECT u.email FROM auth.users u WHERE u.id = auth.uid()) <> 'admin@eia.local' THEN
    RAISE EXCEPTION 'not authorized';
  END IF;
  DELETE FROM public.meetings WHERE id = p_meeting_id;
END;
$$;

GRANT EXECUTE ON FUNCTION public.admin_delete_meeting(uuid) TO authenticated;

CREATE OR REPLACE FUNCTION public.admin_delete_meetings(p_ids uuid[])
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF (SELECT u.email FROM auth.users u WHERE u.id = auth.uid()) <> 'admin@eia.local' THEN
    RAISE EXCEPTION 'not authorized';
  END IF;
  DELETE FROM public.meetings WHERE id = ANY(p_ids);
END;
$$;

GRANT EXECUTE ON FUNCTION public.admin_delete_meetings(uuid[]) TO authenticated;

CREATE OR REPLACE FUNCTION public.admin_delete_all_meetings()
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF (SELECT u.email FROM auth.users u WHERE u.id = auth.uid()) <> 'admin@eia.local' THEN
    RAISE EXCEPTION 'not authorized';
  END IF;
  DELETE FROM public.meetings;
END;
$$;

GRANT EXECUTE ON FUNCTION public.admin_delete_all_meetings() TO authenticated;