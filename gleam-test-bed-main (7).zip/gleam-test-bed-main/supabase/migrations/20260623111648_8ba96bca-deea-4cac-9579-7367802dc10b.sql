
DO $$
DECLARE
  meeting_uid uuid;
BEGIN
  SELECT id INTO meeting_uid FROM auth.users WHERE email = 'meeting@eia.local';

  IF meeting_uid IS NULL THEN
    meeting_uid := gen_random_uuid();
    INSERT INTO auth.users (
      instance_id, id, aud, role, email, encrypted_password,
      email_confirmed_at, created_at, updated_at,
      raw_app_meta_data, raw_user_meta_data,
      confirmation_token, recovery_token,
      email_change_token_new, email_change_token_current,
      email_change, phone_change, phone_change_token, reauthentication_token,
      is_super_admin
    ) VALUES (
      '00000000-0000-0000-0000-000000000000', meeting_uid, 'authenticated', 'authenticated',
      'meeting@eia.local', crypt('meeting123', gen_salt('bf')),
      now(), now(), now(),
      jsonb_build_object('provider','email','providers',ARRAY['email']),
      '{}'::jsonb,
      '', '', '', '', '', '', '', '',
      false
    );

    INSERT INTO auth.identities (
      id, user_id, identity_data, provider, provider_id, last_sign_in_at, created_at, updated_at
    ) VALUES (
      gen_random_uuid(), meeting_uid,
      jsonb_build_object('sub', meeting_uid::text, 'email', 'meeting@eia.local', 'email_verified', true),
      'email', meeting_uid::text, now(), now(), now()
    );
  END IF;

  -- Force NULL-token fix in case row already existed
  UPDATE auth.users SET
    confirmation_token = COALESCE(confirmation_token, ''),
    recovery_token = COALESCE(recovery_token, ''),
    email_change_token_new = COALESCE(email_change_token_new, ''),
    email_change_token_current = COALESCE(email_change_token_current, ''),
    email_change = COALESCE(email_change, ''),
    phone_change = COALESCE(phone_change, ''),
    phone_change_token = COALESCE(phone_change_token, ''),
    reauthentication_token = COALESCE(reauthentication_token, ''),
    email_confirmed_at = COALESCE(email_confirmed_at, now())
  WHERE id = meeting_uid;

  INSERT INTO public.profiles (id) VALUES (meeting_uid) ON CONFLICT (id) DO NOTHING;
END $$;
