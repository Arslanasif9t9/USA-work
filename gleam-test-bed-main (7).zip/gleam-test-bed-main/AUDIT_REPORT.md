# EIA Recap — Final Audit Report

_Date: 2026-06-01 · Commit audited: `55921e9` · Branch: `main`_

A full-system, read-only audit against `PLAN.md` and `CLAUDE.md`. Per the
constraint, the live Gemini API was called **exactly once** (a single minimal
`summarize` request); every other check was done via build/typecheck, the
Supabase Management/Data APIs, HTTP gate probes, and static code reading.

---

## 1. Build status

- `npm run build` (`tsc -b && vite build`): **PASS** — 482 modules, no type
  errors, **no warnings** (the earlier 500 kB chunk warning is gone; jsPDF is
  code-split and lazy-loaded).
- Output: `index` ~424 kB (gzip ~121 kB) + on-demand `jspdf`/`html2canvas`/
  `purify` chunks.

---

## 2. Acceptance checklist (§13)

| # | Item | Result | Reason |
|---|------|--------|--------|
| 1 | Every word captured (3–5 min continuous) | **NEEDS BROWSER TEST** | Architecture verified: records full audio via MediaRecorder → whole file sent to Gemini (no live STT). Needs a live mic + Gemini run to confirm. |
| 2 | Urdu → Roman Urdu, never Nastaliq | **NEEDS BROWSER TEST** | Both `transcribe` and `summarize` prompts enforce Roman Urdu and forbid Nastaliq; logic verified, output needs a Gemini run. |
| 3 | Summary worker-facing, no speaker labels | **PASS** | Validated by the single Gemini call: "What you need to do…" framing, all five §3 sections, zero speaker labels. |
| 4 | 30-min auto-stop + ring; Pause/Resume keeps time | **PASS (logic)** | Cap from profile; auto-stop at cap; elapsed accumulates only while recording (pause-safe). Visual feel is a browser nicety. |
| 5 | Copy is most prominent + copies edited summary | **PASS** | `SummaryCard` Copy is the primary action and copies the live (edited) `summary` state. |
| 6 | Regenerate with custom instruction changes output | **NEEDS BROWSER TEST** | Instruction is wired to the `summarize` `instruction` param + presets; not re-run to preserve the one-call limit. |
| 7 | PDF + .txt download; Email + WhatsApp prefilled | **PASS (logic)** | jsPDF, Blob `.txt`, `mailto:`, `wa.me` all implemented from current title/summary. Actual download/app-open is a browser check. |
| 8 | Saved list: search, duration, word count, open, delete | **PASS** | History page card grid + search + modal + delete; verified against the DB. |
| 9 | Hard-delete after retention (pg_cron); expired never shown | **PASS** | Cron job present (hourly); expired-filter test: active shown, expired hidden. |
| 10 | RLS: user sees only own meetings | **PASS** | RLS enabled on both tables; `own meetings`/`own profile` policies present; queries scoped to `user_id`. |
| 11 | Gemini key server-side, not in bundle | **PASS** | No secrets in `dist`; key lives only in the Supabase `GEMINI_API_KEY` secret. |
| 12 | Landing polished + responsive | **NEEDS BROWSER TEST** | Implemented per §8 (hero, dotted grid, glows, responsive); visual confirmation is manual. |

**Manual browser tests remaining (4):** every-word capture (#1), Urdu→Roman
Urdu (#2), regenerate output (#6), landing/responsive visual (#12).

---

## 3. Supabase & security checks

**Database (Management API):**
- Tables: `public.profiles`, `public.meetings` — present.
- `profiles` columns: `id, name, company, max_minutes, retention_days,
  default_prompt, ai_model, created_at` — includes the Phase-8 `ai_model`.
- RLS: **enabled** on both tables.
- Policies: `own meetings` (ALL), `own profile` (ALL).
- Indexes: `meetings_pkey`, `meetings_user_id_created_at_idx` (the §6 index).
- pg_cron: job `purge-expired-meetings`, schedule `0 * * * *`, command
  `delete from public.meetings where expires_at < now();`.
- Expired filter: insert one active + one expired row → list returns the
  active, hides the expired. **Confirmed.**
- Admin user `admin@eia.local` — sign-in **OK**.

**Edge Functions (deployed + JWT-gated):**
- `transcribe`, `summarize`, `set-gemini-key` — all return **HTTP 401** on an
  unauthenticated POST (gate works before any Gemini call).
- Server secrets present: `GEMINI_MODEL`, `GEMINI_API_KEY`, `MGMT_ACCESS_TOKEN`
  (plus Supabase-managed ones). None are `VITE_`-prefixed.

**Secrets hygiene:**
- Tracked repo: only `.env.example` (placeholders). No `service_role`, access
  token, or Gemini key in any committed file.
- `dist/` bundle: no `service_role` / `GEMINI_API_KEY` / `MGMT_ACCESS_TOKEN` /
  PAT. (The public `anon` key is present in the bundle — expected and safe.)
- `.env.local` is gitignored and untracked.

**Settings / wiring (static):**
- Settings persists `ai_model, max_minutes, retention_days, default_prompt,
  company` to `profiles`; round-trip verified earlier.
- Recorder reads `max_minutes` (cap), `retention_days` (→ `expires_at` on
  insert), `default_prompt` (→ initial summary instruction), `ai_model`
  (→ passed to both functions).
- `transcribe`/`summarize` accept an optional `model`, **allowlisted** to the
  three spec models, falling back to the `GEMINI_MODEL` secret otherwise.
- `set-gemini-key` is JWT- + admin-email-gated and writes the `GEMINI_API_KEY`
  secret via the Management API; Settings field is write-only ("key configured"
  status only).

---

## 4. Done vs Missing vs Bugs

### Done (Phases 1–10)
- **P1 Scaffold** — Vite + React + TS + Tailwind v4, §8 tokens/fonts, routing.
- **P2 Supabase** — schema, RLS, pg_cron purge; auth wired (single fixed admin).
- **P3 Recording core** — MediaRecorder wrapper, ring, timer, pause/resume,
  auto-stop, mic-permission handling; no live STT.
- **P4 Transcription** — `transcribe` function (inline + Files API), JWT-gated.
- **P5 Summary** — `summarize` function, §3 worker-facing prompt, TITLE parsing.
- **P6 Summary UI** — editable card + auto-save, prominent Copy, Email/WhatsApp/
  PDF/.txt, Regenerate + presets.
- **P7 Saved meetings** — now a dedicated **History** page (search, card grid,
  viewer modal, delete, expired filter).
- **P8 Settings** — all fields persisted to `profiles` + per-user Gemini key.
- **P9 Polish** — transcript fallback (copy / copy+prompt), Spacebar shortcut,
  responsive, reduced-motion, friendly empty/error states.
- **P10 Wiring** — model-from-profile end-to-end; secure `set-gemini-key`.
- **Extra (post-plan UX):** separate `/history` route, 3-tab nav, centered
  portal modal, 2-column result layout, auto-growing textareas.

### Missing / partial / intentional deviations
- **Auth model changed by request:** public sign-up / magic link (PLAN §6) was
  replaced by a single fixed admin login; the `profiles` row is created on
  first login rather than sign-up. (Intentional.)
- **Component map:** PLAN §9 lists `MeetingList.tsx`; replaced by the History
  page card grid (`MeetingList` removed). Structural deviation, no feature loss.
- **Live Web Speech captions** (optional nicety in §2) — intentionally omitted.
- **Long-audio chunking** (§2 "if very long, chunk into ≤10-min segments") —
  **partial**: large files use the Files API in one shot; there is no segment
  chunking/concatenation. Fine for typical ≤30-min talks; very long/edge cases
  rely on the model handling the whole file.

### Bugs / dead code
- **None blocking.** Build is clean under `noUnusedLocals`/`noUnusedParameters`;
  no dangling references to the removed `MeetingList`.
- Minor: `pickMimeType` is exported from `recorder.ts` but only used internally
  (harmless). Not a defect.

---

## 5. Known limitations
- **Gemini free-tier quota** is the main operational risk: the daily request cap
  is low and repeated use hits HTTP 429. The app degrades gracefully (clear
  "rate-limited / enable billing" message + always-available transcript and a
  "Copy transcript + summary prompt" fallback), but reliable production use needs
  billing enabled on the key.
- **`gemini-3.5-flash`** is offered in the Settings dropdown per spec; if Google
  does not expose that exact model name, selecting it will return an API error.
- **`MGMT_ACCESS_TOKEN`** (a Supabase Personal Access Token) is stored as an Edge
  Function secret so `set-gemini-key` can write the project secret. It is
  admin-invocation-only and never sent to the browser, but it is a
  project-management-capable credential held server-side.

---

## 6. Recommendations (prioritized)
1. **Enable billing on the Gemini API key** (or keep `gemini-2.5-flash-lite`)
   before real use — removes the 429 quota wall. _(High)_
2. **Run the 4 remaining manual browser tests:** 3–5 min every-word capture,
   Urdu→Roman Urdu, regenerate-with-instruction, and landing/mobile visual.
   _(High)_
3. **Confirm or prune `gemini-3.5-flash`** in the Settings dropdown — verify the
   model name resolves, otherwise remove it to avoid a confusing failure. _(Med)_
4. **(Optional) Long-audio chunking** per §2 for very long recordings, if such
   talks are expected. _(Low)_
5. **(Optional, hygiene) Rotate the Supabase PAT** periodically and document that
   it backs `set-gemini-key`; consider a narrower-scoped token if available.
   _(Low)_
6. **(Optional) Remove the unused `pickMimeType` export** or leave as-is —
   negligible. _(Low)_

---

_Overall: the app implements Phases 1–10 of PLAN.md and passes all
non-AI-dependent acceptance items. The AI summary path was confirmed with the
single permitted Gemini call; the remaining AI/visual items are logic-verified
and await manual browser confirmation. No blocking bugs or secret leaks found._
