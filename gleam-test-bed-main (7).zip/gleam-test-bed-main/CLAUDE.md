# EIA Recap — working notes for Claude Code

## Standing workflow rule (follow on EVERY task, without being asked)
1. **Start** with `git pull origin main` to sync with GitHub.
2. Do the work.
3. **End** with a commit and `git push origin main` — `main` auto-deploys to Vercel.

Pull first to avoid diverging from remote; push at the end so changes go live.
Edge Function changes also require `npx supabase functions deploy <name>` — a git
push alone does NOT deploy Supabase functions.

## Project rules
- **All app UI copy is English.** The only exception is generated summary CONTENT,
  which may be Roman Urdu (never Nastaliq) when the meeting was spoken in Urdu.
- **Never commit secrets.** `.env.local` (Supabase service_role, access token, Gemini
  key) is gitignored. Verify nothing secret is staged before committing.
- Gemini runs **server-side only**, inside Supabase Edge Functions. The browser never
  sees `GEMINI_API_KEY`.
- **Do NOT make live Gemini test calls** (the free daily quota is limited). Verify with
  `npm run build` and DB checks; the user tests AI paths in the browser.

## Project facts
- Stack: Vite + React + TS + Tailwind v4; Supabase (Postgres + Auth + Edge Functions
  + pg_cron). AI engine: **Groq primary, Gemini fallback** (both inside the existing
  `transcribe` / `summarize` Edge Functions — Path A, no separate backend).
  - transcribe → Groq `whisper-large-v3-turbo`; summarize → Groq `llama-3.3-70b-versatile`.
  - On a Groq 429/quota (or other failure), each function auto-falls back to Gemini.
  - Whisper returns Urdu in native script, so the transcribe function transliterates
    to Roman Urdu (best-effort) when Arabic script is detected.
- Supabase project ref: `jhbguzknzatpseinapbj`.
- Single fixed login: username `admin` → mapped to `admin@eia.local`.
- Secrets: `GROQ_API_KEY` (primary), `GEMINI_API_KEY` (fallback), `GEMINI_MODEL`
  (fallback model, currently `gemini-2.5-flash-lite`). The Settings `ai_model`
  dropdown now selects the **Gemini fallback** model. Functions read secrets at
  runtime, so changing them needs no redeploy.
- Helper scripts: `npm run setup:supabase`, `npm run test:transcribe -- <file>`.

See `PLAN.md` for the full product spec and build phases.
