# EIA Recap — Build Plan (React + Supabase)

> **For:** Claude Code
> **Company:** EIA — Intuitive Expert Advisor Inc.
> **Product:** A meeting recorder that turns a spoken briefing into a clean, shareable task summary that a manager sends to a worker.

This document is the complete spec. Build the app exactly to this. If a build detail is unclear, ask one plain how-to-build question.

---

## 1. What the app does (in one line)

A manager presses **Record**, speaks/explains a task or meeting, presses **Stop**, and the app produces an **AI summary written for the worker** — what to do, the details, deadlines, and anything said only once — which the manager can **copy / download / send**.

---

## 2. ⚠️ CRITICAL LESSON FROM THE PROTOTYPE — read first

The HTML prototype used the browser's live `webkitSpeechRecognition`. **It captured only the first ~7 words and then stopped hearing anything.** This must NOT happen again. Every single word must be captured.

### Why it failed
The Web Speech API is unreliable for continuous capture: it stops on short silences, dies after brief network hiccups, has hidden time limits, and the `onend → restart` trick silently drops audio (and often dies completely). It is fine as a toy caption, **never** as the source of truth.

### The fix (mandatory architecture)
**Do NOT use the live Web Speech API for the real transcript.** Instead:

1. **Record the actual audio** for the whole meeting using `MediaRecorder` (mic → compressed `audio/webm;codecs=opus`).
2. On **Stop**, send the complete audio to **Gemini** for transcription (Gemini understands audio natively and handles Urdu + English).
3. Use that full transcript to generate the summary.

This guarantees nothing is missed, because the entire audio is transcribed after the fact, not depended on live.

- Audio handling: short clips (≤ ~18 MB) can go inline (base64); for longer recordings use the **Gemini Files API** (upload, then reference the file URI in `generateContent`). If a recording is very long, chunk audio into ≤10-minute segments, transcribe each, then concatenate.
- **Privacy/retention:** Do **not** store the audio anywhere. Transcribe in a temp flow, then discard the audio. Only the transcript + summary are saved.
- Optional nicety: show live Web Speech captions **only** as on-screen feedback while recording, clearly not the real output. Keep it off if it adds risk.

> Acceptance test: record a continuous 3–5 minute talk with natural pauses → the transcript must contain the entire talk, not just the opening sentence.

---

## 3. The summary — worker-facing, single speaker, NO speaker labels

The earlier 2-speaker detection is **removed**. Assume the normal case: **one person (the manager) is talking and assigning work**, and the result is sent to the worker. Write the summary **as if speaking to the worker.**

- **Do NOT** mention "Speaker 1/2", "~1 speaker", or any speaker detection anywhere.
- Frame everything as a clear brief the worker receives.

### Default summary structure (bullet points)
```
What you need to do        → the tasks/instructions (this is the most important section)
Key points / context       → why, background, anything explaining the task
Details to remember        → numbers, names, dates, links, references
Deadlines                  → if any time/date was mentioned
Don't forget (said once)   → things mentioned only a single time, easy to forget
```
Keep it concise but complete. Use `•` bullets. No preamble, no closing remarks.

### Language rules (keep exactly)
- Write in clear **English**.
- If the talk was clearly in **Urdu**, write the summary in **Roman Urdu** (Urdu in English letters, e.g. `kal tak report bhej dena`).
- **NEVER** use Urdu/Arabic (Nastaliq) script. Everything English letters, left-to-right.

### Title
The AI also returns a short 3–6 word title (e.g. "Website redesign tasks"). First line `TITLE: ...`, parse it out; fallback to date-based title.

---

## 4. Feature list (carry over from prototype + improvements)

- **Landing / sign-in page** that looks like a beautiful home page (not a login form). EIA branding, hero, CTA.
- **Recorder:** one big Record button, **30-min auto-stop** + circular countdown ring, **Pause / Resume**, mic level/feedback while recording.
- **AI summary** as specified in §3 (worker-facing, Gemini).
- **Copy button** — the most prominent action (primary color, large).
- **Editable summary** — user can edit before sending; edits auto-save.
- **Regenerate with AI** — an input box: empty = default bullets; typed instruction (e.g. "as a detailed paragraph", "remove personal details", "tasks only", "shorter", "formal English") → regenerates accordingly. Include quick-preset chips.
- **Download** — PDF and .txt.
- **Send** — Email (`mailto:`) and WhatsApp (`wa.me`).
- **Saved meetings** — list with search, duration, word count; click opens a viewer; delete option.
- **3-day auto-delete** — server-side (see §6) + never show expired.
- **Settings** — see §7. All defaults stay as specified.
- **Spacebar shortcut** to start/stop on the record screen.

---

## 5. Tech stack

- **Frontend:** React + TypeScript (Vite).
- **Styling:** Tailwind CSS (with the design tokens in §8). Fonts via Google Fonts.
- **Backend / DB / Auth:** Supabase (Postgres + Auth + Edge Functions + pg_cron).
- **AI:** Google Gemini (`gemini-2.5-flash` default) for BOTH audio transcription and summary — called **only from a Supabase Edge Function** so the Gemini key stays server-side.
- **Audio:** browser `MediaRecorder`.
- **Exports:** `jspdf` for PDF; Blob for .txt.

> Note: Gemini `gemini-2.0-flash` is retired — use `gemini-2.5-flash` (default), `gemini-2.5-flash-lite`, or `gemini-3.5-flash`. Make the model name an env/config value so it's easy to change later.

---

## 6. Supabase — database, security, retention

### Auth
Supabase Auth, email + password (or magic link). The landing page doubles as sign-in/sign-up. On first sign-up, create a `profiles` row.

### Schema (SQL)
```sql
-- PROFILES
create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  name text,
  company text default 'EIA — Intuitive Expert Advisor Inc.',
  max_minutes int default 30,
  retention_days int default 3,
  default_prompt text default '',
  created_at timestamptz default now()
);

-- MEETINGS (no audio stored)
create table public.meetings (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  title text not null,
  summary text not null,
  transcript text,
  duration_sec int default 0,
  word_count int default 0,
  created_at timestamptz default now(),
  expires_at timestamptz not null default (now() + interval '3 days')
);
create index on public.meetings (user_id, created_at desc);

-- RLS
alter table public.profiles enable row level security;
alter table public.meetings enable row level security;

create policy "own profile"
  on public.profiles for all
  using (auth.uid() = id) with check (auth.uid() = id);

create policy "own meetings"
  on public.meetings for all
  using (auth.uid() = user_id) with check (auth.uid() = user_id);
```

### 3-day hard delete (pg_cron)
Enable `pg_cron` (Supabase → Database → Extensions), then:
```sql
select cron.schedule(
  'purge-expired-meetings',
  '0 * * * *',                       -- hourly
  $$ delete from public.meetings where expires_at < now(); $$
);
```
- On insert, set `expires_at = now() + (profile.retention_days || ' days')::interval`.
- Frontend should also filter `expires_at > now()` so nothing expired is ever shown between purges.

### Edge Functions (Deno) — Gemini stays server-side
Create functions that hold `GEMINI_API_KEY` as a secret (`supabase secrets set GEMINI_API_KEY=...`):

1. **`transcribe`** — input: audio (uploaded). Calls Gemini with the audio → returns `{ transcript }`.
2. **`summarize`** — input: `{ transcript, instruction? }`. Calls Gemini with the prompt in §3 → returns `{ title, summary }` (instruction overrides default format; default uses §3 structure).

Both verify the Supabase JWT (user must be logged in). Endpoint pattern:
`POST https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent?key=GEMINI_API_KEY`
body `{"contents":[{"parts":[{"text": "..."}, {"inline_data"/"file_data": ...audio...}]}]}`
read `data.candidates[0].content.parts[*].text`.

> The prototype put the Gemini key in a browser settings box. For the hosted app, **default to the server-side key** (Edge Function). Optionally still allow a per-user key in Settings as a fallback, but the recommended path is the Edge Function secret.

---

## 7. Settings (page)

All defaults stay exactly as below; user can change:
- **AI model** — default `gemini-2.5-flash` (dropdown with the 3 options in §5).
- **Max recording (minutes)** — default `30`.
- **Retention (days)** — default `3`.
- **Default summary instruction** — default empty (= standard bullets).
- **Company name** — default `EIA — Intuitive Expert Advisor Inc.`.
- (If using per-user key fallback) **Gemini API key** input.

Persist to `profiles`. Changing `max_minutes`/`retention_days` updates the recorder cap and future `expires_at`.

---

## 8. Design system (refine and polish the prototype look)

Keep the calm, premium "expert advisory" feel. Refinements requested — tighten spacing, smoother motion, more polish.

**Palette**
```
--paper   #F3F1EA   (warm background)
--surface #FFFFFF
--ink     #15172A   (near-black navy text)
--ink-2   #2A2D45
--muted   #6B6F82
--line    #E5E2D9   (borders)
--accent  #4F46E5   (indigo — primary actions)
--accent-2#7C74FF
--accent-soft #ECEBFB
--rec     #E5484D   (recording red)
--amber   #C77D1A   (paused)
--good    #2F9E66
radius: 24px cards · soft layered shadows
```

**Typography**
- Display / headings / logo: **Fraunces** (serif, characterful).
- Body / UI: **Hanken Grotesk**.
- Timer / numbers: **Spline Sans Mono**.
- (No Nastaliq font needed — output is always Latin.)

**Brand**
- Monogram badge "EIA" (rounded square, ink bg, white serif).
- Wordmark: **EIA** + "Intuitive Expert Advisor Inc." subtitle.

**Landing page**
- Hero headline (Fraunces, large): emphasize the core promise — *"Never lose what was said only once."*
- Sub-line about turning a briefing into a worker-ready task summary.
- Subtle background: dotted grid + soft indigo radial glows. NOT a generic purple-gradient-on-white.
- Elegant sign-in card on the right (name/email, "Get Started" CTA). Feels like a product home, not a login form.

**Recorder**
- Big circular button (idle indigo → recording red w/ pulse → paused amber).
- SVG progress ring around it counts down to the max time.
- Mono timer `MM:SS / 30:00`.
- Pause/Resume pill appears only during a session.

**Design polish checklist (improve over prototype)**
- Consistent 8px spacing scale; generous whitespace.
- Staggered page-load reveal on landing (animation-delay).
- Hover micro-interactions on buttons/cards (subtle lift).
- Focus states with accent-soft ring on all inputs.
- Mobile: single column, big tap targets, recorder centered.
- Smooth view transitions (record ⇄ settings).
- Empty states with friendly copy.

---

## 9. Project structure

```
eia-recap/
├─ src/
│  ├─ main.tsx
│  ├─ App.tsx
│  ├─ lib/
│  │  ├─ supabase.ts          # client init
│  │  ├─ recorder.ts          # MediaRecorder wrapper (start/pause/resume/stop → Blob)
│  │  ├─ ai.ts                # calls Edge Functions: transcribe(), summarize()
│  │  └─ exports.ts           # pdf / txt / mailto / whatsapp / clipboard
│  ├─ context/
│  │  └─ AuthContext.tsx
│  ├─ pages/
│  │  ├─ Landing.tsx
│  │  ├─ Recorder.tsx
│  │  └─ Settings.tsx
│  ├─ components/
│  │  ├─ RecordButton.tsx
│  │  ├─ ProgressRing.tsx
│  │  ├─ SummaryCard.tsx      # editable textarea + actions + regenerate
│  │  ├─ MeetingList.tsx      # search + items
│  │  └─ MeetingModal.tsx
│  └─ styles/ (tailwind + tokens)
├─ supabase/
│  ├─ migrations/             # the SQL from §6
│  └─ functions/
│     ├─ transcribe/index.ts
│     └─ summarize/index.ts
├─ .env.local
└─ package.json
```

---

## 10. Environment variables

`.env.local` (frontend):
```
VITE_SUPABASE_URL=...
VITE_SUPABASE_ANON_KEY=...
```
Supabase Edge Function secrets (server):
```
GEMINI_API_KEY=...
GEMINI_MODEL=gemini-2.5-flash
```

---

## 11. Build phases / milestones

1. **Scaffold** — Vite + React + TS + Tailwind; design tokens & fonts; routing (Landing / Recorder / Settings).
2. **Supabase** — project, schema migration, RLS, Auth wired into the landing page, pg_cron purge job.
3. **Recording core** — MediaRecorder wrapper with start/pause/resume/stop; 30-min cap; ring + timer. (No live STT dependency.)
4. **Transcription** — `transcribe` Edge Function → Gemini audio → full transcript. **Verify the every-word fix (see §2 acceptance test).**
5. **Summary** — `summarize` Edge Function with the §3 worker-facing prompt + title parsing.
6. **Summary UI** — editable card, prominent Copy, Email/WhatsApp/PDF/.txt, Regenerate box + presets.
7. **Saved meetings** — list, search, duration/word-count, modal, delete; expired filter.
8. **Settings** — all fields in §7 persisted to profiles.
9. **Polish** — design refinements (§8), mobile, animations, empty/error states, spacebar shortcut.
10. **QA** — full acceptance checklist (§13).

---

## 12. How to start with Claude Code

```bash
# 1. create the project folder, put this PLAN.md inside it
mkdir eia-recap && cd eia-recap
# (copy PLAN.md here)

# 2. start Claude Code in that folder
claude

# 3. first message to Claude Code:
#    "Read PLAN.md and scaffold the project (Phase 1). Then stop and show me."
```
Then go phase by phase. Have your Supabase project + Gemini API key ready before Phase 2/4.

---

## 13. Acceptance checklist

- [ ] **Every word captured:** 3–5 min continuous talk → full transcript, not just the start. (The #1 requirement.)
- [ ] Urdu speech → summary in clean **Roman Urdu**, never Nastaliq.
- [ ] Summary is **worker-facing**; no speaker labels anywhere.
- [ ] 30-min auto-stop + countdown ring works; Pause/Resume keeps time correctly.
- [ ] Copy is the most prominent action and copies the (edited) summary.
- [ ] Regenerate with a custom instruction changes the output accordingly.
- [ ] PDF + .txt download; Email + WhatsApp open prefilled.
- [ ] Saved list: search, duration, word count, open, delete.
- [ ] Records hard-delete after the retention period (pg_cron); expired never shown.
- [ ] RLS: a user can only ever see their own meetings.
- [ ] Gemini key is server-side (Edge Function), not in the browser bundle.
- [ ] Landing page looks like a polished home page; responsive on mobile.

---

*End of plan.*
