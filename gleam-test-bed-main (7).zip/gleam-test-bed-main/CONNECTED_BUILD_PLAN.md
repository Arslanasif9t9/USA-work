# CONNECTED BUILD PLAN — PMS + EIA Recap (Meeting Intelligence)

> Single source of truth for the current build track. This file goes to BOTH
> Claude Code projects so each one has the full picture. Project-specific detail
> lives in `PMS_FEATURE_PLAN.md` (PMS repo) and `MEETING_INTEGRATION_PLAN.md`
> (Meeting repo). Where this file conflicts with older notes, THIS WINS.
>
> STATUS: planning locked. No build started yet. Build runs phase-by-phase,
> one prompt at a time, each prompt clearly labelled with which session it
> belongs to.

---

## 1. THE TWO APPS (separate repos, separate Supabase projects)

**PMS — "EIA Projects"**
- React + Vite + TypeScript, TanStack Router, Zustand, Tailwind, shadcn, Tiptap, dnd-kit.
- Supabase ref `ddbrsoofnntzqvbtpqyc`. GitHub `astrolume22/pms`. Vercel.
- Live: https://projects.expertintuitiveadvisor.com
- Core tables: account, users, workspaces, workspace_members, boards,
  board_subscribers, groups, columns, column_labels, board_counters, items,
  item_column_values, item_subscribers, updates, files, notifications,
  activity_log.
- Migrations currently in repo: up to `20260530_0054`.
- Existing bridge endpoints already built FOR the EIA ecosystem:
  - `api/list-groups.ts` — read-only, returns groups on the Tessera board,
    auth header `x-eia-key: <EIA_BRIDGE_KEY>`, CORS allow-list.
  - `api/mcp.ts` — full write API incl. `create_task` / `bulk_create_tasks`,
    auth `Authorization: Bearer <MCP_BEARER>` OR `?token=<MCP_BEARER>`.
  - Tessera board id (hard-pinned in list-groups): `28472783-6d7a-4de9-8834-2354f62856c5`.

**EIA Recap — "Meeting Intelligence"**
- React + Vite + TypeScript, React Router (NOT TanStack), Tailwind.
- Supabase ref `jhbguzknzatpseinapbj`. GitHub `astrolume22/meeting_inteligence`. Vercel.
- Live: https://meeting-inteligence.vercel.app
- Single fixed admin login (username "admin" -> admin@eia.local).
- AI: Groq primary (whisper-large-v3-turbo transcribe, llama-3.3-70b summary),
  Gemini fallback. Output is `{ title, summary }` — worker-facing bullets.
- Tables: profiles, meetings. No audio stored. 3-day auto-delete.

**"Connect" means:** the two apps stay separate. They talk over HTTP. PMS already
exposes the pipe (`list-groups` + `create_task` via the `x-eia-key` / MCP bridge).
There is NO database merge.

---

## 2. THE 9 FEATURES (locked spec)

1. **Login screen** — PMS app entry. ALREADY EXISTS (`src/routes/_bare.login.tsx`).
   Confirm only.
2. **Add Group button** — a "+ Add Group" button placed next to the "New Task"
   button; click creates a group inline. NOTE: an inline "Add new group" control
   already exists (`AddGroupRow.tsx`). This is placement + label, not net-new.
3. **Add Task via last-row plus** — the "+" on the bottom row of each group must
   create a task when pressed (currently it only creates after typing a name +
   Enter). Make the press itself create a blank "Task N" row reliably.
   (`AddItemRow.tsx`).
4. **Per-group access (visibility ACL)** — each group is access-separated. A user
   granted only "Marketing" sees only Marketing. A user can be granted multiple
   groups. Only admin / master_admin assigns access. **Applies to ALL boards,
   including Tessera** (owner choice).
5. **Send call-notes -> a group as a task** — EIA Recap gets a "Send to group"
   action: user picks a group on the Tessera board; the summary is inserted there
   as a NEW task whose body shows the call notes/summary. Uses the existing PMS
   bridge.
6. **Shift "Log In" button + 8-hour countdown** — inside a group, a "Log In"
   button at the top, SEPARATE from app login. Until pressed, the user sees
   NOTHING in the group. One tap (no username/password) logs them in and starts
   an 8-hour countdown (8:00:00 -> 0). Runs Mon–Sat. Fresh 8h countdown each
   workday, auto-reset at start of day.
7. **Timer lock — master_admin control** — master_admin can lock/unlock a user.
   On lock, the user sees a popup: "Please contact admin to discuss your job."
   Locked = blocked until unlocked.
8. **Auto-lock on INACTIVITY** — (final interpretation) if a logged-in user makes
   NO change at all (no status change, no cell edit, nothing moves on the board)
   for a set window, they auto-lock with the same popup as #7. Any real activity
   resets the inactivity timer. This is NOT a per-task "allotted time" limit and
   there is NO new "Allotted Time" column.
9. **Play again / restart** — master_admin can re-arm a user's 8-hour timer fresh.
   It only resets the timer; it does NOT touch the user's tasks/work.

---

## 3. LOCKED DECISIONS (do not relitigate)

- **Per-group isolation scope:** ALL boards including Tessera (owner picked "B").
  Tessera managers will now see only their granted group(s).
- **"Disqualify" meaning:** PMS-INTERNAL flag/lock only. No call into the EIA
  hiring app (that is a different app + different Supabase). The lock from #7 is
  reused.
- **Auto-action trigger:** INACTIVITY (no board activity for the window), NOT
  per-task time overrun.
- **Play again:** re-arm the 8h timer only; master_admin triggers it; tasks
  untouched.
- **Call-notes target:** the Tessera board, into a group the user picks.

---

## 4. PHASED BUILD ORDER

- **Phase 1 — Quick wins (PMS).** #2 Add Group placement + #3 last-row "+"
  creates task on press. Small, additive. No dependencies.
- **Phase 2 — #5 Call-notes -> Tessera group task.** Mostly EIA Recap side +
  add the Meeting domain to PMS CORS allow-list. Independent of the shift system.
- **Phase 3 — #4 Per-group access (FOUNDATION).** Read-only verify first whether
  the ACL exists live; extend if present, build fresh if not. This is the base
  for #6/#7/#8/#9. Heaviest / riskiest (RLS).
- **Phase 4 — #6 Shift Log In + 8h countdown.** Needs Phase 3.
- **Phase 5 — #7 Manual lock (master_admin).** Needs Phase 4.
- **Phase 6 — #8 Auto-lock on inactivity.** Needs Phase 4.
- **Phase 7 — #9 Play again.** Needs Phase 4.

---

## 5. OPEN ITEMS (must answer before the dependent phase)

- **Inactivity window for #8:** 2 hours or 3 hours (or other)? TBD. Needed before
  Phase 6 only. Phases 1–5 are unaffected.
- **ACL existence (#4):** the documented `group_user_visibility` table +
  `/settings/group-access` page were NOT found in the current repo snapshot.
  Phase 3 starts with a read-only verify against the live DB/repo before any
  build decision.

---

## 6. STANDING RULES (every prompt, every phase)

- Each prompt is labelled with its target session: **PMS** (`astrolume22/pms`)
  or **Meeting Intelligence** (`astrolume22/meeting_inteligence`).
- PMS prompts OPEN with `git pull origin main` and CLOSE with `git push`.
  (Two computers push to PMS — pull first always.)
- Meeting prompts also open with `git pull` and close with commit + `git push`.
- Diagnose read-only with REAL data first; then fix in the smallest verified
  step. Never one giant prompt. Demand proof (DB row / build output / logs).
- Localhost-first testing. Surface a one-line Vercel-wait status when waiting.
- ON DELETE SET NULL on user FKs, never CASCADE. Single-row writes by id.
  Never touch the `answers`/`items` tables destructively. Soft-deletes only.
- `tsc` + `vite build` clean after every change.
- No emoji in user-facing EIA surfaces. Dark theme default in PMS.
