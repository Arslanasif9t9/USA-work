/**
 * GET /api/list-tasks?group_id=<uuid>
 *
 * Vercel mirror of supabase/functions/list-tasks. Same auth (x-eia-key
 * vs EIA_BRIDGE_KEY), same CORS allow-list, same service-role pattern,
 * same tenancy guard (group must belong to Tessera board). Read-only.
 *
 * Shapes:
 *   200 { ok:true,  tasks:[ { id, name, task_code, details, status } ] }
 *   400 { ok:false, error:"group_id required" }
 *   401 { ok:false, error:"Unauthorized" }
 *   404 { ok:false, error:"Group not found" }
 *   500 { ok:false, error:"<message>" }
 */
import type { VercelRequest, VercelResponse } from '@vercel/node';
import { createClient } from '@supabase/supabase-js';

const TESSERA_BOARD_ID = '28472783-6d7a-4de9-8834-2354f62856c5';

const STATIC_ALLOWED_ORIGINS = new Set<string>([
  'https://jobs.expertintuitiveadvisor.com',
  'https://meeting-inteligence.vercel.app',
  'http://localhost:5173',
  'http://localhost:3000',
]);
const ALLOWED_ORIGIN_SUFFIXES = ['.lovable.app', '.lovable.dev'];

const UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

function isAllowedOrigin(origin: string | undefined): origin is string {
  if (!origin) return false;
  if (STATIC_ALLOWED_ORIGINS.has(origin)) return true;
  try {
    const host = new URL(origin).hostname;
    return ALLOWED_ORIGIN_SUFFIXES.some((suf) => host === suf.slice(1) || host.endsWith(suf));
  } catch {
    return false;
  }
}

function applyCors(req: VercelRequest, res: VercelResponse) {
  const origin = req.headers.origin;
  const originHeader = Array.isArray(origin) ? origin[0] : origin;
  if (isAllowedOrigin(originHeader)) {
    res.setHeader('Access-Control-Allow-Origin', originHeader);
    res.setHeader('Vary', 'Origin');
  }
  res.setHeader('Access-Control-Allow-Methods', 'GET, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, x-eia-key');
  res.setHeader('Access-Control-Max-Age', '600');
}

function constantTimeEquals(a: string, b: string): boolean {
  if (a.length !== b.length) {
    let acc = 1;
    for (let i = 0; i < a.length; i += 1) acc |= a.charCodeAt(i) ^ 0;
    return acc === 0;
  }
  let diff = 0;
  for (let i = 0; i < a.length; i += 1) diff |= a.charCodeAt(i) ^ b.charCodeAt(i);
  return diff === 0;
}

function readText(raw: unknown): string | null {
  if (raw == null) return null;
  if (typeof raw === 'string') {
    try {
      const p = JSON.parse(raw);
      if (p && typeof p === 'object' && 'text' in p) {
        const t = (p as { text?: unknown }).text;
        return typeof t === 'string' && t.length > 0 ? t : null;
      }
    } catch { /* fall through */ }
    return raw.length > 0 ? raw : null;
  }
  if (typeof raw === 'object') {
    const obj = raw as Record<string, unknown>;
    if (typeof obj.value === 'string') {
      try {
        const inner = JSON.parse(obj.value);
        if (inner && typeof inner === 'object' && 'text' in inner) {
          const t = (inner as { text?: unknown }).text;
          return typeof t === 'string' && t.length > 0 ? t : null;
        }
      } catch { /* ignore */ }
    }
    if (typeof obj.text === 'string') return obj.text.length > 0 ? obj.text : null;
  }
  return null;
}

function readLabelId(raw: unknown): string | null {
  if (raw == null) return null;
  if (typeof raw === 'object') {
    const obj = raw as Record<string, unknown>;
    if (typeof obj.label_id === 'string') return obj.label_id;
    if (typeof obj.value === 'string') {
      try {
        const inner = JSON.parse(obj.value);
        if (inner && typeof inner === 'object' && typeof (inner as { label_id?: unknown }).label_id === 'string') {
          return (inner as { label_id: string }).label_id;
        }
      } catch { /* ignore */ }
    }
  }
  return null;
}

function htmlToPlain(html: string): string | null {
  if (!html) return null;
  let s = html.replace(/<\s*br\s*\/?\s*>/gi, '\n');
  s = s.replace(/<\s*\/\s*p\s*>/gi, '\n');
  s = s.replace(/<\s*\/\s*(div|li|h[1-6]|tr)\s*>/gi, '\n');
  s = s.replace(/<[^>]+>/g, '');
  s = s
    .replace(/&nbsp;/gi, ' ')
    .replace(/&amp;/gi, '&')
    .replace(/&lt;/gi, '<')
    .replace(/&gt;/gi, '>')
    .replace(/&#39;/g, "'")
    .replace(/&quot;/gi, '"');
  s = s.replace(/\n{3,}/g, '\n\n').trim();
  return s.length > 0 ? s : null;
}

export default async function handler(req: VercelRequest, res: VercelResponse) {
  applyCors(req, res);

  if (req.method === 'OPTIONS') { res.status(204).end(); return; }
  if (req.method !== 'GET') {
    res.status(405).json({ ok: false, error: 'Only GET is supported on this endpoint' });
    return;
  }

  try {
    const expectedKey = process.env.EIA_BRIDGE_KEY;
    if (!expectedKey) {
      res.status(500).json({ ok: false, error: 'EIA_BRIDGE_KEY not configured on server' });
      return;
    }
    const supabaseUrl = process.env.SUPABASE_URL ?? process.env.VITE_SUPABASE_URL;
    const serviceRoleKey = process.env.SUPABASE_SERVICE_ROLE_KEY;
    if (!supabaseUrl || !serviceRoleKey) {
      res.status(500).json({ ok: false, error: 'SUPABASE_URL / SUPABASE_SERVICE_ROLE_KEY not configured on server' });
      return;
    }

    const raw = req.headers['x-eia-key'];
    const presented = Array.isArray(raw) ? raw[0] : raw;
    if (!presented || !constantTimeEquals(presented, expectedKey)) {
      res.status(401).json({ ok: false, error: 'Unauthorized' });
      return;
    }

    const q = req.query?.group_id;
    const groupId = Array.isArray(q) ? q[0] : q;
    if (!groupId || typeof groupId !== 'string' || !UUID_RE.test(groupId)) {
      res.status(400).json({ ok: false, error: 'group_id required' });
      return;
    }

    const sb = createClient(supabaseUrl, serviceRoleKey, {
      auth: { persistSession: false, autoRefreshToken: false },
    });

    const { data: groupRow, error: groupErr } = await sb
      .from('groups')
      .select('id, board_id, deleted_at')
      .eq('id', groupId)
      .maybeSingle();
    if (groupErr) { res.status(500).json({ ok: false, error: groupErr.message }); return; }
    if (!groupRow || groupRow.board_id !== TESSERA_BOARD_ID || groupRow.deleted_at) {
      res.status(404).json({ ok: false, error: 'Group not found' });
      return;
    }

    const { data: cols, error: colsErr } = await sb
      .from('columns')
      .select('id, column_type, sort_order')
      .eq('board_id', TESSERA_BOARD_ID)
      .is('archived_at', null)
      .order('sort_order', { ascending: true });
    if (colsErr) { res.status(500).json({ ok: false, error: colsErr.message }); return; }
    const textCol   = (cols ?? []).find((c) => c.column_type === 'text')   ?? null;
    const statusCol = (cols ?? []).find((c) => c.column_type === 'status') ?? null;

    const { data: items, error: itemsErr } = await sb
      .from('items')
      .select('id, name, task_code, sort_order')
      .eq('group_id', groupId)
      .is('deleted_at', null)
      .is('archived_at', null)
      .order('sort_order', { ascending: true });
    if (itemsErr) { res.status(500).json({ ok: false, error: itemsErr.message }); return; }
    const itemRows = items ?? [];
    if (itemRows.length === 0) {
      res.status(200).json({ ok: true, tasks: [] });
      return;
    }

    const colIds: string[] = [];
    if (textCol)   colIds.push(textCol.id);
    if (statusCol) colIds.push(statusCol.id);

    const itemIds = itemRows.map((r) => r.id);
    let cellRows: Array<{ item_id: string; column_id: string; value: unknown }> = [];
    if (colIds.length > 0) {
      const { data: cells, error: cellsErr } = await sb
        .from('item_column_values')
        .select('item_id, column_id, value')
        .in('item_id', itemIds)
        .in('column_id', colIds);
      if (cellsErr) { res.status(500).json({ ok: false, error: cellsErr.message }); return; }
      cellRows = cells ?? [];
    }

    let labelsById = new Map<string, string>();
    if (statusCol) {
      const { data: labels, error: labelsErr } = await sb
        .from('column_labels')
        .select('id, name')
        .eq('column_id', statusCol.id);
      if (labelsErr) { res.status(500).json({ ok: false, error: labelsErr.message }); return; }
      labelsById = new Map((labels ?? []).map((l) => [l.id, l.name]));
    }

    const oldestUpdateByItem = new Map<string, string>();
    {
      const { data: updRows, error: updErr } = await sb
        .from('updates')
        .select('item_id, body_html, created_at')
        .in('item_id', itemIds)
        .is('deleted_at', null)
        .order('created_at', { ascending: true });
      if (updErr) { res.status(500).json({ ok: false, error: updErr.message }); return; }
      for (const r of updRows ?? []) {
        if (!oldestUpdateByItem.has(r.item_id) && typeof r.body_html === 'string') {
          oldestUpdateByItem.set(r.item_id, r.body_html);
        }
      }
    }

    const cellsByItem = new Map<string, Map<string, unknown>>();
    for (const c of cellRows) {
      let m = cellsByItem.get(c.item_id);
      if (!m) { m = new Map(); cellsByItem.set(c.item_id, m); }
      m.set(c.column_id, c.value);
    }

    const tasks = itemRows.map((it) => {
      const m = cellsByItem.get(it.id);
      let details: string | null = textCol && m ? readText(m.get(textCol.id)) : null;
      if (!details) {
        const html = oldestUpdateByItem.get(it.id);
        if (html) details = htmlToPlain(html);
      }
      let status: string | null = null;
      if (statusCol && m) {
        const lbl = readLabelId(m.get(statusCol.id));
        if (lbl) status = labelsById.get(lbl) ?? null;
      }
      return { id: it.id, name: it.name, task_code: it.task_code, details, status };
    });

    res.status(200).json({ ok: true, tasks });
  } catch (e) {
    const message = e instanceof Error ? `${e.name}: ${e.message}` : String(e);
    console.error('[list-tasks] handler threw:', e);
    res.status(500).json({ ok: false, error: message });
  }
}
