/**
 * POST /api/ai-weekly-report — Phase 8b
 *
 * Mirrors supabase/functions/ai-weekly-report/index.ts so the Vercel
 * deploy (p-m-system.vercel.app) keeps working alongside Lovable Cloud.
 * Admin-only. Returns { summary, totals, days } — plain prose, no
 * board actions.
 */
import type { VercelRequest, VercelResponse } from '@vercel/node';
import { createClient } from '@supabase/supabase-js';

const GEMINI_MODEL = 'gemini-2.5-flash';

interface DayRow {
  work_date: string;
  status: string;
  started_at: string | null;
  completed_at: string | null;
  late_start_flag: boolean;
  late_start_minutes: number;
  early_end_flag: boolean;
  early_end_minutes: number;
  bio_break_count_today: number;
  shift_break_count_today: number;
  overstay_lock_email_sent_at: string | null;
  locked_reason: string | null;
}

function dayKind(r: DayRow): 'good' | 'bad' | 'neutral' {
  if (r.status === 'not_started' || r.started_at == null) return 'neutral';
  const overstay = r.overstay_lock_email_sent_at != null || r.locked_reason === 'break_overstay';
  if (overstay || r.bio_break_count_today >= 4) return 'bad';
  return 'good';
}

function addDaysISO(iso: string, n: number): string {
  const d = new Date(iso + 'T00:00:00Z');
  d.setUTCDate(d.getUTCDate() + n);
  return d.toISOString().slice(0, 10);
}

function weekdayLabel(iso: string): string {
  const d = new Date(iso + 'T00:00:00Z');
  return d.toLocaleDateString('en-US', { weekday: 'short', month: 'short', day: 'numeric', timeZone: 'UTC' });
}

async function callGeminiProse(args: { apiKey: string; systemPrompt: string; userPrompt: string }): Promise<
  { ok: true; text: string } | { ok: false; error: string }
> {
  const url = `https://generativelanguage.googleapis.com/v1beta/models/${GEMINI_MODEL}:generateContent?key=${encodeURIComponent(args.apiKey)}`;
  const body = {
    system_instruction: { parts: [{ text: args.systemPrompt }] },
    contents: [{ role: 'user', parts: [{ text: args.userPrompt }] }],
    generationConfig: { temperature: 0.3, maxOutputTokens: 800 },
  };
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 25_000);
  let resp: Response;
  try {
    resp = await fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body),
      signal: controller.signal,
    });
  } catch (err) {
    clearTimeout(timer);
    const aborted = err instanceof Error && err.name === 'AbortError';
    return { ok: false, error: aborted ? 'gemini timed out after 25s' : `network: ${err instanceof Error ? err.message : String(err)}` };
  }
  clearTimeout(timer);
  const raw = await resp.text();
  if (!resp.ok) return { ok: false, error: `gemini http ${resp.status}: ${raw.slice(0, 400)}` };
  let parsed: unknown;
  try { parsed = JSON.parse(raw); } catch { return { ok: false, error: 'gemini returned non-JSON envelope' }; }
  const text = (parsed as { candidates?: { content?: { parts?: { text?: string }[] } }[] })
    .candidates?.[0]?.content?.parts?.[0]?.text;
  if (!text) return { ok: false, error: 'gemini envelope had no text part' };
  return { ok: true, text: text.trim() };
}

export default async function handler(req: VercelRequest, res: VercelResponse) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  if (req.method === 'OPTIONS') { res.status(204).end(); return; }
  if (req.method !== 'POST') { res.status(405).json({ error: 'method not allowed' }); return; }

  try {
    const apiKey = process.env.GEMINI_API_KEY;
    const supabaseUrl = process.env.SUPABASE_URL ?? process.env.VITE_SUPABASE_URL;
    const supabaseAnonKey = process.env.SUPABASE_ANON_KEY ?? process.env.VITE_SUPABASE_ANON_KEY;
    if (!apiKey) { res.status(500).json({ error: 'GEMINI_API_KEY not configured on server' }); return; }
    if (!supabaseUrl || !supabaseAnonKey) {
      res.status(500).json({ error: 'SUPABASE_URL / SUPABASE_ANON_KEY not configured on server' });
      return;
    }

    const authHeader = req.headers.authorization ?? '';
    const jwt = authHeader.startsWith('Bearer ') ? authHeader.slice(7) : '';
    if (!jwt) { res.status(401).json({ error: 'missing Authorization: Bearer <token>' }); return; }

    const sb = createClient(supabaseUrl, supabaseAnonKey, {
      auth: { persistSession: false, autoRefreshToken: false },
      global: { headers: { Authorization: `Bearer ${jwt}` } },
    });

    const { data: userResp, error: userErr } = await sb.auth.getUser(jwt);
    if (userErr || !userResp?.user) { res.status(401).json({ error: 'invalid session token' }); return; }
    const callerId = userResp.user.id;
    const { data: profile, error: profileErr } = await sb
      .from('users')
      .select('id, role, is_super_admin, status')
      .eq('id', callerId)
      .maybeSingle();
    if (profileErr || !profile) { res.status(403).json({ error: 'no profile row for this user' }); return; }
    const isAdmin = profile.role === 'admin' || profile.is_super_admin === true;
    if (!isAdmin) { res.status(403).json({ error: 'admin role required' }); return; }
    if (profile.status !== 'active') { res.status(403).json({ error: 'account deactivated' }); return; }

    let body: Record<string, unknown>;
    if (req.body == null) { res.status(400).json({ error: 'request body is required' }); return; }
    if (typeof req.body === 'string') {
      try { body = JSON.parse(req.body) as Record<string, unknown>; }
      catch (e) { res.status(400).json({ error: `request body is not valid JSON: ${e instanceof Error ? e.message : String(e)}` }); return; }
    } else if (typeof req.body === 'object') {
      body = req.body as Record<string, unknown>;
    } else {
      res.status(400).json({ error: `unexpected request body type: ${typeof req.body}` }); return;
    }

    const targetUserId = typeof body.user_id === 'string' ? body.user_id : '';
    const weekStart = typeof body.week_start === 'string' ? body.week_start : '';
    if (!/^[0-9a-f-]{36}$/i.test(targetUserId)) { res.status(400).json({ error: 'user_id is required (uuid)' }); return; }
    if (!/^\d{4}-\d{2}-\d{2}$/.test(weekStart)) { res.status(400).json({ error: 'week_start must be YYYY-MM-DD' }); return; }
    const weekEnd = addDaysISO(weekStart, 6);

    const { data: target } = await sb
      .from('users')
      .select('id, full_name, username, email')
      .eq('id', targetUserId)
      .maybeSingle();
    if (!target) { res.status(404).json({ error: 'employee not found' }); return; }

    const { data: rowsRaw, error: rowsErr } = await sb
      .from('shift_sessions')
      .select('work_date, status, started_at, completed_at, late_start_flag, late_start_minutes, early_end_flag, early_end_minutes, bio_break_count_today, shift_break_count_today, overstay_lock_email_sent_at, locked_reason')
      .eq('user_id', targetUserId)
      .gte('work_date', weekStart)
      .lte('work_date', weekEnd)
      .order('work_date', { ascending: true });
    if (rowsErr) { res.status(500).json({ error: `db error: ${rowsErr.message}` }); return; }
    const rows = (rowsRaw ?? []) as unknown as DayRow[];

    const byDate = new Map<string, DayRow>();
    for (const r of rows) byDate.set(r.work_date, r);
    const days: { date: string; label: string; kind: string; bio: number; lunch: number; late?: number; early?: number; overstay: boolean; status: string }[] = [];
    for (let i = 0; i < 7; i++) {
      const iso = addDaysISO(weekStart, i);
      const r = byDate.get(iso);
      if (!r) {
        days.push({ date: iso, label: weekdayLabel(iso), kind: 'no_shift', bio: 0, lunch: 0, overstay: false, status: 'no_shift' });
        continue;
      }
      days.push({
        date: iso,
        label: weekdayLabel(iso),
        kind: dayKind(r),
        bio: r.bio_break_count_today ?? 0,
        lunch: r.shift_break_count_today ?? 0,
        late: r.late_start_flag ? r.late_start_minutes : undefined,
        early: r.early_end_flag ? r.early_end_minutes : undefined,
        overstay: r.overstay_lock_email_sent_at != null || r.locked_reason === 'break_overstay',
        status: r.status,
      });
    }

    const totals = {
      good: days.filter((d) => d.kind === 'good').length,
      bad: days.filter((d) => d.kind === 'bad').length,
      no_shift: days.filter((d) => d.kind === 'no_shift').length,
      neutral: days.filter((d) => d.kind === 'neutral').length,
      bio_total: days.reduce((s, d) => s + d.bio, 0),
      lunches_taken: days.filter((d) => d.lunch > 0).length,
      overstays: days.filter((d) => d.overstay).length,
      late_days: days.filter((d) => d.late != null).length,
      early_days: days.filter((d) => d.early != null).length,
    };

    const empName = target.full_name || target.username || 'this employee';
    const systemPrompt = [
      "You are an HR-friendly workplace analyst writing a calm, professional weekly summary of one employee's break and shift discipline.",
      "Audience: the employee's manager. Tone: factual, non-harsh, supportive — never punitive or accusatory.",
      'A "good day" means: no lunch overstay AND bio-break count <= 3. A "bad day" means: a lunch overstay OR bio-break count >= 4.',
      'Write 3–6 sentences of plain prose. No bullet lists, no headings, no markdown, no JSON. Reference specific weekdays where helpful.',
      'Mention overall pattern, which days were strong vs over the limit, and a brief calm note on any trend. Do not invent data.',
    ].join(' ');

    const userPrompt = [
      `Employee: ${empName}`,
      `Week: ${weekStart} to ${weekEnd}`,
      `Per-day data (JSON): ${JSON.stringify(days)}`,
      `Totals: ${JSON.stringify(totals)}`,
      'Write the summary now.',
    ].join('\n');

    const result = await callGeminiProse({ apiKey, systemPrompt, userPrompt });
    if (!result.ok) { res.status(502).json({ error: result.error }); return; }

    const { error: logErr } = await sb.from('ai_runs').insert({
      user_id: callerId,
      feature: 'chat',
      prompt: userPrompt.slice(0, 4000),
      model: GEMINI_MODEL,
      status: 'success',
      response: result.text.slice(0, 8000),
      target_type: 'user',
      target_id: targetUserId,
    } as never);
    if (logErr) console.error('[ai-weekly-report] ai_runs insert failed:', logErr);

    res.status(200).json({ summary: result.text, totals, days });
  } catch (err) {
    const message = err instanceof Error ? `${err.name}: ${err.message}` : typeof err === 'string' ? err : 'unknown error';
    console.error('[ai-weekly-report] handler threw:', err);
    res.status(500).json({ error: 'internal: ' + message });
  }
}
