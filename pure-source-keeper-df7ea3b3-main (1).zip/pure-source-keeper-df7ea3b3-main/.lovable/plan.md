
# Step 1 — Boot the app as a plain Vite SPA + wire env vars

Scope is intentionally tiny: make the React app load in preview. No DB migrations, no `api/*` porting, no router/app changes. Zero edits under `src/`.

## What's wrong right now

- Preview returns 500: `Failed to load url virtual:tanstack-start-server-entry (/dev-server/src/server.ts)`.
- The repo is a plain client-side **Vite + TanStack Router** SPA (`vite.config.ts` uses `defineConfig` from `vite` with `@tanstack/router-vite-plugin` + `@vitejs/plugin-react`; entry is `index.html` → `/src/main.tsx`; there is no `src/server.ts` and no SSR).
- The Lovable dev-server harness is treating it as a **TanStack Start** project (likely because `@tanstack/react-start*` resolved into `node_modules`, and the workspace template wrapper `@lovable.dev/vite-tanstack-config` is the default for TanStack projects). That wrapper expects a `src/server.ts` that re-exports `virtual:tanstack-start-server-entry`, which doesn't and shouldn't exist here.
- Even after that's fixed, `src/lib/supabase.ts` throws at boot unless `VITE_SUPABASE_URL` and `VITE_SUPABASE_ANON_KEY` are set.

## Changes (config/env only — ZERO files under `src/`)

### A. Force SPA mode for the preview harness

Goal: make the Lovable preview/dev server use the repo's own `vite.config.ts` exactly as written and stop expecting a TanStack Start server entry. Order of attempts, smallest first; stop at the first one that works.

1. **Add a Lovable project-type marker** in `.lovable/` (e.g. `.lovable/config.json` or equivalent) declaring this project as a plain Vite SPA (`framework: react`, `ssr: false`, no TanStack Start wrapper). This is the cleanest neutralizer — it just tells the harness "use vite.config.ts as-is, serve index.html, no server entry."
2. If the harness still auto-detects TanStack Start from `node_modules/@tanstack/react-start*`, **remove the unused `@tanstack/react-start*` packages** from the dep tree (the app imports only `@tanstack/react-router` and `@tanstack/react-query` — `react-start*` is not imported anywhere in `src/`). This is a `package.json` / lockfile edit only, still zero changes under `src/`.
3. As a last resort, **shim the workspace wrapper config** to a no-op SPA passthrough (config-only file at the repo root, not under `src/`), so even if the harness loads `@lovable.dev/vite-tanstack-config`, it returns the plain `defineConfig` already in `vite.config.ts`.

Before each attempt: run `tsr generate` so `src/routeTree.gen.ts` is fresh (the build script already does this; just making sure the dev server has it too). Then restart the dev server and confirm the 500 is gone.

The repo's own `vite.config.ts`, `package.json` scripts (`"dev": "vite"`, `"build": "tsr generate && tsc -b && vite build"`), `index.html`, `tsr.config.json`, and everything under `src/` are NOT touched.

### B. Provision Lovable Cloud + set the two frontend env vars

1. Enable Lovable Cloud — this provisions a fresh Supabase project for this app (separate from the original `ddbrsoofnntzqvbtpqyc` referenced in docs). No migrations run, no schema yet — just the empty project so we have a URL + anon key.
2. Set the two **frontend** env vars that `src/lib/supabase.ts` reads at boot:
   - `VITE_SUPABASE_URL` = the new project's `https://<ref>.supabase.co`
   - `VITE_SUPABASE_ANON_KEY` = the new project's anon (publishable) key
3. Restart the dev server so Vite picks up the new env. No `.env` file committed; values live in the Lovable project env.

No service-role key is set in this step. No edge functions, no secrets for `api/*`. None of the 75 SQL files in `supabase/migrations/` are run.

## Verification (proof I'll paste back to you)

1. Exact list of files changed — should be only:
   - a Lovable harness config file (e.g. `.lovable/config.json`) and/or `package.json` + `package-lock.json` (dep removal) and/or a root-level wrapper shim
   - **zero files under `src/`**, **zero changes to `vite.config.ts`, `index.html`, `tsr.config.json`, `tailwind.config.js`, `tsconfig.json`**
2. Preview loads at `/` and `/login` with:
   - no `virtual:tanstack-start-server-entry` error
   - no `Missing Supabase env` throw from `src/lib/supabase.ts`
   - the app's `[diag][build]` console line visible
3. Paste the new `VITE_SUPABASE_URL` (the `.supabase.co` URL). Anon key reference only — no service-role key, ever.

Then stop and wait for your go-ahead before running the 75 migrations.

## Explicitly NOT in this step

- Running any SQL in `supabase/migrations/`
- Porting or rewriting anything in `api/*` (ai-build, ai-health, send-invite-email, mcp, shift-alert-email, cron-driven endpoints, etc.)
- Configuring `pg_cron`, `RESEND_*`, `GEMINI_API_KEY`, `MCP_BEARER`, `EIA_BRIDGE_KEY`, `CRON_SHARED_SECRET`, `SUPABASE_SERVICE_ROLE_KEY`, or any other server-side secret
- Touching the router, route tree, hooks, components, or any other app code
- "Improving" anything

## What I need from you to start

Just approval of this plan. No values needed — Lovable Cloud generates the URL + anon key automatically when I enable it.
