import './loadEnv';
import { Client } from 'pg';
async function main() {
  const c = new Client({ connectionString: process.env.DATABASE_URL!, ssl: { rejectUnauthorized: false } });
  await c.connect();
  console.log('=== shift_configs columns ===');
  const cfg = await c.query(`select column_name, data_type, column_default, is_nullable from information_schema.columns where table_schema='public' and table_name='shift_configs' order by ordinal_position`);
  for (const r of cfg.rows) console.log(`  ${r.column_name.padEnd(32)} ${r.data_type.padEnd(28)} default=${r.column_default ?? 'NULL'} null=${r.is_nullable}`);

  console.log('\n=== shift_sessions columns (subset for gating) ===');
  const ss = await c.query(`select column_name, data_type, column_default from information_schema.columns where table_schema='public' and table_name='shift_sessions' order by ordinal_position`);
  for (const r of ss.rows) console.log(`  ${r.column_name.padEnd(32)} ${r.data_type.padEnd(28)} default=${r.column_default ?? 'NULL'}`);

  console.log('\n=== shift_schedules columns ===');
  const sch = await c.query(`select column_name, data_type, column_default from information_schema.columns where table_schema='public' and table_name='shift_schedules' order by ordinal_position`);
  for (const r of sch.rows) console.log(`  ${r.column_name.padEnd(32)} ${r.data_type.padEnd(28)} default=${r.column_default ?? 'NULL'}`);
  const schCnt = await c.query(`select count(*)::int as n from public.shift_schedules`);
  console.log(`  row count: ${schCnt.rows[0].n}`);

  console.log('\n=== users timezone/shift columns ===');
  const u = await c.query(`select column_name, data_type, column_default from information_schema.columns where table_schema='public' and table_name='users' and (column_name ilike '%zone%' or column_name ilike '%shift%' or column_name ilike '%schedule%' or column_name='timezone') order by column_name`);
  for (const r of u.rows) console.log(`  ${r.column_name.padEnd(32)} ${r.data_type.padEnd(28)} default=${r.column_default ?? 'NULL'}`);

  console.log('\n=== Functions ===');
  for (const fn of [
    'shift_admin_set_config',
    'shift_start',
    'shift_get_or_create_today_session',
    'shift_admin_unlock',
    'shift_admin_set_account_lock',
    'shift_self_period_lock',
  ]) {
    const r = await c.query(`select pg_get_functiondef(p.oid) as d from pg_proc p join pg_namespace n on n.oid=p.pronamespace where n.nspname='public' and p.proname=$1 order by p.oid desc limit 1`, [fn]);
    console.log(`\n--- ${fn} ---`);
    console.log(r.rows[0]?.d ?? '(missing)');
  }
  await c.end();
}
main().catch(e => { console.error(e); process.exit(1); });
