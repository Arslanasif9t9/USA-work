/** Phase 4c proof. */
import './loadEnv';
import { Client } from 'pg';

async function main() {
  const c = new Client({ connectionString: process.env.DATABASE_URL!, ssl: { rejectUnauthorized: false } });
  await c.connect();

  const admin = (await c.query(
    `select id from public.users where role='admin' and status='active' order by created_at limit 1`,
  )).rows[0]?.id;
  const target = (await c.query(
    `select id, username from public.users where username='pm1' limit 1`,
  )).rows[0];
  if (!admin || !target) throw new Error('missing admin or pm1');

  // Read original start date via admin RPC context.
  const orig = (await c.query(
    `select shift_start_date from public.shift_configs where user_id=$1`, [target.id])).rows[0];
  const tomorrow = new Date(Date.now() + 2 * 86400000).toISOString().slice(0, 10);

  // Set shift_start_date = tomorrow via the admin RPC.
  await c.query('begin');
  await c.query(`select set_config('request.jwt.claims', $1, true)`,
    [JSON.stringify({ sub: admin, role: 'authenticated' })]);
  await c.query(`select public.shift_admin_set_start_date($1::uuid, $2::date)`,
    [target.id, tomorrow]);
  await c.query('commit');
  console.log('set shift_start_date =', tomorrow);

  // No need to wipe today's session — the new gate fires BEFORE the
  // session status check inside shift_start().



  // Run gate + shift_start AS pm1.
  await c.query('begin');
  await c.query(`select set_config('request.jwt.claims', $1, true)`,
    [JSON.stringify({ sub: target.id, role: 'authenticated' })]);

  console.log('\n--- shift_can_start() ---');
  const can = (await c.query(`select public.shift_can_start() as r`)).rows[0].r;
  console.log(JSON.stringify(can, null, 2));

  console.log('\n--- shift_start() must raise ---');
  try {
    await c.query(`select public.shift_start()`);
    console.log('UNEXPECTED: shift_start() succeeded');
  } catch (e: any) {
    console.log('RAISED ✓ :', e.message);
  }
  await c.query('rollback');

  // Restore original start date via admin.
  await c.query('begin');
  await c.query(`select set_config('request.jwt.claims', $1, true)`,
    [JSON.stringify({ sub: admin, role: 'authenticated' })]);
  await c.query(`select public.shift_admin_set_start_date($1::uuid, $2::date)`,
    [target.id, orig?.shift_start_date ?? null]);
  await c.query('commit');
  console.log('\nrestored shift_start_date =', orig?.shift_start_date ?? null);
  await c.end();
}
main().catch((e) => { console.error('FAILED:', e.message); process.exit(1); });
