/**
 * Phase 5a proof — tier-7 bio-break suspension.
 *
 * Drives a test manager through 7 bio start/end cycles, asserts:
 *   - shift_configs.account_locked=true with reason 'bio_limit_exceeded'
 *   - shift_sessions.status='locked', locked_reason='bio_limit_exceeded',
 *     current_pause_started_at set (timer frozen)
 *   - shift_my_account_lock() returns the reason
 *   - shift_admin_set_account_lock(uid, false) clears the lock AND
 *     resumes the session.
 * All inside a transaction → rolled back.
 */
import './loadEnv';
import { Client } from 'pg';

async function main() {
  const c = new Client({ connectionString: process.env.DATABASE_URL!, ssl: { rejectUnauthorized: false } });
  await c.connect();

  const { rows: [admin] } = await c.query<{ id: string }>(
    `select id from public.users where status='active' and (role='admin' or is_super_admin=true) limit 1`);
  const { rows: [mgr] } = await c.query<{ id: string; username: string }>(
    `select id, username from public.users
      where role='manager' and status='active' and is_super_admin=false
      order by username limit 1`);

  console.log('admin =', admin.id);
  console.log('manager =', mgr.username, mgr.id);

  await c.query('begin');
  try {
    // Clean slate for this manager today.
    await c.query(`delete from public.shift_sessions where user_id=$1
                    and work_date=(now() at time zone 'UTC')::date`, [mgr.id]);
    await c.query(`delete from public.shift_configs where user_id=$1`, [mgr.id]);
    await c.query(`
      insert into public.shift_configs (user_id, mode, shift_break_seconds, bio_break_max_per_day,
        bio_break_warn_count, bio_break_warn_total_seconds, bio_break_max_seconds_each,
        timezone, account_locked, account_lock_reason)
      values ($1,'hard',1800,7,6,3600,900,'Asia/Manila',false,null)`, [mgr.id]);

    // Start shift as the manager.
    await c.query(`set local "request.jwt.claim.sub" = '${mgr.id}'`);
    await c.query(`select public.shift_start()`);
    const { rows: [sess] } = await c.query<{ id: string }>(
      `select id from public.shift_sessions where user_id=$1
        and work_date=(now() at time zone 'UTC')::date`, [mgr.id]);
    console.log('session =', sess.id);

    // 6 clean bio cycles (start + end). Count goes 0→6.
    for (let i = 1; i <= 6; i++) {
      await c.query(`select public.shift_take_bio_break($1)`, [sess.id]);
      await c.query(`select public.shift_end_break($1)`, [sess.id]);
    }
    const { rows: [after6] } = await c.query(
      `select bio_break_count_today, status from public.shift_sessions where id=$1`, [sess.id]);
    console.log('after 6 bios:', after6);
    if (after6.bio_break_count_today !== 6) throw new Error('expected 6 bios');
    if (after6.status !== 'active') throw new Error('should still be active at 6');

    // 7th cycle — should trip tier-7.
    await c.query(`select public.shift_take_bio_break($1)`, [sess.id]);
    const { rows: [endRes] } = await c.query<{ r: Record<string, unknown> }>(
      `select public.shift_end_break($1) as r`, [sess.id]);
    console.log('7th end result:', endRes.r);
    if (endRes.r.bio_limit_suspended !== true) throw new Error('FAIL — bio_limit_suspended should be true');

    const { rows: [after7] } = await c.query(
      `select bio_break_count_today, status, locked_reason, locked_at,
              current_pause_reason, current_pause_started_at
         from public.shift_sessions where id=$1`, [sess.id]);
    console.log('after 7 bios (session row):', after7);
    if (after7.bio_break_count_today !== 7) throw new Error('FAIL — count');
    if (after7.status !== 'locked') throw new Error('FAIL — status');
    if (after7.locked_reason !== 'bio_limit_exceeded') throw new Error('FAIL — locked_reason');
    if (after7.current_pause_reason !== 'bio_limit_exceeded') throw new Error('FAIL — current_pause_reason');
    if (!after7.current_pause_started_at) throw new Error('FAIL — pause not started (timer not frozen)');

    const { rows: [cfg] } = await c.query(
      `select account_locked, account_lock_reason, account_locked_at
         from public.shift_configs where user_id=$1`, [mgr.id]);
    console.log('config after suspension:', cfg);
    if (cfg.account_locked !== true) throw new Error('FAIL — account_locked');
    if (cfg.account_lock_reason !== 'bio_limit_exceeded') throw new Error('FAIL — reason');

    // shift_my_account_lock() includes the reason.
    const { rows: [mal] } = await c.query<{ r: Record<string, unknown> }>(
      `select public.shift_my_account_lock() as r`);
    console.log('shift_my_account_lock:', mal.r);
    if (mal.r.account_locked !== true) throw new Error('FAIL — mal locked');
    if (mal.r.account_lock_reason !== 'bio_limit_exceeded') throw new Error('FAIL — mal reason');

    // Admin unlock via the existing 4d path — must clear lock AND resume session.
    await c.query(`set local "request.jwt.claim.sub" = '${admin.id}'`);
    const { rows: [unlock] } = await c.query<{ r: Record<string, unknown> }>(
      `select public.shift_admin_set_account_lock($1, false) as r`, [mgr.id]);
    console.log('unlock result:', unlock.r);
    if (unlock.r.session_resumed !== true) throw new Error('FAIL — session_resumed should be true');

    const { rows: [final] } = await c.query(
      `select s.status, s.locked_reason, s.current_pause_reason,
              s.paused_total_seconds, c.account_locked, c.account_lock_reason
         from public.shift_sessions s
         join public.shift_configs c on c.user_id = s.user_id
        where s.id=$1`, [sess.id]);
    console.log('final state:', final);
    if (final.status !== 'active') throw new Error('FAIL — should be active after unlock');
    if (final.locked_reason !== null) throw new Error('FAIL — locked_reason should be null');
    if (final.account_locked !== false) throw new Error('FAIL — account still locked');
    if (final.account_lock_reason !== null) throw new Error('FAIL — reason should be cleared');

    console.log('\n✅ Phase 5a verified.');
  } finally {
    await c.query('rollback');
    console.log('(rolled back)');
  }
  await c.end();
}
main().catch(e => { console.error('FAILED:', e); process.exit(1); });
