import './loadEnv';
import { Client } from 'pg';
async function main() {
  const c = new Client({ connectionString: process.env.DATABASE_URL!, ssl: { rejectUnauthorized: false } });
  await c.connect();
  for (const fn of [
    'public.accept_invite(text,text,text)',
    'public.create_invite(public.user_role,uuid,integer,uuid,text,text)',
    'public.shift_admin_apply_default_schedule(uuid,time,integer)',
    'public.get_invite_by_token(text)',
  ]) {
    try {
      const { rows: [r] } = await c.query<{ d: string }>(`select pg_get_functiondef('${fn}'::regprocedure) as d`);
      console.log('===', fn, '===');
      console.log(r.d);
    } catch (e: any) { console.log('FAIL', fn, e.message); }
  }
  await c.end();
}
main().catch(e => { console.error(e); process.exit(1); });
