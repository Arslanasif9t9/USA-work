import './loadEnv';
import { createClient } from '@supabase/supabase-js';

async function main() {
  const sb = createClient(process.env.VITE_SUPABASE_URL!, process.env.VITE_SUPABASE_ANON_KEY!, { auth: { persistSession: false, autoRefreshToken: false } });
  await sb.auth.signInWithPassword({ email: 'admin@pms.internal', password: 'admin1234' });

  // Fetch target user id via RLS-allowed SELECT (admin can read users)
  const { data: u, error: eu } = await sb.from('users').select('id, email').eq('email','spark11179@gmail.com').single();
  if (eu) throw new Error('user lookup: ' + eu.message);
  console.log('target:', u.email, u.id);

  // Flip to AUTO (schedule was just cleared)
  let r = await sb.rpc('shift_admin_set_shift_mode', { p_user_id: u.id, p_mode: 'auto' });
  if (r.error) throw new Error('set auto: ' + r.error.message);
  console.log('→ auto:', r.data);
  let cfg = await sb.from('shift_configs').select('shift_mode').eq('user_id', u.id).single();
  let sch = await sb.from('shift_schedules').select('weekday, enabled, required_seconds, start_time_local, end_time_local').eq('user_id', u.id).order('weekday');
  console.log('cfg:', cfg.data, 'schedule rows:', sch.data?.length);
  for (const row of sch.data ?? []) console.log(' ', row);

  // Flip to MANUAL
  r = await sb.rpc('shift_admin_set_shift_mode', { p_user_id: u.id, p_mode: 'manual' });
  if (r.error) throw new Error('set manual: ' + r.error.message);
  console.log('→ manual:', r.data);
  cfg = await sb.from('shift_configs').select('shift_mode').eq('user_id', u.id).single();
  const sch2 = await sb.from('shift_schedules').select('weekday').eq('user_id', u.id);
  console.log('cfg:', cfg.data, 'schedule preserved rows:', sch2.data?.length);

  // Admin lock works in manual?
  let lk = await sb.rpc('shift_admin_set_account_lock', { p_target_user_id: u.id, p_locked: true });
  console.log('lock in manual:', lk.error?.message ?? 'ok', lk.data);
  lk = await sb.rpc('shift_admin_set_account_lock', { p_target_user_id: u.id, p_locked: false });
  console.log('unlock in manual:', lk.error?.message ?? 'ok');
}
main().catch(e => { console.error('FAILED:', e); process.exit(1); });
