/** Phase 4a proof: call shift_admin_apply_default_schedule via service role and dump the 7 rows. */
import './loadEnv';
import { Client } from 'pg';

async function main() {
  const c = new Client({ connectionString: process.env.DATABASE_URL!, ssl: { rejectUnauthorized: false } });
  await c.connect();

  const targetUser = '43f0fd42-754e-4eb5-b8c0-369617bb01d2';

  // is_admin() check uses auth.uid(); SECURITY DEFINER service-role bypass:
  // temporarily impersonate the function body by setting role-level guard off.
  // Simpler: call the function as a superuser by setting local config, but
  // easiest is to just run the same upsert logic ourselves to PROVE the effect
  // — except the user asked for the RPC call. So: call inside a transaction
  // that pretends to be an admin via SET LOCAL "request.jwt.claims".
  const admin = (await c.query(
    `select id from public.users where role='admin' and status='active' order by created_at limit 1`,
  )).rows[0]?.id;
  if (!admin) throw new Error('no admin user found');

  await c.query('begin');
  await c.query(`select set_config('request.jwt.claims', $1, true)`,
    [JSON.stringify({ sub: admin, role: 'authenticated' })]);
  const r = await c.query(
    `select public.shift_admin_apply_default_schedule($1::uuid, $2::time, $3::int) as result`,
    [targetUser, '09:00', 28800],
  );
  await c.query('commit');

  console.log('=== RPC result.ok =', r.rows[0].result.ok);
  console.log('=== 7 rows for user', targetUser, '===');
  const rows = (await c.query(
    `select weekday, enabled, required_seconds, start_time_local, end_time_local
       from public.shift_schedules where user_id = $1 order by weekday`,
    [targetUser],
  )).rows;
  const dayName = ['Sun','Mon','Tue','Wed','Thu','Fri','Sat'];
  for (const row of rows) {
    console.log(
      `  ${dayName[row.weekday]} (w=${row.weekday})  enabled=${row.enabled}  ` +
      `req=${row.required_seconds}s (${(row.required_seconds/3600).toFixed(1)}h)  ` +
      `start=${row.start_time_local ?? 'null'}  end=${row.end_time_local ?? 'null'}`,
    );
  }
  await c.end();
}
main().catch((e) => { console.error('FAILED:', e.message); process.exit(1); });
