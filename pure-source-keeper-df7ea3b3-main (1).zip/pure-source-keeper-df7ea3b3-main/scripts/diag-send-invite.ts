import { createClient } from '@supabase/supabase-js';
const url = 'https://kevtjqxsmzjquoonqfbh.supabase.co';
const anon = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImtldnRqcXhzbXpqcXVvb25xZmJoIiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODA5OTQxMjYsImV4cCI6MjA5NjU3MDEyNn0.du6zR2cMmAZsiYjVvY7IB9odYJSTQyZAyXlx1V299yY';
const sb = createClient(url, anon);
const { error: aerr } = await sb.auth.signInWithPassword({ email: 'admin@pms.internal', password: 'admin1234' });
if (aerr) { console.error(aerr); process.exit(1); }
const { data: inv, error: ierr } = await sb.rpc('create_invite', {
  p_role:'manager', p_board_id:null, p_expires_in_hours:1,
  p_invitee_email:'diagnostic-test@example.com',
  p_invitee_name:'Diag Test', p_invitee_shift_mode:'auto',
  p_invitee_shift_start_date:new Date().toISOString().slice(0,10),
  p_invitee_shift_start_time:'10:00', p_invitee_shift_end_time:'18:00',
  p_invitee_timezone:'Asia/Manila',
});
console.log('mint err:', ierr, 'token:', (inv as any)?.token);
const t0 = Date.now();
const { data, error } = await sb.functions.invoke('send-invite-email', {
  body: { token: (inv as any).token, invitee_email:'diagnostic-test@example.com', invitee_name:'Diag Test', role:'manager', board_name:'', inviter_name:'EIA' }
});
console.log('elapsed ms:', Date.now()-t0);
console.log('resp:', JSON.stringify(data));
console.log('err:', error);
