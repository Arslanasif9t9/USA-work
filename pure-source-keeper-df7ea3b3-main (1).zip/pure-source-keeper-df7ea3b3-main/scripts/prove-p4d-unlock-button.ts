import './loadEnv';
import { Client } from 'pg';

async function main() {
  const c = new Client({ connectionString: process.env.DATABASE_URL!, ssl: { rejectUnauthorized: false } });
  await c.connect();

  // Find admin + test manager
  const { rows: [admin] } = await c.query<{ id: string }>(
    `select id from public.users where role='admin' and status='active' limit 1`,
  );
  const { rows: [mgr] } = await c.query<{ id: string; full_name: string | null; username: string }>(
    `select id, full_name, username from public.users
       where role='manager' and status='active' and is_super_admin=false limit 1`,
  );

  if (!admin || !mgr) {
    console.log('MISSING: need at least one admin and one manager');
    await c.end();
    return;
  }

  console.log('Admin:', admin.id);
  console.log('Manager:', mgr.id, mgr.full_name ?? mgr.username);

  await c.query('begin');
  try {
    // Clean slate for the manager today
    await c.query(
      `delete from public.shift_sessions where user_id=$1 and work_date=(now() at time zone 'UTC')::date`,
      [mgr.id],
    );
    await c.query(`delete from public.shift_configs where user_id=$1`, [mgr.id]);
    await c.query(`
      insert into public.shift_configs (user_id, mode, shift_break_seconds, bio_break_max_per_day,
        bio_break_warn_count, bio_break_warn_total_seconds, bio_break_max_seconds_each,
        primary_group_id, timezone, late_start_threshold_seconds, account_locked)
      values ($1,'hard',1800,7,4,1200,360,null,'Asia/Manila',900,false)`, [mgr.id]);

    // Start shift as the manager
    await c.query(`set local "request.jwt.claim.sub" = '${mgr.id}'`);
    const { rows: [s] } = await c.query<{ r: { session_id: string } }>(
      `select public.shift_start() as r`,
    );
    const sid = s.r.session_id;
    console.log('Session created:', sid);

    // Drive into period lock
    await c.query(`set local "request.jwt.claim.sub" = '${admin.id}'`);
    await c.query(
      `update public.shift_sessions
         set status='locked',
             current_pause_started_at = now(),
             current_pause_reason = 'period_lock',
             locked_at = now(),
             locked_reason = 'period_lock',
             locked_by = null
       where id=$1`,
      [sid],
    );

    // Verify locked
    const { rows: [before] } = await c.query<{ status: string }>(
      `select status from public.shift_sessions where id=$1`, [sid],
    );
    console.log('BEFORE unlock:', before.status);

    // Simulate the button click: runLockToggle(row, false) for a period-locked session
    // This calls shift_admin_unlock(session_id)
    await c.query(`select public.shift_admin_unlock($1)`, [sid]);

    const { rows: [after] } = await c.query<{ status: string; locked_reason: string | null }>(
      `select status, locked_reason from public.shift_sessions where id=$1`, [sid],
    );
    console.log('AFTER unlock:', after.status, 'locked_reason:', after.locked_reason);
    console.log('PASS:', after.status === 'active' ? 'YES' : 'NO');

    // Also test account_locked path
    await c.query(
      `update public.shift_configs set account_locked=true where user_id=$1`,
      [mgr.id],
    );
    await c.query(
      `select public.shift_admin_set_account_lock($1, false)`,
      [mgr.id],
    );
    const { rows: [cfgAfter] } = await c.query<{ account_locked: boolean }>(
      `select account_locked from public.shift_configs where user_id=$1`, [mgr.id],
    );
    console.log('Account lock cleared:', cfgAfter.account_locked === false ? 'YES' : 'NO');
  } finally {
    await c.query('rollback');
    console.log('(rolled back)');
  }

  await c.end();
}

main().catch((e) => { console.error('FAILED:', e); process.exit(1); });
