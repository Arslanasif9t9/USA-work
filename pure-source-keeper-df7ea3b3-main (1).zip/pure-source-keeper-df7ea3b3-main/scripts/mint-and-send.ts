import { createClient } from '@supabase/supabase-js';
const url = process.env.VITE_SUPABASE_URL || 'https://kevtjqxsmzjquoonqfbh.supabase.co';
const anon = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImtldnRqcXhzbXpqcXVvb25xZmJoIiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODA5OTQxMjYsImV4cCI6MjA5NjU3MDEyNn0.du6zR2cMmAZsiYjVvY7IB9odYJSTQyZAyXlx1V299yY';
const sb = createClient(url, anon);
const { data: auth, error: aerr } = await sb.auth.signInWithPassword({ email: 'admin@pms.internal', password: 'admin1234' });
if (aerr) { console.error('auth err', aerr); process.exit(1); }
const { data, error } = await sb.rpc('create_invite', {
  p_role: 'manager', p_board_id: null, p_expires_in_hours: 168,
  p_invitee_email: 'ayenmaecrystelbvalentino@gmail.com',
  p_invitee_name: 'Ayen Mae Crystel B Valentino',
  p_invitee_shift_mode: 'auto',
  p_invitee_shift_start_date: new Date().toISOString().slice(0,10),
  p_invitee_shift_start_time: '10:00',
  p_invitee_shift_end_time: '18:00',
  p_invitee_timezone: 'Asia/Manila',
});
console.log('invite:', JSON.stringify(data), 'err:', error);
const token = (data as any)?.token;
if (!token) { console.error('no token'); process.exit(1); }
const { data: send, error: serr } = await sb.functions.invoke('send-invite-email', {
  body: { token, invitee_email: 'ayenmaecrystelbvalentino@gmail.com', invitee_name: 'Ayen Mae Crystel B Valentino', role: 'manager', board_name: '', inviter_name: 'EIA' }
});
console.log('send:', JSON.stringify(send), 'err:', serr);
