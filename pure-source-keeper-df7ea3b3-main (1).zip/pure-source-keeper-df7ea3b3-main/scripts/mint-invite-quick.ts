import { createClient } from '@supabase/supabase-js';

const url = process.env.VITE_SUPABASE_URL!;
const anonKey = process.env.VITE_SUPABASE_ANON_KEY!;

async function main() {
  const sb = createClient(url, anonKey, { auth: { persistSession: false, autoRefreshToken: false } });
  const { data: loginData, error: loginErr } = await sb.auth.signInWithPassword({
    email: 'admin@pms.internal',
    password: 'admin1234',
  });
  if (loginErr || !loginData.session) {
    console.error('Admin login failed:', loginErr?.message);
    process.exit(1);
  }

  const authed = createClient(url, anonKey, {
    auth: { persistSession: false, autoRefreshToken: false },
    global: { headers: { Authorization: `Bearer ${loginData.session.access_token}` } },
  });

  const { data, error } = await authed.rpc('create_invite', {
    p_role: 'manager',
    p_board_id: null,
    p_expires_in_hours: 168,
    p_invitee_email: 'ayenmaecrystelbvalentino@gmail.com',
    p_invitee_name: 'Ayen Mae Crystel B Valentino',
    p_invitee_shift_mode: 'auto',
    p_invitee_shift_start_date: new Date().toISOString().split('T')[0],
    p_invitee_shift_start_time: '10:00',
    p_invitee_shift_end_time: '18:00',
    p_invitee_timezone: 'Asia/Manila',
  });

  if (error) {
    console.error('create_invite error:', error.message, error.code);
    process.exit(1);
  }

  const token = (data as any)?.token;
  console.log('https://myprojects.expertintuitiveadvisor.com/invite/' + token);
}

main().catch((e) => { console.error('FAILED:', e); process.exit(1); });
