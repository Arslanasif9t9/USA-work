import './loadEnv';
import { Client } from 'pg';
import { createClient } from '@supabase/supabase-js';

async function main() {
  const SB = process.env.VITE_SUPABASE_URL!;
  const AK = process.env.VITE_SUPABASE_ANON_KEY!;
  const sb = createClient(SB, AK, { auth: { persistSession: false, autoRefreshToken: false } });
  const c = new Client({ connectionString: process.env.DATABASE_URL!, ssl: { rejectUnauthorized: false } });
  await c.connect();

  // Admin login
  const { data: ad, error: e0 } = await sb.auth.signInWithPassword({ email: 'admin@pms.internal', password: 'admin1234' });
  if (e0) throw new Error('admin login: ' + e0.message);
  console.log('admin ok:', ad.user?.id);

  // --- AUTO invite ---
  const emailA = `p11b-auto-${Date.now()}@example.test`;
  const { data: invA, error: ea } = await sb.rpc('create_invite', {
    p_role: 'manager',
    p_board_id: null,
    p_expires_in_hours: 24,
    p_group_id: null,
    p_invitee_email: emailA,
    p_invitee_name: 'Auto Tester',
    p_invitee_shift_mode: 'auto',
    p_invitee_shift_start_date: '2026-06-15',
    p_invitee_shift_start_time: '09:00',
    p_invitee_shift_end_time: '17:00',
    p_invitee_timezone: 'Asia/Singapore',
  });
  if (ea) throw new Error('create_invite auto: ' + ea.message);
  const tokenA = (invA as any).token;
  console.log('AUTO invite minted:', tokenA);

  // --- MANUAL invite ---
  const emailM = `p11b-manual-${Date.now()}@example.test`;
  const { data: invM, error: em } = await sb.rpc('create_invite', {
    p_role: 'manager',
    p_board_id: null,
    p_expires_in_hours: 24,
    p_group_id: null,
    p_invitee_email: emailM,
    p_invitee_name: 'Manual Tester',
    p_invitee_shift_mode: 'manual',
  });
  if (em) throw new Error('create_invite manual: ' + em.message);
  const tokenM = (invM as any).token;
  console.log('MANUAL invite minted:', tokenM);

  // Accept both (anon RPCs)
  await sb.auth.signOut();

  const { data: accA, error: eaa } = await sb.rpc('accept_invite', {
    p_token: tokenA, p_full_name: 'Auto Tester', p_password: 'TestPass123!',
  });
  if (eaa) throw new Error('accept auto: ' + eaa.message);
  const uidA = (accA as any).user_id;
  console.log('AUTO accepted, user:', uidA);

  const { data: accM, error: eam } = await sb.rpc('accept_invite', {
    p_token: tokenM, p_full_name: 'Manual Tester', p_password: 'TestPass123!',
  });
  if (eam) throw new Error('accept manual: ' + eam.message);
  const uidM = (accM as any).user_id;
  console.log('MANUAL accepted, user:', uidM);

  // Inspect resulting state
  for (const [label, uid] of [['AUTO', uidA], ['MANUAL', uidM]] as const) {
    console.log('\n===', label, uid, '===');
    const cfg = await c.query(`select shift_mode, timezone, shift_start_date from public.shift_configs where user_id=$1`, [uid]);
    console.log('shift_configs:', cfg.rows[0]);
    const sch = await c.query(`select weekday, enabled, required_seconds, start_time_local, end_time_local from public.shift_schedules where user_id=$1 order by weekday`, [uid]);
    console.log('shift_schedules rows:', sch.rows.length);
    for (const r of sch.rows) console.log(' ', r);
  }

  // Cleanup test users
  await c.query(`delete from public.shift_schedules where user_id = any($1)`, [[uidA, uidM]]);
  await c.query(`delete from public.shift_configs where user_id = any($1)`, [[uidA, uidM]]);
  await c.query(`delete from public.workspace_members where user_id = any($1)`, [[uidA, uidM]]);
  await c.query(`delete from public.users where id = any($1)`, [[uidA, uidM]]);
  await c.query(`delete from auth.identities where user_id = any($1)`, [[uidA, uidM]]);
  await c.query(`delete from auth.users where id = any($1)`, [[uidA, uidM]]);
  console.log('\ncleanup done');

  await c.end();
}
main().catch(e => { console.error('FAILED:', e); process.exit(1); });
