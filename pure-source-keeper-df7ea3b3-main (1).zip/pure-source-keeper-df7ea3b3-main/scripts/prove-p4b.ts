/** Phase 4b proof: call shift_admin_set_schedule_bulk + shift_admin_set_start_date as admin, dump effect. */
import './loadEnv';
import { Client } from 'pg';

async function main() {
  const c = new Client({ connectionString: process.env.DATABASE_URL!, ssl: { rejectUnauthorized: false } });
  await c.connect();

  const admin = (await c.query(
    `select id from public.users where role='admin' and status='active' order by created_at limit 1`,
  )).rows[0]?.id;
  if (!admin) throw new Error('no admin');

  const target = (await c.query(
    `select id, username from public.users where username='pm1' limit 1`,
  )).rows[0];
  if (!target) throw new Error('no pm1');

  const rows = [
    { weekday: 0, enabled: false, required_seconds: 0,     start_time_local: null,       end_time_local: null },
    { weekday: 1, enabled: true,  required_seconds: 28800, start_time_local: '09:00:00', end_time_local: '17:00:00' },
    { weekday: 2, enabled: true,  required_seconds: 28800, start_time_local: '09:00:00', end_time_local: '17:00:00' },
    { weekday: 3, enabled: true,  required_seconds: 28800, start_time_local: '09:00:00', end_time_local: '17:00:00' },
    { weekday: 4, enabled: true,  required_seconds: 28800, start_time_local: '09:00:00', end_time_local: '17:00:00' },
    { weekday: 5, enabled: true,  required_seconds: 28800, start_time_local: '09:00:00', end_time_local: '17:00:00' },
    { weekday: 6, enabled: true,  required_seconds: 14400, start_time_local: '09:00:00', end_time_local: '13:00:00' },
  ];
  const tomorrow = new Date(Date.now() + 86400000).toISOString().slice(0, 10);

  await c.query('begin');
  await c.query(`select set_config('request.jwt.claims', $1, true)`,
    [JSON.stringify({ sub: admin, role: 'authenticated' })]);

  const bulk = await c.query(
    `select public.shift_admin_set_schedule_bulk($1::uuid, $2::jsonb) as r`,
    [target.id, JSON.stringify(rows)],
  );
  console.log('bulk ok=', bulk.rows[0].r.ok, 'rows_written=', bulk.rows[0].r.rows_written);

  const sd = await c.query(
    `select public.shift_admin_set_start_date($1::uuid, $2::date) as r`,
    [target.id, tomorrow],
  );
  console.log('start_date result:', sd.rows[0].r);

  await c.query('commit');

  console.log(`\n=== ${target.username} 7 schedule rows ===`);
  const sched = (await c.query(
    `select weekday, enabled, required_seconds, start_time_local, end_time_local
       from public.shift_schedules where user_id=$1 order by weekday`,
    [target.id],
  )).rows;
  const dn = ['Sun','Mon','Tue','Wed','Thu','Fri','Sat'];
  for (const r of sched) {
    console.log(`  ${dn[r.weekday]}  enabled=${r.enabled}  req=${r.required_seconds}s  start=${r.start_time_local ?? 'null'}  end=${r.end_time_local ?? 'null'}`);
  }
  const cfg = (await c.query(
    `select shift_start_date from public.shift_configs where user_id=$1`, [target.id])).rows[0];
  console.log(`\ncfg.shift_start_date = ${cfg?.shift_start_date}`);
  await c.end();
}
main().catch((e) => { console.error('FAILED:', e.message); process.exit(1); });
