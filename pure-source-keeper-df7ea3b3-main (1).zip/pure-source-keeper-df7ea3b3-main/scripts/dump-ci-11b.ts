import './loadEnv';
import { Client } from 'pg';
async function main() {
  const c = new Client({ connectionString: process.env.DATABASE_URL!, ssl: { rejectUnauthorized: false } });
  await c.connect();
  // find create_invite oids
  const r = await c.query(`select oid::regprocedure::text as sig from pg_proc where proname='create_invite' and pronamespace='public'::regnamespace`);
  for (const row of r.rows) {
    const { rows: [d] } = await c.query<{ d: string }>(`select pg_get_functiondef('${row.sig}'::regprocedure) as d`);
    console.log('===', row.sig, '===');
    console.log(d.d);
  }
  await c.end();
}
main().catch(e => { console.error(e); process.exit(1); });
