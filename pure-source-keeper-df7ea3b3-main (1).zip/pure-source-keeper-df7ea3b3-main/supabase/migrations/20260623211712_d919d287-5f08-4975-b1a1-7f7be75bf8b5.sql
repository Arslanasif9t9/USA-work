CREATE OR REPLACE FUNCTION public.shift_admin_set_can_work_now(p_target_user_id uuid, p_can boolean)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_uid uuid := auth.uid();
  v_tz text;
  v_shift_mode text;
  v_now timestamptz := now();
  v_session record;
  v_local_now timestamp;
  v_local_time time;
  v_weekday smallint;
  v_sched record;
  v_outside boolean := false;
  v_ended boolean := false;
BEGIN
  IF NOT public.is_admin(v_uid) THEN
    RAISE EXCEPTION 'not_admin';
  END IF;
  IF p_target_user_id IS NULL THEN
    RAISE EXCEPTION 'target_required';
  END IF;

  INSERT INTO public.shift_configs (user_id, can_work_now, updated_at, updated_by)
  VALUES (p_target_user_id, p_can, v_now, v_uid)
  ON CONFLICT (user_id) DO UPDATE
    SET can_work_now = EXCLUDED.can_work_now,
        updated_at = EXCLUDED.updated_at,
        updated_by = EXCLUDED.updated_by;

  BEGIN
    INSERT INTO public.shift_events (user_id, type, at, by, meta)
    VALUES (p_target_user_id, 'admin_override', v_now, v_uid,
            jsonb_build_object('action','set_can_work_now','can_work_now',p_can));
  EXCEPTION WHEN OTHERS THEN NULL;
  END;

  IF p_can = false THEN
    SELECT COALESCE(timezone, 'Asia/Manila'), shift_mode
      INTO v_tz, v_shift_mode
    FROM public.shift_configs WHERE user_id = p_target_user_id;

    IF v_tz IS NULL THEN v_tz := 'Asia/Manila'; END IF;

    IF v_shift_mode IS DISTINCT FROM 'manual' THEN
      SELECT * INTO v_session
      FROM public.shift_sessions
      WHERE user_id = p_target_user_id
        AND work_date = (now() AT TIME ZONE v_tz)::date
        AND status IN ('active','on_shift_break','on_bio_break')
      FOR UPDATE;

      IF FOUND THEN
        v_local_now := (now() AT TIME ZONE v_tz);
        v_local_time := v_local_now::time;
        v_weekday := extract(dow from v_local_now)::smallint;

        SELECT * INTO v_sched
        FROM public.shift_schedules
        WHERE user_id = p_target_user_id AND weekday = v_weekday;

        IF NOT FOUND THEN
          v_outside := true;
        ELSIF v_sched.enabled IS NOT TRUE THEN
          v_outside := true;
        ELSIF v_sched.start_time_local IS NULL THEN
          v_outside := true;
        ELSIF v_local_time < v_sched.start_time_local THEN
          v_outside := true;
        ELSIF v_sched.end_time_local IS NOT NULL AND v_local_time > v_sched.end_time_local THEN
          v_outside := true;
        END IF;

        IF v_outside THEN
          UPDATE public.shift_sessions
          SET status = 'completed',
              completed_at = v_now,
              updated_at = v_now
          WHERE id = v_session.id;

          v_ended := true;

          BEGIN
            INSERT INTO public.shift_events (session_id, user_id, type, at, by, meta)
            VALUES (v_session.id, p_target_user_id, 'admin_override', v_now, v_uid,
                    jsonb_build_object('action','can_work_now_session_ended'));
          EXCEPTION WHEN OTHERS THEN NULL;
          END;
        END IF;
      END IF;
    END IF;
  END IF;

  RETURN jsonb_build_object('ok', true, 'can_work_now', p_can, 'session_ended', v_ended);
END;
$$;