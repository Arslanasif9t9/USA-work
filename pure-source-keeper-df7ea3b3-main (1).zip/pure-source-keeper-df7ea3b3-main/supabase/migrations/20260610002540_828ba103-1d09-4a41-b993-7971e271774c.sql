CREATE OR REPLACE FUNCTION public.shift_get_or_create_today_session()
 RETURNS shift_sessions
 LANGUAGE plpgsql SECURITY DEFINER SET search_path TO 'public'
AS $function$
declare
  v_uid             uuid := auth.uid();
  v_today           date;
  v_session         public.shift_sessions;
  v_config          public.shift_configs;
  v_sched           public.shift_schedules;
  v_weekday         int;
  v_period          int;
  v_required        int;
  v_effective_mode  text;
begin
  if v_uid is null then
    raise exception 'Not authenticated' using errcode = '42501';
  end if;
  if not is_active_user() then
    raise exception 'User is not active' using errcode = '42501';
  end if;

  select * into v_config from public.shift_configs where user_id = v_uid;
  if not found then
    insert into public.shift_configs (user_id, hard_until) values
      (v_uid, now() + interval '14 days')
    on conflict (user_id) do nothing
    returning * into v_config;
    if v_config is null then
      select * into v_config from public.shift_configs where user_id = v_uid;
    end if;
  end if;

  v_today := (now() at time zone coalesce(v_config.timezone,'Asia/Manila'))::date;

  select * into v_session
    from public.shift_sessions
   where user_id = v_uid and work_date = v_today;
  if found then return v_session; end if;

  v_weekday := extract(dow from v_today)::int;
  select * into v_sched from public.shift_schedules
   where user_id = v_uid and weekday = v_weekday;
  v_required := coalesce(v_sched.required_seconds, v_config.required_seconds_default);
  if found and not v_sched.enabled then
    v_required := 0;
  end if;

  if coalesce(v_config.shift_mode, 'manual') = 'manual' then
    v_required := 0;
  end if;

  v_effective_mode := case
    when v_config.hard_until is not null and v_config.hard_until > now() then 'hard'
    else v_config.mode
  end;

  v_period := public._shift_period_seconds(v_effective_mode);

  insert into public.shift_sessions (
    user_id, work_date, status, mode, period_seconds, required_seconds
  ) values (
    v_uid, v_today, 'not_started', v_effective_mode, v_period, v_required
  )
  on conflict (user_id, work_date) do nothing
  returning * into v_session;

  if v_session.id is null then
    select * into v_session from public.shift_sessions
     where user_id = v_uid and work_date = v_today;
  end if;

  return v_session;
end;
$function$;

CREATE OR REPLACE FUNCTION public.shift_break_sweep()
 RETURNS jsonb
 LANGUAGE plpgsql SECURITY DEFINER SET search_path TO 'public'
AS $function$
declare
  v_now timestamptz := clock_timestamp();
  v_rec record;
  v_allowance int;
  v_grace int;
  v_break_elapsed int;
  v_freeze_dur int;
  v_recorded int;
  v_frozen_count int := 0;
  v_locked_count int := 0;
  v_emailed_count int := 0;
  v_bio6_count int := 0;
  v_secret text;
  v_url text;
  v_email_mark jsonb;
begin
  select value into v_secret from private.config where key='cron_shared_secret';
  select value into v_url    from private.config where key='app_base_url';
  if v_url is null then v_url := 'https://p-m-system.vercel.app'; end if;

  for v_rec in
    select s.id, s.user_id, s.paused_total_seconds,
           s.current_break_started_at, s.current_pause_started_at, s.current_pause_reason,
           coalesce(c.shift_break_seconds, 1800) as allowance,
           coalesce(c.shift_break_overstay_grace_seconds, 900) as grace
      from public.shift_sessions s
      join public.shift_configs c on c.user_id = s.user_id
     where s.status = 'on_shift_break'
       and s.current_break_kind = 'shift'
       and s.current_break_started_at is not null
       and coalesce(c.shift_mode, 'manual') = 'auto'
       and greatest(0, extract(epoch from (v_now - s.current_break_started_at))::int)
           >= coalesce(c.shift_break_seconds, 1800) + coalesce(c.shift_break_overstay_grace_seconds, 900)
     for update of s
  loop
    v_allowance := v_rec.allowance;
    v_grace     := v_rec.grace;
    v_break_elapsed := greatest(0, extract(epoch from (v_now - v_rec.current_break_started_at))::int);
    v_freeze_dur := case
      when v_rec.current_pause_reason = 'break_overstay'
       and v_rec.current_pause_started_at is not null
      then greatest(0, extract(epoch from (v_now - v_rec.current_pause_started_at))::int)
      else 0 end;
    v_recorded := least(v_break_elapsed, v_allowance);

    update public.shift_sessions set
      status='locked', current_break_started_at=null, current_break_kind=null,
      paused_total_seconds = paused_total_seconds + v_freeze_dur,
      current_pause_started_at = v_now, current_pause_reason = 'break_overstay',
      locked_at = v_now, locked_reason = 'break_overstay', locked_by = null,
      updated_at = v_now
     where id = v_rec.id;

    insert into public.shift_events (session_id, user_id, type, by, meta) values
      (v_rec.id, v_rec.user_id, 'shift_break_end', null,
        jsonb_build_object(
          'duration_seconds_actual',   v_break_elapsed,
          'duration_seconds_recorded', v_recorded,
          'overstay_seconds',          greatest(0, v_break_elapsed - v_allowance),
          'frozen_seconds_credited',   v_freeze_dur,
          'allowance_seconds',         v_allowance,
          'ended_by',                  'overstay_lock_sweep',
          'sweep',                     true)),
      (v_rec.id, v_rec.user_id, 'shift_break_overstay_lock', null,
        jsonb_build_object(
          'break_elapsed_seconds',   v_break_elapsed,
          'allowance_seconds',       v_allowance,
          'grace_seconds',           v_grace,
          'frozen_seconds_credited', v_freeze_dur,
          'sweep',                   true));

    v_locked_count := v_locked_count + 1;

    insert into public.notifications
      (recipient_id, actor_id, type, board_id, item_id, update_id, is_read)
      select u.id, v_rec.user_id, 'shift_admin_alert', null, null, null, false
        from public.users u
       where u.status='active' and (u.role='admin' or u.is_super_admin=true);

    select public.shift_mark_overstay_lock_emailed(v_rec.id) into v_email_mark;
    if coalesce((v_email_mark->>'emailed_now')::boolean, false) then
      v_emailed_count := v_emailed_count + 1;
      if v_secret is not null and v_secret <> '' then
        begin
          perform net.http_post(
            url     := v_url || '/api/shift-alert-email',
            body    := jsonb_build_object(
                         'session_id', v_rec.id::text,
                         'kind',       'break_overstay_lock'),
            headers := jsonb_build_object(
                         'Content-Type',  'application/json',
                         'X-Cron-Secret', v_secret),
            timeout_milliseconds := 5000
          );
        exception when others then
          insert into public.shift_events (session_id, user_id, type, by, meta) values
            (v_rec.id, v_rec.user_id, 'admin_override', null,
              jsonb_build_object('action','sweep_email_http_post_failed',
                                 'sweep', true, 'sqlerrm', sqlerrm));
        end;
      else
        insert into public.shift_events (session_id, user_id, type, by, meta) values
          (v_rec.id, v_rec.user_id, 'admin_override', null,
            jsonb_build_object('action','sweep_email_skipped_no_secret','sweep',true));
      end if;
    end if;
  end loop;

  for v_rec in
    select s.id, s.user_id, s.current_break_started_at,
           coalesce(c.shift_break_seconds, 1800) as allowance
      from public.shift_sessions s
      join public.shift_configs c on c.user_id = s.user_id
     where s.status = 'on_shift_break'
       and s.current_break_kind = 'shift'
       and s.current_break_started_at is not null
       and s.current_pause_started_at is null
       and coalesce(c.shift_mode, 'manual') = 'auto'
       and greatest(0, extract(epoch from (v_now - s.current_break_started_at))::int)
           >= coalesce(c.shift_break_seconds, 1800)
     for update of s
  loop
    v_allowance := v_rec.allowance;
    v_break_elapsed := greatest(0, extract(epoch from (v_now - v_rec.current_break_started_at))::int);
    update public.shift_sessions set
      current_pause_started_at = v_now,
      current_pause_reason     = 'break_overstay',
      updated_at               = v_now
     where id = v_rec.id;
    insert into public.shift_events (session_id, user_id, type, by, meta) values
      (v_rec.id, v_rec.user_id, 'shift_break_overstay_freeze', null,
        jsonb_build_object('break_elapsed_seconds', v_break_elapsed,
                           'allowance_seconds',     v_allowance,
                           'sweep',                 true));
    v_frozen_count := v_frozen_count + 1;
  end loop;

  for v_rec in
    select s.id, s.user_id
      from public.shift_sessions s
      join public.shift_configs c on c.user_id = s.user_id
     where s.bio_break_count_today >= 6
       and s.bio6_notified_at is null
       and s.work_date = (v_now at time zone coalesce(c.timezone,'Asia/Manila'))::date
       and coalesce(c.shift_mode, 'manual') = 'auto'
     for update of s
  loop
    insert into public.notifications
      (recipient_id, actor_id, type, board_id, item_id, update_id, is_read)
      select u.id, v_rec.user_id, 'shift_admin_alert', null, null, null, false
        from public.users u
       where u.status='active' and (u.role='admin' or u.is_super_admin=true);
    update public.shift_sessions set bio6_notified_at = v_now where id = v_rec.id;
    v_bio6_count := v_bio6_count + 1;
  end loop;

  return jsonb_build_object(
    'frozen_count',  v_frozen_count,
    'locked_count',  v_locked_count,
    'emailed_count', v_emailed_count,
    'bio6_count',    v_bio6_count,
    'now',           v_now
  );
end;
$function$;

CREATE OR REPLACE FUNCTION public.shift_sweep_due_and_orphans()
 RETURNS jsonb
 LANGUAGE plpgsql SECURITY DEFINER SET search_path TO 'public'
AS $function$
declare
  v_uid uuid := auth.uid();
  v_completed_today uuid[] := '{}';
  v_orphan_user_ids uuid[] := '{}';
  v_orphan_count int := 0;
  v_completed_count int := 0;
  v_elapsed int;
  r record;
begin
  if v_uid is not null and not is_admin() then
    raise exception 'admin or service role only' using errcode='42501';
  end if;

  for r in
    select s.*
      from public.shift_sessions s
      join public.shift_configs c on c.user_id = s.user_id
     where s.work_date = (now() at time zone coalesce(c.timezone,'Asia/Manila'))::date
       and s.status in ('active','on_shift_break','on_bio_break')
       and s.started_at is not null
     for update of s
  loop
    v_elapsed := greatest(0,
      extract(epoch from (clock_timestamp() - r.started_at))::int
      - r.paused_total_seconds
      - case when r.current_pause_started_at is not null
             then extract(epoch from (clock_timestamp() - r.current_pause_started_at))::int
             else 0 end
    );
    if v_elapsed >= r.required_seconds then
      update public.shift_sessions
         set status='completed', completed_at=now(),
             locked_reason='shift_complete',
             current_break_started_at=null, current_break_kind=null,
             updated_at=now()
       where id = r.id;
      insert into public.shift_events (session_id, user_id, type, by, meta)
        values (r.id, r.user_id, 'shift_complete', v_uid,
                jsonb_build_object('worked_seconds', v_elapsed,
                                   'from_status', r.status,
                                   'auto_swept', true));
      v_completed_today := array_append(v_completed_today, r.user_id);
      v_completed_count := v_completed_count + 1;
    end if;
  end loop;

  for r in
    select s.*
      from public.shift_sessions s
      join public.shift_configs c on c.user_id = s.user_id
     where s.work_date < (now() at time zone coalesce(c.timezone,'Asia/Manila'))::date
       and s.status not in ('completed','not_started')
     for update of s
  loop
    update public.shift_sessions
       set status='completed', completed_at=now(),
           current_break_started_at=null, current_break_kind=null,
           updated_at=now()
     where id = r.id;
    insert into public.shift_events (session_id, user_id, type, by, meta)
      values (r.id, r.user_id, 'admin_override', v_uid,
              jsonb_build_object('action','auto_close_orphaned','prior_status', r.status));
    v_orphan_user_ids := array_append(v_orphan_user_ids, r.user_id);
    v_orphan_count := v_orphan_count + 1;
  end loop;

  return jsonb_build_object(
    'completed_today_count',     v_completed_count,
    'completed_today_user_ids',  v_completed_today,
    'closed_orphan_count',       v_orphan_count,
    'closed_orphan_user_ids',    v_orphan_user_ids,
    'now',                       clock_timestamp()
  );
end;
$function$;

CREATE OR REPLACE FUNCTION public.shift_admin_set_account_lock(p_target_user_id uuid, p_locked boolean)
 RETURNS jsonb
 LANGUAGE plpgsql SECURITY DEFINER SET search_path TO 'public'
AS $function$
declare
  v_uid        uuid := auth.uid();
  v_old        public.shift_configs;
  v_existed    boolean;
  v_now        timestamptz := clock_timestamp();
  v_locked_at  timestamptz;
  v_locked_by  uuid;
  v_s          public.shift_sessions;
  v_pause_secs int;
  v_session_paused  boolean := false;
  v_session_resumed boolean := false;
  v_tz         text;
begin
  if not is_admin() then
    raise exception 'admin only' using errcode='42501';
  end if;
  if p_target_user_id is null then
    raise exception 'p_target_user_id is required' using errcode='22023';
  end if;
  if not exists (select 1 from public.users where id = p_target_user_id and status='active') then
    raise exception 'target user not found or inactive' using errcode='42501';
  end if;

  v_locked_at := case when p_locked then v_now else null end;
  v_locked_by := case when p_locked then v_uid else null end;

  select * into v_old from public.shift_configs where user_id = p_target_user_id;
  v_existed := found;
  v_tz := coalesce(v_old.timezone, 'Asia/Manila');

  insert into public.shift_configs (
    user_id, account_locked, account_locked_at, account_locked_by,
    account_lock_reason, hard_until, updated_at, updated_by
  ) values (
    p_target_user_id, p_locked, v_locked_at, v_locked_by,
    case when p_locked then 'admin' else null end,
    v_now + interval '14 days', v_now, v_uid
  )
  on conflict (user_id) do update set
    account_locked      = excluded.account_locked,
    account_locked_at   = excluded.account_locked_at,
    account_locked_by   = excluded.account_locked_by,
    account_lock_reason = case when p_locked then 'admin' else null end,
    updated_at          = v_now,
    updated_by          = v_uid;

  select * into v_s from public.shift_sessions
    where user_id = p_target_user_id
      and work_date = (v_now at time zone v_tz)::date
    for update;

  if found then
    if p_locked then
      if v_s.status in ('active','on_shift_break','on_bio_break') then
        update public.shift_sessions set
          status                   = 'locked',
          current_pause_started_at = v_now,
          current_pause_reason     = 'admin',
          locked_at                = v_now,
          locked_reason            = 'admin',
          locked_by                = v_uid,
          updated_at               = v_now
        where id = v_s.id;
        v_session_paused := true;
        insert into public.shift_events (session_id, user_id, type, by, meta) values (
          v_s.id, v_s.user_id, 'admin_override', v_uid,
          jsonb_build_object('action','account_lock_pause',
                             'paused_at', v_now,
                             'from_status', v_s.status)
        );
      end if;
    else
      if v_s.status = 'locked'
         and v_s.locked_reason in ('admin','bio_limit_exceeded')
         and v_s.current_pause_started_at is not null then
        v_pause_secs := greatest(0, extract(epoch from (v_now - v_s.current_pause_started_at))::int);
        update public.shift_sessions set
          status                   = 'active',
          paused_total_seconds     = paused_total_seconds + v_pause_secs,
          current_pause_started_at = null,
          current_pause_reason     = null,
          locked_at                = null,
          locked_reason            = null,
          locked_by                = null,
          updated_at               = v_now
        where id = v_s.id;
        v_session_resumed := true;
        insert into public.shift_events (session_id, user_id, type, by, meta) values (
          v_s.id, v_s.user_id, 'admin_override', v_uid,
          jsonb_build_object('action','account_unlock_resume',
                             'paused_seconds', v_pause_secs,
                             'prior_reason', v_s.locked_reason,
                             'resumed_at', v_now)
        );
      end if;
    end if;
  end if;

  insert into public.shift_events (session_id, user_id, type, by, meta) values (
    null, p_target_user_id, 'admin_override', v_uid,
    jsonb_build_object(
      'action', case when p_locked then 'account_lock' else 'account_unlock' end,
      'existed_before', v_existed,
      'old_locked', case when v_existed then v_old.account_locked else null end,
      'new_locked', p_locked,
      'session_paused', v_session_paused,
      'session_resumed', v_session_resumed
    )
  );

  return jsonb_build_object(
    'user_id', p_target_user_id,
    'account_locked', p_locked,
    'account_locked_at', v_locked_at,
    'account_locked_by', v_locked_by,
    'session_paused', v_session_paused,
    'session_resumed', v_session_resumed
  );
end;
$function$;

CREATE OR REPLACE FUNCTION public.shift_start()
 RETURNS jsonb
 LANGUAGE plpgsql SECURITY DEFINER SET search_path TO 'public'
AS $function$
declare
  v_uid uuid := auth.uid();
  v_s public.shift_sessions;
  v_cfg public.shift_configs;
  v_sched public.shift_schedules;
  v_local_today      date;
  v_local_weekday    int;
  v_scheduled_start  timestamptz := null;
  v_expected_end     timestamptz := null;
  v_seconds_late     int := null;
  v_late             boolean := false;
  v_late_mins        int := null;
  v_gate             jsonb;
begin
  if v_uid is null or not is_active_user() then
    raise exception 'not authenticated/active' using errcode='42501';
  end if;

  if exists (
    select 1 from public.shift_configs
     where user_id = v_uid and account_locked = true
  ) then
    raise exception 'account locked' using errcode='42501';
  end if;

  v_gate := public.shift_can_start();
  if (v_gate->>'can_start')::boolean = false then
    raise exception 'shift not startable yet: %', (v_gate->>'reason')
      using errcode='22023', detail = v_gate::text;
  end if;

  perform public.shift_get_or_create_today_session();
  select * into v_cfg from public.shift_configs where user_id = v_uid;
  select * into v_s from public.shift_sessions
    where user_id = v_uid
      and work_date = (now() at time zone coalesce(v_cfg.timezone,'Asia/Manila'))::date
    for update;
  if v_s.status <> 'not_started' then
    raise exception 'shift already %', v_s.status using errcode='22023';
  end if;

  v_local_today    := (now() at time zone coalesce(v_cfg.timezone,'Asia/Manila'))::date;
  v_local_weekday  := extract(dow from v_local_today)::int;
  select * into v_sched from public.shift_schedules
    where user_id = v_uid and weekday = v_local_weekday;
  if found and v_sched.enabled and v_sched.start_time_local is not null then
    v_scheduled_start := ((v_local_today::text || ' ' || v_sched.start_time_local::text)::timestamp
                          at time zone coalesce(v_cfg.timezone,'Asia/Manila'));
    v_expected_end := v_scheduled_start + (v_s.required_seconds || ' seconds')::interval;
    v_seconds_late := extract(epoch from (now() - v_scheduled_start))::int;
    if v_seconds_late > coalesce(v_cfg.late_start_threshold_seconds, 900) then
      v_late := true;
      v_late_mins := greatest(0, v_seconds_late / 60);
    end if;
  end if;

  update public.shift_sessions
     set status              = 'active',
         started_at          = now(),
         scheduled_start_at  = v_scheduled_start,
         expected_end_at     = v_expected_end,
         late_start_flag     = v_late,
         late_start_minutes  = case when v_late then v_late_mins else null end,
         updated_at          = now()
   where id = v_s.id
   returning * into v_s;

  insert into public.shift_events (session_id, user_id, type, by)
    values (v_s.id, v_uid, 'shift_start', v_uid);
  if v_late then
    insert into public.shift_events (session_id, user_id, type, by, meta)
      values (v_s.id, v_uid, 'late_start', v_uid,
              jsonb_build_object('minutes_late', v_late_mins,
                                 'scheduled_start_at', v_scheduled_start));
  end if;

  return jsonb_build_object(
    'session_id',          v_s.id,
    'started_at',          v_s.started_at,
    'scheduled_start_at',  v_scheduled_start,
    'expected_end_at',     v_expected_end,
    'late_start_flag',     v_late,
    'late_start_minutes',  v_late_mins
  );
end;
$function$;