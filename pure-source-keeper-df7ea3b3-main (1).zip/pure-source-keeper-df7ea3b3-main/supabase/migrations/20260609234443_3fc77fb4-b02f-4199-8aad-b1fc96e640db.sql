-- =====================================================================
-- Phase 11/12-a — shift_mode (auto|manual)
--
-- New per-user mode column on shift_configs that switches whole subsystems
-- on/off. Default = 'manual' so brand-new invited users never get trapped
-- in the 8h auto-complete pipeline. Existing managers with any enabled
-- schedule row are backfilled to 'auto' so their behavior is preserved
-- byte-for-byte.
--
-- Every CREATE OR REPLACE below starts from the LIVE function body
-- (pulled via pg_get_functiondef) and adds ONLY the minimal manual-mode
-- short-circuit. No other behavior is changed.
-- =====================================================================

-- 1) Column + check.
alter table public.shift_configs
  add column if not exists shift_mode text not null default 'manual';

do $$
begin
  if not exists (
    select 1 from pg_constraint where conname = 'shift_configs_shift_mode_chk'
  ) then
    alter table public.shift_configs
      add constraint shift_configs_shift_mode_chk
      check (shift_mode in ('auto','manual'));
  end if;
end $$;

comment on column public.shift_configs.shift_mode is
  '0076: per-user shift mode. ''auto'' = full scheduled system (gating, 8h timer, period locks, break-overstay, bio-7 suspension). ''manual'' = no automatic enforcement; admin manual lock (Phase 10) still applies.';

-- 2) Backfill: anyone with at least one enabled schedule row → 'auto'.
update public.shift_configs c
   set shift_mode = 'auto'
 where shift_mode = 'manual'
   and exists (
     select 1 from public.shift_schedules s
      where s.user_id = c.user_id and s.enabled = true
   );

-- =====================================================================
-- 3) shift_can_start — add manual short-circuit immediately after v_cfg
--    load. Everything below the new block is the live 0064/0070 body.
-- =====================================================================
create or replace function public.shift_can_start()
returns jsonb
language plpgsql
stable
security definer
set search_path = public
as $$
declare
  v_uid uuid := auth.uid();
  v_cfg public.shift_configs;
  v_tz  text;
  v_local_now   timestamp;
  v_local_today date;
  v_local_time  time;
  v_local_wd    int;
  v_sched       public.shift_schedules;
  v_has_any_sched boolean;
  v_today_start_ts timestamptz;
  v_next_ts        timestamptz;
begin
  if v_uid is null or not is_active_user() then
    raise exception 'not authenticated/active' using errcode='42501';
  end if;

  select * into v_cfg from public.shift_configs where user_id = v_uid;
  v_tz := coalesce(v_cfg.timezone, 'Asia/Manila');

  -- 0076 — MANUAL MODE: no gate, ever. Also covers the "config not
  -- found" case (v_cfg.shift_mode is null) because the column default
  -- is 'manual' for any auto-created config row.
  if coalesce(v_cfg.shift_mode, 'manual') = 'manual' then
    return jsonb_build_object(
      'can_start',     true,
      'reason',        'ok',
      'next_shift_at', null,
      'timezone',      v_tz
    );
  end if;

  v_local_now   := (now() at time zone v_tz);
  v_local_today := v_local_now::date;
  v_local_time  := v_local_now::time;
  v_local_wd    := extract(dow from v_local_today)::int;

  -- Legacy fallback: if the user has no schedule rows at all (or no
  -- enabled day in the next 14 days), don't gate.
  select exists (
    select 1 from public.shift_schedules
     where user_id = v_uid and enabled = true and start_time_local is not null
  ) into v_has_any_sched;
  if not v_has_any_sched then
    return jsonb_build_object(
      'can_start', true, 'reason', 'ok',
      'next_shift_at', null, 'timezone', v_tz
    );
  end if;

  if v_cfg.shift_start_date is not null and v_local_today < v_cfg.shift_start_date then
    v_next_ts := public._shift_next_scheduled_at(v_uid, v_cfg.shift_start_date, v_tz);
    return jsonb_build_object(
      'can_start', false, 'reason', 'before_start_date',
      'next_shift_at', v_next_ts, 'timezone', v_tz
    );
  end if;

  select * into v_sched from public.shift_schedules
    where user_id = v_uid and weekday = v_local_wd;

  if not found or not v_sched.enabled or v_sched.start_time_local is null then
    v_next_ts := public._shift_next_scheduled_at(v_uid, v_local_today + 1, v_tz);
    return jsonb_build_object(
      'can_start', false, 'reason', 'day_off',
      'next_shift_at', v_next_ts, 'timezone', v_tz
    );
  end if;

  v_today_start_ts := ((v_local_today::text || ' ' || v_sched.start_time_local::text)::timestamp
                       at time zone v_tz);
  if v_local_time < v_sched.start_time_local then
    return jsonb_build_object(
      'can_start', false, 'reason', 'before_shift_time',
      'next_shift_at', v_today_start_ts, 'timezone', v_tz
    );
  end if;

  return jsonb_build_object(
    'can_start', true, 'reason', 'ok',
    'next_shift_at', v_today_start_ts, 'timezone', v_tz
  );
end;
$$;
revoke all on function public.shift_can_start() from public;
grant execute on function public.shift_can_start() to authenticated;

-- =====================================================================
-- 4) shift_get_or_create_today_session — for manual users, seed the
--    daily row with required_seconds=0 so the auto-complete pipeline
--    never fires. Rest of body is live 0063 verbatim.
-- =====================================================================
create or replace function public.shift_get_or_create_today_session()
returns public.shift_sessions
language plpgsql
security definer
set search_path = public
as $$
declare
  v_uid             uuid := auth.uid();
  v_today           date;
  v_session         public.shift_sessions;
  v_config          public.shift_configs;
  v_sched           public.shift_schedules;
  v_weekday         int;
  v_period          int;
  v_required        int;
  v_effective_mode  text;
begin
  if v_uid is null then
    raise exception 'Not authenticated' using errcode = '42501';
  end if;
  if not is_active_user() then
    raise exception 'User is not active' using errcode = '42501';
  end if;

  v_today := (now() at time zone 'UTC')::date;

  select * into v_session
    from public.shift_sessions
   where user_id = v_uid and work_date = v_today;
  if found then return v_session; end if;

  select * into v_config from public.shift_configs where user_id = v_uid;
  if not found then
    insert into public.shift_configs (user_id, hard_until) values
      (v_uid, now() + interval '14 days')
    on conflict (user_id) do nothing
    returning * into v_config;
    if v_config is null then
      select * into v_config from public.shift_configs where user_id = v_uid;
    end if;
  end if;

  v_weekday := extract(dow from v_today)::int;
  select * into v_sched from public.shift_schedules
   where user_id = v_uid and weekday = v_weekday;
  v_required := coalesce(v_sched.required_seconds, v_config.required_seconds_default);
  if found and not v_sched.enabled then
    v_required := 0;
  end if;

  -- 0076 — MANUAL MODE: no required timer. required_seconds=0 makes
  -- shift_complete_if_due a no-op (see #6), and the 0/period math
  -- still works in shift_tick (period_85_due / period_lock_due are
  -- additionally suppressed for manual sessions there).
  if coalesce(v_config.shift_mode, 'manual') = 'manual' then
    v_required := 0;
  end if;

  v_effective_mode := case
    when v_config.hard_until is not null and v_config.hard_until > now() then 'hard'
    else v_config.mode
  end;

  v_period := public._shift_period_seconds(v_effective_mode);

  insert into public.shift_sessions (
    user_id, work_date, status, mode, period_seconds, required_seconds
  ) values (
    v_uid, v_today, 'not_started', v_effective_mode, v_period, v_required
  )
  on conflict (user_id, work_date) do nothing
  returning * into v_session;

  if v_session.id is null then
    select * into v_session from public.shift_sessions
     where user_id = v_uid and work_date = v_today;
  end if;

  return v_session;
end;
$$;

-- =====================================================================
-- 5) shift_complete_if_due — guard against required_seconds <= 0
--    (manual mode). Otherwise live body verbatim.
-- =====================================================================
create or replace function public.shift_complete_if_due(p_session_id uuid)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  v_uid     uuid := auth.uid();
  v_s       public.shift_sessions;
  v_elapsed int;
  v_was     text;
begin
  if v_uid is null then
    null;
  else
    select * into v_s from public.shift_sessions where id = p_session_id for update;
    if not found then raise exception 'session not found' using errcode='02000'; end if;
    if v_s.user_id <> v_uid and not is_admin() then
      raise exception 'forbidden' using errcode='42501';
    end if;
  end if;

  if v_uid is null then
    select * into v_s from public.shift_sessions where id = p_session_id for update;
    if not found then raise exception 'session not found' using errcode='02000'; end if;
  end if;

  if v_s.status = 'completed' then
    return jsonb_build_object(
      'session_id', v_s.id, 'already_completed', true, 'completed_at', v_s.completed_at
    );
  end if;

  -- 0076 — MANUAL MODE: required_seconds=0 means "no timer" — never
  -- auto-complete. Returning due=false keeps the client tick happy
  -- without flipping the session to 'completed'.
  if v_s.required_seconds is null or v_s.required_seconds <= 0 then
    return jsonb_build_object(
      'session_id',        v_s.id,
      'already_completed', false,
      'due',               false,
      'reason',            'manual_mode',
      'elapsed_seconds',   0,
      'remaining_seconds', 0
    );
  end if;

  if v_s.started_at is null then
    v_elapsed := 0;
  else
    v_elapsed := greatest(0,
      extract(epoch from (clock_timestamp() - v_s.started_at))::int
      - v_s.paused_total_seconds
      - case when v_s.current_pause_started_at is not null
             then extract(epoch from (clock_timestamp() - v_s.current_pause_started_at))::int
             else 0 end
    );
  end if;

  if v_elapsed < v_s.required_seconds then
    return jsonb_build_object(
      'session_id', v_s.id, 'already_completed', false, 'due', false,
      'elapsed_seconds', v_elapsed,
      'remaining_seconds', v_s.required_seconds - v_elapsed
    );
  end if;

  if v_s.status not in ('active','on_shift_break','on_bio_break') then
    return jsonb_build_object(
      'session_id', v_s.id, 'already_completed', false, 'due', true,
      'completed', false, 'reason', 'wrong_status', 'status', v_s.status
    );
  end if;

  v_was := v_s.status;

  update public.shift_sessions
     set status        = 'completed',
         completed_at  = now(),
         locked_reason = 'shift_complete',
         current_break_started_at = null,
         current_break_kind       = null,
         updated_at    = now()
   where id = v_s.id;

  insert into public.shift_events (session_id, user_id, type, by, meta)
    values (v_s.id, v_s.user_id, 'shift_complete', v_uid,
            jsonb_build_object(
              'worked_seconds', v_elapsed, 'from_status', v_was, 'auto_swept', false
            ));

  return jsonb_build_object(
    'session_id',        v_s.id,
    'already_completed', false,
    'due',               true,
    'completed',         true,
    'completed_at',      now()
  );
end;
$$;

-- =====================================================================
-- 6) shift_self_period_lock — manual users never auto-lock. Skip
--    branch at top, rest of live 0075 body preserved.
-- =====================================================================
create or replace function public.shift_self_period_lock(p_session_id uuid)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  v_uid uuid := auth.uid();
  v_s   public.shift_sessions;
  v_old_cpi int;
  v_user_mode text;
begin
  if v_uid is null then
    raise exception 'Not authenticated' using errcode='42501';
  end if;
  select * into v_s from public.shift_sessions where id = p_session_id for update;
  if not found then raise exception 'session not found' using errcode='02000'; end if;
  if v_s.user_id <> v_uid and not is_admin() then
    raise exception 'forbidden' using errcode='42501';
  end if;

  -- 0076 — MANUAL MODE: no automatic period lock, ever. Return a
  -- no-op shaped like 'already_locked' so the client's idempotent
  -- caller (ShiftDriver lockedFiredRef) treats it as handled.
  select coalesce(c.shift_mode, 'manual') into v_user_mode
    from public.shift_configs c where c.user_id = v_s.user_id;
  if v_user_mode = 'manual' then
    return jsonb_build_object(
      'session_id', v_s.id, 'status', v_s.status,
      'already_locked', true, 'manual_mode', true
    );
  end if;

  if v_s.status = 'locked' then
    return jsonb_build_object('session_id', v_s.id, 'status', 'locked', 'already_locked', true);
  end if;
  if v_s.status not in ('active','on_shift_break','on_bio_break') then
    raise exception 'session not lockable from status %', v_s.status using errcode='22023';
  end if;

  if v_s.skip_next_period_lock then
    v_old_cpi := v_s.current_period_index;
    update public.shift_sessions
       set skip_next_period_lock = false,
           current_period_index  = current_period_index + 1,
           updated_at            = now()
     where id = v_s.id;
    insert into public.shift_events (session_id, user_id, type, by, meta) values
      (v_s.id, v_s.user_id, 'admin_override', null,
        jsonb_build_object('action','period_lock_skipped',
                           'period_index', v_old_cpi,
                           'new_current_period_index', v_old_cpi + 1,
                           'skip_armed_by', v_s.skip_next_period_lock_set_by,
                           'skip_armed_at', v_s.skip_next_period_lock_set_at));
    return jsonb_build_object(
      'session_id', v_s.id, 'status', v_s.status,
      'skipped', true, 'already_locked', false
    );
  end if;

  update public.shift_sessions
     set status = 'locked',
         current_pause_started_at = now(),
         current_pause_reason     = 'period_lock',
         locked_at                = now(),
         locked_reason            = 'period_lock',
         locked_by                = null,
         updated_at               = now()
   where id = v_s.id;
  insert into public.shift_events (session_id, user_id, type, by, meta)
    values (v_s.id, v_s.user_id, 'period_lock', null,
            jsonb_build_object('reason','period_lock','period_index', v_s.current_period_index));
  return jsonb_build_object('session_id', v_s.id, 'status', 'locked', 'already_locked', false);
end;
$$;

-- =====================================================================
-- 7) shift_tick — surface shift_mode in the payload AND suppress the
--    period_85_due / period_lock_due flags for manual users so the
--    client never tries to lock them. Rest is live body verbatim.
-- =====================================================================
create or replace function public.shift_tick(p_session_id uuid)
returns jsonb
language plpgsql
stable
security definer
set search_path = public
as $$
declare
  v_uid uuid := auth.uid();
  v_s public.shift_sessions;
  v_cfg public.shift_configs;
  v_admin boolean;
  v_elapsed int;
  v_remain int;
  v_period_start int;
  v_period_end   int;
  v_85_threshold int;
  v_85_due boolean;
  v_lock_due boolean;
  v_break_elapsed int;
  v_eff_max int;
  v_shift_break_allowance int;
  v_overstay_grace int;
  v_user_mode text;
begin
  if v_uid is null then raise exception 'not authenticated' using errcode='42501'; end if;
  v_admin := is_admin();
  select * into v_s from public.shift_sessions where id = p_session_id;
  if not found then raise exception 'session not found' using errcode='02000'; end if;
  if v_s.user_id <> v_uid and not v_admin then raise exception 'forbidden' using errcode='42501'; end if;
  select * into v_cfg from public.shift_configs where user_id = v_s.user_id;
  v_user_mode := coalesce(v_cfg.shift_mode, 'manual');

  if v_s.started_at is null then
    v_elapsed := 0;
  else
    v_elapsed := greatest(0,
      extract(epoch from (clock_timestamp() - v_s.started_at))::int
      - v_s.paused_total_seconds
      - case when v_s.current_pause_started_at is not null
             then extract(epoch from (clock_timestamp() - v_s.current_pause_started_at))::int
             else 0 end
    );
  end if;
  v_remain       := greatest(0, v_s.required_seconds - v_elapsed);
  v_period_start := v_s.current_period_index * v_s.period_seconds;
  v_period_end   := (v_s.current_period_index + 1) * v_s.period_seconds;
  v_85_threshold := v_period_start + (v_s.period_seconds * 0.85)::int;
  v_85_due := v_elapsed >= v_85_threshold
              and v_s.period_85_last_index_alerted < v_s.current_period_index
              and v_s.status in ('active','on_shift_break','on_bio_break');
  v_lock_due := v_elapsed >= v_period_end
              and v_s.status in ('active','on_shift_break','on_bio_break');

  -- 0076 — MANUAL MODE: no period alerts, no auto-locks. Force both
  -- gates off; client side-effects (mark85, self_period_lock,
  -- complete_if_due) consequently never fire.
  if v_user_mode = 'manual' then
    v_85_due   := false;
    v_lock_due := false;
  end if;

  v_break_elapsed := case
    when v_s.current_break_started_at is null then 0
    else greatest(0, extract(epoch from (clock_timestamp() - v_s.current_break_started_at))::int)
  end;
  v_eff_max := coalesce(v_cfg.bio_break_max_per_day, 7);
  v_shift_break_allowance := coalesce(v_cfg.shift_break_seconds, 1800);
  v_overstay_grace := coalesce(v_cfg.shift_break_overstay_grace_seconds, 900);

  return jsonb_build_object(
    'session_id',                     v_s.id,
    'user_id',                        v_s.user_id,
    'status',                         v_s.status,
    'started_at',                     v_s.started_at,
    'work_date',                      v_s.work_date,
    'mode',                           v_s.mode,
    'shift_mode',                     v_user_mode,
    'period_seconds',                 v_s.period_seconds,
    'required_seconds',               v_s.required_seconds,
    'elapsed_seconds',                v_elapsed,
    'remaining_seconds',              v_remain,
    'paused_total_seconds',           v_s.paused_total_seconds,
    'current_period_index',           v_s.current_period_index,
    'current_period_start_seconds',   v_period_start,
    'current_period_end_seconds',     v_period_end,
    'period_85_threshold_seconds',    v_85_threshold,
    'period_85_due',                  v_85_due,
    'period_lock_due',                v_lock_due,
    'current_break_kind',             v_s.current_break_kind,
    'current_break_started_at',       v_s.current_break_started_at,
    'current_break_elapsed_seconds',  v_break_elapsed,
    'bio_break_count_today',          v_s.bio_break_count_today,
    'bio_break_total_seconds_today',  v_s.bio_break_total_seconds_today,
    'bio_break_admin_grants_today',   v_s.bio_break_admin_grants_today,
    'bio_break_max_per_day',          v_cfg.bio_break_max_per_day,
    'bio_break_warn_count',           v_cfg.bio_break_warn_count,
    'bio_break_warn_total_seconds',   v_cfg.bio_break_warn_total_seconds,
    'bio_break_max_seconds_each',     v_cfg.bio_break_max_seconds_each,
    'bio_limit_reached',              (v_user_mode <> 'manual'
                                        and v_s.bio_break_count_today >= v_eff_max),
    'locked_at',                      v_s.locked_at,
    'locked_reason',                  v_s.locked_reason,
    'completed_at',                   v_s.completed_at,
    'scheduled_start_at',             v_s.scheduled_start_at,
    'expected_end_at',                v_s.expected_end_at,
    'late_start_flag',                v_s.late_start_flag,
    'late_start_minutes',             v_s.late_start_minutes,
    'early_end_flag',                 v_s.early_end_flag,
    'early_end_minutes',              v_s.early_end_minutes,
    'shift_break_count_today',        v_s.shift_break_count_today,
    'shift_break_used_today',         v_s.shift_break_count_today >= 1,
    'shift_break_seconds',            v_shift_break_allowance,
    'shift_break_overstay',           (v_s.status = 'on_shift_break'
                                        and v_s.current_break_kind = 'shift'
                                        and v_break_elapsed >= v_shift_break_allowance),
    'shift_break_overstay_seconds',   greatest(0, v_break_elapsed - v_shift_break_allowance),
    'shift_break_frozen',             coalesce(v_s.current_pause_reason = 'break_overstay', false),
    'shift_break_overstay_grace_seconds', v_overstay_grace,
    'skip_next_period_lock',          v_s.skip_next_period_lock,
    'now',                            clock_timestamp()
  );
end;
$$;

-- =====================================================================
-- 8) shift_my_account_lock — surface shift_mode.
-- =====================================================================
create or replace function public.shift_my_account_lock()
returns jsonb
language sql
stable
security definer
set search_path = public
as $$
  select jsonb_build_object(
    'account_locked',      coalesce(c.account_locked, false),
    'account_locked_at',   c.account_locked_at,
    'account_lock_reason', c.account_lock_reason,
    'shift_mode',          coalesce(c.shift_mode, 'manual')
  )
  from (
    select cfg.account_locked, cfg.account_locked_at, cfg.account_lock_reason, cfg.shift_mode
      from public.shift_configs cfg
     where cfg.user_id = auth.uid()
    union all
    select false, null, null, 'manual'
    where not exists (select 1 from public.shift_configs where user_id = auth.uid())
  ) c
  limit 1;
$$;

-- =====================================================================
-- 9) shift_take_bio_break — manual users have NO hard cap. Auto users
--    keep the existing tier-7 hard cap. Rest of 0067 body verbatim.
-- =====================================================================
create or replace function public.shift_take_bio_break(p_session_id uuid)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  v_uid uuid := auth.uid();
  v_s   public.shift_sessions;
  v_cfg public.shift_configs;
  v_effective_max int;
  v_user_mode text;
begin
  if v_uid is null then raise exception 'not authenticated' using errcode='42501'; end if;
  select * into v_s from public.shift_sessions where id = p_session_id for update;
  if not found then raise exception 'session not found' using errcode='02000'; end if;
  if v_s.user_id <> v_uid and not is_admin() then
    raise exception 'forbidden' using errcode='42501';
  end if;
  if v_s.status <> 'active' then
    raise exception 'cannot bio-break from %', v_s.status using errcode='22023';
  end if;
  select * into v_cfg from public.shift_configs where user_id = v_s.user_id;
  v_user_mode := coalesce(v_cfg.shift_mode, 'manual');

  v_effective_max := coalesce(v_cfg.bio_break_max_per_day, 7);

  -- 0076 — MANUAL MODE: no hard cap on bio breaks. Skip the limit
  -- check entirely; the count is still incremented in shift_end_break
  -- for visibility but no enforcement fires.
  if v_user_mode <> 'manual' and v_s.bio_break_count_today >= v_effective_max then
    return jsonb_build_object(
      'session_id',   v_s.id,
      'status',       v_s.status,
      'limit_reached', true,
      'count_today',  v_s.bio_break_count_today,
      'max_per_day',  v_cfg.bio_break_max_per_day
    );
  end if;

  update public.shift_sessions
     set status                   = 'on_bio_break',
         current_break_started_at = now(),
         current_break_kind       = 'bio',
         updated_at               = now()
   where id = v_s.id;
  insert into public.shift_events (session_id, user_id, type, by, meta)
    values (v_s.id, v_s.user_id, 'bio_break_start', v_uid,
            jsonb_build_object('count_so_far', v_s.bio_break_count_today));
  return jsonb_build_object(
    'session_id',    v_s.id,
    'status',        'on_bio_break',
    'limit_reached', false
  );
end;
$$;

-- =====================================================================
-- 10) shift_end_break — for manual users, skip the tier-7 suspension
--     block entirely. Everything else (bio cap recording, shift-break
--     overstay credit, audit events) is preserved byte-for-byte from
--     live 0067 body.
-- =====================================================================
create or replace function public.shift_end_break(p_session_id uuid)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  v_uid uuid := auth.uid();
  v_s   public.shift_sessions;
  v_cfg public.shift_configs;
  v_kind text;
  v_actual int;
  v_recorded int;
  v_exceeded boolean := false;
  v_freeze_dur int := 0;
  v_shift_allowance int := 1800;
  v_new_bio_count int;
  v_bio_cap int;
  v_now timestamptz := clock_timestamp();
  v_suspended boolean := false;
  v_user_mode text;
begin
  if v_uid is null then raise exception 'not authenticated' using errcode='42501'; end if;
  select * into v_s from public.shift_sessions where id = p_session_id for update;
  if not found then raise exception 'session not found' using errcode='02000'; end if;
  if v_s.user_id <> v_uid and not is_admin() then
    raise exception 'forbidden' using errcode='42501';
  end if;
  if v_s.status not in ('on_shift_break','on_bio_break') then
    raise exception 'not on break (status=%)', v_s.status using errcode='22023';
  end if;

  v_kind   := v_s.current_break_kind;
  v_actual := greatest(0, extract(epoch from (clock_timestamp() - coalesce(v_s.current_break_started_at, clock_timestamp())))::int);
  v_recorded := v_actual;

  if v_kind = 'bio' then
    select * into v_cfg from public.shift_configs where user_id = v_s.user_id;
    v_user_mode := coalesce(v_cfg.shift_mode, 'manual');
    if v_actual > coalesce(v_cfg.bio_break_max_seconds_each, 900) then
      v_recorded := coalesce(v_cfg.bio_break_max_seconds_each, 900);
      v_exceeded := true;
    end if;
    update public.shift_sessions
       set status                        = 'active',
           current_break_started_at      = null,
           current_break_kind            = null,
           bio_break_count_today         = bio_break_count_today + 1,
           bio_break_total_seconds_today = bio_break_total_seconds_today + v_recorded,
           updated_at                    = now()
     where id = v_s.id
     returning bio_break_count_today into v_new_bio_count;
    insert into public.shift_events (session_id, user_id, type, by, meta)
      values (v_s.id, v_s.user_id,
              case when v_exceeded then 'bio_break_auto_end' else 'bio_break_end' end,
              v_uid, jsonb_build_object(
                'duration_seconds_actual',   v_actual,
                'duration_seconds_recorded', v_recorded,
                'exceeded_cap',              v_exceeded));

    -- 0076 — MANUAL MODE: no tier-7 hard suspension. Auto users keep
    -- the existing P5a behavior verbatim.
    v_bio_cap := coalesce(v_cfg.bio_break_max_per_day, 7);
    if v_user_mode <> 'manual' and v_new_bio_count >= v_bio_cap then
      insert into public.shift_configs (
        user_id, account_locked, account_locked_at, account_locked_by,
        account_lock_reason, updated_at, updated_by
      ) values (
        v_s.user_id, true, v_now, null,
        'bio_limit_exceeded', v_now, null
      )
      on conflict (user_id) do update set
        account_locked      = true,
        account_locked_at   = v_now,
        account_locked_by   = null,
        account_lock_reason = 'bio_limit_exceeded',
        updated_at          = v_now;

      update public.shift_sessions
         set status                   = 'locked',
             current_pause_started_at = v_now,
             current_pause_reason     = 'bio_limit_exceeded',
             locked_at                = v_now,
             locked_reason            = 'bio_limit_exceeded',
             locked_by                = null,
             updated_at               = v_now
       where id = v_s.id;

      insert into public.shift_events (session_id, user_id, type, by, meta)
        values (v_s.id, v_s.user_id, 'admin_override', null,
                jsonb_build_object('action','bio_limit_exceeded_lock',
                                   'count', v_new_bio_count,
                                   'cap',   v_bio_cap,
                                   'paused_at', v_now));
      v_suspended := true;
    end if;
  else
    select * into v_cfg from public.shift_configs where user_id = v_s.user_id;
    v_shift_allowance := coalesce(v_cfg.shift_break_seconds, 1800);
    v_recorded := least(v_actual, v_shift_allowance);
    if v_s.current_pause_reason = 'break_overstay'
       and v_s.current_pause_started_at is not null then
      v_freeze_dur := greatest(0,
        extract(epoch from (clock_timestamp() - v_s.current_pause_started_at))::int);
    end if;
    update public.shift_sessions
       set status                   = 'active',
           current_break_started_at = null,
           current_break_kind       = null,
           paused_total_seconds     = paused_total_seconds + v_freeze_dur,
           current_pause_started_at = null,
           current_pause_reason     = null,
           updated_at               = now()
     where id = v_s.id;
    insert into public.shift_events (session_id, user_id, type, by, meta)
      values (v_s.id, v_s.user_id, 'shift_break_end', v_uid,
              jsonb_build_object(
                'duration_seconds_actual',     v_actual,
                'duration_seconds_recorded',   v_recorded,
                'overstay_seconds',            greatest(0, v_actual - v_shift_allowance),
                'frozen_seconds_credited',     v_freeze_dur,
                'allowance_seconds',           v_shift_allowance));
  end if;

  return jsonb_build_object(
    'session_id',                v_s.id,
    'status',                    case when v_suspended then 'locked' else 'active' end,
    'kind',                      v_kind,
    'duration_seconds_actual',   v_actual,
    'duration_seconds_recorded', v_recorded,
    'exceeded_cap',              v_exceeded,
    'bio_limit_suspended',       v_suspended,
    'bio_break_count_today',     v_new_bio_count
  );
end;
$$;

-- =====================================================================
-- 11) shift_break_sweep — exclude manual users from BOTH the LOCK
--     and FREEZE passes, AND from the bio-6 admin alert pass. Live
--     0073 body preserved otherwise.
-- =====================================================================
create or replace function public.shift_break_sweep()
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  v_now timestamptz := clock_timestamp();
  v_rec record;
  v_allowance int;
  v_grace int;
  v_break_elapsed int;
  v_freeze_dur int;
  v_recorded int;
  v_frozen_count int := 0;
  v_locked_count int := 0;
  v_emailed_count int := 0;
  v_bio6_count int := 0;
  v_secret text;
  v_url text;
  v_email_mark jsonb;
  v_today_utc date := (v_now at time zone 'UTC')::date;
begin
  select value into v_secret from private.config where key='cron_shared_secret';
  select value into v_url    from private.config where key='app_base_url';
  if v_url is null then v_url := 'https://p-m-system.vercel.app'; end if;

  -- PASS 1 — LOCK
  for v_rec in
    select s.id, s.user_id, s.paused_total_seconds,
           s.current_break_started_at, s.current_pause_started_at, s.current_pause_reason,
           coalesce(c.shift_break_seconds, 1800) as allowance,
           coalesce(c.shift_break_overstay_grace_seconds, 900) as grace
      from public.shift_sessions s
      join public.shift_configs c on c.user_id = s.user_id
     where s.status = 'on_shift_break'
       and s.current_break_kind = 'shift'
       and s.current_break_started_at is not null
       and coalesce(c.shift_mode, 'manual') = 'auto'   -- 0076: skip manual users
       and greatest(0, extract(epoch from (v_now - s.current_break_started_at))::int)
           >= coalesce(c.shift_break_seconds, 1800) + coalesce(c.shift_break_overstay_grace_seconds, 900)
     for update of s
  loop
    v_allowance := v_rec.allowance;
    v_grace     := v_rec.grace;
    v_break_elapsed := greatest(0, extract(epoch from (v_now - v_rec.current_break_started_at))::int);
    v_freeze_dur := case
      when v_rec.current_pause_reason = 'break_overstay'
       and v_rec.current_pause_started_at is not null
      then greatest(0, extract(epoch from (v_now - v_rec.current_pause_started_at))::int)
      else 0 end;
    v_recorded := least(v_break_elapsed, v_allowance);

    update public.shift_sessions set
      status='locked', current_break_started_at=null, current_break_kind=null,
      paused_total_seconds = paused_total_seconds + v_freeze_dur,
      current_pause_started_at = v_now, current_pause_reason = 'break_overstay',
      locked_at = v_now, locked_reason = 'break_overstay', locked_by = null,
      updated_at = v_now
     where id = v_rec.id;

    insert into public.shift_events (session_id, user_id, type, by, meta) values
      (v_rec.id, v_rec.user_id, 'shift_break_end', null,
        jsonb_build_object(
          'duration_seconds_actual',   v_break_elapsed,
          'duration_seconds_recorded', v_recorded,
          'overstay_seconds',          greatest(0, v_break_elapsed - v_allowance),
          'frozen_seconds_credited',   v_freeze_dur,
          'allowance_seconds',         v_allowance,
          'ended_by',                  'overstay_lock_sweep',
          'sweep',                     true)),
      (v_rec.id, v_rec.user_id, 'shift_break_overstay_lock', null,
        jsonb_build_object(
          'break_elapsed_seconds',   v_break_elapsed,
          'allowance_seconds',       v_allowance,
          'grace_seconds',           v_grace,
          'frozen_seconds_credited', v_freeze_dur,
          'sweep',                   true));

    v_locked_count := v_locked_count + 1;

    insert into public.notifications
      (recipient_id, actor_id, type, board_id, item_id, update_id, is_read)
      select u.id, v_rec.user_id, 'shift_admin_alert', null, null, null, false
        from public.users u
       where u.status='active' and (u.role='admin' or u.is_super_admin=true);

    select public.shift_mark_overstay_lock_emailed(v_rec.id) into v_email_mark;
    if coalesce((v_email_mark->>'emailed_now')::boolean, false) then
      v_emailed_count := v_emailed_count + 1;
      if v_secret is not null and v_secret <> '' then
        begin
          perform net.http_post(
            url     := v_url || '/api/shift-alert-email',
            body    := jsonb_build_object(
                         'session_id', v_rec.id::text,
                         'kind',       'break_overstay_lock'),
            headers := jsonb_build_object(
                         'Content-Type',  'application/json',
                         'X-Cron-Secret', v_secret),
            timeout_milliseconds := 5000
          );
        exception when others then
          insert into public.shift_events (session_id, user_id, type, by, meta) values
            (v_rec.id, v_rec.user_id, 'admin_override', null,
              jsonb_build_object('action','sweep_email_http_post_failed',
                                 'sweep', true, 'sqlerrm', sqlerrm));
        end;
      else
        insert into public.shift_events (session_id, user_id, type, by, meta) values
          (v_rec.id, v_rec.user_id, 'admin_override', null,
            jsonb_build_object('action','sweep_email_skipped_no_secret','sweep',true));
      end if;
    end if;
  end loop;

  -- PASS 2 — FREEZE
  for v_rec in
    select s.id, s.user_id, s.current_break_started_at,
           coalesce(c.shift_break_seconds, 1800) as allowance
      from public.shift_sessions s
      join public.shift_configs c on c.user_id = s.user_id
     where s.status = 'on_shift_break'
       and s.current_break_kind = 'shift'
       and s.current_break_started_at is not null
       and s.current_pause_started_at is null
       and coalesce(c.shift_mode, 'manual') = 'auto'   -- 0076
       and greatest(0, extract(epoch from (v_now - s.current_break_started_at))::int)
           >= coalesce(c.shift_break_seconds, 1800)
     for update of s
  loop
    v_allowance := v_rec.allowance;
    v_break_elapsed := greatest(0, extract(epoch from (v_now - v_rec.current_break_started_at))::int);
    update public.shift_sessions set
      current_pause_started_at = v_now,
      current_pause_reason     = 'break_overstay',
      updated_at               = v_now
     where id = v_rec.id;
    insert into public.shift_events (session_id, user_id, type, by, meta) values
      (v_rec.id, v_rec.user_id, 'shift_break_overstay_freeze', null,
        jsonb_build_object('break_elapsed_seconds', v_break_elapsed,
                           'allowance_seconds',     v_allowance,
                           'sweep',                 true));
    v_frozen_count := v_frozen_count + 1;
  end loop;

  -- PASS 3 — BIO-6 ADMIN ALERT
  for v_rec in
    select s.id, s.user_id
      from public.shift_sessions s
      join public.shift_configs c on c.user_id = s.user_id
     where s.bio_break_count_today >= 6
       and s.bio6_notified_at is null
       and s.work_date = v_today_utc
       and coalesce(c.shift_mode, 'manual') = 'auto'   -- 0076
     for update of s
  loop
    insert into public.notifications
      (recipient_id, actor_id, type, board_id, item_id, update_id, is_read)
      select u.id, v_rec.user_id, 'shift_admin_alert', null, null, null, false
        from public.users u
       where u.status='active' and (u.role='admin' or u.is_super_admin=true);
    update public.shift_sessions set bio6_notified_at = v_now where id = v_rec.id;
    v_bio6_count := v_bio6_count + 1;
  end loop;

  return jsonb_build_object(
    'frozen_count',  v_frozen_count,
    'locked_count',  v_locked_count,
    'emailed_count', v_emailed_count,
    'bio6_count',    v_bio6_count
  );
end;
$$;

-- =====================================================================
-- 12) accept_invite — provision a shift_configs row (mode='manual')
--     for every newly accepted user. Live 0170750 body preserved; only
--     the new insert is added near the end before the return.
-- =====================================================================
create or replace function public.accept_invite(p_token text, p_full_name text, p_password text)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  v_invite     record;
  v_user_id    uuid := gen_random_uuid();
  v_base       text;
  v_username   text;
  v_full_name  text;
  v_email      text;
  v_ws_id      uuid;
begin
  select * into v_invite from public.invites where token = p_token for update;
  if not found                       then raise exception 'Invite link not found' using errcode='42501'; end if;
  if v_invite.revoked_at is not null then raise exception 'This invite was revoked' using errcode='42501'; end if;
  if v_invite.used_at    is not null then raise exception 'This invite has already been used' using errcode='42501'; end if;
  if v_invite.expires_at is not null and v_invite.expires_at <= now() then
    raise exception 'This invite has expired' using errcode='42501';
  end if;

  if p_password is null or length(p_password) < 8 then
    raise exception 'Password must be at least 8 characters' using errcode='22023';
  end if;

  if v_invite.invitee_email is not null and position('@' in v_invite.invitee_email) > 0 then
    v_base := split_part(v_invite.invitee_email, '@', 1);
  else
    v_base := coalesce(nullif(trim(p_full_name), ''), '');
  end if;

  v_username := public._generate_unique_username(v_base);

  if v_username !~ '^[a-z0-9_]{2,32}$' then
    raise exception 'Could not derive a valid username' using errcode='22023';
  end if;

  if v_invite.invitee_email is not null then
    if exists (
      select 1 from public.users
      where lower(email) = lower(v_invite.invitee_email)
        and status = 'active'
    ) then
      raise exception 'An active account already uses this email' using errcode='23505';
    end if;

    update public.users
       set email = 'freed_' || id::text || '@pms.internal'
     where lower(email) = lower(v_invite.invitee_email)
       and status <> 'active';

    update auth.users
       set email = 'freed_' || id::text || '@pms.internal'
     where lower(email) = lower(v_invite.invitee_email)
       and id not in (select id from public.users where status = 'active');

    v_email := lower(v_invite.invitee_email);
  else
    v_email := v_username || '@pms.internal';
  end if;

  v_full_name := coalesce(
    nullif(trim(coalesce(v_invite.invitee_name, '')), ''),
    nullif(trim(coalesce(p_full_name, '')), ''),
    v_username
  );

  insert into auth.users (
    instance_id, id, aud, role, email, encrypted_password, email_confirmed_at,
    raw_app_meta_data, raw_user_meta_data, created_at, updated_at,
    confirmation_token, recovery_token, email_change_token_new, email_change,
    is_sso_user, is_anonymous
  ) values (
    '00000000-0000-0000-0000-000000000000',
    v_user_id, 'authenticated', 'authenticated',
    v_email, extensions.crypt(p_password, extensions.gen_salt('bf')), now(),
    jsonb_build_object('provider','email','providers', jsonb_build_array('email')),
    jsonb_build_object('username', v_username, 'full_name', v_full_name),
    now(), now(),
    '', '', '', '',
    false, false
  );

  insert into auth.identities (
    provider_id, user_id, identity_data, provider,
    last_sign_in_at, created_at, updated_at
  ) values (
    v_user_id::text, v_user_id,
    jsonb_build_object('sub', v_user_id::text, 'email', v_email, 'email_verified', true, 'phone_verified', false),
    'email', null, now(), now()
  );

  insert into public.users (id, email, username, full_name, role, status, is_super_admin)
  values (v_user_id, v_email, v_username, v_full_name, v_invite.role, 'active', false);

  select id into v_ws_id from public.workspaces where is_main = true limit 1;
  if v_ws_id is not null then
    insert into public.workspace_members (workspace_id, user_id, role)
    values (v_ws_id, v_user_id, 'member')
    on conflict do nothing;
  end if;

  if v_invite.board_id is not null then
    insert into public.board_subscribers (board_id, user_id, role, group_id)
    values (
      v_invite.board_id, v_user_id,
      case when v_invite.role = 'viewer' then 'viewer' else 'member' end,
      null
    )
    on conflict do nothing;

    if v_invite.group_id is not null then
      insert into public.group_user_visibility (user_id, group_id, granted_by)
      values (v_user_id, v_invite.group_id, v_invite.created_by)
      on conflict (user_id, group_id) do nothing;
    end if;
  end if;

  -- 0076 — guarantee a shift_configs row with shift_mode='manual'.
  -- Admin can flip them to 'auto' later (Phase 11/12-b/c). Without
  -- this row the new user falls into the auto-create branch of
  -- shift_get_or_create_today_session which also defaults to manual,
  -- but seeding it now keeps the admin UI tidy.
  insert into public.shift_configs (user_id, shift_mode)
  values (v_user_id, 'manual')
  on conflict (user_id) do nothing;

  update public.invites
  set used_at = now(), used_by = v_user_id
  where id = v_invite.id;

  return jsonb_build_object(
    'user_id',  v_user_id,
    'username', v_username,
    'email',    v_email,
    'board_id', v_invite.board_id,
    'group_id', v_invite.group_id
  );
end;
$$;
revoke all on function public.accept_invite(text, text, text) from public;
grant execute on function public.accept_invite(text, text, text) to anon, authenticated;

-- =====================================================================
-- 13) ONE-OFF FIX for the stuck test user spark11179@gmail.com:
--     ensure their mode is 'manual' and remove today's completed
--     session so the overlay clears immediately.
-- =====================================================================
update public.shift_configs
   set shift_mode = 'manual'
 where user_id = (select id from public.users where lower(email)='spark11179@gmail.com');

delete from public.shift_sessions
 where user_id = (select id from public.users where lower(email)='spark11179@gmail.com')
   and work_date = (now() at time zone 'UTC')::date;
