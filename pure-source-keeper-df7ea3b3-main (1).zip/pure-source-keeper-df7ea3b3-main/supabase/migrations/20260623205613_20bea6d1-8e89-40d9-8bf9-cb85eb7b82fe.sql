create or replace function public.shift_admin_set_can_work_now(
  p_target_user_id uuid,
  p_can boolean
) returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  v_admin uuid := auth.uid();
  v_active_session record;
  v_cfg record;
  v_today date := (now() at time zone 'America/New_York')::date;
  v_now_local time := (now() at time zone 'America/New_York')::time;
  v_dow int := extract(isodow from (now() at time zone 'America/New_York'))::int;
  v_sched record;
  v_within_schedule boolean := true;
  v_auto_locked boolean := false;
begin
  if not public.is_admin() then
    raise exception 'admin only' using errcode = '42501';
  end if;
  if p_target_user_id is null then
    raise exception 'p_target_user_id required' using errcode = '22023';
  end if;

  insert into public.shift_configs (user_id, can_work_now, updated_at)
  values (p_target_user_id, coalesce(p_can, false), now())
  on conflict (user_id) do update
    set can_work_now = excluded.can_work_now,
        updated_at = now();

  begin
    insert into public.shift_events (user_id, type, by, meta)
    values (
      p_target_user_id,
      'admin_set_can_work_now',
      v_admin,
      jsonb_build_object('can_work_now', coalesce(p_can, false))
    );
  exception when others then null;
  end;

  if coalesce(p_can, false) = false then
    select * into v_active_session
      from public.shift_sessions
     where user_id = p_target_user_id
       and status = 'active'
     order by started_at desc
     limit 1;

    if found then
      select * into v_cfg from public.shift_configs where user_id = p_target_user_id;

      if coalesce(v_cfg.mode, 'manual') = 'manual' then
        v_within_schedule := true;
      elsif coalesce(v_cfg.shift_schedule_enabled, false) = false then
        v_within_schedule := true;
      elsif v_cfg.shift_start_date is not null and v_cfg.shift_start_date > v_today then
        v_within_schedule := false;
      else
        select * into v_sched
          from public.shift_schedules
         where user_id = p_target_user_id
           and day_of_week = v_dow
         limit 1;

        if not found then
          v_within_schedule := false;
        elsif v_now_local < v_sched.start_time_local then
          v_within_schedule := false;
        elsif v_now_local > v_sched.end_time_local then
          v_within_schedule := false;
        else
          v_within_schedule := true;
        end if;
      end if;

      if v_within_schedule = false then
        v_auto_locked := true;

        update public.shift_configs
           set account_locked = true,
               account_lock_reason= 'admin removed can_work_now outside scheduled hours',
               account_locked_at = now(),
               updated_at = now()
         where user_id = p_target_user_id;

        update public.shift_sessions
           set status        = 'locked',
               locked_at     = now(),
               locked_by     = v_admin,
               locked_reason = 'admin',
               updated_at    = now()
         where id = v_active_session.id;

        begin
          insert into public.shift_events (session_id, user_id, type, by, meta)
          values (
            v_active_session.id,
            p_target_user_id,
            'account_lock',
            v_admin,
            jsonb_build_object('source', 'admin_override_removed')
          );
        exception when others then null;
        end;
      end if;
    end if;
  end if;

  return jsonb_build_object(
    'ok', true,
    'can_work_now', coalesce(p_can, false),
    'auto_locked', v_auto_locked
  );
end;
$$;