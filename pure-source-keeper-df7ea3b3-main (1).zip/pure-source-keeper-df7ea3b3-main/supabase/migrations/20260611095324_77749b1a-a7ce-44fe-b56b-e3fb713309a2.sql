-- 0077 — Global "Pause all automatic locks" master switch.
--
-- Per-user mode/config is NEVER modified by this. This is a blanket
-- gate that lives server-side inside the period-lock + tick RPCs.
--
-- Resume rule: when locks_paused flips false, no retroactive locks.
-- For each in-flight auto-mode session we advance
-- current_period_index so the NEXT boundary computes strictly in the
-- future (floor(effective_elapsed / period_seconds)). Nobody locks
-- at the moment of resume.

-- 1) Table -----------------------------------------------------------
create table if not exists public.shift_global_settings (
  id              smallint primary key default 1,
  locks_paused    boolean   not null default false,
  locks_paused_at timestamptz,
  locks_paused_by uuid references public.users(id) on delete set null,
  created_at      timestamptz not null default now(),
  updated_at      timestamptz not null default now(),
  constraint shift_global_settings_singleton check (id = 1)
);

grant select on public.shift_global_settings to authenticated;
grant all    on public.shift_global_settings to service_role;

alter table public.shift_global_settings enable row level security;

drop policy if exists "shift_global_settings_admin_read"  on public.shift_global_settings;
drop policy if exists "shift_global_settings_admin_write" on public.shift_global_settings;

-- Admins read/write. Non-admins cannot see this row — the security-
-- definer RPCs read it on their behalf.
create policy "shift_global_settings_admin_read"
  on public.shift_global_settings for select
  to authenticated
  using (public.is_admin());

create policy "shift_global_settings_admin_write"
  on public.shift_global_settings for update
  to authenticated
  using (public.is_admin())
  with check (public.is_admin());

-- Seed the singleton row.
insert into public.shift_global_settings (id, locks_paused)
values (1, false)
on conflict (id) do nothing;

-- 2) Helper ---------------------------------------------------------
create or replace function public.shift_locks_globally_paused()
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select coalesce((select locks_paused from public.shift_global_settings where id = 1), false);
$$;
revoke all on function public.shift_locks_globally_paused() from public, anon;
grant execute on function public.shift_locks_globally_paused() to authenticated;

-- 3) shift_self_period_lock — gate at the top with the global pause.
--    Preserves the 0076 manual-mode gate + 0075 skip-flag branch.
create or replace function public.shift_self_period_lock(p_session_id uuid)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  v_uid uuid := auth.uid();
  v_s   public.shift_sessions;
  v_old_cpi int;
  v_user_mode text;
begin
  if v_uid is null then
    raise exception 'Not authenticated' using errcode='42501';
  end if;
  select * into v_s from public.shift_sessions where id = p_session_id for update;
  if not found then raise exception 'session not found' using errcode='02000'; end if;
  if v_s.user_id <> v_uid and not is_admin() then
    raise exception 'forbidden' using errcode='42501';
  end if;

  -- 0077 — GLOBAL PAUSE: master blanket. When admins flip the switch,
  -- automatic period locks are suppressed for everyone. Manual admin
  -- locks (shift_admin_lock / shift_admin_set_account_lock) are
  -- intentionally NOT gated and keep working while paused.
  if public.shift_locks_globally_paused() then
    return jsonb_build_object(
      'session_id', v_s.id,
      'status',     v_s.status,
      'skipped',    'global_pause',
      'already_locked', (v_s.status = 'locked')
    );
  end if;

  -- 0076 — MANUAL MODE: no automatic period lock, ever.
  select coalesce(c.shift_mode, 'manual') into v_user_mode
    from public.shift_configs c where c.user_id = v_s.user_id;
  if v_user_mode = 'manual' then
    return jsonb_build_object(
      'session_id', v_s.id, 'status', v_s.status,
      'already_locked', true, 'manual_mode', true
    );
  end if;

  if v_s.status = 'locked' then
    return jsonb_build_object('session_id', v_s.id, 'status', 'locked', 'already_locked', true);
  end if;
  if v_s.status not in ('active','on_shift_break','on_bio_break') then
    raise exception 'session not lockable from status %', v_s.status using errcode='22023';
  end if;

  if v_s.skip_next_period_lock then
    v_old_cpi := v_s.current_period_index;
    update public.shift_sessions
       set skip_next_period_lock = false,
           current_period_index  = current_period_index + 1,
           updated_at            = now()
     where id = v_s.id;
    insert into public.shift_events (session_id, user_id, type, by, meta) values
      (v_s.id, v_s.user_id, 'admin_override', null,
        jsonb_build_object('action','period_lock_skipped',
                           'period_index', v_old_cpi,
                           'new_current_period_index', v_old_cpi + 1,
                           'skip_armed_by', v_s.skip_next_period_lock_set_by,
                           'skip_armed_at', v_s.skip_next_period_lock_set_at));
    return jsonb_build_object(
      'session_id', v_s.id, 'status', v_s.status,
      'skipped', true, 'already_locked', false
    );
  end if;

  update public.shift_sessions
     set status = 'locked',
         current_pause_started_at = now(),
         current_pause_reason     = 'period_lock',
         locked_at                = now(),
         locked_reason            = 'period_lock',
         locked_by                = null,
         updated_at               = now()
   where id = v_s.id;
  insert into public.shift_events (session_id, user_id, type, by, meta)
    values (v_s.id, v_s.user_id, 'period_lock', null,
            jsonb_build_object('reason','period_lock','period_index', v_s.current_period_index));
  return jsonb_build_object('session_id', v_s.id, 'status', 'locked', 'already_locked', false);
end;
$$;
revoke all on function public.shift_self_period_lock(uuid) from public, anon;
grant execute on function public.shift_self_period_lock(uuid) to authenticated;

-- 4) shift_tick — suppress period_85_due + period_lock_due while
--    globally paused so the client never tries to mark85, email, or
--    lock. Manual-mode suppression preserved. Surfaces a
--    'locks_globally_paused' flag for the UI.
create or replace function public.shift_tick(p_session_id uuid)
returns jsonb
language plpgsql
stable
security definer
set search_path = public
as $$
declare
  v_uid uuid := auth.uid();
  v_s public.shift_sessions;
  v_cfg public.shift_configs;
  v_admin boolean;
  v_elapsed int;
  v_remain int;
  v_period_start int;
  v_period_end   int;
  v_85_threshold int;
  v_85_due boolean;
  v_lock_due boolean;
  v_break_elapsed int;
  v_eff_max int;
  v_shift_break_allowance int;
  v_overstay_grace int;
  v_user_mode text;
  v_paused boolean;
begin
  if v_uid is null then raise exception 'not authenticated' using errcode='42501'; end if;
  v_admin := is_admin();
  select * into v_s from public.shift_sessions where id = p_session_id;
  if not found then raise exception 'session not found' using errcode='02000'; end if;
  if v_s.user_id <> v_uid and not v_admin then raise exception 'forbidden' using errcode='42501'; end if;
  select * into v_cfg from public.shift_configs where user_id = v_s.user_id;
  v_user_mode := coalesce(v_cfg.shift_mode, 'manual');
  v_paused    := public.shift_locks_globally_paused();

  if v_s.started_at is null then
    v_elapsed := 0;
  else
    v_elapsed := greatest(0,
      extract(epoch from (clock_timestamp() - v_s.started_at))::int
      - v_s.paused_total_seconds
      - case when v_s.current_pause_started_at is not null
             then extract(epoch from (clock_timestamp() - v_s.current_pause_started_at))::int
             else 0 end
    );
  end if;
  v_remain       := greatest(0, v_s.required_seconds - v_elapsed);
  v_period_start := v_s.current_period_index * v_s.period_seconds;
  v_period_end   := (v_s.current_period_index + 1) * v_s.period_seconds;
  v_85_threshold := v_period_start + (v_s.period_seconds * 0.85)::int;
  v_85_due := v_elapsed >= v_85_threshold
              and v_s.period_85_last_index_alerted < v_s.current_period_index
              and v_s.status in ('active','on_shift_break','on_bio_break');
  v_lock_due := v_elapsed >= v_period_end
              and v_s.status in ('active','on_shift_break','on_bio_break');

  if v_user_mode = 'manual' then
    v_85_due   := false;
    v_lock_due := false;
  end if;

  -- 0077 — GLOBAL PAUSE: blanket-suppress both gates so neither the
  -- 85% warning nor the auto-lock fires from the client.
  if v_paused then
    v_85_due   := false;
    v_lock_due := false;
  end if;

  v_break_elapsed := case
    when v_s.current_break_started_at is null then 0
    else greatest(0, extract(epoch from (clock_timestamp() - v_s.current_break_started_at))::int)
  end;
  v_eff_max := coalesce(v_cfg.bio_break_max_per_day, 7);
  v_shift_break_allowance := coalesce(v_cfg.shift_break_seconds, 1800);
  v_overstay_grace := coalesce(v_cfg.shift_break_overstay_grace_seconds, 900);

  return jsonb_build_object(
    'session_id',                     v_s.id,
    'user_id',                        v_s.user_id,
    'status',                         v_s.status,
    'started_at',                     v_s.started_at,
    'work_date',                      v_s.work_date,
    'mode',                           v_s.mode,
    'shift_mode',                     v_user_mode,
    'locks_globally_paused',          v_paused,
    'period_seconds',                 v_s.period_seconds,
    'required_seconds',               v_s.required_seconds,
    'elapsed_seconds',                v_elapsed,
    'remaining_seconds',              v_remain,
    'paused_total_seconds',           v_s.paused_total_seconds,
    'current_period_index',           v_s.current_period_index,
    'current_period_start_seconds',   v_period_start,
    'current_period_end_seconds',     v_period_end,
    'period_85_threshold_seconds',    v_85_threshold,
    'period_85_due',                  v_85_due,
    'period_lock_due',                v_lock_due,
    'current_break_kind',             v_s.current_break_kind,
    'current_break_started_at',       v_s.current_break_started_at,
    'current_break_elapsed_seconds',  v_break_elapsed,
    'bio_break_count_today',          v_s.bio_break_count_today,
    'bio_break_total_seconds_today',  v_s.bio_break_total_seconds_today,
    'bio_break_admin_grants_today',   v_s.bio_break_admin_grants_today,
    'bio_break_max_per_day',          v_cfg.bio_break_max_per_day,
    'bio_break_warn_count',           v_cfg.bio_break_warn_count,
    'bio_break_warn_total_seconds',   v_cfg.bio_break_warn_total_seconds,
    'bio_break_max_seconds_each',     v_cfg.bio_break_max_seconds_each,
    'bio_limit_reached',              (v_user_mode <> 'manual'
                                        and v_s.bio_break_count_today >= v_eff_max),
    'locked_at',                      v_s.locked_at,
    'locked_reason',                  v_s.locked_reason,
    'completed_at',                   v_s.completed_at,
    'scheduled_start_at',             v_s.scheduled_start_at,
    'expected_end_at',                v_s.expected_end_at,
    'late_start_flag',                v_s.late_start_flag,
    'late_start_minutes',             v_s.late_start_minutes,
    'early_end_flag',                 v_s.early_end_flag,
    'early_end_minutes',              v_s.early_end_minutes,
    'shift_break_count_today',        v_s.shift_break_count_today,
    'shift_break_used_today',         v_s.shift_break_count_today >= 1,
    'shift_break_seconds',            v_shift_break_allowance,
    'shift_break_overstay',           (v_s.status = 'on_shift_break'
                                        and v_s.current_break_kind = 'shift'
                                        and v_break_elapsed >= v_shift_break_allowance),
    'shift_break_overstay_seconds',   greatest(0, v_break_elapsed - v_shift_break_allowance),
    'shift_break_frozen',             coalesce(v_s.current_pause_reason = 'break_overstay', false),
    'shift_break_overstay_grace_seconds', v_overstay_grace,
    'skip_next_period_lock',          v_s.skip_next_period_lock,
    'now',                            clock_timestamp()
  );
end;
$$;
revoke all on function public.shift_tick(uuid) from public, anon;
grant execute on function public.shift_tick(uuid) to authenticated;

-- 5) Admin RPC: set the global pause flag, with no-retro-lock resume.
create or replace function public.shift_admin_set_locks_paused(p_paused boolean)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  v_uid uuid := auth.uid();
  v_was boolean;
  v_advanced int := 0;
begin
  if not is_admin() then raise exception 'forbidden' using errcode='42501'; end if;

  select locks_paused into v_was from public.shift_global_settings where id = 1 for update;

  update public.shift_global_settings
     set locks_paused    = p_paused,
         locks_paused_at = case when p_paused then now() else null end,
         locks_paused_by = case when p_paused then v_uid else null end,
         updated_at      = now()
   where id = 1;

  -- 0077 — RESUME RULE: no retroactive locks. When flipping false,
  -- walk every in-flight AUTO-mode session and advance
  -- current_period_index to floor(effective_elapsed / period_seconds).
  -- That moves the next boundary strictly into the future relative to
  -- now — any periods that elapsed during the pause are treated as
  -- skipped. We DO NOT touch status, paused_total_seconds,
  -- current_pause_started_at, started_at, or any counter. Hours/
  -- attendance accounting is completely preserved.
  if v_was is distinct from p_paused and p_paused = false then
    with eligible as (
      select s.id, s.period_seconds, s.current_period_index,
             greatest(0,
               extract(epoch from (clock_timestamp() - s.started_at))::int
               - s.paused_total_seconds
               - case when s.current_pause_started_at is not null
                      then extract(epoch from (clock_timestamp() - s.current_pause_started_at))::int
                      else 0 end
             ) as effective_elapsed
        from public.shift_sessions s
        join public.shift_configs  c on c.user_id = s.user_id
       where s.status in ('active','on_shift_break','on_bio_break')
         and coalesce(c.shift_mode, 'manual') = 'auto'
         and s.period_seconds is not null
         and s.period_seconds > 0
    ),
    bumped as (
      update public.shift_sessions s
         set current_period_index = floor(e.effective_elapsed::numeric / s.period_seconds)::int,
             updated_at = now()
        from eligible e
       where s.id = e.id
         and floor(e.effective_elapsed::numeric / s.period_seconds)::int > s.current_period_index
      returning s.id
    )
    select count(*) into v_advanced from bumped;
  end if;

  return jsonb_build_object(
    'locks_paused', p_paused,
    'was',          v_was,
    'sessions_advanced_on_resume', coalesce(v_advanced, 0),
    'at',           now()
  );
end;
$$;
revoke all on function public.shift_admin_set_locks_paused(boolean) from public, anon;
grant execute on function public.shift_admin_set_locks_paused(boolean) to authenticated;

-- 6) Admin RPC: read the global pause state.
create or replace function public.shift_admin_get_global_settings()
returns jsonb
language sql
stable
security definer
set search_path = public
as $$
  select jsonb_build_object(
    'locks_paused',    g.locks_paused,
    'locks_paused_at', g.locks_paused_at,
    'locks_paused_by', g.locks_paused_by
  )
  from public.shift_global_settings g where g.id = 1;
$$;
revoke all on function public.shift_admin_get_global_settings() from public, anon;
grant execute on function public.shift_admin_get_global_settings() to authenticated;
