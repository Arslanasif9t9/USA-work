DROP POLICY IF EXISTS "task-files select own" ON storage.objects;

CREATE POLICY "task-files select board"
ON storage.objects
FOR SELECT
TO authenticated
USING (
  bucket_id = 'task-files'
  AND (
    owner = auth.uid()
    OR public.is_admin()
    OR EXISTS (
      SELECT 1 FROM public.files f
      WHERE f.storage_path = storage.objects.name
        AND f.deleted_at IS NULL
    )
  )
);