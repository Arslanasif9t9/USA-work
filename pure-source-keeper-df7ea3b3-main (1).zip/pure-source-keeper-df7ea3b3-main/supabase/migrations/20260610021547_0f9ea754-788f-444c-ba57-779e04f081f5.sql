-- Add 'off' shift tier: no mid-shift lock (sentinel period_seconds), reversible.

-- 1a. Period mapping
CREATE OR REPLACE FUNCTION public._shift_period_seconds(p_mode text)
 RETURNS integer LANGUAGE sql IMMUTABLE
AS $function$
  select case p_mode
    when 'easy'   then 14400
    when 'medium' then 10800
    when 'hard'   then 3600
    when 'off'    then 2147483647
    else 10800
  end;
$function$;

-- 1b. Widen shift_configs.mode CHECK
alter table public.shift_configs drop constraint if exists shift_configs_mode_check;
alter table public.shift_configs add constraint shift_configs_mode_check
  check (mode = any (array['easy','medium','hard','off']));

-- 1c. shift_admin_set_config: allow 'off' + reconcile current session immediately.
CREATE OR REPLACE FUNCTION public.shift_admin_set_config(p_target_user_id uuid, p_mode text, p_shift_break_seconds integer, p_bio_break_max_per_day integer, p_bio_break_warn_count integer, p_bio_break_warn_total_seconds integer, p_bio_break_max_seconds_each integer, p_primary_group_id uuid, p_timezone text DEFAULT 'Asia/Manila'::text, p_late_start_threshold_seconds integer DEFAULT 900, p_hard_until timestamp with time zone DEFAULT NULL::timestamp with time zone)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare
  v_uid              uuid := auth.uid();
  v_old              public.shift_configs;
  v_existed          boolean;
  v_new_hard_until   timestamptz;
begin
  if not is_admin() then raise exception 'admin only' using errcode='42501'; end if;
  if p_mode not in ('easy','medium','hard','off') then
    raise exception 'mode must be easy/medium/hard/off' using errcode='22023';
  end if;
  if p_shift_break_seconds          <= 0 then raise exception 'shift_break_seconds must be > 0' using errcode='22023'; end if;
  if p_bio_break_max_per_day        <= 0 then raise exception 'bio_break_max_per_day must be > 0' using errcode='22023'; end if;
  if p_bio_break_warn_count         <  0 then raise exception 'bio_break_warn_count must be >= 0' using errcode='22023'; end if;
  if p_bio_break_warn_total_seconds <  0 then raise exception 'bio_break_warn_total_seconds must be >= 0' using errcode='22023'; end if;
  if p_bio_break_max_seconds_each   <= 0 then raise exception 'bio_break_max_seconds_each must be > 0' using errcode='22023'; end if;
  if p_late_start_threshold_seconds <  0 then raise exception 'late_start_threshold_seconds must be >= 0' using errcode='22023'; end if;

  begin
    perform now() at time zone p_timezone;
  exception when others then
    raise exception 'invalid timezone: %', p_timezone using errcode='22023';
  end;

  if not exists (select 1 from public.users where id = p_target_user_id and status='active') then
    raise exception 'target user not found or inactive' using errcode='42501';
  end if;

  select * into v_old from public.shift_configs where user_id = p_target_user_id;
  v_existed := found;

  if v_existed then
    v_new_hard_until := coalesce(p_hard_until, v_old.hard_until);
  else
    v_new_hard_until := coalesce(p_hard_until, now() + interval '14 days');
  end if;

  insert into public.shift_configs (
    user_id, mode,
    shift_break_seconds, bio_break_max_per_day, bio_break_warn_count,
    bio_break_warn_total_seconds, bio_break_max_seconds_each,
    primary_group_id, timezone, late_start_threshold_seconds,
    hard_until, updated_at, updated_by
  ) values (
    p_target_user_id, p_mode,
    p_shift_break_seconds, p_bio_break_max_per_day, p_bio_break_warn_count,
    p_bio_break_warn_total_seconds, p_bio_break_max_seconds_each,
    p_primary_group_id, p_timezone, p_late_start_threshold_seconds,
    v_new_hard_until, now(), v_uid
  )
  on conflict (user_id) do update set
    mode                          = excluded.mode,
    shift_break_seconds           = excluded.shift_break_seconds,
    bio_break_max_per_day         = excluded.bio_break_max_per_day,
    bio_break_warn_count          = excluded.bio_break_warn_count,
    bio_break_warn_total_seconds  = excluded.bio_break_warn_total_seconds,
    bio_break_max_seconds_each    = excluded.bio_break_max_seconds_each,
    primary_group_id              = excluded.primary_group_id,
    timezone                      = excluded.timezone,
    late_start_threshold_seconds  = excluded.late_start_threshold_seconds,
    hard_until                    = excluded.hard_until,
    updated_at                    = now(),
    updated_by                    = v_uid;

  -- Reconcile CURRENT in-progress session so mode change takes effect immediately.
  update public.shift_sessions s
     set period_seconds = public._shift_period_seconds(p_mode),
         updated_at     = now()
    from public.shift_configs c
    where s.user_id = c.user_id
      and s.user_id = p_target_user_id
      and s.work_date = (now() at time zone coalesce(c.timezone,'Asia/Manila'))::date
      and s.status in ('not_started','active','on_shift_break','on_bio_break');

  insert into public.shift_events (session_id, user_id, type, by, meta) values (
    null, p_target_user_id, 'admin_override', v_uid,
    jsonb_build_object(
      'action', 'set_config',
      'existed_before', v_existed,
      'old', case when v_existed then to_jsonb(v_old) else null end,
      'new', jsonb_build_object(
        'mode',                          p_mode,
        'shift_break_seconds',           p_shift_break_seconds,
        'bio_break_max_per_day',         p_bio_break_max_per_day,
        'bio_break_warn_count',          p_bio_break_warn_count,
        'bio_break_warn_total_seconds',  p_bio_break_warn_total_seconds,
        'bio_break_max_seconds_each',    p_bio_break_max_seconds_each,
        'primary_group_id',              p_primary_group_id,
        'timezone',                      p_timezone,
        'late_start_threshold_seconds',  p_late_start_threshold_seconds,
        'hard_until',                    v_new_hard_until
      )
    )
  );

  return jsonb_build_object(
    'user_id',        p_target_user_id,
    'existed_before', v_existed,
    'hard_until',     v_new_hard_until
  );
end;
$function$;
