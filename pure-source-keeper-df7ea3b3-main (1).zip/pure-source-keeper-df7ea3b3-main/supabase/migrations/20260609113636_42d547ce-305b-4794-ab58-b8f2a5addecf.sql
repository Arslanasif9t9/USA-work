do $$
declare t text;
begin
  foreach t in array array['items','item_column_values','groups','columns','board_sync_pings'] loop
    begin
      execute format('alter publication supabase_realtime add table public.%I', t);
    exception when duplicate_object then null;
    end;
  end loop;
end$$;