DELETE FROM public.chat_messages WHERE id IN (
  '7dbde526-2115-46ef-a1e6-795c1a85544b',
  '1dfa0a3b-bede-488c-ae67-c779b3339cca',
  '1abe1f85-c4f0-4fd0-9794-ad495174de49',
  '549a022c-810a-485c-b5df-259ad45e9b70'
) AND sender = 'lily' AND body LIKE 'I''m having a little trouble%';