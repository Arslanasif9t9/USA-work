-- ===================================================================
-- Phase 4c — pre-start shift gating
-- ===================================================================

-- helper: compute next allowed shift start (timestamptz) for a user,
-- starting search at the given local date (inclusive). Walks up to
-- 14 days forward; returns null if no enabled day is found.
create or replace function public._shift_next_scheduled_at(
  p_user_id uuid,
  p_from_local_date date,
  p_tz text
) returns timestamptz
language plpgsql
stable
security definer
set search_path = public
as $$
declare
  v_d  date := p_from_local_date;
  v_wd int;
  v_s  public.shift_schedules;
  v_i  int := 0;
begin
  while v_i < 14 loop
    v_wd := extract(dow from v_d)::int;
    select * into v_s from public.shift_schedules
      where user_id = p_user_id and weekday = v_wd;
    if found and v_s.enabled and v_s.start_time_local is not null then
      return ((v_d::text || ' ' || v_s.start_time_local::text)::timestamp
              at time zone p_tz);
    end if;
    v_d := v_d + 1;
    v_i := v_i + 1;
  end loop;
  return null;
end;
$$;

revoke all on function public._shift_next_scheduled_at(uuid, date, text) from public;
grant execute on function public._shift_next_scheduled_at(uuid, date, text) to authenticated;

-- shift_can_start(): caller-only read RPC. Pure compute, no writes.
create or replace function public.shift_can_start()
returns jsonb
language plpgsql
stable
security definer
set search_path = public
as $$
declare
  v_uid uuid := auth.uid();
  v_cfg public.shift_configs;
  v_tz  text;
  v_local_now   timestamp;
  v_local_today date;
  v_local_time  time;
  v_local_wd    int;
  v_sched       public.shift_schedules;
  v_has_any_sched boolean;
  v_today_start_ts timestamptz;
  v_next_ts        timestamptz;
begin
  if v_uid is null or not is_active_user() then
    raise exception 'not authenticated/active' using errcode='42501';
  end if;

  select * into v_cfg from public.shift_configs where user_id = v_uid;
  v_tz := coalesce(v_cfg.timezone, 'Asia/Manila');

  v_local_now   := (now() at time zone v_tz);
  v_local_today := v_local_now::date;
  v_local_time  := v_local_now::time;
  v_local_wd    := extract(dow from v_local_today)::int;

  -- Legacy fallback: if the user has no schedule rows at all (or no
  -- enabled day in the next 14 days), don't gate. Keeps brand-new
  -- accounts and tests workable.
  select exists (
    select 1 from public.shift_schedules
     where user_id = v_uid and enabled = true and start_time_local is not null
  ) into v_has_any_sched;
  if not v_has_any_sched then
    return jsonb_build_object(
      'can_start',     true,
      'reason',        'ok',
      'next_shift_at', null,
      'timezone',      v_tz
    );
  end if;

  -- (a) Before shift_start_date — first day hasn't arrived yet.
  if v_cfg.shift_start_date is not null and v_local_today < v_cfg.shift_start_date then
    v_next_ts := public._shift_next_scheduled_at(v_uid, v_cfg.shift_start_date, v_tz);
    return jsonb_build_object(
      'can_start',     false,
      'reason',        'before_start_date',
      'next_shift_at', v_next_ts,
      'timezone',      v_tz
    );
  end if;

  -- Pull today's schedule.
  select * into v_sched from public.shift_schedules
    where user_id = v_uid and weekday = v_local_wd;

  -- (b) Today is disabled or has no start_time_local → day_off.
  if not found or not v_sched.enabled or v_sched.start_time_local is null then
    v_next_ts := public._shift_next_scheduled_at(v_uid, v_local_today + 1, v_tz);
    return jsonb_build_object(
      'can_start',     false,
      'reason',        'day_off',
      'next_shift_at', v_next_ts,
      'timezone',      v_tz
    );
  end if;

  -- (c) Today is enabled — compare current local time to start.
  v_today_start_ts := ((v_local_today::text || ' ' || v_sched.start_time_local::text)::timestamp
                       at time zone v_tz);
  if v_local_time < v_sched.start_time_local then
    return jsonb_build_object(
      'can_start',     false,
      'reason',        'before_shift_time',
      'next_shift_at', v_today_start_ts,
      'timezone',      v_tz
    );
  end if;

  -- All good — within today's window (late-start handled by shift_start).
  return jsonb_build_object(
    'can_start',     true,
    'reason',        'ok',
    'next_shift_at', v_today_start_ts,
    'timezone',      v_tz
  );
end;
$$;

revoke all on function public.shift_can_start() from public;
grant execute on function public.shift_can_start() to authenticated;


-- shift_start(): base on current live body. Only addition is the
-- pre-start gate at the top (after auth + account-lock, before any
-- session mutation). All existing logic preserved verbatim.
create or replace function public.shift_start()
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  v_uid uuid := auth.uid();
  v_s public.shift_sessions;
  v_cfg public.shift_configs;
  v_sched public.shift_schedules;
  v_local_today      date;
  v_local_weekday    int;
  v_scheduled_start  timestamptz := null;
  v_expected_end     timestamptz := null;
  v_seconds_late     int := null;
  v_late             boolean := false;
  v_late_mins        int := null;
  v_gate             jsonb;
begin
  if v_uid is null or not is_active_user() then
    raise exception 'not authenticated/active' using errcode='42501';
  end if;

  -- 0064: account-level admin lock blocks shift start entirely.
  if exists (
    select 1 from public.shift_configs
     where user_id = v_uid and account_locked = true
  ) then
    raise exception 'account locked' using errcode='42501';
  end if;

  -- P4c: pre-start gate. Server-side enforcement so even a direct
  -- RPC call can't bypass the UI gate. Reason is returned verbatim
  -- so the client can map it to the same calm message.
  v_gate := public.shift_can_start();
  if (v_gate->>'can_start')::boolean = false then
    raise exception 'shift not startable yet: %', (v_gate->>'reason')
      using errcode='22023',
            detail = v_gate::text;
  end if;

  perform public.shift_get_or_create_today_session();
  select * into v_s from public.shift_sessions
    where user_id = v_uid and work_date = (now() at time zone 'UTC')::date
    for update;
  if v_s.status <> 'not_started' then
    raise exception 'shift already %', v_s.status using errcode='22023';
  end if;

  select * into v_cfg from public.shift_configs where user_id = v_uid;
  v_local_today    := (now() at time zone v_cfg.timezone)::date;
  v_local_weekday  := extract(dow from v_local_today)::int;
  select * into v_sched from public.shift_schedules
    where user_id = v_uid and weekday = v_local_weekday;
  if found and v_sched.enabled and v_sched.start_time_local is not null then
    v_scheduled_start := ((v_local_today::text || ' ' || v_sched.start_time_local::text)::timestamp
                          at time zone v_cfg.timezone);
    v_expected_end := v_scheduled_start + (v_s.required_seconds || ' seconds')::interval;
    v_seconds_late := extract(epoch from (now() - v_scheduled_start))::int;
    if v_seconds_late > coalesce(v_cfg.late_start_threshold_seconds, 900) then
      v_late := true;
      v_late_mins := greatest(0, v_seconds_late / 60);
    end if;
  end if;

  update public.shift_sessions
     set status              = 'active',
         started_at          = now(),
         scheduled_start_at  = v_scheduled_start,
         expected_end_at     = v_expected_end,
         late_start_flag     = v_late,
         late_start_minutes  = case when v_late then v_late_mins else null end,
         updated_at          = now()
   where id = v_s.id
   returning * into v_s;

  insert into public.shift_events (session_id, user_id, type, by)
    values (v_s.id, v_uid, 'shift_start', v_uid);
  if v_late then
    insert into public.shift_events (session_id, user_id, type, by, meta)
      values (v_s.id, v_uid, 'late_start', v_uid,
              jsonb_build_object('minutes_late', v_late_mins,
                                 'scheduled_start_at', v_scheduled_start));
  end if;

  return jsonb_build_object(
    'session_id',          v_s.id,
    'started_at',          v_s.started_at,
    'scheduled_start_at',  v_scheduled_start,
    'expected_end_at',     v_expected_end,
    'late_start_flag',     v_late,
    'late_start_minutes',  v_late_mins
  );
end;
$$;