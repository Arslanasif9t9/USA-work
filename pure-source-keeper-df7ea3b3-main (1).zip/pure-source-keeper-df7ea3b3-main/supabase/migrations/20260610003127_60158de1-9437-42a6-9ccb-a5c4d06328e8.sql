-- F-A: shift_take_bio_break — effective max includes admin grants
CREATE OR REPLACE FUNCTION public.shift_take_bio_break(p_session_id uuid)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare
  v_uid uuid := auth.uid();
  v_s   public.shift_sessions;
  v_cfg public.shift_configs;
  v_effective_max int;
  v_user_mode text;
begin
  if v_uid is null then raise exception 'not authenticated' using errcode='42501'; end if;
  select * into v_s from public.shift_sessions where id = p_session_id for update;
  if not found then raise exception 'session not found' using errcode='02000'; end if;
  if v_s.user_id <> v_uid and not is_admin() then
    raise exception 'forbidden' using errcode='42501';
  end if;
  if v_s.status <> 'active' then
    raise exception 'cannot bio-break from %', v_s.status using errcode='22023';
  end if;
  select * into v_cfg from public.shift_configs where user_id = v_s.user_id;
  v_user_mode := coalesce(v_cfg.shift_mode, 'manual');
  v_effective_max := coalesce(v_cfg.bio_break_max_per_day, 7)
                     + coalesce(v_s.bio_break_admin_grants_today, 0);
  if v_user_mode <> 'manual' and v_s.bio_break_count_today >= v_effective_max then
    return jsonb_build_object(
      'session_id',   v_s.id,
      'status',       v_s.status,
      'limit_reached', true,
      'count_today',  v_s.bio_break_count_today,
      'max_per_day',  v_effective_max
    );
  end if;
  update public.shift_sessions
     set status                   = 'on_bio_break',
         current_break_started_at = now(),
         current_break_kind       = 'bio',
         updated_at               = now()
   where id = v_s.id;
  insert into public.shift_events (session_id, user_id, type, by, meta)
    values (v_s.id, v_s.user_id, 'bio_break_start', v_uid,
            jsonb_build_object('count_so_far', v_s.bio_break_count_today));
  return jsonb_build_object(
    'session_id',    v_s.id,
    'status',        'on_bio_break',
    'limit_reached', false
  );
end;
$function$;

-- F-B: shift_tick — v_eff_max + bio_limit_reached include grants
CREATE OR REPLACE FUNCTION public.shift_tick(p_session_id uuid)
 RETURNS jsonb
 LANGUAGE plpgsql
 STABLE SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare
  v_uid uuid := auth.uid();
  v_s public.shift_sessions;
  v_cfg public.shift_configs;
  v_admin boolean;
  v_elapsed int;
  v_remain int;
  v_period_start int;
  v_period_end   int;
  v_85_threshold int;
  v_85_due boolean;
  v_lock_due boolean;
  v_break_elapsed int;
  v_eff_max int;
  v_shift_break_allowance int;
  v_overstay_grace int;
  v_user_mode text;
begin
  if v_uid is null then raise exception 'not authenticated' using errcode='42501'; end if;
  v_admin := is_admin();
  select * into v_s from public.shift_sessions where id = p_session_id;
  if not found then raise exception 'session not found' using errcode='02000'; end if;
  if v_s.user_id <> v_uid and not v_admin then raise exception 'forbidden' using errcode='42501'; end if;
  select * into v_cfg from public.shift_configs where user_id = v_s.user_id;
  v_user_mode := coalesce(v_cfg.shift_mode, 'manual');
  if v_s.started_at is null then
    v_elapsed := 0;
  else
    v_elapsed := greatest(0,
      extract(epoch from (clock_timestamp() - v_s.started_at))::int
      - v_s.paused_total_seconds
      - case when v_s.current_pause_started_at is not null
             then extract(epoch from (clock_timestamp() - v_s.current_pause_started_at))::int
             else 0 end
    );
  end if;
  v_remain       := greatest(0, v_s.required_seconds - v_elapsed);
  v_period_start := v_s.current_period_index * v_s.period_seconds;
  v_period_end   := (v_s.current_period_index + 1) * v_s.period_seconds;
  v_85_threshold := v_period_start + (v_s.period_seconds * 0.85)::int;
  v_85_due := v_elapsed >= v_85_threshold
              and v_s.period_85_last_index_alerted < v_s.current_period_index
              and v_s.status in ('active','on_shift_break','on_bio_break');
  v_lock_due := v_elapsed >= v_period_end
              and v_s.status in ('active','on_shift_break','on_bio_break');
  if v_user_mode = 'manual' then
    v_85_due   := false;
    v_lock_due := false;
  end if;
  v_break_elapsed := case
    when v_s.current_break_started_at is null then 0
    else greatest(0, extract(epoch from (clock_timestamp() - v_s.current_break_started_at))::int)
  end;
  v_eff_max := coalesce(v_cfg.bio_break_max_per_day, 7)
               + coalesce(v_s.bio_break_admin_grants_today, 0);
  v_shift_break_allowance := coalesce(v_cfg.shift_break_seconds, 1800);
  v_overstay_grace := coalesce(v_cfg.shift_break_overstay_grace_seconds, 900);
  return jsonb_build_object(
    'session_id',                     v_s.id,
    'user_id',                        v_s.user_id,
    'status',                         v_s.status,
    'started_at',                     v_s.started_at,
    'work_date',                      v_s.work_date,
    'mode',                           v_s.mode,
    'shift_mode',                     v_user_mode,
    'period_seconds',                 v_s.period_seconds,
    'required_seconds',               v_s.required_seconds,
    'elapsed_seconds',                v_elapsed,
    'remaining_seconds',              v_remain,
    'paused_total_seconds',           v_s.paused_total_seconds,
    'current_period_index',           v_s.current_period_index,
    'current_period_start_seconds',   v_period_start,
    'current_period_end_seconds',     v_period_end,
    'period_85_threshold_seconds',    v_85_threshold,
    'period_85_due',                  v_85_due,
    'period_lock_due',                v_lock_due,
    'current_break_kind',             v_s.current_break_kind,
    'current_break_started_at',       v_s.current_break_started_at,
    'current_break_elapsed_seconds',  v_break_elapsed,
    'bio_break_count_today',          v_s.bio_break_count_today,
    'bio_break_total_seconds_today',  v_s.bio_break_total_seconds_today,
    'bio_break_admin_grants_today',   v_s.bio_break_admin_grants_today,
    'bio_break_max_per_day',          v_cfg.bio_break_max_per_day,
    'bio_break_warn_count',           v_cfg.bio_break_warn_count,
    'bio_break_warn_total_seconds',   v_cfg.bio_break_warn_total_seconds,
    'bio_break_max_seconds_each',     v_cfg.bio_break_max_seconds_each,
    'bio_limit_reached',              (v_user_mode <> 'manual'
                                         and v_s.bio_break_count_today >= v_eff_max),
    'locked_at',                      v_s.locked_at,
    'locked_reason',                  v_s.locked_reason,
    'completed_at',                   v_s.completed_at,
    'scheduled_start_at',             v_s.scheduled_start_at,
    'expected_end_at',                v_s.expected_end_at,
    'late_start_flag',                v_s.late_start_flag,
    'late_start_minutes',             v_s.late_start_minutes,
    'early_end_flag',                 v_s.early_end_flag,
    'early_end_minutes',              v_s.early_end_minutes,
    'shift_break_count_today',        v_s.shift_break_count_today,
    'shift_break_used_today',         v_s.shift_break_count_today >= 1,
    'shift_break_seconds',            v_shift_break_allowance,
    'shift_break_overstay',           (v_s.status = 'on_shift_break'
                                        and v_s.current_break_kind = 'shift'
                                        and v_break_elapsed >= v_shift_break_allowance),
    'shift_break_overstay_seconds',   greatest(0, v_break_elapsed - v_shift_break_allowance),
    'shift_break_frozen',             coalesce(v_s.current_pause_reason = 'break_overstay', false),
    'shift_break_overstay_grace_seconds', v_overstay_grace,
    'skip_next_period_lock',          v_s.skip_next_period_lock,
    'now',                            clock_timestamp()
  );
end;
$function$;

-- F-C: shift_admin_set_account_lock — unlock grants +1 bio break if prior reason was bio_limit_exceeded
CREATE OR REPLACE FUNCTION public.shift_admin_set_account_lock(p_target_user_id uuid, p_locked boolean)
 RETURNS jsonb
 LANGUAGE plpgsql SECURITY DEFINER SET search_path TO 'public'
AS $function$
declare
  v_uid        uuid := auth.uid();
  v_old        public.shift_configs;
  v_existed    boolean;
  v_now        timestamptz := clock_timestamp();
  v_locked_at  timestamptz;
  v_locked_by  uuid;
  v_s          public.shift_sessions;
  v_pause_secs int;
  v_session_paused  boolean := false;
  v_session_resumed boolean := false;
  v_tz         text;
  v_prior_reason text;
begin
  if not is_admin() then
    raise exception 'admin only' using errcode='42501';
  end if;
  if p_target_user_id is null then
    raise exception 'p_target_user_id is required' using errcode='22023';
  end if;
  if not exists (select 1 from public.users where id = p_target_user_id and status='active') then
    raise exception 'target user not found or inactive' using errcode='42501';
  end if;
  v_locked_at := case when p_locked then v_now else null end;
  v_locked_by := case when p_locked then v_uid else null end;
  select * into v_old from public.shift_configs where user_id = p_target_user_id;
  v_existed := found;
  v_tz := coalesce(v_old.timezone, 'Asia/Manila');
  insert into public.shift_configs (
    user_id, account_locked, account_locked_at, account_locked_by,
    account_lock_reason, hard_until, updated_at, updated_by
  ) values (
    p_target_user_id, p_locked, v_locked_at, v_locked_by,
    case when p_locked then 'admin' else null end,
    v_now + interval '14 days', v_now, v_uid
  )
  on conflict (user_id) do update set
    account_locked      = excluded.account_locked,
    account_locked_at   = excluded.account_locked_at,
    account_locked_by   = excluded.account_locked_by,
    account_lock_reason = case when p_locked then 'admin' else null end,
    updated_at          = v_now,
    updated_by          = v_uid;
  select * into v_s from public.shift_sessions
    where user_id = p_target_user_id
      and work_date = (v_now at time zone v_tz)::date
    for update;
  if found then
    if p_locked then
      if v_s.status in ('active','on_shift_break','on_bio_break') then
        update public.shift_sessions set
          status                   = 'locked',
          current_pause_started_at = v_now,
          current_pause_reason     = 'admin',
          locked_at                = v_now,
          locked_reason            = 'admin',
          locked_by                = v_uid,
          updated_at               = v_now
        where id = v_s.id;
        v_session_paused := true;
        insert into public.shift_events (session_id, user_id, type, by, meta) values (
          v_s.id, v_s.user_id, 'admin_override', v_uid,
          jsonb_build_object('action','account_lock_pause',
                             'paused_at', v_now,
                             'from_status', v_s.status)
        );
      end if;
    else
      if v_s.status = 'locked'
         and v_s.locked_reason in ('admin','bio_limit_exceeded')
         and v_s.current_pause_started_at is not null then
        v_prior_reason := v_s.locked_reason;
        v_pause_secs := greatest(0, extract(epoch from (v_now - v_s.current_pause_started_at))::int);
        update public.shift_sessions set
          status                   = 'active',
          paused_total_seconds     = paused_total_seconds + v_pause_secs,
          current_pause_started_at = null,
          current_pause_reason     = null,
          locked_at                = null,
          locked_reason            = null,
          locked_by                = null,
          bio_break_admin_grants_today = case
            when v_prior_reason = 'bio_limit_exceeded'
            then coalesce(bio_break_admin_grants_today,0) + 1
            else bio_break_admin_grants_today end,
          bio6_notified_at = case
            when v_prior_reason = 'bio_limit_exceeded'
            then null
            else bio6_notified_at end,
          updated_at               = v_now
        where id = v_s.id;
        v_session_resumed := true;
        insert into public.shift_events (session_id, user_id, type, by, meta) values (
          v_s.id, v_s.user_id, 'admin_override', v_uid,
          jsonb_build_object('action','account_unlock_resume',
                             'paused_seconds', v_pause_secs,
                             'prior_reason', v_prior_reason,
                             'bio_grant_added', (v_prior_reason='bio_limit_exceeded'),
                             'resumed_at', v_now)
        );
      end if;
    end if;
  end if;
  insert into public.shift_events (session_id, user_id, type, by, meta) values (
    null, p_target_user_id, 'admin_override', v_uid,
    jsonb_build_object(
      'action', case when p_locked then 'account_lock' else 'account_unlock' end,
      'existed_before', v_existed,
      'old_locked', case when v_existed then v_old.account_locked else null end,
      'new_locked', p_locked,
      'session_paused', v_session_paused,
      'session_resumed', v_session_resumed
    )
  );
  return jsonb_build_object(
    'user_id', p_target_user_id,
    'account_locked', p_locked,
    'account_locked_at', v_locked_at,
    'account_locked_by', v_locked_by,
    'session_paused', v_session_paused,
    'session_resumed', v_session_resumed
  );
end;
$function$;