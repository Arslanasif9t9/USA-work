-- 1) Add column
ALTER TABLE public.invites ADD COLUMN IF NOT EXISTS invitee_name text;

-- 2) Replace create_invite — drop old 5-arg overload first, then create 6-arg version.
DROP FUNCTION IF EXISTS public.create_invite(text, uuid, integer, uuid, text);

CREATE OR REPLACE FUNCTION public.create_invite(
  p_role              text,
  p_board_id          uuid    DEFAULT NULL,
  p_expires_in_hours  integer DEFAULT 168,
  p_group_id          uuid    DEFAULT NULL,
  p_invitee_email     text    DEFAULT NULL,
  p_invitee_name      text    DEFAULT NULL
)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $function$
declare
  v_token       text;
  v_id          uuid;
  v_expires_at  timestamptz;
  v_hours       int;
  v_email       text;
  v_name        text;
begin
  -- AUTH GATE — unchanged (admin-only).
  if not public.is_admin() then
    raise exception 'Only admins can mint invite links' using errcode='42501';
  end if;

  -- ROLE VALIDATION — from 0039 (admin / manager / viewer).
  if p_role not in ('admin', 'manager', 'viewer') then
    raise exception 'Invalid invite role: % (must be admin / manager / viewer)', p_role
      using errcode = '22023';
  end if;

  -- Group scope requires a board (unchanged).
  if p_group_id is not null then
    if p_board_id is null then
      raise exception 'Group-scoped invite requires p_board_id' using errcode='22023';
    end if;
    if not exists (
      select 1 from public.groups
      where id = p_group_id and board_id = p_board_id and deleted_at is null
    ) then
      raise exception 'Group not found on this board' using errcode='22023';
    end if;
  end if;

  -- Normalize the invitee email — trim + lowercase. Null/empty stays
  -- null. We deliberately do NOT block on duplicates at mint time;
  -- the freed-email policy is enforced inside accept_invite().
  v_email := nullif(lower(trim(coalesce(p_invitee_email, ''))), '');

  -- Normalize the legal name — trim. Null/empty stays null.
  v_name := nullif(trim(coalesce(p_invitee_name, '')), '');

  -- NEVER-EXPIRES (preserved from 0037).
  if p_expires_in_hours is null or p_expires_in_hours <= 0 then
    v_expires_at := null;
  else
    v_hours := greatest(1, least(p_expires_in_hours, 24 * 30));
    v_expires_at := now() + make_interval(hours => v_hours);
  end if;

  v_token := encode(extensions.gen_random_bytes(16), 'hex');

  insert into public.invites (
    token, role, board_id, group_id, created_by, expires_at, invitee_email, invitee_name
  )
  values (
    v_token, p_role, p_board_id, p_group_id, auth.uid(), v_expires_at, v_email, v_name
  )
  returning id into v_id;

  return jsonb_build_object(
    'id',            v_id,
    'token',         v_token,
    'role',          p_role,
    'board_id',      p_board_id,
    'group_id',      p_group_id,
    'expires_at',    v_expires_at,
    'invitee_email', v_email,
    'invitee_name',  v_name
  );
end;
$function$;

-- 3) Replace accept_invite (3-arg) — admin-entered legal name wins.
CREATE OR REPLACE FUNCTION public.accept_invite(p_token text, p_full_name text, p_password text)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $function$
declare
  v_invite     record;
  v_user_id    uuid := gen_random_uuid();
  v_base       text;
  v_username   text;
  v_full_name  text;
  v_email      text;
  v_ws_id      uuid;
begin
  -- Lock + validate the token.
  select * into v_invite from public.invites where token = p_token for update;
  if not found                       then raise exception 'Invite link not found' using errcode='42501'; end if;
  if v_invite.revoked_at is not null then raise exception 'This invite was revoked' using errcode='42501'; end if;
  if v_invite.used_at    is not null then raise exception 'This invite has already been used' using errcode='42501'; end if;
  if v_invite.expires_at is not null and v_invite.expires_at <= now() then
    raise exception 'This invite has expired' using errcode='42501';
  end if;

  -- Password validation (unchanged from 0023).
  if p_password is null or length(p_password) < 8 then
    raise exception 'Password must be at least 8 characters' using errcode='22023';
  end if;

  -- Derive a base for the auto-username.
  if v_invite.invitee_email is not null and position('@' in v_invite.invitee_email) > 0 then
    v_base := split_part(v_invite.invitee_email, '@', 1);
  else
    v_base := coalesce(nullif(trim(p_full_name), ''), '');
  end if;

  v_username := public._generate_unique_username(v_base);

  if v_username !~ '^[a-z0-9_]{2,32}$' then
    raise exception 'Could not derive a valid username' using errcode='22023';
  end if;

  -- Email derivation — preserved from 0040.
  if v_invite.invitee_email is not null then
    if exists (
      select 1 from public.users
      where lower(email) = lower(v_invite.invitee_email)
        and status = 'active'
    ) then
      raise exception 'An active account already uses this email' using errcode='23505';
    end if;

    update public.users
       set email = 'freed_' || id::text || '@pms.internal'
     where lower(email) = lower(v_invite.invitee_email)
       and status <> 'active';

    update auth.users
       set email = 'freed_' || id::text || '@pms.internal'
     where lower(email) = lower(v_invite.invitee_email)
       and id not in (select id from public.users where status = 'active');

    v_email := lower(v_invite.invitee_email);
  else
    v_email := v_username || '@pms.internal';
  end if;

  -- Admin-entered legal name on the invite row wins; falls back to
  -- the invitee-typed full name; then to the auto-generated username.
  v_full_name := coalesce(
    nullif(trim(coalesce(v_invite.invitee_name, '')), ''),
    nullif(trim(coalesce(p_full_name, '')), ''),
    v_username
  );

  insert into auth.users (
    instance_id, id, aud, role, email, encrypted_password, email_confirmed_at,
    raw_app_meta_data, raw_user_meta_data, created_at, updated_at,
    confirmation_token, recovery_token, email_change_token_new, email_change,
    is_sso_user, is_anonymous
  ) values (
    '00000000-0000-0000-0000-000000000000',
    v_user_id, 'authenticated', 'authenticated',
    v_email, extensions.crypt(p_password, extensions.gen_salt('bf')), now(),
    jsonb_build_object('provider','email','providers', jsonb_build_array('email')),
    jsonb_build_object('username', v_username, 'full_name', v_full_name),
    now(), now(),
    '', '', '', '',
    false, false
  );

  insert into auth.identities (
    provider_id, user_id, identity_data, provider,
    last_sign_in_at, created_at, updated_at
  ) values (
    v_user_id::text, v_user_id,
    jsonb_build_object('sub', v_user_id::text, 'email', v_email, 'email_verified', true, 'phone_verified', false),
    'email', null, now(), now()
  );

  insert into public.users (id, email, username, full_name, role, status, is_super_admin)
  values (v_user_id, v_email, v_username, v_full_name, v_invite.role, 'active', false);

  select id into v_ws_id from public.workspaces where is_main = true limit 1;
  if v_ws_id is not null then
    insert into public.workspace_members (workspace_id, user_id, role)
    values (v_ws_id, v_user_id, 'member')
    on conflict do nothing;
  end if;

  if v_invite.board_id is not null then
    insert into public.board_subscribers (board_id, user_id, role, group_id)
    values (
      v_invite.board_id, v_user_id,
      case when v_invite.role = 'viewer' then 'viewer' else 'member' end,
      null
    )
    on conflict do nothing;

    if v_invite.group_id is not null then
      insert into public.group_user_visibility (user_id, group_id, granted_by)
      values (v_user_id, v_invite.group_id, v_invite.created_by)
      on conflict (user_id, group_id) do nothing;
    end if;
  end if;

  update public.invites
  set used_at = now(), used_by = v_user_id
  where id = v_invite.id;

  return jsonb_build_object(
    'user_id',  v_user_id,
    'username', v_username,
    'email',    v_email,
    'board_id', v_invite.board_id,
    'group_id', v_invite.group_id
  );
end;
$function$;
