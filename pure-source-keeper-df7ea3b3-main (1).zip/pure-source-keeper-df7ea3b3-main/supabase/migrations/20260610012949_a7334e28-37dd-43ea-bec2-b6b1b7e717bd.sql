do $$
declare v_exists boolean;
begin
  select exists(select 1 from vault.secrets where name='cron_shared_secret') into v_exists;
  if not v_exists then
    perform vault.create_secret(encode(extensions.gen_random_bytes(24),'hex'), 'cron_shared_secret', 'Shared secret for shift cron -> edge function calls');
  end if;
  select exists(select 1 from vault.secrets where name='app_base_url') into v_exists;
  if not v_exists then
    perform vault.create_secret('https://kevtjqxsmzjquoonqfbh.supabase.co/functions/v1', 'app_base_url', 'Base URL for shift-alert-email edge function');
  end if;
end $$;

CREATE OR REPLACE FUNCTION public.shift_break_sweep()
 RETURNS jsonb
 LANGUAGE plpgsql SECURITY DEFINER SET search_path TO 'public'
AS $function$
declare
  v_now timestamptz := clock_timestamp();
  v_rec record;
  v_allowance int;
  v_grace int;
  v_break_elapsed int;
  v_freeze_dur int;
  v_recorded int;
  v_frozen_count int := 0;
  v_locked_count int := 0;
  v_emailed_count int := 0;
  v_bio6_count int := 0;
  v_secret text;
  v_url text;
  v_email_mark jsonb;
begin
  begin
    select decrypted_secret into v_secret
      from vault.decrypted_secrets where name='cron_shared_secret' limit 1;
  exception when others then v_secret := null;
  end;
  begin
    select decrypted_secret into v_url
      from vault.decrypted_secrets where name='app_base_url' limit 1;
  exception when others then v_url := null;
  end;
  if v_url is null then v_url := 'https://p-m-system.vercel.app'; end if;

  for v_rec in
    select s.id, s.user_id, s.paused_total_seconds,
           s.current_break_started_at, s.current_pause_started_at, s.current_pause_reason,
           coalesce(c.shift_break_seconds, 1800) as allowance,
           coalesce(c.shift_break_overstay_grace_seconds, 900) as grace
      from public.shift_sessions s
      join public.shift_configs c on c.user_id = s.user_id
     where s.status = 'on_shift_break'
       and s.current_break_kind = 'shift'
       and s.current_break_started_at is not null
       and coalesce(c.shift_mode, 'manual') = 'auto'
       and greatest(0, extract(epoch from (v_now - s.current_break_started_at))::int)
           >= coalesce(c.shift_break_seconds, 1800) + coalesce(c.shift_break_overstay_grace_seconds, 900)
     for update of s
  loop
    v_allowance := v_rec.allowance;
    v_grace     := v_rec.grace;
    v_break_elapsed := greatest(0, extract(epoch from (v_now - v_rec.current_break_started_at))::int);
    v_freeze_dur := case
      when v_rec.current_pause_reason = 'break_overstay'
       and v_rec.current_pause_started_at is not null
      then greatest(0, extract(epoch from (v_now - v_rec.current_pause_started_at))::int)
      else 0 end;
    v_recorded := least(v_break_elapsed, v_allowance);

    update public.shift_sessions set
      status='locked', current_break_started_at=null, current_break_kind=null,
      paused_total_seconds = paused_total_seconds + v_freeze_dur,
      current_pause_started_at = v_now, current_pause_reason = 'break_overstay',
      locked_at = v_now, locked_reason = 'break_overstay', locked_by = null,
      updated_at = v_now
     where id = v_rec.id;

    insert into public.shift_events (session_id, user_id, type, by, meta) values
      (v_rec.id, v_rec.user_id, 'shift_break_end', null,
        jsonb_build_object(
          'duration_seconds_actual',   v_break_elapsed,
          'duration_seconds_recorded', v_recorded,
          'overstay_seconds',          greatest(0, v_break_elapsed - v_allowance),
          'frozen_seconds_credited',   v_freeze_dur,
          'allowance_seconds',         v_allowance,
          'ended_by',                  'overstay_lock_sweep',
          'sweep',                     true)),
      (v_rec.id, v_rec.user_id, 'shift_break_overstay_lock', null,
        jsonb_build_object(
          'break_elapsed_seconds',   v_break_elapsed,
          'allowance_seconds',       v_allowance,
          'grace_seconds',           v_grace,
          'frozen_seconds_credited', v_freeze_dur,
          'sweep',                   true));

    v_locked_count := v_locked_count + 1;

    insert into public.notifications
      (recipient_id, actor_id, type, board_id, item_id, update_id, is_read)
      select u.id, v_rec.user_id, 'shift_admin_alert', null, null, null, false
        from public.users u
       where u.status='active' and (u.role='admin' or u.is_super_admin=true);

    select public.shift_mark_overstay_lock_emailed(v_rec.id) into v_email_mark;
    if coalesce((v_email_mark->>'emailed_now')::boolean, false) then
      v_emailed_count := v_emailed_count + 1;
      if v_secret is not null and v_secret <> '' then
        begin
          perform net.http_post(
            url     := v_url || '/api/shift-alert-email',
            body    := jsonb_build_object(
                         'session_id', v_rec.id::text,
                         'kind',       'break_overstay_lock'),
            headers := jsonb_build_object(
                         'Content-Type',  'application/json',
                         'X-Cron-Secret', v_secret),
            timeout_milliseconds := 5000
          );
        exception when others then
          insert into public.shift_events (session_id, user_id, type, by, meta) values
            (v_rec.id, v_rec.user_id, 'admin_override', null,
              jsonb_build_object('action','sweep_email_http_post_failed',
                                 'sweep', true, 'sqlerrm', sqlerrm));
        end;
      else
        insert into public.shift_events (session_id, user_id, type, by, meta) values
          (v_rec.id, v_rec.user_id, 'admin_override', null,
            jsonb_build_object('action','sweep_email_skipped_no_secret','sweep',true));
      end if;
    end if;
  end loop;

  for v_rec in
    select s.id, s.user_id, s.current_break_started_at,
           coalesce(c.shift_break_seconds, 1800) as allowance
      from public.shift_sessions s
      join public.shift_configs c on c.user_id = s.user_id
     where s.status = 'on_shift_break'
       and s.current_break_kind = 'shift'
       and s.current_break_started_at is not null
       and s.current_pause_started_at is null
       and coalesce(c.shift_mode, 'manual') = 'auto'
       and greatest(0, extract(epoch from (v_now - s.current_break_started_at))::int)
           >= coalesce(c.shift_break_seconds, 1800)
     for update of s
  loop
    v_allowance := v_rec.allowance;
    v_break_elapsed := greatest(0, extract(epoch from (v_now - v_rec.current_break_started_at))::int);

    update public.shift_sessions set
      current_pause_started_at = v_now,
      current_pause_reason     = 'break_overstay',
      updated_at               = v_now
     where id = v_rec.id;

    insert into public.shift_events (session_id, user_id, type, by, meta) values
      (v_rec.id, v_rec.user_id, 'shift_break_overstay_freeze', null,
        jsonb_build_object('break_elapsed_seconds', v_break_elapsed,
                           'allowance_seconds',     v_allowance,
                           'sweep',                 true));
    v_frozen_count := v_frozen_count + 1;
  end loop;

  for v_rec in
    select s.id, s.user_id
      from public.shift_sessions s
      join public.shift_configs c on c.user_id = s.user_id
     where s.bio_break_count_today >= 6
       and s.bio6_notified_at is null
       and s.work_date = (v_now at time zone coalesce(c.timezone,'Asia/Manila'))::date
       and coalesce(c.shift_mode, 'manual') = 'auto'
     for update of s
  loop
    insert into public.notifications
      (recipient_id, actor_id, type, board_id, item_id, update_id, is_read)
      select u.id, v_rec.user_id, 'shift_admin_alert', null, null, null, false
        from public.users u
       where u.status='active' and (u.role='admin' or u.is_super_admin=true);

    update public.shift_sessions set bio6_notified_at = v_now where id = v_rec.id;
    v_bio6_count := v_bio6_count + 1;
  end loop;

  return jsonb_build_object(
    'frozen_count',  v_frozen_count,
    'locked_count',  v_locked_count,
    'emailed_count', v_emailed_count,
    'bio6_count',    v_bio6_count,
    'now',           v_now
  );
end;
$function$;