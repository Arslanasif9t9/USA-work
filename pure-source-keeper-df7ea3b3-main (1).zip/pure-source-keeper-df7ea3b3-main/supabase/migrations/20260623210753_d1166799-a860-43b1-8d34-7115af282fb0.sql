create or replace function public.shift_admin_set_can_work_now(
  p_target_user_id uuid,
  p_can boolean
) returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  v_admin uuid := auth.uid();
  v_now   timestamptz := clock_timestamp();
  v_cfg   public.shift_configs;
  v_tz    text;
  v_local_now   timestamp;
  v_local_today date;
  v_local_time  time;
  v_local_wd    int;
  v_sched       public.shift_schedules;
  v_s           public.shift_sessions;
  v_outside     boolean := false;
  v_auto_locked boolean := false;
begin
  if not public.is_admin() then
    raise exception 'admin only' using errcode = '42501';
  end if;
  if p_target_user_id is null then
    raise exception 'p_target_user_id required' using errcode = '22023';
  end if;

  -- Primary write: flip can_work_now.
  insert into public.shift_configs (user_id, can_work_now, updated_at)
  values (p_target_user_id, coalesce(p_can, false), v_now)
  on conflict (user_id) do update
    set can_work_now = excluded.can_work_now,
        updated_at   = v_now;

  -- Audit trail for the flip itself. Use 'admin_override' (the only allowed value).
  begin
    insert into public.shift_events (user_id, type, by, meta)
    values (
      p_target_user_id,
      'admin_override',
      v_admin,
      jsonb_build_object(
        'action', 'set_can_work_now',
        'can_work_now', coalesce(p_can, false)
      )
    );
  exception when others then null;
  end;

  -- Enforcement only runs when the override is being turned OFF.
  if coalesce(p_can, false) = false then
    select * into v_cfg from public.shift_configs where user_id = p_target_user_id;
    v_tz := coalesce(v_cfg.timezone, 'Asia/Manila');

    -- Lookup today's active session (locked for update).
    select * into v_s
      from public.shift_sessions
     where user_id   = p_target_user_id
       and work_date = (v_now at time zone v_tz)::date
       and status in ('active','on_shift_break','on_bio_break')
     for update;

    if found then
      -- Manual mode has no schedule gate -> nothing to enforce.
      if coalesce(v_cfg.shift_mode, 'manual') <> 'manual' then
        v_local_now   := (v_now at time zone v_tz);
        v_local_today := v_local_now::date;
        v_local_time  := v_local_now::time;
        v_local_wd    := extract(dow from v_local_today)::int;  -- 0..6, Sunday=0

        select * into v_sched
          from public.shift_schedules
         where user_id = p_target_user_id
           and weekday = v_local_wd;

        if not found
           or coalesce(v_sched.enabled, false) = false
           or v_sched.start_time_local is null
           or v_local_time < v_sched.start_time_local
           or (v_sched.end_time_local is not null and v_local_time > v_sched.end_time_local)
        then
          v_outside := true;
        end if;

        if v_outside then
          -- Lock the live session (same fields as shift_admin_set_account_lock).
          update public.shift_sessions set
            status                   = 'locked',
            current_pause_started_at = v_now,
            current_pause_reason     = 'admin',
            locked_at                = v_now,
            locked_reason            = 'admin',
            locked_by                = v_admin,
            updated_at               = v_now
          where id = v_s.id;

          -- Lock the account.
          update public.shift_configs set
            account_locked      = true,
            account_locked_at   = v_now,
            account_locked_by   = v_admin,
            account_lock_reason = 'override_removed_outside_schedule',
            updated_at          = v_now,
            updated_by          = v_admin
          where user_id = p_target_user_id;

          -- Audit. Only 'admin_override' is allowed in shift_events_type_check.
          begin
            insert into public.shift_events (session_id, user_id, type, by, meta)
            values (
              v_s.id,
              p_target_user_id,
              'admin_override',
              v_admin,
              jsonb_build_object(
                'action', 'can_work_now_lock',
                'reason', 'override_removed_outside_schedule',
                'from_status', v_s.status,
                'weekday', v_local_wd,
                'local_time', v_local_time::text
              )
            );
          exception when others then null;
          end;

          v_auto_locked := true;
        end if;
      end if;
    end if;
  end if;

  return jsonb_build_object(
    'ok', true,
    'can_work_now', coalesce(p_can, false),
    'auto_locked', v_auto_locked
  );
end;
$$;