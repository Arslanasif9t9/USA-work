-- ============================================================
-- 1. chat_threads — one row per user (1:1 thread with Lily)
-- ============================================================
create table public.chat_threads (
  id uuid primary key default gen_random_uuid(),
  user_id uuid unique references public.users(id) on delete set null,
  created_at timestamptz not null default now(),
  last_message_at timestamptz not null default now()
);

grant select, insert, update on public.chat_threads to authenticated;
grant all on public.chat_threads to service_role;

alter table public.chat_threads enable row level security;

create policy "chat_threads: user reads own"
  on public.chat_threads for select to authenticated
  using (user_id = auth.uid());

create policy "chat_threads: user inserts own"
  on public.chat_threads for insert to authenticated
  with check (user_id = auth.uid());

create policy "chat_threads: user updates own"
  on public.chat_threads for update to authenticated
  using (user_id = auth.uid()) with check (user_id = auth.uid());

create policy "chat_threads: admin reads all"
  on public.chat_threads for select to authenticated
  using (public.is_admin());

create policy "chat_threads: admin inserts all"
  on public.chat_threads for insert to authenticated
  with check (public.is_admin());

create policy "chat_threads: admin updates all"
  on public.chat_threads for update to authenticated
  using (public.is_admin()) with check (public.is_admin());

create index chat_threads_user_id_idx on public.chat_threads(user_id);


-- ============================================================
-- 2. chat_messages
-- ============================================================
create table public.chat_messages (
  id uuid primary key default gen_random_uuid(),
  thread_id uuid references public.chat_threads(id) on delete set null,
  sender text not null check (sender in ('user', 'lily')),
  body text not null,
  -- The real admin who typed this message while Lily was in 'human' mode.
  -- Never returned to non-admin users; the UI shows it as "Lily".
  sender_user_id uuid references public.users(id) on delete set null,
  created_at timestamptz not null default now()
);

grant select, insert on public.chat_messages to authenticated;
grant all on public.chat_messages to service_role;

alter table public.chat_messages enable row level security;

create policy "chat_messages: user reads own thread"
  on public.chat_messages for select to authenticated
  using (
    exists (
      select 1 from public.chat_threads t
       where t.id = chat_messages.thread_id and t.user_id = auth.uid()
    )
  );

create policy "chat_messages: user inserts own thread"
  on public.chat_messages for insert to authenticated
  with check (
    sender = 'user'
    and sender_user_id is null
    and exists (
      select 1 from public.chat_threads t
       where t.id = chat_messages.thread_id and t.user_id = auth.uid()
    )
  );

create policy "chat_messages: admin reads all"
  on public.chat_messages for select to authenticated
  using (public.is_admin());

create policy "chat_messages: admin inserts all"
  on public.chat_messages for insert to authenticated
  with check (public.is_admin());

create index chat_messages_thread_id_created_at_idx
  on public.chat_messages(thread_id, created_at);


-- ============================================================
-- 3. lily_settings — single-row config (id always = 1)
-- ============================================================
create table public.lily_settings (
  id int primary key default 1 check (id = 1),
  mode text not null default 'ai' check (mode in ('ai', 'human')),
  updated_at timestamptz not null default now()
);

grant all on public.lily_settings to service_role;
-- Authenticated rows are gated by RLS — only admins pass the policy.
grant select, update on public.lily_settings to authenticated;

alter table public.lily_settings enable row level security;

create policy "lily_settings: admin reads"
  on public.lily_settings for select to authenticated
  using (public.is_admin());

create policy "lily_settings: admin updates"
  on public.lily_settings for update to authenticated
  using (public.is_admin()) with check (public.is_admin());

insert into public.lily_settings (id, mode) values (1, 'ai');


-- ============================================================
-- 4. Realtime
-- ============================================================
alter publication supabase_realtime add table public.chat_threads;
alter publication supabase_realtime add table public.chat_messages;