DROP POLICY IF EXISTS shift_sessions_update ON public.shift_sessions;
CREATE POLICY shift_sessions_update ON public.shift_sessions
  FOR UPDATE
  USING (is_admin())
  WITH CHECK (is_admin());