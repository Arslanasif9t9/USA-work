GRANT USAGE ON SCHEMA auth TO sandbox_exec;
GRANT REFERENCES, SELECT ON auth.users TO sandbox_exec;
GRANT REFERENCES, SELECT ON auth.identities TO sandbox_exec;
SELECT has_schema_privilege('sandbox_exec','auth','USAGE') AS u,
       has_table_privilege('sandbox_exec','auth.users','REFERENCES') AS r;