create or replace function public.shift_admin_set_shift_mode(
  p_user_id uuid,
  p_mode    text
)
returns jsonb
language plpgsql
security definer
set search_path to 'public'
as $function$
declare
  v_uid       uuid := auth.uid();
  v_has_sched boolean;
  v_start     time := '09:00'::time;
  v_req       int  := 28800;
  v_half      int  := 14400;
begin
  if not is_admin() then
    raise exception 'admin only' using errcode='42501';
  end if;
  if p_mode is null or p_mode not in ('auto','manual') then
    raise exception 'p_mode must be auto or manual' using errcode='22023';
  end if;
  if not exists (select 1 from public.users where id = p_user_id and status='active') then
    raise exception 'target user not found or inactive' using errcode='42501';
  end if;

  -- Upsert shift_configs row preserving everything else.
  insert into public.shift_configs (user_id, shift_mode)
  values (p_user_id, p_mode)
  on conflict (user_id) do update set
    shift_mode = excluded.shift_mode;

  -- When switching TO auto with NO existing schedule rows, seed a
  -- sensible default week so Auto is never broken-empty. Mirrors
  -- shift_admin_apply_default_schedule(09:00, 28800).
  if p_mode = 'auto' then
    select exists(
      select 1 from public.shift_schedules where user_id = p_user_id
    ) into v_has_sched;

    if not v_has_sched then
      insert into public.shift_schedules (user_id, weekday, enabled, required_seconds, start_time_local, end_time_local)
      select p_user_id, w, true, v_req, v_start,
             (v_start + make_interval(secs => v_req))::time
        from generate_series(1,5) as w
      on conflict (user_id, weekday) do update set
        enabled          = excluded.enabled,
        required_seconds = excluded.required_seconds,
        start_time_local = excluded.start_time_local,
        end_time_local   = excluded.end_time_local;

      insert into public.shift_schedules (user_id, weekday, enabled, required_seconds, start_time_local, end_time_local)
      values (p_user_id, 6, true, v_half, v_start,
              (v_start + make_interval(secs => v_half))::time)
      on conflict (user_id, weekday) do update set
        enabled          = excluded.enabled,
        required_seconds = excluded.required_seconds,
        start_time_local = excluded.start_time_local,
        end_time_local   = excluded.end_time_local;

      insert into public.shift_schedules (user_id, weekday, enabled, required_seconds, start_time_local, end_time_local)
      values (p_user_id, 0, false, 0, null, null)
      on conflict (user_id, weekday) do update set
        enabled          = excluded.enabled,
        required_seconds = excluded.required_seconds,
        start_time_local = excluded.start_time_local,
        end_time_local   = excluded.end_time_local;
    end if;
  end if;

  insert into public.shift_events (session_id, user_id, type, by, meta) values (
    null, p_user_id, 'admin_override', v_uid,
    jsonb_build_object('kind','set_shift_mode','mode', p_mode)
  );

  return jsonb_build_object(
    'ok', true,
    'user_id', p_user_id,
    'shift_mode', p_mode,
    'seeded_default_schedule', (p_mode = 'auto' and not coalesce(v_has_sched, true))
  );
end;
$function$;

grant execute on function public.shift_admin_set_shift_mode(uuid, text) to authenticated;