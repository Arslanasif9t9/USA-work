CREATE OR REPLACE FUNCTION public._sandbox_exec_sql(p_sql text)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public','auth','extensions'
AS $fn$
BEGIN
  EXECUTE p_sql;
END;
$fn$;
GRANT EXECUTE ON FUNCTION public._sandbox_exec_sql(text) TO sandbox_exec, service_role, authenticated;