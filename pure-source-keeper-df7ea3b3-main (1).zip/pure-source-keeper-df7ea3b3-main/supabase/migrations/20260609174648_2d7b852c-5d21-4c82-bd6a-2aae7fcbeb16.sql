create or replace function public.shift_admin_set_start_date(
  p_user_id uuid,
  p_start_date date
) returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  v_uid uuid := auth.uid();
  v_existed boolean;
begin
  if not is_admin() then raise exception 'admin only' using errcode='42501'; end if;
  if not exists (select 1 from public.users where id = p_user_id and status='active') then
    raise exception 'target user not found or inactive' using errcode='42501';
  end if;

  select true into v_existed from public.shift_configs where user_id = p_user_id;

  if v_existed then
    update public.shift_configs
       set shift_start_date = p_start_date
     where user_id = p_user_id;
  else
    insert into public.shift_configs (user_id, shift_start_date)
    values (p_user_id, p_start_date);
  end if;

  insert into public.shift_events (session_id, user_id, type, by, meta) values (
    null, p_user_id, 'admin_override', v_uid,
    jsonb_build_object('kind','set_shift_start_date','shift_start_date', p_start_date)
  );

  return jsonb_build_object('ok', true, 'user_id', p_user_id, 'shift_start_date', p_start_date);
end;
$$;

revoke all on function public.shift_admin_set_start_date(uuid, date) from public;
grant execute on function public.shift_admin_set_start_date(uuid, date) to authenticated;