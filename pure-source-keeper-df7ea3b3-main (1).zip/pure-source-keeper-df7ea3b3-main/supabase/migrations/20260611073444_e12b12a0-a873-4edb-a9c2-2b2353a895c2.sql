DELETE FROM public.chat_messages WHERE id IN (
  '7086eb5a-47e0-4d54-9213-32bc05c3b9c1',
  '8ebfde4a-b137-43b3-930c-72705773aa78'
);