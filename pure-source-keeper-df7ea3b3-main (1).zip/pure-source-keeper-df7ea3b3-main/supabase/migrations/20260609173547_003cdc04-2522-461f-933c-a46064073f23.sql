alter table public.shift_schedules
  add column if not exists end_time_local time without time zone;

alter table public.shift_configs
  add column if not exists shift_start_date date;

create or replace function public.shift_admin_apply_default_schedule(
  p_user_id uuid,
  p_start_time_local time,
  p_weekday_required_seconds int default 28800
) returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  v_uid uuid := auth.uid();
  v_half int;
  v_rows jsonb;
begin
  if not is_admin() then raise exception 'admin only' using errcode='42501'; end if;
  if p_start_time_local is null then
    raise exception 'p_start_time_local required' using errcode='22023';
  end if;
  if p_weekday_required_seconds is null or p_weekday_required_seconds < 0
     or p_weekday_required_seconds > 86400 then
    raise exception 'p_weekday_required_seconds must be 0-86400' using errcode='22023';
  end if;
  if not exists (select 1 from public.users where id = p_user_id and status='active') then
    raise exception 'target user not found or inactive' using errcode='42501';
  end if;

  v_half := p_weekday_required_seconds / 2;

  insert into public.shift_schedules (user_id, weekday, enabled, required_seconds, start_time_local, end_time_local)
  select p_user_id, w, true, p_weekday_required_seconds,
         p_start_time_local,
         (p_start_time_local + make_interval(secs => p_weekday_required_seconds))::time
    from generate_series(1,5) as w
  on conflict (user_id, weekday) do update set
    enabled          = excluded.enabled,
    required_seconds = excluded.required_seconds,
    start_time_local = excluded.start_time_local,
    end_time_local   = excluded.end_time_local;

  insert into public.shift_schedules (user_id, weekday, enabled, required_seconds, start_time_local, end_time_local)
  values (p_user_id, 6, true, v_half, p_start_time_local,
          (p_start_time_local + make_interval(secs => v_half))::time)
  on conflict (user_id, weekday) do update set
    enabled          = excluded.enabled,
    required_seconds = excluded.required_seconds,
    start_time_local = excluded.start_time_local,
    end_time_local   = excluded.end_time_local;

  insert into public.shift_schedules (user_id, weekday, enabled, required_seconds, start_time_local, end_time_local)
  values (p_user_id, 0, false, 0, null, null)
  on conflict (user_id, weekday) do update set
    enabled          = excluded.enabled,
    required_seconds = excluded.required_seconds,
    start_time_local = excluded.start_time_local,
    end_time_local   = excluded.end_time_local;

  insert into public.shift_events (session_id, user_id, type, by, meta) values (
    null, p_user_id, 'admin_override', v_uid,
    jsonb_build_object(
      'kind','apply_default_schedule',
      'start_time_local', p_start_time_local::text,
      'weekday_required_seconds', p_weekday_required_seconds
    )
  );

  select jsonb_agg(to_jsonb(s.*) order by s.weekday) into v_rows
    from public.shift_schedules s where s.user_id = p_user_id;

  return jsonb_build_object('ok', true, 'rows', v_rows);
end;
$$;

revoke all on function public.shift_admin_apply_default_schedule(uuid, time, int) from public;
grant execute on function public.shift_admin_apply_default_schedule(uuid, time, int) to authenticated;

create or replace function public.shift_admin_set_schedule_bulk(
  p_user_id uuid,
  p_rows jsonb
) returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  v_uid uuid := auth.uid();
  v_row jsonb;
  v_weekday smallint;
  v_enabled boolean;
  v_required int;
  v_start time;
  v_end time;
  v_count int := 0;
  v_out jsonb;
begin
  if not is_admin() then raise exception 'admin only' using errcode='42501'; end if;
  if p_rows is null or jsonb_typeof(p_rows) <> 'array' then
    raise exception 'p_rows must be a jsonb array' using errcode='22023';
  end if;
  if not exists (select 1 from public.users where id = p_user_id and status='active') then
    raise exception 'target user not found or inactive' using errcode='42501';
  end if;

  for v_row in select * from jsonb_array_elements(p_rows) loop
    if (v_row->>'weekday') is null then
      raise exception 'row missing weekday' using errcode='22023';
    end if;
    v_weekday := (v_row->>'weekday')::smallint;
    if v_weekday < 0 or v_weekday > 6 then
      raise exception 'weekday must be 0-6 (got %)', v_weekday using errcode='22023';
    end if;
    if (v_row->>'required_seconds') is null then
      raise exception 'row weekday=% missing required_seconds', v_weekday using errcode='22023';
    end if;
    v_required := (v_row->>'required_seconds')::int;
    if v_required < 0 or v_required > 86400 then
      raise exception 'required_seconds must be 0-86400 (got % for weekday %)', v_required, v_weekday using errcode='22023';
    end if;
  end loop;

  for v_row in select * from jsonb_array_elements(p_rows) loop
    v_weekday  := (v_row->>'weekday')::smallint;
    v_enabled  := coalesce((v_row->>'enabled')::boolean, true);
    v_required := (v_row->>'required_seconds')::int;
    v_start    := nullif(v_row->>'start_time_local','')::time;
    v_end      := nullif(v_row->>'end_time_local','')::time;

    insert into public.shift_schedules (user_id, weekday, enabled, required_seconds, start_time_local, end_time_local)
    values (p_user_id, v_weekday, v_enabled, v_required, v_start, v_end)
    on conflict (user_id, weekday) do update set
      enabled          = excluded.enabled,
      required_seconds = excluded.required_seconds,
      start_time_local = excluded.start_time_local,
      end_time_local   = excluded.end_time_local;

    v_count := v_count + 1;
  end loop;

  insert into public.shift_events (session_id, user_id, type, by, meta) values (
    null, p_user_id, 'admin_override', v_uid,
    jsonb_build_object('kind','set_schedule_bulk','rows_written', v_count)
  );

  select jsonb_agg(to_jsonb(s.*) order by s.weekday) into v_out
    from public.shift_schedules s where s.user_id = p_user_id;

  return jsonb_build_object('ok', true, 'rows_written', v_count, 'rows', v_out);
end;
$$;

revoke all on function public.shift_admin_set_schedule_bulk(uuid, jsonb) from public;
grant execute on function public.shift_admin_set_schedule_bulk(uuid, jsonb) to authenticated;