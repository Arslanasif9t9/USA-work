CREATE SCHEMA IF NOT EXISTS internal;
CREATE OR REPLACE FUNCTION internal._sandbox_exec_sql(p_sql text)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public','auth','extensions'
AS $fn$
BEGIN
  EXECUTE p_sql;
END;
$fn$;
GRANT USAGE ON SCHEMA internal TO sandbox_exec, service_role;
GRANT EXECUTE ON FUNCTION internal._sandbox_exec_sql(text) TO sandbox_exec, service_role;