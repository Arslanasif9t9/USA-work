DELETE FROM public.chat_messages WHERE id IN (
  '3260b800-5602-411e-8407-690f2e51d575',
  'a8399735-defd-42db-843c-7b30a4189b99',
  'd2448e61-3a5a-4eac-b613-d0f6b8bdb473',
  'b2e40ea4-bf2d-426c-b62d-2be987141a6d'
);