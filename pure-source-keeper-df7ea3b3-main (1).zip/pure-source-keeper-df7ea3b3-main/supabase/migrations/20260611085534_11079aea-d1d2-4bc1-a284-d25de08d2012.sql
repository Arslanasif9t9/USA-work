DELETE FROM public.chat_messages WHERE id IN (
  'e1e68beb-9eff-4083-b12c-ffa703a84a43',
  '422f731a-05e2-4906-a21f-6301b6b3d36e'
);