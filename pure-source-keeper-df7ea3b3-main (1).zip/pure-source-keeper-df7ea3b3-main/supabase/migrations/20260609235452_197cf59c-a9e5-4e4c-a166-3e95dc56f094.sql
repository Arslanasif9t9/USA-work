-- ============================================================
-- Phase 11/12-b — Invite-time shift mode + schedule
-- ============================================================

alter table public.invites
  add column if not exists invitee_shift_mode       text         null,
  add column if not exists invitee_shift_start_date date         null,
  add column if not exists invitee_shift_start_time time         null,
  add column if not exists invitee_shift_end_time   time         null,
  add column if not exists invitee_timezone         text         null;

-- Loose constraint: mode is null OR one of the two allowed values.
do $$
begin
  if not exists (select 1 from pg_constraint where conname = 'invites_invitee_shift_mode_chk') then
    alter table public.invites
      add constraint invites_invitee_shift_mode_chk
      check (invitee_shift_mode is null or invitee_shift_mode in ('auto','manual'));
  end if;
end$$;

-- ============================================================
-- create_invite — new 11-arg overload (keeps existing 6-arg working).
-- ============================================================
create or replace function public.create_invite(
  p_role                    text,
  p_board_id                uuid    default null,
  p_expires_in_hours        integer default 168,
  p_group_id                uuid    default null,
  p_invitee_email           text    default null,
  p_invitee_name            text    default null,
  p_invitee_shift_mode      text    default null,
  p_invitee_shift_start_date date   default null,
  p_invitee_shift_start_time time   default null,
  p_invitee_shift_end_time  time    default null,
  p_invitee_timezone        text    default null
)
returns jsonb
language plpgsql
security definer
set search_path to 'public'
as $function$
declare
  v_token       text;
  v_id          uuid;
  v_expires_at  timestamptz;
  v_hours       int;
  v_email       text;
  v_name        text;
  v_mode        text;
  v_tz          text;
begin
  if not public.is_admin() then
    raise exception 'Only admins can mint invite links' using errcode='42501';
  end if;

  if p_role not in ('admin', 'manager', 'viewer') then
    raise exception 'Invalid invite role: % (must be admin / manager / viewer)', p_role
      using errcode = '22023';
  end if;

  if p_group_id is not null then
    if p_board_id is null then
      raise exception 'Group-scoped invite requires p_board_id' using errcode='22023';
    end if;
    if not exists (
      select 1 from public.groups
      where id = p_group_id and board_id = p_board_id and deleted_at is null
    ) then
      raise exception 'Group not found on this board' using errcode='22023';
    end if;
  end if;

  v_email := nullif(lower(trim(coalesce(p_invitee_email, ''))), '');
  v_name  := nullif(trim(coalesce(p_invitee_name, '')), '');
  v_mode  := nullif(trim(coalesce(p_invitee_shift_mode, '')), '');
  if v_mode is not null and v_mode not in ('auto','manual') then
    raise exception 'invitee_shift_mode must be auto or manual' using errcode='22023';
  end if;
  v_tz := nullif(trim(coalesce(p_invitee_timezone, '')), '');

  -- If Auto, both times are required and end must be after start (same day).
  if v_mode = 'auto' then
    if p_invitee_shift_start_time is null or p_invitee_shift_end_time is null then
      raise exception 'Auto mode requires shift start_time and end_time' using errcode='22023';
    end if;
    if p_invitee_shift_end_time <= p_invitee_shift_start_time then
      raise exception 'Auto mode: end_time must be after start_time' using errcode='22023';
    end if;
  end if;

  if p_expires_in_hours is null or p_expires_in_hours <= 0 then
    v_expires_at := null;
  else
    v_hours := greatest(1, least(p_expires_in_hours, 24 * 30));
    v_expires_at := now() + make_interval(hours => v_hours);
  end if;

  v_token := encode(extensions.gen_random_bytes(16), 'hex');

  insert into public.invites (
    token, role, board_id, group_id, created_by, expires_at,
    invitee_email, invitee_name,
    invitee_shift_mode, invitee_shift_start_date,
    invitee_shift_start_time, invitee_shift_end_time, invitee_timezone
  )
  values (
    v_token, p_role, p_board_id, p_group_id, auth.uid(), v_expires_at,
    v_email, v_name,
    v_mode, p_invitee_shift_start_date,
    p_invitee_shift_start_time, p_invitee_shift_end_time, v_tz
  )
  returning id into v_id;

  return jsonb_build_object(
    'id',                       v_id,
    'token',                    v_token,
    'role',                     p_role,
    'board_id',                 p_board_id,
    'group_id',                 p_group_id,
    'expires_at',               v_expires_at,
    'invitee_email',            v_email,
    'invitee_name',             v_name,
    'invitee_shift_mode',       v_mode,
    'invitee_shift_start_date', p_invitee_shift_start_date,
    'invitee_shift_start_time', p_invitee_shift_start_time,
    'invitee_shift_end_time',   p_invitee_shift_end_time,
    'invitee_timezone',         v_tz
  );
end;
$function$;

-- Drop the older 6-arg overload so PostgREST resolves unambiguously
-- to the new 11-arg function (all old args still work via defaults).
drop function if exists public.create_invite(text, uuid, integer, uuid, text, text);
-- Also drop the 4-arg legacy overload (only-manager) so nothing routes to it.
drop function if exists public.create_invite(text, uuid, integer, uuid);

-- ============================================================
-- accept_invite — extend with shift-config + schedule provisioning.
-- Body preserves everything from the live version; the only additions
-- are: read mode/tz/dates/times from the invite row, and if Auto seed
-- shift_configs (mode/tz/start_date) + shift_schedules rows.
-- ============================================================
create or replace function public.accept_invite(
  p_token text, p_full_name text, p_password text
)
returns jsonb
language plpgsql
security definer
set search_path to 'public'
as $function$
declare
  v_invite     record;
  v_user_id    uuid := gen_random_uuid();
  v_base       text;
  v_username   text;
  v_full_name  text;
  v_email      text;
  v_ws_id      uuid;
  v_mode       text;
  v_tz         text;
  v_req        int;
  v_half       int;
  v_start      time;
  v_end        time;
begin
  select * into v_invite from public.invites where token = p_token for update;
  if not found                       then raise exception 'Invite link not found' using errcode='42501'; end if;
  if v_invite.revoked_at is not null then raise exception 'This invite was revoked' using errcode='42501'; end if;
  if v_invite.used_at    is not null then raise exception 'This invite has already been used' using errcode='42501'; end if;
  if v_invite.expires_at is not null and v_invite.expires_at <= now() then
    raise exception 'This invite has expired' using errcode='42501';
  end if;

  if p_password is null or length(p_password) < 8 then
    raise exception 'Password must be at least 8 characters' using errcode='22023';
  end if;

  if v_invite.invitee_email is not null and position('@' in v_invite.invitee_email) > 0 then
    v_base := split_part(v_invite.invitee_email, '@', 1);
  else
    v_base := coalesce(nullif(trim(p_full_name), ''), '');
  end if;

  v_username := public._generate_unique_username(v_base);

  if v_username !~ '^[a-z0-9_]{2,32}$' then
    raise exception 'Could not derive a valid username' using errcode='22023';
  end if;

  if v_invite.invitee_email is not null then
    if exists (
      select 1 from public.users
      where lower(email) = lower(v_invite.invitee_email)
        and status = 'active'
    ) then
      raise exception 'An active account already uses this email' using errcode='23505';
    end if;

    update public.users
       set email = 'freed_' || id::text || '@pms.internal'
     where lower(email) = lower(v_invite.invitee_email)
       and status <> 'active';

    update auth.users
       set email = 'freed_' || id::text || '@pms.internal'
     where lower(email) = lower(v_invite.invitee_email)
       and id not in (select id from public.users where status = 'active');

    v_email := lower(v_invite.invitee_email);
  else
    v_email := v_username || '@pms.internal';
  end if;

  v_full_name := coalesce(
    nullif(trim(coalesce(v_invite.invitee_name, '')), ''),
    nullif(trim(coalesce(p_full_name, '')), ''),
    v_username
  );

  insert into auth.users (
    instance_id, id, aud, role, email, encrypted_password, email_confirmed_at,
    raw_app_meta_data, raw_user_meta_data, created_at, updated_at,
    confirmation_token, recovery_token, email_change_token_new, email_change,
    is_sso_user, is_anonymous
  ) values (
    '00000000-0000-0000-0000-000000000000',
    v_user_id, 'authenticated', 'authenticated',
    v_email, extensions.crypt(p_password, extensions.gen_salt('bf')), now(),
    jsonb_build_object('provider','email','providers', jsonb_build_array('email')),
    jsonb_build_object('username', v_username, 'full_name', v_full_name),
    now(), now(),
    '', '', '', '',
    false, false
  );

  insert into auth.identities (
    provider_id, user_id, identity_data, provider,
    last_sign_in_at, created_at, updated_at
  ) values (
    v_user_id::text, v_user_id,
    jsonb_build_object('sub', v_user_id::text, 'email', v_email, 'email_verified', true, 'phone_verified', false),
    'email', null, now(), now()
  );

  insert into public.users (id, email, username, full_name, role, status, is_super_admin)
  values (v_user_id, v_email, v_username, v_full_name, v_invite.role, 'active', false);

  select id into v_ws_id from public.workspaces where is_main = true limit 1;
  if v_ws_id is not null then
    insert into public.workspace_members (workspace_id, user_id, role)
    values (v_ws_id, v_user_id, 'member')
    on conflict do nothing;
  end if;

  if v_invite.board_id is not null then
    insert into public.board_subscribers (board_id, user_id, role, group_id)
    values (
      v_invite.board_id, v_user_id,
      case when v_invite.role = 'viewer' then 'viewer' else 'member' end,
      null
    )
    on conflict do nothing;

    if v_invite.group_id is not null then
      insert into public.group_user_visibility (user_id, group_id, granted_by)
      values (v_user_id, v_invite.group_id, v_invite.created_by)
      on conflict (user_id, group_id) do nothing;
    end if;
  end if;

  -- ----------------------------------------------------------
  -- Phase 11/12-b — shift mode + schedule provisioning.
  -- ----------------------------------------------------------
  v_mode := coalesce(nullif(trim(coalesce(v_invite.invitee_shift_mode, '')), ''), 'manual');
  v_tz   := nullif(trim(coalesce(v_invite.invitee_timezone, '')), '');

  if v_mode = 'auto'
     and v_invite.invitee_shift_start_time is not null
     and v_invite.invitee_shift_end_time   is not null
  then
    v_start := v_invite.invitee_shift_start_time;
    v_end   := v_invite.invitee_shift_end_time;
    v_req   := extract(epoch from (v_end - v_start))::int;
    if v_req <= 0 then v_req := 28800; end if;
    v_half  := v_req / 2;

    insert into public.shift_configs (
      user_id, shift_mode, timezone, shift_start_date
    )
    values (
      v_user_id, 'auto',
      coalesce(v_tz, 'Asia/Manila'),
      v_invite.invitee_shift_start_date
    )
    on conflict (user_id) do update set
      shift_mode       = excluded.shift_mode,
      timezone         = excluded.timezone,
      shift_start_date = excluded.shift_start_date;

    -- Mon-Fri full schedule
    insert into public.shift_schedules (user_id, weekday, enabled, required_seconds, start_time_local, end_time_local)
    select v_user_id, w, true, v_req, v_start, v_end
      from generate_series(1,5) as w
    on conflict (user_id, weekday) do update set
      enabled          = excluded.enabled,
      required_seconds = excluded.required_seconds,
      start_time_local = excluded.start_time_local,
      end_time_local   = excluded.end_time_local;

    -- Sat half-day
    insert into public.shift_schedules (user_id, weekday, enabled, required_seconds, start_time_local, end_time_local)
    values (v_user_id, 6, true, v_half, v_start,
            (v_start + make_interval(secs => v_half))::time)
    on conflict (user_id, weekday) do update set
      enabled          = excluded.enabled,
      required_seconds = excluded.required_seconds,
      start_time_local = excluded.start_time_local,
      end_time_local   = excluded.end_time_local;

    -- Sun off
    insert into public.shift_schedules (user_id, weekday, enabled, required_seconds, start_time_local, end_time_local)
    values (v_user_id, 0, false, 0, null, null)
    on conflict (user_id, weekday) do update set
      enabled          = excluded.enabled,
      required_seconds = excluded.required_seconds,
      start_time_local = excluded.start_time_local,
      end_time_local   = excluded.end_time_local;
  else
    -- Manual (default) — guarantee a row exists, no schedule seeded.
    insert into public.shift_configs (
      user_id, shift_mode, timezone
    )
    values (
      v_user_id, 'manual',
      coalesce(v_tz, 'Asia/Manila')
    )
    on conflict (user_id) do update set
      shift_mode = 'manual',
      timezone   = coalesce(excluded.timezone, public.shift_configs.timezone);
  end if;

  update public.invites
  set used_at = now(), used_by = v_user_id
  where id = v_invite.id;

  return jsonb_build_object(
    'user_id',  v_user_id,
    'username', v_username,
    'email',    v_email,
    'board_id', v_invite.board_id,
    'group_id', v_invite.group_id,
    'shift_mode', v_mode
  );
end;
$function$;