do $$
begin
  if not exists (
    select 1
    from pg_publication_tables
    where pubname = 'supabase_realtime'
      and schemaname = 'public'
      and tablename = 'shift_configs'
  ) then
    alter publication supabase_realtime add table public.shift_configs;
  end if;
end $$;