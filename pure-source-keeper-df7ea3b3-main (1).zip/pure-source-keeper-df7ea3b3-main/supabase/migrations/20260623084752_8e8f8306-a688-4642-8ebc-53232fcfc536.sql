-- =====================================================================
-- 0077 — Fix hidden-groups bug for manually-created users
-- ---------------------------------------------------------------------
-- groups_select RLS is: can_access_board(board_id) AND (is_admin() OR
-- EXISTS group_user_visibility grant). can_access_board() returns false
-- unless the user has a board_subscribers row. accept_invite inserts
-- that row; admin_create_user did not, so manually-created users had
-- all their GUV grants masked on read.
--
-- This migration:
--   [1] Backfills board_subscribers for the Tessera board for every
--       active user missing one (idempotent via ON CONFLICT DO NOTHING
--       on the (board_id, user_id) PK).
--   [2] Patches admin_create_user to mirror accept_invite's
--       board_subscribers insert for the Tessera board.
--
-- Role mapping matches accept_invite verbatim:
--   case when role='viewer' then 'viewer' else 'member' end
-- group_id = NULL (membership row only; visibility is ACL-driven).
-- notification_level / subscribed_at are left to their column defaults
-- ('everything' / now()), same as accept_invite.
-- =====================================================================

-- ---------- [1] Backfill --------------------------------------------
insert into public.board_subscribers (board_id, user_id, role, group_id)
select
  '28472783-6d7a-4de9-8834-2354f62856c5'::uuid,
  u.id,
  case when u.role = 'viewer' then 'viewer' else 'member' end,
  null
from public.users u
where u.status = 'active'
  and not exists (
    select 1 from public.board_subscribers bs
    where bs.board_id = '28472783-6d7a-4de9-8834-2354f62856c5'::uuid
      and bs.user_id  = u.id
  )
on conflict (board_id, user_id) do nothing;

-- ---------- [2] Patch admin_create_user -----------------------------
-- Body byte-identical to the live function except for the new step 5
-- (board_subscribers insert) appended before the return.
create or replace function public.admin_create_user(
  p_username  text,
  p_full_name text,
  p_role      text,
  p_password  text
) returns jsonb
language plpgsql security definer set search_path = public as $$
declare
  v_email      text;
  v_username   text;
  v_user_id    uuid := gen_random_uuid();
  v_ws_id      uuid;
  v_full_name  text;
begin
  if not public.is_admin() then
    raise exception 'Admin required' using errcode='42501';
  end if;
  if p_role not in ('manager','viewer') then
    raise exception 'New users can only be created as manager or viewer' using errcode='22023';
  end if;
  if p_password is null or length(p_password) < 8 then
    raise exception 'Password must be at least 8 characters' using errcode='22023';
  end if;

  v_username := lower(trim(coalesce(p_username,'')));
  if v_username = '' or v_username !~ '^[a-z0-9_]{2,32}$' then
    raise exception 'Username must be 2-32 characters of lowercase letters, digits, or underscore' using errcode='22023';
  end if;
  if exists (select 1 from public.users where username = v_username) then
    raise exception 'Username "%" already exists', v_username using errcode='23505';
  end if;
  v_email := v_username || '@pms.internal';
  v_full_name := coalesce(nullif(trim(p_full_name), ''), v_username);

  -- 1. Insert auth.users
  insert into auth.users (
    instance_id, id, aud, role, email, encrypted_password, email_confirmed_at,
    raw_app_meta_data, raw_user_meta_data, created_at, updated_at,
    confirmation_token, recovery_token, email_change_token_new, email_change,
    is_sso_user, is_anonymous
  ) values (
    '00000000-0000-0000-0000-000000000000',
    v_user_id, 'authenticated', 'authenticated',
    v_email, extensions.crypt(p_password, extensions.gen_salt('bf')), now(),
    jsonb_build_object('provider', 'email', 'providers', jsonb_build_array('email')),
    jsonb_build_object('username', v_username, 'full_name', v_full_name),
    now(), now(),
    '', '', '', '',
    false, false
  );

  -- 2. Insert auth.identities
  insert into auth.identities (
    provider_id, user_id, identity_data, provider,
    last_sign_in_at, created_at, updated_at
  ) values (
    v_user_id::text, v_user_id,
    jsonb_build_object('sub', v_user_id::text, 'email', v_email, 'email_verified', true, 'phone_verified', false),
    'email', null, now(), now()
  );

  -- 3. Insert public.users
  insert into public.users (id, email, username, full_name, role, status, is_super_admin)
  values (v_user_id, v_email, v_username, v_full_name, p_role, 'active', false);

  -- 4. Main workspace
  select id into v_ws_id from public.workspaces where is_main = true limit 1;
  if v_ws_id is not null then
    insert into public.workspace_members (workspace_id, user_id, role)
    values (v_ws_id, v_user_id, 'member')
    on conflict do nothing;
  end if;

  -- 5. Tessera board membership (mirrors accept_invite's shape).
  -- Without this row, can_access_board(Tessera) returns false and
  -- groups_select hides every group + masks all GUV grants.
  insert into public.board_subscribers (board_id, user_id, role, group_id)
  values (
    '28472783-6d7a-4de9-8834-2354f62856c5'::uuid,
    v_user_id,
    case when p_role = 'viewer' then 'viewer' else 'member' end,
    null
  )
  on conflict (board_id, user_id) do nothing;

  return jsonb_build_object('id', v_user_id, 'username', v_username);
end;
$$;

revoke all on function public.admin_create_user(text, text, text, text) from public;
grant execute on function public.admin_create_user(text, text, text, text) to authenticated;
