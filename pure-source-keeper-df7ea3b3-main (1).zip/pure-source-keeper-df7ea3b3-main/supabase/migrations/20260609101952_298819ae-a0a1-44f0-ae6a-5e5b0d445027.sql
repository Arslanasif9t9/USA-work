-- ===== FILE: 20260520_0001_phase1_schema.sql =====
create extension if not exists "uuid-ossp";
create extension if not exists pgcrypto;

create table if not exists public.account (
  id uuid primary key default uuid_generate_v4(),
  name text not null,
  gemini_api_key_encrypted text,
  settings jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.users (
  id uuid primary key,
  email text not null unique,
  username text not null unique,
  full_name text,
  avatar_url text,
  role text not null default 'manager' check (role in ('admin','manager','viewer')),
  status text not null default 'active' check (status in ('active','deactivated')),
  is_super_admin boolean not null default false,
  theme text not null default 'light' check (theme in ('light','dark')),
  timezone text not null default 'UTC',
  title text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  constraint users_id_fk_auth foreign key (id) references auth.users(id) on delete cascade
);

create index if not exists users_username_idx on public.users (username);
create index if not exists users_role_idx on public.users (role);
create index if not exists users_status_idx on public.users (status);
