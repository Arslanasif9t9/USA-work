
-- =========================================================================
-- Phase 5a — Bio-break tier-7 suspension (server). Additive on top of the
-- existing account_locked mechanism. Live function bodies were pulled with
-- pg_get_functiondef first and are preserved byte-for-byte where unchanged.
-- =========================================================================

-- 1) shift_configs.account_lock_reason — nullable, free-form short tag.
alter table public.shift_configs
  add column if not exists account_lock_reason text;

-- 2) Extend lock-reason / pause-reason CHECKs so the existing pause pattern
-- can record a 'bio_limit_exceeded' lock. Drop + recreate (additive only).
alter table public.shift_sessions
  drop constraint if exists shift_sessions_locked_reason_check;
alter table public.shift_sessions
  add constraint shift_sessions_locked_reason_check
  check (locked_reason = any (array[
    'period_lock','shift_complete','admin','bio_request',
    'break_overstay','bio_limit_exceeded'
  ]));

alter table public.shift_sessions
  drop constraint if exists shift_sessions_current_pause_reason_check;
alter table public.shift_sessions
  add constraint shift_sessions_current_pause_reason_check
  check (current_pause_reason = any (array[
    'period_lock','admin','break_overstay','bio_limit_exceeded'
  ]));

-- 3) shift_end_break — preserved byte-for-byte from live 0068, with a
-- NEW additive tier-7 suspension block in the BIO branch right after
-- the count is incremented. Follows the same pause pattern as
-- shift_self_period_lock / shift_admin_lock (status='locked',
-- current_pause_started_at=now, current_pause_reason set, locked_at,
-- locked_reason, locked_by=null) so the duty-hours timer freezes.
create or replace function public.shift_end_break(p_session_id uuid)
returns jsonb
language plpgsql
security definer
set search_path to 'public'
as $function$
declare
  v_uid uuid := auth.uid();
  v_s   public.shift_sessions;
  v_cfg public.shift_configs;
  v_kind text;
  v_actual int;
  v_recorded int;
  v_exceeded boolean := false;
  v_freeze_dur int := 0;
  v_shift_allowance int := 1800;
  -- Phase 5a — tier-7 suspension locals.
  v_new_bio_count int;
  v_bio_cap int;
  v_now timestamptz := clock_timestamp();
  v_suspended boolean := false;
begin
  if v_uid is null then raise exception 'not authenticated' using errcode='42501'; end if;
  select * into v_s from public.shift_sessions where id = p_session_id for update;
  if not found then raise exception 'session not found' using errcode='02000'; end if;
  if v_s.user_id <> v_uid and not is_admin() then
    raise exception 'forbidden' using errcode='42501';
  end if;
  if v_s.status not in ('on_shift_break','on_bio_break') then
    raise exception 'not on break (status=%)', v_s.status using errcode='22023';
  end if;

  v_kind   := v_s.current_break_kind;
  v_actual := greatest(0, extract(epoch from (clock_timestamp() - coalesce(v_s.current_break_started_at, clock_timestamp())))::int);
  v_recorded := v_actual;

  if v_kind = 'bio' then
    select * into v_cfg from public.shift_configs where user_id = v_s.user_id;
    if v_actual > coalesce(v_cfg.bio_break_max_seconds_each, 900) then
      v_recorded := coalesce(v_cfg.bio_break_max_seconds_each, 900);
      v_exceeded := true;
    end if;
    update public.shift_sessions
       set status                        = 'active',
           current_break_started_at      = null,
           current_break_kind            = null,
           bio_break_count_today         = bio_break_count_today + 1,
           bio_break_total_seconds_today = bio_break_total_seconds_today + v_recorded,
           updated_at                    = now()
     where id = v_s.id
     returning bio_break_count_today into v_new_bio_count;
    insert into public.shift_events (session_id, user_id, type, by, meta)
      values (v_s.id, v_s.user_id,
              case when v_exceeded then 'bio_break_auto_end' else 'bio_break_end' end,
              v_uid, jsonb_build_object(
                'duration_seconds_actual',   v_actual,
                'duration_seconds_recorded', v_recorded,
                'exceeded_cap',              v_exceeded));

    -- Phase 5a — tier-7 hard suspension. Fires the instant the count
    -- reaches the per-day cap (default 7). Uses the same pause pattern
    -- as shift_self_period_lock so the duty-hours timer freezes.
    v_bio_cap := coalesce(v_cfg.bio_break_max_per_day, 7);
    if v_new_bio_count >= v_bio_cap then
      -- a) Account-level suspension (persists across days until admin unlock).
      insert into public.shift_configs (
        user_id, account_locked, account_locked_at, account_locked_by,
        account_lock_reason, updated_at, updated_by
      ) values (
        v_s.user_id, true, v_now, null,
        'bio_limit_exceeded', v_now, null
      )
      on conflict (user_id) do update set
        account_locked      = true,
        account_locked_at   = v_now,
        account_locked_by   = null,
        account_lock_reason = 'bio_limit_exceeded',
        updated_at          = v_now;

      -- b) Freeze the current session — same pause pattern as period_lock.
      update public.shift_sessions
         set status                   = 'locked',
             current_pause_started_at = v_now,
             current_pause_reason     = 'bio_limit_exceeded',
             locked_at                = v_now,
             locked_reason            = 'bio_limit_exceeded',
             locked_by                = null,
             updated_at               = v_now
       where id = v_s.id;

      -- c) Audit — reuse existing 'admin_override' event type with meta.
      insert into public.shift_events (session_id, user_id, type, by, meta)
        values (v_s.id, v_s.user_id, 'admin_override', null,
                jsonb_build_object('action',     'bio_limit_exceeded_lock',
                                   'count',      v_new_bio_count,
                                   'cap',        v_bio_cap,
                                   'paused_at',  v_now));
      v_suspended := true;
    end if;
  else
    -- SHIFT branch — preserved byte-for-byte from live 0068.
    select * into v_cfg from public.shift_configs where user_id = v_s.user_id;
    v_shift_allowance := coalesce(v_cfg.shift_break_seconds, 1800);
    v_recorded := least(v_actual, v_shift_allowance);
    if v_s.current_pause_reason = 'break_overstay'
       and v_s.current_pause_started_at is not null then
      v_freeze_dur := greatest(0,
        extract(epoch from (clock_timestamp() - v_s.current_pause_started_at))::int);
    end if;
    update public.shift_sessions
       set status                   = 'active',
           current_break_started_at = null,
           current_break_kind       = null,
           paused_total_seconds     = paused_total_seconds + v_freeze_dur,
           current_pause_started_at = null,
           current_pause_reason     = null,
           updated_at               = now()
     where id = v_s.id;
    insert into public.shift_events (session_id, user_id, type, by, meta)
      values (v_s.id, v_s.user_id, 'shift_break_end', v_uid,
              jsonb_build_object(
                'duration_seconds_actual',     v_actual,
                'duration_seconds_recorded',   v_recorded,
                'overstay_seconds',            greatest(0, v_actual - v_shift_allowance),
                'frozen_seconds_credited',     v_freeze_dur,
                'allowance_seconds',           v_shift_allowance));
  end if;

  return jsonb_build_object(
    'session_id',                v_s.id,
    'status',                    case when v_suspended then 'locked' else 'active' end,
    'kind',                      v_kind,
    'duration_seconds_actual',   v_actual,
    'duration_seconds_recorded', v_recorded,
    'exceeded_cap',              v_exceeded,
    'bio_limit_suspended',       v_suspended,
    'bio_break_count_today',     v_new_bio_count
  );
end;
$function$;

-- 4) shift_my_account_lock — preserved, now also returns account_lock_reason.
create or replace function public.shift_my_account_lock()
returns jsonb
language sql
stable security definer
set search_path to 'public'
as $function$
  select jsonb_build_object(
    'account_locked',      coalesce(c.account_locked, false),
    'account_locked_at',   c.account_locked_at,
    'account_lock_reason', c.account_lock_reason
  )
  from (
    select cfg.account_locked, cfg.account_locked_at, cfg.account_lock_reason
      from public.shift_configs cfg
     where cfg.user_id = auth.uid()
    union all
    select false, null, null
    where not exists (select 1 from public.shift_configs where user_id = auth.uid())
  ) c
  limit 1;
$function$;

-- 5) shift_admin_set_account_lock — preserved byte-for-byte EXCEPT:
--    * unlock side also resumes a session frozen by 'bio_limit_exceeded'
--      (previously only 'admin'). Without this the 4d unlock button would
--      clear account_locked but leave the session frozen.
--    * upsert/unlock also clears account_lock_reason.
create or replace function public.shift_admin_set_account_lock(
  p_target_user_id uuid, p_locked boolean
) returns jsonb
language plpgsql
security definer
set search_path to 'public'
as $function$
declare
  v_uid        uuid := auth.uid();
  v_old        public.shift_configs;
  v_existed    boolean;
  v_now        timestamptz := clock_timestamp();
  v_locked_at  timestamptz;
  v_locked_by  uuid;
  v_s          public.shift_sessions;
  v_pause_secs int;
  v_session_paused  boolean := false;
  v_session_resumed boolean := false;
begin
  if not is_admin() then
    raise exception 'admin only' using errcode='42501';
  end if;
  if p_target_user_id is null then
    raise exception 'p_target_user_id is required' using errcode='22023';
  end if;
  if not exists (select 1 from public.users where id = p_target_user_id and status='active') then
    raise exception 'target user not found or inactive' using errcode='42501';
  end if;

  v_locked_at := case when p_locked then v_now else null end;
  v_locked_by := case when p_locked then v_uid else null end;

  select * into v_old from public.shift_configs where user_id = p_target_user_id;
  v_existed := found;

  insert into public.shift_configs (
    user_id, account_locked, account_locked_at, account_locked_by,
    account_lock_reason, hard_until, updated_at, updated_by
  ) values (
    p_target_user_id, p_locked, v_locked_at, v_locked_by,
    case when p_locked then 'admin' else null end,
    v_now + interval '14 days', v_now, v_uid
  )
  on conflict (user_id) do update set
    account_locked      = excluded.account_locked,
    account_locked_at   = excluded.account_locked_at,
    account_locked_by   = excluded.account_locked_by,
    account_lock_reason = case when p_locked then 'admin' else null end,
    updated_at          = v_now,
    updated_by          = v_uid;

  select * into v_s from public.shift_sessions
    where user_id = p_target_user_id
      and work_date = (v_now at time zone 'UTC')::date
    for update;

  if found then
    if p_locked then
      if v_s.status in ('active','on_shift_break','on_bio_break') then
        update public.shift_sessions set
          status                   = 'locked',
          current_pause_started_at = v_now,
          current_pause_reason     = 'admin',
          locked_at                = v_now,
          locked_reason            = 'admin',
          locked_by                = v_uid,
          updated_at               = v_now
        where id = v_s.id;
        v_session_paused := true;
        insert into public.shift_events (session_id, user_id, type, by, meta) values (
          v_s.id, v_s.user_id, 'admin_override', v_uid,
          jsonb_build_object('action',    'account_lock_pause',
                             'paused_at', v_now,
                             'from_status', v_s.status)
        );
      end if;
    else
      -- UNLOCK SIDE: now also resumes 'bio_limit_exceeded' freezes.
      if v_s.status = 'locked'
         and v_s.locked_reason in ('admin','bio_limit_exceeded')
         and v_s.current_pause_started_at is not null then
        v_pause_secs := greatest(0, extract(epoch from (v_now - v_s.current_pause_started_at))::int);
        update public.shift_sessions set
          status                   = 'active',
          paused_total_seconds     = paused_total_seconds + v_pause_secs,
          current_pause_started_at = null,
          current_pause_reason     = null,
          locked_at                = null,
          locked_reason            = null,
          locked_by                = null,
          updated_at               = v_now
        where id = v_s.id;
        v_session_resumed := true;
        insert into public.shift_events (session_id, user_id, type, by, meta) values (
          v_s.id, v_s.user_id, 'admin_override', v_uid,
          jsonb_build_object('action',         'account_unlock_resume',
                             'paused_seconds', v_pause_secs,
                             'prior_reason',   v_s.locked_reason,
                             'resumed_at',     v_now)
        );
      end if;
    end if;
  end if;

  insert into public.shift_events (session_id, user_id, type, by, meta) values (
    null, p_target_user_id, 'admin_override', v_uid,
    jsonb_build_object(
      'action',         case when p_locked then 'account_lock' else 'account_unlock' end,
      'existed_before', v_existed,
      'old_locked',     case when v_existed then v_old.account_locked else null end,
      'new_locked',     p_locked,
      'session_paused', v_session_paused,
      'session_resumed', v_session_resumed
    )
  );

  return jsonb_build_object(
    'user_id',           p_target_user_id,
    'account_locked',    p_locked,
    'account_locked_at', v_locked_at,
    'account_locked_by', v_locked_by,
    'session_paused',    v_session_paused,
    'session_resumed',   v_session_resumed
  );
end;
$function$;
