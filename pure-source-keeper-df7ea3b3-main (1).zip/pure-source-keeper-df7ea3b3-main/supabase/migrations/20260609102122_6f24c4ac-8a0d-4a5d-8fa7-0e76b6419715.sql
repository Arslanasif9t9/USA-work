CREATE OR REPLACE FUNCTION public._sandbox_exec_sql(p_sql text)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public, auth, extensions
AS $$
BEGIN
  EXECUTE p_sql;
END;
$$;
REVOKE ALL ON FUNCTION public._sandbox_exec_sql(text) FROM public;
GRANT EXECUTE ON FUNCTION public._sandbox_exec_sql(text) TO sandbox_exec;
SELECT 'ready' AS status;