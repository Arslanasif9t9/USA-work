CREATE OR REPLACE FUNCTION public.shift_admin_set_can_work_now(p_target_user_id uuid, p_can boolean)
RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path TO 'public'
AS $fn$
declare
  v_admin uuid := auth.uid();
begin
  if not public.is_admin() then raise exception 'admin only' using errcode = '42501'; end if;
  if p_target_user_id is null then raise exception 'p_target_user_id required' using errcode = '22023'; end if;

  insert into public.shift_configs (user_id, can_work_now, updated_at)
  values (p_target_user_id, coalesce(p_can, false), now())
  on conflict (user_id) do update
    set can_work_now = excluded.can_work_now, updated_at = now();

  begin
    insert into public.shift_events (user_id, type, by, meta)
    values (p_target_user_id, 'admin_override', v_admin,
            jsonb_build_object('action', 'set_can_work_now', 'can_work_now', coalesce(p_can, false)));
  exception when others then null;
  end;

  return jsonb_build_object('ok', true, 'can_work_now', coalesce(p_can, false));
end;
$fn$;