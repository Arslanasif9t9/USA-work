CREATE OR REPLACE FUNCTION public.shift_admin_set_can_work_now(
  p_target_user_id uuid,
  p_can boolean
) RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $fn$
declare
  v_admin uuid := auth.uid();
  v_row public.shift_configs;
  v_tz text;
  v_local_now timestamp;
  v_local_today date;
  v_local_time time;
  v_local_wd int;
  v_sched public.shift_schedules;
  v_has_any_sched boolean;
  v_within_schedule boolean := false;
  v_active_session public.shift_sessions;
  v_locked boolean := false;
begin
  if v_admin is null or not is_admin() then
    raise exception 'admin only' using errcode = '42501';
  end if;
  if p_target_user_id is null then
    raise exception 'target user required' using errcode = '22023';
  end if;

  -- Upsert: ensure a config row exists, then set the flag.
  insert into public.shift_configs (user_id, can_work_now)
    values (p_target_user_id, coalesce(p_can, false))
  on conflict (user_id) do update
    set can_work_now = coalesce(p_can, false),
        updated_at   = now()
  returning * into v_row;

  -- Audit trail for the override flip (best-effort).
  begin
    insert into public.shift_events (session_id, user_id, type, by, meta)
      select s.id, p_target_user_id, 'admin_override', v_admin,
             jsonb_build_object('action', 'set_can_work_now', 'value', coalesce(p_can, false))
      from public.shift_sessions s
      where s.user_id = p_target_user_id
        and s.work_date = (now() at time zone coalesce(v_row.timezone, 'Asia/Manila'))::date
      limit 1;
  exception when others then
    null;
  end;

  -- Enforcement: when override is being turned OFF, if the user has an
  -- active session AND is currently outside their scheduled shift window,
  -- account-lock them now (admin action, not a period boundary).
  if coalesce(p_can, false) = false then
    v_tz := coalesce(v_row.timezone, 'Asia/Manila');

    select * into v_active_session
      from public.shift_sessions
     where user_id = p_target_user_id
       and status = 'active'
     order by started_at desc nulls last
     limit 1;

    if found then
      -- Determine if "now" is within the user's scheduled window
      -- using the same logic as shift_can_start() (minus the override).
      v_local_now   := (now() at time zone v_tz);
      v_local_today := v_local_now::date;
      v_local_time  := v_local_now::time;
      v_local_wd    := extract(dow from v_local_today)::int;

      if coalesce(v_row.shift_mode, 'manual') = 'manual' then
        v_within_schedule := true;
      else
        select exists (
          select 1 from public.shift_schedules
           where user_id = p_target_user_id
             and enabled = true
             and start_time_local is not null
        ) into v_has_any_sched;

        if not v_has_any_sched then
          v_within_schedule := true;
        elsif v_row.shift_start_date is not null
              and v_local_today < v_row.shift_start_date then
          v_within_schedule := false;
        else
          select * into v_sched from public.shift_schedules
            where user_id = p_target_user_id and weekday = v_local_wd;

          if not found or not v_sched.enabled or v_sched.start_time_local is null then
            v_within_schedule := false;
          elsif v_local_time < v_sched.start_time_local then
            v_within_schedule := false;
          elsif v_sched.end_time_local is not null
                and v_local_time > v_sched.end_time_local then
            v_within_schedule := false;
          else
            v_within_schedule := true;
          end if;
        end if;
      end if;

      if not v_within_schedule then
        -- Account lock (admin-driven, not a period lock).
        update public.shift_configs
           set account_locked     = true,
               account_locked_at  = now(),
               account_locked_by  = v_admin,
               account_lock_reason= 'admin removed can_work_now outside scheduled hours',
               updated_at         = now()
         where user_id = p_target_user_id;

        -- Lock the active session itself so the panel reflects it immediately.
        update public.shift_sessions
           set status        = 'locked',
               locked_at     = now(),
               locked_by     = v_admin,
               locked_reason = 'admin removed can_work_now outside scheduled hours',
               updated_at    = now()
         where id = v_active_session.id;

        -- Audit event for the auto-lock.
        begin
          insert into public.shift_events (session_id, user_id, type, by, meta)
            values (
              v_active_session.id,
              p_target_user_id,
              'account_lock',
              v_admin,
              jsonb_build_object(
                'source', 'admin_override_removed',
                'reason', 'outside scheduled hours',
                'at',     now()
              )
            );
        exception when others then
          null;
        end;

        v_locked := true;
      end if;
    end if;
  end if;

  return jsonb_build_object(
    'user_id',            v_row.user_id,
    'can_work_now',       v_row.can_work_now,
    'auto_locked',        v_locked
  );
end;
$fn$;