
-- =====================================================================
-- 0078 — Admin "Adjust Time" per-day
-- =====================================================================
-- Adds a single nullable-ish int column to shift_sessions to hold
-- per-day admin adjustments (+/-). Original accounting fields
-- (started_at, paused_total_seconds, required_seconds) are NEVER
-- mutated by this feature, so the historic ledger stays auditable.
-- =====================================================================

alter table public.shift_sessions
  add column if not exists admin_adjust_seconds int not null default 0;

comment on column public.shift_sessions.admin_adjust_seconds is
  '0078 — Per-day admin time adjustment in seconds. Positive = ADD time owed (remaining grows). Negative = CREDIT time (remaining shrinks). Applied as: remaining = required_seconds + admin_adjust_seconds - elapsed. NEVER mutates started_at / paused_total_seconds / required_seconds.';

-- ---------------------------------------------------------------------
-- 1) shift_admin_adjust_time(p_target_user_id, p_delta_seconds, p_note)
-- ---------------------------------------------------------------------
create or replace function public.shift_admin_adjust_time(
  p_target_user_id uuid,
  p_delta_seconds  int,
  p_note           text default null
) returns jsonb
language plpgsql
security definer
set search_path to 'public'
as $$
declare
  v_uid   uuid := auth.uid();
  v_today date := (now() at time zone 'UTC')::date;
  v_s     public.shift_sessions;
  v_cfg   public.shift_configs;
  v_old   int;
  v_new   int;
begin
  if not is_admin() then
    raise exception 'admin only' using errcode='42501';
  end if;
  if p_target_user_id is null then
    raise exception 'p_target_user_id is required' using errcode='22023';
  end if;
  if p_delta_seconds is null or p_delta_seconds = 0 then
    raise exception 'p_delta_seconds must be non-zero' using errcode='22023';
  end if;
  if abs(p_delta_seconds) > 24*3600 then
    raise exception 'delta out of range (max +/- 24h)' using errcode='22023';
  end if;

  -- Find today's session row. Do NOT auto-create — adjustment only
  -- makes sense once the session exists (otherwise required_seconds
  -- is not snapshotted yet).
  select * into v_s
    from public.shift_sessions
   where user_id = p_target_user_id and work_date = v_today
   for update;
  if not found then
    raise exception 'no session for target user today — adjustment requires an existing session row'
      using errcode='02000';
  end if;

  v_old := v_s.admin_adjust_seconds;
  v_new := v_old + p_delta_seconds;

  update public.shift_sessions
     set admin_adjust_seconds = v_new,
         updated_at           = now()
   where id = v_s.id;

  insert into public.shift_events (session_id, user_id, type, by, meta)
  values (
    v_s.id, p_target_user_id, 'admin_override', v_uid,
    jsonb_build_object(
      'action',                'adjust_time',
      'delta_seconds',         p_delta_seconds,
      'old_adjust_seconds',    v_old,
      'new_adjust_seconds',    v_new,
      'required_seconds',      v_s.required_seconds,
      'note',                  p_note
    )
  );

  return jsonb_build_object(
    'session_id',           v_s.id,
    'user_id',              p_target_user_id,
    'delta_seconds',        p_delta_seconds,
    'old_adjust_seconds',   v_old,
    'new_adjust_seconds',   v_new,
    'required_seconds',     v_s.required_seconds,
    'effective_required',   v_s.required_seconds + v_new
  );
end;
$$;

revoke all on function public.shift_admin_adjust_time(uuid, int, text) from public, anon;
grant execute on function public.shift_admin_adjust_time(uuid, int, text) to authenticated;

-- ---------------------------------------------------------------------
-- 2) shift_tick — same body as 20260611095324; only v_remain formula
--    now includes admin_adjust_seconds, and payload surfaces it.
-- ---------------------------------------------------------------------
create or replace function public.shift_tick(p_session_id uuid)
returns jsonb
language plpgsql
stable
security definer
set search_path = public
as $$
declare
  v_uid uuid := auth.uid();
  v_s public.shift_sessions;
  v_cfg public.shift_configs;
  v_admin boolean;
  v_elapsed int;
  v_remain int;
  v_period_start int;
  v_period_end   int;
  v_85_threshold int;
  v_85_due boolean;
  v_lock_due boolean;
  v_break_elapsed int;
  v_eff_max int;
  v_shift_break_allowance int;
  v_overstay_grace int;
  v_user_mode text;
  v_paused boolean;
  v_eff_required int;
begin
  if v_uid is null then raise exception 'not authenticated' using errcode='42501'; end if;
  v_admin := is_admin();
  select * into v_s from public.shift_sessions where id = p_session_id;
  if not found then raise exception 'session not found' using errcode='02000'; end if;
  if v_s.user_id <> v_uid and not v_admin then raise exception 'forbidden' using errcode='42501'; end if;
  select * into v_cfg from public.shift_configs where user_id = v_s.user_id;
  v_user_mode := coalesce(v_cfg.shift_mode, 'manual');
  v_paused    := public.shift_locks_globally_paused();

  if v_s.started_at is null then
    v_elapsed := 0;
  else
    v_elapsed := greatest(0,
      extract(epoch from (clock_timestamp() - v_s.started_at))::int
      - v_s.paused_total_seconds
      - case when v_s.current_pause_started_at is not null
             then extract(epoch from (clock_timestamp() - v_s.current_pause_started_at))::int
             else 0 end
    );
  end if;

  -- 0078 — effective required includes per-day admin adjustment.
  v_eff_required := greatest(0, v_s.required_seconds + coalesce(v_s.admin_adjust_seconds, 0));
  v_remain       := greatest(0, v_eff_required - v_elapsed);

  v_period_start := v_s.current_period_index * v_s.period_seconds;
  v_period_end   := (v_s.current_period_index + 1) * v_s.period_seconds;
  v_85_threshold := v_period_start + (v_s.period_seconds * 0.85)::int;
  v_85_due := v_elapsed >= v_85_threshold
              and v_s.period_85_last_index_alerted < v_s.current_period_index
              and v_s.status in ('active','on_shift_break','on_bio_break');
  v_lock_due := v_elapsed >= v_period_end
              and v_s.status in ('active','on_shift_break','on_bio_break');

  if v_user_mode = 'manual' then
    v_85_due   := false;
    v_lock_due := false;
  end if;

  if v_paused then
    v_85_due   := false;
    v_lock_due := false;
  end if;

  v_break_elapsed := case
    when v_s.current_break_started_at is null then 0
    else greatest(0, extract(epoch from (clock_timestamp() - v_s.current_break_started_at))::int)
  end;
  v_eff_max := coalesce(v_cfg.bio_break_max_per_day, 7);
  v_shift_break_allowance := coalesce(v_cfg.shift_break_seconds, 1800);
  v_overstay_grace := coalesce(v_cfg.shift_break_overstay_grace_seconds, 900);

  return jsonb_build_object(
    'session_id',                     v_s.id,
    'user_id',                        v_s.user_id,
    'status',                         v_s.status,
    'started_at',                     v_s.started_at,
    'work_date',                      v_s.work_date,
    'mode',                           v_s.mode,
    'shift_mode',                     v_user_mode,
    'locks_globally_paused',          v_paused,
    'period_seconds',                 v_s.period_seconds,
    'required_seconds',               v_s.required_seconds,
    'admin_adjust_seconds',           coalesce(v_s.admin_adjust_seconds, 0),
    'effective_required_seconds',     v_eff_required,
    'elapsed_seconds',                v_elapsed,
    'remaining_seconds',              v_remain,
    'paused_total_seconds',           v_s.paused_total_seconds,
    'current_period_index',           v_s.current_period_index,
    'current_period_start_seconds',   v_period_start,
    'current_period_end_seconds',     v_period_end,
    'period_85_threshold_seconds',    v_85_threshold,
    'period_85_due',                  v_85_due,
    'period_lock_due',                v_lock_due,
    'current_break_kind',             v_s.current_break_kind,
    'current_break_started_at',       v_s.current_break_started_at,
    'current_break_elapsed_seconds',  v_break_elapsed,
    'bio_break_count_today',          v_s.bio_break_count_today,
    'bio_break_total_seconds_today',  v_s.bio_break_total_seconds_today,
    'bio_break_admin_grants_today',   v_s.bio_break_admin_grants_today,
    'bio_break_max_per_day',          v_cfg.bio_break_max_per_day,
    'bio_break_warn_count',           v_cfg.bio_break_warn_count,
    'bio_break_warn_total_seconds',   v_cfg.bio_break_warn_total_seconds,
    'bio_break_max_seconds_each',     v_cfg.bio_break_max_seconds_each,
    'bio_limit_reached',              (v_user_mode <> 'manual'
                                        and v_s.bio_break_count_today >= v_eff_max),
    'locked_at',                      v_s.locked_at,
    'locked_reason',                  v_s.locked_reason,
    'completed_at',                   v_s.completed_at,
    'scheduled_start_at',             v_s.scheduled_start_at,
    'expected_end_at',                v_s.expected_end_at,
    'late_start_flag',                v_s.late_start_flag,
    'late_start_minutes',             v_s.late_start_minutes,
    'early_end_flag',                 v_s.early_end_flag,
    'early_end_minutes',              v_s.early_end_minutes,
    'shift_break_count_today',        v_s.shift_break_count_today,
    'shift_break_used_today',         v_s.shift_break_count_today >= 1,
    'shift_break_seconds',            v_shift_break_allowance,
    'shift_break_overstay',           (v_s.status = 'on_shift_break'
                                        and v_s.current_break_kind = 'shift'
                                        and v_break_elapsed >= v_shift_break_allowance),
    'shift_break_overstay_seconds',   greatest(0, v_break_elapsed - v_shift_break_allowance),
    'shift_break_frozen',             coalesce(v_s.current_pause_reason = 'break_overstay', false),
    'shift_break_overstay_grace_seconds', v_overstay_grace,
    'skip_next_period_lock',          v_s.skip_next_period_lock,
    'now',                            clock_timestamp()
  );
end;
$$;
revoke all on function public.shift_tick(uuid) from public, anon;
grant execute on function public.shift_tick(uuid) to authenticated;

-- ---------------------------------------------------------------------
-- 3) shift_complete_if_due — include admin_adjust_seconds.
-- ---------------------------------------------------------------------
create or replace function public.shift_complete_if_due(p_session_id uuid)
  returns jsonb
  language plpgsql
  security definer
  set search_path to 'public'
as $$
declare
  v_uid          uuid := auth.uid();
  v_s            public.shift_sessions;
  v_elapsed      int;
  v_eff_required int;
  v_was          text;
begin
  if v_uid is null then
    null;
  else
    select * into v_s from public.shift_sessions where id = p_session_id for update;
    if not found then raise exception 'session not found' using errcode='02000'; end if;
    if v_s.user_id <> v_uid and not is_admin() then
      raise exception 'forbidden' using errcode='42501';
    end if;
  end if;

  if v_uid is null then
    select * into v_s from public.shift_sessions where id = p_session_id for update;
    if not found then raise exception 'session not found' using errcode='02000'; end if;
  end if;

  if v_s.status = 'completed' then
    return jsonb_build_object(
      'session_id',        v_s.id,
      'already_completed', true,
      'completed_at',      v_s.completed_at
    );
  end if;

  if v_s.started_at is null then
    v_elapsed := 0;
  else
    v_elapsed := greatest(0,
      extract(epoch from (clock_timestamp() - v_s.started_at))::int
      - v_s.paused_total_seconds
      - case when v_s.current_pause_started_at is not null
             then extract(epoch from (clock_timestamp() - v_s.current_pause_started_at))::int
             else 0 end
    );
  end if;

  v_eff_required := greatest(0, v_s.required_seconds + coalesce(v_s.admin_adjust_seconds, 0));

  if v_elapsed < v_eff_required then
    return jsonb_build_object(
      'session_id',        v_s.id,
      'already_completed', false,
      'due',               false,
      'elapsed_seconds',   v_elapsed,
      'remaining_seconds', v_eff_required - v_elapsed
    );
  end if;

  if v_s.status not in ('active','on_shift_break','on_bio_break') then
    return jsonb_build_object(
      'session_id',        v_s.id,
      'already_completed', false,
      'due',               true,
      'completed',         false,
      'reason',            'wrong_status',
      'status',            v_s.status
    );
  end if;

  v_was := v_s.status;

  update public.shift_sessions
     set status        = 'completed',
         completed_at  = now(),
         locked_reason = 'shift_complete',
         current_break_started_at = null,
         current_break_kind       = null,
         updated_at    = now()
   where id = v_s.id;

  insert into public.shift_events (session_id, user_id, type, by, meta)
    values (v_s.id, v_s.user_id, 'shift_complete', v_uid,
            jsonb_build_object(
              'worked_seconds',  v_elapsed,
              'from_status',     v_was,
              'auto_swept',      false,
              'admin_adjust_seconds', coalesce(v_s.admin_adjust_seconds, 0)
            ));

  return jsonb_build_object(
    'session_id',        v_s.id,
    'already_completed', false,
    'due',               true,
    'completed',         true,
    'worked_seconds',    v_elapsed,
    'from_status',       v_was
  );
end;
$$;

-- ---------------------------------------------------------------------
-- 4) shift_sweep_due_and_orphans — include admin_adjust_seconds.
-- ---------------------------------------------------------------------
create or replace function public.shift_sweep_due_and_orphans()
  returns jsonb
  language plpgsql
  security definer
  set search_path to 'public'
as $$
declare
  v_uid uuid := auth.uid();
  v_today date := (now() at time zone 'UTC')::date;
  v_completed_today uuid[] := '{}';
  v_orphan_user_ids uuid[] := '{}';
  v_orphan_count int := 0;
  v_completed_count int := 0;
  v_elapsed int;
  v_eff_required int;
  r record;
begin
  if v_uid is not null and not is_admin() then
    raise exception 'admin or service role only' using errcode='42501';
  end if;

  for r in
    select * from public.shift_sessions
     where work_date = v_today
       and status in ('active','on_shift_break','on_bio_break')
       and started_at is not null
     for update
  loop
    v_elapsed := greatest(0,
      extract(epoch from (clock_timestamp() - r.started_at))::int
      - r.paused_total_seconds
      - case when r.current_pause_started_at is not null
             then extract(epoch from (clock_timestamp() - r.current_pause_started_at))::int
             else 0 end
    );
    v_eff_required := greatest(0, r.required_seconds + coalesce(r.admin_adjust_seconds, 0));
    if v_elapsed >= v_eff_required then
      update public.shift_sessions
         set status        = 'completed',
             completed_at  = now(),
             locked_reason = 'shift_complete',
             current_break_started_at = null,
             current_break_kind       = null,
             updated_at    = now()
       where id = r.id;
      insert into public.shift_events (session_id, user_id, type, by, meta)
        values (r.id, r.user_id, 'shift_complete', v_uid,
                jsonb_build_object(
                  'worked_seconds', v_elapsed,
                  'from_status',    r.status,
                  'auto_swept',     true,
                  'admin_adjust_seconds', coalesce(r.admin_adjust_seconds, 0)
                ));
      v_completed_today := array_append(v_completed_today, r.user_id);
      v_completed_count := v_completed_count + 1;
    end if;
  end loop;

  for r in
    select * from public.shift_sessions
     where work_date < v_today
       and status not in ('completed','not_started')
     for update
  loop
    update public.shift_sessions
       set status        = 'completed',
           completed_at  = now(),
           current_break_started_at = null,
           current_break_kind       = null,
           updated_at    = now()
     where id = r.id;
    insert into public.shift_events (session_id, user_id, type, by, meta)
      values (r.id, r.user_id, 'admin_override', v_uid,
              jsonb_build_object('action','auto_close_orphaned','prior_status', r.status));
    v_orphan_user_ids := array_append(v_orphan_user_ids, r.user_id);
    v_orphan_count := v_orphan_count + 1;
  end loop;

  return jsonb_build_object(
    'completed_today_count',     v_completed_count,
    'completed_today_user_ids',  v_completed_today,
    'closed_orphan_count',       v_orphan_count,
    'closed_orphan_user_ids',    v_orphan_user_ids,
    'now',                       clock_timestamp()
  );
end;
$$;
