CREATE OR REPLACE FUNCTION public.shift_admin_set_shift_mode(p_user_id uuid, p_mode text)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare
  v_uid       uuid := auth.uid();
  v_has_sched boolean;
  v_start     time := '09:00'::time;
  v_req       int  := 28800;
  v_half      int  := 14400;
  v_tz        text;
  v_today     date;
  v_weekday   int;
  v_sched     public.shift_schedules;
  v_new_req   int;
  v_sess      public.shift_sessions;
  v_reconciled boolean := false;
begin
  if not is_admin() then
    raise exception 'admin only' using errcode='42501';
  end if;
  if p_mode is null or p_mode not in ('auto','manual') then
    raise exception 'p_mode must be auto or manual' using errcode='22023';
  end if;
  if not exists (select 1 from public.users where id = p_user_id and status='active') then
    raise exception 'target user not found or inactive' using errcode='42501';
  end if;

  insert into public.shift_configs (user_id, shift_mode)
  values (p_user_id, p_mode)
  on conflict (user_id) do update set
    shift_mode = excluded.shift_mode;

  if p_mode = 'auto' then
    select exists(
      select 1 from public.shift_schedules where user_id = p_user_id
    ) into v_has_sched;
    if not v_has_sched then
      insert into public.shift_schedules (user_id, weekday, enabled, required_seconds, start_time_local, end_time_local)
      select p_user_id, w, true, v_req, v_start,
             (v_start + make_interval(secs => v_req))::time
        from generate_series(1,5) as w
      on conflict (user_id, weekday) do update set
        enabled          = excluded.enabled,
        required_seconds = excluded.required_seconds,
        start_time_local = excluded.start_time_local,
        end_time_local   = excluded.end_time_local;

      insert into public.shift_schedules (user_id, weekday, enabled, required_seconds, start_time_local, end_time_local)
      values (p_user_id, 6, true, v_half, v_start,
              (v_start + make_interval(secs => v_half))::time)
      on conflict (user_id, weekday) do update set
        enabled          = excluded.enabled,
        required_seconds = excluded.required_seconds,
        start_time_local = excluded.start_time_local,
        end_time_local   = excluded.end_time_local;

      insert into public.shift_schedules (user_id, weekday, enabled, required_seconds, start_time_local, end_time_local)
      values (p_user_id, 0, false, 0, null, null)
      on conflict (user_id, weekday) do update set
        enabled          = excluded.enabled,
        required_seconds = excluded.required_seconds,
        start_time_local = excluded.start_time_local,
        end_time_local   = excluded.end_time_local;
    end if;
  end if;

  -- ---- RECONCILE TODAY'S LIVE SESSION (new) ----
  select coalesce(timezone,'Asia/Manila') into v_tz
    from public.shift_configs where user_id = p_user_id;
  v_today   := (now() at time zone v_tz)::date;
  v_weekday := extract(dow from v_today)::int;

  select * into v_sess from public.shift_sessions
   where user_id = p_user_id and work_date = v_today
   for update;

  if found then
    if p_mode = 'manual' then
      update public.shift_sessions set
        required_seconds         = 0,
        current_pause_started_at = null,
        current_pause_reason     = null,
        current_break_started_at = null,
        current_break_kind       = null,
        updated_at               = now()
      where id = v_sess.id;
      v_reconciled := true;
    else
      select * into v_sched from public.shift_schedules
       where user_id = p_user_id and weekday = v_weekday;
      if found and v_sched.enabled then
        v_new_req := coalesce(v_sched.required_seconds, v_req);
      else
        v_new_req := 0;
      end if;
      update public.shift_sessions set
        required_seconds = v_new_req,
        updated_at       = now()
      where id = v_sess.id;
      v_reconciled := true;
    end if;

    insert into public.shift_events (session_id, user_id, type, by, meta) values (
      v_sess.id, p_user_id, 'admin_override', v_uid,
      jsonb_build_object('kind','mode_flip_session_reconcile',
                         'new_mode', p_mode,
                         'work_date', v_today)
    );
  end if;
  -- ---- end reconcile ----

  insert into public.shift_events (session_id, user_id, type, by, meta) values (
    null, p_user_id, 'admin_override', v_uid,
    jsonb_build_object('kind','set_shift_mode','mode', p_mode)
  );

  return jsonb_build_object(
    'ok', true,
    'user_id', p_user_id,
    'shift_mode', p_mode,
    'seeded_default_schedule', (p_mode = 'auto' and not coalesce(v_has_sched, true)),
    'session_reconciled', v_reconciled
  );
end;
$function$;

CREATE OR REPLACE FUNCTION public.shift_complete_if_due(p_session_id uuid)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare
  v_uid     uuid := auth.uid();
  v_s       public.shift_sessions;
  v_elapsed int;
  v_was     text;
  v_mode    text;
begin
  if v_uid is null then
    null;
  else
    select * into v_s from public.shift_sessions where id = p_session_id for update;
    if not found then raise exception 'session not found' using errcode='02000'; end if;
    if v_s.user_id <> v_uid and not is_admin() then
      raise exception 'forbidden' using errcode='42501';
    end if;
  end if;

  if v_uid is null then
    select * into v_s from public.shift_sessions where id = p_session_id for update;
    if not found then raise exception 'session not found' using errcode='02000'; end if;
  end if;

  if v_s.status = 'completed' then
    return jsonb_build_object(
      'session_id', v_s.id, 'already_completed', true, 'completed_at', v_s.completed_at
    );
  end if;

  select coalesce(shift_mode,'manual') into v_mode
    from public.shift_configs where user_id = v_s.user_id;

  if v_mode = 'manual' or v_s.required_seconds is null or v_s.required_seconds <= 0 then
    return jsonb_build_object(
      'session_id',        v_s.id,
      'already_completed', false,
      'due',               false,
      'reason',            'manual_mode',
      'elapsed_seconds',   0,
      'remaining_seconds', 0
    );
  end if;

  if v_s.started_at is null then
    v_elapsed := 0;
  else
    v_elapsed := greatest(0,
      extract(epoch from (clock_timestamp() - v_s.started_at))::int
      - v_s.paused_total_seconds
      - case when v_s.current_pause_started_at is not null
             then extract(epoch from (clock_timestamp() - v_s.current_pause_started_at))::int
             else 0 end
    );
  end if;

  if v_elapsed < v_s.required_seconds then
    return jsonb_build_object(
      'session_id', v_s.id, 'already_completed', false, 'due', false,
      'elapsed_seconds', v_elapsed,
      'remaining_seconds', v_s.required_seconds - v_elapsed
    );
  end if;

  if v_s.status not in ('active','on_shift_break','on_bio_break') then
    return jsonb_build_object(
      'session_id', v_s.id, 'already_completed', false, 'due', true,
      'completed', false, 'reason', 'wrong_status', 'status', v_s.status
    );
  end if;

  v_was := v_s.status;
  update public.shift_sessions
     set status        = 'completed',
         completed_at  = now(),
         locked_reason = 'shift_complete',
         current_break_started_at = null,
         current_break_kind       = null,
         updated_at    = now()
   where id = v_s.id;

  insert into public.shift_events (session_id, user_id, type, by, meta)
    values (v_s.id, v_s.user_id, 'shift_complete', v_uid,
            jsonb_build_object(
              'worked_seconds', v_elapsed, 'from_status', v_was, 'auto_swept', false
            ));

  return jsonb_build_object(
    'session_id',        v_s.id,
    'already_completed', false,
    'due',               true,
    'completed',         true,
    'completed_at',      now()
  );
end;
$function$;