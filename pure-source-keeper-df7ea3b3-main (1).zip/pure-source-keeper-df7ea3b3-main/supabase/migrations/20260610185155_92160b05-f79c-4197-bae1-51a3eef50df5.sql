DROP POLICY IF EXISTS "chat_messages: user inserts own thread" ON public.chat_messages;
CREATE POLICY "chat_messages: user inserts own thread"
ON public.chat_messages
FOR INSERT
TO authenticated
WITH CHECK (
  sender = 'user'
  AND (sender_user_id IS NULL OR sender_user_id = auth.uid())
  AND EXISTS (
    SELECT 1 FROM public.chat_threads t
    WHERE t.id = chat_messages.thread_id
      AND t.user_id = auth.uid()
  )
);