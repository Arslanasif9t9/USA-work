
-- 1. Column on shift_configs
ALTER TABLE public.shift_configs
  ADD COLUMN IF NOT EXISTS can_work_now boolean NOT NULL DEFAULT false;

COMMENT ON COLUMN public.shift_configs.can_work_now IS
  'Admin override. When true, shift_can_start() bypasses scheduled-time gates (before_start_date, day_off, before_shift_time, after_shift_end). Persists until admin flips it back.';

-- 2. Admin RPC to set the flag
CREATE OR REPLACE FUNCTION public.shift_admin_set_can_work_now(
  p_target_user_id uuid,
  p_can boolean
) RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $fn$
declare
  v_admin uuid := auth.uid();
  v_row public.shift_configs;
begin
  if v_admin is null or not is_admin() then
    raise exception 'admin only' using errcode = '42501';
  end if;
  if p_target_user_id is null then
    raise exception 'target user required' using errcode = '22023';
  end if;

  -- Upsert: ensure a config row exists, then set the flag.
  insert into public.shift_configs (user_id, can_work_now)
    values (p_target_user_id, coalesce(p_can, false))
  on conflict (user_id) do update
    set can_work_now = coalesce(p_can, false),
        updated_at   = now()
  returning * into v_row;

  -- Audit trail (best-effort; mirrors the account-lock audit shape).
  begin
    insert into public.shift_events (session_id, user_id, type, by, meta)
      select s.id, p_target_user_id, 'admin_override', v_admin,
             jsonb_build_object('action', 'set_can_work_now', 'value', coalesce(p_can, false))
      from public.shift_sessions s
      where s.user_id = p_target_user_id
        and s.work_date = (now() at time zone coalesce(v_row.timezone, 'Asia/Manila'))::date
      limit 1;
  exception when others then
    -- No session today → skip the audit row silently.
    null;
  end;

  return jsonb_build_object(
    'user_id',      v_row.user_id,
    'can_work_now', v_row.can_work_now
  );
end;
$fn$;

REVOKE ALL ON FUNCTION public.shift_admin_set_can_work_now(uuid, boolean) FROM public;
GRANT EXECUTE ON FUNCTION public.shift_admin_set_can_work_now(uuid, boolean) TO authenticated;

-- 3. Patch shift_can_start() to honor the override.
CREATE OR REPLACE FUNCTION public.shift_can_start()
 RETURNS jsonb
 LANGUAGE plpgsql
 STABLE SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
declare
  v_uid uuid := auth.uid();
  v_cfg public.shift_configs;
  v_tz  text;
  v_local_now   timestamp;
  v_local_today date;
  v_local_time  time;
  v_local_wd    int;
  v_sched       public.shift_schedules;
  v_has_any_sched boolean;
  v_today_start_ts timestamptz;
  v_next_ts        timestamptz;
begin
  if v_uid is null or not is_active_user() then
    raise exception 'not authenticated/active' using errcode='42501';
  end if;

  select * into v_cfg from public.shift_configs where user_id = v_uid;
  v_tz := coalesce(v_cfg.timezone, 'Asia/Manila');

  -- Admin override: "Can Work Now". Bypasses all scheduled-time gates.
  if coalesce(v_cfg.can_work_now, false) = true then
    return jsonb_build_object(
      'can_start',     true,
      'reason',        'ok',
      'next_shift_at', null,
      'timezone',      v_tz
    );
  end if;

  if coalesce(v_cfg.shift_mode, 'manual') = 'manual' then
    return jsonb_build_object(
      'can_start',     true,
      'reason',        'ok',
      'next_shift_at', null,
      'timezone',      v_tz
    );
  end if;

  v_local_now   := (now() at time zone v_tz);
  v_local_today := v_local_now::date;
  v_local_time  := v_local_now::time;
  v_local_wd    := extract(dow from v_local_today)::int;

  select exists (
    select 1 from public.shift_schedules
     where user_id = v_uid and enabled = true and start_time_local is not null
  ) into v_has_any_sched;
  if not v_has_any_sched then
    return jsonb_build_object(
      'can_start', true, 'reason', 'ok',
      'next_shift_at', null, 'timezone', v_tz
    );
  end if;

  if v_cfg.shift_start_date is not null and v_local_today < v_cfg.shift_start_date then
    v_next_ts := public._shift_next_scheduled_at(v_uid, v_cfg.shift_start_date, v_tz);
    return jsonb_build_object(
      'can_start', false, 'reason', 'before_start_date',
      'next_shift_at', v_next_ts, 'timezone', v_tz
    );
  end if;

  select * into v_sched from public.shift_schedules
    where user_id = v_uid and weekday = v_local_wd;

  if not found or not v_sched.enabled or v_sched.start_time_local is null then
    v_next_ts := public._shift_next_scheduled_at(v_uid, v_local_today + 1, v_tz);
    return jsonb_build_object(
      'can_start', false, 'reason', 'day_off',
      'next_shift_at', v_next_ts, 'timezone', v_tz
    );
  end if;

  v_today_start_ts := ((v_local_today::text || ' ' || v_sched.start_time_local::text)::timestamp
                       at time zone v_tz);
  if v_local_time < v_sched.start_time_local then
    return jsonb_build_object(
      'can_start', false, 'reason', 'before_shift_time',
      'next_shift_at', v_today_start_ts, 'timezone', v_tz
    );
  end if;

  if v_sched.end_time_local is not null
     and v_local_time > v_sched.end_time_local then
    v_next_ts := public._shift_next_scheduled_at(v_uid, v_local_today + 1, v_tz);
    return jsonb_build_object(
      'can_start', false, 'reason', 'after_shift_end',
      'next_shift_at', v_next_ts, 'timezone', v_tz
    );
  end if;

  return jsonb_build_object(
    'can_start', true, 'reason', 'ok',
    'next_shift_at', v_today_start_ts, 'timezone', v_tz
  );
end;
$function$;
