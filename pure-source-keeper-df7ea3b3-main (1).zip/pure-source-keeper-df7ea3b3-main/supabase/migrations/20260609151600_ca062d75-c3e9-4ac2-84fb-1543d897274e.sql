ALTER TABLE public.shift_configs ALTER COLUMN shift_break_seconds SET DEFAULT 1800;
UPDATE public.shift_configs SET shift_break_seconds = 1800 WHERE shift_break_seconds = 3600;