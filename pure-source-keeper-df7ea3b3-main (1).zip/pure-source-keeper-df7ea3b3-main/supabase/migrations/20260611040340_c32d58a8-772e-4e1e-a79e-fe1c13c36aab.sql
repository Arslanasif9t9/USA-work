
-- 1. Widen files INSERT policy: authenticated users uploading to a board they can access.
DROP POLICY IF EXISTS files_insert ON public.files;
CREATE POLICY files_insert ON public.files
  FOR INSERT
  TO authenticated
  WITH CHECK (
    uploader_id = auth.uid()
    AND (
      (item_id IS NOT NULL AND EXISTS (
        SELECT 1 FROM public.items i
        WHERE i.id = files.item_id AND public.can_access_board(i.board_id)
      ))
      OR
      (update_id IS NOT NULL AND EXISTS (
        SELECT 1 FROM public.updates u
        JOIN public.items i ON i.id = u.item_id
        WHERE u.id = files.update_id AND public.can_access_board(i.board_id)
      ))
    )
  );

-- 2. Storage policies for the private task-files bucket.
DROP POLICY IF EXISTS "task-files insert own"  ON storage.objects;
DROP POLICY IF EXISTS "task-files select own"  ON storage.objects;
DROP POLICY IF EXISTS "task-files update own"  ON storage.objects;
DROP POLICY IF EXISTS "task-files delete own"  ON storage.objects;
DROP POLICY IF EXISTS "task-files admin all"   ON storage.objects;

CREATE POLICY "task-files insert own" ON storage.objects
  FOR INSERT TO authenticated
  WITH CHECK (bucket_id = 'task-files' AND owner = auth.uid());

CREATE POLICY "task-files select own" ON storage.objects
  FOR SELECT TO authenticated
  USING (bucket_id = 'task-files' AND (owner = auth.uid() OR public.is_admin()));

CREATE POLICY "task-files update own" ON storage.objects
  FOR UPDATE TO authenticated
  USING (bucket_id = 'task-files' AND (owner = auth.uid() OR public.is_admin()))
  WITH CHECK (bucket_id = 'task-files' AND (owner = auth.uid() OR public.is_admin()));

CREATE POLICY "task-files delete own" ON storage.objects
  FOR DELETE TO authenticated
  USING (bucket_id = 'task-files' AND (owner = auth.uid() OR public.is_admin()));
