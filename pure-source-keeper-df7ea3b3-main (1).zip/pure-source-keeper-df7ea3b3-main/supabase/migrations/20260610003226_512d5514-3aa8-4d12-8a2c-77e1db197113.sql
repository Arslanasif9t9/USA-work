do $$
declare
  v_admin uuid := '14edc3ea-62bb-469e-aca0-2f6617af991f';
  v_user uuid;
  v_sid  uuid;
  v_tz   text;
  v_wd   date;
  v_old_locked boolean;
  v_old_reason text;
  v_grant_before int;
  v_grant_after  int;
  v_flag_after   timestamptz;
begin
  select user_id, coalesce(timezone,'Asia/Manila')
    into v_user, v_tz
    from public.shift_configs
    where user_id <> v_admin
    limit 1;
  v_wd := (now() at time zone v_tz)::date;

  select account_locked, account_lock_reason into v_old_locked, v_old_reason
    from public.shift_configs where user_id=v_user;

  delete from public.shift_sessions where user_id=v_user and work_date=v_wd;

  insert into public.shift_sessions (
    user_id, work_date, status, mode, period_seconds, required_seconds,
    started_at, bio_break_count_today, bio_break_admin_grants_today,
    bio6_notified_at, current_pause_started_at, current_pause_reason,
    locked_at, locked_reason, locked_by
  ) values (
    v_user, v_wd, 'locked', 'hard', 3600, 28800,
    now() - interval '2 hours', 7, 0,
    now(), now(), 'bio_limit_exceeded',
    now(), 'bio_limit_exceeded', null
  ) returning id into v_sid;

  update public.shift_configs
     set account_locked=true, account_lock_reason='bio_limit_exceeded'
   where user_id=v_user;

  select bio_break_admin_grants_today into v_grant_before
    from public.shift_sessions where id=v_sid;

  -- impersonate admin
  perform set_config('request.jwt.claim.sub', v_admin::text, true);
  perform set_config('request.jwt.claims',
    json_build_object('sub', v_admin::text, 'role','authenticated')::text, true);
  perform set_config('role', 'authenticated', true);

  perform public.shift_admin_set_account_lock(v_user, false);

  select bio_break_admin_grants_today, bio6_notified_at
    into v_grant_after, v_flag_after
    from public.shift_sessions where id=v_sid;

  raise notice 'PROBE grant_before=% grant_after=% bio6_notified_after=%',
    v_grant_before, v_grant_after, v_flag_after;

  -- cleanup
  perform set_config('role','postgres', true);
  delete from public.shift_sessions where id=v_sid;
  update public.shift_configs
     set account_locked=coalesce(v_old_locked,false), account_lock_reason=v_old_reason
   where user_id=v_user;
end $$;