create or replace function public.shift_can_start()
returns jsonb
language plpgsql
stable
security definer
set search_path = public
as $$
declare
  v_uid uuid := auth.uid();
  v_cfg public.shift_configs;
  v_tz  text;
  v_local_now   timestamp;
  v_local_today date;
  v_local_time  time;
  v_local_wd    int;
  v_sched       public.shift_schedules;
  v_has_any_sched boolean;
  v_today_start_ts timestamptz;
  v_next_ts        timestamptz;
begin
  if v_uid is null or not is_active_user() then
    raise exception 'not authenticated/active' using errcode='42501';
  end if;

  select * into v_cfg from public.shift_configs where user_id = v_uid;
  v_tz := coalesce(v_cfg.timezone, 'Asia/Manila');

  if coalesce(v_cfg.shift_mode, 'manual') = 'manual' then
    return jsonb_build_object(
      'can_start',     true,
      'reason',        'ok',
      'next_shift_at', null,
      'timezone',      v_tz
    );
  end if;

  v_local_now   := (now() at time zone v_tz);
  v_local_today := v_local_now::date;
  v_local_time  := v_local_now::time;
  v_local_wd    := extract(dow from v_local_today)::int;

  select exists (
    select 1 from public.shift_schedules
     where user_id = v_uid and enabled = true and start_time_local is not null
  ) into v_has_any_sched;
  if not v_has_any_sched then
    return jsonb_build_object(
      'can_start', true, 'reason', 'ok',
      'next_shift_at', null, 'timezone', v_tz
    );
  end if;

  if v_cfg.shift_start_date is not null and v_local_today < v_cfg.shift_start_date then
    v_next_ts := public._shift_next_scheduled_at(v_uid, v_cfg.shift_start_date, v_tz);
    return jsonb_build_object(
      'can_start', false, 'reason', 'before_start_date',
      'next_shift_at', v_next_ts, 'timezone', v_tz
    );
  end if;

  select * into v_sched from public.shift_schedules
    where user_id = v_uid and weekday = v_local_wd;

  if not found or not v_sched.enabled or v_sched.start_time_local is null then
    v_next_ts := public._shift_next_scheduled_at(v_uid, v_local_today + 1, v_tz);
    return jsonb_build_object(
      'can_start', false, 'reason', 'day_off',
      'next_shift_at', v_next_ts, 'timezone', v_tz
    );
  end if;

  v_today_start_ts := ((v_local_today::text || ' ' || v_sched.start_time_local::text)::timestamp
                       at time zone v_tz);
  if v_local_time < v_sched.start_time_local then
    return jsonb_build_object(
      'can_start', false, 'reason', 'before_shift_time',
      'next_shift_at', v_today_start_ts, 'timezone', v_tz
    );
  end if;

  -- 0077 — AFTER-END-OF-WINDOW gate. Mirrors the before_shift_time
  -- branch above but on the upper bound. Uses the same per-employee
  -- v_sched row already loaded (so end_time_local is the manager's
  -- own scheduled end for today, in their own timezone). When
  -- end_time_local is null the comparison yields null → false, so the
  -- branch is a no-op for schedules with no defined end.
  if v_sched.end_time_local is not null
     and v_local_time > v_sched.end_time_local then
    v_next_ts := public._shift_next_scheduled_at(v_uid, v_local_today + 1, v_tz);
    return jsonb_build_object(
      'can_start', false, 'reason', 'after_shift_end',
      'next_shift_at', v_next_ts, 'timezone', v_tz
    );
  end if;

  return jsonb_build_object(
    'can_start', true, 'reason', 'ok',
    'next_shift_at', v_today_start_ts, 'timezone', v_tz
  );
end;
$$;
revoke all on function public.shift_can_start() from public;
grant execute on function public.shift_can_start() to authenticated;