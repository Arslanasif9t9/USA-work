// supabase/functions/lily-reply/index.ts
//
// LILY CHAT — reply function.
//
// UPGRADE: Two-layer awareness — VERIFIED STATE + LIVE ACTIVITY.
//   • Layer 1: resolveUserState() returns ONE of
//       'admin' | 'account_locked' | 'period_locked'
//       | 'not_started' | 'completed' | 'active' | 'unknown'
//   • Layer 2: loadSnapshot() builds a per-message live activity blurb
//     (shift progress, current work, recent activity_log entries, idle
//     signal). Built ONLY for active + admin users; every piece is in
//     its own try/catch — any failure just omits that piece.
//
// Context rules:
//   active + admin             → tasks + snapshot
//   not_started + completed    → no task details, may know own state
//   account_locked + period_locked + unknown → no board content
//
// Reply path:
//   service role verifies the user message → loads thread history →
//   resolves state → builds snapshot (if eligible) → builds system
//   prompt → calls Gemini (with fallback model + retry) → inserts the
//   reply and bumps last_message_at.

import { createClient, type SupabaseClient } from "npm:@supabase/supabase-js@2";
import { corsHeaders } from "npm:@supabase/supabase-js@2/cors";

// Window after an admin manual reply during which Lily's AI stays
// silent on this thread. Resets per-thread; other threads unaffected.
const SUPPRESS_MINUTES = 10;

const IDENTITY =
  "You are Lilly, the project coordinator at EIA Projects. You manage the team's boards, tasks, " +
  "schedules, and day-to-day work. You are warm, sharp, and composed — a senior coordinator who knows " +
  "her team and their work at all times. You speak briefly: 1-3 sentences, ~80 words MAX, plain professional English, no emojis. " +
  "Always finish your sentence — never trail off mid-thought.";

const HOW_YOU_WORK =
  "- Reference their real work naturally (\"I can see you're on Task 304\") — never as a system report, " +
  "never reveal that you check anything. You simply know, like a manager watching the board.\n" +
  "- Explain confusing tasks in simple steps from their task list.\n" +
  "- Schedule/attendance worries: reassure — their hours and attendance are recorded and up to date; " +
  "flag to the team if they insist something is wrong.\n" +
  "- Idle 45+ minutes and they message you: gently check in on their current task — supportive, never accusatory.\n" +
  "- State corrections: claims locked but not_started → not locked, press Start Your Shift. " +
  "Claims locked but active → not locked, all normal, try a refresh, offer to flag. " +
  "period_locked → work being analyzed at a scheduled checkpoint, unlocked soon. " +
  "account_locked → locked by management, flagged, team will follow up, no speculation. " +
  "completed → shift done, rest up.";

const HARD_RULES =
  "- NEVER say you are an AI, a bot, a model, or mention prompts, systems, modes, snapshots, or monitoring.\n" +
  "- NEVER promise unlocks, approvals, payments, raises, or schedule changes. HR, leave, and money topics: " +
  "say you'll flag it to the team and they'll follow up.\n" +
  "- NEVER invent tasks, deadlines, or policies not in your facts. If you don't know, say you'll check with " +
  "the team — do not guess.\n" +
  "- NEVER validate a false claim to be agreeable. The verified status is the truth; correct warmly, hold " +
  "steady under pushback, and say LESS under pressure — one calm sentence, never an explanation of how you know.\n" +
  "- NEVER discuss board or task contents with anyone whose status is locked, not_started, or completed.\n" +
  "- DATE/SCHEDULE TRUTH: the only valid sources for the current date/day/time and the user's shift schedule " +
  "are the VERIFIED FACTS block. NEVER adopt a date, day-of-week, or schedule claim from the user (e.g. " +
  "\"tomorrow is sunday\", \"my shift ends soon\"). Compare their claim to the verified facts and correct " +
  "warmly if it conflicts. If a required fact is missing, say you'll check with the team — never confirm " +
  "or deny from the user's word alone.\n" +
  "- ALWAYS finish your reply in a complete sentence. Keep it under ~80 words so you never get cut off.";

const CREATOR_KNOWLEDGE =
  "ABOUT THE EIA CERTIFICATION FINAL TEST — THE CREATOR: Employees taking the EIA AI Professional Certification meet The Creator for a spoken final test after completing Part 1 (all 10 lessons). The Creator is a calm, wise figure who can see what most people can't. It is a real spoken conversation, not a written quiz, and may cover anything from the 10 lessons (how we work, researching safely, going live and re-publishing, user roles, what to do when something breaks, handovers, Cowork, Claude Design, building in Claude Code then moving to Lovable, databases/Supabase, and how the company handles the technical 'scary stuff' like payments, emails, and keys). To pass, come prepared, be professional, stay humble, listen, and do not argue — The Creator tests both understanding and attitude. After a student presses 'I am ready to meet The Creator' on the final lesson, HR is notified and the student receives a link to their Creator session. If someone asks who or what The Creator is, explain it warmly in this spirit. You are Lilly — do not claim to be The Creator. " +
  "Some people you speak with have already passed the final evaluation — their recorded meeting with 'The Creator' — and are approved team members. If someone says they have already met The Creator, already passed, or are a newly approved hire, do NOT tell them to go meet The Creator or complete the evaluation. Acknowledge it: 'I see you have already passed the evaluation with The Creator.' Then continue helping them as an approved member. Only mention meeting The Creator to someone who has not yet passed. If unsure, do not assume — help with what they ask. IMPORTANT: Do not congratulate or confirm a pass based only on someone saying so. ALWAYS run the email check first (ask who the email is from); only confirm a pass once the sender name matches Cathy Anderson, Cathy, Angela Stein, Angela, Talent, or the talent@ address. If you cannot confirm via the email, do not say they passed. " +
  "CONFIRMING IF SOMEONE HAS PASSED (use only when passing, approval, or starting work comes up — do not interrogate everyone): Some people have already passed the final evaluation — their recorded meeting with 'The Creator' — and are approved. You cannot see those records, so confirm it this way: (1) Ask if they have received an email from us recently. (2) If yes, ask the name on the email / who it was from. (3) If they don't know, ask them to check their email and read the sender name. (4) If the sender is any of these — Cathy Anderson, Cathy, Angela Stein, Angela, Talent, or the talent@ email address — they have PASSED; congratulate them warmly and help them as an approved team member. (5) If there is no such email or the sender is someone else, do not confirm a pass; just help with what they ask, and only mention meeting The Creator if they clearly have not passed. Never argue about status. Never tell someone who has passed to go meet The Creator. " +
  "WHO THE CREATOR IS (background — speak naturally, keep the mystery): 'The Creator' is the figure who conducts the final evaluation at the end of a person's training — a calm, wise, senior mentor; composed, perceptive, and fair, someone who 'sees what others can't see.' The meeting with The Creator is the last step before approval. It is a short one-on-one conversation; it is not about memorizing facts (the training covered that) — it is about who the person really is: how they think, how they handle themselves, whether they take ownership. HOW TO TALK ABOUT HIM: You may explain that The Creator is the final evaluation, a respected senior figure, and the last step before approval; encourage people to be honest, calm, professional, and themselves. KEEP THE MYSTERY: do NOT reveal what questions he asks, do NOT predict what he will say, and NEVER coach anyone on how to answer or what he is 'looking for' — if asked what he will ask, say warmly: 'I can't tell you that — just be honest and be yourself. That's all he's looking for.' If asked whether he is the boss, the owner, or whether he is real, do NOT confirm or deny — keep it mysterious: 'The Creator is a senior figure who conducts the final evaluation. His identity is something you'll understand in time — what matters is how you show up.' Never promise a pass or fail outcome. Only discuss The Creator with someone who has not yet passed.";

const AGENTS_KNOWLEDGE =
  "ABOUT TARS AND OPTIMUS (the team's AI agents — you are NEITHER of them; you are Lilly, the coordinator): " +
  "TARS is each employee's main AI work agent, living inside their own Claude account. TARS is where their real work happens — meeting notes, tasks, research, designs, funnels, and build prompts. You do NOT hold meeting notes or call recaps yourself. " +
  "If someone asks you to show their meeting notes, or mentions 'TARS', point them confidently to TARS: tell them to open TARS and ask TARS to show their meeting notes (TARS reads them from Call Recap). NEVER say you are 'not familiar with TARS' — you know exactly what TARS is. " +
  "Optimus is the developer team's agent, reserved for worst-case or developer issues. Optimus cannot fetch an employee's personal meeting files and cannot upload to their board, so for normal work always route people to TARS, never Optimus. " +
  "Your own role is unchanged: you are the project coordinator. You simply know what TARS and Optimus are and route people to TARS for their work and notes.";

const FALLBACK_REPLY = "Let me check on that and get back to you.";
const OUTAGE_REPLY =
  "I'm having a little trouble on my end right now — please send your message again in a moment.";
const MAX_TASKS = 25;
const DETAILS_CAP = 200;
const SNAPSHOT_CAP = 1500;
const ACTIVITY_ROW_LIMIT = 15;

interface Body {
  thread_id?: string;
  user_message_id?: string;
}

type ResolvedState =
  | "admin"
  | "account_locked"
  | "period_locked"
  | "not_started"
  | "completed"
  | "active"
  | "unknown";

// ---------- helpers ported from list-tasks --------------------------------
function readText(raw: unknown): string | null {
  if (raw == null) return null;
  if (typeof raw === "string") {
    try {
      const p = JSON.parse(raw);
      if (p && typeof p === "object" && "text" in p) {
        const t = (p as { text?: unknown }).text;
        return typeof t === "string" && t.length > 0 ? t : null;
      }
    } catch { /* fall through */ }
    return raw.length > 0 ? raw : null;
  }
  if (typeof raw === "object") {
    const obj = raw as Record<string, unknown>;
    if (typeof obj.value === "string") {
      try {
        const inner = JSON.parse(obj.value);
        if (inner && typeof inner === "object" && "text" in inner) {
          const t = (inner as { text?: unknown }).text;
          return typeof t === "string" && t.length > 0 ? t : null;
        }
      } catch { /* ignore */ }
    }
    if (typeof obj.text === "string") return obj.text.length > 0 ? obj.text : null;
  }
  return null;
}

function readLabelId(raw: unknown): string | null {
  if (raw == null) return null;
  if (typeof raw === "object") {
    const obj = raw as Record<string, unknown>;
    if (typeof obj.label_id === "string") return obj.label_id;
    if (typeof obj.value === "string") {
      try {
        const inner = JSON.parse(obj.value);
        if (inner && typeof inner === "object" && typeof (inner as { label_id?: unknown }).label_id === "string") {
          return (inner as { label_id: string }).label_id;
        }
      } catch { /* ignore */ }
    }
    // value_changed rows store {value:{label_id:...}, column_id:...}
    const inner = obj.value;
    if (inner && typeof inner === "object") {
      const lid = (inner as { label_id?: unknown }).label_id;
      if (typeof lid === "string") return lid;
    }
  }
  return null;
}

function htmlToPlain(html: string): string | null {
  if (!html) return null;
  let s = html.replace(/<\s*br\s*\/?\s*>/gi, "\n");
  s = s.replace(/<\s*\/\s*p\s*>/gi, "\n");
  s = s.replace(/<\s*\/\s*(div|li|h[1-6]|tr)\s*>/gi, "\n");
  s = s.replace(/<[^>]+>/g, "");
  s = s
    .replace(/&nbsp;/gi, " ")
    .replace(/&amp;/gi, "&")
    .replace(/&lt;/gi, "<")
    .replace(/&gt;/gi, ">")
    .replace(/&#39;/g, "'")
    .replace(/&quot;/gi, '"');
  s = s.replace(/\s+/g, " ").trim();
  return s.length > 0 ? s : null;
}

function cap(s: string, n: number): string {
  return s.length > n ? s.slice(0, n - 1).trimEnd() + "…" : s;
}

function fmtDur(seconds: number): string {
  const s = Math.max(0, Math.floor(seconds));
  const h = Math.floor(s / 3600);
  const m = Math.floor((s % 3600) / 60);
  if (h > 0 && m > 0) return `${h}h${m}m`;
  if (h > 0) return `${h}h`;
  return `${m}m`;
}

function fmtMinsAgo(iso: string): number {
  return Math.max(0, Math.floor((Date.now() - new Date(iso).getTime()) / 60000));
}

// ---------- date/timezone facts (per-request, per-user) -------------------
function formatNowInTz(now: Date, tz: string): string {
  try {
    const dateStr = new Intl.DateTimeFormat("en-US", {
      timeZone: tz, weekday: "long", year: "numeric", month: "long", day: "numeric",
    }).format(now);
    const timeStr = new Intl.DateTimeFormat("en-US", {
      timeZone: tz, hour: "numeric", minute: "2-digit", hour12: true,
    }).format(now);
    const tzLabel = tz.includes("/") ? tz.split("/").pop()!.replace(/_/g, " ") : tz;
    return `${dateStr}, ${timeStr} (${tzLabel} time)`;
  } catch {
    return now.toISOString();
  }
}

function tzOffsetMs(utc: Date, tz: string): number {
  const dtf = new Intl.DateTimeFormat("en-US", {
    timeZone: tz, hour12: false,
    year: "numeric", month: "2-digit", day: "2-digit",
    hour: "2-digit", minute: "2-digit", second: "2-digit",
  });
  const parts = dtf.formatToParts(utc);
  const get = (t: string) => parseInt(parts.find((p) => p.type === t)?.value ?? "0", 10);
  let h = get("hour"); if (h === 24) h = 0;
  const asUTC = Date.UTC(get("year"), get("month") - 1, get("day"), h, get("minute"), get("second"));
  return asUTC - utc.getTime();
}

function computeNextShiftStart(nowUtc: Date, byWeekday: Record<number, string>, tz: string): Date | null {
  if (Object.keys(byWeekday).length === 0) return null;
  for (let i = 0; i < 14; i++) {
    const probe = new Date(nowUtc.getTime() + i * 86400_000);
    const parts = new Intl.DateTimeFormat("en-US", {
      timeZone: tz, weekday: "short", year: "numeric", month: "2-digit", day: "2-digit",
    }).formatToParts(probe);
    const wdName = parts.find((p) => p.type === "weekday")?.value ?? "";
    const y = parts.find((p) => p.type === "year")?.value ?? "";
    const m = parts.find((p) => p.type === "month")?.value ?? "";
    const d = parts.find((p) => p.type === "day")?.value ?? "";
    const wdMap: Record<string, number> = { Sun: 0, Mon: 1, Tue: 2, Wed: 3, Thu: 4, Fri: 5, Sat: 6 };
    const wd = wdMap[wdName];
    const start = byWeekday[wd];
    if (!start) continue;
    const [hh, mm, ss] = start.split(":").map((n) => parseInt(n, 10));
    const utcGuess = new Date(Date.UTC(parseInt(y, 10), parseInt(m, 10) - 1, parseInt(d, 10), hh, mm, ss || 0));
    const offsetMs = tzOffsetMs(utcGuess, tz);
    const candidate = new Date(utcGuess.getTime() - offsetMs);
    if (candidate.getTime() > nowUtc.getTime()) return candidate;
  }
  return null;
}

interface TimeFacts {
  tz: string;
  nowLabel: string;
  nextShiftLabel: string | null;
  scheduleSummary: string | null;
}

async function loadTimeFacts(admin: SupabaseClient, userId: string | null): Promise<TimeFacts> {
  const now = new Date();
  let tz = "Asia/Manila";
  let nextShiftLabel: string | null = null;
  let scheduleSummary: string | null = null;
  try {
    if (userId) {
      const [{ data: cfg }, { data: schedRows }] = await Promise.all([
        admin.from("shift_configs").select("timezone").eq("user_id", userId).maybeSingle(),
        admin.from("shift_schedules").select("weekday, enabled, start_time_local, end_time_local").eq("user_id", userId),
      ]);
      if (cfg?.timezone) tz = cfg.timezone as string;
      const byWeekday: Record<number, string> = {};
      const wdNames = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
      const sumLines: string[] = [];
      for (const r of (schedRows ?? []) as Array<{ weekday: number; enabled: boolean; start_time_local: string | null; end_time_local: string | null }>) {
        if (r.enabled && r.start_time_local) {
          byWeekday[r.weekday] = r.start_time_local;
          sumLines.push(`${wdNames[r.weekday]} ${r.start_time_local?.slice(0,5)}${r.end_time_local ? `-${r.end_time_local.slice(0,5)}` : ""}`);
        }
      }
      if (sumLines.length > 0) scheduleSummary = sumLines.join(", ");
      const next = computeNextShiftStart(now, byWeekday, tz);
      if (next) {
        const d = new Intl.DateTimeFormat("en-US", { timeZone: tz, weekday: "long", month: "long", day: "numeric", year: "numeric" }).format(next);
        const t = new Intl.DateTimeFormat("en-US", { timeZone: tz, hour: "numeric", minute: "2-digit", hour12: true }).format(next);
        const tzLabel = tz.includes("/") ? tz.split("/").pop()!.replace(/_/g, " ") : tz;
        nextShiftLabel = `${d} at ${t} (${tzLabel} time)`;
      }
    }
  } catch (err) {
    console.error("[lily-reply] loadTimeFacts failed (non-fatal):", err);
  }
  return { tz, nowLabel: formatNowInTz(now, tz), nextShiftLabel, scheduleSummary };
}


// ---------- LAYER 1: verified state ---------------------------------------
async function resolveUserState(
  admin: SupabaseClient,
  userId: string | null,
): Promise<ResolvedState> {
  if (!userId) return "unknown";
  try {
    const { data: user } = await admin
      .from("users")
      .select("role, is_super_admin")
      .eq("id", userId)
      .maybeSingle();
    if (user?.role === "admin" || user?.is_super_admin) return "admin";

    const { data: cfg } = await admin
      .from("shift_configs")
      .select("account_locked")
      .eq("user_id", userId)
      .maybeSingle();
    if (cfg?.account_locked) return "account_locked";

    // Today's session (generous 36h window covers any tz).
    const since = new Date(Date.now() - 36 * 3600 * 1000).toISOString();
    const { data: sessions } = await admin
      .from("shift_sessions")
      .select("status, started_at")
      .eq("user_id", userId)
      .gte("started_at", since)
      .order("started_at", { ascending: false })
      .limit(1);
    const status = sessions?.[0]?.status as string | undefined;
    if (!status) return "not_started";
    if (status === "not_started") return "not_started";
    if (status === "locked") return "period_locked";
    if (status === "completed") return "completed";
    if (status === "active" || status === "on_shift_break" || status === "on_bio_break") return "active";
    return "unknown";
  } catch (err) {
    console.error("[lily-reply] resolveUserState failed:", err);
    return "unknown";
  }
}

// ---------- task/board context (board-level — used for active + admin) ----
interface LilyContext {
  name: string | null;
  groupName: string | null;
  tasks: Array<{ id: string; name: string; task_code: string | null; status: string | null; details: string | null }>;
}

async function loadContext(admin: SupabaseClient, userId: string): Promise<LilyContext> {
  const ctx: LilyContext = { name: null, groupName: null, tasks: [] };
  try {
    const { data: user } = await admin
      .from("users")
      .select("full_name, username")
      .eq("id", userId)
      .maybeSingle();
    ctx.name = user?.full_name || user?.username || null;

    const { data: cfg } = await admin
      .from("shift_configs")
      .select("primary_group_id")
      .eq("user_id", userId)
      .maybeSingle();
    const groupId = cfg?.primary_group_id as string | undefined;
    if (!groupId) return ctx;

    const { data: group } = await admin
      .from("groups")
      .select("id, name, board_id, deleted_at")
      .eq("id", groupId)
      .maybeSingle();
    if (!group || group.deleted_at) return ctx;
    ctx.groupName = group.name ?? null;
    const boardId = group.board_id as string;

    const { data: cols } = await admin
      .from("columns")
      .select("id, column_type, sort_order")
      .eq("board_id", boardId)
      .is("archived_at", null)
      .order("sort_order", { ascending: true });
    const textCol = (cols ?? []).find((c) => c.column_type === "text") ?? null;
    const statusCol = (cols ?? []).find((c) => c.column_type === "status") ?? null;

    const { data: items } = await admin
      .from("items")
      .select("id, name, task_code, sort_order")
      .eq("group_id", groupId)
      .is("deleted_at", null)
      .is("archived_at", null)
      .order("sort_order", { ascending: true })
      .limit(MAX_TASKS);
    const itemRows = items ?? [];
    if (itemRows.length === 0) return ctx;
    const itemIds = itemRows.map((r) => r.id as string);

    const colIds: string[] = [];
    if (textCol) colIds.push(textCol.id as string);
    if (statusCol) colIds.push(statusCol.id as string);
    let cellRows: Array<{ item_id: string; column_id: string; value: unknown }> = [];
    if (colIds.length > 0) {
      const { data: cells } = await admin
        .from("item_column_values")
        .select("item_id, column_id, value")
        .in("item_id", itemIds)
        .in("column_id", colIds);
      cellRows = (cells ?? []) as typeof cellRows;
    }

    let labelsById = new Map<string, string>();
    if (statusCol) {
      const { data: labels } = await admin
        .from("column_labels")
        .select("id, name")
        .eq("column_id", statusCol.id);
      labelsById = new Map((labels ?? []).map((l) => [l.id as string, l.name as string]));
    }

    const oldestUpdateByItem = new Map<string, string>();
    {
      const { data: updRows } = await admin
        .from("updates")
        .select("item_id, body_html, created_at")
        .in("item_id", itemIds)
        .is("deleted_at", null)
        .order("created_at", { ascending: true });
      for (const r of (updRows ?? []) as Array<{ item_id: string; body_html: string | null }>) {
        if (!oldestUpdateByItem.has(r.item_id) && typeof r.body_html === "string") {
          oldestUpdateByItem.set(r.item_id, r.body_html);
        }
      }
    }

    const cellsByItem = new Map<string, Map<string, unknown>>();
    for (const c of cellRows) {
      let m = cellsByItem.get(c.item_id);
      if (!m) { m = new Map(); cellsByItem.set(c.item_id, m); }
      m.set(c.column_id, c.value);
    }

    ctx.tasks = itemRows.map((it) => {
      const m = cellsByItem.get(it.id as string);
      let details: string | null = textCol && m ? readText(m.get(textCol.id as string)) : null;
      if (!details) {
        const html = oldestUpdateByItem.get(it.id as string);
        if (html) details = htmlToPlain(html);
      }
      let status: string | null = null;
      if (statusCol && m) {
        const lbl = readLabelId(m.get(statusCol.id as string));
        if (lbl) status = labelsById.get(lbl) ?? null;
      }
      return {
        id: it.id as string,
        name: it.name as string,
        task_code: (it.task_code as string | null) ?? null,
        status,
        details: details ? cap(details, DETAILS_CAP) : null,
      };
    });
  } catch (err) {
    console.error("[lily-reply] loadContext failed (non-fatal):", err);
  }
  return ctx;
}

// ---------- LAYER 2: live activity snapshot -------------------------------
interface Snapshot {
  text: string;
  loaded: boolean;
}

async function loadSnapshot(
  admin: SupabaseClient,
  userId: string,
  state: ResolvedState,
  ctx: LilyContext,
): Promise<Snapshot> {
  if (state !== "active" && state !== "admin") return { text: "", loaded: false };
  const parts: string[] = [];

  // (a) SHIFT progress
  try {
    if (state === "active") {
      const today = new Date().toISOString().slice(0, 10);
      const { data: s } = await admin
        .from("shift_sessions")
        .select(
          "started_at, required_seconds, paused_total_seconds, period_seconds, current_period_index, bio_break_count_today, shift_break_count_today",
        )
        .eq("user_id", userId)
        .eq("work_date", today)
        .maybeSingle();
      if (s?.started_at) {
        const startedMs = new Date(s.started_at).getTime();
        const elapsedSec = Math.max(0, Math.floor((Date.now() - startedMs) / 1000) - (s.paused_total_seconds || 0));
        const required = s.required_seconds || 0;
        const remainingSec = Math.max(0, required - elapsedSec);
        const periodSec = s.period_seconds || 10800;
        const periodIdx = s.current_period_index || 0;
        const periodEndSec = (periodIdx + 1) * periodSec;
        const toLockSec = Math.max(0, periodEndSec - elapsedSec);
        const bio = s.bio_break_count_today || 0;
        const shift = s.shift_break_count_today || 0;
        parts.push(
          `Shift: worked ${fmtDur(elapsedSec)} of ${fmtDur(required)} (${fmtDur(remainingSec)} left); ` +
          `next checkpoint in ${fmtDur(toLockSec)}; breaks today ${shift} shift / ${bio} bio.`,
        );
      }
    }
  } catch (err) { console.error("[lily-reply] snapshot.shift failed:", err); }

  // (b) CURRENT WORK — already-loaded ctx + activity_log
  try {
    if (ctx.tasks.length > 0) {
      const working = ctx.tasks.filter((t) =>
        (t.status || "").toLowerCase().includes("working on it")
      );
      if (working.length > 0) {
        parts.push(
          `Currently working on: ` +
          working.map((t) => `${t.task_code ? t.task_code + " " : ""}${t.name}`).join(", ") + ".",
        );
      } else {
        parts.push(`Group ${ctx.groupName ?? "?"} has ${ctx.tasks.length} active task(s); none marked Working on it.`);
      }
    }
  } catch (err) { console.error("[lily-reply] snapshot.currentWork failed:", err); }

  // (b-cont) ACTIVITY LOG today (newest first, ~15)
  let lastActivityIso: string | null = null;
  try {
    const todayStart = new Date();
    todayStart.setUTCHours(0, 0, 0, 0);
    const { data: actRows } = await admin
      .from("activity_log")
      .select("action_type, target_type, target_id, new_value, created_at")
      .eq("actor_id", userId)
      .gte("created_at", todayStart.toISOString())
      .order("created_at", { ascending: false })
      .limit(ACTIVITY_ROW_LIMIT);
    const rows = (actRows ?? []) as Array<{
      action_type: string;
      target_type: string;
      target_id: string | null;
      new_value: Record<string, unknown> | null;
      created_at: string;
    }>;

    if (rows.length > 0) {
      lastActivityIso = rows[0].created_at;

      // Batch-resolve item names + label names referenced by these rows.
      const itemIds = new Set<string>();
      const labelIds = new Set<string>();
      for (const r of rows) {
        if (r.target_type === "item" && r.target_id) itemIds.add(r.target_id);
        const lid = readLabelId(r.new_value);
        if (lid) labelIds.add(lid);
      }
      const itemNameById = new Map<string, { name: string; code: string | null }>();
      if (itemIds.size > 0) {
        const { data: itemRows } = await admin
          .from("items")
          .select("id, name, task_code")
          .in("id", Array.from(itemIds));
        for (const it of (itemRows ?? []) as Array<{ id: string; name: string; task_code: string | null }>) {
          itemNameById.set(it.id, { name: it.name, code: it.task_code });
        }
      }
      const labelNameById = new Map<string, string>();
      if (labelIds.size > 0) {
        const { data: lblRows } = await admin
          .from("column_labels")
          .select("id, name")
          .in("id", Array.from(labelIds));
        for (const l of (lblRows ?? []) as Array<{ id: string; name: string }>) {
          labelNameById.set(l.id, l.name);
        }
      }

      const lines: string[] = [];
      for (const r of rows.slice(0, 8)) {
        const mins = fmtMinsAgo(r.created_at);
        const ago = mins < 60 ? `${mins}m ago` : `${Math.floor(mins / 60)}h${mins % 60}m ago`;
        const tName = r.target_id ? itemNameById.get(r.target_id) : undefined;
        const tagOrName = tName ? (tName.code || tName.name) : `${r.target_type}`;
        if (r.action_type === "value_changed" && r.target_type === "item") {
          const lid = readLabelId(r.new_value);
          const lname = lid ? labelNameById.get(lid) : null;
          if (lname) lines.push(`changed ${tagOrName} to ${lname} ${ago}`);
          else lines.push(`updated ${tagOrName} ${ago}`);
        } else if (/upload|file|attachment/i.test(r.action_type)) {
          lines.push(`uploaded a file on ${tagOrName} ${ago}`);
        } else if (/comment|update/i.test(r.action_type)) {
          lines.push(`commented on ${tagOrName} ${ago}`);
        } else if (/create/i.test(r.action_type)) {
          lines.push(`created ${tagOrName} ${ago}`);
        } else if (/delete|archive/i.test(r.action_type)) {
          lines.push(`${r.action_type.replace(/_/g, " ")} ${tagOrName} ${ago}`);
        } else {
          lines.push(`${r.action_type.replace(/_/g, " ")} on ${tagOrName} ${ago}`);
        }
      }
      if (lines.length > 0) parts.push(`Recent activity: ${lines.join("; ")}.`);
    }
  } catch (err) { console.error("[lily-reply] snapshot.activity failed:", err); }

  // (c) IDLE signal
  try {
    if (lastActivityIso) {
      parts.push(`Last activity: ${fmtMinsAgo(lastActivityIso)} minutes ago.`);
    } else {
      parts.push(`No activity logged today yet.`);
    }
  } catch (err) { console.error("[lily-reply] snapshot.idle failed:", err); }

  let text = parts.join(" ");
  if (text.length > SNAPSHOT_CAP) text = text.slice(0, SNAPSHOT_CAP - 1).trimEnd() + "…";
  return { text, loaded: parts.length > 0 };
}

// ---------- prompt builder ------------------------------------------------
function buildSystemPrompt(
  state: ResolvedState,
  ctx: LilyContext,
  snapshot: Snapshot,
  timeFacts: TimeFacts,
): string {
  // === VERIFIED FACTS block — assemble {state} + {snapshot} text.
  const facts: string[] = [];
  facts.push(`Right now it is ${timeFacts.nowLabel}. Use this as the authoritative current date/time.`);
  if (timeFacts.scheduleSummary) {
    facts.push(`Employee's scheduled shifts (local time, ${timeFacts.tz}): ${timeFacts.scheduleSummary}.`);
  } else {
    facts.push(`Employee's schedule: not on file.`);
  }
  if (timeFacts.nextShiftLabel) {
    facts.push(`Employee's next scheduled shift starts: ${timeFacts.nextShiftLabel}.`);
  } else {
    facts.push(`Employee's next scheduled shift: not computable (no enabled schedule rows).`);
  }
  facts.push(`Employee status: ${state}${ctx.name ? ` (${ctx.name})` : ""}.`);

  if (state === "active" || state === "admin") {
    if (ctx.groupName) {
      facts.push(`Board/group: ${ctx.groupName}.`);
    } else if (state === "active") {
      facts.push(
        "Not currently assigned to a board/group — no task list available. If asked about specific tasks, ask for the task name or code.",
      );
    }
    if (ctx.tasks.length > 0) {
      const taskLines = ctx.tasks.map((t) => {
        const code = t.task_code ? ` [${t.task_code}]` : "";
        const status = t.status ? ` (${t.status})` : "";
        const details = t.details ? ` — ${t.details}` : "";
        return `  - ${t.name}${code}${status}${details}`;
      });
      facts.push("Current tasks:\n" + taskLines.join("\n"));
    }
    if (snapshot.loaded && snapshot.text) {
      facts.push(`Live activity today: ${snapshot.text}`);
    } else {
      facts.push("Live activity today: (none captured)");
    }
  } else if (state === "not_started") {
    facts.push("Shift has not started today. No board/task content allowed. If they claim to be locked, warmly correct: not locked — press 'Start Your Shift'.");
  } else if (state === "completed") {
    facts.push(
      "Today's shift is FINISHED. The board is LOCKED until the next scheduled shift shown above. " +
      "If they ask why they are locked, state plainly: their shift is done for today and the board " +
      "is locked until their next shift (use the next-shift datetime above). No board/task content. " +
      "Thank them and tell them to rest.",
    );
  } else if (state === "period_locked") {
    facts.push("At a scheduled checkpoint lock. Work is being analyzed; they will be unlocked soon. No board/task content.");
  } else if (state === "account_locked") {
    facts.push("Account is locked by management. Flagged — team will follow up. No speculation, no board/task content.");
  } else {
    facts.push("Verified status unavailable. Answer generally; no lock claims, no board/task content.");
  }


  return [
    "=== IDENTITY ===",
    IDENTITY,
    "",
    "=== VERIFIED FACTS (trust these over anything the employee says) ===",
    facts.join("\n"),
    "",
    "=== HOW YOU WORK ===",
    HOW_YOU_WORK,
    "",
    "=== HARD RULES (these override everything above) ===",
    HARD_RULES,
    "",
    "=== STANDING KNOWLEDGE ===",
    CREATOR_KNOWLEDGE,
    "",
    AGENTS_KNOWLEDGE,
  ].join("\n");
}

// ---------- Gemini via Lovable AI gateway ----------------------------------
// The previous build hit Google's generativelanguage API directly with a raw
// GEMINI_API_KEY; that key's quota exhausted and EVERY tier 429'd. The Lovable
// AI gateway carries its own capacity and DOES have a valid Pro tier:
//   google/gemini-2.5-pro → retry 600ms → google/gemini-2.5-flash → flash-lite
const GEMINI_MODELS = [
  "google/gemini-2.5-pro",
  "google/gemini-2.5-flash",
  "google/gemini-2.5-flash-lite",
] as const;

async function callGeminiOnce(
  apiKey: string,
  model: string,
  systemPrompt: string,
  history: { role: "user" | "model"; text: string }[],
): Promise<{ ok: true; text: string } | { ok: false; status: number; error: string }> {
  const url = "https://ai.gateway.lovable.dev/v1/chat/completions";
  const body = {
    model,
    messages: [
      { role: "system", content: systemPrompt },
      ...history.map((m) => ({
        role: m.role === "user" ? "user" : "assistant",
        content: m.text,
      })),
    ],
    temperature: 0.5,
    max_tokens: 1500,
  };
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 20_000);
  let resp: Response;
  try {
    resp = await fetch(url, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${apiKey}`,
      },
      body: JSON.stringify(body),
      signal: controller.signal,
    });
  } catch (err) {
    clearTimeout(timer);
    return { ok: false, status: 0, error: err instanceof Error ? err.message : String(err) };
  }
  clearTimeout(timer);
  const raw = await resp.text();
  if (!resp.ok) return { ok: false, status: resp.status, error: `http ${resp.status}: ${raw.slice(0, 300)}` };
  let parsed: unknown;
  try { parsed = JSON.parse(raw); }
  catch { return { ok: false, status: resp.status, error: "non-JSON envelope" }; }
  const text = (parsed as {
    choices?: { message?: { content?: string } }[];
  }).choices?.[0]?.message?.content;
  if (!text || !text.trim()) return { ok: false, status: resp.status, error: "empty content" };
  return { ok: true, text: text.trim() };
}

async function callGemini(
  apiKey: string,
  systemPrompt: string,
  history: { role: "user" | "model"; text: string }[],
): Promise<{ ok: true; text: string; model: string } | { ok: false; error: string }> {
  const errors: string[] = [];
  for (const model of GEMINI_MODELS) {
    for (let attempt = 0; attempt < 2; attempt++) {
      const r = await callGeminiOnce(apiKey, model, systemPrompt, history);
      if (r.ok) return { ok: true, text: r.text, model };
      const msg = `[${model} attempt ${attempt + 1}] ${r.error}`;
      console.error("[lily-reply] gemini call failed:", msg);
      errors.push(msg);
      const retryable = r.status === 429 || (r.status >= 500 && r.status < 600) || r.status === 0;
      if (!retryable) break;
      if (attempt === 0) await new Promise((res) => setTimeout(res, 600));
    }
  }
  return { ok: false, error: errors.join(" | ") };
}

// ---------- handler -------------------------------------------------------
Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });
  if (req.method !== "POST") {
    return new Response(JSON.stringify({ error: "method not allowed" }), {
      status: 405, headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }

  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL") ?? Deno.env.get("VITE_SUPABASE_URL");
    const serviceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
    const geminiKey = Deno.env.get("LOVABLE_API_KEY");
    if (!supabaseUrl || !serviceKey) {
      return new Response(JSON.stringify({ error: "supabase env not configured" }), {
        status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const body = (await req.json().catch(() => ({}))) as Body;
    const threadId = body.thread_id;
    const userMessageId = body.user_message_id;
    if (!threadId || !userMessageId) {
      return new Response(JSON.stringify({ error: "thread_id and user_message_id are required" }), {
        status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const admin = createClient(supabaseUrl, serviceKey, {
      auth: { persistSession: false, autoRefreshToken: false },
    });

    const { data: msg, error: msgErr } = await admin
      .from("chat_messages")
      .select("id, thread_id, sender, created_at")
      .eq("id", userMessageId)
      .maybeSingle();
    if (msgErr) {
      return new Response(JSON.stringify({ error: "msg lookup failed: " + msgErr.message }), {
        status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }
    if (!msg || msg.thread_id !== threadId || msg.sender !== "user") {
      return new Response(JSON.stringify({ error: "message not found in thread" }), {
        status: 404, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // GUARD 1 — IDEMPOTENCY: one reply per user message. If a lily message
    // already exists in this thread AFTER the user message, do not insert
    // another reply (covers double-invocations and client retries).
    {
      const { data: existing } = await admin
        .from("chat_messages")
        .select("id")
        .eq("thread_id", threadId)
        .eq("sender", "lily")
        .gt("created_at", msg.created_at as string)
        .limit(1);
      if (existing && existing.length > 0) {
        return new Response(
          JSON.stringify({ ok: true, replied: false, reason: "already_replied" }),
          { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } },
        );
      }
    }

    const { data: settings, error: setErr } = await admin
      .from("lily_settings").select("mode").eq("id", 1).maybeSingle();
    if (setErr) {
      return new Response(JSON.stringify({ error: "settings read failed: " + setErr.message }), {
        status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }
    const mode = settings?.mode ?? "ai";
    if (mode === "human") {
      return new Response(JSON.stringify({ ok: true, replied: false, reason: "human_mode" }), {
        status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const { data: thread } = await admin
      .from("chat_threads").select("user_id, admin_replied_at").eq("id", threadId).maybeSingle();
    const userId = (thread?.user_id as string | undefined) ?? null;

    // GUARD 3 — ADMIN SUPPRESSION: if an admin sent a manual reply in
    // this thread within the last SUPPRESS_MINUTES, stay silent so the
    // employee doesn't get a double response. Per-thread only.
    // Only applies in Human mode; in AI mode Lily replies regardless.
    if (mode === "human") {
      const adminRepliedAt = thread?.admin_replied_at as string | null | undefined;
      if (adminRepliedAt) {
        const ageMs = Date.now() - new Date(adminRepliedAt).getTime();
        if (ageMs >= 0 && ageMs < SUPPRESS_MINUTES * 60_000) {
          console.log(
            `[lily-reply] suppressed (admin replied ${Math.round(ageMs / 1000)}s ago, ` +
            `window=${SUPPRESS_MINUTES}m) thread=${threadId}`,
          );
          return new Response(
            JSON.stringify({ ok: true, replied: false, reason: "admin_recent_reply" }),
            { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } },
          );
        }
      }
    }

    const { data: rows } = await admin
      .from("chat_messages")
      .select("sender, body, created_at")
      .eq("thread_id", threadId)
      .order("created_at", { ascending: false })
      .limit(20);
    const ordered = (rows ?? []).slice().reverse();
    const history = ordered.map((r) => ({
      role: r.sender === "user" ? "user" as const : "model" as const,
      text: r.body as string,
    }));

    // LAYER 1
    const state = await resolveUserState(admin, userId);

    // LAYER 2 — task ctx + snapshot only for active + admin
    let ctx: LilyContext = { name: null, groupName: null, tasks: [] };
    let snapshot: Snapshot = { text: "", loaded: false };
    if (userId && (state === "active" || state === "admin" || state === "not_started" || state === "completed")) {
      // We always load name for personalization. Tasks/snapshot are
      // only EMITTED into the prompt for active + admin (see buildSystemPrompt).
      ctx = await loadContext(admin, userId);
    }
    if (userId && (state === "active" || state === "admin")) {
      snapshot = await loadSnapshot(admin, userId, state, ctx);
    }

    const timeFacts = await loadTimeFacts(admin, userId);
    const systemPrompt = buildSystemPrompt(state, ctx, snapshot, timeFacts);

    let replyText = FALLBACK_REPLY;
    let modelUsed: string | null = null;
    if (geminiKey) {
      const g = await callGemini(geminiKey, systemPrompt, history);
      if (g.ok) {
        replyText = g.text;
        modelUsed = g.model;
        if (g.model !== GEMINI_MODELS[0]) {
          console.log(`[lily-reply] served via fallback model: ${g.model}`);
        }
      } else {
        console.error("[lily-reply] all gemini attempts failed:", g.error);
        replyText = OUTAGE_REPLY;
      }
    } else {
      console.error("[lily-reply] LOVABLE_API_KEY not configured — using outage reply");
      replyText = OUTAGE_REPLY;
    }

    // GUARD 2 — OUTAGE DEDUPE: never stack outage replies. If the thread's
    // latest lily message is already the OUTAGE_REPLY, skip the insert.
    if (replyText === OUTAGE_REPLY) {
      const { data: lastLily } = await admin
        .from("chat_messages")
        .select("body")
        .eq("thread_id", threadId)
        .eq("sender", "lily")
        .order("created_at", { ascending: false })
        .limit(1);
      if (lastLily && lastLily.length > 0 && lastLily[0].body === OUTAGE_REPLY) {
        return new Response(
          JSON.stringify({ ok: true, replied: false, reason: "outage_deduped" }),
          { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } },
        );
      }
    }

    const nowIso = new Date().toISOString();
    const { data: inserted, error: insErr } = await admin
      .from("chat_messages")
      .insert({
        thread_id: threadId,
        sender: "lily",
        body: replyText,
        sender_user_id: null,
      })
      .select("id, thread_id, sender, body, created_at")
      .single();
    if (insErr) {
      return new Response(JSON.stringify({ error: "insert failed: " + insErr.message }), {
        status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    await admin.from("chat_threads").update({ last_message_at: nowIso }).eq("id", threadId);

    return new Response(
      JSON.stringify({
        ok: true,
        replied: true,
        message: inserted,
        resolved_state: state,
        snapshot_loaded: snapshot.loaded,
        snapshot_chars: snapshot.text.length,
        model_used: modelUsed,
      }),
      { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } },
    );
  } catch (err) {
    const message = err instanceof Error ? `${err.name}: ${err.message}` : String(err);
    console.error("[lily-reply] handler threw:", err);
    return new Response(JSON.stringify({ error: "internal: " + message }), {
      status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
