// agent-mcp — locked-down JSON-RPC MCP endpoint for the "Agent Tars" identity.
//
// Sibling of supabase/functions/mcp/index.ts. Same JSON-RPC 2.0 transport,
// same status/update write shapes, BUT:
//   - No authentication — URL alone is the access control (deployed with
//     verify_jwt = false). The 4-tool allow-list below is the only gate.
//   - Resolves the actor as the public.users row WHERE full_name='Agent Tars'
//     (NOT the admin service actor). So updated_by / author_id on every row
//     this endpoint writes is Agent Tars's id; the board shows "Agent Tars"
//     next to the status change / update.
//   - Tool allow-list is HARD: exactly seven tools are exposed AND accepted:
//        list_boards, get_board, update_task_status, add_task_update,
//        get_task_updates, upload_file, add_task_update_with_file.
//        Anything else returns -32601 "tool not permitted for this endpoint"
//        and performs no write.

//
// Read tools (list_boards, get_board) and the two write tools are
// behaviour-identical to mcp/index.ts so callers can reuse the same
// discovery → write flow. Cross-tenant reads are intentional (RLS bypass)
// — the workspace_id surfaced on every row is the multi-tenant boundary
// the caller must respect.

import { vercel, type VercelLikeRequest, type VercelLikeResponse } from '../_shared/vercel-adapter.ts';
import { createClient, type SupabaseClient } from 'npm:@supabase/supabase-js@2';
import {
  parseSensitiveWorkspaceIds,
  assertWorkspaceWriteAllowed,
  assertTaskBoardAndWorkspace,
} from '../_shared/mcp-tenancy.ts';
import { logMcpRun } from '../_shared/mcp-logging.ts';

// ----- MCP protocol declaration ---------------------------------------
const MCP_PROTOCOL_VERSION = '2025-06-18';
const SERVER_NAME = 'pms-agent-mcp';
const SERVER_VERSION = '0.1.0';

// ----- JSON-RPC primitives --------------------------------------------
type JsonRpcId = string | number | null;
interface JsonRpcRequest { jsonrpc: '2.0'; id?: JsonRpcId; method: string; params?: unknown; }
interface JsonRpcOk      { jsonrpc: '2.0'; id: JsonRpcId; result: unknown; }
interface JsonRpcErr     { jsonrpc: '2.0'; id: JsonRpcId; error: { code: number; message: string; data?: unknown }; }

const ERR_PARSE          = -32700;
const ERR_INVALID_REQ    = -32600;
const ERR_METHOD         = -32601;
const ERR_INVALID_PARAMS = -32602;
const ERR_INTERNAL       = -32603;
const ERR_AUTH           = -32001;
const ERR_TOOL_FAILED    = -32002;

function ok(id: JsonRpcId, result: unknown): JsonRpcOk {
  return { jsonrpc: '2.0', id, result };
}
function err(id: JsonRpcId, code: number, message: string, data?: unknown): JsonRpcErr {
  return { jsonrpc: '2.0', id, error: { code, message, ...(data !== undefined ? { data } : {}) } };
}

// ----- Per-user group gating ------------------------------------------
// The Agent Tars connector account. Source of truth for what this MCP
// endpoint is allowed to READ: only groups granted to this user in
// public.group_user_visibility (and their tasks, and boards containing
// at least one such granted group). The same id is ALSO the write-stamp
// actor returned by getAgentTarsActorId — intentional, do not change.
const AGENT_TARS_GATING_USER_ID = '5c9c6af5-8611-4273-9387-e1f551eeb0b8';

async function grantedGroupIdsForBoard(sb: SupabaseClient, boardId: string): Promise<string[]> {
  const { data, error } = await sb
    .from('group_user_visibility')
    .select('group_id, groups!inner(board_id)')
    .eq('user_id', AGENT_TARS_GATING_USER_ID)
    .eq('groups.board_id', boardId);
  if (error) throw new Error(`grantedGroupIdsForBoard failed: ${error.message}`);
  return ((data ?? []) as Array<{ group_id: string }>).map((r) => r.group_id);
}

async function grantedBoardIds(sb: SupabaseClient): Promise<string[]> {
  const { data, error } = await sb
    .from('group_user_visibility')
    .select('group_id, groups!inner(board_id)')
    .eq('user_id', AGENT_TARS_GATING_USER_ID);
  if (error) throw new Error(`grantedBoardIds failed: ${error.message}`);
  const ids = ((data ?? []) as Array<{ groups: { board_id: string } | null }>)
    .map((r) => r.groups?.board_id)
    .filter((v): v is string => !!v);
  return Array.from(new Set(ids));
}



// ----- Tool catalogue (7 tools — HARD allow-list) ---------------
const TOOLS = {
  list_boards: {
    name: 'list_boards',
    description:
      'List every board visible to the Agent Tars MCP caller. Returns each board\'s id, ' +
      'name, icon_emoji, board_type (main|private), archived flag, workspace_id, and ' +
      'workspace_name. Use workspace_id as the multi-tenant boundary.',
    inputSchema: {
      type: 'object',
      properties: {
        include_archived: { type: 'boolean', description: 'If true, include archived boards.', default: false },
      },
      additionalProperties: false,
    },
  },
  get_board: {
    name: 'get_board',
    description:
      'Snapshot of a board — groups, columns (with labels), and every non-deleted task ' +
      'with its current cell values. Use this to find a task by name (capture its id) ' +
      'before calling update_task_status or add_task_update.',
    inputSchema: {
      type: 'object',
      properties: {
        board_id: { type: 'string', description: 'UUID of the board to snapshot.' },
      },
      required: ['board_id'],
      additionalProperties: false,
    },
  },
  update_task_status: {
    name: 'update_task_status',
    description:
      'Move a task into a status label by NAME. Only the board\'s first status column is ' +
      'targeted — this tool cannot touch any other column. Tenancy-checked; refuses ' +
      'sensitive-workspace writes without confirm_sensitive_workspace.',
    inputSchema: {
      type: 'object',
      properties: {
        task_id:      { type: 'string', description: 'UUID of the task.' },
        status_label: { type: 'string', description: 'Label name (e.g. "Done", "Working on it").' },
        confirm_sensitive_workspace: { type: 'boolean', default: false },
      },
      required: ['task_id', 'status_label'],
      additionalProperties: false,
    },
  },
  add_task_update: {
    name: 'add_task_update',
    description:
      'Post an update (conversation message) on a task. body is plain text by default; ' +
      'set is_html:true to pass caller-supplied markup. Authored as "Agent Tars".',
    inputSchema: {
      type: 'object',
      properties: {
        task_id: { type: 'string', description: 'UUID of the task.' },
        body:    { type: 'string', description: 'Update body.' },
        is_html: { type: 'boolean', default: false },
        confirm_sensitive_workspace: { type: 'boolean', default: false },
      },
      required: ['task_id', 'body'],
      additionalProperties: false,
    },
  },
  get_task_updates: {
    name: 'get_task_updates',
    description: 'Read the update/comment thread on a task. Returns all updates with author name, body, and timestamp. Read-only — does not write anything.',
    inputSchema: {
      type: 'object',
      properties: {
        task_id: { type: 'string', description: 'UUID of the task to read updates from.' },
      },
      required: ['task_id'],
      additionalProperties: false,
    },
  },
  upload_file: {
    name: 'upload_file',
    description:
      'Download a file from a public URL and attach it to a task. Stores the bytes in the ' +
      'task-files bucket under boards/{board_id}/items/{task_id}/ and inserts a row in the ' +
      'files table (uploader = Agent Tars, item_id = task). Returns file_id, storage_path, ' +
      'file_name, mime_type, file_size, and a 1-hour signed URL. Tenancy-checked: refuses ' +
      'tasks not in a group granted to this connector.',
    inputSchema: {
      type: 'object',
      properties: {
        task_id:   { type: 'string', description: 'UUID of the task to attach the file to.' },
        file_url:  { type: 'string', description: 'Publicly fetchable HTTP(S) URL of the file.' },
        file_name: { type: 'string', description: 'Optional override for the stored file name. Defaults to the URL basename.' },
      },
      required: ['task_id', 'file_url'],
      additionalProperties: false,
    },
  },
  add_task_update_with_file: {
    name: 'add_task_update_with_file',
    description:
      'Post an update on a task AND attach a file to it, in one call. Provide either ' +
      'file_url (downloaded + uploaded to storage) OR storage_path (already in the ' +
      'task-files bucket, e.g. returned by upload_file). The file row is linked to the ' +
      'task; the update body_html has a "📎 file_name" link to the signed URL appended. ' +
      'Authored as "Agent Tars". Tenancy-checked.',
    inputSchema: {
      type: 'object',
      properties: {
        task_id:      { type: 'string', description: 'UUID of the task.' },
        body:         { type: 'string', description: 'Update body.' },
        is_html:      { type: 'boolean', default: false },
        file_url:     { type: 'string', description: 'Public URL to download + upload. Mutually exclusive with storage_path.' },
        storage_path: { type: 'string', description: 'Existing path in the task-files bucket. Mutually exclusive with file_url.' },
        file_name:    { type: 'string', description: 'Optional override for the stored file name (only used with file_url).' },
        confirm_sensitive_workspace: { type: 'boolean', default: false },
      },
      required: ['task_id', 'body'],
      additionalProperties: false,
    },
  },
} as const;


const ALLOWED_TOOL_NAMES = new Set(Object.keys(TOOLS));

// =====================================================================
// HTTP handler
// =====================================================================
export default async function handler(req: VercelLikeRequest, res: VercelLikeResponse) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization, Mcp-Session-Id, MCP-Protocol-Version');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  if (req.method === 'OPTIONS') { res.status(200).end(); return; }

  {
    const pathOnly = (req.url || '').split('?')[0] || '';
    if (/\/\.well-known\//.test(pathOnly)) { res.status(404).json({}); return; }
  }

  if (req.method === 'GET') {
    res.status(200).json({ ok: true, transport: 'http', hint: 'POST JSON-RPC 2.0', server: SERVER_NAME });
    return;
  }
  if (req.method !== 'POST') {
    res.status(405).json(err(null, ERR_METHOD, 'Only POST is supported on this MCP endpoint'));
    return;
  }

  try {
    // ---- 1. Env / config checks --------------------------------------
    // No bearer required — auth is removed; the 4-tool allow-list is the
    // sole gate. Only Supabase service-role + URL are needed to write.
    const supabaseUrl =
      Deno.env.get('SUPABASE_URL') ?? Deno.env.get('VITE_SUPABASE_URL');
    const serviceRoleKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY');
    if (!supabaseUrl || !serviceRoleKey) {
      res.status(500).json(err(null, ERR_INTERNAL,
        'SUPABASE_URL / SUPABASE_SERVICE_ROLE_KEY not configured on server'));
      return;
    }

    // ---- 3. Parse JSON-RPC body --------------------------------------
    const message = parseRequestBody(req.body);
    if ('parseError' in message) {
      res.status(400).json(err(null, ERR_PARSE, message.parseError));
      return;
    }
    if (!isJsonRpcRequest(message.payload)) {
      res.status(400).json(err((message.payload as { id?: JsonRpcId })?.id ?? null,
        ERR_INVALID_REQ, 'Body is not a valid JSON-RPC 2.0 request'));
      return;
    }
    const rpc = message.payload;
    const isNotification = !('id' in rpc) || rpc.id === undefined;

    // ---- 3b. Auth gate removed --------------------------------------
    // This endpoint is intentionally unauthenticated. The hard 4-tool
    // allow-list below + Agent Tars actor attribution are the security
    // model; any other tool name is rejected with -32601 before any
    // write occurs.

    // ---- 4. Service-role client (RLS bypassed; tenancy enforced in code)
    const sb = createClient(supabaseUrl, serviceRoleKey, {
      auth: { persistSession: false, autoRefreshToken: false },
    });

    // ---- 5. Dispatch -------------------------------------------------
    const result = await dispatch(rpc, sb);
    if (isNotification) { res.status(202).end(); return; }
    res.status(200).json(result);
  } catch (e) {
    const message = e instanceof Error ? `${e.name}: ${e.message}` : String(e);
    console.error('[agent-mcp] handler threw:', e);
    res.status(500).json(err(null, ERR_INTERNAL, `internal: ${message}`));
  }
}

// =====================================================================
// Method dispatch
// =====================================================================
async function dispatch(rpc: JsonRpcRequest, sb: SupabaseClient): Promise<JsonRpcOk | JsonRpcErr> {
  const id = rpc.id ?? null;

  switch (rpc.method) {
    case 'initialize': {
      const params = (rpc.params ?? {}) as { protocolVersion?: string; clientInfo?: unknown };
      return ok(id, {
        protocolVersion: MCP_PROTOCOL_VERSION,
        serverInfo: { name: SERVER_NAME, version: SERVER_VERSION },
        capabilities: { tools: { listChanged: false } },
        instructions:
          'Agent Tars MCP endpoint. Seven tools are available: list_boards, get_board, ' +
          'update_task_status, add_task_update, get_task_updates, upload_file, ' +
          'add_task_update_with_file. Discover boards/tasks with the read tools (including ' +
          'get_task_updates to read a task\'s comment thread), then call the write tools — ' +
          'every write is attributed to "Agent Tars" on the board.',

        clientInfo: params.clientInfo,
      });
    }
    case 'notifications/initialized':
    case 'initialized':
      return ok(id, {});

    case 'tools/list':
      return ok(id, { tools: Object.values(TOOLS) });

    case 'tools/call': {
      const params = rpc.params as { name?: string; arguments?: Record<string, unknown> } | undefined;
      const toolName = params?.name;
      const args = params?.arguments ?? {};
      if (!toolName) {
        return err(id, ERR_INVALID_PARAMS, 'tools/call requires params.name');
      }
      if (!ALLOWED_TOOL_NAMES.has(toolName)) {
        return err(id, ERR_METHOD, `tool not permitted for this endpoint: ${toolName}`);
      }
      const sensitiveWs = parseSensitiveWorkspaceIds();
      try {
        let payload: unknown;
        switch (toolName) {
          case 'list_boards':
            payload = await toolListBoards(sb, args as { include_archived?: boolean });
            break;
          case 'get_board':
            payload = await toolGetBoard(sb, args as { board_id?: string });
            break;
          case 'update_task_status':
            payload = await toolUpdateTaskStatus(sb, args as unknown as ToolUpdateTaskStatusArgs, sensitiveWs);
            break;
          case 'add_task_update':
            payload = await toolAddTaskUpdate(sb, args as unknown as ToolAddTaskUpdateArgs, sensitiveWs);
            break;
          case 'get_task_updates':
            payload = await toolGetTaskUpdates(sb, args as { task_id?: string });
            break;
          case 'upload_file':
            payload = await toolUploadFile(sb, args as unknown as ToolUploadFileArgs);
            break;
          case 'add_task_update_with_file':
            payload = await toolAddTaskUpdateWithFile(sb, args as unknown as ToolAddTaskUpdateWithFileArgs, sensitiveWs);
            break;

          default:
            // Belt-and-braces — ALLOWED_TOOL_NAMES already filtered.
            return err(id, ERR_METHOD, `tool not permitted for this endpoint: ${toolName}`);
        }
        return ok(id, { content: [{ type: 'text', text: JSON.stringify(payload) }], structuredContent: payload });
      } catch (e) {
        const m = e instanceof Error ? e.message : String(e);
        return err(id, ERR_TOOL_FAILED, `tool ${toolName} failed: ${m}`);
      }
    }

    default:
      return err(id, ERR_METHOD, `method not supported: ${rpc.method}`);
  }
}

// =====================================================================
// Tool: list_boards   (behavior-identical to mcp/index.ts)
// =====================================================================
interface BoardListItem {
  id: string; name: string; icon_emoji: string; board_type: 'main' | 'private';
  workspace_id: string; workspace_name: string | null; archived: boolean; created_at: string;
}
async function toolListBoards(
  sb: SupabaseClient,
  args: { include_archived?: boolean },
): Promise<{ boards: BoardListItem[]; count: number; workspaces: { id: string; name: string }[] }> {
  const includeArchived = args.include_archived === true;
  const allowedBoardIds = await grantedBoardIds(sb);
  if (allowedBoardIds.length === 0) {
    return { boards: [], count: 0, workspaces: [] };
  }
  const { data: boards, error } = await sb
    .from('boards')
    .select('id, name, icon_emoji, board_type, workspace_id, archived_at, created_at')
    .in('id', allowedBoardIds)
    .is('deleted_at', null)
    .order('created_at', { ascending: false });

  if (error) throw new Error(`boards select failed: ${error.message}`);
  const rows = (boards ?? []) as Array<{
    id: string; name: string; icon_emoji: string; board_type: 'main' | 'private';
    workspace_id: string; archived_at: string | null; created_at: string;
  }>;
  const wsIds = Array.from(new Set(rows.map((b) => b.workspace_id)));
  const wsById = new Map<string, string>();
  if (wsIds.length > 0) {
    const { data: ws } = await sb.from('workspaces').select('id, name').in('id', wsIds);
    for (const w of (ws ?? []) as { id: string; name: string }[]) wsById.set(w.id, w.name);
  }
  const visible = rows
    .filter((b) => includeArchived || !b.archived_at)
    .map<BoardListItem>((b) => ({
      id: b.id, name: b.name, icon_emoji: b.icon_emoji, board_type: b.board_type,
      workspace_id: b.workspace_id, workspace_name: wsById.get(b.workspace_id) ?? null,
      archived: !!b.archived_at, created_at: b.created_at,
    }));
  return {
    boards: visible, count: visible.length,
    workspaces: Array.from(wsById, ([id, name]) => ({ id, name })),
  };
}

// =====================================================================
// Tool: get_board   (behavior-identical to mcp/index.ts)
// =====================================================================
interface BoardSnapshot {
  board: {
    id: string; name: string; workspace_id: string; workspace_name: string | null;
    board_type: 'main' | 'private'; icon_emoji: string; description: string | null;
  };
  groups: Array<{ id: string; name: string; color: string; sort_order: number }>;
  columns: Array<{
    id: string; name: string; column_type: string; sort_order: number;
    labels: Array<{ id: string; name: string; color: string; sort_order: number }>;
  }>;
  tasks: Array<{
    id: string; name: string; task_code: string; group_id: string;
    parent_item_id: string | null; sort_order: number; archived: boolean;
    cells: Record<string, unknown>;
  }>;
  task_count: number;
}
async function toolGetBoard(sb: SupabaseClient, args: { board_id?: string }): Promise<BoardSnapshot> {
  if (!args.board_id || typeof args.board_id !== 'string') {
    throw new Error('board_id (string) is required');
  }
  const boardId = args.board_id;
  const { data: board, error: bErr } = await sb
    .from('boards')
    .select('id, name, workspace_id, board_type, icon_emoji, description')
    .eq('id', boardId).is('deleted_at', null).maybeSingle();
  if (bErr) throw new Error(`board select failed: ${bErr.message}`);
  if (!board) throw new Error(`board not found: ${boardId}`);
  const { data: ws } = await sb.from('workspaces').select('name').eq('id', board.workspace_id).maybeSingle();
  // Per-user group gating — only groups granted to the Agent Tars connector
  // user in group_user_visibility are returned, and tasks are filtered to
  // those granted group_ids. Columns remain board-wide.
  const granted = await grantedGroupIdsForBoard(sb, boardId);
  if (granted.length === 0) {
    // Short-circuit: still return board shell + columns, but no groups/tasks.
    const { data: columnsOnly, error: cErrOnly } = await sb
      .from('columns').select('id, name, column_type, sort_order')
      .eq('board_id', boardId).is('archived_at', null).order('sort_order');
    if (cErrOnly) throw new Error(`columns select failed: ${cErrOnly.message}`);
    const colIdsOnly = (columnsOnly ?? []).map((c) => (c as { id: string }).id);
    const { data: labelsOnly, error: lErrOnly } = colIdsOnly.length === 0
      ? { data: [] as Array<{ id: string; column_id: string; name: string; color: string; sort_order: number }>, error: null }
      : await sb.from('column_labels').select('id, column_id, name, color, sort_order').in('column_id', colIdsOnly).order('sort_order');
    if (lErrOnly) throw new Error(`labels select failed: ${lErrOnly.message}`);
    const labelsByColOnly = new Map<string, Array<{ id: string; name: string; color: string; sort_order: number }>>();
    for (const l of (labelsOnly ?? []) as Array<{ id: string; column_id: string; name: string; color: string; sort_order: number }>) {
      const arr = labelsByColOnly.get(l.column_id) ?? [];
      arr.push({ id: l.id, name: l.name, color: l.color, sort_order: l.sort_order });
      labelsByColOnly.set(l.column_id, arr);
    }
    return {
      board: {
        id: board.id, name: board.name, workspace_id: board.workspace_id,
        workspace_name: (ws as { name?: string } | null)?.name ?? null,
        board_type: board.board_type, icon_emoji: board.icon_emoji, description: board.description,
      },
      groups: [],
      columns: ((columnsOnly ?? []) as Array<{ id: string; name: string; column_type: string; sort_order: number }>)
        .map((c) => ({
          id: c.id, name: c.name, column_type: c.column_type, sort_order: c.sort_order,
          labels: labelsByColOnly.get(c.id) ?? [],
        })),
      tasks: [],
      task_count: 0,
    };
  }
  const [
    { data: groups, error: gErr },
    { data: columns, error: cErr },
    { data: items, error: iErr },
  ] = await Promise.all([
    sb.from('groups').select('id, name, color, sort_order')
      .eq('board_id', boardId).is('deleted_at', null).in('id', granted).order('sort_order'),
    sb.from('columns').select('id, name, column_type, sort_order')
      .eq('board_id', boardId).is('archived_at', null).order('sort_order'),
    sb.from('items').select('id, name, task_code, group_id, parent_item_id, sort_order, archived_at')
      .eq('board_id', boardId).is('deleted_at', null).in('group_id', granted).order('group_id').order('sort_order'),
  ]);

  if (gErr) throw new Error(`groups select failed: ${gErr.message}`);
  if (cErr) throw new Error(`columns select failed: ${cErr.message}`);
  if (iErr) throw new Error(`items select failed: ${iErr.message}`);

  const colIds  = (columns ?? []).map((c) => c.id);
  const itemIds = (items   ?? []).map((i) => (i as { id: string }).id);
  const labelsByCol = new Map<string, Array<{ id: string; name: string; color: string; sort_order: number }>>();
  const cellsByItem = new Map<string, Record<string, unknown>>();
  const [labelsRes, cellsRes] = await Promise.all([
    colIds.length === 0
      ? Promise.resolve({ data: [] as Array<{ id: string; column_id: string; name: string; color: string; sort_order: number }>, error: null })
      : sb.from('column_labels').select('id, column_id, name, color, sort_order').in('column_id', colIds).order('sort_order'),
    itemIds.length === 0
      ? Promise.resolve({ data: [] as Array<{ item_id: string; column_id: string; value: unknown }>, error: null })
      : sb.from('item_column_values').select('item_id, column_id, value').in('item_id', itemIds),
  ]);
  if (labelsRes.error) throw new Error(`labels select failed: ${labelsRes.error.message}`);
  if (cellsRes.error)  throw new Error(`item_column_values select failed: ${cellsRes.error.message}`);
  for (const l of (labelsRes.data ?? []) as Array<{ id: string; column_id: string; name: string; color: string; sort_order: number }>) {
    const arr = labelsByCol.get(l.column_id) ?? [];
    arr.push({ id: l.id, name: l.name, color: l.color, sort_order: l.sort_order });
    labelsByCol.set(l.column_id, arr);
  }
  for (const r of (cellsRes.data ?? []) as Array<{ item_id: string; column_id: string; value: unknown }>) {
    const map = cellsByItem.get(r.item_id) ?? {};
    map[r.column_id] = r.value;
    cellsByItem.set(r.item_id, map);
  }
  const tasksOut: BoardSnapshot['tasks'] = ((items ?? []) as Array<{
    id: string; name: string; task_code: string; group_id: string;
    parent_item_id: string | null; sort_order: number; archived_at: string | null;
  }>).map((it) => ({
    id: it.id, name: it.name, task_code: it.task_code, group_id: it.group_id,
    parent_item_id: it.parent_item_id, sort_order: it.sort_order,
    archived: !!it.archived_at, cells: cellsByItem.get(it.id) ?? {},
  }));
  return {
    board: {
      id: board.id, name: board.name, workspace_id: board.workspace_id,
      workspace_name: (ws as { name?: string } | null)?.name ?? null,
      board_type: board.board_type, icon_emoji: board.icon_emoji, description: board.description,
    },
    groups: (groups ?? []) as BoardSnapshot['groups'],
    columns: ((columns ?? []) as Array<{ id: string; name: string; column_type: string; sort_order: number }>)
      .map((c) => ({
        id: c.id, name: c.name, column_type: c.column_type, sort_order: c.sort_order,
        labels: labelsByCol.get(c.id) ?? [],
      })),
    tasks: tasksOut,
    task_count: tasksOut.length,
  };
}

// =====================================================================
// Tool: update_task_status — Agent Tars actor
// Copied byte-for-byte from mcp/index.ts EXCEPT actor = getAgentTarsActorId.
// Only ever touches the board's first status column (no other column).
// =====================================================================
interface ToolUpdateTaskStatusArgs {
  task_id: string;
  status_label: string;
  confirm_sensitive_workspace?: boolean;
}
async function toolUpdateTaskStatus(
  sb: SupabaseClient,
  args: ToolUpdateTaskStatusArgs,
  sensitive: Set<string>,
): Promise<{ task_id: string; board_id: string; workspace_id: string; label_id: string; actor_id: string }> {
  if (!args.task_id)      throw new Error('task_id is required');
  if (!args.status_label) throw new Error('status_label is required');

  const t = await assertTaskBoardAndWorkspace(sb, args.task_id);
  assertWorkspaceWriteAllowed(t.workspaceId, sensitive, args.confirm_sensitive_workspace === true);

  const { data: statusCols } = await sb
    .from('columns')
    .select('id')
    .eq('board_id', t.boardId)
    .eq('column_type', 'status')
    .is('archived_at', null)
    .order('sort_order')
    .limit(1);
  const statusColId = ((statusCols ?? [])[0] as { id?: string } | undefined)?.id;
  if (!statusColId) throw new Error(`no status column on board ${t.boardId}`);

  // HARD GUARD: this connector can ONLY write to the Status column on the
  // Tessera board. If the resolved column id is anything else, refuse the
  // write entirely (no DB mutation happens after this point).
  const ALLOWED_STATUS_COLUMN_ID = '4c6c4dd5-5fee-4652-95cb-93971a6fc4fa';
  if (statusColId !== ALLOWED_STATUS_COLUMN_ID) {
    throw new Error('This connector can only change the Status column.');
  }

  const { data: labels } = await sb
    .from('column_labels')
    .select('id, name')
    .eq('column_id', statusColId);
  const label = (labels ?? []).find((l) => (l as { name: string }).name === args.status_label) as { id: string } | undefined;
  if (!label) throw new Error(`status label "${args.status_label}" not found on this board`);

  const actor = await getAgentTarsActorId(sb);
  const { error } = await sb
    .from('item_column_values')
    .upsert({
      item_id: t.taskId,
      column_id: statusColId,
      value: { label_id: label.id },
      updated_by: actor,
    } as never, { onConflict: 'item_id,column_id' });
  if (error) {
    await logMcpRun(sb, {
      toolName: 'update_task_status', status: 'error',
      workspaceId: t.workspaceId, boardId: t.boardId,
      prompt: args.status_label, responseSummary: 'upsert failed',
      errorMessage: error.message,
    });
    throw new Error(`status upsert failed: ${error.message}`);
  }
  await logMcpRun(sb, {
    toolName: 'update_task_status', status: 'success',
    workspaceId: t.workspaceId, boardId: t.boardId,
    prompt: args.status_label,
    responseSummary: `agent-mcp task=${t.taskId} → label=${label.id} actor=${actor}`,
  });
  return {
    task_id: t.taskId,
    board_id: t.boardId,
    workspace_id: t.workspaceId,
    label_id: label.id,
    actor_id: actor,
  };
}

// =====================================================================
// Tool: add_task_update — Agent Tars actor
// Copied byte-for-byte from mcp/index.ts EXCEPT actor = getAgentTarsActorId.
// =====================================================================
interface ToolAddTaskUpdateArgs {
  task_id: string;
  body: string;
  is_html?: boolean;
  confirm_sensitive_workspace?: boolean;
}
async function toolAddTaskUpdate(
  sb: SupabaseClient,
  args: ToolAddTaskUpdateArgs,
  sensitive: Set<string>,
): Promise<{ update_id: string; task_id: string; board_id: string; workspace_id: string; actor_id: string }> {
  if (!args.task_id) throw new Error('task_id is required');
  if (!args.body || args.body.trim().length === 0) throw new Error('body is required');

  const t = await assertTaskBoardAndWorkspace(sb, args.task_id);
  assertWorkspaceWriteAllowed(t.workspaceId, sensitive, args.confirm_sensitive_workspace === true);

  const bodyHtml = args.is_html
    ? args.body
    : `<p>${escapeHtml(args.body)}</p>`;

  const actor = await getAgentTarsActorId(sb);
  const { data, error } = await sb
    .from('updates')
    .insert({
      item_id:   t.taskId,
      author_id: actor,
      body_html: bodyHtml,
      body_json: null,
    } as never)
    .select('id')
    .single();
  if (error) {
    await logMcpRun(sb, {
      toolName: 'add_task_update', status: 'error',
      workspaceId: t.workspaceId, boardId: t.boardId,
      prompt: args.body.slice(0, 200),
      responseSummary: `insert failed: ${error.message}`,
      errorMessage: error.message,
    });
    throw new Error(`updates insert failed: ${error.message}`);
  }
  const updateId = (data as { id: string }).id;
  await logMcpRun(sb, {
    toolName: 'add_task_update', status: 'success',
    workspaceId: t.workspaceId, boardId: t.boardId,
    prompt: args.body.slice(0, 200),
    responseSummary: `agent-mcp update_id=${updateId} actor=${actor}`,
  });
  return { update_id: updateId, task_id: t.taskId, board_id: t.boardId, workspace_id: t.workspaceId, actor_id: actor };
}

// =====================================================================
// Tool: get_task_updates — read-only, wall-checked
// =====================================================================
async function toolGetTaskUpdates(
  sb: SupabaseClient,
  args: { task_id?: string },
): Promise<{ task_id: string; updates: Array<{ id: string; author_name: string; body_html: string; created_at: string }> }> {
  if (!args.task_id || typeof args.task_id !== 'string') {
    throw new Error('task_id (string) is required');
  }
  const { data: task, error: tErr } = await sb
    .from('items')
    .select('id, group_id, board_id')
    .eq('id', args.task_id)
    .is('deleted_at', null)
    .maybeSingle();
  if (tErr) throw new Error(`task lookup failed: ${tErr.message}`);
  if (!task) throw new Error(`task not found: ${args.task_id}`);
  const granted = await grantedGroupIdsForBoard(sb, (task as { board_id: string }).board_id);
  if (!granted.includes((task as { group_id: string }).group_id)) {
    throw new Error(`task ${args.task_id} is not in a group granted to this connector`);
  }
  const { data: updates, error: uErr } = await sb
    .from('updates')
    .select('id, author_id, body_html, created_at')
    .eq('item_id', args.task_id)
    .order('created_at', { ascending: true });
  if (uErr) throw new Error(`updates select failed: ${uErr.message}`);
  const authorIds = Array.from(new Set((updates ?? []).map((u: any) => u.author_id).filter(Boolean)));
  const authorMap = new Map<string, string>();
  if (authorIds.length > 0) {
    const { data: authors } = await sb
      .from('users')
      .select('id, full_name')
      .in('id', authorIds);
    for (const a of (authors ?? []) as Array<{ id: string; full_name: string }>) {
      authorMap.set(a.id, a.full_name ?? 'Unknown');
    }
  }
  return {
    task_id: args.task_id,
    updates: ((updates ?? []) as Array<{ id: string; author_id: string; body_html: string; created_at: string }>).map((u) => ({
      id: u.id,
      author_name: authorMap.get(u.author_id) ?? 'Unknown',
      body_html: u.body_html,
      created_at: u.created_at,
    })),
  };
}

// =====================================================================
// Actor resolution — Agent Tars (NOT the admin service actor)
// Looked up by full_name='Agent Tars'; cached per-instance.
// =====================================================================
const AGENT_TARS_ACTOR_CACHE: { id: string | null } = { id: null };
async function getAgentTarsActorId(sb: SupabaseClient): Promise<string> {
  if (AGENT_TARS_ACTOR_CACHE.id) return AGENT_TARS_ACTOR_CACHE.id;
  const { data, error } = await sb
    .from('users')
    .select('id')
    .eq('id', '5c9c6af5-8611-4273-9387-e1f551eeb0b8')
    .limit(1)
    .maybeSingle();
  if (error) throw new Error(`could not resolve Agent Tars actor: ${error.message}`);
  const id = (data as { id?: string } | null)?.id;
  if (!id) throw new Error('Agent TARS account (5c9c6af5-8611-4273-9387-e1f551eeb0b8) not found');
  AGENT_TARS_ACTOR_CACHE.id = id;
  return id;
}

// =====================================================================
// Local helpers (copied from mcp/index.ts so this function stands alone)
// =====================================================================
function escapeHtml(s: string): string {
  return s
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

type ParseOk = { payload: unknown };
type ParseFail = { parseError: string };
function parseRequestBody(body: unknown): ParseOk | ParseFail {
  if (body == null) return { parseError: 'request body is required' };
  if (typeof body === 'string') {
    if (body.trim().length === 0) return { parseError: 'request body is empty' };
    try { return { payload: JSON.parse(body) }; }
    catch (e) {
      return { parseError: `body is not valid JSON: ${e instanceof Error ? e.message : String(e)}` };
    }
  }
  if (typeof body === 'object') return { payload: body };
  return { parseError: `unexpected body type: ${typeof body}` };
}

function isJsonRpcRequest(x: unknown): x is JsonRpcRequest {
  if (!x || typeof x !== 'object') return false;
  const r = x as Record<string, unknown>;
  return r.jsonrpc === '2.0' && typeof r.method === 'string';
}

// =====================================================================
// File-attachment helpers (shared by upload_file + add_task_update_with_file)
// =====================================================================
const FILES_BUCKET = 'task-files';
const MAX_FILE_BYTES = 50 * 1024 * 1024; // 50 MB cap on URL downloads

// Loads the task, verifies it's in a group granted to the Agent Tars
// connector, and returns the ids needed by the file pipeline.
async function assertTaskInGrantedGroup(
  sb: SupabaseClient,
  taskId: string,
): Promise<{ taskId: string; boardId: string; groupId: string }> {
  const { data: task, error } = await sb
    .from('items')
    .select('id, group_id, board_id')
    .eq('id', taskId)
    .is('deleted_at', null)
    .maybeSingle();
  if (error) throw new Error(`task lookup failed: ${error.message}`);
  if (!task) throw new Error(`task not found: ${taskId}`);
  const row = task as { id: string; group_id: string; board_id: string };
  const granted = await grantedGroupIdsForBoard(sb, row.board_id);
  if (!granted.includes(row.group_id)) {
    throw new Error(`task ${taskId} is not in a group granted to this connector`);
  }
  return { taskId: row.id, boardId: row.board_id, groupId: row.group_id };
}

function basenameFromUrl(rawUrl: string): string {
  try {
    const u = new URL(rawUrl);
    const last = u.pathname.split('/').filter(Boolean).pop() ?? 'file';
    return decodeURIComponent(last) || 'file';
  } catch {
    return 'file';
  }
}

function safeFileName(name: string): string {
  const trimmed = (name || 'file').replace(/[^a-zA-Z0-9._-]/g, '_');
  return trimmed.length > 0 ? trimmed : 'file';
}

function buildItemStoragePath(boardId: string, itemId: string, fileName: string): string {
  return `boards/${boardId}/items/${itemId}/${crypto.randomUUID()}-${safeFileName(fileName)}`;
}

// Download bytes from a public URL (size-capped) and return as Blob + meta.
async function downloadPublicFile(
  fileUrl: string,
): Promise<{ bytes: Uint8Array; mime: string; size: number }> {
  let parsed: URL;
  try { parsed = new URL(fileUrl); }
  catch { throw new Error(`file_url is not a valid URL: ${fileUrl}`); }
  if (parsed.protocol !== 'http:' && parsed.protocol !== 'https:') {
    throw new Error(`file_url must be http(s): ${fileUrl}`);
  }
  const resp = await fetch(fileUrl, { redirect: 'follow' });
  if (!resp.ok) throw new Error(`file_url fetch failed (${resp.status} ${resp.statusText})`);
  const lenHeader = resp.headers.get('content-length');
  if (lenHeader && Number(lenHeader) > MAX_FILE_BYTES) {
    throw new Error(`file too large: ${lenHeader} bytes (max ${MAX_FILE_BYTES})`);
  }
  const buf = new Uint8Array(await resp.arrayBuffer());
  if (buf.byteLength > MAX_FILE_BYTES) {
    throw new Error(`file too large: ${buf.byteLength} bytes (max ${MAX_FILE_BYTES})`);
  }
  const mime = (resp.headers.get('content-type') ?? 'application/octet-stream').split(';')[0].trim()
    || 'application/octet-stream';
  return { bytes: buf, mime, size: buf.byteLength };
}

// Look up the metadata of an already-uploaded object in the task-files bucket.
async function statStorageObject(
  sb: SupabaseClient,
  storagePath: string,
): Promise<{ size: number; mime: string }> {
  const slash = storagePath.lastIndexOf('/');
  const dir = slash >= 0 ? storagePath.slice(0, slash) : '';
  const name = slash >= 0 ? storagePath.slice(slash + 1) : storagePath;
  const { data, error } = await sb.storage.from(FILES_BUCKET).list(dir, {
    search: name,
    limit: 100,
  });
  if (error) throw new Error(`storage stat failed: ${error.message}`);
  const hit = (data ?? []).find((o) => o.name === name);
  if (!hit) throw new Error(`storage_path not found in ${FILES_BUCKET}: ${storagePath}`);
  const meta = (hit.metadata ?? {}) as { size?: number; mimetype?: string };
  return {
    size: typeof meta.size === 'number' ? meta.size : 0,
    mime: meta.mimetype ?? 'application/octet-stream',
  };
}

// Insert the files row (uploader = Agent Tars, scoped to the task).
async function insertFileRow(
  sb: SupabaseClient,
  opts: {
    actor: string;
    itemId: string;
    updateId?: string | null;
    storagePath: string;
    fileName: string;
    fileSize: number;
    mimeType: string;
  },
): Promise<string> {
  const { data, error } = await sb
    .from('files')
    .insert({
      uploader_id: opts.actor,
      item_id: opts.itemId,
      update_id: opts.updateId ?? null,
      column_id: null,
      storage_path: opts.storagePath,
      file_name: opts.fileName,
      file_size: opts.fileSize,
      mime_type: opts.mimeType,
    } as never)
    .select('id')
    .single();
  if (error) throw new Error(`files insert failed: ${error.message}`);
  return (data as { id: string }).id;
}

async function createSignedFileUrl(
  sb: SupabaseClient,
  storagePath: string,
  expiresInSec = 3600,
): Promise<string> {
  const { data, error } = await sb.storage.from(FILES_BUCKET).createSignedUrl(storagePath, expiresInSec);
  if (error) throw new Error(`signed url failed: ${error.message}`);
  if (!data?.signedUrl) throw new Error('signed url response missing signedUrl');
  return data.signedUrl;
}

// =====================================================================
// Tool: upload_file — download a public URL, attach to a task
// =====================================================================
interface ToolUploadFileArgs {
  task_id: string;
  file_url: string;
  file_name?: string;
}
async function toolUploadFile(
  sb: SupabaseClient,
  args: ToolUploadFileArgs,
): Promise<{
  file_id: string; task_id: string; board_id: string;
  storage_path: string; file_name: string; mime_type: string;
  file_size: number; signed_url: string; actor_id: string;
}> {
  if (!args.task_id) throw new Error('task_id is required');
  if (!args.file_url) throw new Error('file_url is required');

  const t = await assertTaskInGrantedGroup(sb, args.task_id);
  const dl = await downloadPublicFile(args.file_url);
  const fileName = safeFileName(args.file_name || basenameFromUrl(args.file_url));
  const storagePath = buildItemStoragePath(t.boardId, t.taskId, fileName);

  const { error: upErr } = await sb.storage
    .from(FILES_BUCKET)
    .upload(storagePath, dl.bytes, { contentType: dl.mime, upsert: false });
  if (upErr) throw new Error(`storage upload failed: ${upErr.message}`);

  const actor = await getAgentTarsActorId(sb);
  let fileId: string;
  try {
    fileId = await insertFileRow(sb, {
      actor,
      itemId: t.taskId,
      storagePath,
      fileName,
      fileSize: dl.size,
      mimeType: dl.mime,
    });
  } catch (e) {
    // Roll the upload back so we don't orphan the object.
    try { await sb.storage.from(FILES_BUCKET).remove([storagePath]); } catch { /* best-effort */ }
    throw e;
  }
  const signed = await createSignedFileUrl(sb, storagePath);

  await logMcpRun(sb, {
    toolName: 'upload_file', status: 'success',
    workspaceId: null, boardId: t.boardId,
    prompt: args.file_url.slice(0, 200),
    responseSummary: `agent-mcp file=${fileId} path=${storagePath} actor=${actor}`,
  });
  return {
    file_id: fileId, task_id: t.taskId, board_id: t.boardId,
    storage_path: storagePath, file_name: fileName, mime_type: dl.mime,
    file_size: dl.size, signed_url: signed, actor_id: actor,
  };
}

// =====================================================================
// Tool: add_task_update_with_file — update + file in one call
// =====================================================================
interface ToolAddTaskUpdateWithFileArgs {
  task_id: string;
  body: string;
  is_html?: boolean;
  file_url?: string;
  storage_path?: string;
  file_name?: string;
  confirm_sensitive_workspace?: boolean;
}
async function toolAddTaskUpdateWithFile(
  sb: SupabaseClient,
  args: ToolAddTaskUpdateWithFileArgs,
  sensitive: Set<string>,
): Promise<{
  update_id: string; file_id: string; task_id: string; board_id: string;
  workspace_id: string; storage_path: string; file_name: string;
  signed_url: string; actor_id: string;
}> {
  if (!args.task_id) throw new Error('task_id is required');
  if (!args.body || args.body.trim().length === 0) throw new Error('body is required');
  if (!!args.file_url === !!args.storage_path) {
    throw new Error('exactly one of file_url or storage_path is required');
  }

  const t = await assertTaskBoardAndWorkspace(sb, args.task_id);
  assertWorkspaceWriteAllowed(t.workspaceId, sensitive, args.confirm_sensitive_workspace === true);
  // Group-grant check (mirrors the other Tars tools).
  const granted = await grantedGroupIdsForBoard(sb, t.boardId);
  const { data: itemRow, error: itemErr } = await sb
    .from('items').select('group_id').eq('id', t.taskId).maybeSingle();
  if (itemErr) throw new Error(`task lookup failed: ${itemErr.message}`);
  const groupId = (itemRow as { group_id?: string } | null)?.group_id;
  if (!groupId || !granted.includes(groupId)) {
    throw new Error(`task ${t.taskId} is not in a group granted to this connector`);
  }

  // Resolve the file — either upload from URL, or adopt an existing path.
  let storagePath: string;
  let fileName: string;
  let mime: string;
  let size: number;
  let uploadedHere = false;
  if (args.file_url) {
    const dl = await downloadPublicFile(args.file_url);
    fileName = safeFileName(args.file_name || basenameFromUrl(args.file_url));
    storagePath = buildItemStoragePath(t.boardId, t.taskId, fileName);
    const { error: upErr } = await sb.storage
      .from(FILES_BUCKET)
      .upload(storagePath, dl.bytes, { contentType: dl.mime, upsert: false });
    if (upErr) throw new Error(`storage upload failed: ${upErr.message}`);
    mime = dl.mime; size = dl.size; uploadedHere = true;
  } else {
    storagePath = args.storage_path!;
    if (!storagePath.startsWith(`boards/`)) {
      throw new Error(`storage_path must be inside boards/... (got: ${storagePath})`);
    }
    const stat = await statStorageObject(sb, storagePath);
    mime = stat.mime; size = stat.size;
    const slash = storagePath.lastIndexOf('/');
    fileName = safeFileName(
      args.file_name || (slash >= 0 ? storagePath.slice(slash + 1).replace(/^[0-9a-f-]{36}-/, '') : storagePath),
    );
  }

  const actor = await getAgentTarsActorId(sb);

  // Insert the update first (so we can link the file row to update_id).
  const baseHtml = args.is_html ? args.body : `<p>${escapeHtml(args.body)}</p>`;
  let signed: string;
  try { signed = await createSignedFileUrl(sb, storagePath); }
  catch (e) {
    if (uploadedHere) { try { await sb.storage.from(FILES_BUCKET).remove([storagePath]); } catch { /* */ } }
    throw e;
  }
  const linkHtml = `<p><a href="${escapeHtml(signed)}" target="_blank" rel="noopener noreferrer">📎 ${escapeHtml(fileName)}</a></p>`;
  const bodyHtml = `${baseHtml}${linkHtml}`;

  const { data: upd, error: updErr } = await sb
    .from('updates')
    .insert({ item_id: t.taskId, author_id: actor, body_html: bodyHtml, body_json: null } as never)
    .select('id').single();
  if (updErr) {
    if (uploadedHere) { try { await sb.storage.from(FILES_BUCKET).remove([storagePath]); } catch { /* */ } }
    await logMcpRun(sb, {
      toolName: 'add_task_update_with_file', status: 'error',
      workspaceId: t.workspaceId, boardId: t.boardId,
      prompt: args.body.slice(0, 200),
      responseSummary: `updates insert failed: ${updErr.message}`,
      errorMessage: updErr.message,
    });
    throw new Error(`updates insert failed: ${updErr.message}`);
  }
  const updateId = (upd as { id: string }).id;

  let fileId: string;
  try {
    fileId = await insertFileRow(sb, {
      actor, itemId: t.taskId, updateId,
      storagePath, fileName, fileSize: size, mimeType: mime,
    });
  } catch (e) {
    // Roll back update + (if we uploaded) the storage object.
    try { await sb.from('updates').delete().eq('id', updateId); } catch { /* */ }
    if (uploadedHere) { try { await sb.storage.from(FILES_BUCKET).remove([storagePath]); } catch { /* */ } }
    throw e;
  }

  await logMcpRun(sb, {
    toolName: 'add_task_update_with_file', status: 'success',
    workspaceId: t.workspaceId, boardId: t.boardId,
    prompt: args.body.slice(0, 200),
    responseSummary: `agent-mcp update=${updateId} file=${fileId} path=${storagePath} actor=${actor}`,
  });
  return {
    update_id: updateId, file_id: fileId, task_id: t.taskId,
    board_id: t.boardId, workspace_id: t.workspaceId,
    storage_path: storagePath, file_name: fileName,
    signed_url: signed, actor_id: actor,
  };
}

Deno.serve(vercel(handler));

