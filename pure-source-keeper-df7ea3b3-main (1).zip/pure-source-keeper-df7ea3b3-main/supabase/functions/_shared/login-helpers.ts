// Helpers shared by check-teamblue-login and check-login-devices.
export async function resolveLocation(
  ip: string | null,
  fetchImpl: typeof fetch = fetch,
): Promise<string | null> {
  if (!ip) return null;
  try {
    const resp = await fetchImpl(`https://ipapi.co/${encodeURIComponent(ip)}/json/`);
    if (!resp.ok) return null;
    const data = (await resp.json()) as { city?: string; country_name?: string; error?: boolean };
    if (!data || data.error) return null;
    const parts = [data.city, data.country_name].filter((s): s is string => !!s && s.trim() !== "");
    return parts.length ? parts.join(", ") : null;
  } catch {
    return null;
  }
}

export function formatManila(iso: string): string {
  try {
    const s = new Intl.DateTimeFormat("en-US", {
      timeZone: "Asia/Manila",
      dateStyle: "medium",
      timeStyle: "short",
    }).format(new Date(iso));
    return `${s} (PHT)`;
  } catch {
    return iso;
  }
}
