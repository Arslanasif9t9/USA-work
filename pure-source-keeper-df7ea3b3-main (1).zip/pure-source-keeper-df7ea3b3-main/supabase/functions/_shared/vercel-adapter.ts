// Vercel-style (req, res) handler adapter for Deno / Supabase Edge Functions.
// Lets us drop in the existing api/*.ts handlers with minimal edits.
import { corsHeaders } from "npm:@supabase/supabase-js@2/cors";

export interface VercelLikeRequest {
  method: string;
  url: string;
  headers: Record<string, string>;
  query: Record<string, string>;
  body: any;
  // node-style alias used by some handlers:
  rawBody?: string;
}

export interface VercelLikeResponse {
  setHeader(name: string, value: string | number | string[]): void;
  getHeader(name: string): string | undefined;
  status(code: number): VercelLikeResponse;
  json(body: unknown): VercelLikeResponse;
  send(body: unknown): VercelLikeResponse;
  end(body?: unknown): VercelLikeResponse;
  // headersSent / writableEnded flags used by some handlers:
  headersSent: boolean;
  writableEnded: boolean;
}

type Handler = (req: VercelLikeRequest, res: VercelLikeResponse) => Promise<unknown> | unknown;

export function vercel(handler: Handler) {
  return async (request: Request): Promise<Response> => {
    // CORS preflight — match what the original handlers expect.
    if (request.method === "OPTIONS") {
      return new Response("ok", { headers: corsHeaders });
    }

    const url = new URL(request.url);
    const headers: Record<string, string> = {};
    request.headers.forEach((v, k) => { headers[k.toLowerCase()] = v; });

    // Body parsing
    let body: any = undefined;
    let rawBody = "";
    if (request.method !== "GET" && request.method !== "HEAD") {
      try {
        rawBody = await request.text();
        const ct = (headers["content-type"] || "").toLowerCase();
        if (ct.includes("application/json") && rawBody.length) {
          try { body = JSON.parse(rawBody); } catch { body = rawBody; }
        } else if (ct.includes("application/x-www-form-urlencoded")) {
          body = Object.fromEntries(new URLSearchParams(rawBody));
        } else if (rawBody.length) {
          // try JSON anyway (some clients omit content-type)
          try { body = JSON.parse(rawBody); } catch { body = rawBody; }
        }
      } catch { /* ignore */ }
    }

    const query: Record<string, string> = {};
    url.searchParams.forEach((v, k) => { query[k] = v; });

    const req: VercelLikeRequest = {
      method: request.method,
      url: url.pathname + url.search,
      headers,
      query,
      body,
      rawBody,
    };

    // Build response object
    let statusCode = 200;
    const resHeaders = new Headers({ ...corsHeaders });
    let resBody: BodyInit | null = null;
    let resolved = false;
    let resolve!: (r: Response) => void;
    const responsePromise = new Promise<Response>((r) => { resolve = r; });

    const finish = () => {
      if (resolved) return;
      resolved = true;
      resolve(new Response(resBody, { status: statusCode, headers: resHeaders }));
    };

    const res: VercelLikeResponse = {
      headersSent: false,
      writableEnded: false,
      setHeader(name, value) {
        if (Array.isArray(value)) resHeaders.set(name, value.join(", "));
        else resHeaders.set(name, String(value));
      },
      getHeader(name) {
        return resHeaders.get(name) ?? undefined;
      },
      status(code) { statusCode = code; return res; },
      json(b) {
        if (!resHeaders.has("content-type")) resHeaders.set("content-type", "application/json");
        resBody = typeof b === "string" ? b : JSON.stringify(b);
        res.headersSent = true;
        res.writableEnded = true;
        finish();
        return res;
      },
      send(b) {
        if (b !== undefined && b !== null) {
          if (typeof b === "object") {
            if (!resHeaders.has("content-type")) resHeaders.set("content-type", "application/json");
            resBody = JSON.stringify(b);
          } else {
            resBody = String(b);
          }
        }
        res.headersSent = true;
        res.writableEnded = true;
        finish();
        return res;
      },
      end(b) {
        if (b !== undefined && b !== null) resBody = typeof b === "string" ? b : String(b);
        res.headersSent = true;
        res.writableEnded = true;
        finish();
        return res;
      },
    };

    try {
      const result = handler(req, res);
      if (result && typeof (result as any).then === "function") {
        await result;
      }
      // If handler returned without calling res.end/json — close it out
      if (!resolved) {
        if (resBody === null && statusCode === 200) statusCode = 204;
        finish();
      }
    } catch (err) {
      if (!resolved) {
        console.error("[vercel-adapter] handler threw:", err);
        statusCode = 500;
        resHeaders.set("content-type", "application/json");
        resBody = JSON.stringify({ error: (err as Error)?.message ?? "internal error" });
        finish();
      }
    }

    return responsePromise;
  };
}

export { corsHeaders };
