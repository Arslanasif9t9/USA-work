// supabase/functions/cleanup-old-files/index.ts
//
// CLEANUP-OLD-FILES — scheduled daily.
//
// Finds public.files rows where created_at < now() - RETENTION_DAYS and
// deleted_at IS NULL, then for each (capped at MAX_PER_RUN):
//   1) DELETE the storage object via the Storage REST API (service role).
//   2) Soft-delete the row: UPDATE public.files SET deleted_at = now()
//      WHERE id = $1  (single-row update by id — no other tables touched).
//
// The Files tab already filters on `deleted_at IS NULL`, so the UI
// requires no change.

import { createClient } from "npm:@supabase/supabase-js@2";
import { corsHeaders } from "npm:@supabase/supabase-js@2/cors";

const RETENTION_DAYS = 2;
const MAX_PER_RUN = 200;
const BUCKET = "task-files";

interface FileRow {
  id: string;
  storage_path: string;
  created_at: string;
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });

  const supabaseUrl = Deno.env.get("SUPABASE_URL") ?? Deno.env.get("VITE_SUPABASE_URL");
  const serviceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
  if (!supabaseUrl || !serviceKey) {
    return new Response(JSON.stringify({ ok: false, error: "supabase env not configured" }), {
      status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }

  const admin = createClient(supabaseUrl, serviceKey, {
    auth: { persistSession: false, autoRefreshToken: false },
  });

  const cutoffIso = new Date(Date.now() - RETENTION_DAYS * 86400 * 1000).toISOString();

  const { data: rows, error: selErr } = await admin
    .from("files")
    .select("id, storage_path, created_at")
    .is("deleted_at", null)
    .lt("created_at", cutoffIso)
    .order("created_at", { ascending: true })
    .limit(MAX_PER_RUN);

  if (selErr) {
    console.error("[cleanup-old-files] select failed:", selErr.message);
    return new Response(JSON.stringify({ ok: false, error: selErr.message }), {
      status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }

  const candidates = (rows ?? []) as FileRow[];
  let storageDeleted = 0;
  let rowsSoftDeleted = 0;
  const errors: Array<{ id: string; stage: "storage" | "row"; message: string }> = [];

  for (const f of candidates) {
    // 1) DELETE the storage object (service role bypasses storage RLS).
    try {
      const { error: rmErr } = await admin.storage.from(BUCKET).remove([f.storage_path]);
      if (rmErr) {
        // "Object not found" is fine — proceed to soft-delete the row.
        const msg = rmErr.message || String(rmErr);
        if (!/not found|does not exist/i.test(msg)) {
          errors.push({ id: f.id, stage: "storage", message: msg });
          continue; // do NOT soft-delete the row if storage delete failed for non-not-found reasons.
        }
      } else {
        storageDeleted += 1;
      }
    } catch (err) {
      errors.push({ id: f.id, stage: "storage", message: err instanceof Error ? err.message : String(err) });
      continue;
    }

    // 2) Soft-delete the row — single-row update by exact id.
    const { error: updErr } = await admin
      .from("files")
      .update({ deleted_at: new Date().toISOString() })
      .eq("id", f.id);
    if (updErr) {
      errors.push({ id: f.id, stage: "row", message: updErr.message });
      continue;
    }
    rowsSoftDeleted += 1;
  }

  const summary = {
    ok: true,
    retention_days: RETENTION_DAYS,
    cutoff: cutoffIso,
    candidates: candidates.length,
    storage_deleted: storageDeleted,
    rows_soft_deleted: rowsSoftDeleted,
    errors,
  };
  console.log("[cleanup-old-files] run summary:", JSON.stringify(summary));

  return new Response(JSON.stringify(summary), {
    status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" },
  });
});
