// developer-mcp — locked-down JSON-RPC MCP endpoint for the "developer_human" identity.
//
// Sibling of supabase/functions/mcp/index.ts and supabase/functions/agent-mcp/index.ts.
// Same JSON-RPC 2.0 transport, same status/update write shapes, BUT:
//   - No authentication — URL alone is the access control (deployed with
//     verify_jwt = false). The 4-tool allow-list below is the only gate.
//   - Resolves the actor as the public.users row WHERE id='998ae571-b2ba-4fcc-b01a-d4da6b9d307c'
//     (developer_human; NOT the admin service actor, NOT Agent Tars). So
//     updated_by / author_id on every row this endpoint writes is
//     developer_human's id; the board shows "developer_human" next to the
//     status change / update.
//   - Tool allow-list is HARD: exactly five tools are exposed AND accepted:
//        list_boards, get_board, update_task_status, add_task_update,
//        get_task_updates. Anything else returns -32601 "tool not permitted
//        for this endpoint" and performs no write.

import { vercel, type VercelLikeRequest, type VercelLikeResponse } from '../_shared/vercel-adapter.ts';
import { createClient, type SupabaseClient } from 'npm:@supabase/supabase-js@2';
import {
  parseSensitiveWorkspaceIds,
  assertWorkspaceWriteAllowed,
  assertTaskBoardAndWorkspace,
} from '../_shared/mcp-tenancy.ts';
import { logMcpRun } from '../_shared/mcp-logging.ts';

// ----- MCP protocol declaration ---------------------------------------
const MCP_PROTOCOL_VERSION = '2025-06-18';
const SERVER_NAME = 'pms-developer-mcp';
const SERVER_VERSION = '0.1.0';

// ----- Developer actor id (developer_human) ---------------------------
const DEVELOPER_ACTOR_ID = '0f455630-621d-4778-9c98-abd1a42dcedf';

// ----- Gating helpers: per-user group_user_visibility filters ---------
async function grantedGroupIdsForBoard(sb: SupabaseClient, boardId: string): Promise<string[]> {
  const { data, error } = await sb
    .from('group_user_visibility')
    .select('group_id, groups!inner(board_id)')
    .eq('user_id', '0f455630-621d-4778-9c98-abd1a42dcedf')
    .eq('groups.board_id', boardId);
  if (error) throw new Error(`group_user_visibility select failed: ${error.message}`);
  return ((data ?? []) as Array<{ group_id: string }>).map((r) => r.group_id);
}
async function grantedBoardIds(sb: SupabaseClient): Promise<string[]> {
  const { data, error } = await sb
    .from('group_user_visibility')
    .select('group_id, groups!inner(board_id)')
    .eq('user_id', '0f455630-621d-4778-9c98-abd1a42dcedf');
  if (error) throw new Error(`group_user_visibility select failed: ${error.message}`);
  const rows = (data ?? []) as Array<{ groups: { board_id: string } | null }>;
  return Array.from(new Set(rows.map((r) => r.groups?.board_id).filter((v): v is string => !!v)));
}

// ----- JSON-RPC primitives --------------------------------------------
type JsonRpcId = string | number | null;
interface JsonRpcRequest { jsonrpc: '2.0'; id?: JsonRpcId; method: string; params?: unknown; }
interface JsonRpcOk      { jsonrpc: '2.0'; id: JsonRpcId; result: unknown; }
interface JsonRpcErr     { jsonrpc: '2.0'; id: JsonRpcId; error: { code: number; message: string; data?: unknown }; }

const ERR_PARSE          = -32700;
const ERR_INVALID_REQ    = -32600;
const ERR_METHOD         = -32601;
const ERR_INVALID_PARAMS = -32602;
const ERR_INTERNAL       = -32603;
const ERR_AUTH           = -32001;
const ERR_TOOL_FAILED    = -32002;

function ok(id: JsonRpcId, result: unknown): JsonRpcOk {
  return { jsonrpc: '2.0', id, result };
}
function err(id: JsonRpcId, code: number, message: string, data?: unknown): JsonRpcErr {
  return { jsonrpc: '2.0', id, error: { code, message, ...(data !== undefined ? { data } : {}) } };
}

// ----- Tool catalogue (5 tools — HARD allow-list) ---------------
const TOOLS = {
  list_boards: {
    name: 'list_boards',
    description:
      'List every board visible to the developer_human MCP caller. Returns each board\'s id, ' +
      'name, icon_emoji, board_type (main|private), archived flag, workspace_id, and ' +
      'workspace_name. Use workspace_id as the multi-tenant boundary.',
    inputSchema: {
      type: 'object',
      properties: {
        include_archived: { type: 'boolean', description: 'If true, include archived boards.', default: false },
      },
      additionalProperties: false,
    },
  },
  get_board: {
    name: 'get_board',
    description:
      'Snapshot of a board — groups, columns (with labels), and every non-deleted task ' +
      'with its current cell values. Use this to find a task by name (capture its id) ' +
      'before calling update_task_status or add_task_update.',
    inputSchema: {
      type: 'object',
      properties: {
        board_id: { type: 'string', description: 'UUID of the board to snapshot.' },
      },
      required: ['board_id'],
      additionalProperties: false,
    },
  },
  update_task_status: {
    name: 'update_task_status',
    description:
      'Move a task into a status label by NAME. Only the board\'s first status column is ' +
      'targeted — this tool cannot touch any other column. Tenancy-checked; refuses ' +
      'sensitive-workspace writes without confirm_sensitive_workspace.',
    inputSchema: {
      type: 'object',
      properties: {
        task_id:      { type: 'string', description: 'UUID of the task.' },
        status_label: { type: 'string', description: 'Label name (e.g. "Done", "Working on it").' },
        confirm_sensitive_workspace: { type: 'boolean', default: false },
      },
      required: ['task_id', 'status_label'],
      additionalProperties: false,
    },
  },
  add_task_update: {
    name: 'add_task_update',
    description:
      'Post an update (conversation message) on a task. body is plain text by default; ' +
      'set is_html:true to pass caller-supplied markup. Authored as "developer_human".',
    inputSchema: {
      type: 'object',
      properties: {
        task_id: { type: 'string', description: 'UUID of the task.' },
        body:    { type: 'string', description: 'Update body.' },
        is_html: { type: 'boolean', default: false },
        confirm_sensitive_workspace: { type: 'boolean', default: false },
      },
      required: ['task_id', 'body'],
      additionalProperties: false,
    },
  },
  get_task_updates: {
    name: 'get_task_updates',
    description: 'Read the update/comment thread on a task. Returns all updates with author name, body, and timestamp. Read-only — does not write anything.',
    inputSchema: {
      type: 'object',
      properties: {
        task_id: { type: 'string', description: 'UUID of the task to read updates from.' },
      },
      required: ['task_id'],
      additionalProperties: false,
    },
  },
} as const;

const ALLOWED_TOOL_NAMES = new Set(Object.keys(TOOLS));

// =====================================================================
// HTTP handler
// =====================================================================
export default async function handler(req: VercelLikeRequest, res: VercelLikeResponse) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization, Mcp-Session-Id, MCP-Protocol-Version');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  if (req.method === 'OPTIONS') { res.status(200).end(); return; }

  {
    const pathOnly = (req.url || '').split('?')[0] || '';
    if (/\/\.well-known\//.test(pathOnly)) { res.status(404).json({}); return; }
  }

  if (req.method === 'GET') {
    res.status(200).json({ ok: true, transport: 'http', hint: 'POST JSON-RPC 2.0', server: SERVER_NAME });
    return;
  }
  if (req.method !== 'POST') {
    res.status(405).json(err(null, ERR_METHOD, 'Only POST is supported on this MCP endpoint'));
    return;
  }

  try {
    // ---- 1. Env / config checks --------------------------------------
    // No bearer required — auth is removed; the 4-tool allow-list is the
    // sole gate. Only Supabase service-role + URL are needed to write.
    const supabaseUrl =
      Deno.env.get('SUPABASE_URL') ?? Deno.env.get('VITE_SUPABASE_URL');
    const serviceRoleKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY');
    if (!supabaseUrl || !serviceRoleKey) {
      res.status(500).json(err(null, ERR_INTERNAL,
        'SUPABASE_URL / SUPABASE_SERVICE_ROLE_KEY not configured on server'));
      return;
    }

    // ---- 3. Parse JSON-RPC body --------------------------------------
    const message = parseRequestBody(req.body);
    if ('parseError' in message) {
      res.status(400).json(err(null, ERR_PARSE, message.parseError));
      return;
    }
    if (!isJsonRpcRequest(message.payload)) {
      res.status(400).json(err((message.payload as { id?: JsonRpcId })?.id ?? null,
        ERR_INVALID_REQ, 'Body is not a valid JSON-RPC 2.0 request'));
      return;
    }
    const rpc = message.payload;
    const isNotification = !('id' in rpc) || rpc.id === undefined;

    // ---- 3b. Auth gate removed --------------------------------------
    // This endpoint is intentionally unauthenticated. The hard 4-tool
    // allow-list below + developer_human actor attribution are the security
    // model; any other tool name is rejected with -32601 before any
    // write occurs.

    // ---- 4. Service-role client (RLS bypassed; tenancy enforced in code)
    const sb = createClient(supabaseUrl, serviceRoleKey, {
      auth: { persistSession: false, autoRefreshToken: false },
    });

    // ---- 5. Dispatch -------------------------------------------------
    const result = await dispatch(rpc, sb);
    if (isNotification) { res.status(202).end(); return; }
    res.status(200).json(result);
  } catch (e) {
    const message = e instanceof Error ? `${e.name}: ${e.message}` : String(e);
    console.error('[developer-mcp] handler threw:', e);
    res.status(500).json(err(null, ERR_INTERNAL, `internal: ${message}`));
  }
}

// =====================================================================
// Method dispatch
// =====================================================================
async function dispatch(rpc: JsonRpcRequest, sb: SupabaseClient): Promise<JsonRpcOk | JsonRpcErr> {
  const id = rpc.id ?? null;

  switch (rpc.method) {
    case 'initialize': {
      const params = (rpc.params ?? {}) as { protocolVersion?: string; clientInfo?: unknown };
      return ok(id, {
        protocolVersion: MCP_PROTOCOL_VERSION,
        serverInfo: { name: SERVER_NAME, version: SERVER_VERSION },
        capabilities: { tools: { listChanged: false } },
        instructions:
          'developer_human MCP endpoint. Only five tools are available: list_boards, get_board, ' +
          'update_task_status, add_task_update, get_task_updates. Discover boards/tasks with ' +
          'the read tools (including get_task_updates to read a task\'s comment thread), then ' +
          'call the two writes — every write is attributed to "developer_human" on the board.',
        clientInfo: params.clientInfo,
      });
    }
    case 'notifications/initialized':
    case 'initialized':
      return ok(id, {});

    case 'tools/list':
      return ok(id, { tools: Object.values(TOOLS) });

    case 'tools/call': {
      const params = rpc.params as { name?: string; arguments?: Record<string, unknown> } | undefined;
      const toolName = params?.name;
      const args = params?.arguments ?? {};
      if (!toolName) {
        return err(id, ERR_INVALID_PARAMS, 'tools/call requires params.name');
      }
      if (!ALLOWED_TOOL_NAMES.has(toolName)) {
        return err(id, ERR_METHOD, `tool not permitted for this endpoint: ${toolName}`);
      }
      const sensitiveWs = parseSensitiveWorkspaceIds();
      try {
        let payload: unknown;
        switch (toolName) {
          case 'list_boards':
            payload = await toolListBoards(sb, args as { include_archived?: boolean });
            break;
          case 'get_board':
            payload = await toolGetBoard(sb, args as { board_id?: string });
            break;
          case 'update_task_status':
            payload = await toolUpdateTaskStatus(sb, args as unknown as ToolUpdateTaskStatusArgs, sensitiveWs);
            break;
          case 'add_task_update':
            payload = await toolAddTaskUpdate(sb, args as unknown as ToolAddTaskUpdateArgs, sensitiveWs);
            break;
          case 'get_task_updates':
            payload = await toolGetTaskUpdates(sb, args as { task_id?: string });
            break;
          default:
            // Belt-and-braces — ALLOWED_TOOL_NAMES already filtered.
            return err(id, ERR_METHOD, `tool not permitted for this endpoint: ${toolName}`);
        }
        return ok(id, { content: [{ type: 'text', text: JSON.stringify(payload) }], structuredContent: payload });
      } catch (e) {
        const m = e instanceof Error ? e.message : String(e);
        return err(id, ERR_TOOL_FAILED, `tool ${toolName} failed: ${m}`);
      }
    }

    default:
      return err(id, ERR_METHOD, `method not supported: ${rpc.method}`);
  }
}

// =====================================================================
// Tool: list_boards   (behavior-identical to mcp/index.ts)
// =====================================================================
interface BoardListItem {
  id: string; name: string; icon_emoji: string; board_type: 'main' | 'private';
  workspace_id: string; workspace_name: string | null; archived: boolean; created_at: string;
}
async function toolListBoards(
  sb: SupabaseClient,
  args: { include_archived?: boolean },
): Promise<{ boards: BoardListItem[]; count: number; workspaces: { id: string; name: string }[] }> {
  const includeArchived = args.include_archived === true;
  const allowedBoardIds = await grantedBoardIds(sb);
  if (allowedBoardIds.length === 0) {
    return { boards: [], count: 0, workspaces: [] };
  }
  const { data: boards, error } = await sb
    .from('boards')
    .select('id, name, icon_emoji, board_type, workspace_id, archived_at, created_at')
    .in('id', allowedBoardIds)
    .is('deleted_at', null)
    .order('created_at', { ascending: false });
  if (error) throw new Error(`boards select failed: ${error.message}`);
  const rows = (boards ?? []) as Array<{
    id: string; name: string; icon_emoji: string; board_type: 'main' | 'private';
    workspace_id: string; archived_at: string | null; created_at: string;
  }>;
  const wsIds = Array.from(new Set(rows.map((b) => b.workspace_id)));
  const wsById = new Map<string, string>();
  if (wsIds.length > 0) {
    const { data: ws } = await sb.from('workspaces').select('id, name').in('id', wsIds);
    for (const w of (ws ?? []) as { id: string; name: string }[]) wsById.set(w.id, w.name);
  }
  const visible = rows
    .filter((b) => includeArchived || !b.archived_at)
    .map<BoardListItem>((b) => ({
      id: b.id, name: b.name, icon_emoji: b.icon_emoji, board_type: b.board_type,
      workspace_id: b.workspace_id, workspace_name: wsById.get(b.workspace_id) ?? null,
      archived: !!b.archived_at, created_at: b.created_at,
    }));
  return {
    boards: visible, count: visible.length,
    workspaces: Array.from(wsById, ([id, name]) => ({ id, name })),
  };
}

// =====================================================================
// Tool: get_board   (behavior-identical to mcp/index.ts)
// =====================================================================
interface BoardSnapshot {
  board: {
    id: string; name: string; workspace_id: string; workspace_name: string | null;
    board_type: 'main' | 'private'; icon_emoji: string; description: string | null;
  };
  groups: Array<{ id: string; name: string; color: string; sort_order: number }>;
  columns: Array<{
    id: string; name: string; column_type: string; sort_order: number;
    labels: Array<{ id: string; name: string; color: string; sort_order: number }>;
  }>;
  tasks: Array<{
    id: string; name: string; task_code: string; group_id: string;
    parent_item_id: string | null; sort_order: number; archived: boolean;
    cells: Record<string, unknown>;
  }>;
  task_count: number;
}
async function toolGetBoard(sb: SupabaseClient, args: { board_id?: string }): Promise<BoardSnapshot> {
  if (!args.board_id || typeof args.board_id !== 'string') {
    throw new Error('board_id (string) is required');
  }
  const boardId = args.board_id;
  const { data: board, error: bErr } = await sb
    .from('boards')
    .select('id, name, workspace_id, board_type, icon_emoji, description')
    .eq('id', boardId).is('deleted_at', null).maybeSingle();
  if (bErr) throw new Error(`board select failed: ${bErr.message}`);
  if (!board) throw new Error(`board not found: ${boardId}`);
  const { data: ws } = await sb.from('workspaces').select('name').eq('id', board.workspace_id).maybeSingle();
  const granted = await grantedGroupIdsForBoard(sb, boardId);
  const [
    { data: groups, error: gErr },
    { data: columns, error: cErr },
    { data: items, error: iErr },
  ] = granted.length === 0
    ? await Promise.all([
        Promise.resolve({ data: [] as Array<{ id: string; name: string; color: string; sort_order: number }>, error: null }),
        sb.from('columns').select('id, name, column_type, sort_order')
          .eq('board_id', boardId).is('archived_at', null).order('sort_order'),
        Promise.resolve({ data: [] as Array<{ id: string; name: string; task_code: string; group_id: string; parent_item_id: string | null; sort_order: number; archived_at: string | null }>, error: null }),
      ])
    : await Promise.all([
        sb.from('groups').select('id, name, color, sort_order')
          .eq('board_id', boardId).in('id', granted).is('deleted_at', null).order('sort_order'),
        sb.from('columns').select('id, name, column_type, sort_order')
          .eq('board_id', boardId).is('archived_at', null).order('sort_order'),
        sb.from('items').select('id, name, task_code, group_id, parent_item_id, sort_order, archived_at')
          .eq('board_id', boardId).in('group_id', granted).is('deleted_at', null).order('group_id').order('sort_order'),
      ]);
  if (gErr) throw new Error(`groups select failed: ${gErr.message}`);
  if (cErr) throw new Error(`columns select failed: ${cErr.message}`);
  if (iErr) throw new Error(`items select failed: ${iErr.message}`);

  const colIds  = (columns ?? []).map((c) => c.id);
  const itemIds = (items   ?? []).map((i) => (i as { id: string }).id);
  const labelsByCol = new Map<string, Array<{ id: string; name: string; color: string; sort_order: number }>>();
  const cellsByItem = new Map<string, Record<string, unknown>>();
  const [labelsRes, cellsRes] = await Promise.all([
    colIds.length === 0
      ? Promise.resolve({ data: [] as Array<{ id: string; column_id: string; name: string; color: string; sort_order: number }>, error: null })
      : sb.from('column_labels').select('id, column_id, name, color, sort_order').in('column_id', colIds).order('sort_order'),
    itemIds.length === 0
      ? Promise.resolve({ data: [] as Array<{ item_id: string; column_id: string; value: unknown }>, error: null })
      : sb.from('item_column_values').select('item_id, column_id, value').in('item_id', itemIds),
  ]);
  if (labelsRes.error) throw new Error(`labels select failed: ${labelsRes.error.message}`);
  if (cellsRes.error)  throw new Error(`item_column_values select failed: ${cellsRes.error.message}`);
  for (const l of (labelsRes.data ?? []) as Array<{ id: string; column_id: string; name: string; color: string; sort_order: number }>) {
    const arr = labelsByCol.get(l.column_id) ?? [];
    arr.push({ id: l.id, name: l.name, color: l.color, sort_order: l.sort_order });
    labelsByCol.set(l.column_id, arr);
  }
  for (const r of (cellsRes.data ?? []) as Array<{ item_id: string; column_id: string; value: unknown }>) {
    const map = cellsByItem.get(r.item_id) ?? {};
    map[r.column_id] = r.value;
    cellsByItem.set(r.item_id, map);
  }
  const tasksOut: BoardSnapshot['tasks'] = ((items ?? []) as Array<{
    id: string; name: string; task_code: string; group_id: string;
    parent_item_id: string | null; sort_order: number; archived_at: string | null;
  }>).map((it) => ({
    id: it.id, name: it.name, task_code: it.task_code, group_id: it.group_id,
    parent_item_id: it.parent_item_id, sort_order: it.sort_order,
    archived: !!it.archived_at, cells: cellsByItem.get(it.id) ?? {},
  }));
  return {
    board: {
      id: board.id, name: board.name, workspace_id: board.workspace_id,
      workspace_name: (ws as { name?: string } | null)?.name ?? null,
      board_type: board.board_type, icon_emoji: board.icon_emoji, description: board.description,
    },
    groups: (groups ?? []) as BoardSnapshot['groups'],
    columns: ((columns ?? []) as Array<{ id: string; name: string; column_type: string; sort_order: number }>)
      .map((c) => ({
        id: c.id, name: c.name, column_type: c.column_type, sort_order: c.sort_order,
        labels: labelsByCol.get(c.id) ?? [],
      })),
    tasks: tasksOut,
    task_count: tasksOut.length,
  };
}

// =====================================================================
// Tool: update_task_status — developer_human actor
// Copied byte-for-byte from agent-mcp/index.ts EXCEPT actor = getDeveloperActorId.
// Only ever touches the board's first status column (no other column).
// =====================================================================
interface ToolUpdateTaskStatusArgs {
  task_id: string;
  status_label: string;
  confirm_sensitive_workspace?: boolean;
}
async function toolUpdateTaskStatus(
  sb: SupabaseClient,
  args: ToolUpdateTaskStatusArgs,
  sensitive: Set<string>,
): Promise<{ task_id: string; board_id: string; workspace_id: string; label_id: string; actor_id: string }> {
  if (!args.task_id)      throw new Error('task_id is required');
  if (!args.status_label) throw new Error('status_label is required');

  const t = await assertTaskBoardAndWorkspace(sb, args.task_id);
  assertWorkspaceWriteAllowed(t.workspaceId, sensitive, args.confirm_sensitive_workspace === true);

  const { data: statusCols } = await sb
    .from('columns')
    .select('id')
    .eq('board_id', t.boardId)
    .eq('column_type', 'status')
    .is('archived_at', null)
    .order('sort_order')
    .limit(1);
  const statusColId = ((statusCols ?? [])[0] as { id?: string } | undefined)?.id;
  if (!statusColId) throw new Error(`no status column on board ${t.boardId}`);

  const { data: labels } = await sb
    .from('column_labels')
    .select('id, name')
    .eq('column_id', statusColId);
  const label = (labels ?? []).find((l) => (l as { name: string }).name === args.status_label) as { id: string } | undefined;
  if (!label) throw new Error(`status label "${args.status_label}" not found on this board`);

  const actor = await getDeveloperActorId(sb);
  const { error } = await sb
    .from('item_column_values')
    .upsert({
      item_id: t.taskId,
      column_id: statusColId,
      value: { label_id: label.id },
      updated_by: actor,
    } as never, { onConflict: 'item_id,column_id' });
  if (error) {
    await logMcpRun(sb, {
      toolName: 'update_task_status', status: 'error',
      workspaceId: t.workspaceId, boardId: t.boardId,
      prompt: args.status_label, responseSummary: 'upsert failed',
      errorMessage: error.message,
    });
    throw new Error(`status upsert failed: ${error.message}`);
  }
  await logMcpRun(sb, {
    toolName: 'update_task_status', status: 'success',
    workspaceId: t.workspaceId, boardId: t.boardId,
    prompt: args.status_label,
    responseSummary: `developer-mcp task=${t.taskId} → label=${label.id} actor=${actor}`,
  });
  return {
    task_id: t.taskId,
    board_id: t.boardId,
    workspace_id: t.workspaceId,
    label_id: label.id,
    actor_id: actor,
  };
}

// =====================================================================
// Tool: add_task_update — developer_human actor
// Copied byte-for-byte from agent-mcp/index.ts EXCEPT actor = getDeveloperActorId.
// =====================================================================
interface ToolAddTaskUpdateArgs {
  task_id: string;
  body: string;
  is_html?: boolean;
  confirm_sensitive_workspace?: boolean;
}
async function toolAddTaskUpdate(
  sb: SupabaseClient,
  args: ToolAddTaskUpdateArgs,
  sensitive: Set<string>,
): Promise<{ update_id: string; task_id: string; board_id: string; workspace_id: string; actor_id: string }> {
  if (!args.task_id) throw new Error('task_id is required');
  if (!args.body || args.body.trim().length === 0) throw new Error('body is required');

  const t = await assertTaskBoardAndWorkspace(sb, args.task_id);
  assertWorkspaceWriteAllowed(t.workspaceId, sensitive, args.confirm_sensitive_workspace === true);

  const bodyHtml = args.is_html
    ? args.body
    : `<p>${escapeHtml(args.body)}</p>`;

  const actor = await getDeveloperActorId(sb);
  const { data, error } = await sb
    .from('updates')
    .insert({
      item_id:   t.taskId,
      author_id: actor,
      body_html: bodyHtml,
      body_json: null,
    } as never)
    .select('id')
    .single();
  if (error) {
    await logMcpRun(sb, {
      toolName: 'add_task_update', status: 'error',
      workspaceId: t.workspaceId, boardId: t.boardId,
      prompt: args.body.slice(0, 200),
      responseSummary: `insert failed: ${error.message}`,
      errorMessage: error.message,
    });
    throw new Error(`updates insert failed: ${error.message}`);
  }
  const updateId = (data as { id: string }).id;
  await logMcpRun(sb, {
    toolName: 'add_task_update', status: 'success',
    workspaceId: t.workspaceId, boardId: t.boardId,
    prompt: args.body.slice(0, 200),
    responseSummary: `developer-mcp update_id=${updateId} actor=${actor}`,
  });
  return { update_id: updateId, task_id: t.taskId, board_id: t.boardId, workspace_id: t.workspaceId, actor_id: actor };
}

// =====================================================================
// Tool: get_task_updates — read-only, wall-checked
// =====================================================================
async function toolGetTaskUpdates(
  sb: SupabaseClient,
  args: { task_id?: string },
): Promise<{ task_id: string; updates: Array<{ id: string; author_name: string; body_html: string; created_at: string }> }> {
  if (!args.task_id || typeof args.task_id !== 'string') {
    throw new Error('task_id (string) is required');
  }
  const { data: task, error: tErr } = await sb
    .from('items')
    .select('id, group_id, board_id')
    .eq('id', args.task_id)
    .is('deleted_at', null)
    .maybeSingle();
  if (tErr) throw new Error(`task lookup failed: ${tErr.message}`);
  if (!task) throw new Error(`task not found: ${args.task_id}`);
  const granted = await grantedGroupIdsForBoard(sb, (task as { board_id: string }).board_id);
  if (!granted.includes((task as { group_id: string }).group_id)) {
    throw new Error(`task ${args.task_id} is not in a group granted to this connector`);
  }
  const { data: updates, error: uErr } = await sb
    .from('updates')
    .select('id, author_id, body_html, created_at')
    .eq('item_id', args.task_id)
    .order('created_at', { ascending: true });
  if (uErr) throw new Error(`updates select failed: ${uErr.message}`);
  const authorIds = Array.from(new Set((updates ?? []).map((u: any) => u.author_id).filter(Boolean)));
  const authorMap = new Map<string, string>();
  if (authorIds.length > 0) {
    const { data: authors } = await sb
      .from('users')
      .select('id, full_name')
      .in('id', authorIds);
    for (const a of (authors ?? []) as Array<{ id: string; full_name: string }>) {
      authorMap.set(a.id, a.full_name ?? 'Unknown');
    }
  }
  return {
    task_id: args.task_id,
    updates: ((updates ?? []) as Array<{ id: string; author_id: string; body_html: string; created_at: string }>).map((u) => ({
      id: u.id,
      author_name: authorMap.get(u.author_id) ?? 'Unknown',
      body_html: u.body_html,
      created_at: u.created_at,
    })),
  };
}


// =====================================================================
// Actor resolution — developer_human (NOT the admin service actor, NOT Agent Tars)
// Looked up by id='998ae571-b2ba-4fcc-b01a-d4da6b9d307c'; cached per-instance.
// =====================================================================
const DEVELOPER_ACTOR_CACHE: { id: string | null } = { id: null };
async function getDeveloperActorId(sb: SupabaseClient): Promise<string> {
  if (DEVELOPER_ACTOR_CACHE.id) return DEVELOPER_ACTOR_CACHE.id;
  const { data, error } = await sb
    .from('users')
    .select('id')
    .eq('id', DEVELOPER_ACTOR_ID)
    .limit(1)
    .maybeSingle();
  if (error) throw new Error(`could not resolve developer_human actor: ${error.message}`);
  const id = (data as { id?: string } | null)?.id;
  if (!id) throw new Error(`developer_human account (${DEVELOPER_ACTOR_ID}) not found`);
  DEVELOPER_ACTOR_CACHE.id = id;
  return id;
}

// =====================================================================
// Local helpers (copied from agent-mcp/index.ts so this function stands alone)
// =====================================================================
function escapeHtml(s: string): string {
  return s
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

type ParseOk = { payload: unknown };
type ParseFail = { parseError: string };
function parseRequestBody(body: unknown): ParseOk | ParseFail {
  if (body == null) return { parseError: 'request body is required' };
  if (typeof body === 'string') {
    if (body.trim().length === 0) return { parseError: 'request body is empty' };
    try { return { payload: JSON.parse(body) }; }
    catch (e) {
      return { parseError: `body is not valid JSON: ${e instanceof Error ? e.message : String(e)}` };
    }
  }
  if (typeof body === 'object') return { payload: body };
  return { parseError: `unexpected body type: ${typeof body}` };
}

function isJsonRpcRequest(x: unknown): x is JsonRpcRequest {
  if (!x || typeof x !== 'object') return false;
  const r = x as Record<string, unknown>;
  return r.jsonrpc === '2.0' && typeof r.method === 'string';
}


Deno.serve(vercel(handler));
