// Auto-ported from api/mcp.ts to Supabase Edge Function
import { vercel, type VercelLikeRequest, type VercelLikeResponse } from '../_shared/vercel-adapter.ts';

/**
 * POST /api/mcp
 *
 * Phase 3a: MCP (Model Context Protocol) server skeleton.
 *
 * Transport:        Streamable HTTP, STATELESS POST variant
 *                   (spec rev 2025-06-18; one JSON-RPC message per
 *                   request, response in the same body, no session
 *                   state retained between invocations).
 * Auth:             Authorization: Bearer <MCP_BEARER>   (shared
 *                   secret env var; ignore the request if absent or
 *                   wrong — server returns a JSON-RPC error, never a
 *                   crash).
 * Wire format:      JSON-RPC 2.0
 * Implemented:      initialize, notifications/initialized (ack only),
 *                   tools/list, tools/call.
 * Tools:            list_boards, get_board     (read-only for 3a).
 *
 * ⚠️ MULTI-TENANT WARNING — RLS IS BYPASSED ON THIS PATH.
 * This endpoint authenticates with the Supabase SERVICE_ROLE key
 * because the caller (Optimus) doesn't carry a user JWT. The service
 * role bypasses every RLS policy. **Isolation MUST be enforced in
 * code on every read AND write.**
 *
 *   - 3a read tools (list_boards / get_board) intentionally surface
 *     workspace_id on every row so the caller can verify tenancy at
 *     the application layer. Cross-tenant reads are by design — Optimus
 *     needs to see the whole workspace surface to choose where to
 *     write next. RLS_BYPASS-REVIEWED-3B in the read tool bodies marks
 *     each spot.
 *   - 3b write tools route EVERY mutation through the helpers in
 *     api/_shared/mcp-tenancy.ts (resolveWorkspaceForBoard,
 *     assertGroupInBoard, assertTaskBoardAndWorkspace,
 *     assertWorkspaceWriteAllowed). That file is the single auditable
 *     place where tenancy + sensitive-workspace policy is enforced.
 *
 * Conventions: matches api/ai-build.ts — NodeNext + .js extensions
 * for relative imports, top-level try/catch surfacing the real cause
 * in the response body so Vercel never returns FUNCTION_INVOCATION_FAILED.
 */
import { createClient, type SupabaseClient } from 'npm:@supabase/supabase-js@2';
import { runEngine, type EngineContext } from '../_shared/gemini-engine.ts';
import { Action as ActionSchema, type Action } from '../_shared/actions-schema.ts';
import { applyActions } from '../_shared/applier.ts';
import { toCanonicalHex, defaultLabelHexFor } from '../_shared/color-normalize.ts';
import {
  TenancyError,
  parseSensitiveWorkspaceIds,
  assertWorkspaceWriteAllowed,
  resolveWorkspaceForBoard,
  assertGroupInBoard,
  assertTaskBoardAndWorkspace,
} from '../_shared/mcp-tenancy.ts';
import { logMcpRun } from '../_shared/mcp-logging.ts';
import { z } from 'npm:zod';

// ----- MCP protocol version we declare to clients ----------------------
const MCP_PROTOCOL_VERSION = '2025-06-18';
const SERVER_NAME = 'pms-mcp';
const SERVER_VERSION = '0.1.0';

// ----- JSON-RPC primitives --------------------------------------------
type JsonRpcId = string | number | null;

interface JsonRpcRequest {
  jsonrpc: '2.0';
  id?: JsonRpcId;                 // omitted for notifications
  method: string;
  params?: unknown;
}

interface JsonRpcOk {
  jsonrpc: '2.0';
  id: JsonRpcId;
  result: unknown;
}

interface JsonRpcErr {
  jsonrpc: '2.0';
  id: JsonRpcId;
  error: { code: number; message: string; data?: unknown };
}

// Standard JSON-RPC codes + a couple of server-defined ones we use.
const ERR_PARSE          = -32700;
const ERR_INVALID_REQ    = -32600;
const ERR_METHOD         = -32601;
const ERR_INVALID_PARAMS = -32602;
const ERR_INTERNAL       = -32603;
const ERR_AUTH           = -32001;   // server-defined: bearer missing/wrong
const ERR_TOOL_FAILED    = -32002;   // server-defined: tool body threw

function ok(id: JsonRpcId, result: unknown): JsonRpcOk {
  return { jsonrpc: '2.0', id, result };
}
function err(id: JsonRpcId, code: number, message: string, data?: unknown): JsonRpcErr {
  return { jsonrpc: '2.0', id, error: { code, message, ...(data !== undefined ? { data } : {}) } };
}

// ----- Tool catalogue (schemas drive tools/list output) ----------------
const TOOLS = {
  list_boards: {
    name: 'list_boards',
    description:
      'List every board visible to the MCP caller. Returns each board\'s id, name, ' +
      'icon_emoji, board_type (main|private), archived flag, and the workspace it ' +
      'belongs to (workspace_id + workspace_name). Use the workspace_id to scope ' +
      'subsequent calls — RLS is bypassed on this endpoint so the workspace_id IS ' +
      'the multi-tenant boundary.',
    inputSchema: {
      type: 'object',
      properties: {
        include_archived: {
          type: 'boolean',
          description: 'If true, include archived boards. Defaults to false.',
          default: false,
        },
      },
      additionalProperties: false,
    },
  },
  get_board: {
    name: 'get_board',
    description:
      'Snapshot of a board — groups + columns (with labels) + EVERY non-deleted task ' +
      'on the board with its current cell values. Use this as the discovery step for ' +
      'any per-task write:\n' +
      '  1. list_boards → pick board_id\n' +
      '  2. get_board    → find a task by name in the tasks[] array; capture its id\n' +
      '  3. update_task_cell / add_task_update / update_task_name / update_task_status / ' +
      'delete_task with that task_id\n' +
      'Task cells are keyed by column_id (NOT column name) so the round-trip into ' +
      'update_task_cell is unambiguous; use the columns[] array to map column_id → ' +
      'column_name. Archived items are included with archived:true; soft-deleted items ' +
      'are excluded. Returns workspace_id so the caller can verify tenancy before any ' +
      'follow-up write.\n' +
      '\n' +
      '⚠️ Before adding a new column, scan columns[] for an existing one with the same ' +
      'name. If a Status / Priority / dropdown column already exists and you just need ' +
      'a new chip option, call add_column_label (NOT create_column — that makes a ' +
      'duplicate column).',
    inputSchema: {
      type: 'object',
      properties: {
        board_id: {
          type: 'string',
          description: 'UUID of the board to snapshot.',
        },
      },
      required: ['board_id'],
      additionalProperties: false,
    },
  },

  // ----- 3b: write tools ------------------------------------------------
  create_task: {
    name: 'create_task',
    description:
      'Create one task in a specific group of a specific board. The caller passes ' +
      'board_id + group_id together; the server verifies the group belongs to that ' +
      'board (cross-board writes are refused). Optional cells map column-name (NOT ' +
      'column-id) to a value object — e.g. {"Status": {"value": "Working on it"}}. ' +
      'For chip columns use {"label_ref": "<existing-label-name>"}. Writes to a ' +
      'sensitive workspace require confirm_sensitive_workspace: true.',
    inputSchema: {
      type: 'object',
      properties: {
        board_id: { type: 'string', description: 'UUID of the board.' },
        group_id: { type: 'string', description: 'UUID of the group. Must belong to board_id.' },
        name:     { type: 'string', description: 'Task name.', minLength: 1, maxLength: 200 },
        cells:    {
          type: 'object',
          description: 'Optional initial cells, keyed by column name. Each value is ' +
            'a CellValue object — { value: ... } | { label_ref: "<name>" } | ' +
            '{ label_refs: [...] } | { checked: bool } | { url: ..., label: ... }.',
          additionalProperties: true,
        },
        confirm_sensitive_workspace: {
          type: 'boolean',
          description: 'Required only if the target workspace is on SENSITIVE_WORKSPACE_IDS. ' +
            'Pass true to consent.',
          default: false,
        },
      },
      required: ['board_id', 'group_id', 'name'],
      additionalProperties: false,
    },
  },

  bulk_create_tasks: {
    name: 'bulk_create_tasks',
    description:
      'Create many tasks in one call. Each task is attempted independently — the ' +
      'response carries a per-task report ({ index, ok, task_id?, error? }) so a ' +
      'partial failure never lies about success. The top-level board_id+group_id ' +
      'are defaults; an individual task may override group_id to write into a ' +
      'different group on the SAME board (cross-board overrides are refused per task ' +
      'by the tenancy helper, surfaced as that task\'s error without aborting the ' +
      'batch). Sensitive-workspace check runs once for the parent board.',
    inputSchema: {
      type: 'object',
      properties: {
        board_id: { type: 'string' },
        group_id: { type: 'string' },
        tasks: {
          type: 'array',
          minItems: 1,
          maxItems: 200,
          items: {
            type: 'object',
            properties: {
              name:     { type: 'string', minLength: 1, maxLength: 200 },
              group_id: { type: 'string', description: 'Optional per-task override; falls back to the top-level group_id.' },
              cells:    { type: 'object', additionalProperties: true },
            },
            required: ['name'],
            additionalProperties: false,
          },
        },
        confirm_sensitive_workspace: { type: 'boolean', default: false },
      },
      required: ['board_id', 'group_id', 'tasks'],
      additionalProperties: false,
    },
  },

  create_board: {
    name: 'create_board',
    description:
      'Create a new board in an EXPLICIT workspace. workspace_id is REQUIRED — never ' +
      'defaulted, never guessed. The board\'s task_name column + a default Status column ' +
      'are auto-seeded by the DB trigger (matches the human "create board" flow). ' +
      'Writes to a sensitive workspace require confirm_sensitive_workspace: true.',
    inputSchema: {
      type: 'object',
      properties: {
        workspace_id: { type: 'string', description: 'UUID of the workspace.' },
        name:         { type: 'string', description: 'Board name.', minLength: 1, maxLength: 80 },
        icon_emoji:   { type: 'string', description: 'Optional emoji, defaults to 📋.' },
        board_type:   { type: 'string', enum: ['main', 'private'], default: 'main' },
        description:  { type: 'string', maxLength: 2000 },
        confirm_sensitive_workspace: { type: 'boolean', default: false },
      },
      required: ['workspace_id', 'name'],
      additionalProperties: false,
    },
  },

  design_board_from_spec: {
    name: 'design_board_from_spec',
    description:
      'Create a new board in workspace_id and populate it from a spec — either a ' +
      'natural-language prompt (the SAME Gemini engine + Zod actions schema the ' +
      '"Build with AI" button uses) OR a pre-built actions array (skip the LLM). ' +
      'Identical results to the button when called with the same prompt. Logs to ' +
      'ai_runs with feature="design_board_from_spec". Sensitive-workspace gated.',
    inputSchema: {
      type: 'object',
      properties: {
        workspace_id: { type: 'string', description: 'UUID of the workspace.' },
        board_name:   { type: 'string', description: 'Name for the new board.', minLength: 1, maxLength: 80 },
        icon_emoji:   { type: 'string' },
        prompt:       { type: 'string', description: 'Natural-language spec. Mutually exclusive with actions.' },
        actions:      {
          type: 'array',
          description: 'Pre-built actions array (matches api/_shared/actions-schema.ts). ' +
            'Mutually exclusive with prompt.',
        },
        model: { type: 'string', enum: ['gemini-2.5-flash', 'gemini-2.5-pro'], default: 'gemini-2.5-flash' },
        confirm_sensitive_workspace: { type: 'boolean', default: false },
      },
      required: ['workspace_id', 'board_name'],
      additionalProperties: false,
    },
  },

  update_task_status: {
    name: 'update_task_status',
    description:
      'Set the Status of a task to a specific label by name. Resolves task → board → ' +
      'workspace before writing; refuses if the workspace is sensitive without ' +
      'confirm_sensitive_workspace. The status column is the first status-type column ' +
      'on the task\'s board (matches the applier\'s convention). For OTHER column ' +
      'types use update_task_cell.',
    inputSchema: {
      type: 'object',
      properties: {
        task_id:      { type: 'string', description: 'UUID of the task.' },
        status_label: { type: 'string', description: 'Name of an existing status label on the task\'s board.' },
        confirm_sensitive_workspace: { type: 'boolean', default: false },
      },
      required: ['task_id', 'status_label'],
      additionalProperties: false,
    },
  },

  move_task_to_group: {
    name: 'move_task_to_group',
    description:
      'Move an existing task into a different group on the SAME board, by updating items.group_id. ' +
      'Resolves task → board → workspace, verifies the destination group belongs to the same board, ' +
      'refuses cross-board moves and sensitive-workspace writes without confirm_sensitive_workspace. ' +
      'Keeps the task, its id, task_code, cells, and updates intact — only its group membership changes.',
    inputSchema: {
      type: 'object',
      properties: {
        task_id:  { type: 'string', description: 'UUID of the task to move.' },
        group_id: { type: 'string', description: 'UUID of the destination group on the same board.' },
        confirm_sensitive_workspace: { type: 'boolean', default: false },
      },
      required: ['task_id', 'group_id'],
      additionalProperties: false,
    },
  },

  // =================================================================
  // 3d chunk 1 — non-destructive expansions
  // =================================================================
  add_task_update: {
    name: 'add_task_update',
    description:
      'Post an update/comment on a task — appears in the task panel\'s Updates feed. ' +
      'Input: task_id + body (plain text OR an HTML fragment). To get the task_id from ' +
      'a task name, call get_board first and look in tasks[]. Resolves task → board → ' +
      'workspace, refuses cross-tenant + sensitive-workspace writes. Use this for ' +
      'comments / status notes on EXISTING tasks; for STRUCTURED data like an ' +
      '"Instructions" field, use create_column + update_task_cell instead.',
    inputSchema: {
      type: 'object',
      properties: {
        task_id: { type: 'string', description: 'UUID of the task.' },
        body:    { type: 'string', minLength: 1, maxLength: 20000,
                   description: 'Update body. Plain text is wrapped in <p>; HTML is stored as-is.' },
        is_html: { type: 'boolean', default: false,
                   description: 'If true, body is treated as HTML; otherwise wrapped in <p>…</p>.' },
        confirm_sensitive_workspace: { type: 'boolean', default: false },
      },
      required: ['task_id', 'body'],
      additionalProperties: false,
    },
  },

  update_task_cell: {
    name: 'update_task_cell',
    description:
      'Set ANY cell value on a task — generalizes update_task_status to every column ' +
      'type. To get task_id + column_id from human names, call get_board first: every ' +
      'task is in tasks[] with its id+name; every column is in columns[] with its ' +
      'id+name+column_type. Pass the column by id (column_id) OR by name (column_name); ' +
      'if both are given, column_id wins.\n' +
      '\n' +
      'The "value" field accepts ANY natural shape — pass a primitive or an object, ' +
      'whichever is simpler. Examples by column type (any of the rows below works):\n' +
      '\n' +
      '  text/long_text → "Run the checkout flow…"   OR   { "value": "…" }   OR { "text": "…" }\n' +
      '  numbers        → 42                          OR   { "value": 42 }    OR { "num": 42 }\n' +
      '  date           → "2026-05-30"                OR   { "value": "2026-05-30" }   OR { "date": "…" }\n' +
      '  checkbox       → true / false                OR   { "checked": true }\n' +
      '  link           → "https://example.com"       OR   { "url": "…", "label"?: "…" }\n' +
      '  status         → "Done"                      OR   { "label_name": "Done" }   OR { "label_id": "<uuid>" }\n' +
      '  priority       → same as status\n' +
      '  dropdown       → ["EU", "US"]                OR   { "label_names": ["EU", "US"] }   OR { "label_ids": [...] }\n' +
      '  people         → ["<uuid>", …]               OR   { "user_ids": ["<uuid>", …] }\n' +
      '\n' +
      'Tenancy-checked + sensitive-workspace-gated.',
    inputSchema: {
      type: 'object',
      properties: {
        task_id:     { type: 'string' },
        column_id:   { type: 'string', description: 'UUID of the column. Mutually exclusive with column_name (id wins).' },
        column_name: { type: 'string', description: 'Display name of the column on the task\'s board.' },
        value:       { description: 'Shape varies by column type — see tool description.' },
        confirm_sensitive_workspace: { type: 'boolean', default: false },
      },
      required: ['task_id', 'value'],
      additionalProperties: false,
    },
  },

  update_task_name: {
    name: 'update_task_name',
    description:
      'Rename a task. Resolves task → board → workspace; sensitive-workspace gated.',
    inputSchema: {
      type: 'object',
      properties: {
        task_id:  { type: 'string' },
        new_name: { type: 'string', minLength: 1, maxLength: 500 },
        confirm_sensitive_workspace: { type: 'boolean', default: false },
      },
      required: ['task_id', 'new_name'],
      additionalProperties: false,
    },
  },

  // ----- 3d follow-up #2 — column management -----------------------
  add_column_label: {
    name: 'add_column_label',
    description:
      'Add one or more labels to an EXISTING status/priority/dropdown column. ' +
      'Use this when you need a new chip option on a column that already exists — ' +
      'do NOT call create_column for this (that makes a whole new column). To find ' +
      'the column, call get_board first and look in columns[] for the column by ' +
      'name; capture its id and type. Refuses if the column is not a status/' +
      'priority/dropdown. New labels append at the end (sort_order = max+1).\n' +
      '\n' +
      'Color is OPTIONAL — when omitted, a smart palette default is chosen by ' +
      'label name + column type (so a new "Done" status seeds mint, a new "Stuck" ' +
      'seeds teal, etc.). When provided, the value is normalised to canonical ' +
      '#RRGGBB hex; accepts #RRGGBB, #RGB, oklch(L C H), var(--chip-X), or a ' +
      'token / CSS color name (mint / amber / red / sky / …). To RECOLOR an ' +
      'existing label use update_column_label, not this.\n' +
      'Tenancy + sensitive-workspace gated.',
    inputSchema: {
      type: 'object',
      properties: {
        column_id:   { type: 'string', description: 'UUID of the column. Mutually exclusive with column_name + board_id.' },
        board_id:    { type: 'string', description: 'Required only if you pass column_name instead of column_id.' },
        column_name: { type: 'string', description: 'Display name. Requires board_id.' },
        labels: {
          type: 'array',
          minItems: 1,
          items: {
            type: 'object',
            properties: {
              name:  { type: 'string', minLength: 1, maxLength: 80 },
              color: { type: 'string', description: 'Optional #RRGGBB hex or oklch(); defaults to #C4C4C4.' },
            },
            required: ['name'],
            additionalProperties: false,
          },
        },
        confirm_sensitive_workspace: { type: 'boolean', default: false },
      },
      required: ['labels'],
      additionalProperties: false,
    },
  },

  update_column_label: {
    name: 'update_column_label',
    description:
      'Rename and/or recolor an EXISTING column_labels row. Use this when the agent ' +
      'or a user wants to change a label\'s name or color without creating a duplicate ' +
      'label. Resolves by label_id (preferred), or by (board_id + column_name + ' +
      'current_label_name). At least one of new_name / color must be supplied. Color ' +
      'is normalised to canonical #RRGGBB hex — accepts hex, oklch(...), var(--chip-*), ' +
      'bare token names ("mint", "amber", "red", …), and common CSS color names.\n' +
      'Tenancy + sensitive-workspace gated.',
    inputSchema: {
      type: 'object',
      properties: {
        label_id:           { type: 'string', description: 'UUID of the label row.' },
        board_id:           { type: 'string', description: 'Required only if you use column_name + current_label_name.' },
        column_name:        { type: 'string' },
        current_label_name: { type: 'string', description: 'Current name to find the row by.' },
        new_name:           { type: 'string', minLength: 1, maxLength: 80 },
        color:              { type: 'string', description: 'Any of: #RRGGBB, #RGB, oklch(L C H), var(--chip-X), or a token name.' },
        confirm_sensitive_workspace: { type: 'boolean', default: false },
      },
      additionalProperties: false,
    },
  },

  delete_column: {
    name: 'delete_column',
    description:
      'SOFT-delete a column (sets columns.archived_at — column rows are recoverable). ' +
      'Refuses without confirm_delete: true. Refuses on task_name columns regardless ' +
      'of confirm_delete (the task_name column is required per-board and the DB-side ' +
      'guard_task_name_column trigger would block it anyway — this surface refuses ' +
      'earlier with a clear message). Tenancy + sensitive-workspace gated.',
    inputSchema: {
      type: 'object',
      properties: {
        column_id:      { type: 'string' },
        confirm_delete: { type: 'boolean', default: false,
                          description: 'Required — set to true to acknowledge soft-deletion.' },
        confirm_sensitive_workspace: { type: 'boolean', default: false },
      },
      required: ['column_id'],
      additionalProperties: false,
    },
  },

  rename_column: {
    name: 'rename_column',
    description: 'Rename an existing column. Tenancy + sensitive-workspace gated.',
    inputSchema: {
      type: 'object',
      properties: {
        column_id: { type: 'string' },
        new_name:  { type: 'string', minLength: 1, maxLength: 80 },
        confirm_sensitive_workspace: { type: 'boolean', default: false },
      },
      required: ['column_id', 'new_name'],
      additionalProperties: false,
    },
  },

  // ----- 3d chunk 6 — create_workspace -----------------------------
  create_workspace: {
    name: 'create_workspace',
    description:
      'Create a new workspace (a tenant boundary). Use this when onboarding a new ' +
      'company/team. is_main is ALWAYS false here — only one main workspace exists ' +
      'and it\'s the single seeded one. Returns workspace_id; pass that to ' +
      'create_board / design_board_from_spec to populate it. Workspaces have no ' +
      'soft-delete; this phase does not expose delete_workspace.',
    inputSchema: {
      type: 'object',
      properties: {
        name:       { type: 'string', minLength: 1, maxLength: 120 },
        icon_emoji: { type: 'string', description: 'Optional, defaults to 🏠.' },
        icon_color: { type: 'string', description: 'Optional #hex or oklch(); defaults to brand blue.' },
      },
      required: ['name'],
      additionalProperties: false,
    },
  },

  // ----- 3d chunk 5 — board ops ------------------------------------
  rename_board: {
    name: 'rename_board',
    description: 'Rename a board. Tenancy + sensitive-workspace gated.',
    inputSchema: {
      type: 'object',
      properties: {
        board_id: { type: 'string' },
        new_name: { type: 'string', minLength: 1, maxLength: 200 },
        confirm_sensitive_workspace: { type: 'boolean', default: false },
      },
      required: ['board_id', 'new_name'],
      additionalProperties: false,
    },
  },

  archive_board: {
    name: 'archive_board',
    description:
      'Archive (or un-archive) a board. Sets boards.archived_at to now (or null when ' +
      'restore=true). Non-destructive — the row stays, just hides from default sidebar ' +
      'lists. Tenancy + sensitive-workspace gated.',
    inputSchema: {
      type: 'object',
      properties: {
        board_id: { type: 'string' },
        restore:  { type: 'boolean', default: false,
                    description: 'If true, set archived_at = null (unarchive).' },
        confirm_sensitive_workspace: { type: 'boolean', default: false },
      },
      required: ['board_id'],
      additionalProperties: false,
    },
  },

  delete_board: {
    name: 'delete_board',
    description:
      'SOFT-delete a board (sets boards.deleted_at). The most destructive tool on ' +
      'this server — refuses without confirm_delete: true. Tenancy + sensitive-' +
      'workspace gated. Soft-delete does NOT fire the DB cascade trigger; child rows ' +
      '(groups, columns, items) keep their data and become recoverable by clearing ' +
      'deleted_at later.',
    inputSchema: {
      type: 'object',
      properties: {
        board_id:       { type: 'string' },
        confirm_delete: { type: 'boolean', default: false,
                          description: 'Required — set to true to acknowledge soft-deletion.' },
        confirm_sensitive_workspace: { type: 'boolean', default: false },
      },
      required: ['board_id'],
      additionalProperties: false,
    },
  },

  // ----- 3d chunk 4 — delete_task (soft) ---------------------------
  delete_task: {
    name: 'delete_task',
    description:
      'SOFT-delete a task (sets items.deleted_at). Refuses without confirm_delete: ' +
      'true. Cell values, updates/comments, and subitems stay in the DB — only the ' +
      'task row itself is marked deleted. Tenancy + sensitive-workspace gated.',
    inputSchema: {
      type: 'object',
      properties: {
        task_id:        { type: 'string' },
        confirm_delete: { type: 'boolean', default: false,
                          description: 'Required — set to true to acknowledge soft-deletion.' },
        confirm_sensitive_workspace: { type: 'boolean', default: false },
      },
      required: ['task_id'],
      additionalProperties: false,
    },
  },

  // ----- 3d chunk 3 — group ops ------------------------------------
  create_group: {
    name: 'create_group',
    description:
      'Add a new group to an existing board. Group color defaults to a soft sky ' +
      'tone; pass color (#hex or oklch()) to override. Tenancy + sensitive-' +
      'workspace gated.',
    inputSchema: {
      type: 'object',
      properties: {
        board_id: { type: 'string' },
        name:     { type: 'string', minLength: 1, maxLength: 120 },
        color:    { type: 'string', description: '#RRGGBB hex or oklch(...) — optional.' },
        confirm_sensitive_workspace: { type: 'boolean', default: false },
      },
      required: ['board_id', 'name'],
      additionalProperties: false,
    },
  },

  rename_group: {
    name: 'rename_group',
    description: 'Rename a group. Tenancy-checked (group must belong to a non-deleted board).',
    inputSchema: {
      type: 'object',
      properties: {
        group_id: { type: 'string' },
        new_name: { type: 'string', minLength: 1, maxLength: 120 },
        confirm_sensitive_workspace: { type: 'boolean', default: false },
      },
      required: ['group_id', 'new_name'],
      additionalProperties: false,
    },
  },

  delete_group: {
    name: 'delete_group',
    description:
      'SOFT-delete a group (sets groups.deleted_at). REFUSES without confirm_delete: ' +
      'true. ALSO refuses if the group still has non-deleted tasks UNLESS ' +
      'confirm_delete_with_tasks: true is ALSO passed (so a chatty Optimus can\'t ' +
      'wipe a populated group by accident). Tenancy + sensitive-workspace gated.',
    inputSchema: {
      type: 'object',
      properties: {
        group_id: { type: 'string' },
        confirm_delete:            { type: 'boolean', default: false,
                                     description: 'Required — set to true to acknowledge soft-deletion.' },
        confirm_delete_with_tasks: { type: 'boolean', default: false,
                                     description: 'Required IF the group still has non-deleted tasks.' },
        confirm_sensitive_workspace: { type: 'boolean', default: false },
      },
      required: ['group_id'],
      additionalProperties: false,
    },
  },

  // ----- 3d chunk 2 — column ops -----------------------------------
  create_column: {
    name: 'create_column',
    description:
      'Create a NEW column on a board. Always makes a fresh column. ' +
      '⚠️ DO NOT use this to add a label to a column that already exists — that\'s ' +
      'add_column_label. Calling create_column with the same name as an existing ' +
      'column produces a DUPLICATE column, not an updated one.\n' +
      '\n' +
      'Use this to add a brand-new "Instructions" / "Notes" text column, a "Due date" ' +
      'date column, a brand-new custom status column, etc. For comments / discussion ' +
      'ON a task, use add_task_update instead.\n' +
      '\n' +
      'column_type accepts the 10 user-creatable types (task_name is auto-seeded ' +
      'per-board and refused here):\n' +
      '  text | long_text | numbers | number | date | checkbox | link |\n' +
      '  status | priority | dropdown | people\n' +
      'long_text → text and number → numbers are aliased silently (canonical type ' +
      'returned in the response). Labels apply to status/priority/dropdown and are ' +
      'seeded as column_labels rows. Tenancy + sensitive-workspace gated.',
    inputSchema: {
      type: 'object',
      properties: {
        board_id:    { type: 'string' },
        name:        { type: 'string', minLength: 1, maxLength: 80 },
        column_type: {
          type: 'string',
          enum: ['text', 'long_text', 'numbers', 'number', 'date', 'checkbox',
                 'link', 'status', 'priority', 'dropdown', 'people'],
        },
        labels: {
          type: 'array',
          description: 'Only consumed for status/priority/dropdown. Other types ignore it.',
          items: {
            type: 'object',
            properties: {
              name:  { type: 'string', minLength: 1, maxLength: 80 },
              color: { type: 'string', description: 'Optional. Hex like "#FF3D8B" or oklch(...); defaults to #C4C4C4.' },
            },
            required: ['name'],
            additionalProperties: false,
          },
        },
        confirm_sensitive_workspace: { type: 'boolean', default: false },
      },
      required: ['board_id', 'name', 'column_type'],
      additionalProperties: false,
    },
  },
} as const;

// ----- Vercel handler --------------------------------------------------
export default async function handler(req: VercelLikeRequest, res: VercelLikeResponse) {
  // CORS preamble — mirrors api/ai-build.ts so the inspector / curl /
  // a browser-side MCP client all work in dev.
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization, Mcp-Session-Id, MCP-Protocol-Version');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  if (req.method === 'OPTIONS') { res.status(200).end(); return; }

  // ---- OAuth discovery probes from Claude.ai ------------------------
  // Claude's custom-connector flow probes /.well-known/oauth-authorization-server
  // and /.well-known/oauth-protected-resource (sometimes relative to the
  // mcp path). Respond with a clean 404 + empty JSON so Claude knows
  // there's no OAuth here and falls back to tokenless / query-token auth.
  {
    const pathOnly = (req.url || '').split('?')[0] || '';
    if (/\/\.well-known\//.test(pathOnly)) {
      res.status(404).json({});
      return;
    }
  }

  // ---- GET probe → small JSON ping (some clients GET before POST) ---
  if (req.method === 'GET') {
    res.status(200).json({ ok: true, transport: 'http', hint: 'POST JSON-RPC 2.0' });
    return;
  }

  if (req.method !== 'POST') {
    res.status(405).json(err(null, ERR_METHOD, 'Only POST is supported on this MCP endpoint'));
    return;
  }

  try {
    // ---- 1. Env / config checks --------------------------------------
    const bearer = Deno.env.get('MCP_BEARER');
    if (!bearer) {
      res.status(500).json(err(null, ERR_INTERNAL, 'MCP_BEARER not configured on server'));
      return;
    }
    const supabaseUrl =
      Deno.env.get('SUPABASE_URL') ?? Deno.env.get('VITE_SUPABASE_URL');
    const serviceRoleKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY');
    if (!supabaseUrl || !serviceRoleKey) {
      res.status(500).json(err(null, ERR_INTERNAL,
        'SUPABASE_URL / SUPABASE_SERVICE_ROLE_KEY not configured on server'));
      return;
    }

    // ---- 2. Bearer-token auth (DEFERRED until after we know the method)
    // Claude.ai's custom-connector handshake sends `initialize`,
    // `notifications/initialized`, and `tools/list` BEFORE auth is
    // established. Those three methods reveal only tool names/schemas
    // and must succeed tokenless so registration completes. Every
    // `tools/call` (actual tool execution) still requires the bearer.
    // The token MAY arrive via either path:
    //   (1) Authorization: Bearer <MCP_BEARER>  — preferred. Used by
    //       curl, the smoke scripts, mcp-inspector, and any client that
    //       lets you set custom headers.
    //   (2) ?token=<MCP_BEARER> query parameter — fallback added in 3c
    //       prep for claude.ai's "Add custom connector" UI, which does
    //       NOT expose a custom-header field. Either path satisfies the
    //       check; the header wins when both are present.
    //
    //   Security note: query-param secrets can leak into access logs,
    //   referer headers, and browser history. We accept that tradeoff
    //   because (a) MCP_BEARER is a long random secret, (b) it is
    //   rotatable via Vercel env in seconds, and (c) the only way
    //   claude.ai's connector UI can auth today is via the URL. To
    //   minimise the leak surface we deliberately do NOT log req.url
    //   anywhere in this handler — only the JSON-RPC method name when
    //   diagnosing the catch-all 500. If you add logging below, do NOT
    //   include req.url.
    const authHeader  = req.headers.authorization ?? '';
    const headerToken = authHeader.startsWith('Bearer ')
      ? authHeader.slice(7).trim()
      : '';
    const queryTokenRaw = req.query?.token;
    const queryToken = typeof queryTokenRaw === 'string' ? queryTokenRaw.trim() : '';
    const sessionIdToken = (req.headers['mcp-session-id'] ?? '').trim();
    const presented  = headerToken || queryToken || sessionIdToken;
    const hasValidBearer = !!presented && constantTimeEquals(presented, bearer);

    // ---- 3. Parse JSON-RPC body --------------------------------------
    const message = parseRequestBody(req.body);
    if ('parseError' in message) {
      res.status(400).json(err(null, ERR_PARSE, message.parseError));
      return;
    }
    if (!isJsonRpcRequest(message.payload)) {
      res.status(400).json(err((message.payload as { id?: JsonRpcId })?.id ?? null,
        ERR_INVALID_REQ, 'Body is not a valid JSON-RPC 2.0 request'));
      return;
    }
    const rpc = message.payload;
    const isNotification = !('id' in rpc) || rpc.id === undefined;

    // ---- 3b. Method-scoped auth gate ---------------------------------
    // Tokenless methods (handshake + tool discovery) succeed without a
    // bearer. tools/call ALWAYS requires a valid bearer.
    const TOKENLESS_METHODS = new Set([
      'initialize',
      'initialized',
      'notifications/initialized',
      'tools/list',
    ]);
    if (!TOKENLESS_METHODS.has(rpc.method) && !hasValidBearer) {
      res.status(401).json(err(rpc.id ?? null, ERR_AUTH,
        presented
          ? 'Invalid bearer token'
          : 'Missing bearer — provide Authorization: Bearer <MCP_BEARER> header OR ?token=<MCP_BEARER> query parameter'));
      return;
    }

    // ---- 4. Build the service-role Supabase client (RLS_BYPASS) ------
    const sb = createClient(supabaseUrl, serviceRoleKey, {
      auth: { persistSession: false, autoRefreshToken: false },
    });

    // ---- 5. Dispatch by method ---------------------------------------
    const result = await dispatch(rpc, sb);
    if (isNotification) {
      res.status(202).end();
      return;
    }
    if (rpc.method === 'initialize' && queryToken && constantTimeEquals(queryToken, bearer)) {
      res.setHeader('Mcp-Session-Id', queryToken);
    }
    res.status(200).json(result);
  } catch (e) {
    const message = e instanceof Error ? `${e.name}: ${e.message}` : String(e);
    console.error('[mcp] handler threw:', e);
    res.status(500).json(err(null, ERR_INTERNAL, `internal: ${message}`));
  }
}

// ----- Method dispatch -------------------------------------------------
async function dispatch(rpc: JsonRpcRequest, sb: SupabaseClient): Promise<JsonRpcOk | JsonRpcErr> {
  const id = rpc.id ?? null;

  switch (rpc.method) {
    // ----- MCP handshake ---------------------------------------------
    case 'initialize': {
      const params = (rpc.params ?? {}) as { protocolVersion?: string; clientInfo?: unknown };
      // Per the spec we echo BACK our supported protocol version. The
      // client decides whether it's compatible.
      return ok(id, {
        protocolVersion: MCP_PROTOCOL_VERSION,
        serverInfo: { name: SERVER_NAME, version: SERVER_VERSION },
        capabilities: {
          tools: { listChanged: false },
        },
        instructions:
          'EIA Projects MCP server. Use list_boards to discover boards (returns workspace_id ' +
          'for tenancy scoping), then get_board for a board\'s structural snapshot. ' +
          'Write tools land in phase 3b.',
        // Spec-suggested informational field — what version of OUR
        // server is talking back. Optional but useful when debugging.
        clientInfo: params.clientInfo,
      });
    }

    case 'notifications/initialized':
    case 'initialized': {
      // Spec: client sends this after `initialize` to confirm the
      // handshake is complete. No response expected (it's a notification),
      // but we route through dispatch() anyway and the caller's
      // notification check short-circuits the response.
      return ok(id, {});
    }

    // ----- Tool discovery / invocation -------------------------------
    case 'tools/list': {
      return ok(id, { tools: Object.values(TOOLS) });
    }

    case 'tools/call': {
      const params = rpc.params as { name?: string; arguments?: Record<string, unknown> } | undefined;
      const toolName = params?.name;
      const args = params?.arguments ?? {};
      if (!toolName) {
        return err(id, ERR_INVALID_PARAMS, 'tools/call requires params.name');
      }
      const sensitiveWs = parseSensitiveWorkspaceIds();
      try {
        let payload: unknown;
        switch (toolName) {
          // ----- read tools -------------------------------------------
          case 'list_boards':
            payload = await toolListBoards(sb, args as { include_archived?: boolean });
            break;
          case 'get_board':
            payload = await toolGetBoard(sb, args as { board_id?: string });
            break;
          // ----- write tools (3b) -------------------------------------
          // The `as unknown as X` two-step is intentional: TS can't
          // narrow Record<string, unknown> → a specific Args shape, but
          // each tool validates its required fields at the top of the
          // body so the runtime is safe.
          case 'create_task':
            payload = await toolCreateTask(sb, args as unknown as ToolCreateTaskArgs, sensitiveWs);
            break;
          case 'bulk_create_tasks':
            payload = await toolBulkCreateTasks(sb, args as unknown as ToolBulkCreateTasksArgs, sensitiveWs);
            break;
          case 'create_board':
            payload = await toolCreateBoard(sb, args as unknown as ToolCreateBoardArgs, sensitiveWs);
            break;
          case 'design_board_from_spec':
            payload = await toolDesignBoardFromSpec(sb, args as unknown as ToolDesignBoardArgs, sensitiveWs);
            break;
          case 'update_task_status':
            payload = await toolUpdateTaskStatus(sb, args as unknown as ToolUpdateTaskStatusArgs, sensitiveWs);
            break;
          case 'move_task_to_group':
            payload = await toolMoveTaskToGroup(sb, args as unknown as ToolMoveTaskToGroupArgs, sensitiveWs);
            break;
          // ----- 3d chunk 1 (non-destructive) -------------------------
          case 'add_task_update':
            payload = await toolAddTaskUpdate(sb, args as unknown as ToolAddTaskUpdateArgs, sensitiveWs);
            break;
          case 'update_task_cell':
            payload = await toolUpdateTaskCell(sb, args as unknown as ToolUpdateTaskCellArgs, sensitiveWs);
            break;
          case 'update_task_name':
            payload = await toolUpdateTaskName(sb, args as unknown as ToolUpdateTaskNameArgs, sensitiveWs);
            break;
          // ----- 3d chunk 2 (column ops) ------------------------------
          case 'create_column':
            payload = await toolCreateColumn(sb, args as unknown as ToolCreateColumnArgs, sensitiveWs);
            break;
          // ----- 3d chunk 3 (group ops) -------------------------------
          case 'create_group':
            payload = await toolCreateGroup(sb, args as unknown as ToolCreateGroupArgs, sensitiveWs);
            break;
          case 'rename_group':
            payload = await toolRenameGroup(sb, args as unknown as ToolRenameGroupArgs, sensitiveWs);
            break;
          case 'delete_group':
            payload = await toolDeleteGroup(sb, args as unknown as ToolDeleteGroupArgs, sensitiveWs);
            break;
          // ----- 3d chunk 4 (delete_task) -----------------------------
          case 'delete_task':
            payload = await toolDeleteTask(sb, args as unknown as ToolDeleteTaskArgs, sensitiveWs);
            break;
          // ----- 3d chunk 5 (board ops) -------------------------------
          case 'rename_board':
            payload = await toolRenameBoard(sb, args as unknown as ToolRenameBoardArgs, sensitiveWs);
            break;
          case 'archive_board':
            payload = await toolArchiveBoard(sb, args as unknown as ToolArchiveBoardArgs, sensitiveWs);
            break;
          case 'delete_board':
            payload = await toolDeleteBoard(sb, args as unknown as ToolDeleteBoardArgs, sensitiveWs);
            break;
          // ----- 3d chunk 6 (workspace) -------------------------------
          case 'create_workspace':
            payload = await toolCreateWorkspace(sb, args as unknown as ToolCreateWorkspaceArgs);
            break;
          // ----- 3d follow-up #2 (column management) ------------------
          case 'add_column_label':
            payload = await toolAddColumnLabel(sb, args as unknown as ToolAddColumnLabelArgs, sensitiveWs);
            break;
          case 'delete_column':
            payload = await toolDeleteColumn(sb, args as unknown as ToolDeleteColumnArgs, sensitiveWs);
            break;
          case 'rename_column':
            payload = await toolRenameColumn(sb, args as unknown as ToolRenameColumnArgs, sensitiveWs);
            break;
          case 'update_column_label':
            payload = await toolUpdateColumnLabel(sb, args as unknown as ToolUpdateColumnLabelArgs, sensitiveWs);
            break;
          default:
            return err(id, ERR_METHOD, `Unknown tool: ${toolName}`);
        }
        // MCP tools/call result shape: content[] for human-readable
        // display, structuredContent for typed consumption. We return
        // both so legacy and modern clients are happy.
        return ok(id, {
          content: [{ type: 'text', text: JSON.stringify(payload, null, 2) }],
          structuredContent: payload,
          isError: false,
        });
      } catch (e) {
        // TenancyError is a deliberate refusal — surface its message
        // verbatim so callers can read why we said no. Everything else
        // is treated as a tool failure.
        if (e instanceof TenancyError) {
          return err(id, ERR_TOOL_FAILED, e.message);
        }
        const m = e instanceof Error ? e.message : String(e);
        return err(id, ERR_TOOL_FAILED, `tool '${toolName}' failed: ${m}`);
      }
    }

    default:
      return err(id, ERR_METHOD, `Method not implemented: ${rpc.method}`);
  }
}

// =====================================================================
// Tools
// =====================================================================

interface BoardListItem {
  id: string;
  name: string;
  icon_emoji: string;
  board_type: 'main' | 'private';
  workspace_id: string;
  workspace_name: string | null;
  archived: boolean;
  created_at: string;
}

async function toolListBoards(
  sb: SupabaseClient,
  args: { include_archived?: boolean },
): Promise<{ boards: BoardListItem[]; count: number; workspaces: { id: string; name: string }[] }> {
  const includeArchived = args.include_archived === true;

  // RLS_BYPASS-REVIEWED-3B: this read is INTENTIONALLY cross-workspace
  // — Optimus needs to discover boards across tenants to choose where
  // to write next. The response includes workspace_id on every row so
  // the caller can scope its own behaviour. Writes are gated separately
  // by api/_shared/mcp-tenancy.ts.
  const { data: boards, error } = await sb
    .from('boards')
    .select('id, name, icon_emoji, board_type, workspace_id, archived_at, created_at')
    .is('deleted_at', null)
    .order('created_at', { ascending: false });
  if (error) throw new Error(`boards select failed: ${error.message}`);

  const rows = (boards ?? []) as Array<{
    id: string; name: string; icon_emoji: string; board_type: 'main' | 'private';
    workspace_id: string; archived_at: string | null; created_at: string;
  }>;

  // Pull workspace names in one round-trip.
  const wsIds = Array.from(new Set(rows.map((b) => b.workspace_id)));
  const wsById = new Map<string, string>();
  if (wsIds.length > 0) {
    const { data: ws } = await sb
      .from('workspaces')
      .select('id, name')
      .in('id', wsIds);
    for (const w of (ws ?? []) as { id: string; name: string }[]) {
      wsById.set(w.id, w.name);
    }
  }

  const visible = rows
    .filter((b) => includeArchived || !b.archived_at)
    .map<BoardListItem>((b) => ({
      id: b.id,
      name: b.name,
      icon_emoji: b.icon_emoji,
      board_type: b.board_type,
      workspace_id: b.workspace_id,
      workspace_name: wsById.get(b.workspace_id) ?? null,
      archived: !!b.archived_at,
      created_at: b.created_at,
    }));

  return {
    boards: visible,
    count: visible.length,
    workspaces: Array.from(wsById, ([id, name]) => ({ id, name })),
  };
}

interface BoardSnapshot {
  board: {
    id: string;
    name: string;
    workspace_id: string;
    workspace_name: string | null;
    board_type: 'main' | 'private';
    icon_emoji: string;
    description: string | null;
  };
  groups: Array<{ id: string; name: string; color: string; sort_order: number }>;
  columns: Array<{
    id: string;
    name: string;
    column_type: string;
    sort_order: number;
    labels: Array<{ id: string; name: string; color: string; sort_order: number }>;
  }>;
  // 3d follow-up: items[] is the bridge that makes the per-task write
  // tools (update_task_cell / add_task_update / update_task_name /
  // delete_task / update_task_status) usable end-to-end — the caller
  // discovers a task's UUID by NAME from this array, then uses it as
  // task_id in the write call. Soft-deleted items are excluded; archived
  // items are included with archived:true so callers can choose to
  // ignore them. Cell values are keyed by column_id (NOT column_name)
  // so the round-trip into update_task_cell is unambiguous.
  tasks: Array<{
    id: string;
    name: string;
    task_code: string;
    group_id: string;
    parent_item_id: string | null;
    sort_order: number;
    archived: boolean;
    cells: Record<string, unknown>;
  }>;
  // Convenience counter so the caller doesn't have to scan tasks.length.
  task_count: number;
}

async function toolGetBoard(
  sb: SupabaseClient,
  args: { board_id?: string },
): Promise<BoardSnapshot> {
  if (!args.board_id || typeof args.board_id !== 'string') {
    throw new Error('board_id (string) is required');
  }
  const boardId = args.board_id;

  // RLS_BYPASS-REVIEWED-3B: read pulls the board even if it belongs to
  // a different workspace. Returning workspace_id below lets the caller
  // verify the snapshot is from the workspace it expected. Writes are
  // gated by api/_shared/mcp-tenancy.ts at the call site.
  const { data: board, error: bErr } = await sb
    .from('boards')
    .select('id, name, workspace_id, board_type, icon_emoji, description')
    .eq('id', boardId)
    .is('deleted_at', null)
    .maybeSingle();
  if (bErr) throw new Error(`board select failed: ${bErr.message}`);
  if (!board) throw new Error(`board not found: ${boardId}`);

  const { data: ws } = await sb
    .from('workspaces')
    .select('name')
    .eq('id', board.workspace_id)
    .maybeSingle();

  // Groups + columns + items in parallel (each scoped to this board).
  // items pulled here so the snapshot is one round-trip for the LLM.
  const [
    { data: groups, error: gErr },
    { data: columns, error: cErr },
    { data: items, error: iErr },
  ] = await Promise.all([
    sb.from('groups')
      .select('id, name, color, sort_order')
      .eq('board_id', boardId)
      .is('deleted_at', null)
      .order('sort_order'),
    sb.from('columns')
      .select('id, name, column_type, sort_order')
      .eq('board_id', boardId)
      .is('archived_at', null)
      .order('sort_order'),
    // RLS_BYPASS-REVIEWED-3D-FOLLOWUP: service-role read of items in
    // this board. Tenancy is asserted at the BOARD level above (we
    // refuse soft-deleted boards), and the response surfaces the board
    // → workspace mapping so the caller can verify tenancy before any
    // write. Per-task soft-delete is filtered here; archived items are
    // returned with archived:true so the caller can choose to skip.
    sb.from('items')
      .select('id, name, task_code, group_id, parent_item_id, sort_order, archived_at')
      .eq('board_id', boardId)
      .is('deleted_at', null)
      .order('group_id')
      .order('sort_order'),
  ]);
  if (gErr) throw new Error(`groups select failed: ${gErr.message}`);
  if (cErr) throw new Error(`columns select failed: ${cErr.message}`);
  if (iErr) throw new Error(`items select failed: ${iErr.message}`);

  // Labels per column + cell values per item — fired in parallel because
  // they target different tables.
  const colIds  = (columns ?? []).map((c) => c.id);
  const itemIds = (items   ?? []).map((i) => (i as { id: string }).id);
  const labelsByCol = new Map<string, Array<{ id: string; name: string; color: string; sort_order: number }>>();
  // Keyed by item_id → (column_id → raw jsonb value). The exact shape
  // of `value` varies by column_type — see update_task_cell's docs.
  const cellsByItem = new Map<string, Record<string, unknown>>();
  const [labelsRes, cellsRes] = await Promise.all([
    colIds.length === 0
      ? Promise.resolve({ data: [] as Array<{ id: string; column_id: string; name: string; color: string; sort_order: number }>, error: null })
      : sb.from('column_labels')
          .select('id, column_id, name, color, sort_order')
          .in('column_id', colIds)
          .order('sort_order'),
    itemIds.length === 0
      ? Promise.resolve({ data: [] as Array<{ item_id: string; column_id: string; value: unknown }>, error: null })
      : sb.from('item_column_values')
          .select('item_id, column_id, value')
          .in('item_id', itemIds),
  ]);
  if (labelsRes.error) throw new Error(`labels select failed: ${labelsRes.error.message}`);
  if (cellsRes.error)  throw new Error(`item_column_values select failed: ${cellsRes.error.message}`);
  for (const l of (labelsRes.data ?? []) as Array<{ id: string; column_id: string; name: string; color: string; sort_order: number }>) {
    const arr = labelsByCol.get(l.column_id) ?? [];
    arr.push({ id: l.id, name: l.name, color: l.color, sort_order: l.sort_order });
    labelsByCol.set(l.column_id, arr);
  }
  for (const r of (cellsRes.data ?? []) as Array<{ item_id: string; column_id: string; value: unknown }>) {
    const map = cellsByItem.get(r.item_id) ?? {};
    map[r.column_id] = r.value;
    cellsByItem.set(r.item_id, map);
  }

  const tasksOut: BoardSnapshot['tasks'] = ((items ?? []) as Array<{
    id: string; name: string; task_code: string; group_id: string;
    parent_item_id: string | null; sort_order: number; archived_at: string | null;
  }>).map((it) => ({
    id:             it.id,
    name:           it.name,
    task_code:      it.task_code,
    group_id:       it.group_id,
    parent_item_id: it.parent_item_id,
    sort_order:     it.sort_order,
    archived:       !!it.archived_at,
    cells:          cellsByItem.get(it.id) ?? {},
  }));

  return {
    board: {
      id: board.id,
      name: board.name,
      workspace_id: board.workspace_id,
      workspace_name: (ws as { name?: string } | null)?.name ?? null,
      board_type: board.board_type,
      icon_emoji: board.icon_emoji,
      description: board.description,
    },
    groups: (groups ?? []) as BoardSnapshot['groups'],
    columns: ((columns ?? []) as Array<{ id: string; name: string; column_type: string; sort_order: number }>)
      .map((c) => ({
        id: c.id,
        name: c.name,
        column_type: c.column_type,
        sort_order: c.sort_order,
        labels: labelsByCol.get(c.id) ?? [],
      })),
    tasks: tasksOut,
    task_count: tasksOut.length,
  };
}

// =====================================================================
// 3b — Write tools
//
// Every write tool below:
//   1. Resolves the target's workspace_id via api/_shared/mcp-tenancy.ts.
//   2. Asserts the asserted board/group/task actually belongs there
//      (refuses cross-board / cross-workspace mismatches).
//   3. Checks the SENSITIVE_WORKSPACE_IDS gate with the caller's
//      confirm_sensitive_workspace flag.
//   4. Performs the write (via the ported applier when the operation
//      is action-shaped; direct insert otherwise).
//   5. Logs the result to public.ai_runs (awaited — Phase 2 lesson).
// =====================================================================

// ----- create_task ---------------------------------------------------
interface ToolCreateTaskArgs {
  board_id: string;
  group_id: string;
  name: string;
  cells?: Record<string, unknown>;
  confirm_sensitive_workspace?: boolean;
}

async function toolCreateTask(
  sb: SupabaseClient,
  args: ToolCreateTaskArgs,
  sensitive: Set<string>,
): Promise<{ task_id: string; board_id: string; workspace_id: string }> {
  // 1. Tenancy chain: board → workspace, group ∈ board.
  const board = await resolveWorkspaceForBoard(sb, args.board_id);
  await assertGroupInBoard(sb, args.group_id, board.boardId);
  assertWorkspaceWriteAllowed(board.workspaceId, sensitive, args.confirm_sensitive_workspace === true);

  // 2. Translate `cells` (keyed by column NAME) into the applier's
  //    ref-keyed actions schema by building a one-action plan + a
  //    minimal EngineContext so the applier can resolve refs.
  const ctx = await fetchBoardContext(sb, board.boardId);
  // Find the group ref that maps to args.group_id (it's seeded by id
  // already; we still need to look it up by its ref name).
  const groupRef = ctx.groups.find((g) => g.id === args.group_id)?.ref;
  if (!groupRef) {
    // Should never happen — group is in this board per assertGroupInBoard
    throw new Error(`internal: could not resolve group ref for ${args.group_id}`);
  }
  // Translate column-name keys → column-ref keys.
  //
  // The applier (api/_shared/applier.ts) expects each cell in the
  // *action* shape ({value, label_ref, label_refs, checked, url, …}).
  // The bug-fix from the same commit teaches update_task_cell to accept
  // LLM-natural shapes (bare strings, numbers, arrays, etc.); we apply
  // the same normalisation here so create_task's cells path is
  // consistent. Without this, create_task silently SKIPS bad-shape
  // cells (the applier returns null and the cell never lands).
  const cellsByRef: Record<string, unknown> = {};
  if (args.cells) {
    for (const [colName, cv] of Object.entries(args.cells)) {
      const col = ctx.columns.find((c) => c.name === colName);
      if (!col) continue;     // silently skip unknown columns
      const normalised = normaliseCellToActionShape(cv, col);
      if (normalised !== null) cellsByRef[col.ref] = normalised;
    }
  }

  const actor = await getServiceActorId(sb);
  const action: Action = {
    type: 'create_task',
    group_ref: groupRef,
    name: args.name,
    ...(Object.keys(cellsByRef).length > 0 ? { cells: cellsByRef as never } : {}),
  };
  const result = await applyActions({
    boardId: board.boardId,
    actions: [action],
    context: ctx,
    userId: actor,
    sb,
  });
  if (result.failedAt) {
    await logMcpRun(sb, {
      toolName: 'create_task',
      status: 'error',
      workspaceId: board.workspaceId,
      boardId: board.boardId,
      prompt: args.name,
      responseSummary: `failed: ${result.failedAt.error}`,
      errorMessage: result.failedAt.error,
    });
    throw new Error(`applier failed: ${result.failedAt.error}`);
  }
  // Fetch the inserted task id back — pull the most recent items row
  // for this group whose name matches.
  const { data: items } = await sb
    .from('items')
    .select('id')
    .eq('group_id', args.group_id)
    .eq('name', args.name)
    .order('created_at', { ascending: false })
    .limit(1);
  const taskId = ((items ?? [])[0] as { id?: string } | undefined)?.id ?? '';
  await logMcpRun(sb, {
    toolName: 'create_task',
    status: 'success',
    workspaceId: board.workspaceId,
    boardId: board.boardId,
    prompt: args.name,
    responseSummary: `task_id=${taskId}`,
  });
  return { task_id: taskId, board_id: board.boardId, workspace_id: board.workspaceId };
}

// ----- bulk_create_tasks --------------------------------------------
interface ToolBulkCreateTasksArgs {
  board_id: string;
  group_id: string;
  tasks: Array<{ name: string; group_id?: string; cells?: Record<string, unknown> }>;
  confirm_sensitive_workspace?: boolean;
}

async function toolBulkCreateTasks(
  sb: SupabaseClient,
  args: ToolBulkCreateTasksArgs,
  sensitive: Set<string>,
): Promise<{
  board_id: string;
  workspace_id: string;
  total: number;
  succeeded: number;
  failed: number;
  results: Array<{ index: number; ok: boolean; task_id?: string; name: string; error?: string }>;
}> {
  // Tenancy + sensitive check (ONCE for the whole batch — every task
  // lands in the same group on the same board on the same workspace).
  const board = await resolveWorkspaceForBoard(sb, args.board_id);
  await assertGroupInBoard(sb, args.group_id, board.boardId);
  assertWorkspaceWriteAllowed(board.workspaceId, sensitive, args.confirm_sensitive_workspace === true);

  if (!Array.isArray(args.tasks) || args.tasks.length === 0) {
    throw new Error('tasks must be a non-empty array');
  }

  // Per-task try/catch so one bad row doesn't poison the rest. Each
  // task honours its own group_id override (falling back to the
  // batch's group_id). toolCreateTask runs the full tenancy chain for
  // every per-task group_id, so a cross-board override surfaces as
  // THAT task's TenancyError without aborting the batch.
  const results: Array<{ index: number; ok: boolean; task_id?: string; name: string; error?: string }> = [];
  let succeeded = 0;
  let failed = 0;
  for (let i = 0; i < args.tasks.length; i += 1) {
    const t = args.tasks[i];
    const effectiveGroupId = t.group_id ?? args.group_id;
    try {
      const r = await toolCreateTask(sb, {
        board_id: args.board_id,
        group_id: effectiveGroupId,
        name: t.name,
        cells: t.cells,
        confirm_sensitive_workspace: args.confirm_sensitive_workspace,
      }, sensitive);
      results.push({ index: i, ok: true, task_id: r.task_id, name: t.name });
      succeeded += 1;
    } catch (e) {
      results.push({
        index: i,
        ok: false,
        name: t.name,
        error: e instanceof Error ? e.message : String(e),
      });
      failed += 1;
    }
  }

  await logMcpRun(sb, {
    toolName: 'bulk_create_tasks',
    status: failed === 0 ? 'success' : 'error',
    workspaceId: board.workspaceId,
    boardId: board.boardId,
    prompt: `${args.tasks.length} tasks → group ${args.group_id}`,
    responseSummary: `succeeded=${succeeded} failed=${failed}`,
    errorMessage: failed === 0 ? undefined : `${failed} of ${args.tasks.length} failed`,
  });
  return {
    board_id: board.boardId,
    workspace_id: board.workspaceId,
    total: args.tasks.length,
    succeeded,
    failed,
    results,
  };
}

// ----- create_board -------------------------------------------------
interface ToolCreateBoardArgs {
  workspace_id: string;
  name: string;
  icon_emoji?: string;
  board_type?: 'main' | 'private';
  description?: string;
  confirm_sensitive_workspace?: boolean;
}

async function toolCreateBoard(
  sb: SupabaseClient,
  args: ToolCreateBoardArgs,
  sensitive: Set<string>,
): Promise<{ board_id: string; workspace_id: string }> {
  if (!args.workspace_id || typeof args.workspace_id !== 'string') {
    throw new TenancyError('workspace_id is required — never defaulted, never guessed');
  }
  if (!args.name || args.name.trim().length === 0) {
    throw new Error('name is required');
  }
  assertWorkspaceWriteAllowed(args.workspace_id, sensitive, args.confirm_sensitive_workspace === true);

  // Verify the workspace exists. service-role read.
  const { data: ws, error: wsErr } = await sb
    .from('workspaces')
    .select('id')
    .eq('id', args.workspace_id)
    .maybeSingle();
  if (wsErr) throw new Error(`workspaces select failed: ${wsErr.message}`);
  if (!ws) throw new TenancyError(`Workspace ${args.workspace_id} not found`);

  const actor = await getServiceActorId(sb);
  const insert = {
    workspace_id: args.workspace_id,
    name: args.name.trim(),
    description: args.description?.trim() || null,
    icon_emoji: args.icon_emoji ?? '📋',
    board_type: args.board_type ?? 'main',
    owner_id: actor,
    created_by: actor,
  };
  const { data, error } = await sb
    .from('boards')
    .insert(insert as never)
    .select('id')
    .single();
  if (error) {
    await logMcpRun(sb, {
      toolName: 'create_board', status: 'error',
      workspaceId: args.workspace_id, boardId: null,
      prompt: args.name, responseSummary: `error: ${error.message}`,
      errorMessage: error.message,
    });
    throw new Error(`board insert failed: ${error.message}`);
  }
  const boardId = (data as { id: string }).id;
  await logMcpRun(sb, {
    toolName: 'create_board', status: 'success',
    workspaceId: args.workspace_id, boardId,
    prompt: args.name, responseSummary: `board_id=${boardId}`,
  });
  return { board_id: boardId, workspace_id: args.workspace_id };
}

// ----- design_board_from_spec ---------------------------------------
interface ToolDesignBoardArgs {
  workspace_id: string;
  board_name: string;
  icon_emoji?: string;
  prompt?: string;
  actions?: unknown[];
  model?: 'gemini-2.5-flash' | 'gemini-2.5-pro';
  confirm_sensitive_workspace?: boolean;
}

async function toolDesignBoardFromSpec(
  sb: SupabaseClient,
  args: ToolDesignBoardArgs,
  sensitive: Set<string>,
): Promise<{
  board_id: string;
  workspace_id: string;
  actions_applied: number;
  actions_planned: number;
  failed_at?: { index: number; description: string; error: string };
  source: 'prompt' | 'actions';
}> {
  if (!args.workspace_id) throw new TenancyError('workspace_id is required');
  if (!args.board_name)   throw new Error('board_name is required');
  assertWorkspaceWriteAllowed(args.workspace_id, sensitive, args.confirm_sensitive_workspace === true);

  const hasPrompt = typeof args.prompt === 'string' && args.prompt.trim().length > 0;
  const hasActions = Array.isArray(args.actions) && args.actions.length > 0;
  if (hasPrompt && hasActions) throw new Error('pass either prompt OR actions, not both');
  if (!hasPrompt && !hasActions) throw new Error('one of prompt or actions is required');

  // 1. Resolve actions, either from Gemini or from the caller.
  let actions: Action[];
  let source: 'prompt' | 'actions';
  if (hasPrompt) {
    const apiKey = Deno.env.get('GEMINI_API_KEY');
    if (!apiKey) throw new Error('GEMINI_API_KEY not configured on server');
    const engineResult = await runEngine({
      apiKey,
      prompt: args.prompt!,
      kind: 'create_board',
      context: { groups: [], columns: [] },
      model: args.model ?? 'gemini-2.5-flash',
    });
    if (!engineResult.ok) {
      await logMcpRun(sb, {
        toolName: 'design_board_from_spec', status: 'error',
        workspaceId: args.workspace_id, boardId: null,
        prompt: args.prompt ?? '', responseSummary: `engine failed: ${engineResult.error}`,
        errorMessage: engineResult.error,
      });
      throw new Error(`gemini engine failed: ${engineResult.error}`);
    }
    actions = engineResult.data.actions;
    source = 'prompt';
  } else {
    // Validate the supplied actions through the SAME Zod schema the
    // button-flow uses, so the two paths can't diverge.
    const parsed = z.array(ActionSchema).safeParse(args.actions);
    if (!parsed.success) {
      throw new Error(`actions failed schema validation: ${parsed.error.message}`);
    }
    actions = parsed.data;
    source = 'actions';
  }

  // 2. Create the board (DB trigger seeds task_name + default columns).
  const newBoard = await toolCreateBoard(sb, {
    workspace_id: args.workspace_id,
    name: args.board_name,
    icon_emoji: args.icon_emoji,
    confirm_sensitive_workspace: args.confirm_sensitive_workspace,
  }, sensitive);

  // 3. Apply the actions inside the new board. We re-fetch the just-
  //    created board's seeded columns so the applier has the column refs
  //    it needs (chiefly task_name + the trigger-seeded Status column).
  const ctx = await fetchBoardContext(sb, newBoard.board_id);
  const actor = await getServiceActorId(sb);
  const result = await applyActions({
    boardId: newBoard.board_id,
    actions,
    context: ctx,
    userId: actor,
    sb,
  });

  await logMcpRun(sb, {
    toolName: 'design_board_from_spec',
    status: result.failedAt ? 'error' : 'success',
    workspaceId: args.workspace_id,
    boardId: newBoard.board_id,
    prompt: args.prompt ?? `(actions × ${actions.length})`,
    responseSummary: `applied=${result.applied}/${actions.length} source=${source}`,
    errorMessage: result.failedAt?.error,
  });

  return {
    board_id: newBoard.board_id,
    workspace_id: newBoard.workspace_id,
    actions_planned: actions.length,
    actions_applied: result.applied,
    ...(result.failedAt ? { failed_at: result.failedAt } : {}),
    source,
  };
}

// ----- update_task_status -------------------------------------------
interface ToolUpdateTaskStatusArgs {
  task_id: string;
  status_label: string;
  confirm_sensitive_workspace?: boolean;
}

async function toolUpdateTaskStatus(
  sb: SupabaseClient,
  args: ToolUpdateTaskStatusArgs,
  sensitive: Set<string>,
): Promise<{ task_id: string; board_id: string; workspace_id: string; label_id: string }> {
  if (!args.task_id)      throw new Error('task_id is required');
  if (!args.status_label) throw new Error('status_label is required');

  const t = await assertTaskBoardAndWorkspace(sb, args.task_id);
  assertWorkspaceWriteAllowed(t.workspaceId, sensitive, args.confirm_sensitive_workspace === true);

  // Find the first status column on the task's board (matches applier).
  const { data: statusCols } = await sb
    .from('columns')
    .select('id')
    .eq('board_id', t.boardId)
    .eq('column_type', 'status')
    .is('archived_at', null)
    .order('sort_order')
    .limit(1);
  const statusColId = ((statusCols ?? [])[0] as { id?: string } | undefined)?.id;
  if (!statusColId) throw new Error(`no status column on board ${t.boardId}`);

  // Resolve the requested label by name on that column.
  const { data: labels } = await sb
    .from('column_labels')
    .select('id, name')
    .eq('column_id', statusColId);
  const label = (labels ?? []).find((l) => (l as { name: string }).name === args.status_label) as { id: string } | undefined;
  if (!label) throw new Error(`status label "${args.status_label}" not found on this board`);

  const actor = await getServiceActorId(sb);
  const { error } = await sb
    .from('item_column_values')
    .upsert({
      item_id: t.taskId,
      column_id: statusColId,
      value: { label_id: label.id },
      updated_by: actor,
    } as never, { onConflict: 'item_id,column_id' });
  if (error) {
    await logMcpRun(sb, {
      toolName: 'update_task_status', status: 'error',
      workspaceId: t.workspaceId, boardId: t.boardId,
      prompt: args.status_label, responseSummary: `upsert failed`,
      errorMessage: error.message,
    });
    throw new Error(`status upsert failed: ${error.message}`);
  }
  await logMcpRun(sb, {
    toolName: 'update_task_status', status: 'success',
    workspaceId: t.workspaceId, boardId: t.boardId,
    prompt: args.status_label, responseSummary: `task=${t.taskId} → label=${label.id}`,
  });
  return {
    task_id: t.taskId,
    board_id: t.boardId,
    workspace_id: t.workspaceId,
    label_id: label.id,
  };
}

// ----- move_task_to_group -------------------------------------------
interface ToolMoveTaskToGroupArgs {
  task_id: string;
  group_id: string;
  confirm_sensitive_workspace?: boolean;
}

async function toolMoveTaskToGroup(
  sb: SupabaseClient,
  args: ToolMoveTaskToGroupArgs,
  sensitive: Set<string>,
): Promise<{ task_id: string; board_id: string; workspace_id: string; group_id: string }> {
  if (!args.task_id)  throw new Error('task_id is required');
  if (!args.group_id) throw new Error('group_id is required');

  // Tenancy: task → board → workspace
  const t = await assertTaskBoardAndWorkspace(sb, args.task_id);
  assertWorkspaceWriteAllowed(t.workspaceId, sensitive, args.confirm_sensitive_workspace === true);

  // Destination group must belong to the SAME board (no cross-board move)
  await assertGroupInBoard(sb, args.group_id, t.boardId);

  // Write: update only items.group_id
  const actor = await getServiceActorId(sb);
  const { error } = await sb.from('items')
    .update({ group_id: args.group_id, updated_by: actor } as never)
    .eq('id', t.taskId);
  if (error) {
    await logMcpRun(sb, {
      toolName: 'move_task_to_group', status: 'error',
      workspaceId: t.workspaceId, boardId: t.boardId,
      prompt: null, responseSummary: 'group_id update failed',
      errorMessage: error.message,
    });
    throw error;
  }
  await logMcpRun(sb, {
    toolName: 'move_task_to_group', status: 'success',
    workspaceId: t.workspaceId, boardId: t.boardId,
    prompt: null, responseSummary: `task=${t.taskId} → group=${args.group_id}`,
  });
  return {
    task_id: t.taskId,
    board_id: t.boardId,
    workspace_id: t.workspaceId,
    group_id: args.group_id,
  };
}

// =====================================================================
// 3d chunk 1 — non-destructive expansions
// =====================================================================

// ----- add_task_update ----------------------------------------------
interface ToolAddTaskUpdateArgs {
  task_id: string;
  body: string;
  is_html?: boolean;
  confirm_sensitive_workspace?: boolean;
}

async function toolAddTaskUpdate(
  sb: SupabaseClient,
  args: ToolAddTaskUpdateArgs,
  sensitive: Set<string>,
): Promise<{ update_id: string; task_id: string; board_id: string; workspace_id: string }> {
  if (!args.task_id) throw new Error('task_id is required');
  if (!args.body || args.body.trim().length === 0) throw new Error('body is required');

  // Tenancy chain: task → board → workspace.
  const t = await assertTaskBoardAndWorkspace(sb, args.task_id);
  assertWorkspaceWriteAllowed(t.workspaceId, sensitive, args.confirm_sensitive_workspace === true);

  // Wrap plain text in <p>; treat is_html=true as caller-supplied
  // markup (no sanitization beyond what the DB stores — the UI already
  // renders this field through DOMPurify on read).
  const bodyHtml = args.is_html
    ? args.body
    : `<p>${escapeHtml(args.body)}</p>`;

  const actor = await getServiceActorId(sb);
  const { data, error } = await sb
    .from('updates')
    .insert({
      item_id:   t.taskId,
      author_id: actor,
      body_html: bodyHtml,
      body_json: null,
    } as never)
    .select('id')
    .single();
  if (error) {
    await logMcpRun(sb, {
      toolName: 'add_task_update', status: 'error',
      workspaceId: t.workspaceId, boardId: t.boardId,
      prompt: args.body.slice(0, 200),
      responseSummary: `insert failed: ${error.message}`,
      errorMessage: error.message,
    });
    throw new Error(`updates insert failed: ${error.message}`);
  }
  const updateId = (data as { id: string }).id;
  await logMcpRun(sb, {
    toolName: 'add_task_update', status: 'success',
    workspaceId: t.workspaceId, boardId: t.boardId,
    prompt: args.body.slice(0, 200),
    responseSummary: `update_id=${updateId}`,
  });
  return { update_id: updateId, task_id: t.taskId, board_id: t.boardId, workspace_id: t.workspaceId };
}

// ----- update_task_cell ---------------------------------------------
interface ToolUpdateTaskCellArgs {
  task_id: string;
  column_id?: string;
  column_name?: string;
  value: unknown;
  confirm_sensitive_workspace?: boolean;
}

async function toolUpdateTaskCell(
  sb: SupabaseClient,
  args: ToolUpdateTaskCellArgs,
  sensitive: Set<string>,
): Promise<{
  task_id: string; column_id: string; column_type: string;
  board_id: string; workspace_id: string;
}> {
  if (!args.task_id) throw new Error('task_id is required');
  if (!args.column_id && !args.column_name) {
    throw new Error('one of column_id or column_name is required');
  }
  if (args.value === undefined || args.value === null) {
    throw new Error('value is required (use { value: null } to clear is not yet supported)');
  }

  const t = await assertTaskBoardAndWorkspace(sb, args.task_id);
  assertWorkspaceWriteAllowed(t.workspaceId, sensitive, args.confirm_sensitive_workspace === true);

  // Resolve the column on the task's board. column_id wins when both
  // are present, and we re-verify the column actually belongs to this
  // board (cross-board column_id is refused).
  let columnRow: { id: string; column_type: string; name: string } | null = null;
  if (args.column_id) {
    const { data, error } = await sb
      .from('columns')
      .select('id, column_type, name, board_id, archived_at')
      .eq('id', args.column_id)
      .maybeSingle();
    if (error) throw new Error(`columns select failed: ${error.message}`);
    if (!data) throw new Error(`column ${args.column_id} not found`);
    const row = data as { id: string; column_type: string; name: string; board_id: string; archived_at: string | null };
    if (row.archived_at) throw new Error(`column ${args.column_id} is archived`);
    if (row.board_id !== t.boardId) {
      throw new TenancyError(
        `Cross-board write refused: column ${args.column_id} belongs to board ` +
        `${row.board_id}, not to the task's board (${t.boardId}).`,
      );
    }
    columnRow = { id: row.id, column_type: row.column_type, name: row.name };
  } else if (args.column_name) {
    const { data, error } = await sb
      .from('columns')
      .select('id, column_type, name')
      .eq('board_id', t.boardId)
      .eq('name', args.column_name)
      .is('archived_at', null)
      .maybeSingle();
    if (error) throw new Error(`columns select failed: ${error.message}`);
    if (!data) throw new Error(`column named "${args.column_name}" not found on this board`);
    columnRow = data as { id: string; column_type: string; name: string };
  }
  if (!columnRow) throw new Error('column resolution failed');
  if (columnRow.column_type === 'task_name') {
    throw new Error('use update_task_name for the task_name column, not update_task_cell');
  }
  if (columnRow.column_type === 'files') {
    throw new Error('files column writes are not exposed via MCP in 3d');
  }

  // Translate the caller's value shape → DB JSON. We accept both
  // human-readable forms (label_name, label_names) and id forms
  // (label_id, label_ids).
  const dbValue = await translateMcpCellValue(sb, columnRow, args.value);
  if (dbValue == null) {
    // Echo what we got + what the column expects so the LLM can self-correct
    // without having to re-read the tool description.
    const seen = `typeof=${typeof args.value} value=${JSON.stringify(args.value).slice(0, 200)}`;
    const hint = exampleValueFor(columnRow.column_type);
    throw new Error(
      `value did not resolve for ${columnRow.column_type} column "${columnRow.name}". ` +
      `Received: ${seen}. Try: ${hint}.`,
    );
  }

  const actor = await getServiceActorId(sb);
  const { error } = await sb
    .from('item_column_values')
    .upsert({
      item_id:    t.taskId,
      column_id:  columnRow.id,
      value:      dbValue,
      updated_by: actor,
    } as never, { onConflict: 'item_id,column_id' });
  if (error) {
    await logMcpRun(sb, {
      toolName: 'update_task_cell', status: 'error',
      workspaceId: t.workspaceId, boardId: t.boardId,
      prompt: `${columnRow.name} = ${JSON.stringify(args.value)}`.slice(0, 200),
      responseSummary: `upsert failed: ${error.message}`,
      errorMessage: error.message,
    });
    throw new Error(`item_column_values upsert failed: ${error.message}`);
  }
  await logMcpRun(sb, {
    toolName: 'update_task_cell', status: 'success',
    workspaceId: t.workspaceId, boardId: t.boardId,
    prompt: `${columnRow.name} = ${JSON.stringify(args.value)}`.slice(0, 200),
    responseSummary: `task=${t.taskId} col=${columnRow.id} type=${columnRow.column_type}`,
  });
  return {
    task_id: t.taskId,
    column_id: columnRow.id,
    column_type: columnRow.column_type,
    board_id: t.boardId,
    workspace_id: t.workspaceId,
  };
}

// Cell-value translator that ALSO accepts {label_name, label_names,
// label_id, label_ids, user_ids, value, checked, url}. Resolves
// name→id where needed by querying column_labels on this column.
// translateMcpCellValue — LLM-friendly cell-value normaliser.
//
// Returns the DB-shape jsonb that goes into item_column_values.value.
// Accepts EVERY natural shape an LLM client might send (string, number,
// boolean, array, the documented {value|label_ref|label_name|...} forms,
// and a few alias keys). The previous version's first line was a
// `typeof raw !== 'object' → null` short-circuit that rejected primitives
// before any column-type logic ran — that was the -32002 root cause.
//
// Resolves label names → ids inline. Throws on truly unrecognisable
// inputs so the caller surfaces a useful JSON-RPC error.
async function translateMcpCellValue(
  sb: SupabaseClient,
  column: { id: string; column_type: string },
  raw: unknown,
): Promise<unknown | null> {
  if (raw === undefined) return null;
  // Explicit null clears in the LLM-friendly form aren't supported yet;
  // returning null here lets the caller throw a clear message.
  if (raw === null) return null;

  const colType = column.column_type;

  // Step 1 — auto-box bare primitives / arrays into the canonical object
  //          form for the column type. After this branch `v` is always
  //          a plain object the per-type logic can read keys from.
  let v: Record<string, unknown>;
  if (typeof raw === 'object' && !Array.isArray(raw)) {
    v = raw as Record<string, unknown>;
  } else {
    // raw is a primitive (string|number|boolean|bigint) or an array.
    if (colType === 'text' || colType === 'numbers' || colType === 'date') {
      v = { value: raw };
    } else if (colType === 'checkbox') {
      v = { checked: raw };
    } else if (colType === 'status' || colType === 'priority') {
      v = { label_name: String(raw) };
    } else if (colType === 'dropdown') {
      v = Array.isArray(raw) ? { label_names: raw } : { label_names: [String(raw)] };
    } else if (colType === 'people') {
      v = Array.isArray(raw) ? { user_ids: raw } : { user_ids: [String(raw)] };
    } else if (colType === 'link') {
      v = { url: String(raw) };
    } else {
      return null;
    }
  }

  // Step 2 — per-type DB-shape resolution. Accepts the documented keys
  //          plus a couple of natural aliases (`text`/`date`/`num`).
  if (colType === 'status' || colType === 'priority') {
    if (typeof v.label_id === 'string') return { label_id: v.label_id };
    const wantName =
      typeof v.label_name === 'string' ? v.label_name :
      typeof v.value      === 'string' ? v.value :
      null;
    if (wantName) {
      const id = await resolveLabelIdByName(sb, column.id, wantName);
      if (!id) throw new Error(`label "${wantName}" not found on column ${column.id}`);
      return { label_id: id };
    }
    return null;
  }
  if (colType === 'dropdown') {
    if (Array.isArray(v.label_ids) && (v.label_ids as unknown[]).every((x) => typeof x === 'string')) {
      return { label_ids: v.label_ids };
    }
    const names =
      Array.isArray(v.label_names)  ? v.label_names as unknown[] :
      typeof v.label_name === 'string' ? [v.label_name] :
      Array.isArray(v.value)        ? v.value as unknown[] :
      typeof v.value === 'string'   ? [v.value] :
      null;
    if (names && names.every((x) => typeof x === 'string')) {
      const ids = await resolveLabelIdsByNames(sb, column.id, names as string[]);
      if (ids.length === 0) {
        throw new Error(`no matching labels for [${(names as string[]).join(', ')}] on column ${column.id}`);
      }
      return { label_ids: ids };
    }
    return null;
  }
  if (colType === 'people') {
    if (Array.isArray(v.user_ids) && (v.user_ids as unknown[]).every((x) => typeof x === 'string')) {
      return { user_ids: v.user_ids };
    }
    if (typeof v.user_id === 'string') return { user_ids: [v.user_id] };
    return null;
  }
  if (colType === 'checkbox') {
    if ('checked' in v) return { checked: coerceBool(v.checked) };
    if ('value'   in v) return { checked: coerceBool(v.value) };
    return null;
  }
  if (colType === 'link') {
    if (typeof v.url === 'string') {
      return { url: v.url, label: typeof v.label === 'string' ? v.label : null };
    }
    return null;
  }
  if (colType === 'date') {
    // Accept either { value } or { date }. Pass through as a string —
    // the UI's date renderer expects YYYY-MM-DD but we don't enforce.
    const s = v.value ?? v.date;
    if (s === undefined || s === null) return null;
    return { value: String(s) };
  }
  if (colType === 'numbers') {
    const candidate = v.value ?? v.num ?? v.number;
    if (candidate === undefined || candidate === null) return null;
    const n = typeof candidate === 'number' ? candidate : Number(candidate);
    if (!Number.isFinite(n)) return null;
    return { value: n };
  }
  // text — accept value | text | str | content; cast to string.
  if (colType === 'text') {
    const s = v.value ?? v.text ?? v.str ?? v.content;
    if (s === undefined || s === null) return null;
    return { value: String(s) };
  }
  return null;
}

async function resolveLabelIdByName(
  sb: SupabaseClient, columnId: string, name: string,
): Promise<string | null> {
  const { data } = await sb
    .from('column_labels')
    .select('id')
    .eq('column_id', columnId)
    .eq('name', name)
    .maybeSingle();
  return (data as { id?: string } | null)?.id ?? null;
}

async function resolveLabelIdsByNames(
  sb: SupabaseClient, columnId: string, names: string[],
): Promise<string[]> {
  const { data } = await sb
    .from('column_labels')
    .select('id')
    .eq('column_id', columnId)
    .in('name', names);
  return (data ?? []).map((r) => (r as { id: string }).id);
}

function coerceBool(x: unknown): boolean {
  if (typeof x === 'boolean') return x;
  if (typeof x === 'number')  return x !== 0;
  if (typeof x === 'string') {
    const s = x.trim().toLowerCase();
    return s === 'true' || s === '1' || s === 'yes' || s === 'y';
  }
  return !!x;
}

// Returns a one-line example string for the "value did not resolve"
// error message — keeps the failure surface self-documenting so an LLM
// agent can self-correct from the error text alone.
function exampleValueFor(columnType: string): string {
  switch (columnType) {
    case 'text':     return '"some text"   or   { "value": "…" }';
    case 'numbers':  return '42            or   { "value": 42 }';
    case 'date':     return '"2026-05-30"  or   { "value": "YYYY-MM-DD" }';
    case 'checkbox': return 'true          or   { "checked": true }';
    case 'link':     return '"https://…"   or   { "url": "https://…", "label"?: "…" }';
    case 'status':
    case 'priority': return '"Done"        or   { "label_name": "Done" }   or   { "label_id": "<uuid>" }';
    case 'dropdown': return '["EU","US"]   or   { "label_names": ["EU","US"] }';
    case 'people':   return '["<uuid>", …] or   { "user_ids": ["<uuid>", …] }';
    default:         return '(unsupported column type for MCP writes)';
  }
}

// normaliseCellToActionShape — converts an LLM-natural cell value into
// the *action-shape* the applier (api/_shared/applier.ts) expects.
// This is the create_task counterpart to translateMcpCellValue (which
// produces the DB shape). The two functions share the same input
// language so create_task and update_task_cell behave identically for
// the same caller inputs.
//
// IMPORTANT: outputs the {value | label_ref | label_refs | checked |
// url | user_ids} shape — the applier resolves refs against the
// engine context. Label lookups happen against the supplied column's
// labels[] (already cached in the engine context, so this is sync).
function normaliseCellToActionShape(
  raw: unknown,
  column: { id: string; ref: string; column_type: string; labels: { id: string; ref: string; name: string }[] },
): unknown | null {
  if (raw === undefined || raw === null) return null;
  const colType = column.column_type;

  // Step 1 — box primitives + arrays per column type.
  let v: Record<string, unknown>;
  if (typeof raw === 'object' && !Array.isArray(raw)) {
    v = raw as Record<string, unknown>;
  } else {
    if (colType === 'text' || colType === 'numbers' || colType === 'date') {
      v = { value: raw };
    } else if (colType === 'checkbox') {
      v = { checked: raw };
    } else if (colType === 'status' || colType === 'priority') {
      v = { label_name: String(raw) };
    } else if (colType === 'dropdown') {
      v = Array.isArray(raw) ? { label_names: raw } : { label_names: [String(raw)] };
    } else if (colType === 'people') {
      v = Array.isArray(raw) ? { user_ids: raw } : { user_ids: [String(raw)] };
    } else if (colType === 'link') {
      v = { url: String(raw) };
    } else {
      return null;
    }
  }

  // Step 2 — resolve to the action-shape the applier consumes.
  if (colType === 'status' || colType === 'priority') {
    // applier expects label_ref (NOT label_id) so the ref-map can
    // round-trip; we resolve name→ref against the column's labels.
    if (typeof v.label_ref === 'string') return { label_ref: v.label_ref };
    const wantName =
      typeof v.label_name === 'string' ? v.label_name :
      typeof v.value      === 'string' ? v.value :
      null;
    if (!wantName) return null;
    const lab = column.labels.find((l) => l.name === wantName);
    return lab ? { label_ref: lab.ref } : null;
  }
  if (colType === 'dropdown') {
    if (Array.isArray(v.label_refs)) return { label_refs: v.label_refs };
    const names =
      Array.isArray(v.label_names) ? v.label_names as unknown[] :
      typeof v.label_name === 'string' ? [v.label_name] :
      Array.isArray(v.value)        ? v.value as unknown[] :
      typeof v.value === 'string'   ? [v.value] :
      null;
    if (!names || !names.every((x) => typeof x === 'string')) return null;
    const refs = (names as string[])
      .map((n) => column.labels.find((l) => l.name === n)?.ref)
      .filter((x): x is string => typeof x === 'string');
    return refs.length > 0 ? { label_refs: refs } : null;
  }
  if (colType === 'people') {
    if (Array.isArray(v.user_ids)) return { user_ids: v.user_ids };
    if (typeof v.user_id === 'string') return { user_ids: [v.user_id] };
    return null;
  }
  if (colType === 'checkbox') {
    if ('checked' in v) return { checked: coerceBool(v.checked) };
    if ('value'   in v) return { checked: coerceBool(v.value) };
    return null;
  }
  if (colType === 'link') {
    if (typeof v.url === 'string') {
      return { url: v.url, ...(typeof v.label === 'string' ? { label: v.label } : {}) };
    }
    return null;
  }
  if (colType === 'date') {
    const s = v.value ?? v.date;
    if (s === undefined || s === null) return null;
    return { value: String(s) };
  }
  if (colType === 'numbers') {
    const candidate = v.value ?? v.num ?? v.number;
    if (candidate === undefined || candidate === null) return null;
    const n = typeof candidate === 'number' ? candidate : Number(candidate);
    if (!Number.isFinite(n)) return null;
    return { value: n };
  }
  if (colType === 'text') {
    const s = v.value ?? v.text ?? v.str ?? v.content;
    if (s === undefined || s === null) return null;
    return { value: String(s) };
  }
  return null;
}

// ----- update_task_name ---------------------------------------------
interface ToolUpdateTaskNameArgs {
  task_id: string;
  new_name: string;
  confirm_sensitive_workspace?: boolean;
}

async function toolUpdateTaskName(
  sb: SupabaseClient,
  args: ToolUpdateTaskNameArgs,
  sensitive: Set<string>,
): Promise<{ task_id: string; board_id: string; workspace_id: string; new_name: string }> {
  if (!args.task_id) throw new Error('task_id is required');
  if (!args.new_name || args.new_name.trim().length === 0) {
    throw new Error('new_name is required');
  }
  const t = await assertTaskBoardAndWorkspace(sb, args.task_id);
  assertWorkspaceWriteAllowed(t.workspaceId, sensitive, args.confirm_sensitive_workspace === true);

  const actor = await getServiceActorId(sb);
  const trimmed = args.new_name.trim();
  const { error } = await sb
    .from('items')
    .update({ name: trimmed, updated_by: actor } as never)
    .eq('id', t.taskId);
  if (error) {
    await logMcpRun(sb, {
      toolName: 'update_task_name', status: 'error',
      workspaceId: t.workspaceId, boardId: t.boardId,
      prompt: trimmed, responseSummary: `update failed: ${error.message}`,
      errorMessage: error.message,
    });
    throw new Error(`items update failed: ${error.message}`);
  }
  await logMcpRun(sb, {
    toolName: 'update_task_name', status: 'success',
    workspaceId: t.workspaceId, boardId: t.boardId,
    prompt: trimmed, responseSummary: `task=${t.taskId} renamed`,
  });
  return { task_id: t.taskId, board_id: t.boardId, workspace_id: t.workspaceId, new_name: trimmed };
}

// =====================================================================
// 3d chunk 2 — create_column
// =====================================================================

interface ToolCreateColumnArgs {
  board_id: string;
  name: string;
  column_type: string;            // includes the long_text/number aliases
  labels?: Array<{ name: string; color?: string }>;
  confirm_sensitive_workspace?: boolean;
}

// Maps caller-supplied type names → the 11-value DB enum.
//   long_text → text   (rendered with a "long" hint via settings)
//   number    → numbers
// task_name is refused (the per-board task_name column is auto-seeded
// by the boards-after-insert trigger; multiple task_name columns are
// blocked by the partial unique index).
function canonicalColumnType(t: string): { type: string; settings: Record<string, unknown> } {
  const lower = t.toLowerCase();
  if (lower === 'task_name') {
    throw new Error('task_name columns are auto-seeded per board; create_column refuses to add another');
  }
  if (lower === 'long_text') return { type: 'text',    settings: { render_hint: 'long' } };
  if (lower === 'number')    return { type: 'numbers', settings: {} };
  const allowed = new Set([
    'text', 'numbers', 'date', 'checkbox', 'link',
    'status', 'priority', 'dropdown', 'people', 'files',
  ]);
  if (!allowed.has(lower)) {
    throw new Error(`unknown column_type "${t}". Allowed: text/long_text, numbers/number, date, checkbox, link, status, priority, dropdown, people`);
  }
  return { type: lower, settings: {} };
}

async function toolCreateColumn(
  sb: SupabaseClient,
  args: ToolCreateColumnArgs,
  sensitive: Set<string>,
): Promise<{
  column_id: string;
  board_id: string;
  workspace_id: string;
  column_type: string;            // canonical (mapped) value the DB stored
  alias_applied?: string;         // present when the caller passed long_text/number
  labels: { id: string; name: string; color: string }[];
}> {
  if (!args.board_id) throw new Error('board_id is required');
  if (!args.name || args.name.trim().length === 0) throw new Error('name is required');
  if (!args.column_type) throw new Error('column_type is required');

  const board = await resolveWorkspaceForBoard(sb, args.board_id);
  assertWorkspaceWriteAllowed(board.workspaceId, sensitive, args.confirm_sensitive_workspace === true);

  const canonical = canonicalColumnType(args.column_type);
  const aliasApplied =
    args.column_type.toLowerCase() === 'long_text' ? 'long_text→text'
    : args.column_type.toLowerCase() === 'number'  ? 'number→numbers'
    : undefined;

  // Next sort_order: 1 + max existing on this board.
  const { data: existing } = await sb
    .from('columns').select('sort_order').eq('board_id', board.boardId);
  const nextSort = ((existing ?? []).reduce(
    (m: number, c: { sort_order: number }) => Math.max(m, c.sort_order), -1,
  )) + 1;

  // Reasonable width defaults per type — mirrors the applier's logic.
  const widthFor = (t: string): number => {
    switch (t) {
      case 'status':
      case 'priority': return 180;
      case 'dropdown': return 200;
      case 'people':   return 160;
      case 'date':
      case 'numbers':  return 140;
      case 'link':     return 220;
      case 'checkbox': return 100;
      case 'text':     return canonical.settings.render_hint === 'long' ? 360 : 220;
      default:         return 180;
    }
  };

  const { data: col, error } = await sb
    .from('columns')
    .insert({
      board_id:    board.boardId,
      name:        args.name.trim(),
      column_type: canonical.type,
      sort_order:  nextSort,
      width:       widthFor(canonical.type),
      settings:    canonical.settings,
    } as never)
    .select('id, column_type')
    .single();
  if (error) {
    await logMcpRun(sb, {
      toolName: 'create_column', status: 'error',
      workspaceId: board.workspaceId, boardId: board.boardId,
      prompt: args.name, responseSummary: `insert failed: ${error.message}`,
      errorMessage: error.message,
    });
    throw new Error(`columns insert failed: ${error.message}`);
  }
  const colId = (col as { id: string }).id;

  // Seed labels only when the type supports them.
  const wantsLabels = ['status', 'priority', 'dropdown'].includes(canonical.type);
  const inserted: { id: string; name: string; color: string }[] = [];
  if (wantsLabels && Array.isArray(args.labels) && args.labels.length > 0) {
    let labelSort = 0;
    for (const l of args.labels) {
      const labelName = l.name.trim();
      // Canonical-hex normalisation: caller-supplied colors go through
      // the normaliser; missing colors get a smart default by label
      // name + this column's type/name. Either way the DB lands hex.
      const color = l.color
        ? toCanonicalHex(l.color)
        : defaultLabelHexFor({
            columnType: canonical.type,
            columnName: args.name,
            labelName,
            positionInColumn: labelSort,
            totalInColumn:    (args.labels?.length ?? 0),
          });
      const { data, error: lErr } = await sb
        .from('column_labels')
        .insert({
          column_id:  colId,
          name:       labelName,
          color,
          sort_order: labelSort,
        } as never)
        .select('id, name, color')
        .single();
      if (lErr) {
        // Surface but don't roll back the column — partial seeding is
        // explicit in the response.
        console.error('[create_column] label insert failed:', lErr.message);
        continue;
      }
      const row = data as { id: string; name: string; color: string };
      inserted.push(row);
      labelSort += 1;
    }
  }

  await logMcpRun(sb, {
    toolName: 'create_column', status: 'success',
    workspaceId: board.workspaceId, boardId: board.boardId,
    prompt: `${args.name} (${args.column_type})`,
    responseSummary: `col=${colId} type=${canonical.type} labels=${inserted.length}` +
      (aliasApplied ? ` alias=${aliasApplied}` : ''),
  });

  return {
    column_id:    colId,
    board_id:     board.boardId,
    workspace_id: board.workspaceId,
    column_type:  canonical.type,
    ...(aliasApplied ? { alias_applied: aliasApplied } : {}),
    labels:       inserted,
  };
}

// =====================================================================
// 3d chunk 3 — group ops
// =====================================================================

interface ToolCreateGroupArgs {
  board_id: string;
  name: string;
  color?: string;
  confirm_sensitive_workspace?: boolean;
}

async function toolCreateGroup(
  sb: SupabaseClient,
  args: ToolCreateGroupArgs,
  sensitive: Set<string>,
): Promise<{ group_id: string; board_id: string; workspace_id: string }> {
  if (!args.board_id) throw new Error('board_id is required');
  if (!args.name || args.name.trim().length === 0) throw new Error('name is required');

  const board = await resolveWorkspaceForBoard(sb, args.board_id);
  assertWorkspaceWriteAllowed(board.workspaceId, sensitive, args.confirm_sensitive_workspace === true);

  const { data: existing } = await sb
    .from('groups').select('sort_order').eq('board_id', board.boardId).is('deleted_at', null);
  const nextSort = ((existing ?? []).reduce(
    (m: number, g: { sort_order: number }) => Math.max(m, g.sort_order), -1,
  )) + 1;

  const { data, error } = await sb
    .from('groups')
    .insert({
      board_id:   board.boardId,
      name:       args.name.trim(),
      color:      (args.color && args.color.trim()) ? args.color.trim() : '#579BFC',
      sort_order: nextSort,
    } as never)
    .select('id')
    .single();
  if (error) {
    await logMcpRun(sb, {
      toolName: 'create_group', status: 'error',
      workspaceId: board.workspaceId, boardId: board.boardId,
      prompt: args.name, responseSummary: `insert failed: ${error.message}`,
      errorMessage: error.message,
    });
    throw new Error(`groups insert failed: ${error.message}`);
  }
  const gid = (data as { id: string }).id;
  await logMcpRun(sb, {
    toolName: 'create_group', status: 'success',
    workspaceId: board.workspaceId, boardId: board.boardId,
    prompt: args.name, responseSummary: `group_id=${gid}`,
  });
  return { group_id: gid, board_id: board.boardId, workspace_id: board.workspaceId };
}

interface ToolRenameGroupArgs {
  group_id: string;
  new_name: string;
  confirm_sensitive_workspace?: boolean;
}

async function toolRenameGroup(
  sb: SupabaseClient,
  args: ToolRenameGroupArgs,
  sensitive: Set<string>,
): Promise<{ group_id: string; board_id: string; workspace_id: string; new_name: string }> {
  if (!args.group_id) throw new Error('group_id is required');
  if (!args.new_name || args.new_name.trim().length === 0) throw new Error('new_name is required');

  // Resolve group → board → workspace inline (mcp-tenancy.ts has
  // assertGroupInBoard for the "I claim board X" pattern, but here we
  // only have group_id and need to discover the board ourselves).
  const { data: g, error: gErr } = await sb
    .from('groups')
    .select('id, board_id, deleted_at')
    .eq('id', args.group_id)
    .maybeSingle();
  if (gErr) throw new Error(`groups select failed: ${gErr.message}`);
  if (!g) throw new TenancyError(`Group ${args.group_id} not found`);
  const groupRow = g as { id: string; board_id: string; deleted_at: string | null };
  if (groupRow.deleted_at) throw new TenancyError(`Group ${args.group_id} is deleted`);

  const board = await resolveWorkspaceForBoard(sb, groupRow.board_id);
  assertWorkspaceWriteAllowed(board.workspaceId, sensitive, args.confirm_sensitive_workspace === true);

  const trimmed = args.new_name.trim();
  const { error } = await sb
    .from('groups').update({ name: trimmed } as never).eq('id', groupRow.id);
  if (error) {
    await logMcpRun(sb, {
      toolName: 'rename_group', status: 'error',
      workspaceId: board.workspaceId, boardId: board.boardId,
      prompt: trimmed, responseSummary: error.message,
      errorMessage: error.message,
    });
    throw new Error(`groups update failed: ${error.message}`);
  }
  await logMcpRun(sb, {
    toolName: 'rename_group', status: 'success',
    workspaceId: board.workspaceId, boardId: board.boardId,
    prompt: trimmed, responseSummary: `group=${groupRow.id} renamed`,
  });
  return { group_id: groupRow.id, board_id: board.boardId, workspace_id: board.workspaceId, new_name: trimmed };
}

interface ToolDeleteGroupArgs {
  group_id: string;
  confirm_delete?: boolean;
  confirm_delete_with_tasks?: boolean;
  confirm_sensitive_workspace?: boolean;
}

async function toolDeleteGroup(
  sb: SupabaseClient,
  args: ToolDeleteGroupArgs,
  sensitive: Set<string>,
): Promise<{
  group_id: string; board_id: string; workspace_id: string;
  deleted_at: string; tasks_in_group: number;
}> {
  if (!args.group_id) throw new Error('group_id is required');
  if (args.confirm_delete !== true) {
    throw new Error('delete_group refuses without confirm_delete: true (soft-delete is reversible — but still requires explicit consent)');
  }

  const { data: g, error: gErr } = await sb
    .from('groups')
    .select('id, board_id, deleted_at, name')
    .eq('id', args.group_id)
    .maybeSingle();
  if (gErr) throw new Error(`groups select failed: ${gErr.message}`);
  if (!g) throw new TenancyError(`Group ${args.group_id} not found`);
  const groupRow = g as { id: string; board_id: string; deleted_at: string | null; name: string };
  if (groupRow.deleted_at) throw new Error(`Group ${args.group_id} is already soft-deleted`);

  const board = await resolveWorkspaceForBoard(sb, groupRow.board_id);
  assertWorkspaceWriteAllowed(board.workspaceId, sensitive, args.confirm_sensitive_workspace === true);

  // Count non-deleted tasks in this group; gate via confirm_delete_with_tasks.
  const { count: liveTasks } = await sb
    .from('items')
    .select('id', { count: 'exact', head: true })
    .eq('group_id', groupRow.id)
    .is('deleted_at', null);
  const taskCount = liveTasks ?? 0;
  if (taskCount > 0 && args.confirm_delete_with_tasks !== true) {
    throw new Error(
      `Group "${groupRow.name}" still has ${taskCount} non-deleted task` +
      `${taskCount === 1 ? '' : 's'}. To soft-delete it anyway, pass ` +
      `confirm_delete_with_tasks: true. (Tasks stay rows in the DB; they ` +
      `just become orphaned in a soft-deleted group.)`,
    );
  }

  const stamp = new Date().toISOString();
  const { error } = await sb
    .from('groups').update({ deleted_at: stamp } as never).eq('id', groupRow.id);
  if (error) {
    await logMcpRun(sb, {
      toolName: 'delete_group', status: 'error',
      workspaceId: board.workspaceId, boardId: board.boardId,
      prompt: groupRow.name, responseSummary: error.message,
      errorMessage: error.message,
    });
    throw new Error(`groups soft-delete failed: ${error.message}`);
  }
  await logMcpRun(sb, {
    toolName: 'delete_group', status: 'success',
    workspaceId: board.workspaceId, boardId: board.boardId,
    prompt: groupRow.name,
    responseSummary: `group=${groupRow.id} soft-deleted, tasks_in_group=${taskCount}`,
  });
  return {
    group_id:       groupRow.id,
    board_id:       board.boardId,
    workspace_id:   board.workspaceId,
    deleted_at:     stamp,
    tasks_in_group: taskCount,
  };
}

// =====================================================================
// 3d chunk 4 — delete_task (soft)
// =====================================================================

interface ToolDeleteTaskArgs {
  task_id: string;
  confirm_delete?: boolean;
  confirm_sensitive_workspace?: boolean;
}

async function toolDeleteTask(
  sb: SupabaseClient,
  args: ToolDeleteTaskArgs,
  sensitive: Set<string>,
): Promise<{ task_id: string; board_id: string; workspace_id: string; deleted_at: string }> {
  if (!args.task_id) throw new Error('task_id is required');
  if (args.confirm_delete !== true) {
    throw new Error('delete_task refuses without confirm_delete: true. Soft-delete is reversible but still requires explicit consent.');
  }

  const t = await assertTaskBoardAndWorkspace(sb, args.task_id);
  assertWorkspaceWriteAllowed(t.workspaceId, sensitive, args.confirm_sensitive_workspace === true);

  // Already soft-deleted? Surface a friendly error.
  const { data: cur } = await sb
    .from('items').select('deleted_at, name').eq('id', t.taskId).maybeSingle();
  const curRow = cur as { deleted_at: string | null; name: string } | null;
  if (curRow?.deleted_at) {
    throw new Error(`Task ${t.taskId} is already soft-deleted (deleted_at=${curRow.deleted_at})`);
  }

  const stamp = new Date().toISOString();
  const actor = await getServiceActorId(sb);
  const { error } = await sb
    .from('items')
    .update({ deleted_at: stamp, updated_by: actor } as never)
    .eq('id', t.taskId);
  if (error) {
    await logMcpRun(sb, {
      toolName: 'delete_task', status: 'error',
      workspaceId: t.workspaceId, boardId: t.boardId,
      prompt: curRow?.name ?? t.taskId,
      responseSummary: error.message, errorMessage: error.message,
    });
    throw new Error(`items soft-delete failed: ${error.message}`);
  }
  await logMcpRun(sb, {
    toolName: 'delete_task', status: 'success',
    workspaceId: t.workspaceId, boardId: t.boardId,
    prompt: curRow?.name ?? t.taskId,
    responseSummary: `task=${t.taskId} soft-deleted`,
  });
  return { task_id: t.taskId, board_id: t.boardId, workspace_id: t.workspaceId, deleted_at: stamp };
}

// =====================================================================
// 3d chunk 5 — board ops (rename / archive / soft-delete)
// =====================================================================

interface ToolRenameBoardArgs {
  board_id: string;
  new_name: string;
  confirm_sensitive_workspace?: boolean;
}

async function toolRenameBoard(
  sb: SupabaseClient,
  args: ToolRenameBoardArgs,
  sensitive: Set<string>,
): Promise<{ board_id: string; workspace_id: string; new_name: string }> {
  if (!args.board_id) throw new Error('board_id is required');
  if (!args.new_name || args.new_name.trim().length === 0) throw new Error('new_name is required');

  const board = await resolveWorkspaceForBoard(sb, args.board_id);
  assertWorkspaceWriteAllowed(board.workspaceId, sensitive, args.confirm_sensitive_workspace === true);

  const trimmed = args.new_name.trim();
  const { error } = await sb
    .from('boards').update({ name: trimmed } as never).eq('id', board.boardId);
  if (error) {
    await logMcpRun(sb, {
      toolName: 'rename_board', status: 'error',
      workspaceId: board.workspaceId, boardId: board.boardId,
      prompt: trimmed, responseSummary: error.message, errorMessage: error.message,
    });
    throw new Error(`boards update failed: ${error.message}`);
  }
  await logMcpRun(sb, {
    toolName: 'rename_board', status: 'success',
    workspaceId: board.workspaceId, boardId: board.boardId,
    prompt: trimmed, responseSummary: `board=${board.boardId} renamed`,
  });
  return { board_id: board.boardId, workspace_id: board.workspaceId, new_name: trimmed };
}

interface ToolArchiveBoardArgs {
  board_id: string;
  restore?: boolean;
  confirm_sensitive_workspace?: boolean;
}

async function toolArchiveBoard(
  sb: SupabaseClient,
  args: ToolArchiveBoardArgs,
  sensitive: Set<string>,
): Promise<{ board_id: string; workspace_id: string; archived_at: string | null }> {
  if (!args.board_id) throw new Error('board_id is required');

  const board = await resolveWorkspaceForBoard(sb, args.board_id);
  assertWorkspaceWriteAllowed(board.workspaceId, sensitive, args.confirm_sensitive_workspace === true);

  const restore = args.restore === true;
  const stamp = restore ? null : new Date().toISOString();
  const { error } = await sb
    .from('boards').update({ archived_at: stamp } as never).eq('id', board.boardId);
  if (error) {
    await logMcpRun(sb, {
      toolName: 'archive_board', status: 'error',
      workspaceId: board.workspaceId, boardId: board.boardId,
      prompt: restore ? '(restore)' : '(archive)',
      responseSummary: error.message, errorMessage: error.message,
    });
    throw new Error(`boards archive update failed: ${error.message}`);
  }
  await logMcpRun(sb, {
    toolName: 'archive_board', status: 'success',
    workspaceId: board.workspaceId, boardId: board.boardId,
    prompt: restore ? '(restore)' : '(archive)',
    responseSummary: restore ? 'archived_at cleared' : `archived_at=${stamp}`,
  });
  return { board_id: board.boardId, workspace_id: board.workspaceId, archived_at: stamp };
}

interface ToolDeleteBoardArgs {
  board_id: string;
  confirm_delete?: boolean;
  confirm_sensitive_workspace?: boolean;
}

async function toolDeleteBoard(
  sb: SupabaseClient,
  args: ToolDeleteBoardArgs,
  sensitive: Set<string>,
): Promise<{ board_id: string; workspace_id: string; deleted_at: string }> {
  if (!args.board_id) throw new Error('board_id is required');
  if (args.confirm_delete !== true) {
    throw new Error('delete_board refuses without confirm_delete: true. Soft-delete is reversible but still requires explicit consent.');
  }

  const board = await resolveWorkspaceForBoard(sb, args.board_id);
  assertWorkspaceWriteAllowed(board.workspaceId, sensitive, args.confirm_sensitive_workspace === true);

  // Already soft-deleted? resolveWorkspaceForBoard already filters those
  // out, so reaching here means the board is live.
  const stamp = new Date().toISOString();
  const { error } = await sb
    .from('boards').update({ deleted_at: stamp } as never).eq('id', board.boardId);
  if (error) {
    await logMcpRun(sb, {
      toolName: 'delete_board', status: 'error',
      workspaceId: board.workspaceId, boardId: board.boardId,
      prompt: '(soft-delete)', responseSummary: error.message, errorMessage: error.message,
    });
    throw new Error(`boards soft-delete failed: ${error.message}`);
  }
  await logMcpRun(sb, {
    toolName: 'delete_board', status: 'success',
    workspaceId: board.workspaceId, boardId: board.boardId,
    prompt: '(soft-delete)', responseSummary: `board=${board.boardId} soft-deleted`,
  });
  return { board_id: board.boardId, workspace_id: board.workspaceId, deleted_at: stamp };
}

// =====================================================================
// 3d chunk 6 — create_workspace
// =====================================================================

interface ToolCreateWorkspaceArgs {
  name: string;
  icon_emoji?: string;
  icon_color?: string;
}

async function toolCreateWorkspace(
  sb: SupabaseClient,
  args: ToolCreateWorkspaceArgs,
): Promise<{ workspace_id: string; name: string; icon_emoji: string; icon_color: string }> {
  if (!args.name || args.name.trim().length === 0) throw new Error('name is required');

  // is_main is ALWAYS false here — the schema has a partial unique index
  // (workspaces_only_one_main) preventing more than one main workspace,
  // and the seeded "Main workspace" already holds that slot.
  const insert = {
    name:       args.name.trim(),
    icon_emoji: args.icon_emoji ?? '🏠',
    icon_color: args.icon_color ?? '#0073EA',
    is_main:    false,
  };
  const { data, error } = await sb
    .from('workspaces')
    .insert(insert as never)
    .select('id, name, icon_emoji, icon_color')
    .single();
  if (error) {
    await logMcpRun(sb, {
      toolName: 'create_workspace', status: 'error',
      workspaceId: null, boardId: null,
      prompt: args.name, responseSummary: error.message, errorMessage: error.message,
    });
    throw new Error(`workspaces insert failed: ${error.message}`);
  }
  const row = data as { id: string; name: string; icon_emoji: string; icon_color: string };
  await logMcpRun(sb, {
    toolName: 'create_workspace', status: 'success',
    workspaceId: row.id, boardId: null,
    prompt: args.name, responseSummary: `workspace_id=${row.id}`,
  });
  return {
    workspace_id: row.id,
    name:         row.name,
    icon_emoji:   row.icon_emoji,
    icon_color:   row.icon_color,
  };
}

// =====================================================================
// 3d follow-up #2 — column management
// =====================================================================

interface ToolAddColumnLabelArgs {
  column_id?: string;
  board_id?: string;
  column_name?: string;
  labels: Array<{ name: string; color?: string }>;
  confirm_sensitive_workspace?: boolean;
}

async function toolAddColumnLabel(
  sb: SupabaseClient,
  args: ToolAddColumnLabelArgs,
  sensitive: Set<string>,
): Promise<{
  column_id: string;
  column_name: string;
  column_type: string;
  board_id: string;
  workspace_id: string;
  inserted: Array<{ id: string; name: string; color: string; sort_order: number }>;
}> {
  if (!Array.isArray(args.labels) || args.labels.length === 0) {
    throw new Error('labels[] is required (at least one)');
  }

  // Resolve the column: column_id wins; else require board_id + column_name.
  let columnRow: { id: string; name: string; column_type: string; board_id: string } | null = null;
  if (args.column_id) {
    const { data, error } = await sb
      .from('columns')
      .select('id, name, column_type, board_id, archived_at')
      .eq('id', args.column_id)
      .maybeSingle();
    if (error) throw new Error(`columns select failed: ${error.message}`);
    if (!data) throw new TenancyError(`Column ${args.column_id} not found`);
    const row = data as { id: string; name: string; column_type: string; board_id: string; archived_at: string | null };
    if (row.archived_at) throw new Error(`Column ${args.column_id} is archived`);
    columnRow = { id: row.id, name: row.name, column_type: row.column_type, board_id: row.board_id };
  } else {
    if (!args.board_id || !args.column_name) {
      throw new Error('Pass either column_id, or (board_id + column_name)');
    }
    const { data, error } = await sb
      .from('columns')
      .select('id, name, column_type, board_id')
      .eq('board_id', args.board_id)
      .eq('name', args.column_name)
      .is('archived_at', null)
      .maybeSingle();
    if (error) throw new Error(`columns select failed: ${error.message}`);
    if (!data) throw new TenancyError(`Column "${args.column_name}" not found on board ${args.board_id}`);
    columnRow = data as { id: string; name: string; column_type: string; board_id: string };
  }

  // Refuse non-labelable column types.
  if (!['status', 'priority', 'dropdown'].includes(columnRow.column_type)) {
    throw new Error(
      `Column "${columnRow.name}" is a ${columnRow.column_type} column; labels only apply to ` +
      `status/priority/dropdown. Use create_column to add a labeled column, or update_task_cell ` +
      `to write a value into this one.`,
    );
  }

  // Tenancy chain: board → workspace.
  const board = await resolveWorkspaceForBoard(sb, columnRow.board_id);
  assertWorkspaceWriteAllowed(board.workspaceId, sensitive, args.confirm_sensitive_workspace === true);

  // Next sort_order: max existing + 1 (so new labels append to the bottom of
  // the picker, never reordering existing ones).
  const { data: existing } = await sb
    .from('column_labels')
    .select('sort_order')
    .eq('column_id', columnRow.id);
  let nextSort = ((existing ?? []).reduce(
    (m: number, l: { sort_order: number }) => Math.max(m, l.sort_order), -1,
  )) + 1;

  const inserted: Array<{ id: string; name: string; color: string; sort_order: number }> = [];
  for (const l of args.labels) {
    const name  = l.name.trim();
    if (!name) continue;
    // Caller-supplied color (any form) → canonical hex via the
    // normaliser. If no color was given, fall back to the smart default
    // based on label name + column type (matches the UI's create-time
    // intent). Either way the DB lands a #RRGGBB string.
    const color = l.color
      ? toCanonicalHex(l.color)
      : defaultLabelHexFor({
          columnType: columnRow.column_type,
          columnName: columnRow.name,
          labelName:  name,
          positionInColumn: nextSort,
          totalInColumn:    nextSort + 1,
        });
    const { data, error } = await sb
      .from('column_labels')
      .insert({ column_id: columnRow.id, name, color, sort_order: nextSort } as never)
      .select('id, name, color, sort_order')
      .single();
    if (error) {
      // Surface the first insert failure but don't roll back what we already
      // inserted — the response carries the partial list.
      await logMcpRun(sb, {
        toolName: 'add_column_label', status: 'error',
        workspaceId: board.workspaceId, boardId: board.boardId,
        prompt: `${columnRow.name} ← ${name}`,
        responseSummary: `insert failed at "${name}": ${error.message}; partial=${inserted.length}`,
        errorMessage: error.message,
      });
      throw new Error(`column_labels insert failed for "${name}": ${error.message}. ` +
        `${inserted.length} earlier label(s) DID land — re-call with the remaining labels only to retry.`);
    }
    inserted.push(data as { id: string; name: string; color: string; sort_order: number });
    nextSort += 1;
  }

  await logMcpRun(sb, {
    toolName: 'add_column_label', status: 'success',
    workspaceId: board.workspaceId, boardId: board.boardId,
    prompt: `${columnRow.name} ← ${inserted.map((l) => l.name).join(', ')}`,
    responseSummary: `col=${columnRow.id} added=${inserted.length}`,
  });

  return {
    column_id:    columnRow.id,
    column_name:  columnRow.name,
    column_type:  columnRow.column_type,
    board_id:     board.boardId,
    workspace_id: board.workspaceId,
    inserted,
  };
}

interface ToolDeleteColumnArgs {
  column_id: string;
  confirm_delete?: boolean;
  confirm_sensitive_workspace?: boolean;
}

async function toolDeleteColumn(
  sb: SupabaseClient,
  args: ToolDeleteColumnArgs,
  sensitive: Set<string>,
): Promise<{ column_id: string; column_name: string; board_id: string; workspace_id: string; archived_at: string }> {
  if (!args.column_id) throw new Error('column_id is required');
  if (args.confirm_delete !== true) {
    throw new Error('delete_column refuses without confirm_delete: true. Soft-deletes are reversible (clear archived_at) but still require explicit consent.');
  }

  const { data: col, error: cErr } = await sb
    .from('columns')
    .select('id, name, column_type, board_id, archived_at')
    .eq('id', args.column_id)
    .maybeSingle();
  if (cErr) throw new Error(`columns select failed: ${cErr.message}`);
  if (!col) throw new TenancyError(`Column ${args.column_id} not found`);
  const colRow = col as { id: string; name: string; column_type: string; board_id: string; archived_at: string | null };

  // Refuse on task_name columns at the tool level (the DB trigger
  // guard_task_name_column blocks DELETE; we're doing a soft-delete so
  // the trigger wouldn't fire, but the intent is the same: task_name is
  // required per board).
  if (colRow.column_type === 'task_name') {
    throw new Error(
      `Refusing to soft-delete column "${colRow.name}" — it's the task_name column, ` +
      `which is required per board (matches the DB-side guard_task_name_column trigger\'s intent).`,
    );
  }
  if (colRow.archived_at) {
    throw new Error(`Column "${colRow.name}" is already archived (archived_at=${colRow.archived_at})`);
  }

  const board = await resolveWorkspaceForBoard(sb, colRow.board_id);
  assertWorkspaceWriteAllowed(board.workspaceId, sensitive, args.confirm_sensitive_workspace === true);

  const stamp = new Date().toISOString();
  const { error } = await sb
    .from('columns')
    .update({ archived_at: stamp } as never)
    .eq('id', colRow.id);
  if (error) {
    await logMcpRun(sb, {
      toolName: 'delete_column', status: 'error',
      workspaceId: board.workspaceId, boardId: board.boardId,
      prompt: colRow.name, responseSummary: error.message, errorMessage: error.message,
    });
    throw new Error(`columns soft-delete failed: ${error.message}`);
  }
  await logMcpRun(sb, {
    toolName: 'delete_column', status: 'success',
    workspaceId: board.workspaceId, boardId: board.boardId,
    prompt: colRow.name, responseSummary: `col=${colRow.id} archived`,
  });
  return {
    column_id:    colRow.id,
    column_name:  colRow.name,
    board_id:     board.boardId,
    workspace_id: board.workspaceId,
    archived_at:  stamp,
  };
}

interface ToolRenameColumnArgs {
  column_id: string;
  new_name: string;
  confirm_sensitive_workspace?: boolean;
}

async function toolRenameColumn(
  sb: SupabaseClient,
  args: ToolRenameColumnArgs,
  sensitive: Set<string>,
): Promise<{ column_id: string; board_id: string; workspace_id: string; new_name: string }> {
  if (!args.column_id) throw new Error('column_id is required');
  if (!args.new_name || args.new_name.trim().length === 0) throw new Error('new_name is required');

  const { data: col, error: cErr } = await sb
    .from('columns')
    .select('id, board_id, archived_at')
    .eq('id', args.column_id)
    .maybeSingle();
  if (cErr) throw new Error(`columns select failed: ${cErr.message}`);
  if (!col) throw new TenancyError(`Column ${args.column_id} not found`);
  const colRow = col as { id: string; board_id: string; archived_at: string | null };
  if (colRow.archived_at) throw new Error(`Column ${args.column_id} is archived`);

  const board = await resolveWorkspaceForBoard(sb, colRow.board_id);
  assertWorkspaceWriteAllowed(board.workspaceId, sensitive, args.confirm_sensitive_workspace === true);

  const trimmed = args.new_name.trim();
  const { error } = await sb
    .from('columns').update({ name: trimmed } as never).eq('id', colRow.id);
  if (error) {
    await logMcpRun(sb, {
      toolName: 'rename_column', status: 'error',
      workspaceId: board.workspaceId, boardId: board.boardId,
      prompt: trimmed, responseSummary: error.message, errorMessage: error.message,
    });
    throw new Error(`columns update failed: ${error.message}`);
  }
  await logMcpRun(sb, {
    toolName: 'rename_column', status: 'success',
    workspaceId: board.workspaceId, boardId: board.boardId,
    prompt: trimmed,
    responseSummary: `col=${colRow.id} renamed`,
  });
  return { column_id: colRow.id, board_id: board.boardId, workspace_id: board.workspaceId, new_name: trimmed };
}

// =====================================================================
// Label color fix — update_column_label
// =====================================================================
//
// Rename and/or recolor an existing column_labels row. Closes the gap
// where the agent could ADD a label (add_column_label) but had no way
// to fix one without re-creating it. Color is normalised to canonical
// hex via toCanonicalHex so every write path converges on one format.
//
// Resolution order:
//   1. label_id (preferred — direct match)
//   2. board_id + column_name + current_label_name (for LLM agents
//      that have names but not ids)

interface ToolUpdateColumnLabelArgs {
  label_id?: string;
  board_id?: string;
  column_name?: string;
  current_label_name?: string;
  new_name?: string;
  color?: string;
  confirm_sensitive_workspace?: boolean;
}

async function toolUpdateColumnLabel(
  sb: SupabaseClient,
  args: ToolUpdateColumnLabelArgs,
  sensitive: Set<string>,
): Promise<{
  label_id: string;
  column_id: string;
  column_name: string;
  board_id: string;
  workspace_id: string;
  before: { name: string; color: string };
  after:  { name: string; color: string };
}> {
  if (!args.new_name && !args.color) {
    throw new Error('one of new_name or color must be supplied');
  }

  // Resolve the label row.
  let labelRow: { id: string; column_id: string; name: string; color: string } | null = null;
  if (args.label_id) {
    const { data, error } = await sb
      .from('column_labels')
      .select('id, column_id, name, color')
      .eq('id', args.label_id)
      .maybeSingle();
    if (error) throw new Error(`column_labels select failed: ${error.message}`);
    if (!data) throw new TenancyError(`Label ${args.label_id} not found`);
    labelRow = data as { id: string; column_id: string; name: string; color: string };
  } else {
    if (!args.board_id || !args.column_name || !args.current_label_name) {
      throw new Error('Pass either label_id, or (board_id + column_name + current_label_name)');
    }
    // (board, column_name) → column_id  →  (column_id, current_label_name) → label
    const { data: col, error: cErr } = await sb
      .from('columns')
      .select('id, board_id, archived_at')
      .eq('board_id', args.board_id)
      .eq('name', args.column_name)
      .is('archived_at', null)
      .maybeSingle();
    if (cErr) throw new Error(`columns select failed: ${cErr.message}`);
    if (!col) throw new TenancyError(`Column "${args.column_name}" not found on board ${args.board_id}`);
    const colId = (col as { id: string }).id;
    const { data: lab, error: lErr } = await sb
      .from('column_labels')
      .select('id, column_id, name, color')
      .eq('column_id', colId)
      .eq('name', args.current_label_name)
      .maybeSingle();
    if (lErr) throw new Error(`column_labels select failed: ${lErr.message}`);
    if (!lab) throw new TenancyError(`Label "${args.current_label_name}" not found on column "${args.column_name}"`);
    labelRow = lab as { id: string; column_id: string; name: string; color: string };
  }

  // Resolve the column → board → workspace chain for tenancy.
  const { data: colData, error: colErr } = await sb
    .from('columns')
    .select('id, board_id, name')
    .eq('id', labelRow.column_id)
    .maybeSingle();
  if (colErr) throw new Error(`columns select failed: ${colErr.message}`);
  if (!colData) throw new TenancyError(`Parent column ${labelRow.column_id} not found`);
  const colMeta = colData as { id: string; board_id: string; name: string };
  const board = await resolveWorkspaceForBoard(sb, colMeta.board_id);
  assertWorkspaceWriteAllowed(board.workspaceId, sensitive, args.confirm_sensitive_workspace === true);

  const before = { name: labelRow.name, color: labelRow.color };
  const patch: Record<string, unknown> = {};
  if (args.new_name && args.new_name.trim() !== labelRow.name) {
    patch.name = args.new_name.trim();
  }
  if (args.color) {
    const hex = toCanonicalHex(args.color);
    if (hex !== labelRow.color.toUpperCase() && hex !== labelRow.color) {
      patch.color = hex;
    }
  }
  if (Object.keys(patch).length === 0) {
    // Nothing actually changed — surface a no-op success rather than throwing.
    await logMcpRun(sb, {
      toolName: 'update_column_label', status: 'success',
      workspaceId: board.workspaceId, boardId: board.boardId,
      prompt: `${colMeta.name}.${labelRow.name}`,
      responseSummary: 'no-op (already at requested values)',
    });
    return {
      label_id: labelRow.id, column_id: labelRow.column_id,
      column_name: colMeta.name, board_id: board.boardId, workspace_id: board.workspaceId,
      before, after: before,
    };
  }

  const { error } = await sb
    .from('column_labels').update(patch as never).eq('id', labelRow.id);
  if (error) {
    await logMcpRun(sb, {
      toolName: 'update_column_label', status: 'error',
      workspaceId: board.workspaceId, boardId: board.boardId,
      prompt: `${colMeta.name}.${labelRow.name}`,
      responseSummary: error.message, errorMessage: error.message,
    });
    throw new Error(`column_labels update failed: ${error.message}`);
  }
  const after = {
    name:  (patch.name as string | undefined)  ?? labelRow.name,
    color: (patch.color as string | undefined) ?? labelRow.color,
  };
  await logMcpRun(sb, {
    toolName: 'update_column_label', status: 'success',
    workspaceId: board.workspaceId, boardId: board.boardId,
    prompt: `${colMeta.name}.${labelRow.name}`,
    responseSummary: `name="${after.name}" color=${after.color}`,
  });
  return {
    label_id:     labelRow.id,
    column_id:    labelRow.column_id,
    column_name:  colMeta.name,
    board_id:     board.boardId,
    workspace_id: board.workspaceId,
    before,
    after,
  };
}

// Minimal HTML-escape for the plain-text path. Updates body_html is
// rendered through the UI's prose pipeline which already escapes, but
// we don't want raw '<' / '>' to break the rendered markup when the
// caller passes plain text.
function escapeHtml(s: string): string {
  return s
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

// =====================================================================
// Shared internal helpers used by the write tools
// =====================================================================

// Build the EngineContext snapshot for a board — same shape api/ai-build.ts
// constructs for Gemini. The applier consumes this to seed its refMap.
// Refs are deterministic: prefix_slug(name)_<id4> — duplicates with the
// same name still get unique refs because of the id suffix.
async function fetchBoardContext(sb: SupabaseClient, boardId: string): Promise<EngineContext> {
  const { data: board } = await sb.from('boards').select('id, name').eq('id', boardId).maybeSingle();
  const ctx: EngineContext = {
    board_id: boardId,
    board_name: (board as { name?: string } | null)?.name ?? '',
    groups: [],
    columns: [],
  };
  const [{ data: groups }, { data: columns }] = await Promise.all([
    sb.from('groups').select('id, name, color').eq('board_id', boardId).is('deleted_at', null).order('sort_order'),
    sb.from('columns').select('id, name, column_type').eq('board_id', boardId).is('archived_at', null).order('sort_order'),
  ]);
  ctx.groups = (groups ?? []).map((g) => ({
    id: g.id, ref: refFor('g', g.name, g.id), name: g.name, color: g.color,
  })) as EngineContext['groups'];
  const colIds = (columns ?? []).map((c) => c.id);
  let labelsByCol = new Map<string, { id: string; name: string; color: string }[]>();
  if (colIds.length > 0) {
    const { data: labels } = await sb
      .from('column_labels')
      .select('id, column_id, name, color')
      .in('column_id', colIds);
    for (const l of (labels ?? []) as { id: string; column_id: string; name: string; color: string }[]) {
      const list = labelsByCol.get(l.column_id) ?? [];
      list.push({ id: l.id, name: l.name, color: l.color });
      labelsByCol.set(l.column_id, list);
    }
  }
  ctx.columns = (columns ?? []).map((c) => ({
    id: c.id,
    ref: refFor('c', c.name, c.id),
    name: c.name,
    column_type: c.column_type,
    labels: (labelsByCol.get(c.id) ?? []).map((l) => ({
      id: l.id, ref: refFor('l', l.name, l.id), name: l.name, color: l.color,
    })),
  })) as EngineContext['columns'];
  return ctx;
}

function refFor(prefix: string, name: string, id: string): string {
  const slug = name
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '_')
    .replace(/^_+|_+$/g, '')
    .slice(0, 32) || 'x';
  return `${prefix}_${slug}_${id.slice(0, 4)}`;
}

// Cached: the first admin user's id. Used as the actor for created_by /
// updated_by on MCP-originated rows. See mcp-logging.ts for the same
// cache (intentional duplication — the two caches are independent and
// each module can be reused standalone).
const SERVICE_ACTOR_CACHE: { id: string | null } = { id: null };
async function getServiceActorId(sb: SupabaseClient): Promise<string> {
  if (SERVICE_ACTOR_CACHE.id) return SERVICE_ACTOR_CACHE.id;
  const { data, error } = await sb
    .from('users')
    .select('id')
    .eq('role', 'admin')
    .eq('status', 'active')
    .order('created_at', { ascending: true })
    .limit(1)
    .maybeSingle();
  if (error) throw new Error(`could not resolve service actor: ${error.message}`);
  const id = (data as { id?: string } | null)?.id;
  if (!id) throw new Error('no admin user available to act as MCP service actor');
  SERVICE_ACTOR_CACHE.id = id;
  return id;
}

// =====================================================================
// Helpers
// =====================================================================

// req.body can be a string, parsed object, or undefined depending on
// Content-Type. Same gotcha api/ai-build.ts already handles — copying
// that pattern so MCP messages from any client (curl, fetch, inspector)
// land cleanly.
type ParseOk = { payload: unknown };
type ParseFail = { parseError: string };
function parseRequestBody(body: unknown): ParseOk | ParseFail {
  if (body == null) return { parseError: 'request body is required' };
  if (typeof body === 'string') {
    if (body.trim().length === 0) return { parseError: 'request body is empty' };
    try { return { payload: JSON.parse(body) }; }
    catch (e) {
      return { parseError: `body is not valid JSON: ${e instanceof Error ? e.message : String(e)}` };
    }
  }
  if (typeof body === 'object') return { payload: body };
  return { parseError: `unexpected body type: ${typeof body}` };
}

function isJsonRpcRequest(x: unknown): x is JsonRpcRequest {
  if (!x || typeof x !== 'object') return false;
  const r = x as Record<string, unknown>;
  return r.jsonrpc === '2.0' && typeof r.method === 'string';
}

// Constant-time string compare to avoid leaking bearer length via
// early-exit timing. Standard pattern.
function constantTimeEquals(a: string, b: string): boolean {
  if (a.length !== b.length) {
    // Still walk one of the strings so the timing is roughly even.
    let acc = 1;
    for (let i = 0; i < a.length; i += 1) acc |= a.charCodeAt(i) ^ 0;
    return acc === 0;
  }
  let diff = 0;
  for (let i = 0; i < a.length; i += 1) diff |= a.charCodeAt(i) ^ b.charCodeAt(i);
  return diff === 0;
}

Deno.serve(vercel(handler));
