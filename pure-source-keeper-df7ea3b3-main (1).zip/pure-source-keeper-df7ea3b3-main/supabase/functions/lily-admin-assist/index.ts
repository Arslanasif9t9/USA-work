// supabase/functions/lily-admin-assist/index.ts
//
// LILY ADMIN — AI writing assist for the admin composer.
//
// Admin-only. Takes a rough draft + optional recent thread context and
// returns a polished "Lily" version. NEVER auto-sends — the admin
// reviews the suggestion and presses Send manually in the UI.
//
// Input:  { draft: string, thread_context?: Array<{ sender: 'user'|'lily', body: string }> }
// Output: { ok: true, suggestion: string } | { ok: false, error: string }

import { createClient } from "npm:@supabase/supabase-js@2";
import { corsHeaders } from "npm:@supabase/supabase-js@2/cors";

const SYSTEM_PROMPT =
  "You are helping an admin reply as Lilly, the project coordinator at " +
  "EIA Projects. Rewrite the admin's draft into a polished Lilly " +
  "message: warm, professional, brief (1-3 sentences), plain English, " +
  "no emojis. Keep the meaning and any specific facts exactly. Return " +
  "ONLY the rewritten message text.";

interface Body {
  draft?: string;
  thread_context?: Array<{ sender?: string; body?: string }>;
}

const GEMINI_MODELS = [
  "google/gemini-2.5-flash",
  "google/gemini-2.5-flash-lite",
] as const;

async function callGeminiOnce(
  apiKey: string,
  model: string,
  systemPrompt: string,
  userPrompt: string,
): Promise<{ ok: true; text: string } | { ok: false; status: number; error: string }> {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 20_000);
  let resp: Response;
  try {
    resp = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${apiKey}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model,
        messages: [
          { role: "system", content: systemPrompt },
          { role: "user", content: userPrompt },
        ],
        temperature: 0.6,
        max_tokens: 512,
      }),
      signal: controller.signal,
    });
  } catch (err) {
    clearTimeout(timer);
    return { ok: false, status: 0, error: err instanceof Error ? err.message : String(err) };
  }
  clearTimeout(timer);
  const raw = await resp.text();
  if (!resp.ok) return { ok: false, status: resp.status, error: `http ${resp.status}: ${raw.slice(0, 200)}` };
  let parsed: unknown;
  try { parsed = JSON.parse(raw); } catch { return { ok: false, status: resp.status, error: "non-JSON envelope" }; }
  const text = (parsed as {
    choices?: { message?: { content?: string } }[];
  }).choices?.[0]?.message?.content;
  if (!text || !text.trim()) return { ok: false, status: resp.status, error: "empty content" };
  return { ok: true, text: text.trim() };
}

async function callGemini(
  apiKey: string,
  systemPrompt: string,
  userPrompt: string,
): Promise<{ ok: true; text: string; model: string } | { ok: false; error: string }> {
  const errors: string[] = [];
  for (const model of GEMINI_MODELS) {
    for (let attempt = 0; attempt < 2; attempt++) {
      const r = await callGeminiOnce(apiKey, model, systemPrompt, userPrompt);
      if (r.ok) return { ok: true, text: r.text, model };
      const msg = `[${model} attempt ${attempt + 1}] ${r.error}`;
      console.error("[lily-admin-assist] gemini call failed:", msg);
      errors.push(msg);
      const retryable = r.status === 429 || (r.status >= 500 && r.status < 600) || r.status === 0;
      if (!retryable) break;
      if (attempt === 0) await new Promise((res) => setTimeout(res, 600));
    }
  }
  return { ok: false, error: errors.join(" | ") };
}

function jsonResp(status: number, payload: unknown): Response {
  return new Response(JSON.stringify(payload), {
    status,
    headers: { ...corsHeaders, "Content-Type": "application/json" },
  });
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });
  if (req.method !== "POST") return jsonResp(405, { ok: false, error: "method not allowed" });

  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL") ?? Deno.env.get("VITE_SUPABASE_URL");
    const anonKey = Deno.env.get("SUPABASE_ANON_KEY") ?? Deno.env.get("VITE_SUPABASE_ANON_KEY");
    const geminiKey = Deno.env.get("LOVABLE_API_KEY") ?? "";
    if (!supabaseUrl || !anonKey) return jsonResp(500, { ok: false, error: "supabase env not configured" });
    if (!geminiKey) return jsonResp(500, { ok: false, error: "LOVABLE_API_KEY not configured" });

    const authHeader = req.headers.get("authorization") ?? "";
    const jwt = authHeader.startsWith("Bearer ") ? authHeader.slice(7) : "";
    if (!jwt) return jsonResp(401, { ok: false, error: "missing Authorization: Bearer <token>" });

    const sb = createClient(supabaseUrl, anonKey, {
      auth: { persistSession: false, autoRefreshToken: false },
      global: { headers: { Authorization: `Bearer ${jwt}` } },
    });
    const { data: userResp, error: userErr } = await sb.auth.getUser(jwt);
    if (userErr || !userResp?.user) return jsonResp(401, { ok: false, error: "invalid session token" });
    const { data: profile } = await sb
      .from("users")
      .select("id, role, is_super_admin, status")
      .eq("id", userResp.user.id)
      .maybeSingle();
    if (!profile) return jsonResp(403, { ok: false, error: "no profile row" });
    const isAdmin = profile.role === "admin" || profile.is_super_admin === true;
    if (!isAdmin) return jsonResp(403, { ok: false, error: "admin role required" });
    if (profile.status !== "active") return jsonResp(403, { ok: false, error: "account deactivated" });

    const body = (await req.json().catch(() => ({}))) as Body;
    const draft = (body.draft ?? "").toString().trim();
    if (!draft) return jsonResp(400, { ok: false, error: "draft is required" });

    const ctxLines: string[] = [];
    if (Array.isArray(body.thread_context)) {
      for (const m of body.thread_context.slice(-6)) {
        const who = m.sender === "lily" ? "Lilly" : "User";
        const txt = (m.body ?? "").toString().trim();
        if (txt) ctxLines.push(`${who}: ${txt}`);
      }
    }
    const userPrompt = (ctxLines.length > 0
      ? `Recent conversation:\n${ctxLines.join("\n")}\n\n`
      : "") + `Admin draft to rewrite as Lilly:\n${draft}`;

    const out = await callGemini(geminiKey, SYSTEM_PROMPT, userPrompt);
    if (!out.ok) return jsonResp(200, { ok: false, error: "assist_busy", detail: out.error });
    return jsonResp(200, { ok: true, suggestion: out.text, model_used: out.model });
  } catch (err) {
    return jsonResp(200, {
      ok: false,
      error: err instanceof Error ? err.message : String(err),
    });
  }
});
