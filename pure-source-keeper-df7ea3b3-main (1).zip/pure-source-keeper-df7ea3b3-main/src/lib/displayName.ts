/**
 * Display-name helper — replaces the master admin's name with the
 * project-coordinator alias everywhere employees (and shared UI)
 * see it.  Purely cosmetic; the DB record is untouched.
 */
export function displayUserName(
  user?: {
    full_name?: string | null;
    username?: string;
    is_super_admin?: boolean;
  } | null,
): string {
  if (!user) return 'Unknown';
  if (user.is_super_admin) return 'Lilly (Ai)';
  return user.full_name?.trim() || user.username || 'Unknown';
}
