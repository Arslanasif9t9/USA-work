// Hand-curated Supabase types for Phase 1 tables.
// Regenerate with `supabase gen types typescript` once the CLI is wired up.

export type UserRole = 'admin' | 'manager' | 'viewer';
export type UserStatus = 'active' | 'deactivated';
export type ThemePref = 'light' | 'dark';

export interface UserRow {
  id: string;
  email: string;
  username: string;
  full_name: string | null;
  avatar_url: string | null;
  role: UserRole;
  status: UserStatus;
  is_super_admin: boolean;
  theme: ThemePref;
  timezone: string;
  title: string | null;
  created_at: string;
  updated_at: string;
}

export interface WorkspaceRow {
  id: string;
  name: string;
  icon_emoji: string;
  icon_color: string;
  is_main: boolean;
  created_at: string;
  updated_at: string;
}

export interface WorkspaceMemberRow {
  workspace_id: string;
  user_id: string;
  role: 'owner' | 'member' | 'viewer';
  created_at: string;
}

export interface AccountRow {
  id: string;
  name: string;
  gemini_api_key_encrypted: string | null;
  settings: Record<string, unknown>;
  created_at: string;
  updated_at: string;
}

export interface ActivityLogRow {
  id: string;
  actor_id: string;
  action_type: string;
  target_type: string;
  target_id: string | null;
  old_value: unknown;
  new_value: unknown;
  created_at: string;
}

// ---------- Phase 2 ----------
export type BoardType = 'main' | 'private';
export type BoardSubscriberRole = 'owner' | 'member' | 'viewer';
export type NotificationLevel = 'everything' | 'replies_mentions' | 'nothing';
export type ColumnType =
  | 'task_name' | 'text' | 'status' | 'people' | 'date'
  | 'priority' | 'numbers' | 'checkbox' | 'dropdown' | 'link' | 'files';

export interface BoardRow {
  id: string;
  workspace_id: string;
  name: string;
  description: string | null;
  icon_emoji: string;
  board_type: BoardType;
  owner_id: string;
  created_by: string;
  settings: Record<string, unknown>;
  created_at: string;
  updated_at: string;
  archived_at: string | null;
  deleted_at: string | null;
}

export interface BoardSubscriberRow {
  board_id: string;
  user_id: string;
  role: BoardSubscriberRole;
  notification_level: NotificationLevel;
  subscribed_at: string;
}

export interface BoardFavoriteRow {
  user_id: string;
  board_id: string;
  favorited_at: string;
}

export interface BoardLastViewedRow {
  board_id: string;
  user_id: string;
  last_viewed_at: string;
}

export interface GroupRow {
  id: string;
  board_id: string;
  name: string;
  color: string;
  sort_order: number;
  is_collapsed_default: boolean;
  created_at: string;
  updated_at: string;
  archived_at: string | null;
  deleted_at: string | null;
}

export interface ColumnRow {
  id: string;
  board_id: string;
  name: string;
  column_type: ColumnType;
  sort_order: number;
  width: number;
  is_required: boolean;
  is_pinned_left: boolean;
  is_pinned_right: boolean;
  default_value: unknown;
  settings: Record<string, unknown>;
  created_at: string;
  updated_at: string;
  archived_at: string | null;
}

export interface ColumnLabelRow {
  id: string;
  column_id: string;
  name: string;
  color: string;
  sort_order: number;
  is_default: boolean;
  created_at: string;
}

// ---------- Phase 3 ----------
export interface ItemRow {
  id: string;
  board_id: string;
  group_id: string;
  parent_item_id: string | null;
  name: string;
  task_code: string;
  sort_order: number;
  created_by: string;
  updated_by: string | null;
  created_at: string;
  updated_at: string;
  archived_at: string | null;
  deleted_at: string | null;
}

export interface ItemColumnValueRow {
  id: string;
  item_id: string;
  column_id: string;
  value: unknown;
  updated_by: string | null;
  updated_at: string;
}

export interface ItemSubscriberRow {
  item_id: string;
  user_id: string;
  subscribed_at: string;
}

// Column value shapes (typed) — what gets stored in item_column_values.value
export type CellValue =
  | { text: string }                                  // text
  | { value: number | null }                          // numbers
  | { label_id: string | null }                       // status / priority
  | { label_ids: string[] }                           // dropdown
  | { user_ids: string[] }                            // people
  | { date: string | null }                           // date (YYYY-MM-DD)
  | { checked: boolean }                              // checkbox
  | { url: string; text: string }                     // link
  | { file_ids: string[] };                           // files

// ---------- Phase 4 ----------
export interface UpdateRow {
  id: string;
  item_id: string;
  author_id: string;
  body_html: string;
  body_json: unknown;
  created_at: string;
  updated_at: string;
  edited_at: string | null;
  deleted_at: string | null;
}

export interface UpdateReactionRow {
  update_id: string;
  user_id: string;
  emoji: string;
  created_at: string;
}

export interface UpdateMentionRow {
  update_id: string;
  mentioned_user_id: string;
  created_at: string;
}

export interface FileRow {
  id: string;
  uploader_id: string;
  item_id: string | null;
  update_id: string | null;
  column_id: string | null;
  storage_path: string;
  file_name: string;
  file_size: number;
  mime_type: string;
  thumbnail_path: string | null;
  created_at: string;
  deleted_at: string | null;
}

export type NotificationType =
  | 'mention' | 'comment' | 'assigned' | 'status_changed' | 'due_date' | 'task_updated'
  // Server-emitted shift admin alert (DB migration 0073). Recipient is
  // an admin user, actor is the manager whose shift triggered the
  // alert. No item/board context — rendered with a generic copy line.
  | 'shift_admin_alert';

export interface NotificationRow {
  id: string;
  recipient_id: string;
  actor_id: string | null;
  type: NotificationType;
  item_id: string | null;
  update_id: string | null;
  board_id: string | null;
  is_read: boolean;
  read_at: string | null;
  created_at: string;
}

// ---------- Phase 5 ----------
export type ViewType = 'table' | 'kanban' | 'calendar';

export interface ViewRow {
  id: string;
  board_id: string;
  name: string;
  type: ViewType;
  sort_order: number;
  is_default: boolean;
  created_by: string;
  settings: Record<string, unknown>;
  created_at: string;
  updated_at: string;
  archived_at: string | null;
}

export type AiFeature = 'create_board' | 'create_tasks' | 'chat' | 'suggest';
export type AiRunStatus = 'success' | 'error' | 'not_configured';

export interface AiRunRow {
  id: string;
  user_id: string;
  feature: AiFeature;
  prompt: string | null;
  response: string | null;
  model: string | null;
  tokens_input: number | null;
  tokens_output: number | null;
  target_type: string | null;
  target_id: string | null;
  status: AiRunStatus;
  error_message: string | null;
  ran_at: string;
}

export interface Database {
  public: {
    Tables: {
      users: { Row: UserRow; Insert: Partial<UserRow> & { id: string; email: string; username: string }; Update: Partial<UserRow> };
      workspaces: { Row: WorkspaceRow; Insert: Partial<WorkspaceRow> & { name: string }; Update: Partial<WorkspaceRow> };
      workspace_members: { Row: WorkspaceMemberRow; Insert: WorkspaceMemberRow; Update: Partial<WorkspaceMemberRow> };
      account: { Row: AccountRow; Insert: Partial<AccountRow> & { name: string }; Update: Partial<AccountRow> };
      activity_log: { Row: ActivityLogRow; Insert: Partial<ActivityLogRow> & { actor_id: string; action_type: string; target_type: string }; Update: Partial<ActivityLogRow> };
    };
    Views: Record<string, never>;
    Functions: Record<string, never>;
    Enums: Record<string, never>;
  };
}
