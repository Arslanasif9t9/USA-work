/**
 * Thin API client indirection.
 *
 * Routes `/api/<name>` to either:
 *  - Vercel functions at `/api/<name>` (default — preserves the existing
 *    p-m-system.vercel.app deployment), OR
 *  - Lovable Cloud edge functions at `${VITE_SUPABASE_URL}/functions/v1/<name>`
 *    when `VITE_API_BASE` is set to `lovable` (or to a full URL base).
 *
 * Controlled by a single env var: VITE_API_BASE.
 *   - unset / empty / "vercel"  → same-origin /api/* (Vercel)
 *   - "lovable"                  → ${VITE_SUPABASE_URL}/functions/v1/*
 *   - any other value           → used verbatim as the base (e.g. a proxy URL)
 *
 * Call sites use `apiFetch('/api/foo', init)` — drop-in for fetch().
 */

const RAW_BASE = (import.meta.env.VITE_API_BASE as string | undefined)?.trim() ?? '';
// Hardcoded fallback mirrors src/lib/supabase.ts — guarantees edge-function
// routing works on the published custom domain even when VITE_SUPABASE_URL
// isn't baked into the bundle at build time.
const FALLBACK_SUPABASE_URL = 'https://kevtjqxsmzjquoonqfbh.supabase.co';
const SUPABASE_URL =
  ((import.meta.env.VITE_SUPABASE_URL as string | undefined) ?? '') || FALLBACK_SUPABASE_URL;

function resolveBase(): string {
  // Explicit override always wins.
  if (RAW_BASE && RAW_BASE !== 'vercel') {
    if (RAW_BASE === 'lovable') {
      if (!SUPABASE_URL) {
        console.warn('[apiClient] VITE_API_BASE=lovable but VITE_SUPABASE_URL missing');
        return '';
      }
      return `${SUPABASE_URL.replace(/\/$/, '')}/functions/v1`;
    }
    return RAW_BASE.replace(/\/$/, '');
  }
  if (RAW_BASE === 'vercel') return '';
  // Auto-detect: the ONLY host that has same-origin Vercel /api/*
  // functions is p-m-system.vercel.app. Every other host (Lovable
  // preview, Lovable published, custom domains like
  // myprojects.expertintuitiveadvisor.com, etc.) must route to the
  // Supabase edge functions. Localhost falls back to /api/* so
  // `vercel dev` keeps working during local development.
  if (typeof window !== 'undefined' && SUPABASE_URL) {
    const host = window.location.hostname;
    const isVercelHost = host === 'p-m-system.vercel.app';
    const isLocalhost  = host === 'localhost' || host === '127.0.0.1';
    if (!isVercelHost && !isLocalhost) {
      return `${SUPABASE_URL.replace(/\/$/, '')}/functions/v1`;
    }
  }
  return '';
}

const API_BASE = resolveBase();

export function apiUrl(path: string): string {
  // Accept either '/api/foo' or 'foo'.
  const name = path.replace(/^\/?api\//, '').replace(/^\//, '');
  if (!API_BASE) return `/api/${name}`;
  return `${API_BASE}/${name}`;
}

// Client-side hard timeout for every apiFetch call. Without this, a
// slow/hanging POST (e.g. /api/send-invite-email when Resend stalls)
// parks the caller at the await forever — the Send Invite button's
// finally never runs, sending stays true, and the button spins
// indefinitely. 12s is comfortably above any healthy round-trip but
// well under the user-perceived "broken" threshold.
const API_FETCH_TIMEOUT_MS = 12_000;

export function apiFetch(path: string, init?: RequestInit): Promise<Response> {
  const ctrl = new AbortController();
  const t = setTimeout(() => ctrl.abort(), API_FETCH_TIMEOUT_MS);

  // Merge with caller-supplied signal if any: abort our controller when
  // the caller's signal aborts, so we don't override their intent.
  const callerSignal = init?.signal;
  if (callerSignal) {
    if (callerSignal.aborted) ctrl.abort();
    else callerSignal.addEventListener('abort', () => ctrl.abort(), { once: true });
  }

  return fetch(apiUrl(path), { ...(init ?? {}), signal: ctrl.signal })
    .catch((err) => {
      if (err instanceof DOMException && err.name === 'AbortError') {
        throw new Error('Request timed out — please try again');
      }
      throw err;
    })
    .finally(() => {
      clearTimeout(t);
    });
}

