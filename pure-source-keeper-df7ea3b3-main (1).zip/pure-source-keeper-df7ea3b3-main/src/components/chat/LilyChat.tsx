/**
 * LilyChat — floating project-coordinator chat bubble.
 *
 * Mounted in AppShell so every authenticated route shows the bubble.
 * Data path: lock-free dbSelect/dbInsertReturning/dbUpdate (see
 * src/lib/db.ts). Realtime via supabase.channel postgres_changes on
 * chat_messages filtered to this user's thread. AI replies arrive via
 * the lily-reply edge function (fire-and-forget after sending).
 */
import { Component, useCallback, useEffect, useMemo, useRef, useState } from 'react';
import type { ReactNode } from 'react';
import { toast } from 'sonner';
import { ChevronDown, MessageCircle, Send, AlertCircle } from 'lucide-react';
import { useAuthStore } from '@/state/authStore';
import { supabase } from '@/lib/supabase';
import { dbSelect, dbInsertReturning, dbUpdate, eq, gte } from '@/lib/db';

import { cn } from '@/lib/cn';

interface ChatThreadRow {
  id: string;
  user_id: string | null;
  created_at: string;
  last_message_at: string;
}

interface ChatMessageRow {
  id: string;
  thread_id: string | null;
  sender: 'user' | 'lily' | string;
  sender_user_id: string | null;
  body: string;
  created_at: string;
  // UI-only flags for optimistic state.
  _pending?: boolean;
  _failed?: boolean;
}

const LAST_OPENED_KEY = 'lilychat:lastOpenedAt';
const MINIMIZED_KEY = 'lilychat:minimized';

// ============== Error boundary so a chat failure never breaks boards.
interface BoundaryState { error: Error | null }
class LilyBoundary extends Component<{ children: ReactNode }, BoundaryState> {
  state: BoundaryState = { error: null };
  static getDerivedStateFromError(error: Error): BoundaryState { return { error }; }
  componentDidCatch(err: Error) { console.error('[LilyChat]', err); }
  render() {
    if (this.state.error) return null; // fail silent — boards must keep working
    return this.props.children;
  }
}

function formatTime(iso: string): string {
  try {
    const d = new Date(iso);
    return d.toLocaleTimeString(undefined, { hour: 'numeric', minute: '2-digit' });
  } catch { return ''; }
}

function LilyChatInner() {
  const profile = useAuthStore((s) => s.profile);
  const userId = profile?.id ?? null;
  const isAdmin = profile?.role === 'admin';
  // Lily is available to ALL authenticated users — including locked /
  // not-started / period-locked employees. The bubble + panel sit
  // above the lock overlays via z-[60]. Lock-aware content filtering
  // happens server-side in the lily-reply edge function.

  // Admins always start MINIMIZED (bubble-only) on every mount, so the
  // panel never auto-opens while they navigate. Employees keep the
  // existing default-open behavior, then honor the session-minimized
  // flag for the rest of their session.
  const [open, setOpen] = useState(!isAdmin);
  const [thread, setThread] = useState<ChatThreadRow | null>(null);
  const [messages, setMessages] = useState<ChatMessageRow[]>([]);
  const [input, setInput] = useState('');
  const [sending, setSending] = useState(false);
  const [waitingForLily, setWaitingForLily] = useState(false);
  const [lastOpenedAt, setLastOpenedAt] = useState<number>(0);
  // Hydrate from localStorage AFTER mount so import-time / SSR-safe.
  // Also honor a per-session "minimized" flag so once the user collapses
  // the panel it stays collapsed for the rest of the session (across
  // route changes); a fresh session opens it again — except for admins
  // who always start minimized regardless of the flag.
  useEffect(() => {
    try {
      if (typeof window === 'undefined') return;
      const v = window.localStorage.getItem(LAST_OPENED_KEY);
      if (v) setLastOpenedAt(Number(v));
      if (isAdmin) {
        setOpen(false);
        return;
      }
      if (window.sessionStorage.getItem(MINIMIZED_KEY) === '1') {
        setOpen(false);
      }
    } catch { /* ignore */ }
  }, [isAdmin]);


  const handleMinimize = useCallback(() => {
    setOpen(false);
    try {
      if (typeof window !== 'undefined') {
        window.sessionStorage.setItem(MINIMIZED_KEY, '1');
      }
    } catch { /* ignore */ }
  }, []);

  const handleExpand = useCallback(() => {
    setOpen(true);
    try {
      if (typeof window !== 'undefined') {
        window.sessionStorage.removeItem(MINIMIZED_KEY);
      }
    } catch { /* ignore */ }
  }, []);

  const bodyRef = useRef<HTMLDivElement | null>(null);
  const inputRef = useRef<HTMLInputElement | null>(null);
  const waitTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  // --------------- Soft chime for incoming Lily messages.
  // Web Audio only — no asset files. Created lazily on first user
  // interaction to respect autoplay rules; fails silently if blocked.
  const audioCtxRef = useRef<AudioContext | null>(null);
  useEffect(() => {
    if (typeof window === 'undefined') return;
    const ensureCtx = () => {
      try {
        type Ctor = typeof AudioContext;
        const W = window as unknown as { AudioContext?: Ctor; webkitAudioContext?: Ctor };
        const Ctor = W.AudioContext ?? W.webkitAudioContext;
        if (!Ctor) return;
        if (!audioCtxRef.current) audioCtxRef.current = new Ctor();
        const ctx = audioCtxRef.current;
        if (ctx && ctx.state === 'suspended') void ctx.resume().catch(() => {});
      } catch { /* ignore */ }
    };
    window.addEventListener('pointerdown', ensureCtx, { once: false });
    window.addEventListener('keydown', ensureCtx, { once: false });
    return () => {
      window.removeEventListener('pointerdown', ensureCtx);
      window.removeEventListener('keydown', ensureCtx);
    };
  }, []);
  const playLilyChime = useCallback(() => {
    const ctx = audioCtxRef.current;
    if (!ctx) return;
    const emit = () => {
      try {
        const now = ctx.currentTime;
        const note = (freq: number, start: number, dur: number, peak: number) => {
          const osc = ctx.createOscillator();
          const gain = ctx.createGain();
          osc.type = 'sine';
          osc.frequency.value = freq;
          gain.gain.setValueAtTime(0.0001, now + start);
          gain.gain.exponentialRampToValueAtTime(peak, now + start + 0.02);
          gain.gain.exponentialRampToValueAtTime(0.0001, now + start + dur);
          osc.connect(gain).connect(ctx.destination);
          osc.start(now + start);
          osc.stop(now + start + dur + 0.05);
        };
        // Soft two-note chime (E5 → A5), low volume ~0.2.
        note(659, 0.00, 0.35, 0.20);
        note(880, 0.18, 0.45, 0.18);
      } catch { /* ignore */ }
    };
    try {
      if (ctx.state === 'running') emit();
      else void ctx.resume().then(emit, () => {});
    } catch { /* ignore */ }
  }, []);

  // --------------- Bootstrap: load/create thread + initial messages.
  useEffect(() => {
    if (!userId) return;
    let cancelled = false;
    (async () => {
      try {
        let t: ChatThreadRow | null = null;
        const rows = await dbSelect<ChatThreadRow>('chat_threads', {
          filters: { user_id: eq(userId) },
          limit: 1,
        });
        t = rows[0] ?? null;
        if (!t) {
          t = await dbInsertReturning<ChatThreadRow>('chat_threads', { user_id: userId });
        }
        if (cancelled) return;
        setThread(t);
        const msgs = await dbSelect<ChatMessageRow>('chat_messages', {
          filters: { thread_id: eq(t.id) },
          order: 'created_at.asc',
          limit: 200,
        });
        if (cancelled) return;
        setMessages(msgs);
      } catch (err) {
        console.error('[LilyChat] bootstrap failed', err);
      }
    })();
    return () => { cancelled = true; };
  }, [userId]);

  // --------------- Realtime: append new lily/user messages from server
  //                 (accelerator only — the 7s poll below is the source
  //                 of truth so a dead channel never hides Lily's reply).
  const handleIncoming = useCallback((row: ChatMessageRow) => {
    let added = false;
    setMessages((prev) => {
      if (prev.some((m) => m.id === row.id)) return prev;
      added = true;
      return [...prev, row];
    });
    if (added && row.sender === 'lily') {
      setWaitingForLily(false);
      if (waitTimerRef.current) { clearTimeout(waitTimerRef.current); waitTimerRef.current = null; }
      playLilyChime();
    }
  }, [playLilyChime]);

  useEffect(() => {
    if (!thread?.id) return;
    const subscribe = () => {
      const ch = supabase.channel('lilychat:' + thread.id + ':' + Date.now());
      ch.on(
        'postgres_changes',
        { event: 'INSERT', schema: 'public', table: 'chat_messages', filter: 'thread_id=eq.' + thread.id },
        (payload) => handleIncoming(payload.new as ChatMessageRow),
      );
      ch.subscribe();
      return ch;
    };
    let ch = subscribe();
    const onVis = () => {
      if (document.visibilityState !== 'visible') return;
      try { void supabase.removeChannel(ch); } catch { /* ignore */ }
      ch = subscribe();
    };
    document.addEventListener('visibilitychange', onVis);
    return () => {
      document.removeEventListener('visibilitychange', onVis);
      try { void supabase.removeChannel(ch); } catch { /* ignore */ }
    };
  }, [thread?.id, handleIncoming]);

  // --------------- Polling fallback: every 7s, pull any messages newer
  //                 than the newest loaded row. Guarantees Lily's reply
  //                 (admin human-Lily or AI lily-reply) lands even if
  //                 the realtime channel silently drops.
  const messagesRef = useRef<ChatMessageRow[]>([]);
  useEffect(() => { messagesRef.current = messages; }, [messages]);
  useEffect(() => {
    if (!thread?.id) return;
    let cancelled = false;
    const tick = async () => {
      if (cancelled) return;
      try {
        const cur = messagesRef.current.filter((m) => !m._pending && !m._failed);
        const newestTs = cur.length > 0
          ? cur[cur.length - 1].created_at
          : new Date(0).toISOString();
        const rows = await dbSelect<ChatMessageRow>('chat_messages', {
          filters: { thread_id: eq(thread.id), created_at: gte(newestTs) },
          order: 'created_at.asc',
          limit: 100,
        });
        if (cancelled || rows.length === 0) return;
        for (const r of rows) handleIncoming(r);
      } catch (err) {
        console.warn('[LilyChat] poll failed', err);
      }
    };
    const id = window.setInterval(() => { void tick(); }, 7000);
    return () => { cancelled = true; window.clearInterval(id); };
  }, [thread?.id, handleIncoming]);


  // --------------- Auto-scroll to newest on message change / open.
  useEffect(() => {
    if (!open) return;
    const el = bodyRef.current;
    if (!el) return;
    el.scrollTop = el.scrollHeight;
  }, [messages, open, waitingForLily]);

  // --------------- Mark "last opened" + focus input on open.
  useEffect(() => {
    if (!open) return;
    const now = Date.now();
    try { localStorage.setItem(LAST_OPENED_KEY, String(now)); } catch { /* ignore */ }
    setLastOpenedAt(now);
    // focus after slide-in animation
    setTimeout(() => inputRef.current?.focus(), 80);
  }, [open]);

  // --------------- Unread badge: lily messages newer than lastOpenedAt.
  const unread = useMemo(() => {
    if (open) return 0;
    return messages.filter(
      (m) => m.sender === 'lily' && new Date(m.created_at).getTime() > lastOpenedAt,
    ).length;
  }, [messages, lastOpenedAt, open]);

  // --------------- Send a user message.
  const send = useCallback(async () => {
    const text = input.trim();
    if (!text || !thread || !userId || sending) return;
    setSending(true);
    setInput('');

    const tempId = 'tmp-' + Math.random().toString(36).slice(2);
    const optimistic: ChatMessageRow = {
      id: tempId,
      thread_id: thread.id,
      sender: 'user',
      sender_user_id: userId,
      body: text,
      created_at: new Date().toISOString(),
      _pending: true,
    };
    setMessages((prev) => [...prev, optimistic]);

    try {
      const saved = await dbInsertReturning<ChatMessageRow>('chat_messages', {
        thread_id: thread.id,
        sender: 'user',
        sender_user_id: userId,
        body: text,
      });
      // Swap optimistic row for the real one (dedupe in case realtime beat us).
      setMessages((prev) => {
        const withoutTemp = prev.filter((m) => m.id !== tempId);
        if (withoutTemp.some((m) => m.id === saved.id)) return withoutTemp;
        return [...withoutTemp, saved];
      });
      // Bump thread last_message_at (best-effort).
      try {
        await dbUpdate('chat_threads', { id: eq(thread.id) }, {
          last_message_at: new Date().toISOString(),
        });
      } catch { /* non-fatal */ }

      // Fire-and-forget AI reply trigger.
      setWaitingForLily(true);
      if (waitTimerRef.current) clearTimeout(waitTimerRef.current);
      waitTimerRef.current = setTimeout(() => setWaitingForLily(false), 12_000);
      void supabase.functions
        .invoke('lily-reply', { body: { thread_id: thread.id, user_message_id: saved.id } })
        .catch((err) => console.warn('[LilyChat] lily-reply invoke failed', err));
    } catch (err) {
      console.error('[LilyChat] send failed', err);
      setMessages((prev) =>
        prev.map((m) => (m.id === tempId ? { ...m, _pending: false, _failed: true } : m)),
      );
      toast.error(err instanceof Error ? err.message : 'Message failed to send');
    } finally {
      setSending(false);
    }
  }, [input, thread, userId, sending]);

  const retryMessage = useCallback((m: ChatMessageRow) => {
    setMessages((prev) => prev.filter((x) => x.id !== m.id));
    setInput((cur) => (cur ? cur : m.body));
    setTimeout(() => inputRef.current?.focus(), 0);
  }, []);

  if (!userId) return null;


  return (
    <>
      {/* ============== COLLAPSED BUBBLE ============== */}
      {!open && (
        <button
          type="button"
          aria-label="Open chat with Lilly"
          onClick={handleExpand}
          className="fixed bottom-4 right-4 z-[60] group"
        >
          <span className="relative flex h-14 w-14 items-center justify-center rounded-full bg-gradient-to-br from-violet-500 to-violet-700 text-white shadow-lg shadow-violet-900/30 ring-1 ring-white/10 transition-transform duration-150 group-hover:scale-105 group-active:scale-95">
            <MessageCircle className="h-6 w-6" strokeWidth={2.2} />
            {/* presence dot */}
            <span className="absolute bottom-0.5 right-0.5 h-3 w-3 rounded-full bg-emerald-400 ring-2 ring-white" />
            {unread > 0 && (
              <span className="absolute -top-1 -right-1 min-w-[20px] h-5 px-1.5 rounded-full bg-red-500 text-[11px] font-semibold flex items-center justify-center ring-2 ring-white">
                {unread > 9 ? '9+' : unread}
              </span>
            )}
          </span>
        </button>
      )}

      {/* ============== EXPANDED PANEL ============== */}
      {open && (
        <div
          className="fixed bottom-4 right-4 z-[60] w-[380px] max-w-[calc(100vw-2rem)] h-[560px] max-h-[calc(100vh-2rem)] flex flex-col rounded-2xl bg-white shadow-2xl ring-1 ring-black/5 overflow-hidden animate-in fade-in slide-in-from-bottom-4 duration-200"
          role="dialog"
          aria-label="Chat with Lilly"
        >
          {/* Header */}
          <div className="flex items-center gap-3 px-4 py-3 bg-gradient-to-br from-violet-600 to-violet-700 text-white">
            <div className="relative h-10 w-10 rounded-full bg-white/15 flex items-center justify-center font-semibold">
              L
              <span className="absolute bottom-0 right-0 h-2.5 w-2.5 rounded-full bg-emerald-400 ring-2 ring-violet-600" />
            </div>
            <div className="flex-1 min-w-0">
              <div className="text-[15px] font-semibold leading-tight">Lilly</div>
              <div className="text-[11px] text-white/80 flex items-center gap-1.5">
                <span className="h-1.5 w-1.5 rounded-full bg-emerald-400" />
                Project Coordinator · Online
              </div>
            </div>
            <button
              type="button"
              onClick={handleMinimize}
              aria-label="Minimize"
              className="p-1.5 rounded-md hover:bg-white/15 transition-colors"
            >
              <ChevronDown className="h-5 w-5" />
            </button>
          </div>

          {/* Body */}
          <div
            ref={bodyRef}
            className="flex-1 overflow-y-auto px-4 py-4 space-y-3 bg-slate-50"
          >
            {messages.length === 0 && (
              <div className="text-center text-sm text-slate-500 mt-8 px-6">
                <div className="font-medium text-slate-700 mb-1">Hi! I'm Lilly 👋</div>
                <div>Ask me anything about your projects, tasks, or boards — I'm happy to help.</div>
              </div>
            )}
            {messages.map((m) => {
              const mine = m.sender === 'user';
              return (
                <div key={m.id} className={cn('flex flex-col', mine ? 'items-end' : 'items-start')}>
                  <div
                    className={cn(
                      'max-w-[78%] px-3.5 py-2 rounded-2xl text-[14px] leading-relaxed whitespace-pre-wrap break-words',
                      mine
                        ? 'bg-violet-600 text-white rounded-br-md'
                        : 'bg-white text-slate-800 ring-1 ring-slate-200 rounded-bl-md',
                      m._pending && 'opacity-60',
                      m._failed && 'bg-red-100 text-red-900 ring-1 ring-red-200',
                    )}
                  >
                    {m.body}
                  </div>
                  <div className={cn('mt-1 text-[10px] text-slate-400 px-1 flex items-center gap-1', mine ? 'justify-end' : 'justify-start')}>
                    {m._failed && (
                      <button
                        type="button"
                        onClick={() => retryMessage(m)}
                        className="inline-flex items-center gap-0.5 text-red-500 hover:underline"
                      >
                        <AlertCircle className="h-3 w-3" /> Retry
                      </button>
                    )}
                    <span>{m._pending ? 'Sending…' : formatTime(m.created_at)}</span>
                  </div>
                </div>
              );
            })}

            {waitingForLily && (
              <div className="flex items-start">
                <div className="bg-white text-slate-500 ring-1 ring-slate-200 rounded-2xl rounded-bl-md px-4 py-2.5">
                  <div className="flex items-end gap-1 h-4">
                    <span className="h-1.5 w-1.5 rounded-full bg-slate-400 animate-bounce" style={{ animationDelay: '0ms' }} />
                    <span className="h-1.5 w-1.5 rounded-full bg-slate-400 animate-bounce" style={{ animationDelay: '120ms' }} />
                    <span className="h-1.5 w-1.5 rounded-full bg-slate-400 animate-bounce" style={{ animationDelay: '240ms' }} />
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Footer */}
          <form
            onSubmit={(e) => { e.preventDefault(); void send(); }}
            className="flex items-center gap-2 px-3 py-3 border-t border-slate-200 bg-white"
          >
            <input
              ref={inputRef}
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder="Type a message…"
              autoComplete="off"
              className="flex-1 px-3 py-2 rounded-full bg-slate-100 text-slate-800 text-[14px] placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-violet-500"
              disabled={!thread || sending}
            />
            <button
              type="submit"
              disabled={!input.trim() || !thread || sending}
              aria-label="Send message"
              className="h-9 w-9 flex items-center justify-center rounded-full bg-violet-600 text-white hover:bg-violet-700 disabled:bg-slate-300 disabled:cursor-not-allowed transition-colors"
            >
              <Send className="h-4 w-4" />
            </button>
          </form>
        </div>
      )}
    </>
  );
}

export function LilyChat() {
  return (
    <LilyBoundary>
      <LilyChatInner />
    </LilyBoundary>
  );
}
