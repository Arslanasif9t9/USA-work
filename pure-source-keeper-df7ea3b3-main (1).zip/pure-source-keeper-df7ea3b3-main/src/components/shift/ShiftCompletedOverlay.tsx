/**
 * P4.8 — Shift Completed for Today overlay (post-shift-end lock screen).
 *
 * Full-cover EIA navy/gold gate shown when shift_tick reports
 * status='completed' (whether by natural completion or an admin "End"
 * button). Same visual family as AccountLockedOverlay — calm, no action
 * button, the path forward is "wait until next shift / message Lilly".
 *
 * Computes the NEXT scheduled shift start by reading the user's own
 * shift_configs.timezone + shift_schedules rows (RLS allows self-read)
 * and rolling forward from "now" over non-scheduled weekdays. Display
 * is rendered IN THE USER'S TIMEZONE via Intl.DateTimeFormat.
 *
 * No timer / no countdown is shown — completion is final for the day.
 * Lilly chat widget stays usable (comfort mode), like other lock gates.
 */
import { useQuery } from '@tanstack/react-query';
// Lock-free PostgREST path via @/lib/db — keeps board/route renders off
// the supabase-js getSession() funnel that wedged on tab refocus.
import { dbSelect, dbSelectMaybeSingle, eq } from '@/lib/db';

import { useAuthStore } from '@/state/authStore';

const EIA_NAVY = '#0F1E36';
const EIA_GOLD = '#E1B978';

interface MyScheduleSummary {
  timezone: string;
  // weekday 0..6 (Sun..Sat) → HH:MM:SS local-start, only enabled rows
  byWeekday: Record<number, string>;
}

function useMyScheduleSummary() {
  const userId = useAuthStore((s) => s.profile?.id);
  return useQuery<MyScheduleSummary>({
    queryKey: ['shift', 'my-schedule-summary', userId ?? '_'],
    enabled: !!userId,
    queryFn: async () => {
      const [cfg, schedRows] = await Promise.all([
        dbSelectMaybeSingle<{ timezone: string | null }>('shift_configs', {
          select: 'timezone',
          filters: { user_id: eq(userId!) },
        }),
        dbSelect<{ weekday: number; enabled: boolean; start_time_local: string | null }>('shift_schedules', {
          select: 'weekday, enabled, start_time_local',
          filters: { user_id: eq(userId!) },
        }),
      ]);
      const byWeekday: Record<number, string> = {};
      for (const r of schedRows) {
        if (r.enabled && r.start_time_local) byWeekday[r.weekday] = r.start_time_local;
      }
      return { timezone: cfg?.timezone ?? 'Asia/Manila', byWeekday };
    },

    staleTime: 5 * 60_000,
    refetchOnWindowFocus: false,
  });
}

// Compute the next scheduled-shift start AFTER `nowUtc`, given a per-
// weekday HH:MM:SS map of local start times and the user's IANA tz.
// Returns null if no schedule rows are enabled.
function computeNextShiftStart(
  nowUtc: Date,
  byWeekday: Record<number, string>,
  tz: string,
): Date | null {
  if (Object.keys(byWeekday).length === 0) return null;
  // Look ahead up to 14 days to find the next enabled weekday whose
  // local start is strictly after "now in that tz".
  for (let i = 0; i < 14; i++) {
    // Compute the local Y-M-D / weekday for nowUtc + i days, in tz.
    const probe = new Date(nowUtc.getTime() + i * 86400_000);
    const parts = new Intl.DateTimeFormat('en-US', {
      timeZone: tz, weekday: 'short', year: 'numeric', month: '2-digit', day: '2-digit',
    }).formatToParts(probe);
    const wdName = parts.find((p) => p.type === 'weekday')?.value ?? '';
    const y = parts.find((p) => p.type === 'year')?.value ?? '';
    const m = parts.find((p) => p.type === 'month')?.value ?? '';
    const d = parts.find((p) => p.type === 'day')?.value ?? '';
    const wdMap: Record<string, number> = { Sun: 0, Mon: 1, Tue: 2, Wed: 3, Thu: 4, Fri: 5, Sat: 6 };
    const wd = wdMap[wdName];
    const start = byWeekday[wd];
    if (!start) continue;
    // Build a UTC instant for "Y-M-D start" interpreted in tz, using
    // the tz-offset trick: format an arbitrary UTC instant in tz, read
    // back the offset, then invert.
    const [hh, mm, ss] = start.split(':').map((n) => parseInt(n, 10));
    const utcGuess = new Date(Date.UTC(parseInt(y, 10), parseInt(m, 10) - 1, parseInt(d, 10), hh, mm, ss || 0));
    // Adjust by tz offset (positive = east of UTC).
    const offsetMs = tzOffsetMs(utcGuess, tz);
    const candidate = new Date(utcGuess.getTime() - offsetMs);
    if (candidate.getTime() > nowUtc.getTime()) return candidate;
  }
  return null;
}

// Offset (ms) of `tz` at a given UTC instant: how far east of UTC.
function tzOffsetMs(utc: Date, tz: string): number {
  const dtf = new Intl.DateTimeFormat('en-US', {
    timeZone: tz, hour12: false,
    year: 'numeric', month: '2-digit', day: '2-digit',
    hour: '2-digit', minute: '2-digit', second: '2-digit',
  });
  const parts = dtf.formatToParts(utc);
  const get = (t: string) => parseInt(parts.find((p) => p.type === t)?.value ?? '0', 10);
  let h = get('hour'); if (h === 24) h = 0;
  const asUTC = Date.UTC(get('year'), get('month') - 1, get('day'), h, get('minute'), get('second'));
  return asUTC - utc.getTime();
}

function formatNextShift(d: Date, tz: string): string {
  const dateStr = new Intl.DateTimeFormat('en-US', {
    timeZone: tz, weekday: 'long', month: 'long', day: 'numeric',
  }).format(d);
  const timeStr = new Intl.DateTimeFormat('en-US', {
    timeZone: tz, hour: 'numeric', minute: '2-digit', hour12: true,
  }).format(d);
  // Pretty tz label: "Asia/Manila" → "Manila"
  const tzLabel = tz.includes('/') ? tz.split('/').pop()!.replace(/_/g, ' ') : tz;
  return `Your next shift starts ${dateStr} at ${timeStr} (${tzLabel} time).`;
}

export function ShiftCompletedOverlay() {
  const { data: summary } = useMyScheduleSummary();
  let nextLine = 'Your next shift will be available tomorrow.';
  if (summary && Object.keys(summary.byWeekday).length > 0) {
    const next = computeNextShiftStart(new Date(), summary.byWeekday, summary.timezone);
    if (next) nextLine = formatNextShift(next, summary.timezone);
  }
  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center backdrop-blur-md"
      style={{ background: 'rgba(15, 30, 54, 0.65)' }}
      role="dialog"
      aria-modal="true"
      aria-labelledby="shift-completed-heading"
    >
      <div
        className="rounded-md shadow-2xl flex flex-col items-center gap-5 mx-4 max-w-md w-full"
        style={{
          background: EIA_NAVY,
          border: `1px solid ${EIA_GOLD}55`,
          padding: '44px 52px',
        }}
      >
        <h2
          id="shift-completed-heading"
          className="text-[32px] leading-tight m-0 text-center"
          style={{
            fontFamily: '"Cormorant Garamond", "Cormorant", serif',
            fontWeight: 500,
            color: EIA_GOLD,
            letterSpacing: '0.01em',
          }}
        >
          Your shift has ended for today.
        </h2>
        <p
          className="text-[13.5px] text-center m-0"
          style={{ color: 'rgba(255,255,255,0.88)', letterSpacing: '0.02em', lineHeight: 1.55 }}
        >
          Your account is locked until your next shift.
        </p>
        <p
          className="text-[13.5px] text-center m-0"
          style={{ color: EIA_GOLD, letterSpacing: '0.02em', lineHeight: 1.55 }}
        >
          {nextLine}
        </p>
        <p
          className="text-[12.5px] text-center m-0 max-w-sm"
          style={{ color: 'rgba(255,255,255,0.7)', letterSpacing: '0.02em', lineHeight: 1.55 }}
        >
          Need anything? Message Lilly, our Project Coordinator, using the chat in the corner.
        </p>
      </div>
    </div>
  );
}
