/**
 * P4.2 — Start Shift gate.
 *
 * P4c update: before showing the Start button, call shift_can_start().
 * If can_start=false, render a calm, professional "shift hasn't started
 * yet" card with the next allowed start datetime formatted in the
 * user's configured timezone. No Start button while gated. Server-side
 * shift_start() enforces the same rule — this UI is just the friendly
 * surface.
 */
import { useMemo, useState } from 'react';
import { toast } from 'sonner';
import { useShiftStart, useShiftCanStart, type ShiftCanStartReason } from '@/hooks/shift';
import { Spinner } from '@/components/Spinner';

const EIA_NAVY = '#0F1E36';
const EIA_GOLD = '#E1B978';

function formatInTz(iso: string | null, tz: string): string {
  if (!iso) return '';
  try {
    const fmt = new Intl.DateTimeFormat(undefined, {
      timeZone: tz,
      weekday: 'long',
      month: 'long',
      day: 'numeric',
      hour: 'numeric',
      minute: '2-digit',
      hour12: true,
    });
    // e.g. "Tuesday, June 10, 9:00 AM"
    return fmt.format(new Date(iso));
  } catch {
    return new Date(iso).toLocaleString();
  }
}

function reasonHeading(r: ShiftCanStartReason): string {
  if (r === 'before_start_date') return 'Welcome aboard';
  if (r === 'day_off')           return 'You are off today';
  if (r === 'after_shift_end')   return 'Your shift has ended for today';
  return 'Your shift hasn’t started yet';
}

function reasonBody(r: ShiftCanStartReason): string {
  if (r === 'before_start_date')
    return 'Your first scheduled shift hasn’t arrived yet. Please log in on your start date.';
  if (r === 'day_off')
    return 'Today is not a scheduled work day. Enjoy your day off.';
  if (r === 'after_shift_end')
    return 'Your scheduled hours are over for today. Please come back on your next shift.';
  return 'Please log in during your scheduled shift.';
}

export function StartShiftGate() {
  const start = useShiftStart();
  const can   = useShiftCanStart(true);
  const [submitting, setSubmitting] = useState(false);

  const gated = can.data && can.data.can_start === false;
  const nextLabel = useMemo(() => {
    if (!can.data?.next_shift_at) return null;
    return formatInTz(can.data.next_shift_at, can.data.timezone);
  }, [can.data]);

  const handleStart = async () => {
    if (submitting) return;
    setSubmitting(true);
    try {
      await start.mutateAsync();
    } catch (err) {
      // Server enforcement — surface the exact gate reason if it raises.
      const msg = err instanceof Error ? err.message : 'Could not start shift';
      toast.error(msg);
      // Refresh the gate so the friendly card replaces the button.
      void can.refetch();
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center backdrop-blur-md"
      style={{ background: 'rgba(15, 30, 54, 0.55)' }}
      role="dialog"
      aria-modal="true"
      aria-labelledby="start-shift-heading"
    >
      <div
        className="rounded-md shadow-2xl flex flex-col items-center gap-5 mx-4 max-w-md w-full"
        style={{
          background: EIA_NAVY,
          border: `1px solid ${EIA_GOLD}33`,
          padding: '40px 48px',
        }}
      >
        {can.isLoading ? (
          <Spinner className="h-6 w-6" />
        ) : gated ? (
          <>
            <h2
              id="start-shift-heading"
              className="text-[30px] leading-tight m-0 text-center"
              style={{
                fontFamily: '"Cormorant Garamond", "Cormorant", serif',
                fontWeight: 500,
                color: EIA_GOLD,
                letterSpacing: '0.01em',
              }}
            >
              {reasonHeading(can.data!.reason)}
            </h2>
            <p
              className="text-[14px] text-center m-0"
              style={{ color: 'rgba(255,255,255,0.80)', letterSpacing: '0.02em', lineHeight: 1.5 }}
            >
              {reasonBody(can.data!.reason)}
            </p>
            {nextLabel && (
              <div
                className="w-full rounded-md text-center"
                style={{
                  background: 'rgba(225, 185, 120, 0.08)',
                  border: `1px solid ${EIA_GOLD}33`,
                  padding: '14px 16px',
                }}
              >
                <div
                  className="text-[11px] uppercase tracking-[0.18em] mb-1"
                  style={{ color: 'rgba(255,255,255,0.55)' }}
                >
                  Your next shift begins
                </div>
                <div
                  className="text-[16px] font-semibold"
                  style={{ color: EIA_GOLD, letterSpacing: '0.01em' }}
                >
                  {nextLabel}
                </div>
                <div
                  className="text-[11px] mt-1"
                  style={{ color: 'rgba(255,255,255,0.55)' }}
                >
                  ({can.data!.timezone})
                </div>
              </div>
            )}
            <button
              type="button"
              onClick={() => void can.refetch()}
              disabled={can.isFetching}
              className="inline-flex items-center justify-center gap-2 h-9 px-5 rounded-md text-[12px] font-medium transition-opacity duration-100 disabled:opacity-50"
              style={{
                background: 'transparent',
                color: 'rgba(255,255,255,0.65)',
                border: `1px solid ${EIA_GOLD}33`,
                letterSpacing: '0.06em',
                textTransform: 'uppercase',
              }}
            >
              {can.isFetching ? <Spinner className="h-3.5 w-3.5" /> : 'Refresh'}
            </button>
          </>
        ) : (
          <>
            <h2
              id="start-shift-heading"
              className="text-[34px] leading-none m-0"
              style={{
                fontFamily: '"Cormorant Garamond", "Cormorant", serif',
                fontWeight: 500,
                color: EIA_GOLD,
                letterSpacing: '0.01em',
              }}
            >
              Start Your Shift
            </h2>
            <p
              className="text-[13px] text-center m-0"
              style={{ color: 'rgba(255,255,255,0.72)', letterSpacing: '0.02em' }}
            >
              Press start to begin your work day.
            </p>
            <button
              type="button"
              onClick={() => void handleStart()}
              disabled={submitting}
              className="inline-flex items-center justify-center gap-2 h-11 px-9 rounded-md text-[14px] font-semibold transition-[filter,opacity] duration-100 hover:brightness-110 disabled:opacity-60 disabled:cursor-not-allowed"
              style={{
                background: EIA_GOLD,
                color: EIA_NAVY,
                letterSpacing: '0.06em',
                textTransform: 'uppercase',
                minWidth: 180,
              }}
            >
              {submitting ? (
                <>
                  <Spinner className="h-4 w-4" />
                  Starting
                </>
              ) : 'Start Shift'}
            </button>
          </>
        )}
      </div>
    </div>
  );
}
