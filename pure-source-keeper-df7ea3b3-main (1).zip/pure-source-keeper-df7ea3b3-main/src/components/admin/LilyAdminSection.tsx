/**
 * Admin console for Lily Chat. Lock-free dbSelect/dbUpdate/dbInsertReturning
 * for data; supabase.channel only for realtime notify.
 */
import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { toast } from 'sonner';
import { Send, Sparkles, User as UserIcon, Loader2, Check, RefreshCw, X } from 'lucide-react';
import { useAuthStore } from '@/state/authStore';
import { supabase } from '@/lib/supabase';
import { dbSelect, dbInsertReturning, dbUpdate, dbInvoke, eq, gte } from '@/lib/db';


import { cn } from '@/lib/cn';

interface LilySettingsRow {
  id: number;
  mode: 'ai' | 'human' | string;
  updated_at: string;
}

interface ThreadRow {
  id: string;
  user_id: string | null;
  created_at: string;
  last_message_at: string;
}

interface UserMini {
  id: string;
  username: string;
  full_name: string | null;
  avatar_url: string | null;
}

interface MessageRow {
  id: string;
  thread_id: string | null;
  sender: 'user' | 'lily' | string;
  sender_user_id: string | null;
  body: string;
  created_at: string;
  _pending?: boolean;
}

function formatTime(iso: string): string {
  try {
    const d = new Date(iso);
    const today = new Date();
    if (d.toDateString() === today.toDateString()) {
      return d.toLocaleTimeString(undefined, { hour: 'numeric', minute: '2-digit' });
    }
    return d.toLocaleDateString(undefined, { month: 'short', day: 'numeric' });
  } catch { return ''; }
}

function displayName(u: UserMini | undefined): string {
  if (!u) return 'Unknown user';
  return u.full_name?.trim() || u.username || 'User';
}

export function LilyAdminSection() {
  const profile = useAuthStore((s) => s.profile);
  const adminId = profile?.id ?? null;

  const [settings, setSettings] = useState<LilySettingsRow | null>(null);
  const [savingMode, setSavingMode] = useState(false);

  const [threads, setThreads] = useState<ThreadRow[]>([]);
  const [users, setUsers] = useState<Record<string, UserMini>>({});
  const [lastByThread, setLastByThread] = useState<Record<string, MessageRow | undefined>>({});
  // newest lily message per thread (used for unread dot)
  const [lastLilyByThread, setLastLilyByThread] = useState<Record<string, string>>({});

  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [messages, setMessages] = useState<MessageRow[]>([]);
  const [input, setInput] = useState('');
  const [sending, setSending] = useState(false);
  const [assistLoading, setAssistLoading] = useState(false);
  const [suggestion, setSuggestion] = useState<string | null>(null);
  const [assistOriginalDraft, setAssistOriginalDraft] = useState<string>('');

  const bodyRef = useRef<HTMLDivElement | null>(null);

  // -------- Load settings + threads + users + last-message-per-thread.
  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const [s, t] = await Promise.all([
          dbSelect<LilySettingsRow>('lily_settings', { filters: { id: eq(1) }, limit: 1 }),
          dbSelect<ThreadRow>('chat_threads', { order: 'last_message_at.desc', limit: 500 }),
        ]);
        if (cancelled) return;
        setSettings(s[0] ?? null);
        setThreads(t);
        const userIds = Array.from(new Set(t.map((x) => x.user_id).filter((x): x is string => !!x)));
        if (userIds.length > 0) {
          const us = await dbSelect<UserMini>('users', {
            select: 'id,username,full_name,avatar_url',
            filters: { id: 'in.(' + userIds.join(',') + ')' },
            limit: userIds.length,
          });
          if (cancelled) return;
          const map: Record<string, UserMini> = {};
          for (const u of us) map[u.id] = u;
          setUsers(map);
        }
        // Last message per thread — simple per-thread fetch (admin volume low).
        const lastEntries = await Promise.all(
          t.map(async (th) => {
            const rows = await dbSelect<MessageRow>('chat_messages', {
              filters: { thread_id: eq(th.id) },
              order: 'created_at.desc',
              limit: 1,
            });
            return [th.id, rows[0]] as const;
          }),
        );
        if (cancelled) return;
        const lastMap: Record<string, MessageRow | undefined> = {};
        for (const [tid, m] of lastEntries) lastMap[tid] = m;
        setLastByThread(lastMap);
        // newest lily ts per thread
        const lilyEntries = await Promise.all(
          t.map(async (th) => {
            const rows = await dbSelect<MessageRow>('chat_messages', {
              filters: { thread_id: eq(th.id), sender: eq('lily') },
              order: 'created_at.desc',
              limit: 1,
            });
            return [th.id, rows[0]?.created_at ?? ''] as const;
          }),
        );
        if (cancelled) return;
        const lilyMap: Record<string, string> = {};
        for (const [tid, ts] of lilyEntries) lilyMap[tid] = ts;
        setLastLilyByThread(lilyMap);
      } catch (err) {
        console.error('[LilyAdmin] bootstrap failed', err);
        toast.error('Failed to load Lilly console');
      }
    })();
    return () => { cancelled = true; };
  }, []);

  // selectedId ref so realtime + polling closures see the latest value.
  const selectedIdRef = useRef<string | null>(null);
  useEffect(() => { selectedIdRef.current = selectedId; }, [selectedId]);

  // -------- Realtime: every chat_messages INSERT (accelerator only —
  //         polling below is the source of truth so a dropped channel
  //         can never silently swallow service-role inserts from the
  //         lily-reply edge function).
  const subscribeMessages = useCallback(() => {
    const ch = supabase.channel('lilyadmin:messages:' + Date.now());
    ch.on(
      'postgres_changes',
      { event: 'INSERT', schema: 'public', table: 'chat_messages' },
      (payload) => {
        const row = payload.new as MessageRow;
        if (!row.thread_id) return;
        setLastByThread((prev) => ({ ...prev, [row.thread_id!]: row }));
        if (row.sender === 'lily') {
          setLastLilyByThread((prev) => ({ ...prev, [row.thread_id!]: row.created_at }));
        }
        setThreads((prev) => {
          const idx = prev.findIndex((t) => t.id === row.thread_id);
          if (idx === -1) return prev;
          const updated = { ...prev[idx], last_message_at: row.created_at };
          return [updated, ...prev.slice(0, idx), ...prev.slice(idx + 1)];
        });
        setMessages((prev) => {
          if (row.thread_id !== selectedIdRef.current) return prev;
          if (prev.some((m) => m.id === row.id)) return prev;
          return [...prev, row];
        });
      },
    );
    ch.subscribe();
    return ch;
  }, []);

  useEffect(() => {
    let ch = subscribeMessages();
    // Heal a dead channel after tab switch / sleep.
    const onVis = () => {
      if (document.visibilityState !== 'visible') return;
      try { void supabase.removeChannel(ch); } catch { /* ignore */ }
      ch = subscribeMessages();
    };
    document.addEventListener('visibilitychange', onVis);
    return () => {
      document.removeEventListener('visibilitychange', onVis);
      try { void supabase.removeChannel(ch); } catch { /* ignore */ }
    };
  }, [subscribeMessages]);

  // -------- Realtime: settings row changes (keeps toggle in sync if
  //         another admin flips it).
  useEffect(() => {
    const ch = supabase.channel('lilyadmin:settings');
    ch.on(
      'postgres_changes',
      { event: 'UPDATE', schema: 'public', table: 'lily_settings' },
      (payload) => setSettings(payload.new as LilySettingsRow),
    );
    ch.subscribe();
    return () => { void supabase.removeChannel(ch); };
  }, []);

  // -------- POLLING (source of truth — every 5s):
  //   a. messages in the OPEN thread newer than the newest loaded row;
  //   b. global thread head: top recent chat_messages → derives
  //      last_message_at, last snippet, and the unread dot for every
  //      thread (so unopened threads light up too).
  const messagesRef = useRef<MessageRow[]>([]);
  useEffect(() => { messagesRef.current = messages; }, [messages]);

  useEffect(() => {
    let cancelled = false;
    const tick = async () => {
      if (cancelled) return;
      // (a) open thread — fetch any rows since the newest loaded.
      const sid = selectedIdRef.current;
      if (sid) {
        try {
          const cur = messagesRef.current;
          const newestTs = cur.length > 0
            ? cur[cur.length - 1].created_at
            : new Date(0).toISOString();
          const rows = await dbSelect<MessageRow>('chat_messages', {
            filters: { thread_id: eq(sid), created_at: gte(newestTs) },
            order: 'created_at.asc',
            limit: 200,
          });
          if (!cancelled && rows.length > 0) {
            setMessages((prev) => {
              const seen = new Set(prev.map((m) => m.id));
              const adds = rows.filter((r) => !seen.has(r.id));
              if (adds.length === 0) return prev;
              return [...prev, ...adds];
            });
          }
        } catch (err) {
          console.warn('[LilyAdmin] poll(open) failed', err);
        }
      }
      // (b) global head — last 100 messages across all threads. Derives
      //     last-message, lily-marker, and reorders the thread list.
      try {
        const head = await dbSelect<MessageRow>('chat_messages', {
          order: 'created_at.desc',
          limit: 100,
        });
        if (cancelled) return;
        const nextLast: Record<string, MessageRow> = {};
        const nextLily: Record<string, string> = {};
        for (const r of head) {
          if (!r.thread_id) continue;
          if (!nextLast[r.thread_id]) nextLast[r.thread_id] = r;
          if (r.sender === 'lily' && !nextLily[r.thread_id]) {
            nextLily[r.thread_id] = r.created_at;
          }
        }
        setLastByThread((prev) => ({ ...prev, ...nextLast }));
        setLastLilyByThread((prev) => ({ ...prev, ...nextLily }));
        setThreads((prev) => {
          if (prev.length === 0) return prev;
          let changed = false;
          const next = prev.map((t) => {
            const newest = nextLast[t.id];
            if (newest && newest.created_at > (t.last_message_at || '')) {
              changed = true;
              return { ...t, last_message_at: newest.created_at };
            }
            return t;
          });
          if (!changed) return prev;
          return [...next].sort((a, b) =>
            (b.last_message_at || '').localeCompare(a.last_message_at || ''),
          );
        });
      } catch (err) {
        console.warn('[LilyAdmin] poll(head) failed', err);
      }
    };
    const id = window.setInterval(() => { void tick(); }, 5000);
    // First tick after a short delay so it doesn't race the bootstrap.
    const first = window.setTimeout(() => { void tick(); }, 1500);
    return () => {
      cancelled = true;
      window.clearInterval(id);
      window.clearTimeout(first);
    };
  }, []);


  // -------- Load conversation when a thread is selected.
  useEffect(() => {
    if (!selectedId) { setMessages([]); return; }
    let cancelled = false;
    (async () => {
      try {
        const msgs = await dbSelect<MessageRow>('chat_messages', {
          filters: { thread_id: eq(selectedId) },
          order: 'created_at.asc',
          limit: 500,
        });
        if (cancelled) return;
        setMessages(msgs);
      } catch (err) {
        console.error('[LilyAdmin] load messages failed', err);
      }
    })();
    return () => { cancelled = true; };
  }, [selectedId]);

  useEffect(() => {
    const el = bodyRef.current;
    if (el) el.scrollTop = el.scrollHeight;
  }, [messages, selectedId]);

  // -------- Toggle AI / Human mode.
  const setMode = useCallback(async (next: 'ai' | 'human') => {
    if (savingMode) return;
    if (settings?.mode === next) return;
    setSavingMode(true);
    const prev = settings;
    setSettings((s) => (s ? { ...s, mode: next } : { id: 1, mode: next, updated_at: new Date().toISOString() }));
    try {
      await dbUpdate('lily_settings', { id: eq(1) }, { mode: next, updated_at: new Date().toISOString() });
      toast.success(next === 'ai'
        ? 'Lilly is now answering automatically'
        : 'You are now answering as Lilly');
    } catch (err) {
      console.error('[LilyAdmin] setMode failed', err);
      setSettings(prev);
      toast.error('Failed to change Lilly mode');
    } finally {
      setSavingMode(false);
    }
  }, [savingMode, settings]);

  // -------- Admin sends as Lily.
  const send = useCallback(async () => {
    const text = input.trim();
    if (!text || !selectedId || !adminId || sending) return;
    setSending(true);
    setInput('');
    const tempId = 'tmp-' + Math.random().toString(36).slice(2);
    const optimistic: MessageRow = {
      id: tempId,
      thread_id: selectedId,
      sender: 'lily',
      sender_user_id: adminId,
      body: text,
      created_at: new Date().toISOString(),
      _pending: true,
    };
    setMessages((prev) => [...prev, optimistic]);
    try {
      const saved = await dbInsertReturning<MessageRow>('chat_messages', {
        thread_id: selectedId,
        sender: 'lily',
        sender_user_id: adminId,
        body: text,
      });
      setMessages((prev) => {
        const without = prev.filter((m) => m.id !== tempId);
        if (without.some((m) => m.id === saved.id)) return without;
        return [...without, saved];
      });
      try {
        const nowIso = new Date().toISOString();
        await dbUpdate('chat_threads', { id: eq(selectedId) }, {
          last_message_at: nowIso,
          admin_replied_at: nowIso,
        });
      } catch { /* non-fatal */ }
    } catch (err) {
      console.error('[LilyAdmin] send failed', err);
      setMessages((prev) => prev.filter((m) => m.id !== tempId));
      setInput(text);
      toast.error(err instanceof Error ? err.message : 'Send failed');
    } finally {
      setSending(false);
    }
  }, [input, selectedId, adminId, sending]);

  // -------- AI writing assist (admin-only) — rewrites composer text as
  // a polished Lily message. Never auto-sends. `draftOverride` is used
  // by "Regenerate" so it re-runs against the ORIGINAL draft, not the
  // previous suggestion.
  const runAssist = useCallback(async (draftOverride?: string) => {
    const draft = (draftOverride ?? input).trim();
    if (!draft || assistLoading) return;
    setAssistLoading(true);
    try {
      const ctx = messages.slice(-6).map((m) => ({ sender: m.sender, body: m.body }));
      const payload = await dbInvoke<{ ok?: boolean; suggestion?: string; error?: string } | null>(
        'lily-admin-assist',
        { draft, thread_context: ctx },
      );
      if (!payload?.ok || !payload.suggestion) {
        const friendly = payload?.error === 'assist_busy'
          ? 'Assist is busy — try again in a moment.'
          : (payload?.error || 'Assist failed');
        throw new Error(friendly);
      }

      setSuggestion(payload.suggestion);
      setAssistOriginalDraft(draft);
    } catch (err) {
      console.error('[LilyAdmin] assist failed', err);
      const msg = err instanceof Error ? err.message : 'Assist failed';
      toast.error(/edge function|non-2xx|FunctionsHttpError|FunctionsFetchError/i.test(msg)
        ? 'Assist is busy — try again in a moment.'
        : msg);
    } finally {
      setAssistLoading(false);
    }
  }, [input, messages, assistLoading]);

  // Clear suggestion when switching threads.
  useEffect(() => {
    setSuggestion(null);
    setAssistOriginalDraft('');
  }, [selectedId]);

  const sortedThreads = useMemo(() => {
    return [...threads].sort((a, b) => (b.last_message_at || '').localeCompare(a.last_message_at || ''));
  }, [threads]);

  const selectedThread = selectedId ? threads.find((t) => t.id === selectedId) ?? null : null;
  const selectedUser = selectedThread?.user_id ? users[selectedThread.user_id] : undefined;
  const mode = (settings?.mode ?? 'ai') as 'ai' | 'human';

  return (
    <div className="flex flex-col h-[calc(100vh-7rem)] -mx-8 -my-6 overflow-hidden">
      {/* ====== HEADER (compact one-line) ====== */}
      <div className="shrink-0 flex items-center gap-3 px-8 py-2 border-b border-border-light bg-surface">
        <h1 className="text-base font-semibold leading-none">Lilly</h1>
        <span className="text-[11px] text-text-secondary truncate">
          Project Coordinator chat console — AI / Human toggle in the top bar.
        </span>
      </div>


      {/* ====== TWO PANES ====== */}
      <div className="flex flex-1 min-h-0">
        {/* Thread list */}
        <aside className="w-[320px] shrink-0 border-r border-border-light bg-surface overflow-y-auto">
          {sortedThreads.length === 0 && (
            <div className="px-4 py-8 text-center text-sm text-text-secondary">
              No conversations yet.
            </div>
          )}
          {sortedThreads.map((t) => {
            const user = t.user_id ? users[t.user_id] : undefined;
            const last = lastByThread[t.id];
            const lastLilyAt = lastLilyByThread[t.id] ?? '';
            const hasUnread = !!last
              && last.sender === 'user'
              && (!lastLilyAt || last.created_at > lastLilyAt);
            const active = selectedId === t.id;
            return (
              <button
                key={t.id}
                type="button"
                onClick={() => setSelectedId(t.id)}
                className={cn(
                  'w-full text-left px-4 py-3 border-b border-border-light hover:bg-hover transition-colors',
                  active && 'bg-[#E1B978]/15 border-l-4 border-l-[#E1B978]',
                )}
              >
                <div className="flex items-start gap-3">
                  <div className="h-9 w-9 shrink-0 rounded-full bg-slate-200 text-slate-600 flex items-center justify-center text-sm font-semibold overflow-hidden">
                    {user?.avatar_url
                      ? <img src={user.avatar_url} alt="" className="h-full w-full object-cover" />
                      : (displayName(user)[0] ?? '?').toUpperCase()}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between gap-2">
                      <span className="text-sm font-medium truncate">{displayName(user)}</span>
                      <span className="text-[10px] text-text-secondary shrink-0">
                        {formatTime(t.last_message_at)}
                      </span>
                    </div>
                    <div className="flex items-center gap-1.5 mt-0.5">
                      <span className={cn('text-xs truncate flex-1', hasUnread ? 'text-text-primary font-medium' : 'text-text-secondary')}>
                        {last
                          ? (last.sender === 'lily' ? 'Lilly: ' : '') + last.body
                          : 'No messages yet'}
                      </span>
                      {hasUnread && (
                        <span className="h-2 w-2 rounded-full bg-violet-500 shrink-0" aria-label="unread" />
                      )}
                    </div>
                  </div>
                </div>
              </button>
            );
          })}
        </aside>

        {/* Conversation */}
        <section className="flex-1 min-w-0 flex flex-col bg-slate-50">
          {!selectedThread && (
            <div className="flex-1 flex items-center justify-center text-sm text-text-secondary">
              Select a conversation
            </div>
          )}
          {selectedThread && (
            <>
              <div ref={bodyRef} className="flex-1 overflow-y-auto px-6 py-4 space-y-3">
                {messages.map((m) => {
                  const fromLily = m.sender === 'lily';
                  return (
                    <div key={m.id} className={cn('flex flex-col', fromLily ? 'items-end' : 'items-start')}>
                      <div
                        className={cn(
                          'max-w-[70%] px-3.5 py-2 rounded-2xl text-[14px] leading-relaxed whitespace-pre-wrap break-words',
                          fromLily
                            ? 'bg-violet-600 text-white rounded-br-md'
                            : 'bg-white text-slate-800 ring-1 ring-slate-200 rounded-bl-md',
                          m._pending && 'opacity-60',
                        )}
                      >
                        {m.body}
                      </div>
                      <div className={cn('mt-1 text-[10px] text-slate-400 px-1', fromLily ? 'text-right' : 'text-left')}>
                        {m._pending ? 'Sending…' : formatTime(m.created_at)}
                      </div>
                    </div>
                  );
                })}
              </div>
              {suggestion && (
                <div className="mx-4 mt-2 mb-0 rounded-xl border border-violet-200 bg-violet-50/60 px-3 py-2.5">
                  <div className="flex items-center gap-1.5 text-[11px] font-medium text-violet-700 mb-1">
                    <Sparkles className="h-3 w-3" />
                    Suggested Lilly reply
                  </div>
                  <div className="text-[13px] leading-relaxed text-slate-800 whitespace-pre-wrap break-words">
                    {suggestion}
                  </div>
                  <div className="flex items-center gap-2 mt-2">
                    <button
                      type="button"
                      onClick={() => { setInput(suggestion); setSuggestion(null); }}
                      className="inline-flex items-center gap-1 px-2.5 py-1 rounded-md bg-violet-600 text-white text-xs font-medium hover:bg-violet-700"
                    >
                      <Check className="h-3 w-3" /> Use
                    </button>
                    <button
                      type="button"
                      onClick={() => void runAssist(assistOriginalDraft)}
                      disabled={assistLoading}
                      className="inline-flex items-center gap-1 px-2.5 py-1 rounded-md bg-white ring-1 ring-slate-200 text-slate-700 text-xs font-medium hover:bg-slate-50 disabled:opacity-50"
                    >
                      {assistLoading
                        ? <Loader2 className="h-3 w-3 animate-spin" />
                        : <RefreshCw className="h-3 w-3" />}
                      Regenerate
                    </button>
                    <button
                      type="button"
                      onClick={() => setSuggestion(null)}
                      className="inline-flex items-center gap-1 px-2.5 py-1 rounded-md text-slate-500 text-xs font-medium hover:text-slate-700"
                    >
                      <X className="h-3 w-3" /> Dismiss
                    </button>
                  </div>
                </div>
              )}
              <form
                onSubmit={(e) => { e.preventDefault(); void send(); }}
                className="flex items-center gap-2 px-4 py-3 border-t border-border-light bg-surface"
              >
                <input
                  type="text"
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                  placeholder={mode === 'ai'
                    ? 'Send as Lilly (overrides AI for this message)…'
                    : 'Reply as Lilly…'}
                  autoComplete="off"
                  className="flex-1 px-3 py-2 rounded-full bg-slate-100 text-slate-800 text-[14px] placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-violet-500"
                  disabled={sending}
                />
                <button
                  type="button"
                  onClick={() => void runAssist()}
                  disabled={!input.trim() || assistLoading || sending}
                  aria-label="AI assist"
                  title="Polish as Lilly"
                  className="h-9 px-3 inline-flex items-center gap-1.5 rounded-full bg-white ring-1 ring-violet-200 text-violet-700 text-xs font-medium hover:bg-violet-50 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
                >
                  {assistLoading
                    ? <Loader2 className="h-3.5 w-3.5 animate-spin" />
                    : <Sparkles className="h-3.5 w-3.5" />}
                  Assist
                </button>
                <button
                  type="submit"
                  disabled={!input.trim() || sending}
                  aria-label="Send as Lilly"
                  className="h-9 w-9 flex items-center justify-center rounded-full bg-violet-600 text-white hover:bg-violet-700 disabled:bg-slate-300 disabled:cursor-not-allowed transition-colors"
                >
                  <Send className="h-4 w-4" />
                </button>
              </form>
            </>
          )}
        </section>
      </div>
    </div>
  );
}
