/**
 * P4.7 — Admin Shift Control panel.
 *
 * Single table of every active manager with their live shift state:
 * status (active / locked / on_*_break / completed / not_started),
 * remaining time today, current mode, primary group, today's bio
 * count, and per-row actions: Lock, Unlock, Re-arm ("play again"),
 * Edit (opens the settings modal).
 *
 * Live state polled every 10s by useAdminShiftControl. Remaining
 * seconds for each row is computed client-side from the snapshotted
 * session fields (started_at + paused_total_seconds + the optional
 * current_pause_started_at) — exactly the same formula that
 * shift_tick uses server-side. Interpolated 1/sec locally between
 * polls so the displayed countdown feels smooth.
 *
 * Admin-only — the parent route already gates /admin to admins, and
 * each RPC enforces is_admin() server-side as the truth layer.
 */
import { useEffect, useMemo, useRef, useState } from 'react';
import { toast } from 'sonner';
import { Lock, Unlock, Pause, Pencil, Play, RefreshCw, RotateCcw, ListChecks, SkipForward, CalendarDays, Users, Clock3 } from 'lucide-react';
import { AdjustTimeDialog } from './AdjustTimeDialog';
import { apiFetch } from '@/lib/apiClient';
import { safeGetSession } from '@/lib/safeAuth';
import { UserActivityPanel } from './UserActivityPanel';
import { Spinner } from '@/components/Spinner';
import { EmptyMessage } from '@/components/EmptyMessage';
import {
  useAdminShiftControl,
  useShiftAdminSetAccountLock,
  useShiftAdminSetCanWorkNow,
  useShiftAdminUnlock,
  useShiftAdminRearm,
  useShiftAdminForceEnd,
  useShiftAdminSkipNextLock,
  useShiftAdminSetShiftMode,
  useShiftAdminSetConfig,
  useShiftGlobalSettings,
  useShiftAdminSetLocksPaused,
  type AdminShiftRow,
  type ShiftMode,
} from '@/hooks/shift';

import { AdminShiftEditModal } from './AdminShiftEditModal';
import { AdminShiftScheduleModal } from './AdminShiftScheduleModal';
import { useAuthStore } from '@/state/authStore';
// 0067 — Check, X icons used to live in BioRequestsQueue which has been
// removed (bio is now a hard limit, no admin approval flow). Keep Square
// (force-end + early-end flag pill) and Clock (late-start flag pill).
import { Square, Clock } from 'lucide-react';

// =====================================================================
// LockToggle — a navy/gold inline switch built on a styled
// <input type="checkbox"> + sibling <span> track.
//
// As of "unified lock toggle": this switch is the SINGLE SOURCE OF TRUTH
// for "is this manager currently blocked from working?" — covering BOTH
// lock types in one control:
//   • `checked === true` when EITHER
//        – shift_configs.account_locked = true   (permanent admin lock, 0064)
//        – today's shift_sessions.status = 'locked' (auto period-lock from
//          shift_self_period_lock OR a manual shift_admin_lock)
//   • Toggle OFF runs whichever paths apply (could be both):
//        – account_locked → shift_admin_set_account_lock(user, false)
//        – session locked → shift_admin_unlock(session_id)
//                       + shift_admin_rearm(session_id)
//          (unlock satisfies the status='locked' precondition + writes
//           the audit event; rearm zeroes the clock so the very next tick
//           does NOT instantly re-lock at the previous period boundary.)
//   • Toggle ON applies the strongest lock — account_locked = true. This
//     also blocks shift_start server-side via the 0064 guard.
//   • `disabled` is ONLY for the brief window while a mutation is in
//     flight (isBusy). NEVER tied to session_id presence: the toggle
//     must work for offline / no-session-today / brand-new / auto-locked
//     managers alike.
//   • Pure CSS, no new dependency.
// =====================================================================
function LockToggle({
  checked, disabled, onToggle, idAttr,
}: {
  checked: boolean;
  disabled: boolean;
  onToggle: (next: boolean) => void;
  idAttr: string;
}) {
  return (
    <label
      htmlFor={idAttr}
      className={
        'inline-flex items-center gap-3 select-none px-2 py-1.5 rounded-base ' +
        (disabled ? 'cursor-not-allowed opacity-60' : 'cursor-pointer hover:bg-hover')
      }
      title={checked ? 'Locked — flip OFF to unlock' : 'Unlocked — flip ON to lock'}
    >
      <span className="relative inline-flex items-center">
        <input
          id={idAttr}
          type="checkbox"
          role="switch"
          checked={checked}
          disabled={disabled}
          onChange={(e) => onToggle(e.target.checked)}
          // Visually hidden; the styled span beside is the visible track.
          className="peer sr-only"
        />
        {/* Track — enlarged for an easier click target. */}
        <span
          aria-hidden
          className={
            'block h-7 w-12 rounded-full transition-colors duration-150 ' +
            (checked
              ? 'bg-brand'                // navy when locked
              : 'bg-slate-700/60') +
            ' peer-focus-visible:ring-2 peer-focus-visible:ring-amber-400/60'
          }
        />
        {/* Knob — slides right when checked. Gold when ON for the navy/gold accent. */}
        <span
          aria-hidden
          className={
            'absolute top-0.5 left-0.5 h-6 w-6 rounded-full shadow-sm transition-transform duration-150 ' +
            (checked
              ? 'translate-x-5 bg-amber-300'    // gold knob = locked
              : 'translate-x-0 bg-slate-200')
          }
        />
      </span>
      <span className={
        'text-[13px] font-semibold tabular-nums w-[64px] ' +
        (checked ? 'text-amber-200' : 'text-text-secondary')
      }>
        {checked ? 'Locked' : 'Unlocked'}
      </span>
    </label>
  );
}

function formatHMS(s: number): string {
  const v = Math.max(0, Math.floor(s));
  const h = Math.floor(v / 3600);
  const m = Math.floor((v % 3600) / 60);
  const sec = v % 60;
  return `${h}:${String(m).padStart(2, '0')}:${String(sec).padStart(2, '0')}`;
}

// Client-side mirror of the shift_tick elapsed formula. Used for the
// remaining-time column so we don't issue 14 shift_tick RPCs per poll.
// 0078 — remaining = (required + admin_adjust) - elapsed.
function computeRemainingSeconds(row: AdminShiftRow, nowMs: number): number | null {
  if (!row.session_required_seconds || !row.session_started_at) return null;
  const startedMs = new Date(row.session_started_at).getTime();
  const pausedTotalMs = (row.session_paused_total_seconds ?? 0) * 1000;
  const currentPauseMs = row.session_current_pause_started_at
    ? Math.max(0, nowMs - new Date(row.session_current_pause_started_at).getTime())
    : 0;
  const elapsedMs = Math.max(0, nowMs - startedMs - pausedTotalMs - currentPauseMs);
  const adjustMs = (row.session_admin_adjust_seconds ?? 0) * 1000;
  const effectiveRequiredMs = Math.max(0, row.session_required_seconds * 1000 + adjustMs);
  const remainingMs = Math.max(0, effectiveRequiredMs - elapsedMs);
  return Math.floor(remainingMs / 1000);
}

// ---------------------------------------------------------------------
// computeNextLockSeconds — wall-clock seconds until the NEXT period
// auto-lock fires. Mirrors shift_tick's period_end_seconds formula:
//   elapsed = (now − started_at) − paused_total − current_pause_running
//   period_end = (current_period_index + 1) × period_seconds
//   secsLeft = max(0, period_end − elapsed)
//
// Returns null when no auto-lock will fire (no session / no period
// snapshot / shift_mode=manual / mode=off / status not in the
// lockable set).
// When skip_next_period_lock is armed, the next boundary is pushed
// forward by one full period_seconds (shift_self_period_lock will
// consume the skip + advance current_period_index instead of locking).
// ---------------------------------------------------------------------
const OFF_SENTINEL = 2147483647; // matches _shift_period_seconds('off')
function computeNextLockSeconds(row: AdminShiftRow, nowMs: number): number | null {
  if (row.shift_mode === 'manual') return null;
  if (row.mode === 'off') return null;
  if (!row.session_started_at) return null;
  if (row.session_period_seconds == null || row.session_period_seconds >= OFF_SENTINEL) return null;
  if (row.session_current_period_index == null) return null;
  if (row.status !== 'active' && row.status !== 'on_shift_break' && row.status !== 'on_bio_break') return null;

  const startedMs = new Date(row.session_started_at).getTime();
  const pausedTotalSec = row.session_paused_total_seconds ?? 0;
  const pauseRunningSec = row.session_current_pause_started_at
    ? Math.max(0, (nowMs - new Date(row.session_current_pause_started_at).getTime()) / 1000)
    : 0;
  const elapsedSec = Math.max(0, (nowMs - startedMs) / 1000 - pausedTotalSec - pauseRunningSec);
  const targetIndex = row.session_current_period_index + 1 + (row.skip_next_period_lock ? 1 : 0);
  const periodEndSec = targetIndex * row.session_period_seconds;
  return Math.max(0, Math.floor(periodEndSec - elapsedSec));
}

function formatNextLockMins(secs: number): string {
  if (secs < 60) return `${secs}s`;
  const m = Math.floor(secs / 60);
  if (m < 60) return `${m}m`;
  const h = Math.floor(m / 60);
  const rem = m % 60;
  return rem === 0 ? `${h}h` : `${h}h ${rem}m`;
}

function formatWallClock(atMs: number, tz: string | null): string {
  try {
    return new Intl.DateTimeFormat('en-GB', {
      hour: '2-digit', minute: '2-digit', hour12: false,
      timeZone: tz || undefined,
    }).format(new Date(atMs));
  } catch {
    return new Intl.DateTimeFormat('en-GB', { hour: '2-digit', minute: '2-digit', hour12: false }).format(new Date(atMs));
  }
}



const STATUS_LABEL: Record<NonNullable<AdminShiftRow['status']>, string> = {
  not_started:   'Not started',
  active:        'Active',
  on_shift_break:'Shift break',
  on_bio_break:  'Bio break',
  locked:        'LOCKED',
  completed:     'Completed',
};

// Fire-and-forget invocation of the shift-alert-email function for an
// admin-initiated account lock. Mirrors postShiftAlertEmail in
// ShiftDriver: Bearer auth with the admin's JWT, kind='lock',
// keepalive=true, errors logged only. The email function reuses the
// SAME calm kind='lock' template — no new template is created here.
async function sendAdminLockEmail(sessionId: string): Promise<void> {
  try {
    const { data: { session }, timedOut } = await safeGetSession('admin-lock-email');
    if (timedOut) { console.warn('[admin-lock] getSession timed out; skipping email'); return; }
    const token = session?.access_token;
    if (!token) { console.warn('[admin-lock] no access token; skipping email'); return; }
    const resp = await apiFetch('/api/shift-alert-email', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
      body: JSON.stringify({ session_id: sessionId, kind: 'lock' }),
      keepalive: true,
    });
    const body = (await resp.json().catch(() => ({} as Record<string, unknown>))) as Record<string, unknown>;
    if (!resp.ok || body.ok === false) {
      console.warn('[admin-lock] email post returned', resp.status, body);
    } else {
      console.info('[admin-lock] email post ok kind=lock', body);
    }
  } catch (e) {
    console.warn('[admin-lock] email post failed:', e);
  }
}
const STATUS_TONE: Record<NonNullable<AdminShiftRow['status']>, string> = {
  not_started:   'bg-slate-700/40 text-text-secondary',
  active:        'bg-emerald-900/30 text-emerald-300',
  on_shift_break:'bg-sky-900/30 text-sky-300',
  on_bio_break:  'bg-amber-900/30 text-amber-200',
  locked:        'bg-rose-900/35 text-rose-300',
  completed:     'bg-slate-800/40 text-text-secondary',
};

export function AdminShiftControlSection() {
  const profile = useAuthStore((s) => s.profile);
  const isAdmin = !!profile && (profile.role === 'admin' || profile.is_super_admin);
  const { data: rows, isLoading, refetch, isFetching } = useAdminShiftControl(isAdmin);
  const setAccountLock = useShiftAdminSetAccountLock();
  const setCanWorkNow  = useShiftAdminSetCanWorkNow();
  const unlockMut  = useShiftAdminUnlock();
  const rearmMut   = useShiftAdminRearm();
  const forceMut   = useShiftAdminForceEnd();
  const skipNextMut = useShiftAdminSkipNextLock();
  const setShiftMode = useShiftAdminSetShiftMode();
  const setConfigMut = useShiftAdminSetConfig();
  // 0077 — global "Pause all automatic locks" master switch.
  const { data: globalSettings } = useShiftGlobalSettings(isAdmin);
  const setLocksPaused = useShiftAdminSetLocksPaused();
  const [locksPausedOverride, setLocksPausedOverride] = useState<boolean | null>(null);
  const locksPaused = locksPausedOverride ?? (globalSettings?.locks_paused ?? false);
  // Clear the optimistic override once the polled server state matches.
  useEffect(() => {
    if (locksPausedOverride === null) return;
    if (globalSettings && globalSettings.locks_paused === locksPausedOverride) {
      setLocksPausedOverride(null);
    }
  }, [globalSettings, locksPausedOverride]);
  const runToggleLocksPaused = async (next: boolean) => {
    setLocksPausedOverride(next);
    try {
      const res = await setLocksPaused.mutateAsync(next);
      if (next) {
        toast.success('Paused all automatic locks');
      } else {
        const n = res.sessions_advanced_on_resume ?? 0;
        toast.success(
          n > 0
            ? `Resumed — ${n} session${n === 1 ? '' : 's'} advanced past pause; next boundary is in the future`
            : 'Resumed — automatic locks active',
        );
      }
    } catch (e) {
      setLocksPausedOverride(null);
      toast.error(e instanceof Error ? e.message : 'Toggle failed');
    }
  };

  const runSetShiftMode = async (row: AdminShiftRow, mode: 'auto' | 'manual') => {
    const current = (row.shift_mode ?? 'manual');
    if (current === mode) return;
    const who = row.full_name ?? row.username;
    if (!confirm(`Switch ${who} to ${mode === 'auto' ? 'Auto' : 'Manual'} mode?`)) return;
    setBusy(row.user_id);
    try {
      const res = await setShiftMode.mutateAsync({ targetUserId: row.user_id, mode });
      const note = res.seeded_default_schedule ? ' (seeded default schedule)' : '';
      toast.success(`${who} → ${mode === 'auto' ? 'Auto' : 'Manual'} mode${note}`);
    } catch (e) {
      toast.error(e instanceof Error ? e.message : 'Could not change mode');
    } finally {
      setBusy(null);
    }
  };


  const [editRow, setEditRow] = useState<AdminShiftRow | null>(null);
  const [scheduleRow, setScheduleRow] = useState<AdminShiftRow | null>(null);
  const [activityRow, setActivityRow] = useState<AdminShiftRow | null>(null);
  const [adjustRow, setAdjustRow] = useState<AdminShiftRow | null>(null);
  const [busy, setBusy] = useState<string | null>(null);
  // Per-user optimistic lock override.
  //
  // Flicker fix — RECONCILE-ON-MATCH (not "clear in finally"):
  //   The toggle flips → override is set to `next` immediately so the
  //   switch animates without waiting for the network.
  //   The override is then KEPT until the polled `rows` actually
  //   reflects the new server state. An effect below watches `rows`
  //   and clears any user's override ONLY when the polled row's
  //   derived locked state == that user's override. This eliminates
  //   the old finally-clear → stale-poll → next-poll-flip cycle that
  //   caused the on→off→on flicker.
  //
  // Cleared in two cases:
  //   • RECONCILE: polled row's derived state matches the override.
  //   • REVERT  : the RPC threw (manual clear in the catch block).
  const [lockOverrides, setLockOverrides] = useState<Map<string, boolean>>(() => new Map());
  const clearLockOverride = (userId: string) => {
    setLockOverrides((prev) => {
      if (!prev.has(userId)) return prev;
      const next = new Map(prev);
      next.delete(userId);
      return next;
    });
  };

  // Reconcile-on-match: when the 10s poll lands, drop overrides whose
  // server state has caught up. This is the ONLY non-error path that
  // clears an override, so the optimistic UI never reverts to stale
  // data and never flips on the in-between poll.
  useEffect(() => {
    if (!rows) return;
    if (lockOverrides.size === 0) return;
    setLockOverrides((prev) => {
      if (prev.size === 0) return prev;
      let changed = false;
      const next = new Map(prev);
      for (const [userId, want] of prev) {
        const row = rows.find((r) => r.user_id === userId);
        if (!row) continue;
        const have = (row.account_locked ?? false) || row.status === 'locked';
        if (have === want) {
          next.delete(userId);
          changed = true;
        }
      }
      return changed ? next : prev;
    });
  }, [rows, lockOverrides]);

  // 1/sec tick so the Remaining column counts down smoothly between
  // the 10s server polls. Just a heartbeat — the actual numbers come
  // from computeRemainingSeconds(row, now()).
  const [now, setNow] = useState<number>(() => Date.now());
  const intervalRef = useRef<number | null>(null);
  useEffect(() => {
    intervalRef.current = window.setInterval(() => setNow(Date.now()), 1000);
    return () => { if (intervalRef.current) clearInterval(intervalRef.current); };
  }, []);

  // When the server poll lands, snap the local clock to it.
  useEffect(() => { if (rows) setNow(Date.now()); }, [rows]);

  const summary = useMemo(() => {
    if (!rows) return null;
    return rows.reduce(
      (a, r) => ({
        total:    a.total + 1,
        active:   a.active + (r.status === 'active' ? 1 : 0),
        locked:   a.locked + (r.status === 'locked' ? 1 : 0),
        onBreak:  a.onBreak + (r.status === 'on_shift_break' || r.status === 'on_bio_break' ? 1 : 0),
        notStarted: a.notStarted + ((r.status === 'not_started' || r.status === null) ? 1 : 0),
      }),
      { total: 0, active: 0, locked: 0, onBreak: 0, notStarted: 0 },
    );
  }, [rows]);

  if (!isAdmin) return null;

  // Unified flip handler — ONE switch reflects+controls BOTH lock types.
  //
  // Toggle ON (admin lock):
  //   • Always applies the ACCOUNT-level lock (the strongest — also blocks
  //     shift_start server-side via the 0064 guard at the SQL layer).
  //   • Works regardless of session_id — offline / no-session-today /
  //     brand-new managers are all lockable.
  //
  // Toggle OFF (admin unlock — free the manager to work whatever the cause):
  //   • If account_locked === true → shift_admin_set_account_lock(user, false).
  //     (As of migration 0065, that RPC ALSO finalizes any admin-paused
  //     session — credits the pause duration to paused_total_seconds and
  //     restores status='active'. So zero time is lost during the lock.)
  //   • If the session is in a TRUE period-lock (status='locked' AND
  //     session_locked_reason='period_lock'), call shift_admin_unlock —
  //     and ONLY shift_admin_unlock. It cleanly resumes the session:
  //     status='active', credits the pause to paused_total_seconds,
  //     advances current_period_index by 1 so the next period boundary
  //     moves forward and shift_tick does NOT immediately report
  //     period_lock_due=true again.
  //
  //   • CRITICAL — we do NOT call shift_admin_rearm here. Rearm is a
  //     deliberate FULL RESET (started_at=now(), paused_total_seconds=0,
  //     period_index=0, bio_break_count_today=0,
  //     bio_break_total_seconds_today=0). Calling it on unlock was the
  //     founder's bug: the manager's bio break counter was zeroed every
  //     time the periodic lock fired and the admin unlocked them.
  //
  //     Rearm stays wired to the separate "Re-arm" button (runRearm
  //     below) which the admin clicks deliberately. That is the ONLY
  //     path that resets counts/timer.
  //   • Both account-unlock and period-unlock run when both apply.
  //
  // Optimistic flip BEFORE await so the switch animates immediately.
  // Override is RECONCILED with the polled row (see the effect above) —
  // never cleared in finally — so there's no on→off→on flip while the
  // 10s poll catches up.
  const runLockToggle = async (row: AdminShiftRow, next: boolean) => {
    setLockOverrides((prev) => {
      const m = new Map(prev);
      m.set(row.user_id, next);
      return m;
    });
    setBusy(row.user_id);
    try {
      if (next) {
        await setAccountLock.mutateAsync({ targetUserId: row.user_id, locked: true });
        toast.success(`Locked ${row.full_name ?? row.username}`);
        // Fire-and-forget: send the calm kind='lock' alert email to
        // the manager (same template used by the self period-lock
        // path in ShiftDriver). No await — never block or fail the
        // lock toggle on email errors. No email on UNLOCK by design.
        // No email on global pause or skip-next-lock — those paths
        // never call this toggle handler.
        // No double-send: self period-lock fires from the EMPLOYEE's
        // ShiftDriver after shift_self_period_lock returns
        // already_locked=false. Admin account-lock fires here from
        // the ADMIN's browser after shift_admin_set_account_lock
        // succeeds. They are distinct user actions on different
        // machines targeting different RPCs, so the same lock event
        // cannot trigger both. Requires a session row today (email
        // function validates session_id) — we skip silently when the
        // user has no session yet.
        if (row.session_id) {
          void sendAdminLockEmail(row.session_id);
        }
      } else {
        const ranAccount = row.account_locked === true;
        const ranPeriod  = row.status === 'locked'
                        && row.session_locked_reason === 'period_lock'
                        && !!row.session_id;
        if (ranAccount) {
          await setAccountLock.mutateAsync({ targetUserId: row.user_id, locked: false });
        }
        if (ranPeriod) {
          // ONLY resume — no rearm. shift_admin_unlock advances the
          // period index by 1 so a re-lock is impossible until the
          // next period actually ends.
          await unlockMut.mutateAsync(row.session_id!);
        }
        const who = row.full_name ?? row.username;
        const msg =
          ranAccount && ranPeriod ? `Unlocked ${who} — account + period lock cleared, break counts preserved` :
          ranAccount               ? `Unlocked ${who}'s account` :
          ranPeriod                ? `Unlocked ${who} — period lock cleared, break counts preserved` :
                                     `Unlocked ${who}`;
        toast.success(msg);
      }
    } catch (err) {
      toast.error(err instanceof Error ? err.message : (next ? 'Lock failed' : 'Unlock failed'));
      // Revert the optimistic flip on error so the toggle snaps back to
      // server truth. Reconcile-on-match handles the success path.
      clearLockOverride(row.user_id);
    } finally {
      setBusy(null);
    }
  };
  const runForceEnd = async (row: AdminShiftRow) => {
    if (!row.session_id) { toast.error('No session today — nothing to end'); return; }
    if (!confirm(`Force end ${row.full_name ?? row.username}'s shift NOW? Their session will be marked completed regardless of elapsed time. If before their expected end, an early_end_flag is recorded.`)) return;
    setBusy(row.user_id);
    try {
      const r = await forceMut.mutateAsync(row.session_id);
      const tag = r.early_end_flag ? ` (early by ${r.early_end_minutes ?? '?'} min)` : '';
      toast.success(`Force-ended ${row.full_name ?? row.username}${tag}`);
    } catch (err) { toast.error(err instanceof Error ? err.message : 'Force-end failed'); }
    finally { setBusy(null); }
  };
  const runRearm = async (row: AdminShiftRow) => {
    if (!row.session_id) { toast.error('No session today to un-skip'); return; }
    if (!confirm(`Un-Skip Next Lock for ${row.full_name ?? row.username}? Timer resets fresh, period index 0, bio counters cleared.`)) return;
    setBusy(row.user_id);
    try {
      await rearmMut.mutateAsync(row.session_id);
      toast.success(`Un-Skipped next lock for ${row.full_name ?? row.username}`);
    } catch (err) { toast.error(err instanceof Error ? err.message : 'Un-Skip Next Lock failed'); }
    finally { setBusy(null); }
  };

  // UI-shortcuts batch (#2): inline Mode dropdown saver. Reuses the
  // exact same shift_admin_set_config RPC the Edit dialog uses, just
  // wired to all-current-values + new mode. Falls back to the same
  // defaults the Edit dialog uses when a config field is null.
  const runInlineModeChange = async (row: AdminShiftRow, nextMode: ShiftMode) => {
    if ((row.mode ?? 'medium') === nextMode) return;
    setBusy(row.user_id);
    try {
      await setConfigMut.mutateAsync({
        target_user_id:               row.user_id,
        mode:                         nextMode,
        shift_break_seconds:          row.shift_break_seconds ?? 3600,
        bio_break_max_per_day:        row.bio_break_max_per_day ?? 7,
        bio_break_warn_count:         row.bio_break_warn_count ?? 6,
        bio_break_warn_total_seconds: row.bio_break_warn_total_seconds ?? 3600,
        bio_break_max_seconds_each:   row.bio_break_max_seconds_each ?? 900,
        primary_group_id:             row.primary_group_id,
        timezone:                     row.timezone ?? 'Asia/Manila',
        late_start_threshold_seconds: row.late_start_threshold_seconds ?? 900,
      });
      const label = nextMode === 'off' ? 'Off' : nextMode === 'easy' ? 'Easy' : nextMode === 'medium' ? 'Medium' : 'Hard';
      toast.success(`${row.full_name ?? row.username} → mode ${label}`);
    } catch (err) {
      toast.error(err instanceof Error ? err.message : 'Mode change failed');
    } finally {
      setBusy(null);
    }
  };


  // 0075 — admin arms the one-shot "skip next period lock" flag for the
  // selected manager's session. Server-side, the very next
  // shift_self_period_lock call will consume the flag (NOT lock + advance
  // current_period_index by 1); the period after that locks normally.
  // Works whether the user is online or offline — the flag lives on the
  // session row and is read at lock time, not at click time.
  const runSkipNext = async (row: AdminShiftRow) => {
    if (!row.session_id) { toast.error('No session today to skip'); return; }
    setBusy(row.user_id);
    try {
      await skipNextMut.mutateAsync(row.session_id);
      toast.success(`Next lock will be skipped for ${row.full_name ?? row.username}.`);
    } catch (err) { toast.error(err instanceof Error ? err.message : 'Skip-next failed'); }
    finally { setBusy(null); }
  };

  // ===================================================================
  // Phase 6a — "Currently on Break" live card.
  //
  // Reuses the same `rows` from useAdminShiftControl (10s poll) plus the
  // existing 1/sec `now` ticker. No new RPC — admins already have RLS
  // SELECT on shift_sessions, and we now also fetch current_break_started_at
  // + current_pause_reason in the query.
  //
  // Math mirrors the employee side (BreakControls.tsx formatMS + the
  // shift_tick payload): elapsed = now - current_break_started_at; the
  // displayed value is (cap - elapsed) — going NEGATIVE on lunch
  // overstay exactly like the employee timer.
  //   • Bio   cap = bio_break_max_seconds_each
  //   • Lunch cap = shift_break_seconds
  // ===================================================================
  const onBreakRows = (rows ?? []).filter(
    (r) => r.status === 'on_shift_break' || r.status === 'on_bio_break',
  );

  // Phase 6b — rows that took any break today (bio, lunch, or currently on break).
  const breakTodayRows = (rows ?? []).filter(
    (r) =>
      r.status === 'on_shift_break' ||
      r.status === 'on_bio_break' ||
      (r.session_bio_break_count_today ?? 0) > 0 ||
      (r.shift_break_count_today ?? 0) > 0,
  );
  const groupBreakMap = new Map<string, typeof breakTodayRows>();
  for (const r of breakTodayRows) {
    const g = r.primary_group_name ?? 'Unassigned';
    const arr = groupBreakMap.get(g) ?? [];
    arr.push(r);
    groupBreakMap.set(g, arr);
  }
  const sortedGroupBreaks = Array.from(groupBreakMap.entries()).sort((a, b) =>
    a[0].localeCompare(b[0]),
  );

  return (
    <>
    <div className="flex flex-col">
    <section className="order-2 bg-surface border border-border-light rounded-md p-6 mb-4">
      <header className="mb-3">
        <h2 className="text-lg font-semibold inline-flex items-center gap-2">
          <Pause className="h-4 w-4 text-amber-300" />
          Currently on Break
        </h2>
        <p className="text-sm text-text-secondary">
          Live view of every manager on a break right now — same running
          timer they see.
        </p>
      </header>
      {onBreakRows.length === 0 ? (
        <div className="text-sm text-text-secondary px-2 py-6 text-center">
          No one is on a break right now.
        </div>
      ) : (
        <ul className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
          {onBreakRows.map((r) => {
            const isBio = r.status === 'on_bio_break';
            const cap = isBio
              ? (r.bio_break_max_seconds_each ?? 900)
              : (r.shift_break_seconds ?? 0);
            const startedMs = r.session_current_break_started_at
              ? new Date(r.session_current_break_started_at).getTime()
              : null;
            const elapsed = startedMs !== null
              ? Math.max(0, Math.floor((now - startedMs) / 1000))
              : 0;
            const remaining = cap - elapsed; // negative = overstay (lunch)
            const overstay  = !isBio && remaining < 0;
            const lowBio    = isBio && remaining <= 60;
            const tone = overstay
              ? 'border-rose-500/60 bg-rose-950/30'
              : lowBio
                ? 'border-amber-400/60 bg-amber-950/20'
                : isBio
                  ? 'border-sky-500/40 bg-sky-950/20'
                  : 'border-amber-400/40 bg-amber-950/10';
            const timerTone = overstay
              ? 'text-rose-300'
              : lowBio
                ? 'text-amber-200'
                : 'text-amber-300';
            return (
              <li
                key={r.user_id}
                className={`rounded-md border px-4 py-3 ${tone}`}
              >
                <div className="flex items-center justify-between gap-2">
                  <div className="min-w-0">
                    <div className="text-text-primary font-semibold truncate">
                      {r.full_name ?? r.username}
                    </div>
                    <div className="text-[11px] text-text-secondary truncate">
                      {r.email}
                    </div>
                  </div>
                  <span
                    className={
                      'inline-flex items-center h-6 px-2 rounded-pill text-[11px] font-semibold ' +
                      (isBio ? 'bg-sky-900/40 text-sky-200' : 'bg-amber-900/40 text-amber-100')
                    }
                  >
                    {isBio ? 'Bio Break' : 'Lunch / Dinner Break'}
                  </span>
                </div>
                <div className="mt-1 text-[11px] text-text-secondary truncate">
                  Group: {r.primary_group_name ?? <span className="text-text-disabled">—</span>}
                </div>
                <div className="mt-2 flex items-baseline gap-2">
                  <span className={`timer-readout ${timerTone}`}>
                    {formatBreakMS(remaining)}
                  </span>
                  <span className="text-[11px] text-text-secondary">
                    {overstay ? 'overstay' : (isBio ? 'remaining' : 'remaining')}
                  </span>
                </div>
              </li>
            );
          })}
        </ul>
      )}
    </section>

    {/* Phase 6b — "Breaks Today by Group" rollup */}
    <section className="order-3 bg-surface border border-border-light rounded-md p-6 mb-4">
      <header className="mb-3">
        <h2 className="text-lg font-semibold inline-flex items-center gap-2">
          <Users className="h-4 w-4 text-amber-300" />
          Breaks Today by Group
        </h2>
        <p className="text-sm text-text-secondary">
          People who took a break today, grouped by team.
        </p>
      </header>
      {sortedGroupBreaks.length === 0 ? (
        <div className="text-sm text-text-secondary px-2 py-6 text-center">
          No breaks taken yet today.
        </div>
      ) : (
        <div className="space-y-4">
          {sortedGroupBreaks.map(([groupName, members]) => {
            return (
              <div key={groupName} className="rounded-md border border-border-light p-4">
                <h3 className="text-sm font-semibold text-text-primary mb-2 flex items-center gap-2">
                  <span className="inline-flex items-center justify-center h-5 min-w-[1.25rem] px-1.5 rounded-pill text-[10px] font-bold bg-brand/20 text-amber-200">
                    {members.length}
                  </span>
                  {groupName}
                </h3>
                <ul className="space-y-2">
                  {members.map((r) => {
                    const bc = r.session_bio_break_count_today ?? 0;
                    let bioColor = 'text-emerald-300';
                    if (bc >= 6) bioColor = 'text-rose-300';
                    else if (bc === 5) bioColor = 'text-slate-300';
                    else if (bc === 4) bioColor = 'text-amber-300';
                    const onBreakNow = r.status === 'on_shift_break' || r.status === 'on_bio_break';
                    return (
                      <li key={r.user_id} className="flex items-center justify-between gap-3">
                        <div className="min-w-0">
                          <div className="text-text-primary font-medium text-sm truncate">
                            {r.full_name ?? r.username}
                          </div>
                          <div className="text-[11px] text-text-secondary truncate">
                            {r.email}
                          </div>
                        </div>
                        <div className="flex items-center gap-2 shrink-0">
                          <span className={`text-sm font-medium tabular-nums ${bioColor}`}>
                            {bc}
                          </span>
                          <span className="text-[11px] text-text-secondary">bio</span>
                          {onBreakNow && (
                            <span className="inline-flex items-center h-5 px-1.5 rounded-pill text-[10px] font-semibold bg-amber-900/40 text-amber-100">
                              On break
                            </span>
                          )}
                        </div>
                      </li>
                    );
                  })}
                </ul>
              </div>
            );
          })}
        </div>
      )}
    </section>

    <section className="order-1 bg-surface border border-border-light rounded-md p-6 mb-4">
      {/* 0077 — global "Pause all automatic locks" master switch.
          Lives at the TOP of Shift Control. Per-user mode is NEVER
          modified by this; manual admin locks keep working while
          paused. Server-side gates live inside shift_self_period_lock
          and shift_tick. */}
      <div
        className={
          'mb-4 flex items-center justify-between gap-3 rounded-md border px-4 py-3 ' +
          (locksPaused
            ? 'border-amber-700/50 bg-amber-900/20'
            : 'border-border-light bg-canvas')
        }
      >
        <div className="min-w-0">
          <div className="text-sm font-semibold text-text-primary">
            Pause all automatic locks
          </div>
          <div className="text-[12px] text-text-secondary">
            Master blanket on top of per-user modes. Manual admin locks still work while paused; per-user modes are not modified.
          </div>
          {locksPaused && (
            <div className="mt-1.5 inline-flex items-center gap-1.5 h-6 px-2 rounded-pill text-[11px] font-semibold bg-amber-900/40 text-amber-200">
              <Pause className="h-3 w-3" />
              All automatic locks are paused
            </div>
          )}
        </div>
        <label className="inline-flex items-center gap-2 select-none cursor-pointer shrink-0">
          <span className="relative inline-flex items-center">
            <input
              type="checkbox"
              role="switch"
              checked={locksPaused}
              onChange={(e) => void runToggleLocksPaused(e.target.checked)}
              disabled={setLocksPaused.isPending}
              className="peer sr-only"
            />
            <span className="block w-11 h-6 rounded-pill bg-slate-700 peer-checked:bg-amber-600 transition-colors" />
            <span className="absolute left-0.5 top-0.5 h-5 w-5 rounded-pill bg-white shadow transition-transform peer-checked:translate-x-5" />
          </span>
          <span className="text-[12px] font-medium text-text-primary">
            {locksPaused ? 'Paused' : 'Active'}
          </span>
        </label>
      </div>

      <header className="flex items-center justify-between mb-4">
        <div>
          <h2 className="text-lg font-semibold inline-flex items-center gap-2">
            <Lock className="h-4 w-4 text-text-secondary" />
            Shift Control
          </h2>
          <p className="text-sm text-text-secondary">
            Live state of every manager + per-employee settings. Polls every 10 s.
            {summary && (
              <span className="ml-2 text-text-secondary">
                · {summary.active} active · {summary.locked} locked · {summary.onBreak} on break · {summary.notStarted} not started
              </span>
            )}
          </p>
        </div>
        <button
          type="button"
          onClick={() => void refetch()}
          disabled={isFetching}
          title="Refresh"
          className="h-9 w-9 inline-flex items-center justify-center rounded-base text-text-secondary hover:bg-hover disabled:opacity-40"
          aria-label="Refresh"
        >
          <RefreshCw className={`h-4 w-4 ${isFetching ? 'animate-spin' : ''}`} />
        </button>
      </header>

      {isLoading ? (
        <div className="flex items-center justify-center py-8"><Spinner className="h-6 w-6 text-brand" /></div>
      ) : !rows || rows.length === 0 ? (
        <EmptyMessage title="No managers" description="No active managers configured." icon={<Lock className="h-7 w-7" />} />
      ) : (
        <div className="w-full">
          <table className="w-full text-left text-sm">
            <thead>
              <tr className="text-[11px] uppercase tracking-wide text-text-secondary border-b border-border-light">
                <th className="py-2 pr-3 font-semibold">Manager</th>
                <th className="py-2 pr-3 font-semibold">Status</th>
                <th className="py-2 pr-3 font-semibold">Remaining</th>
                <th className="py-2 pr-3 font-semibold">Next lock</th>
                <th className="py-2 pr-3 font-semibold">Mode</th>
                <th className="py-2 pr-3 font-semibold">Primary group</th>
                <th className="py-2 pr-3 font-semibold">Bio</th>
                <th className="py-2 pr-0 font-semibold text-right">Actions</th>
              </tr>
            </thead>
            <tbody>
              {rows.map((r) => {
                const status = r.status ?? 'not_started';
                // 0080 — completed sessions show 0:00:00 + "Completed"
                // chip (no running clock). Underlying session row is
                // never zeroed — this is purely display.
                const remaining = (r.status === 'active' || r.status === 'on_shift_break' || r.status === 'on_bio_break' || r.status === 'locked')
                  ? computeRemainingSeconds(r, now)
                  : (r.status === 'completed' ? 0 : null);
                const isBusy = busy === r.user_id;
                return (
                  <tr key={r.user_id} className="border-b border-border-hair last:border-0 hover:bg-hover/40 transition-colors">
                    <td className="py-2 pr-3 max-w-[180px]">
                      <div className="text-text-primary font-medium truncate" title={r.full_name ?? r.username}>{r.full_name ?? r.username}</div>
                      <div className="text-[11px] text-text-secondary truncate" title={`@${r.username}`}>@{r.username}</div>
                    </td>

                    <td className="py-2 pr-3">
                      <span className={`inline-flex items-center h-6 px-2 rounded-pill text-[11px] font-semibold ${STATUS_TONE[status]}`}>
                        {STATUS_LABEL[status]}
                      </span>
                      {status === 'locked' && r.session_locked_reason && (
                        <div className="text-[10px] text-text-secondary mt-0.5">{r.session_locked_reason}</div>
                      )}
                      {/* P4.5 — flag chips */}
                      {r.late_start_flag === true && (
                        <span className="inline-flex items-center gap-1 h-5 px-1.5 mt-1 mr-1 rounded-pill text-[10px] font-semibold bg-amber-900/30 text-amber-200" title={`Started ${r.late_start_minutes ?? '?'} min after scheduled start`}>
                          <Clock className="h-3 w-3" />
                          Late {r.late_start_minutes}m
                        </span>
                      )}
                      {r.early_end_flag === true && (
                        <span className="inline-flex items-center gap-1 h-5 px-1.5 mt-1 rounded-pill text-[10px] font-semibold bg-rose-900/30 text-rose-200" title={`Ended ${r.early_end_minutes ?? '?'} min before expected end`}>
                          <Square className="h-3 w-3" />
                          Early end {r.early_end_minutes}m
                        </span>
                      )}
                    </td>
                    <td className="py-2 pr-3 tabular-nums">
                      {/*
                        Founder requirement: the admin must SEE whether
                        each manager's timer is currently FROZEN (paused
                        by a lock — period_lock or admin lock) vs
                        RUNNING (active / on a paid break).

                        - status='locked' → amber "Paused (locked)" badge
                          + the remaining value shown bold-amber. The
                          value is the FROZEN snapshot at lock time —
                          our computeRemainingSeconds mirrors the server
                          shift_tick formula so it does NOT decrement
                          while paused.
                        - status='active' / 'on_*_break' → green "Running"
                          badge + live-decrementing remaining (breaks are
                          paid, timer keeps running — DECISION 1).
                      */}
                      {remaining !== null ? (
                        <div className="flex flex-col items-start gap-1">
                          <span className={status === 'locked' ? 'text-amber-200 font-semibold' : (status === 'completed' ? 'text-text-secondary' : '')}>
                            {formatHMS(remaining)}
                          </span>
                          {status === 'locked' ? (
                            <span className="inline-flex items-center gap-1 h-5 px-1.5 rounded-pill text-[10px] font-semibold bg-amber-900/35 text-amber-200">
                              <Pause className="h-2.5 w-2.5" />
                              Paused (locked)
                            </span>
                          ) : status === 'completed' ? (
                            <span className="inline-flex items-center gap-1 h-5 px-1.5 rounded-pill text-[10px] font-semibold bg-slate-700/40 text-text-secondary">
                              Completed
                            </span>
                          ) : (
                            <span className="inline-flex items-center gap-1 h-5 px-1.5 rounded-pill text-[10px] font-semibold bg-emerald-900/30 text-emerald-300">
                              <Play className="h-2.5 w-2.5" />
                              Running
                            </span>
                          )}
                        </div>
                      ) : (
                        <span className="text-text-disabled">—</span>
                      )}
                    </td>
                    <td className="py-2 pr-3 tabular-nums">
                      {(() => {
                        // 0077 — While the global pause is on, ALL
                        // auto-lock users show "paused". Mode-Off
                        // users keep "—" (they never auto-lock either
                        // way, so "paused" would be misleading).
                        if (locksPaused) {
                          if ((r.mode ?? 'medium') === 'off') {
                            return <span className="text-text-disabled">—</span>;
                          }
                          return (
                            <span className="inline-flex items-center gap-1 h-5 px-1.5 rounded-pill text-[10px] font-semibold bg-amber-900/35 text-amber-200" title="All automatic locks are globally paused">
                              <Pause className="h-2.5 w-2.5" />
                              paused
                            </span>
                          );
                        }
                        const secsLeft = computeNextLockSeconds(r, now);
                        if (secsLeft === null) return <span className="text-text-disabled">—</span>;
                        const wall = formatWallClock(now + secsLeft * 1000, r.timezone);
                        const amber = secsLeft <= 600;
                        return (
                          <div className="flex flex-col items-start gap-1">
                            <span className={amber ? 'text-amber-300 font-semibold' : ''}>
                              in {formatNextLockMins(secsLeft)} <span className="text-text-secondary">({wall})</span>
                            </span>
                            {r.skip_next_period_lock && (
                              <span className="inline-flex items-center gap-1 h-5 px-1.5 rounded-pill text-[10px] font-semibold bg-sky-900/35 text-sky-200" title="Admin armed: the next period lock will be skipped">
                                <SkipForward className="h-2.5 w-2.5" />
                                skip armed
                              </span>
                            )}
                          </div>
                        );
                      })()}
                    </td>
                    <td className="py-2 pr-3">
                      {(() => {
                        const m: ShiftMode = (r.mode ?? 'medium') as ShiftMode;
                        return (
                          <select
                            value={m}
                            onChange={(e) => void runInlineModeChange(r, e.target.value as ShiftMode)}
                            disabled={isBusy}
                            title="Mode (period-lock cadence) — saves immediately"
                            className="h-8 px-2 rounded-base bg-canvas border border-border-light text-text-primary text-[12px] disabled:opacity-40"
                          >
                            <option value="off">Off</option>
                            <option value="easy">Easy (4h)</option>
                            <option value="medium">Medium (3h)</option>
                            <option value="hard">Hard (1h)</option>
                          </select>
                        );
                      })()}
                    </td>
                    <td className="py-2 pr-3 truncate max-w-[180px]" title={r.primary_group_name ?? ''}>
                      {r.primary_group_name ?? <span className="text-text-disabled">—</span>}
                    </td>
                    <td className="py-2 pr-3 tabular-nums">
                      {(() => {
                        const bc = r.session_bio_break_count_today ?? 0;
                        let colorClass = 'text-emerald-300';
                        if (bc >= 6) colorClass = 'text-rose-300';
                        else if (bc === 5) colorClass = 'text-slate-300';
                        else if (bc === 4) colorClass = 'text-amber-300';
                        return (
                          <span className={`${colorClass} font-medium`}>
                            {bc}/{r.bio_break_max_per_day ?? 7}
                          </span>
                        );
                      })()}
                    </td>
                    <td className="py-2 pr-0">

                      <div className="flex flex-wrap items-center justify-end gap-1.5 gap-y-1.5">
                        {/* 11/12-c — Auto/Manual mode pill + flipper.
                            Auto = navy/gold accent (scheduled lock/unlock).
                            Manual = neutral (open all day; auto-lock off). */}
                        {(() => {
                          const mode: 'auto' | 'manual' = (r.shift_mode ?? 'manual');
                          const isAuto = mode === 'auto';
                          return (
                            <div
                              className="inline-flex items-stretch h-8 rounded-base overflow-hidden border"
                              style={{ borderColor: isAuto ? '#E1B978' : 'rgb(var(--border-light))' }}
                              title={isAuto
                                ? 'Auto — shift locks/unlocks on schedule'
                                : 'Manual — open all day, no schedule, no auto-lock'}
                            >
                              <button
                                type="button"
                                onClick={() => void runSetShiftMode(r, 'auto')}
                                disabled={isBusy}
                                className="px-2 text-[12px] font-medium disabled:opacity-40"
                                style={isAuto
                                  ? { background: '#0F1E36', color: '#E1B978' }
                                  : { background: 'transparent', color: 'rgb(var(--text-secondary))' }}
                              >
                                Auto
                              </button>
                              <button
                                type="button"
                                onClick={() => void runSetShiftMode(r, 'manual')}
                                disabled={isBusy}
                                className="px-2 text-[12px] font-medium border-l border-border-light disabled:opacity-40"
                                style={!isAuto
                                  ? { background: 'rgb(var(--surface))', color: 'rgb(var(--text-primary))' }
                                  : { background: 'transparent', color: 'rgb(var(--text-secondary))' }}
                              >
                                Manual
                              </button>
                            </div>
                          );
                        })()}

                        {/*
                          UNIFIED lock toggle. `checked` is the OR of:
                            • shift_configs.account_locked = true (0064
                              permanent admin lock, also blocks shift_start)
                            • today's shift_sessions.status = 'locked'
                              (auto period-lock OR a manual shift_admin_lock)
                          So an auto-locked manager shows the toggle ON,
                          and the admin can unlock them right here. NEVER
                          disabled for missing session — `disabled` only
                          fires while this toggle's own mutation is in
                          flight (isBusy). The session-level "Paused
                          (locked)" badge in the Remaining column AND the
                          LockedShiftsSection panel are preserved as-is.
                        */}
                        {/* Spacer + divider so the Lock toggle is visually and physically
                            separated from the Auto/Manual segmented control — no accidental clicks. */}
                        <span aria-hidden className="inline-block h-8 w-px bg-border-light mx-2" />
                        <div className="flex flex-col items-end gap-0.5 ml-2">
                          <LockToggle
                            idAttr={`lock-toggle-${r.user_id}`}
                            checked={lockOverrides.get(r.user_id) ?? ((r.account_locked ?? false) || r.status === 'locked')}
                            disabled={isBusy}
                            onToggle={(next) => void runLockToggle(r, next)}
                          />
                          {(() => {
                            const ov  = lockOverrides.get(r.user_id);
                            const eff = ov ?? ((r.account_locked ?? false) || r.status === 'locked');
                            if (!eff) return null;
                            // Optimistic ON → just-applied account lock.
                            // Otherwise reflect the strongest active source
                            // (account_locked wins; else period lock).
                            const showAccount = ov === true || r.account_locked === true;
                            const label = showAccount ? 'Account locked' : 'Period locked';
                            const title = showAccount
                              ? (r.account_locked_at ? `Account locked since ${new Date(r.account_locked_at).toLocaleString()}` : 'Account locked')
                              : (r.session_locked_reason ? `Session ${r.session_locked_reason}` : 'Session locked');
                            return (
                              <span className="text-[10px] font-medium text-amber-200/80" title={title}>
                                {label}
                              </span>
                            );
                          })()}
                        </div>
                        {/*
                          "Can Work Now" override toggle. Per-user admin
                          bypass for the scheduled-time gate in
                          shift_can_start() — for overtime, emergencies,
                          or wrong-timezone cases where the user is
                          blocked by "shift not started / ended / day
                          off". Persists in shift_configs.can_work_now
                          until the admin flips it back.
                            • Toggle ON  → label "Shift Time Only"
                              (can_work_now = false, normal schedule).
                            • Toggle OFF → label "Can Work Now"
                              (can_work_now = true, user can start any time).
                        */}
                        <span aria-hidden className="inline-block h-8 w-px bg-border-light mx-2" />
                        <div className="flex flex-col items-end gap-0.5">
                          {(() => {
                            const shiftTimeOnly = !(r.can_work_now ?? false);
                            const busy = setCanWorkNow.isPending;
                            const next = shiftTimeOnly; // flipping the visual toggle
                            return (
                              <label
                                htmlFor={`cwn-toggle-${r.user_id}`}
                                className={
                                  'inline-flex items-center gap-3 select-none px-2 py-1.5 rounded-base ' +
                                  (busy ? 'cursor-not-allowed opacity-60' : 'cursor-pointer hover:bg-hover')
                                }
                                title={shiftTimeOnly
                                  ? 'Shift Time Only — flip OFF to let this user start a shift any time'
                                  : 'Can Work Now — admin override active; user can start a shift any time'}
                              >
                                <span className="relative inline-flex items-center">
                                  <input
                                    id={`cwn-toggle-${r.user_id}`}
                                    type="checkbox"
                                    role="switch"
                                    checked={shiftTimeOnly}
                                    disabled={busy}
                                    onChange={() => {
                                      // checked = shiftTimeOnly. Flipping means
                                      // can_work_now becomes the opposite.
                                      void setCanWorkNow.mutateAsync({
                                        targetUserId: r.user_id,
                                        canWorkNow: next, // true when turning OFF
                                      }).then(() => {
                                        toast.success(next
                                          ? `${r.full_name ?? r.username}: Can Work Now (override ON)`
                                          : `${r.full_name ?? r.username}: Shift Time Only`);
                                      }).catch((e) => {
                                        toast.error((e as Error)?.message ?? 'Could not update override');
                                      });
                                    }}
                                    className="peer sr-only"
                                  />
                                  <span
                                    aria-hidden
                                    className={
                                      'block h-7 w-12 rounded-full transition-colors duration-150 ' +
                                      (shiftTimeOnly ? 'bg-brand' : 'bg-emerald-700/70') +
                                      ' peer-focus-visible:ring-2 peer-focus-visible:ring-amber-400/60'
                                    }
                                  />
                                  <span
                                    aria-hidden
                                    className={
                                      'absolute top-0.5 left-0.5 h-6 w-6 rounded-full shadow-sm transition-transform duration-150 ' +
                                      (shiftTimeOnly
                                        ? 'translate-x-5 bg-amber-300'
                                        : 'translate-x-0 bg-emerald-200')
                                    }
                                  />
                                </span>
                                <span className={
                                  'text-[12px] font-semibold tabular-nums whitespace-nowrap ' +
                                  (shiftTimeOnly ? 'text-amber-200' : 'text-emerald-200')
                                }>
                                  {shiftTimeOnly ? 'Shift Time Only' : 'Can Work Now'}
                                </span>
                              </label>
                            );
                          })()}
                        </div>

                        {/* P4d — one-click Unlock Shift. Visible only when locked. Reuses the exact runLockToggle(row,false) path so it clears whichever lock is active (account, period, or break-overstay) exactly as the unified toggle does today. */}
                        {(r.status === 'locked' || r.account_locked === true) && (
                          <button
                            type="button"
                            onClick={() => {
                              if (!confirm(`Unlock ${r.full_name ?? r.username}'s shift?`)) return;
                              void runLockToggle(r, false);
                            }}
                            disabled={isBusy}
                            className="inline-flex items-center gap-1.5 h-8 px-3 rounded-base disabled:opacity-40"
                            style={{
                              background: '#0F1E36',
                              border: '1px solid #E1B978',
                              color: '#E1B978',
                              fontSize: '13.5px',
                              fontWeight: 500,
                            }}
                            title="Unlock shift — clears the active lock"
                          >
                            <Unlock className="h-4 w-4" />
                            Unlock Shift
                          </button>
                        )}
                        <button type="button" onClick={() => setActivityRow(r)} disabled={isBusy}
                          className="btn-secondary inline-flex items-center gap-1 h-8 px-2.5 text-[12px] disabled:opacity-40"
                          title="View activity log">
                          <ListChecks className="h-3.5 w-3.5" /> Activity
                        </button>
                        {/* 0078 — Adjust Time (per-day +/-). Audit-safe; never
                            touches started_at/paused_total/required_seconds.
                            Disabled until today's session exists. */}
                        <button type="button" onClick={() => setAdjustRow(r)}
                          disabled={isBusy || !r.session_id}
                          className="btn-secondary inline-flex items-center gap-1 h-8 px-2.5 text-[12px] disabled:opacity-40"
                          title="Adjust today's owed time (+/-) — original accounting preserved">
                          <Clock3 className="h-3.5 w-3.5" /> Adjust Time
                        </button>
                        {(r.session_admin_adjust_seconds ?? 0) !== 0 && (
                          <span
                            title="Today's admin time adjustment"
                            className={
                              'inline-flex items-center h-6 px-2 rounded-pill text-[11px] font-semibold border ' +
                              ((r.session_admin_adjust_seconds ?? 0) < 0
                                ? 'bg-emerald-900/25 text-emerald-200 border-emerald-800/40'
                                : 'bg-amber-900/25 text-amber-200 border-amber-800/40')
                            }
                          >
                            {(r.session_admin_adjust_seconds ?? 0) > 0 ? '+' : ''}
                            {Math.round((r.session_admin_adjust_seconds ?? 0) / 60)}m
                          </span>
                        )}

                        {/*
                          11/12-c — auto-only controls. Manual users get
                          NO auto-lock automation, so hiding Schedule /
                          Skip-next-lock / Re-arm / End keeps the row
                          honest. The manual Lock/Unlock toggle above
                          (Phase 10) stays available in both modes.
                        */}
                        {(r.shift_mode ?? 'manual') === 'auto' && (
                          <>
                            {/*
                              0075 — "Skip next lock" (one-shot, admin-only).
                            */}
                            <button type="button" onClick={() => void runSkipNext(r)}
                              disabled={isBusy || !r.session_id}
                              className={
                                'inline-flex items-center gap-1 h-8 px-2.5 text-[12px] rounded-base disabled:opacity-40 ' +
                                (r.skip_next_period_lock
                                  ? 'bg-amber-900/40 text-amber-100 border border-amber-700/40'
                                  : 'btn-secondary')
                              }
                              title={r.skip_next_period_lock
                                ? 'Next period-lock is ARMED to skip. Clicking again keeps it armed.'
                                : 'Skip this manager\'s next hourly period-lock (one shot)'}>
                              <SkipForward className="h-3.5 w-3.5" />
                              {r.skip_next_period_lock ? 'Skip armed' : 'Skip next lock'}
                            </button>
                            <button type="button" onClick={() => void runRearm(r)} disabled={isBusy || !r.session_id}
                              className="btn-secondary inline-flex items-center gap-1 h-8 px-2.5 text-[12px] disabled:opacity-40"
                              title="Un-Skip Next Lock — reset timer fresh, period index 0">
                              <RotateCcw className="h-3.5 w-3.5" /> Un-Skip Next Lock
                            </button>
                            {status !== 'completed' && status !== 'not_started' && (
                              <button type="button" onClick={() => void runForceEnd(r)} disabled={isBusy || !r.session_id}
                                className="btn-secondary inline-flex items-center gap-1 h-8 px-2.5 text-[12px] disabled:opacity-40"
                                title="Force end — mark session completed now (may set early_end_flag)">
                                <Square className="h-3.5 w-3.5" /> End
                              </button>
                            )}
                            <button type="button" onClick={() => setScheduleRow(r)} disabled={isBusy}
                              className="btn-secondary inline-flex items-center gap-1 h-8 px-2.5 text-[12px]"
                              title="Edit weekly shift schedule (Mon–Sun)">
                              <CalendarDays className="h-3.5 w-3.5" /> Schedule
                            </button>
                          </>
                        )}

                        <button type="button" onClick={() => setEditRow(r)} disabled={isBusy}
                          className="btn-secondary inline-flex items-center gap-1 h-8 px-2.5 text-[12px]"
                          title="Edit settings">
                          <Pencil className="h-3.5 w-3.5" /> Edit
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}

      {editRow && (
        <AdminShiftEditModal
          row={editRow}
          open={!!editRow}
          onClose={() => setEditRow(null)}
        />
      )}

      {scheduleRow && (
        <AdminShiftScheduleModal
          row={scheduleRow}
          open={!!scheduleRow}
          onClose={() => setScheduleRow(null)}
        />
      )}

      {/* Per-user activity-log drawer (read-only). */}
      <UserActivityPanel
        open={!!activityRow}
        userId={activityRow?.user_id ?? null}
        userLabel={activityRow?.full_name ?? activityRow?.username ?? ''}
        onClose={() => setActivityRow(null)}
      />

      {/* 0078 — Adjust Time dialog (per-day +/-). */}
      {adjustRow && (
        <AdjustTimeDialog
          row={adjustRow}
          open={!!adjustRow}
          onClose={() => setAdjustRow(null)}
        />
      )}

      {/*
        0067 — pending bio-break approval queue REMOVED. Bio break is
        now a hard limit (server cap = config.bio_break_max_per_day;
        admin grants no longer add to the max). The bio_break_requests
        table + RPCs remain in the DB but the manager UI no longer
        creates new requests, so no rows reach the admin panel.
      */}
    </section>
    </div>
    </>

  );
}

// Phase 6a — mirror of BreakControls.formatMS: M:SS with leading "-" on
// negative (lunch overstay). Defined at module scope so the on-break
// card renders identical glyph widths to the employee timer.
function formatBreakMS(s: number): string {
  const neg = s < 0;
  const v = Math.floor(Math.abs(s));
  const m = Math.floor(v / 60);
  const sec = v % 60;
  return `${neg ? '-' : ''}${m}:${String(sec).padStart(2, '0')}`;
}

// 0067 — BioRequestsQueue sub-component fully removed.
//   It rendered the pending bio_break_requests queue with Approve / Deny
//   actions. Now that bio break is a HARD limit (no admin-request escape
//   hatch), no rows reach this surface. The bio_break_requests table +
//   useBioBreakPending / useBioBreakRequestDecide hooks + the underlying
//   RPCs all remain in the DB / shift.ts as inert legacy — only the
//   admin-panel render of this queue and its imports are removed here.
