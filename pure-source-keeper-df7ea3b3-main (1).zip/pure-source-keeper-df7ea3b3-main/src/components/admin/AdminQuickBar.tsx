/**
 * AdminQuickBar — admin-only slim bar shown on every authenticated
 * page (mounted in AppShell, directly under the TopBar). Pure UI:
 * reuses the same hooks/RPCs/polling as Shift Control.
 *
 * Left  : two primary nav buttons (Shift Control, Lilly).
 * Right : compact live strip of currently RUNNING shift sessions —
 *         each with a clearly sized Lock/Unlock toggle (same RPC
 *         branching as Shift Control).
 *
 * Gating: admin/super only. Non-admins never see this bar.
 */
import { Link, useRouterState } from '@tanstack/react-router';
import { toast } from 'sonner';
import { Lock, Unlock, Sparkles, Clock } from 'lucide-react';
import { LilyModeToggle } from './LilyModeToggle';
import {
  useAdminShiftControl,
  useShiftAdminSetAccountLock,
  useShiftAdminUnlock,
  type AdminShiftRow,
} from '@/hooks/shift';

export function AdminQuickBar() {
  const { data: rows } = useAdminShiftControl(true);
  const setAccountLock = useShiftAdminSetAccountLock();
  const unlockMut = useShiftAdminUnlock();
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  const onLilyPage = pathname.startsWith('/admin/lily');

  const running = (rows ?? []).filter(
    (r) =>
      r.status === 'active' ||
      r.status === 'locked' ||
      r.status === 'on_shift_break' ||
      r.status === 'on_bio_break',
  );

  const onToggleLock = async (row: AdminShiftRow, nextLocked: boolean) => {
    const who = row.full_name ?? row.username;
    if (nextLocked) {
      if (!confirm(`Lock ${who}'s account?`)) return;
      try {
        await setAccountLock.mutateAsync({ targetUserId: row.user_id, locked: true });
        toast.success(`Locked ${who}`);
      } catch (e) {
        toast.error(e instanceof Error ? e.message : 'Lock failed');
      }
      return;
    }
    if (!confirm(`Unlock ${who}'s shift?`)) return;
    try {
      const ranAccount = row.account_locked === true;
      const ranPeriod =
        row.status === 'locked' &&
        row.session_locked_reason === 'period_lock' &&
        !!row.session_id;
      if (ranAccount) {
        await setAccountLock.mutateAsync({ targetUserId: row.user_id, locked: false });
      }
      if (ranPeriod) {
        await unlockMut.mutateAsync(row.session_id!);
      }
      if (!ranAccount && !ranPeriod) {
        await setAccountLock.mutateAsync({ targetUserId: row.user_id, locked: false });
      }
      toast.success(`Unlocked ${who}`);
    } catch (e) {
      toast.error(e instanceof Error ? e.message : 'Unlock failed');
    }
  };

  return (
    <div className="w-full border-b border-border-light bg-surface px-4 py-2 flex flex-wrap items-center gap-3">
      <div className="flex-1" />
      <div className="flex items-center gap-2 shrink-0">
        <Link
          to="/admin/shift-control"
          className="inline-flex items-center gap-2 h-10 px-4 rounded-base text-[13px] font-semibold transition-colors hover:opacity-90"
          style={{ background: '#0F1E36', color: '#E1B978', border: '1px solid #E1B978' }}
        >
          <Clock className="h-4 w-4" /> Shift Control
        </Link>
        <Link
          to="/admin/lily"
          className="inline-flex items-center gap-2 h-10 px-4 rounded-base text-[13px] font-semibold transition-colors hover:opacity-90"
          style={{ background: '#E1B978', color: '#0F1E36', border: '1px solid #E1B978' }}
        >
          <Sparkles className="h-4 w-4" /> Lilly
        </Link>
      </div>
      {onLilyPage && (
        <>
          <span aria-hidden className="inline-block h-8 w-px bg-border-light mx-1" />
          <LilyModeToggle />
        </>
      )}
      <div className="flex-1 flex flex-wrap items-center gap-2 min-w-0 justify-end">
        {running.length === 0 ? (
          <span className="text-[12px] text-text-secondary">No active shifts</span>
        ) : (
          running.map((r) => {
            const isLocked = r.status === 'locked' || r.account_locked === true;
            const who = r.full_name ?? r.username;
            const busy = setAccountLock.isPending || unlockMut.isPending;
            return (
              <div
                key={r.user_id}
                className="inline-flex items-center gap-3 h-11 pl-3 pr-2 rounded-pill border border-border-light bg-canvas"
                title={`${who} — ${isLocked ? 'Locked' : 'Active'}`}
              >
                <span className="text-[12px] font-medium text-text-primary truncate max-w-[160px]">
                  {who}
                </span>
                <span
                  className={
                    'inline-flex items-center h-5 px-2 rounded-pill text-[10px] font-semibold ' +
                    (isLocked
                      ? 'bg-rose-900/35 text-rose-300'
                      : 'bg-emerald-900/30 text-emerald-300')
                  }
                >
                  {isLocked ? 'Locked' : 'Active'}
                </span>
                {/* Divider so the Lock toggle is clearly separated from the status chip. */}
                <span aria-hidden className="inline-block h-6 w-px bg-border-light" />
                <button
                  type="button"
                  disabled={busy}
                  onClick={() => void onToggleLock(r, !isLocked)}
                  className={
                    'inline-flex items-center gap-1.5 h-9 px-3.5 rounded-base text-[13px] font-semibold transition-colors disabled:opacity-50 ' +
                    (isLocked
                      ? 'bg-emerald-900/40 text-emerald-200 hover:bg-emerald-900/60'
                      : 'bg-rose-900/40 text-rose-200 hover:bg-rose-900/60')
                  }
                  title={isLocked ? 'Unlock' : 'Lock'}
                  aria-label={isLocked ? 'Unlock' : 'Lock'}
                >
                  {isLocked ? (
                    <>
                      <Unlock className="h-4 w-4" /> Unlock
                    </>
                  ) : (
                    <>
                      <Lock className="h-4 w-4" /> Lock
                    </>
                  )}
                </button>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
}
