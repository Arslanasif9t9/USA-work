/**
 * Phase 9a — KPI dashboard foundation.
 *
 * Date-range picker (presets + custom) + 4 KPI scorecards computed
 * client-side from useKpiData + useKpiSchedules. No charts yet; those
 * land in 9b. Employee table lands in 9c.
 *
 * LOCKED good/bad rule (same as ReportsSection / EmployeePanel):
 *   GOOD = no lunch overstay AND bio_break_count_today <= 3
 *   BAD  = overstay_lock_email_sent_at != null
 *          OR locked_reason === 'break_overstay'
 *          OR bio_break_count_today >= 4
 *   NEUTRAL = not_started / no started_at (doesn't count as worked)
 *
 * ATTENDANCE: a (user, date) pair is "scheduled" if shift_schedules has
 * weekday=enabled for that user. "Present" = a shift_sessions row
 * exists for that (user, date) with started_at (status ∈ active /
 * completed / locked / on_shift_break / on_bio_break). "Absent" =
 * scheduled AND not present.
 */
import { useMemo, useState } from 'react';
import { useQueryClient } from '@tanstack/react-query';
import { RefreshCw } from 'lucide-react';
import {
  useKpiData,
  useKpiSchedules,
  shiftKeys,
  type KpiSessionRow,
} from '@/hooks/shift';
import { Spinner } from '@/components/Spinner';
import { KpiCharts } from './KpiCharts';
import { KpiEmployeeTable } from './KpiEmployeeTable';

const EIA_NAVY = '#0F1E36';
const EIA_GOLD = '#E1B978';

type DayKind = 'good' | 'bad' | 'neutral';

function dayKind(r: KpiSessionRow): DayKind {
  if (r.status === 'not_started' || r.started_at == null) return 'neutral';
  const overstayLikeLocked = r.locked_reason === 'break_overstay';
  const hasOverstay = r.overstay_lock_email_sent_at != null || overstayLikeLocked;
  if (hasOverstay || r.bio_break_count_today >= 4) return 'bad';
  return 'good';
}

function toISO(d: Date): string {
  return d.toISOString().slice(0, 10);
}
function addDays(d: Date, n: number): Date {
  const c = new Date(d);
  c.setUTCDate(c.getUTCDate() + n);
  return c;
}
function eachDateISO(fromISO: string, toISO: string): string[] {
  const out: string[] = [];
  const start = new Date(fromISO + 'T00:00:00Z');
  const end = new Date(toISO + 'T00:00:00Z');
  for (let d = start; d <= end; d = addDays(d, 1)) out.push(toISO_fast(d));
  return out;
}
function toISO_fast(d: Date): string { return d.toISOString().slice(0, 10); }

type Preset = '7' | '30' | 'custom';

export function KpiDashboard() {
  const today = useMemo(() => new Date(), []);
  const [preset, setPreset] = useState<Preset>('7');
  const [customFrom, setCustomFrom] = useState<string>(toISO(addDays(today, -6)));
  const [customTo, setCustomTo] = useState<string>(toISO(today));

  const { fromISO, toISO: rangeToISO } = useMemo(() => {
    if (preset === '7') return { fromISO: toISO(addDays(today, -6)), toISO: toISO(today) };
    if (preset === '30') return { fromISO: toISO(addDays(today, -29)), toISO: toISO(today) };
    return { fromISO: customFrom, toISO: customTo };
  }, [preset, customFrom, customTo, today]);

  const qc = useQueryClient();
  const data = useKpiData(fromISO, rangeToISO);
  const schedules = useKpiSchedules();

  const sessions = data.data ?? [];
  const sched = schedules.data ?? [];

  // ============ KPI calculations ============
  const kpis = useMemo(() => {
    // Worked = sessions that aren't neutral. Good/bad bucketed per row.
    let good = 0, bad = 0, worked = 0;
    let bioTotal = 0;
    let overstays = 0;
    for (const r of sessions) {
      const k = dayKind(r);
      if (k === 'neutral') continue;
      worked++;
      if (k === 'good') good++;
      else bad++;
      bioTotal += r.bio_break_count_today ?? 0;
      if (r.overstay_lock_email_sent_at != null || r.locked_reason === 'break_overstay') overstays++;
    }

    // Attendance: scheduled days across the range × all distinct users
    // that appear in schedules (weekday enabled).
    const dates = eachDateISO(fromISO, rangeToISO);
    // Map: user_id -> Set<weekday> of enabled days
    const userEnabled = new Map<string, Set<number>>();
    for (const s of sched) {
      if (!s.enabled) continue;
      let set = userEnabled.get(s.user_id);
      if (!set) { set = new Set(); userEnabled.set(s.user_id, set); }
      set.add(s.weekday);
    }
    // Present set keyed by `${user}|${date}` — present = real started_at row.
    const present = new Set<string>();
    for (const r of sessions) {
      if (r.started_at == null && r.status === 'not_started') continue;
      present.add(r.user_id + '|' + r.work_date);
    }
    let scheduledDays = 0;
    let presentDays = 0;
    for (const [userId, set] of userEnabled) {
      for (const iso of dates) {
        // JS Date weekday: 0=Sun..6=Sat — matches our shift_schedules.weekday
        const wd = new Date(iso + 'T00:00:00Z').getUTCDay();
        if (!set.has(wd)) continue;
        scheduledDays++;
        if (present.has(userId + '|' + iso)) presentDays++;
      }
    }

    const attendancePct = scheduledDays === 0 ? null : (presentDays / scheduledDays) * 100;
    const goodPct = worked === 0 ? null : (good / worked) * 100;
    const avgBio = worked === 0 ? null : bioTotal / worked;

    return {
      attendancePct, goodPct, avgBio, overstays,
      worked, good, bad, scheduledDays, presentDays,
    };
  }, [sessions, sched, fromISO, rangeToISO]);

  const loading = data.isLoading || schedules.isLoading;

  const refresh = () => {
    qc.invalidateQueries({ queryKey: [...shiftKeys.all, 'kpi-data'] });
    qc.invalidateQueries({ queryKey: [...shiftKeys.all, 'kpi-schedules'] });
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <header className="flex items-baseline justify-between gap-4">
        <div>
          <h1 className="text-2xl font-semibold" style={{ color: EIA_NAVY }}>
            KPI Dashboard
          </h1>
          <p className="text-sm text-text-secondary mt-1">
            Team-wide break &amp; shift performance. Range: <span className="font-medium">{fromISO}</span> → <span className="font-medium">{rangeToISO}</span>
          </p>
        </div>
      </header>

      {/* Range picker */}
      <div className="flex flex-wrap items-center gap-3 rounded-lg border border-border-light bg-surface p-3">
        <div className="flex items-center gap-1 rounded-md border border-border-light p-0.5">
          {(['7', '30', 'custom'] as Preset[]).map((p) => (
            <button
              key={p}
              onClick={() => setPreset(p)}
              className={`px-3 py-1.5 text-sm rounded transition-colors ${
                preset === p
                  ? 'bg-[color:var(--brand-navy,#0F1E36)] text-white'
                  : 'text-text-secondary hover:bg-hover'
              }`}
              style={preset === p ? { background: EIA_NAVY, color: 'white' } : undefined}
            >
              {p === '7' ? 'Last 7 days' : p === '30' ? 'Last 30 days' : 'Custom'}
            </button>
          ))}
        </div>
        {preset === 'custom' && (
          <div className="flex items-center gap-2 text-sm">
            <label className="flex items-center gap-1">
              <span className="text-text-secondary">From</span>
              <input
                type="date"
                value={customFrom}
                max={customTo}
                onChange={(e) => setCustomFrom(e.target.value)}
                className="px-2 py-1 border border-border-light rounded bg-background"
              />
            </label>
            <label className="flex items-center gap-1">
              <span className="text-text-secondary">To</span>
              <input
                type="date"
                value={customTo}
                min={customFrom}
                max={toISO(today)}
                onChange={(e) => setCustomTo(e.target.value)}
                className="px-2 py-1 border border-border-light rounded bg-background"
              />
            </label>
          </div>
        )}
        <button
          onClick={refresh}
          className="ml-auto inline-flex items-center gap-1.5 px-3 py-1.5 text-sm rounded border border-border-light hover:bg-hover transition-colors"
          disabled={loading}
        >
          <RefreshCw className={`h-3.5 w-3.5 ${loading ? 'animate-spin' : ''}`} />
          Refresh
        </button>
      </div>

      {/* Scorecards */}
      {loading ? (
        <div className="flex justify-center py-12"><Spinner /></div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <Scorecard
            label="Attendance"
            value={kpis.attendancePct == null ? '—' : kpis.attendancePct.toFixed(0) + '%'}
            sub={`${kpis.presentDays} of ${kpis.scheduledDays} scheduled`}
            tone={
              kpis.attendancePct == null ? 'neutral'
              : kpis.attendancePct >= 95 ? 'good'
              : kpis.attendancePct >= 85 ? 'warn' : 'bad'
            }
          />
          <Scorecard
            label="Good-day rate"
            value={kpis.goodPct == null ? '—' : kpis.goodPct.toFixed(0) + '%'}
            sub={`${kpis.good} good / ${kpis.bad} bad`}
            tone={
              kpis.goodPct == null ? 'neutral'
              : kpis.goodPct >= 90 ? 'good'
              : kpis.goodPct >= 75 ? 'warn' : 'bad'
            }
          />
          <Scorecard
            label="Avg bio breaks / day"
            value={kpis.avgBio == null ? '—' : kpis.avgBio.toFixed(1)}
            sub={`across ${kpis.worked} worked day${kpis.worked === 1 ? '' : 's'}`}
            tone={
              kpis.avgBio == null ? 'neutral'
              : kpis.avgBio <= 3 ? 'good'
              : kpis.avgBio <= 4 ? 'warn' : 'bad'
            }
          />
          <Scorecard
            label="Overstays"
            value={String(kpis.overstays)}
            sub="lunch / period lock events"
            tone={kpis.overstays === 0 ? 'good' : kpis.overstays <= 2 ? 'warn' : 'bad'}
          />
        </div>
      )}

      {/* Phase 9b — charts */}
      {!loading && (
        <KpiCharts
          sessions={sessions}
          schedules={sched}
          fromISO={fromISO}
          toISO={rangeToISO}
        />
      )}

      {/* Phase 9c — employee list table + drill-down */}
      {!loading && (
        <KpiEmployeeTable
          sessions={sessions}
          schedules={sched}
          fromISO={fromISO}
          toISO={rangeToISO}
        />
      )}
    </div>
  );
}

function Scorecard({
  label, value, sub, tone,
}: {
  label: string;
  value: string;
  sub: string;
  tone: 'good' | 'warn' | 'bad' | 'neutral';
}) {
  const toneCls =
    tone === 'good' ? 'text-emerald-600'
    : tone === 'warn' ? 'text-amber-600'
    : tone === 'bad' ? 'text-rose-600'
    : 'text-text-primary';
  return (
    <div
      className="rounded-lg border bg-surface p-5 shadow-sm"
      style={{ borderColor: EIA_GOLD + '55' }}
    >
      <div className="text-xs font-medium uppercase tracking-wide text-text-secondary">
        {label}
      </div>
      <div className={`mt-2 text-4xl font-bold tabular-nums ${toneCls}`}>
        {value}
      </div>
      <div className="mt-1 text-xs text-text-secondary">{sub}</div>
    </div>
  );
}
