/**
 * 0078 — Admin "Adjust Time" dialog.
 *
 * Per-person, per-day. Adds +/- minutes to today's session via
 * shift_admin_adjust_time. NEVER mutates started_at / paused_total /
 * required_seconds — the delta lives in admin_adjust_seconds and is
 * applied in remaining math (shift_tick + admin panel + completion).
 */
import { useMemo, useState } from 'react';
import { toast } from 'sonner';
import { Plus, Minus } from 'lucide-react';
import { useShiftAdminAdjustTime, type AdminShiftRow } from '@/hooks/shift';

function fmtHM(secs: number): string {
  const neg = secs < 0;
  const v = Math.abs(Math.floor(secs));
  const h = Math.floor(v / 3600);
  const m = Math.floor((v % 3600) / 60);
  return `${neg ? '-' : ''}${h}h ${m}m`;
}

export function AdjustTimeDialog({
  row, open, onClose,
}: {
  row: AdminShiftRow;
  open: boolean;
  onClose: () => void;
}) {
  const [minutes, setMinutes] = useState<number>(0);
  const [sign, setSign] = useState<1 | -1>(-1);
  const [note, setNote] = useState<string>('');
  const adjust = useShiftAdminAdjustTime();

  const currentRequired = row.session_required_seconds ?? 0;
  const currentAdjust   = row.session_admin_adjust_seconds ?? 0;
  const deltaSec        = (Math.max(0, Math.floor(minutes)) || 0) * 60 * sign;
  const previewEffective = useMemo(
    () => Math.max(0, currentRequired + currentAdjust + deltaSec),
    [currentRequired, currentAdjust, deltaSec],
  );

  if (!open) return null;

  const canSubmit = deltaSec !== 0 && Math.abs(deltaSec) <= 24 * 3600 && !adjust.isPending && !!row.session_id;

  const onSubmit = async () => {
    if (!canSubmit) return;
    try {
      const r = await adjust.mutateAsync({
        targetUserId: row.user_id,
        deltaSeconds: deltaSec,
        note: note.trim() || null,
      });
      toast.success(
        `${row.full_name ?? row.username} — adjusted ${sign > 0 ? '+' : '-'}${Math.abs(deltaSec / 60)}m. ` +
        `Effective shift: ${fmtHM(r.effective_required)}`,
      );
      onClose();
    } catch (e) {
      toast.error(e instanceof Error ? e.message : 'Adjust failed');
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 px-4">
      <div className="w-full max-w-md rounded-md border border-border-light bg-surface p-5 shadow-xl">
        <header className="mb-3">
          <h3 className="text-base font-semibold text-text-primary">
            Adjust Time — {row.full_name ?? row.username}
          </h3>
          <p className="text-[12px] text-text-secondary mt-1">
            Per-day. Adds/subtracts time owed for TODAY only. Original
            accounting (started_at, paused total, required snapshot) is
            never touched.
          </p>
        </header>

        <div className="mb-3 grid grid-cols-2 gap-2 text-[12px]">
          <div className="rounded-base bg-canvas border border-border-light p-2">
            <div className="text-text-secondary">Today's required</div>
            <div className="font-medium text-text-primary tabular-nums">{fmtHM(currentRequired)}</div>
          </div>
          <div className="rounded-base bg-canvas border border-border-light p-2">
            <div className="text-text-secondary">Current adjust</div>
            <div className={'font-medium tabular-nums ' + (currentAdjust < 0 ? 'text-emerald-300' : currentAdjust > 0 ? 'text-amber-200' : 'text-text-primary')}>
              {currentAdjust === 0 ? '0' : (currentAdjust > 0 ? '+' : '') + fmtHM(currentAdjust)}
            </div>
          </div>
        </div>

        <div className="mb-3">
          <label className="block text-[12px] font-medium text-text-secondary mb-1.5">Direction</label>
          <div className="inline-flex rounded-base overflow-hidden border border-border-light">
            <button
              type="button"
              onClick={() => setSign(-1)}
              className={'inline-flex items-center gap-1 px-3 h-9 text-[12px] ' +
                (sign === -1 ? 'bg-emerald-900/40 text-emerald-200' : 'text-text-secondary')}
            >
              <Minus className="h-3.5 w-3.5" /> Credit (shrink)
            </button>
            <button
              type="button"
              onClick={() => setSign(1)}
              className={'inline-flex items-center gap-1 px-3 h-9 text-[12px] border-l border-border-light ' +
                (sign === 1 ? 'bg-amber-900/40 text-amber-200' : 'text-text-secondary')}
            >
              <Plus className="h-3.5 w-3.5" /> Owe (grow)
            </button>
          </div>
        </div>

        <div className="mb-3">
          <label className="block text-[12px] font-medium text-text-secondary mb-1.5">Minutes</label>
          <input
            type="number"
            min={0}
            max={1440}
            step={1}
            value={minutes || ''}
            onChange={(e) => setMinutes(Math.max(0, Math.min(1440, Number(e.target.value) || 0)))}
            placeholder="30"
            className="w-full h-9 rounded-base bg-canvas border border-border-light px-3 text-text-primary text-[13px]"
          />
        </div>

        <div className="mb-3">
          <label className="block text-[12px] font-medium text-text-secondary mb-1.5">Note (optional)</label>
          <input
            type="text"
            value={note}
            onChange={(e) => setNote(e.target.value)}
            maxLength={200}
            placeholder="e.g. left 30m early — credit it"
            className="w-full h-9 rounded-base bg-canvas border border-border-light px-3 text-text-primary text-[13px]"
          />
        </div>

        <div className="mb-4 rounded-base border border-border-light bg-canvas p-3">
          <div className="text-[11px] uppercase tracking-wide text-text-secondary mb-1">Preview</div>
          <div className="text-[13px] text-text-primary">
            New effective shift today: <span className="font-semibold tabular-nums">{fmtHM(previewEffective)}</span>
            <span className="text-text-secondary ml-2">
              ({sign > 0 ? '+' : '-'}{Math.abs(Math.floor(minutes))}m to current)
            </span>
          </div>
        </div>

        <div className="flex items-center justify-end gap-2">
          <button
            type="button"
            onClick={onClose}
            disabled={adjust.isPending}
            className="btn-secondary h-9 px-3 text-[12px]"
          >
            Cancel
          </button>
          <button
            type="button"
            onClick={() => void onSubmit()}
            disabled={!canSubmit}
            className="inline-flex items-center gap-1.5 h-9 px-3 rounded-base disabled:opacity-40"
            style={{ background: '#0F1E36', border: '1px solid #E1B978', color: '#E1B978', fontWeight: 500, fontSize: '12px' }}
          >
            {adjust.isPending ? 'Saving…' : 'Apply adjustment'}
          </button>
        </div>

        {!row.session_id && (
          <p className="mt-3 text-[11px] text-amber-200">
            No session for this user today — adjustment requires an existing session row.
          </p>
        )}
      </div>
    </div>
  );
}
