/**
 * Phase 8a — Admin Reports.
 *
 * DAILY break report. Admin picks a date; we list every employee who
 * had a shift_sessions row that day with a tick/cross summary using
 * the LOCKED good/bad rule:
 *   GOOD (✓) = no lunch overstay AND bio_break_count_today <= 3
 *   BAD  (✕) = overstay_lock_email_sent_at != null
 *              OR locked_reason is a break-overstay
 *              OR bio_break_count_today >= 4
 *   NEUTRAL (—) = not_started / no real session
 *
 * Pure SELECT through useDailyBreakReport — no new RPC, RLS-gated.
 */
import { useMemo, useState } from 'react';
import {
  useDailyBreakReport,
  useWeeklyAiReport,
  type DailyReportRow,
  type WeeklyAiDay,
} from '@/hooks/shift';
import { useActiveUsers } from '@/hooks/users';
import { Spinner } from '@/components/Spinner';
import { EmptyMessage } from '@/components/EmptyMessage';


const EIA_NAVY = '#0F1E36';
const EIA_GOLD = '#E1B978';

function todayISO(): string {
  const d = new Date();
  return d.toISOString().slice(0, 10);
}

type DayKind = 'good' | 'bad' | 'neutral';

function dayKind(r: DailyReportRow): DayKind {
  if (r.status === 'not_started' || r.started_at == null) return 'neutral';
  const overstayLikeLocked = r.locked_reason === 'break_overstay';
  const hasOverstay = r.overstay_lock_email_sent_at != null || overstayLikeLocked;
  if (hasOverstay || r.bio_break_count_today >= 4) return 'bad';
  return 'good';
}

function bioTierClasses(count: number): string {
  if (count >= 6) return 'text-rose-200 bg-rose-900/30';
  if (count === 5) return 'text-slate-200 bg-slate-700/40';
  if (count === 4) return 'text-amber-200 bg-amber-900/30';
  return 'text-emerald-200 bg-emerald-900/30';
}

function statusLabel(s: string): string {
  switch (s) {
    case 'not_started': return 'Not started';
    case 'active': return 'On shift';
    case 'on_shift_break': return 'Lunch break';
    case 'on_bio_break': return 'Bio break';
    case 'locked': return 'Locked';
    case 'completed': return 'Completed';
    default: return s;
  }
}

function DayBadge({ kind }: { kind: DayKind }) {
  if (kind === 'neutral') return <span className="text-sm text-text-secondary">—</span>;
  const good = kind === 'good';
  return (
    <span
      className={`inline-flex h-7 w-7 items-center justify-center rounded-full text-sm font-bold ${
        good ? 'bg-emerald-900/40 text-emerald-300' : 'bg-rose-900/40 text-rose-300'
      }`}
      title={good ? 'Good day — within limits' : 'Day over limit'}
    >
      {good ? '✓' : '✕'}
    </span>
  );
}

export function ReportsSection() {
  const [dateISO, setDateISO] = useState<string>(todayISO());
  const { data: rows, isLoading, error } = useDailyBreakReport(dateISO, true);

  const summary = useMemo(() => {
    const list = rows ?? [];
    let good = 0, bad = 0, neutral = 0;
    for (const r of list) {
      const k = dayKind(r);
      if (k === 'good') good += 1;
      else if (k === 'bad') bad += 1;
      else neutral += 1;
    }
    return { total: list.length, good, bad, neutral };
  }, [rows]);

  return (
    <section className="space-y-6">
      <header className="space-y-1">
        <h2 className="text-2xl font-semibold tracking-tight" style={{ color: EIA_NAVY }}>
          Reports
        </h2>
        <p className="text-sm text-text-secondary">
          Daily break + shift performance across all employees.
        </p>
      </header>

      <div
        className="rounded-lg border p-5 space-y-5"
        style={{ borderColor: 'var(--border)', background: 'white' }}
      >
        <div className="flex flex-wrap items-end gap-4">
          <div>
            <label className="block text-xs font-medium text-text-secondary mb-1">
              Date
            </label>
            <input
              type="date"
              value={dateISO}
              onChange={(e) => setDateISO(e.target.value)}
              max={todayISO()}
              className="rounded-base border px-3 py-2 text-sm bg-white"
              style={{ borderColor: 'var(--border)' }}
            />
          </div>

          <div className="ml-auto flex gap-3">
            <SummaryPill label="Worked" value={summary.total} />
            <SummaryPill label="Good days" value={summary.good} tone="good" />
            <SummaryPill label="Bad days" value={summary.bad} tone="bad" />
          </div>
        </div>

        <div>
          <h3 className="text-lg font-semibold mb-3" style={{ color: EIA_NAVY }}>
            Daily Report — {formatDateLabel(dateISO)}
          </h3>

          {isLoading ? (
            <div className="flex justify-center py-10"><Spinner /></div>
          ) : error ? (
            <p className="text-sm text-rose-600">Failed to load report.</p>
          ) : !rows || rows.length === 0 ? (
            <EmptyMessage title="No sessions" description="No employees worked on this date." />
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr
                    className="text-left text-xs uppercase tracking-wide border-b"
                    style={{ borderColor: 'var(--border)', color: EIA_NAVY }}
                  >
                    <th className="py-2 pr-3 font-semibold">Employee</th>
                    <th className="py-2 pr-3 font-semibold">Day</th>
                    <th className="py-2 pr-3 font-semibold">Bio</th>
                    <th className="py-2 pr-3 font-semibold">Lunch/Dinner</th>
                    <th className="py-2 pr-3 font-semibold">Flags</th>
                    <th className="py-2 pr-3 font-semibold">Status</th>
                  </tr>
                </thead>
                <tbody>
                  {rows.map((r) => {
                    const kind = dayKind(r);
                    const tookLunch = (r.shift_break_count_today ?? 0) > 0;
                    return (
                      <tr
                        key={r.session_id}
                        className="border-b last:border-b-0"
                        style={{ borderColor: 'var(--border)' }}
                      >
                        <td className="py-3 pr-3">
                          <div className="font-medium" style={{ color: EIA_NAVY }}>
                            {r.full_name || r.username}
                          </div>
                          <div className="text-xs text-text-secondary">
                            {r.email || `@${r.username}`}
                          </div>
                        </td>
                        <td className="py-3 pr-3"><DayBadge kind={kind} /></td>
                        <td className="py-3 pr-3">
                          <span
                            className={`inline-flex items-center text-xs font-medium px-2 py-0.5 rounded-full ${bioTierClasses(r.bio_break_count_today)}`}
                          >
                            {r.bio_break_count_today}
                          </span>
                        </td>
                        <td className="py-3 pr-3">
                          <span className="text-sm" style={{ color: tookLunch ? EIA_NAVY : 'var(--text-secondary)' }}>
                            {tookLunch ? `Yes (${r.shift_break_count_today})` : 'No'}
                          </span>
                        </td>
                        <td className="py-3 pr-3">
                          <div className="flex flex-wrap gap-1">
                            {r.late_start_flag && (
                              <span className="inline-flex items-center text-[11px] font-medium px-1.5 py-0.5 rounded-full bg-amber-100 text-amber-800">
                                Late {r.late_start_minutes}m
                              </span>
                            )}
                            {r.early_end_flag && (
                              <span className="inline-flex items-center text-[11px] font-medium px-1.5 py-0.5 rounded-full bg-slate-200 text-slate-700">
                                Early {r.early_end_minutes}m
                              </span>
                            )}
                            {!r.late_start_flag && !r.early_end_flag && (
                              <span className="text-xs text-text-secondary">—</span>
                            )}
                          </div>
                        </td>
                        <td className="py-3 pr-3">
                          <span
                            className="inline-flex items-center text-xs font-medium px-2 py-0.5 rounded-full border"
                            style={{
                              borderColor: r.status === 'locked' ? '#fecaca' : EIA_GOLD,
                              color: r.status === 'locked' ? '#b91c1c' : EIA_NAVY,
                              background: r.status === 'locked' ? '#fef2f2' : '#fff8ec',
                            }}
                          >
                            {statusLabel(r.status)}
                          </span>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>

      <WeeklyAiReportCard />
    </section>
  );
}


// ---------------------------------------------------------------------
// Phase 8b — Weekly AI break report card.
// ---------------------------------------------------------------------
function startOfWeekISO(d: Date): string {
  // ISO week start (Monday). Uses local date.
  const day = d.getDay(); // 0=Sun..6=Sat
  const diff = (day + 6) % 7; // days since Monday
  const m = new Date(d);
  m.setDate(d.getDate() - diff);
  return `${m.getFullYear()}-${String(m.getMonth() + 1).padStart(2, '0')}-${String(m.getDate()).padStart(2, '0')}`;
}

function WeeklyAiReportCard() {
  const { data: users, isLoading: usersLoading } = useActiveUsers();
  const [userId, setUserId] = useState<string>('');
  const [weekStart, setWeekStart] = useState<string>(() => startOfWeekISO(new Date()));
  const mutation = useWeeklyAiReport();

  const canRun = !!userId && /^\d{4}-\d{2}-\d{2}$/.test(weekStart) && !mutation.isPending;

  const onGenerate = () => {
    if (!canRun) return;
    mutation.mutate({ userId, weekStart });
  };

  const result = mutation.data;

  return (
    <div
      className="rounded-lg border p-5 space-y-5"
      style={{ borderColor: 'var(--border)', background: 'white' }}
    >
      <div className="space-y-1">
        <h3 className="text-lg font-semibold" style={{ color: EIA_NAVY }}>
          Weekly AI Report
        </h3>
        <p className="text-sm text-text-secondary">
          AI-written summary of one employee's break discipline for the chosen week.
        </p>
      </div>

      <div className="flex flex-wrap items-end gap-4">
        <div>
          <label className="block text-xs font-medium text-text-secondary mb-1">Employee</label>
          <select
            value={userId}
            onChange={(e) => setUserId(e.target.value)}
            disabled={usersLoading}
            className="rounded-base border px-3 py-2 text-sm bg-white min-w-[220px]"
            style={{ borderColor: 'var(--border)' }}
          >
            <option value="">Choose an employee…</option>
            {(users ?? []).map((u) => (
              <option key={u.id} value={u.id}>
                {u.full_name || u.username}
              </option>
            ))}
          </select>
        </div>

        <div>
          <label className="block text-xs font-medium text-text-secondary mb-1">
            Week starting (Mon)
          </label>
          <input
            type="date"
            value={weekStart}
            onChange={(e) => setWeekStart(e.target.value)}
            max={todayISO()}
            className="rounded-base border px-3 py-2 text-sm bg-white"
            style={{ borderColor: 'var(--border)' }}
          />
        </div>

        <button
          type="button"
          onClick={onGenerate}
          disabled={!canRun}
          className="rounded-base px-4 py-2 text-sm font-semibold disabled:opacity-50"
          style={{ background: EIA_NAVY, color: EIA_GOLD }}
        >
          {mutation.isPending ? 'Generating…' : 'Generate AI Report'}
        </button>
      </div>

      {mutation.isPending && (
        <div className="flex items-center gap-2 text-sm text-text-secondary">
          <Spinner /> Asking the model — this can take up to 30 seconds.
        </div>
      )}

      {mutation.error && (
        <p className="text-sm text-rose-600">
          {(mutation.error as Error).message || 'Report failed.'}
        </p>
      )}

      {result && (
        <div className="space-y-4">
          <WeeklyGrid days={result.days} />
          <div
            className="rounded-base border p-4"
            style={{ borderColor: EIA_GOLD, background: '#fff8ec' }}
          >
            <div
              className="text-[11px] uppercase tracking-wide font-semibold mb-2"
              style={{ color: EIA_NAVY }}
            >
              AI Summary
            </div>
            <p
              className="text-base leading-relaxed whitespace-pre-wrap"
              style={{ color: EIA_NAVY }}
            >
              {result.summary}
            </p>
          </div>
        </div>
      )}
    </div>
  );
}

function WeeklyGrid({ days }: { days: WeeklyAiDay[] }) {
  return (
    <div className="grid grid-cols-7 gap-2">
      {days.map((d) => {
        const isGood = d.kind === 'good';
        const isBad = d.kind === 'bad';
        const isNone = d.kind === 'no_shift';
        const bg = isGood
          ? 'bg-emerald-50 border-emerald-200'
          : isBad
          ? 'bg-rose-50 border-rose-200'
          : 'bg-slate-50 border-slate-200';
        const mark = isGood ? '✓' : isBad ? '✕' : '—';
        const markColor = isGood ? 'text-emerald-700' : isBad ? 'text-rose-700' : 'text-slate-400';
        return (
          <div
            key={d.date}
            className={`rounded-base border p-2 text-center ${bg}`}
            title={isNone ? 'No shift' : `${d.kind} · bio ${d.bio} · lunches ${d.lunch}`}
          >
            <div className="text-[11px] font-semibold" style={{ color: EIA_NAVY }}>
              {d.label}
            </div>
            <div className={`text-2xl font-bold leading-tight mt-1 ${markColor}`}>{mark}</div>
            <div className="text-[10px] text-text-secondary mt-1">
              bio {d.bio}{d.lunch > 0 ? ` · lunch ${d.lunch}` : ''}
            </div>
          </div>
        );
      })}
    </div>
  );
}

function SummaryPill({
  label,
  value,
  tone,
}: {
  label: string;
  value: number;
  tone?: 'good' | 'bad';
}) {

  const styles =
    tone === 'good'
      ? { background: '#ecfdf5', color: '#047857', borderColor: '#a7f3d0' }
      : tone === 'bad'
      ? { background: '#fef2f2', color: '#b91c1c', borderColor: '#fecaca' }
      : { background: '#fff8ec', color: EIA_NAVY, borderColor: EIA_GOLD };
  return (
    <div
      className="rounded-base border px-3 py-2 min-w-[110px]"
      style={styles}
    >
      <div className="text-[11px] uppercase tracking-wide font-semibold opacity-80">{label}</div>
      <div className="text-xl font-bold leading-tight">{value}</div>
    </div>
  );
}

function formatDateLabel(iso: string): string {
  const d = new Date(iso + 'T00:00:00');
  return d.toLocaleDateString('en-US', {
    weekday: 'long',
    month: 'long',
    day: 'numeric',
    year: 'numeric',
  });
}
