/**
 * LilyModeToggle — AI / Human switch for Lily.
 *
 * Self-contained: loads lily_settings (id=1), subscribes to UPDATEs so
 * it stays in sync with any other admin's toggle, and writes via
 * dbUpdate. Same RPC/handler shape as the original toggle in
 * LilyAdminSection — pure DESIGN-ONLY relocation, no logic changes.
 *
 * Mounted in AdminQuickBar only on /admin/lily so it is always visible
 * regardless of conversation scroll.
 */
import { useCallback, useEffect, useState } from 'react';
import { Sparkles, User as UserIcon } from 'lucide-react';

import { dbSelect, dbUpdate, eq } from '@/lib/db';
import { supabase } from '@/lib/supabase';
import { cn } from '@/lib/cn';

interface LilySettingsRow {
  id: number;
  mode: 'ai' | 'human' | string;
  updated_at: string;
}

export function LilyModeToggle() {
  const [settings, setSettings] = useState<LilySettingsRow | null>(null);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const rows = await dbSelect<LilySettingsRow>('lily_settings', {
          filters: { id: eq(1) },
          limit: 1,
        });
        if (!cancelled) setSettings(rows[0] ?? null);
      } catch (err) {
        console.warn('[LilyModeToggle] load failed', err);
      }
    })();
    const ch = supabase.channel('lilymodetoggle:settings');
    ch.on(
      'postgres_changes',
      { event: 'UPDATE', schema: 'public', table: 'lily_settings' },
      (payload) => setSettings(payload.new as LilySettingsRow),
    );
    ch.subscribe();
    return () => {
      cancelled = true;
      try { void supabase.removeChannel(ch); } catch { /* ignore */ }
    };
  }, []);

  const mode = (settings?.mode ?? 'ai') as 'ai' | 'human';

  const setMode = useCallback(async (next: 'ai' | 'human') => {
    if (saving) return;
    if (mode === next) return;
    setSaving(true);
    const prev = settings;
    setSettings((s) => (s ? { ...s, mode: next } : { id: 1, mode: next, updated_at: new Date().toISOString() }));
    try {
      await dbUpdate('lily_settings', { id: eq(1) }, { mode: next, updated_at: new Date().toISOString() });
    } catch (err) {
      console.error('[LilyModeToggle] setMode failed', err);
      setSettings(prev);
    } finally {
      setSaving(false);
    }
  }, [saving, mode, settings]);

  return (
    <div className="inline-flex items-center bg-slate-100 rounded-full p-1.5 ring-1 ring-slate-200 shrink-0">
      <button
        type="button"
        onClick={() => void setMode('ai')}
        disabled={saving}
        className={cn(
          'flex items-center gap-2 h-9 px-4 rounded-full text-[13px] font-semibold transition-all',
          mode === 'ai' ? 'bg-violet-600 text-white shadow-sm' : 'text-slate-600 hover:text-slate-900',
        )}
        aria-pressed={mode === 'ai'}
      >
        <Sparkles className="h-4 w-4" />
        AI
      </button>
      <button
        type="button"
        onClick={() => void setMode('human')}
        disabled={saving}
        className={cn(
          'flex items-center gap-2 h-9 px-4 rounded-full text-[13px] font-semibold transition-all',
          mode === 'human' ? 'bg-amber-500 text-white shadow-sm' : 'text-slate-600 hover:text-slate-900',
        )}
        aria-pressed={mode === 'human'}
      >
        <UserIcon className="h-4 w-4" />
        Human
      </button>
    </div>
  );
}
