/**
 * P4b — Admin Weekly Shift Schedule modal.
 *
 * Per-user Mon-Sun grid that writes to shift_schedules via
 * shift_admin_set_schedule_bulk (single transactional 7-row replace).
 * Also writes the optional shift_configs.shift_start_date via
 * shift_admin_set_start_date (used by 4c gating).
 *
 * IMPORTANT — defaults must persist (past bug was partial/null sends
 * failing server-side). Before saving, every enabled day is validated
 * client-side: must have both start_time and end_time with end > start,
 * and required_seconds is derived from (end - start). Disabled days
 * send {enabled:false, required_seconds:0, start/end:null}. No half-null
 * rows ever go to the server.
 */
import { useEffect, useMemo, useState } from 'react';
import { toast } from 'sonner';
import { Calendar, CopyPlus, Save, Sun } from 'lucide-react';
import { Modal } from '@/components/Modal';
import { Spinner } from '@/components/Spinner';
import {
  useAdminShiftSchedules,
  useShiftAdminSetScheduleBulk,
  useShiftAdminSetStartDate,
  useUserShiftStartDate,
  type AdminShiftRow,
  type BulkScheduleRow,
} from '@/hooks/shift';

// 0 = Sunday … 6 = Saturday (matches Postgres EXTRACT(DOW) + our schema).
const DAY_LABELS = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];

// Sensible blank-slate defaults: Mon-Fri 09:00-17:00, Sat 09:00-13:00,
// Sun off. Used when the user has no shift_schedules rows yet.
const DEFAULT_WEEK: DayState[] = [
  { weekday: 0, enabled: false, start: '',      end: '' },      // Sun
  { weekday: 1, enabled: true,  start: '09:00', end: '17:00' }, // Mon
  { weekday: 2, enabled: true,  start: '09:00', end: '17:00' },
  { weekday: 3, enabled: true,  start: '09:00', end: '17:00' },
  { weekday: 4, enabled: true,  start: '09:00', end: '17:00' },
  { weekday: 5, enabled: true,  start: '09:00', end: '17:00' },
  { weekday: 6, enabled: true,  start: '09:00', end: '13:00' }, // Sat half
];

interface DayState {
  weekday: number;
  enabled: boolean;
  start: string;  // "HH:MM" (input[type=time]) — empty = blank
  end:   string;  // "HH:MM" — must be > start when enabled
}

interface Props {
  row: AdminShiftRow;
  open: boolean;
  onClose: () => void;
}

// (HH:MM) → seconds-of-day. Returns -1 on bad input.
function hmToSecs(hm: string): number {
  const m = /^(\d{1,2}):(\d{2})$/.exec(hm.trim());
  if (!m) return -1;
  const h = parseInt(m[1], 10);
  const mm = parseInt(m[2], 10);
  if (h < 0 || h > 23 || mm < 0 || mm > 59) return -1;
  return h * 3600 + mm * 60;
}

function secsToHoursLabel(secs: number): string {
  if (secs <= 0) return '0h';
  const h = Math.floor(secs / 3600);
  const m = Math.round((secs % 3600) / 60);
  return m === 0 ? `${h}h` : `${h}h ${m}m`;
}

export function AdminShiftScheduleModal({ row, open, onClose }: Props) {
  const { data: schedules, isLoading: schedLoading } = useAdminShiftSchedules(row.user_id, open);
  const { data: startDateLive, isLoading: sdLoading } = useUserShiftStartDate(row.user_id, open);
  const setBulk = useShiftAdminSetScheduleBulk();
  const setStartDateMut = useShiftAdminSetStartDate();

  const [days, setDays] = useState<DayState[]>(DEFAULT_WEEK);
  const [startDate, setStartDate] = useState<string>('');  // YYYY-MM-DD or ''
  const [submitting, setSubmitting] = useState(false);

  // Pre-fill from DB (or defaults if user has no rows yet).
  useEffect(() => {
    if (!open) return;
    if (!schedules) return;
    if (schedules.length === 0) {
      setDays(DEFAULT_WEEK);
      return;
    }
    const byWd = new Map(schedules.map((s) => [s.weekday, s] as const));
    setDays(Array.from({ length: 7 }, (_, wd) => {
      const r = byWd.get(wd);
      if (!r) {
        return DEFAULT_WEEK[wd];
      }
      // Trim "HH:MM:SS" → "HH:MM"
      const start = r.start_time_local ? r.start_time_local.slice(0, 5) : '';
      const end   = r.end_time_local   ? r.end_time_local.slice(0, 5)   : '';
      return { weekday: wd, enabled: r.enabled, start, end };
    }));
  }, [open, schedules]);

  useEffect(() => {
    if (!open) return;
    setStartDate(startDateLive ?? '');
  }, [open, startDateLive]);

  const totalWeekSecs = useMemo(() => {
    return days.reduce((acc, d) => {
      if (!d.enabled) return acc;
      const s = hmToSecs(d.start);
      const e = hmToSecs(d.end);
      if (s < 0 || e < 0 || e <= s) return acc;
      return acc + (e - s);
    }, 0);
  }, [days]);

  const updateDay = (wd: number, patch: Partial<DayState>) => {
    setDays((arr) => arr.map((d) => d.weekday === wd ? { ...d, ...patch } : d));
  };

  // Copy Monday's enabled/start/end to Tue-Fri. Sat/Sun untouched.
  const applyToWeekdays = () => {
    const mon = days.find((d) => d.weekday === 1);
    if (!mon) return;
    setDays((arr) => arr.map((d) =>
      (d.weekday >= 2 && d.weekday <= 5)
        ? { ...d, enabled: mon.enabled, start: mon.start, end: mon.end }
        : d
    ));
    toast.success('Mon hours copied to Tue–Fri');
  };

  // Sat half-day from Mon's start: half the weekday hours.
  const setSaturdayHalfDay = () => {
    const mon = days.find((d) => d.weekday === 1);
    if (!mon || !mon.enabled) {
      toast.error('Set Monday first — Sat half-day mirrors weekday hours.');
      return;
    }
    const s = hmToSecs(mon.start);
    const e = hmToSecs(mon.end);
    if (s < 0 || e < 0 || e <= s) {
      toast.error('Monday must have a valid start/end first.');
      return;
    }
    const half = Math.floor((e - s) / 2);
    const satEndSecs = s + half;
    const hh = String(Math.floor(satEndSecs / 3600)).padStart(2, '0');
    const mm = String(Math.floor((satEndSecs % 3600) / 60)).padStart(2, '0');
    updateDay(6, { enabled: true, start: mon.start, end: `${hh}:${mm}` });
    toast.success(`Saturday set to half-day (${mon.start}–${hh}:${mm})`);
  };

  const handleSave = async () => {
    if (submitting) return;

    // Client-side validation — no half-null rows reach the server.
    const rows: BulkScheduleRow[] = [];
    for (const d of days) {
      if (!d.enabled) {
        rows.push({
          weekday: d.weekday, enabled: false,
          required_seconds: 0, start_time_local: null, end_time_local: null,
        });
        continue;
      }
      const s = hmToSecs(d.start);
      const e = hmToSecs(d.end);
      if (s < 0 || e < 0) {
        toast.error(`${DAY_LABELS[d.weekday]}: enabled days need both a start and end time.`);
        return;
      }
      if (e <= s) {
        toast.error(`${DAY_LABELS[d.weekday]}: end time must be after start time.`);
        return;
      }
      rows.push({
        weekday: d.weekday, enabled: true,
        required_seconds: e - s,
        start_time_local: `${d.start}:00`,
        end_time_local:   `${d.end}:00`,
      });
    }

    setSubmitting(true);
    try {
      await setBulk.mutateAsync({ target_user_id: row.user_id, rows });
      // Start date is optional — only call if it changed.
      if ((startDate || null) !== (startDateLive ?? null)) {
        await setStartDateMut.mutateAsync({
          target_user_id: row.user_id,
          start_date: startDate || null,
        });
      }
      toast.success(`Schedule saved for ${row.full_name ?? row.username}.`);
      onClose();
    } catch (err) {
      toast.error(err instanceof Error ? err.message : 'Save failed');
    } finally {
      setSubmitting(false);
    }
  };

  const loading = schedLoading || sdLoading;

  return (
    <Modal
      open={open}
      onClose={() => { if (!submitting) onClose(); }}
      title={`Weekly schedule — ${row.full_name ?? row.username}`}
      size="lg"
    >
      <div className="space-y-5">
        <p className="text-[13px] text-text-secondary">
          Set the manager&apos;s weekly working hours. Saved transactionally as a
          full 7-day replace. Times are interpreted in their configured
          timezone ({row.timezone ?? 'Asia/Manila'}).
        </p>

        {/* Shift start date */}
        <section className="grid grid-cols-2 gap-4">
          <label className="block">
            <span className="text-[12px] font-semibold uppercase tracking-wide text-text-secondary inline-flex items-center gap-1">
              <Calendar className="h-3.5 w-3.5" /> First shift day (optional)
            </span>
            <input
              type="date"
              value={startDate}
              onChange={(e) => setStartDate(e.target.value)}
              className="mt-1 w-full h-10 px-3 rounded-base bg-canvas border border-border-light text-text-primary"
            />
            <span className="text-[11px] text-text-secondary mt-0.5 block">
              Blank = no start-date gating. Set this and the manager can&apos;t start a shift before that date.
            </span>
          </label>
          <div className="flex items-end">
            <div className="text-[12px] text-text-secondary">
              Total scheduled this week:{' '}
              <span className="text-amber-200 font-semibold tabular-nums">
                {secsToHoursLabel(totalWeekSecs)}
              </span>
            </div>
          </div>
        </section>

        {/* Shortcuts */}
        <div className="flex flex-wrap gap-2">
          <button
            type="button"
            onClick={applyToWeekdays}
            className="btn-secondary inline-flex items-center gap-1.5 h-9 px-3 text-[13px]"
            title="Copy Monday's enabled/start/end to Tue-Fri"
          >
            <CopyPlus className="h-4 w-4" /> Apply Mon to all weekdays
          </button>
          <button
            type="button"
            onClick={setSaturdayHalfDay}
            className="btn-secondary inline-flex items-center gap-1.5 h-9 px-3 text-[13px]"
            title="Set Saturday to half the weekday hours"
          >
            <Sun className="h-4 w-4" /> Set Saturday half-day
          </button>
        </div>

        {/* Grid */}
        <section>
          {loading ? (
            <div className="flex justify-center py-6"><Spinner className="h-5 w-5 text-brand" /></div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-left text-[13px]">
                <thead>
                  <tr className="text-[11px] uppercase tracking-wide text-text-secondary border-b border-border-light">
                    <th className="py-2 pr-3 font-semibold w-16">Day</th>
                    <th className="py-2 pr-3 font-semibold w-24">Enabled</th>
                    <th className="py-2 pr-3 font-semibold">Start</th>
                    <th className="py-2 pr-3 font-semibold">End</th>
                    <th className="py-2 pr-0 font-semibold text-right">Hours</th>
                  </tr>
                </thead>
                <tbody>
                  {days.map((d) => {
                    const s = hmToSecs(d.start);
                    const e = hmToSecs(d.end);
                    const valid = d.enabled && s >= 0 && e > s;
                    const secs = valid ? e - s : 0;
                    const badRange = d.enabled && s >= 0 && e >= 0 && e <= s;
                    return (
                      <tr key={d.weekday} className="border-b border-border-hair last:border-0">
                        <td className="py-2 pr-3 font-medium">{DAY_LABELS[d.weekday]}</td>
                        <td className="py-2 pr-3">
                          <label className="inline-flex items-center gap-2 cursor-pointer">
                            <input
                              type="checkbox"
                              checked={d.enabled}
                              onChange={(e2) => updateDay(d.weekday, { enabled: e2.target.checked })}
                              className="h-4 w-4 accent-brand cursor-pointer"
                            />
                            <span className="text-[12px] text-text-secondary">{d.enabled ? 'On' : 'Off'}</span>
                          </label>
                        </td>
                        <td className="py-2 pr-3">
                          <input
                            type="time"
                            value={d.start}
                            disabled={!d.enabled}
                            onChange={(e2) => updateDay(d.weekday, { start: e2.target.value })}
                            className="h-9 px-2 rounded-base bg-canvas border border-border-light text-text-primary disabled:opacity-40"
                          />
                        </td>
                        <td className="py-2 pr-3">
                          <input
                            type="time"
                            value={d.end}
                            disabled={!d.enabled}
                            onChange={(e2) => updateDay(d.weekday, { end: e2.target.value })}
                            className={
                              'h-9 px-2 rounded-base bg-canvas border text-text-primary disabled:opacity-40 ' +
                              (badRange ? 'border-rose-500/60' : 'border-border-light')
                            }
                          />
                        </td>
                        <td className="py-2 pr-0 text-right tabular-nums">
                          {d.enabled
                            ? (valid
                                ? <span className="text-amber-200 font-semibold">{secsToHoursLabel(secs)}</span>
                                : <span className="text-rose-300">—</span>)
                            : <span className="text-text-disabled">off</span>}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}
        </section>

        <div className="flex items-center justify-end gap-2 pt-2 border-t border-border-light">
          <button
            type="button"
            onClick={onClose}
            disabled={submitting}
            className="btn-secondary h-9 px-4"
          >
            Cancel
          </button>
          <button
            type="button"
            onClick={() => void handleSave()}
            disabled={submitting || loading}
            className="btn-primary h-9 px-4 inline-flex items-center gap-2 disabled:opacity-60"
          >
            <Save className="h-4 w-4" />
            {submitting ? 'Saving…' : 'Save schedule'}
          </button>
        </div>
      </div>
    </Modal>
  );
}
