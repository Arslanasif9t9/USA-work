/**
 * Phase 9c — Employee list table + per-employee drill-down for the KPI
 * dashboard. Pure client-side aggregation from the 9a data already in
 * scope (KpiSessionRow[] + KpiScheduleRow[]). Reuses the LOCKED rules:
 *
 *   GOOD  = started_at != null AND no overstay AND bio <= 3
 *   BAD   = overstay_lock_email_sent_at != null
 *           OR locked_reason === 'break_overstay'
 *           OR bio_break_count_today >= 4
 *   NEUTRAL = not_started / no started_at (doesn't count as worked)
 *   ABSENT  = scheduled (weekday enabled) AND no present session
 */
import { useMemo, useState } from 'react';
import { ArrowUpDown, Check, X as XIcon, Minus, X } from 'lucide-react';
import { Avatar } from '@/components/Avatar';
import { EmptyMessage } from '@/components/EmptyMessage';
import type { KpiSessionRow, KpiScheduleRow } from '@/hooks/shift';

const EIA_NAVY = '#0F1E36';
const EIA_GOLD = '#E1B978';

// ---------- Locked rule helpers ----------
type DayKind = 'good' | 'bad' | 'neutral';
function dayKind(r: KpiSessionRow): DayKind {
  if (r.status === 'not_started' || r.started_at == null) return 'neutral';
  const hasOverstay =
    r.overstay_lock_email_sent_at != null || r.locked_reason === 'break_overstay';
  if (hasOverstay || r.bio_break_count_today >= 4) return 'bad';
  return 'good';
}

// 5b bio-tier pill classes (mirrors EmployeePanel.tsx)
function bioTierClasses(count: number): string {
  if (count >= 6) return 'text-rose-700 bg-rose-100';
  if (count === 5) return 'text-slate-700 bg-slate-200';
  if (count === 4) return 'text-amber-800 bg-amber-100';
  return 'text-emerald-800 bg-emerald-100';
}

function complianceTone(p: number | null): 'good' | 'warn' | 'bad' | 'neutral' {
  if (p == null) return 'neutral';
  if (p >= 90) return 'good';
  if (p >= 75) return 'warn';
  return 'bad';
}
const toneText: Record<string, string> = {
  good: 'text-emerald-600',
  warn: 'text-amber-600',
  bad: 'text-rose-600',
  neutral: 'text-text-secondary',
};

function eachDateISO(fromISO: string, toISO: string): string[] {
  const out: string[] = [];
  const start = new Date(fromISO + 'T00:00:00Z');
  const end = new Date(toISO + 'T00:00:00Z');
  for (let d = new Date(start); d <= end; d.setUTCDate(d.getUTCDate() + 1)) {
    out.push(d.toISOString().slice(0, 10));
  }
  return out;
}
function fmtDateShort(iso: string) {
  return new Date(iso + 'T00:00:00Z').toLocaleDateString(undefined, {
    month: 'short', day: '2-digit', timeZone: 'UTC',
  });
}
function fmtWeekday(iso: string) {
  return new Date(iso + 'T00:00:00Z').toLocaleDateString(undefined, {
    weekday: 'short', timeZone: 'UTC',
  });
}

// ---------- Row aggregation ----------
interface EmpRow {
  user_id: string;
  name: string;
  email: string | null;
  avatar_url: string | null;
  worked: number;
  good: number;
  bad: number;
  absent: number;
  compliance: number | null;
  late: number;
  early: number;
  overstays: number;
}

function buildRows(
  sessions: KpiSessionRow[],
  schedules: KpiScheduleRow[],
  fromISO: string,
  toISO: string,
): EmpRow[] {
  const dates = eachDateISO(fromISO, toISO);
  const userEnabled = new Map<string, Set<number>>();
  for (const s of schedules) {
    if (!s.enabled) continue;
    let set = userEnabled.get(s.user_id);
    if (!set) { set = new Set(); userEnabled.set(s.user_id, set); }
    set.add(s.weekday);
  }
  type Acc = EmpRow & { _present: Set<string> };
  const acc = new Map<string, Acc>();
  const ensure = (id: string, name: string, email: string | null, avatar: string | null) => {
    let a = acc.get(id);
    if (!a) {
      a = {
        user_id: id, name, email, avatar_url: avatar,
        worked: 0, good: 0, bad: 0, absent: 0, compliance: null,
        late: 0, early: 0, overstays: 0,
        _present: new Set<string>(),
      };
      acc.set(id, a);
    }
    if ((a.name === '—' || !a.name) && name) a.name = name;
    if (!a.email && email) a.email = email;
    if (!a.avatar_url && avatar) a.avatar_url = avatar;
    return a;
  };

  for (const r of sessions) {
    const name = r.full_name?.trim() || r.username || '—';
    const a = ensure(r.user_id, name, r.email, r.avatar_url);
    const k = dayKind(r);
    if (k === 'neutral') continue;
    a.worked++;
    if (k === 'good') a.good++; else a.bad++;
    if (r.late_start_flag) a.late++;
    if (r.early_end_flag) a.early++;
    if (r.overstay_lock_email_sent_at != null || r.locked_reason === 'break_overstay') a.overstays++;
    a._present.add(r.work_date);
  }
  for (const [userId, set] of userEnabled) {
    const a = ensure(userId, acc.get(userId)?.name ?? '—', null, null);
    let scheduled = 0, present = 0;
    for (const iso of dates) {
      const wd = new Date(iso + 'T00:00:00Z').getUTCDay();
      if (!set.has(wd)) continue;
      scheduled++;
      if (a._present.has(iso)) present++;
    }
    a.absent = Math.max(0, scheduled - present);
  }
  return Array.from(acc.values()).map(({ _present, ...rest }) => ({
    ...rest,
    compliance: rest.worked === 0 ? null : Math.round((rest.good / rest.worked) * 100),
  }));
}

type SortKey = 'name' | 'worked' | 'good' | 'bad' | 'absent' | 'compliance' | 'late' | 'early' | 'overstays';

export function KpiEmployeeTable({
  sessions, schedules, fromISO, toISO,
}: {
  sessions: KpiSessionRow[];
  schedules: KpiScheduleRow[];
  fromISO: string;
  toISO: string;
}) {
  const rows = useMemo(
    () => buildRows(sessions, schedules, fromISO, toISO),
    [sessions, schedules, fromISO, toISO],
  );
  const [sortKey, setSortKey] = useState<SortKey>('compliance');
  const [sortDir, setSortDir] = useState<'asc' | 'desc'>('desc');
  const [activeUser, setActiveUser] = useState<string | null>(null);

  const sorted = useMemo(() => {
    const arr = [...rows];
    arr.sort((a, b) => {
      const av = a[sortKey];
      const bv = b[sortKey];
      const an = av == null ? -1 : typeof av === 'number' ? av : 0;
      const bn = bv == null ? -1 : typeof bv === 'number' ? bv : 0;
      if (sortKey === 'name') {
        return sortDir === 'asc'
          ? a.name.localeCompare(b.name)
          : b.name.localeCompare(a.name);
      }
      return sortDir === 'asc' ? an - bn : bn - an;
    });
    return arr;
  }, [rows, sortKey, sortDir]);

  const toggleSort = (k: SortKey) => {
    if (sortKey === k) setSortDir(sortDir === 'asc' ? 'desc' : 'asc');
    else { setSortKey(k); setSortDir(k === 'name' ? 'asc' : 'desc'); }
  };

  const active = activeUser ? rows.find((r) => r.user_id === activeUser) ?? null : null;
  const activeSessions = useMemo(
    () => activeUser ? sessions.filter((s) => s.user_id === activeUser) : [],
    [sessions, activeUser],
  );
  const activeSchedule = useMemo(() => {
    if (!activeUser) return new Set<number>();
    const set = new Set<number>();
    for (const s of schedules) if (s.user_id === activeUser && s.enabled) set.add(s.weekday);
    return set;
  }, [schedules, activeUser]);

  return (
    <div
      className="rounded-lg border bg-surface shadow-sm"
      style={{ borderColor: EIA_GOLD + '55' }}
    >
      <header className="px-5 py-4 border-b border-border-light">
        <h3 className="text-lg font-semibold" style={{ color: EIA_NAVY }}>
          Employee leaderboard
        </h3>
        <p className="text-xs text-text-secondary mt-0.5">
          Click any row to see that employee's per-day breakdown.
        </p>
      </header>

      {sorted.length === 0 ? (
        <EmptyMessage title="No employees in this range" description="Try widening the date range or check that schedules exist." />
      ) : (
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="text-left text-xs uppercase tracking-wide text-text-secondary bg-app/40">
                <SortTh label="Employee" col="name" sortKey={sortKey} sortDir={sortDir} onClick={() => toggleSort('name')} />
                <SortTh label="Worked" col="worked" sortKey={sortKey} sortDir={sortDir} onClick={() => toggleSort('worked')} align="right" />
                <SortTh label="Good" col="good" sortKey={sortKey} sortDir={sortDir} onClick={() => toggleSort('good')} align="right" />
                <SortTh label="Bad" col="bad" sortKey={sortKey} sortDir={sortDir} onClick={() => toggleSort('bad')} align="right" />
                <SortTh label="Absent" col="absent" sortKey={sortKey} sortDir={sortDir} onClick={() => toggleSort('absent')} align="right" />
                <SortTh label="Compliance" col="compliance" sortKey={sortKey} sortDir={sortDir} onClick={() => toggleSort('compliance')} align="right" />
                <SortTh label="Late" col="late" sortKey={sortKey} sortDir={sortDir} onClick={() => toggleSort('late')} align="right" />
                <SortTh label="Early" col="early" sortKey={sortKey} sortDir={sortDir} onClick={() => toggleSort('early')} align="right" />
                <SortTh label="Overstays" col="overstays" sortKey={sortKey} sortDir={sortDir} onClick={() => toggleSort('overstays')} align="right" />
              </tr>
            </thead>
            <tbody>
              {sorted.map((r) => {
                const tone = complianceTone(r.compliance);
                return (
                  <tr
                    key={r.user_id}
                    className="border-t border-border-light hover:bg-hover cursor-pointer transition-colors"
                    onClick={() => setActiveUser(r.user_id)}
                  >
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-3">
                        <Avatar name={r.name} url={r.avatar_url} size="md" />
                        <div className="min-w-0">
                          <div className="font-medium truncate" style={{ color: EIA_NAVY }}>{r.name}</div>
                          {r.email && (
                            <div className="text-xs text-text-secondary truncate">{r.email}</div>
                          )}
                        </div>
                      </div>
                    </td>
                    <td className="px-4 py-3 text-right tabular-nums">{r.worked}</td>
                    <td className="px-4 py-3 text-right tabular-nums font-semibold text-emerald-600">{r.good}</td>
                    <td className="px-4 py-3 text-right tabular-nums font-semibold text-rose-600">{r.bad}</td>
                    <td className="px-4 py-3 text-right tabular-nums text-text-secondary">{r.absent}</td>
                    <td className={`px-4 py-3 text-right tabular-nums font-bold ${toneText[tone]}`}>
                      {r.compliance == null ? '—' : `${r.compliance}%`}
                    </td>
                    <td className="px-4 py-3 text-right tabular-nums">{r.late}</td>
                    <td className="px-4 py-3 text-right tabular-nums">{r.early}</td>
                    <td className="px-4 py-3 text-right tabular-nums">{r.overstays}</td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}

      {active && (
        <EmployeeDrillDown
          row={active}
          sessions={activeSessions}
          scheduleDays={activeSchedule}
          fromISO={fromISO}
          toISO={toISO}
          onClose={() => setActiveUser(null)}
        />
      )}
    </div>
  );
}

function SortTh({
  label, col, sortKey, sortDir, onClick, align = 'left',
}: {
  label: string;
  col: SortKey;
  sortKey: SortKey;
  sortDir: 'asc' | 'desc';
  onClick: () => void;
  align?: 'left' | 'right';
}) {
  const active = sortKey === col;
  return (
    <th
      className={`px-4 py-2.5 font-medium ${align === 'right' ? 'text-right' : 'text-left'}`}
    >
      <button
        type="button"
        onClick={onClick}
        className={`inline-flex items-center gap-1 hover:text-text-primary transition-colors ${active ? 'text-text-primary' : ''}`}
      >
        <span>{label}</span>
        <ArrowUpDown className={`h-3 w-3 ${active ? 'opacity-100' : 'opacity-40'}`} />
        {active && <span className="text-[10px]">{sortDir === 'asc' ? '↑' : '↓'}</span>}
      </button>
    </th>
  );
}

// ---------- Drill-down panel ----------
function EmployeeDrillDown({
  row, sessions, scheduleDays, fromISO, toISO, onClose,
}: {
  row: EmpRow;
  sessions: KpiSessionRow[];
  scheduleDays: Set<number>;
  fromISO: string;
  toISO: string;
  onClose: () => void;
}) {
  // Per-date map for THIS user
  const byDate = useMemo(() => {
    const m = new Map<string, KpiSessionRow>();
    for (const s of sessions) m.set(s.work_date, s);
    return m;
  }, [sessions]);

  const dates = useMemo(() => eachDateISO(fromISO, toISO), [fromISO, toISO]);
  const tone = complianceTone(row.compliance);

  return (
    <div className="fixed inset-0 z-50 flex" role="dialog" aria-modal="true" aria-label={`${row.name} breakdown`}>
      <div className="absolute inset-0 bg-black/40" onClick={onClose} aria-hidden="true" />
      <aside
        className="relative ml-auto w-full max-w-[920px] h-full bg-surface shadow-2xl flex flex-col animate-[fadeIn_120ms_ease-out] border-l"
        style={{ borderColor: EIA_GOLD + '88' }}
      >
        <header
          className="shrink-0 flex items-center justify-between px-6 py-4 border-b"
          style={{ borderColor: EIA_GOLD + '55', background: EIA_NAVY }}
        >
          <div className="flex items-center gap-3 min-w-0">
            <Avatar name={row.name} url={row.avatar_url} size="lg" />
            <div className="min-w-0">
              <h2 className="text-xl font-semibold text-white truncate">{row.name}</h2>
              {row.email && (
                <p className="text-xs text-white/70 truncate">{row.email}</p>
              )}
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close"
            className="p-2 rounded-md hover:bg-white/10 text-white"
          >
            <X className="h-5 w-5" />
          </button>
        </header>

        <div className="flex-1 overflow-y-auto p-6 space-y-6">
          {/* Range totals */}
          <div className="grid grid-cols-2 sm:grid-cols-5 gap-3">
            <Stat label="Worked" value={String(row.worked)} />
            <Stat label="Good" value={String(row.good)} cls="text-emerald-600" />
            <Stat label="Bad" value={String(row.bad)} cls="text-rose-600" />
            <Stat label="Absent" value={String(row.absent)} cls="text-text-secondary" />
            <Stat label="Compliance" value={row.compliance == null ? '—' : `${row.compliance}%`} cls={toneText[tone]} />
          </div>

          <div className="text-xs text-text-secondary">
            Range: <span className="font-medium">{fromISO}</span> → <span className="font-medium">{toISO}</span>
          </div>

          {/* Per-day grid */}
          <div>
            <h3 className="text-sm font-semibold mb-3" style={{ color: EIA_NAVY }}>
              Per-day breakdown
            </h3>
            <div className="grid grid-cols-2 sm:grid-cols-4 md:grid-cols-7 gap-2">
              {dates.map((iso) => {
                const s = byDate.get(iso);
                const wd = new Date(iso + 'T00:00:00Z').getUTCDay();
                const scheduled = scheduleDays.has(wd);
                let kind: 'good' | 'bad' | 'absent' | 'off' = 'off';
                if (s) {
                  const k = dayKind(s);
                  if (k === 'good') kind = 'good';
                  else if (k === 'bad') kind = 'bad';
                  else kind = scheduled ? 'absent' : 'off';
                } else {
                  kind = scheduled ? 'absent' : 'off';
                }

                const bioCount = s?.bio_break_count_today ?? 0;
                const lunchTaken = (s?.shift_break_count_today ?? 0) > 0;

                const cell = {
                  good: { bg: 'bg-emerald-50', br: 'border-emerald-200', icon: <Check className="h-4 w-4 text-emerald-600" />, label: 'Good' },
                  bad: { bg: 'bg-rose-50', br: 'border-rose-200', icon: <XIcon className="h-4 w-4 text-rose-600" />, label: 'Bad' },
                  absent: { bg: 'bg-slate-50', br: 'border-slate-200', icon: <Minus className="h-4 w-4 text-slate-400" />, label: 'Absent' },
                  off: { bg: 'bg-slate-50/50', br: 'border-dashed border-slate-200', icon: <Minus className="h-4 w-4 text-slate-300" />, label: 'Off' },
                }[kind];

                return (
                  <div
                    key={iso}
                    className={`rounded-md border ${cell.br} ${cell.bg} p-2.5 flex flex-col items-center text-center`}
                  >
                    <div className="text-[10px] uppercase tracking-wide text-text-secondary">
                      {fmtWeekday(iso)}
                    </div>
                    <div className="text-xs font-medium" style={{ color: EIA_NAVY }}>
                      {fmtDateShort(iso)}
                    </div>
                    <div className="my-1.5">{cell.icon}</div>
                    <div className="text-[10px] text-text-secondary">{cell.label}</div>
                    {s && (kind === 'good' || kind === 'bad') && (
                      <div className="mt-1.5 flex flex-col items-center gap-1">
                        <span className={`text-[10px] font-medium px-1.5 py-0.5 rounded-full ${bioTierClasses(bioCount)}`}>
                          {bioCount} bio
                        </span>
                        <span className={`text-[10px] ${lunchTaken ? 'text-emerald-700' : 'text-text-secondary'}`}>
                          {lunchTaken ? '🍽 lunch' : 'no lunch'}
                        </span>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </div>

          {/* Legend */}
          <div className="flex flex-wrap items-center gap-3 text-xs text-text-secondary pt-2 border-t border-border-light">
            <LegendDot color="bg-emerald-100 border-emerald-300" label="Good" />
            <LegendDot color="bg-rose-100 border-rose-300" label="Bad" />
            <LegendDot color="bg-slate-100 border-slate-300" label="Absent (scheduled)" />
            <LegendDot color="bg-slate-50 border-dashed border-slate-200" label="Off / not scheduled" />
          </div>
        </div>
      </aside>
    </div>
  );
}

function Stat({ label, value, cls }: { label: string; value: string; cls?: string }) {
  return (
    <div className="rounded-md border border-border-light bg-app/30 px-3 py-2">
      <div className="text-[10px] uppercase tracking-wide text-text-secondary">{label}</div>
      <div className={`mt-0.5 text-xl font-bold tabular-nums ${cls ?? ''}`}>{value}</div>
    </div>
  );
}

function LegendDot({ color, label }: { color: string; label: string }) {
  return (
    <span className="inline-flex items-center gap-1.5">
      <span className={`inline-block h-3 w-3 rounded border ${color}`} />
      {label}
    </span>
  );
}
