/**
 * Phase 9b — KPI charts (recharts) for the admin KPI dashboard.
 *
 * Consumes the same KpiSessionRow[] + KpiScheduleRow[] already loaded by
 * 9a (useKpiData + useKpiSchedules). All aggregation is client-side and
 * reuses the locked GOOD/BAD/attendance rules.
 *
 *   GOOD = started_at != null AND no overstay AND bio <= 3
 *   BAD  = overstay_lock_email_sent_at != null
 *          OR locked_reason === 'break_overstay'
 *          OR bio_break_count_today >= 4
 *   NEUTRAL = not_started / no started_at  (doesn't count as worked)
 *   ABSENT  = scheduled (weekday enabled) AND no present session
 */
import { useMemo } from 'react';
import {
  ResponsiveContainer,
  AreaChart, Area,
  LineChart, Line,
  BarChart, Bar,
  XAxis, YAxis, CartesianGrid, Tooltip, Legend, ReferenceLine, Cell,
} from 'recharts';
import type { KpiSessionRow, KpiScheduleRow } from '@/hooks/shift';

const EIA_NAVY = '#0F1E36';
const EIA_GOLD = '#E1B978';
const GREEN = '#10b981';
const AMBER = '#f59e0b';
const RED = '#ef4444';
const GRAY = '#9ca3af';

type DayKind = 'good' | 'bad' | 'neutral';
function dayKind(r: KpiSessionRow): DayKind {
  if (r.status === 'not_started' || r.started_at == null) return 'neutral';
  const hasOverstay =
    r.overstay_lock_email_sent_at != null || r.locked_reason === 'break_overstay';
  if (hasOverstay || r.bio_break_count_today >= 4) return 'bad';
  return 'good';
}

function eachDateISO(fromISO: string, toISO: string): string[] {
  const out: string[] = [];
  const start = new Date(fromISO + 'T00:00:00Z');
  const end = new Date(toISO + 'T00:00:00Z');
  for (let d = new Date(start); d <= end; d.setUTCDate(d.getUTCDate() + 1)) {
    out.push(d.toISOString().slice(0, 10));
  }
  return out;
}
function shortDate(iso: string) {
  // MMM-DD
  const d = new Date(iso + 'T00:00:00Z');
  return d.toLocaleDateString(undefined, { month: 'short', day: '2-digit', timeZone: 'UTC' });
}

export function KpiCharts({
  sessions, schedules, fromISO, toISO,
}: {
  sessions: KpiSessionRow[];
  schedules: KpiScheduleRow[];
  fromISO: string;
  toISO: string;
}) {
  // ----- Per-date aggregates -----
  const perDate = useMemo(() => {
    const map = new Map<string, { good: number; bad: number; bio: number; worked: number }>();
    for (const iso of eachDateISO(fromISO, toISO)) {
      map.set(iso, { good: 0, bad: 0, bio: 0, worked: 0 });
    }
    for (const r of sessions) {
      const slot = map.get(r.work_date);
      if (!slot) continue;
      const k = dayKind(r);
      if (k === 'neutral') continue;
      slot.worked++;
      if (k === 'good') slot.good++;
      else slot.bad++;
      slot.bio += r.bio_break_count_today ?? 0;
    }
    return Array.from(map.entries()).map(([date, v]) => ({
      date,
      label: shortDate(date),
      goodPct: v.worked === 0 ? null : Math.round((v.good / v.worked) * 100),
      bio: v.bio,
      worked: v.worked,
    }));
  }, [sessions, fromISO, toISO]);

  const teamBioAvg = useMemo(() => {
    const days = perDate.filter((d) => d.worked > 0);
    if (!days.length) return null;
    return days.reduce((s, d) => s + d.bio, 0) / days.length;
  }, [perDate]);

  // ----- Per-employee aggregates -----
  const perUser = useMemo(() => {
    const dates = eachDateISO(fromISO, toISO);
    // Scheduled days per user, by weekday set
    const userEnabled = new Map<string, Set<number>>();
    for (const s of schedules) {
      if (!s.enabled) continue;
      let set = userEnabled.get(s.user_id);
      if (!set) { set = new Set(); userEnabled.set(s.user_id, set); }
      set.add(s.weekday);
    }
    type Acc = {
      user_id: string;
      name: string;
      good: number;
      bad: number;
      worked: number;
      scheduled: number;
      present: number;
    };
    const acc = new Map<string, Acc>();
    const ensure = (id: string, name: string) => {
      let a = acc.get(id);
      if (!a) {
        a = { user_id: id, name, good: 0, bad: 0, worked: 0, scheduled: 0, present: 0 };
        acc.set(id, a);
      }
      return a;
    };
    // Present + good/bad from sessions
    const present = new Set<string>();
    for (const r of sessions) {
      const name = r.full_name?.trim() || r.username || '—';
      const a = ensure(r.user_id, name);
      if (a.name === '—' && name !== '—') a.name = name;
      const k = dayKind(r);
      if (k === 'neutral') continue;
      a.worked++;
      if (k === 'good') a.good++; else a.bad++;
      present.add(r.user_id + '|' + r.work_date);
    }
    // Scheduled + present counts from schedule × date matrix
    for (const [userId, set] of userEnabled) {
      const a = ensure(userId, acc.get(userId)?.name ?? '—');
      for (const iso of dates) {
        const wd = new Date(iso + 'T00:00:00Z').getUTCDay();
        if (!set.has(wd)) continue;
        a.scheduled++;
        if (present.has(userId + '|' + iso)) a.present++;
      }
    }
    const rows = Array.from(acc.values()).map((a) => {
      const compliance = a.worked === 0 ? null : Math.round((a.good / a.worked) * 100);
      const absent = Math.max(0, a.scheduled - a.present);
      return { ...a, compliance, absent };
    });
    return rows;
  }, [sessions, schedules, fromISO, toISO]);

  const leaderboard = useMemo(() => {
    return [...perUser]
      .filter((r) => r.worked > 0)
      .map((r) => ({ name: r.name, compliance: r.compliance ?? 0 }))
      .sort((a, b) => b.compliance - a.compliance);
  }, [perUser]);

  const dayMix = useMemo(() => {
    return [...perUser]
      .filter((r) => r.scheduled > 0 || r.worked > 0)
      .map((r) => ({ name: r.name, good: r.good, bad: r.bad, absent: r.absent }))
      .sort((a, b) => (b.good + b.bad + b.absent) - (a.good + a.bad + a.absent));
  }, [perUser]);

  const hasPerDate = perDate.some((d) => d.worked > 0);
  const hasUsers = perUser.length > 0;

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <ChartCard title="Good-day % trend">
          {hasPerDate ? (
            <ResponsiveContainer width="100%" height={260}>
              <AreaChart data={perDate} margin={{ top: 10, right: 16, bottom: 0, left: -10 }}>
                <defs>
                  <linearGradient id="goodFill" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor={EIA_GOLD} stopOpacity={0.55} />
                    <stop offset="100%" stopColor={EIA_GOLD} stopOpacity={0.05} />
                  </linearGradient>
                </defs>
                <CartesianGrid stroke="#e5e7eb" strokeDasharray="3 3" />
                <XAxis dataKey="label" tick={{ fontSize: 12, fill: EIA_NAVY }} />
                <YAxis domain={[0, 100]} tickFormatter={(v) => `${v}%`} tick={{ fontSize: 12, fill: EIA_NAVY }} />
                <Tooltip
                  formatter={(v) => (v == null ? '—' : `${v}%`)}
                  labelStyle={{ color: EIA_NAVY, fontWeight: 600 }}
                />
                <Area
                  type="monotone"
                  dataKey="goodPct"
                  stroke={EIA_NAVY}
                  strokeWidth={2}
                  fill="url(#goodFill)"
                  connectNulls
                />
              </AreaChart>
            </ResponsiveContainer>
          ) : <EmptyChart />}
        </ChartCard>

        <ChartCard title="Bio breaks per day (team total)">
          {hasPerDate ? (
            <ResponsiveContainer width="100%" height={260}>
              <LineChart data={perDate} margin={{ top: 10, right: 16, bottom: 0, left: -10 }}>
                <CartesianGrid stroke="#e5e7eb" strokeDasharray="3 3" />
                <XAxis dataKey="label" tick={{ fontSize: 12, fill: EIA_NAVY }} />
                <YAxis allowDecimals={false} tick={{ fontSize: 12, fill: EIA_NAVY }} />
                <Tooltip labelStyle={{ color: EIA_NAVY, fontWeight: 600 }} />
                {teamBioAvg != null && (
                  <ReferenceLine
                    y={teamBioAvg}
                    stroke={EIA_GOLD}
                    strokeDasharray="4 4"
                    label={{ value: `avg ${teamBioAvg.toFixed(1)}`, fill: EIA_GOLD, fontSize: 11, position: 'right' }}
                  />
                )}
                <Line
                  type="monotone"
                  dataKey="bio"
                  name="Bio breaks"
                  stroke={EIA_NAVY}
                  strokeWidth={2}
                  dot={{ r: 3, fill: EIA_NAVY }}
                />
              </LineChart>
            </ResponsiveContainer>
          ) : <EmptyChart />}
        </ChartCard>
      </div>

      <ChartCard title="Compliance leaderboard">
        {leaderboard.length > 0 ? (
          <ResponsiveContainer width="100%" height={Math.max(180, leaderboard.length * 36 + 40)}>
            <BarChart
              data={leaderboard}
              layout="vertical"
              margin={{ top: 8, right: 32, bottom: 0, left: 8 }}
            >
              <CartesianGrid stroke="#e5e7eb" strokeDasharray="3 3" horizontal={false} />
              <XAxis type="number" domain={[0, 100]} tickFormatter={(v) => `${v}%`} tick={{ fontSize: 12, fill: EIA_NAVY }} />
              <YAxis
                type="category"
                dataKey="name"
                width={140}
                tick={{ fontSize: 12, fill: EIA_NAVY }}
              />
              <Tooltip formatter={(v) => `${v}%`} labelStyle={{ color: EIA_NAVY, fontWeight: 600 }} />
              <Bar dataKey="compliance" radius={[0, 6, 6, 0]} label={{ position: 'right', fill: EIA_NAVY, fontSize: 11, formatter: (v) => `${v}%` }}>
                {leaderboard.map((row, i) => (
                  <Cell
                    key={i}
                    fill={row.compliance >= 90 ? GREEN : row.compliance >= 75 ? AMBER : RED}
                  />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        ) : <EmptyChart />}
      </ChartCard>

      <ChartCard title="Day mix per employee">
        {dayMix.length > 0 ? (
          <ResponsiveContainer width="100%" height={Math.max(220, dayMix.length * 42 + 60)}>
            <BarChart
              data={dayMix}
              layout="vertical"
              margin={{ top: 8, right: 16, bottom: 0, left: 8 }}
              stackOffset="none"
            >
              <CartesianGrid stroke="#e5e7eb" strokeDasharray="3 3" horizontal={false} />
              <XAxis type="number" allowDecimals={false} tick={{ fontSize: 12, fill: EIA_NAVY }} />
              <YAxis type="category" dataKey="name" width={140} tick={{ fontSize: 12, fill: EIA_NAVY }} />
              <Tooltip labelStyle={{ color: EIA_NAVY, fontWeight: 600 }} />
              <Legend wrapperStyle={{ fontSize: 12 }} />
              <Bar dataKey="good" stackId="d" name="Good" fill={GREEN} radius={[6, 0, 0, 6]} />
              <Bar dataKey="bad" stackId="d" name="Bad" fill={RED} />
              <Bar dataKey="absent" stackId="d" name="Absent" fill={GRAY} radius={[0, 6, 6, 0]} />
            </BarChart>
          </ResponsiveContainer>
        ) : <EmptyChart />}
      </ChartCard>

      {!hasUsers && !hasPerDate && null}
    </div>
  );
}

function ChartCard({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div
      className="rounded-lg border bg-surface p-5 shadow-sm"
      style={{ borderColor: EIA_GOLD + '55' }}
    >
      <h3 className="text-lg font-semibold mb-3" style={{ color: EIA_NAVY }}>{title}</h3>
      {children}
    </div>
  );
}

function EmptyChart() {
  return (
    <div className="h-[220px] flex items-center justify-center text-sm text-text-secondary">
      No data for this range
    </div>
  );
}
