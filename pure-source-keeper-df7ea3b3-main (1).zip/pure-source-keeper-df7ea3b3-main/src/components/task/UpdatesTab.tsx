import { useRef, useState } from 'react';
import {
  Smile, MoreHorizontal, Pencil, Trash2, MessageSquare,
  Mail, MessageCircle, ChevronDown, Paperclip,
} from 'lucide-react';
import { toast } from 'sonner';
import {
  useItemUpdates, useCreateUpdate, useDeleteUpdate, useEditUpdate, useToggleReaction,
  type UpdateWithMeta,
} from '@/hooks/updates';
import { useUploadFile, getSignedFileUrl } from '@/hooks/files';
import { useAuthStore } from '@/state/authStore';
import { useActiveUsers } from '@/hooks/users';
import { useUpdateShiftContexts, type UpdateShiftCtx } from '@/hooks/updateShiftContexts';
import { displayUserName } from '@/lib/displayName';
import { RichTextEditor, type RichTextEditorHandle } from './RichTextEditor';
import { Avatar } from '@/components/Avatar';
import { Spinner } from '@/components/Spinner';
import { EmptyMessage } from '@/components/EmptyMessage';
import { cn } from '@/lib/cn';

const QUICK_EMOJIS = ['👍', '❤️', '😄', '🎉', '🚀', '👀'];

export function UpdatesTab({ boardId, itemId, canEdit }: { boardId: string; itemId: string; canEdit: boolean }) {
  const profile = useAuthStore((s) => s.profile);
  const { data: updates, isLoading } = useItemUpdates(itemId);
  const create = useCreateUpdate();
  const upload = useUploadFile();
  const editorRef = useRef<RichTextEditorHandle>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const isAdmin = !!profile && (profile.role === 'admin' || profile.is_super_admin);
  const { data: shiftCtxMap } = useUpdateShiftContexts(
    (updates ?? []).map((u) => ({ id: u.id, author_id: u.author_id, created_at: u.created_at })),
    isAdmin,
  );

  const onPickFiles = async (fileList: FileList | null) => {
    if (!fileList || fileList.length === 0) return;
    for (const f of Array.from(fileList)) {
      try {
        const row = await upload.mutateAsync({ boardId, itemId, file: f });
        try {
          const url = await getSignedFileUrl(row.storage_path);
          editorRef.current?.insertLink(url, `📎 ${row.file_name}`);
        } catch {
          editorRef.current?.insertLink('#', `📎 ${row.file_name}`);
        }
      } catch (err) {
        toast.error(`${f.name}: ${err instanceof Error ? err.message : 'upload failed'}`);
        return;
      }
    }
    toast.success(`Attached ${fileList.length} file${fileList.length === 1 ? '' : 's'}`);
  };

  const onSubmit = async () => {
    if (!editorRef.current) return;
    const html = editorRef.current.getHtml().trim();
    // Tiptap leaves <p></p> for empty content — treat that as empty.
    const stripped = html.replace(/<p[^>]*>(?:\s|&nbsp;)*<\/p>/gi, '').trim();
    if (!stripped) {
      toast.error('Write something first');
      return;
    }
    const json = editorRef.current.getJson();
    const mentions = editorRef.current.getMentionedUserIds();
    try {
      await create.mutateAsync({ itemId, bodyHtml: html, bodyJson: json, mentionedUserIds: mentions });
      editorRef.current.clear();
    } catch (err) {
      toast.error(err instanceof Error ? err.message : 'Failed to post update');
    }
  };

  return (
    <div className="flex flex-col gap-4">
      {canEdit && (
        <div>
          {/* Monday-style action row above the composer: Update via email · Give feedback */}
          <div className="flex items-center gap-5 text-[12px] text-text-secondary mb-2 px-1">
            <button type="button" className="inline-flex items-center gap-1.5 hover:text-text-primary" disabled title="Update via email — Phase 6">
              <Mail className="h-3.5 w-3.5" /> Update via email
            </button>
            <button type="button" className="inline-flex items-center gap-1.5 hover:text-text-primary" disabled title="Give feedback — Phase 6">
              <MessageCircle className="h-3.5 w-3.5" /> Give feedback
            </button>
          </div>

          <RichTextEditor
            ref={editorRef}
            placeholder="Write an update and mention others with @"
            minHeightPx={120}
          />

          {/* Footer row beneath the composer — left has the small icon cluster
              (matches Monday's @ / attachment / GIF / emoji / pen quick-actions),
              right has Clear + Update split-button. */}
          <div className="mt-2 flex items-center justify-between gap-2 px-1">
            <div className="flex items-center gap-1 text-text-secondary">
              <button
                type="button"
                onClick={() => editorRef.current?.focus()}
                title="Mention"
                className="h-7 w-7 inline-flex items-center justify-center rounded-sm hover:bg-hover text-[13px]"
              >@</button>
              <button
                type="button"
                onClick={() => fileInputRef.current?.click()}
                disabled={upload.isPending}
                title="Attach a file"
                className="h-7 w-7 inline-flex items-center justify-center rounded-sm hover:bg-hover disabled:opacity-50"
              >
                {upload.isPending ? <Spinner className="h-3.5 w-3.5" /> : <Paperclip className="h-4 w-4" />}
              </button>
              <input
                ref={fileInputRef}
                type="file"
                multiple
                className="hidden"
                onChange={(e) => { void onPickFiles(e.target.files); e.target.value = ''; }}
              />
              <button type="button" title="GIF — Phase 6" disabled className="h-7 px-1.5 inline-flex items-center justify-center rounded-sm text-[10px] font-bold opacity-50">
                GIF
              </button>
              <button type="button" title="Emoji — Phase 6" disabled className="h-7 w-7 inline-flex items-center justify-center rounded-sm opacity-50">
                <Smile className="h-4 w-4" />
              </button>
            </div>
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => editorRef.current?.clear()}
                className="btn-ghost h-8 text-[13px]"
              >
                Clear
              </button>
              <div className="inline-flex items-stretch rounded-base overflow-hidden">
                <button
                  type="button"
                  onClick={() => void onSubmit()}
                  disabled={create.isPending}
                  className="h-8 px-4 bg-brand text-white text-[13px] font-medium hover:bg-brand-hover disabled:opacity-40 inline-flex items-center"
                >
                  {create.isPending && <Spinner className="h-3 w-3 mr-2" />}
                  Update
                </button>
                <button
                  type="button"
                  disabled
                  title="More update options — Phase 6"
                  className="h-8 px-2 bg-brand/90 text-white border-l border-white/20 inline-flex items-center disabled:opacity-60"
                >
                  <ChevronDown className="h-4 w-4" />
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {isLoading ? (
        <div className="flex items-center justify-center py-8">
          <Spinner className="h-5 w-5 text-brand" />
        </div>
      ) : !updates || updates.length === 0 ? (
        <EmptyMessage
          title="No updates yet"
          description="Start the conversation by posting an update above."
          icon={<MessageSquare className="h-6 w-6" />}
        />
      ) : (
        <ul className="space-y-3">
          {updates.map((u) => (
            <UpdateItem
              key={u.id}
              update={u}
              itemId={itemId}
              isOwn={u.author_id === profile?.id}
              canModerate={isAdmin}
              shiftCtx={isAdmin ? shiftCtxMap?.get(u.id) ?? null : null}
            />
          ))}
        </ul>
      )}
    </div>
  );
}

function UpdateItem({
  update, itemId, isOwn, canModerate, shiftCtx,
}: { update: UpdateWithMeta; itemId: string; isOwn: boolean; canModerate: boolean; shiftCtx: UpdateShiftCtx | null }) {
  const profile = useAuthStore((s) => s.profile);
  const { data: users } = useActiveUsers();
  const author = users?.find((u) => u.id === update.author_id);

  const edit = useEditUpdate();
  const del = useDeleteUpdate();
  const toggleReaction = useToggleReaction();
  const editorRef = useRef<RichTextEditorHandle>(null);

  const [editing, setEditing] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const [pickerOpen, setPickerOpen] = useState(false);

  // Aggregate reactions by emoji
  const reactionsByEmoji = new Map<string, { users: string[] }>();
  for (const r of update.reactions) {
    const entry = reactionsByEmoji.get(r.emoji) ?? { users: [] };
    entry.users.push(r.user_id);
    reactionsByEmoji.set(r.emoji, entry);
  }

  const onToggle = (emoji: string) => {
    if (!profile) return;
    const on = reactionsByEmoji.get(emoji)?.users.includes(profile.id) ?? false;
    void toggleReaction.mutateAsync({ updateId: update.id, emoji, itemId, currentlyOn: on });
  };

  const onSaveEdit = async () => {
    if (!editorRef.current) return;
    const html = editorRef.current.getHtml();
    const json = editorRef.current.getJson();
    try {
      await edit.mutateAsync({ id: update.id, itemId, bodyHtml: html, bodyJson: json });
      setEditing(false);
    } catch (err) {
      toast.error(err instanceof Error ? err.message : 'Edit failed');
    }
  };

  return (
    <li className="bg-surface border border-border-light rounded-md p-4">
      <header className="flex items-center gap-3 mb-3">
        <Avatar name={displayUserName(author)} url={author?.avatar_url} size="md" />
        <div className="flex-1 min-w-0">
          <p className="text-[14px] font-semibold leading-tight truncate">
            {displayUserName(author)}
          </p>
          <p
            className="text-[12px] text-text-secondary truncate"
            title={fullDateTime(update.created_at)}
          >
            {shortDateTime(update.created_at)}
            {update.edited_at && (
              <span className="ml-1 text-text-disabled" title={fullDateTime(update.edited_at)}>
                (edited {shortDateTime(update.edited_at)})
              </span>
            )}
          </p>
          {canModerate && shiftCtx && (
            <p className="text-[11px] text-text-disabled truncate mt-0.5">
              Shift: started {timeOnly(shiftCtx.startedAt)} · this update at {fmtDur(shiftCtx.intoShiftSec)} into shift
            </p>
          )}
        </div>
        {(isOwn || canModerate) && (
          <div className="relative">
            <button
              type="button"
              onClick={() => setMenuOpen((v) => !v)}
              aria-label="Update menu"
              className="h-6 w-6 inline-flex items-center justify-center rounded-sm text-text-secondary hover:bg-hover"
            >
              <MoreHorizontal className="h-3.5 w-3.5" />
            </button>
            {menuOpen && (
              <div
                className="absolute right-0 top-7 z-10 w-36 bg-surface border border-border-light rounded-md shadow-lg overflow-hidden"
                onMouseLeave={() => setMenuOpen(false)}
              >
                {isOwn && (
                  <button
                    onClick={() => { setMenuOpen(false); setEditing(true); }}
                    className="w-full text-left px-3 py-1.5 text-xs flex items-center gap-2 hover:bg-hover"
                  >
                    <Pencil className="h-3.5 w-3.5 text-text-secondary" /> Edit
                  </button>
                )}
                <button
                  onClick={async () => {
                    setMenuOpen(false);
                    if (!window.confirm('Delete this update?')) return;
                    try {
                      await del.mutateAsync({ id: update.id, itemId });
                    } catch (err) {
                      toast.error(err instanceof Error ? err.message : 'Delete failed');
                    }
                  }}
                  className="w-full text-left px-3 py-1.5 text-xs flex items-center gap-2 hover:bg-error/10 text-error"
                >
                  <Trash2 className="h-3.5 w-3.5" /> Delete
                </button>
              </div>
            )}
          </div>
        )}
      </header>

      {editing ? (
        <>
          <RichTextEditor ref={editorRef} initialHtml={update.body_html} minHeightPx={64} />
          <div className="mt-2 flex justify-end gap-1">
            <button onClick={() => setEditing(false)} className="btn-ghost h-7 px-2 text-xs">Cancel</button>
            <button onClick={() => void onSaveEdit()} className="btn-primary h-7 px-3 text-xs">Save</button>
          </div>
        </>
      ) : (
        <div
          className="update-body text-sm leading-relaxed"
          dangerouslySetInnerHTML={{ __html: update.body_html }}
        />
      )}

      {/* Reactions */}
      <div className="mt-2 flex items-center gap-1 flex-wrap">
        {Array.from(reactionsByEmoji.entries()).map(([emoji, info]) => {
          const isOn = profile && info.users.includes(profile.id);
          return (
            <button
              key={emoji}
              type="button"
              onClick={() => onToggle(emoji)}
              className={cn(
                'inline-flex items-center gap-1 h-6 px-2 rounded-pill border text-xs',
                isOn ? 'bg-selected border-brand text-brand' : 'bg-app border-border-light text-text-secondary hover:bg-hover',
              )}
            >
              <span>{emoji}</span>
              <span>{info.users.length}</span>
            </button>
          );
        })}
        <div className="relative">
          <button
            type="button"
            onClick={() => setPickerOpen((v) => !v)}
            aria-label="React"
            className="h-6 w-6 inline-flex items-center justify-center rounded-pill border border-border-light bg-app text-text-secondary hover:bg-hover"
          >
            <Smile className="h-3 w-3" />
          </button>
          {pickerOpen && (
            <div
              className="absolute left-0 bottom-7 z-10 bg-surface border border-border-light rounded-md shadow-lg px-1 py-1 flex gap-1"
              onMouseLeave={() => setPickerOpen(false)}
            >
              {QUICK_EMOJIS.map((e) => (
                <button
                  key={e}
                  type="button"
                  onClick={() => { setPickerOpen(false); onToggle(e); }}
                  className="h-7 w-7 inline-flex items-center justify-center rounded-sm hover:bg-hover text-sm"
                >
                  {e}
                </button>
              ))}
            </div>
          )}
        </div>
      </div>
    </li>
  );
}

// Visible label: "Jun 11, 3:42 PM" in the VIEWER's timezone.
function shortDateTime(iso: string | null | undefined): string {
  if (!iso) return '';
  const d = new Date(iso);
  if (!Number.isFinite(d.getTime())) return '';
  try {
    const date = d.toLocaleDateString(undefined, { month: 'short', day: 'numeric' });
    const time = d.toLocaleTimeString(undefined, { hour: 'numeric', minute: '2-digit' });
    return `${date}, ${time}`;
  } catch { return ''; }
}

// Tooltip: full date, including year + seconds, in viewer's timezone.
function fullDateTime(iso: string | null | undefined): string {
  if (!iso) return '';
  const d = new Date(iso);
  if (!Number.isFinite(d.getTime())) return '';
  try {
    return d.toLocaleString(undefined, {
      year: 'numeric', month: 'short', day: 'numeric',
      hour: 'numeric', minute: '2-digit', second: '2-digit',
      timeZoneName: 'short',
    });
  } catch { return ''; }
}

// Time-only label, e.g. "10:02 AM".
function timeOnly(iso: string | null | undefined): string {
  if (!iso) return '';
  const d = new Date(iso);
  if (!Number.isFinite(d.getTime())) return '';
  try {
    return d.toLocaleTimeString(undefined, { hour: 'numeric', minute: '2-digit' });
  } catch { return ''; }
}

// Duration in seconds → "7h 41m" / "23m" / "0m".
function fmtDur(totalSec: number): string {
  const n = Number.isFinite(totalSec) ? totalSec : 0;
  const s = Math.max(0, Math.floor(n));
  const h = Math.floor(s / 3600);
  const m = Math.floor((s % 3600) / 60);
  if (h > 0 && m > 0) return `${h}h ${m}m`;
  if (h > 0) return `${h}h`;
  return `${m}m`;
}

