import { useMemo, useState } from 'react';
import { Clock, RotateCcw } from 'lucide-react';
import { useQueryClient } from '@tanstack/react-query';
import { useItemActivity, activityKeys } from '@/hooks/activity';
import { useActiveUsers } from '@/hooks/users';
import { useColumns } from '@/hooks/columns';
import { useColumnLabels } from '@/hooks/labels';
import { useUpdateCellValue } from '@/hooks/items';
import { displayUserName } from '@/lib/displayName';
import { Avatar } from '@/components/Avatar';
import { Spinner } from '@/components/Spinner';
import { EmptyMessage } from '@/components/EmptyMessage';
import { toast } from 'sonner';
import type { ActivityLogRow, ColumnRow, ColumnLabelRow } from '@/lib/database.types';

interface ActivityTabProps {
  itemId: string;
  boardId: string;
}

export function ActivityTab({ itemId, boardId }: ActivityTabProps) {
  const { data, isLoading } = useItemActivity(itemId);
  const { data: users } = useActiveUsers();
  const { data: columns } = useColumns(boardId);
  const { data: labelsByColumnId } = useColumnLabels(boardId);
  const updateCell = useUpdateCellValue();
  const qc = useQueryClient();

  const mostRecentValueChangedIds = useMemo(() => {
    const seen = new Set<string>();
    const ids = new Set<string>();
    for (const row of data ?? []) {
      if (row.action_type !== 'value_changed') continue;
      const colId =
        (row.new_value as { column_id?: string } | null)?.column_id ??
        (row.old_value as { column_id?: string } | null)?.column_id;
      if (!colId) continue;
      if (!seen.has(colId)) {
        seen.add(colId);
        ids.add(row.id);
      }
    }
    return ids;
  }, [data]);

  const columnById = useMemo(() => {
    const m = new Map<string, ColumnRow>();
    for (const c of columns ?? []) m.set(c.id, c);
    return m;
  }, [columns]);

  if (isLoading) {
    return <div className="flex items-center justify-center py-6"><Spinner className="h-5 w-5 text-brand" /></div>;
  }
  if (!data || data.length === 0) {
    return <EmptyMessage title="No activity yet" description="Edits to this task will appear here." icon={<Clock className="h-6 w-6" />} />;
  }

  return (
    <ul className="space-y-2">
      {data.map((row) => (
        <ActivityRow
          key={row.id}
          row={row}
          actor={users?.find((u) => u.id === row.actor_id)}
          columnById={columnById}
          labelsByColumnId={labelsByColumnId ?? new Map()}
          users={users ?? []}
          boardId={boardId}
          itemId={itemId}
          isMostRecentValueChanged={mostRecentValueChangedIds.has(row.id)}
          onRestore={(columnId, value) => {
            updateCell.mutate(
              { boardId, itemId, columnId, value },
              {
                onSuccess: () => {
                  toast.success('Value restored');
                  void qc.invalidateQueries({ queryKey: activityKeys.byItem(itemId) });
                },
              },
            );
          }}
        />
      ))}
    </ul>
  );
}

interface ActivityRowProps {
  row: ActivityLogRow;
  actor?: { id: string; username: string; full_name: string | null; avatar_url: string | null; is_super_admin?: boolean };
  columnById: Map<string, ColumnRow>;
  labelsByColumnId: Map<string, ColumnLabelRow[]>;
  users: { id: string; username: string; full_name: string | null; is_super_admin?: boolean }[];
  boardId: string;
  itemId: string;
  isMostRecentValueChanged: boolean;
  onRestore: (columnId: string, value: unknown) => void;
}

function ActivityRow({ row, actor, columnById, labelsByColumnId, users, isMostRecentValueChanged, onRestore }: ActivityRowProps) {
  const [confirming, setConfirming] = useState(false);
  const actorName = displayUserName(actor);

  const oldVal = row.old_value as { column_id?: string; value?: unknown } | null;
  const canRestore =
    row.action_type === 'value_changed' &&
    !isMostRecentValueChanged &&
    oldVal != null &&
    oldVal.column_id != null;

  return (
    <li className="flex items-start gap-2 px-1 py-1.5">
      <Avatar name={actorName} url={actor?.avatar_url ?? null} size="sm" />
      <div className="flex-1 min-w-0">
        <p className="text-sm">
          <span className="font-medium">{actorName}</span>{' '}
          <span className="text-text-secondary">{renderMessage(row, columnById, labelsByColumnId, users)}</span>
        </p>
        <p className="text-[11px] text-text-disabled" title={fullDateTime(row.created_at)}>{shortDateTime(row.created_at)}</p>
        {canRestore && (
          <div className="mt-0.5">
            {!confirming ? (
              <button
                type="button"
                onClick={() => setConfirming(true)}
                className="inline-flex items-center gap-1 text-[11px] text-brand hover:underline"
              >
                <RotateCcw className="h-3 w-3" />
                Restore
              </button>
            ) : (
              <span className="text-[11px] text-text-secondary">
                Restore this value?{' '}
                <button
                  type="button"
                  onClick={() => {
                    setConfirming(false);
                    onRestore(oldVal!.column_id!, oldVal!.value);
                  }}
                  className="text-brand hover:underline font-medium"
                >
                  Yes
                </button>{' '}
                <button
                  type="button"
                  onClick={() => setConfirming(false)}
                  className="text-text-secondary hover:underline"
                >
                  No
                </button>
              </span>
            )}
          </div>
        )}
      </div>
    </li>
  );
}

function renderMessage(
  row: ActivityLogRow,
  columnById: Map<string, ColumnRow>,
  labelsByColumnId: Map<string, ColumnLabelRow[]>,
  users: { id: string; username: string; full_name: string | null; is_super_admin?: boolean }[],
): string {
  switch (row.action_type) {
    case 'item_created':   return 'created this task';
    case 'item_renamed': {
      const o = (row.old_value as { name?: string } | null)?.name;
      const n = (row.new_value as { name?: string } | null)?.name;
      return `renamed it ${o ? `from "${o}" ` : ''}to "${n ?? '—'}"`;
    }
    case 'item_archived':  return 'archived this task';
    case 'item_restored':  return 'restored this task';
    case 'item_deleted':   return 'deleted this task';
    case 'update_added':   return 'posted an update';
    case 'file_uploaded': {
      const name = (row.new_value as { name?: string } | null)?.name ?? 'a file';
      return `uploaded ${name}`;
    }
    case 'value_changed': {
      const old = row.old_value as { column_id?: string; value?: unknown } | null;
      const next = row.new_value as { column_id?: string; value?: unknown } | null;
      const colId = next?.column_id ?? old?.column_id;
      const col = colId ? columnById.get(colId) : null;
      if (!col) return 'changed a cell';
      const fromText = describeValue(col, old?.value, labelsByColumnId, users);
      const toText = describeValue(col, next?.value, labelsByColumnId, users);
      if (!fromText) return `set ${col.name} to ${toText || '—'}`;
      if (!toText)   return `cleared ${col.name} (was ${fromText})`;
      return `changed ${col.name} from ${fromText} to ${toText}`;
    }
    default: return row.action_type.replaceAll('_', ' ');
  }
}

function describeValue(
  col: ColumnRow,
  value: unknown,
  labelsByColumnId: Map<string, ColumnLabelRow[]>,
  users: { id: string; username: string; full_name: string | null; is_super_admin?: boolean }[],
): string {
  if (value == null) return '';
  switch (col.column_type) {
    case 'text':     return `"${((value as { text?: string }).text ?? '').slice(0, 60)}"`;
    case 'numbers':  return String((value as { value?: number }).value ?? '');
    case 'checkbox': return (value as { checked?: boolean }).checked ? 'checked' : 'unchecked';
    case 'date':     return (value as { date?: string }).date ?? '';
    case 'link':     return (value as { url?: string }).url ?? '';
    case 'status':
    case 'priority': {
      const id = (value as { label_id?: string }).label_id;
      const lbl = (labelsByColumnId.get(col.id) ?? []).find((l) => l.id === id);
      return lbl ? `"${lbl.name}"` : '';
    }
    case 'dropdown': {
      const ids = (value as { label_ids?: string[] }).label_ids ?? [];
      const names = ids
        .map((id) => (labelsByColumnId.get(col.id) ?? []).find((l) => l.id === id)?.name)
        .filter((n): n is string => !!n);
      return names.length ? names.join(', ') : '';
    }
    case 'people': {
      const ids = (value as { user_ids?: string[] }).user_ids ?? [];
      const names = ids
        .map((id) => users.find((u) => u.id === id))
        .filter((u): u is NonNullable<typeof u> => !!u)
        .map((u) => displayUserName(u));
      return names.join(', ');
    }
    default: return '';
  }
}

// Visible label: "Jun 11, 3:42 PM" in the viewer's timezone (admin sees own tz).
function shortDateTime(iso: string | null | undefined): string {
  if (!iso) return '';
  const d = new Date(iso);
  if (!Number.isFinite(d.getTime())) return '';
  try {
    const date = d.toLocaleDateString(undefined, { month: 'short', day: 'numeric' });
    const time = d.toLocaleTimeString(undefined, { hour: 'numeric', minute: '2-digit' });
    return `${date}, ${time}`;
  } catch { return ''; }
}

// Tooltip: full date with year + seconds + tz.
function fullDateTime(iso: string | null | undefined): string {
  if (!iso) return '';
  const d = new Date(iso);
  if (!Number.isFinite(d.getTime())) return '';
  try {
    return d.toLocaleString(undefined, {
      year: 'numeric', month: 'short', day: 'numeric',
      hour: 'numeric', minute: '2-digit', second: '2-digit',
      timeZoneName: 'short',
    });
  } catch { return ''; }
}
