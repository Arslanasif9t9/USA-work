/**
 * Phase 7b — EmployeePanel live "today" shift summary.
 *
 * Read-only glanceable status for the manager's own shift:
 *   • Live status dot + label
 *   • Time worked / remaining (interpolated 1s, .timer-readout)
 *   • Bio breaks used today (5b tier colors)
 *   • Lunch / dinner break status + live overstay timer
 *   • Current break timer (if on a break)
 *   • Lock / suspension calm notice
 *
 * Reuses ONLY the existing self-hooks:
 *   useTodayShiftSession, useShiftTick, useMyAccountLock, useShiftCanStart.
 * No new queries, no new RPC.
 */
import { useEffect, useRef, useState } from 'react';
import {
  useTodayShiftSession,
  useShiftTick,
  useMyAccountLock,
  useShiftCanStart,
  type ShiftTickPayload,
  useMyShiftHistory,
  type MyShiftHistoryRow,
} from '@/hooks/shift';

const EIA_NAVY = '#0F1E36';
const EIA_GOLD = '#E1B978';

function formatHMS(s: number): string {
  const v = Math.max(0, Math.floor(s));
  const h = Math.floor(v / 3600);
  const m = Math.floor((v % 3600) / 60);
  const sec = v % 60;
  return `${h}:${String(m).padStart(2, '0')}:${String(sec).padStart(2, '0')}`;
}

function formatMS(s: number): string {
  const neg = s < 0;
  const v = Math.floor(Math.abs(s));
  const m = Math.floor(v / 60);
  const sec = v % 60;
  return `${neg ? '-' : ''}${m}:${String(sec).padStart(2, '0')}`;
}

// Runtime extension for tick fields not yet in the shared TS type.
type BreakTickExt = {
  shift_break_used_today?: boolean;
  shift_break_seconds?: number;
  shift_break_overstay?: boolean;
};

function statusMeta(
  status: string | null | undefined,
  accountLocked: boolean,
): { label: string; dotClass: string } {
  if (accountLocked) return { label: 'Suspended', dotClass: 'bg-rose-500' };
  switch (status) {
    case 'not_started':
      return { label: 'Not started', dotClass: 'bg-slate-400' };
    case 'active':
      return { label: 'On shift', dotClass: 'bg-emerald-400' };
    case 'on_shift_break':
      return { label: 'On Lunch-Dinner Break', dotClass: 'bg-amber-400' };
    case 'on_bio_break':
      return { label: 'On Bio Break', dotClass: 'bg-sky-400' };
    case 'locked':
      return { label: 'Locked', dotClass: 'bg-rose-500' };
    case 'completed':
      return { label: 'Completed', dotClass: 'bg-emerald-500' };
    default:
      return { label: '—', dotClass: 'bg-slate-400' };
  }
}

export function EmployeePanel() {
  const { data: session } = useTodayShiftSession(true);
  const { data: accountLock } = useMyAccountLock(true);
  const { data: canStart } = useShiftCanStart(true);
  const { data: historyRows } = useMyShiftHistory(7);

  const sessionId = session?.id;
  const tickEnabled = !!sessionId && session.status !== 'not_started';
  const { data: tick } = useShiftTick(sessionId, tickEnabled);

  // ------------------------------------------------------------------
  // 1s local interpolation for elapsed / remaining (mirrors ShiftCountdownChip)
  // ------------------------------------------------------------------
  const [elapsedDisplay, setElapsedDisplay] = useState<number | null>(null);
  const [remainingDisplay, setRemainingDisplay] = useState<number | null>(null);
  const lastElapsedSnap = useRef<number | null>(null);
  const lastRemainingSnap = useRef<number | null>(null);

  useEffect(() => {
    if (!tick) return;
    if (lastElapsedSnap.current !== tick.elapsed_seconds) {
      lastElapsedSnap.current = tick.elapsed_seconds;
      setElapsedDisplay(tick.elapsed_seconds);
    }
    if (lastRemainingSnap.current !== tick.remaining_seconds) {
      lastRemainingSnap.current = tick.remaining_seconds;
      setRemainingDisplay(tick.remaining_seconds);
    }
  }, [tick]);

  const isTicking =
    tick?.status === 'active' ||
    tick?.status === 'on_shift_break' ||
    tick?.status === 'on_bio_break';

  useEffect(() => {
    if (elapsedDisplay === null || remainingDisplay === null || !isTicking) return;
    const id = setInterval(() => {
      setElapsedDisplay((e) => (e === null ? null : e + 1));
      setRemainingDisplay((r) => (r === null ? null : Math.max(0, r - 1)));
    }, 1000);
    return () => clearInterval(id);
  }, [isTicking, elapsedDisplay === null, remainingDisplay === null]);

  // ------------------------------------------------------------------
  // 1s local interpolation for break timer (mirrors BreakControls)
  // ------------------------------------------------------------------
  const [breakElapsed, setBreakElapsed] = useState<number>(0);
  const lastBreakSnapRef = useRef<number | null>(null);

  useEffect(() => {
    if (!tick) return;
    if (lastBreakSnapRef.current !== tick.current_break_elapsed_seconds) {
      lastBreakSnapRef.current = tick.current_break_elapsed_seconds;
      setBreakElapsed(tick.current_break_elapsed_seconds);
    }
  }, [tick]);

  const onShiftBreak = tick?.status === 'on_shift_break';
  const onBioBreak = tick?.status === 'on_bio_break';
  const onBreak = onShiftBreak || onBioBreak;

  useEffect(() => {
    if (!onBreak) return;
    const id = setInterval(() => setBreakElapsed((e) => e + 1), 1000);
    return () => clearInterval(id);
  }, [onBreak]);

  // ------------------------------------------------------------------
  // Derived values
  // ------------------------------------------------------------------
  const liveStatus = tick?.status ?? session?.status ?? 'not_started';
  const { label, dotClass } = statusMeta(liveStatus, !!accountLock?.account_locked);

  const tickExt = (tick ?? {}) as ShiftTickPayload & BreakTickExt;
  const bioCount = tick?.bio_break_count_today ?? 0;
  const effMax = tick?.bio_break_max_per_day ?? 7;
  const bioWarnCount = tick?.bio_break_warn_count ?? 6;
  const shiftBreakUsed = !!tickExt.shift_break_used_today;
  const shiftBreakAllowance = tickExt.shift_break_seconds ?? 1800;

  // Bio tier colors (exact 5b mapping from BreakControls)
  let bioPillClass = 'text-emerald-200 bg-emerald-900/30';
  let bioStatusWord = '';
  if (bioCount >= 6) {
    bioPillClass = 'text-rose-200 bg-rose-900/30';
    bioStatusWord = 'Final warning';
  } else if (bioCount === 5) {
    bioPillClass = 'text-slate-200 bg-slate-700/40';
    bioStatusWord = 'Please be mindful';
  } else if (bioCount === 4) {
    bioPillClass = 'text-amber-200 bg-amber-900/30';
    bioStatusWord = 'Caution';
  }

  const displayedBreakSecs = onShiftBreak
    ? shiftBreakAllowance - breakElapsed
    : Math.min(tick?.bio_break_max_seconds_each ?? 900, Math.max(1, breakElapsed));

  const shiftOverstay =
    onShiftBreak &&
    (!!tickExt.shift_break_overstay || breakElapsed >= shiftBreakAllowance);

  // Helper text when shift hasn't started yet
  let notStartedInfo: string | null = null;
  if (liveStatus === 'not_started' && canStart) {
    if (canStart.can_start) {
      notStartedInfo = 'Ready to start';
    } else if (canStart.reason === 'before_shift_time' && canStart.next_shift_at) {
      const t = new Date(canStart.next_shift_at);
      notStartedInfo = `Starts at ${t.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}`;
    } else if (canStart.reason === 'day_off') {
      notStartedInfo = 'Day off today';
    } else if (canStart.reason === 'before_start_date') {
      notStartedInfo = 'Not yet scheduled';
    }
  }

  const showWorkStats =
    liveStatus !== 'not_started' &&
    liveStatus !== 'locked' &&
    liveStatus !== 'completed' &&
    !accountLock?.account_locked;

  return (
    <aside className="w-60 shrink-0 h-full border-r border-border-light bg-sidebar flex flex-col">
      {/* Navy header strip */}
      <div className="px-4 py-3 border-b border-border-light" style={{ background: EIA_NAVY }}>
        <h2 className="text-base font-semibold" style={{ color: EIA_GOLD }}>
          My Shift
        </h2>
        <p className="text-[11px] text-white/70 mt-0.5">
          Your shift &amp; break history
        </p>
      </div>

      <div className="flex-1 overflow-y-auto px-4 py-4 space-y-4">
        {/* ---- 1. Status ---- */}
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <span className={`inline-block h-2.5 w-2.5 rounded-full ${dotClass}`} />
            <span className="text-[15px] font-semibold text-text-primary">{label}</span>
          </div>
          {notStartedInfo && (
            <p className="text-[13px] text-text-secondary">{notStartedInfo}</p>
          )}
        </div>

        {/* ---- 2. Time worked + remaining ---- */}
        {showWorkStats && elapsedDisplay !== null && remainingDisplay !== null && (
          <div className="space-y-1">
            <div className="flex items-baseline justify-between gap-2">
              <span className="text-[11px] uppercase tracking-wider text-text-secondary">
                Worked
              </span>
              <span className="timer-readout" style={{ color: EIA_GOLD }}>
                {formatHMS(elapsedDisplay)}
              </span>
            </div>
            <div className="flex items-baseline justify-between gap-2">
              <span className="text-[11px] uppercase tracking-wider text-text-secondary">
                Remaining
              </span>
              <span className="timer-readout" style={{ color: EIA_GOLD }}>
                {formatHMS(remainingDisplay)}
              </span>
            </div>
          </div>
        )}

        {/* ---- 3. Bio breaks ---- */}
        {showWorkStats && (
          <div className="space-y-1">
            <span className="text-[11px] uppercase tracking-wider text-text-secondary">
              Bio breaks today
            </span>
            <div className={`inline-flex items-center gap-1.5 text-[13px] px-2.5 py-1 rounded-full font-medium ${bioPillClass}`}>
              {bioCount} of {effMax}
              {bioStatusWord && <span className="opacity-80">· {bioStatusWord}</span>}
            </div>
          </div>
        )}

        {/* ---- 4. Lunch / Dinner break ---- */}
        {showWorkStats && (
          <div className="space-y-1">
            <span className="text-[11px] uppercase tracking-wider text-text-secondary">
              Lunch / Dinner
            </span>
            {onShiftBreak ? (
              <div className="flex items-center gap-2">
                <span className="inline-block h-2 w-2 rounded-full bg-amber-400 animate-pulse" />
                <span
                  className={`timer-readout ${shiftOverstay ? 'text-rose-400' : 'text-amber-200'}`}
                >
                  {formatMS(displayedBreakSecs)}
                </span>
                {shiftOverstay && (
                  <span className="text-[11px] text-rose-300">Overstay</span>
                )}
              </div>
            ) : (
              <span className="text-[13px] text-text-secondary">
                {shiftBreakUsed ? 'Used today' : 'Not used today'}
              </span>
            )}
          </div>
        )}

        {/* ---- 5. Live break timer (bio break) ---- */}
        {onBioBreak && (
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <span className="inline-block h-2 w-2 rounded-full bg-sky-400 animate-pulse" />
              <span className="text-[11px] uppercase tracking-wider text-text-secondary">
                Bio break timer
              </span>
            </div>
            <span className="timer-readout text-sky-200">
              {formatMS(displayedBreakSecs)}
            </span>
          </div>
        )}

        {/* ---- 6. Locked / Suspended notice ---- */}
        {(liveStatus === 'locked' || accountLock?.account_locked) && (
          <div className="rounded-md p-3 border border-rose-700/30 bg-rose-950/20">
            <p className="text-[13px] text-rose-200 leading-relaxed">
              {accountLock?.account_locked
                ? 'Your account is suspended — see the message on your board.'
                : 'Your shift is locked — see the message on your board.'}
            </p>
          </div>
        )}

        {/* ---- Completed notice ---- */}
        {liveStatus === 'completed' && (
          <p className="text-[13px] text-emerald-300">Shift complete — great work today.</p>
        )}

        {/* ---- Last 7 Days ---- */}
        <div className="border-t border-border-light pt-4 mt-2">
          <h3 className="text-[11px] uppercase tracking-wider text-text-secondary mb-2">
            Last 7 Days
          </h3>
          {historyRows && historyRows.length > 0 ? (
            <div className="space-y-2 max-h-[260px] overflow-y-auto pr-1">
              {historyRows.map((row) => {
                const { kind, label } = dayStatus(row);
                const bioColor = bioTierClasses(row.bio_break_count_today);
                const tookLunch = row.shift_break_count_today > 0;
                return (
                  <div
                    key={row.work_date}
                    className="rounded-md border border-border-light bg-surface/40 px-3 py-2.5 space-y-1.5"
                  >
                    <div className="flex items-center justify-between gap-2">
                      <span className="text-[13px] font-medium text-text-primary">
                        {formatDayLabel(row.work_date)}
                      </span>
                      <DayIndicator kind={kind} label={label} />
                    </div>
                    <div className="flex flex-wrap items-center gap-2">
                      <span
                        className={`inline-flex items-center text-[11px] font-medium px-1.5 py-0.5 rounded-full ${bioColor}`}
                      >
                        Bio {row.bio_break_count_today}
                      </span>
                      <span className="text-[11px] text-text-secondary">
                        {tookLunch ? 'Lunch · Yes' : 'Lunch · No'}
                      </span>
                      {row.late_start_flag && (
                        <span className="inline-flex items-center text-[10px] font-medium px-1.5 py-0.5 rounded-full bg-amber-900/30 text-amber-200">
                          Late start
                        </span>
                      )}
                      {row.early_end_flag && (
                        <span className="inline-flex items-center text-[10px] font-medium px-1.5 py-0.5 rounded-full bg-slate-700/40 text-slate-200">
                          Early end
                        </span>
                      )}
                      {row.status === 'locked' && (
                        <span className="inline-flex items-center text-[10px] font-medium px-1.5 py-0.5 rounded-full bg-rose-900/30 text-rose-200">
                          Locked
                        </span>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          ) : (
            <p className="text-[13px] text-text-secondary py-2">No shift history yet.</p>
          )}
        </div>
      </div>
    </aside>
  );
}

function formatDayLabel(dateISO: string): string {
  const d = new Date(dateISO + 'T00:00:00');
  return d.toLocaleDateString('en-US', {
    weekday: 'short',
    month: 'short',
    day: 'numeric',
  });
}

type DayStatusKind = 'good' | 'bad' | 'neutral';

function dayStatus(row: MyShiftHistoryRow): { kind: DayStatusKind; label: string } {
  if (row.status === 'not_started') {
    return { kind: 'neutral', label: '—' };
  }
  const hasOverstay =
    row.overstay_lock_email_sent_at != null || row.locked_reason === 'break_overstay';
  if (hasOverstay || row.bio_break_count_today >= 4) {
    return { kind: 'bad', label: '✕' };
  }
  return { kind: 'good', label: '✓' };
}

function DayIndicator({ kind, label }: { kind: DayStatusKind; label: string }) {
  if (kind === 'neutral') {
    return <span className="text-[13px] text-text-secondary">{label}</span>;
  }
  const isGood = kind === 'good';
  return (
    <span
      className={`inline-flex h-5 w-5 items-center justify-center rounded-full text-[10px] font-bold ${
        isGood
          ? 'bg-emerald-900/30 text-emerald-300'
          : 'bg-rose-900/30 text-rose-300'
      }`}
      title={isGood ? 'Good day — within limits' : 'Day over limit'}
    >
      {label}
    </span>
  );
}

function bioTierClasses(count: number): string {
  if (count >= 6) return 'text-rose-200 bg-rose-900/30';
  if (count === 5) return 'text-slate-200 bg-slate-700/40';
  if (count === 4) return 'text-amber-200 bg-amber-900/30';
  return 'text-emerald-200 bg-emerald-900/30';
}
