import { useEffect, useRef } from 'react';
import { Outlet } from '@tanstack/react-router';
import { useQueryClient } from '@tanstack/react-query';
import { ChevronLeft, ChevronRight } from 'lucide-react';
import { TopBar } from './TopBar';
import { IconRail } from './IconRail';
import { WorkspacePanel } from './WorkspacePanel';
import { EmployeePanel } from './EmployeePanel';
import { AdminQuickBar } from '@/components/admin/AdminQuickBar';
import { useAuthStore } from '@/state/authStore';
import { useSidebarStore } from '@/state/sidebarStore';
import { useMyAccountLock, useMyAccountLockRealtime } from '@/hooks/shift';
import { AccountLockedOverlay } from '@/components/shift/AccountLockedOverlay';
import { LilyChat } from '@/components/chat/LilyChat';
import { cn } from '@/lib/cn';
import { DIAG, diag, logStuckQueries } from '@/lib/diag';

// =====================================================================
// Simplified data-loading model (founder decision):
//
// All focus-driven query machinery has been REMOVED from this shell.
// A tab refocus is now a complete no-op at the shell level — no
// invalidate, no paused-kick, no zombie-fetch rekick, no blur/focus/
// visibilitychange listeners, no online/offline diag. Data simply
// loads when a page mounts; to see another machine's changes the user
// refreshes / reopens the board (cross-machine live sync is
// intentionally dropped here).
//
// Paired with src/lib/supabase.ts having autoRefreshToken:false, this
// means a refocus event causes ZERO supabase activity. The only thing
// that ever touches auth on focus is the user themselves clicking
// something, and tokens rotate lazily via timeoutFetch's 401-retry.
// =====================================================================
export function AppShell() {
  // UI polish (batch item 3): the left sidebar (IconRail = workspace
  // switcher, WorkspacePanel = Boards list + "Add new") is admin/super
  // only. Managers see no sidebar — they get only the board area, full
  // width. The role gate matches the server's is_admin() SQL helper
  // (role='admin' OR is_super_admin), the same shape used elsewhere in
  // the codebase (e.g. BoardContent's canEdit). Non-admins are routed
  // directly to their first subscribed board by _app.index.tsx, so
  // hiding the sidebar doesn't strand them.
  const profile = useAuthStore((s) => s.profile);
  const isAdmin = !!profile && (profile.role === 'admin' || profile.is_super_admin);
  // Phase 10 — app-shell-level account lock. Managers only (admins
  // manage locks and must never be locked out). Polls the same
  // shift_my_account_lock RPC ShiftDriver uses. When locked, the
  // full-screen AccountLockedOverlay renders ABOVE the route Outlet,
  // covering every route (/, /profile, any board, before load).
  const isManagerForLockCheck = !!profile && !isAdmin;
  const { data: accountLock } = useMyAccountLock(isManagerForLockCheck);
  // 0078 — instant push for admin Stop / unlock. Replaces the previous
  // 30s poll (now a 2-min backstop). Mounted app-wide so every route
  // (/, /profile, every board) reacts within ~1s.
  useMyAccountLockRealtime(isManagerForLockCheck);
  const showAccountLock = isManagerForLockCheck && accountLock?.account_locked === true;

  // ===================================================================
  // DIAG-ONLY: passive focus/visibilitychange logger. NO invalidate,
  // NO refetch, NO setInterval, NO cache walk other than the one-shot
  // logStuckQueries report. This is the bare-minimum instrumentation
  // we need to answer: "on refocus, does a fetch fire and hang, or
  // does it not fire at all?" — without re-introducing any of the
  // focus-driven query machinery that was deliberately ripped out at
  // commit e3b2055 (and don't re-introduce queryWatchdog from ec59373).
  // ===================================================================
  const qc = useQueryClient();
  const hiddenSinceRef = useRef<number | null>(null);
  useEffect(() => {
    if (!DIAG) return;
    const onHidden = () => {
      if (document.visibilityState === 'hidden') {
        hiddenSinceRef.current = Date.now();
        diag('focus', 'hidden  at=' + new Date().toISOString());
      }
    };
    const onVisible = () => {
      if (document.visibilityState !== 'visible') return;
      const since = hiddenSinceRef.current;
      const hiddenMs = since === null ? 0 : Date.now() - since;
      hiddenSinceRef.current = null;
      diag('focus', 'VISIBLE hiddenMs=' + hiddenMs
        + '  onLine=' + navigator.onLine
        + '  hasFocus=' + document.hasFocus()
        + '  at=' + new Date().toISOString());
      // One-shot cache snapshot on refocus. Pure read; no mutation.
      logStuckQueries(qc, 'focus.return');
      diag('focus', 'NO invalidate, NO refetch — shell is intentionally inert on focus');
    };
    document.addEventListener('visibilitychange', onHidden);
    document.addEventListener('visibilitychange', onVisible);
    window.addEventListener('focus', onVisible);
    window.addEventListener('blur', onHidden);
    diag('focus', 'listeners attached (DIAG only — log-only, no behavior change)');
    return () => {
      document.removeEventListener('visibilitychange', onHidden);
      document.removeEventListener('visibilitychange', onVisible);
      window.removeEventListener('focus', onVisible);
      window.removeEventListener('blur', onHidden);
    };
  }, [qc]);

  const collapsed = useSidebarStore((s) => s.collapsed);
  const toggleSidebar = useSidebarStore((s) => s.toggle);

  return (
    <div className="h-screen flex flex-col bg-app text-text-primary">
      <TopBar />
      {isAdmin && <AdminQuickBar />}
      <div className="flex-1 flex min-h-0">
        {isAdmin ? (
          <>
            <IconRail />
            {/* Collapsible WorkspacePanel wrapper — smooth width
                transition. When collapsed, width=0 + overflow hidden
                so the boards list slides out and the main area
                expands full-width. The IconRail stays visible as the
                thin rail so admin can still navigate / re-expand. */}
            <div
              className={cn(
                'relative shrink-0 overflow-hidden transition-[width] duration-300 ease-in-out',
                collapsed ? 'w-0' : 'w-60',
              )}
            >
              <WorkspacePanel />
            </div>
          </>
        ) : (
          // Phase 7a — manager-only sidebar slot. Shares the same
          // useSidebarStore + chevron toggle as admin. No IconRail
          // and no WorkspacePanel — just the EmployeePanel (the
          // employee self-dashboard, filled in 7b/7c). Collapse
          // behavior, slide transition, and full-width board reflow
          // are identical to the admin shell.
          <div
            className={cn(
              'relative shrink-0 overflow-hidden transition-[width] duration-300 ease-in-out',
              collapsed ? 'w-0' : 'w-60',
            )}
          >
            <EmployeePanel />
          </div>
        )}
        <main className="flex-1 min-w-0 overflow-y-auto relative">
          {/* Chevron toggle is shown for BOTH admin and manager —
              both have a left panel now. Same store, same UX. */}
          <button
            type="button"
            onClick={toggleSidebar}
            aria-label={collapsed ? 'Expand sidebar' : 'Collapse sidebar'}
            title={collapsed ? 'Expand sidebar' : 'Collapse sidebar'}
            className="absolute top-3 left-0 z-30 inline-flex h-8 w-6 items-center justify-center rounded-r-md border border-l-0 border-[hsl(var(--gold)/0.4)] bg-[hsl(var(--navy))] text-[hsl(var(--gold))] shadow-md hover:bg-[hsl(var(--navy)/0.85)] transition-colors"
          >
            {collapsed ? (
              <ChevronRight className="h-4 w-4" />
            ) : (
              <ChevronLeft className="h-4 w-4" />
            )}
          </button>
          <Outlet />
          <LilyChat />
        </main>
      </div>
      {/* Phase 10 — app-shell-level account lock overlay (managers).
          Rendered last so it sits above every route surface. The
          overlay is itself fixed inset-0 z-50; mounting here ensures
          it's present on every route, including before any board
          finishes loading. ShiftDriver also renders its own copy
          inside boards — both reference the same RPC state, so
          there is no visual double-overlay (one fixed full-screen
          panel either way). */}
      {showAccountLock && (
        <AccountLockedOverlay reason={accountLock?.account_lock_reason} />
      )}
    </div>
  );
}
