/**
 * /admin/lily — admin console for the Lily onboarding chat.
 *
 * - Mode toggle (AI / Human) — flips lily_settings.mode (single row id=1).
 * - Left pane: every chat_thread, sorted by last_message_at desc.
 * - Right pane: selected conversation; admin can send as Lily.
 *
 * Route gate inherited from src/routes/_app.admin.tsx beforeLoad.
 */
import { createFileRoute } from '@tanstack/react-router';
import { LilyAdminSection } from '@/components/admin/LilyAdminSection';

export const Route = createFileRoute('/_app/admin/lily')({
  component: () => <LilyAdminSection />,
});
