/**
 * /admin/reports — Phase 8a daily break/shift report.
 *
 * Admin-only (gate is on parent /admin route). Renders ReportsSection,
 * which uses useDailyBreakReport(date) — a direct SELECT on
 * shift_sessions under the existing is_admin() OR user_id = auth.uid()
 * RLS policy.
 */
import { createFileRoute } from '@tanstack/react-router';
import { ReportsSection } from '@/components/admin/ReportsSection';

export const Route = createFileRoute('/_app/admin/reports')({
  component: () => <ReportsSection />,
});
