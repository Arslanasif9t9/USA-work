/**
 * /admin/kpi — Phase 9a KPI dashboard route.
 *
 * Admin-only (gate inherited from /admin parent). Renders KpiDashboard,
 * which uses useKpiData + useKpiSchedules — both pure SELECTs under
 * existing RLS (is_admin() OR user_id = auth.uid()).
 */
import { createFileRoute } from '@tanstack/react-router';
import { KpiDashboard } from '@/components/admin/KpiDashboard';

export const Route = createFileRoute('/_app/admin/kpi')({
  component: () => <KpiDashboard />,
});
