/**
 * P4.2 — Shift system hooks (read-only + start RPC).
 *
 * The server (migration 0057) is the source of truth for every time
 * value here. The client polls `shift_tick` every ~10s and interpolates
 * 1/sec locally between polls — but it NEVER persists a timer to local
 * storage. A refresh / refocus / clock-change immediately snaps back to
 * the server-computed remaining_seconds, so users cannot steal time by
 * fiddling with the page.
 *
 * Higher phases (P4.3+) add lock / break / admin mutations on top of
 * the skeleton RPCs already shipped in 0057.
 */
import { useEffect, useRef } from 'react';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { DIAG, diag } from '@/lib/diag';
import { dbRpc, dbSelect, dbSelectMaybeSingle, eq, inSet } from '@/lib/db';
import { supabase } from '@/lib/supabase';

import { useAuthStore } from '@/state/authStore';

// =====================================================================
// DIAG candidate #9 helper — log every transition of an `enabled` flag.
// If a shift query is stuck not running after refocus, the founder will
// see the value flip true→false→true here. If it stays true the whole
// time and queryFn is still not firing, candidate #9 is innocent and we
// look at candidate #5 (fetch wrapper) next.
// =====================================================================
function useEnabledDiag(name: string, enabled: boolean): void {
  const prev = useRef<boolean | null>(null);
  useEffect(() => {
    if (!DIAG) return;
    if (prev.current === enabled) return;
    diag('shift.enabled', name + ': ' + prev.current + ' → ' + enabled);
    prev.current = enabled;
  }, [name, enabled]);
}

export type ShiftStatus =
  | 'not_started'
  | 'active'
  | 'on_shift_break'
  | 'on_bio_break'
  | 'locked'
  | 'completed';

export type ShiftMode = 'easy' | 'medium' | 'hard' | 'off';

// Row returned by shift_get_or_create_today_session (composite of
// public.shift_sessions, serialized as JSON by PostgREST).
export interface ShiftSessionRow {
  id: string;
  user_id: string;
  work_date: string;
  status: ShiftStatus;
  mode: ShiftMode;
  period_seconds: number;
  required_seconds: number;
  started_at: string | null;
  paused_total_seconds: number;
  current_pause_started_at: string | null;
  current_pause_reason: 'period_lock' | 'admin' | null;
  current_period_index: number;
  period_85_last_index_alerted: number;
  locked_at: string | null;
  locked_reason: 'period_lock' | 'shift_complete' | 'admin' | 'bio_request' | null;
  locked_by: string | null;
  bio_break_count_today: number;
  bio_break_total_seconds_today: number;
  completed_at: string | null;
  created_at: string;
  updated_at: string;
}

// Live computed payload returned by shift_tick (jsonb). Widened by
// migration 0060 to expose break state + bio config + computed flags.
export interface ShiftTickPayload {
  session_id: string;
  user_id: string;
  status: ShiftStatus;
  started_at: string | null;
  work_date: string;
  mode: ShiftMode;
  period_seconds: number;
  required_seconds: number;
  elapsed_seconds: number;
  remaining_seconds: number;
  paused_total_seconds: number;
  current_period_index: number;
  current_period_start_seconds?: number;
  current_period_end_seconds: number;
  period_85_threshold_seconds?: number;
  period_85_due: boolean;
  period_lock_due: boolean;
  // Break state (P4.4)
  current_break_kind: 'shift' | 'bio' | null;
  current_break_started_at: string | null;
  current_break_elapsed_seconds: number;
  // Bio counters + config (P4.4)
  bio_break_count_today: number;
  bio_break_total_seconds_today: number;
  bio_break_admin_grants_today: number;
  bio_break_max_per_day: number | null;
  bio_break_warn_count: number | null;
  bio_break_warn_total_seconds: number | null;
  bio_break_max_seconds_each: number | null;
  bio_limit_reached: boolean;
  locked_at: string | null;
  locked_reason: ShiftSessionRow['locked_reason'];
  completed_at: string | null;
  // P4.5 schedule flags
  scheduled_start_at: string | null;
  expected_end_at: string | null;
  late_start_flag: boolean | null;
  late_start_minutes: number | null;
  early_end_flag: boolean | null;
  early_end_minutes: number | null;
  now: string;
}

export const shiftKeys = {
  all:   ['shift'] as const,
  today: (uid: string) => [...shiftKeys.all, 'today', uid] as const,
  tick:  (sessionId: string) => [...shiftKeys.all, 'tick', sessionId] as const,
};

// ---------------------------------------------------------------------
// useTodayShiftSession — one call per mount; the daily-reset / lazy-
// create happens server-side in shift_get_or_create_today_session().
// Pass enabled=isManager so admins/super never touch the shift tables.
// ---------------------------------------------------------------------
export function useTodayShiftSession(enabled: boolean) {
  const userId = useAuthStore((s) => s.profile?.id);
  useEnabledDiag('useTodayShiftSession', enabled && !!userId);
  return useQuery<ShiftSessionRow>({
    queryKey: userId ? shiftKeys.today(userId) : [...shiftKeys.all, 'today', '_'],
    enabled: enabled && !!userId,
    queryFn: async () => {
      return await dbRpc<ShiftSessionRow>('shift_get_or_create_today_session', {});
    },
    // Fresh on mount so a page refresh immediately re-syncs.
    staleTime: 0,
    refetchOnWindowFocus: false, // refresh-on-401 layer + warm-up handle this
  });
}

// ---------------------------------------------------------------------
// Phase 7a — useMyShiftHistory(days).
//
// Self-read of the calling manager's own past shift_sessions rows.
// Works under the existing RLS policy:
//   shift_sessions_select USING (is_admin() OR user_id = auth.uid())
// — no new RPC, no policy change. Includes today's row when present
// so the panel can show "today + previous N-1 days". Polled lightly
// (60s) so a freshly-completed day appears without a manual refresh.
// ---------------------------------------------------------------------
export interface MyShiftHistoryRow {
  work_date: string;
  status: ShiftStatus;
  started_at: string | null;
  completed_at: string | null;
  required_seconds: number;
  paused_total_seconds: number;
  late_start_flag: boolean;
  late_start_minutes: number;
  early_end_flag: boolean;
  early_end_minutes: number;
  bio_break_count_today: number;
  shift_break_count_today: number;
  overstay_lock_email_sent_at: string | null;
  locked_reason: string | null;
}

export function useMyShiftHistory(days = 7, enabled = true) {
  const userId = useAuthStore((s) => s.profile?.id);
  useEnabledDiag('useMyShiftHistory', enabled && !!userId);
  return useQuery<MyShiftHistoryRow[]>({
    queryKey: [...shiftKeys.all, 'history', userId ?? '_', days],
    enabled: enabled && !!userId,
    queryFn: async () => {
      // Compute the inclusive lower bound in UTC (work_date is a DATE
      // column written in UTC server-side — match that here).
      const since = new Date();
      since.setUTCDate(since.getUTCDate() - (days - 1));
      const sinceISO = since.toISOString().slice(0, 10);
      return await dbSelect<MyShiftHistoryRow>('shift_sessions', {
        select:
          'work_date, status, started_at, completed_at, required_seconds, ' +
          'paused_total_seconds, late_start_flag, late_start_minutes, ' +
          'early_end_flag, early_end_minutes, bio_break_count_today, ' +
          'shift_break_count_today, overstay_lock_email_sent_at, locked_reason',
        filters: { user_id: eq(userId!), work_date: `gte.${sinceISO}` },
        order: 'work_date.desc',
      });

    },
    staleTime: 30_000,
    refetchInterval: 60_000,
    refetchOnWindowFocus: false,
  });
}

// ---------------------------------------------------------------------
// Phase 8a — useDailyBreakReport(dateISO).
//
// Admin-only report. Pulls every shift_sessions row for the given
// work_date and joins users(full_name, email, username). Works under
// the existing RLS:
//   shift_sessions_select USING (is_admin() OR user_id = auth.uid())
// — admins read every row. No new RPC. Light polling (30s) so a fresh
// completion shows up without manual refresh.
// ---------------------------------------------------------------------
export interface DailyReportRow {
  session_id: string;
  user_id: string;
  work_date: string;
  status: ShiftStatus;
  started_at: string | null;
  completed_at: string | null;
  late_start_flag: boolean;
  late_start_minutes: number;
  early_end_flag: boolean;
  early_end_minutes: number;
  bio_break_count_today: number;
  shift_break_count_today: number;
  overstay_lock_email_sent_at: string | null;
  locked_reason: string | null;
  full_name: string | null;
  email: string | null;
  username: string;
}

export function useDailyBreakReport(dateISO: string, enabled = true) {
  return useQuery<DailyReportRow[]>({
    queryKey: [...shiftKeys.all, 'daily-report', dateISO],
    enabled: enabled && !!dateISO,
    queryFn: async () => {
      type Raw = {
        id: string;
        user_id: string;
        work_date: string;
        status: ShiftStatus;
        started_at: string | null;
        completed_at: string | null;
        late_start_flag: boolean;
        late_start_minutes: number;
        early_end_flag: boolean;
        early_end_minutes: number;
        bio_break_count_today: number;
        shift_break_count_today: number;
        overstay_lock_email_sent_at: string | null;
        locked_reason: string | null;
        users: { full_name: string | null; email: string | null; username: string } | null;
      };
      const data = await dbSelect<Raw>('shift_sessions', {
        select:
          'id, user_id, work_date, status, started_at, completed_at, ' +
          'late_start_flag, late_start_minutes, early_end_flag, early_end_minutes, ' +
          'bio_break_count_today, shift_break_count_today, ' +
          'overstay_lock_email_sent_at, locked_reason, ' +
          'users:user_id ( full_name, email, username )',
        filters: { work_date: eq(dateISO) },
        order: 'started_at.asc.nullslast',
      });

      return data.map((r) => ({

        session_id: r.id,
        user_id: r.user_id,
        work_date: r.work_date,
        status: r.status,
        started_at: r.started_at,
        completed_at: r.completed_at,
        late_start_flag: r.late_start_flag,
        late_start_minutes: r.late_start_minutes,
        early_end_flag: r.early_end_flag,
        early_end_minutes: r.early_end_minutes,
        bio_break_count_today: r.bio_break_count_today,
        shift_break_count_today: r.shift_break_count_today,
        overstay_lock_email_sent_at: r.overstay_lock_email_sent_at,
        locked_reason: r.locked_reason,
        full_name: r.users?.full_name ?? null,
        email: r.users?.email ?? null,
        username: r.users?.username ?? '?',
      })) as DailyReportRow[];
    },
    staleTime: 30_000,
    refetchInterval: 30_000,
    refetchOnWindowFocus: false,
  });
}

// ---------------------------------------------------------------------
// Phase 8b — useWeeklyAiReport.
//
// Mirrors useAiBuild's pattern: grab the session JWT, POST to the
// /api/ai-weekly-report edge function, parse JSON. The server is the
// admin gate (re-fetches public.users.role); this hook just transports
// the request. Returns prose + the deterministic per-day breakdown so
// the UI can render BOTH the tick/cross grid and the AI summary.
// ---------------------------------------------------------------------
export interface WeeklyAiDay {
  date: string;
  label: string;
  kind: 'good' | 'bad' | 'neutral' | 'no_shift';
  bio: number;
  lunch: number;
  late?: number;
  early?: number;
  overstay: boolean;
  status: string;
}
export interface WeeklyAiTotals {
  good: number;
  bad: number;
  no_shift: number;
  neutral: number;
  bio_total: number;
  lunches_taken: number;
  overstays: number;
  late_days: number;
  early_days: number;
}
export interface WeeklyAiReportResponse {
  summary: string;
  totals: WeeklyAiTotals;
  days: WeeklyAiDay[];
}
export interface WeeklyAiReportArgs {
  userId: string;
  weekStart: string; // YYYY-MM-DD (inclusive)
}

export function useWeeklyAiReport() {
  return useMutation({
    mutationFn: async (args: WeeklyAiReportArgs): Promise<WeeklyAiReportResponse> => {
      const { safeGetSession } = await import('@/lib/safeAuth');
      const { apiFetch } = await import('@/lib/apiClient');
      const { data: sessionData, timedOut } = await safeGetSession('ai-weekly-report');
      if (timedOut) throw new Error('auth check timed out — please try again');
      const jwt = sessionData.session?.access_token;
      if (!jwt) throw new Error('not signed in');

      const controller = new AbortController();
      const timer = setTimeout(() => controller.abort(), 35_000);

      let resp: Response;
      try {
        resp = await apiFetch('/api/ai-weekly-report', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${jwt}`,
          },
          body: JSON.stringify({ user_id: args.userId, week_start: args.weekStart }),
          signal: controller.signal,
        });
      } catch (err) {
        clearTimeout(timer);
        if (err instanceof Error && err.name === 'AbortError') {
          throw new Error('AI report timed out after 35 seconds. Please try again.');
        }
        throw new Error(err instanceof Error ? err.message : String(err));
      }
      clearTimeout(timer);

      const text = await resp.text();
      let payload: unknown;
      try { payload = JSON.parse(text); }
      catch { throw new Error(`bad response (HTTP ${resp.status}): ${text.slice(0, 200)}`); }
      if (!resp.ok) {
        const errMsg = (payload as { error?: string } | null)?.error ?? `request failed (HTTP ${resp.status})`;
        throw new Error(errMsg);
      }
      return payload as WeeklyAiReportResponse;
    },
  });
}



// ---------------------------------------------------------------------
// useShiftStart — RPC mutation. Optimistically flips the cached
// session to status='active' so the gate hides instantly; the
// invalidate-driven refetch confirms moments later.
// ---------------------------------------------------------------------
export function useShiftStart() {
  const qc = useQueryClient();
  const userId = useAuthStore((s) => s.profile?.id);
  return useMutation({
    mutationFn: async (): Promise<{ session_id: string; started_at: string }> => {
      return await dbRpc<{ session_id: string; started_at: string }>('shift_start', {});
    },
    onSuccess: (payload) => {
      if (userId) {
        qc.setQueryData<ShiftSessionRow | undefined>(
          shiftKeys.today(userId),
          (prev) => prev ? { ...prev, status: 'active', started_at: payload.started_at } : prev,
        );
      }
      void qc.invalidateQueries({ queryKey: shiftKeys.all });
    },
  });
}

// ---------------------------------------------------------------------
// P4c — useShiftCanStart. Caller-only read RPC that returns whether the
// logged-in manager is allowed to start a shift NOW, with a reason and
// the next allowed start datetime (in their tz). Polled every 30s so a
// manager waiting through their start time gets unlocked without a
// manual refresh.
// ---------------------------------------------------------------------
export type ShiftCanStartReason =
  | 'ok' | 'before_start_date' | 'day_off' | 'before_shift_time' | 'after_shift_end';
export interface ShiftCanStart {
  can_start: boolean;
  reason: ShiftCanStartReason;
  next_shift_at: string | null;  // ISO timestamptz
  timezone: string;
}
export function useShiftCanStart(enabled: boolean) {
  return useQuery<ShiftCanStart>({
    queryKey: [...shiftKeys.all, 'can-start'],
    enabled,
    queryFn: async () => {
      return await dbRpc<ShiftCanStart>('shift_can_start', {});
    },
    refetchInterval: 30_000,
    refetchOnWindowFocus: true,
    staleTime: 0,
  });
}

// ---------------------------------------------------------------------
// useShiftTick — polls the read-only RPC every 10s. The component
// using this is responsible for the 1/sec local interpolation.
// ---------------------------------------------------------------------
// ---------------------------------------------------------------------
// useShiftSelfPeriodLock — manager-callable (idempotent) when tick says
// period_lock_due. Server-time gated by the RPC itself.
// ---------------------------------------------------------------------
export function useShiftSelfPeriodLock() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async (sessionId: string) => {
      return await dbRpc<{ session_id: string; status: ShiftStatus; already_locked: boolean }>('shift_self_period_lock', { p_session_id: sessionId });
    },
    onSuccess: (_data, sessionId) => {
      void qc.invalidateQueries({ queryKey: shiftKeys.all });
      void sessionId;
    },
  });
}

// ---------------------------------------------------------------------
// useShiftBreakFreeze (0068) — manager-callable, idempotent. The client
// fires it when shift_tick reports shift_break_overstay=true AND
// shift_break_frozen=false. The RPC re-checks eligibility server-side
// so a stale client never freezes something it shouldn't, and double
// calls are safe (returns {applied:false}).
// ---------------------------------------------------------------------
export function useShiftBreakFreeze() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async (sessionId: string) => {
      return await dbRpc<{
        session_id: string;
        status: ShiftStatus;
        frozen: boolean;
        applied: boolean;
      }>('shift_break_freeze', { p_session_id: sessionId });
    },
    onSuccess: () => {
      void qc.invalidateQueries({ queryKey: shiftKeys.all });
    },
  });
}

// ---------------------------------------------------------------------
// useUserShiftActivity (PHASE 0 Step — Activity Log Panel)
// Reads the target user's shift_events newest first, capped at ~200 rows.
// Admin RLS on public.shift_events allows cross-user SELECT
// (USING is_admin() OR user_id = auth.uid()), so we use a direct
// supabase.from select with no RPC. enabled-gated so the panel only
// queries when the drawer is open.
// ---------------------------------------------------------------------
export interface ShiftActivityRow {
  id: string;
  session_id: string | null;
  user_id: string;
  type: string;
  at: string;
  by: string | null;
  meta: Record<string, unknown> | null;
}
export function useUserShiftActivity(userId: string | undefined, enabled: boolean) {
  return useQuery<ShiftActivityRow[]>({
    queryKey: ['admin', 'user-activity', userId ?? '_'],
    enabled: enabled && !!userId,
    queryFn: async (): Promise<ShiftActivityRow[]> => {
      return await dbSelect<ShiftActivityRow>('shift_events', {
        select: 'id, session_id, user_id, type, at, by, meta',
        filters: { user_id: eq(userId!) },
        order: 'at.desc',
        limit: 200,
      });

    },
    refetchOnWindowFocus: false,
    staleTime: 0,
  });
}

// ---------------------------------------------------------------------
// useShiftBreakOverstayLock (0069) — manager-callable, idempotent. Fires
// when shift_tick reports overstay seconds >= grace AND status is still
// on_shift_break. Server atomically finalizes the freeze pause, ends
// the break, opens a fresh break_overstay pause, and flips status to
// 'locked' / locked_reason='break_overstay'. The work-timer freeze is
// continuous — no paid time leaks across overstay → lock.
// ---------------------------------------------------------------------
export function useShiftBreakOverstayLock() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async (sessionId: string) => {
      return await dbRpc<{
        session_id: string;
        status: ShiftStatus;
        locked: boolean;
        applied: boolean;
      }>('shift_break_overstay_lock', { p_session_id: sessionId });
    },
    onSuccess: () => {
      void qc.invalidateQueries({ queryKey: shiftKeys.all });
    },
  });
}

// ---------------------------------------------------------------------
// useShiftMark85Alerted — manager-callable; flips period_85_due to
// false for the current period so the toast never re-fires.
// ---------------------------------------------------------------------
export function useShiftMark85Alerted() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async (sessionId: string) => {
      return await dbRpc<{ session_id: string; already_alerted: boolean; period_index?: number }>('shift_mark_85_alerted', { p_session_id: sessionId });
    },
    onSuccess: () => {
      void qc.invalidateQueries({ queryKey: shiftKeys.all });
    },
  });
}

// ---------------------------------------------------------------------
// useShiftAdminSkipNextLock (0075) — admin-only. Arms the one-shot
// skip flag on a session: the NEXT shift_self_period_lock call for
// that session will NOT lock — it will consume the flag, advance
// current_period_index by 1, and log an admin_override
// 'period_lock_skipped' event. Idempotent: arming twice is fine.
// ---------------------------------------------------------------------
export function useShiftAdminSkipNextLock() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async (sessionId: string) => {
      return await dbRpc<{ session_id: string; skip_armed: boolean }>('shift_admin_skip_next_lock', {
        p_session_id: sessionId,
      });

    },
    onSuccess: () => {
      void qc.invalidateQueries({ queryKey: ['admin', 'shift-control'] });
      void qc.invalidateQueries({ queryKey: shiftKeys.all });
    },
  });
}

// ---------------------------------------------------------------------
// Admin-only shift RPCs (P4.7). Server-side is_admin() is the truth
// gate; the UI hides these buttons for non-admins as a UX layer.
// ---------------------------------------------------------------------
export function useShiftAdminLock() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async (args: { sessionId: string; reason: 'period_lock' | 'shift_complete' | 'admin' | 'bio_request' }) => {
      return await dbRpc<{ session_id: string; status: ShiftStatus }>('shift_admin_lock', {
        p_session_id: args.sessionId, p_reason: args.reason,
      });

    },
    onSuccess: () => {
      void qc.invalidateQueries({ queryKey: ['admin', 'shift-control'] });
      void qc.invalidateQueries({ queryKey: ['admin', 'locked-shifts'] });
    },
  });
}

export function useShiftAdminRearm() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async (sessionId: string) => {
      return await dbRpc<{ session_id: string; status: ShiftStatus }>('shift_admin_rearm', { p_session_id: sessionId });

    },
    onSuccess: () => {
      void qc.invalidateQueries({ queryKey: ['admin', 'shift-control'] });
    },
  });
}

export interface AdminSetConfigInput {
  target_user_id: string;
  mode: ShiftMode;
  shift_break_seconds: number;
  bio_break_max_per_day: number;
  bio_break_warn_count: number;
  bio_break_warn_total_seconds: number;
  bio_break_max_seconds_each: number;
  primary_group_id: string | null;
  // P4.5 — per-employee tz + late-start threshold (optional, defaults
  // apply if omitted).
  timezone?: string;
  late_start_threshold_seconds?: number;
}
export function useShiftAdminSetConfig() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async (input: AdminSetConfigInput) => {
      return await dbRpc<{ user_id: string; existed_before: boolean }>('shift_admin_set_config', {
        p_target_user_id:               input.target_user_id,
        p_mode:                         input.mode,
        p_shift_break_seconds:          input.shift_break_seconds,
        p_bio_break_max_per_day:        input.bio_break_max_per_day,
        p_bio_break_warn_count:         input.bio_break_warn_count,
        p_bio_break_warn_total_seconds: input.bio_break_warn_total_seconds,
        p_bio_break_max_seconds_each:   input.bio_break_max_seconds_each,
        p_primary_group_id:             input.primary_group_id,
        p_timezone:                     input.timezone ?? 'Asia/Manila',
        p_late_start_threshold_seconds: input.late_start_threshold_seconds ?? 900,
      });

    },
    onSuccess: () => {
      void qc.invalidateQueries({ queryKey: ['admin', 'shift-control'] });
    },
  });
}

export function useShiftAdminSetSchedule() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async (input: {
      target_user_id: string; weekday: number; enabled: boolean; required_seconds: number;
      // P4.5 — per-day start of work in employee's local tz, e.g. "10:00:00". Null = no start window.
      start_time_local?: string | null;
    }) => {
      return await dbRpc<{ user_id: string; weekday: number; changed: boolean }>('shift_admin_set_schedule', {
        p_target_user_id:   input.target_user_id,
        p_weekday:          input.weekday,
        p_enabled:          input.enabled,
        p_required_seconds: input.required_seconds,
        p_start_time_local: input.start_time_local ?? null,
      });

    },
    onSuccess: () => {
      void qc.invalidateQueries({ queryKey: ['admin', 'shift-control'] });
    },
  });
}

// P4.5 — admin force-end (marks session completed at now() regardless
// of elapsed). Triggers early_end_flag if before expected_end_at.
export function useShiftAdminForceEnd() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async (sessionId: string) => {
      return await dbRpc<{
        session_id: string;
        completed?: boolean;
        already_completed?: boolean;
        worked_seconds?: number;
        from_status?: string;
        early_end_flag?: boolean;
        early_end_minutes?: number | null;
      }>('shift_admin_force_end', { p_session_id: sessionId });

    },
    onSuccess: () => {
      void qc.invalidateQueries({ queryKey: ['admin', 'shift-control'] });
      void qc.invalidateQueries({ queryKey: shiftKeys.all });
    },
  });
}

// ---------------------------------------------------------------------
// 0077 — Global "Pause all automatic locks" master switch. Read via
// shift_admin_get_global_settings (admin only), written via
// shift_admin_set_locks_paused. The server gates 85% warnings + auto
// period-locks inside shift_tick / shift_self_period_lock when paused.
// ---------------------------------------------------------------------
export interface ShiftGlobalSettings {
  locks_paused: boolean;
  locks_paused_at: string | null;
  locks_paused_by: string | null;
}
export function useShiftGlobalSettings(enabled: boolean) {
  return useQuery<ShiftGlobalSettings>({
    queryKey: ['admin', 'shift-global-settings'],
    enabled,
    refetchInterval: 10_000,
    queryFn: async () => {
      return await dbRpc<ShiftGlobalSettings>('shift_admin_get_global_settings', {});
    },
  });

}
export function useShiftAdminSetLocksPaused() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async (paused: boolean) => {
      return await dbRpc<{ locks_paused: boolean; was: boolean | null; sessions_advanced_on_resume: number; at: string }>('shift_admin_set_locks_paused', { p_paused: paused });

    },
    onSuccess: () => {
      void qc.invalidateQueries({ queryKey: ['admin', 'shift-global-settings'] });
      void qc.invalidateQueries({ queryKey: ['admin', 'shift-control'] });
    },
  });
}

// ---------------------------------------------------------------------
// useAdminShiftControl — the unified per-manager view that powers the
// /admin → Shift Control panel. Returns one row per active manager
// joining users + shift_configs + today's shift_sessions + primary
// group name. Polled every 10s so live status (active / locked /
// break / completed) stays current. Admin RLS already grants SELECT
// on all three tables to is_admin().
// ---------------------------------------------------------------------
export interface AdminShiftRow {
  user_id: string;
  full_name: string | null;
  username: string;
  email: string;
  // Config (may be null if config row missing — rare; will create on
  // first save).
  mode: ShiftMode | null;
  shift_break_seconds: number | null;
  bio_break_max_per_day: number | null;
  bio_break_warn_count: number | null;
  bio_break_warn_total_seconds: number | null;
  bio_break_max_seconds_each: number | null;
  primary_group_id: string | null;
  primary_group_name: string | null;
  // P4.5 — per-employee tz + late-start threshold (config-level)
  timezone: string | null;
  late_start_threshold_seconds: number | null;
  // P-AccountLock (0064) — account-level admin lock. Independent of any
  // session: stays true even with no session row today. The admin
  // toggle keys off this field, never off session_id.
  account_locked: boolean;
  account_locked_at: string | null;
  // 11/12-a — auto vs manual shift mode. Manual = no timer/gate/auto-lock.
  shift_mode: 'auto' | 'manual' | null;
  // Admin override — when true, shift_can_start() bypasses scheduled-time
  // gates so the user can start a shift any time of day. Persists until
  // an admin flips it back.
  can_work_now: boolean;

  // Today's session (may be null if not_started not yet created).
  session_id: string | null;
  status: ShiftStatus | null;
  session_required_seconds: number | null;
  session_started_at: string | null;
  session_paused_total_seconds: number | null;
  session_current_pause_started_at: string | null;
  session_current_break_started_at: string | null;
  session_current_pause_reason: string | null;
  session_locked_reason: string | null;
  session_bio_break_count_today: number | null;
  shift_break_count_today: number | null;
  // P4.5 — flags on today's session
  late_start_flag: boolean | null;
  late_start_minutes: number | null;
  early_end_flag: boolean | null;
  early_end_minutes: number | null;
  scheduled_start_at: string | null;
  expected_end_at: string | null;
  // 0075 — one-shot admin-armed skip flag for the NEXT period lock.
  skip_next_period_lock: boolean;
  // Period boundary fields needed to compute the next auto-lock moment
  // client-side (mirrors shift_tick's period_end_seconds formula).
  session_period_seconds: number | null;
  session_current_period_index: number | null;
  // 0078 — per-day admin time adjustment in seconds (+ or -).
  session_admin_adjust_seconds: number | null;
}
export function useAdminShiftControl(enabled: boolean) {
  useEnabledDiag('useAdminShiftControl', enabled);
  return useQuery<AdminShiftRow[]>({
    queryKey: ['admin', 'shift-control'],
    enabled,
    queryFn: async () => {
      const todayUTC = new Date().toISOString().slice(0, 10);
      type UserRow = { id: string; full_name: string | null; username: string; email: string; role: string; status: string; is_super_admin: boolean };
      type CfgRow = { user_id: string; mode: ShiftMode; shift_mode: 'auto' | 'manual' | null; shift_break_seconds: number;
        bio_break_max_per_day: number; bio_break_warn_count: number;
        bio_break_warn_total_seconds: number; bio_break_max_seconds_each: number;
        primary_group_id: string | null; timezone: string;
        late_start_threshold_seconds: number;
        account_locked: boolean; account_locked_at: string | null;
        can_work_now: boolean };
      type SessRow = { id: string; user_id: string; status: ShiftStatus; required_seconds: number;
        started_at: string | null; paused_total_seconds: number;
        current_pause_started_at: string | null; current_break_started_at: string | null;
        current_pause_reason: string | null; locked_reason: string | null;
        bio_break_count_today: number;
        shift_break_count_today: number;
        late_start_flag: boolean | null; late_start_minutes: number | null;
        early_end_flag: boolean | null; early_end_minutes: number | null;
        scheduled_start_at: string | null; expected_end_at: string | null;
        skip_next_period_lock: boolean;
        period_seconds: number | null; current_period_index: number | null;
        admin_adjust_seconds: number | null };
      // Three small parallel queries — RLS lets admins read everything.
      const [usersData, cfgData, sessData] = await Promise.all([
        dbSelect<UserRow>('users', {
          select: 'id, full_name, username, email, role, status, is_super_admin',
          filters: { role: eq('manager'), status: eq('active'), is_super_admin: eq(false) },
        }),
        dbSelect<CfgRow>('shift_configs', {
          select: 'user_id, mode, shift_mode, shift_break_seconds, bio_break_max_per_day, bio_break_warn_count, bio_break_warn_total_seconds, bio_break_max_seconds_each, primary_group_id, timezone, late_start_threshold_seconds, account_locked, account_locked_at, can_work_now',
        }),
        dbSelect<SessRow>('shift_sessions', {
          select: 'id, user_id, status, required_seconds, started_at, paused_total_seconds, current_pause_started_at, current_break_started_at, current_pause_reason, locked_reason, bio_break_count_today, shift_break_count_today, late_start_flag, late_start_minutes, early_end_flag, early_end_minutes, scheduled_start_at, expected_end_at, skip_next_period_lock, period_seconds, current_period_index, admin_adjust_seconds',
          filters: { work_date: eq(todayUTC) },
        }),
      ]);

      const cfgByUser  = new Map<string, CfgRow>(cfgData.map((r) => [r.user_id, r]));
      const sessByUser = new Map<string, SessRow>(sessData.map((r) => [r.user_id, r]));

      // Collect primary_group_ids → fetch group names in one go.
      const groupIds = Array.from(new Set(
        cfgData.map((c) => c.primary_group_id).filter(Boolean) as string[]
      ));
      let groupNames = new Map<string, string>();
      if (groupIds.length > 0) {
        const groups = await dbSelect<{ id: string; name: string }>('groups', {
          select: 'id, name',
          filters: { id: inSet(groupIds) },
        });
        groupNames = new Map(groups.map((g) => [g.id, g.name]));
      }

      return usersData.map((u) => {
        const cfg = cfgByUser.get(u.id);
        const s   = sessByUser.get(u.id);
        return {
          user_id: u.id,
          full_name: u.full_name ?? null,
          username: u.username,
          email: u.email,

          mode:                         cfg?.mode                          ?? null,
          shift_break_seconds:          cfg?.shift_break_seconds           ?? null,
          bio_break_max_per_day:        cfg?.bio_break_max_per_day         ?? null,
          bio_break_warn_count:         cfg?.bio_break_warn_count          ?? null,
          bio_break_warn_total_seconds: cfg?.bio_break_warn_total_seconds  ?? null,
          bio_break_max_seconds_each:   cfg?.bio_break_max_seconds_each    ?? null,
          primary_group_id:             cfg?.primary_group_id              ?? null,
          primary_group_name:           cfg?.primary_group_id ? (groupNames.get(cfg.primary_group_id) ?? null) : null,
          timezone:                     cfg?.timezone                      ?? null,
          late_start_threshold_seconds: cfg?.late_start_threshold_seconds  ?? null,
          account_locked:               cfg?.account_locked                ?? false,
          account_locked_at:            cfg?.account_locked_at             ?? null,
          shift_mode:                   (cfg?.shift_mode as 'auto' | 'manual' | null | undefined) ?? null,
          can_work_now:                 cfg?.can_work_now                  ?? false,

          session_id:                       s?.id                          ?? null,
          status:                           s?.status                      ?? null,
          session_required_seconds:         s?.required_seconds            ?? null,
          session_started_at:               s?.started_at                  ?? null,
          session_paused_total_seconds:     s?.paused_total_seconds        ?? null,
          session_current_pause_started_at: s?.current_pause_started_at    ?? null,
          session_current_break_started_at: s?.current_break_started_at    ?? null,
          session_current_pause_reason:     s?.current_pause_reason        ?? null,
          session_locked_reason:            s?.locked_reason               ?? null,
          session_bio_break_count_today:    s?.bio_break_count_today       ?? null,
          shift_break_count_today:          s?.shift_break_count_today     ?? null,
          late_start_flag:                  s?.late_start_flag             ?? null,
          late_start_minutes:               s?.late_start_minutes          ?? null,
          early_end_flag:                   s?.early_end_flag              ?? null,
          early_end_minutes:                s?.early_end_minutes           ?? null,
          scheduled_start_at:               s?.scheduled_start_at          ?? null,
          expected_end_at:                  s?.expected_end_at             ?? null,
          skip_next_period_lock:            s?.skip_next_period_lock       ?? false,
          session_period_seconds:           s?.period_seconds              ?? null,
          session_current_period_index:     s?.current_period_index        ?? null,
          session_admin_adjust_seconds:     s?.admin_adjust_seconds        ?? null,
        };
      }).sort((a, b) => (a.full_name ?? a.username).localeCompare(b.full_name ?? b.username));
    },
    refetchInterval: 10_000,
    refetchOnWindowFocus: false,
    staleTime: 0,
  });
}

// ---------------------------------------------------------------------
// useAdminShiftSchedules — load all shift_schedules rows for ONE user
// (admin opens the edit modal). 7 rows expected; sorted weekday 0→6.
// ---------------------------------------------------------------------
export interface AdminScheduleRow {
  user_id: string; weekday: number; enabled: boolean; required_seconds: number;
  start_time_local: string | null;  // "HH:MM:SS" or null
  end_time_local:   string | null;  // P4a — "HH:MM:SS" or null
}
export function useAdminShiftSchedules(userId: string | undefined, enabled: boolean) {
  return useQuery<AdminScheduleRow[]>({
    queryKey: userId ? ['admin', 'shift-schedules', userId] : ['admin', 'shift-schedules', '_'],
    enabled: enabled && !!userId,
    queryFn: async () => {
      return await dbSelect<AdminScheduleRow>('shift_schedules', {
        select: 'user_id, weekday, enabled, required_seconds, start_time_local, end_time_local',
        filters: { user_id: eq(userId!) },
        order: 'weekday.asc',
      });

    },
    staleTime: 0,
    refetchOnWindowFocus: false,
  });
}

// P4b — bulk schedule writer (full 7-day replace) via the
// shift_admin_set_schedule_bulk RPC. Server validates each row and
// upserts in a single transaction.
export interface BulkScheduleRow {
  weekday: number;            // 0..6 (Sun..Sat)
  enabled: boolean;
  required_seconds: number;   // 0 when disabled, else (end - start) in seconds
  start_time_local: string | null;  // "HH:MM:SS" or null
  end_time_local:   string | null;  // "HH:MM:SS" or null
}
export function useShiftAdminSetScheduleBulk() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async (input: { target_user_id: string; rows: BulkScheduleRow[] }) => {
      return await dbRpc<{ ok: boolean; rows_written: number; rows: unknown }>('shift_admin_set_schedule_bulk', {
        p_user_id: input.target_user_id,
        p_rows:    input.rows as unknown as object,
      });

    },
    onSuccess: (_d, vars) => {
      void qc.invalidateQueries({ queryKey: ['admin', 'shift-schedules', vars.target_user_id] });
      void qc.invalidateQueries({ queryKey: ['admin', 'shift-control'] });
    },
  });
}

// P4b — set (or clear) shift_configs.shift_start_date for one user.
// Used by 4c gating to refuse shift_start before that date.
export function useShiftAdminSetStartDate() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async (input: { target_user_id: string; start_date: string | null }) => {
      return await dbRpc<{ ok: boolean; user_id: string; shift_start_date: string | null }>('shift_admin_set_start_date', {
        p_user_id:    input.target_user_id,
        p_start_date: input.start_date,
      });

    },
    onSuccess: (_d, vars) => {
      void qc.invalidateQueries({ queryKey: ['admin', 'shift-control'] });
      void qc.invalidateQueries({ queryKey: ['admin', 'shift-start-date', vars.target_user_id] });
    },
  });
}

// P4b — read current shift_start_date for one user (schedule modal).
export function useUserShiftStartDate(userId: string | undefined, enabled: boolean) {
  return useQuery<string | null>({
    queryKey: userId ? ['admin', 'shift-start-date', userId] : ['admin', 'shift-start-date', '_'],
    enabled: enabled && !!userId,
    queryFn: async () => {
      const row = await dbSelectMaybeSingle<{ shift_start_date: string | null }>('shift_configs', {
        select: 'shift_start_date',
        filters: { user_id: eq(userId!) },
      });
      return row?.shift_start_date ?? null;

    },
    staleTime: 0,
    refetchOnWindowFocus: false,
  });
}

// ---------------------------------------------------------------------
// useUserVisibleGroups — for the admin edit modal's primary-group
// dropdown. Returns the groups a given user has been granted via
// group_user_visibility (Phase 3 ACL). Admin RLS lets is_admin() read
// every row.
// ---------------------------------------------------------------------
export interface VisibleGroupRow { id: string; name: string; color: string; board_id: string; board_name: string; }
export function useUserVisibleGroups(userId: string | undefined, enabled: boolean) {
  return useQuery<VisibleGroupRow[]>({
    queryKey: userId ? ['admin', 'user-visible-groups', userId] : ['admin', 'user-visible-groups', '_'],
    enabled: enabled && !!userId,
    queryFn: async () => {
      // Step 1: which groups can this user see?
      const acl = await dbSelect<{ group_id: string }>('group_user_visibility', {
        select: 'group_id',
        filters: { user_id: eq(userId!) },
      });
      const ids = acl.map((r) => r.group_id);
      if (ids.length === 0) return [];
      // Step 2: group details + board name
      const groups = await dbSelect<{ id: string; name: string; color: string; board_id: string; deleted_at: string | null }>('groups', {
        select: 'id, name, color, board_id, deleted_at',
        filters: { id: inSet(ids) },
      });
      const aliveGroups = groups.filter((g) => !g.deleted_at);
      if (aliveGroups.length === 0) return [];
      const boardIds = Array.from(new Set(aliveGroups.map((g) => g.board_id)));
      const boards = await dbSelect<{ id: string; name: string }>('boards', {
        select: 'id, name',
        filters: { id: inSet(boardIds) },
      });
      const boardName = new Map(boards.map((b) => [b.id, b.name]));
      return aliveGroups.map((g) => ({
        id: g.id,
        name: g.name,
        color: g.color,
        board_id: g.board_id,
        board_name: boardName.get(g.board_id) ?? '?',
      })).sort((a, b) => a.board_name.localeCompare(b.board_name) || a.name.localeCompare(b.name));

    },
    staleTime: 60_000,
    refetchOnWindowFocus: false,
  });
}

export function useShiftAdminUnlock() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async (sessionId: string) => {
      return await dbRpc<{ session_id: string; status: ShiftStatus; lock_wait_seconds: number }>('shift_admin_unlock', { p_session_id: sessionId });

    },
    onSuccess: () => {
      void qc.invalidateQueries({ queryKey: shiftKeys.all });
      // Also kick the admin's locked-shifts list so the row disappears.
      void qc.invalidateQueries({ queryKey: ['admin', 'locked-shifts'] });
      // And the unified Shift Control panel so the toggle's reconcile
      // effect picks up the fresh row promptly (no up-to-10s lag).
      void qc.invalidateQueries({ queryKey: ['admin', 'shift-control'] });
    },
  });
}

// ---------------------------------------------------------------------
// useShiftAdminSetAccountLock — account-level admin lock (0064).
//
// Independent of any session: the toggle works even when the target
// manager has no shift_sessions row today. Server-side, the RPC upserts
// shift_configs and audits via 'admin_override' + meta.action.
// ---------------------------------------------------------------------
export function useShiftAdminSetAccountLock() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async (args: { targetUserId: string; locked: boolean }) => {
      return await dbRpc<{
        user_id: string;
        account_locked: boolean;
        account_locked_at: string | null;
        account_locked_by: string | null;
      }>('shift_admin_set_account_lock', {
        p_target_user_id: args.targetUserId,
        p_locked:         args.locked,
      });

    },
    onSuccess: () => {
      // Refresh the admin panel so the toggle's persisted state lands
      // and any other manager-row consumer (future widgets) catches up.
      void qc.invalidateQueries({ queryKey: ['admin', 'shift-control'] });
    },
  });
}

// ---------------------------------------------------------------------
// useShiftAdminSetCanWorkNow — per-user admin override that bypasses
// the scheduled-time gate in shift_can_start() (before_start_date,
// day_off, before_shift_time, after_shift_end). When TRUE, the user
// can start a shift any time of day. Persists until an admin flips it.
// ---------------------------------------------------------------------
export function useShiftAdminSetCanWorkNow() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async (args: { targetUserId: string; canWorkNow: boolean }) => {
      return await dbRpc<{ user_id: string; can_work_now: boolean }>(
        'shift_admin_set_can_work_now',
        { p_target_user_id: args.targetUserId, p_can: args.canWorkNow },
      );
    },
    onSuccess: () => {
      void qc.invalidateQueries({ queryKey: ['admin', 'shift-control'] });
    },
  });
}


// ---------------------------------------------------------------------
// 0078 — useShiftAdminAdjustTime — admin per-day time adjustment.
// Positive delta = add owed time (remaining grows). Negative = credit.
// Original accounting fields are never mutated; the delta is stored in
// shift_sessions.admin_adjust_seconds and applied in remaining math
// (shift_tick + shift_complete_if_due + admin panel formula).
// ---------------------------------------------------------------------
export function useShiftAdminAdjustTime() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async (args: { targetUserId: string; deltaSeconds: number; note?: string | null }) => {
      return await dbRpc<{
        session_id: string;
        user_id: string;
        delta_seconds: number;
        old_adjust_seconds: number;
        new_adjust_seconds: number;
        required_seconds: number;
        effective_required: number;
      }>('shift_admin_adjust_time', {
        p_target_user_id: args.targetUserId,
        p_delta_seconds:  args.deltaSeconds,
        p_note:           args.note ?? null,
      });

    },
    onSuccess: () => {
      void qc.invalidateQueries({ queryKey: ['admin', 'shift-control'] });
      void qc.invalidateQueries({ queryKey: shiftKeys.all });
    },
  });
}

// ---------------------------------------------------------------------
// useShiftAdminSetShiftMode (11/12-c) — admin-only. Flips a user
// between Auto and Manual. Server seeds a default Mon-Fri 09:00-17:00
// (+ Sat half-day, Sun off) when switching TO Auto for a user with no
// existing shift_schedules rows. Switching TO Manual preserves the
// schedule (manual mode ignores it).
// ---------------------------------------------------------------------
export function useShiftAdminSetShiftMode() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async (args: { targetUserId: string; mode: 'auto' | 'manual' }) => {
      return await dbRpc<{ ok: boolean; user_id: string; shift_mode: 'auto' | 'manual'; seeded_default_schedule: boolean }>('shift_admin_set_shift_mode', {
        p_user_id: args.targetUserId,
        p_mode:    args.mode,
      });

    },
    onSuccess: () => {
      void qc.invalidateQueries({ queryKey: ['admin', 'shift-control'] });
    },
  });
}



// ---------------------------------------------------------------------
// useMyAccountLock — candidate-side poll of the calling user's own
// account-lock flag (0064). Self-only RPC: a non-admin user can call
// it for themselves; an admin checks their own as well. Polls every
// 30s so a freshly-applied admin lock kicks in within the window.
// Returns { account_locked, account_locked_at }.
// ---------------------------------------------------------------------
export interface MyAccountLock { account_locked: boolean; account_locked_at: string | null; account_lock_reason: string | null }
export function useMyAccountLock(enabled: boolean) {
  return useQuery<MyAccountLock>({
    queryKey: ['shift', 'my-account-lock'],
    enabled,
    queryFn: async () => {
      const data = await dbRpc<Partial<MyAccountLock>>('shift_my_account_lock', {});
      const obj = (data ?? {}) as Partial<MyAccountLock>;
      return {
        account_locked:      obj.account_locked ?? false,
        account_locked_at:   obj.account_locked_at ?? null,
        account_lock_reason: obj.account_lock_reason ?? null,
      };
    },
    // 0078 — realtime push (useMyAccountLockRealtime, below) is the
    // primary path for instant admin-Stop. This poll is now a slow
    // safety backstop in case the realtime channel drops or never
    // connects (cold tab, transient network). 2 min keeps daily
    // request volume tiny while still self-healing.
    refetchInterval: 120_000,
    refetchOnWindowFocus: false,
    staleTime: 0,
  });
}

// ---------------------------------------------------------------------
// useMyAccountLockRealtime — instant push for admin Stop / unlock.
//
// Subscribes to UPDATEs on the calling user's OWN row in
// public.shift_configs (filtered server-side by user_id=eq.<uid>) using
// the same .channel(...).on('postgres_changes', ...).subscribe()
// pattern already used in src/lib/boardSync.ts and LilyChat.tsx — no
// second Supabase client, no new pattern. On any change to the row we
// invalidate the my-account-lock query; the existing useMyAccountLock
// then re-fetches via the small shift_my_account_lock RPC and the
// AccountLockedOverlay flips within ~1s instead of waiting for the
// 2-min backstop poll. Mounted once at app shell level.
// ---------------------------------------------------------------------
export function useMyAccountLockRealtime(enabled: boolean): void {
  const userId = useAuthStore((s) => s.profile?.id);
  const qc = useQueryClient();
  useEffect(() => {
    if (!enabled || !userId) return;
    const channel = supabase
      .channel(`my-account-lock:${userId}`)
      .on(
        'postgres_changes',
        {
          event: 'UPDATE',
          schema: 'public',
          table: 'shift_configs',
          filter: `user_id=eq.${userId}`,
        },
        () => {
          void qc.invalidateQueries({ queryKey: ['shift', 'my-account-lock'] });
        },
      )
      .subscribe();
    return () => {
      void supabase.removeChannel(channel);
    };
  }, [enabled, userId, qc]);
}

// ---------------------------------------------------------------------
// useShiftGateActive — single source of truth for "is the employee
// currently behind a full-screen shift gate?". Mirrors EXACTLY the
// branches in ShiftDriver (account-locked overlay, StartShiftGate,
// ShiftLockedOverlay, ShiftCompletedOverlay). Anything that needs to
// hide alongside the lock overlay (e.g. the Lily chat widget) should
// read this rather than re-deriving the condition.
//
// Returns false while data is still loading so we never flash a hidden
// state on cold mount.
// ---------------------------------------------------------------------
export function useShiftGateActive(): boolean {
  const { data: session } = useTodayShiftSession(true);
  const { data: accountLock } = useMyAccountLock(true);
  const sessionId = session?.id;
  const tickEnabled = !!sessionId && session?.status !== 'not_started';
  const { data: tick } = useShiftTick(sessionId, tickEnabled);
  if (accountLock?.account_locked) return true;
  if (!session) return false;
  const liveStatus = tick?.status ?? session.status;
  return liveStatus === 'not_started'
      || liveStatus === 'locked'
      || liveStatus === 'completed';
}

// ---------------------------------------------------------------------
// useLockedShifts — admin Locked-Shifts queue. Polls every 10s so new
// locks land within the polling window. Filtered server-side to
// status='locked' (admin RLS lets is_admin() read all shift_sessions).
// ---------------------------------------------------------------------
export interface LockedShiftRow {
  id: string;
  user_id: string;
  locked_at: string;
  locked_reason: string;
  locked_by: string | null;
  full_name: string | null;
  username: string;
}
export function useLockedShifts(enabled: boolean) {
  return useQuery<LockedShiftRow[]>({
    queryKey: ['admin', 'locked-shifts'],
    enabled,
    queryFn: async () => {
      // Two-step: shift_sessions + users for the display name. Cheap
      // (locked shifts at any moment are rare).
      type SessLockedRow = Pick<LockedShiftRow,'id'|'user_id'|'locked_at'|'locked_reason'|'locked_by'>;
      const list = await dbSelect<SessLockedRow>('shift_sessions', {
        select: 'id, user_id, locked_at, locked_reason, locked_by',
        filters: { status: eq('locked') },
        order: 'locked_at.asc',
      });
      if (list.length === 0) return [];
      const userIds = Array.from(new Set(list.map(r => r.user_id)));
      const users = await dbSelect<{ id: string; username: string; full_name: string | null }>('users', {
        select: 'id, username, full_name',
        filters: { id: inSet(userIds) },
      });
      const byId = new Map(users.map(u => [u.id, u]));
      return list.map(r => ({
        ...r,
        full_name: byId.get(r.user_id)?.full_name ?? null,
        username:  byId.get(r.user_id)?.username  ?? '?',
      }));

    },
    refetchInterval: 10_000,
    refetchOnWindowFocus: false,
    staleTime: 0,
  });
}

// ---------------------------------------------------------------------
// P4.4 — break RPCs.  All three take session_id (post-0060). The RPCs
// enforce self-or-admin; the UI only exposes them to managers.
// ---------------------------------------------------------------------
export function useShiftTakeShiftBreak() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async (sessionId: string) => {
      return await dbRpc<{ session_id: string; status: ShiftStatus }>('shift_take_shift_break', { p_session_id: sessionId });
    },
    onSuccess: () => { void qc.invalidateQueries({ queryKey: shiftKeys.all }); },
  });
}

export function useShiftTakeBioBreak() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async (sessionId: string) => {
      return await dbRpc<{
        session_id: string; status: ShiftStatus;
        needs_request: boolean;
        count_today?: number; max_per_day?: number; admin_grants_today?: number;
      }>('shift_take_bio_break', { p_session_id: sessionId });
    },
    onSuccess: () => { void qc.invalidateQueries({ queryKey: shiftKeys.all }); },
  });
}

export function useShiftEndBreak() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async (sessionId: string) => {
      return await dbRpc<{
        session_id: string; status: ShiftStatus;
        kind: 'shift' | 'bio' | null;
        duration_seconds_actual: number;
        duration_seconds_recorded: number;
        exceeded_cap: boolean;
      }>('shift_end_break', { p_session_id: sessionId });
    },
    onSuccess: () => { void qc.invalidateQueries({ queryKey: shiftKeys.all }); },
  });
}

// ---------------------------------------------------------------------
// Bio break request lifecycle (manager creates, admin decides).
// ---------------------------------------------------------------------
export function useBioBreakRequestCreate() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async () => {
      return await dbRpc<{ request_id: string; status: 'pending' }>('bio_break_request_create', {});

    },
    onSuccess: () => {
      void qc.invalidateQueries({ queryKey: shiftKeys.all });
      void qc.invalidateQueries({ queryKey: ['admin', 'bio-requests'] });
    },
  });
}

export function useBioBreakRequestDecide() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async (args: { requestId: string; decision: 'approved' | 'denied'; note?: string | null }) => {
      return await dbRpc<{ request_id: string; status: 'approved' | 'denied' }>('bio_break_request_decide', {
        p_request_id: args.requestId,
        p_decision:   args.decision,
        p_note:       args.note ?? null,
      });

    },
    onSuccess: () => {
      void qc.invalidateQueries({ queryKey: ['admin', 'bio-requests'] });
      void qc.invalidateQueries({ queryKey: ['admin', 'shift-control'] });
      void qc.invalidateQueries({ queryKey: shiftKeys.all });
    },
  });
}

// ---------------------------------------------------------------------
// Admin pending bio-break requests queue.
// ---------------------------------------------------------------------
export interface BioBreakRequestRow {
  id: string;
  session_id: string;
  user_id: string;
  requested_at: string;
  full_name: string | null;
  username: string;
}
export function useBioBreakPending(enabled: boolean) {
  return useQuery<BioBreakRequestRow[]>({
    queryKey: ['admin', 'bio-requests'],
    enabled,
    queryFn: async () => {
      type ReqRow = Pick<BioBreakRequestRow,'id'|'session_id'|'user_id'|'requested_at'>;
      const list = await dbSelect<ReqRow>('bio_break_requests', {
        select: 'id, session_id, user_id, requested_at',
        filters: { status: eq('pending') },
        order: 'requested_at.asc',
      });
      if (list.length === 0) return [];
      const userIds = Array.from(new Set(list.map((r) => r.user_id)));
      const users = await dbSelect<{ id: string; username: string; full_name: string | null }>('users', {
        select: 'id, username, full_name',
        filters: { id: inSet(userIds) },
      });
      const byId = new Map(users.map((u) => [u.id, u]));
      return list.map((r) => ({
        ...r,
        full_name: byId.get(r.user_id)?.full_name ?? null,
        username:  byId.get(r.user_id)?.username  ?? '?',
      }));

    },
    refetchInterval: 10_000,
    refetchOnWindowFocus: false,
    staleTime: 0,
  });
}

// ---------------------------------------------------------------------
// useShiftCompleteIfDue — P4.8. Self-or-admin RPC. Idempotent. Returns
// `already_completed` / `due` / `completed` flags so the caller can
// fire the bell + email only on the actual transition.
// ---------------------------------------------------------------------
export function useShiftCompleteIfDue() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async (sessionId: string) => {
      return await dbRpc<{
        session_id: string;
        already_completed: boolean;
        due?: boolean;
        completed?: boolean;
        worked_seconds?: number;
        from_status?: string;
        remaining_seconds?: number;
        elapsed_seconds?: number;
        reason?: string;
        completed_at?: string;
      }>('shift_complete_if_due', { p_session_id: sessionId });
    },
    onSuccess: () => {
      void qc.invalidateQueries({ queryKey: shiftKeys.all });
      void qc.invalidateQueries({ queryKey: ['admin', 'shift-control'] });
    },
  });
}

export function useShiftTick(sessionId: string | undefined, enabled: boolean) {
  useEnabledDiag('useShiftTick', enabled && !!sessionId);
  return useQuery<ShiftTickPayload>({
    queryKey: sessionId ? shiftKeys.tick(sessionId) : [...shiftKeys.all, 'tick', '_'],
    enabled: enabled && !!sessionId,
    queryFn: async () => {
      return await dbRpc<ShiftTickPayload>('shift_tick', { p_session_id: sessionId });
    },
    refetchInterval: 10_000,
    // We rely on the visibility warm-up + refresh-on-401 layer; no
    // refocus-driven storm of ticks needed.
    refetchOnWindowFocus: false,
    staleTime: 0,
  });
}

// ---------------------------------------------------------------------
// Phase 9a — KPI dashboard data hooks.
//
// Two pure-SELECT hooks (no new RPC, RLS-gated by the existing
// shift_sessions_select / shift_schedules_select policies which are
// already `is_admin() OR user_id = auth.uid()`).
//
//   useKpiData(fromISO, toISO):
//     all shift_sessions rows in [from, to] joined to users(id, full_name,
//     username, avatar_url, role). Polled every 60s; refetches on range
//     change via the queryKey.
//
//   useKpiSchedules():
//     all shift_schedules rows (small — ~7 rows per manager). Long
//     staleTime, no polling.
// ---------------------------------------------------------------------
export interface KpiSessionRow {
  session_id: string;
  user_id: string;
  work_date: string;
  status: ShiftStatus;
  started_at: string | null;
  completed_at: string | null;
  required_seconds: number;
  paused_total_seconds: number;
  late_start_flag: boolean;
  late_start_minutes: number;
  early_end_flag: boolean;
  early_end_minutes: number;
  bio_break_count_today: number;
  bio_break_total_seconds_today: number;
  shift_break_count_today: number;
  overstay_lock_email_sent_at: string | null;
  locked_reason: string | null;
  full_name: string | null;
  username: string;
  email: string | null;
  avatar_url: string | null;
  role: string;
}

export function useKpiData(fromISO: string, toISO: string, enabled = true) {
  return useQuery<KpiSessionRow[]>({
    queryKey: [...shiftKeys.all, 'kpi-data', fromISO, toISO],
    enabled: enabled && !!fromISO && !!toISO,
    queryFn: async () => {
      type Raw = Omit<KpiSessionRow, 'session_id' | 'full_name' | 'username' | 'email' | 'avatar_url' | 'role'> & {
        id: string;
        users: { full_name: string | null; username: string; email: string | null; avatar_url: string | null; role: string } | null;
      };
      const data = await dbSelect<Raw>('shift_sessions', {
        select:
          'id, user_id, work_date, status, started_at, completed_at, ' +
          'required_seconds, paused_total_seconds, ' +
          'late_start_flag, late_start_minutes, early_end_flag, early_end_minutes, ' +
          'bio_break_count_today, bio_break_total_seconds_today, shift_break_count_today, ' +
          'overstay_lock_email_sent_at, locked_reason, ' +
          'users:user_id ( full_name, username, email, avatar_url, role )',
        // Same column gets two filters (gte + lte) — PostgREST `and=(...)` syntax.
        filters: { and: `(work_date.gte.${fromISO},work_date.lte.${toISO})` },
        order: 'work_date.asc',
      });
      return data.map((r) => ({

        session_id: r.id,
        user_id: r.user_id,
        work_date: r.work_date,
        status: r.status,
        started_at: r.started_at,
        completed_at: r.completed_at,
        required_seconds: r.required_seconds,
        paused_total_seconds: r.paused_total_seconds,
        late_start_flag: r.late_start_flag,
        late_start_minutes: r.late_start_minutes,
        early_end_flag: r.early_end_flag,
        early_end_minutes: r.early_end_minutes,
        bio_break_count_today: r.bio_break_count_today,
        bio_break_total_seconds_today: r.bio_break_total_seconds_today,
        shift_break_count_today: r.shift_break_count_today,
        overstay_lock_email_sent_at: r.overstay_lock_email_sent_at,
        locked_reason: r.locked_reason,
        full_name: r.users?.full_name ?? null,
        username: r.users?.username ?? '?',
        email: r.users?.email ?? null,
        avatar_url: r.users?.avatar_url ?? null,
        role: r.users?.role ?? 'manager',
      }));
    },
    staleTime: 30_000,
    refetchInterval: 60_000,
    refetchOnWindowFocus: false,
  });
}

export interface KpiScheduleRow {
  user_id: string;
  weekday: number;            // 0..6 (Sun..Sat)
  enabled: boolean;
  start_time_local: string | null;
}

export function useKpiSchedules(enabled = true) {
  return useQuery<KpiScheduleRow[]>({
    queryKey: [...shiftKeys.all, 'kpi-schedules'],
    enabled,
    queryFn: async () => {
      return await dbSelect<KpiScheduleRow>('shift_schedules', {
        select: 'user_id, weekday, enabled, start_time_local',
      });

    },
    staleTime: 5 * 60_000,
    refetchOnWindowFocus: false,
  });
}
