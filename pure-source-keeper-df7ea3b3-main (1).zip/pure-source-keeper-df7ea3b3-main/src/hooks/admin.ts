/**
 * Phase 6 — admin user-management hooks.
 *
 * Every write goes through a SECURITY DEFINER Postgres function in
 * migration 0018, which runs the role + super-admin guards server-side.
 * The frontend never gets the service-role key or any raw passwords
 * back from these calls.
 */
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { dbRpc } from '@/lib/db';
import type { UserRole, UserStatus } from '@/lib/database.types';

export const adminKeys = {
  users: ['admin', 'users'] as const,
  secretsStatus: ['admin', 'secrets-status'] as const,
};

export interface AdminUserRow {
  id: string;
  username: string;
  full_name: string | null;
  avatar_url: string | null;
  role: UserRole;
  status: UserStatus;
  is_super_admin: boolean;
  title: string | null;
  timezone: string;
  created_at: string;
  last_active: string | null;
}

export function useAdminUsers() {
  return useQuery({
    queryKey: adminKeys.users,
    queryFn: async (): Promise<AdminUserRow[]> => {
      return (await dbRpc<AdminUserRow[]>('admin_list_users')) ?? [];
    },
    staleTime: 10_000,
  });
}

export function useAdminSecretsStatus() {
  return useQuery({
    queryKey: adminKeys.secretsStatus,
    queryFn: async (): Promise<{ configured: boolean }> => {
      return (await dbRpc<{ configured: boolean }>('get_admin_secrets_status')) ?? { configured: false };
    },
    staleTime: 60_000,
  });
}

export function useSetAdminSecrets() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async (args: { serviceRoleKey: string; supabaseUrl: string }) => {
      await dbRpc('set_admin_secrets', {
        p_key: args.serviceRoleKey,
        p_url: args.supabaseUrl,
      });
    },
    onSuccess: () => void qc.invalidateQueries({ queryKey: adminKeys.secretsStatus }),
  });
}

export function useAdminCreateUser() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async (args: {
      username: string;
      fullName: string;
      role: Exclude<UserRole, 'admin'>;
      password: string;
    }) => {
      await dbRpc('admin_create_user', {
        p_username: args.username,
        p_full_name: args.fullName,
        p_role: args.role,
        p_password: args.password,
      });
    },
    onSuccess: () => void qc.invalidateQueries({ queryKey: adminKeys.users }),
  });
}

export function useAdminResetPassword() {
  return useMutation({
    mutationFn: async (args: { userId: string; newPassword: string }) => {
      await dbRpc('admin_reset_password', {
        p_user_id: args.userId,
        p_new_password: args.newPassword,
      });
    },
  });
}

/**
 * Mark the latest teamblue backup-login event as rotated, which
 * suppresses the 72h chaser email. Additive: calls the admin-only
 * mark_teamblue_rotated() RPC (migration 0053). Does NOT touch the
 * password-reset flow.
 */
export function useMarkTeamblueRotated() {
  return useMutation({
    mutationFn: async (): Promise<boolean> => {
      // mark_teamblue_rotated() isn't in the hand-maintained Database
      // types yet — cast the name like the rest of this untyped client.
      return await dbRpc<boolean>('mark_teamblue_rotated');
    },
  });
}

export function useAdminSetRole() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async (args: { userId: string; role: UserRole }) => {
      await dbRpc('admin_set_role', {
        p_user_id: args.userId,
        p_role: args.role,
      });
    },
    onSuccess: () => void qc.invalidateQueries({ queryKey: adminKeys.users }),
  });
}

// Migration 0042 — admin renames a user's username. Validates the
// regex + uniqueness server-side. Does NOT touch the user's email or
// auth identity — they can still log in by email AND by the new
// username (resolve_login_email matches either branch).
export function useAdminSetUsername() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async (args: { userId: string; newUsername: string }) => {
      await dbRpc('admin_set_username', {
        p_user_id: args.userId,
        p_new_username: args.newUsername,
      });
    },
    onSuccess: () => void qc.invalidateQueries({ queryKey: adminKeys.users }),
  });
}

// Migration 0043 — permanent delete. Admin-only via is_admin(). The RPC
// also refuses self-delete, the last active admin, and any super admin.
// The user's CONTENT (boards, items, updates, views, files, invites
// they minted, AI runs, audit-log rows) survives with the author column
// set to NULL — per the DATA OWNERSHIP RULE (SET NULL never CASCADE on
// authorship FKs).
export function useAdminDeleteUser() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async (args: { userId: string }) => {
      await dbRpc('admin_delete_user', {
        p_user_id: args.userId,
      });
    },
    onSuccess: () => void qc.invalidateQueries({ queryKey: adminKeys.users }),
  });
}

export function useAdminSetStatus() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async (args: { userId: string; status: UserStatus }) => {
      await dbRpc('admin_set_status', {
        p_user_id: args.userId,
        p_status: args.status,
      });
    },
    onSuccess: () => void qc.invalidateQueries({ queryKey: adminKeys.users }),
  });
}
