/**
 * Phase 6.5 — Invite link hooks. Everything goes through SECURITY
 * DEFINER RPCs in migration 0020 so the role checks live server-side.
 *
 * `useInvitesForBoard` and `useCreateInvite` need an authenticated user
 * (admin / manager / board owner). `useInviteByToken` and
 * `useAcceptInvite` are public — they're called from the un-authed
 * /invite/{token} accept page.
 */
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { dbRpc, dbSelect, eq, isNull } from '@/lib/db';
import type { UserRole } from '@/lib/database.types';

export const inviteKeys = {
  all: ['invites'] as const,
  board: (boardId: string) => [...inviteKeys.all, 'board', boardId] as const,
  token: (token: string) => [...inviteKeys.all, 'token', token] as const,
};

export interface InviteRow {
  id: string;
  token: string;
  role: UserRole;
  board_id: string | null;
  created_by: string;
  created_at: string;
  // Migration 0037 allows null ⇒ "never expires".
  expires_at: string | null;
  used_at: string | null;
  used_by: string | null;
  revoked_at: string | null;
  // Migration 0040 — optional real email the admin emailed the invite
  // to (null when admin used "Generate invite link" without an email).
  invitee_email: string | null;
  // Migration 0076 — optional legal name captured at invite time.
  // accept_invite() prefers this over what the invitee types.
  invitee_name: string | null;
}

// ---------------------------------------------------------------------
// List all pending + recent invites for a specific board (board_id) or
// workspace-wide (boardId === null). RLS returns the rows the caller is
// allowed to see (admin / creator / board owner).
// ---------------------------------------------------------------------
export function useInvitesForBoard(boardId: string | null) {
  return useQuery({
    queryKey: boardId ? inviteKeys.board(boardId) : ['invites', 'workspace'],
    queryFn: async (): Promise<InviteRow[]> => {
      // Lock-free fast path: direct PostgREST via src/lib/db.ts. Avoids
      // supabase-js's per-request getSession → tabLocalAuthLock funnel
      // that was wedging this query behind the invite RPC.
      const rows = await dbSelect<InviteRow>('invites', {
        select: '*',
        filters: { board_id: boardId ? eq(boardId) : isNull },
        order: 'created_at.desc',
      });
      return rows;
    },
    staleTime: 10_000,
  });
}

export function useCreateInvite() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async (args: {
      role: UserRole;
      boardId: string | null;
      groupId?: string | null;
      // null  ⇒ never expires (migration 0037)
      // undef ⇒ default of 7 days
      // number ⇒ explicit hours (1..720)
      expiresInHours?: number | null;
      // Optional. Stored on the invite row via migration 0040's
      // p_invitee_email arg. When present, accept_invite() uses this
      // as the new account's real email instead of the synthetic
      // username@pms.internal. Pass undefined/null to keep the
      // legacy synthetic-email behaviour (e.g. "Generate link" flow).
      inviteeEmail?: string | null;
      // Optional. Stored on the invite row via migration 0076's
      // p_invitee_name arg. When present, accept_invite() uses this
      // as the new account's full_name (admin-entered legal name
      // takes precedence over what the invitee types).
      inviteeName?: string | null;
      // Phase 11/12-b — invite-time shift mode + schedule. All
      // optional; when shiftMode='auto', the schedule fields seed
      // the new user's shift_configs + shift_schedules at accept.
      inviteeShiftMode?: 'auto' | 'manual' | null;
      inviteeShiftStartDate?: string | null; // YYYY-MM-DD
      inviteeShiftStartTime?: string | null; // HH:MM[:SS]
      inviteeShiftEndTime?: string | null;   // HH:MM[:SS]
      inviteeTimezone?: string | null;
    }): Promise<{ id: string; token: string; role: UserRole; board_id: string | null; group_id: string | null; expires_at: string | null; invitee_email: string | null; invitee_name: string | null }> => {
      // Lock-free fast path via src/lib/db.ts dbRpc — synchronous
      // getCachedAccessToken + direct timeoutFetch to PostgREST /rpc/.
      // Bypasses supabase-js's getSession → tabLocalAuthLock funnel
      // that was queueing this call indefinitely. Token expiry is still
      // handled by timeoutFetch's 401-retry path.
      type CreateInviteRow = { id: string; token: string; role: UserRole; board_id: string | null; group_id: string | null; expires_at: string | null; invitee_email: string | null; invitee_name: string | null };
      const rpcPromise = dbRpc<CreateInviteRow>('create_invite', {
        p_role: args.role,
        p_board_id: args.boardId,
        // Pass the value as-is when explicitly null — RPC treats null as
        // "never expires". Only fall back to 168 when undefined.
        p_expires_in_hours: args.expiresInHours === undefined ? 168 : args.expiresInHours,
        p_group_id: args.groupId ?? null,
        p_invitee_email: args.inviteeEmail ?? null,
        p_invitee_name: args.inviteeName ?? null,
        p_invitee_shift_mode: args.inviteeShiftMode ?? null,
        p_invitee_shift_start_date: args.inviteeShiftStartDate ?? null,
        p_invitee_shift_start_time: args.inviteeShiftStartTime ?? null,
        p_invitee_shift_end_time: args.inviteeShiftEndTime ?? null,
        p_invitee_timezone: args.inviteeTimezone ?? null,
      });
      // Belt-and-suspenders 10s race kept exactly as before — even
      // though the lock funnel is gone, this guarantees the UI's
      // finally block always runs.
      const data = await Promise.race([
        rpcPromise,
        new Promise<never>((_, reject) =>
          setTimeout(() => reject(new Error('Server is busy — please try again')), 10_000),
        ),
      ]);
      return data;
    },

    onSuccess: (_d, vars) => {
      void qc.invalidateQueries({
        queryKey: vars.boardId ? inviteKeys.board(vars.boardId) : ['invites', 'workspace'],
      });
    },
  });
}

export function useRevokeInvite() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async (args: { id: string; boardId: string | null }) => {
      await dbRpc('revoke_invite', { p_invite_id: args.id });
    },
    onSuccess: (_d, vars) => {
      void qc.invalidateQueries({
        queryKey: vars.boardId ? inviteKeys.board(vars.boardId) : ['invites', 'workspace'],
      });
    },
  });
}

// ---------------------------------------------------------------------
// Anon-safe: used on the accept page before any user exists.
// ---------------------------------------------------------------------
export interface InviteCheckResult {
  valid: boolean;
  reason?: 'not_found' | 'expired' | 'revoked' | 'used' | 'missing';
  role?: UserRole;
  board_id?: string | null;
  board_name?: string | null;
  // null ⇒ never expires (migration 0037).
  expires_at?: string | null;
  // Migration 0076 — admin-entered legal name on the invite row, when
  // returned by get_invite_by_token (may be undefined on older payloads).
  invitee_name?: string | null;
}

export function useInviteByToken(token: string | undefined) {
  return useQuery({
    queryKey: token ? inviteKeys.token(token) : ['invites', 'token', '_'],
    enabled: !!token,
    queryFn: async (): Promise<InviteCheckResult> => {
      return (await dbRpc<InviteCheckResult>('get_invite_by_token', { p_token: token })) ?? { valid: false, reason: 'not_found' };
    },
    staleTime: 30_000,
  });
}

export function useAcceptInvite() {
  return useMutation({
    mutationFn: async (args: {
      token: string;
      // Migration 0042 dropped p_username — the server auto-generates a
      // unique username from invitee_email local-part / full_name / a
      // "user####" fallback. The invitee only types a full name + password.
      fullName: string;
      password: string;
    }): Promise<{ user_id: string; username: string; email: string; board_id: string | null }> => {
      return dbRpc<{ user_id: string; username: string; email: string; board_id: string | null }>('accept_invite', {
        p_token: args.token,
        p_full_name: args.fullName,
        p_password: args.password,
      });
    },
  });
}
