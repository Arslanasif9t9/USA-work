/**
 * src/hooks/updates.ts — task updates (comments) + reactions.
 *
 * Routes through the lock-free PostgREST fast path in src/lib/db.ts
 * (synchronous getCachedAccessToken + timeoutFetch direct to PostgREST).
 * Bypasses supabase.from()/.rpc(), which serialize on the
 * tabLocalAuthLock queue and were the proven funnel jam that wedged
 * the "Update" button in the task side panel.
 */
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import {
  dbSelect, dbInsert, dbInsertMany, dbInsertReturning, dbUpdate, dbDelete,
  eq, inSet,
} from '@/lib/db';
import { useAuthStore } from '@/state/authStore';
import type { UpdateRow, UpdateReactionRow } from '@/lib/database.types';

export const updateKeys = {
  all: ['updates'] as const,
  byItem: (itemId: string) => [...updateKeys.all, 'item', itemId] as const,
  reactionsByUpdate: (updateId: string) =>
    [...updateKeys.all, 'reactions', updateId] as const,
};

// ---------------------------------------------------------------------
// useItemUpdates — comments + their reactions in one query
// ---------------------------------------------------------------------
export interface UpdateWithMeta extends UpdateRow {
  reactions: UpdateReactionRow[];
  mentioned_user_ids: string[];
}

export function useItemUpdates(itemId: string | undefined) {
  return useQuery({
    queryKey: itemId ? updateKeys.byItem(itemId) : ['updates', '_'],
    enabled: !!itemId,
    queryFn: async (): Promise<UpdateWithMeta[]> => {
      const rows = await dbSelect<UpdateRow>('updates', {
        filters: { item_id: eq(itemId!), deleted_at: 'is.null' },
        order: 'created_at.desc',
      });
      if (rows.length === 0) return [];

      const updateIds = rows.map((u) => u.id);
      const [reactions, mentions] = await Promise.all([
        dbSelect<UpdateReactionRow>('update_reactions', {
          filters: { update_id: inSet(updateIds) },
        }),
        dbSelect<{ update_id: string; mentioned_user_id: string }>('update_mentions', {
          select: 'update_id,mentioned_user_id',
          filters: { update_id: inSet(updateIds) },
        }),
      ]);

      const reactionsByUpdate = new Map<string, UpdateReactionRow[]>();
      for (const r of reactions) {
        const arr = reactionsByUpdate.get(r.update_id) ?? [];
        arr.push(r);
        reactionsByUpdate.set(r.update_id, arr);
      }
      const mentionsByUpdate = new Map<string, string[]>();
      for (const m of mentions) {
        const arr = mentionsByUpdate.get(m.update_id) ?? [];
        arr.push(m.mentioned_user_id);
        mentionsByUpdate.set(m.update_id, arr);
      }
      return rows.map((u) => ({
        ...u,
        reactions: reactionsByUpdate.get(u.id) ?? [],
        mentioned_user_ids: mentionsByUpdate.get(u.id) ?? [],
      }));
    },
  });
}

// ---------------------------------------------------------------------
// useCreateUpdate — inserts update + mention rows
// ---------------------------------------------------------------------
export interface CreateUpdateInput {
  itemId: string;
  bodyHtml: string;
  bodyJson: unknown;
  mentionedUserIds: string[];
}

export function useCreateUpdate() {
  const qc = useQueryClient();
  const userId = useAuthStore((s) => s.profile?.id);
  return useMutation({
    mutationFn: async ({ itemId, bodyHtml, bodyJson, mentionedUserIds }: CreateUpdateInput) => {
      if (!userId) throw new Error('Not signed in');
      const update = await dbInsertReturning<UpdateRow>('updates', {
        item_id: itemId,
        author_id: userId,
        body_html: bodyHtml,
        body_json: bodyJson,
      });
      // De-dup mentions and self.
      const ids = Array.from(new Set(mentionedUserIds)).filter((id) => id !== userId);
      if (ids.length > 0) {
        await dbInsertMany(
          'update_mentions',
          ids.map((mid) => ({ update_id: update.id, mentioned_user_id: mid })),
        );
      }
      return update;
    },
    onSuccess: (u) => {
      void qc.invalidateQueries({ queryKey: updateKeys.byItem(u.item_id) });
    },
  });
}

// ---------------------------------------------------------------------
// useEditUpdate
// ---------------------------------------------------------------------
export function useEditUpdate() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async ({
      id, bodyHtml, bodyJson,
    }: { id: string; itemId: string; bodyHtml: string; bodyJson: unknown }) => {
      await dbUpdate('updates', { id: eq(id) }, { body_html: bodyHtml, body_json: bodyJson });
    },
    onSettled: (_d, _e, vars) => void qc.invalidateQueries({ queryKey: updateKeys.byItem(vars.itemId) }),
  });
}

// ---------------------------------------------------------------------
// useDeleteUpdate — soft delete
// ---------------------------------------------------------------------
export function useDeleteUpdate() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async ({ id }: { id: string; itemId: string }) => {
      await dbUpdate('updates', { id: eq(id) }, { deleted_at: new Date().toISOString() });
    },
    onSettled: (_d, _e, vars) => void qc.invalidateQueries({ queryKey: updateKeys.byItem(vars.itemId) }),
  });
}

// ---------------------------------------------------------------------
// useToggleReaction — add or remove a user's emoji on an update
// ---------------------------------------------------------------------
export function useToggleReaction() {
  const qc = useQueryClient();
  const userId = useAuthStore((s) => s.profile?.id);
  return useMutation({
    mutationFn: async ({ updateId, emoji, currentlyOn }: {
      updateId: string; emoji: string; itemId: string; currentlyOn: boolean;
    }) => {
      if (!userId) throw new Error('Not signed in');
      if (currentlyOn) {
        await dbDelete('update_reactions', {
          update_id: eq(updateId),
          user_id: eq(userId),
          emoji: eq(emoji),
        });
      } else {
        try {
          await dbInsert('update_reactions', {
            update_id: updateId, user_id: userId, emoji,
          });
        } catch (err) {
          // Ignore unique-violation (already reacted) — matches prior behavior.
          const code = (err as { code?: string } | null)?.code;
          if (code !== '23505') throw err;
        }
      }
    },
    onSettled: (_d, _e, vars) => void qc.invalidateQueries({ queryKey: updateKeys.byItem(vars.itemId) }),
  });
}
