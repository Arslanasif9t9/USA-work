import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import {
  SUPABASE_URL,
  SUPABASE_ANON_KEY,
  getCachedAccessToken,
  timeoutFetch,
} from '@/lib/supabase';
import { dbInsertReturning, dbSelect, dbUpdate, eq, inSet, isNull } from '@/lib/db';
import { useAuthStore } from '@/state/authStore';
import type { FileRow } from '@/lib/database.types';

export const fileKeys = {
  all: ['files'] as const,
  byItem: (itemId: string) => [...fileKeys.all, 'item', itemId] as const,
  byCell: (itemId: string, columnId: string) =>
    [...fileKeys.all, 'cell', itemId, columnId] as const,
  signedUrl: (path: string) => [...fileKeys.all, 'url', path] as const,
};

const BUCKET = 'task-files';
const STORAGE_BASE = `${SUPABASE_URL}/storage/v1`;

// ---------------------------------------------------------------------
// Lock-free Storage REST helpers.
//
// supabase.storage.* (like supabase.from()) routes through supabase-js's
// fetchWithAuth, which awaits supabase.auth.getSession() before EVERY
// request. After a tab refocus that get-session call serializes behind
// the auth lock — uploads then hang for minutes (same root cause that
// wedged board reads, fixed via db.ts). These helpers mirror db.ts:
// synchronous cached token + shared timeoutFetch (per-attempt
// AbortController + refresh-on-401 retry).
// ---------------------------------------------------------------------
function storageHeaders(extra?: Record<string, string>): Headers {
  const token = getCachedAccessToken() ?? SUPABASE_ANON_KEY;
  const h = new Headers({
    apikey: SUPABASE_ANON_KEY,
    Authorization: 'Bearer ' + token,
  });
  if (extra) for (const [k, v] of Object.entries(extra)) h.set(k, v);
  return h;
}

async function storageError(resp: Response, fallback: string): Promise<Error> {
  let msg = fallback;
  try {
    const text = await resp.text();
    if (text) {
      try {
        const parsed = JSON.parse(text) as { message?: string; error?: string };
        msg = parsed.message ?? parsed.error ?? text;
      } catch { msg = text; }
    }
  } catch { /* ignore */ }
  const err = new Error(msg) as Error & { status?: number };
  err.status = resp.status;
  return err;
}

async function storageUpload(path: string, file: File): Promise<void> {
  const resp = await timeoutFetch(`${STORAGE_BASE}/object/${BUCKET}/${path}`, {
    method: 'POST',
    headers: storageHeaders({
      'Content-Type': file.type || 'application/octet-stream',
      'x-upsert': 'false',
      'Cache-Control': '3600',
    }),
    body: file,
  });
  if (!resp.ok) throw await storageError(resp, `Storage upload failed (${resp.status})`);
}

async function storageRemove(path: string): Promise<{ notFound: boolean }> {
  const resp = await timeoutFetch(`${STORAGE_BASE}/object/${BUCKET}/${path}`, {
    method: 'DELETE',
    headers: storageHeaders(),
  });
  if (resp.ok) return { notFound: false };
  if (resp.status === 404) return { notFound: true };
  const err = await storageError(resp, `Storage delete failed (${resp.status})`);
  if (/not found/i.test(err.message)) return { notFound: true };
  throw err;
}

async function storageCreateSignedUrl(path: string, expiresInSec: number): Promise<string> {
  const resp = await timeoutFetch(`${STORAGE_BASE}/object/sign/${BUCKET}/${path}`, {
    method: 'POST',
    headers: storageHeaders({ 'Content-Type': 'application/json' }),
    body: JSON.stringify({ expiresIn: expiresInSec }),
  });
  if (!resp.ok) throw await storageError(resp, `Signed URL failed (${resp.status})`);
  const json = (await resp.json()) as { signedURL?: string; signedUrl?: string };
  const rel = json.signedURL ?? json.signedUrl;
  if (!rel) throw new Error('Signed URL response missing signedURL');
  return rel.startsWith('http')
    ? rel
    : `${STORAGE_BASE}${rel.startsWith('/') ? '' : '/'}${rel}`;
}

// Public helper — lock-free signed URL fetch outside of React Query, used by
// the update composer to inline a link to the file it just uploaded.
export async function getSignedFileUrl(path: string, expiresInSec = 60 * 60): Promise<string> {
  return storageCreateSignedUrl(path, expiresInSec);
}

function makeStoragePath(opts: {
  boardId: string;
  itemId?: string | null;
  updateId?: string | null;
  fileName: string;
}): string {
  const safe = opts.fileName.replace(/[^a-zA-Z0-9._-]/g, '_');
  const fileId = crypto.randomUUID();
  if (opts.itemId) return `boards/${opts.boardId}/items/${opts.itemId}/${fileId}-${safe}`;
  if (opts.updateId) return `boards/${opts.boardId}/updates/${opts.updateId}/${fileId}-${safe}`;
  throw new Error('makeStoragePath requires itemId or updateId');
}

// ---------------------------------------------------------------------
// useItemFiles — files attached at the item level (not column-cell)
// ---------------------------------------------------------------------
export function useItemFiles(itemId: string | undefined) {
  return useQuery({
    queryKey: itemId ? fileKeys.byItem(itemId) : ['files', '_'],
    enabled: !!itemId,
    queryFn: async (): Promise<FileRow[]> => {
      return dbSelect<FileRow>('files', {
        filters: { item_id: eq(itemId!), column_id: isNull, deleted_at: isNull },
        order: 'created_at.desc',
      });
    },
  });
}

// ---------------------------------------------------------------------
// useUploadFile — uploads to storage + inserts files row
// ---------------------------------------------------------------------
interface UploadInput {
  boardId: string;
  file: File;
  itemId?: string;
  updateId?: string;
  columnId?: string;
}

export function useUploadFile() {
  const qc = useQueryClient();
  const userId = useAuthStore((s) => s.profile?.id);
  return useMutation({
    mutationFn: async ({ boardId, file, itemId, updateId, columnId }: UploadInput): Promise<FileRow> => {
      if (!userId) throw new Error('Not signed in');
      if (!itemId && !updateId) throw new Error('Need itemId or updateId');

      const path = makeStoragePath({ boardId, itemId, updateId, fileName: file.name });
      await storageUpload(path, file);

      const insert = {
        uploader_id: userId,
        item_id: itemId ?? null,
        update_id: updateId ?? null,
        column_id: columnId ?? null,
        storage_path: path,
        file_name: file.name,
        file_size: file.size,
        mime_type: file.type || 'application/octet-stream',
      };
      try {
        return await dbInsertReturning<FileRow>('files', insert);
      } catch (error) {
        // Roll back the storage upload if the DB row failed.
        try { await storageRemove(path); } catch { /* best-effort */ }
        throw error;
      }
    },
    onSuccess: (f) => {
      if (f.item_id) {
        void qc.invalidateQueries({ queryKey: fileKeys.byItem(f.item_id) });
        if (f.column_id) {
          void qc.invalidateQueries({ queryKey: fileKeys.byCell(f.item_id, f.column_id) });
        }
      }
    },
  });
}

// ---------------------------------------------------------------------
// useDeleteFile — soft delete the row, hard delete the object
// ---------------------------------------------------------------------
export function useDeleteFile() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async (file: FileRow) => {
      // Remove from storage first; if it fails (other than 404), the row
      // stays alive and we can retry. RLS already restricts to
      // owner/admin.
      await storageRemove(file.storage_path);
      await dbUpdate('files', { id: eq(file.id) }, { deleted_at: new Date().toISOString() });
      return file;
    },
    onSuccess: (f) => {
      if (f.item_id) {
        void qc.invalidateQueries({ queryKey: fileKeys.byItem(f.item_id) });
        if (f.column_id) {
          void qc.invalidateQueries({ queryKey: fileKeys.byCell(f.item_id, f.column_id) });
        }
      }
      if (f.update_id) void qc.invalidateQueries({ queryKey: ['updates'] });
    },
  });
}

// ---------------------------------------------------------------------
// useDeleteGroupFiles — admin "Delete All Files" for a group.
//
// Mirrors cleanup-old-files mechanics (storage REST + soft-delete row),
// but scoped to every file row whose item_id is in the supplied list
// (the group's items + their subitems). Lock-free transport — uses
// db.ts + the storage REST helpers above, no second supabase client.
// Batches the file row scan to stay responsive on large groups.
// Returns { deleted, errors } so the caller can toast a count.
// ---------------------------------------------------------------------
const GROUP_FILES_BATCH = 100;
const ITEM_ID_CHUNK = 100; // PostgREST URL safety for in.(...) lists
export function useDeleteGroupFiles() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async ({ itemIds }: { boardId: string; groupId: string; itemIds: string[] }) => {
      let deleted = 0;
      const errors: string[] = [];
      if (itemIds.length === 0) return { deleted, errors };
      // Collect all live file rows for these items, chunked to keep URLs short.
      const all: FileRow[] = [];
      for (let i = 0; i < itemIds.length; i += ITEM_ID_CHUNK) {
        const chunk = itemIds.slice(i, i + ITEM_ID_CHUNK);
        const rows = await dbSelect<FileRow>('files', {
          filters: { item_id: inSet(chunk), deleted_at: isNull },
          order: 'created_at.asc',
        });
        all.push(...rows);
      }
      // Process in batches.
      for (let i = 0; i < all.length; i += GROUP_FILES_BATCH) {
        const batch = all.slice(i, i + GROUP_FILES_BATCH);
        for (const f of batch) {
          try {
            await storageRemove(f.storage_path);
            await dbUpdate('files', { id: eq(f.id) }, { deleted_at: new Date().toISOString() });
            deleted += 1;
          } catch (err) {
            errors.push(err instanceof Error ? err.message : String(err));
          }
        }
        // Yield to the event loop between batches so the UI stays responsive.
        await new Promise((r) => setTimeout(r, 0));
      }
      return { deleted, errors };
    },
    onSuccess: () => {
      // Broadly invalidate file caches — cells, item-level, updates.
      void qc.invalidateQueries({ queryKey: fileKeys.all });
      void qc.invalidateQueries({ queryKey: ['updates'] });
    },
  });
}

// ---------------------------------------------------------------------
// useFileUrl — fresh signed URL for download / inline preview
// ---------------------------------------------------------------------
export function useFileUrl(path: string | null | undefined, expiresInSec = 60 * 60) {
  return useQuery({
    queryKey: path ? fileKeys.signedUrl(path) : ['files', 'url', '_'],
    enabled: !!path,
    staleTime: (expiresInSec - 60) * 1000,
    queryFn: async () => storageCreateSignedUrl(path!, expiresInSec),
  });
}

// ---------------------------------------------------------------------
// useCellFiles — files attached to a specific item-column pair (files col)
//
// FIX for the "files refetching in a loop on tab refocus" report: the
// queryKey is keyed on (itemId, columnId) — both strings, so it is
// already stable across re-renders. We also explicitly set
// refetchOnWindowFocus: false here (the global default in main.tsx is
// already false; this is belt-and-suspenders so a future global change
// can't reintroduce a refocus storm). Plus a temporary diag log on
// each queryFn entry so the founder can confirm in DevTools whether
// the same cell's files endpoint is being hammered or whether the run
// of #39-#48 was simply N distinct cells fetching once each on
// initial mount (the expected pattern for a Files-column board).
// =====================================================================
const cellFilesFetchCount = new Map<string, number>();
export function useCellFiles(itemId: string | undefined, columnId: string | undefined) {
  return useQuery({
    queryKey: itemId && columnId ? fileKeys.byCell(itemId, columnId) : ['files', 'cell', '_'],
    enabled: !!itemId && !!columnId,
    refetchOnWindowFocus: false,
    queryFn: async (): Promise<FileRow[]> => {
      const cellKey = `${itemId}:${columnId}`;
      const n = (cellFilesFetchCount.get(cellKey) ?? 0) + 1;
      cellFilesFetchCount.set(cellKey, n);
      console.count('files-fetch');
      console.log(`[diag] useCellFiles fetch cell=${cellKey.slice(0, 12)}… run=${n}`);
      return dbSelect<FileRow>('files', {
        filters: { item_id: eq(itemId!), column_id: eq(columnId!), deleted_at: isNull },
        order: 'created_at.desc',
      });
    },
  });
}

// ---------------------------------------------------------------------
// useDownloadGroupFiles — admin "Download All Files" for a group.
//
// READ-ONLY counterpart of useDeleteGroupFiles. Uses the IDENTICAL
// enumeration (same files table, same filters, same itemIds chunking)
// so the set of files downloaded matches exactly what Delete All would
// target. Fetches each via a fresh signed URL through timeoutFetch
// (lock-free — no second supabase client), then bundles everything
// into one ZIP foldered by task name (collisions resolved with a
// numeric suffix). Returns { total, downloaded, errors } so the caller
// can toast progress.
// ---------------------------------------------------------------------
export function useDownloadGroupFiles() {
  return useMutation({
    mutationFn: async ({
      groupName,
      itemIds,
      itemNames,
      onProgress,
    }: {
      boardId: string;
      groupId: string;
      groupName: string;
      itemIds: string[];
      itemNames: Record<string, string>;
      onProgress?: (done: number, total: number) => void;
    }) => {
      const errors: string[] = [];
      if (itemIds.length === 0) return { total: 0, downloaded: 0, errors };

      // Identical enumeration to useDeleteGroupFiles.
      const all: FileRow[] = [];
      for (let i = 0; i < itemIds.length; i += ITEM_ID_CHUNK) {
        const chunk = itemIds.slice(i, i + ITEM_ID_CHUNK);
        const rows = await dbSelect<FileRow>('files', {
          filters: { item_id: inSet(chunk), deleted_at: isNull },
          order: 'created_at.asc',
        });
        all.push(...rows);
      }
      const total = all.length;
      if (total === 0) return { total, downloaded: 0, errors };

      const { default: JSZip } = await import('jszip');
      const zip = new JSZip();
      let downloaded = 0;

      const sanitize = (s: string) => s.replace(/[\\/:*?"<>|]+/g, '_').trim() || 'untitled';
      const usedNames = new Map<string, number>(); // per-folder filename dedupe

      for (const f of all) {
        try {
          const url = await storageCreateSignedUrl(f.storage_path, 60 * 10);
          const resp = await timeoutFetch(url, { method: 'GET' });
          if (!resp.ok) throw new Error(`HTTP ${resp.status}`);
          const buf = await resp.arrayBuffer();
          const folder = sanitize(itemNames[f.item_id ?? ''] ?? 'unassigned');
          let fileName = sanitize(f.file_name);
          const key = `${folder}/${fileName}`;
          const seen = usedNames.get(key) ?? 0;
          if (seen > 0) {
            const dot = fileName.lastIndexOf('.');
            const base = dot > 0 ? fileName.slice(0, dot) : fileName;
            const ext = dot > 0 ? fileName.slice(dot) : '';
            fileName = `${base} (${seen})${ext}`;
          }
          usedNames.set(key, seen + 1);
          zip.file(`${folder}/${fileName}`, buf);
          downloaded += 1;
          onProgress?.(downloaded, total);
        } catch (err) {
          errors.push(`${f.file_name}: ${err instanceof Error ? err.message : String(err)}`);
        }
      }

      if (downloaded === 0) return { total, downloaded, errors };

      const blob = await zip.generateAsync({ type: 'blob' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `${sanitize(groupName)}-files.zip`;
      document.body.appendChild(a);
      a.click();
      a.remove();
      setTimeout(() => URL.revokeObjectURL(url), 1000);

      return { total, downloaded, errors };
    },
  });
}
