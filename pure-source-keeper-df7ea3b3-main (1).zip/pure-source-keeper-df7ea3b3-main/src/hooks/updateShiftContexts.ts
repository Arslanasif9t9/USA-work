/**
 * src/hooks/updateShiftContexts.ts
 *
 * For ADMIN viewers: given a list of updates ({id, author_id, created_at}),
 * fetch each author's shift_sessions and compute, per update, the author's
 * shift context at the moment the update was posted.
 *
 * Returns Map<update_id, { startedAt, intoShiftSec }>.
 *
 * Display-only. No schema change. Uses paused_total_seconds snapshot
 * (same approximation as the lily-reply snapshot).
 *
 * RLS: shift_sessions select policy = is_admin() OR user_id = auth.uid().
 * Caller should set `enabled` false for non-admin viewers.
 *
 * IMPORTANT: uses the project's primary supabase client (@/lib/supabase)
 * so it shares the single GoTrue instance + auth-token storage key with
 * the rest of the app. A second client would race on the same storage
 * key and could wedge auth.
 */
import { useMemo } from 'react';
import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/lib/supabase';

export interface UpdateShiftCtx {
  startedAt: string;
  intoShiftSec: number;
}

interface UpdateLike {
  id: string;
  author_id: string | null;
  created_at: string | null;
}

const UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

function safeMs(iso: string | null | undefined): number | null {
  if (!iso) return null;
  const t = new Date(iso).getTime();
  return Number.isFinite(t) ? t : null;
}

export function useUpdateShiftContexts(updates: UpdateLike[], enabled: boolean) {
  // Filter to rows we can actually query (real uuid + parseable timestamp).
  const safeUpdates = useMemo(
    () =>
      updates.filter(
        (u) =>
          !!u.author_id &&
          UUID_RE.test(u.author_id) &&
          safeMs(u.created_at) !== null,
      ),
    [updates],
  );

  const authorIds = useMemo(
    () => Array.from(new Set(safeUpdates.map((u) => u.author_id as string))).sort(),
    [safeUpdates],
  );
  const sig = authorIds.join(',');

  return useQuery<Map<string, UpdateShiftCtx>>({
    queryKey: ['update-shift-ctx', sig],
    enabled: enabled && authorIds.length > 0,
    staleTime: 60_000,
    queryFn: async () => {
      const map = new Map<string, UpdateShiftCtx>();
      try {
        const since = new Date(Date.now() - 90 * 86400_000).toISOString();
        const { data, error } = await supabase
          .from('shift_sessions')
          .select('user_id, started_at, completed_at, paused_total_seconds')
          .in('user_id', authorIds)
          .not('started_at', 'is', null)
          .gte('started_at', since);
        if (error) {
          // Don't crash the panel — admin shift-context line is best-effort.
          // eslint-disable-next-line no-console
          console.warn('[updateShiftContexts] query failed:', error.message);
          return map;
        }
        const sessions = (data ?? []) as Array<{
          user_id: string;
          started_at: string | null;
          completed_at: string | null;
          paused_total_seconds: number | null;
        }>;
        for (const u of safeUpdates) {
          const ut = safeMs(u.created_at);
          if (ut === null) continue;
          const s = sessions.find((row) => {
            if (row.user_id !== u.author_id) return false;
            const startMs = safeMs(row.started_at);
            if (startMs === null || startMs > ut) return false;
            const endMs = safeMs(row.completed_at);
            if (endMs !== null && endMs < ut) return false;
            return true;
          });
          if (!s || !s.started_at) continue;
          const startMs = safeMs(s.started_at);
          if (startMs === null) continue;
          const elapsedSec = Math.max(
            0,
            Math.floor((ut - startMs) / 1000) - (s.paused_total_seconds ?? 0),
          );
          map.set(u.id, { startedAt: s.started_at, intoShiftSec: elapsedSec });
        }
      } catch (err) {
        // eslint-disable-next-line no-console
        console.warn('[updateShiftContexts] unexpected error:', err);
      }
      return map;
    },
  });
}
