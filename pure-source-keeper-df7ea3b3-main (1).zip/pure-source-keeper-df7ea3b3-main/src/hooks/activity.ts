/**
 * src/hooks/activity.ts — task activity log.
 *
 * Routes through the lock-free PostgREST fast path (src/lib/db.ts).
 * Previously used supabase.from('activity_log') which serializes on
 * supabase-js's getSession() lock — that funnel jam wedged the
 * Activity tab on infinite spinner after tab refocus (same disease
 * that hit boards / shift / updates). Same cure: dbSelect.
 */
import { useQuery } from '@tanstack/react-query';
import { dbSelect, eq } from '@/lib/db';
import type { ActivityLogRow } from '@/lib/database.types';

export const activityKeys = {
  all: ['activity'] as const,
  byItem: (itemId: string) => [...activityKeys.all, 'item', itemId] as const,
};

export function useItemActivity(itemId: string | undefined) {
  return useQuery({
    queryKey: itemId ? activityKeys.byItem(itemId) : ['activity', '_'],
    enabled: !!itemId,
    queryFn: async (): Promise<ActivityLogRow[]> => {
      return dbSelect<ActivityLogRow>('activity_log', {
        filters: { target_type: eq('item'), target_id: eq(itemId!) },
        order: 'created_at.desc',
        limit: 200,
      });
    },
  });
}
