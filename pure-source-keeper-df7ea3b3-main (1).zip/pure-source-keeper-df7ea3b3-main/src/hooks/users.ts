import { useQuery } from '@tanstack/react-query';
import { dbSelect, eq } from '@/lib/db';
import type { UserRow } from '@/lib/database.types';

export const userKeys = {
  active: ['users', 'active'] as const,
};

// Used by the people picker.  Only active users — no emails returned.
export function useActiveUsers() {
  return useQuery({
    queryKey: userKeys.active,
    queryFn: async () => {
      return dbSelect<Pick<UserRow, 'id' | 'username' | 'full_name' | 'avatar_url' | 'role' | 'status' | 'is_super_admin'>>('users', {
        select: 'id,username,full_name,avatar_url,role,status,is_super_admin',
        filters: { status: eq('active') },
        order: 'username.asc',
      });
    },
  });
}
