/**
 * Frontend wrapper for POST /api/ai-build (the Version B endpoint).
 * The function does the Gemini call + auth + role gate; this hook just
 * passes the session JWT and parses the JSON.
 */
import { useMutation } from '@tanstack/react-query';
import { getCachedAccessToken } from '@/lib/supabase';
import type { Action, EngineContext } from '@/lib/ai-applier';
import { apiFetch } from '@/lib/apiClient';

export interface AiBuildArgs {
  prompt: string;
  kind: 'create_board' | 'add_to_board' | 'add_tasks';
  boardId?: string;
  model?: 'gemini-2.5-flash' | 'gemini-2.5-pro';
}

export interface AiBuildResponse {
  actions: Action[];
  notes?: string;
  context: EngineContext;
}

export function useAiBuild() {
  return useMutation({
    mutationFn: async (args: AiBuildArgs): Promise<AiBuildResponse> => {
      // Lock-free auth: read the cached access token synchronously instead
      // of awaiting safeGetSession (which serializes on the tab-local auth
      // lock and can time out after a tab refocus, producing the
      // "auth check timed out" toast). The token is seeded at boot and
      // refreshed by onAuthStateChange + the 401-retry path in db.ts.
      const jwt = getCachedAccessToken();
      if (!jwt) throw new Error('not signed in');

      // Hard client-side deadline: 35s. The server's own Gemini cap is
      // 25s; we leave room for the round-trip + Vercel cold start and
      // then bail with a clear error rather than spinning forever.
      const controller = new AbortController();
      const timer = setTimeout(() => controller.abort(), 35_000);

      let resp: Response;
      try {
        resp = await apiFetch('/api/ai-build', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${jwt}`,
          },
          body: JSON.stringify({
            prompt: args.prompt,
            kind: args.kind,
            board_id: args.boardId,
            model: args.model,
          }),
          signal: controller.signal,
        });
      } catch (err) {
        clearTimeout(timer);
        if (err instanceof Error && err.name === 'AbortError') {
          throw new Error('AI build timed out after 35 seconds. Please try again.');
        }
        throw new Error(err instanceof Error ? err.message : String(err));
      }
      clearTimeout(timer);

      const text = await resp.text();
      let payload: unknown;
      try { payload = JSON.parse(text); }
      catch { throw new Error(`bad response (HTTP ${resp.status}): ${text.slice(0, 200)}`); }

      if (!resp.ok) {
        const errMsg = (payload as { error?: string } | null)?.error
          ?? `request failed (HTTP ${resp.status})`;
        throw new Error(errMsg);
      }
      return payload as AiBuildResponse;
    },
  });
}
