import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { dbCount, dbSelect, dbUpdate, eq } from '@/lib/db';
import { useAuthStore } from '@/state/authStore';
import type { NotificationRow } from '@/lib/database.types';

export const notificationKeys = {
  all: ['notifications'] as const,
  list: () => [...notificationKeys.all, 'list'] as const,
  unread: () => [...notificationKeys.all, 'unread'] as const,
};

export function useNotifications(limit = 50) {
  const userId = useAuthStore((s) => s.profile?.id);
  return useQuery({
    queryKey: [...notificationKeys.list(), limit],
    enabled: !!userId,
    queryFn: async (): Promise<NotificationRow[]> => {
      return dbSelect<NotificationRow>('notifications', {
        order: 'created_at.desc',
        limit,
      });
    },
    // 20s background poll so the notification watcher (src/lib/notify.ts
    // useNotificationWatcher) surfaces a toast + bell chime for every new
    // row within ~20s of arrival. refetchOnWindowFocus stays OFF — we do
    // not re-enable refocus machinery here.
    refetchInterval: 20_000,
    refetchOnWindowFocus: false,
  });
}

export function useUnreadCount() {
  const userId = useAuthStore((s) => s.profile?.id);
  return useQuery({
    queryKey: notificationKeys.unread(),
    enabled: !!userId,
    queryFn: async (): Promise<number> => {
      return dbCount('notifications', { select: 'id', filters: { is_read: eq(false) } });
    },
    refetchInterval: 30_000,           // background refresh every 30s
    // P4.0 fix: previously true, contributing to the refocus stampede +
    // 401 spam on stale tokens. The 30s interval poll keeps the unread
    // count fresh; visibility-driven refetch is no longer needed.
    refetchOnWindowFocus: false,
  });
}

export function useMarkRead() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async (id: string) => {
      await dbUpdate('notifications', { id: eq(id) }, { is_read: true, read_at: new Date().toISOString() });
    },
    onSettled: () => {
      void qc.invalidateQueries({ queryKey: notificationKeys.all });
    },
  });
}

export function useMarkAllRead() {
  const qc = useQueryClient();
  const userId = useAuthStore((s) => s.profile?.id);
  return useMutation({
    mutationFn: async () => {
      if (!userId) return;
      await dbUpdate('notifications', { recipient_id: eq(userId), is_read: eq(false) }, { is_read: true, read_at: new Date().toISOString() });
    },
    onSettled: () => void qc.invalidateQueries({ queryKey: notificationKeys.all }),
  });
}
