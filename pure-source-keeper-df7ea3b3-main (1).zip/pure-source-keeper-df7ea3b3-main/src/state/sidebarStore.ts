import { create } from 'zustand';

// Persists the admin left sidebar (WorkspacePanel) collapsed state
// across reloads. Only the admin shell consumes this — managers have
// no sidebar to collapse. Default = expanded (false).
const STORAGE_KEY = 'pms.sidebar.collapsed';
// UI-shortcuts batch: persistent collapsed state for the inline
// notifications block embedded in the WorkspacePanel. Default = true
// (collapsed) so a fresh login does NOT auto-expand the notifications
// list. Clicking the bell header toggles + persists.
const NOTIF_KEY = 'pms.notif.collapsed';

function readInitial(): boolean {
  try {
    return localStorage.getItem(STORAGE_KEY) === '1';
  } catch {
    return false;
  }
}

function readNotifInitial(): boolean {
  try {
    const v = localStorage.getItem(NOTIF_KEY);
    // Default collapsed=true when no value has ever been written.
    if (v === null) return true;
    return v === '1';
  } catch {
    return true;
  }
}

interface SidebarState {
  collapsed: boolean;
  setCollapsed: (v: boolean) => void;
  toggle: () => void;
  notifCollapsed: boolean;
  setNotifCollapsed: (v: boolean) => void;
  toggleNotif: () => void;
}

export const useSidebarStore = create<SidebarState>((set, get) => ({
  collapsed: readInitial(),
  setCollapsed: (v) => {
    try {
      localStorage.setItem(STORAGE_KEY, v ? '1' : '0');
    } catch {
      /* ignore */
    }
    set({ collapsed: v });
  },
  toggle: () => get().setCollapsed(!get().collapsed),
  notifCollapsed: readNotifInitial(),
  setNotifCollapsed: (v) => {
    try {
      localStorage.setItem(NOTIF_KEY, v ? '1' : '0');
    } catch {
      /* ignore */
    }
    set({ notifCollapsed: v });
  },
  toggleNotif: () => get().setNotifCollapsed(!get().notifCollapsed),
}));
