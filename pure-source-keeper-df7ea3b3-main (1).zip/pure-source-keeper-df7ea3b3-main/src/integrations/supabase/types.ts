export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.5"
  }
  public: {
    Tables: {
      account: {
        Row: {
          created_at: string
          gemini_api_key_encrypted: string | null
          id: string
          name: string
          settings: Json
          updated_at: string
        }
        Insert: {
          created_at?: string
          gemini_api_key_encrypted?: string | null
          id?: string
          name: string
          settings?: Json
          updated_at?: string
        }
        Update: {
          created_at?: string
          gemini_api_key_encrypted?: string | null
          id?: string
          name?: string
          settings?: Json
          updated_at?: string
        }
        Relationships: []
      }
      activity_log: {
        Row: {
          action_type: string
          actor_id: string | null
          created_at: string
          id: string
          new_value: Json | null
          old_value: Json | null
          target_id: string | null
          target_type: string
        }
        Insert: {
          action_type: string
          actor_id?: string | null
          created_at?: string
          id?: string
          new_value?: Json | null
          old_value?: Json | null
          target_id?: string | null
          target_type: string
        }
        Update: {
          action_type?: string
          actor_id?: string | null
          created_at?: string
          id?: string
          new_value?: Json | null
          old_value?: Json | null
          target_id?: string | null
          target_type?: string
        }
        Relationships: [
          {
            foreignKeyName: "activity_log_actor_fk"
            columns: ["actor_id"]
            isOneToOne: false
            referencedRelation: "users"
            referencedColumns: ["id"]
          },
        ]
      }
      ai_runs: {
        Row: {
          error_message: string | null
          feature: string
          id: string
          model: string | null
          prompt: string | null
          ran_at: string
          response: string | null
          status: string
          target_id: string | null
          target_type: string | null
          tokens_input: number | null
          tokens_output: number | null
          user_id: string | null
        }
        Insert: {
          error_message?: string | null
          feature: string
          id?: string
          model?: string | null
          prompt?: string | null
          ran_at?: string
          response?: string | null
          status?: string
          target_id?: string | null
          target_type?: string | null
          tokens_input?: number | null
          tokens_output?: number | null
          user_id?: string | null
        }
        Update: {
          error_message?: string | null
          feature?: string
          id?: string
          model?: string | null
          prompt?: string | null
          ran_at?: string
          response?: string | null
          status?: string
          target_id?: string | null
          target_type?: string | null
          tokens_input?: number | null
          tokens_output?: number | null
          user_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "ai_runs_user_fk"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "users"
            referencedColumns: ["id"]
          },
        ]
      }
      bio_break_requests: {
        Row: {
          decided_at: string | null
          decided_by: string | null
          decision_note: string | null
          id: string
          requested_at: string
          session_id: string
          status: string
          user_id: string
        }
        Insert: {
          decided_at?: string | null
          decided_by?: string | null
          decision_note?: string | null
          id?: string
          requested_at?: string
          session_id: string
          status?: string
          user_id: string
        }
        Update: {
          decided_at?: string | null
          decided_by?: string | null
          decision_note?: string | null
          id?: string
          requested_at?: string
          session_id?: string
          status?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "bio_break_requests_decided_by_fkey"
            columns: ["decided_by"]
            isOneToOne: false
            referencedRelation: "users"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "bio_break_requests_session_id_fkey"
            columns: ["session_id"]
            isOneToOne: false
            referencedRelation: "shift_sessions"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "bio_break_requests_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "users"
            referencedColumns: ["id"]
          },
        ]
      }
      board_counters: {
        Row: {
          board_id: string
          last_task_number: number
          updated_at: string
        }
        Insert: {
          board_id: string
          last_task_number?: number
          updated_at?: string
        }
        Update: {
          board_id?: string
          last_task_number?: number
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "board_counters_board_fk"
            columns: ["board_id"]
            isOneToOne: true
            referencedRelation: "boards"
            referencedColumns: ["id"]
          },
        ]
      }
      board_favorites: {
        Row: {
          board_id: string
          favorited_at: string
          user_id: string
        }
        Insert: {
          board_id: string
          favorited_at?: string
          user_id: string
        }
        Update: {
          board_id?: string
          favorited_at?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "board_favorites_board_fk"
            columns: ["board_id"]
            isOneToOne: false
            referencedRelation: "boards"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "board_favorites_user_fk"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "users"
            referencedColumns: ["id"]
          },
        ]
      }
      board_last_viewed: {
        Row: {
          board_id: string
          last_viewed_at: string
          user_id: string
        }
        Insert: {
          board_id: string
          last_viewed_at?: string
          user_id: string
        }
        Update: {
          board_id?: string
          last_viewed_at?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "board_last_viewed_board_fk"
            columns: ["board_id"]
            isOneToOne: false
            referencedRelation: "boards"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "board_last_viewed_user_fk"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "users"
            referencedColumns: ["id"]
          },
        ]
      }
      board_subscribers: {
        Row: {
          board_id: string
          group_id: string | null
          notification_level: string
          role: string
          subscribed_at: string
          user_id: string
        }
        Insert: {
          board_id: string
          group_id?: string | null
          notification_level?: string
          role?: string
          subscribed_at?: string
          user_id: string
        }
        Update: {
          board_id?: string
          group_id?: string | null
          notification_level?: string
          role?: string
          subscribed_at?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "board_subscribers_board_fk"
            columns: ["board_id"]
            isOneToOne: false
            referencedRelation: "boards"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "board_subscribers_group_fk"
            columns: ["group_id"]
            isOneToOne: false
            referencedRelation: "groups"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "board_subscribers_user_fk"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "users"
            referencedColumns: ["id"]
          },
        ]
      }
      board_sync_pings: {
        Row: {
          board_id: string
          id: string
          pinged_at: string
          pinged_by: string | null
        }
        Insert: {
          board_id: string
          id?: string
          pinged_at?: string
          pinged_by?: string | null
        }
        Update: {
          board_id?: string
          id?: string
          pinged_at?: string
          pinged_by?: string | null
        }
        Relationships: []
      }
      boards: {
        Row: {
          archived_at: string | null
          board_type: string
          created_at: string
          created_by: string | null
          deleted_at: string | null
          description: string | null
          icon_emoji: string
          id: string
          name: string
          owner_id: string | null
          settings: Json
          updated_at: string
          workspace_id: string
        }
        Insert: {
          archived_at?: string | null
          board_type?: string
          created_at?: string
          created_by?: string | null
          deleted_at?: string | null
          description?: string | null
          icon_emoji?: string
          id?: string
          name: string
          owner_id?: string | null
          settings?: Json
          updated_at?: string
          workspace_id: string
        }
        Update: {
          archived_at?: string | null
          board_type?: string
          created_at?: string
          created_by?: string | null
          deleted_at?: string | null
          description?: string | null
          icon_emoji?: string
          id?: string
          name?: string
          owner_id?: string | null
          settings?: Json
          updated_at?: string
          workspace_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "boards_created_by_fk"
            columns: ["created_by"]
            isOneToOne: false
            referencedRelation: "users"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "boards_owner_fk"
            columns: ["owner_id"]
            isOneToOne: false
            referencedRelation: "users"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "boards_workspace_fk"
            columns: ["workspace_id"]
            isOneToOne: false
            referencedRelation: "workspaces"
            referencedColumns: ["id"]
          },
        ]
      }
      chat_messages: {
        Row: {
          body: string
          created_at: string
          id: string
          sender: string
          sender_user_id: string | null
          thread_id: string | null
        }
        Insert: {
          body: string
          created_at?: string
          id?: string
          sender: string
          sender_user_id?: string | null
          thread_id?: string | null
        }
        Update: {
          body?: string
          created_at?: string
          id?: string
          sender?: string
          sender_user_id?: string | null
          thread_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "chat_messages_sender_user_id_fkey"
            columns: ["sender_user_id"]
            isOneToOne: false
            referencedRelation: "users"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "chat_messages_thread_id_fkey"
            columns: ["thread_id"]
            isOneToOne: false
            referencedRelation: "chat_threads"
            referencedColumns: ["id"]
          },
        ]
      }
      chat_threads: {
        Row: {
          admin_replied_at: string | null
          created_at: string
          id: string
          last_message_at: string
          user_id: string | null
        }
        Insert: {
          admin_replied_at?: string | null
          created_at?: string
          id?: string
          last_message_at?: string
          user_id?: string | null
        }
        Update: {
          admin_replied_at?: string | null
          created_at?: string
          id?: string
          last_message_at?: string
          user_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "chat_threads_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: true
            referencedRelation: "users"
            referencedColumns: ["id"]
          },
        ]
      }
      column_labels: {
        Row: {
          color: string
          column_id: string
          created_at: string
          id: string
          is_default: boolean
          name: string
          sort_order: number
        }
        Insert: {
          color?: string
          column_id: string
          created_at?: string
          id?: string
          is_default?: boolean
          name: string
          sort_order?: number
        }
        Update: {
          color?: string
          column_id?: string
          created_at?: string
          id?: string
          is_default?: boolean
          name?: string
          sort_order?: number
        }
        Relationships: [
          {
            foreignKeyName: "column_labels_column_fk"
            columns: ["column_id"]
            isOneToOne: false
            referencedRelation: "columns"
            referencedColumns: ["id"]
          },
        ]
      }
      columns: {
        Row: {
          archived_at: string | null
          board_id: string
          column_type: string
          created_at: string
          default_value: Json | null
          id: string
          is_pinned_left: boolean
          is_pinned_right: boolean
          is_required: boolean
          name: string
          settings: Json
          sort_order: number
          updated_at: string
          width: number
        }
        Insert: {
          archived_at?: string | null
          board_id: string
          column_type: string
          created_at?: string
          default_value?: Json | null
          id?: string
          is_pinned_left?: boolean
          is_pinned_right?: boolean
          is_required?: boolean
          name: string
          settings?: Json
          sort_order?: number
          updated_at?: string
          width?: number
        }
        Update: {
          archived_at?: string | null
          board_id?: string
          column_type?: string
          created_at?: string
          default_value?: Json | null
          id?: string
          is_pinned_left?: boolean
          is_pinned_right?: boolean
          is_required?: boolean
          name?: string
          settings?: Json
          sort_order?: number
          updated_at?: string
          width?: number
        }
        Relationships: [
          {
            foreignKeyName: "columns_board_fk"
            columns: ["board_id"]
            isOneToOne: false
            referencedRelation: "boards"
            referencedColumns: ["id"]
          },
        ]
      }
      files: {
        Row: {
          column_id: string | null
          created_at: string
          deleted_at: string | null
          file_name: string
          file_size: number
          id: string
          item_id: string | null
          mime_type: string
          storage_path: string
          thumbnail_path: string | null
          update_id: string | null
          uploader_id: string | null
        }
        Insert: {
          column_id?: string | null
          created_at?: string
          deleted_at?: string | null
          file_name: string
          file_size: number
          id?: string
          item_id?: string | null
          mime_type: string
          storage_path: string
          thumbnail_path?: string | null
          update_id?: string | null
          uploader_id?: string | null
        }
        Update: {
          column_id?: string | null
          created_at?: string
          deleted_at?: string | null
          file_name?: string
          file_size?: number
          id?: string
          item_id?: string | null
          mime_type?: string
          storage_path?: string
          thumbnail_path?: string | null
          update_id?: string | null
          uploader_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "files_column_fk"
            columns: ["column_id"]
            isOneToOne: false
            referencedRelation: "columns"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "files_item_fk"
            columns: ["item_id"]
            isOneToOne: false
            referencedRelation: "items"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "files_update_fk"
            columns: ["update_id"]
            isOneToOne: false
            referencedRelation: "updates"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "files_uploader_fk"
            columns: ["uploader_id"]
            isOneToOne: false
            referencedRelation: "users"
            referencedColumns: ["id"]
          },
        ]
      }
      group_user_visibility: {
        Row: {
          created_at: string
          granted_by: string | null
          group_id: string
          user_id: string
        }
        Insert: {
          created_at?: string
          granted_by?: string | null
          group_id: string
          user_id: string
        }
        Update: {
          created_at?: string
          granted_by?: string | null
          group_id?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "group_user_visibility_granted_by_fkey"
            columns: ["granted_by"]
            isOneToOne: false
            referencedRelation: "users"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "group_user_visibility_group_id_fkey"
            columns: ["group_id"]
            isOneToOne: false
            referencedRelation: "groups"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "group_user_visibility_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "users"
            referencedColumns: ["id"]
          },
        ]
      }
      groups: {
        Row: {
          archived_at: string | null
          board_id: string
          color: string
          created_at: string
          deleted_at: string | null
          id: string
          is_collapsed_default: boolean
          name: string
          sort_order: number
          updated_at: string
        }
        Insert: {
          archived_at?: string | null
          board_id: string
          color?: string
          created_at?: string
          deleted_at?: string | null
          id?: string
          is_collapsed_default?: boolean
          name: string
          sort_order?: number
          updated_at?: string
        }
        Update: {
          archived_at?: string | null
          board_id?: string
          color?: string
          created_at?: string
          deleted_at?: string | null
          id?: string
          is_collapsed_default?: boolean
          name?: string
          sort_order?: number
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "groups_board_fk"
            columns: ["board_id"]
            isOneToOne: false
            referencedRelation: "boards"
            referencedColumns: ["id"]
          },
        ]
      }
      invites: {
        Row: {
          board_id: string | null
          created_at: string
          created_by: string | null
          expires_at: string | null
          group_id: string | null
          id: string
          invitee_email: string | null
          invitee_name: string | null
          invitee_shift_end_time: string | null
          invitee_shift_mode: string | null
          invitee_shift_start_date: string | null
          invitee_shift_start_time: string | null
          invitee_timezone: string | null
          revoked_at: string | null
          role: string
          token: string
          used_at: string | null
          used_by: string | null
        }
        Insert: {
          board_id?: string | null
          created_at?: string
          created_by?: string | null
          expires_at?: string | null
          group_id?: string | null
          id?: string
          invitee_email?: string | null
          invitee_name?: string | null
          invitee_shift_end_time?: string | null
          invitee_shift_mode?: string | null
          invitee_shift_start_date?: string | null
          invitee_shift_start_time?: string | null
          invitee_timezone?: string | null
          revoked_at?: string | null
          role: string
          token: string
          used_at?: string | null
          used_by?: string | null
        }
        Update: {
          board_id?: string | null
          created_at?: string
          created_by?: string | null
          expires_at?: string | null
          group_id?: string | null
          id?: string
          invitee_email?: string | null
          invitee_name?: string | null
          invitee_shift_end_time?: string | null
          invitee_shift_mode?: string | null
          invitee_shift_start_date?: string | null
          invitee_shift_start_time?: string | null
          invitee_timezone?: string | null
          revoked_at?: string | null
          role?: string
          token?: string
          used_at?: string | null
          used_by?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "invites_board_fk"
            columns: ["board_id"]
            isOneToOne: false
            referencedRelation: "boards"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "invites_created_by_fk"
            columns: ["created_by"]
            isOneToOne: false
            referencedRelation: "users"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "invites_group_fk"
            columns: ["group_id"]
            isOneToOne: false
            referencedRelation: "groups"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "invites_used_by_fk"
            columns: ["used_by"]
            isOneToOne: false
            referencedRelation: "users"
            referencedColumns: ["id"]
          },
        ]
      }
      item_column_values: {
        Row: {
          column_id: string
          id: string
          item_id: string
          updated_at: string
          updated_by: string | null
          value: Json
        }
        Insert: {
          column_id: string
          id?: string
          item_id: string
          updated_at?: string
          updated_by?: string | null
          value: Json
        }
        Update: {
          column_id?: string
          id?: string
          item_id?: string
          updated_at?: string
          updated_by?: string | null
          value?: Json
        }
        Relationships: [
          {
            foreignKeyName: "item_column_values_column_fk"
            columns: ["column_id"]
            isOneToOne: false
            referencedRelation: "columns"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "item_column_values_item_fk"
            columns: ["item_id"]
            isOneToOne: false
            referencedRelation: "items"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "item_column_values_updated_by_fk"
            columns: ["updated_by"]
            isOneToOne: false
            referencedRelation: "users"
            referencedColumns: ["id"]
          },
        ]
      }
      item_subscribers: {
        Row: {
          item_id: string
          subscribed_at: string
          user_id: string
        }
        Insert: {
          item_id: string
          subscribed_at?: string
          user_id: string
        }
        Update: {
          item_id?: string
          subscribed_at?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "item_subscribers_item_fk"
            columns: ["item_id"]
            isOneToOne: false
            referencedRelation: "items"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "item_subscribers_user_fk"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "users"
            referencedColumns: ["id"]
          },
        ]
      }
      items: {
        Row: {
          archived_at: string | null
          board_id: string
          created_at: string
          created_by: string | null
          deleted_at: string | null
          group_id: string
          id: string
          name: string
          parent_item_id: string | null
          sort_order: number
          task_code: string
          updated_at: string
          updated_by: string | null
        }
        Insert: {
          archived_at?: string | null
          board_id: string
          created_at?: string
          created_by?: string | null
          deleted_at?: string | null
          group_id: string
          id?: string
          name?: string
          parent_item_id?: string | null
          sort_order?: number
          task_code: string
          updated_at?: string
          updated_by?: string | null
        }
        Update: {
          archived_at?: string | null
          board_id?: string
          created_at?: string
          created_by?: string | null
          deleted_at?: string | null
          group_id?: string
          id?: string
          name?: string
          parent_item_id?: string | null
          sort_order?: number
          task_code?: string
          updated_at?: string
          updated_by?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "items_board_fk"
            columns: ["board_id"]
            isOneToOne: false
            referencedRelation: "boards"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "items_created_by_fk"
            columns: ["created_by"]
            isOneToOne: false
            referencedRelation: "users"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "items_group_fk"
            columns: ["group_id"]
            isOneToOne: false
            referencedRelation: "groups"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "items_parent_fk"
            columns: ["parent_item_id"]
            isOneToOne: false
            referencedRelation: "items"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "items_updated_by_fk"
            columns: ["updated_by"]
            isOneToOne: false
            referencedRelation: "users"
            referencedColumns: ["id"]
          },
        ]
      }
      known_logins: {
        Row: {
          account_email: string
          device_fingerprint: string | null
          first_seen: string
          id: string
          last_seen: string
          location: string | null
        }
        Insert: {
          account_email: string
          device_fingerprint?: string | null
          first_seen?: string
          id?: string
          last_seen?: string
          location?: string | null
        }
        Update: {
          account_email?: string
          device_fingerprint?: string | null
          first_seen?: string
          id?: string
          last_seen?: string
          location?: string | null
        }
        Relationships: []
      }
      lily_settings: {
        Row: {
          id: number
          mode: string
          updated_at: string
        }
        Insert: {
          id?: number
          mode?: string
          updated_at?: string
        }
        Update: {
          id?: number
          mode?: string
          updated_at?: string
        }
        Relationships: []
      }
      login_alert_log: {
        Row: {
          alerted_at: string | null
          created_at: string
          device_fingerprint: string | null
          id: string
          login_at: string
          login_ip: string | null
          login_location: string | null
          role: string | null
          user_email: string
        }
        Insert: {
          alerted_at?: string | null
          created_at?: string
          device_fingerprint?: string | null
          id?: string
          login_at: string
          login_ip?: string | null
          login_location?: string | null
          role?: string | null
          user_email: string
        }
        Update: {
          alerted_at?: string | null
          created_at?: string
          device_fingerprint?: string | null
          id?: string
          login_at?: string
          login_ip?: string | null
          login_location?: string | null
          role?: string | null
          user_email?: string
        }
        Relationships: []
      }
      notifications: {
        Row: {
          actor_id: string | null
          board_id: string | null
          created_at: string
          id: string
          is_read: boolean
          item_id: string | null
          read_at: string | null
          recipient_id: string
          type: string
          update_id: string | null
        }
        Insert: {
          actor_id?: string | null
          board_id?: string | null
          created_at?: string
          id?: string
          is_read?: boolean
          item_id?: string | null
          read_at?: string | null
          recipient_id: string
          type: string
          update_id?: string | null
        }
        Update: {
          actor_id?: string | null
          board_id?: string | null
          created_at?: string
          id?: string
          is_read?: boolean
          item_id?: string | null
          read_at?: string | null
          recipient_id?: string
          type?: string
          update_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "notif_actor_fk"
            columns: ["actor_id"]
            isOneToOne: false
            referencedRelation: "users"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "notif_board_fk"
            columns: ["board_id"]
            isOneToOne: false
            referencedRelation: "boards"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "notif_item_fk"
            columns: ["item_id"]
            isOneToOne: false
            referencedRelation: "items"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "notif_recipient_fk"
            columns: ["recipient_id"]
            isOneToOne: false
            referencedRelation: "users"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "notif_update_fk"
            columns: ["update_id"]
            isOneToOne: false
            referencedRelation: "updates"
            referencedColumns: ["id"]
          },
        ]
      }
      shift_configs: {
        Row: {
          account_lock_reason: string | null
          account_locked: boolean
          account_locked_at: string | null
          account_locked_by: string | null
          bio_break_max_per_day: number
          bio_break_max_seconds_each: number
          bio_break_warn_count: number
          bio_break_warn_total_seconds: number
          can_work_now: boolean
          created_at: string
          hard_until: string | null
          late_start_threshold_seconds: number
          mode: string
          primary_group_id: string | null
          required_seconds_default: number
          shift_break_overstay_grace_seconds: number
          shift_break_paid_seconds: number
          shift_break_seconds: number
          shift_mode: string
          shift_start_date: string | null
          timezone: string
          updated_at: string
          updated_by: string | null
          user_id: string
        }
        Insert: {
          account_lock_reason?: string | null
          account_locked?: boolean
          account_locked_at?: string | null
          account_locked_by?: string | null
          bio_break_max_per_day?: number
          bio_break_max_seconds_each?: number
          bio_break_warn_count?: number
          bio_break_warn_total_seconds?: number
          can_work_now?: boolean
          created_at?: string
          hard_until?: string | null
          late_start_threshold_seconds?: number
          mode?: string
          primary_group_id?: string | null
          required_seconds_default?: number
          shift_break_overstay_grace_seconds?: number
          shift_break_paid_seconds?: number
          shift_break_seconds?: number
          shift_mode?: string
          shift_start_date?: string | null
          timezone?: string
          updated_at?: string
          updated_by?: string | null
          user_id: string
        }
        Update: {
          account_lock_reason?: string | null
          account_locked?: boolean
          account_locked_at?: string | null
          account_locked_by?: string | null
          bio_break_max_per_day?: number
          bio_break_max_seconds_each?: number
          bio_break_warn_count?: number
          bio_break_warn_total_seconds?: number
          can_work_now?: boolean
          created_at?: string
          hard_until?: string | null
          late_start_threshold_seconds?: number
          mode?: string
          primary_group_id?: string | null
          required_seconds_default?: number
          shift_break_overstay_grace_seconds?: number
          shift_break_paid_seconds?: number
          shift_break_seconds?: number
          shift_mode?: string
          shift_start_date?: string | null
          timezone?: string
          updated_at?: string
          updated_by?: string | null
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "shift_configs_account_locked_by_fkey"
            columns: ["account_locked_by"]
            isOneToOne: false
            referencedRelation: "users"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "shift_configs_primary_group_id_fkey"
            columns: ["primary_group_id"]
            isOneToOne: false
            referencedRelation: "groups"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "shift_configs_updated_by_fkey"
            columns: ["updated_by"]
            isOneToOne: false
            referencedRelation: "users"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "shift_configs_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: true
            referencedRelation: "users"
            referencedColumns: ["id"]
          },
        ]
      }
      shift_events: {
        Row: {
          at: string
          by: string | null
          id: string
          meta: Json
          session_id: string | null
          type: string
          user_id: string
        }
        Insert: {
          at?: string
          by?: string | null
          id?: string
          meta?: Json
          session_id?: string | null
          type: string
          user_id: string
        }
        Update: {
          at?: string
          by?: string | null
          id?: string
          meta?: Json
          session_id?: string | null
          type?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "shift_events_by_fkey"
            columns: ["by"]
            isOneToOne: false
            referencedRelation: "users"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "shift_events_session_id_fkey"
            columns: ["session_id"]
            isOneToOne: false
            referencedRelation: "shift_sessions"
            referencedColumns: ["id"]
          },
        ]
      }
      shift_global_settings: {
        Row: {
          created_at: string
          id: number
          locks_paused: boolean
          locks_paused_at: string | null
          locks_paused_by: string | null
          updated_at: string
        }
        Insert: {
          created_at?: string
          id?: number
          locks_paused?: boolean
          locks_paused_at?: string | null
          locks_paused_by?: string | null
          updated_at?: string
        }
        Update: {
          created_at?: string
          id?: number
          locks_paused?: boolean
          locks_paused_at?: string | null
          locks_paused_by?: string | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "shift_global_settings_locks_paused_by_fkey"
            columns: ["locks_paused_by"]
            isOneToOne: false
            referencedRelation: "users"
            referencedColumns: ["id"]
          },
        ]
      }
      shift_schedules: {
        Row: {
          enabled: boolean
          end_time_local: string | null
          required_seconds: number
          start_time_local: string | null
          user_id: string
          weekday: number
        }
        Insert: {
          enabled?: boolean
          end_time_local?: string | null
          required_seconds?: number
          start_time_local?: string | null
          user_id: string
          weekday: number
        }
        Update: {
          enabled?: boolean
          end_time_local?: string | null
          required_seconds?: number
          start_time_local?: string | null
          user_id?: string
          weekday?: number
        }
        Relationships: [
          {
            foreignKeyName: "shift_schedules_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "users"
            referencedColumns: ["id"]
          },
        ]
      }
      shift_sessions: {
        Row: {
          admin_adjust_seconds: number
          bio_break_admin_grants_today: number
          bio_break_count_today: number
          bio_break_total_seconds_today: number
          bio6_notified_at: string | null
          completed_at: string | null
          created_at: string
          current_break_kind: string | null
          current_break_started_at: string | null
          current_pause_reason: string | null
          current_pause_started_at: string | null
          current_period_index: number
          early_end_flag: boolean | null
          early_end_minutes: number | null
          expected_end_at: string | null
          id: string
          late_start_flag: boolean | null
          late_start_minutes: number | null
          locked_at: string | null
          locked_by: string | null
          locked_reason: string | null
          mode: string
          overstay_lock_email_sent_at: string | null
          paused_total_seconds: number
          period_85_last_index_alerted: number
          period_seconds: number
          required_seconds: number
          scheduled_start_at: string | null
          shift_break_count_today: number
          skip_next_period_lock: boolean
          skip_next_period_lock_set_at: string | null
          skip_next_period_lock_set_by: string | null
          started_at: string | null
          status: string
          updated_at: string
          user_id: string
          work_date: string
        }
        Insert: {
          admin_adjust_seconds?: number
          bio_break_admin_grants_today?: number
          bio_break_count_today?: number
          bio_break_total_seconds_today?: number
          bio6_notified_at?: string | null
          completed_at?: string | null
          created_at?: string
          current_break_kind?: string | null
          current_break_started_at?: string | null
          current_pause_reason?: string | null
          current_pause_started_at?: string | null
          current_period_index?: number
          early_end_flag?: boolean | null
          early_end_minutes?: number | null
          expected_end_at?: string | null
          id?: string
          late_start_flag?: boolean | null
          late_start_minutes?: number | null
          locked_at?: string | null
          locked_by?: string | null
          locked_reason?: string | null
          mode: string
          overstay_lock_email_sent_at?: string | null
          paused_total_seconds?: number
          period_85_last_index_alerted?: number
          period_seconds: number
          required_seconds: number
          scheduled_start_at?: string | null
          shift_break_count_today?: number
          skip_next_period_lock?: boolean
          skip_next_period_lock_set_at?: string | null
          skip_next_period_lock_set_by?: string | null
          started_at?: string | null
          status?: string
          updated_at?: string
          user_id: string
          work_date: string
        }
        Update: {
          admin_adjust_seconds?: number
          bio_break_admin_grants_today?: number
          bio_break_count_today?: number
          bio_break_total_seconds_today?: number
          bio6_notified_at?: string | null
          completed_at?: string | null
          created_at?: string
          current_break_kind?: string | null
          current_break_started_at?: string | null
          current_pause_reason?: string | null
          current_pause_started_at?: string | null
          current_period_index?: number
          early_end_flag?: boolean | null
          early_end_minutes?: number | null
          expected_end_at?: string | null
          id?: string
          late_start_flag?: boolean | null
          late_start_minutes?: number | null
          locked_at?: string | null
          locked_by?: string | null
          locked_reason?: string | null
          mode?: string
          overstay_lock_email_sent_at?: string | null
          paused_total_seconds?: number
          period_85_last_index_alerted?: number
          period_seconds?: number
          required_seconds?: number
          scheduled_start_at?: string | null
          shift_break_count_today?: number
          skip_next_period_lock?: boolean
          skip_next_period_lock_set_at?: string | null
          skip_next_period_lock_set_by?: string | null
          started_at?: string | null
          status?: string
          updated_at?: string
          user_id?: string
          work_date?: string
        }
        Relationships: [
          {
            foreignKeyName: "shift_sessions_locked_by_fkey"
            columns: ["locked_by"]
            isOneToOne: false
            referencedRelation: "users"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "shift_sessions_skip_next_period_lock_set_by_fkey"
            columns: ["skip_next_period_lock_set_by"]
            isOneToOne: false
            referencedRelation: "users"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "shift_sessions_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "users"
            referencedColumns: ["id"]
          },
        ]
      }
      teamblue_rotation_log: {
        Row: {
          chaser_sent_at: string | null
          created_at: string
          id: string
          login_at: string
          login_ip: string | null
          login_location: string | null
          reminder_sent_at: string | null
          rotated: boolean
        }
        Insert: {
          chaser_sent_at?: string | null
          created_at?: string
          id?: string
          login_at: string
          login_ip?: string | null
          login_location?: string | null
          reminder_sent_at?: string | null
          rotated?: boolean
        }
        Update: {
          chaser_sent_at?: string | null
          created_at?: string
          id?: string
          login_at?: string
          login_ip?: string | null
          login_location?: string | null
          reminder_sent_at?: string | null
          rotated?: boolean
        }
        Relationships: []
      }
      update_mentions: {
        Row: {
          created_at: string
          mentioned_user_id: string
          update_id: string
        }
        Insert: {
          created_at?: string
          mentioned_user_id: string
          update_id: string
        }
        Update: {
          created_at?: string
          mentioned_user_id?: string
          update_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "update_mentions_update_fk"
            columns: ["update_id"]
            isOneToOne: false
            referencedRelation: "updates"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "update_mentions_user_fk"
            columns: ["mentioned_user_id"]
            isOneToOne: false
            referencedRelation: "users"
            referencedColumns: ["id"]
          },
        ]
      }
      update_reactions: {
        Row: {
          created_at: string
          emoji: string
          update_id: string
          user_id: string
        }
        Insert: {
          created_at?: string
          emoji: string
          update_id: string
          user_id: string
        }
        Update: {
          created_at?: string
          emoji?: string
          update_id?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "update_reactions_update_fk"
            columns: ["update_id"]
            isOneToOne: false
            referencedRelation: "updates"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "update_reactions_user_fk"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "users"
            referencedColumns: ["id"]
          },
        ]
      }
      updates: {
        Row: {
          author_id: string | null
          body_html: string
          body_json: Json | null
          created_at: string
          deleted_at: string | null
          edited_at: string | null
          id: string
          item_id: string
          updated_at: string
        }
        Insert: {
          author_id?: string | null
          body_html: string
          body_json?: Json | null
          created_at?: string
          deleted_at?: string | null
          edited_at?: string | null
          id?: string
          item_id: string
          updated_at?: string
        }
        Update: {
          author_id?: string | null
          body_html?: string
          body_json?: Json | null
          created_at?: string
          deleted_at?: string | null
          edited_at?: string | null
          id?: string
          item_id?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "updates_author_fk"
            columns: ["author_id"]
            isOneToOne: false
            referencedRelation: "users"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "updates_item_fk"
            columns: ["item_id"]
            isOneToOne: false
            referencedRelation: "items"
            referencedColumns: ["id"]
          },
        ]
      }
      users: {
        Row: {
          avatar_url: string | null
          created_at: string
          email: string
          full_name: string | null
          id: string
          is_super_admin: boolean
          role: string
          status: string
          theme: string
          timezone: string
          title: string | null
          updated_at: string
          username: string
        }
        Insert: {
          avatar_url?: string | null
          created_at?: string
          email: string
          full_name?: string | null
          id: string
          is_super_admin?: boolean
          role?: string
          status?: string
          theme?: string
          timezone?: string
          title?: string | null
          updated_at?: string
          username: string
        }
        Update: {
          avatar_url?: string | null
          created_at?: string
          email?: string
          full_name?: string | null
          id?: string
          is_super_admin?: boolean
          role?: string
          status?: string
          theme?: string
          timezone?: string
          title?: string | null
          updated_at?: string
          username?: string
        }
        Relationships: []
      }
      views: {
        Row: {
          archived_at: string | null
          board_id: string
          created_at: string
          created_by: string | null
          id: string
          is_default: boolean
          name: string
          settings: Json
          sort_order: number
          type: string
          updated_at: string
        }
        Insert: {
          archived_at?: string | null
          board_id: string
          created_at?: string
          created_by?: string | null
          id?: string
          is_default?: boolean
          name: string
          settings?: Json
          sort_order?: number
          type: string
          updated_at?: string
        }
        Update: {
          archived_at?: string | null
          board_id?: string
          created_at?: string
          created_by?: string | null
          id?: string
          is_default?: boolean
          name?: string
          settings?: Json
          sort_order?: number
          type?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "views_board_fk"
            columns: ["board_id"]
            isOneToOne: false
            referencedRelation: "boards"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "views_created_by_fk"
            columns: ["created_by"]
            isOneToOne: false
            referencedRelation: "users"
            referencedColumns: ["id"]
          },
        ]
      }
      workspace_members: {
        Row: {
          created_at: string
          role: string
          user_id: string
          workspace_id: string
        }
        Insert: {
          created_at?: string
          role?: string
          user_id: string
          workspace_id: string
        }
        Update: {
          created_at?: string
          role?: string
          user_id?: string
          workspace_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "workspace_members_user_fk"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "users"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "workspace_members_workspace_fk"
            columns: ["workspace_id"]
            isOneToOne: false
            referencedRelation: "workspaces"
            referencedColumns: ["id"]
          },
        ]
      }
      workspaces: {
        Row: {
          created_at: string
          icon_color: string
          icon_emoji: string
          id: string
          is_main: boolean
          name: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          icon_color?: string
          icon_emoji?: string
          id?: string
          is_main?: boolean
          name: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          icon_color?: string
          icon_emoji?: string
          id?: string
          is_main?: boolean
          name?: string
          updated_at?: string
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      _generate_unique_username: { Args: { p_base: string }; Returns: string }
      _shift_next_scheduled_at: {
        Args: { p_from_local_date: string; p_tz: string; p_user_id: string }
        Returns: string
      }
      _shift_period_seconds: { Args: { p_mode: string }; Returns: number }
      accept_invite:
        | {
            Args: { p_full_name: string; p_password: string; p_token: string }
            Returns: Json
          }
        | {
            Args: {
              p_full_name: string
              p_password: string
              p_token: string
              p_username: string
            }
            Returns: Json
          }
      admin_close_orphaned_shifts: { Args: never; Returns: number }
      admin_create_user: {
        Args: {
          p_full_name: string
          p_password: string
          p_role: string
          p_username: string
        }
        Returns: Json
      }
      admin_delete_user: { Args: { p_user_id: string }; Returns: undefined }
      admin_list_users: {
        Args: never
        Returns: {
          avatar_url: string
          created_at: string
          full_name: string
          id: string
          is_super_admin: boolean
          last_active: string
          role: string
          status: string
          timezone: string
          title: string
          username: string
        }[]
      }
      admin_reset_password: {
        Args: { p_new_password: string; p_user_id: string }
        Returns: undefined
      }
      admin_set_role: {
        Args: { p_role: string; p_user_id: string }
        Returns: undefined
      }
      admin_set_status: {
        Args: { p_status: string; p_user_id: string }
        Returns: undefined
      }
      admin_set_username: {
        Args: { p_new_username: string; p_user_id: string }
        Returns: undefined
      }
      bio_break_request_create: { Args: never; Returns: Json }
      bio_break_request_decide: {
        Args: { p_decision: string; p_note?: string; p_request_id: string }
        Returns: Json
      }
      board_watermark: { Args: { p_board_id: string }; Returns: string }
      can_access_board: { Args: { _board_id: string }; Returns: boolean }
      can_access_item: { Args: { _item_id: string }; Returns: boolean }
      can_edit_board: { Args: { _board_id: string }; Returns: boolean }
      can_manage_board: { Args: { _board_id: string }; Returns: boolean }
      clear_gemini_key: { Args: never; Returns: undefined }
      create_invite: {
        Args: {
          p_board_id?: string
          p_expires_in_hours?: number
          p_group_id?: string
          p_invitee_email?: string
          p_invitee_name?: string
          p_invitee_shift_end_time?: string
          p_invitee_shift_mode?: string
          p_invitee_shift_start_date?: string
          p_invitee_shift_start_time?: string
          p_invitee_timezone?: string
          p_role: string
        }
        Returns: Json
      }
      current_user_role: { Args: never; Returns: string }
      duplicate_board: { Args: { p_board_id: string }; Returns: string }
      duplicate_group: { Args: { p_group_id: string }; Returns: string }
      gemini_invoke: {
        Args: {
          p_feature?: string
          p_model?: string
          p_prompt: string
          p_system?: string
        }
        Returns: Json
      }
      generate_task_code: {
        Args: { _board_id: string; _parent_item_id: string }
        Returns: string
      }
      get_admin_secrets_status: { Args: never; Returns: Json }
      get_gemini_status: { Args: never; Returns: Json }
      get_invite_by_token: { Args: { p_token: string }; Returns: Json }
      int_to_letters: { Args: { _n: number }; Returns: string }
      is_active_user: { Args: never; Returns: boolean }
      is_admin: { Args: never; Returns: boolean }
      is_status_column: { Args: { _column_id: string }; Returns: boolean }
      is_super_admin: { Args: never; Returns: boolean }
      mark_teamblue_rotated: { Args: never; Returns: boolean }
      recent_logins_except_teamblue: {
        Args: never
        Returns: {
          email: string
          login_at: string
          login_ip: string
          role: string
          user_agent: string
          user_id: string
        }[]
      }
      resolve_login_email: { Args: { p_identifier: string }; Returns: string }
      revoke_invite: { Args: { p_invite_id: string }; Returns: undefined }
      set_admin_secrets: {
        Args: { p_key: string; p_url: string }
        Returns: undefined
      }
      set_gemini_key: { Args: { p_key: string }; Returns: undefined }
      set_my_password: { Args: { p_new_password: string }; Returns: undefined }
      shift_admin_adjust_time: {
        Args: {
          p_delta_seconds: number
          p_note?: string
          p_target_user_id: string
        }
        Returns: Json
      }
      shift_admin_apply_default_schedule: {
        Args: {
          p_start_time_local: string
          p_user_id: string
          p_weekday_required_seconds?: number
        }
        Returns: Json
      }
      shift_admin_force_end: { Args: { p_session_id: string }; Returns: Json }
      shift_admin_get_global_settings: { Args: never; Returns: Json }
      shift_admin_lock: {
        Args: { p_reason: string; p_session_id: string }
        Returns: Json
      }
      shift_admin_rearm: { Args: { p_session_id: string }; Returns: Json }
      shift_admin_set_account_lock: {
        Args: { p_locked: boolean; p_target_user_id: string }
        Returns: Json
      }
      shift_admin_set_can_work_now: {
        Args: { p_can: boolean; p_target_user_id: string }
        Returns: Json
      }
      shift_admin_set_config: {
        Args: {
          p_bio_break_max_per_day: number
          p_bio_break_max_seconds_each: number
          p_bio_break_warn_count: number
          p_bio_break_warn_total_seconds: number
          p_hard_until?: string
          p_late_start_threshold_seconds?: number
          p_mode: string
          p_primary_group_id: string
          p_shift_break_seconds: number
          p_target_user_id: string
          p_timezone?: string
        }
        Returns: Json
      }
      shift_admin_set_locks_paused: {
        Args: { p_paused: boolean }
        Returns: Json
      }
      shift_admin_set_schedule: {
        Args: {
          p_enabled: boolean
          p_required_seconds: number
          p_start_time_local?: string
          p_target_user_id: string
          p_weekday: number
        }
        Returns: Json
      }
      shift_admin_set_schedule_bulk: {
        Args: { p_rows: Json; p_user_id: string }
        Returns: Json
      }
      shift_admin_set_shift_mode: {
        Args: { p_mode: string; p_user_id: string }
        Returns: Json
      }
      shift_admin_set_start_date: {
        Args: { p_start_date: string; p_user_id: string }
        Returns: Json
      }
      shift_admin_skip_next_lock: {
        Args: { p_session_id: string }
        Returns: Json
      }
      shift_admin_unlock: { Args: { p_session_id: string }; Returns: Json }
      shift_break_freeze: { Args: { p_session_id: string }; Returns: Json }
      shift_break_overstay_lock: {
        Args: { p_session_id: string }
        Returns: Json
      }
      shift_break_sweep: { Args: never; Returns: Json }
      shift_can_start: { Args: never; Returns: Json }
      shift_complete_if_due: { Args: { p_session_id: string }; Returns: Json }
      shift_end_break: { Args: { p_session_id: string }; Returns: Json }
      shift_get_or_create_today_session: {
        Args: never
        Returns: {
          admin_adjust_seconds: number
          bio_break_admin_grants_today: number
          bio_break_count_today: number
          bio_break_total_seconds_today: number
          bio6_notified_at: string | null
          completed_at: string | null
          created_at: string
          current_break_kind: string | null
          current_break_started_at: string | null
          current_pause_reason: string | null
          current_pause_started_at: string | null
          current_period_index: number
          early_end_flag: boolean | null
          early_end_minutes: number | null
          expected_end_at: string | null
          id: string
          late_start_flag: boolean | null
          late_start_minutes: number | null
          locked_at: string | null
          locked_by: string | null
          locked_reason: string | null
          mode: string
          overstay_lock_email_sent_at: string | null
          paused_total_seconds: number
          period_85_last_index_alerted: number
          period_seconds: number
          required_seconds: number
          scheduled_start_at: string | null
          shift_break_count_today: number
          skip_next_period_lock: boolean
          skip_next_period_lock_set_at: string | null
          skip_next_period_lock_set_by: string | null
          started_at: string | null
          status: string
          updated_at: string
          user_id: string
          work_date: string
        }
        SetofOptions: {
          from: "*"
          to: "shift_sessions"
          isOneToOne: true
          isSetofReturn: false
        }
      }
      shift_locks_globally_paused: { Args: never; Returns: boolean }
      shift_mark_85_alerted: { Args: { p_session_id: string }; Returns: Json }
      shift_mark_overstay_lock_emailed: {
        Args: { p_session_id: string }
        Returns: Json
      }
      shift_my_account_lock: { Args: never; Returns: Json }
      shift_self_period_lock: { Args: { p_session_id: string }; Returns: Json }
      shift_start: { Args: never; Returns: Json }
      shift_sweep_due_and_orphans: { Args: never; Returns: Json }
      shift_take_bio_break: { Args: { p_session_id: string }; Returns: Json }
      shift_take_shift_break: { Args: { p_session_id: string }; Returns: Json }
      shift_tick: { Args: { p_session_id: string }; Returns: Json }
      teamblue_last_login: {
        Args: never
        Returns: {
          login_at: string
          login_ip: string
        }[]
      }
      verify_current_password: {
        Args: { p_password: string }
        Returns: boolean
      }
    }
    Enums: {
      [_ in never]: never
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {},
  },
} as const
