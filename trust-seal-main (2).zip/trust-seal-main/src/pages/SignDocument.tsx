import { useEffect, useMemo, useRef, useState } from "react";
import { useParams } from "react-router-dom";
import { motion, AnimatePresence } from "framer-motion";
import { Document, Page, pdfjs } from "react-pdf";
import { AlertTriangle, CheckCircle, Download, FileText, Shield, ChevronLeft, ChevronRight, ChevronDown, UserCheck, Mail } from "lucide-react";
import { toast } from "sonner";
import { SignaturePad } from "@/components/signing/SignaturePad";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogDescription } from "@/components/ui/dialog";
import { useSignRequest, useSubmitSignature } from "@/hooks/use-sign-request";
import "react-pdf/dist/Page/AnnotationLayer.css";
import "react-pdf/dist/Page/TextLayer.css";

pdfjs.GlobalWorkerOptions.workerSrc = `https://unpkg.com/pdfjs-dist@${pdfjs.version}/build/pdf.worker.min.mjs`;

const FIELD_STYLES: Record<string, { empty: string; filled: string; label: string }> = {
  signature: { empty: "border-blue-500 bg-blue-500/0 hover:bg-blue-500/10", filled: "border-blue-500 bg-white", label: "Click to sign" },
  initials: { empty: "border-purple-500 bg-purple-500/10", filled: "border-purple-500 bg-white", label: "Initials" },
  date: { empty: "border-green-500 bg-green-500/10", filled: "border-green-500 bg-white", label: "Date (auto)" },
  text: { empty: "border-gray-500 bg-gray-500/10", filled: "border-gray-500 bg-white", label: "Optional" },
};

// Render a typed-name signature to a PNG dataURL (mirrors SignaturePad's typed mode).
function renderTypedSignatureFromName(name: string): string {
  const width = 600;
  const height = 200;
  const ratio = Math.max(window.devicePixelRatio || 1, 1);
  const canvas = window.document.createElement("canvas");
  canvas.width = width * ratio;
  canvas.height = height * ratio;
  const ctx = canvas.getContext("2d")!;
  ctx.scale(ratio, ratio);
  ctx.clearRect(0, 0, width, height);
  ctx.fillStyle = "rgb(15, 23, 42)";
  ctx.textBaseline = "middle";
  ctx.textAlign = "center";
  const family = "'Pinyon Script', 'Great Vibes', 'Allura', cursive";
  let size = 110;
  ctx.font = `${size}px ${family}`;
  while (ctx.measureText(name).width > width - 40 && size > 20) {
    size -= 4;
    ctx.font = `${size}px ${family}`;
  }
  ctx.fillText(name, width / 2, height / 2);
  return canvas.toDataURL("image/png");
}

const SignDocument = () => {
  const { token } = useParams<{ token: string }>();
  const isDemo = token === "demo";

  const { data: signRequest, isLoading, error } = useSignRequest(token);
  const submitSignature = useSubmitSignature();

  const [step, setStep] = useState<"review" | "signing" | "complete">("review");
  const [padOpen, setPadOpen] = useState(false);
  const [activeSigFieldId, setActiveSigFieldId] = useState<string | null>(null);
  const [activeInitFieldId, setActiveInitFieldId] = useState<string | null>(null);
  const [initialsInput, setInitialsInput] = useState("");
  const [fullName, setFullName] = useState("");
  const [signerEmail, setSignerEmail] = useState("");
  const [fieldValues, setFieldValues] = useState<Record<string, string>>({});
  const [downloadUrl, setDownloadUrl] = useState<string | null>(null);
  const [downloadName, setDownloadName] = useState("signed-document.pdf");

  // Identity dialog (collected upfront before signing)
  const [identityOpen, setIdentityOpen] = useState(false);
  const [identityName, setIdentityName] = useState("");
  const [identityEmail, setIdentityEmail] = useState("");
  const [identityErrors, setIdentityErrors] = useState<{ name?: string; email?: string }>({});

  const [currentPage, setCurrentPage] = useState(1);
  const [numPages, setNumPages] = useState(0);
  const [pageWidth, setPageWidth] = useState(800);
  const mainRef = useRef<HTMLDivElement | null>(null);
  const fieldRefs = useRef<Record<string, HTMLDivElement | null>>({});
  const autoStartedRef = useRef(false);

  const documentTitle = useMemo(() => {
    if (isDemo) return "Employment_Agreement_2024.pdf";
    return signRequest?.document.fileName ?? "Document";
  }, [isDemo, signRequest?.document.fileName]);

  const pdfUrl = isDemo ? null : signRequest?.document.pdfUrl ?? null;
  const fields = signRequest?.fields ?? [];
  const progress = step === "review" ? 33 : step === "signing" ? 66 : 100;

  // Pre-seed signer email from request
  useEffect(() => {
    if (signRequest?.signerEmail) {
      setSignerEmail(signRequest.signerEmail);
      setIdentityEmail(signRequest.signerEmail);
    }
    if (signRequest?.signerName) {
      setIdentityName(signRequest.signerName);
    }
  }, [signRequest?.signerEmail, signRequest?.signerName]);

  // Auto-advance to "signing" for pre-seeded candidates (email-link case) so
  // they land directly on a live signing page — no "Start Signing" pre-click.
  // Mirrors startSigning()'s pre-seeded branch exactly (sets fullName so the
  // one-tap typed-name signing in handleFieldClick works on first click).
  // Ref guard ensures this fires at most once and never loops, and never
  // re-advances after the user clicks "Edit" identity.
  useEffect(() => {
    if (autoStartedRef.current) return;
    if (isLoading || error) return;
    if (step !== "review") return;
    if (!pdfUrl) return;
    const preName = (signRequest?.signerName ?? "").trim();
    const preEmail = (signRequest?.signerEmail ?? "").trim();
    if (preName.length < 2 || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(preEmail)) return;
    autoStartedRef.current = true;
    setFullName(preName);
    setSignerEmail(preEmail);
    setIdentityName(preName);
    setIdentityEmail(preEmail);
    setStep("signing");
  }, [isLoading, error, pdfUrl, signRequest?.signerName, signRequest?.signerEmail, step]);

  // Auto-fill date fields once on load
  useEffect(() => {
    if (!fields.length) return;
    const today = new Date().toLocaleDateString("en-US");
    setFieldValues((prev) => {
      const next = { ...prev };
      let changed = false;
      for (const f of fields) {
        if (f.field_type === "date" && !next[f.id]) {
          next[f.id] = today;
          changed = true;
        }
      }
      return changed ? next : prev;
    });
  }, [fields]);

  useEffect(() => {
    if (!signRequest) return;
    if (signRequest.status === "signed") {
      setStep("complete");
      setFullName(signRequest.signerName ?? "");
      setDownloadUrl(signRequest.signedDocument?.downloadUrl ?? null);
      setDownloadName(`signed_${signRequest.document.fileName}`);
    }
  }, [signRequest]);

  useEffect(() => {
    if (!mainRef.current) return;
    const update = () => {
      if (mainRef.current) {
        const w = Math.min(900, mainRef.current.clientWidth - 48);
        if (w > 200) setPageWidth(w);
      }
    };
    update();
    const ro = new ResizeObserver(update);
    ro.observe(mainRef.current);
    window.addEventListener("resize", update);
    return () => {
      ro.disconnect();
      window.removeEventListener("resize", update);
    };
  }, []);

  const handleFieldClick = (fieldId: string, type: string) => {
    if (step !== "signing") return;
    if (type === "signature") {
      // One-tap sign: if we already know the signer's name and this field is empty,
      // auto-apply a typed signature across all signature fields. A second click
      // on a filled field still opens the pad to change/redraw.
      const name = fullName.trim();
      if (name && !fieldValues[fieldId]) {
        const dataUrl = renderTypedSignatureFromName(name);
        setFieldValues((prev) => {
          const next = { ...prev };
          for (const f of fields) {
            if (f.field_type === "signature") next[f.id] = dataUrl;
          }
          return next;
        });
        toast.success("Signed — tap the signature again to change it");
        return;
      }
      setActiveSigFieldId(fieldId);
      setPadOpen(true);
    } else if (type === "initials") {
      setActiveInitFieldId(fieldId);
      setInitialsInput(fieldValues[fieldId] ?? "");
    }
  };

  const handleSignatureConfirm = (dataUrl: string) => {
    setFieldValues((prev) => {
      const next = { ...prev };
      for (const f of fields) {
        if (f.field_type === "signature") next[f.id] = dataUrl;
      }
      return next;
    });
    setPadOpen(false);
    setActiveSigFieldId(null);
    toast.success("Signature applied to all signature fields");
  };

  const handleInitialsConfirm = () => {
    const v = initialsInput.trim().toUpperCase();
    if (!v) return;
    setFieldValues((prev) => {
      const next = { ...prev };
      for (const f of fields) {
        if (f.field_type === "initials") next[f.id] = v;
      }
      return next;
    });
    setActiveInitFieldId(null);
    setInitialsInput("");
  };

  const handleTextChange = (fieldId: string, value: string) => {
    setFieldValues((prev) => ({ ...prev, [fieldId]: value }));
  };

  // Only signature + initials are required. text (ID/passport) and date are optional.
  const missingFields = useMemo(() => {
    return fields.filter(
      (f) => (f.field_type === "signature" || f.field_type === "initials") && !fieldValues[f.id],
    );
  }, [fields, fieldValues]);

  const requiredRemaining = missingFields.length;
  const hasAnySignatureField = fields.some((f) => f.field_type === "signature");
  const canFinish = !!fullName.trim() && requiredRemaining === 0 && fields.length > 0;

  // First unsigned signature field on the current page — anchor for the inline CTA.
  const firstUnsignedSigOnPage = useMemo(
    () =>
      fields.find(
        (f) => f.field_type === "signature" && f.page === currentPage && !fieldValues[f.id],
      ) ?? null,
    [fields, fieldValues, currentPage],
  );

  const todayStr = useMemo(() => new Date().toLocaleDateString("en-US"), []);

  const handleDownloadCopy = () => {
    if (!downloadUrl) return;
    const link = window.document.createElement("a");
    link.href = downloadUrl;
    link.download = downloadName;
    window.document.body.appendChild(link);
    link.click();
    window.document.body.removeChild(link);
  };

  // --- Identity gate ---
  const validateEmail = (e: string) => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(e.trim());

  const openIdentityGate = () => {
    setIdentityErrors({});
    setIdentityOpen(true);
  };

  // Smart entry: if signer name + email are already known from the request
  // (the common case for emailed signing links), skip the identity dialog
  // and drop straight into signing mode. Only prompt when truly missing.
  const startSigning = () => {
    const preName = (signRequest?.signerName ?? identityName ?? "").trim();
    const preEmail = (signRequest?.signerEmail ?? identityEmail ?? "").trim();
    if (preName.length >= 2 && validateEmail(preEmail)) {
      setFullName(preName);
      setSignerEmail(preEmail);
      setIdentityName(preName);
      setIdentityEmail(preEmail);
      setStep("signing");
      toast.success(`Welcome, ${preName.split(" ")[0]} — tap the signature box to sign`);
      return;
    }
    openIdentityGate();
  };

  const confirmIdentity = () => {
    const errs: { name?: string; email?: string } = {};
    if (!identityName.trim() || identityName.trim().length < 2) {
      errs.name = "Please enter your full legal name";
    }
    if (!validateEmail(identityEmail)) {
      errs.email = "Please enter a valid email address";
    }
    if (Object.keys(errs).length) {
      setIdentityErrors(errs);
      return;
    }
    setFullName(identityName.trim());
    setSignerEmail(identityEmail.trim());
    setIdentityOpen(false);
    setStep("signing");
    toast.success(`Welcome, ${identityName.trim().split(" ")[0]} — tap each highlighted field to sign`);
  };

  const scrollToField = (fieldId: string, page: number) => {
    if (page !== currentPage) setCurrentPage(page);
    setTimeout(() => {
      const el = fieldRefs.current[fieldId];
      if (el) {
        el.scrollIntoView({ behavior: "smooth", block: "center" });
        el.classList.add("ring-4", "ring-accent");
        setTimeout(() => el.classList.remove("ring-4", "ring-accent"), 1600);
      }
    }, 120);
  };

  const handleFinish = async () => {
    if (!fullName.trim()) {
      toast.error("Please confirm your identity before signing", {
        action: { label: "Confirm now", onClick: openIdentityGate },
      });
      return;
    }
    if (requiredRemaining > 0) {
      const first = missingFields[0];
      toast.error(`${requiredRemaining} field${requiredRemaining === 1 ? "" : "s"} still need your attention`, {
        action: { label: "Jump to next", onClick: () => scrollToField(first.id, first.page) },
      });
      return;
    }
    if (isDemo) {
      setStep("complete");
      return;
    }
    if (!token) return;
    try {
      const result = await submitSignature.mutateAsync({
        token,
        signerName: fullName.trim(),
        fieldValues,
      });
      setDownloadUrl(result.downloadUrl);
      setDownloadName(`signed_${result.fileName}`);
      window.setTimeout(() => {
        const link = window.document.createElement("a");
        link.href = result.downloadUrl;
        link.download = `signed_${result.fileName}`;
        window.document.body.appendChild(link);
        link.click();
        window.document.body.removeChild(link);
      }, 150);
      setStep("complete");
    } catch (err) {
      toast.error((err as Error)?.message ?? "Failed to submit signature");
    }
  };

  if (!isDemo && isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background-pure">
        <p className="text-body text-muted">Loading document...</p>
      </div>
    );
  }

  if (!isDemo && error) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background-pure px-4">
        <div className="text-center">
          <AlertTriangle className="w-12 h-12 text-warning mx-auto mb-4" />
          <h1 className="text-xl font-semibold text-foreground mb-2">Unable to Load Document</h1>
          <p className="text-body text-muted">{(error as Error).message}</p>
        </div>
      </div>
    );
  }

  const fieldsOnPage = fields.filter((f) => f.page === currentPage);

  return (
    <div className="min-h-screen bg-background-pure flex flex-col">
      <header className="border-b bg-card sticky top-0 z-30">
        <div className="max-w-5xl mx-auto px-4 py-3 flex items-center justify-between gap-4">
          <div className="flex items-center gap-2 min-w-0">
            <FileText className="w-4 h-4 text-foreground shrink-0" />
            <span className="text-body font-medium text-foreground truncate">{documentTitle}</span>
          </div>
          <div className="flex items-center gap-2 shrink-0">
            <Shield className="w-3.5 h-3.5 text-muted" />
            <span className="text-meta text-muted">Secure Document</span>
          </div>
        </div>
        {/* Identity strip — visible at the top once confirmed */}
        {step === "signing" && fullName && (
          <div className="border-t bg-secondary/40">
            <div className="max-w-5xl mx-auto px-4 py-2 flex items-center justify-between gap-3 flex-wrap">
              <div className="flex items-center gap-2 text-meta">
                <UserCheck className="w-3.5 h-3.5 text-success" />
                <span className="text-foreground font-medium">{fullName}</span>
                <span className="text-muted">·</span>
                <Mail className="w-3.5 h-3.5 text-muted" />
                <span className="text-muted truncate max-w-[200px]">{signerEmail}</span>
              </div>
              <button
                onClick={openIdentityGate}
                className="text-meta text-accent hover:underline"
              >
                Edit
              </button>
            </div>
          </div>
        )}
        <div className="h-1 bg-secondary">
          <motion.div
            className="h-full bg-accent"
            initial={{ width: "0%" }}
            animate={{ width: `${progress}%` }}
            transition={{ duration: 0.4, ease: [0.16, 1, 0.3, 1] }}
          />
        </div>
      </header>

      {step === "complete" ? (
        <main className="flex-1 max-w-3xl mx-auto w-full px-4 py-12">
          <motion.div
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-center py-16"
          >
            <div className="w-16 h-16 rounded-full bg-success-foreground border border-success-border flex items-center justify-center mx-auto mb-6">
              <CheckCircle className="w-8 h-8 text-success" />
            </div>
            <h1 className="text-2xl font-semibold text-foreground mb-2">Document Signed</h1>
            <p className="text-body text-muted mb-8">Your signed document is ready.</p>
            <Button variant="outline" className="gap-2 btn-settle" onClick={handleDownloadCopy} disabled={!downloadUrl}>
              <Download className="w-4 h-4" />
              Download Copy
            </Button>
          </motion.div>
        </main>
      ) : (
        <>
          <main ref={mainRef} className="flex-1 w-full px-4 py-6 flex flex-col items-center pb-32">
            {pdfUrl ? (
              <div className="relative shadow-lg bg-white" style={{ width: pageWidth }}>
                <Document
                  file={pdfUrl}
                  onLoadSuccess={({ numPages }) => setNumPages(numPages)}
                  onLoadError={(err) => console.error("PDF load error:", err)}
                  loading={<div className="p-12 text-muted">Loading PDF...</div>}
                >
                  <Page
                    pageNumber={currentPage}
                    width={pageWidth}
                    renderAnnotationLayer={false}
                    renderTextLayer={false}
                  />
                </Document>

                {fieldsOnPage.map((f) => {
                  const styles = FIELD_STYLES[f.field_type];
                  const value = fieldValues[f.id];
                  const filled = !!value;
                  const isInteractive = step === "signing";
                  // Only signature/initials are required-missing.
                  const isMissing =
                    isInteractive && !filled && (f.field_type === "signature" || f.field_type === "initials");

                  return (
                    <div key={f.id} className="contents">
                      <div
                        ref={(el) => { fieldRefs.current[f.id] = el; }}
                        className={`absolute border-2 rounded-sm flex items-center justify-center overflow-hidden transition-colors ${
                          filled ? styles.filled : `${styles.empty} border-dashed`
                        } ${isInteractive && f.field_type !== "text" ? "cursor-pointer hover:brightness-95" : ""}`}
                        style={{
                          left: `${f.x_percent}%`,
                          top: `${f.y_percent}%`,
                          width: `${f.width_percent}%`,
                          height: `${f.height_percent}%`,
                        }}
                        onClick={() => f.field_type !== "text" && handleFieldClick(f.id, f.field_type)}
                      >
                        {f.field_type === "signature" && filled ? (
                          <img src={value} alt="signature" className="max-w-full max-h-full object-contain" />
                        ) : f.field_type === "text" ? (
                          <input
                            type="text"
                            value={value ?? ""}
                            onChange={(e) => handleTextChange(f.id, e.target.value)}
                            disabled={step === "review"}
                            placeholder={isInteractive ? "Optional — type if needed" : ""}
                            className="w-full h-full bg-transparent border-0 outline-none text-foreground px-1 text-xs"
                            onClick={(e) => e.stopPropagation()}
                          />
                        ) : filled ? (
                          <span className="text-foreground text-xs font-medium px-1 truncate">{value}</span>
                        ) : (
                          <span className="text-meta text-foreground/70 select-none">{styles.label}</span>
                        )}

                        {isMissing && (
                          <span className="absolute -top-2 -right-2 w-4 h-4 rounded-full bg-destructive text-[10px] text-destructive-foreground font-semibold flex items-center justify-center shadow">!</span>
                        )}
                      </div>

                      {/* Auto date paired with every signature field (visual, sits just below) */}
                      {f.field_type === "signature" && (
                        <div
                          className="absolute pointer-events-none text-[10px] text-foreground/80 font-medium px-1 truncate"
                          style={{
                            left: `${f.x_percent}%`,
                            top: `calc(${f.y_percent + f.height_percent}% + 2px)`,
                            width: `${Math.max(f.width_percent, 12)}%`,
                          }}
                        >
                          Date: {todayStr}
                        </div>
                      )}
                    </div>
                  );
                })}

                {/* Inline "Click here to sign" CTA anchored to the first unsigned signature field on this page */}
                {step === "signing" && firstUnsignedSigOnPage && (
                  <div
                    className="absolute z-10 pointer-events-none"
                    style={{
                      left: `${firstUnsignedSigOnPage.x_percent}%`,
                      top: `calc(${firstUnsignedSigOnPage.y_percent}% - 18px)`,
                    }}
                  >
                    <div className="bg-accent text-accent-foreground text-[11px] font-semibold px-2.5 py-1 rounded shadow-md whitespace-nowrap">
                      👆 Click here to sign
                    </div>
                  </div>
                )}
              </div>
            ) : (
              <div className="aspect-[8.5/11] w-full max-w-2xl flex items-center justify-center bg-background-pure border rounded">
                <div className="text-center text-muted">
                  <FileText className="w-16 h-16 mx-auto mb-4 opacity-20" />
                  <p className="text-body">Demo PDF Preview</p>
                </div>
              </div>
            )}

            {numPages > 1 && (
              <div className="flex items-center gap-3 mt-4">
                <Button variant="outline" size="sm" onClick={() => setCurrentPage((p) => Math.max(1, p - 1))} disabled={currentPage === 1}>
                  <ChevronLeft className="w-4 h-4" /> Previous
                </Button>
                <span className="text-body text-muted">Page {currentPage} of {numPages}</span>
                <Button variant="outline" size="sm" onClick={() => setCurrentPage((p) => Math.min(numPages, p + 1))} disabled={currentPage === numPages}>
                  Next <ChevronRight className="w-4 h-4" />
                </Button>
              </div>
            )}
          </main>

          {/* Floating action panel — lifted off bottom edge so OS toasts / browser bars never obscure it */}
          <div className="fixed bottom-6 sm:bottom-8 inset-x-0 z-30 px-4 pointer-events-none">
            <div className="max-w-5xl mx-auto rounded-xl border bg-card shadow-[0_12px_40px_-8px_rgba(0,0,0,0.35)] ring-1 ring-border/60 px-4 py-3 flex items-center gap-4 flex-wrap pointer-events-auto">
              {step === "review" ? (
                <>
                  <p className="text-body text-muted flex-1">
                    Review the document, then start signing to fill the highlighted fields.
                  </p>
                  <Button
                    onClick={startSigning}
                    disabled={!pdfUrl && !isDemo}
                    size="lg"
                    className="btn-settle bg-accent hover:bg-accent/90 text-accent-foreground font-medium px-6"
                  >
                    Start Signing
                  </Button>
                </>
              ) : (
                <>
                  <div className="flex-1 flex items-center gap-3">
                    <AnimatePresence mode="wait">
                      {requiredRemaining === 0 ? (
                        <motion.div
                          key="done"
                          initial={{ opacity: 0, y: 4 }}
                          animate={{ opacity: 1, y: 0 }}
                          exit={{ opacity: 0 }}
                          className="flex items-center gap-2 text-body"
                        >
                          <CheckCircle className="w-4 h-4 text-success" />
                          <span className="text-success font-medium">All fields complete — ready to submit</span>
                        </motion.div>
                      ) : (
                        <motion.button
                          key="missing"
                          initial={{ opacity: 0, y: 4 }}
                          animate={{ opacity: 1, y: 0 }}
                          exit={{ opacity: 0 }}
                          onClick={() => {
                            const f = missingFields[0];
                            if (f) scrollToField(f.id, f.page);
                          }}
                          className="group flex items-center gap-2 text-body text-foreground hover:text-accent transition-colors"
                        >
                          <span className="relative flex h-2.5 w-2.5">
                            <span className="absolute inline-flex h-full w-full rounded-full bg-destructive opacity-60 animate-ping" />
                            <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-destructive" />
                          </span>
                          <span className="font-medium">
                            {requiredRemaining} field{requiredRemaining === 1 ? "" : "s"} remaining
                          </span>
                          <span className="text-meta text-muted group-hover:text-accent flex items-center gap-1">
                            Jump to next <ChevronDown className="w-3 h-3" />
                          </span>
                        </motion.button>
                      )}
                    </AnimatePresence>
                  </div>
                  <Button
                    onClick={handleFinish}
                    disabled={submitSignature.isPending}
                    size="lg"
                    className={`btn-settle font-medium px-6 ${canFinish ? "bg-success hover:bg-success/90 text-success-foreground" : "bg-accent hover:bg-accent/90 text-accent-foreground"}`}
                  >
                    {submitSignature.isPending ? "Submitting..." : canFinish ? "Finish & Submit" : "Finish Signing"}
                  </Button>
                </>
              )}
            </div>
          </div>
        </>
      )}

      {/* Identity confirmation dialog — premium gate before signing */}
      <Dialog open={identityOpen} onOpenChange={setIdentityOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <div className="w-12 h-12 rounded-full bg-accent/10 border border-accent/20 flex items-center justify-center mb-2">
              <UserCheck className="w-6 h-6 text-accent" />
            </div>
            <DialogTitle className="text-xl">Confirm your identity</DialogTitle>
            <DialogDescription>
              Before you sign, please verify your full legal name and email. This information is recorded with your signature for legal validity.
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-4 py-2">
            <div className="space-y-1.5">
              <Label htmlFor="identity-name" className="text-meta font-medium">
                Full Legal Name <span className="text-destructive">*</span>
              </Label>
              <Input
                id="identity-name"
                value={identityName}
                onChange={(e) => { setIdentityName(e.target.value); if (identityErrors.name) setIdentityErrors({ ...identityErrors, name: undefined }); }}
                placeholder="e.g. Jane Marie Doe"
                autoFocus
                className={identityErrors.name ? "border-destructive focus-visible:ring-destructive" : ""}
              />
              {identityErrors.name && <p className="text-meta text-destructive">{identityErrors.name}</p>}
            </div>

            <div className="space-y-1.5">
              <Label htmlFor="identity-email" className="text-meta font-medium">
                Email Address <span className="text-destructive">*</span>
              </Label>
              <Input
                id="identity-email"
                type="email"
                value={identityEmail}
                onChange={(e) => { setIdentityEmail(e.target.value); if (identityErrors.email) setIdentityErrors({ ...identityErrors, email: undefined }); }}
                placeholder="you@example.com"
                className={identityErrors.email ? "border-destructive focus-visible:ring-destructive" : ""}
              />
              {identityErrors.email && <p className="text-meta text-destructive">{identityErrors.email}</p>}
            </div>

            <div className="flex items-start gap-2 p-3 rounded-md bg-secondary/60 border border-border">
              <Shield className="w-4 h-4 text-muted mt-0.5 shrink-0" />
              <p className="text-meta text-muted leading-relaxed">
                By continuing, you agree your typed name and signature are legally binding electronic signatures.
              </p>
            </div>
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={() => setIdentityOpen(false)}>Cancel</Button>
            <Button onClick={confirmIdentity} className="bg-accent hover:bg-accent/90 text-accent-foreground">
              Continue to sign
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <SignaturePad open={padOpen} onClose={() => { setPadOpen(false); setActiveSigFieldId(null); }} onConfirm={handleSignatureConfirm} defaultName={fullName} />

      <Dialog open={!!activeInitFieldId} onOpenChange={(o) => !o && setActiveInitFieldId(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Enter your initials</DialogTitle>
          </DialogHeader>
          <Input
            value={initialsInput}
            onChange={(e) => setInitialsInput(e.target.value.toUpperCase())}
            maxLength={4}
            placeholder="SC"
            autoFocus
          />
          <DialogFooter>
            <Button variant="outline" onClick={() => setActiveInitFieldId(null)}>Cancel</Button>
            <Button onClick={handleInitialsConfirm} disabled={!initialsInput.trim()}>Confirm</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default SignDocument;
