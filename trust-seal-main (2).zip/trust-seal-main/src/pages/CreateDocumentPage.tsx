import { useEffect, useState, useCallback, useRef } from "react";
import { useNavigate } from "react-router-dom";
import { useEditor, EditorContent, Editor, Extension } from "@tiptap/react";
import StarterKit from "@tiptap/starter-kit";
import TextAlign from "@tiptap/extension-text-align";
import Underline from "@tiptap/extension-underline";
import Link from "@tiptap/extension-link";
import { TextStyle } from "@tiptap/extension-text-style";
import {
  Bold,
  Italic,
  Underline as UnderlineIcon,
  List,
  ListOrdered,
  Quote,
  AlignLeft,
  AlignCenter,
  AlignRight,
  AlignJustify,
  Link as LinkIcon,
  Undo,
  Redo,
  Loader2,
  SquarePen,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { useCreateDocumentFromHtml } from "@/hooks/use-documents";
import { useToast } from "@/hooks/use-toast";

const FONT_SIZES = ["8", "9", "10", "11", "12", "14", "16", "18", "20", "24", "28", "32", "36", "48", "72"];

const FontSize = Extension.create({
  name: "fontSize",
  addOptions() {
    return { types: ["textStyle"] as string[] };
  },
  addGlobalAttributes() {
    return [
      {
        types: this.options.types,
        attributes: {
          fontSize: {
            default: null,
            parseHTML: (el: HTMLElement) =>
              el.style.fontSize?.replace(/['"]+/g, "") || null,
            renderHTML: (attrs: { fontSize?: string | null }) => {
              if (!attrs.fontSize) return {};
              return { style: `font-size: ${attrs.fontSize}` };
            },
          },
        },
      },
    ];
  },
  addCommands() {
    return {
      setFontSize:
        (size: string) =>
        ({ chain }: any) =>
          chain().setMark("textStyle", { fontSize: size }).run(),
      unsetFontSize:
        () =>
        ({ chain }: any) =>
          chain().setMark("textStyle", { fontSize: null }).removeEmptyTextStyle().run(),
    } as any;
  },
});

function ToolbarBtn({
  onClick,
  active,
  disabled,
  title,
  children,
}: {
  onClick: () => void;
  active?: boolean;
  disabled?: boolean;
  title: string;
  children: React.ReactNode;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      disabled={disabled}
      title={title}
      className={`p-1.5 rounded hover:bg-secondary transition-colors disabled:opacity-40 ${
        active ? "bg-secondary text-foreground" : "text-muted"
      }`}
    >
      {children}
    </button>
  );
}

const PRESET_FIELDS = ["Name", "Signature", "Date", "Initials", "Title", "Company"];
const FIELD_BLANK = "_".repeat(30);

function InsertFieldPopover({ editor }: { editor: Editor }) {
  const [open, setOpen] = useState(false);
  const [showCustom, setShowCustom] = useState(false);
  const [custom, setCustom] = useState("");

  const insert = (label: string) => {
    if (!label.trim()) return;
    editor.chain().focus().insertContent(`${label.trim()}: ${FIELD_BLANK}`).run();
    setOpen(false);
    setShowCustom(false);
    setCustom("");
  };

  return (
    <Popover open={open} onOpenChange={(o) => { setOpen(o); if (!o) { setShowCustom(false); setCustom(""); } }}>
      <PopoverTrigger asChild>
        <button
          type="button"
          title="Insert field placeholder"
          className="p-1.5 rounded hover:bg-secondary transition-colors text-muted"
        >
          <SquarePen className="w-4 h-4" />
        </button>
      </PopoverTrigger>
      <PopoverContent className="w-56 p-1" align="start">
        {!showCustom ? (
          <div className="flex flex-col">
            {PRESET_FIELDS.map((f) => (
              <button
                key={f}
                type="button"
                onClick={() => insert(f)}
                className="text-left px-2 py-1.5 text-sm rounded hover:bg-accent"
              >
                {f}
              </button>
            ))}
            <div className="h-px bg-border my-1" />
            <button
              type="button"
              onClick={() => setShowCustom(true)}
              className="text-left px-2 py-1.5 text-sm rounded hover:bg-accent text-muted-foreground"
            >
              Custom…
            </button>
          </div>
        ) : (
          <form
            onSubmit={(e) => { e.preventDefault(); insert(custom); }}
            className="flex flex-col gap-2 p-1"
          >
            <Input
              autoFocus
              value={custom}
              onChange={(e) => setCustom(e.target.value)}
              placeholder="Field label"
              className="h-8 text-sm"
            />
            <div className="flex gap-1 justify-end">
              <Button type="button" variant="ghost" size="sm" onClick={() => setShowCustom(false)}>Back</Button>
              <Button type="submit" size="sm" disabled={!custom.trim()}>Insert</Button>
            </div>
          </form>
        )}
      </PopoverContent>
    </Popover>
  );
}

function Toolbar({ editor }: { editor: Editor | null }) {
  const [sizeValue, setSizeValue] = useState("11");
  const sizeRef = useRef(sizeValue);
  sizeRef.current = sizeValue;

  useEffect(() => {
    if (!editor) return;
    const sync = () => {
      const fs = editor.getAttributes("textStyle").fontSize as string | undefined;
      const n = fs ? parseInt(fs) : NaN;
      const next = Number.isFinite(n) ? String(n) : "11";
      if (next !== sizeRef.current) setSizeValue(next);
    };
    editor.on("selectionUpdate", sync);
    editor.on("transaction", sync);
    sync();
    return () => {
      editor.off("selectionUpdate", sync);
      editor.off("transaction", sync);
    };
  }, [editor]);

  if (!editor) return null;

  const setLink = () => {
    const prev = editor.getAttributes("link").href;
    const url = window.prompt("URL", prev || "https://");
    if (url === null) return;
    if (url === "") {
      editor.chain().focus().extendMarkRange("link").unsetLink().run();
      return;
    }
    editor.chain().focus().extendMarkRange("link").setLink({ href: url }).run();
  };

  const applySize = (v: string) => {
    setSizeValue(v); // instant UI update
    // defer editor mutation so dropdown closes immediately without jank
    requestAnimationFrame(() => {
      (editor.chain().focus() as any).setFontSize(`${v}px`).run();
    });
  };

  return (
    <div className="sticky top-0 z-10 bg-card border-b px-4 py-2 flex flex-wrap items-center gap-1">
      <ToolbarBtn title="Bold" onClick={() => editor.chain().focus().toggleBold().run()} active={editor.isActive("bold")}>
        <Bold className="w-4 h-4" />
      </ToolbarBtn>
      <ToolbarBtn title="Italic" onClick={() => editor.chain().focus().toggleItalic().run()} active={editor.isActive("italic")}>
        <Italic className="w-4 h-4" />
      </ToolbarBtn>
      <ToolbarBtn title="Underline" onClick={() => editor.chain().focus().toggleUnderline().run()} active={editor.isActive("underline")}>
        <UnderlineIcon className="w-4 h-4" />
      </ToolbarBtn>
      <div className="w-px h-5 bg-border mx-1" />
      <select
        value={sizeValue}
        onChange={(e) => applySize(e.target.value)}
        title="Font size"
        className="h-8 w-[70px] text-sm rounded-md border border-input bg-background px-2"
      >
        {FONT_SIZES.map((s) => (
          <option key={s} value={s}>{s}</option>
        ))}
      </select>
      <div className="w-px h-5 bg-border mx-1" />
      <ToolbarBtn title="Bullet list" onClick={() => editor.chain().focus().toggleBulletList().run()} active={editor.isActive("bulletList")}>
        <List className="w-4 h-4" />
      </ToolbarBtn>
      <ToolbarBtn title="Numbered list" onClick={() => editor.chain().focus().toggleOrderedList().run()} active={editor.isActive("orderedList")}>
        <ListOrdered className="w-4 h-4" />
      </ToolbarBtn>
      <ToolbarBtn title="Blockquote" onClick={() => editor.chain().focus().toggleBlockquote().run()} active={editor.isActive("blockquote")}>
        <Quote className="w-4 h-4" />
      </ToolbarBtn>
      <div className="w-px h-5 bg-border mx-1" />
      <ToolbarBtn title="Align left" onClick={() => editor.chain().focus().setTextAlign("left").run()} active={editor.isActive({ textAlign: "left" })}>
        <AlignLeft className="w-4 h-4" />
      </ToolbarBtn>
      <ToolbarBtn title="Align center" onClick={() => editor.chain().focus().setTextAlign("center").run()} active={editor.isActive({ textAlign: "center" })}>
        <AlignCenter className="w-4 h-4" />
      </ToolbarBtn>
      <ToolbarBtn title="Align right" onClick={() => editor.chain().focus().setTextAlign("right").run()} active={editor.isActive({ textAlign: "right" })}>
        <AlignRight className="w-4 h-4" />
      </ToolbarBtn>
      <ToolbarBtn title="Justify" onClick={() => editor.chain().focus().setTextAlign("justify").run()} active={editor.isActive({ textAlign: "justify" })}>
        <AlignJustify className="w-4 h-4" />
      </ToolbarBtn>
      <div className="w-px h-5 bg-border mx-1" />
      <ToolbarBtn title="Link" onClick={setLink} active={editor.isActive("link")}>
        <LinkIcon className="w-4 h-4" />
      </ToolbarBtn>
      <InsertFieldPopover editor={editor} />
      <div className="w-px h-5 bg-border mx-1" />
      <ToolbarBtn title="Undo" onClick={() => editor.chain().focus().undo().run()} disabled={!editor.can().undo()}>
        <Undo className="w-4 h-4" />
      </ToolbarBtn>
      <ToolbarBtn title="Redo" onClick={() => editor.chain().focus().redo().run()} disabled={!editor.can().redo()}>
        <Redo className="w-4 h-4" />
      </ToolbarBtn>
    </div>
  );
}

export default function CreateDocumentPage() {
  const navigate = useNavigate();
  const { toast } = useToast();
  const [title, setTitle] = useState("");
  const [dirty, setDirty] = useState(false);
  const createDoc = useCreateDocumentFromHtml();

  const editor = useEditor({
    extensions: [
      StarterKit.configure({ heading: false }),
      TextStyle,
      FontSize,
      Underline,
      TextAlign.configure({ types: ["paragraph"] }),
      Link.configure({ openOnClick: false }),
    ],
    content: "<p></p>",
    editorProps: {
      attributes: {
        class:
          "prose prose-sm max-w-none focus:outline-none min-h-[1000px] font-[Helvetica,Arial,sans-serif]",
      },
    },
    onUpdate: () => setDirty(true),
  });

  useEffect(() => {
    const handler = (e: BeforeUnloadEvent) => {
      if (dirty || title) {
        e.preventDefault();
        e.returnValue = "";
      }
    };
    window.addEventListener("beforeunload", handler);
    return () => window.removeEventListener("beforeunload", handler);
  }, [dirty, title]);

  const confirmDiscard = useCallback(() => {
    if (!dirty && !title) return true;
    return window.confirm("Discard your draft? Your unsaved changes will be lost.");
  }, [dirty, title]);

  const handleCancel = () => {
    if (confirmDiscard()) navigate("/admin");
  };

  const isEmpty = !editor || editor.getText().trim().length === 0;

  const handleSave = async () => {
    if (!title.trim() || isEmpty || !editor) return;
    try {
      const html = editor.getHTML();
      const result = await createDoc.mutateAsync({ title: title.trim(), htmlContent: html });
      toast({ title: "Document created", description: "Now place signature fields." });
      setDirty(false);
      navigate(`/admin/documents/${result.documentId}/place-fields`);
    } catch (e: any) {
      toast({
        title: "Failed to generate PDF",
        description: e?.message || "Something went wrong",
        variant: "destructive",
      });
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <div className="border-b bg-card">
        <div className="max-w-5xl mx-auto px-6 py-3 flex items-center gap-4">
          <h1 className="text-display text-foreground whitespace-nowrap">Create Document</h1>
          <Input
            value={title}
            onChange={(e) => {
              setTitle(e.target.value);
              setDirty(true);
            }}
            placeholder="Document title"
            className="flex-1 max-w-md"
          />
          <div className="flex items-center gap-2 ml-auto">
            <Button variant="outline" onClick={handleCancel} disabled={createDoc.isPending}>
              Cancel
            </Button>
            <Button
              onClick={handleSave}
              disabled={!title.trim() || isEmpty || createDoc.isPending}
              className="gap-2"
            >
              {createDoc.isPending && <Loader2 className="w-4 h-4 animate-spin" />}
              {createDoc.isPending ? "Generating PDF..." : "Save as PDF"}
            </Button>
          </div>
        </div>
        <div className="max-w-5xl mx-auto">
          <Toolbar editor={editor} />
        </div>
      </div>

      <div className="py-8 px-4">
        <div
          className="mx-auto bg-white text-black rounded shadow-lg"
          style={{
            width: "794px",
            maxWidth: "100%",
            minHeight: "1123px",
            padding: "75px",
          }}
        >
          <EditorContent editor={editor} />
        </div>
      </div>
    </div>
  );
}
