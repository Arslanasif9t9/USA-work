import { useNavigate } from "react-router-dom";
import { motion } from "framer-motion";
import { FileText, Shield, ArrowRight } from "lucide-react";
import { Button } from "@/components/ui/button";

const Index = () => {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-background-pure flex items-center justify-center p-4">
      <motion.div
        initial={{ opacity: 0, y: 8 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4, ease: [0.16, 1, 0.3, 1] }}
        className="max-w-md w-full text-center"
      >
        <div className="w-14 h-14 rounded-xl bg-primary flex items-center justify-center mx-auto mb-6">
          <FileText className="w-7 h-7 text-primary-foreground" />
        </div>

        <h1 className="text-2xl font-semibold text-foreground tracking-tight mb-2">
          DocuSign Legal
        </h1>
        <p className="text-body text-muted mb-8">
          Internal document signing for your organization.
        </p>

        <div className="space-y-3">
          <Button
            onClick={() => navigate("/admin")}
            className="w-full btn-settle gap-2 h-11"
          >
            Admin Dashboard
            <ArrowRight className="w-4 h-4" />
          </Button>
          <Button
            variant="outline"
            onClick={() => navigate("/sign/demo")}
            className="w-full btn-settle gap-2 h-11"
          >
            Demo Signing Page
            <ArrowRight className="w-4 h-4" />
          </Button>
        </div>

        <div className="flex items-center justify-center gap-1.5 mt-8 text-meta text-muted">
          <Shield className="w-3.5 h-3.5" />
          <span>Secure · Encrypted · Audited</span>
        </div>
      </motion.div>
    </div>
  );
};

export default Index;
