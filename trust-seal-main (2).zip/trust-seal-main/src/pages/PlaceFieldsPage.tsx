import { useEffect, useMemo, useRef, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { Document, Page, pdfjs } from "react-pdf";
import { Rnd } from "react-rnd";
import {
  PenLine,
  Type as TypeIcon,
  Calendar,
  TextCursor,
  X,
  ChevronLeft,
  ChevronRight,
  Loader2,
  Copy as CopyIcon,
  Check,
  AlertTriangle,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import {
  useDocument,
  useDocumentSignedUrl,
  useGenerateSigningLink,
  useSignatureFields,
  PlacedField,
} from "@/hooks/use-documents";
import "react-pdf/dist/Page/AnnotationLayer.css";
import "react-pdf/dist/Page/TextLayer.css";

// Configure react-pdf worker via unpkg CDN, version-pinned to installed pdfjs-dist
pdfjs.GlobalWorkerOptions.workerSrc = `https://unpkg.com/pdfjs-dist@${pdfjs.version}/build/pdf.worker.min.mjs`;

type FieldType = PlacedField["field_type"];

const FIELD_DEFAULTS: Record<FieldType, { w: number; h: number; color: string; label: string; Icon: any }> = {
  signature: { w: 30, h: 8, color: "border-blue-500 bg-blue-500/10", label: "Signature", Icon: PenLine },
  initials: { w: 10, h: 5, color: "border-purple-500 bg-purple-500/10", label: "Initials", Icon: TypeIcon },
  date: { w: 15, h: 4, color: "border-green-500 bg-green-500/10", label: "Date", Icon: Calendar },
  text: { w: 20, h: 5, color: "border-gray-500 bg-gray-500/10", label: "Text", Icon: TextCursor },
};

export default function PlaceFieldsPage() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { toast } = useToast();

  const { data: doc, isLoading: docLoading } = useDocument(id);
  const { data: pdfUrl } = useDocumentSignedUrl(doc?.original_path);
  const { data: existingFields } = useSignatureFields(id);
  const generate = useGenerateSigningLink();

  const existingReq = useMemo(
    () =>
      doc?.sign_requests
        ?.slice()
        .sort((a: any, b: any) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime())[0],
    [doc],
  );
  const isReedit = !!existingReq;

  const [activeType, setActiveType] = useState<FieldType | null>(null);
  const [fields, setFields] = useState<PlacedField[]>([]);
  const [currentPage, setCurrentPage] = useState(1);
  const [numPages, setNumPages] = useState(0);
  const [pageWidth, setPageWidth] = useState(800);
  const [signerEmail, setSignerEmail] = useState("");
  const [signerName, setSignerName] = useState("");
  const [expiresInDays, setExpiresInDays] = useState(30);
  const [shareModal, setShareModal] = useState<{ url: string; email: string; days: number } | null>(null);
  const [copied, setCopied] = useState(false);
  const [hydrated, setHydrated] = useState(false);

  const pageContainerRef = useRef<HTMLDivElement | null>(null);
  const mainRef = useRef<HTMLDivElement | null>(null);

  // Hydrate from existing fields/sign_request
  useEffect(() => {
    if (hydrated) return;
    if (existingFields && existingFields.length) {
      setFields(
        existingFields.map((f: any) => ({
          id: crypto.randomUUID(),
          field_type: f.field_type,
          page: f.page,
          x_percent: Number(f.x_percent),
          y_percent: Number(f.y_percent),
          width_percent: Number(f.width_percent),
          height_percent: Number(f.height_percent),
        })),
      );
    }
    if (existingReq) {
      setSignerEmail(existingReq.signer_email || "");
      setSignerName(existingReq.signer_name || "");
      const ms = new Date(existingReq.expires_at).getTime() - Date.now();
      const days = Math.max(1, Math.round(ms / (24 * 60 * 60 * 1000)));
      setExpiresInDays([7, 14, 30].includes(days) ? days : 30);
    }
    if (existingFields !== undefined && doc) setHydrated(true);
  }, [existingFields, existingReq, doc, hydrated]);

  // Resize page width to fit container
  useEffect(() => {
    const update = () => {
      if (mainRef.current) {
        const w = Math.min(900, mainRef.current.clientWidth - 48);
        if (w > 200) setPageWidth(w);
      }
    };
    update();
    window.addEventListener("resize", update);
    return () => window.removeEventListener("resize", update);
  }, []);

  const emailValid = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(signerEmail);
  const canGenerate = fields.length > 0 && emailValid && !generate.isPending;

  const handlePageClick = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!activeType) return;
    const rect = e.currentTarget.getBoundingClientRect();
    const x = ((e.clientX - rect.left) / rect.width) * 100;
    const y = ((e.clientY - rect.top) / rect.height) * 100;
    const def = FIELD_DEFAULTS[activeType];
    const newField: PlacedField = {
      id: crypto.randomUUID(),
      field_type: activeType,
      page: currentPage,
      x_percent: Math.max(0, Math.min(100 - def.w, x - def.w / 2)),
      y_percent: Math.max(0, Math.min(100 - def.h, y - def.h / 2)),
      width_percent: def.w,
      height_percent: def.h,
    };
    setFields((prev) => [...prev, newField]);
    setActiveType(null);
  };

  const updateField = (id: string, patch: Partial<PlacedField>) => {
    setFields((prev) => prev.map((f) => (f.id === id ? { ...f, ...patch } : f)));
  };

  const removeField = (id: string) => {
    setFields((prev) => prev.filter((f) => f.id !== id));
  };

  const handleGenerate = async () => {
    if (!id) return;
    try {
      const result = await generate.mutateAsync({
        documentId: id,
        fields,
        signerEmail,
        signerName,
        expiresInDays,
        isReedit,
      });
      setShareModal({ url: result.url, email: signerEmail, days: expiresInDays });
    } catch (err: any) {
      toast({
        title: "Could not generate link",
        description: err?.message || "Something went wrong",
        variant: "destructive",
      });
    }
  };

  const copyLink = async () => {
    if (!shareModal) return;
    await navigator.clipboard.writeText(shareModal.url);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const fieldsOnCurrentPage = fields.filter((f) => f.page === currentPage);

  return (
    <div className="min-h-screen bg-background flex flex-col">
      {/* Top bar */}
      <div className="border-b bg-card px-6 py-3 flex items-center justify-between">
        <h1 className="text-display text-foreground">
          Place Fields — {docLoading ? "Loading..." : doc?.title}
        </h1>
        <div className="flex gap-2">
          <Button variant="outline" onClick={() => navigate("/admin")} className="btn-settle">
            Cancel
          </Button>
          <Button onClick={handleGenerate} disabled={!canGenerate} className="btn-settle gap-2">
            {generate.isPending && <Loader2 className="w-4 h-4 animate-spin" />}
            {isReedit ? "Regenerate Link" : "Generate Signing Link"}
          </Button>
        </div>
      </div>

      {isReedit && (
        <div className="bg-yellow-500/10 border-b border-yellow-500/30 px-6 py-2 flex items-center gap-2 text-body text-foreground">
          <AlertTriangle className="w-4 h-4 text-yellow-600 shrink-0" />
          Re-editing will invalidate the current signing link. A new link will be generated.
        </div>
      )}

      <div className="flex-1 flex overflow-hidden">
        {/* Sidebar */}
        <aside className="w-72 border-r bg-card overflow-y-auto p-4 space-y-6">
          <div>
            <h3 className="text-meta font-medium text-muted uppercase tracking-wide mb-2">Field Types</h3>
            <div className="grid grid-cols-2 gap-2">
              {(Object.keys(FIELD_DEFAULTS) as FieldType[]).map((t) => {
                const { Icon, label } = FIELD_DEFAULTS[t];
                const isActive = activeType === t;
                return (
                  <button
                    key={t}
                    onClick={() => setActiveType(isActive ? null : t)}
                    className={`flex flex-col items-center gap-1 p-3 rounded-md border transition-colors ${
                      isActive ? "bg-accent text-accent-foreground border-accent" : "hover:bg-secondary"
                    }`}
                  >
                    <Icon className="w-4 h-4" />
                    <span className="text-meta">{label}</span>
                  </button>
                );
              })}
            </div>
            {activeType && (
              <p className="text-meta text-muted mt-2">Click on the PDF to place a {activeType}.</p>
            )}
          </div>

          <div>
            <h3 className="text-meta font-medium text-muted uppercase tracking-wide mb-2">
              Placed Fields ({fields.length})
            </h3>
            {fields.length === 0 ? (
              <p className="text-meta text-muted">
                No fields placed. Click a field type above, then click on the PDF to place it.
              </p>
            ) : (
              <ul className="space-y-1">
                {fields.map((f) => {
                  const { Icon, label } = FIELD_DEFAULTS[f.field_type];
                  return (
                    <li
                      key={f.id}
                      className="flex items-center gap-2 px-2 py-1.5 rounded-md hover:bg-secondary text-body"
                    >
                      <Icon className="w-3.5 h-3.5 text-muted" />
                      <span className="flex-1">
                        {label} <span className="text-muted">· Page {f.page}</span>
                      </span>
                      <button
                        onClick={() => removeField(f.id)}
                        className="p-0.5 rounded hover:bg-destructive/10"
                      >
                        <X className="w-3.5 h-3.5 text-destructive" />
                      </button>
                    </li>
                  );
                })}
              </ul>
            )}
          </div>

          <div className="space-y-3">
            <h3 className="text-meta font-medium text-muted uppercase tracking-wide">Signer Info</h3>
            <div className="space-y-1.5">
              <Label className="text-body">Signer Email *</Label>
              <Input
                type="email"
                value={signerEmail}
                onChange={(e) => setSignerEmail(e.target.value)}
                placeholder="signer@example.com"
              />
            </div>
            <div className="space-y-1.5">
              <Label className="text-body">Signer Name</Label>
              <Input
                value={signerName}
                onChange={(e) => setSignerName(e.target.value)}
                placeholder="Optional"
              />
            </div>
            <div className="space-y-1.5">
              <Label className="text-body">Expires In</Label>
              <Select
                value={String(expiresInDays)}
                onValueChange={(v) => setExpiresInDays(Number(v))}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="7">7 days</SelectItem>
                  <SelectItem value="14">14 days</SelectItem>
                  <SelectItem value="30">30 days</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </aside>

        {/* Main PDF area */}
        <div ref={mainRef} className="flex-1 overflow-auto p-6 flex flex-col items-center">
          {!pdfUrl ? (
            <div className="text-muted py-20">Loading document...</div>
          ) : (
            <>
              <div
                ref={pageContainerRef}
                className="relative shadow-lg bg-white"
                style={{ cursor: activeType ? "crosshair" : "default" }}
                onClick={handlePageClick}
              >
                {pdfUrl ? (
                  <Document
                    file={pdfUrl}
                    onLoadSuccess={({ numPages }) => setNumPages(numPages)}
                    onLoadError={(error) => console.error("PDF load error:", error)}
                    loading={<div className="p-12 text-muted">Loading PDF...</div>}
                  >
                    <Page pageNumber={currentPage} width={pageWidth} renderAnnotationLayer={false} renderTextLayer={false} />
                  </Document>
                ) : (
                  <div className="p-12 text-muted">Loading PDF...</div>
                )}

                {/* Placed fields overlay */}
                {fieldsOnCurrentPage.map((f) => {
                  const def = FIELD_DEFAULTS[f.field_type];
                  const container = pageContainerRef.current;
                  const cw = container?.clientWidth || pageWidth;
                  const ch = container?.clientHeight || pageWidth * 1.4;
                  return (
                    <Rnd
                      key={f.id}
                      bounds="parent"
                      size={{
                        width: (f.width_percent / 100) * cw,
                        height: (f.height_percent / 100) * ch,
                      }}
                      position={{
                        x: (f.x_percent / 100) * cw,
                        y: (f.y_percent / 100) * ch,
                      }}
                      onDragStop={(_, d) => {
                        updateField(f.id, {
                          x_percent: (d.x / cw) * 100,
                          y_percent: (d.y / ch) * 100,
                        });
                      }}
                      onResizeStop={(_, __, ref, ___, pos) => {
                        updateField(f.id, {
                          width_percent: (ref.offsetWidth / cw) * 100,
                          height_percent: (ref.offsetHeight / ch) * 100,
                          x_percent: (pos.x / cw) * 100,
                          y_percent: (pos.y / ch) * 100,
                        });
                      }}
                      onClick={(e: any) => e.stopPropagation()}
                      className={`border-2 ${def.color} group flex items-center justify-center`}
                    >
                      <span className="text-meta font-medium text-foreground/70 select-none pointer-events-none">
                        {def.label}
                      </span>
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          removeField(f.id);
                        }}
                        className="absolute -top-2 -right-2 w-5 h-5 rounded-full bg-destructive text-destructive-foreground flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity"
                      >
                        <X className="w-3 h-3" />
                      </button>
                    </Rnd>
                  );
                })}
              </div>

              {numPages > 1 && (
                <div className="flex items-center gap-3 mt-4">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setCurrentPage((p) => Math.max(1, p - 1))}
                    disabled={currentPage === 1}
                  >
                    <ChevronLeft className="w-4 h-4" /> Previous
                  </Button>
                  <span className="text-body text-muted">
                    Page {currentPage} of {numPages}
                  </span>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setCurrentPage((p) => Math.min(numPages, p + 1))}
                    disabled={currentPage === numPages}
                  >
                    Next <ChevronRight className="w-4 h-4" />
                  </Button>
                </div>
              )}
            </>
          )}
        </div>
      </div>

      {/* Share modal */}
      {shareModal && (
        <div className="fixed inset-0 z-50 bg-foreground/40 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-card border rounded-lg vault-shadow-lg w-full max-w-lg p-6 space-y-4">
            <div>
              <h2 className="text-display text-foreground">Share Signing Link</h2>
              <p className="text-body text-muted mt-1">Link ready for {shareModal.email}</p>
            </div>
            <Input value={shareModal.url} readOnly className="font-mono text-meta" />
            <Button onClick={copyLink} className="w-full btn-settle gap-2 h-11">
              {copied ? (
                <>
                  <Check className="w-4 h-4" /> Copied
                </>
              ) : (
                <>
                  <CopyIcon className="w-4 h-4" /> Copy Link
                </>
              )}
            </Button>
            <p className="text-meta text-muted">
              Send this link via WhatsApp, email, or any messenger. Expires in {shareModal.days} days.
            </p>
            <div className="flex justify-end">
              <Button variant="outline" onClick={() => navigate("/admin")} className="btn-settle">
                Done
              </Button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
