import { useState } from "react";
import { Plus, LogOut, Upload, FilePlus2, ChevronDown } from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Button } from "@/components/ui/button";
import { AdminSidebar } from "@/components/admin/AdminSidebar";
import { StatsBar } from "@/components/admin/StatsBar";
import { DocumentTable } from "@/components/admin/DocumentTable";
import { UploadDialog } from "@/components/admin/UploadDialog";
import { useDocuments, useUploadDocument } from "@/hooks/use-documents";
import { useAuth } from "@/hooks/use-auth";
import { useNavigate } from "react-router-dom";
import { useToast } from "@/hooks/use-toast";

const AdminDashboard = () => {
  const [uploadOpen, setUploadOpen] = useState(false);
  const [activeTab, setActiveTab] = useState("dashboard");
  const { data: documents = [], isLoading } = useDocuments();
  const uploadDocument = useUploadDocument();
  const { signOut } = useAuth();
  const navigate = useNavigate();
  const { toast } = useToast();

  const handleSignOut = async () => {
    await signOut();
    navigate("/login");
  };

  const flatDocs = documents.flatMap((doc) =>
    doc.sign_requests.length > 0
      ? doc.sign_requests.map((req) => ({
          id: req.id,
          title: doc.title,
          fileName: doc.file_name,
          status: req.status as any,
          signerEmail: req.signer_email,
          signerName: req.signer_name || undefined,
          createdAt: doc.created_at,
          sentAt: req.sent_at || undefined,
          viewedAt: req.viewed_at || undefined,
          signedAt: req.signed_at || undefined,
          expiresAt: req.expires_at,
          token: req.token,
          originalPath: doc.original_path,
          signedPath: req.signatures?.[0]?.signed_pdf_path || undefined,
        }))
      : [
          {
            id: doc.id,
            title: doc.title,
            fileName: doc.file_name,
            status: "draft" as any,
            signerEmail: "",
            createdAt: doc.created_at,
            originalPath: doc.original_path,
          },
        ],
  );

  const filteredDocs = (() => {
    switch (activeTab) {
      case "documents":
        return flatDocs;
      case "sent":
        return flatDocs.filter((d) => d.status === "pending" || d.status === "viewed");
      case "archive":
        return flatDocs.filter((d) => d.status === "signed" || d.status === "expired" || d.status === "cancelled");
      default:
        return flatDocs;
    }
  })();

  const tabTitles: Record<string, string> = {
    dashboard: "Dashboard",
    documents: "All Documents",
    sent: "Sent & Awaiting",
    archive: "Archive",
    settings: "Settings",
  };

  const handleUpload = async (data: { title: string; file: File }) => {
    try {
      const result = await uploadDocument.mutateAsync(data);
      toast({
        title: "Document uploaded",
        description: "Now place signature fields on the PDF.",
      });
      setUploadOpen(false);
      navigate(`/admin/documents/${result.document.id}/place-fields`);
    } catch (err: any) {
      toast({
        title: "Upload failed",
        description: err?.message || "Something went wrong",
        variant: "destructive",
      });
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <AdminSidebar
        activeTab={activeTab}
        onTabChange={setActiveTab}
        counts={{
          documents: flatDocs.length,
          sent: flatDocs.filter((d) => d.status === "pending" || d.status === "viewed").length,
        }}
      />

      <main className="ml-60 p-6">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h1 className="text-display text-foreground">{tabTitles[activeTab] ?? "Dashboard"}</h1>
            <p className="text-body text-muted mt-0.5">
              {activeTab === "dashboard" && "Manage documents and track signing status."}
              {activeTab === "documents" && "All uploaded documents."}
              {activeTab === "sent" && "Documents sent and awaiting signature."}
              {activeTab === "archive" && "Completed, expired, and cancelled documents."}
              {activeTab === "settings" && "System settings."}
            </p>
          </div>
          <div className="flex items-center gap-2">
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button className="btn-settle gap-2">
                  <Plus className="w-4 h-4" />
                  New Document
                  <ChevronDown className="w-3.5 h-3.5 opacity-70" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-52">
                <DropdownMenuItem onClick={() => setUploadOpen(true)} className="gap-2">
                  <Upload className="w-4 h-4" /> Upload PDF
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => navigate("/admin/documents/new")} className="gap-2">
                  <FilePlus2 className="w-4 h-4" /> Create from Scratch
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
            <Button variant="outline" onClick={handleSignOut} className="btn-settle gap-2">
              <LogOut className="w-4 h-4" />
              Sign Out
            </Button>
          </div>
        </div>

        <div className="space-y-6">
          {isLoading ? (
            <p className="text-body text-muted">Loading documents...</p>
          ) : (
            <>
              {(activeTab === "dashboard" || activeTab === "documents") && <StatsBar documents={flatDocs} />}
              <DocumentTable documents={filteredDocs} rawDocuments={documents} />
            </>
          )}
        </div>
      </main>

      <UploadDialog open={uploadOpen} onClose={() => setUploadOpen(false)} onSubmit={handleUpload} />
    </div>
  );
};

export default AdminDashboard;
