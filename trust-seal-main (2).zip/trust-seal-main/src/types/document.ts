export type DocumentStatus = "draft" | "pending" | "viewed" | "signed" | "expired" | "cancelled";

export interface SigningDocument {
  id: string;
  title: string;
  fileName: string;
  status: DocumentStatus;
  signerEmail: string;
  signerName?: string;
  createdAt: string;
  sentAt?: string;
  viewedAt?: string;
  signedAt?: string;
  expiresAt?: string;
  signerIp?: string;
  documentHash?: string;
  token?: string;
  originalPath?: string;
  signedPath?: string;
}
