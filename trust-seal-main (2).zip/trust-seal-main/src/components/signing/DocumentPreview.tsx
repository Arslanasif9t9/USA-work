import { AlertTriangle, FileText } from "lucide-react";

interface DocumentPreviewProps {
  documentTitle: string;
  isDemo: boolean;
  isLoading: boolean;
  error: string | null;
  pdfUrl: string | null;
}

export function DocumentPreview({ documentTitle, isDemo, isLoading, error, pdfUrl }: DocumentPreviewProps) {
  if (isDemo) {
    return (
      <div className="aspect-[8.5/11] flex items-center justify-center bg-background-pure">
        <div className="text-center text-muted">
          <FileText className="w-16 h-16 mx-auto mb-4 opacity-20" />
          <p className="text-body">Demo PDF Preview</p>
        </div>
      </div>
    );
  }

  if (isLoading) {
    return (
      <div className="aspect-[8.5/11] flex items-center justify-center bg-background-pure">
        <p className="text-body text-muted">Loading PDF...</p>
      </div>
    );
  }

  if (error) {
    return (
      <div className="aspect-[8.5/11] flex items-center justify-center bg-background-pure">
        <div className="text-center text-muted">
          <AlertTriangle className="w-8 h-8 mx-auto mb-2" />
          <p className="text-body">{error}</p>
        </div>
      </div>
    );
  }

  if (!pdfUrl) {
    return null;
  }

  return (
    <iframe
      src={`${pdfUrl}#toolbar=1&navpanes=0&scrollbar=1`}
      title={documentTitle}
      className="w-full min-h-[70vh] bg-background-pure"
    />
  );
}
