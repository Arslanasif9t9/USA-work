import { useRef, useEffect, useState, useMemo } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { X, RotateCcw } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import SignaturePadLib from "signature_pad";

interface SignaturePadProps {
  open: boolean;
  onClose: () => void;
  onConfirm: (signatureDataUrl: string) => void;
  /** Pre-fills the typed-signature name field (e.g. signer's full name). */
  defaultName?: string;
}

const FONT_STYLES: { id: string; label: string; family: string; scale: number }[] = [
  { id: "pinyon", label: "Pinyon Script", family: "'Pinyon Script', cursive", scale: 1.15 },
  { id: "great-vibes", label: "Great Vibes", family: "'Great Vibes', cursive", scale: 1.05 },
  { id: "alex-brush", label: "Alex Brush", family: "'Alex Brush', cursive", scale: 1.1 },
  { id: "allura", label: "Allura", family: "'Allura', cursive", scale: 1.1 },
  { id: "dancing", label: "Dancing Script", family: "'Dancing Script', cursive", scale: 1 },
  { id: "sacramento", label: "Sacramento", family: "'Sacramento', cursive", scale: 1 },
  { id: "caveat", label: "Caveat", family: "'Caveat', cursive", scale: 0.95 },
];

function renderTypedSignature(name: string, fontFamily: string, scale = 1): string {
  const width = 600;
  const height = 200;
  const ratio = Math.max(window.devicePixelRatio || 1, 1);
  const canvas = document.createElement("canvas");
  canvas.width = width * ratio;
  canvas.height = height * ratio;
  const ctx = canvas.getContext("2d")!;
  ctx.scale(ratio, ratio);
  ctx.clearRect(0, 0, width, height);
  ctx.fillStyle = "rgb(15, 23, 42)";
  ctx.textBaseline = "middle";
  ctx.textAlign = "center";

  // Fit text to width
  let size = 96 * scale;
  ctx.font = `${size}px ${fontFamily}`;
  while (ctx.measureText(name).width > width - 40 && size > 20) {
    size -= 4;
    ctx.font = `${size}px ${fontFamily}`;
  }
  ctx.fillText(name, width / 2, height / 2);
  return canvas.toDataURL("image/png");
}

export function SignaturePad({ open, onClose, onConfirm, defaultName = "" }: SignaturePadProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const padRef = useRef<SignaturePadLib | null>(null);
  const [isEmpty, setIsEmpty] = useState(true);
  const [mode, setMode] = useState<"draw" | "type">("draw");
  const [typedName, setTypedName] = useState(defaultName);
  const [selectedFontId, setSelectedFontId] = useState(FONT_STYLES[0].id);

  useEffect(() => {
    if (open) setTypedName(defaultName);
  }, [open, defaultName]);

  useEffect(() => {
    if (open && mode === "draw" && canvasRef.current) {
      const canvas = canvasRef.current;
      const ratio = Math.max(window.devicePixelRatio || 1, 1);
      canvas.width = canvas.offsetWidth * ratio;
      canvas.height = canvas.offsetHeight * ratio;
      canvas.getContext("2d")?.scale(ratio, ratio);

      padRef.current = new SignaturePadLib(canvas, {
        penColor: "rgb(15, 23, 42)",
        minWidth: 1.5,
        maxWidth: 2.5,
      });

      padRef.current.addEventListener("endStroke", () => {
        setIsEmpty(padRef.current?.isEmpty() ?? true);
      });
    }

    return () => {
      padRef.current?.off();
    };
  }, [open, mode]);

  const handleClear = () => {
    padRef.current?.clear();
    setIsEmpty(true);
  };

  const selectedFont = useMemo(
    () => FONT_STYLES.find((f) => f.id === selectedFontId) ?? FONT_STYLES[0],
    [selectedFontId],
  );

  const handleConfirm = () => {
    if (mode === "draw") {
      if (padRef.current && !padRef.current.isEmpty()) {
        onConfirm(padRef.current.toDataURL("image/png"));
      }
    } else {
      const name = typedName.trim();
      if (!name) return;
      onConfirm(renderTypedSignature(name, selectedFont.family, selectedFont.scale));
    }
  };

  const canConfirm = mode === "draw" ? !isEmpty : typedName.trim().length > 0;

  return (
    <AnimatePresence>
      {open && (
        <>
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-foreground/20 backdrop-blur-sm z-50"
            onClick={onClose}
          />
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.95 }}
            transition={{ duration: 0.2, ease: [0.16, 1, 0.3, 1] }}
            className="fixed top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-full max-w-xl bg-card rounded-lg border vault-shadow-lg z-50"
            transformTemplate={(_, generated) => generated}
          >
            <div className="flex items-center justify-between p-4 border-b">
              <h2 className="text-display text-foreground">Add Your Signature</h2>
              <button onClick={onClose} className="p-1.5 rounded-md hover:bg-secondary transition-colors">
                <X className="w-4 h-4 text-muted" />
              </button>
            </div>

            <div className="p-4">
              <Tabs value={mode} onValueChange={(v) => setMode(v as "draw" | "type")}>
                <TabsList className="grid w-full grid-cols-2">
                  <TabsTrigger value="draw">Draw</TabsTrigger>
                  <TabsTrigger value="type">Type</TabsTrigger>
                </TabsList>

                <TabsContent value="draw" className="mt-4">
                  <div className="relative border-2 border-border rounded-lg bg-background-pure overflow-hidden">
                    <canvas ref={canvasRef} className="w-full touch-none" style={{ height: "200px" }} />
                    <div className="absolute bottom-4 left-4 right-4 border-t border-border/50" />
                    <p className="absolute bottom-1 left-4 text-meta text-muted/50">Sign above the line</p>
                    {!isEmpty && (
                      <button
                        onClick={handleClear}
                        className="absolute top-2 right-2 p-1.5 rounded-md bg-secondary hover:bg-border transition-colors"
                      >
                        <RotateCcw className="w-3.5 h-3.5 text-muted" />
                      </button>
                    )}
                  </div>
                </TabsContent>

                <TabsContent value="type" className="mt-4 space-y-3">
                  <Input
                    value={typedName}
                    onChange={(e) => setTypedName(e.target.value)}
                    placeholder="Type your full name"
                    autoFocus
                    maxLength={60}
                  />
                  <div className="grid grid-cols-1 gap-2">
                    {FONT_STYLES.map((f) => {
                      const isActive = f.id === selectedFontId;
                      return (
                        <button
                          key={f.id}
                          type="button"
                          onClick={() => setSelectedFontId(f.id)}
                          className={`relative flex items-center justify-center h-16 rounded-md border-2 bg-background-pure transition-colors overflow-hidden px-4 ${
                            isActive ? "border-accent" : "border-border hover:border-muted"
                          }`}
                        >
                          <span
                            className="text-foreground truncate"
                            style={{
                              fontFamily: f.family,
                              fontSize: `${42 * f.scale}px`,
                              lineHeight: 1,
                            }}
                          >
                            {typedName.trim() || "Your Name"}
                          </span>
                          <span className="absolute bottom-1 right-2 text-[10px] text-muted/70 uppercase tracking-wide">
                            {f.label}
                          </span>
                        </button>
                      );
                    })}
                  </div>
                  <p className="text-meta text-muted">
                    By typing your name, you agree this is the legal representation of your signature.
                  </p>
                </TabsContent>
              </Tabs>
            </div>

            <div className="flex items-center justify-end gap-2 p-4 border-t">
              <Button variant="outline" onClick={onClose} className="text-body btn-settle">
                Cancel
              </Button>
              <Button onClick={handleConfirm} disabled={!canConfirm} className="text-body btn-settle">
                Apply Signature
              </Button>
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}
