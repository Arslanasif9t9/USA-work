import { FileText, Clock, Eye, CheckCircle } from "lucide-react";
import { SigningDocument } from "@/types/document";

interface StatsBarProps {
  documents: SigningDocument[];
}

export function StatsBar({ documents }: StatsBarProps) {
  const stats = [
    {
      label: "Total",
      value: documents.length,
      icon: FileText,
    },
    {
      label: "Pending",
      value: documents.filter((d) => d.status === "pending").length,
      icon: Clock,
    },
    {
      label: "Viewed",
      value: documents.filter((d) => d.status === "viewed").length,
      icon: Eye,
    },
    {
      label: "Signed",
      value: documents.filter((d) => d.status === "signed").length,
      icon: CheckCircle,
    },
  ];

  return (
    <div className="grid grid-cols-4 gap-4">
      {stats.map((stat) => (
        <div
          key={stat.label}
          className="bg-card rounded-lg border p-4 vault-shadow animate-settle"
        >
          <div className="flex items-center justify-between mb-2">
            <span className="text-meta text-muted font-medium">{stat.label}</span>
            <stat.icon className="w-4 h-4 text-muted" />
          </div>
          <p className="text-2xl font-semibold text-foreground tabular-nums">{stat.value}</p>
        </div>
      ))}
    </div>
  );
}
