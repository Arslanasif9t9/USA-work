import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Copy, RefreshCw, XCircle, Download, Trash2, Loader2, PenLine, Pencil, Shield } from "lucide-react";
import { AuditTrailDialog } from "./AuditTrailDialog";
import { StatusBadge } from "@/components/ui/status-badge";
import { SigningDocument } from "@/types/document";
import { formatDistanceToNow } from "date-fns";
import { useToast } from "@/hooks/use-toast";
import {
  useResendSigningLink,
  useCancelSignRequest,
  useDownloadDocument,
  useDeleteDocument,
  DocumentWithRequests,
} from "@/hooks/use-documents";
import { Button } from "@/components/ui/button";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";

interface DocumentTableProps {
  documents: SigningDocument[];
  rawDocuments?: DocumentWithRequests[];
}

export function DocumentTable({ documents, rawDocuments = [] }: DocumentTableProps) {
  const { toast } = useToast();
  const navigate = useNavigate();
  const resendMutation = useResendSigningLink();
  const cancelMutation = useCancelSignRequest();
  const downloadMutation = useDownloadDocument();
  const deleteMutation = useDeleteDocument();
  const [pendingDelete, setPendingDelete] = useState<SigningDocument | null>(null);
  const [auditState, setAuditState] = useState<{ doc: DocumentWithRequests; signRequestId: string } | null>(null);

  const handleDelete = async () => {
    if (!pendingDelete) return;
    const raw = rawDocuments.find(
      (d) => d.id === pendingDelete.id || d.sign_requests.some((r) => r.id === pendingDelete.id)
    );
    if (!raw) {
      toast({ title: "Document not found", variant: "destructive" });
      return;
    }
    try {
      await deleteMutation.mutateAsync(raw);
      toast({ title: "Document deleted", description: `'${pendingDelete.title}' was permanently removed.` });
      setPendingDelete(null);
    } catch (err: any) {
      toast({
        title: "Delete failed",
        description: err?.message || "Something went wrong",
        variant: "destructive",
      });
    }
  };

  const formatDate = (dateStr?: string) => {
    if (!dateStr) return "—";
    return formatDistanceToNow(new Date(dateStr), { addSuffix: true });
  };

  const copySigningLink = (token?: string) => {
    if (!token) return;
    const url = `${window.location.origin}/sign/${token}`;
    navigator.clipboard.writeText(url);
    toast({ title: "Link copied", description: "Signing link copied to clipboard." });
  };

  const handleResend = async (doc: SigningDocument) => {
    if (!doc.token) return;
    try {
      await resendMutation.mutateAsync({
        signRequestId: doc.id,
        email: doc.signerEmail,
        title: doc.title,
        token: doc.token,
      });
      toast({ title: "Email resent", description: `Signing link resent to ${doc.signerEmail}` });
    } catch {
      toast({ title: "Failed to resend", variant: "destructive" });
    }
  };

  const handleCancel = async (doc: SigningDocument) => {
    try {
      await cancelMutation.mutateAsync(doc.id);
      toast({ title: "Request cancelled", description: "Signing request has been cancelled." });
    } catch {
      toast({ title: "Failed to cancel", variant: "destructive" });
    }
  };

  const handleDownload = async (doc: SigningDocument) => {
    try {
      // If signed, download from signed-documents bucket; otherwise download original
      const bucket = doc.signedPath ? "signed-documents" : "documents";
      const path = doc.signedPath || doc.originalPath;
      if (!path) return;

      const blob = await downloadMutation.mutateAsync({ path, bucket });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = doc.signedPath ? `signed_${doc.fileName}` : doc.fileName;
      a.click();
      URL.revokeObjectURL(url);
    } catch {
      toast({ title: "Download failed", variant: "destructive" });
    }
  };

  return (
    <div className="bg-card rounded-lg border vault-shadow overflow-hidden">
      <table className="w-full">
        <thead>
          <tr className="border-b">
            <th className="text-left text-meta font-medium text-muted px-4 py-3">Document</th>
            <th className="text-left text-meta font-medium text-muted px-4 py-3">Signer</th>
            <th className="text-left text-meta font-medium text-muted px-4 py-3">Status</th>
            <th className="text-left text-meta font-medium text-muted px-4 py-3">Sent</th>
            <th className="text-left text-meta font-medium text-muted px-4 py-3">Expires</th>
            <th className="text-right text-meta font-medium text-muted px-4 py-3">Actions</th>
          </tr>
        </thead>
        <tbody>
          {documents.length === 0 ? (
            <tr>
              <td colSpan={6} className="px-4 py-12 text-center text-body text-muted">
                No documents yet. Click "New Document" to get started.
              </td>
            </tr>
          ) : (
            documents.map((doc, i) => (
              <tr
                key={doc.id}
                className="border-b last:border-b-0 hover:bg-secondary/50 transition-colors animate-settle"
                style={{ animationDelay: `${i * 30}ms` }}
              >
                <td className="px-4 py-3">
                  <div>
                    <p className="text-body font-medium text-foreground">{doc.title}</p>
                    <p className="text-meta font-mono text-muted">{doc.fileName}</p>
                  </div>
                </td>
                <td className="px-4 py-3">
                  <p className="text-body text-foreground">{doc.signerName || "—"}</p>
                  <p className="text-meta text-muted">{doc.signerEmail}</p>
                </td>
                <td className="px-4 py-3">
                  <StatusBadge status={doc.status}>
                    {doc.status.charAt(0).toUpperCase() + doc.status.slice(1)}
                  </StatusBadge>
                </td>
                <td className="px-4 py-3 text-body text-muted tabular-nums">{formatDate(doc.sentAt)}</td>
                <td className="px-4 py-3 text-body text-muted tabular-nums">{formatDate(doc.expiresAt)}</td>
                <td className="px-4 py-3">
                  <div className="flex items-center justify-end gap-1">
                    {doc.status === "draft" && (
                      <Button
                        size="sm"
                        onClick={() => navigate(`/admin/documents/${doc.id}/place-fields`)}
                        className="btn-settle gap-1.5 h-8"
                      >
                        <PenLine className="w-3.5 h-3.5" />
                        Place Fields
                      </Button>
                    )}

                    {doc.token && (
                      <button
                        onClick={() => copySigningLink(doc.token)}
                        className="p-1.5 rounded-md hover:bg-secondary transition-colors"
                        title="Copy signing link"
                      >
                        <Copy className="w-4 h-4 text-muted" />
                      </button>
                    )}
                    {(doc.status === "pending" || doc.status === "viewed") && doc.token && (
                      <>
                        {(() => {
                          const raw = rawDocuments.find((d) =>
                            d.sign_requests.some((r) => r.id === doc.id)
                          );
                          return raw ? (
                            <button
                              onClick={() => navigate(`/admin/documents/${raw.id}/place-fields`)}
                              className="p-1.5 rounded-md hover:bg-secondary transition-colors"
                              title="Edit fields (invalidates current link)"
                            >
                              <Pencil className="w-4 h-4 text-muted" />
                            </button>
                          ) : null;
                        })()}
                        <button
                          onClick={() => handleResend(doc)}
                          className="p-1.5 rounded-md hover:bg-secondary transition-colors"
                          title="Resend email"
                          disabled={resendMutation.isPending}
                        >
                          <RefreshCw className="w-4 h-4 text-muted" />
                        </button>
                        <button
                          onClick={() => handleCancel(doc)}
                          className="p-1.5 rounded-md hover:bg-secondary transition-colors"
                          title="Cancel request"
                          disabled={cancelMutation.isPending}
                        >
                          <XCircle className="w-4 h-4 text-muted" />
                        </button>
                      </>
                    )}

                    {(doc.signedPath || doc.originalPath) && doc.status !== "draft" && (
                      <button
                        onClick={() => handleDownload(doc)}
                        className="p-1.5 rounded-md hover:bg-secondary transition-colors"
                        title={doc.signedPath ? "Download signed document" : "Download original"}
                      >
                        <Download className="w-4 h-4 text-muted" />
                      </button>
                    )}

                    {doc.status !== "draft" && (() => {
                      const raw = rawDocuments.find((d) =>
                        d.sign_requests.some((r) => r.id === doc.id)
                      );
                      return raw ? (
                        <button
                          onClick={() => setAuditState({ doc: raw, signRequestId: doc.id })}
                          className="p-1.5 rounded-md hover:bg-secondary transition-colors"
                          title="View audit trail"
                        >
                          <Shield className="w-4 h-4 text-muted" />
                        </button>
                      ) : null;
                    })()}

                    <button
                      onClick={() => setPendingDelete(doc)}
                      className="p-1.5 rounded-md hover:bg-destructive/10 transition-colors"
                      title="Delete document"
                    >
                      <Trash2 className="w-4 h-4 text-destructive" />
                    </button>
                  </div>
                </td>
              </tr>
            ))
          )}
        </tbody>
      </table>

      <AlertDialog open={!!pendingDelete} onOpenChange={(open) => !open && !deleteMutation.isPending && setPendingDelete(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete document?</AlertDialogTitle>
            <AlertDialogDescription>
              Permanently delete '{pendingDelete?.title}'? This removes the PDF file, all signatures,
              and signing requests. This cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={deleteMutation.isPending}>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={(e) => {
                e.preventDefault();
                handleDelete();
              }}
              disabled={deleteMutation.isPending}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              {deleteMutation.isPending && <Loader2 className="w-4 h-4 mr-2 animate-spin" />}
              Delete Permanently
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      <AuditTrailDialog
        open={!!auditState}
        onClose={() => setAuditState(null)}
        document={auditState?.doc ?? null}
        signRequestId={auditState?.signRequestId}
      />
    </div>
  );
}
