import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Upload, X, FileText, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

interface UploadDialogProps {
  open: boolean;
  onClose: () => void;
  onSubmit: (data: { title: string; file: File }) => Promise<void> | void;
}

export function UploadDialog({ open, onClose, onSubmit }: UploadDialogProps) {
  const [title, setTitle] = useState("");
  const [file, setFile] = useState<File | null>(null);
  const [dragOver, setDragOver] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setDragOver(false);
    const droppedFile = e.dataTransfer.files[0];
    if (droppedFile?.type === "application/pdf") setFile(droppedFile);
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFile = e.target.files?.[0];
    if (selectedFile) setFile(selectedFile);
  };

  const handleSubmit = async () => {
    if (title && file) {
      setIsSubmitting(true);
      try {
        await onSubmit({ title, file });
        setTitle("");
        setFile(null);
      } finally {
        setIsSubmitting(false);
      }
    }
  };

  return (
    <AnimatePresence>
      {open && (
        <>
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-foreground/20 backdrop-blur-sm z-50"
            onClick={onClose}
          />
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.95 }}
            transition={{ duration: 0.2, ease: [0.16, 1, 0.3, 1] }}
            className="fixed top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-full max-w-lg bg-card rounded-lg border vault-shadow-lg z-50"
            transformTemplate={(_, generated) => generated}
          >
            <div className="flex items-center justify-between p-4 border-b">
              <h2 className="text-display text-foreground">New Document</h2>
              <button onClick={onClose} className="p-1.5 rounded-md hover:bg-secondary transition-colors">
                <X className="w-4 h-4 text-muted" />
              </button>
            </div>

            <div className="p-4 space-y-4">
              <div className="space-y-1.5">
                <Label className="text-body font-medium">Document Title</Label>
                <Input
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  placeholder="Employment Agreement — John Doe"
                  className="text-body"
                />
              </div>

              <div className="space-y-1.5">
                <Label className="text-body font-medium">PDF Document</Label>
                <div
                  onDrop={handleDrop}
                  onDragOver={(e) => {
                    e.preventDefault();
                    setDragOver(true);
                  }}
                  onDragLeave={() => setDragOver(false)}
                  className={`border-2 border-dashed rounded-lg p-8 text-center transition-colors cursor-pointer ${
                    dragOver ? "border-accent bg-accent/5" : "border-border hover:border-muted"
                  }`}
                  onClick={() => document.getElementById("file-input")?.click()}
                >
                  <input id="file-input" type="file" accept=".pdf" className="hidden" onChange={handleFileSelect} />
                  {file ? (
                    <div className="flex items-center justify-center gap-2">
                      <FileText className="w-5 h-5 text-foreground" />
                      <span className="text-body text-foreground font-medium">{file.name}</span>
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          setFile(null);
                        }}
                        className="p-0.5 rounded hover:bg-secondary"
                      >
                        <X className="w-3.5 h-3.5 text-muted" />
                      </button>
                    </div>
                  ) : (
                    <>
                      <Upload className="w-8 h-8 text-muted mx-auto mb-2" />
                      <p className="text-body text-muted">Drop a PDF here or click to browse</p>
                    </>
                  )}
                </div>
              </div>
            </div>

            <div className="flex items-center justify-end gap-2 p-4 border-t">
              <Button variant="outline" onClick={onClose} disabled={isSubmitting} className="text-body btn-settle">
                Cancel
              </Button>
              <Button onClick={handleSubmit} disabled={!title || !file || isSubmitting} className="text-body btn-settle gap-2">
                {isSubmitting && <Loader2 className="w-4 h-4 animate-spin" />}
                {isSubmitting ? "Uploading..." : "Upload & Place Fields"}
              </Button>
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}
