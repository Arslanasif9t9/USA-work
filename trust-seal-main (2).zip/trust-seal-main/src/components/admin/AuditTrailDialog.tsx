import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { StatusBadge } from "@/components/ui/status-badge";
import { DocumentWithRequests } from "@/hooks/use-documents";
import { DocumentStatus } from "@/types/document";

interface Props {
  open: boolean;
  onClose: () => void;
  document: DocumentWithRequests | null;
  signRequestId?: string;
}

function parseUserAgent(ua?: string | null): string {
  if (!ua) return "Unknown";
  let browser = "Unknown browser";
  let os = "Unknown OS";
  if (ua.includes("Edg/")) browser = "Edge";
  else if (ua.includes("Chrome/")) browser = "Chrome";
  else if (ua.includes("Firefox/")) browser = "Firefox";
  else if (ua.includes("Safari/")) browser = "Safari";
  if (ua.includes("Windows")) os = "Windows";
  else if (ua.includes("Mac OS")) os = "macOS";
  else if (ua.includes("Android")) os = "Android";
  else if (ua.includes("iPhone") || ua.includes("iPad")) os = "iOS";
  else if (ua.includes("Linux")) os = "Linux";
  return `${browser} on ${os}`;
}

function formatDateTime(iso?: string | null): string {
  if (!iso) return "—";
  return new Date(iso).toLocaleString("en-US", {
    year: "numeric",
    month: "short",
    day: "numeric",
    hour: "numeric",
    minute: "2-digit",
    second: "2-digit",
  });
}

function relativeTime(from: string, to: string): string {
  const diff = new Date(to).getTime() - new Date(from).getTime();
  if (diff < 0) return "";
  const s = Math.floor(diff / 1000);
  if (s < 60) return `${s}s later`;
  const m = Math.floor(s / 60);
  if (m < 60) return `${m}m later`;
  const h = Math.floor(m / 60);
  const rm = m % 60;
  if (h < 24) return `${h}h ${rm}m later`;
  const d = Math.floor(h / 24);
  const rh = h % 24;
  return `${d}d ${rh}h later`;
}

export function AuditTrailDialog({ open, onClose, document, signRequestId }: Props) {
  const [showRawUa, setShowRawUa] = useState(false);

  if (!document) return null;
  const req =
    document.sign_requests.find((r) => r.id === signRequestId) ||
    document.sign_requests[0];
  if (!req) return null;

  const sig = req.signatures?.[0];
  const now = Date.now();
  const isExpired = new Date(req.expires_at).getTime() < now && req.status !== "signed";

  const displayStatus: DocumentStatus =
    req.status === "signed"
      ? "signed"
      : req.status === "cancelled"
        ? "cancelled"
        : isExpired
          ? "expired"
          : (req.status as DocumentStatus);

  const signerName = sig?.signer_name || req.signer_name || "—";
  const signerIp = (sig?.signer_ip as any) || (req.signer_ip as any) || "—";
  const ua = sig?.signer_user_agent || req.signer_user_agent || "";

  type Event = { label: string; ts: string };
  const events: Event[] = [];
  events.push({ label: "Document created", ts: req.created_at });
  if (req.sent_at) events.push({ label: "Link sent to signer", ts: req.sent_at });
  if (req.viewed_at) events.push({ label: "Document viewed by signer", ts: req.viewed_at });
  const signedTs = req.signed_at || sig?.created_at;
  if (signedTs) events.push({ label: "Document signed", ts: signedTs });
  if (req.status === "cancelled") events.push({ label: "Request cancelled", ts: req.created_at });
  if (isExpired) events.push({ label: "Link expired", ts: req.expires_at });

  events.sort((a, b) => new Date(a.ts).getTime() - new Date(b.ts).getTime());

  const tokenShort = req.token ? `${req.token.slice(0, 8)}...` : "—";

  return (
    <Dialog open={open} onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="max-w-xl max-h-[85vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Audit Trail</DialogTitle>
          <p className="text-body text-muted">{document.title}</p>
        </DialogHeader>

        <div className="space-y-5">
          {/* STATUS */}
          <section>
            <h3 className="text-meta font-medium text-muted uppercase tracking-wide mb-2">Status</h3>
            <div className="rounded-md border bg-secondary/30 p-3 space-y-1.5">
              <div className="flex items-center gap-3">
                <StatusBadge status={displayStatus}>
                  {displayStatus.charAt(0).toUpperCase() + displayStatus.slice(1)}
                </StatusBadge>
                <span className="text-meta font-mono text-muted">Token: {tokenShort}</span>
              </div>
              <p className="text-meta text-muted">Expires: {formatDateTime(req.expires_at)}</p>
            </div>
          </section>

          {/* SIGNER */}
          <section>
            <h3 className="text-meta font-medium text-muted uppercase tracking-wide mb-2">Signer</h3>
            <div className="rounded-md border bg-secondary/30 p-3 space-y-1 text-body">
              <div className="grid grid-cols-[80px_1fr] gap-x-3">
                <span className="text-muted">Email:</span>
                <span className="text-foreground">{req.signer_email || "—"}</span>
                <span className="text-muted">Name:</span>
                <span className="text-foreground">{signerName}</span>
                <span className="text-muted">IP:</span>
                <span className="text-foreground font-mono text-meta">{signerIp || "—"}</span>
                <span className="text-muted">Browser:</span>
                <span className="text-foreground">
                  {parseUserAgent(ua)}
                  {ua && (
                    <button
                      onClick={() => setShowRawUa((v) => !v)}
                      className="ml-2 text-meta text-accent hover:underline"
                    >
                      {showRawUa ? "Hide raw" : "Show raw"}
                    </button>
                  )}
                </span>
              </div>
              {showRawUa && ua && (
                <pre className="mt-2 p-2 bg-background border rounded text-meta font-mono whitespace-pre-wrap break-all text-muted">
                  {ua}
                </pre>
              )}
            </div>
          </section>

          {/* TIMELINE */}
          <section>
            <h3 className="text-meta font-medium text-muted uppercase tracking-wide mb-2">Timeline</h3>
            <ol className="relative space-y-4 pl-5">
              {events.map((ev, i) => (
                <li key={i} className="relative">
                  <span className="absolute -left-[18px] top-1.5 w-2.5 h-2.5 rounded-full bg-accent ring-2 ring-background" />
                  {i < events.length - 1 && (
                    <span className="absolute -left-[12px] top-4 bottom-[-1rem] w-px bg-border" />
                  )}
                  <p className="text-body text-foreground">{ev.label}</p>
                  <p className="text-meta text-muted tabular-nums">
                    {formatDateTime(ev.ts)}
                    {i > 0 && (
                      <span className="ml-2">· {relativeTime(events[i - 1].ts, ev.ts)}</span>
                    )}
                  </p>
                </li>
              ))}
            </ol>
          </section>

          {/* TOKEN */}
          <section>
            <h3 className="text-meta font-medium text-muted uppercase tracking-wide mb-1">
              Token (for support)
            </h3>
            <p className="text-meta font-mono text-foreground break-all select-all bg-secondary/30 border rounded p-2">
              {req.token || "—"}
            </p>
          </section>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={onClose}>
            Close
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
