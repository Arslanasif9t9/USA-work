import { FileText, LayoutDashboard, Send, Archive, Settings } from "lucide-react";
import { cn } from "@/lib/utils";
import { useAuth } from "@/hooks/use-auth";

interface NavItem {
  label: string;
  icon: React.ElementType;
  id: string;
}

const navItems: NavItem[] = [
  { label: "Dashboard", icon: LayoutDashboard, id: "dashboard" },
  { label: "Documents", icon: FileText, id: "documents" },
  { label: "Sent", icon: Send, id: "sent" },
  { label: "Archive", icon: Archive, id: "archive" },
  { label: "Settings", icon: Settings, id: "settings" },
];

interface AdminSidebarProps {
  activeTab: string;
  onTabChange: (tab: string) => void;
  counts?: { documents: number; sent: number };
}

export function AdminSidebar({ activeTab, onTabChange, counts }: AdminSidebarProps) {
  const { user } = useAuth();

  return (
    <aside className="fixed left-0 top-0 bottom-0 w-60 bg-sidebar text-sidebar-foreground flex flex-col z-40">
      <div className="p-4 border-b border-sidebar-border">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-lg bg-sidebar-accent flex items-center justify-center">
            <FileText className="w-4 h-4 text-sidebar-primary" />
          </div>
          <div>
            <h1 className="text-sm font-semibold text-sidebar-primary">DocuSign Legal</h1>
            <p className="text-meta text-sidebar-muted">Internal Signing</p>
          </div>
        </div>
      </div>

      <nav className="flex-1 p-2 space-y-0.5">
        {navItems.map((item) => {
          const count = item.id === "documents" ? counts?.documents : item.id === "sent" ? counts?.sent : undefined;
          return (
            <button
              key={item.id}
              onClick={() => onTabChange(item.id)}
              className={cn(
                "w-full flex items-center gap-3 px-3 py-2 rounded-lg text-body transition-colors",
                activeTab === item.id
                  ? "bg-sidebar-accent text-sidebar-accent-foreground"
                  : "text-sidebar-foreground hover:bg-sidebar-accent/50"
              )}
            >
              <item.icon className="w-4 h-4 shrink-0" />
              <span className="flex-1 text-left">{item.label}</span>
              {count !== undefined && (
                <span className="text-meta tabular-nums text-sidebar-muted">{count}</span>
              )}
            </button>
          );
        })}
      </nav>

      <div className="p-4 border-t border-sidebar-border">
        <div className="flex items-center gap-2">
          <div className="w-7 h-7 rounded-full bg-sidebar-accent flex items-center justify-center text-meta text-sidebar-primary font-medium">
            {user?.email?.charAt(0).toUpperCase() ?? "A"}
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-body text-sidebar-primary truncate">Admin</p>
            <p className="text-meta text-sidebar-muted truncate">{user?.email ?? "admin@company.com"}</p>
          </div>
        </div>
      </div>
    </aside>
  );
}
