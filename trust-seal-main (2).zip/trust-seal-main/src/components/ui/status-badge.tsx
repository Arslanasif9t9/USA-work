import { cva, type VariantProps } from "class-variance-authority";
import { cn } from "@/lib/utils";

const statusBadgeVariants = cva(
  "inline-flex items-center rounded-md border px-2 py-0.5 text-meta font-medium tabular-nums",
  {
    variants: {
      status: {
        signed: "bg-success-foreground text-success border-success-border",
        pending: "bg-warning-foreground text-warning border-warning-border",
        viewed: "bg-accent/10 text-accent border-accent/20",
        expired: "bg-secondary text-muted border",
        draft: "bg-secondary text-muted border",
        cancelled: "bg-destructive/10 text-destructive border-destructive/20",
      },
    },
    defaultVariants: {
      status: "pending",
    },
  }
);

interface StatusBadgeProps extends VariantProps<typeof statusBadgeVariants> {
  className?: string;
  children: React.ReactNode;
}

export function StatusBadge({ status, className, children }: StatusBadgeProps) {
  return (
    <span className={cn(statusBadgeVariants({ status }), className)}>
      {children}
    </span>
  );
}
