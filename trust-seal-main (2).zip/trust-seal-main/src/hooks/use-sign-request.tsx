import { useMutation, useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";

export interface SignRequestPayload {
  id: string;
  status: string;
  expiresAt: string;
  viewedAt: string | null;
  signedAt: string | null;
  signerName: string | null;
  signerEmail: string;
  document: {
    title: string;
    fileName: string;
    pdfUrl: string;
  };
  signedDocument: {
    path: string;
    downloadUrl: string | null;
  } | null;
  fields: Array<{
    id: string;
    field_type: "signature" | "initials" | "date" | "text";
    page: number;
    x_percent: number;
    y_percent: number;
    width_percent: number;
    height_percent: number;
    field_order: number;
  }>;
}

export function useSignRequest(token: string | undefined) {
  return useQuery({
    queryKey: ["sign-request", token],
    queryFn: async () => {
      if (!token) throw new Error("No token");

      const { data, error } = await supabase.functions.invoke("get-sign-request", {
        body: { token },
      });

      if (error) throw error;
      if (data?.error) throw new Error(data.error);

      return data as SignRequestPayload;
    },
    enabled: !!token && token !== "demo",
    retry: false,
  });
}

export function useSubmitSignature() {
  return useMutation({
    mutationFn: async ({
      token,
      signerName,
      fieldValues,
    }: {
      token: string;
      signerName: string;
      fieldValues: Record<string, string>;
    }) => {
      const { data, error } = await supabase.functions.invoke("submit-signature", {
        body: {
          token,
          signerName,
          fieldValues,
        },
      });

      if (error) throw error;
      if (data?.error) throw new Error(data.error);

      return data as {
        success: true;
        signedPdfPath: string;
        fileName: string;
        signedAt: string;
        downloadUrl: string;
      };
    },
  });
}
