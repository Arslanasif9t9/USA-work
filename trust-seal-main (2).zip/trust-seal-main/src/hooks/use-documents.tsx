import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "./use-auth";

export interface DocumentWithRequests {
  id: string;
  title: string;
  file_name: string;
  original_path: string;
  document_hash: string | null;
  created_at: string;
  sign_requests: {
    id: string;
    signer_email: string;
    signer_name: string | null;
    status: string;
    token: string;
    created_at: string;
    sent_at: string | null;
    viewed_at: string | null;
    signed_at: string | null;
    expires_at: string;
    signer_ip: string | null;
    signer_user_agent: string | null;
    signatures: {
      signed_pdf_path: string | null;
      signer_name: string | null;
      signer_initials: string | null;
      signer_ip: string | null;
      signer_user_agent: string | null;
      created_at: string;
    }[];
  }[];
}

export interface PlacedField {
  id: string;
  field_type: "signature" | "initials" | "date" | "text";
  page: number;
  x_percent: number;
  y_percent: number;
  width_percent: number;
  height_percent: number;
}

export function useDocuments() {
  const { user } = useAuth();

  return useQuery({
    queryKey: ["documents", user?.id],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("documents")
        .select("*, sign_requests(*, signatures(signed_pdf_path, signer_name, signer_initials, signer_ip, signer_user_agent, created_at))")
        .order("created_at", { ascending: false });

      if (error) throw error;
      return data as DocumentWithRequests[];
    },
    enabled: !!user,
  });
}

export function useDocument(id: string | undefined) {
  return useQuery({
    queryKey: ["document", id],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("documents")
        .select("*, sign_requests(*)")
        .eq("id", id!)
        .single();
      if (error) throw error;
      return data;
    },
    enabled: !!id,
  });
}

export function useSignatureFields(documentId: string | undefined) {
  return useQuery({
    queryKey: ["signature_fields", documentId],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("signature_fields")
        .select("*")
        .eq("document_id", documentId!)
        .order("field_order", { ascending: true });
      if (error) throw error;
      return data as any[];
    },
    enabled: !!documentId,
  });
}

export function useDocumentSignedUrl(path: string | undefined) {
  return useQuery({
    queryKey: ["doc-signed-url", path],
    queryFn: async () => {
      const { data, error } = await supabase.storage
        .from("documents")
        .createSignedUrl(path!, 3600);
      if (error) throw error;
      return data.signedUrl;
    },
    enabled: !!path,
  });
}

export function useUploadDocument() {
  const queryClient = useQueryClient();
  const { user } = useAuth();

  return useMutation({
    mutationFn: async ({ title, file }: { title: string; file: File }) => {
      if (!user) throw new Error("Not authenticated");

      const filePath = `${user.id}/${Date.now()}_${file.name}`;
      const { error: uploadError } = await supabase.storage
        .from("documents")
        .upload(filePath, file, { contentType: file.type || "application/pdf", upsert: false });

      if (uploadError) throw uploadError;

      const { data: doc, error: docError } = await supabase
        .from("documents")
        .insert({
          title,
          file_name: file.name,
          original_path: filePath,
          file_size: file.size,
          created_by: user.id,
        })
        .select()
        .single();

      if (docError) throw docError;

      return { document: doc };
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["documents"] });
    },
  });
}

export function useCreateDocumentFromHtml() {
  const queryClient = useQueryClient();
  const { user } = useAuth();

  return useMutation({
    mutationFn: async ({ title, htmlContent }: { title: string; htmlContent: string }) => {
      if (!user) throw new Error("Not authenticated");
      const { data, error } = await supabase.functions.invoke("generate-pdf-from-html", {
        body: { title, htmlContent },
      });
      if (error) throw error;
      if (data?.error) throw new Error(data.error);
      return data as { success: true; documentId: string; filePath: string };
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["documents"] });
    },
  });
}

export function useGenerateSigningLink() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async ({
      documentId,
      fields,
      signerEmail,
      signerName,
      expiresInDays,
      isReedit,
    }: {
      documentId: string;
      fields: PlacedField[];
      signerEmail: string;
      signerName?: string;
      expiresInDays: number;
      isReedit: boolean;
    }) => {
      if (!fields.length) throw new Error("Place at least one field before generating a link.");
      const emailRe = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!emailRe.test(signerEmail)) throw new Error("Enter a valid signer email.");

      let insertedFieldIds: string[] = [];
      try {
        if (isReedit) {
          const { error: delReqErr } = await supabase
            .from("sign_requests")
            .delete()
            .eq("document_id", documentId);
          if (delReqErr) throw delReqErr;
        }

        const { error: delFieldsErr } = await supabase
          .from("signature_fields")
          .delete()
          .eq("document_id", documentId);
        if (delFieldsErr) throw delFieldsErr;

        const rows = fields.map((f, i) => ({
          document_id: documentId,
          field_type: f.field_type,
          page: f.page,
          x_percent: f.x_percent,
          y_percent: f.y_percent,
          width_percent: f.width_percent,
          height_percent: f.height_percent,
          field_order: i,
        }));
        const { data: inserted, error: insertErr } = await supabase
          .from("signature_fields")
          .insert(rows)
          .select("id");
        if (insertErr) throw insertErr;
        insertedFieldIds = (inserted ?? []).map((r: any) => r.id);

        const expiresAt = new Date(Date.now() + expiresInDays * 24 * 60 * 60 * 1000).toISOString();
        const { data: signReq, error: reqErr } = await supabase
          .from("sign_requests")
          .insert({
            document_id: documentId,
            signer_email: signerEmail,
            signer_name: signerName || null,
            sent_at: new Date().toISOString(),
            expires_at: expiresAt,
            status: "pending",
          })
          .select()
          .single();
        if (reqErr) throw reqErr;

        // Best-effort email; do not block on failure
        try {
          await supabase.functions.invoke("send-signing-email", {
            body: {
              to: signerEmail,
              documentTitle: "",
              signingUrl: `${window.location.origin}/sign/${signReq.token}`,
              expiresAt: signReq.expires_at,
            },
          });
        } catch {
          /* silent */
        }

        const url = `${window.location.origin}/sign/${signReq.token}`;
        return { signRequest: signReq, url };
      } catch (err) {
        if (insertedFieldIds.length) {
          try {
            await supabase.from("signature_fields").delete().in("id", insertedFieldIds);
          } catch { /* ignore rollback errors */ }
        }
        throw err;
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["documents"] });
    },
  });
}

export function useResendSigningLink() {
  return useMutation({
    mutationFn: async ({ signRequestId, email, title, token }: { signRequestId: string; email: string; title: string; token: string }) => {
      const { error } = await supabase
        .from("sign_requests")
        .update({ sent_at: new Date().toISOString() })
        .eq("id", signRequestId);

      if (error) throw error;

      const { data, error: emailError } = await supabase.functions.invoke("send-signing-email", {
        body: {
          to: email,
          documentTitle: title,
          signingUrl: `${window.location.origin}/sign/${token}`,
        },
      });

      if (emailError) throw emailError;
      if (data?.error) throw new Error(data.error);
      if (data?.warning) throw new Error(data.warning);
    },
  });
}

export function useCancelSignRequest() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (signRequestId: string) => {
      const { error } = await supabase
        .from("sign_requests")
        .update({ status: "cancelled" })
        .eq("id", signRequestId);

      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["documents"] });
    },
  });
}

export function useDeleteDocument() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (doc: DocumentWithRequests) => {
      const docPaths: string[] = [];
      const signedPaths: string[] = [];
      if (doc.original_path) docPaths.push(doc.original_path);
      for (const req of doc.sign_requests || []) {
        for (const sig of req.signatures || []) {
          if (sig.signed_pdf_path) signedPaths.push(sig.signed_pdf_path);
        }
      }

      if (docPaths.length) {
        await supabase.storage.from("documents").remove(docPaths).catch(() => {});
      }
      if (signedPaths.length) {
        await supabase.storage.from("signed-documents").remove(signedPaths).catch(() => {});
      }

      const { error } = await supabase.from("documents").delete().eq("id", doc.id);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["documents"] });
    },
  });
}

export function useDownloadDocument() {
  return useMutation({
    mutationFn: async ({ path, bucket }: { path: string; bucket: string }) => {
      const { data, error } = await supabase.storage
        .from(bucket)
        .download(path);

      if (error) throw error;
      return data;
    },
  });
}
