// External document creation endpoint for cross-project calls (e.g., Typeform Admin).
// Auth: shared API key in Authorization: Bearer header (NOT Supabase JWT).
// Note: when sign_requests.source = 'typeform', SignFlow does NOT auto-send the
// notification email — the originating app handles candidate notification itself.

import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
const SERVICE_ROLE = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
const API_KEY = Deno.env.get("SIGNFLOW_API_KEY");

const ALLOWED_PDF_PREFIX = "https://hhckericwqspxeyteecn.supabase.co/storage/";
const MAX_PDF_BYTES = 10 * 1024 * 1024;
const SIGNING_BASE_URL = "https://docusign.expertintuitiveadvisor.com";

const admin = createClient(SUPABASE_URL, SERVICE_ROLE);

function json(body: unknown, status = 200) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { ...corsHeaders, "Content-Type": "application/json" },
  });
}

function err(message: string, code: string, status: number) {
  return json({ error: message, code }, status);
}

function sanitizeText(s: string): string {
  return s.replace(/[<>]/g, "").trim().slice(0, 500);
}

function isEmail(s: string): boolean {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(s);
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });
  if (req.method !== "POST") return err("Method not allowed", "method_not_allowed", 405);

  const ts = new Date().toISOString();

  // 1. Auth
  const authHeader = req.headers.get("Authorization") ?? req.headers.get("authorization");
  if (!authHeader || !authHeader.startsWith("Bearer ")) {
    return err("Missing authorization", "missing_authorization", 401);
  }
  if (!API_KEY) {
    console.error(`[${ts}] SIGNFLOW_API_KEY not configured`);
    return err("Server not configured", "server_misconfigured", 500);
  }
  const token = authHeader.slice("Bearer ".length).trim();
  if (token !== API_KEY) {
    return err("Invalid API key", "invalid_api_key", 403);
  }

  // 2. Validate
  let body: any;
  try {
    body = await req.json();
  } catch {
    return err("Invalid JSON body", "invalid_json", 400);
  }

  const errors: Record<string, string> = {};
  const external_offer_reference = String(body.external_offer_reference ?? "").trim();
  const signer_name = sanitizeText(String(body.signer_name ?? ""));
  const signer_email = String(body.signer_email ?? "").trim().toLowerCase();
  const document_title = sanitizeText(String(body.document_title ?? ""));
  const pdf_url = String(body.pdf_url ?? "").trim();
  const pos = body.signature_field_position ?? {};

  if (!external_offer_reference) errors.external_offer_reference = "required";
  if (!signer_name) errors.signer_name = "required";
  if (!signer_email || !isEmail(signer_email)) errors.signer_email = "invalid email";
  if (!document_title) errors.document_title = "required";
  if (!pdf_url || !pdf_url.startsWith("https://")) errors.pdf_url = "must be https url";
  if (pdf_url && !pdf_url.startsWith(ALLOWED_PDF_PREFIX)) {
    errors.pdf_url = "url not in allowed storage prefix";
  }

  if (Object.keys(errors).length) {
    console.log(`[${ts}] ref=${external_offer_reference} email=${signer_email} FAIL validation`, errors);
    return json({ error: "Invalid input", code: "invalid_input", fields: errors }, 400);
  }

  const page = Number.isFinite(pos.page) ? Number(pos.page) : 4;
  const x = Number(pos.x ?? 100);
  const y = Number(pos.y ?? 350);
  const width = Number(pos.width ?? 200);
  const height = Number(pos.height ?? 60);

  // 3. Fetch PDF
  let pdfBytes: Uint8Array;
  try {
    const res = await fetch(pdf_url);
    if (!res.ok) throw new Error(`status ${res.status}`);
    const ct = res.headers.get("content-type") ?? "";
    const buf = new Uint8Array(await res.arrayBuffer());
    if (buf.byteLength > MAX_PDF_BYTES) {
      return err("PDF exceeds 10MB", "pdf_too_large", 400);
    }
    const magic = String.fromCharCode(...buf.slice(0, 4));
    if (magic !== "%PDF" && !ct.includes("pdf")) {
      return err("Source file is not a PDF", "invalid_pdf", 502);
    }
    pdfBytes = buf;
  } catch (e) {
    console.log(`[${ts}] ref=${external_offer_reference} FAIL fetch_pdf ${e}`);
    return err("Could not fetch PDF from source", "pdf_fetch_failed", 502);
  }

  try {
    // 4. Upload PDF into our documents bucket (so signer flow can load it via signed URL).
    const safeRef = external_offer_reference.replace(/[^a-zA-Z0-9_-]/g, "_");
    const storagePath = `external/${safeRef}-${crypto.randomUUID()}.pdf`;
    const { error: uploadErr } = await admin.storage
      .from("documents")
      .upload(storagePath, pdfBytes, { contentType: "application/pdf", upsert: false });
    if (uploadErr) throw new Error(`storage upload: ${uploadErr.message}`);

    // 5. Insert document
    const { data: doc, error: docErr } = await admin
      .from("documents")
      .insert({
        title: document_title,
        file_name: `${safeRef}.pdf`,
        original_path: storagePath,
        file_size: pdfBytes.byteLength,
        is_template: false,
        created_by: null,
      })
      .select("id")
      .single();
    if (docErr || !doc) throw new Error(`document insert: ${docErr?.message}`);

    // 6. Signature field — stored as percentages of page dimensions.
    // For known NDA templates we override the caller-supplied coords with
    // values aligned to the printed signature rect, and add paired Name + Date
    // fields beneath so signature / name / date read as one block.
    const titleLc = document_title.toLowerCase();
    const isJoiningNDA = /non[- ]?disclosure agreement/.test(titleLc);
    const isExitNDA = /exit settlement|exit nda|confidentiality agreement/.test(titleLc);

    type FieldRow = {
      document_id: string;
      field_type: "signature" | "text" | "date" | "initials";
      page: number;
      x_percent: number;
      y_percent: number;
      width_percent: number;
      height_percent: number;
      field_order: number;
    };

    const rows: FieldRow[] = [];
    if (isJoiningNDA || isExitNDA) {
      const sigPage = isExitNDA ? 3 : 2;
      const sigY = isExitNDA ? 18.69 : 25.25;
      const nameY = isExitNDA ? 29.0 : 35.5;
      const dateY = isExitNDA ? 30.0 : 36.5;
      rows.push(
        { document_id: doc.id, field_type: "signature", page: sigPage, x_percent: 9.97, y_percent: sigY,  width_percent: 39.22, height_percent: 7.58, field_order: 0 },
        { document_id: doc.id, field_type: "text",      page: sigPage, x_percent: 9.97, y_percent: nameY, width_percent: 39.22, height_percent: 3.5, field_order: 1 },
        { document_id: doc.id, field_type: "date",      page: sigPage, x_percent: 54.08, y_percent: dateY, width_percent: 29.42, height_percent: 3.5, field_order: 2 },
      );
    } else {
      const PAGE_W = 612;
      const PAGE_H = 792;
      rows.push({
        document_id: doc.id,
        field_type: "signature",
        page,
        x_percent: Math.max(0, Math.min(100, (x / PAGE_W) * 100)),
        y_percent: Math.max(0, Math.min(100, (y / PAGE_H) * 100)),
        width_percent: Math.max(0, Math.min(100, (width / PAGE_W) * 100)),
        height_percent: Math.max(0, Math.min(100, (height / PAGE_H) * 100)),
        field_order: 0,
      });
    }

    const { error: fieldErr } = await admin.from("signature_fields").insert(rows);
    if (fieldErr) throw new Error(`field insert: ${fieldErr.message}`);


    // 7. Sign request. source='typeform' means SignFlow's auto-email is skipped;
    // the originating app sends the notification email itself.
    const { data: sr, error: srErr } = await admin
      .from("sign_requests")
      .insert({
        document_id: doc.id,
        signer_email,
        signer_name,
        source: "typeform",
        external_offer_reference,
        status: "pending",
        sent_at: null,
      })
      .select("id, token, expires_at")
      .single();
    if (srErr || !sr) throw new Error(`sign_request insert: ${srErr?.message}`);

    const signing_url = `${SIGNING_BASE_URL}/sign/${sr.token}`;
    console.log(`[${ts}] ref=${external_offer_reference} email=${signer_email} OK doc=${doc.id} sr=${sr.id}`);

    return json({
      success: true,
      document_id: doc.id,
      sign_request_id: sr.id,
      signing_token: sr.token,
      signing_url,
      expires_at: sr.expires_at,
    });
  } catch (e) {
    const msg = e instanceof Error ? e.message : String(e);
    console.error(`[${ts}] ref=${external_offer_reference} FAIL ${msg}`);
    return err("Internal error", "internal_error", 500);
  }
});
