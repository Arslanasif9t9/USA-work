import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
import { PDFDocument, StandardFonts, rgb } from "https://esm.sh/pdf-lib@1.17.1";
import { sendEmail, toBase64 } from "../_shared/send-email.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
const serviceRoleKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;

const admin = createClient(supabaseUrl, serviceRoleKey);

function extractIpAddress(req: Request) {
  const forwardedFor = req.headers.get("x-forwarded-for");
  if (forwardedFor) return forwardedFor.split(",")[0]?.trim() ?? null;
  return req.headers.get("x-real-ip") || req.headers.get("cf-connecting-ip") || null;
}

function decodeDataUrl(dataUrl: string) {
  const match = dataUrl.match(/^data:image\/(png|jpeg);base64,(.+)$/);
  if (!match) throw new Error("Invalid image data URL.");
  const mimeType = match[1] === "jpeg" ? "image/jpeg" : "image/png";
  const binary = atob(match[2]);
  const bytes = Uint8Array.from(binary, (c) => c.charCodeAt(0));
  return { bytes, mimeType };
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { token, signerName, fieldValues } = await req.json();

    if (!token || !signerName || !fieldValues || typeof fieldValues !== "object") {
      return new Response(JSON.stringify({ error: "Missing required fields." }), {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const { data: signRequest, error: fetchError } = await admin
      .from("sign_requests")
      .select(`id, document_id, status, expires_at, documents(file_name, original_path)`)
      .eq("token", token)
      .single();

    if (fetchError || !signRequest) {
      return new Response(JSON.stringify({ error: "Signing request not found." }), {
        status: 404,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    if (signRequest.status === "signed") {
      return new Response(JSON.stringify({ error: "This document has already been signed." }), {
        status: 409,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    if (signRequest.status === "cancelled") {
      return new Response(JSON.stringify({ error: "This signing request has been cancelled." }), {
        status: 410,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    if (new Date(signRequest.expires_at) < new Date()) {
      await admin.from("sign_requests").update({ status: "expired" }).eq("id", signRequest.id);
      return new Response(JSON.stringify({ error: "This signing link has expired." }), {
        status: 410,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    if (!signRequest.documents?.original_path) {
      throw new Error("Document file is missing.");
    }

    // Fetch all fields for the document
    const { data: fields, error: fieldsErr } = await admin
      .from("signature_fields")
      .select("id, field_type, page, x_percent, y_percent, width_percent, height_percent")
      .eq("document_id", signRequest.document_id);

    if (fieldsErr) throw fieldsErr;

    // Download original PDF
    const { data: pdfData, error: pdfDownloadError } = await admin.storage
      .from("documents")
      .download(signRequest.documents.original_path);

    if (pdfDownloadError || !pdfData) {
      throw pdfDownloadError || new Error("Could not load the PDF document.");
    }

    const pdfBytes = await pdfData.arrayBuffer();
    const pdfDoc = await PDFDocument.load(pdfBytes);
    const font = await pdfDoc.embedFont(StandardFonts.Helvetica);

    // Cache embedded signature images by data URL string
    const imageCache = new Map<string, any>();
    const embedImage = async (dataUrl: string) => {
      if (imageCache.has(dataUrl)) return imageCache.get(dataUrl);
      const { bytes, mimeType } = decodeDataUrl(dataUrl);
      const img = mimeType === "image/jpeg" ? await pdfDoc.embedJpg(bytes) : await pdfDoc.embedPng(bytes);
      imageCache.set(dataUrl, img);
      return img;
    };

    // Save first signature image to storage (audit)
    let signaturePath: string | null = null;
    const firstSigField = (fields || []).find((f: any) => f.field_type === "signature" && fieldValues[f.id]);
    if (firstSigField) {
      const dataUrl = fieldValues[firstSigField.id];
      const { bytes, mimeType } = decodeDataUrl(dataUrl);
      signaturePath = `${signRequest.id}/${Date.now()}_signature.${mimeType === "image/jpeg" ? "jpg" : "png"}`;
      const { error: upErr } = await admin.storage
        .from("signatures")
        .upload(signaturePath, new Blob([bytes], { type: mimeType }), {
          contentType: mimeType,
          upsert: false,
        });
      if (upErr) throw upErr;
    }

    const todayStr = new Date().toLocaleDateString("en-US");
    const pageCount = pdfDoc.getPageCount();

    for (const f of fields || []) {
      const pageIndex = (f.page || 1) - 1;
      if (pageIndex < 0 || pageIndex >= pageCount) continue;
      const page = pdfDoc.getPage(pageIndex);
      const pw = page.getWidth();
      const ph = page.getHeight();
      const x = (Number(f.x_percent) / 100) * pw;
      const w = (Number(f.width_percent) / 100) * pw;
      const h = (Number(f.height_percent) / 100) * ph;
      const y = ph - ((Number(f.y_percent) + Number(f.height_percent)) / 100) * ph;

      const value = fieldValues[f.id];

      if (f.field_type === "signature") {
        if (!value) continue;
        const img = await embedImage(value);
        page.drawImage(img, { x, y, width: w, height: h });

        // Paired date drawn directly beneath every signature (no schema/field required)
        const dateSize = 9;
        const dateText = `Date: ${todayStr}`;
        page.drawText(dateText, {
          x,
          y: Math.max(y - dateSize - 2, 4),
          size: dateSize,
          font,
          color: rgb(0.1, 0.1, 0.1),
        });
      } else if (f.field_type === "initials") {
        const text = String(value || "").toUpperCase();
        if (!text) continue;
        // Try image first if it's a data URL
        if (text.startsWith("DATA:")) {
          const img = await embedImage(value);
          page.drawImage(img, { x, y, width: w, height: h });
        } else {
          const size = Math.min(h * 0.6, 14);
          page.drawText(text, {
            x: x + 4,
            y: y + h / 2 - size / 2,
            size,
            font,
            color: rgb(0.1, 0.1, 0.1),
          });
        }
      } else if (f.field_type === "date") {
        const size = Math.min(h * 0.6, 11);
        page.drawText(todayStr, {
          x: x + 4,
          y: y + h / 2 - size / 2,
          size,
          font,
          color: rgb(0.1, 0.1, 0.1),
        });
      } else if (f.field_type === "text") {
        const text = String(value || "");
        if (!text) continue;
        const size = Math.min(h * 0.6, 11);
        page.drawText(text, {
          x: x + 4,
          y: y + h / 2 - size / 2,
          size,
          font,
          color: rgb(0.1, 0.1, 0.1),
        });
      }
    }

    // Audit footer on last page
    const signerIp = extractIpAddress(req);
    const signerUserAgent = req.headers.get("user-agent");
    const lastPage = pdfDoc.getPage(pageCount - 1);
    const footer = `Signed by ${signerName} on ${new Date().toLocaleString("en-US")} · IP ${signerIp ?? "unknown"} · Token ${String(token).slice(0, 8)}`;
    lastPage.drawText(footer, {
      x: 20,
      y: 20,
      size: 7,
      font,
      color: rgb(0.5, 0.5, 0.5),
    });

    const signedPdfBytes = await pdfDoc.save();
    const signedPdfPath = `${signRequest.id}/${Date.now()}_signed.pdf`;
    const { error: signedUploadError } = await admin.storage
      .from("signed-documents")
      .upload(signedPdfPath, new Blob([signedPdfBytes], { type: "application/pdf" }), {
        contentType: "application/pdf",
        upsert: false,
      });
    if (signedUploadError) throw signedUploadError;

    const signedAt = new Date().toISOString();

    const { error: signatureInsertError } = await admin.from("signatures").insert({
      sign_request_id: signRequest.id,
      signer_name: signerName.trim(),
      signer_initials: null,
      signature_image_path: signaturePath ?? signedPdfPath,
      signed_pdf_path: signedPdfPath,
      signer_ip: signerIp,
      signer_user_agent: signerUserAgent,
    });
    if (signatureInsertError) throw signatureInsertError;

    const { data: updatedSR, error: signRequestUpdateError } = await admin.from("sign_requests").update({
      status: "signed",
      signed_at: signedAt,
      signer_name: signerName.trim(),
      signer_ip: signerIp,
      signer_user_agent: signerUserAgent,
    }).eq("id", signRequest.id).select("id, source").single();
    if (signRequestUpdateError) throw signRequestUpdateError;

    // Fire webhook for typeform-sourced requests (fire-and-forget)
    if (updatedSR?.source === "typeform") {
      try {
        fetch(`${supabaseUrl}/functions/v1/deliver-webhook`, {
          method: "POST",
          headers: {
            "Authorization": `Bearer ${serviceRoleKey}`,
            "Content-Type": "application/json",
          },
          body: JSON.stringify({ sign_request_id: signRequest.id }),
        }).catch((err) => console.error("[submit-signature] webhook dispatch error", err));
      } catch (err) {
        console.error("[submit-signature] webhook dispatch threw", err);
      }
    }

    // Fire-and-forget: email signed PDF to internal recipient.
    // Never block signing on email failure.
    (async () => {
      try {
        const { data: pdfBlob, error: dlErr } = await admin.storage
          .from("signed-documents")
          .download(signedPdfPath);
        if (dlErr || !pdfBlob) throw dlErr || new Error("Could not download signed PDF");
        const pdfBuf = await pdfBlob.arrayBuffer();
        const base64 = toBase64(pdfBuf);

        const title = signRequest.documents?.file_name || "Signed Offer";
        const subject = `Signed Offer — ${signerName.trim()}`;
        const html = `
          <div style="font-family: -apple-system, system-ui, sans-serif; color: #0f172a;">
            <h2 style="margin:0 0 12px;">Signed contract received</h2>
            <p style="margin:0 0 8px;"><strong>${signerName.trim()}</strong> has signed the offer.</p>
            <p style="margin:0 0 8px;">Document: ${title}</p>
            <p style="margin:0 0 8px;">Signed at: ${new Date(signedAt).toLocaleString("en-US")}</p>
            <p style="margin:16px 0 0; color:#475569;">The fully executed PDF is attached.</p>
          </div>
        `;

        await sendEmail({
          to: "talent.expertadvisor@outlook.com",
          subject,
          html,
          attachments: [{
            filename: signRequest.documents?.file_name || `signed-${signRequest.id}.pdf`,
            content: base64,
            contentType: "application/pdf",
          }],
        });

        await admin
          .from("sign_requests")
          .update({ signed_pdf_emailed_at: new Date().toISOString() })
          .eq("id", signRequest.id);
      } catch (err) {
        console.error("[submit-signature] signed PDF email failed", err);
      }
    })();




    const { data: signedUrlData, error: signedUrlError } = await admin.storage
      .from("signed-documents")
      .createSignedUrl(signedPdfPath, 60 * 60);

    if (signedUrlError || !signedUrlData?.signedUrl) {
      throw signedUrlError || new Error("Could not create signed download URL.");
    }

    return new Response(JSON.stringify({
      success: true,
      signedPdfPath,
      fileName: signRequest.documents.file_name,
      signedAt,
      downloadUrl: signedUrlData.signedUrl,
    }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (error) {
    console.error("Error in submit-signature:", error);
    return new Response(JSON.stringify({ error: error instanceof Error ? error.message : "Unknown error" }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
