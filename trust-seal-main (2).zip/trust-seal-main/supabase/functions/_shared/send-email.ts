// Shared Resend email sender for SignFlow edge functions.
// Calls api.resend.com directly with Bearer RESEND_API_KEY.
// Supports optional PDF (or any) attachments via base64 content.

const RESEND_API_URL = "https://api.resend.com/emails";
const DEFAULT_FROM = "SignFlow <talent@careers.expertintuitiveadvisor.com>";

export interface EmailAttachment {
  /** Filename shown to the recipient, e.g. "signed-contract.pdf" */
  filename: string;
  /** Base64-encoded file contents (no data: prefix) */
  content: string;
  /** MIME type, defaults to application/pdf */
  contentType?: string;
}

export interface SendEmailParams {
  to: string | string[];
  subject: string;
  html: string;
  text?: string;
  from?: string;
  replyTo?: string | string[];
  cc?: string | string[];
  bcc?: string | string[];
  attachments?: EmailAttachment[];
}

export interface SendEmailResult {
  id: string;
}

/**
 * Send an email through Resend. Throws on non-2xx responses.
 * Requires the RESEND_API_KEY secret to be set on the project.
 */
export async function sendEmail(params: SendEmailParams): Promise<SendEmailResult> {
  const apiKey = Deno.env.get("RESEND_API_KEY");
  if (!apiKey) {
    throw new Error("RESEND_API_KEY is not configured");
  }

  const body: Record<string, unknown> = {
    from: params.from ?? DEFAULT_FROM,
    to: Array.isArray(params.to) ? params.to : [params.to],
    subject: params.subject,
    html: params.html,
  };

  if (params.text) body.text = params.text;
  if (params.replyTo) body.reply_to = params.replyTo;
  if (params.cc) body.cc = params.cc;
  if (params.bcc) body.bcc = params.bcc;

  if (params.attachments?.length) {
    body.attachments = params.attachments.map((a) => ({
      filename: a.filename,
      content: a.content,
      content_type: a.contentType ?? "application/pdf",
    }));
  }

  const res = await fetch(RESEND_API_URL, {
    method: "POST",
    headers: {
      Authorization: `Bearer ${apiKey}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify(body),
  });

  if (!res.ok) {
    const errText = await res.text().catch(() => "");
    throw new Error(`Resend API error ${res.status}: ${errText}`);
  }

  return (await res.json()) as SendEmailResult;
}

/** Helper to convert a Uint8Array / ArrayBuffer to base64 for attachments. */
export function toBase64(bytes: Uint8Array | ArrayBuffer): string {
  const arr = bytes instanceof Uint8Array ? bytes : new Uint8Array(bytes);
  let binary = "";
  const chunk = 0x8000;
  for (let i = 0; i < arr.length; i += chunk) {
    binary += String.fromCharCode(...arr.subarray(i, i + chunk));
  }
  return btoa(binary);
}
