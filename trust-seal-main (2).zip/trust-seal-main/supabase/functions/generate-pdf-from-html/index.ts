import { createClient } from "https://esm.sh/@supabase/supabase-js@2.45.0";
import { PDFDocument, StandardFonts, rgb } from "https://esm.sh/pdf-lib@1.17.1";
import { DOMParser, Element, Node } from "https://deno.land/x/deno_dom@v0.1.45/deno-dom-wasm.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

const PAGE_W = 595.28;
const PAGE_H = 841.89;
const MARGIN = 64;
const MARGIN_TOP = 72;
const MARGIN_BOTTOM = 64;
const CONTENT_W = PAGE_W - 2 * MARGIN;

interface Style {
  size: number;
  bold: boolean;
  italic: boolean;
  underline: boolean;
  align: "left" | "center" | "right" | "justify";
  spaceBefore: number;
  spaceAfter: number;
  lineHeight: number;
  indent: number;
  bullet?: string | null;
  leftBar?: boolean;
}

interface Run {
  text: string;
  bold: boolean;
  italic: boolean;
  underline: boolean;
  fontSize: number | null;
}

function sanitizeFilename(s: string) {
  return s.replace(/[^a-zA-Z0-9-_]+/g, "_").slice(0, 80) || "document";
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });

  try {
    const auth = req.headers.get("Authorization");
    if (!auth) return json({ error: "Unauthorized" }, 401);

    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const anon = Deno.env.get("SUPABASE_ANON_KEY")!;
    const serviceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;

    const userClient = createClient(supabaseUrl, anon, { global: { headers: { Authorization: auth } } });
    const { data: userData, error: userErr } = await userClient.auth.getUser();
    if (userErr || !userData.user) return json({ error: "Unauthorized" }, 401);
    const userId = userData.user.id;

    const body = await req.json();
    const title = String(body?.title || "").trim();
    const html = String(body?.htmlContent || "").trim();
    if (!title) return json({ error: "Title required" }, 400);
    if (!html) return json({ error: "Content required" }, 400);

    const pdfBytes = await renderHtmlToPdf(title, html);

    const fileName = `${sanitizeFilename(title)}.pdf`;
    const filePath = `${userId}/${Date.now()}_${fileName}`;

    const admin = createClient(supabaseUrl, serviceKey);
    const { error: upErr } = await admin.storage
      .from("documents")
      .upload(filePath, pdfBytes, { contentType: "application/pdf", upsert: false });
    if (upErr) return json({ error: `Upload failed: ${upErr.message}` }, 500);

    const { data: doc, error: docErr } = await admin
      .from("documents")
      .insert({
        title,
        file_name: fileName,
        original_path: filePath,
        file_size: pdfBytes.length,
        created_by: userId,
      })
      .select()
      .single();

    if (docErr) {
      await admin.storage.from("documents").remove([filePath]).catch(() => {});
      return json({ error: `DB insert failed: ${docErr.message}` }, 500);
    }

    return json({ success: true, documentId: doc.id, filePath });
  } catch (e) {
    console.error("generate-pdf-from-html error", e);
    return json({ error: (e as Error).message || "Internal error" }, 500);
  }
});

function json(b: unknown, status = 200) {
  return new Response(JSON.stringify(b), {
    status,
    headers: { ...corsHeaders, "Content-Type": "application/json" },
  });
}

async function renderHtmlToPdf(title: string, html: string): Promise<Uint8Array> {
  const pdfDoc = await PDFDocument.create();
  pdfDoc.setTitle(title);

  const fonts = {
    regular: await pdfDoc.embedFont(StandardFonts.Helvetica),
    bold: await pdfDoc.embedFont(StandardFonts.HelveticaBold),
    italic: await pdfDoc.embedFont(StandardFonts.HelveticaOblique),
    boldItalic: await pdfDoc.embedFont(StandardFonts.HelveticaBoldOblique),
  };

  let page = pdfDoc.addPage([PAGE_W, PAGE_H]);
  let y = PAGE_H - MARGIN_TOP;
  let atPageTop = true;

  const doc = new DOMParser().parseFromString(`<root>${html}</root>`, "text/html");
  if (!doc) throw new Error("Failed to parse HTML");
  const root = doc.querySelector("root") || doc.body;

  const newPage = () => {
    page = pdfDoc.addPage([PAGE_W, PAGE_H]);
    y = PAGE_H - MARGIN_TOP;
    atPageTop = true;
  };

  const ensureSpace = (h: number) => {
    if (y - h < MARGIN_BOTTOM) newPage();
  };

  const baseStyle = (): Style => ({
    size: 11,
    bold: false,
    italic: false,
    underline: false,
    align: "left",
    spaceBefore: 0,
    spaceAfter: 10,
    lineHeight: 1.5,
    indent: 0,
    bullet: null,
  });

  const pickFont = (b: boolean, i: boolean) =>
    b && i ? fonts.boldItalic : b ? fonts.bold : i ? fonts.italic : fonts.regular;

  type Inh = { bold: boolean; italic: boolean; underline: boolean; fontSize: number | null };

  function collectRuns(el: Node, inh: Inh): Run[] {
    const runs: Run[] = [];
    el.childNodes.forEach((child) => {
      if (child.nodeType === 3) {
        const t = (child.nodeValue || "").replace(/\s+/g, " ");
        if (t) runs.push({ text: t, ...inh });
      } else if (child.nodeType === 1) {
        const e = child as Element;
        const tag = e.tagName.toLowerCase();
        const next: Inh = { ...inh };
        if (tag === "strong" || tag === "b") next.bold = true;
        if (tag === "em" || tag === "i") next.italic = true;
        if (tag === "u") next.underline = true;
        const styleAttr = e.getAttribute("style");
        if (styleAttr) {
          const m = styleAttr.match(/font-size:\s*(\d+(?:\.\d+)?)/);
          if (m) next.fontSize = parseFloat(m[1]);
        }
        if (tag === "br") {
          runs.push({ text: "\n", ...inh });
          return;
        }
        runs.push(...collectRuns(e, next));
      }
    });
    return runs;
  }

  function runSize(r: Run, def: number) {
    return r.fontSize ?? def;
  }

  function wrapRuns(runs: Run[], maxW: number, defaultSize: number): Run[][] {
    type Tok = Run & { w: number; isSpace: boolean };
    const tokens: Tok[] = [];
    for (const r of runs) {
      const parts = r.text.split(/(\s+|\n)/);
      for (const p of parts) {
        if (!p) continue;
        if (p === "\n") {
          tokens.push({ ...r, text: "\n", w: 0, isSpace: false });
          continue;
        }
        const isSpace = /^\s+$/.test(p);
        const f = pickFont(r.bold, r.italic);
        tokens.push({ ...r, text: p, w: f.widthOfTextAtSize(p, runSize(r, defaultSize)), isSpace });
      }
    }

    const lines: Run[][] = [];
    let cur: Tok[] = [];
    let curW = 0;
    const flush = () => {
      while (cur.length && cur[cur.length - 1].isSpace) cur.pop();
      lines.push(cur.map((t) => ({ text: t.text, bold: t.bold, italic: t.italic, underline: t.underline, fontSize: t.fontSize })));
      cur = [];
      curW = 0;
    };
    for (const t of tokens) {
      if (t.text === "\n") { flush(); continue; }
      if (curW === 0 && t.isSpace) continue;
      if (curW + t.w > maxW && !t.isSpace) flush();
      cur.push(t);
      curW += t.w;
    }
    if (cur.length) flush();
    return lines;
  }

  function drawLine(line: Run[], style: Style, xStart: number, maxW: number, isLastLine: boolean) {
    let totalW = 0;
    let spaceCount = 0;
    for (const r of line) {
      totalW += pickFont(r.bold, r.italic).widthOfTextAtSize(r.text, runSize(r, style.size));
      if (/^\s+$/.test(r.text)) spaceCount++;
    }

    let x = xStart;
    let extraSpace = 0;
    if (style.align === "center") x = xStart + (maxW - totalW) / 2;
    else if (style.align === "right") x = xStart + (maxW - totalW);
    else if (style.align === "justify" && !isLastLine && spaceCount > 0) {
      extraSpace = (maxW - totalW) / spaceCount;
    }

    for (const r of line) {
      const f = pickFont(r.bold, r.italic);
      const sz = runSize(r, style.size);
      const w = f.widthOfTextAtSize(r.text, sz);
      page.drawText(r.text, { x, y, size: sz, font: f, color: rgb(0, 0, 0) });
      if (r.underline) {
        const off = Math.max(1, sz * 0.12);
        page.drawLine({
          start: { x, y: y - off },
          end: { x: x + w, y: y - off },
          thickness: Math.max(0.5, sz * 0.05),
          color: rgb(0, 0, 0),
        });
      }
      x += w;
      if (extraSpace && /^\s+$/.test(r.text)) x += extraSpace;
    }
  }

  function styleForTag(tag: string): Style {
    const s = baseStyle();
    if (tag === "blockquote") {
      s.italic = true; s.indent = 24; s.spaceBefore = 4; s.spaceAfter = 12; s.leftBar = true;
    }
    return s;
  }

  function applyAlignAttr(el: Element, style: Style) {
    const align = el.getAttribute("style")?.match(/text-align:\s*(left|center|right|justify)/)?.[1] as Style["align"] | undefined;
    if (align) style.align = align;
  }

  function renderBlock(el: Element) {
    const tag = el.tagName.toLowerCase();

    if (tag === "ul" || tag === "ol") {
      const items = Array.from(el.children).filter((c) => c.tagName.toLowerCase() === "li");
      items.forEach((li, idx) => {
        const itemStyle = baseStyle();
        itemStyle.size = 11;
        itemStyle.lineHeight = 1.4;
        itemStyle.spaceAfter = 4;
        itemStyle.indent = 24;
        applyAlignAttr(li as Element, itemStyle);
        const bulletText = tag === "ol" ? `${idx + 1}.` : "•";
        renderParagraph(li as Element, itemStyle, bulletText);
      });
      y -= 6;
      return;
    }

    if (tag === "h1" || tag === "h2" || tag === "h3" || tag === "p" || tag === "blockquote" || tag === "div") {
      const style = tag === "blockquote" ? styleForTag("blockquote") : baseStyle();
      applyAlignAttr(el, style);
      renderParagraph(el, style, "");
      return;
    }

    Array.from(el.children).forEach((c) => renderBlock(c as Element));
  }

  function renderParagraph(el: Element, style: Style, bulletText = "") {
    const inh: Inh = { bold: style.bold, italic: style.italic, underline: style.underline, fontSize: null };
    const runs = collectRuns(el, inh);
    if (!runs.length || runs.every((r) => !r.text.trim() && r.text !== "\n")) {
      y -= style.size * style.lineHeight;
      ensureSpace(0);
      return;
    }
    const xStart = MARGIN + style.indent;
    const maxW = CONTENT_W - style.indent;
    const lines = wrapRuns(runs, maxW, style.size);

    // spaceBefore (skip if at top of page)
    if (!atPageTop && style.spaceBefore) y -= style.spaceBefore;

    const barTop = y;
    let barPage = page;

    lines.forEach((line, idx) => {
      const maxRunSize = line.length
        ? Math.max(...line.map((r) => runSize(r, style.size)))
        : style.size;
      const lineH = maxRunSize * style.lineHeight;
      const needNewPage = y - lineH < MARGIN_BOTTOM;
      if (needNewPage) {
        if (style.leftBar) {
          barPage.drawLine({
            start: { x: MARGIN + style.indent - 10, y: barTop },
            end: { x: MARGIN + style.indent - 10, y: y },
            thickness: 2,
            color: rgb(0.7, 0.7, 0.7),
          });
        }
        newPage();
        barPage = page;
      }
      y -= lineH;
      atPageTop = false;
      if (idx === 0 && bulletText) {
        page.drawText(bulletText, {
          x: MARGIN + Math.max(0, style.indent - 18),
          y,
          size: style.size,
          font: pickFont(false, false),
          color: rgb(0, 0, 0),
        });
      }
      drawLine(line, style, xStart, maxW, idx === lines.length - 1);
    });

    if (style.leftBar) {
      barPage.drawLine({
        start: { x: MARGIN + style.indent - 10, y: barTop },
        end: { x: MARGIN + style.indent - 10, y: y },
        thickness: 2,
        color: rgb(0.7, 0.7, 0.7),
      });
    }

    y -= style.spaceAfter;
  }

  Array.from(root!.children).forEach((c) => renderBlock(c as Element));

  // Page numbers
  const totalPages = pdfDoc.getPageCount();
  for (let i = 0; i < totalPages; i++) {
    const p = pdfDoc.getPage(i);
    const text = `${i + 1} / ${totalPages}`;
    const fontSize = 9;
    const tw = fonts.regular.widthOfTextAtSize(text, fontSize);
    p.drawText(text, {
      x: PAGE_W - MARGIN - tw,
      y: 32,
      size: fontSize,
      font: fonts.regular,
      color: rgb(0.5, 0.5, 0.5),
    });
  }

  const bytes = await pdfDoc.save();
  return bytes;
}
