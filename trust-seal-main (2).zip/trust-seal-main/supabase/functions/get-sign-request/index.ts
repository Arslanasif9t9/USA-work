import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
const serviceRoleKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;

const admin = createClient(supabaseUrl, serviceRoleKey);

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { token } = await req.json();

    if (!token) {
      return new Response(JSON.stringify({ error: "Missing signing token." }), {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const { data, error } = await admin
      .from("sign_requests")
      .select(`
        id,
        document_id,
        status,
        expires_at,
        viewed_at,
        signed_at,
        signer_name,
        signer_email,
        documents(title, file_name, original_path),
        signatures(signed_pdf_path)
      `)
      .eq("token", token)
      .single();

    if (error || !data) {
      return new Response(JSON.stringify({ error: "Signing request not found." }), {
        status: 404,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    if (!data.documents?.original_path) {
      return new Response(JSON.stringify({ error: "Document file is missing." }), {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    if (data.status === "cancelled") {
      return new Response(JSON.stringify({ error: "This signing request has been cancelled." }), {
        status: 410,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const now = new Date();
    const expiresAt = new Date(data.expires_at);

    if (expiresAt < now && data.status !== "signed") {
      await admin
        .from("sign_requests")
        .update({ status: "expired" })
        .eq("id", data.id)
        .neq("status", "signed");

      return new Response(JSON.stringify({ error: "This signing link has expired." }), {
        status: 410,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    let status = data.status;
    let viewedAt = data.viewed_at;

    if (data.status === "pending") {
      viewedAt = new Date().toISOString();
      const { error: updateError } = await admin
        .from("sign_requests")
        .update({ status: "viewed", viewed_at: viewedAt })
        .eq("id", data.id)
        .eq("status", "pending");

      if (!updateError) {
        status = "viewed";
      }
    }

    const { data: originalUrlData, error: originalUrlError } = await admin.storage
      .from("documents")
      .createSignedUrl(data.documents.original_path, 60 * 60);

    if (originalUrlError || !originalUrlData?.signedUrl) {
      throw originalUrlError || new Error("Could not create document URL.");
    }

    const { data: fieldsData, error: fieldsError } = await admin
      .from("signature_fields")
      .select("id, field_type, page, x_percent, y_percent, width_percent, height_percent, field_order")
      .eq("document_id", data.document_id)
      .order("field_order", { ascending: true });

    if (fieldsError) {
      throw fieldsError;
    }

    const signedPath = data.signatures?.find((signature) => signature.signed_pdf_path)?.signed_pdf_path ?? null;
    let signedDownloadUrl: string | null = null;

    if (signedPath) {
      const { data: signedUrlData, error: signedUrlError } = await admin.storage
        .from("signed-documents")
        .createSignedUrl(signedPath, 60 * 60);

      if (!signedUrlError && signedUrlData?.signedUrl) {
        signedDownloadUrl = signedUrlData.signedUrl;
      }
    }

    return new Response(
      JSON.stringify({
        id: data.id,
        status,
        expiresAt: data.expires_at,
        viewedAt,
        signedAt: data.signed_at,
        signerName: data.signer_name,
        signerEmail: data.signer_email,
        document: {
          title: data.documents.title,
          fileName: data.documents.file_name,
          pdfUrl: originalUrlData.signedUrl,
        },
        fields: fieldsData ?? [],
        signedDocument: signedPath
          ? {
              path: signedPath,
              downloadUrl: signedDownloadUrl,
            }
          : null,
      }),
      { headers: { ...corsHeaders, "Content-Type": "application/json" } },
    );
  } catch (error) {
    console.error("Error in get-sign-request:", error);
    return new Response(JSON.stringify({ error: error instanceof Error ? error.message : "Unknown error" }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
