import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type",
};

const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
const serviceRoleKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
const admin = createClient(supabaseUrl, serviceRoleKey);

type PurgeResult = {
  sign_request_id: string;
  document_id: string;
  deleted: boolean;
  errors: string[];
};

async function purgeOne(sr: {
  id: string;
  document_id: string;
  signed_at: string | null;
  signed_pdf_emailed_at: string | null;
  status: string;
}): Promise<PurgeResult> {
  const errors: string[] = [];

  // SAFETY INTERLOCK — re-verify in-code; never purge un-emailed/unsigned rows.
  if (
    sr.status !== "signed" ||
    !sr.signed_at ||
    !sr.signed_pdf_emailed_at
  ) {
    return {
      sign_request_id: sr.id,
      document_id: sr.document_id,
      deleted: false,
      errors: ["safety_interlock_skip"],
    };
  }

  // 1. Load signatures for this sign_request (for file paths).
  const { data: signatures, error: sigErr } = await admin
    .from("signatures")
    .select("id, signature_image_path, signed_pdf_path")
    .eq("sign_request_id", sr.id);
  if (sigErr) errors.push(`load_signatures: ${sigErr.message}`);

  // 2. Delete signature image files + signed PDF files.
  const sigFiles = (signatures ?? [])
    .map((s) => s.signature_image_path)
    .filter((p): p is string => !!p);
  const signedPdfFiles = (signatures ?? [])
    .map((s) => s.signed_pdf_path)
    .filter((p): p is string => !!p);

  if (sigFiles.length) {
    const { error } = await admin.storage.from("signatures").remove(sigFiles);
    if (error) errors.push(`remove_signature_files: ${error.message}`);
  }
  if (signedPdfFiles.length) {
    const { error } = await admin.storage
      .from("signed-documents")
      .remove(signedPdfFiles);
    if (error) errors.push(`remove_signed_pdf_files: ${error.message}`);
  }

  // 3. Delete signatures rows.
  {
    const { error } = await admin
      .from("signatures")
      .delete()
      .eq("sign_request_id", sr.id);
    if (error) errors.push(`delete_signatures: ${error.message}`);
  }

  // 4. Delete signature_fields rows for this document.
  {
    const { error } = await admin
      .from("signature_fields")
      .delete()
      .eq("document_id", sr.document_id);
    if (error) errors.push(`delete_signature_fields: ${error.message}`);
  }

  // 5. Delete sign_requests row.
  {
    const { error } = await admin
      .from("sign_requests")
      .delete()
      .eq("id", sr.id);
    if (error) errors.push(`delete_sign_request: ${error.message}`);
  }

  // 6. Load document for original_path, then delete source PDF from documents bucket.
  const { data: doc, error: docFetchErr } = await admin
    .from("documents")
    .select("id, original_path")
    .eq("id", sr.document_id)
    .maybeSingle();
  if (docFetchErr) errors.push(`load_document: ${docFetchErr.message}`);

  if (doc?.original_path) {
    const { error } = await admin.storage
      .from("documents")
      .remove([doc.original_path]);
    if (error) errors.push(`remove_document_file: ${error.message}`);
  }

  // 7. Delete documents row.
  if (doc) {
    const { error } = await admin
      .from("documents")
      .delete()
      .eq("id", doc.id);
    if (error) errors.push(`delete_document: ${error.message}`);
  }

  return {
    sign_request_id: sr.id,
    document_id: sr.document_id,
    deleted: errors.length === 0,
    errors,
  };
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const cutoffIso = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString();

    // SAFETY INTERLOCK at the query level:
    //   status = 'signed'
    //   AND signed_at < now() - 7 days
    //   AND signed_pdf_emailed_at IS NOT NULL
    const { data: candidates, error } = await admin
      .from("sign_requests")
      .select("id, document_id, signed_at, signed_pdf_emailed_at, status")
      .eq("status", "signed")
      .lt("signed_at", cutoffIso)
      .not("signed_pdf_emailed_at", "is", null);

    if (error) {
      return new Response(
        JSON.stringify({ error: error.message }),
        { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } },
      );
    }

    const results: PurgeResult[] = [];
    for (const sr of candidates ?? []) {
      // Defensive re-check; purgeOne also enforces.
      if (!sr.signed_pdf_emailed_at) continue;
      results.push(await purgeOne(sr));
    }

    const summary = {
      cutoff: cutoffIso,
      considered: candidates?.length ?? 0,
      purged: results.filter((r) => r.deleted).length,
      failed: results.filter((r) => !r.deleted).length,
      results,
    };

    console.log("purge-old-signed-contracts", JSON.stringify(summary));

    return new Response(JSON.stringify(summary), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
      status: 200,
    });
  } catch (e) {
    console.error("purge-old-signed-contracts error", e);
    return new Response(
      JSON.stringify({ error: (e as Error).message }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } },
    );
  }
});
