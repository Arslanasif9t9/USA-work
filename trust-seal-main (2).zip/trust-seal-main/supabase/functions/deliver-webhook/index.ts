import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
const serviceRoleKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
const signflowApiKey = Deno.env.get("SIGNFLOW_API_KEY")!;
const typeformWebhookUrl = Deno.env.get("TYPEFORM_WEBHOOK_URL") || "";

const admin = createClient(supabaseUrl, serviceRoleKey);

// Backoff schedule in seconds: 30s, 2m, 10m, 1h, 6h
const BACKOFF_SECONDS = [30, 120, 600, 3600, 21600];
const MAX_ATTEMPTS = 5;

function hostOnly(url: string): string {
  try { return new URL(url).host; } catch { return "invalid"; }
}

async function attemptDelivery(deliveryId: string) {
  const { data: delivery, error } = await admin
    .from("webhook_deliveries")
    .select("*")
    .eq("id", deliveryId)
    .single();
  if (error || !delivery) {
    console.error("[deliver-webhook] delivery not found", deliveryId, error);
    return { ok: false, status: 0 };
  }

  if (delivery.status === "delivered" || delivery.status === "failed_permanent") {
    return { ok: delivery.status === "delivered", status: delivery.response_code || 0 };
  }

  if (!delivery.destination_url.startsWith("https://")) {
    await admin.from("webhook_deliveries").update({
      status: "failed_permanent",
      last_attempt_at: new Date().toISOString(),
      response_body: "destination_url must be HTTPS",
    }).eq("id", deliveryId);
    return { ok: false, status: 0 };
  }

  const attempt = (delivery.attempt_count || 0) + 1;
  const startedAt = new Date().toISOString();

  let responseCode = 0;
  let responseBody = "";
  let ok = false;
  let networkErr = false;

  try {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 10_000);
    const res = await fetch(delivery.destination_url, {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${signflowApiKey}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify(delivery.payload),
      signal: controller.signal,
    });
    clearTimeout(timeout);
    responseCode = res.status;
    responseBody = (await res.text()).slice(0, 2000);
    ok = res.status >= 200 && res.status < 300;
  } catch (e) {
    networkErr = true;
    responseBody = e instanceof Error ? e.message : String(e);
  }

  console.log(JSON.stringify({
    fn: "deliver-webhook",
    ts: startedAt,
    sign_request_id: delivery.sign_request_id,
    external_offer_reference: (delivery.payload as any)?.external_offer_reference,
    attempt,
    host: hostOnly(delivery.destination_url),
    response_code: responseCode,
    ok,
  }));

  if (ok) {
    await admin.from("webhook_deliveries").update({
      status: "delivered",
      attempt_count: attempt,
      last_attempt_at: startedAt,
      delivered_at: new Date().toISOString(),
      response_code: responseCode,
      response_body: responseBody,
      next_retry_at: null,
    }).eq("id", deliveryId);
    return { ok: true, status: responseCode };
  }

  // Retryable?
  const retryable = networkErr || responseCode >= 500 || responseCode === 408 || responseCode === 429;
  if (!retryable || attempt >= MAX_ATTEMPTS) {
    await admin.from("webhook_deliveries").update({
      status: "failed_permanent",
      attempt_count: attempt,
      last_attempt_at: startedAt,
      response_code: responseCode || null,
      response_body: responseBody,
      next_retry_at: null,
    }).eq("id", deliveryId);
    console.error(`[deliver-webhook] CRITICAL failed_permanent delivery=${deliveryId} attempts=${attempt} code=${responseCode}`);
    return { ok: false, status: responseCode };
  }

  const backoffSec = BACKOFF_SECONDS[Math.min(attempt - 1, BACKOFF_SECONDS.length - 1)];
  const nextRetry = new Date(Date.now() + backoffSec * 1000).toISOString();
  await admin.from("webhook_deliveries").update({
    status: "failed_retrying",
    attempt_count: attempt,
    last_attempt_at: startedAt,
    next_retry_at: nextRetry,
    response_code: responseCode || null,
    response_body: responseBody,
  }).eq("id", deliveryId);
  return { ok: false, status: responseCode };
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });

  try {
    const body = await req.json().catch(() => ({}));
    const { sign_request_id, delivery_id, mode } = body || {};

    // Mode: 'process_retries' — sweep failed_retrying due for retry
    if (mode === "process_retries") {
      const { data: due, error } = await admin
        .from("webhook_deliveries")
        .select("id")
        .eq("status", "failed_retrying")
        .lte("next_retry_at", new Date().toISOString())
        .limit(25);
      if (error) throw error;
      const results: any[] = [];
      for (const row of due || []) {
        results.push({ id: row.id, ...(await attemptDelivery(row.id)) });
      }
      return new Response(JSON.stringify({ processed: results.length, results }), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // Mode: retry a specific delivery_id
    if (delivery_id) {
      const result = await attemptDelivery(delivery_id);
      return new Response(JSON.stringify({ delivery_id, ...result }), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    if (!sign_request_id) {
      return new Response(JSON.stringify({ error: "sign_request_id required" }), {
        status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // Build payload from sign_requests
    const { data: sr, error: srErr } = await admin
      .from("sign_requests")
      .select("id, source, external_offer_reference, signer_email, status, signed_at, signatures(signed_pdf_path)")
      .eq("id", sign_request_id)
      .single();

    if (srErr || !sr) {
      return new Response(JSON.stringify({ error: "sign_request not found" }), {
        status: 404, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    if (sr.source !== "typeform") {
      return new Response(JSON.stringify({ skipped: true, reason: "source not typeform" }), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    if (!typeformWebhookUrl || !typeformWebhookUrl.startsWith("https://")) {
      return new Response(JSON.stringify({ error: "TYPEFORM_WEBHOOK_URL not configured or not HTTPS" }), {
        status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // Generate long-lived signed URL for the signed PDF (1 year)
    let signedPdfUrl: string | null = null;
    const signedPath = (sr as any).signatures?.find((s: any) => s.signed_pdf_path)?.signed_pdf_path ?? null;
    if (signedPath) {
      const { data: urlData, error: urlErr } = await admin.storage
        .from("signed-documents")
        .createSignedUrl(signedPath, 60 * 60 * 24 * 365);
      if (!urlErr && urlData?.signedUrl) signedPdfUrl = urlData.signedUrl;
      else console.error("[deliver-webhook] failed to create signed url", urlErr);
    }

    const payload = {
      event: "signature_completed",
      sign_request_id: sr.id,
      external_offer_reference: sr.external_offer_reference,
      signer_email: sr.signer_email,
      signed_at: sr.signed_at,
      status: sr.status,
      signed_pdf_url: signedPdfUrl,
      timestamp: new Date().toISOString(),
    };

    const { data: created, error: cErr } = await admin
      .from("webhook_deliveries")
      .insert({
        sign_request_id: sr.id,
        destination_url: typeformWebhookUrl,
        payload,
        status: "pending",
      })
      .select("id")
      .single();
    if (cErr || !created) throw cErr || new Error("could not create delivery row");

    const result = await attemptDelivery(created.id);
    return new Response(JSON.stringify({ delivery_id: created.id, ...result }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (e) {
    console.error("[deliver-webhook] error", e);
    return new Response(JSON.stringify({ error: e instanceof Error ? e.message : String(e) }), {
      status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
