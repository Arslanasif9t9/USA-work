
-- Timestamp update function
CREATE OR REPLACE FUNCTION public.update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SET search_path = public;

-- Table 1: Documents (uploaded PDFs)
CREATE TABLE public.documents (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  title TEXT NOT NULL,
  file_name TEXT NOT NULL,
  original_path TEXT NOT NULL,
  file_size BIGINT,
  document_hash TEXT,
  created_by UUID REFERENCES auth.users(id),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

ALTER TABLE public.documents ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Authenticated users can view documents" ON public.documents
  FOR SELECT TO authenticated USING (true);
CREATE POLICY "Authenticated users can insert documents" ON public.documents
  FOR INSERT TO authenticated WITH CHECK (auth.uid() = created_by);
CREATE POLICY "Authenticated users can update own documents" ON public.documents
  FOR UPDATE TO authenticated USING (auth.uid() = created_by);

CREATE TRIGGER update_documents_updated_at
  BEFORE UPDATE ON public.documents
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- Table 2: Sign Requests
CREATE TABLE public.sign_requests (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  document_id UUID NOT NULL REFERENCES public.documents(id) ON DELETE CASCADE,
  signer_email TEXT NOT NULL,
  signer_name TEXT,
  token TEXT NOT NULL UNIQUE DEFAULT encode(gen_random_bytes(32), 'hex'),
  status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'viewed', 'signed', 'expired', 'cancelled')),
  sent_at TIMESTAMPTZ,
  viewed_at TIMESTAMPTZ,
  signed_at TIMESTAMPTZ,
  expires_at TIMESTAMPTZ NOT NULL DEFAULT (now() + interval '72 hours'),
  signer_ip INET,
  signer_user_agent TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

ALTER TABLE public.sign_requests ENABLE ROW LEVEL SECURITY;

-- Authenticated (admin) can manage sign requests
CREATE POLICY "Authenticated users can view sign_requests" ON public.sign_requests
  FOR SELECT TO authenticated USING (true);
CREATE POLICY "Authenticated users can insert sign_requests" ON public.sign_requests
  FOR INSERT TO authenticated WITH CHECK (true);
CREATE POLICY "Authenticated users can update sign_requests" ON public.sign_requests
  FOR UPDATE TO authenticated USING (true);

-- Anonymous users can view/update their own request via token (for signing flow)
CREATE POLICY "Anyone can view sign_request by token" ON public.sign_requests
  FOR SELECT TO anon USING (true);
CREATE POLICY "Anyone can update sign_request for signing" ON public.sign_requests
  FOR UPDATE TO anon USING (true);

CREATE TRIGGER update_sign_requests_updated_at
  BEFORE UPDATE ON public.sign_requests
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- Table 3: Signatures
CREATE TABLE public.signatures (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  sign_request_id UUID NOT NULL REFERENCES public.sign_requests(id) ON DELETE CASCADE,
  signer_name TEXT NOT NULL,
  signer_initials TEXT,
  signature_image_path TEXT NOT NULL,
  signed_pdf_path TEXT,
  signer_ip INET,
  signer_user_agent TEXT,
  signed_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

ALTER TABLE public.signatures ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Authenticated users can view signatures" ON public.signatures
  FOR SELECT TO authenticated USING (true);
CREATE POLICY "Anyone can insert signatures" ON public.signatures
  FOR INSERT TO anon WITH CHECK (true);
CREATE POLICY "Anon can insert signatures" ON public.signatures
  FOR INSERT TO authenticated WITH CHECK (true);

-- Anon can also view documents for the signing flow
CREATE POLICY "Anon can view documents" ON public.documents
  FOR SELECT TO anon USING (true);

-- Storage buckets
INSERT INTO storage.buckets (id, name, public) VALUES ('documents', 'documents', false);
INSERT INTO storage.buckets (id, name, public) VALUES ('signatures', 'signatures', false);
INSERT INTO storage.buckets (id, name, public) VALUES ('signed-documents', 'signed-documents', false);

-- Storage policies for documents bucket
CREATE POLICY "Authenticated users can upload documents" ON storage.objects
  FOR INSERT TO authenticated WITH CHECK (bucket_id = 'documents');
CREATE POLICY "Authenticated users can view documents" ON storage.objects
  FOR SELECT TO authenticated USING (bucket_id = 'documents');
CREATE POLICY "Anon can view documents" ON storage.objects
  FOR SELECT TO anon USING (bucket_id = 'documents');

-- Storage policies for signatures bucket
CREATE POLICY "Anyone can upload signatures" ON storage.objects
  FOR INSERT TO anon WITH CHECK (bucket_id = 'signatures');
CREATE POLICY "Auth can upload signatures" ON storage.objects
  FOR INSERT TO authenticated WITH CHECK (bucket_id = 'signatures');
CREATE POLICY "Anyone can view signatures" ON storage.objects
  FOR SELECT USING (bucket_id = 'signatures');

-- Storage policies for signed-documents bucket
CREATE POLICY "Anyone can upload signed docs" ON storage.objects
  FOR INSERT WITH CHECK (bucket_id = 'signed-documents');
CREATE POLICY "Anyone can view signed docs" ON storage.objects
  FOR SELECT USING (bucket_id = 'signed-documents');
