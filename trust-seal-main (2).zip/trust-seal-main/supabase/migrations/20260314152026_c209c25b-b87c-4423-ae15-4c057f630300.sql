
-- Tighten anon update on sign_requests: only allow updating status from pending/viewed
DROP POLICY "Anyone can update sign_request for signing" ON public.sign_requests;
CREATE POLICY "Anon can update sign_request for signing" ON public.sign_requests
  FOR UPDATE TO anon USING (status IN ('pending', 'viewed'));

-- Tighten authenticated insert on sign_requests to creator's documents
DROP POLICY "Authenticated users can insert sign_requests" ON public.sign_requests;
CREATE POLICY "Authenticated users can insert sign_requests" ON public.sign_requests
  FOR INSERT TO authenticated WITH CHECK (
    EXISTS (SELECT 1 FROM public.documents WHERE id = document_id AND created_by = auth.uid())
  );

-- Tighten authenticated update on sign_requests to creator's documents  
DROP POLICY "Authenticated users can update sign_requests" ON public.sign_requests;
CREATE POLICY "Authenticated users can update sign_requests" ON public.sign_requests
  FOR UPDATE TO authenticated USING (
    EXISTS (SELECT 1 FROM public.documents WHERE id = document_id AND created_by = auth.uid())
  );
