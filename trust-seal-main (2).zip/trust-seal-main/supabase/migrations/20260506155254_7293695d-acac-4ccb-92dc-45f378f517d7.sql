CREATE TABLE public.signature_fields (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  document_id UUID NOT NULL REFERENCES public.documents(id) ON DELETE CASCADE,
  field_type TEXT NOT NULL CHECK (field_type IN ('signature','initials','date','text')),
  page INTEGER NOT NULL CHECK (page >= 1),
  x_percent NUMERIC NOT NULL CHECK (x_percent >= 0 AND x_percent <= 100),
  y_percent NUMERIC NOT NULL CHECK (y_percent >= 0 AND y_percent <= 100),
  width_percent NUMERIC NOT NULL CHECK (width_percent > 0 AND width_percent <= 100),
  height_percent NUMERIC NOT NULL CHECK (height_percent > 0 AND height_percent <= 100),
  field_order INTEGER NOT NULL DEFAULT 0,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX idx_signature_fields_document_id ON public.signature_fields(document_id);

ALTER TABLE public.signature_fields ENABLE ROW LEVEL SECURITY;

-- Owner full CRUD
CREATE POLICY "Owners can select signature_fields"
ON public.signature_fields FOR SELECT TO authenticated
USING (EXISTS (SELECT 1 FROM public.documents d WHERE d.id = signature_fields.document_id AND d.created_by = auth.uid()));

CREATE POLICY "Owners can insert signature_fields"
ON public.signature_fields FOR INSERT TO authenticated
WITH CHECK (EXISTS (SELECT 1 FROM public.documents d WHERE d.id = signature_fields.document_id AND d.created_by = auth.uid()));

CREATE POLICY "Owners can update signature_fields"
ON public.signature_fields FOR UPDATE TO authenticated
USING (EXISTS (SELECT 1 FROM public.documents d WHERE d.id = signature_fields.document_id AND d.created_by = auth.uid()));

CREATE POLICY "Owners can delete signature_fields"
ON public.signature_fields FOR DELETE TO authenticated
USING (EXISTS (SELECT 1 FROM public.documents d WHERE d.id = signature_fields.document_id AND d.created_by = auth.uid()));

-- Anon read via valid sign_request
CREATE POLICY "Anon can view fields via valid sign_request"
ON public.signature_fields FOR SELECT TO anon
USING (EXISTS (
  SELECT 1 FROM public.sign_requests sr
  WHERE sr.document_id = signature_fields.document_id
    AND sr.expires_at > now()
    AND sr.status IN ('pending','viewed')
));