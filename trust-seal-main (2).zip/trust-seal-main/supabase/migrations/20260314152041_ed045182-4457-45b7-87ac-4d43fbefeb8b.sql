
-- Tighten signatures insert: require valid non-signed sign_request
DROP POLICY "Anyone can insert signatures" ON public.signatures;
DROP POLICY "Anon can insert signatures" ON public.signatures;

CREATE POLICY "Anon can insert signatures for valid requests" ON public.signatures
  FOR INSERT TO anon WITH CHECK (
    EXISTS (SELECT 1 FROM public.sign_requests WHERE id = sign_request_id AND status IN ('pending', 'viewed'))
  );
CREATE POLICY "Auth can insert signatures for valid requests" ON public.signatures
  FOR INSERT TO authenticated WITH CHECK (
    EXISTS (SELECT 1 FROM public.sign_requests WHERE id = sign_request_id AND status IN ('pending', 'viewed'))
  );
