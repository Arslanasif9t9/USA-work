-- Tighten documents SELECT (drop "USING true" policies)
DROP POLICY IF EXISTS "Anon can view documents" ON public.documents;
DROP POLICY IF EXISTS "Authenticated users can view documents" ON public.documents;

CREATE POLICY "Users can view own documents"
ON public.documents FOR SELECT TO authenticated
USING (auth.uid() = created_by);

CREATE POLICY "Anon can view documents via valid sign_request"
ON public.documents FOR SELECT TO anon
USING (EXISTS (
  SELECT 1 FROM public.sign_requests
  WHERE sign_requests.document_id = documents.id
    AND sign_requests.expires_at > now()
    AND sign_requests.status IN ('pending','viewed')
));

-- Add DELETE policy on documents
CREATE POLICY "Users can delete own documents"
ON public.documents FOR DELETE TO authenticated
USING (auth.uid() = created_by);

-- Tighten sign_requests SELECT (drop "USING true")
DROP POLICY IF EXISTS "Authenticated users can view sign_requests" ON public.sign_requests;

CREATE POLICY "Users can view own sign_requests"
ON public.sign_requests FOR SELECT TO authenticated
USING (EXISTS (
  SELECT 1 FROM public.documents
  WHERE documents.id = sign_requests.document_id
    AND documents.created_by = auth.uid()
));

-- Tighten signatures SELECT
DROP POLICY IF EXISTS "Authenticated users can view signatures" ON public.signatures;

CREATE POLICY "Users can view own signatures"
ON public.signatures FOR SELECT TO authenticated
USING (EXISTS (
  SELECT 1 FROM public.sign_requests sr
  JOIN public.documents d ON d.id = sr.document_id
  WHERE sr.id = signatures.sign_request_id
    AND d.created_by = auth.uid()
));

-- Add foreign keys with CASCADE so deleting a document cleans up children
ALTER TABLE public.sign_requests
  DROP CONSTRAINT IF EXISTS sign_requests_document_id_fkey,
  ADD CONSTRAINT sign_requests_document_id_fkey
    FOREIGN KEY (document_id) REFERENCES public.documents(id) ON DELETE CASCADE;

ALTER TABLE public.signatures
  DROP CONSTRAINT IF EXISTS signatures_sign_request_id_fkey,
  ADD CONSTRAINT signatures_sign_request_id_fkey
    FOREIGN KEY (sign_request_id) REFERENCES public.sign_requests(id) ON DELETE CASCADE;

-- Storage policies: tighten documents bucket and add DELETE
DROP POLICY IF EXISTS "Authenticated users can upload to documents bucket" ON storage.objects;
DROP POLICY IF EXISTS "Users can upload own documents" ON storage.objects;
DROP POLICY IF EXISTS "Users can view own documents storage" ON storage.objects;
DROP POLICY IF EXISTS "Users can delete own documents storage" ON storage.objects;
DROP POLICY IF EXISTS "Users can delete own signed-documents storage" ON storage.objects;
DROP POLICY IF EXISTS "Users can delete own signatures storage" ON storage.objects;

CREATE POLICY "Users can upload own documents"
ON storage.objects FOR INSERT TO authenticated
WITH CHECK (
  bucket_id = 'documents'
  AND (storage.foldername(name))[1] = auth.uid()::text
);

CREATE POLICY "Users can view own documents storage"
ON storage.objects FOR SELECT TO authenticated
USING (
  bucket_id IN ('documents','signed-documents','signatures')
  AND (storage.foldername(name))[1] = auth.uid()::text
);

CREATE POLICY "Users can delete own documents storage"
ON storage.objects FOR DELETE TO authenticated
USING (
  bucket_id IN ('documents','signed-documents','signatures')
  AND (storage.foldername(name))[1] = auth.uid()::text
);
