ALTER TABLE public.documents
  ADD COLUMN IF NOT EXISTS is_template boolean NOT NULL DEFAULT false;

ALTER TABLE public.sign_requests
  ADD COLUMN IF NOT EXISTS source text NOT NULL DEFAULT 'internal',
  ADD COLUMN IF NOT EXISTS external_offer_reference text;

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint WHERE conname = 'sign_requests_source_check'
  ) THEN
    ALTER TABLE public.sign_requests
      ADD CONSTRAINT sign_requests_source_check
      CHECK (source IN ('internal', 'typeform'));
  END IF;
END $$;

CREATE INDEX IF NOT EXISTS idx_sign_requests_external_offer_reference
  ON public.sign_requests(external_offer_reference);

-- Service role policies (edge function with service role bypasses RLS,
-- but adding explicit policies makes intent clear and future-proof).
DROP POLICY IF EXISTS "Service role full access documents" ON public.documents;
CREATE POLICY "Service role full access documents"
  ON public.documents FOR ALL
  USING (auth.role() = 'service_role')
  WITH CHECK (auth.role() = 'service_role');

DROP POLICY IF EXISTS "Service role full access signature_fields" ON public.signature_fields;
CREATE POLICY "Service role full access signature_fields"
  ON public.signature_fields FOR ALL
  USING (auth.role() = 'service_role')
  WITH CHECK (auth.role() = 'service_role');

DROP POLICY IF EXISTS "Service role full access sign_requests" ON public.sign_requests;
CREATE POLICY "Service role full access sign_requests"
  ON public.sign_requests FOR ALL
  USING (auth.role() = 'service_role')
  WITH CHECK (auth.role() = 'service_role');