CREATE TABLE public.webhook_deliveries (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  sign_request_id uuid REFERENCES public.sign_requests(id) ON DELETE SET NULL,
  destination_url text NOT NULL,
  payload jsonb NOT NULL,
  attempt_count int NOT NULL DEFAULT 0,
  last_attempt_at timestamptz,
  next_retry_at timestamptz,
  status text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','delivered','failed_retrying','failed_permanent')),
  response_code int,
  response_body text,
  created_at timestamptz NOT NULL DEFAULT now(),
  delivered_at timestamptz
);

CREATE INDEX idx_webhook_deliveries_status_retry ON public.webhook_deliveries (status, next_retry_at);
CREATE INDEX idx_webhook_deliveries_sign_request ON public.webhook_deliveries (sign_request_id);

ALTER TABLE public.webhook_deliveries ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Service role full access webhook_deliveries"
  ON public.webhook_deliveries
  FOR ALL
  USING (auth.role() = 'service_role')
  WITH CHECK (auth.role() = 'service_role');