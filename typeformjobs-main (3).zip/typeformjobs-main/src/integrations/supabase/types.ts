export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.5"
  }
  public: {
    Tables: {
      ai_interview_evaluations: {
        Row: {
          ai_recommended: boolean | null
          availability: string | null
          created_at: string
          hunger: string | null
          id: string
          red_flags: string | null
          response_id: string | null
          sentiment: string | null
          session_id: string
          summary: string | null
          tier: string | null
          verdict: string | null
        }
        Insert: {
          ai_recommended?: boolean | null
          availability?: string | null
          created_at?: string
          hunger?: string | null
          id?: string
          red_flags?: string | null
          response_id?: string | null
          sentiment?: string | null
          session_id: string
          summary?: string | null
          tier?: string | null
          verdict?: string | null
        }
        Update: {
          ai_recommended?: boolean | null
          availability?: string | null
          created_at?: string
          hunger?: string | null
          id?: string
          red_flags?: string | null
          response_id?: string | null
          sentiment?: string | null
          session_id?: string
          summary?: string | null
          tier?: string | null
          verdict?: string | null
        }
        Relationships: []
      }
      ai_interview_failures: {
        Row: {
          audio_context_state: string | null
          created_at: string
          device_type: string | null
          failure_stage: string | null
          id: string
          response_id: string | null
          retell_error: string | null
          token: string | null
          user_agent: string | null
        }
        Insert: {
          audio_context_state?: string | null
          created_at?: string
          device_type?: string | null
          failure_stage?: string | null
          id?: string
          response_id?: string | null
          retell_error?: string | null
          token?: string | null
          user_agent?: string | null
        }
        Update: {
          audio_context_state?: string | null
          created_at?: string
          device_type?: string | null
          failure_stage?: string | null
          id?: string
          response_id?: string | null
          retell_error?: string | null
          token?: string | null
          user_agent?: string | null
        }
        Relationships: []
      }
      ai_interview_sessions: {
        Row: {
          cost_usd: number | null
          created_at: string
          duration_seconds: number | null
          ended_at: string | null
          id: string
          merged_video_url: string | null
          recording_url: string | null
          response_id: string | null
          retell_call_id: string | null
          session_hidden: boolean | null
          stage: string | null
          started_at: string | null
          termination_reason: string | null
          transcript: Json | null
          video_url: string | null
        }
        Insert: {
          cost_usd?: number | null
          created_at?: string
          duration_seconds?: number | null
          ended_at?: string | null
          id?: string
          merged_video_url?: string | null
          recording_url?: string | null
          response_id?: string | null
          retell_call_id?: string | null
          session_hidden?: boolean | null
          stage?: string | null
          started_at?: string | null
          termination_reason?: string | null
          transcript?: Json | null
          video_url?: string | null
        }
        Update: {
          cost_usd?: number | null
          created_at?: string
          duration_seconds?: number | null
          ended_at?: string | null
          id?: string
          merged_video_url?: string | null
          recording_url?: string | null
          response_id?: string | null
          retell_call_id?: string | null
          session_hidden?: boolean | null
          stage?: string | null
          started_at?: string | null
          termination_reason?: string | null
          transcript?: Json | null
          video_url?: string | null
        }
        Relationships: []
      }
      answers: {
        Row: {
          answer_text: string | null
          file_url: string | null
          id: string
          question_id: string | null
          response_id: string
        }
        Insert: {
          answer_text?: string | null
          file_url?: string | null
          id?: string
          question_id?: string | null
          response_id: string
        }
        Update: {
          answer_text?: string | null
          file_url?: string | null
          id?: string
          question_id?: string | null
          response_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "answers_question_id_fkey"
            columns: ["question_id"]
            isOneToOne: false
            referencedRelation: "questions"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "answers_response_id_fkey"
            columns: ["response_id"]
            isOneToOne: false
            referencedRelation: "responses"
            referencedColumns: ["id"]
          },
        ]
      }
      app_settings: {
        Row: {
          hr_copy_email: string | null
          id: number
          main_backup_email: string
          updated_at: string
          updated_by_hr_id: string | null
        }
        Insert: {
          hr_copy_email?: string | null
          id?: number
          main_backup_email?: string
          updated_at?: string
          updated_by_hr_id?: string | null
        }
        Update: {
          hr_copy_email?: string | null
          id?: number
          main_backup_email?: string
          updated_at?: string
          updated_by_hr_id?: string | null
        }
        Relationships: []
      }
      candidate_actions: {
        Row: {
          candidate_id: string
          created_at: string
          form_id: string
          id: string
          job_offer_id: string | null
          nudge_last_sent_at: string | null
          nudge_resend_count: number
          offer_last_sent_at: string | null
          offer_resend_count: number
          offer_sent_at: string | null
          offer_signed_at: string | null
          offer_status: string
          recover_reminder_last_sent_at: string | null
          recover_reminder_opt_out: boolean
          response_id: string | null
          round1_appointment_date: string | null
          round1_attendance_marked_at: string | null
          round1_attendance_marked_by_hr_id: string | null
          round1_attendance_status: string | null
          round1_hr_copy_email_override: string | null
          round1_hr_copy_requested: boolean
          round1_hr_copy_sent_at: string | null
          round1_last_sent_at: string | null
          round1_mode: string | null
          round1_reminder_15_sent_at: string | null
          round1_reminder_30_sent_at: string | null
          round1_reminder_sent_at: string | null
          round1_resend_count: number
          round1_sent_at: string | null
          round1_status: string
          round1_zoom_join_url: string | null
          round1_zoom_meeting_id: string | null
          round2_appointment_date: string | null
          round2_attendance_marked_at: string | null
          round2_attendance_marked_by_hr_id: string | null
          round2_attendance_status: string | null
          round2_hr_copy_email_override: string | null
          round2_hr_copy_requested: boolean
          round2_hr_copy_sent_at: string | null
          round2_last_sent_at: string | null
          round2_reminder_15_sent_at: string | null
          round2_reminder_30_sent_at: string | null
          round2_reminder_sent_at: string | null
          round2_resend_count: number
          round2_send_count: number | null
          round2_sent_at: string | null
          round2_status: string
          round2_zoom_join_url: string | null
          round2_zoom_meeting_id: string | null
          updated_at: string
          zoom_send_count: number
        }
        Insert: {
          candidate_id: string
          created_at?: string
          form_id: string
          id?: string
          job_offer_id?: string | null
          nudge_last_sent_at?: string | null
          nudge_resend_count?: number
          offer_last_sent_at?: string | null
          offer_resend_count?: number
          offer_sent_at?: string | null
          offer_signed_at?: string | null
          offer_status?: string
          recover_reminder_last_sent_at?: string | null
          recover_reminder_opt_out?: boolean
          response_id?: string | null
          round1_appointment_date?: string | null
          round1_attendance_marked_at?: string | null
          round1_attendance_marked_by_hr_id?: string | null
          round1_attendance_status?: string | null
          round1_hr_copy_email_override?: string | null
          round1_hr_copy_requested?: boolean
          round1_hr_copy_sent_at?: string | null
          round1_last_sent_at?: string | null
          round1_mode?: string | null
          round1_reminder_15_sent_at?: string | null
          round1_reminder_30_sent_at?: string | null
          round1_reminder_sent_at?: string | null
          round1_resend_count?: number
          round1_sent_at?: string | null
          round1_status?: string
          round1_zoom_join_url?: string | null
          round1_zoom_meeting_id?: string | null
          round2_appointment_date?: string | null
          round2_attendance_marked_at?: string | null
          round2_attendance_marked_by_hr_id?: string | null
          round2_attendance_status?: string | null
          round2_hr_copy_email_override?: string | null
          round2_hr_copy_requested?: boolean
          round2_hr_copy_sent_at?: string | null
          round2_last_sent_at?: string | null
          round2_reminder_15_sent_at?: string | null
          round2_reminder_30_sent_at?: string | null
          round2_reminder_sent_at?: string | null
          round2_resend_count?: number
          round2_send_count?: number | null
          round2_sent_at?: string | null
          round2_status?: string
          round2_zoom_join_url?: string | null
          round2_zoom_meeting_id?: string | null
          updated_at?: string
          zoom_send_count?: number
        }
        Update: {
          candidate_id?: string
          created_at?: string
          form_id?: string
          id?: string
          job_offer_id?: string | null
          nudge_last_sent_at?: string | null
          nudge_resend_count?: number
          offer_last_sent_at?: string | null
          offer_resend_count?: number
          offer_sent_at?: string | null
          offer_signed_at?: string | null
          offer_status?: string
          recover_reminder_last_sent_at?: string | null
          recover_reminder_opt_out?: boolean
          response_id?: string | null
          round1_appointment_date?: string | null
          round1_attendance_marked_at?: string | null
          round1_attendance_marked_by_hr_id?: string | null
          round1_attendance_status?: string | null
          round1_hr_copy_email_override?: string | null
          round1_hr_copy_requested?: boolean
          round1_hr_copy_sent_at?: string | null
          round1_last_sent_at?: string | null
          round1_mode?: string | null
          round1_reminder_15_sent_at?: string | null
          round1_reminder_30_sent_at?: string | null
          round1_reminder_sent_at?: string | null
          round1_resend_count?: number
          round1_sent_at?: string | null
          round1_status?: string
          round1_zoom_join_url?: string | null
          round1_zoom_meeting_id?: string | null
          round2_appointment_date?: string | null
          round2_attendance_marked_at?: string | null
          round2_attendance_marked_by_hr_id?: string | null
          round2_attendance_status?: string | null
          round2_hr_copy_email_override?: string | null
          round2_hr_copy_requested?: boolean
          round2_hr_copy_sent_at?: string | null
          round2_last_sent_at?: string | null
          round2_reminder_15_sent_at?: string | null
          round2_reminder_30_sent_at?: string | null
          round2_reminder_sent_at?: string | null
          round2_resend_count?: number
          round2_send_count?: number | null
          round2_sent_at?: string | null
          round2_status?: string
          round2_zoom_join_url?: string | null
          round2_zoom_meeting_id?: string | null
          updated_at?: string
          zoom_send_count?: number
        }
        Relationships: []
      }
      circular_recipients: {
        Row: {
          created_at: string
          email: string
          id: string
          last_sent_at: string | null
          name: string | null
        }
        Insert: {
          created_at?: string
          email: string
          id?: string
          last_sent_at?: string | null
          name?: string | null
        }
        Update: {
          created_at?: string
          email?: string
          id?: string
          last_sent_at?: string | null
          name?: string | null
        }
        Relationships: []
      }
      circular_signatures: {
        Row: {
          access_token: string | null
          archived_pdf_url: string | null
          circular_id: string | null
          hr_copy_email_override: string | null
          hr_copy_requested: boolean
          hr_copy_sent_at: string | null
          id: string
          reference: string
          sent_at: string
          signed_at: string | null
          signed_pdf_url: string | null
          signer_email: string | null
          signer_name: string | null
          signing_url: string | null
          status: string
          understanding_text: string | null
        }
        Insert: {
          access_token?: string | null
          archived_pdf_url?: string | null
          circular_id?: string | null
          hr_copy_email_override?: string | null
          hr_copy_requested?: boolean
          hr_copy_sent_at?: string | null
          id?: string
          reference: string
          sent_at?: string
          signed_at?: string | null
          signed_pdf_url?: string | null
          signer_email?: string | null
          signer_name?: string | null
          signing_url?: string | null
          status?: string
          understanding_text?: string | null
        }
        Update: {
          access_token?: string | null
          archived_pdf_url?: string | null
          circular_id?: string | null
          hr_copy_email_override?: string | null
          hr_copy_requested?: boolean
          hr_copy_sent_at?: string | null
          id?: string
          reference?: string
          sent_at?: string
          signed_at?: string | null
          signed_pdf_url?: string | null
          signer_email?: string | null
          signer_name?: string | null
          signing_url?: string | null
          status?: string
          understanding_text?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "circular_signatures_circular_id_fkey"
            columns: ["circular_id"]
            isOneToOne: false
            referencedRelation: "circulars"
            referencedColumns: ["id"]
          },
        ]
      }
      circulars: {
        Row: {
          body: string | null
          branded_letterhead: boolean
          created_at: string
          created_by: string | null
          explanation: string | null
          id: string
          recipient_count: number
          title: string | null
        }
        Insert: {
          body?: string | null
          branded_letterhead?: boolean
          created_at?: string
          created_by?: string | null
          explanation?: string | null
          id?: string
          recipient_count?: number
          title?: string | null
        }
        Update: {
          body?: string | null
          branded_letterhead?: boolean
          created_at?: string
          created_by?: string | null
          explanation?: string | null
          id?: string
          recipient_count?: number
          title?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "circulars_created_by_fkey"
            columns: ["created_by"]
            isOneToOne: false
            referencedRelation: "hr_users"
            referencedColumns: ["id"]
          },
        ]
      }
      email_log: {
        Row: {
          candidate_id: string | null
          created_at: string
          error_message: string | null
          from_address: string
          from_name: string
          id: string
          job_offer_id: string | null
          resend_message_id: string | null
          sender: string
          sent_at: string | null
          stage: string
          status: string
          subject: string
          to_address: string
        }
        Insert: {
          candidate_id?: string | null
          created_at?: string
          error_message?: string | null
          from_address: string
          from_name: string
          id?: string
          job_offer_id?: string | null
          resend_message_id?: string | null
          sender: string
          sent_at?: string | null
          stage: string
          status?: string
          subject: string
          to_address: string
        }
        Update: {
          candidate_id?: string | null
          created_at?: string
          error_message?: string | null
          from_address?: string
          from_name?: string
          id?: string
          job_offer_id?: string | null
          resend_message_id?: string | null
          sender?: string
          sent_at?: string | null
          stage?: string
          status?: string
          subject?: string
          to_address?: string
        }
        Relationships: []
      }
      employee_boards: {
        Row: {
          assigned_agent: string | null
          board_id: string | null
          board_name: string | null
          created_at: string
          id: string
          onboarding_credentials: string | null
          onboarding_notes: string | null
          response_id: string | null
          updated_at: string
        }
        Insert: {
          assigned_agent?: string | null
          board_id?: string | null
          board_name?: string | null
          created_at?: string
          id?: string
          onboarding_credentials?: string | null
          onboarding_notes?: string | null
          response_id?: string | null
          updated_at?: string
        }
        Update: {
          assigned_agent?: string | null
          board_id?: string | null
          board_name?: string | null
          created_at?: string
          id?: string
          onboarding_credentials?: string | null
          onboarding_notes?: string | null
          response_id?: string | null
          updated_at?: string
        }
        Relationships: []
      }
      form_metadata: {
        Row: {
          created_at: string
          default_job_scope_item_ids: string[]
          form_id: string
          id: string
          position_title: string | null
          updated_at: string
        }
        Insert: {
          created_at?: string
          default_job_scope_item_ids?: string[]
          form_id: string
          id?: string
          position_title?: string | null
          updated_at?: string
        }
        Update: {
          created_at?: string
          default_job_scope_item_ids?: string[]
          form_id?: string
          id?: string
          position_title?: string | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "form_metadata_form_id_fkey"
            columns: ["form_id"]
            isOneToOne: true
            referencedRelation: "forms"
            referencedColumns: ["id"]
          },
        ]
      }
      forms: {
        Row: {
          created_at: string
          created_by: string | null
          description: string | null
          id: string
          slug: string
          status: string
          theme: string
          title: string
          typography: Json
          updated_at: string
        }
        Insert: {
          created_at?: string
          created_by?: string | null
          description?: string | null
          id?: string
          slug: string
          status?: string
          theme?: string
          title?: string
          typography?: Json
          updated_at?: string
        }
        Update: {
          created_at?: string
          created_by?: string | null
          description?: string | null
          id?: string
          slug?: string
          status?: string
          theme?: string
          title?: string
          typography?: Json
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "forms_created_by_fkey"
            columns: ["created_by"]
            isOneToOne: false
            referencedRelation: "users"
            referencedColumns: ["id"]
          },
        ]
      }
      hr_candidate_extras: {
        Row: {
          bank_account_details: string | null
          created_at: string
          digital_pay_gcash: string | null
          hr_badge: string | null
          hr_nickname: string | null
          notes: string | null
          other_notes: string | null
          phone: string | null
          photo_file_url: string | null
          response_id: string
          updated_at: string
          updated_by_hr_id: string | null
        }
        Insert: {
          bank_account_details?: string | null
          created_at?: string
          digital_pay_gcash?: string | null
          hr_badge?: string | null
          hr_nickname?: string | null
          notes?: string | null
          other_notes?: string | null
          phone?: string | null
          photo_file_url?: string | null
          response_id: string
          updated_at?: string
          updated_by_hr_id?: string | null
        }
        Update: {
          bank_account_details?: string | null
          created_at?: string
          digital_pay_gcash?: string | null
          hr_badge?: string | null
          hr_nickname?: string | null
          notes?: string | null
          other_notes?: string | null
          phone?: string | null
          photo_file_url?: string | null
          response_id?: string
          updated_at?: string
          updated_by_hr_id?: string | null
        }
        Relationships: []
      }
      hr_users: {
        Row: {
          created_at: string
          display_name: string
          email: string
          id: string
          is_active: boolean
          nickname: string | null
          personal_meeting_password: string | null
          personal_meeting_url: string | null
          role: string
          zoom_pmi: string | null
          zoom_user_email: string | null
          zoom_user_id: string | null
        }
        Insert: {
          created_at?: string
          display_name: string
          email: string
          id?: string
          is_active?: boolean
          nickname?: string | null
          personal_meeting_password?: string | null
          personal_meeting_url?: string | null
          role?: string
          zoom_pmi?: string | null
          zoom_user_email?: string | null
          zoom_user_id?: string | null
        }
        Update: {
          created_at?: string
          display_name?: string
          email?: string
          id?: string
          is_active?: boolean
          nickname?: string | null
          personal_meeting_password?: string | null
          personal_meeting_url?: string | null
          role?: string
          zoom_pmi?: string | null
          zoom_user_email?: string | null
          zoom_user_id?: string | null
        }
        Relationships: []
      }
      interview_slots: {
        Row: {
          appointment_resend_count: number
          blocked_reason: string | null
          cancelled_due_to_ooo: boolean
          claimed_at: string | null
          claimed_by_hr_id: string | null
          completed_at: string | null
          completion_method: string | null
          created_at: string
          created_by_admin: boolean
          id: string
          notes: string | null
          ooo_period_id: string | null
          reserved_until: string | null
          response_id: string | null
          slot_date: string
          slot_end: string
          slot_start: string
          slot_time: string
          status: string
          taken_over_from_hr_id: string | null
          updated_at: string
          zoom_meeting_id: string | null
        }
        Insert: {
          appointment_resend_count?: number
          blocked_reason?: string | null
          cancelled_due_to_ooo?: boolean
          claimed_at?: string | null
          claimed_by_hr_id?: string | null
          completed_at?: string | null
          completion_method?: string | null
          created_at?: string
          created_by_admin?: boolean
          id?: string
          notes?: string | null
          ooo_period_id?: string | null
          reserved_until?: string | null
          response_id?: string | null
          slot_date: string
          slot_end: string
          slot_start: string
          slot_time: string
          status?: string
          taken_over_from_hr_id?: string | null
          updated_at?: string
          zoom_meeting_id?: string | null
        }
        Update: {
          appointment_resend_count?: number
          blocked_reason?: string | null
          cancelled_due_to_ooo?: boolean
          claimed_at?: string | null
          claimed_by_hr_id?: string | null
          completed_at?: string | null
          completion_method?: string | null
          created_at?: string
          created_by_admin?: boolean
          id?: string
          notes?: string | null
          ooo_period_id?: string | null
          reserved_until?: string | null
          response_id?: string | null
          slot_date?: string
          slot_end?: string
          slot_start?: string
          slot_time?: string
          status?: string
          taken_over_from_hr_id?: string | null
          updated_at?: string
          zoom_meeting_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "interview_slots_claimed_by_hr_id_fkey"
            columns: ["claimed_by_hr_id"]
            isOneToOne: false
            referencedRelation: "hr_users"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "interview_slots_ooo_period_id_fkey"
            columns: ["ooo_period_id"]
            isOneToOne: false
            referencedRelation: "out_of_office_periods"
            referencedColumns: ["id"]
          },
        ]
      }
      job_offers: {
        Row: {
          archived_pdf_url: string | null
          candidate_email: string
          candidate_id: string | null
          candidate_name: string
          created_at: string
          currency: string
          duplicated_from_offer_id: string | null
          employment_status: string
          form_id: string
          hold_effective_date: string | null
          hold_rejoin_date: string | null
          hold_remark: string | null
          hold_set_at: string | null
          hold_set_by_hr_id: string | null
          hold_status: string | null
          hr_copy_email_override: string | null
          hr_copy_requested: boolean
          hr_copy_sent_at: string | null
          id: string
          include_adaptability_clause: boolean
          internal_notes: string | null
          monthly_range_max: number | null
          monthly_range_min: number | null
          offer_reference_id: string
          override_email: string | null
          parallel_group_id: string | null
          performance_bonus_amount: number | null
          performance_bonus_enabled: boolean
          position_title: string
          post_trial_weekly_salary: number
          quarantine_removed: boolean
          raise_applied: boolean
          remarks: string | null
          saturday_end: string | null
          saturday_start: string | null
          schedule_preset_used: string | null
          scope_items: Json
          sent_at: string | null
          signed_at: string | null
          signed_pdf_url: string | null
          signing_token: string | null
          start_date: string | null
          status: string
          sunday_off: boolean
          terminated_at: string | null
          terminated_by_hr_id: string | null
          termination_reason: string | null
          trial_weekly_salary: number
          trial_weeks: number
          weekday_end: string | null
          weekday_start: string | null
          welcome_resend_count: number
        }
        Insert: {
          archived_pdf_url?: string | null
          candidate_email: string
          candidate_id?: string | null
          candidate_name: string
          created_at?: string
          currency?: string
          duplicated_from_offer_id?: string | null
          employment_status?: string
          form_id: string
          hold_effective_date?: string | null
          hold_rejoin_date?: string | null
          hold_remark?: string | null
          hold_set_at?: string | null
          hold_set_by_hr_id?: string | null
          hold_status?: string | null
          hr_copy_email_override?: string | null
          hr_copy_requested?: boolean
          hr_copy_sent_at?: string | null
          id?: string
          include_adaptability_clause?: boolean
          internal_notes?: string | null
          monthly_range_max?: number | null
          monthly_range_min?: number | null
          offer_reference_id?: string
          override_email?: string | null
          parallel_group_id?: string | null
          performance_bonus_amount?: number | null
          performance_bonus_enabled?: boolean
          position_title: string
          post_trial_weekly_salary: number
          quarantine_removed?: boolean
          raise_applied?: boolean
          remarks?: string | null
          saturday_end?: string | null
          saturday_start?: string | null
          schedule_preset_used?: string | null
          scope_items?: Json
          sent_at?: string | null
          signed_at?: string | null
          signed_pdf_url?: string | null
          signing_token?: string | null
          start_date?: string | null
          status?: string
          sunday_off?: boolean
          terminated_at?: string | null
          terminated_by_hr_id?: string | null
          termination_reason?: string | null
          trial_weekly_salary: number
          trial_weeks?: number
          weekday_end?: string | null
          weekday_start?: string | null
          welcome_resend_count?: number
        }
        Update: {
          archived_pdf_url?: string | null
          candidate_email?: string
          candidate_id?: string | null
          candidate_name?: string
          created_at?: string
          currency?: string
          duplicated_from_offer_id?: string | null
          employment_status?: string
          form_id?: string
          hold_effective_date?: string | null
          hold_rejoin_date?: string | null
          hold_remark?: string | null
          hold_set_at?: string | null
          hold_set_by_hr_id?: string | null
          hold_status?: string | null
          hr_copy_email_override?: string | null
          hr_copy_requested?: boolean
          hr_copy_sent_at?: string | null
          id?: string
          include_adaptability_clause?: boolean
          internal_notes?: string | null
          monthly_range_max?: number | null
          monthly_range_min?: number | null
          offer_reference_id?: string
          override_email?: string | null
          parallel_group_id?: string | null
          performance_bonus_amount?: number | null
          performance_bonus_enabled?: boolean
          position_title?: string
          post_trial_weekly_salary?: number
          quarantine_removed?: boolean
          raise_applied?: boolean
          remarks?: string | null
          saturday_end?: string | null
          saturday_start?: string | null
          schedule_preset_used?: string | null
          scope_items?: Json
          sent_at?: string | null
          signed_at?: string | null
          signed_pdf_url?: string | null
          signing_token?: string | null
          start_date?: string | null
          status?: string
          sunday_off?: boolean
          terminated_at?: string | null
          terminated_by_hr_id?: string | null
          termination_reason?: string | null
          trial_weekly_salary?: number
          trial_weeks?: number
          weekday_end?: string | null
          weekday_start?: string | null
          welcome_resend_count?: number
        }
        Relationships: [
          {
            foreignKeyName: "job_offers_duplicated_from_offer_id_fkey"
            columns: ["duplicated_from_offer_id"]
            isOneToOne: false
            referencedRelation: "job_offers"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "job_offers_terminated_by_hr_id_fkey"
            columns: ["terminated_by_hr_id"]
            isOneToOne: false
            referencedRelation: "hr_users"
            referencedColumns: ["id"]
          },
        ]
      }
      job_scope_library: {
        Row: {
          category: string
          created_at: string
          created_by: string | null
          id: string
          text: string
          usage_count: number
        }
        Insert: {
          category?: string
          created_at?: string
          created_by?: string | null
          id?: string
          text: string
          usage_count?: number
        }
        Update: {
          category?: string
          created_at?: string
          created_by?: string | null
          id?: string
          text?: string
          usage_count?: number
        }
        Relationships: []
      }
      known_logins: {
        Row: {
          account_email: string
          device_fingerprint: string
          first_seen: string
          id: string
          last_seen: string
          location: string
        }
        Insert: {
          account_email: string
          device_fingerprint: string
          first_seen?: string
          id?: string
          last_seen?: string
          location: string
        }
        Update: {
          account_email?: string
          device_fingerprint?: string
          first_seen?: string
          id?: string
          last_seen?: string
          location?: string
        }
        Relationships: []
      }
      launches: {
        Row: {
          candidate_name: string | null
          contact_timezone: string | null
          created_at: string
          created_by: string | null
          error_message: string | null
          id: string
          mode: string
          response_id: string | null
          scheduled_for: string | null
          sent_at: string | null
          status: string
          sylvia_instruction: string | null
          whatsapp_number: string
        }
        Insert: {
          candidate_name?: string | null
          contact_timezone?: string | null
          created_at?: string
          created_by?: string | null
          error_message?: string | null
          id?: string
          mode: string
          response_id?: string | null
          scheduled_for?: string | null
          sent_at?: string | null
          status?: string
          sylvia_instruction?: string | null
          whatsapp_number: string
        }
        Update: {
          candidate_name?: string | null
          contact_timezone?: string | null
          created_at?: string
          created_by?: string | null
          error_message?: string | null
          id?: string
          mode?: string
          response_id?: string | null
          scheduled_for?: string | null
          sent_at?: string | null
          status?: string
          sylvia_instruction?: string | null
          whatsapp_number?: string
        }
        Relationships: [
          {
            foreignKeyName: "launches_response_id_fkey"
            columns: ["response_id"]
            isOneToOne: false
            referencedRelation: "responses"
            referencedColumns: ["id"]
          },
        ]
      }
      leave_requests: {
        Row: {
          agreed_with_coverer: boolean | null
          archived_pdf_url: string | null
          ca_amount: string | null
          ca_reason: string | null
          ca_repayment_method: string | null
          coverer_name: string | null
          created_at: string
          decided_at: string | null
          decided_by_hr_id: string | null
          doc_type: string
          external_reference: string
          hours_missed: string | null
          hr_copy_email_override: string | null
          hr_copy_requested: boolean
          hr_copy_sent_at: string | null
          hr_decision_note: string | null
          id: string
          id_body_note: string | null
          id_hr_message: string | null
          id_photo_1_url: string | null
          id_photo_2_url: string | null
          id_text_style: string | null
          leave_type: string
          makeup_choice: string | null
          makeup_plan: string | null
          matched_at: string | null
          matched_response_id: string | null
          num_days: string | null
          pc_amount: string | null
          pc_body_note: string | null
          pc_duration: string | null
          pc_hr_message: string | null
          pc_preferred_time: string | null
          reason: string | null
          response_id: string | null
          signature_data: string | null
          signature_date: string | null
          signed_pdf_url: string | null
          signer_email: string | null
          signer_name: string | null
          start_date: string | null
          status: string
          token: string | null
          token_expires_at: string
          token_used_at: string | null
          trained_coverer: boolean | null
          typed_name: string | null
          updated_at: string
        }
        Insert: {
          agreed_with_coverer?: boolean | null
          archived_pdf_url?: string | null
          ca_amount?: string | null
          ca_reason?: string | null
          ca_repayment_method?: string | null
          coverer_name?: string | null
          created_at?: string
          decided_at?: string | null
          decided_by_hr_id?: string | null
          doc_type?: string
          external_reference: string
          hours_missed?: string | null
          hr_copy_email_override?: string | null
          hr_copy_requested?: boolean
          hr_copy_sent_at?: string | null
          hr_decision_note?: string | null
          id?: string
          id_body_note?: string | null
          id_hr_message?: string | null
          id_photo_1_url?: string | null
          id_photo_2_url?: string | null
          id_text_style?: string | null
          leave_type?: string
          makeup_choice?: string | null
          makeup_plan?: string | null
          matched_at?: string | null
          matched_response_id?: string | null
          num_days?: string | null
          pc_amount?: string | null
          pc_body_note?: string | null
          pc_duration?: string | null
          pc_hr_message?: string | null
          pc_preferred_time?: string | null
          reason?: string | null
          response_id?: string | null
          signature_data?: string | null
          signature_date?: string | null
          signed_pdf_url?: string | null
          signer_email?: string | null
          signer_name?: string | null
          start_date?: string | null
          status?: string
          token?: string | null
          token_expires_at?: string
          token_used_at?: string | null
          trained_coverer?: boolean | null
          typed_name?: string | null
          updated_at?: string
        }
        Update: {
          agreed_with_coverer?: boolean | null
          archived_pdf_url?: string | null
          ca_amount?: string | null
          ca_reason?: string | null
          ca_repayment_method?: string | null
          coverer_name?: string | null
          created_at?: string
          decided_at?: string | null
          decided_by_hr_id?: string | null
          doc_type?: string
          external_reference?: string
          hours_missed?: string | null
          hr_copy_email_override?: string | null
          hr_copy_requested?: boolean
          hr_copy_sent_at?: string | null
          hr_decision_note?: string | null
          id?: string
          id_body_note?: string | null
          id_hr_message?: string | null
          id_photo_1_url?: string | null
          id_photo_2_url?: string | null
          id_text_style?: string | null
          leave_type?: string
          makeup_choice?: string | null
          makeup_plan?: string | null
          matched_at?: string | null
          matched_response_id?: string | null
          num_days?: string | null
          pc_amount?: string | null
          pc_body_note?: string | null
          pc_duration?: string | null
          pc_hr_message?: string | null
          pc_preferred_time?: string | null
          reason?: string | null
          response_id?: string | null
          signature_data?: string | null
          signature_date?: string | null
          signed_pdf_url?: string | null
          signer_email?: string | null
          signer_name?: string | null
          start_date?: string | null
          status?: string
          token?: string | null
          token_expires_at?: string
          token_used_at?: string | null
          trained_coverer?: boolean | null
          typed_name?: string | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "leave_requests_matched_response_id_fkey"
            columns: ["matched_response_id"]
            isOneToOne: false
            referencedRelation: "responses"
            referencedColumns: ["id"]
          },
        ]
      }
      nda_signatures: {
        Row: {
          archived_pdf_url: string | null
          created_at: string
          doc_type: string
          external_reference: string
          hr_copy_email_override: string | null
          hr_copy_requested: boolean
          hr_copy_sent_at: string | null
          id: string
          response_id: string | null
          signed_at: string | null
          signed_pdf_url: string | null
          signer_email: string | null
          signer_name: string | null
          signing_token: string | null
          signing_url: string | null
          status: string
        }
        Insert: {
          archived_pdf_url?: string | null
          created_at?: string
          doc_type?: string
          external_reference: string
          hr_copy_email_override?: string | null
          hr_copy_requested?: boolean
          hr_copy_sent_at?: string | null
          id?: string
          response_id?: string | null
          signed_at?: string | null
          signed_pdf_url?: string | null
          signer_email?: string | null
          signer_name?: string | null
          signing_token?: string | null
          signing_url?: string | null
          status?: string
        }
        Update: {
          archived_pdf_url?: string | null
          created_at?: string
          doc_type?: string
          external_reference?: string
          hr_copy_email_override?: string | null
          hr_copy_requested?: boolean
          hr_copy_sent_at?: string | null
          id?: string
          response_id?: string | null
          signed_at?: string | null
          signed_pdf_url?: string | null
          signer_email?: string | null
          signer_name?: string | null
          signing_token?: string | null
          signing_url?: string | null
          status?: string
        }
        Relationships: []
      }
      notification_log: {
        Row: {
          event_type: string
          id: string
          recipient_email: string
          related_resource_id: string | null
          sent_at: string
          status: string
        }
        Insert: {
          event_type: string
          id?: string
          recipient_email: string
          related_resource_id?: string | null
          sent_at?: string
          status?: string
        }
        Update: {
          event_type?: string
          id?: string
          recipient_email?: string
          related_resource_id?: string | null
          sent_at?: string
          status?: string
        }
        Relationships: []
      }
      onboarding_quiz_attempts: {
        Row: {
          answers: Json | null
          attempt_number: number
          candidate_email: string | null
          candidate_name: string | null
          created_at: string
          id: string
          passed: boolean
          score: number
          token_id: string | null
          total: number
        }
        Insert: {
          answers?: Json | null
          attempt_number: number
          candidate_email?: string | null
          candidate_name?: string | null
          created_at?: string
          id?: string
          passed: boolean
          score: number
          token_id?: string | null
          total?: number
        }
        Update: {
          answers?: Json | null
          attempt_number?: number
          candidate_email?: string | null
          candidate_name?: string | null
          created_at?: string
          id?: string
          passed?: boolean
          score?: number
          token_id?: string | null
          total?: number
        }
        Relationships: [
          {
            foreignKeyName: "onboarding_quiz_attempts_token_id_fkey"
            columns: ["token_id"]
            isOneToOne: false
            referencedRelation: "onboarding_quiz_tokens"
            referencedColumns: ["id"]
          },
        ]
      }
      onboarding_quiz_questions: {
        Row: {
          active: boolean
          correct_index: number
          created_at: string
          id: string
          options: Json
          order_index: number
          question: string
          updated_at: string
        }
        Insert: {
          active?: boolean
          correct_index?: number
          created_at?: string
          id?: string
          options?: Json
          order_index?: number
          question: string
          updated_at?: string
        }
        Update: {
          active?: boolean
          correct_index?: number
          created_at?: string
          id?: string
          options?: Json
          order_index?: number
          question?: string
          updated_at?: string
        }
        Relationships: []
      }
      onboarding_quiz_tokens: {
        Row: {
          after_pass_mode: string
          assigned_group_id: string | null
          attempts_used: number
          candidate_email: string
          candidate_name: string
          created_at: string
          created_by: string | null
          expires_at: string
          id: string
          invalidated_at: string | null
          passed: boolean
          passed_at: string | null
          status: string
          token: string
          updated_at: string
          video_url: string | null
        }
        Insert: {
          after_pass_mode?: string
          assigned_group_id?: string | null
          attempts_used?: number
          candidate_email: string
          candidate_name: string
          created_at?: string
          created_by?: string | null
          expires_at?: string
          id?: string
          invalidated_at?: string | null
          passed?: boolean
          passed_at?: string | null
          status?: string
          token: string
          updated_at?: string
          video_url?: string | null
        }
        Update: {
          after_pass_mode?: string
          assigned_group_id?: string | null
          attempts_used?: number
          candidate_email?: string
          candidate_name?: string
          created_at?: string
          created_by?: string | null
          expires_at?: string
          id?: string
          invalidated_at?: string | null
          passed?: boolean
          passed_at?: string | null
          status?: string
          token?: string
          updated_at?: string
          video_url?: string | null
        }
        Relationships: []
      }
      onboarding_submissions: {
        Row: {
          created_at: string
          digital_pay_gcash: string | null
          email: string | null
          full_name: string | null
          id: string
          onboarding_status: string
          onlinejobs_profile_url: string | null
          phone: string | null
          position_title: string | null
          profile_photo_url: string | null
          response_id: string
          speedtest_screenshot_url: string | null
          submitted_at: string | null
          typing_screenshot_url: string | null
          updated_at: string
        }
        Insert: {
          created_at?: string
          digital_pay_gcash?: string | null
          email?: string | null
          full_name?: string | null
          id?: string
          onboarding_status?: string
          onlinejobs_profile_url?: string | null
          phone?: string | null
          position_title?: string | null
          profile_photo_url?: string | null
          response_id: string
          speedtest_screenshot_url?: string | null
          submitted_at?: string | null
          typing_screenshot_url?: string | null
          updated_at?: string
        }
        Update: {
          created_at?: string
          digital_pay_gcash?: string | null
          email?: string | null
          full_name?: string | null
          id?: string
          onboarding_status?: string
          onlinejobs_profile_url?: string | null
          phone?: string | null
          position_title?: string | null
          profile_photo_url?: string | null
          response_id?: string
          speedtest_screenshot_url?: string | null
          submitted_at?: string | null
          typing_screenshot_url?: string | null
          updated_at?: string
        }
        Relationships: []
      }
      onboarding_tokens: {
        Row: {
          candidate_email: string | null
          candidate_name: string | null
          closed_at: string | null
          created_at: string
          expires_at: string
          id: string
          position_title: string | null
          prefill_data: Json | null
          response_id: string | null
          token: string
          used_at: string | null
        }
        Insert: {
          candidate_email?: string | null
          candidate_name?: string | null
          closed_at?: string | null
          created_at?: string
          expires_at?: string
          id?: string
          position_title?: string | null
          prefill_data?: Json | null
          response_id?: string | null
          token: string
          used_at?: string | null
        }
        Update: {
          candidate_email?: string | null
          candidate_name?: string | null
          closed_at?: string | null
          created_at?: string
          expires_at?: string
          id?: string
          position_title?: string | null
          prefill_data?: Json | null
          response_id?: string | null
          token?: string
          used_at?: string | null
        }
        Relationships: []
      }
      out_of_office_periods: {
        Row: {
          created_at: string
          disabled_at: string | null
          enabled_at: string
          enabled_by_hr_id: string | null
          end_date: string
          id: string
          reason: string | null
          start_date: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          disabled_at?: string | null
          enabled_at?: string
          enabled_by_hr_id?: string | null
          end_date: string
          id?: string
          reason?: string | null
          start_date: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          disabled_at?: string | null
          enabled_at?: string
          enabled_by_hr_id?: string | null
          end_date?: string
          id?: string
          reason?: string | null
          start_date?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "out_of_office_periods_enabled_by_hr_id_fkey"
            columns: ["enabled_by_hr_id"]
            isOneToOne: false
            referencedRelation: "hr_users"
            referencedColumns: ["id"]
          },
        ]
      }
      password_audit_log: {
        Row: {
          action_taken: string
          hr_user_id: string | null
          id: string
          ip_address: string | null
          password_used: string
          target_resource_id: string | null
          timestamp: string
        }
        Insert: {
          action_taken: string
          hr_user_id?: string | null
          id?: string
          ip_address?: string | null
          password_used: string
          target_resource_id?: string | null
          timestamp?: string
        }
        Update: {
          action_taken?: string
          hr_user_id?: string | null
          id?: string
          ip_address?: string | null
          password_used?: string
          target_resource_id?: string | null
          timestamp?: string
        }
        Relationships: [
          {
            foreignKeyName: "password_audit_log_hr_user_id_fkey"
            columns: ["hr_user_id"]
            isOneToOne: false
            referencedRelation: "hr_users"
            referencedColumns: ["id"]
          },
        ]
      }
      questions: {
        Row: {
          created_at: string
          description: string | null
          form_id: string
          id: string
          label: string
          options: Json
          order_index: number
          placeholder: string | null
          required: boolean
          type: string
        }
        Insert: {
          created_at?: string
          description?: string | null
          form_id: string
          id?: string
          label: string
          options?: Json
          order_index?: number
          placeholder?: string | null
          required?: boolean
          type: string
        }
        Update: {
          created_at?: string
          description?: string | null
          form_id?: string
          id?: string
          label?: string
          options?: Json
          order_index?: number
          placeholder?: string | null
          required?: boolean
          type?: string
        }
        Relationships: [
          {
            foreignKeyName: "questions_form_id_fkey"
            columns: ["form_id"]
            isOneToOne: false
            referencedRelation: "forms"
            referencedColumns: ["id"]
          },
        ]
      }
      rebook_tokens: {
        Row: {
          assigned_hr_id: string | null
          candidate_email: string | null
          candidate_name: string | null
          created_at: string
          curated_slot_ids: string[] | null
          expires_at: string
          form_id: string | null
          id: string
          is_universal_zoom: boolean
          last_minted_at: string | null
          marissa_salary: string | null
          marissa_schedule: string | null
          mint_count: number
          new_slot_id: string | null
          original_slot_id: string | null
          response_id: string
          stage: string
          token: string
          used_at: string | null
        }
        Insert: {
          assigned_hr_id?: string | null
          candidate_email?: string | null
          candidate_name?: string | null
          created_at?: string
          curated_slot_ids?: string[] | null
          expires_at?: string
          form_id?: string | null
          id?: string
          is_universal_zoom?: boolean
          last_minted_at?: string | null
          marissa_salary?: string | null
          marissa_schedule?: string | null
          mint_count?: number
          new_slot_id?: string | null
          original_slot_id?: string | null
          response_id: string
          stage?: string
          token: string
          used_at?: string | null
        }
        Update: {
          assigned_hr_id?: string | null
          candidate_email?: string | null
          candidate_name?: string | null
          created_at?: string
          curated_slot_ids?: string[] | null
          expires_at?: string
          form_id?: string | null
          id?: string
          is_universal_zoom?: boolean
          last_minted_at?: string | null
          marissa_salary?: string | null
          marissa_schedule?: string | null
          mint_count?: number
          new_slot_id?: string | null
          original_slot_id?: string | null
          response_id?: string
          stage?: string
          token?: string
          used_at?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "rebook_tokens_assigned_hr_fk"
            columns: ["assigned_hr_id"]
            isOneToOne: false
            referencedRelation: "hr_users"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "rebook_tokens_new_slot_id_fkey"
            columns: ["new_slot_id"]
            isOneToOne: false
            referencedRelation: "interview_slots"
            referencedColumns: ["id"]
          },
        ]
      }
      responses: {
        Row: {
          applicant_id: string
          appointment_cancelled: boolean
          appointment_permanently_deleted: boolean
          assigned_group_id: string | null
          contact_timezone: string | null
          current_question_index: number
          custom_position: string | null
          disqualified_at: string | null
          disqualified_at_stage: string | null
          disqualified_by_hr_id: string | null
          final_outcome: string | null
          form_id: string
          future_shortlisted: boolean
          handled_by_hr_id: string | null
          id: string
          last_activity_at: string
          needs_human: boolean
          needs_human_at: string | null
          offer_sent_at: string | null
          offer_signed_hours: number | null
          override_email: string | null
          override_name: string | null
          preferred_contact_time: string | null
          quarantine_moved_at: string | null
          r1_completed_hours: number | null
          r2_completed_hours: number | null
          removal_reason: string | null
          removed_from_disqualified_view: boolean
          round_1_sent_at: string | null
          round_2_sent_at: string | null
          round_stage: string | null
          scheduled_at: string | null
          scheduled_slot_id: string | null
          session_token: string | null
          status: string
          submitted_at: string
          sylvia_instruction: string | null
          viewed_at: string | null
        }
        Insert: {
          applicant_id?: string
          appointment_cancelled?: boolean
          appointment_permanently_deleted?: boolean
          assigned_group_id?: string | null
          contact_timezone?: string | null
          current_question_index?: number
          custom_position?: string | null
          disqualified_at?: string | null
          disqualified_at_stage?: string | null
          disqualified_by_hr_id?: string | null
          final_outcome?: string | null
          form_id: string
          future_shortlisted?: boolean
          handled_by_hr_id?: string | null
          id?: string
          last_activity_at?: string
          needs_human?: boolean
          needs_human_at?: string | null
          offer_sent_at?: string | null
          offer_signed_hours?: number | null
          override_email?: string | null
          override_name?: string | null
          preferred_contact_time?: string | null
          quarantine_moved_at?: string | null
          r1_completed_hours?: number | null
          r2_completed_hours?: number | null
          removal_reason?: string | null
          removed_from_disqualified_view?: boolean
          round_1_sent_at?: string | null
          round_2_sent_at?: string | null
          round_stage?: string | null
          scheduled_at?: string | null
          scheduled_slot_id?: string | null
          session_token?: string | null
          status?: string
          submitted_at?: string
          sylvia_instruction?: string | null
          viewed_at?: string | null
        }
        Update: {
          applicant_id?: string
          appointment_cancelled?: boolean
          appointment_permanently_deleted?: boolean
          assigned_group_id?: string | null
          contact_timezone?: string | null
          current_question_index?: number
          custom_position?: string | null
          disqualified_at?: string | null
          disqualified_at_stage?: string | null
          disqualified_by_hr_id?: string | null
          final_outcome?: string | null
          form_id?: string
          future_shortlisted?: boolean
          handled_by_hr_id?: string | null
          id?: string
          last_activity_at?: string
          needs_human?: boolean
          needs_human_at?: string | null
          offer_sent_at?: string | null
          offer_signed_hours?: number | null
          override_email?: string | null
          override_name?: string | null
          preferred_contact_time?: string | null
          quarantine_moved_at?: string | null
          r1_completed_hours?: number | null
          r2_completed_hours?: number | null
          removal_reason?: string | null
          removed_from_disqualified_view?: boolean
          round_1_sent_at?: string | null
          round_2_sent_at?: string | null
          round_stage?: string | null
          scheduled_at?: string | null
          scheduled_slot_id?: string | null
          session_token?: string | null
          status?: string
          submitted_at?: string
          sylvia_instruction?: string | null
          viewed_at?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "responses_disqualified_by_hr_id_fkey"
            columns: ["disqualified_by_hr_id"]
            isOneToOne: false
            referencedRelation: "hr_users"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "responses_form_id_fkey"
            columns: ["form_id"]
            isOneToOne: false
            referencedRelation: "forms"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "responses_handled_by_hr_id_fkey"
            columns: ["handled_by_hr_id"]
            isOneToOne: false
            referencedRelation: "hr_users"
            referencedColumns: ["id"]
          },
        ]
      }
      responses_deletion_log: {
        Row: {
          deleted_at: string
          deleted_by_app: string | null
          deleted_by_role: string | null
          deleted_response_id: string | null
          deleted_row: Json | null
          id: string
        }
        Insert: {
          deleted_at?: string
          deleted_by_app?: string | null
          deleted_by_role?: string | null
          deleted_response_id?: string | null
          deleted_row?: Json | null
          id?: string
        }
        Update: {
          deleted_at?: string
          deleted_by_app?: string | null
          deleted_by_role?: string | null
          deleted_response_id?: string | null
          deleted_row?: Json | null
          id?: string
        }
        Relationships: []
      }
      scheduled_sends: {
        Row: {
          attempts: number
          created_at: string
          created_by: string | null
          error: string | null
          id: string
          payload: Json
          response_id: string | null
          scheduled_for: string
          send_type: string
          sent_at: string | null
          status: string
          target_function: string
          timezone: string
        }
        Insert: {
          attempts?: number
          created_at?: string
          created_by?: string | null
          error?: string | null
          id?: string
          payload?: Json
          response_id?: string | null
          scheduled_for: string
          send_type: string
          sent_at?: string | null
          status?: string
          target_function: string
          timezone?: string
        }
        Update: {
          attempts?: number
          created_at?: string
          created_by?: string | null
          error?: string | null
          id?: string
          payload?: Json
          response_id?: string | null
          scheduled_for?: string
          send_type?: string
          sent_at?: string | null
          status?: string
          target_function?: string
          timezone?: string
        }
        Relationships: []
      }
      scheduling_blocked_slots: {
        Row: {
          config_id: string
          created_at: string
          end_at: string
          id: string
          reason: string | null
          start_at: string
        }
        Insert: {
          config_id: string
          created_at?: string
          end_at: string
          id?: string
          reason?: string | null
          start_at: string
        }
        Update: {
          config_id?: string
          created_at?: string
          end_at?: string
          id?: string
          reason?: string | null
          start_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "scheduling_blocked_slots_config_id_fkey"
            columns: ["config_id"]
            isOneToOne: false
            referencedRelation: "scheduling_configs"
            referencedColumns: ["id"]
          },
        ]
      }
      scheduling_bookings: {
        Row: {
          admin_note: string | null
          candidate_email: string | null
          candidate_name: string | null
          candidate_timezone: string | null
          config_id: string
          created_at: string
          decided_at: string | null
          id: string
          response_id: string | null
          slot_end: string
          slot_start: string
          status: string
        }
        Insert: {
          admin_note?: string | null
          candidate_email?: string | null
          candidate_name?: string | null
          candidate_timezone?: string | null
          config_id: string
          created_at?: string
          decided_at?: string | null
          id?: string
          response_id?: string | null
          slot_end: string
          slot_start: string
          status?: string
        }
        Update: {
          admin_note?: string | null
          candidate_email?: string | null
          candidate_name?: string | null
          candidate_timezone?: string | null
          config_id?: string
          created_at?: string
          decided_at?: string | null
          id?: string
          response_id?: string | null
          slot_end?: string
          slot_start?: string
          status?: string
        }
        Relationships: [
          {
            foreignKeyName: "scheduling_bookings_config_id_fkey"
            columns: ["config_id"]
            isOneToOne: false
            referencedRelation: "scheduling_configs"
            referencedColumns: ["id"]
          },
        ]
      }
      scheduling_config: {
        Row: {
          id: number
          interview_mode: string | null
          is_out_of_office: boolean
          lock_days_ahead: number
          min_advance_hours: number
          ooo_active_period_id: string | null
          out_of_office_end: string | null
          out_of_office_start: string | null
          reservation_timer_minutes: number
          saturday_hours_end: string
          saturday_hours_start: string
          slot_duration_minutes: number
          sylvia_daily_brief: string | null
          timezone: string
          updated_at: string
          working_days: number[]
          working_hours_end: string
          working_hours_start: string
        }
        Insert: {
          id?: number
          interview_mode?: string | null
          is_out_of_office?: boolean
          lock_days_ahead?: number
          min_advance_hours?: number
          ooo_active_period_id?: string | null
          out_of_office_end?: string | null
          out_of_office_start?: string | null
          reservation_timer_minutes?: number
          saturday_hours_end?: string
          saturday_hours_start?: string
          slot_duration_minutes?: number
          sylvia_daily_brief?: string | null
          timezone?: string
          updated_at?: string
          working_days?: number[]
          working_hours_end?: string
          working_hours_start?: string
        }
        Update: {
          id?: number
          interview_mode?: string | null
          is_out_of_office?: boolean
          lock_days_ahead?: number
          min_advance_hours?: number
          ooo_active_period_id?: string | null
          out_of_office_end?: string | null
          out_of_office_start?: string | null
          reservation_timer_minutes?: number
          saturday_hours_end?: string
          saturday_hours_start?: string
          slot_duration_minutes?: number
          sylvia_daily_brief?: string | null
          timezone?: string
          updated_at?: string
          working_days?: number[]
          working_hours_end?: string
          working_hours_start?: string
        }
        Relationships: [
          {
            foreignKeyName: "scheduling_config_ooo_active_period_id_fkey"
            columns: ["ooo_active_period_id"]
            isOneToOne: false
            referencedRelation: "out_of_office_periods"
            referencedColumns: ["id"]
          },
        ]
      }
      scheduling_configs: {
        Row: {
          advance_notice_hours: number
          booking_window_days: number
          buffer_minutes: number
          calendar_source: string
          created_at: string
          disclaimer_text: string
          form_id: string
          id: string
          question_id: string
          slot_duration_minutes: number
          timezone: string
          updated_at: string
          working_hours: Json
        }
        Insert: {
          advance_notice_hours?: number
          booking_window_days?: number
          buffer_minutes?: number
          calendar_source?: string
          created_at?: string
          disclaimer_text?: string
          form_id: string
          id?: string
          question_id: string
          slot_duration_minutes?: number
          timezone?: string
          updated_at?: string
          working_hours?: Json
        }
        Update: {
          advance_notice_hours?: number
          booking_window_days?: number
          buffer_minutes?: number
          calendar_source?: string
          created_at?: string
          disclaimer_text?: string
          form_id?: string
          id?: string
          question_id?: string
          slot_duration_minutes?: number
          timezone?: string
          updated_at?: string
          working_hours?: Json
        }
        Relationships: []
      }
      sylvia_blocklist: {
        Row: {
          created_at: string
          created_by_hr_id: string | null
          email: string | null
          full_name: string | null
          id: string
          reason: string | null
          removed_at: string | null
        }
        Insert: {
          created_at?: string
          created_by_hr_id?: string | null
          email?: string | null
          full_name?: string | null
          id?: string
          reason?: string | null
          removed_at?: string | null
        }
        Update: {
          created_at?: string
          created_by_hr_id?: string | null
          email?: string | null
          full_name?: string | null
          id?: string
          reason?: string | null
          removed_at?: string | null
        }
        Relationships: []
      }
      termination_log: {
        Row: {
          archived_pdf_url: string | null
          created_at: string
          email_log_id: string | null
          email_sent_at: string | null
          hr_copy_email_override: string | null
          hr_copy_requested: boolean
          hr_copy_sent_at: string | null
          id: string
          job_offer_id: string | null
          notes: string | null
          terminated_by_hr_id: string | null
          termination_type: string
        }
        Insert: {
          archived_pdf_url?: string | null
          created_at?: string
          email_log_id?: string | null
          email_sent_at?: string | null
          hr_copy_email_override?: string | null
          hr_copy_requested?: boolean
          hr_copy_sent_at?: string | null
          id?: string
          job_offer_id?: string | null
          notes?: string | null
          terminated_by_hr_id?: string | null
          termination_type: string
        }
        Update: {
          archived_pdf_url?: string | null
          created_at?: string
          email_log_id?: string | null
          email_sent_at?: string | null
          hr_copy_email_override?: string | null
          hr_copy_requested?: boolean
          hr_copy_sent_at?: string | null
          id?: string
          job_offer_id?: string | null
          notes?: string | null
          terminated_by_hr_id?: string | null
          termination_type?: string
        }
        Relationships: [
          {
            foreignKeyName: "termination_log_email_log_id_fkey"
            columns: ["email_log_id"]
            isOneToOne: false
            referencedRelation: "email_log"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "termination_log_job_offer_id_fkey"
            columns: ["job_offer_id"]
            isOneToOne: false
            referencedRelation: "job_offers"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "termination_log_terminated_by_hr_id_fkey"
            columns: ["terminated_by_hr_id"]
            isOneToOne: false
            referencedRelation: "hr_users"
            referencedColumns: ["id"]
          },
        ]
      }
      tracking_tokens: {
        Row: {
          created_at: string
          expires_at: string | null
          id: string
          response_id: string
          revoked_at: string | null
          token: string
        }
        Insert: {
          created_at?: string
          expires_at?: string | null
          id?: string
          response_id: string
          revoked_at?: string | null
          token: string
        }
        Update: {
          created_at?: string
          expires_at?: string | null
          id?: string
          response_id?: string
          revoked_at?: string | null
          token?: string
        }
        Relationships: []
      }
      users: {
        Row: {
          created_at: string
          email: string
          id: string
          role: string
        }
        Insert: {
          created_at?: string
          email: string
          id: string
          role?: string
        }
        Update: {
          created_at?: string
          email?: string
          id?: string
          role?: string
        }
        Relationships: []
      }
      whatsapp_messages: {
        Row: {
          body: string | null
          contact_name: string | null
          created_at: string
          direction: string
          id: string
          media_mime: string | null
          media_url: string | null
          phone: string
          raw: Json | null
          response_id: string | null
          status: string | null
          type: string
          wa_message_id: string | null
        }
        Insert: {
          body?: string | null
          contact_name?: string | null
          created_at?: string
          direction: string
          id?: string
          media_mime?: string | null
          media_url?: string | null
          phone: string
          raw?: Json | null
          response_id?: string | null
          status?: string | null
          type?: string
          wa_message_id?: string | null
        }
        Update: {
          body?: string | null
          contact_name?: string | null
          created_at?: string
          direction?: string
          id?: string
          media_mime?: string | null
          media_url?: string | null
          phone?: string
          raw?: Json | null
          response_id?: string | null
          status?: string | null
          type?: string
          wa_message_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "whatsapp_messages_response_id_fkey"
            columns: ["response_id"]
            isOneToOne: false
            referencedRelation: "responses"
            referencedColumns: ["id"]
          },
        ]
      }
      zoom_meetings: {
        Row: {
          candidate_actions_id: string | null
          candidate_id: string | null
          created_at: string
          duration_minutes: number
          id: string
          join_url: string
          last_synced_at: string | null
          password: string | null
          round: number | null
          start_time: string
          start_url: string | null
          status: string
          timezone: string | null
          topic: string
          zoom_meeting_id: string
          zoom_meeting_uuid: string | null
        }
        Insert: {
          candidate_actions_id?: string | null
          candidate_id?: string | null
          created_at?: string
          duration_minutes?: number
          id?: string
          join_url: string
          last_synced_at?: string | null
          password?: string | null
          round?: number | null
          start_time: string
          start_url?: string | null
          status?: string
          timezone?: string | null
          topic: string
          zoom_meeting_id: string
          zoom_meeting_uuid?: string | null
        }
        Update: {
          candidate_actions_id?: string | null
          candidate_id?: string | null
          created_at?: string
          duration_minutes?: number
          id?: string
          join_url?: string
          last_synced_at?: string | null
          password?: string | null
          round?: number | null
          start_time?: string
          start_url?: string | null
          status?: string
          timezone?: string | null
          topic?: string
          zoom_meeting_id?: string
          zoom_meeting_uuid?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "zoom_meetings_candidate_actions_id_fkey"
            columns: ["candidate_actions_id"]
            isOneToOne: false
            referencedRelation: "candidate_actions"
            referencedColumns: ["id"]
          },
        ]
      }
      zoom_token_cache: {
        Row: {
          access_token: string
          expires_at: string
          id: number
          updated_at: string
        }
        Insert: {
          access_token: string
          expires_at: string
          id?: number
          updated_at?: string
        }
        Update: {
          access_token?: string
          expires_at?: string
          id?: number
          updated_at?: string
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      generate_offer_reference_id: { Args: never; Returns: string }
      is_admin: { Args: { _uid: string }; Returns: boolean }
    }
    Enums: {
      [_ in never]: never
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {},
  },
} as const
