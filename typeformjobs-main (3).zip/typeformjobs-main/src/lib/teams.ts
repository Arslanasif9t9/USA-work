// Shared team list used by BOTH the inline EmployeesDashboard dropdown and the
// AssignToSylviaDialog so the two never drift. Sylvia's edge functions keep a
// mirror of this in supabase/functions/_shared/teams.ts.
export const TEAM_OPTIONS: { id: string; name: string }[] = [
  { id: "2d3a5b87-40de-4433-83aa-a59732b5c8f7", name: "Marketing & Planning Intelligence" },
  { id: "25e424e3-d44d-4c91-97a2-b30f3ed2a5f3", name: "Stock Market Team" },
  { id: "19d3f678-d412-44b3-b46b-216fa0209252", name: "E-Com & Marketing Force" },
  { id: "5fd5ca28-6854-47b8-ac96-c61bb994aad0", name: "Real Estate Team" },
  { id: "914de165-232c-4357-9756-48f6be2d15be", name: "Team Expert Advisor" },
];

// UUID → team name, with PASSTHROUGH: if the value is not one of the 5 known
// UUIDs, treat the raw value as the literal team name (covers manual free-text
// like "personal assistant").
export const teamNameById = (id: string | null | undefined): string | null => {
  const v = (id ?? "").trim();
  if (!v) return null;
  return TEAM_OPTIONS.find((t) => t.id === v)?.name ?? v;
};
