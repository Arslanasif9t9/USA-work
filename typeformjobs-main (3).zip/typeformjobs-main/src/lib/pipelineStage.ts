// Shared pipeline-stage computation for the Results page status pill and the
// ActionsCell "in pipeline" lock. Built ONLY against data we actually have:
// responses.round_stage / disqualified_at_stage and
// candidate_actions.round1_status / round2_status / offer_status.
// No viewed/opened/attended/termination-split logic — that data does not exist.

export type PipelineStageKey =
  | "disqualified"
  | "terminated"
  | "offer_signed"
  | "offer_sent"
  | "round2_sent"
  | "round1_sent";

export type PipelineStage = {
  key: PipelineStageKey;
  /** Pill label (Disqualified may include the "· {stage}" suffix). */
  label: string;
  /** Short label used for the greyed lock button. */
  lockLabel: string;
  /** Exact pill color (hex). White text sits on top. */
  color: string;
} | null;

const COLORS: Record<PipelineStageKey, string> = {
  disqualified: "#c0392b", // red
  terminated: "#7a1f1f", // dark red
  offer_signed: "#7DB8E8", // baby-blue
  offer_sent: "#b08d57", // gold
  round2_sent: "#4f46e5", // indigo
  round1_sent: "#1a2547", // navy blue
};

export function computePipelineStage(opts: {
  roundStage?: string | null;
  disqualifiedAtStage?: string | null;
  round1Status?: string | null;
  round2Status?: string | null;
  offerStatus?: string | null;
}): PipelineStage {
  const {
    roundStage,
    disqualifiedAtStage,
    round1Status,
    round2Status,
    offerStatus,
  } = opts;

  // Priority order — first match wins.
  if (roundStage === "disqualified") {
    return {
      key: "disqualified",
      label: disqualifiedAtStage
        ? `Disqualified · ${disqualifiedAtStage}`
        : "Disqualified",
      lockLabel: "Disqualified",
      color: COLORS.disqualified,
    };
  }
  if (roundStage === "terminated") {
    return { key: "terminated", label: "Terminated", lockLabel: "Terminated", color: COLORS.terminated };
  }
  if (offerStatus === "signed" || roundStage === "offer_signed") {
    return { key: "offer_signed", label: "Offer Signed", lockLabel: "Offer Signed", color: COLORS.offer_signed };
  }
  if (offerStatus === "sent" || roundStage === "offer_sent") {
    return { key: "offer_sent", label: "Offer Sent", lockLabel: "Offer Sent", color: COLORS.offer_sent };
  }
  if (round2Status === "sent" || roundStage === "round_2_sent") {
    return { key: "round2_sent", label: "Round 2 Sent", lockLabel: "Round 2 Sent", color: COLORS.round2_sent };
  }
  if (round1Status === "sent" || roundStage === "round_1_sent") {
    return { key: "round1_sent", label: "Round 1 Sent", lockLabel: "Round 1 Sent", color: COLORS.round1_sent };
  }
  // Fresh candidate — no pill, no lock.
  return null;
}
