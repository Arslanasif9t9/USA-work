export function cleanPositionTitle(raw: string): string {
  if (!raw) return "";
  let s = raw.trim();
  // Strip common prefixes (case-insensitive, repeatable)
  s = s.replace(/^\s*(va\s*-\s*|job\s*-\s*)/i, "").trim();
  // Strip common suffixes
  s = s.replace(/\s*(application|form)\s*$/i, "").trim();
  // Title-case
  s = s
    .split(/\s+/)
    .map((w) =>
      w.length ? w[0].toUpperCase() + w.slice(1).toLowerCase() : w,
    )
    .join(" ");
  return s.slice(0, 80);
}

export const POSITION_TITLE_UPDATED_EVENT = "position-title-updated";

export function emitPositionTitleUpdated(formId: string) {
  window.dispatchEvent(
    new CustomEvent(POSITION_TITLE_UPDATED_EVENT, { detail: { formId } }),
  );
}
