export type ScopeCategory =
  | "Real Estate"
  | "E-commerce"
  | "Marketing"
  | "Research"
  | "Admin Support"
  | "AI & Tools"
  | "General";

export const SCOPE_CATEGORIES: ScopeCategory[] = [
  "Real Estate",
  "E-commerce",
  "Marketing",
  "Research",
  "Admin Support",
  "AI & Tools",
  "General",
];

export const CATEGORY_COLORS: Record<string, string> = {
  "Real Estate": "#1a2547",
  "E-commerce": "#059669",
  Marketing: "#dc2626",
  Research: "#7c3aed",
  "Admin Support": "#d97706",
  "AI & Tools": "#0891b2",
  General: "#64748b",
};

/** Returns the color for a category. Unknown/legacy categories fall back to General slate. */
export function categoryColor(category?: string | null): string {
  if (!category) return CATEGORY_COLORS.General;
  return CATEGORY_COLORS[category] ?? CATEGORY_COLORS.General;
}

/** Normalize an arbitrary category string to a known ScopeCategory (fallback: General). */
export function normalizeCategory(category?: string | null): ScopeCategory {
  if (!category) return "General";
  return (SCOPE_CATEGORIES as string[]).includes(category)
    ? (category as ScopeCategory)
    : "General";
}
