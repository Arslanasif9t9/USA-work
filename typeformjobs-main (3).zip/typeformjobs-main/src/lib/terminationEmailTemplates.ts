// Termination email templates — neutral language about compensation.
// Used by the terminate-employee edge function.

export type TerminationVars = {
  employee_name: string;
  position_title: string;
  today: string; // e.g., "Monday, May 19, 2026"
};

export const formatTodayLong = (d: Date = new Date()): string =>
  d.toLocaleDateString("en-US", {
    weekday: "long",
    year: "numeric",
    month: "long",
    day: "numeric",
  });

const SIGNATURE_HTML = `
  <p style="margin:16px 0 4px 0;">With respect,</p>
  <p style="margin:0;"><strong>Cathy Anderson</strong><br/>Hiring Director<br/>Expert Intuitive Advisor Inc.</p>
`;

const wrapHtml = (inner: string) => `<!DOCTYPE html>
<html><body style="font-family: -apple-system, Segoe UI, Roboto, Helvetica, Arial, sans-serif; color:#1a2547; line-height:1.6; font-size:15px;">
<div style="max-width:600px; margin:0 auto; padding:24px;">${inner}${SIGNATURE_HTML}</div>
</body></html>`;

export function evaluationTerminationEmail(v: TerminationVars) {
  const subject = "Update on your position with Expert Intuitive Advisor Inc.";
  const text = `Dear ${v.employee_name},

Thank you for the time and effort you've invested with Expert Intuitive Advisor Inc. as a ${v.position_title}.

After careful review of your performance during the trial period, we've decided not to continue your engagement beyond this point. The trial period exists to assess fit on both sides, and at this time we don't feel the role aligns with the direction we're going or the standards we need to maintain.

This decision is not a reflection of your character or potential. Many talented individuals find that a particular role isn't quite the right match — that's exactly why the trial period exists.

Effective ${v.today}, your engagement with EIA is concluded. Any compensation owed for verified work completed will be processed accordingly. If no work was completed, there is no balance owed.

We wish you the very best in your future endeavors.

With respect,

Cathy Anderson
Hiring Director
Expert Intuitive Advisor Inc.`;

  const html = wrapHtml(`
    <p>Dear ${v.employee_name},</p>
    <p>Thank you for the time and effort you've invested with Expert Intuitive Advisor Inc. as a ${v.position_title}.</p>
    <p>After careful review of your performance during the trial period, we've decided not to continue your engagement beyond this point. The trial period exists to assess fit on both sides, and at this time we don't feel the role aligns with the direction we're going or the standards we need to maintain.</p>
    <p>This decision is not a reflection of your character or potential. Many talented individuals find that a particular role isn't quite the right match — that's exactly why the trial period exists.</p>
    <p>Effective ${v.today}, your engagement with EIA is concluded. Any compensation owed for verified work completed will be processed accordingly. If no work was completed, there is no balance owed.</p>
    <p>We wish you the very best in your future endeavors.</p>
  `);

  return { subject, text, html };
}

export function regularTerminationEmail(v: TerminationVars) {
  const subject = "Conclusion of your engagement with Expert Intuitive Advisor Inc.";
  const text = `Dear ${v.employee_name},

I'm writing to inform you that, effective ${v.today}, your engagement with Expert Intuitive Advisor Inc. as a ${v.position_title} will be concluded.

We appreciate the contributions you've made during your time with us. The decision to part ways was made after careful consideration of our current business needs and the direction of the team.

Any compensation owed for verified work completed will be processed accordingly. If no balance is owed, no further action is required.

We wish you continued success in your career.

With respect,

Cathy Anderson
Hiring Director
Expert Intuitive Advisor Inc.`;

  const html = wrapHtml(`
    <p>Dear ${v.employee_name},</p>
    <p>I'm writing to inform you that, effective ${v.today}, your engagement with Expert Intuitive Advisor Inc. as a ${v.position_title} will be concluded.</p>
    <p>We appreciate the contributions you've made during your time with us. The decision to part ways was made after careful consideration of our current business needs and the direction of the team.</p>
    <p>Any compensation owed for verified work completed will be processed accordingly. If no balance is owed, no further action is required.</p>
    <p>We wish you continued success in your career.</p>
  `);

  return { subject, text, html };
}
