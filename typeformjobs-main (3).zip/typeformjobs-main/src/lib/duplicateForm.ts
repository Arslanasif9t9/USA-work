import { supabase } from "@/integrations/supabase/client";
import { generateUniqueSlug } from "@/lib/slug";

export type DuplicatedForm = {
  id: string;
  title: string;
  slug: string;
  status: string;
};

export async function duplicateForm(originalFormId: string, userId: string): Promise<DuplicatedForm> {
  const { data: original, error: oErr } = await supabase
    .from("forms")
    .select("*")
    .eq("id", originalFormId)
    .single();
  if (oErr || !original) throw oErr || new Error("Form not found");

  const newTitle = `${original.title} (Copy)`;
  const newSlug = await generateUniqueSlug(newTitle);

  const { data: newForm, error: fErr } = await supabase
    .from("forms")
    .insert({
      title: newTitle,
      slug: newSlug,
      description: original.description,
      status: "draft",
      created_by: userId,
    })
    .select()
    .single();
  if (fErr || !newForm) throw fErr || new Error("Insert failed");

  try {
    const { data: qs, error: qErr } = await supabase
      .from("questions")
      .select("*")
      .eq("form_id", originalFormId)
      .order("order_index", { ascending: true });
    if (qErr) throw qErr;

    if (qs && qs.length) {
      // Normalize order_index: welcome=0, real questions=1..N, thank_you=9999
      let next = 1;
      const newQs = qs.map((q: any) => {
        let order_index: number;
        if (q.type === "welcome") order_index = 0;
        else if (q.type === "thank_you") order_index = 9999;
        else order_index = next++;
        return {
          form_id: newForm.id,
          type: q.type,
          label: q.label,
          placeholder: q.placeholder,
          description: q.description,
          required: q.required,
          options: q.options,
          order_index,
        };
      });
      const { error: insErr } = await supabase.from("questions").insert(newQs);
      if (insErr) throw insErr;
    }

    return newForm as DuplicatedForm;
  } catch (e) {
    // Cleanup partial
    await supabase.from("questions").delete().eq("form_id", newForm.id);
    await supabase.from("forms").delete().eq("id", newForm.id);
    throw e;
  }
}
