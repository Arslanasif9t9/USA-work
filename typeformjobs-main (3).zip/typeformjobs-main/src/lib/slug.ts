import { supabase } from "@/integrations/supabase/client";

export const generateSlug = (title: string): string => {
  const base = title
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9\s-]/g, "")
    .replace(/\s+/g, "-")
    .replace(/-+/g, "-")
    .replace(/^-+|-+$/g, "");
  return base || "untitled-form";
};

export const generateUniqueSlug = async (title: string, excludeId?: string): Promise<string> => {
  const base = generateSlug(title);
  let candidate = base;
  let n = 2;
  // Loop until we find a slug not used by another form
  // Limit attempts to avoid infinite loop
  for (let i = 0; i < 200; i++) {
    let q = supabase.from("forms").select("id").eq("slug", candidate).maybeSingle();
    const { data } = await q;
    if (!data || (excludeId && data.id === excludeId)) return candidate;
    candidate = `${base}-${n++}`;
  }
  return `${base}-${Date.now()}`;
};
