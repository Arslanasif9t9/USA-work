import NProgress from "nprogress";

NProgress.configure({ showSpinner: false, minimum: 0.1, trickleSpeed: 200 });

let activeCount = 0;

export const startProgress = () => {
  activeCount++;
  NProgress.start();
};

export const doneProgress = () => {
  activeCount = Math.max(0, activeCount - 1);
  if (activeCount === 0) NProgress.done();
};

/** Wrap an async action so the route progress bar runs during it. */
export const withProgress = async <T,>(fn: () => Promise<T>): Promise<T> => {
  startProgress();
  try {
    return await fn();
  } finally {
    doneProgress();
  }
};

export default NProgress;
