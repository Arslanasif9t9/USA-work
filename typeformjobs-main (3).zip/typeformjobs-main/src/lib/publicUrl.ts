// Public-facing base URL where candidates open shared forms.
// Editor preview origins require authentication,
// so share links must always use the published site instead.
const PUBLIC_DOMAINS = [
  "jobs.expertintuitiveadvisor.com",
  "typeformjobs.lovable.app",
];

export const getPublicBaseUrl = (): string => {
  if (typeof window === "undefined") return `https://${PUBLIC_DOMAINS[0]}`;
  const host = window.location.hostname;
  // If we're already on a public domain, use it as-is.
  if (PUBLIC_DOMAINS.includes(host)) return window.location.origin;
  // Otherwise (editor preview, localhost, etc.) use the primary public domain.
  return `https://${PUBLIC_DOMAINS[0]}`;
};

export const getPublicFormUrl = (slug: string): string =>
  `${getPublicBaseUrl()}/form/${slug}`;
