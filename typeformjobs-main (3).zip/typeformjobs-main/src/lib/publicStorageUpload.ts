const SUPABASE_URL = import.meta.env.VITE_SUPABASE_URL;
const SUPABASE_PUBLISHABLE_KEY = import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY;

type UploadArgs = {
  bucket: string;
  path: string;
  file: Blob;
  contentType: string;
};

export type PublicStorageUploadResult = {
  id?: string;
  path: string;
  fullPath: string;
  raw: unknown;
};

const encodeStoragePath = (path: string) =>
  path
    .split("/")
    .map((part) => encodeURIComponent(part))
    .join("/");

export const uploadPublicStorageObject = async ({
  bucket,
  path,
  file,
  contentType,
}: UploadArgs): Promise<PublicStorageUploadResult> => {
  const objectPath = `${encodeURIComponent(bucket)}/${encodeStoragePath(path)}`;
  const endpoint = `${SUPABASE_URL}/storage/v1/object/${objectPath}`;
  const response = await fetch(endpoint, {
    method: "POST",
    headers: {
      apikey: SUPABASE_PUBLISHABLE_KEY,
      authorization: `Bearer ${SUPABASE_PUBLISHABLE_KEY}`,
      "content-type": contentType,
      "x-upsert": "false",
    },
    body: file,
  });

  const responseText = await response.text();
  let body: any = responseText;
  try {
    body = responseText ? JSON.parse(responseText) : null;
  } catch {
    // Keep the raw text body for diagnostics.
  }

  if (!response.ok) {
    const message =
      body?.message ||
      body?.error ||
      response.statusText ||
      "Storage upload failed";
    const error = new Error(message) as Error & {
      status: number;
      statusCode: string;
      body: unknown;
      endpoint: string;
    };
    error.status = response.status;
    error.statusCode = String(response.status);
    error.body = body;
    error.endpoint = endpoint;
    throw error;
  }

  return {
    id: body?.Id || body?.id,
    path,
    fullPath: body?.Key || body?.fullPath || `${bucket}/${path}`,
    raw: body,
  };
};