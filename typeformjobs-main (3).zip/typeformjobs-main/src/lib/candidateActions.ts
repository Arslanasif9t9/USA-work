import { supabase } from "@/integrations/supabase/client";

export type Stage = "round1" | "round2" | "offer";

export type CandidateAction = {
  id: string;
  candidate_id: string;
  form_id: string;
  response_id: string | null;
  zoom_send_count?: number;
  round1_status: "not_sent" | "sent";
  round1_sent_at: string | null;
  round1_last_sent_at: string | null;
  round1_resend_count: number;
  round1_appointment_date: string | null;
  round1_zoom_meeting_id: string | null;
  round1_zoom_join_url: string | null;
  round2_status: "not_sent" | "sent";
  round2_sent_at: string | null;
  round2_last_sent_at: string | null;
  round2_resend_count: number;
  /** How many times "Send Round 2" has been sent (additive counter, mirrors R1 nudge). */
  round2_send_count?: number | null;
  round2_appointment_date: string | null;
  round2_zoom_meeting_id: string | null;
  round2_zoom_join_url: string | null;
  offer_status: "not_sent" | "sent" | "signed";
  offer_sent_at: string | null;
  offer_last_sent_at: string | null;
  offer_resend_count: number;
  offer_signed_at: string | null;
  job_offer_id: string | null;
  round1_attendance_status?: "attended" | "no_show" | null;
  round1_attendance_marked_at?: string | null;
  round1_attendance_marked_by_hr_id?: string | null;
  round2_attendance_status?: "attended" | "no_show" | null;
  round2_attendance_marked_at?: string | null;
  round2_attendance_marked_by_hr_id?: string | null;
};

export type CandidateInfo = { name: string; email: string };

/** Find name/email question ids in a form's question list. */
export const detectContactQuestionIds = (
  questions: { id: string; type: string; label: string }[],
): { nameQid?: string; emailQid?: string } => {
  // Email: prefer a question whose label clearly says "email" and is not the
  // Onlinejobs / profile / URL link field. Fall back to first type='email'.
  const EMAIL_LABEL_RE = /e[\s-]?mail/i;
  const EMAIL_EXCLUDE_RE = /(onlinejob|online\s*jobs?|profile|link|url)/i;
  const emailByLabel = questions.find(
    (q) => EMAIL_LABEL_RE.test(q.label || "") && !EMAIL_EXCLUDE_RE.test(q.label || ""),
  );
  const emailByType = questions.find(
    (q) => q.type === "email" && !EMAIL_EXCLUDE_RE.test(q.label || ""),
  );
  const emailQ = emailByLabel || emailByType;
  const nameQ =
    questions.find(
      (q) => q.type === "short_text" && /name/i.test(q.label),
    ) || questions.find((q) => q.type === "short_text");
  return { nameQid: nameQ?.id, emailQid: emailQ?.id };
};

export const extractCandidateInfo = (
  questions: { id: string; type: string; label: string }[],
  answers: { response_id: string; question_id: string; answer_text: string | null }[],
  responseId: string,
  overrideEmail?: string | null,
): CandidateInfo => {
  const { nameQid, emailQid } = detectContactQuestionIds(questions);
  const find = (qid?: string) =>
    qid ? answers.find((a) => a.response_id === responseId && a.question_id === qid)?.answer_text || "" : "";
  const answerEmail = (find(emailQid) || "").trim();
  const email = (overrideEmail || "").trim() || answerEmail;
  return { name: (find(nameQid) || "").trim(), email };
};

/** Ensure a candidate_actions row exists for this response. Returns the row. */
export const ensureCandidateAction = async (
  responseId: string,
  formId: string,
  applicantId: string,
): Promise<CandidateAction> => {
  const { data: existing } = await supabase
    .from("candidate_actions")
    .select("*")
    .eq("response_id", responseId)
    .maybeSingle();
  if (existing) return existing as CandidateAction;
  const { data, error } = await supabase
    .from("candidate_actions")
    .insert({ response_id: responseId, form_id: formId, candidate_id: applicantId })
    .select("*")
    .single();
  if (error) throw error;
  return data as CandidateAction;
};

export const fetchCandidateActionsForForm = async (
  formId: string,
): Promise<Record<string, CandidateAction>> => {
  const { data, error } = await supabase
    .from("candidate_actions")
    .select("*")
    .eq("form_id", formId);
  if (error) throw error;
  const map: Record<string, CandidateAction> = {};
  for (const row of (data || []) as CandidateAction[]) {
    if (row.response_id) map[row.response_id] = row;
  }
  return map;
};

export const verifyOverridePassword = async (password: string): Promise<boolean> => {
  try {
    const { data, error } = await supabase.functions.invoke("verify-currency-override", {
      body: { password },
    });
    if (error) return false;
    return !!(data as any)?.valid;
  } catch {
    return false;
  }
};

export const markStageSent = async (
  actionId: string,
  stage: Stage,
  extra: { appointmentDate?: string | null; jobOfferId?: string } = {},
): Promise<void> => {
  const now = new Date().toISOString();
  const patch: Record<string, any> = {
    [`${stage}_status`]: "sent",
    [`${stage}_sent_at`]: now,
    [`${stage}_last_sent_at`]: now,
  };
  if (stage !== "offer" && extra.appointmentDate !== undefined) {
    patch[`${stage}_appointment_date`] = extra.appointmentDate;
  }
  if (stage === "offer" && extra.jobOfferId) {
    patch.job_offer_id = extra.jobOfferId;
  }
  const { error } = await supabase.from("candidate_actions").update(patch as any).eq("id", actionId);
  if (error) throw error;
};

export const markStageResent = async (
  actionId: string,
  stage: Stage,
  currentCount: number,
  extra: { appointmentDate?: string | null } = {},
): Promise<void> => {
  const now = new Date().toISOString();
  const patch: Record<string, any> = {
    [`${stage}_last_sent_at`]: now,
    [`${stage}_resend_count`]: currentCount + 1,
  };
  if (stage !== "offer" && extra.appointmentDate !== undefined) {
    patch[`${stage}_appointment_date`] = extra.appointmentDate;
  }
  const { error } = await supabase.from("candidate_actions").update(patch as any).eq("id", actionId);
  if (error) throw error;
};

export const updateResponseAnswer = async (
  responseId: string,
  questionId: string,
  text: string,
): Promise<void> => {
  const { data: existing } = await supabase
    .from("answers")
    .select("id")
    .eq("response_id", responseId)
    .eq("question_id", questionId)
    .maybeSingle();
  if (existing) {
    await supabase.from("answers").update({ answer_text: text }).eq("id", (existing as any).id);
  } else {
    await supabase.from("answers").insert({ response_id: responseId, question_id: questionId, answer_text: text });
  }
};
