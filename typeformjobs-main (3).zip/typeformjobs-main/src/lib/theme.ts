// Form theme palettes — each form has its own theme, stored in the database.
// Admin can preview a theme locally; changes go live only after Save.

export type ThemeId = "default" | "darkblue" | "forest" | "charcoal" | "plum";

export type ThemeDef = {
  id: ThemeId;
  name: string;
  className: string;
  bg: string;
  fg: string;
};

export const THEMES: ThemeDef[] = [
  { id: "default",  name: "Default",   className: "",               bg: "#ffffff", fg: "#0a0a0a" },
  { id: "darkblue", name: "Dark Blue", className: "theme-darkblue", bg: "#f5f1ea", fg: "#1e3a8a" },
  { id: "forest",   name: "Forest",    className: "theme-forest",   bg: "#f3efe6", fg: "#1f3d2b" },
  { id: "charcoal", name: "Charcoal",  className: "theme-charcoal", bg: "#eeece8", fg: "#1f2937" },
  { id: "plum",     name: "Plum",      className: "theme-plum",     bg: "#f4ecef", fg: "#4a1d3f" },
];

export const getThemeClass = (id: ThemeId | string | null | undefined): string => {
  const t = THEMES.find((x) => x.id === id);
  return t?.className ?? "";
};

export const isValidTheme = (id: string | null | undefined): id is ThemeId =>
  !!id && THEMES.some((t) => t.id === id);
