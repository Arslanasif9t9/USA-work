// Email templates for Round 1 / Round 2 interview invites.
// Returns plaintext + simple HTML for sender_a (Resend) and sender_b (Gmail).

export type RoundEmailVars = {
  round: 1 | 2;
  candidate_name: string;
  position_title: string;
  formatted_date: string;
  formatted_time: string;
  duration_minutes: number;
  zoom_join_url: string;
  zoom_password: string | null;
};

const htmlEscape = (s: string) =>
  s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");

const toHtml = (text: string, joinUrl: string) => {
  const escaped = htmlEscape(text)
    .replace(
      new RegExp(htmlEscape(joinUrl).replace(/[.*+?^${}()|[\]\\]/g, "\\$&"), "g"),
      `<a href="${joinUrl}">${joinUrl}</a>`,
    )
    .replace(/\n/g, "<br/>");
  return `<div style="font-family:Arial,sans-serif;font-size:14px;line-height:1.55;color:#1a2236">${escaped}</div>`;
};

export function buildRoundEmails(v: RoundEmailVars) {
  // Password intentionally omitted — meetings rely on waiting-room admission.
  void v.zoom_password;

  if (v.round === 1) {
    const aText = `Hi ${v.candidate_name},

For the better experience, we recommend joining on a desktop or laptop computer with camera and mic.

Congratulations — you've been shortlisted for our Round 1 Interview for the ${v.position_title} position at Expert Intuitive Advisor Inc.

INTERVIEW DETAILS:
Date: ${v.formatted_date}
Time: ${v.formatted_time} (Asia/Manila time)
Duration: ${v.duration_minutes} minutes
Format: Zoom video call

JOIN MEETING:
${v.zoom_join_url}

The calendar invite is attached — please add it to your calendar so you don't miss it.

Please make sure:
- You have a stable internet connection
- You're in a quiet, well-lit space
- Your camera and microphone are working
- You're available 5 minutes before the scheduled time

This is a brief evaluation interview. We'll discuss your background and assess fit for the role.

If you need to reschedule, reply to this email and we'll work with you.

Looking forward to speaking with you.

Angela Stein
HR – Talent Manager
Expert Intuitive Advisor Inc.`;

    const bText = `Hi ${v.candidate_name},

For the better experience, we recommend joining on a desktop or laptop computer with camera and mic.

Just sending a personal reminder about your Round 1 interview.

When: ${v.formatted_date} at ${v.formatted_time} (Manila time)
Where: Zoom — ${v.zoom_join_url}

The calendar invite should be attached. If you can't open it, just save the date and time above.

A few quick tips:
- Test your Zoom audio/video beforehand
- Have your resume nearby in case we want to discuss it
- Be ready a couple minutes early

If anything changes on your end, just reply and we'll figure it out.

— Angela Stein`;

    return {
      sender_a: {
        from_name: "Angela Stein / HR – Talent Manager",
        from_address: "talent@expertintuitiveadvisor.com",
        subject: `Round 1 Interview Scheduled — ${v.position_title}`,
        text_body: aText,
        html_body: toHtml(aText, v.zoom_join_url),
      },
      sender_b: {
        from_name: "Angela Stein",
        from_address: "expertintuitiveadvisor@gmail.com",
        subject: "Quick reminder — your Round 1 interview is set",
        text_body: bText,
        html_body: toHtml(bText, v.zoom_join_url),
      },
    };
  }

  // Round 2
  const aText = `Hi ${v.candidate_name},

For the better experience, we recommend joining on a desktop or laptop computer with camera and mic.

Thank you for completing Round 1. We're moving forward with you to Round 2 of our interview process for the ${v.position_title} position.

INTERVIEW DETAILS:
Date: ${v.formatted_date}
Time: ${v.formatted_time} (Asia/Manila time)
Duration: ${v.duration_minutes} minutes
Format: Zoom video call

JOIN MEETING:
${v.zoom_join_url}

The calendar invite is attached.

In this interview, we'll discuss your application in more detail and go over the role responsibilities, work schedule, compensation, and other important details.

Please be prepared to:
- Discuss your relevant experience and approach
- Ask any questions you have about the role
- Demonstrate basic technical setup (internet speed, audio, video)

Please make sure you have a stable internet connection and a quiet environment.

If you need to reschedule, reply to this email.

Angela Stein
HR – Talent Manager
Expert Intuitive Advisor Inc.`;

  const bText = `Hi ${v.candidate_name},

For the better experience, we recommend joining on a desktop or laptop computer with camera and mic.

Excited to chat again — here are the details for Round 2:

When: ${v.formatted_date} at ${v.formatted_time} (Manila time)
Where: Zoom — ${v.zoom_join_url}

This is the discussion where we go over the role in more depth. Come prepared with questions.

We'll also do a quick technical check (internet, audio, video) during the call, so make sure your setup is ready.

If you need to reschedule, just reply.

— Angela Stein`;

  return {
    sender_a: {
      from_name: "Angela Stein / HR – Talent Manager",
      from_address: "talent@expertintuitiveadvisor.com",
      subject: `Round 2 Interview Scheduled — ${v.position_title}`,
      text_body: aText,
      html_body: toHtml(aText, v.zoom_join_url),
    },
    sender_b: {
      from_name: "Angela Stein",
      from_address: "expertintuitiveadvisor@gmail.com",
      subject: "Quick reminder — Round 2 interview details",
      text_body: bText,
      html_body: toHtml(bText, v.zoom_join_url),
    },
  };
}
