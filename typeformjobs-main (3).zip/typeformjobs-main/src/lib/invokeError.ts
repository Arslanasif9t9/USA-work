// Shared helper for turning a Supabase functions.invoke() failure into a clean,
// user-friendly message — without ever leaking the raw
// "Edge Function returned a non-2xx status code" string.
//
// When an edge function responds with a non-2xx status (e.g. 403 wrong password),
// supabase.functions.invoke throws a FunctionsHttpError whose `.context` is the
// raw Response. We read that body to recover the real { error: "..." } payload.

const WRONG_PASSWORD_MESSAGE = "Access denied — Invalid Password";
const GENERIC_MESSAGE = "Something went wrong — please try again.";

type ParsedInvokeError = {
  wrongPassword: boolean;
  message: string;
};

async function readErrorBody(error: unknown, fallbackData?: unknown): Promise<{ body: any; status?: number }> {
  const ctx = (error as any)?.context;
  let status: number | undefined = typeof ctx?.status === "number" ? ctx.status : undefined;

  // FunctionsHttpError: context is the raw Response object.
  if (ctx && typeof ctx.json === "function") {
    try {
      const body = await ctx.json();
      return { body, status };
    } catch {
      /* fall through */
    }
  }

  // Sometimes the parsed body is already returned as `data`.
  if (fallbackData && typeof fallbackData === "object") {
    return { body: fallbackData, status };
  }

  return { body: null, status };
}

/**
 * Inspect an invoke() error (and optional returned data) and decide what to show.
 * Returns a clean message; never the raw non-2xx string.
 */
export async function parseInvokeError(error: unknown, fallbackData?: unknown): Promise<ParsedInvokeError> {
  const { body, status } = await readErrorBody(error, fallbackData);
  const errStr = String(body?.error || "").toLowerCase();

  if (errStr === "wrong password" || errStr === "wrong_password" || status === 403) {
    return { wrongPassword: true, message: WRONG_PASSWORD_MESSAGE };
  }

  return { wrongPassword: false, message: GENERIC_MESSAGE };
}
