// Helpers for the Schedule Send feature (Piece 1).
// Asia/Manila is first-class. We store scheduled_for as a UTC instant and keep
// the timezone string for display only.
import { supabase } from "@/integrations/supabase/client";

export const MANILA_TZ = "Asia/Manila";

/** Y-M-D as seen in a given IANA timezone. */
export function ymdInTz(date: Date, timeZone: string): { y: number; m: number; d: number } {
  const parts = new Intl.DateTimeFormat("en-US", {
    timeZone, year: "numeric", month: "2-digit", day: "2-digit",
  }).formatToParts(date);
  const get = (t: string) => parseInt(parts.find((p) => p.type === t)?.value || "0", 10);
  return { y: get("year"), m: get("month"), d: get("day") };
}

/** Current hour (0-23) as seen in a timezone. */
export function hourInTz(date: Date, timeZone: string): number {
  const h = new Intl.DateTimeFormat("en-US", { timeZone, hour: "2-digit", hour12: false }).format(date);
  const n = parseInt(h, 10);
  return n === 24 ? 0 : n;
}

const pad = (n: number) => String(n).padStart(2, "0");
const toISODate = (y: number, m: number, d: number) => `${y}-${pad(m)}-${pad(d)}`;

/**
 * Default schedule date: the next 6 AM in Manila.
 * If current Manila time is past 06:00 today -> tomorrow; else today.
 */
export function nextSixAmManilaDate(now: Date = new Date()): string {
  const { y, m, d } = ymdInTz(now, MANILA_TZ);
  const hour = hourInTz(now, MANILA_TZ);
  if (hour >= 6) {
    // tomorrow in Manila
    const base = new Date(`${toISODate(y, m, d)}T12:00:00+08:00`);
    base.setUTCDate(base.getUTCDate() + 1);
    const t = ymdInTz(base, MANILA_TZ);
    return toISODate(t.y, t.m, t.d);
  }
  return toISODate(y, m, d);
}

/** Manila wall-clock (date + HH:MM) -> UTC ISO instant. PHT is UTC+8, no DST. */
export function manilaWallToUtcIso(date: string, time: string): string {
  if (!date || !time) return "";
  const d = new Date(`${date}T${time}:00+08:00`);
  if (Number.isNaN(d.getTime())) return "";
  return d.toISOString();
}

/** Generic: wall-clock in any IANA tz -> UTC ISO. */
export function wallToUtcIso(date: string, time: string, timeZone: string): string {
  if (!date || !time) return "";
  if (timeZone === MANILA_TZ) return manilaWallToUtcIso(date, time);
  // Compute the tz offset for that wall time and back it out.
  const guess = new Date(`${date}T${time}:00Z`);
  if (Number.isNaN(guess.getTime())) return "";
  const parts = new Intl.DateTimeFormat("en-US", {
    timeZone, year: "numeric", month: "2-digit", day: "2-digit",
    hour: "2-digit", minute: "2-digit", second: "2-digit", hour12: false,
  }).formatToParts(guess);
  const get = (t: string) => parseInt(parts.find((p) => p.type === t)?.value || "0", 10);
  const asUtc = Date.UTC(get("year"), get("month") - 1, get("day"), get("hour"), get("minute"), get("second"));
  const offset = asUtc - guess.getTime();
  return new Date(guess.getTime() - offset).toISOString();
}

/** Display a UTC instant in a timezone, e.g. "Jun 2, 2026, 6:00 AM". */
export function formatScheduledFor(utcIso: string, timeZone: string): string {
  if (!utcIso) return "";
  const d = new Date(utcIso);
  if (Number.isNaN(d.getTime())) return "";
  return new Intl.DateTimeFormat(undefined, {
    timeZone, month: "short", day: "numeric", year: "numeric",
    hour: "numeric", minute: "2-digit", hour12: true,
  }).format(d);
}

export type PendingScheduledSend = {
  id: string;
  scheduled_for: string;
  timezone: string;
  send_type: string;
};

export type ScheduleSendInsert = {
  send_type: string;
  target_function: string;
  payload: Record<string, unknown>;
  response_id?: string | null;
  scheduled_for_utc: string;
  timezone: string;
};

/**
 * Insert a pending scheduled_sends row. The payload MUST be byte-identical to
 * what the Send-Now path would have sent, so the fire engine replays the exact
 * same call. created_by is the current authenticated HR user (for attribution).
 * Throws on failure so callers can keep the dialog open and surface an error.
 */
export async function insertScheduledSend(input: ScheduleSendInsert): Promise<void> {
  const { data: userData } = await supabase.auth.getUser();
  const createdBy = userData?.user?.id ?? null;
  const { error } = await supabase.from("scheduled_sends").insert({
    send_type: input.send_type,
    target_function: input.target_function,
    payload: input.payload as any,
    response_id: input.response_id ?? null,
    scheduled_for: input.scheduled_for_utc,
    timezone: input.timezone,
    status: "pending",
    created_by: createdBy,
  } as any);
  if (error) throw new Error(error.message || "Could not schedule send");
}

/**
 * Soonest pending scheduled send for a given response_id, or null.
 * Display-only — used to render the amber "Scheduled for …" chip.
 */
export async function getPendingScheduledForResponse(
  responseId: string,
): Promise<PendingScheduledSend | null> {
  const { data, error } = await supabase
    .from("scheduled_sends")
    .select("id, scheduled_for, timezone, send_type")
    .eq("response_id", responseId)
    .eq("status", "pending")
    .order("scheduled_for", { ascending: true })
    .limit(1)
    .maybeSingle();
  if (error || !data) return null;
  return data as PendingScheduledSend;
}
