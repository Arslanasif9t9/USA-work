// Form typography settings — stored on forms.typography (jsonb).
// Applied to candidate-facing content + admin preview/edit canvas.

export type FontFamilyId = "sans" | "serif" | "mono" | "display" | "rounded";
export type FontSizeId = "sm" | "md" | "lg" | "xl";
export type AlignId = "left" | "center" | "right";

export type FormTypography = {
  fontFamily?: FontFamilyId;
  fontSize?: FontSizeId;
  bold?: boolean;
  italic?: boolean;
  underline?: boolean;
  color?: string | null;       // hex; null = use theme default
  align?: AlignId;
};

export const DEFAULT_TYPOGRAPHY: Required<Omit<FormTypography, "color">> & { color: string | null } = {
  fontFamily: "sans",
  fontSize: "md",
  bold: false,
  italic: false,
  underline: false,
  color: null,
  align: "left",
};

export const FONT_FAMILIES: { id: FontFamilyId; name: string; stack: string }[] = [
  { id: "sans",    name: "Sans (Inter)",        stack: 'Inter, ui-sans-serif, system-ui, -apple-system, "Segoe UI", Roboto, sans-serif' },
  { id: "serif",   name: "Serif (Georgia)",      stack: 'Georgia, "Times New Roman", Times, serif' },
  { id: "mono",    name: "Mono (JetBrains)",     stack: '"JetBrains Mono", ui-monospace, SFMono-Regular, Menlo, monospace' },
  { id: "display", name: "Display (Playfair)",   stack: '"Playfair Display", Georgia, serif' },
  { id: "rounded", name: "Rounded (Nunito)",     stack: 'Nunito, "Segoe UI", Roboto, sans-serif' },
];

// Multiplier applied to all font sizes via CSS var --ftype-scale
export const FONT_SIZES: { id: FontSizeId; name: string; scale: number }[] = [
  { id: "sm", name: "Small",       scale: 0.875 },
  { id: "md", name: "Medium",      scale: 1 },
  { id: "lg", name: "Large",       scale: 1.125 },
  { id: "xl", name: "Extra large", scale: 1.25 },
];

export const mergeTypography = (raw: any): Required<Omit<FormTypography, "color">> & { color: string | null } => ({
  ...DEFAULT_TYPOGRAPHY,
  ...(raw && typeof raw === "object" ? raw : {}),
});

export const typographyStyle = (t: FormTypography): React.CSSProperties => {
  const fam = FONT_FAMILIES.find((f) => f.id === (t.fontFamily || "sans")) || FONT_FAMILIES[0];
  const sz = FONT_SIZES.find((s) => s.id === (t.fontSize || "md")) || FONT_SIZES[1];
  const style: React.CSSProperties & Record<string, string> = {
    ["--ftype-scale" as any]: String(sz.scale),
    fontFamily: fam.stack,
    textAlign: t.align || "left",
  };
  if (t.color) style.color = t.color;
  if (t.bold) style.fontWeight = "700";
  if (t.italic) style.fontStyle = "italic";
  if (t.underline) (style as any).textDecoration = "underline";
  return style;
};

export const typographyEqual = (a: FormTypography, b: FormTypography) =>
  JSON.stringify(mergeTypography(a)) === JSON.stringify(mergeTypography(b));
