// Scheduling helpers for the "Schedule a Call" question type.
// All time math is done in the config's timezone for slot generation,
// but values are stored as UTC ISO strings (timestamptz).

export type DayKey = "mon" | "tue" | "wed" | "thu" | "fri" | "sat" | "sun";
export const DAY_KEYS: DayKey[] = ["mon", "tue", "wed", "thu", "fri", "sat", "sun"];
export const DAY_LABELS: Record<DayKey, string> = {
  mon: "Monday", tue: "Tuesday", wed: "Wednesday", thu: "Thursday",
  fri: "Friday", sat: "Saturday", sun: "Sunday",
};

export type WorkingHours = Record<DayKey, [string, string] | null>;

export type SchedulingConfig = {
  id: string;
  question_id: string;
  form_id: string;
  calendar_source: "internal" | "google_calendar" | "calendly";
  timezone: string;
  slot_duration_minutes: number;
  buffer_minutes: number;
  working_hours: WorkingHours;
  advance_notice_hours: number;
  booking_window_days: number;
  disclaimer_text: string;
};

export type BlockedSlot = {
  id: string;
  config_id: string;
  start_at: string;
  end_at: string;
  reason: string | null;
};

export type Booking = {
  id: string;
  config_id: string;
  slot_start: string;
  slot_end: string;
  status: "pending_approval" | "approved" | "rejected" | "cancelled";
  candidate_name?: string | null;
  candidate_email?: string | null;
};

export const DEFAULT_DISCLAIMER =
  "Please note: Booking a time slot does not guarantee an interview. Your selection is provisional and remains subject to review by our hiring team. You will receive formal confirmation via email only if your application advances to the interview stage.";

export const defaultWorkingHours = (): WorkingHours => ({
  mon: ["09:00", "17:00"],
  tue: ["09:00", "17:00"],
  wed: ["09:00", "17:00"],
  thu: ["09:00", "17:00"],
  fri: ["09:00", "17:00"],
  sat: null,
  sun: null,
});

export const detectBrowserTimezone = (): string => {
  try {
    return Intl.DateTimeFormat().resolvedOptions().timeZone || "UTC";
  } catch {
    return "UTC";
  }
};

// Build a Date for a Y-M-D + HH:mm in a given IANA timezone.
// We compute the offset for that wall time by formatting in the timezone and
// reading back the components.
const buildZonedDate = (
  year: number, month: number, day: number,
  hour: number, minute: number, timeZone: string,
): Date => {
  // Start from UTC guess.
  const guess = new Date(Date.UTC(year, month - 1, day, hour, minute, 0));
  const parts = new Intl.DateTimeFormat("en-US", {
    timeZone, year: "numeric", month: "2-digit", day: "2-digit",
    hour: "2-digit", minute: "2-digit", second: "2-digit", hour12: false,
  }).formatToParts(guess);
  const get = (t: string) => parseInt(parts.find((p) => p.type === t)?.value || "0", 10);
  const asUtc = Date.UTC(get("year"), get("month") - 1, get("day"), get("hour"), get("minute"), get("second"));
  const offset = asUtc - guess.getTime();
  return new Date(guess.getTime() - offset);
};

// Returns the weekday key (mon..sun) of a Date as seen in the configured timezone.
export const dayKeyInTz = (date: Date, timeZone: string): DayKey => {
  const wd = new Intl.DateTimeFormat("en-US", { timeZone, weekday: "short" }).format(date);
  const map: Record<string, DayKey> = { Mon: "mon", Tue: "tue", Wed: "wed", Thu: "thu", Fri: "fri", Sat: "sat", Sun: "sun" };
  return map[wd] || "mon";
};

// Returns Y-M-D as seen in the timezone.
export const ymdInTz = (date: Date, timeZone: string): { y: number; m: number; d: number } => {
  const parts = new Intl.DateTimeFormat("en-US", {
    timeZone, year: "numeric", month: "2-digit", day: "2-digit",
  }).formatToParts(date);
  const get = (t: string) => parseInt(parts.find((p) => p.type === t)?.value || "0", 10);
  return { y: get("year"), m: get("month"), d: get("day") };
};

export const parseHHMM = (s: string): [number, number] => {
  const [h, m] = s.split(":").map((x) => parseInt(x, 10));
  return [h || 0, m || 0];
};

export type Slot = { start: Date; end: Date; key: string };

/**
 * Generate all candidate slots for a given local date in the config's timezone.
 * `date` is interpreted by its Y-M-D components in the config timezone.
 * This is the single source of truth — future Google/Calendly branches go here.
 */
export const generateSlotsForDate = (
  date: Date,
  config: SchedulingConfig,
): Slot[] => {
  if (config.calendar_source !== "internal") {
    // Hook for future integrations
    return [];
  }
  const { y, m, d } = ymdInTz(date, config.timezone);
  const dk = dayKeyInTz(date, config.timezone);
  const hours = config.working_hours?.[dk];
  if (!hours) return [];
  const [sh, sm] = parseHHMM(hours[0]);
  const [eh, em] = parseHHMM(hours[1]);
  const startUtc = buildZonedDate(y, m, d, sh, sm, config.timezone);
  const endUtc = buildZonedDate(y, m, d, eh, em, config.timezone);
  const step = (config.slot_duration_minutes + config.buffer_minutes) * 60 * 1000;
  const dur = config.slot_duration_minutes * 60 * 1000;
  const out: Slot[] = [];
  for (let t = startUtc.getTime(); t + dur <= endUtc.getTime(); t += step) {
    const start = new Date(t);
    const end = new Date(t + dur);
    out.push({ start, end, key: start.toISOString() });
  }
  return out;
};

export const isSlotBlocked = (slot: Slot, blocked: BlockedSlot[]): boolean => {
  const s = slot.start.getTime();
  const e = slot.end.getTime();
  return blocked.some((b) => {
    const bs = new Date(b.start_at).getTime();
    const be = new Date(b.end_at).getTime();
    return s < be && e > bs;
  });
};

export const isSlotBooked = (slot: Slot, bookings: Booking[]): boolean => {
  const s = slot.start.getTime();
  return bookings.some(
    (b) =>
      (b.status === "pending_approval" || b.status === "approved") &&
      new Date(b.slot_start).getTime() === s,
  );
};

export const isSlotTooSoon = (slot: Slot, advanceNoticeHours: number): boolean => {
  return slot.start.getTime() - Date.now() < advanceNoticeHours * 3600 * 1000;
};

export type SlotState = "available" | "blocked" | "booked" | "too_soon" | "outside_hours";

export const getSlotState = (
  slot: Slot,
  config: SchedulingConfig,
  blocked: BlockedSlot[],
  bookings: Booking[],
): SlotState => {
  if (isSlotBlocked(slot, blocked)) return "blocked";
  if (isSlotBooked(slot, bookings)) return "booked";
  if (isSlotTooSoon(slot, config.advance_notice_hours)) return "too_soon";
  return "available";
};

export const formatTimeInTz = (date: Date, timeZone: string): string => {
  return new Intl.DateTimeFormat(undefined, {
    timeZone, hour: "numeric", minute: "2-digit", hour12: true,
  }).format(date);
};

export const formatDateInTz = (date: Date, timeZone: string): string => {
  return new Intl.DateTimeFormat(undefined, {
    timeZone, weekday: "short", month: "short", day: "numeric",
  }).format(date);
};

export const formatFullDateInTz = (date: Date, timeZone: string): string => {
  return new Intl.DateTimeFormat(undefined, {
    timeZone, weekday: "long", month: "long", day: "numeric", year: "numeric",
  }).format(date);
};

// Returns N consecutive days starting from `from` (inclusive), preserving the
// configured timezone (i.e. local-midnight in tz).
export const getDateRange = (from: Date, days: number): Date[] => {
  const out: Date[] = [];
  for (let i = 0; i < days; i++) {
    const d = new Date(from);
    d.setDate(d.getDate() + i);
    out.push(d);
  }
  return out;
};

export const COMMON_TIMEZONES = [
  "UTC",
  "America/New_York",
  "America/Chicago",
  "America/Denver",
  "America/Los_Angeles",
  "America/Toronto",
  "America/Sao_Paulo",
  "Europe/London",
  "Europe/Paris",
  "Europe/Berlin",
  "Europe/Madrid",
  "Africa/Cairo",
  "Asia/Dubai",
  "Asia/Kolkata",
  "Asia/Singapore",
  "Asia/Tokyo",
  "Asia/Shanghai",
  "Australia/Sydney",
  "Pacific/Auckland",
];
