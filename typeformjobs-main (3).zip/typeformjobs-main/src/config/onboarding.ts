// Single source of truth (frontend) for the default EIA onboarding training
// video. Mirrors supabase/functions/_shared/onboarding-video.ts — kept in sync
// because the browser and edge runtimes can't share an import.
export const DEFAULT_ONBOARDING_VIDEO_URL = "https://player.vimeo.com/video/1199893890";
