// ============================================================
// BRAND CONFIG — white-label foundation.
// To clone the AI interview page for another company, edit ONLY this file.
// ============================================================

export const BRAND = {
  companyName: "Expert Intuitive Advisor Inc.",
  companyShortName: "EIA",
  wordmarkText: "EIA",
  /** Optional logo image. Empty string = render the wordmark text instead. */
  logoUrl: "",
  colors: {
    navy: "#1a2547",
    navyDeep: "#0f1730",
    gold: "#b08d57",
    goldSoft: "#c9a877",
    cream: "#faf8f3",
    rule: "#e6e0d1",
  },
  interviewerName: "Christine",
  interviewerTitle: "Talent Recruiter — HR",
} as const;

export type Brand = typeof BRAND;
