import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter,
} from "@/components/ui/dialog";
import { Table, TableHeader, TableBody, TableRow, TableHead, TableCell } from "@/components/ui/table";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { ArrowLeft, Loader2, UserCog, Plus, Pencil, FileText, Sparkles, Bot, RefreshCw, Rocket, ExternalLink } from "lucide-react";
import { toast } from "sonner";
import OnboardingTestResultsSection from "@/components/OnboardingTestResultsSection";

type Offer = {
  id: string;
  candidate_id: string | null;
  candidate_name: string;
  candidate_email: string;
  position_title: string;
  override_email?: string | null;
};

const AGENT_OPTIONS = [
  "Genius E-Com & Marketing",
  "Stock Market Intelligence",
  "Real Estate Intelligence",
] as const;

type BoardRow = {
  id: string;
  response_id: string | null;
  board_id: string | null;
  board_name: string | null;
  assigned_agent?: string | null;
  onboarding_notes?: string | null;
  onboarding_credentials?: string | null;
};

export default function SylviaDashboard() {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(true);
  const [offers, setOffers] = useState<Offer[]>([]);
  const [respIdByCandidate, setRespIdByCandidate] = useState<Record<string, string>>({});
  const [boardByResp, setBoardByResp] = useState<Record<string, BoardRow>>({});
  // response_id -> true when an onboarding form has been submitted
  const [onboardingByResp, setOnboardingByResp] = useState<Record<string, boolean>>({});

  // assign dialog state
  const [assignTarget, setAssignTarget] = useState<{ offer: Offer; respId: string; existing: BoardRow | null } | null>(null);
  const [boardName, setBoardName] = useState("");
  const [boardId, setBoardId] = useState("");
  const [agentVal, setAgentVal] = useState<string>("");
  const [saving, setSaving] = useState(false);

  // daily brief state
  const [briefVal, setBriefVal] = useState("");
  const [briefLoading, setBriefLoading] = useState(true);
  const [briefSaving, setBriefSaving] = useState(false);

  // details dialog state
  const [detailsTarget, setDetailsTarget] = useState<{ offer: Offer; respId: string; existing: BoardRow | null } | null>(null);
  const [notesVal, setNotesVal] = useState("");
  const [credsVal, setCredsVal] = useState("");
  const [savingDetails, setSavingDetails] = useState(false);

  // PMS boards (from edge function pms-list-boards)
  type PmsBoard = { id: string; name: string; workspace_id?: string | null; icon_emoji?: string | null };
  const [pmsBoards, setPmsBoards] = useState<PmsBoard[]>([]);
  const [pmsLoading, setPmsLoading] = useState(false);
  const [pmsError, setPmsError] = useState<string | null>(null);

  const fetchPmsBoards = async () => {
    setPmsLoading(true);
    setPmsError(null);
    try {
      const { data, error } = await supabase.functions.invoke("pms-list-boards", { body: {} });
      if (error) throw error;
      const list = ((data as any)?.boards || []) as PmsBoard[];
      setPmsBoards(list);
    } catch (e: any) {
      setPmsError(e?.message || "Couldn't load boards");
      setPmsBoards([]);
    } finally {
      setPmsLoading(false);
    }
  };

  useEffect(() => { fetchPmsBoards(); }, []);


  const load = async () => {
    setLoading(true);
    const { data, error } = await supabase
      .from("job_offers")
      .select("id, candidate_id, candidate_name, candidate_email, position_title, override_email")
      .eq("status", "signed")
      .eq("employment_status", "active")
      .order("signed_at", { ascending: false });
    if (error) {
      toast.error(error.message);
      setLoading(false);
      return;
    }
    const rows = (data as Offer[]) || [];
    const candIds = Array.from(new Set(rows.map((o) => o.candidate_id).filter(Boolean) as string[]));
    const idMap: Record<string, string> = {};
    const matchedSet = new Set<string>();
    if (candIds.length) {
      const { data: resps } = await (supabase
        .from("responses") as any)
        .select("id, applicant_id, final_outcome")
        .in("applicant_id", candIds)
        .eq("final_outcome", "matched");
      for (const r of ((resps as any[]) || [])) {
        matchedSet.add(r.applicant_id);
        idMap[r.applicant_id] = r.id;
      }
    }
    setRespIdByCandidate(idMap);
    const filtered = rows.filter((o) => o.candidate_id && matchedSet.has(o.candidate_id));
    setOffers(filtered);

    const respIds = filtered.map((o) => (o.candidate_id ? idMap[o.candidate_id] : null)).filter(Boolean) as string[];
    if (respIds.length) {
      const { data: boards } = await (supabase
        .from("employee_boards") as any)
        .select("id, response_id, board_id, board_name, onboarding_notes, onboarding_credentials, assigned_agent")
        .in("response_id", respIds);
      const map: Record<string, BoardRow> = {};
      for (const b of ((boards as BoardRow[]) || [])) {
        if (b.response_id) map[b.response_id] = b;
      }
      setBoardByResp(map);
    } else {
      setBoardByResp({});
    }

    // Which of these employees have a submitted onboarding form?
    if (respIds.length) {
      const { data: subs } = await (supabase
        .from("onboarding_submissions") as any)
        .select("response_id, submitted_at")
        .in("response_id", respIds)
        .not("submitted_at", "is", null);
      const submap: Record<string, boolean> = {};
      for (const s of ((subs as any[]) || [])) {
        if (s.response_id) submap[s.response_id] = true;
      }
      setOnboardingByResp(submap);
    } else {
      setOnboardingByResp({});
    }
    setLoading(false);
  };

  useEffect(() => { load(); }, []);

  useEffect(() => {
    (async () => {
      setBriefLoading(true);
      const { data, error } = await (supabase
        .from("scheduling_config") as any)
        .select("sylvia_daily_brief")
        .eq("id", 1)
        .maybeSingle();
      if (!error && data) setBriefVal((data as any).sylvia_daily_brief || "");
      setBriefLoading(false);
    })();
  }, []);

  const saveBrief = async () => {
    setBriefSaving(true);
    try {
      const { error } = await (supabase
        .from("scheduling_config") as any)
        .update({ sylvia_daily_brief: briefVal.trim() || null })
        .eq("id", 1);
      if (error) throw error;
      toast.success("Daily Brief saved");
    } catch (e: any) {
      toast.error(e?.message || "Failed to save Daily Brief");
    } finally {
      setBriefSaving(false);
    }
  };

  const openAssign = (offer: Offer) => {
    const respId = offer.candidate_id ? respIdByCandidate[offer.candidate_id] : null;
    if (!respId) {
      toast.error("No matched response found for this employee");
      return;
    }
    const existing = boardByResp[respId] || null;
    setBoardName(existing?.board_name || "");
    setBoardId(existing?.board_id || "");
    setAgentVal(existing?.assigned_agent || "");
    setAssignTarget({ offer, respId, existing });
  };

  const closeAssign = () => {
    setAssignTarget(null);
    setBoardName("");
    setBoardId("");
    setAgentVal("");
  };

  const saveBoard = async () => {
    if (!assignTarget) return;
    const idValue = boardId.trim();
    if (!idValue) {
      toast.error("Please select a board");
      return;
    }
    const selected = pmsBoards.find((b) => b.id === idValue);
    const name = (selected?.name || boardName).trim();
    if (!name) {
      toast.error("Selected board has no name");
      return;
    }
    const agentValue = agentVal.trim() || null;
    setSaving(true);
    try {
      const { respId, existing } = assignTarget;
      let savedRow: BoardRow | null = null;
      const selectCols = "id, response_id, board_id, board_name, onboarding_notes, onboarding_credentials, assigned_agent";

      if (existing) {
        const { data, error } = await (supabase
          .from("employee_boards") as any)
          .update({ board_name: name, board_id: idValue, assigned_agent: agentValue, updated_at: new Date().toISOString() })
          .eq("id", existing.id)
          .select(selectCols)
          .single();
        if (error) throw error;
        savedRow = data as BoardRow;
      } else {
        const { data, error } = await (supabase
          .from("employee_boards") as any)
          .insert({ response_id: respId, board_name: name, board_id: idValue, assigned_agent: agentValue })
          .select(selectCols)
          .single();
        if (error) throw error;
        savedRow = data as BoardRow;
      }

      if (savedRow) {
        setBoardByResp((prev) => ({ ...prev, [respId]: savedRow! }));
      }
      toast.success("Board assigned");
      closeAssign();
    } catch (e: any) {
      toast.error(e?.message || "Failed to save board");
    } finally {
      setSaving(false);
    }
  };

  const openDetails = (offer: Offer) => {
    const respId = offer.candidate_id ? respIdByCandidate[offer.candidate_id] : null;
    if (!respId) {
      toast.error("No matched response found for this employee");
      return;
    }
    const existing = boardByResp[respId] || null;
    setNotesVal(existing?.onboarding_notes || "");
    setCredsVal(existing?.onboarding_credentials || "");
    setDetailsTarget({ offer, respId, existing });
  };

  const closeDetails = () => {
    setDetailsTarget(null);
    setNotesVal("");
    setCredsVal("");
  };

  const saveDetails = async () => {
    if (!detailsTarget) return;
    setSavingDetails(true);
    try {
      const { respId, existing } = detailsTarget;
      const notes = notesVal.trim() || null;
      const creds = credsVal.trim() || null;
      let savedRow: BoardRow | null = null;

      if (existing) {
        const { data, error } = await (supabase
          .from("employee_boards") as any)
          .update({
            onboarding_notes: notes,
            onboarding_credentials: creds,
            updated_at: new Date().toISOString(),
          })
          .eq("id", existing.id)
          .select("id, response_id, board_id, board_name, onboarding_notes, onboarding_credentials, assigned_agent")
          .single();
        if (error) throw error;
        savedRow = data as BoardRow;
      } else {
        const { data, error } = await (supabase
          .from("employee_boards") as any)
          .insert({
            response_id: respId,
            onboarding_notes: notes,
            onboarding_credentials: creds,
          })
          .select("id, response_id, board_id, board_name, onboarding_notes, onboarding_credentials, assigned_agent")
          .single();
        if (error) throw error;
        savedRow = data as BoardRow;
      }

      if (savedRow) {
        setBoardByResp((prev) => ({ ...prev, [respId]: savedRow! }));
      }
      toast.success("Saved");
      closeDetails();
    } catch (e: any) {
      toast.error(e?.message || "Failed to save");
    } finally {
      setSavingDetails(false);
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <header className="border-b bg-card">
        <div className="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between">
          <Button variant="ghost" size="sm" onClick={() => navigate("/dashboard")}>
            <ArrowLeft className="h-4 w-4 mr-1.5" /> Back
          </Button>
          <div className="flex items-center gap-3">
            <Button variant="ghost" size="sm" onClick={() => navigate("/dashboard/launch")}>
              <Rocket className="h-4 w-4 mr-1.5" /> Launch Sylvia
            </Button>
            <div className="flex items-center gap-2" style={{ color: "#b8860b" }}>
              <UserCog className="h-5 w-5" />
              <span className="text-sm font-medium">Agent Sylvia</span>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-6 py-10">
        <div className="mb-8">
          <h1
            className="text-4xl font-semibold tracking-tight"
            style={{ fontFamily: "'Cormorant Garamond', serif", color: "#1a2547" }}
          >
            Agent Sylvia — Onboarding Boards
          </h1>
          <p className="text-muted-foreground mt-1">
            Active employees and their assigned PMS boards
          </p>
        </div>

        <div className="mb-8 border rounded-md bg-card p-5">
          <div className="flex items-center gap-2 mb-3">
            <Sparkles className="h-4 w-4" style={{ color: "#b8860b" }} />
            <h2 className="text-lg font-semibold">Daily Brief (all hires)</h2>
          </div>
          <p className="text-xs text-muted-foreground mb-3">
            One global note Sylvia shares with every active hire today.
          </p>
          {briefLoading ? (
            <div className="flex items-center text-sm text-muted-foreground">
              <Loader2 className="h-4 w-4 mr-2 animate-spin" /> Loading…
            </div>
          ) : (
            <>
              <Textarea
                value={briefVal}
                onChange={(e) => setBriefVal(e.target.value)}
                rows={4}
                placeholder="e.g. Today: team-wide standup at 10:00 PHT. Reminder to log hours by 6 PM."
              />
              <div className="flex justify-end mt-3">
                <Button onClick={saveBrief} disabled={briefSaving}>
                  {briefSaving ? <Loader2 className="h-4 w-4 mr-1.5 animate-spin" /> : null}
                  Save Daily Brief
                </Button>
              </div>
            </>
          )}
        </div>

        <OnboardingTestResultsSection />



        {loading ? (
          <div className="flex items-center justify-center py-20">
            <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
          </div>
        ) : offers.length === 0 ? (
          <div className="text-center py-20 text-muted-foreground">
            No active matched employees yet.
          </div>
        ) : (
          <div className="border rounded-md bg-card">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Name</TableHead>
                  <TableHead>Position</TableHead>
                  <TableHead>Email</TableHead>
                  <TableHead>Assigned Board</TableHead>
                  <TableHead>Details</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {offers.map((o) => {
                  const respId = o.candidate_id ? respIdByCandidate[o.candidate_id] : null;
                  const board = respId ? boardByResp[respId] : null;
                  const email = o.override_email || o.candidate_email;
                  const hasNotes = !!(board?.onboarding_notes && board.onboarding_notes.trim());
                  const hasCreds = !!(board?.onboarding_credentials && board.onboarding_credentials.trim());
                  return (
                    <TableRow key={o.id}>
                      <TableCell className="font-medium">{o.candidate_name}</TableCell>
                      <TableCell>{o.position_title}</TableCell>
                      <TableCell className="text-muted-foreground">{email}</TableCell>
                      <TableCell>
                        {board?.board_name ? (
                          <div className="flex items-center gap-2 flex-wrap">
                            <Badge variant="secondary">{board.board_name}</Badge>
                            {board.board_id && (
                              <span className="text-[10px] uppercase tracking-wide text-muted-foreground">
                                ID set
                              </span>
                            )}
                            {board.assigned_agent && (
                              <Badge variant="outline" className="gap-1">
                                <Bot className="h-3 w-3" /> {board.assigned_agent}
                              </Badge>
                            )}
                            <Button
                              variant="ghost"
                              size="sm"
                              className="h-7 px-2"
                              onClick={() => openAssign(o)}
                            >
                              <Pencil className="h-3 w-3 mr-1" /> Change
                            </Button>
                          </div>
                        ) : (
                          <div className="flex items-center gap-2 flex-wrap">
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => openAssign(o)}
                            >
                              <Plus className="h-3 w-3 mr-1" /> Assign board
                            </Button>
                            {board?.assigned_agent && (
                              <Badge variant="outline" className="gap-1">
                                <Bot className="h-3 w-3" /> {board.assigned_agent}
                              </Badge>
                            )}
                          </div>
                        )}
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center gap-2 flex-wrap">
                          <Button
                            variant="outline"
                            size="sm"
                            className="h-7"
                            onClick={() => openDetails(o)}
                          >
                            <FileText className="h-3 w-3 mr-1" /> Details
                          </Button>
                          {respId && onboardingByResp[respId] ? (
                            <Button
                              variant="outline"
                              size="sm"
                              className="h-7"
                              onClick={() => window.open(`/onboarding-submission/${respId}`, "_blank", "noopener,noreferrer")}
                            >
                              <ExternalLink className="h-3 w-3 mr-1" /> View Onboarding Submission
                            </Button>
                          ) : (
                            <span className="text-[10px] uppercase tracking-wide text-muted-foreground">
                              No onboarding submission yet
                            </span>
                          )}
                          {hasNotes && (
                            <span className="text-[10px] uppercase tracking-wide text-muted-foreground">
                              notes set
                            </span>
                          )}
                          {hasCreds && (
                            <span className="text-[10px] uppercase tracking-wide text-muted-foreground">
                              credentials set
                            </span>
                          )}
                        </div>
                      </TableCell>
                    </TableRow>
                  );
                })}
              </TableBody>
            </Table>
          </div>
        )}
      </main>

      <Dialog open={!!assignTarget} onOpenChange={(open) => { if (!open) closeAssign(); }}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>
              {assignTarget?.existing ? "Change board" : "Assign board"}
            </DialogTitle>
            <DialogDescription>
              {assignTarget ? `For ${assignTarget.offer.candidate_name}` : ""}
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-2">
            <div className="space-y-1.5">
              <div className="flex items-center justify-between">
                <Label htmlFor="board-select">
                  PMS Board <span className="text-destructive">*</span>
                </Label>
                <Button
                  type="button"
                  variant="ghost"
                  size="sm"
                  className="h-7 px-2"
                  onClick={fetchPmsBoards}
                  disabled={pmsLoading}
                >
                  <RefreshCw className={`h-3 w-3 mr-1 ${pmsLoading ? "animate-spin" : ""}`} />
                  Refresh
                </Button>
              </div>
              {pmsLoading ? (
                <div className="flex items-center text-sm text-muted-foreground py-2">
                  <Loader2 className="h-4 w-4 mr-2 animate-spin" /> Loading boards…
                </div>
              ) : pmsError ? (
                <div className="text-sm text-destructive py-1">
                  Couldn't load boards: {pmsError}
                </div>
              ) : pmsBoards.length === 0 ? (
                <div className="text-sm text-muted-foreground py-1">
                  No boards found in PMS.
                </div>
              ) : (
                <Select value={boardId} onValueChange={setBoardId}>
                  <SelectTrigger id="board-select">
                    <SelectValue placeholder="Select a board" />
                  </SelectTrigger>
                  <SelectContent>
                    {pmsBoards.map((b) => (
                      <SelectItem key={b.id} value={b.id}>
                        {b.icon_emoji ? `${b.icon_emoji} ` : ""}{b.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              )}
              {boardId && !pmsBoards.find((b) => b.id === boardId) && boardName && (
                <p className="text-[11px] text-muted-foreground">
                  Currently assigned: <span className="font-medium">{boardName}</span> (not in live PMS list — pick a board above to replace)
                </p>
              )}
            </div>

            <div className="space-y-1.5">
              <Label htmlFor="assigned-agent">Assigned work-agent (optional)</Label>
              <Select
                value={agentVal || "__none__"}
                onValueChange={(v) => setAgentVal(v === "__none__" ? "" : v)}
              >
                <SelectTrigger id="assigned-agent">
                  <SelectValue placeholder="Select an agent" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="__none__">None</SelectItem>
                  {AGENT_OPTIONS.map((a) => (
                    <SelectItem key={a} value={a}>{a}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={closeAssign} disabled={saving}>
              Cancel
            </Button>
            <Button onClick={saveBoard} disabled={saving || !boardId.trim() || pmsLoading}>
              {saving ? <Loader2 className="h-4 w-4 mr-1.5 animate-spin" /> : null}
              Save
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={!!detailsTarget} onOpenChange={(open) => { if (!open) closeDetails(); }}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>Onboarding details</DialogTitle>
            <DialogDescription>
              {detailsTarget ? `For ${detailsTarget.offer.candidate_name}` : ""}
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-2">
            <div className="space-y-1.5">
              <Label>Assigned board</Label>
              <div className="text-sm">
                {detailsTarget?.existing?.board_name ? (
                  <div className="flex items-center gap-2 flex-wrap">
                    <Badge variant="secondary">{detailsTarget.existing.board_name}</Badge>
                    {detailsTarget.existing.board_id && (
                      <span className="text-[10px] uppercase tracking-wide text-muted-foreground">
                        ID: {detailsTarget.existing.board_id}
                      </span>
                    )}
                  </div>
                ) : (
                  <span className="text-muted-foreground italic">No board assigned yet</span>
                )}
              </div>
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="onboarding-notes">Onboarding notes</Label>
              <Textarea
                id="onboarding-notes"
                value={notesVal}
                onChange={(e) => setNotesVal(e.target.value)}
                placeholder="Anything Sylvia should know to onboard this hire well…"
                rows={5}
              />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="onboarding-creds">
                Starter credentials <span className="text-muted-foreground">(Sylvia will share these with the hire)</span>
              </Label>
              <Textarea
                id="onboarding-creds"
                value={credsVal}
                onChange={(e) => setCredsVal(e.target.value)}
                placeholder={"Email: name@company.com\nTemp pass: ...\nTool login: ..."}
                rows={6}
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={closeDetails} disabled={savingDetails}>
              Cancel
            </Button>
            <Button onClick={saveDetails} disabled={savingDetails}>
              {savingDetails ? <Loader2 className="h-4 w-4 mr-1.5 animate-spin" /> : null}
              Save
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
