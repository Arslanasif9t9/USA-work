import { useEffect, useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Badge } from "@/components/ui/badge";
import {
  ArrowLeft,
  Pencil,
  Plus,
  Search,
  Trash2,
  Loader2,
  X,
  Check,
} from "lucide-react";
import { toast } from "sonner";

const CATEGORIES = [
  "Real Estate",
  "E-commerce",
  "Marketing",
  "Research",
  "Admin Support",
  "AI & Tools",
  "General",
];

const PAGE_SIZE = 50;

type ScopeItem = {
  id: string;
  text: string;
  category: string;
  usage_count: number;
  created_at: string;
};

const JobScopeLibrary = () => {
  const navigate = useNavigate();
  const [items, setItems] = useState<ScopeItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [categoryFilter, setCategoryFilter] = useState<string>("ALL");
  const [page, setPage] = useState(1);

  // Add form
  const [addOpen, setAddOpen] = useState(false);
  const [addText, setAddText] = useState("");
  const [addCategory, setAddCategory] = useState("General");
  const [addError, setAddError] = useState<string | null>(null);
  const [adding, setAdding] = useState(false);

  // Edit
  const [editId, setEditId] = useState<string | null>(null);
  const [editText, setEditText] = useState("");
  const [editCategory, setEditCategory] = useState("General");
  const [editError, setEditError] = useState<string | null>(null);
  const [editSaving, setEditSaving] = useState(false);

  // Delete confirm dialog state
  const [deleting, setDeleting] = useState<ScopeItem | null>(null);
  const [deleteBusy, setDeleteBusy] = useState(false);

  // Highlight a row briefly (e.g., when duplicate add)
  const [highlightId, setHighlightId] = useState<string | null>(null);

  const load = async () => {
    setLoading(true);
    const { data, error } = await supabase
      .from("job_scope_library")
      .select("id, text, category, usage_count, created_at")
      .order("category", { ascending: true })
      .order("text", { ascending: true });
    if (error) {
      toast.error(error.message);
      setLoading(false);
      return;
    }
    setItems(data || []);
    setLoading(false);
  };

  useEffect(() => {
    load();
  }, []);

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    return items.filter((i) => {
      if (categoryFilter !== "ALL" && i.category !== categoryFilter) return false;
      if (q && !i.text.toLowerCase().includes(q)) return false;
      return true;
    });
  }, [items, search, categoryFilter]);

  const totalPages = Math.max(1, Math.ceil(filtered.length / PAGE_SIZE));
  const pageItems = filtered.slice((page - 1) * PAGE_SIZE, page * PAGE_SIZE);

  useEffect(() => {
    setPage(1);
  }, [search, categoryFilter]);

  const flashHighlight = (id: string) => {
    setHighlightId(id);
    setTimeout(() => setHighlightId((v) => (v === id ? null : v)), 1800);
    // Scroll into view
    setTimeout(() => {
      const el = document.getElementById(`scope-row-${id}`);
      el?.scrollIntoView({ behavior: "smooth", block: "center" });
    }, 50);
  };

  const handleAdd = async () => {
    const text = addText.trim();
    if (!text) {
      setAddError("Text cannot be empty.");
      return;
    }
    if (text.length > 200) {
      setAddError("Must be 200 characters or fewer.");
      return;
    }
    setAdding(true);
    const { data, error } = await supabase
      .from("job_scope_library")
      .insert({ text, category: addCategory })
      .select()
      .single();
    setAdding(false);
    if (error) {
      // Unique violation on LOWER(text)
      if ((error as any).code === "23505") {
        const existing = items.find((i) => i.text.toLowerCase() === text.toLowerCase());
        toast.error("Item already in library");
        if (existing) flashHighlight(existing.id);
        return;
      }
      toast.error(error.message);
      return;
    }
    toast.success("Item added");
    setAddText("");
    setAddError(null);
    setAddOpen(false);
    await load();
    if (data) flashHighlight(data.id);
  };

  const startEdit = (item: ScopeItem) => {
    setEditId(item.id);
    setEditText(item.text);
    setEditCategory(item.category);
    setEditError(null);
  };
  const cancelEdit = () => {
    setEditId(null);
    setEditError(null);
  };
  const handleEditSave = async () => {
    if (!editId) return;
    const text = editText.trim();
    if (!text) {
      setEditError("Text cannot be empty.");
      return;
    }
    if (text.length > 200) {
      setEditError("Must be 200 characters or fewer.");
      return;
    }
    // local dup check
    const dup = items.find(
      (i) => i.id !== editId && i.text.toLowerCase() === text.toLowerCase(),
    );
    if (dup) {
      setEditError("Another item with this text already exists.");
      return;
    }
    setEditSaving(true);
    const { error } = await supabase
      .from("job_scope_library")
      .update({ text, category: editCategory })
      .eq("id", editId);
    setEditSaving(false);
    if (error) {
      if ((error as any).code === "23505") {
        setEditError("Another item with this text already exists.");
        return;
      }
      toast.error(error.message);
      return;
    }
    toast.success("Item updated");
    setEditId(null);
    await load();
  };

  const handleDelete = async (item: ScopeItem) => {
    // Optimistic remove — keep snapshot for revert
    const snapshot = items;
    setItems((prev) => prev.filter((i) => i.id !== item.id));
    setDeleting(null);
    setDeleteBusy(false);

    const { error } = await supabase
      .from("job_scope_library")
      .delete()
      .eq("id", item.id);

    if (error) {
      // Revert — keep scroll position (no re-render of the whole list, same data)
      setItems(snapshot);
      const msg = error.message || "Failed to delete";
      toast.error(msg.includes("Cannot delete") ? msg : `Failed to delete: ${msg}`);
      return;
    }

    toast.success("Item deleted", {
      action: {
        label: "Undo",
        onClick: async () => {
          const { data, error: insErr } = await supabase
            .from("job_scope_library")
            .insert({ id: item.id, text: item.text, category: item.category })
            .select("id, text, category, usage_count, created_at")
            .single();
          if (insErr || !data) return toast.error("Couldn't undo: " + (insErr?.message || ""));
          setItems((prev) => [...prev, data as ScopeItem].sort((a, b) =>
            a.category.localeCompare(b.category) || a.text.localeCompare(b.text)
          ));
          setHighlightId(item.id);
          setTimeout(() => setHighlightId(null), 1500);
        },
      },
      duration: 5000,
    });
  };

  const requestDelete = (item: ScopeItem) => setDeleting(item);
  const confirmDelete = () => {
    if (!deleting) return;
    setDeleteBusy(true);
    void handleDelete(deleting);
  };

  return (
    <div className="min-h-screen bg-background">
      <header className="border-b border-border bg-background">
        <div className="max-w-6xl mx-auto px-4 md:px-6 h-16 flex items-center gap-3">
          <Button
            variant="ghost"
            size="icon"
            onClick={() => navigate("/dashboard")}
            aria-label="Back to dashboard"
            className="min-h-[44px] min-w-[44px] sm:min-h-0 sm:min-w-0"
          >
            <ArrowLeft className="h-4 w-4" />
          </Button>
          <h1 className="text-xl md:text-2xl font-bold tracking-tight">
            Job Scope Library
          </h1>
        </div>
      </header>

      <main className="max-w-6xl mx-auto px-4 md:px-6 py-6 md:py-10">
        <p className="text-sm text-muted-foreground mb-6">
          Reusable job scope items used when creating offers.
        </p>

        {/* Top controls */}
        <div className="flex flex-col sm:flex-row gap-2 sm:items-center mb-4">
          <div className="relative flex-1">
            <Search className="h-4 w-4 absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground pointer-events-none" />
            <Input
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search items..."
              className="pl-9 min-h-[44px] sm:min-h-0"
            />
          </div>
          <Select value={categoryFilter} onValueChange={setCategoryFilter}>
            <SelectTrigger className="sm:w-56 min-h-[44px] sm:min-h-0">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="ALL">All Categories</SelectItem>
              {CATEGORIES.map((c) => (
                <SelectItem key={c} value={c}>
                  {c}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Button
            onClick={() => {
              setAddOpen(true);
              setAddError(null);
            }}
            className="min-h-[44px] sm:min-h-0 sm:h-10"
          >
            <Plus className="h-4 w-4 mr-1" /> Add Item
          </Button>
        </div>

        {/* Inline add form */}
        {addOpen && (
          <div className="border border-border rounded-lg bg-secondary/30 p-4 mb-4">
            <div className="flex flex-col sm:flex-row gap-2">
              <div className="flex-1">
                <Label htmlFor="add-text" className="text-xs">
                  Text <span className="text-destructive">*</span>
                </Label>
                <Input
                  id="add-text"
                  value={addText}
                  maxLength={200}
                  onChange={(e) => {
                    setAddText(e.target.value);
                    if (addError) setAddError(null);
                  }}
                  placeholder="e.g. Manage social media calendar"
                  className="mt-1 min-h-[44px] sm:min-h-0"
                  autoFocus
                  aria-invalid={!!addError}
                />
              </div>
              <div className="sm:w-48">
                <Label className="text-xs">
                  Category <span className="text-destructive">*</span>
                </Label>
                <Select value={addCategory} onValueChange={setAddCategory}>
                  <SelectTrigger className="mt-1 min-h-[44px] sm:min-h-0">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {CATEGORIES.map((c) => (
                      <SelectItem key={c} value={c}>
                        {c}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
            {addError && (
              <p className="text-xs text-destructive mt-2">{addError}</p>
            )}
            <div className="flex gap-2 mt-3 justify-end">
              <Button
                variant="ghost"
                onClick={() => {
                  setAddOpen(false);
                  setAddText("");
                  setAddError(null);
                }}
                disabled={adding}
                className="min-h-[44px] sm:min-h-0"
              >
                Cancel
              </Button>
              <Button
                onClick={handleAdd}
                disabled={adding}
                className="min-h-[44px] sm:min-h-0"
              >
                {adding ? (
                  <>
                    <Loader2 className="h-4 w-4 mr-2 animate-spin" /> Saving...
                  </>
                ) : (
                  "Save"
                )}
              </Button>
            </div>
          </div>
        )}

        {loading ? (
          <div className="flex items-center justify-center py-16" aria-busy="true">
            <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
          </div>
        ) : items.length === 0 ? (
          <div className="text-center py-16 text-sm text-muted-foreground border border-dashed border-border rounded-lg">
            No items yet. Add your first scope item to get started.
          </div>
        ) : filtered.length === 0 ? (
          <div className="text-center py-16 text-sm text-muted-foreground border border-dashed border-border rounded-lg">
            No items match your filters.
          </div>
        ) : (
          <>
            {/* Desktop table */}
            <div className="hidden md:block border border-border rounded-lg overflow-hidden">
              <table className="w-full text-sm">
                <thead className="bg-secondary/40 text-left">
                  <tr>
                    <th className="px-4 py-2 font-medium">Text</th>
                    <th className="px-4 py-2 font-medium w-40">Category</th>
                    <th className="px-4 py-2 font-medium w-24">Usage</th>
                    <th className="px-4 py-2 font-medium w-32 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {pageItems.map((item) => {
                    const isEditing = editId === item.id;
                    const highlight = highlightId === item.id;
                    return (
                      <tr
                        key={item.id}
                        id={`scope-row-${item.id}`}
                        className={`border-t border-border group transition-colors ${
                          highlight ? "bg-amber-50" : "hover:bg-secondary/30"
                        }`}
                      >
                        {isEditing ? (
                          <>
                            <td className="px-4 py-2" colSpan={2}>
                              <div className="flex flex-col sm:flex-row gap-2">
                                <Input
                                  value={editText}
                                  maxLength={200}
                                  onChange={(e) => {
                                    setEditText(e.target.value);
                                    if (editError) setEditError(null);
                                  }}
                                  className="flex-1"
                                  aria-invalid={!!editError}
                                />
                                <Select
                                  value={editCategory}
                                  onValueChange={setEditCategory}
                                >
                                  <SelectTrigger className="sm:w-44">
                                    <SelectValue />
                                  </SelectTrigger>
                                  <SelectContent>
                                    {CATEGORIES.map((c) => (
                                      <SelectItem key={c} value={c}>
                                        {c}
                                      </SelectItem>
                                    ))}
                                  </SelectContent>
                                </Select>
                              </div>
                              {editError && (
                                <p className="text-xs text-destructive mt-1">
                                  {editError}
                                </p>
                              )}
                            </td>
                            <td className="px-4 py-2 text-muted-foreground">
                              {item.usage_count}
                            </td>
                            <td className="px-4 py-2 text-right">
                              <div className="inline-flex gap-1">
                                <Button
                                  size="icon"
                                  variant="ghost"
                                  onClick={cancelEdit}
                                  disabled={editSaving}
                                  aria-label="Cancel edit"
                                >
                                  <X className="h-4 w-4" />
                                </Button>
                                <Button
                                  size="icon"
                                  onClick={handleEditSave}
                                  disabled={editSaving}
                                  aria-label="Save edit"
                                >
                                  {editSaving ? (
                                    <Loader2 className="h-4 w-4 animate-spin" />
                                  ) : (
                                    <Check className="h-4 w-4" />
                                  )}
                                </Button>
                              </div>
                            </td>
                          </>
                        ) : (
                          <>
                            <td className="px-4 py-2">{item.text}</td>
                            <td className="px-4 py-2">
                              <Badge variant="secondary">{item.category}</Badge>
                            </td>
                            <td className="px-4 py-2 text-muted-foreground">
                              {item.usage_count}
                            </td>
                            <td className="px-4 py-2 text-right">
                              <div className="inline-flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                                <Button
                                  size="icon"
                                  variant="ghost"
                                  onClick={() => startEdit(item)}
                                  aria-label="Edit item"
                                >
                                  <Pencil className="h-4 w-4" />
                                </Button>
                                <Button
                                  size="icon"
                                  variant="ghost"
                                  onClick={() => requestDelete(item)}
                                  aria-label="Delete item"
                                  className="text-muted-foreground hover:text-destructive"
                                >
                                  <Trash2 className="h-4 w-4" />
                                </Button>
                              </div>
                            </td>
                          </>
                        )}
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>

            {/* Mobile cards */}
            <div className="md:hidden space-y-2">
              {pageItems.map((item) => {
                const isEditing = editId === item.id;
                const highlight = highlightId === item.id;
                return (
                  <div
                    key={item.id}
                    id={`scope-row-${item.id}-m`}
                    className={`border border-border rounded-lg p-3 ${
                      highlight ? "bg-amber-50" : "bg-background"
                    }`}
                  >
                    {isEditing ? (
                      <div className="space-y-2">
                        <Input
                          value={editText}
                          maxLength={200}
                          onChange={(e) => {
                            setEditText(e.target.value);
                            if (editError) setEditError(null);
                          }}
                          className="min-h-[44px]"
                          aria-invalid={!!editError}
                        />
                        <Select value={editCategory} onValueChange={setEditCategory}>
                          <SelectTrigger className="min-h-[44px]">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            {CATEGORIES.map((c) => (
                              <SelectItem key={c} value={c}>
                                {c}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                        {editError && (
                          <p className="text-xs text-destructive">{editError}</p>
                        )}
                        <div className="flex gap-2 justify-end">
                          <Button
                            variant="ghost"
                            onClick={cancelEdit}
                            disabled={editSaving}
                            className="min-h-[44px]"
                          >
                            Cancel
                          </Button>
                          <Button
                            onClick={handleEditSave}
                            disabled={editSaving}
                            className="min-h-[44px]"
                          >
                            {editSaving ? (
                              <Loader2 className="h-4 w-4 animate-spin" />
                            ) : (
                              "Save"
                            )}
                          </Button>
                        </div>
                      </div>
                    ) : (
                      <div className="space-y-2">
                        <p className="text-sm leading-snug">{item.text}</p>
                        <div className="flex items-center justify-between gap-2">
                          <div className="flex items-center gap-2">
                            <Badge variant="secondary">{item.category}</Badge>
                            <span className="text-xs text-muted-foreground">
                              Used {item.usage_count}×
                            </span>
                          </div>
                          <div className="flex gap-1">
                            <Button
                              size="icon"
                              variant="ghost"
                              onClick={() => startEdit(item)}
                              aria-label="Edit item"
                              className="min-h-[44px] min-w-[44px]"
                            >
                              <Pencil className="h-4 w-4" />
                            </Button>
                            <Button
                              size="icon"
                              variant="ghost"
                              onClick={() => requestDelete(item)}
                              aria-label="Delete item"
                              className="min-h-[44px] min-w-[44px] text-muted-foreground hover:text-destructive"
                            >
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </div>
                        </div>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>

            {/* Pagination */}
            {filtered.length > PAGE_SIZE && (
              <div className="flex items-center justify-between mt-4 text-sm">
                <span className="text-muted-foreground">
                  Showing {(page - 1) * PAGE_SIZE + 1}–
                  {Math.min(page * PAGE_SIZE, filtered.length)} of {filtered.length}
                </span>
                <div className="flex gap-2">
                  <Button
                    variant="outline"
                    size="sm"
                    disabled={page === 1}
                    onClick={() => setPage((p) => Math.max(1, p - 1))}
                  >
                    Previous
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    disabled={page >= totalPages}
                    onClick={() => setPage((p) => Math.min(totalPages, p + 1))}
                  >
                    Next
                  </Button>
                </div>
              </div>
            )}
          </>
        )}
      </main>

      <AlertDialog open={!!deleting} onOpenChange={(o) => !o && !deleteBusy && setDeleting(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Remove this job scope item?</AlertDialogTitle>
            <AlertDialogDescription>
              {deleting ? `"${deleting.text}" will be removed from the library. You can undo immediately after.` : ""}
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={deleteBusy}>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={(e) => { e.preventDefault(); confirmDelete(); }}
              disabled={deleteBusy}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              {deleteBusy ? (<><Loader2 className="h-4 w-4 mr-2 animate-spin" /> Deleting…</>) : "Delete"}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
};

export default JobScopeLibrary;
