import { useEffect, useMemo, useRef, useState } from "react";
import { useParams } from "react-router-dom";
import { RetellWebClient } from "retell-client-js-sdk";
import { supabase } from "@/integrations/supabase/client";
import { BRAND } from "@/config/brand";
import { usePageSeo } from "@/components/PageSeo";
import { AlertTriangle } from "lucide-react";
// ---------- Palette (from BRAND so cloning = edit one file) ----------
const NAVY = BRAND.colors.navy;
const NAVY_DEEP = BRAND.colors.navyDeep;
const NAVY_INK = "#11193a";
const GOLD = BRAND.colors.gold;
const GOLD_SOFT = BRAND.colors.goldSoft;
const CREAM = BRAND.colors.cream;
const CREAM_2 = "#f3eee2";
const RULE = BRAND.colors.rule;
const LIVE = "#e15a5a";
const SUCCESS = "#2f6d4f";
const DEEP_RED = "#8B2635"; // deep premium red — in-call warning banner only (UI)
const INK_60 = "rgba(26,37,71,0.62)";
const DANGER = "#E2445C";
const INK_40 = "rgba(26,37,71,0.40)";
const COMPANY = BRAND.companyName;
const COMPANY_SHORT = BRAND.companyShortName;
const WORDMARK = BRAND.wordmarkText;
const DEFAULT_INTERVIEWER = BRAND.interviewerName;
const DEFAULT_INTERVIEWER_TITLE = BRAND.interviewerTitle;
const YEAR = new Date().getFullYear();
type Status = "idle" | "starting" | "live" | "uploading" | "ended" | "error" | "camera_blocked" | "connect_failed" | "silent_mic" | "already_completed";
type Who = "agent" | "user";
type Line = { who: Who; text: string };
type DebugLine = { id: number; text: string };
type CheckStage = "mic" | "camera" | null;
type InterviewerProfile = { name: string; title: string; initial: string };

const getInterviewerForStage = (stage: string | null | undefined): InterviewerProfile => {
  const name = stage === "round2_ai" ? "Marissa" : DEFAULT_INTERVIEWER;
  return {
    name,
    title: DEFAULT_INTERVIEWER_TITLE,
    initial: (name.trim().charAt(0) || "A").toUpperCase(),
  };
};

// Phone-vs-desktop detection: keeps the proven iPhone flow on mobile and
// uses a single combined permission prompt on desktop.
const isMobileDevice = (): boolean => {
  if (typeof navigator === "undefined") return false;
  const ua = navigator.userAgent || "";
  if (/Android|iPhone|iPad|iPod|Mobile|webOS|BlackBerry|IEMobile|Opera Mini/i.test(ua)) return true;
  // iPadOS 13+ reports as Mac; detect via touch points.
  if (/Macintosh/.test(ua) && typeof navigator.maxTouchPoints === "number" && navigator.maxTouchPoints > 1) return true;
  return false;
};

const PrimaryButton = ({
  label,
  onTap,
  disabled,
  dataAttr,
}: {
  label: string;
  onTap: () => void;
  disabled?: boolean;
  dataAttr?: string;
}) => (
  <button
    type="button"
    {...(dataAttr ? { [dataAttr]: "true" } : {})}
    onClick={() => { if (!disabled) onTap(); }}
    disabled={disabled}
    className="btn-tap w-full max-w-[440px] block rounded-full transition mx-auto"
    style={{
      padding: "14px 28px",
      minHeight: 52,
      fontSize: 13,
      letterSpacing: "0.22em",
      textTransform: "uppercase",
      fontWeight: 600,
      background: disabled ? "rgba(26,37,71,0.45)" : NAVY,
      color: disabled ? "rgba(250,248,243,0.65)" : CREAM,
      boxShadow: disabled ? "none" : "0 6px 20px rgba(15,23,48,0.20)",
      cursor: disabled ? "not-allowed" : "pointer",
      opacity: 1,
      userSelect: "none",
      WebkitUserSelect: "none",
      WebkitTouchCallout: "none",
      touchAction: "manipulation",
      WebkitTapHighlightColor: "transparent",
      pointerEvents: "auto",
      position: "relative",
      zIndex: 1,
    } as React.CSSProperties}
  >
    <span className="inline-block" style={{ pointerEvents: "none" }}>{label}</span>
  </button>
);

const formatDebugValue = (value: unknown): string => {
  try {
    if (value instanceof Error) {
      return JSON.stringify({ name: value.name, message: value.message, stack: value.stack });
    }
    if (typeof value === "string") return value;
    return JSON.stringify(value, Object.getOwnPropertyNames(Object(value)));
  } catch {
    try { return String(value); } catch { return "[unserializable]"; }
  }
};
// ============================================================
// Global stylesheet (keyframes from the design handoff)
// ============================================================
const STYLES = `
  :root { color-scheme: light; }
  .ios-vh { min-height: 100vh; min-height: var(--app-vh, 100vh); }
  .call-vh { height: 100vh; height: var(--app-vh, 100vh); height: 100dvh; }
  .cream-grain {
    background-color: ${CREAM};
    background-image:
      radial-gradient(rgba(26,37,71,0.022) 1px, transparent 1px),
      radial-gradient(rgba(176,141,87,0.016) 1px, transparent 1px);
    background-size: 3px 3px, 7px 7px;
    background-position: 0 0, 1px 2px;
  }
  .video-placeholder {
    background-color: ${NAVY_DEEP};
    background-image: linear-gradient(135deg, rgba(255,255,255,0.025) 0 2px, transparent 2px 14px);
  }
  @keyframes ring-pulse { 0%{transform:scale(1);opacity:.95}50%{transform:scale(1.07);opacity:.55}100%{transform:scale(1);opacity:.95} }
  @keyframes ring-halo  { 0%{transform:scale(1);opacity:.4}50%{transform:scale(1.28);opacity:0}100%{transform:scale(1);opacity:.4} }
  @keyframes ring-jit   { 0%,100%{transform:translate(0,0)}25%{transform:translate(.4px,-.4px)}50%{transform:translate(-.3px,.3px)}75%{transform:translate(.3px,.2px)} }
  .ring-speaking .rc { animation: ring-pulse 1.3s ease-in-out infinite; }
  .ring-speaking .rh { animation: ring-halo 1.7s ease-out infinite; }
  .ring-speaking .rj { animation: ring-jit 0.18s linear infinite; }
  @keyframes wv { 0%,100%{transform:scaleY(.18)}50%{transform:scaleY(1)} }
  .wv-bar { transform-origin:center; animation: wv 1s ease-in-out infinite; }
  @keyframes lb { 0%,100%{transform:scaleY(.3)}50%{transform:scaleY(1)} }
  .lb-bar { transform-origin:bottom; animation: lb 0.9s ease-in-out infinite; }
  @keyframes blink { 0%,100%{opacity:1}50%{opacity:.35} }
  .live-dot { animation: blink 1.6s ease-in-out infinite; }
  @keyframes breathe { 0%,100%{opacity:.85}50%{opacity:1} }
  .breathe { animation: breathe 4s ease-in-out infinite; }
  @keyframes draw { from{stroke-dashoffset:60}to{stroke-dashoffset:0} }
  .draw-path { stroke-dasharray:60; stroke-dashoffset:60; animation: draw .6s ease-out forwards; }
  @keyframes circ { from{stroke-dashoffset:200}to{stroke-dashoffset:0} }
  .draw-circ { stroke-dasharray:200; stroke-dashoffset:200; animation: circ .9s ease-out forwards; }
  @keyframes pop { 0%{transform:scale(.6);opacity:0}60%{transform:scale(1.05);opacity:1}100%{transform:scale(1);opacity:1} }
  .pop-in { animation: pop .5s cubic-bezier(.2,.7,.3,1.2) forwards; }
  @keyframes capFade { from{opacity:0;transform:translateY(4px)}to{opacity:1;transform:translateY(0)} }
  .cap-fade { animation: capFade .35s ease-out both; }
  @keyframes arrow-bob { 0%,100%{transform:translateY(0)}50%{transform:translateY(7px)} }
  .arrow-bob { animation: arrow-bob 1.6s ease-in-out infinite; }
  @keyframes arrow-fade { 0%,100%{opacity:.55}50%{opacity:1} }
  .arrow-fade { animation: arrow-fade 1.6s ease-in-out infinite; }
  @keyframes label-slide { from{opacity:0;transform:translateY(-4px)}to{opacity:1;transform:translateY(0)} }
  .label-slide { animation: label-slide .35s ease-out both; }
  /* Copy-protection scoped to caption/transcript text ONLY — never on .screen-lock
     globally, because iOS Safari drops the synthesized click after touchend on
     any tappable descendant of an element with user-select:none / -webkit-touch-callout:none. */
  .no-select { user-select:none; -webkit-user-select:none; -webkit-touch-callout:none; }
  [data-protected-text="true"], [data-protected-text="true"] * {
    user-select:none; -webkit-user-select:none; -webkit-touch-callout:none;
  }
  [data-protected-text="true"]::selection, [data-protected-text="true"] *::selection { background: transparent; }
  /* iOS Safari safety net for the Begin button: ensure all <button> elements
     inside .screen-lock remain interactive even if a parent global stylesheet
     applies user-select:none / pointer-events styles that bleed onto buttons.
     Without this, a tap can be interpreted as a selection start and the
     synthesized click never fires. */
  .screen-lock button { pointer-events: auto; touch-action: manipulation; -webkit-tap-highlight-color: rgba(0,0,0,0); }
  [data-begin-button="true"] {
    pointer-events: auto !important;
    touch-action: manipulation !important;
    -webkit-user-select: none;
    user-select: none;
    -webkit-touch-callout: none;
    cursor: pointer;
  }
  [data-begin-button="true"]:disabled { cursor: wait; }
  [data-begin-button="true"] > * { pointer-events: none; }
  .scroll-thin::-webkit-scrollbar { width:6px; height:6px; }
  .scroll-thin::-webkit-scrollbar-thumb { background:rgba(26,37,71,0.18); border-radius:3px; }
  .scroll-thin::-webkit-scrollbar-track { background:transparent; }
  .btn-tap { min-height:48px; }
`;
// ============================================================
// Brand atoms
// ============================================================
function EIAWordmark({ context = "AI INTERVIEW" }: { context?: string }) {
  return (
    <div className="flex items-center gap-3 sm:gap-4 no-select">
      <span style={{ fontFamily: "'Cormorant Garamond', serif", fontWeight: 600, fontSize: 22, letterSpacing: "0.06em", color: NAVY }}>{WORDMARK}</span>
      <span className="hidden sm:inline-block h-4 w-px" style={{ background: RULE }} />
      <span className="hidden sm:inline" style={{ fontFamily: "'Cormorant Garamond', serif", fontStyle: "italic", fontWeight: 500, fontSize: 13, color: INK_60 }}>{COMPANY}</span>
      {context && (
        <>
          <span className="h-4 w-px" style={{ background: RULE }} />
          <span style={{ fontSize: 10, letterSpacing: "0.22em", color: INK_60, fontWeight: 500 }}>{context}</span>
        </>
      )}
    </div>
  );
}
function PoweredBy({ tone = "dark" }: { tone?: "dark" | "light" }) {
  const c = tone === "dark"
    ? { dot: GOLD, txt: INK_60, dim: INK_40 }
    : { dot: GOLD, txt: "rgba(250,248,243,0.72)", dim: "rgba(250,248,243,0.40)" };
  return (
    <div className="flex items-center gap-2 no-select" style={{ fontSize: 10, letterSpacing: "0.16em", color: c.txt }}>
      <span className="inline-block w-1 h-1 rounded-full" style={{ background: c.dot }} />
      <span style={{ fontWeight: 500 }}>{COMPANY_SHORT} LIVE</span>
      <span style={{ color: c.dim }}>·</span>
      <span style={{ fontFamily: "'Cormorant Garamond', serif", fontStyle: "italic", fontSize: 11, letterSpacing: "0.03em" }}>Powered by {COMPANY}</span>
    </div>
  );
}
function DebugBox(_: { lines: DebugLine[] }) {
  // Debug overlay permanently removed. Returns null so it never renders.
  return null;
}
function ChristineDisc({ speaking, size = 160, volume = 0, initial }: { speaking: boolean; size?: number; volume?: number; initial: string }) {
  const ring = size, halo = size + 26, core = Math.round(size * 0.78);
  const v = Math.min(1, Math.max(0, volume));
  const rcScale = speaking ? 1 + v * 0.08 : 1;
  const rhOp = speaking ? 0.25 + v * 0.55 : 0.2;
  return (
    <div className={"relative grid place-items-center " + (speaking ? "ring-speaking" : "")} style={{ width: ring + 50, height: ring + 50 }}>
      <span className="rh absolute rounded-full" style={{ width: halo, height: halo, opacity: rhOp, background: "radial-gradient(closest-side, rgba(176,141,87,0.38), rgba(176,141,87,0) 70%)" }} />
      <span className="rc absolute rounded-full" style={{ width: ring, height: ring, border: `1.5px solid ${GOLD}`, transform: `scale(${rcScale})`, transition: "transform 60ms linear", boxShadow: speaking ? "0 0 0 1px rgba(176,141,87,0.18), inset 0 0 0 6px rgba(176,141,87,0.06)" : "0 0 0 1px rgba(176,141,87,0.15)" }} />
      <span className="absolute rounded-full breathe" style={{ width: ring - 18, height: ring - 18, border: "1px solid rgba(176,141,87,0.30)" }} />
      <div className="rj relative rounded-full grid place-items-center" style={{ width: core, height: core, background: "radial-gradient(120% 120% at 30% 25%, #243059 0%, #1a2547 55%, #11193a 100%)", boxShadow: "inset 0 1px 0 rgba(255,255,255,0.05), 0 8px 30px rgba(15,23,48,0.25)" }}>
        <span style={{ fontFamily: "'Cormorant Garamond', serif", fontWeight: 500, fontSize: Math.round(core * 0.42), color: CREAM, letterSpacing: "0.02em" }}>{initial}</span>
        <span className="absolute" style={{ bottom: Math.round(core * 0.18), width: Math.round(core * 0.18), height: 1, background: GOLD, opacity: 0.7 }} />
      </div>
    </div>
  );
}
function VoiceWave({ active = true, color = GOLD, bars = 14 }: { active?: boolean; color?: string; bars?: number }) {
  return (
    <div className="flex items-center justify-center gap-[3px] h-5">
      {Array.from({ length: bars }).map((_, i) => {
        const mid = (bars - 1) / 2;
        const dist = Math.abs(i - mid);
        const baseH = Math.max(20, 100 - dist * 11);
        return (
          <span key={i}
            className={active ? "wv-bar" : ""}
            style={{
              width: 2, height: "100%", background: color, borderRadius: 1,
              transform: active ? undefined : `scaleY(${(baseH / 100) * 0.4})`,
              animationDelay: i * 0.06 + "s",
              animationDuration: 0.7 + dist * 0.05 + "s",
            }}
          />
        );
      })}
    </div>
  );
}
function ListeningBars({ active = true }: { active?: boolean }) {
  return (
    <div className="flex items-end gap-[3px] h-3">
      {[0, 0.12, 0.24, 0.36, 0.18, 0.06].map((d, i) => (
        <span key={i} className={active ? "lb-bar" : ""} style={{ width: 2, height: "100%", background: GOLD, animationDelay: d + "s" }} />
      ))}
    </div>
  );
}
function GreenCheckAnim({ size = 22 }: { size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 32 32" aria-hidden>
      <circle className="draw-circ" cx="16" cy="16" r="14" fill="none" stroke={SUCCESS} strokeWidth="1.5" />
      <path className="draw-path" d="M9.5 16.5 L14 21 L23 11.5" fill="none" stroke={SUCCESS} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{ animationDelay: "0.4s" }} />
    </svg>
  );
}
function NeutralCircle({ size = 22 }: { size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 32 32" aria-hidden>
      <circle cx="16" cy="16" r="14" fill="none" stroke="rgba(26,37,71,0.25)" strokeWidth="1.5" strokeDasharray="3 4" />
    </svg>
  );
}
function MicGlyph({ size = 14, tone = NAVY }: { size?: number; tone?: string }) {
  return (
    <svg width={size} height={size} viewBox="0 0 16 16" aria-hidden>
      <rect x="6" y="2" width="4" height="8" rx="2" fill="none" stroke={tone} strokeWidth="1.2" />
      <path d="M4 8 a4 4 0 0 0 8 0 M8 12 v2" fill="none" stroke={tone} strokeWidth="1.2" strokeLinecap="round" />
    </svg>
  );
}
function CamGlyph({ size = 14, tone = NAVY }: { size?: number; tone?: string }) {
  return (
    <svg width={size} height={size} viewBox="0 0 18 14" aria-hidden>
      <rect x="0.7" y="1.7" width="12" height="10.6" rx="1.5" fill="none" stroke={tone} strokeWidth="1.2" />
      <path d="M12.7 5 L17 3 V11 L12.7 9 Z" fill="none" stroke={tone} strokeWidth="1.2" strokeLinejoin="round" />
    </svg>
  );
}
function TinyCheck({ tone = SUCCESS }: { tone?: string }) {
  return (
    <svg width="14" height="14" viewBox="0 0 14 14" className="flex-none">
      <circle cx="7" cy="7" r="6" fill="none" stroke={tone} strokeOpacity="0.35" />
      <path d="M4 7.3 L6.2 9.4 L10 5.3" fill="none" stroke={tone} strokeWidth="1.4" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}
// ============================================================
// Headers & footers
// ============================================================
function HeaderEntry() {
  return (
    <header className="px-5 md:px-10 pt-5 pb-3 md:pt-6 md:pb-4 flex items-center justify-between gap-3 border-b" style={{ borderColor: RULE }}>
      <EIAWordmark />
    </header>
  );
}
function HeaderCall({ elapsed, onEnd, uploading }: { elapsed: number; onEnd: () => void; uploading: boolean }) {
  const mm = String(Math.floor(elapsed / 60)).padStart(2, "0");
  const ss = String(elapsed % 60).padStart(2, "0");
  return (
    <header className="px-4 sm:px-6 md:px-10 pt-3 pb-2 md:pt-5 md:pb-3 flex items-center justify-between gap-3 border-b" style={{ borderColor: RULE, background: CREAM }}>
      <div className="flex items-center gap-3 min-w-0">
        <span className="hidden sm:inline" style={{ fontFamily: "'Cormorant Garamond', serif", fontWeight: 600, fontSize: 22, color: NAVY, letterSpacing: "0.06em" }}>{WORDMARK}</span>
        <span className="hidden sm:inline-block h-4 w-px" style={{ background: RULE }} />
        <span className="hidden md:inline truncate" style={{ fontFamily: "'Cormorant Garamond', serif", fontStyle: "italic", fontWeight: 500, fontSize: 12.5, color: INK_60 }}>{COMPANY}</span>
      </div>
      <div className="flex items-center gap-3 sm:gap-5">
        <div className="flex items-center gap-2 no-select">
          <span style={{ fontFamily: "'JetBrains Mono', ui-monospace, monospace", fontSize: 13, color: "rgba(26,37,71,0.85)" }}>{mm}:{ss}</span>
        </div>
        <button onClick={uploading ? undefined : onEnd} disabled={uploading}
          className="btn-tap rounded-full transition px-3 sm:px-4"
          style={{ fontSize: 11, letterSpacing: "0.22em", textTransform: "uppercase", border: "1px solid rgba(26,37,71,0.3)", color: uploading ? INK_60 : NAVY, background: "transparent", cursor: uploading ? "not-allowed" : "pointer", touchAction: "manipulation", position: "relative", zIndex: 5 }}>
          {uploading ? "Saving…" : "End Interview"}
        </button>
      </div>
    </header>
  );
}
function Footer() {
  return (
    <footer className="px-5 md:px-10 py-4 md:py-5 border-t flex flex-wrap items-center justify-between gap-3" style={{ borderColor: RULE }}>
      <span className="no-select" style={{ fontSize: 11, letterSpacing: "0.18em", color: INK_60 }}>© {YEAR} {COMPANY}</span>
      <PoweredBy tone="dark" />
      <span className="hidden sm:inline no-select" style={{ fontSize: 11, letterSpacing: "0.18em", color: INK_60 }}>PRIVACY · SUPPORT</span>
    </footer>
  );
}
// ============================================================
// Entry screen — Camera test card
// ============================================================
const makeRulesAll = (interviewerName: string): React.ReactNode[] => [
  <>Conducted by <span style={{ color: NAVY, fontWeight: 500 }}>{interviewerName}</span>, our AI interviewer — treat it like a real interview.</>,
  <>This session is <span style={{ color: NAVY, fontWeight: 500 }}>recorded</span>; a real person reviews every interview.</>,
  <>Your video must remain <span style={{ color: NAVY, fontWeight: 500 }}>on</span> to continue — company requirement.</>,
  <>Answer naturally — <span style={{ color: NAVY, fontWeight: 500 }}>{interviewerName}</span> listens and follows up; trolling or long silences will end the interview.</>,
];
function CameraTestCard({
  ready, requesting, error, micLevel, hasVideo, videoRef, checkingStage,
  micReady, micNoSignalHint, audioInputs, selectedMicId, onMicChange,
}: {
  ready: boolean; requesting: boolean; error: string | null; micLevel: number; hasVideo: boolean;
  videoRef: React.RefObject<HTMLVideoElement>;
  checkingStage?: CheckStage;
  micReady: boolean;
  micNoSignalHint: boolean;
  audioInputs: { deviceId: string; label: string }[];
  selectedMicId: string | undefined;
  onMicChange: (deviceId: string) => void;
}) {
  const ringStyle = (active: boolean): React.CSSProperties =>
    active
      ? { boxShadow: `0 0 0 2px ${GOLD}`, borderColor: GOLD }
      : {};
  const camChecking = checkingStage === "camera";
  const micChecking = checkingStage === "mic";
  const camReady = ready;
  const micTileMsg = micReady
    ? "Microphone Ready"
    : (micChecking ? "Testing microphone…" : (ready ? "Please say HELLO out loud now" : "Not enabled"));
  return (
    <div className="w-full">
      <div className="relative rounded-[14px] overflow-hidden video-placeholder aspect-video mx-auto" style={{ border: "1px solid rgba(26,37,71,0.15)", boxShadow: "0 14px 36px rgba(15,23,48,0.14)", maxHeight: "min(34vh, 260px)" }}>
        {!hasVideo && (
          <div className="absolute inset-0 grid place-items-center p-5 text-center" style={{ color: "rgba(250,248,243,0.85)" }}>
            <div className="max-w-[80%]">
              <div style={{ fontFamily: "'Cormorant Garamond', serif", fontStyle: "italic", fontSize: 14, color: "rgba(250,248,243,0.7)", marginBottom: 8 }}>camera preview</div>
              {!requesting && !error && <p style={{ fontSize: 12.5, color: "rgba(250,248,243,0.65)", lineHeight: 1.55 }}>Tap the button below to enable your camera and microphone.</p>}
              {requesting && checkingStage && (
                <p style={{ fontSize: 13, color: "rgba(250,248,243,0.8)" }}>
                  {checkingStage === "mic" ? "Testing microphone…" : "Testing camera…"}
                </p>
              )}
              {requesting && !checkingStage && <p style={{ fontSize: 13, color: "rgba(250,248,243,0.7)" }}>Requesting permission…</p>}
              {error === "denied" && <p style={{ fontSize: 13, color: "rgba(250,248,243,0.8)" }}>Camera was blocked. Open your browser permissions and allow camera + microphone, then try again.</p>}
              {error === "nodevice" && <p style={{ fontSize: 13, color: "rgba(250,248,243,0.8)" }}>No camera detected. Plug one in or enable it, then try again.</p>}
            </div>
          </div>
        )}
        <video ref={videoRef} playsInline muted autoPlay className="w-full h-full" style={{ objectFit: "cover", transform: "scaleX(-1)", opacity: hasVideo ? 1 : 0, transition: "opacity 200ms ease" }} />
        <div className="absolute top-3 left-3 flex items-center gap-2">
          <span className={hasVideo ? "live-dot inline-block" : "inline-block"} style={{ width: 6, height: 6, borderRadius: 999, background: hasVideo ? LIVE : "rgba(250,248,243,0.3)" }} />
          <span className="no-select" style={{ fontSize: 10, letterSpacing: "0.22em", color: "rgba(250,248,243,0.85)" }}>{hasVideo ? "PREVIEW · LIVE" : "PREVIEW"}</span>
        </div>
        <div className="absolute bottom-3 left-3 no-select" style={{ fontSize: 10, letterSpacing: "0.22em", color: "rgba(250,248,243,0.7)" }}>YOU</div>
      </div>
      {/* Status row */}
      <div className="mt-2.5 grid grid-cols-2 gap-2">
        <div className="rounded-[10px] border px-2.5 py-1.5 flex items-center gap-2 transition" style={{ borderColor: camReady ? "rgba(47,109,79,0.3)" : RULE, background: camReady ? "rgba(47,109,79,0.05)" : "rgba(243,238,226,0.4)", ...ringStyle(camChecking) }}>
          <CamGlyph tone={camReady ? SUCCESS : NAVY} />
          <div className="min-w-0 flex-1">
            <div style={{ fontSize: 9, letterSpacing: "0.18em", color: INK_60, lineHeight: 1 }}>CAMERA</div>
            <div style={{ fontSize: 11.5, lineHeight: 1.2, marginTop: 2, color: camReady ? SUCCESS : "rgba(26,37,71,0.7)", fontWeight: camReady ? 500 : 400 }}>{camReady ? "Ready" : (camChecking ? "Testing camera…" : "Not enabled")}</div>
          </div>
          <div className="ml-1">{camReady ? <span className="pop-in inline-block"><GreenCheckAnim size={18} /></span> : <NeutralCircle size={18} />}</div>
        </div>
        <div className="rounded-[10px] border px-2.5 py-1.5 flex items-center gap-2 transition" style={{ borderColor: micReady ? "rgba(47,109,79,0.3)" : (ready ? "rgba(226,68,92,0.35)" : RULE), background: micReady ? "rgba(47,109,79,0.05)" : (ready ? "rgba(226,68,92,0.06)" : "rgba(243,238,226,0.4)"), ...ringStyle(micChecking) }}>
          <MicGlyph tone={micReady ? SUCCESS : (ready && !micChecking ? DANGER : NAVY)} />
          <div className="min-w-0 flex-1">
            <div style={{ fontSize: 9, letterSpacing: "0.18em", color: INK_60, lineHeight: 1 }}>MICROPHONE</div>
            <div style={{ fontSize: 11.5, lineHeight: 1.2, marginTop: 2, color: micReady ? SUCCESS : (ready && !micChecking ? DANGER : "rgba(26,37,71,0.7)"), fontWeight: micReady || (ready && !micChecking) ? 600 : 400 }}>{micTileMsg}</div>
            {ready && (
              <div className="mt-1 flex items-center gap-[1.5px] h-1">
                {Array.from({ length: 14 }).map((_, i) => {
                  const lit = micLevel >= (i + 1) / 14 - 0.04;
                  const peak = i >= 11;
                  return <span key={i} className="flex-1 h-full rounded-[1px]" style={{ background: lit ? (peak ? GOLD : NAVY) : RULE }} />;
                })}
              </div>
            )}
          </div>
          <div className="ml-1">{micReady ? <span className="pop-in inline-block"><GreenCheckAnim size={18} /></span> : <NeutralCircle size={18} />}</div>
        </div>
      </div>
      {/* Mic picker + helper text — only after camera is granted */}
      {ready && (
        <div className="mt-2.5">
          <p className="text-center" style={{ fontSize: 12, color: micReady ? SUCCESS : DANGER, lineHeight: 1.4, fontWeight: 600 }}>
            {micReady
              ? "Great — we can hear you."
              : "Please say HELLO out loud so we can hear your microphone."}
          </p>
          {audioInputs.length > 0 && (
            <div className="mt-2 flex flex-col items-center gap-1">
              <label style={{ fontSize: 10, letterSpacing: "0.22em", color: INK_60 }} htmlFor="mic-picker">MICROPHONE INPUT</label>
              <select
                id="mic-picker"
                value={selectedMicId ?? ""}
                onChange={(e) => onMicChange(e.target.value)}
                className="rounded-md border w-full max-w-[360px]"
                style={{
                  minHeight: 44,
                  padding: "8px 12px",
                  fontSize: 13,
                  background: CREAM,
                  borderColor: RULE,
                  color: NAVY,
                  touchAction: "manipulation",
                }}
              >
                {audioInputs.map((d) => (
                  <option key={d.deviceId || "default"} value={d.deviceId}>{d.label || "Microphone"}</option>
                ))}
              </select>
            </div>
          )}
          {micNoSignalHint && !micReady && (
            <p className="mt-2 text-center" style={{ fontSize: 12.5, color: DANGER, lineHeight: 1.45, fontWeight: 700 }}>
              We still can't hear you. Please SAY HELLO out loud. If it still doesn't work, make sure your microphone isn't muted, or pick a different microphone above.
            </p>
          )}
        </div>
      )}
      {ready && micReady && (
        <div className="pop-in mt-2.5 flex items-center justify-center gap-2 py-1.5">
          <GreenCheckAnim size={16} />
          <span style={{ fontSize: 12, color: SUCCESS, fontWeight: 500, letterSpacing: "0.02em" }}>Camera &amp; Mic Ready</span>
        </div>
      )}
    </div>
  );
}
function GuidanceArrow({ ready }: { ready: boolean }) {
  return (
    <div className="flex flex-col items-center pointer-events-none no-select" aria-hidden>
      <span key={ready ? "ready" : "start"} className="label-slide mb-1" style={{ fontFamily: "'Cormorant Garamond', serif", fontStyle: "italic", fontWeight: 500, fontSize: 13, color: ready ? SUCCESS : GOLD, letterSpacing: "0.01em" }}>
        {ready ? "You're ready — click to begin" : "Start here"}
      </span>
      <div className="arrow-bob arrow-fade">
        <svg width="22" height="30" viewBox="0 0 22 30" fill="none">
          <path d="M11 2 V22" stroke={ready ? SUCCESS : GOLD} strokeWidth="1.6" strokeLinecap="round" />
          <path d="M4 18 L11 26 L18 18" stroke={ready ? SUCCESS : GOLD} strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" fill="none" />
        </svg>
      </div>
    </div>
  );
}
// ============================================================
// In-call: Candidate video + Christine video + Caption feed
// ============================================================
function CandidateVideo({ videoRef, hasStream, compact = false }: { videoRef: React.RefObject<HTMLVideoElement>; hasStream: boolean; compact?: boolean }) {
  return (
    <div className="relative w-full h-full rounded-[14px] sm:rounded-[18px] overflow-hidden video-placeholder" style={{ border: "1px solid rgba(26,37,71,0.15)", boxShadow: "0 14px 40px rgba(15,23,48,0.16)" }}>
      <video ref={videoRef} playsInline muted autoPlay className="w-full h-full" style={{ objectFit: "cover", transform: "scaleX(-1)", opacity: hasStream ? 1 : 0, transition: "opacity 200ms ease" }} />
      {!hasStream && (
        <div className="absolute inset-0 grid place-items-center p-4 text-center" style={{ color: "rgba(250,248,243,0.75)" }}>
          <div className="max-w-[80%]">
            <div style={{ fontFamily: "'Cormorant Garamond', serif", fontStyle: "italic", fontSize: 16, color: "rgba(250,248,243,0.7)", marginBottom: 4 }}>your camera</div>
            <p style={{ fontSize: 12.5, color: "rgba(250,248,243,0.6)", lineHeight: 1.55 }}>Allow camera access — your video must remain on.</p>
          </div>
        </div>
      )}
      <div className="absolute top-2.5 left-2.5 sm:top-3 sm:left-3 flex items-center gap-1.5 no-select">
        <span className="inline-block w-1.5 h-1.5 rounded-full live-dot" style={{ background: LIVE }} />
        <span style={{ fontSize: 10, letterSpacing: "0.22em", color: "rgba(250,248,243,0.85)" }}>YOU</span>
      </div>
      {!compact && (
        <div className="hidden sm:block absolute bottom-2.5 left-2.5 sm:bottom-3 sm:left-3 no-select">
          <div style={{ fontFamily: "'Cormorant Garamond', serif", fontWeight: 500, fontSize: 16, color: CREAM }}>Candidate</div>
          <div style={{ color: "rgba(250,248,243,0.6)", fontSize: 10.5 }}>{COMPANY_SHORT} Interview</div>
        </div>
      )}
      <div className="absolute bottom-2.5 right-2.5 sm:bottom-3 sm:right-3">
        <PoweredBy tone="light" />
      </div>
    </div>
  );
}
function CaptionFeed({ transcript, interviewerName, tone = "dark" }: { transcript: Line[]; interviewerName: string; tone?: "dark" | "light" }) {
  const ref = useRef<HTMLDivElement | null>(null);
  const stickRef = useRef(true);
  const onScroll = () => {
    const el = ref.current; if (!el) return;
    const nearBottom = el.scrollHeight - el.scrollTop - el.clientHeight < 24;
    stickRef.current = nearBottom;
  };
  useEffect(() => {
    const el = ref.current; if (!el) return;
    if (stickRef.current) el.scrollTop = el.scrollHeight;
  }, [transcript]);
  const isDark = tone === "dark";
  return (
    <div className="flex flex-col h-full min-h-0" data-protected-text="true" style={{ userSelect: "none", WebkitUserSelect: "none" } as React.CSSProperties}>
      <div className={"px-3 py-1.5 flex items-center justify-between shrink-0 " + (isDark ? "" : "border-b")} style={isDark ? undefined : { borderColor: RULE, background: "rgba(243,238,226,0.4)" }}>
        <div className="flex items-center gap-1.5 no-select">
          <span className="inline-block w-1 h-1 rounded-full live-dot" style={{ background: LIVE }} />
          <span style={{ fontSize: 9, letterSpacing: "0.24em", fontWeight: 500, color: isDark ? "rgba(250,248,243,0.65)" : NAVY }}>LIVE CAPTIONS</span>
        </div>
        <span className="no-select" style={{ fontSize: 9, letterSpacing: "0.20em", color: isDark ? "rgba(250,248,243,0.35)" : INK_40 }}>auto-scroll</span>
      </div>
      <div ref={ref} onScroll={onScroll} className="px-3 pt-1.5 pb-2.5 scroll-thin overflow-y-auto flex-1 min-h-0" style={{ overscrollBehavior: "contain" }}>
        {transcript.length === 0 && (
          <div className="py-1" style={{ fontSize: 11, fontStyle: "italic", color: isDark ? "rgba(250,248,243,0.4)" : INK_40 }}>connecting…</div>
        )}
        <ul className="flex flex-col gap-2">
          {transcript.map((l, i) => {
            const isAgent = l.who === "agent";
            return (
              <li key={i} className="grid items-start" style={{ gridTemplateColumns: "72px 1fr", columnGap: 14, lineHeight: 1.45 }}>
                <span className="no-select truncate" style={{ fontSize: 8.5, letterSpacing: "0.22em", marginTop: 3, fontWeight: 500, color: isAgent ? GOLD : (isDark ? "rgba(250,248,243,0.55)" : "rgba(26,37,71,0.55)") }}>
                  {isAgent ? interviewerName.toUpperCase() : "YOU"}
                </span>
                <span className="min-w-0 break-words" style={{ fontSize: 12.5, color: isDark ? "rgba(250,248,243,0.85)" : "rgba(26,37,71,0.9)", wordBreak: "break-word" }}>
                  {l.text}
                </span>
              </li>
            );
          })}
        </ul>
      </div>
    </div>
  );
}
function ChristineVideo({ speaking, volume, transcript, interviewer }: { speaking: boolean; volume: number; transcript: Line[]; interviewer: InterviewerProfile }) {
  return (
    <div className="relative w-full h-full rounded-[14px] sm:rounded-[18px] overflow-hidden flex flex-col" style={{ background: NAVY_DEEP, border: "1px solid rgba(26,37,71,0.4)", boxShadow: "0 14px 40px rgba(15,23,48,0.16)" }}>
      <div className="absolute inset-0 pointer-events-none" style={{ opacity: 0.05, backgroundImage: "linear-gradient(135deg, rgba(255,255,255,0.4) 0 1px, transparent 1px 22px)" }} />
      <div className="relative flex-1 flex flex-col items-center justify-center px-4 py-3 min-h-0">
        <div className="absolute top-2.5 left-2.5 sm:top-3 sm:left-3 flex items-center gap-1.5">
          <span className="inline-block w-1.5 h-1.5 rounded-full" style={{ background: speaking ? GOLD : "rgba(250,248,243,0.3)" }} />
          <span className="no-select" style={{ fontSize: 10, letterSpacing: "0.22em", color: "rgba(250,248,243,0.85)" }}>{interviewer.name.toUpperCase()} · AI</span>
        </div>
        <div className="absolute top-2.5 right-2.5 sm:top-3 sm:right-3 flex items-center gap-1.5">
          <span className="no-select" style={{ fontSize: 10, letterSpacing: "0.20em", color: "rgba(250,248,243,0.55)" }}>{speaking ? "SPEAKING" : "LISTENING"}</span>
          {!speaking && <ListeningBars />}
        </div>
        <ChristineDisc speaking={speaking} size={130} volume={volume} initial={interviewer.initial} />
        <div className="text-center mt-1">
          <div style={{ fontFamily: "'Cormorant Garamond', serif", fontWeight: 500, fontSize: 18, color: CREAM }}>
            {interviewer.name} <span style={{ color: "rgba(250,248,243,0.55)", fontSize: 10.5, letterSpacing: "0.12em", verticalAlign: "middle", fontFamily: "'Inter', sans-serif" }}>(AI)</span>
          </div>
          <div style={{ color: "rgba(250,248,243,0.6)", fontSize: 10.5, marginTop: 2 }}>{interviewer.title}</div>
        </div>
        <div className="mt-1.5 w-full max-w-[180px]">
          {speaking
            ? <VoiceWave active color={GOLD_SOFT} bars={14} />
            : <div className="h-5 grid place-items-center"><span className="block h-px w-12" style={{ background: "rgba(250,248,243,0.15)" }} /></div>}
        </div>
      </div>
      {/* Embedded caption strip — fixed height, scrolls internally */}
      <div className="relative shrink-0 flex flex-col" style={{ background: "rgba(17,25,58,0.35)", borderTop: "1px solid rgba(250,248,243,0.12)", height: "clamp(110px, 30%, 180px)" }}>
        <CaptionFeed transcript={transcript} interviewerName={interviewer.name} tone="dark" />
      </div>
    </div>
  );
}
// ============================================================
// PAGE
// ============================================================
export default function AiInterview() {
  const { token } = useParams<{ token: string }>();
  usePageSeo({
    title: "AI Interview — EIA Talent Recruiting",
    description: "Complete your live AI-guided interview with Expert Intuitive Advisor Inc. Check your camera and microphone, then begin when ready.",
    path: token ? `/ai-interview/${token}` : undefined,
  });
  const [status, setStatus] = useState<Status>("idle");
  const statusRef = useRef<Status>("idle");
  const [errorMsg, setErrorMsg] = useState<string>("");
  const [christineSpeaking, setChristineSpeaking] = useState(false);
  const [transcript, setTranscript] = useState<Line[]>([]);
  const [previewReady, setPreviewReady] = useState(false);
  // Pre-flight camera FRAME-liveness warning (display-only). True when the probe
  // reads the EXISTING preview stream and finds no actual frames flowing (dead
  // track case). NEVER blocks Begin — warn-only, the zero-chunk watchdog is the
  // real backstop. Acquires NOTHING new; reads camStreamRef + videoPreviewRef.
  const [frameWarn, setFrameWarn] = useState(false);
  const frameProbeRunningRef = useRef(false);
  const [prefetchReady, setPrefetchReady] = useState(false);
  // PART 1 (two-phase commit) — true while the FIRST Begin tap is minting the
  // Retell call (a plain network fetch). Disables the button + shows "Preparing…"
  // until prefetchReady flips true, then the SECOND tap runs handleStart().
  const [minting, setMinting] = useState(false);
  // PART 1 — safety: flips true when a BACKGROUND re-check finds the rebook
  // token has been invalidated / expired / used while the candidate is idle on
  // the entry/camera screen. Disables Begin and drops the cached Retell call.
  // Never consulted inside the Begin gesture path (iOS-safe start preserved).
  const [linkInvalid, setLinkInvalid] = useState(false);
  // PART 2 — 72-hour completion messaging (front-end only, read-only).
  // deadlineAt = invite-sent + 72h. Source: rebook_tokens.expires_at returned by
  // validate-rebook-token (token is issued at invite-send time with a 72h / 3-day
  // window, so expires_at IS the sent+72h deadline). Informational only — it never
  // blocks Begin; real expiry/gating stays in the edge functions, untouched.
  const [deadlineAt, setDeadlineAt] = useState<Date | null>(null);
  const [tokenStage, setTokenStage] = useState<string | null>(token === "permanent-test" ? "permanent-test" : null);
  const [nowTick, setNowTick] = useState<number>(() => Date.now());
  const [wizardStep, setWizardStep] = useState<1 | 2 | 3 | 4>(1);
  // Phase 3.3 — tracking link shown on Thank-You screen (fetched after end).
  const [trackingToken, setTrackingToken] = useState<string | null>(null);
  const [trackingCopied, setTrackingCopied] = useState(false);
  const [christineVolume, setChristineVolume] = useState(0);
  const volumeRafRef = useRef<number | null>(null);
  // Entry-screen mic meter (real audio analyser on candidate's mic).
  const [micLevel, setMicLevel] = useState(0);
  const micAudioCtxRef = useRef<AudioContext | null>(null);
  const micRafRef = useRef<number | null>(null);
  const micSourceRef = useRef<MediaStreamAudioSourceNode | null>(null);
  const micAnalyserRef = useRef<AnalyserNode | null>(null);
  // Mic SIGNAL gate (separate from permission) — true once real audio detected.
  const [micSignalOk, setMicSignalOk] = useState(false);
  const [micNoSignalHint, setMicNoSignalHint] = useState(false);
  const micSignalOkRef = useRef(false);
  const micAboveSinceRef = useRef<number | null>(null);
  const micNoSignalTimerRef = useRef<number | null>(null);
  // Short-lived probe stream JUST for the level meter (separate from camStreamRef).
  const micProbeStreamRef = useRef<MediaStream | null>(null);
  // Audio device picker.
  const [audioInputs, setAudioInputs] = useState<{ deviceId: string; label: string }[]>([]);
  const [selectedMicId, setSelectedMicId] = useState<string | undefined>(undefined);
  // Joined-but-silent watchdog (separate from connect_timeout).
  const silentMicTimerRef = useRef<number | null>(null);
  // Guard so onTouchEnd + onClick + onPointerUp can't double/triple-fire handleStart on iOS.
  const startingRef = useRef<boolean>(false);
  const clientRef = useRef<RetellWebClient | null>(null);
  const videoPreviewRef = useRef<HTMLVideoElement | null>(null);
  const videoInCallRef = useRef<HTMLVideoElement | null>(null);
  const camStreamRef = useRef<MediaStream | null>(null);
  const recorderRef = useRef<MediaRecorder | null>(null);
  const chunksRef = useRef<Blob[]>([]);
  // Pattern A live-part streaming: index of the next part to upload, and a count
  // of parts that uploaded successfully (used to decide concat-vs-single-blob).
  const partIndexRef = useRef<number>(0);
  const uploadedPartsRef = useRef<number>(0);
  // Zero-chunk video-loss detection: counts non-empty chunks seen, a one-shot
  // watchdog timer, and a per-stage dedupe set for video failure logging.
  const chunksSeenRef = useRef<number>(0);
  const zeroChunkTimerRef = useRef<number | null>(null);
  const videoFailureStagesRef = useRef<Set<string>>(new Set());
  const callIdRef = useRef<string | null>(null);
  // Fire-once guard so pagehide + visibilitychange-hidden don't double-trigger the
  // close-time finalize/reap beacon.
  const closeFinalizeFiredRef = useRef<boolean>(false);
  const uploadedRef = useRef<boolean>(false);
  const startedAtRef = useRef<number | null>(null);
  const [durationSec, setDurationSec] = useState<number>(0);
  const [permRequesting, setPermRequesting] = useState(false);
  const [permError, setPermError] = useState<string | null>(null);
  const [debugLines, setDebugLines] = useState<DebugLine[]>([]);
  // UI-only: which device the static ring is currently sitting on during the
  // permission check ("mic" | "camera" | null). Does NOT drive the underlying
  // getUserMedia order — purely visual feedback.
  const [checkingStage, setCheckingStage] = useState<CheckStage>(null);
  // Permission-blocked full-screen recovery flag. Set when NotAllowedError /
  // NotAllowed permission errors occur. Cleared on reload or when granted.
  const [permBlocked, setPermBlocked] = useState(false);
  const debugSeqRef = useRef(0);
  const beginBtnRef = useRef<HTMLButtonElement | null>(null);
  const addDebug = (label: string, value?: unknown) => {
    const text = typeof value === "undefined" ? label : `${label}: ${formatDebugValue(value)}`;
    setDebugLines((lines) => [...lines.slice(-24), { id: ++debugSeqRef.current, text }]);
  };
  const interviewer = useMemo(() => getInterviewerForStage(tokenStage), [tokenStage]);
  const rulesAll = useMemo(() => makeRulesAll(interviewer.name), [interviewer.name]);
  // iOS audio-unlock context (created+resumed inside Begin tap, before any await)
  const unlockedAudioCtxRef = useRef<AudioContext | null>(null);
  const getUnlockedAudioState = () => unlockedAudioCtxRef.current?.state || "none";
  const isAudioContextLike = (value: unknown): value is AudioContext => {
    return !!value && typeof (value as AudioContext).resume === "function" && typeof (value as AudioContext).state === "string";
  };
  const collectRetellAudioContexts = (client: RetellWebClient): AudioContext[] => {
    const anyClient = client as any;
    const candidates = [
      anyClient?.room?.audioContext,
      anyClient?.room?.localParticipant?.audioContext,
      anyClient?.analyzerComponent?.analyser?.context,
    ].filter(isAudioContextLike);
    return Array.from(new Set(candidates.filter(isAudioContextLike)));
  };
  const describeAudioContexts = (contexts: AudioContext[]) => {
    return contexts.length ? contexts.map((ctx, i) => `${i + 1}:${ctx.state}`).join(", ") : "none";
  };
  const resumeRetellAudioContexts = (client: RetellWebClient, phase: string) => {
    const before = collectRetellAudioContexts(client);
    addDebug(`Retell internal AC found (${phase})`, before.length > 0 ? "yes" : "no");
    addDebug(`Retell internal AC state before resume (${phase})`, describeAudioContexts(before));
    try {
      const startAudioPlayback = (client as any).startAudioPlayback;
      if (typeof startAudioPlayback === "function") {
        void startAudioPlayback.call(client).catch((e: unknown) => addDebug(`Retell startAudioPlayback failed (${phase})`, e));
        addDebug(`Retell startAudioPlayback called (${phase})`);
      } else {
        addDebug(`Retell startAudioPlayback exposed (${phase})`, "no");
      }
    } catch (e) {
      addDebug(`Retell startAudioPlayback threw (${phase})`, e);
    }
    const afterExpose = collectRetellAudioContexts(client);
    for (const ctx of afterExpose) {
      if (ctx.state === "suspended") void ctx.resume().catch((e) => addDebug(`Retell internal AC resume failed (${phase})`, e));
    }
    if (unlockedAudioCtxRef.current?.state === "suspended") {
      void unlockedAudioCtxRef.current.resume().catch((e) => addDebug(`unlocked AC resume after startCall failed (${phase})`, e));
    }
    addDebug(`Retell internal AC found after startAudioPlayback (${phase})`, afterExpose.length > 0 ? "yes" : "no");
    addDebug(`Retell internal AC state after resume requested (${phase})`, describeAudioContexts(afterExpose));
    window.setTimeout(() => {
      addDebug(`Retell internal AC state after resume settle (${phase})`, describeAudioContexts(collectRetellAudioContexts(client)));
      addDebug(`Unlocked AudioContext after resume settle (${phase})`, getUnlockedAudioState());
    }, 250);
  };
  // Pre-fetched create-ai-web-call result so Begin tap has zero awaits before startCall
  const prefetchedCallRef = useRef<{ access_token: string; call_id: string } | null>(null);
  const prefetchPromiseRef = useRef<Promise<{ access_token: string; call_id: string } | null> | null>(null);
  const prefetchRetryTimerRef = useRef<number | null>(null);
  // Connect-timeout safety net (15s). Cleared on call_started / error / unmount.
  const connectTimeoutRef = useRef<number | null>(null);
  const failureLoggedRef = useRef<boolean>(false);
  const clearConnectTimeout = () => {
    if (connectTimeoutRef.current != null) {
      window.clearTimeout(connectTimeoutRef.current);
      connectTimeoutRef.current = null;
    }
  };
  const parseDeviceType = (ua: string): string => {
    if (/iPhone|iPad|iPod/i.test(ua)) return "iOS";
    if (/Android/i.test(ua)) return "Android";
    if (/Windows/i.test(ua)) return "Windows";
    if (/Mac/i.test(ua)) return "Mac";
    return "Other";
  };
  const logFailure = (stage: string, retellError: unknown = null) => {
    if (failureLoggedRef.current) return;
    failureLoggedRef.current = true;
    const payload = {
      token,
      device_type: parseDeviceType(navigator.userAgent),
      user_agent: navigator.userAgent,
      failure_stage: stage,
      audio_context_state: getUnlockedAudioState(),
      retell_error: retellError == null ? null : formatDebugValue(retellError),
    };
    addDebug("logFailure", { stage, device: payload.device_type });
    try {
      void supabase.functions.invoke("log-ai-interview-failure", { body: payload });
    } catch (e) {
      addDebug("logFailure invoke threw", e);
    }
  };
  // Video-recording failures (zero chunks / empty blob / dead camera track) are
  // INDEPENDENT of the Retell connection failures logged via logFailure(): the
  // audio interview is usually still succeeding, so they must NOT be suppressed
  // by failureLoggedRef. Same table / same edge function / same payload shape as
  // logFailure() above — only the dedupe differs (per-stage instead of one-shot),
  // and retell_error is always null (these are recorder-side, not Retell-side).
  const logVideoFailure = (stage: string) => {
    if (videoFailureStagesRef.current.has(stage)) return;
    videoFailureStagesRef.current.add(stage);
    const payload = {
      token,
      device_type: parseDeviceType(navigator.userAgent),
      user_agent: navigator.userAgent,
      failure_stage: stage,
      audio_context_state: getUnlockedAudioState(),
      retell_error: null,
    };
    addDebug("logVideoFailure", { stage, device: payload.device_type });
    try {
      void supabase.functions.invoke("log-ai-interview-failure", { body: payload });
    } catch (e) {
      addDebug("logVideoFailure invoke threw", e);
    }
  };
  // (Mobile rules popup removed — replaced by the 3-step wizard.)
  // Cleanup on unmount
  useEffect(() => {
    return () => {
      clearConnectTimeout();
      if (prefetchRetryTimerRef.current != null) window.clearTimeout(prefetchRetryTimerRef.current);
      if (silentMicTimerRef.current != null) window.clearTimeout(silentMicTimerRef.current);
      if (micNoSignalTimerRef.current != null) window.clearTimeout(micNoSignalTimerRef.current);
      if (zeroChunkTimerRef.current != null) window.clearTimeout(zeroChunkTimerRef.current);
      try { clientRef.current?.stopCall(); } catch { /* noop */ }
      try { micProbeStreamRef.current?.getTracks().forEach((t) => t.stop()); } catch { /* noop */ }
      stopCameraTracks();
      if (micRafRef.current) cancelAnimationFrame(micRafRef.current);
      if (micAudioCtxRef.current) micAudioCtxRef.current.close().catch(() => {});
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);
  useEffect(() => {
    statusRef.current = status;
  }, [status]);
  // iOS viewport-height fallback
  useEffect(() => {
    const setVh = () => document.documentElement.style.setProperty("--app-vh", `${window.innerHeight}px`);
    setVh();
    window.addEventListener("resize", setVh);
    window.addEventListener("orientationchange", setVh);
    return () => {
      window.removeEventListener("resize", setVh);
      window.removeEventListener("orientationchange", setVh);
    };
  }, []);
  // Phase 3.3 — once the interview has ended, fetch the candidate's tracking
  // token (minted by the Retell webhook). Polls briefly to ride out the
  // webhook delay; gracefully gives up so the Thank-You screen still renders.
  useEffect(() => {
    if (status !== "ended" || !token || trackingToken) return;
    let cancelled = false;
    let attempts = 0;
    const tick = async () => {
      attempts++;
      try {
        const { data } = await supabase.functions.invoke<{ token: string | null }>(
          "get-tracking-link",
          { body: { interview_token: token } },
        );
        if (!cancelled && data?.token) { setTrackingToken(data.token); return; }
      } catch { /* swallow */ }
      if (!cancelled && attempts < 8) window.setTimeout(tick, 4000);
    };
    tick();
    return () => { cancelled = true; };
  }, [status, token, trackingToken]);
  // ============================================================
  // iOS viewport lock — prevents the URL/search bar + keyboard
  // accessory from popping during taps near the top of the page.
  //
  // Without `maximum-scale=1, user-scalable=no, viewport-fit=cover`,
  // iOS Safari permits double-tap-to-zoom on the page. While the
  // page is in zoomed/zoomable state, iOS treats taps near the top
  // as gestures that can promote the address bar (which carries the
  // search keyboard) into view, covering the popup's "I Understand"
  // button. Locking the viewport eliminates that gesture path.
  //
  // Scoped to this route only — the meta tag is reverted on unmount
  // so other pages keep their own viewport setting.
  // ============================================================
  useEffect(() => {
    const head = document.head;
    if (!head) return;
    let meta = head.querySelector('meta[name="viewport"]') as HTMLMetaElement | null;
    const created = !meta;
    const original = meta?.getAttribute("content") ?? null;
    if (!meta) {
      meta = document.createElement("meta");
      meta.setAttribute("name", "viewport");
      head.appendChild(meta);
    }
    meta.setAttribute(
      "content",
      "width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no, viewport-fit=cover",
    );
    return () => {
      if (!meta) return;
      if (created) {
        try { head.removeChild(meta); } catch { /* noop */ }
      } else if (original != null) {
        meta.setAttribute("content", original);
      }
    };
  }, []);
  // Voice-reactive meter for Christine (real audio amplitude via Retell SDK)
  useEffect(() => {
    if (status !== "live") {
      setChristineVolume(0);
      if (volumeRafRef.current) cancelAnimationFrame(volumeRafRef.current);
      volumeRafRef.current = null;
      return;
    }
    let smoothed = 0;
    const tick = () => {
      const client = clientRef.current as any;
      let v = 0;
      try {
        if (client?.analyzerComponent?.calculateVolume) {
          v = Number(client.analyzerComponent.calculateVolume()) || 0;
        }
      } catch { /* noop */ }
      v = Math.min(1, Math.max(0, v));
      const boosted = Math.min(1, v * 2.2);
      smoothed = smoothed * 0.55 + boosted * 0.45;
      setChristineVolume(smoothed);
      volumeRafRef.current = requestAnimationFrame(tick);
    };
    volumeRafRef.current = requestAnimationFrame(tick);
    return () => {
      if (volumeRafRef.current) cancelAnimationFrame(volumeRafRef.current);
      volumeRafRef.current = null;
    };
  }, [status]);
  // ============================================================
  // (FIX BUG 1) Copy/paste/contextmenu/keyboard-shortcut block —
  // SCOPED TO CAPTION/TRANSCRIPT TEXT ONLY, AND with `selectstart` REMOVED
  // from the document level entirely.
  //
  // Root cause of the dead Begin button on iOS Safari:
  // Previously this effect attached `selectstart` at the document level
  // with a guarded preventDefault. Even though the guard only fired for
  // [data-protected-text="true"] targets, iOS Safari fires `selectstart`
  // on every tap (including on <button>) and inspects the event before
  // synthesizing the click. Having ANY document-level `selectstart`
  // listener — guarded or not — causes iOS to treat the tap as a
  // potential text-selection gesture and silently suppress the
  // synthesized click on the underlying <button>. The result was that
  // onClick (and the bubbled-up click event) never fired even though the
  // button was visually enabled and on top of the stack.
  //
  // Selection prevention inside the caption is handled entirely by CSS
  // (`[data-protected-text="true"] { user-select: none; -webkit-user-select: none; -webkit-touch-callout: none }`)
  // so removing the JS `selectstart` handler does not regress the
  // copy-protection requirement on the live caption.
  // ============================================================
  useEffect(() => {
    const isEditable = (t: EventTarget | null): boolean => {
      const el = t as HTMLElement | null;
      if (!el || !el.tagName) return false;
      const tag = el.tagName.toUpperCase();
      if (tag === "INPUT" || tag === "TEXTAREA" || tag === "SELECT") return true;
      if (el.isContentEditable) return true;
      return false;
    };
    const isProtectedText = (t: EventTarget | null): boolean => {
      const el = t as HTMLElement | null;
      return !!el?.closest?.('[data-protected-text="true"]');
    };
    const block = (e: Event) => {
      if (isEditable(e.target)) return;
      if (isProtectedText(e.target)) e.preventDefault();
    };
    const keyBlock = (e: KeyboardEvent) => {
      if (isEditable(e.target)) return;
      if (!isProtectedText(e.target)) return;
      const k = e.key.toLowerCase();
      if ((e.ctrlKey || e.metaKey) && (k === "c" || k === "x" || k === "a" || k === "s" || k === "p")) {
        e.preventDefault();
      }
    };
    // NOTE: `selectstart` is intentionally NOT attached. See BUG 1 explanation above.
    // NOTE: `touchstart` / `pointerdown` / `mousedown` were never attached and must not be.
    document.addEventListener("copy", block);
    document.addEventListener("cut", block);
    document.addEventListener("paste", block);
    document.addEventListener("contextmenu", block);
    document.addEventListener("keydown", keyBlock);
    return () => {
      document.removeEventListener("copy", block);
      document.removeEventListener("cut", block);
      document.removeEventListener("paste", block);
      document.removeEventListener("contextmenu", block);
      document.removeEventListener("keydown", keyBlock);
    };
  }, []);
  // ============================================================
  // (REMOVED — was the root cause of all three iOS symptoms)
  //
  // Previously this file ran TWO focus-management effects:
  //   1. useEffect(() => { document.activeElement.blur(); }, [status])
  //   2. document.addEventListener("focusin", blurIfTextEntry, true)
  //
  // Effect #1 fired the moment React committed setStatus("starting") inside
  // handleStart — i.e. INSIDE the iOS touchend → click → mouseup → click
  // synthesis window. iOS Safari interprets a focus/blur transition inside
  // that window as "the gesture target moved" and aborts the rest of the
  // pipeline. The three reported symptoms — button "stops working" mid-tap,
  // address-bar / search keyboard popping up, and Retell stuck on
  // "Connecting" — are all downstream of this single blur firing inside
  // the user-gesture window.
  //
  // Effect #2 was dead code: this file contains zero <input>, <textarea>,
  // contenteditable, [tabindex], autoFocus, or .focus() — verified via
  // grep — so the listener never had anything to blur. It only added
  // capture-phase work on every focus event including the button's own
  // focus, which compounded the iOS gesture interference.
  //
  // Removing both effects fixes the button, the keyboard, AND the
  // "stuck on Connecting" symptom together because they share one root
  // cause. Selection prevention inside the caption is already handled
  // entirely by CSS ([data-protected-text="true"] { user-select: none }).
  // ============================================================
  // Mic level meter for entry screen
  const startMicMeter = (stream: MediaStream) => {
    try {
      const AC: typeof AudioContext | undefined =
        (window as any).AudioContext || (window as any).webkitAudioContext;
      if (!AC || stream.getAudioTracks().length === 0) return;
      const ctx = new AC();
      micAudioCtxRef.current = ctx;
      const src = ctx.createMediaStreamSource(stream);
      const an = ctx.createAnalyser();
      an.fftSize = 512;
      src.connect(an);
      micSourceRef.current = src;
      micAnalyserRef.current = an;
      const buf = new Uint8Array(an.frequencyBinCount);
      micAboveSinceRef.current = null;
      const tick = () => {
        an.getByteTimeDomainData(buf);
        let s = 0;
        for (let i = 0; i < buf.length; i++) { const v = (buf[i] - 128) / 128; s += v * v; }
        const level = Math.min(1, Math.sqrt(s / buf.length) * 3);
        setMicLevel(level);
        // Sustained-signal gate: > 0.025 for ~300ms => micSignalOk
        if (!micSignalOkRef.current) {
          const now = performance.now();
          if (level > 0.025) {
            if (micAboveSinceRef.current == null) micAboveSinceRef.current = now;
            else if (now - micAboveSinceRef.current > 300) {
              micSignalOkRef.current = true;
              setMicSignalOk(true);
              setMicNoSignalHint(false);
              if (micNoSignalTimerRef.current != null) { window.clearTimeout(micNoSignalTimerRef.current); micNoSignalTimerRef.current = null; }
            }
          } else {
            micAboveSinceRef.current = null;
          }
        }
        micRafRef.current = requestAnimationFrame(tick);
      };
      tick();
    } catch (err) {
      console.warn("[ai-interview] mic meter failed:", err);
    }
  };
  // Open a SHORT-LIVED, SEPARATE mic stream just for the level meter.
  // Stays open only while the candidate is on the pre-check screen; released
  // synchronously inside the Begin tap BEFORE handleStart runs so Retell/LiveKit
  // is the sole mic owner during the call.
  const startMicProbe = async (deviceId?: string) => {
    try {
      // Tear down any previous probe first.
      stopMicProbe();
      micSignalOkRef.current = false;
      setMicSignalOk(false);
      setMicNoSignalHint(false);
      setMicLevel(0);
      const constraints: MediaStreamConstraints = {
        audio: deviceId ? { deviceId: { exact: deviceId } } : true,
      };
      const stream = await navigator.mediaDevices.getUserMedia(constraints);
      micProbeStreamRef.current = stream;
      startMicMeter(stream);
      // Hint after 4s of no detected signal.
      if (micNoSignalTimerRef.current != null) window.clearTimeout(micNoSignalTimerRef.current);
      micNoSignalTimerRef.current = window.setTimeout(() => {
        if (!micSignalOkRef.current) setMicNoSignalHint(true);
      }, 4000);
      // Refresh device list (labels available once permission is granted).
      try {
        const devices = await navigator.mediaDevices.enumerateDevices();
        const inputs = devices
          .filter((d) => d.kind === "audioinput")
          .map((d, i) => ({ deviceId: d.deviceId, label: d.label || `Microphone ${i + 1}` }));
        setAudioInputs(inputs);
        if (!deviceId) {
          const active = stream.getAudioTracks()[0]?.getSettings?.().deviceId as string | undefined;
          if (active) setSelectedMicId(active);
        } else {
          setSelectedMicId(deviceId);
        }
      } catch { /* noop */ }
    } catch (err) {
      console.warn("[ai-interview] mic probe failed:", err);
      setMicNoSignalHint(true);
    }
  };
  const stopMicProbe = () => {
    try { micProbeStreamRef.current?.getTracks().forEach((t) => t.stop()); } catch { /* noop */ }
    micProbeStreamRef.current = null;
    if (micNoSignalTimerRef.current != null) { window.clearTimeout(micNoSignalTimerRef.current); micNoSignalTimerRef.current = null; }
    releaseMicMeter();
  };
  const handleMicDeviceChange = (deviceId: string) => {
    void startMicProbe(deviceId);
  };
  // onTest — iOS-safe two-step grant:
  //   1) Acquire VIDEO-ONLY preview stream (does NOT hold the mic).
  //   2) Mic probe — request + release the mic so iOS pre-grants permission.
  // Result: when the Begin tap later runs Retell.startCall, iOS has the mic
  // free AND already authorized, so no second prompt / no mic contention.
  const requestCameraAndMic = async () => {
    if (permRequesting || previewReady) return;
    if (camStreamRef.current) { setPreviewReady(true); return; }
    setPermRequesting(true);
    setPermError(null);
    setPermBlocked(false);

    const isBlockedError = (err: any) => {
      const name = err?.name || "";
      return name === "NotAllowedError" || name === "SecurityError" || name === "PermissionDeniedError";
    };

    const mobile = isMobileDevice();
    try {
      if (mobile) {
        // ---------- MOBILE (iPhone/Android) — proven separate flow ----------
        // 1) video-only preview stream  2) mic probe (request + release).
        // Visual ring follows the actual underlying step.
        setCheckingStage("camera");
        const videoStream = await navigator.mediaDevices.getUserMedia({
          video: { facingMode: "user" },
          audio: false,
        });
        if (videoStream.getVideoTracks().length === 0) {
          videoStream.getTracks().forEach((t) => t.stop());
          setPermError("nodevice");
          return;
        }
        setCheckingStage("mic");
        try {
          const micProbe = await navigator.mediaDevices.getUserMedia({ audio: true });
          micProbe.getTracks().forEach((t) => t.stop());
        } catch (e: any) {
          console.error("[ai-interview] mic probe denied:", e);
          videoStream.getTracks().forEach((t) => t.stop());
          if (isBlockedError(e)) setPermBlocked(true);
          setPermError("denied");
          return;
        }
        camStreamRef.current = videoStream;
        if (videoPreviewRef.current) {
          videoPreviewRef.current.srcObject = videoStream;
          videoPreviewRef.current.play().catch(() => {});
        }
        setPreviewReady(true);
        // Open the SHORT-LIVED probe mic stream for the signal meter. Separate
        // from camStreamRef (which stays video-only). Released synchronously
        // inside the Begin tap BEFORE handleStart runs.
        void startMicProbe(undefined);
      } else {
        // ---------- DESKTOP — single combined permission prompt ----------
        // Visual ring sits on the mic during the combined prompt, then
        // briefly moves to the camera as confirmation, then clears.
        setCheckingStage("mic");
        const combined = await navigator.mediaDevices.getUserMedia({
          video: { facingMode: "user" },
          audio: true,
        });
        if (combined.getVideoTracks().length === 0) {
          combined.getTracks().forEach((t) => t.stop());
          setPermError("nodevice");
          return;
        }
        // Release the mic track immediately so Retell can acquire it cleanly
        // later — keep only the video track on the preview stream (same
        // contract as the mobile flow, so the downstream pipeline is unchanged).
        combined.getAudioTracks().forEach((t) => t.stop());
        const videoOnly = new MediaStream(combined.getVideoTracks());
        setCheckingStage("camera");
        camStreamRef.current = videoOnly;
        if (videoPreviewRef.current) {
          videoPreviewRef.current.srcObject = videoOnly;
          videoPreviewRef.current.play().catch(() => {});
        }
        setPreviewReady(true);
        void startMicProbe(undefined);
      }
    } catch (err: any) {
      console.error("[ai-interview] getUserMedia denied:", err);
      const name = err?.name;
      if (name === "NotFoundError") setPermError("nodevice");
      else {
        if (isBlockedError(err)) setPermBlocked(true);
        setPermError("denied");
      }
    } finally {
      setPermRequesting(false);
      setCheckingStage(null);
    }
  };
  // Attach camera stream to whichever <video> is currently mounted.
  useEffect(() => {
    const stream = camStreamRef.current;
    if (!stream) return;
    const targets: Array<HTMLVideoElement | null> = [videoPreviewRef.current, videoInCallRef.current];
    for (const el of targets) {
      if (el && el.srcObject !== stream) {
        el.srcObject = stream;
        el.play().catch(() => {});
      }
    }
  }, [status, previewReady]);
  // Duration timer
  useEffect(() => {
    if (status !== "live") return;
    if (!startedAtRef.current) startedAtRef.current = Date.now();
    const id = setInterval(() => {
      if (startedAtRef.current) setDurationSec(Math.floor((Date.now() - startedAtRef.current) / 1000));
    }, 1000);
    return () => clearInterval(id);
  }, [status]);
  const stopCameraTracks = () => {
    try { camStreamRef.current?.getTracks().forEach((t) => t.stop()); } catch { /* noop */ }
    camStreamRef.current = null;
    if (micRafRef.current) { cancelAnimationFrame(micRafRef.current); micRafRef.current = null; }
    if (micAudioCtxRef.current) { micAudioCtxRef.current.close().catch(() => {}); micAudioCtxRef.current = null; }
  };
  // ----------------------------------------------------------------
  // PRE-FLIGHT CAMERA FRAME-LIVENESS PROBE (ready/preview screen only)
  // Reads the EXISTING preview stream (camStreamRef) + preview <video>
  // (videoPreviewRef). Acquires NOTHING new and never touches the start
  // sequence. Catches the "track but no frames" dead-camera case BEFORE Begin.
  // Warn-only: it can set frameWarn=true but NEVER disables Begin.
  // ----------------------------------------------------------------
  const runFrameLivenessProbe = async () => {
    if (frameProbeRunningRef.current) return;
    frameProbeRunningRef.current = true;
    try {
      const stream = camStreamRef.current;            // EXISTING preview stream
      const videoEl = videoPreviewRef.current;        // EXISTING preview <video>
      const track = stream?.getVideoTracks?.()[0] ?? null;
      const trackLive =
        !!track && track.readyState === "live" && track.enabled !== false && track.muted !== true;

      // (a) sample currentTime + dimensions, wait ~1.5s, sample again.
      const t0 = videoEl ? videoEl.currentTime : 0;
      const dims0 = !!videoEl && videoEl.videoWidth > 0 && videoEl.videoHeight > 0;
      await new Promise((r) => setTimeout(r, 1500));
      const t1 = videoEl ? videoEl.currentTime : 0;
      const dims1 = !!videoEl && videoEl.videoWidth > 0 && videoEl.videoHeight > 0;

      const advanced = t1 > t0;
      const hasDims = dims0 || dims1;

      const framesFlowing = hasDims && advanced && trackLive;
      // Clearly dead: dims 0 AND not advancing, OR the track itself isn't live.
      const clearlyDead = (!hasDims && !advanced) || !trackLive;

      if (framesFlowing) {
        setFrameWarn(false);
      } else if (clearlyDead) {
        setFrameWarn(true);
        logVideoFailure("preflight_no_frames");
        addDebug("preflight frame probe", { hasDims, advanced, trackLive });
      } else {
        // Uncertain — do NOT warn, do NOT block.
        setFrameWarn(false);
      }
    } finally {
      frameProbeRunningRef.current = false;
    }
  };
  // Run the probe once whenever the preview becomes ready (and again after a
  // Try Again re-acquire flips previewReady back true). Entry screen only.
  useEffect(() => {
    if (status !== "idle") return;
    if (!previewReady) return;
    void runFrameLivenessProbe();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [previewReady, status]);
  // Try Again — re-runs the EXISTING requestCameraAndMic, then the effect above
  // re-probes once preview is ready again. Never blocks Begin.
  const retryCameraPreflight = () => {
    setFrameWarn(false);
    try { stopCameraTracks(); } catch { /* noop */ }
    setPreviewReady(false);
    void requestCameraAndMic();
  };
  // Pattern A: upload a single recorded chunk to R2 as a numbered PART object so
  // the bytes leave the device DURING the interview. Fire-and-forget but tracked:
  // retries up to 3x with backoff; on permanent failure the chunk stays in
  // chunksRef so the end-of-call single-blob fallback still covers it.
  const uploadPart = async (chunk: Blob, index: number): Promise<void> => {
    const callId = callIdRef.current;
    if (!callId || !token || chunk.size === 0) return;
    for (let attempt = 0; attempt < 3; attempt++) {
      try {
        const { data: presign, error: pErr } = await supabase.functions.invoke<{
          upload_url: string; public_url: string; error?: string;
        }>("get-r2-upload-url", { body: { token, retell_call_id: callId, part: index } });
        if (pErr || !presign?.upload_url) throw new Error(presign?.error || pErr?.message || "presign_failed");
        const putRes = await fetch(presign.upload_url, {
          method: "PUT",
          headers: { "Content-Type": "video/webm" },
          body: chunk,
        });
        if (!putRes.ok) {
          const text = await putRes.text().catch(() => "");
          throw new Error(`r2_part_put_failed ${putRes.status} ${text.slice(0, 120)}`);
        }
        uploadedPartsRef.current += 1;
        return;
      } catch (e) {
        if (attempt === 2) {
          console.error(`[ai-interview] part ${index} upload failed after retries:`, e);
          return; // leave chunk in chunksRef as fallback
        }
        await new Promise((r) => setTimeout(r, 800 * (attempt + 1)));
      }
    }
  };
  // finalizeRecordingAndUpload — preferred path concatenates the live-streamed
  // parts server-side; if no parts exist it falls back to TODAY's single whole-blob
  // PUT (no regression). `silent` lets error paths save the recording WITHOUT
  // overriding their own error UI status.
  const finalizeRecordingAndUpload = async (opts?: { silent?: boolean }): Promise<void> => {
    const silent = opts?.silent === true;
    if (uploadedRef.current) return;
    uploadedRef.current = true;
    const rec = recorderRef.current;
    if (!rec) {
      // Recorder was never built (MediaRecorder unavailable / init failed at start).
      // Used to early-return silently → video_url stayed NULL with nothing logged.
      logVideoFailure("recorder_init_failed");
      if (!silent) setStatus("ended");
      return;
    }
    if (!silent) setStatus("uploading");
    const blob: Blob = await new Promise((resolve) => {
      const finish = () => resolve(new Blob(chunksRef.current, { type: "video/webm" }));
      if (rec.state === "inactive") return finish();
      rec.onstop = finish;
      try { rec.stop(); } catch { finish(); }
    });
    stopCameraTracks();
    const callId = callIdRef.current;
    if (!callId || !token) {
      console.error("[ai-interview] skipping upload — missing call_id/token", { callId });
      // Upload skipped (no call id / token) → bytes captured but never saved.
      // Make the silent drop visible.
      logVideoFailure("upload_failed");
      if (!silent) setStatus("ended");
      return;
    }
    const saveVideoUrl = async (video_url: string) => {
      const saveOnce = async () =>
        supabase.functions.invoke<{ ok?: boolean; error?: string }>("save-interview-video-url", {
          body: { token, retell_call_id: callId, video_url },
        });
      let saveResp = await saveOnce();
      if (saveResp.error || !saveResp.data?.ok) {
        await new Promise((r) => setTimeout(r, 5000));
        saveResp = await saveOnce();
      }
      if (saveResp.error || !saveResp.data?.ok) {
        console.error("[ai-interview] save video_url failed:", saveResp.error, saveResp.data);
        // File reached R2 but save-interview-video-url never persisted the URL →
        // video effectively lost (column stays NULL). Log the silent drop.
        logVideoFailure("upload_failed");
      }
    };
    try {
      // PATH 1 (preferred): live parts already streamed → concatenate server-side.
      if (uploadedPartsRef.current > 0) {
        try {
          const { data: fin, error: finErr } = await supabase.functions.invoke<{
            ok?: boolean; public_url?: string; parts_found?: number; error?: string;
          }>("finalize-interview-parts", { body: { token, retell_call_id: callId } });
          if (!finErr && fin?.ok && fin.public_url) {
            await saveVideoUrl(fin.public_url);
            return;
          }
          console.warn("[ai-interview] finalize-parts unusable, falling back to single blob:", finErr, fin);
        } catch (e) {
          console.warn("[ai-interview] finalize-parts threw, falling back to single blob:", e);
        }
      }
      // PATH 2 (fallback / no live parts): single whole-object PUT — TODAY's behavior.
      if (blob.size === 0) {
        console.error("[ai-interview] no parts and empty blob — nothing to upload");
        // Empty-video sessions used to vanish silently (video_url NULL, nothing
        // logged). Make it VISIBLE. Keep the early return — no crash, no
        // candidate-facing break; audio/transcript already saved normally.
        logVideoFailure("empty_blob_finalize");
        return;
      }
      const { data: presign, error: pErr } = await supabase.functions.invoke<{
        upload_url: string; public_url: string; error?: string;
      }>("get-r2-upload-url", { body: { token, retell_call_id: callId } });
      if (pErr || !presign?.upload_url) throw new Error(presign?.error || pErr?.message || "presign_failed");
      const putRes = await fetch(presign.upload_url, {
        method: "PUT",
        headers: { "Content-Type": "video/webm" },
        body: blob,
      });
      if (!putRes.ok) {
        const text = await putRes.text().catch(() => "");
        throw new Error(`r2_put_failed ${putRes.status} ${text.slice(0, 200)}`);
      }
      await saveVideoUrl(presign.public_url);
    } catch (e) {
      console.error("[ai-interview] video upload failed:", e);
      // R2 presign / PUT (or finalize-parts) failed → no video saved. Log it.
      logVideoFailure("upload_failed");
    } finally {
      if (!silent) setStatus("ended");
    }
  };
  // Pattern A tab-close flush: if recording is active, force-flush the current
  // buffer (recorder.requestData → ondataavailable → uploadPart) so a closing tab
  // loses at most the in-flight ~6s, not the whole video. Best-effort; ADDITIVE to
  // the idle-screen token-poll visibilitychange handler (which is left untouched).
  //
  // Gap closed: requestData() alone never runs finalize, so on browser-close the
  // parts already on R2 sat stranded until the ~20-min cron reaper. After flushing
  // we fire the reaper for this session ON-DEMAND via navigator.sendBeacon (falling
  // back to fetch keepalive) — these survive page unload, so the candidate's parts
  // get stitched and video_url set within seconds, not minutes. The cron reaper
  // stays as the backstop for anything the beacon misses. Best-effort, fire-once,
  // never throws, never blocks the unload, never touches Retell/audio.
  useEffect(() => {
    const fireCloseFinalize = () => {
      if (closeFinalizeFiredRef.current) return;
      const callId = callIdRef.current;
      // Nothing to recover without a call id (recorder never produced parts).
      if (!callId) return;
      closeFinalizeFiredRef.current = true;
      try {
        const url = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/reap-orphaned-interview-videos`;
        const payload = JSON.stringify({ token, retell_call_id: callId });
        let sent = false;
        if (typeof navigator !== "undefined" && typeof navigator.sendBeacon === "function") {
          const blob = new Blob([payload], { type: "application/json" });
          sent = navigator.sendBeacon(url, blob);
        }
        if (!sent) {
          // Fallback: keepalive fetch survives unload when sendBeacon is unavailable.
          void fetch(url, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: payload,
            keepalive: true,
          }).catch(() => { /* noop */ });
        }
      } catch { /* best-effort: never throw during unload */ }
    };
    const flush = () => {
      const rec = recorderRef.current;
      if (rec && rec.state === "recording") {
        try { rec.requestData(); } catch { /* noop */ }
      }
      fireCloseFinalize();
    };
    const onHide = () => { if (document.visibilityState === "hidden") flush(); };
    window.addEventListener("pagehide", flush);
    document.addEventListener("visibilitychange", onHide);
    return () => {
      window.removeEventListener("pagehide", flush);
      document.removeEventListener("visibilitychange", onHide);
    };
  }, [token]);
  // ============================================================
  // releaseMicMeter — Stops ONLY the visualizer (RAF + AnalyserNode +
  // meter AudioContext). The candidate's audio MediaStreamTrack stays
  // LIVE so Retell's WebRTC pipeline can share the already-granted mic.
  //
  // We deliberately do NOT call track.stop() or removeTrack here. On
  // iOS Safari, stopping the mic track before Retell connects can
  // surrender the audio session and leave Retell joining without
  // audible mic input — call_started never fires and the candidate
  // is stuck on "Connecting…".
  // ============================================================
  const releaseMicMeter = () => {
    if (micRafRef.current) { cancelAnimationFrame(micRafRef.current); micRafRef.current = null; }
    try { micSourceRef.current?.disconnect(); } catch { /* noop */ }
    try { micAnalyserRef.current?.disconnect(); } catch { /* noop */ }
    micSourceRef.current = null;
    micAnalyserRef.current = null;
    if (micAudioCtxRef.current) {
      try {
        if (micAudioCtxRef.current.state !== "closed") {
          micAudioCtxRef.current.close().catch(() => {});
        }
      } catch { /* noop */ }
      micAudioCtxRef.current = null;
    }
  };
  // Pre-fetch create-ai-web-call so the Begin tap has no awaits before client.startCall.
  const clearPrefetchRetry = () => {
    if (prefetchRetryTimerRef.current != null) {
      window.clearTimeout(prefetchRetryTimerRef.current);
      prefetchRetryTimerRef.current = null;
    }
  };
  const prefetchCall = (): Promise<{ access_token: string; call_id: string } | null> => {
    if (prefetchedCallRef.current) return Promise.resolve(prefetchedCallRef.current);
    if (prefetchPromiseRef.current) return prefetchPromiseRef.current;
    if (!token) return Promise.resolve(null);
    // PART 1: never (re)mint a Retell call for a link that's been invalidated.
    if (linkInvalid) return Promise.resolve(null);
    clearPrefetchRetry();
    setPrefetchReady(false);
    // 10s per-attempt timeout so a hung invoke never blocks indefinitely.
    const invokePromise = supabase.functions
      .invoke<{ access_token?: string; call_id?: string; stage?: string; error?: string }>("create-ai-web-call", { body: { token } });
    const timeoutPromise = new Promise<{ data: null; error: { message: string } }>((resolve) => {
      window.setTimeout(() => resolve({ data: null, error: { message: "prefetch_timeout" } }), 10000);
    });
    const p = Promise.race([invokePromise, timeoutPromise])
      .then(({ data, error }: any) => {
        // GLITCH 8: server says this response already has a real completion.
        // Show the "already complete" screen — do NOT retry, do NOT route to retry/connect_failed.
        // supabase.functions.invoke surfaces non-2xx as `error` with `context.status`;
        // also detect via the body's `error` field for resilience.
        const status = error?.context?.status ?? error?.status;
        const bodyErr = data?.error || error?.context?.body?.error;
        if (status === 409 || bodyErr === "already_completed") {
          console.log("[ai] create-ai-web-call → already_completed; showing final screen");
          prefetchPromiseRef.current = null;
          setPrefetchReady(false);
          clearPrefetchRetry();
          setStatus("already_completed");
          return null;
        }
        // Audit fix #1: a 401 token_expired / token_used / invalid_token means the
        // link is dead. Surface the existing "no longer active" state immediately
        // instead of silently leaving Begin tappable with no message. (already_completed
        // is handled above and is intentionally left untouched.)
        if (status === 401 || bodyErr === "token_expired" || bodyErr === "token_used" || bodyErr === "invalid_token") {
          console.log("[ai] create-ai-web-call → link no longer active; showing inactive state", bodyErr);
          prefetchPromiseRef.current = null;
          setPrefetchReady(false);
          clearPrefetchRetry();
          prefetchedCallRef.current = null;
          setLinkInvalid(true);
          return null;
        }
        if (error || !data?.access_token || !data?.call_id) {
          console.warn("[ai] mint create-ai-web-call failed:", error || data?.error);
          prefetchPromiseRef.current = null;
          setPrefetchReady(false);
          // Two-phase commit: NO auto-retry. The mint only happens on a deliberate
          // Begin tap, so a failed mint simply leaves Begin tappable to retry.
          return null;
        }
        if (data.stage) setTokenStage(data.stage);
        prefetchedCallRef.current = { access_token: data.access_token, call_id: data.call_id };
        setPrefetchReady(true);
        return prefetchedCallRef.current;
      })

      .catch((e) => {
        console.warn("[ai] mint create-ai-web-call threw:", e);
        prefetchPromiseRef.current = null;
        setPrefetchReady(false);
        // Two-phase commit: NO auto-retry. Candidate can re-tap Begin to retry.
        return null;
      });
    prefetchPromiseRef.current = p;
    return p;
  };
  // PART 1 (one-tap restore): auto-prefetch the Retell call as soon as the
  // camera + mic checks pass (previewReady && micSignalOk), BEFORE the user
  // taps Begin. This mirrors the proven iOS-safe pattern so the token is
  // already in memory when they tap, making the single Begin tap synchronous.
  // prefetchCall() is idempotent (guards on prefetchedCallRef/prefetchPromiseRef),
  // and it is NEVER awaited inside the Begin gesture — the iOS-safe start path
  // (handleStart) is untouched.
  useEffect(() => {
    if (!token) return;
    if (linkInvalid) return;
    if (!previewReady || !micSignalOk) return;
    if (prefetchReady || prefetchedCallRef.current) return;
    void prefetchCall();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [token, linkInvalid, previewReady, micSignalOk, prefetchReady]);


  // ============================================================
  // PART 1 — ENFORCE INVALIDATION ON AN ALREADY-OPEN IDLE SESSION
  // ------------------------------------------------------------
  // While the candidate sits on the entry/camera screen, periodically re-check
  // that the rebook token is still valid (unexpired AND unused). If HR
  // invalidates it mid-session, drop the cached Retell access_token and disable
  // Begin within seconds. This runs ONLY in the background on the idle screen —
  // it is NEVER awaited inside the Begin tap gesture, so the iOS-safe start
  // pattern is untouched. The permanent-test token is fully exempt.
  useEffect(() => {
    if (!token || token === "permanent-test") return; // permanent-test always works
    if (status !== "idle") return; // only matters on the entry/camera screen

    let cancelled = false;

    const recheck = async () => {
      if (cancelled || statusRef.current !== "idle") return;
      try {
        const { data, error } = await supabase.functions.invoke<{ valid?: boolean; stage?: string }>(
          "validate-rebook-token",
          { body: { token } },
        );
        if (cancelled || statusRef.current !== "idle") return;
        if (!error && data?.stage) setTokenStage(data.stage);
        // Only act on a DEFINITIVE invalid verdict. Network / edge blips are
        // ignored so a transient failure never falsely kills a legit candidate.
        if (!error && data && data.valid === false) {
          clearPrefetchRetry();
          prefetchedCallRef.current = null;
          prefetchPromiseRef.current = null;
          setPrefetchReady(false);
          setLinkInvalid(true);
        }
      } catch {
        /* transient — ignore, the next tick will retry */
      }
    };

    const intervalId = window.setInterval(recheck, 25000); // poll ~every 25s
    const onFocus = () => { void recheck(); };
    const onVisible = () => { if (document.visibilityState === "visible") void recheck(); };
    window.addEventListener("focus", onFocus);
    document.addEventListener("visibilitychange", onVisible);
    void recheck(); // immediate check on mount / return to idle

    return () => {
      cancelled = true;
      window.clearInterval(intervalId);
      window.removeEventListener("focus", onFocus);
      document.removeEventListener("visibilitychange", onVisible);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [token, status]);
  // ============================================================
  // PART 2 — fetch the 72h completion deadline (read-only).
  // deadlineAt = rebook_tokens.expires_at (= invite-sent + 72h). No DB writes,
  // no edge-function changes — reuses the existing public validate-rebook-token.
  // permanent-test has no real token row, so synthesize a live deadline (issued
  // ~ now + 72h) purely so the countdown is demonstrable during QA.
  useEffect(() => {
    if (!token) return;
    if (token === "permanent-test") {
      setDeadlineAt(new Date(Date.now() + 72 * 60 * 60 * 1000));
      return;
    }
    let cancelled = false;
    void (async () => {
      try {
        const { data } = await supabase.functions.invoke<{ valid?: boolean; expires_at?: string; stage?: string }>(
          "validate-rebook-token",
          { body: { token } },
        );
        if (cancelled) return;
        if (data?.stage) setTokenStage(data.stage);
        if (data?.expires_at) setDeadlineAt(new Date(data.expires_at));
      } catch {
        /* transient — the countdown simply won't render */
      }
    })();
    return () => { cancelled = true; };
  }, [token]);

  // PART 2 — tick the countdown once per second, ONLY on the idle/ready screen.
  // Never runs during the live call / thank-you / invalid screens.
  useEffect(() => {
    if (status !== "idle" || !deadlineAt) return;
    setNowTick(Date.now());
    const id = window.setInterval(() => setNowTick(Date.now()), 1000);
    return () => window.clearInterval(id);
  }, [status, deadlineAt]);
  // ============================================================
  // handleStart — SYNCHRONOUS Begin handler. Must NOT be async.
  //
  // iOS Safari rule: any call that opens the mic / starts WebRTC
  // (Retell.startCall) must run inside the original tap gesture.
  // No `await`, no `setTimeout`, no `.then()` before startCall.
  //
  // Preconditions enforced by the caller (Begin button disabled
  // until both are true):
  //   - previewReady (camera + mic permission granted)
  //   - prefetchReady (Retell access_token already in memory)
  // ============================================================
  const handleStart = () => {
    if (!token) return;
    if (startingRef.current) return;
    const call = prefetchedCallRef.current;
    if (!call?.access_token) {
      // Token wasn't ready — shouldn't reach here because button is gated,
      // but bail safely without freezing the UI.
      return;
    }
    startingRef.current = true;

    // 1) Synchronous iOS audio unlock inside the gesture.
    try {
      const AC: typeof AudioContext | undefined =
        (window as any).AudioContext || (window as any).webkitAudioContext;
      if (AC) {
        if (!unlockedAudioCtxRef.current) unlockedAudioCtxRef.current = new AC();
        const ac = unlockedAudioCtxRef.current!;
        ac.resume().catch(() => {});
        try {
          const src = ac.createBufferSource();
          src.buffer = ac.createBuffer(1, 1, 22050);
          src.connect(ac.destination);
          src.start(0);
        } catch { /* noop */ }
      }
    } catch (e) {
      console.warn("[ai] audio unlock failed:", e);
    }

    // 2) Fire Retell IMMEDIATELY with the pre-fetched token. No await.
    //    Listeners are attached BEFORE startCall.
    callIdRef.current = call.call_id;
    prefetchedCallRef.current = null;
    prefetchPromiseRef.current = null;
    // Note: setPrefetchReady(false) is intentionally NOT called here —
    // it triggers a re-render that would compete with the screen flip.
    // The state will be reset by handleRetryConnect / unmount paths.
    failureLoggedRef.current = false;
    uploadedRef.current = false;
    chunksRef.current = [];
    partIndexRef.current = 0;
    uploadedPartsRef.current = 0;
    // Reset zero-chunk video-loss detection for this fresh interview attempt.
    chunksSeenRef.current = 0;
    if (zeroChunkTimerRef.current != null) { window.clearTimeout(zeroChunkTimerRef.current); zeroChunkTimerRef.current = null; }
    videoFailureStagesRef.current = new Set();

    const client = new RetellWebClient();
    clientRef.current = client;
    let callStartedFired = false;

    // Joined-but-silent watchdog: arm on call_started, clear on first agent
    // audio activity / transcript update. If neither happens within ~12s, the
    // candidate joined but their mic sent nothing (Retell will later emit
    // error_user_not_joined). Added ALONGSIDE the existing connect_timeout /
    // disconnect / error / start_threw hooks — none of those are altered.
    const clearSilentWatchdog = () => {
      if (silentMicTimerRef.current != null) {
        window.clearTimeout(silentMicTimerRef.current);
        silentMicTimerRef.current = null;
      }
    };
    const armSilentWatchdog = () => {
      clearSilentWatchdog();
      silentMicTimerRef.current = window.setTimeout(() => {
        silentMicTimerRef.current = null;
        if (clientRef.current !== client) return;
        // Only fire if we still have not heard a peep from the agent.
        console.error("[ai] joined_but_silent — no agent activity in 12s");
        logFailure("joined_but_silent");
        setStatus("silent_mic");
        try { client.stopCall(); } catch { /* noop */ }
        try { recorderRef.current?.stop(); } catch { /* noop */ }
        void finalizeRecordingAndUpload({ silent: true });
        stopCameraTracks();
      }, 12000);
    };

    client.on("call_started", () => {
      callStartedFired = true;
      clearConnectTimeout();
      console.log("[ai] call_started fired");
      armSilentWatchdog();
      setStatus("live");
    });
    client.on("call_ended", () => { clearSilentWatchdog(); void finalizeRecordingAndUpload(); });
    (client as any).on?.("disconnect", (reason: unknown) => {
      if (!callStartedFired && clientRef.current === client) {
        clearConnectTimeout();
        clearSilentWatchdog();
        logFailure("retell_disconnect_before_start", reason);
        setStatus("connect_failed");
        try { client.stopCall(); } catch { /* noop */ }
        try { recorderRef.current?.stop(); } catch { /* noop */ }
        void finalizeRecordingAndUpload({ silent: true });
        stopCameraTracks();
      }
    });
    client.on("error", (err: unknown) => {
      console.error("[retell] error:", err);
      clearConnectTimeout();
      clearSilentWatchdog();
      logFailure("retell_error", err);
      setStatus("connect_failed");
      try { client.stopCall(); } catch { /* noop */ }
      try { recorderRef.current?.stop(); } catch { /* noop */ }
      void finalizeRecordingAndUpload({ silent: true });
      stopCameraTracks();
    });
    client.on("agent_start_talking", () => { clearSilentWatchdog(); setChristineSpeaking(true); });
    client.on("agent_stop_talking", () => setChristineSpeaking(false));
    client.on("update", (u: any) => {
      try {
        const arr: any[] | undefined = u?.transcript;
        if (Array.isArray(arr)) {
          if (arr.length > 0) clearSilentWatchdog();
          const lines: Line[] = arr
            .filter((m) => m && typeof m.content === "string" && m.content.trim().length > 0)
            .map((m) => ({
              who: m.role === "agent" || m.role === "assistant" ? "agent" : "user",
              text: String(m.content),
            }));
          setTranscript(lines);
        }
      } catch (err) {
        console.error("[retell:update] parse failed", err);
      }
    });

    // CRITICAL: startCall is invoked SYNCHRONOUSLY inside the tap gesture,
    // with NO await preceding it. Do NOT await this promise either.
    client
      .startCall({ accessToken: call.access_token })
      .then(() => {
        resumeRetellAudioContexts(client, "after startCall resolved");
      })
      .catch((err: any) => {
        console.error("[ai-interview] startCall threw:", err);
        clearConnectTimeout();
        logFailure("start_threw", err);
        setStatus("connect_failed");
        try { client.stopCall(); } catch { /* noop */ }
        try { recorderRef.current?.stop(); } catch { /* noop */ }
        void finalizeRecordingAndUpload({ silent: true });
        stopCameraTracks();
      });
    resumeRetellAudioContexts(client, "immediate after startCall");

    // 3) Start recording from the existing VIDEO-ONLY preview stream.
    //    Recorder failure must NEVER abort the handler (handleStart stays SYNC).
    try {
      // Build + start the recorder from a verified-live video track. Extracted
      // so both the happy path and the async re-acquire path share one builder.
      const buildRecorder = (videoTrack: MediaStreamTrack) => {
        const videoOnlyStream = new MediaStream([videoTrack]);
        // iOS Safari frequently records ZERO frames with mp4 → PREFER webm there,
        // falling back to mp4 only if no webm codec is supported. Non-iOS keeps
        // the proven mp4-first order. videoBitsPerSecond + start(6000) unchanged.
        const iOS =
          /iPad|iPhone|iPod/.test(navigator.userAgent) ||
          (navigator.platform === "MacIntel" && navigator.maxTouchPoints > 1);
        const mimeType = iOS
          ? (MediaRecorder.isTypeSupported("video/webm;codecs=vp9") ? "video/webm;codecs=vp9" :
             MediaRecorder.isTypeSupported("video/webm;codecs=vp8") ? "video/webm;codecs=vp8" :
             MediaRecorder.isTypeSupported("video/webm") ? "video/webm" :
             MediaRecorder.isTypeSupported("video/mp4") ? "video/mp4" : "")
          : (MediaRecorder.isTypeSupported("video/mp4") ? "video/mp4" :
             MediaRecorder.isTypeSupported("video/webm;codecs=vp9") ? "video/webm;codecs=vp9" :
             MediaRecorder.isTypeSupported("video/webm;codecs=vp8") ? "video/webm;codecs=vp8" : "");
        const recorder = mimeType
          ? new MediaRecorder(videoOnlyStream, { mimeType, videoBitsPerSecond: 1_200_000 })
          : new MediaRecorder(videoOnlyStream);
        recorderRef.current = recorder;
        recorder.ondataavailable = (ev) => {
          if (ev.data && ev.data.size > 0) {
            // First real bytes → cancel the zero-chunk watchdog (recording is alive).
            chunksSeenRef.current += 1;
            if (zeroChunkTimerRef.current != null) {
              window.clearTimeout(zeroChunkTimerRef.current);
              zeroChunkTimerRef.current = null;
            }
            // Keep buffering in-memory (end-of-call single-blob fallback) AND
            // immediately stream this chunk to R2 as its own numbered part so the
            // bytes survive a tab-close. Part upload is fire-and-forget + retried.
            chunksRef.current.push(ev.data);
            const idx = partIndexRef.current;
            partIndexRef.current += 1;
            void uploadPart(ev.data, idx);
          }
        };
        // ~6s parts: large enough to keep request overhead low, small enough that
        // a tab-close at the very end loses at most the final part.
        recorder.start(6000);
        // Zero-chunk watchdog: if NOTHING ever arrives within ~12s the recorder
        // is dead (the silent video-loss bug). Log it; NEVER touch the Retell
        // call — audio/transcript must complete normally.
        if (zeroChunkTimerRef.current != null) window.clearTimeout(zeroChunkTimerRef.current);
        zeroChunkTimerRef.current = window.setTimeout(() => {
          zeroChunkTimerRef.current = null;
          if (chunksSeenRef.current === 0) logVideoFailure("zero_video_chunks");
        }, 12000);
      };

      const camStream = camStreamRef.current;
      const vt = camStream?.getVideoTracks?.()[0];
      const trackLive =
        !!vt && vt.readyState === "live" && vt.enabled !== false && vt.muted !== true;

      if (camStream && vt && trackLive) {
        // Happy path: camera track is verified live → record immediately.
        buildRecorder(vt);
      } else if (vt && !trackLive) {
        // Track present but dead/muted (iOS Safari + LiveKit mic contention can
        // kill the separate camera track between acquisition and Begin). ONE
        // camera-only re-acquire, mirroring requestCameraAndMic. Done WITHOUT
        // await so handleStart stays synchronous and the Retell call already
        // running is never disturbed. Can NEVER throw out of handleStart.
        navigator.mediaDevices
          .getUserMedia({ video: { facingMode: "user" }, audio: false })
          .then((fresh) => {
            try {
              const fvt = fresh.getVideoTracks()[0];
              const freshLive =
                !!fvt && fvt.readyState === "live" && fvt.enabled !== false && fvt.muted !== true;
              if (fvt && freshLive) {
                try { camStreamRef.current?.getTracks().forEach((t) => t.stop()); } catch { /* noop */ }
                camStreamRef.current = fresh;
                buildRecorder(fvt);
              } else {
                try { fresh.getTracks().forEach((t) => t.stop()); } catch { /* noop */ }
                logVideoFailure("no_live_video_track_at_start");
              }
            } catch (e) {
              console.warn("[ai] re-acquire post-process failed (non-fatal):", e);
              logVideoFailure("no_live_video_track_at_start");
            }
          })
          .catch((reErr) => {
            // Re-acquire failed → proceed audio-only but make it VISIBLE.
            console.warn("[ai] camera re-acquire failed (non-fatal):", reErr);
            logVideoFailure("no_live_video_track_at_start");
          });
      } else {
        // No video track at all → proceed audio-only, but log instead of silent skip.
        console.warn("[ai] no live video track at Begin — recording skipped");
        logVideoFailure("no_live_video_track_at_start");
      }
    } catch (err) {
      console.error("[ai] recorder failed (non-fatal):", err);
      // MediaRecorder constructor / start() threw → recorder never ran. Used to be
      // swallowed silently. Log it; best-effort, never aborts the sync handler.
      logVideoFailure("recorder_init_failed");
    }

    // 4) 12s connect-timeout safety net so candidate is never frozen.
    clearConnectTimeout();
    connectTimeoutRef.current = window.setTimeout(() => {
      connectTimeoutRef.current = null;
      if (!callStartedFired && clientRef.current === client) {
        console.error("[ai] call_started never fired within 12s");
        logFailure("connect_timeout");
        setStatus("connect_failed");
        try { client.stopCall(); } catch { /* noop */ }
        try { recorderRef.current?.stop(); } catch { /* noop */ }
        void finalizeRecordingAndUpload({ silent: true });
        stopCameraTracks();
      }
    }, 12000);

    // 5) Reset transient UI state.
    setDebugLines([]);
    setTranscript([]);
    setChristineSpeaking(false);
    startedAtRef.current = null;
    setDurationSec(0);
    setErrorMsg("");

    // 6) Flip the screen LAST. Steps 1-5 cannot throw out, so this always flushes.
    setStatus("starting");
  };
  const handleRetryConnect = () => {
    clearConnectTimeout();
    clearPrefetchRetry();
    if (silentMicTimerRef.current != null) { window.clearTimeout(silentMicTimerRef.current); silentMicTimerRef.current = null; }
    failureLoggedRef.current = false;
    startingRef.current = false;
    try { clientRef.current?.stopCall(); } catch { /* noop */ }
    clientRef.current = null;
    prefetchedCallRef.current = null;
    prefetchPromiseRef.current = null;
    setPrefetchReady(false);
    setMinting(false);
    setErrorMsg("");
    // Re-run the pre-check (which re-runs the mic-signal probe).
    micSignalOkRef.current = false;
    setMicSignalOk(false);
    setMicNoSignalHint(false);
    setStatus("idle");
    setPreviewReady(false);
    setWizardStep(2);
  };
  const handleStop = () => {
    try { clientRef.current?.stopCall(); } catch { /* noop */ }
    void finalizeRecordingAndUpload();
  };
  // ============================================================
  // INVALID TOKEN
  // ============================================================
  if (!token) {
    return (
      <div className="min-h-screen cream-grain flex items-center justify-center">
        <style>{STYLES}</style>
        <div className="max-w-md mx-auto px-6 py-10 text-center space-y-3">
          <div style={{ fontSize: 10, letterSpacing: "0.28em", color: GOLD }}>INVALID LINK</div>
          <p style={{ fontSize: 14, color: INK_60 }}>This interview link is missing or invalid.</p>
        </div>
      </div>
    );
  }
  if (status === "idle" && !linkInvalid && !tokenStage) {
    return (
      <div className="screen-lock flex flex-col cream-grain ios-vh" style={{ color: NAVY }}>
        <style>{STYLES}</style>
        <HeaderEntry />
        <main className="flex-1 grid place-items-center px-6 py-10">
          <div className="max-w-[520px] text-center space-y-4">
            <div className="no-select" style={{ fontSize: 10, letterSpacing: "0.28em", color: GOLD }}>PREPARING INTERVIEW</div>
            <h1 style={{ fontFamily: "'Cormorant Garamond', serif", fontWeight: 500, fontSize: "clamp(22px, 3.2vw, 32px)", lineHeight: 1.15, color: NAVY }}>
              Loading your interview…
            </h1>
          </div>
        </main>
      </div>
    );
  }
  // ============================================================
  // CONNECTING SCREEN — shown immediately on Begin tap (status === "starting")
  // ============================================================
  if (status === "starting") {
    return (
      <div className="screen-lock flex flex-col cream-grain ios-vh" style={{ color: NAVY }}>
        <style>{STYLES}</style>
        <HeaderEntry />
        <section className="flex-1 flex flex-col items-center justify-center px-4 text-center">
          <div className="max-w-[520px] mx-auto">
            <div className="no-select" style={{ fontSize: 10, letterSpacing: "0.28em", color: GOLD, marginBottom: 6 }}>
              YOU'RE ALL SET
            </div>
            <div className="flex justify-center mb-4">
              <div
                className="relative grid place-items-center rounded-full breathe"
                style={{
                  width: 96, height: 96,
                  background: "radial-gradient(120% 120% at 30% 25%, #243059 0%, #1a2547 55%, #11193a 100%)",
                  border: `1px solid ${GOLD}`,
                  boxShadow: "0 14px 36px rgba(15,23,48,0.22)",
                }}
              >
                <span style={{ fontFamily: "'Cormorant Garamond', serif", fontWeight: 500, fontSize: 40, color: CREAM, letterSpacing: "0.02em" }}>{interviewer.initial}</span>
              </div>
            </div>
            <h1 style={{ fontFamily: "'Cormorant Garamond', serif", fontWeight: 500, fontSize: "clamp(22px, 3.2vw, 32px)", lineHeight: 1.15, color: NAVY }}>
              Connecting you with <span style={{ fontStyle: "italic" }}>{interviewer.name}</span>…
            </h1>
            <p className="mt-3" style={{ fontSize: 12.5, color: INK_60, lineHeight: 1.5 }}>
              {interviewer.name} will introduce herself in just a moment.
            </p>
            <div className="mt-6 flex justify-center gap-1">
              <span className="lb-bar inline-block" style={{ width: 4, height: 18, background: GOLD, borderRadius: 2, animationDelay: "0ms" }} />
              <span className="lb-bar inline-block" style={{ width: 4, height: 18, background: GOLD, borderRadius: 2, animationDelay: "120ms" }} />
              <span className="lb-bar inline-block" style={{ width: 4, height: 18, background: GOLD, borderRadius: 2, animationDelay: "240ms" }} />
            </div>
          </div>
        </section>
      </div>
    );
  }

  // ============================================================
  // SCREEN 1 — ENTRY (2-step wizard)
  // ============================================================
  if (status === "idle") {
    const requesting = permRequesting;
    const step = wizardStep;

    const StepDots = () => (
      <div className="flex items-center justify-center gap-2 no-select" aria-label={`Step ${step} of 4`}>
        {[1, 2, 3, 4].map((n) => {
          const active = n === step;
          const done = n < step;
          return (
            <span
              key={n}
              className="inline-block rounded-full transition-all"
              style={{
                width: active ? 22 : 8,
                height: 8,
                background: active ? GOLD : (done ? GOLD_SOFT : RULE),
              }}
            />
          );
        })}
        <span className="ml-2" style={{ fontSize: 10, letterSpacing: "0.22em", color: INK_60 }}>
          STEP {step} OF 4
        </span>
      </div>
    );


    return (
      <div className="screen-lock flex flex-col cream-grain ios-vh" style={{ color: NAVY }}>
        <style>{STYLES}</style>
        <HeaderEntry />
        <section
          className="flex-1 flex flex-col px-4 sm:px-8 lg:px-14 pt-4 pb-5 sm:pt-6 sm:pb-7"
          style={{ minHeight: "calc(var(--app-vh, 100vh) - 64px)" }}
        >
          <div className="w-full max-w-[960px] mx-auto flex-1 flex flex-col">

            {/* ============ STEP 1 — FRAME IT ============ */}
            {step === 1 && (
              <div className="flex-1 flex flex-col">
                <div className="flex-1 flex flex-col items-center justify-center text-center max-w-[600px] mx-auto w-full">
                  <div className="no-select" style={{ fontSize: 10, letterSpacing: "0.28em", color: GOLD, marginBottom: 8 }}>
                    WELCOME
                  </div>
                  <h1 style={{ fontFamily: "'Cormorant Garamond', serif", fontWeight: 500, fontSize: "clamp(26px, 4vw, 40px)", letterSpacing: "-0.01em", lineHeight: 1.1, color: NAVY }}>
                    Hi — let's get you <span style={{ fontStyle: "italic" }}>started</span>.
                  </h1>
                  <p className="mt-5" style={{ fontSize: 16, lineHeight: 1.6, color: "rgba(26,37,71,0.85)", maxWidth: 480 }}>
                    A short voice interview, guided by {interviewer.name}, our AI interviewer. About 7 minutes, right here.
                  </p>
                  <p className="mt-3" style={{ fontSize: 14, color: INK_60 }}>
                    No download. No scheduling.
                  </p>
                </div>
                <div className="mt-4 sm:mt-5">
                  <PrimaryButton label="See what she'll ask" onTap={() => setWizardStep(2)} />
                  <div className="mt-3 flex justify-center">
                    <StepDots />
                  </div>
                </div>
              </div>
            )}

            {/* ============ STEP 2 — THE QUESTIONS ============ */}
            {step === 2 && (
              <div className="flex-1 flex flex-col">
                <div className="flex-1 flex flex-col items-center justify-center text-center max-w-[600px] mx-auto w-full">
                  <div className="no-select" style={{ fontSize: 10, letterSpacing: "0.28em", color: GOLD, marginBottom: 8 }}>
                    WHAT TO EXPECT
                  </div>
                  <h1 style={{ fontFamily: "'Cormorant Garamond', serif", fontWeight: 500, fontSize: "clamp(24px, 3.6vw, 36px)", letterSpacing: "-0.01em", lineHeight: 1.1, color: NAVY }}>
                    She'll ask <span style={{ fontStyle: "italic" }}>four things</span>.
                  </h1>
                  <ul className="mt-6 flex flex-col gap-3.5 text-left mx-auto" style={{ maxWidth: 360 }}>
                    {["Your name", "A bit about you", "Your experience", "How you'd help our team"].map((t) => (
                      <li key={t} className="flex items-center gap-3" style={{ fontSize: 16, lineHeight: 1.4, color: "rgba(26,37,71,0.9)" }}>
                        <TinyCheck /><span>{t}</span>
                      </li>
                    ))}
                  </ul>
                  <p className="mt-6" style={{ fontSize: 14, color: INK_60 }}>
                    Your own words. No trick questions.
                  </p>
                </div>
                <div className="mt-4 sm:mt-5">
                  <PrimaryButton label="Got it" onTap={() => setWizardStep(3)} />
                  <div className="mt-3 flex justify-center">
                    <StepDots />
                  </div>
                </div>
              </div>
            )}

            {/* ============ STEP 3 — COMFORT + REVIEW ============ */}
            {step === 3 && (
              <div className="flex-1 flex flex-col">
                <div className="flex-1 flex flex-col items-center justify-center text-center max-w-[600px] mx-auto w-full">
                  <div className="no-select" style={{ fontSize: 10, letterSpacing: "0.28em", color: GOLD, marginBottom: 8 }}>
                    A FEW TIPS
                  </div>
                  <h1 style={{ fontFamily: "'Cormorant Garamond', serif", fontWeight: 500, fontSize: "clamp(24px, 3.6vw, 36px)", letterSpacing: "-0.01em", lineHeight: 1.1, color: NAVY }}>
                    A few <span style={{ fontStyle: "italic" }}>quick things</span>.
                  </h1>
                  <ul className="mt-6 flex flex-col gap-3.5 text-left mx-auto" style={{ maxWidth: 440 }}>
                    {[
                      "Find a comfortable, quiet space where you won't be distracted",
                      "Speak naturally, like a normal conversation",
                      "Earphones help if you have them",
                      "A member of our team reviews every interview",
                    ].map((t) => (
                      <li key={t} className="flex items-start gap-3" style={{ fontSize: 15, lineHeight: 1.45, color: "rgba(26,37,71,0.9)" }}>
                        <span className="mt-0.5"><TinyCheck /></span><span>{t}</span>
                      </li>
                    ))}
                  </ul>
                </div>
                <div className="mt-4 sm:mt-5">
                  <PrimaryButton label="Check my camera" onTap={() => setWizardStep(4)} />
                  <div className="mt-3 flex justify-center">
                    <StepDots />
                  </div>
                </div>
              </div>
            )}

            {/* ============ STEP 2 — CAMERA CHECK + BEGIN ============ */}
            {step === 4 && permBlocked && (
              <div className="flex-1 flex flex-col items-center justify-center text-center max-w-[520px] mx-auto w-full">
                <div className="no-select" style={{ fontSize: 10, letterSpacing: "0.28em", color: GOLD, marginBottom: 8 }}>
                  PERMISSION NEEDED
                </div>
                <h1 style={{ fontFamily: "'Cormorant Garamond', serif", fontWeight: 500, fontSize: "clamp(20px, 3vw, 30px)", letterSpacing: "-0.01em", lineHeight: 1.15, color: NAVY }}>
                  Camera or microphone access was <span style={{ fontStyle: "italic" }}>blocked</span>.
                </h1>

                <div className="mt-5 flex items-center gap-3 rounded-[10px] border px-3 py-2.5" style={{ borderColor: RULE, background: "rgba(243,238,226,0.5)" }}>
                  <svg width="36" height="36" viewBox="0 0 36 36" aria-hidden>
                    <rect x="2.5" y="9.5" width="31" height="17" rx="8.5" fill="#fff" stroke={NAVY} strokeWidth="1.2" />
                    <circle cx="10.5" cy="18" r="2.4" fill={NAVY} />
                    <path d="M16 14h13M16 18h11M16 22h9" stroke={NAVY} strokeWidth="1.2" strokeLinecap="round" />
                  </svg>
                  <div className="text-left" style={{ fontSize: 12.5, color: NAVY, lineHeight: 1.45 }}>
                    Look to the <strong>left of the website address</strong> at the top of your screen for the "site information" icon.
                  </div>
                </div>

                <ol className="mt-4 text-left max-w-[420px]" style={{ fontSize: 12.5, color: "rgba(26,37,71,0.85)", lineHeight: 1.6 }}>
                  <li><strong>1.</strong> Click "View site information" (the icon shown above).</li>
                  <li><strong>2.</strong> Set <strong>Camera</strong> and <strong>Microphone</strong> to <strong>Allow</strong>.</li>
                  <li><strong>3.</strong> Press <strong>Try Again</strong> below.</li>
                </ol>

                <div className="mt-5 w-full">
                  <PrimaryButton
                    label="Try Again"
                    onTap={() => { try { window.location.reload(); } catch { /* noop */ } }}
                  />
                </div>
              </div>
            )}

            {step === 4 && !permBlocked && (
              <div className="flex-1 flex flex-col">
                <div className="text-center max-w-[600px] mx-auto mb-3">
                  <div className="no-select" style={{ fontSize: 10, letterSpacing: "0.28em", color: GOLD, marginBottom: 4 }}>
                    CAMERA &amp; MICROPHONE
                  </div>
                  <h1 style={{ fontFamily: "'Cormorant Garamond', serif", fontWeight: 500, fontSize: "clamp(20px, 3vw, 30px)", letterSpacing: "-0.01em", lineHeight: 1.1, color: NAVY }}>
                    {previewReady
                      ? <>Looking good — <span style={{ fontStyle: "italic" }}>begin when ready</span>.</>
                      : checkingStage === "mic"
                        ? <>Testing your <span style={{ fontStyle: "italic" }}>microphone</span>…</>
                        : checkingStage === "camera"
                          ? <>Testing your <span style={{ fontStyle: "italic" }}>camera</span>…</>
                          : <>Let's check your <span style={{ fontStyle: "italic" }}>camera and microphone</span>.</>}
                  </h1>
                </div>

                <div className="flex-1 max-w-[560px] w-full mx-auto flex flex-col justify-center">
                  <CameraTestCard
                    ready={previewReady}
                    requesting={requesting}
                    error={permError}
                    micLevel={micLevel}
                    hasVideo={previewReady}
                    videoRef={videoPreviewRef}
                    checkingStage={checkingStage}
                    micReady={micSignalOk}
                    micNoSignalHint={micNoSignalHint}
                    audioInputs={audioInputs}
                    selectedMicId={selectedMicId}
                    onMicChange={handleMicDeviceChange}
                  />
                </div>

                {/* PRE-FLIGHT FRAME-LIVENESS WARNING (warn-only, never blocks Begin) */}
                {previewReady && frameWarn && (
                  <div
                    className="max-w-[560px] w-full mx-auto mt-3 rounded-[12px] border px-4 py-3 text-center"
                    style={{ borderColor: "#F59E0B", background: "rgba(245,158,11,0.08)" }}
                  >
                    <p style={{ fontSize: 12.5, color: "#B45309", fontWeight: 600, lineHeight: 1.45 }}>
                      We're not detecting your camera feed. Please check your camera isn't being used by
                      another app, then tap Test Camera &amp; Mic again.
                    </p>
                    <div className="mt-2 flex justify-center">
                      <button
                        type="button"
                        onClick={retryCameraPreflight}
                        className="rounded-full px-4 py-1.5"
                        style={{ fontSize: 12, fontWeight: 600, color: NAVY, border: `1px solid ${GOLD}`, background: "transparent" }}
                      >
                        Test Camera &amp; Mic again
                      </button>
                    </div>
                  </div>
                )}



                <div className="mt-4 sm:mt-5 flex flex-col items-center" style={{ position: "relative", zIndex: 60, isolation: "isolate" }}>
                  {/* PART 2 — 72h completion countdown + resume note. Ready screen ONLY.
                      Hidden when the link is no longer active; the already-completed
                      screen returns earlier so neither block can appear there. */}
                  {!linkInvalid && deadlineAt && (() => {
                    const msLeft = deadlineAt.getTime() - nowTick;
                    if (msLeft <= 0) {
                      // 72h passed but the link may still be valid (real expiry stays 3 days).
                      // Informational only — does NOT block Begin.
                      return (
                        <div className="text-center mb-2" style={{ fontSize: 12.5, color: "#B45309", fontWeight: 600, letterSpacing: "0.01em" }}>
                          Deadline passed — please complete as soon as possible
                        </div>
                      );
                    }
                    const totalMin = Math.floor(msLeft / 60000);
                    const h = Math.floor(totalMin / 60);
                    const m = totalMin % 60;
                    return (
                      <div className="text-center mb-2" style={{ fontSize: 12.5, color: NAVY, letterSpacing: "0.01em" }}>
                        Time remaining to complete: <span style={{ color: GOLD, fontWeight: 600 }}>{h}h {m}m</span>
                      </div>
                    );
                  })()}
                  {!linkInvalid && (
                    <p className="text-center mb-3" style={{ fontSize: 12.5, color: DANGER, fontWeight: 600, lineHeight: 1.45, maxWidth: 420 }}>
                      You haven't completed your interview yet. Please complete it now before your link expires.
                    </p>
                  )}
                  {!previewReady && <GuidanceArrow ready={previewReady} />}
                  {previewReady && !linkInvalid && (
                    <p className="text-center mb-2 no-select" style={{ fontSize: 12.5, color: INK_60, lineHeight: 1.45 }}>
                      {interviewer.name} will say hello in a moment.
                    </p>
                  )}
                  <PrimaryButton
                    dataAttr={previewReady && !linkInvalid ? "data-begin-button" : undefined}
                    label={
                      linkInvalid
                        ? "Link no longer active"
                        : previewReady
                          ? (!micSignalOk
                              ? "Say HELLO to continue"
                              : (minting ? "Preparing…" : "Begin Interview"))
                          : (requesting ? "Requesting permission…" : "Click to Test Camera & Mic")
                    }
                    disabled={requesting || linkInvalid || minting || (previewReady && !micSignalOk)}
                    onTap={() => {
                      if (linkInvalid) return;
                      if (!previewReady) { requestCameraAndMic(); return; }
                      if (!micSignalOk) return;
                      if (startingRef.current) return;
                      // ONE-TAP START (normal case): the token was already
                      // auto-prefetched on the ready screen, so prefetchReady is
                      // true. Run the EXISTING iOS-safe synchronous start path
                      // BYTE-FOR-BYTE unchanged: release the probe mic stream +
                      // AudioContext SYNCHRONOUSLY before handleStart. NO await.
                      if (prefetchReady) {
                        stopMicProbe();
                        handleStart();
                        return;
                      }
                      // SLOW-NETWORK FALLBACK (one tap, no second tap): the
                      // prefetch hasn't resolved yet. Show "Preparing…", wait for
                      // the SAME in-flight prefetch, then auto-continue to
                      // handleStart the instant it resolves. The user still taps
                      // only once.
                      if (minting) return;
                      setMinting(true);
                      void prefetchCall()
                        .then((call) => {
                          if (call?.access_token) {
                            stopMicProbe();
                            handleStart();
                          }
                        })
                        .finally(() => setMinting(false));
                    }}
                  />

                  <p className="mt-2 text-center" style={{ fontSize: 11, color: (linkInvalid || (previewReady && !micSignalOk)) ? DANGER : INK_60, fontWeight: (linkInvalid || (previewReady && !micSignalOk)) ? 600 : 400 }}>
                    {linkInvalid
                      ? <>This interview link is no longer active. Please contact the recruiter.</>
                      : previewReady
                        ? (micSignalOk
                            ? <>Take a breath — {interviewer.name} will introduce herself.</>
                            : <>We need to hear your microphone before we can start.</>)
                        : permError === "denied"
                          ? "Camera was blocked. Allow camera + microphone in your browser, then tap again."
                          : permError === "nodevice"
                            ? "We can't find a camera. Plug one in or enable it, then tap again."
                            : "We need your camera and microphone to continue."}
                  </p>
                  <div className="mt-3 flex justify-center">
                    <StepDots />
                  </div>
                </div>
              </div>
            )}
          </div>
        </section>
      </div>
    );
  }
  // ============================================================
  // SCREEN 2 — IN-CALL (live | uploading)
  // ============================================================
  if (status === "live" || status === "uploading") {
    return (
      <div className="screen-lock flex flex-col cream-grain overflow-hidden call-vh">
        <style>{STYLES}</style>
        <div
          className="flex-none w-full flex items-center justify-center gap-2 px-4 py-2.5 text-center no-select"
          style={{
            background: DEEP_RED,
            color: CREAM,
            boxShadow: "0 2px 10px rgba(15,23,48,0.22)",
          }}
        >
          <AlertTriangle size={16} strokeWidth={2.25} style={{ flexShrink: 0 }} aria-hidden="true" />
          <span style={{ fontSize: 12.5, fontWeight: 600, letterSpacing: "0.01em", lineHeight: 1.35 }}>
            INTERVIEW IN PROGRESS — Do not close the browser. It will disqualify your application.
          </span>
        </div>
        <HeaderCall elapsed={durationSec} onEnd={handleStop} uploading={status === "uploading"} />
        <main className="flex-1 min-h-0 px-3 sm:px-4 md:px-6 lg:px-8 py-3 sm:py-4 relative">
          {/* Responsive layout: column on mobile, 7/5 grid on sm+. ONE candidate <video>. */}
          <div className="flex flex-col sm:grid sm:grid-cols-12 gap-2.5 sm:gap-3 md:gap-4 h-full min-h-0">
            {/* Candidate tile — single instance, single ref, responsive container */}
            <div className="flex-none sm:col-span-7 min-h-0 h-[min(46vh,320px)] sm:h-auto">
              <CandidateVideo videoRef={videoInCallRef} hasStream={previewReady} />
            </div>
            {/* Christine area — desktop full tile with embedded captions */}
            <div className="hidden sm:block sm:col-span-5 min-h-0">
              <ChristineVideo speaking={christineSpeaking} volume={christineVolume} transcript={transcript} interviewer={interviewer} />
            </div>
            {/* Mobile-only Christine compact bar + caption box */}
            <div className="sm:hidden flex-none rounded-[14px] border px-3 py-2.5 flex items-center gap-3" style={{ borderColor: RULE, background: NAVY_DEEP }}>
              <div className={"relative grid place-items-center w-10 h-10 rounded-full shrink-0 " + (christineSpeaking ? "ring-speaking" : "")} style={{ background: "radial-gradient(120% 120% at 30% 25%, #243059 0%, #1a2547 55%, #11193a 100%)" }}>
                <span style={{ fontFamily: "'Cormorant Garamond', serif", fontWeight: 500, fontSize: 18, color: CREAM, lineHeight: 1 }}>{interviewer.initial}</span>
                <span className="rc absolute inset-0 rounded-full" style={{ border: `1.5px solid ${GOLD}` }} />
              </div>
              <div className="min-w-0 flex-1">
                <div className="flex items-center gap-2">
                  <span style={{ fontFamily: "'Cormorant Garamond', serif", fontWeight: 500, fontSize: 15, color: CREAM }}>{interviewer.name}</span>
                  <span style={{ color: "rgba(250,248,243,0.55)", fontSize: 9.5, letterSpacing: "0.18em" }}>{christineSpeaking ? "SPEAKING" : "LISTENING"}</span>
                </div>
                <div className="mt-1">
                  {christineSpeaking ? <VoiceWave color={GOLD_SOFT} bars={16} /> : <div className="h-3"><ListeningBars /></div>}
                </div>
              </div>
            </div>
            <div className="sm:hidden flex-1 min-h-0 rounded-[14px] border overflow-hidden flex flex-col" style={{ borderColor: RULE, background: CREAM }}>
              <CaptionFeed transcript={transcript} interviewerName={interviewer.name} tone="light" />
            </div>
          </div>
          {status === "uploading" && (
            <div className="absolute inset-0 grid place-items-center pointer-events-none">
              <div className="rounded-full px-5 py-2.5 border no-select" style={{ background: "rgba(250,248,243,0.96)", borderColor: RULE, boxShadow: "0 12px 36px rgba(15,23,48,0.18)" }}>
                <span style={{ fontFamily: "'Cormorant Garamond', serif", fontStyle: "italic", fontSize: 14, color: NAVY }}>finishing up…</span>
              </div>
            </div>
          )}
        </main>
      </div>
    );
  }
  // ============================================================
  // SCREEN 3 — THANK YOU
  // ============================================================
  if (status === "ended") {
    const mm = String(Math.floor(durationSec / 60)).padStart(2, "0");
    const ss = String(durationSec % 60).padStart(2, "0");
    return (
      <div className="screen-lock flex flex-col cream-grain ios-vh">
        <style>{STYLES}</style>
        <HeaderEntry />
        <main className="flex-1 px-5 md:px-10 grid place-items-center">
          <div className="max-w-[640px] w-full text-center py-12 sm:py-16">
            <div className="mx-auto mb-7 grid place-items-center">
              <GreenCheckAnim size={56} />
            </div>
            <div className="no-select" style={{ fontSize: 10, letterSpacing: "0.28em", color: GOLD, marginBottom: 12 }}>INTERVIEW COMPLETE</div>
            <h1 style={{ fontFamily: "'Cormorant Garamond', serif", fontWeight: 500, fontSize: "clamp(34px, 5.4vw, 56px)", letterSpacing: "-0.01em", lineHeight: 1.06, color: NAVY, marginBottom: 20 }}>
              Thank you for <span style={{ fontFamily: "'Cormorant Garamond', serif", fontStyle: "italic", fontWeight: 500 }}>your time</span>.
            </h1>
            <p style={{ color: "rgba(26,37,71,0.85)", fontSize: 16, lineHeight: 1.65, maxWidth: 520, margin: "0 auto" }}>
              A member of our hiring team will review your interview. If you're selected, we'll be in touch within{" "}
              <span style={{ color: NAVY, fontWeight: 500 }}>5–7 business days</span>. Please check your spam folder, as our messages occasionally land there.
            </p>
            <p className="no-select" style={{ color: SUCCESS, fontSize: 15, fontWeight: 600, marginTop: 18, lineHeight: 1.5 }}>
              You can close your browser now.
            </p>
            <div className="mt-7 inline-flex items-center gap-3" style={{ fontSize: 12, color: INK_60 }}>
              <span className="h-px w-10" style={{ background: RULE }} />
              <span style={{ fontFamily: "'Cormorant Garamond', serif", fontStyle: "italic" }}>You may now close this window.</span>
              <span className="h-px w-10" style={{ background: RULE }} />
            </div>
            <div className="mt-10 mx-auto max-w-[460px] text-left border rounded-[12px] p-4 sm:p-5" style={{ borderColor: RULE, background: "rgba(243,238,226,0.5)" }}>
              <div className="flex items-baseline justify-between mb-3 pb-2 border-b" style={{ borderColor: RULE }}>
                <span className="no-select" style={{ fontSize: 10, letterSpacing: "0.22em", color: INK_60 }}>SESSION SUMMARY</span>
              </div>
              <dl className="grid grid-cols-2 gap-y-2 gap-x-6" style={{ fontSize: 12.5 }}>
                <dt style={{ color: INK_60 }}>Interviewer</dt><dd style={{ color: NAVY }}>{interviewer.name} (AI) · HR</dd>
                <dt style={{ color: INK_60 }}>Duration</dt><dd style={{ color: NAVY }}>{mm}:{ss}</dd>
                <dt style={{ color: INK_60 }}>Recording</dt><dd style={{ color: NAVY }}>Saved</dd>
                <dt style={{ color: INK_60 }}>Decision window</dt><dd style={{ color: NAVY }}>5–7 business days</dd>
              </dl>
              {/* Phase 3.3 — tracking link */}
              <div className="mt-4 pt-3 border-t" style={{ borderColor: RULE }}>
                <div style={{ fontSize: 10, letterSpacing: "0.22em", color: INK_60, marginBottom: 6 }}>
                  TRACK YOUR APPLICATION STATUS HERE
                </div>
                {trackingToken ? (
                  <div className="flex items-center gap-2">
                    <a
                      href={`/track/${trackingToken}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      style={{ color: GOLD, fontSize: 12.5, wordBreak: "break-all", textDecoration: "underline" }}
                    >
                      {`${window.location.origin}/track/${trackingToken}`}
                    </a>
                    <button
                      type="button"
                      onClick={async () => {
                        try {
                          await navigator.clipboard.writeText(`${window.location.origin}/track/${trackingToken}`);
                          setTrackingCopied(true);
                          window.setTimeout(() => setTrackingCopied(false), 1800);
                        } catch { /* noop */ }
                      }}
                      style={{
                        flexShrink: 0,
                        padding: "4px 10px",
                        fontSize: 10,
                        letterSpacing: "0.18em",
                        textTransform: "uppercase",
                        color: NAVY,
                        border: `1px solid ${RULE}`,
                        borderRadius: 999,
                        background: "transparent",
                        cursor: "pointer",
                      }}
                    >
                      {trackingCopied ? "Copied" : "Copy"}
                    </button>
                  </div>
                ) : (
                  <div style={{ fontSize: 12.5, color: INK_60 }}>
                    We'll email you a link to track your application shortly.
                  </div>
                )}
              </div>
            </div>
          </div>
        </main>
        <Footer />
      </div>
    );
  }
  // ============================================================
  // CAMERA BLOCKED
  // ============================================================
  if (status === "camera_blocked") {
    return (
      <div className="screen-lock flex flex-col cream-grain ios-vh">
        <style>{STYLES}</style>
        <HeaderEntry />
        <main className="flex-1 grid place-items-center px-6 py-10">
          <div className="max-w-[480px] text-center space-y-4">
            <div className="no-select" style={{ fontSize: 10, letterSpacing: "0.28em", color: GOLD }}>CAMERA REQUIRED</div>
            <h2 style={{ fontFamily: "'Cormorant Garamond', serif", fontWeight: 500, fontSize: 32, color: NAVY, lineHeight: 1.1 }}>
              We need your camera on
            </h2>
            <p style={{ fontSize: 14, color: INK_60, lineHeight: 1.6 }}>
              Please allow camera access in your browser and try again. Your video is recorded for hiring review only.
            </p>
            <button onClick={() => { setStatus("idle"); setPreviewReady(false); setWizardStep(1); }} className="btn-tap rounded-full"
              style={{ padding: "12px 28px", background: NAVY, color: CREAM, fontSize: 12, letterSpacing: "0.22em", textTransform: "uppercase", boxShadow: "0 8px 28px rgba(15,23,48,0.18)", touchAction: "manipulation", position: "relative", zIndex: 5 }}>
              Try Again
            </button>
          </div>
        </main>
      </div>
    );
  }
  // ============================================================
  // SILENT MIC — joined Retell but candidate's mic sent no audio
  // ============================================================
  if (status === "silent_mic") {
    return (
      <div className="screen-lock flex flex-col cream-grain ios-vh">
        <style>{STYLES}</style>
        <HeaderEntry />
        <main className="flex-1 grid place-items-center px-6 py-10">
          <div className="max-w-[520px] text-center space-y-5">
            <div className="no-select" style={{ fontSize: 10, letterSpacing: "0.28em", color: GOLD }}>MICROPHONE ISSUE</div>
            <h2 style={{ fontFamily: "'Cormorant Garamond', serif", fontWeight: 500, fontSize: 30, color: NAVY, lineHeight: 1.15 }}>
              We couldn't hear your microphone
            </h2>
            <p style={{ fontSize: 14, color: INK_60, lineHeight: 1.65 }}>
              Please check your mic isn't muted, try a different microphone if needed, and tap Retry.
            </p>
            <button onClick={handleRetryConnect} className="btn-tap rounded-full"
              style={{ padding: "12px 32px", background: NAVY, color: CREAM, fontSize: 12, letterSpacing: "0.22em", textTransform: "uppercase", boxShadow: "0 8px 28px rgba(15,23,48,0.18)", touchAction: "manipulation", position: "relative", zIndex: 5, minHeight: 44 }}>
              Retry
            </button>
          </div>
        </main>
      </div>
    );
  }
  // ============================================================
  // ALREADY COMPLETED — GLITCH 8: this response already has a real completed interview.
  // No retry button. No fault language.
  // ============================================================
  if (status === "already_completed") {
    return (
      <div className="screen-lock flex flex-col cream-grain ios-vh">
        <style>{STYLES}</style>
        <HeaderEntry />
        <main className="flex-1 grid place-items-center px-6 py-10">
          <div className="max-w-[520px] text-center space-y-5">
            <div className="no-select" style={{ fontSize: 10, letterSpacing: "0.28em", color: GOLD }}>INTERVIEW RECEIVED</div>
            <h2 style={{ fontFamily: "'Cormorant Garamond', serif", fontWeight: 500, fontSize: 30, color: NAVY, lineHeight: 1.15 }}>
              You've already completed this interview
            </h2>
            <p style={{ fontSize: 14, color: INK_60, lineHeight: 1.65 }}>
              Thank you — we've received your interview and our team is reviewing it. You'll hear from us within 5–7 business days. You can close this page.
            </p>
          </div>
        </main>
      </div>
    );
  }

  // ============================================================
  // CONNECT FAILED — calm, recoverable fallback (15s timeout / retell error)
  // ============================================================
  if (status === "connect_failed") {
    return (
      <div className="screen-lock flex flex-col cream-grain ios-vh">
        <style>{STYLES}</style>
        <HeaderEntry />
        <main className="flex-1 grid place-items-center px-6 py-10">
          <div className="max-w-[520px] text-center space-y-5">
            <div className="no-select" style={{ fontSize: 10, letterSpacing: "0.28em", color: GOLD }}>CONNECTION ISSUE</div>
            <h2 style={{ fontFamily: "'Cormorant Garamond', serif", fontWeight: 500, fontSize: 30, color: NAVY, lineHeight: 1.15 }}>
              We're having trouble connecting your interview
            </h2>
            <p style={{ fontSize: 14, color: INK_60, lineHeight: 1.65 }}>
              This is usually a connection or device issue, not you. Please tap Retry. If it keeps happening, don't worry — our team will reach out to help you reschedule.
            </p>
            <button onClick={handleRetryConnect} className="btn-tap rounded-full"
              style={{ padding: "12px 32px", background: NAVY, color: CREAM, fontSize: 12, letterSpacing: "0.22em", textTransform: "uppercase", boxShadow: "0 8px 28px rgba(15,23,48,0.18)", touchAction: "manipulation", position: "relative", zIndex: 5 }}>
              Retry
            </button>
          </div>
        </main>
      </div>
    );
  }
  // ============================================================
  // ERROR
  // ============================================================
  return (
    <div className="screen-lock flex flex-col cream-grain ios-vh">
      <style>{STYLES}</style>
      <HeaderEntry />
      <main className="flex-1 grid place-items-center px-6 py-10">
        <div className="max-w-[480px] text-center space-y-4">
          <div className="no-select" style={{ fontSize: 10, letterSpacing: "0.28em", color: GOLD }}>SOMETHING WENT WRONG</div>
          <p style={{ fontSize: 14, color: INK_60 }}>{errorMsg}</p>
          <button onClick={() => { setStatus("idle"); }} className="btn-tap rounded-full"
            style={{ padding: "12px 28px", background: NAVY, color: CREAM, fontSize: 12, letterSpacing: "0.22em", textTransform: "uppercase", boxShadow: "0 8px 28px rgba(15,23,48,0.18)", touchAction: "manipulation", position: "relative", zIndex: 5 }}>
            Try Again
          </button>
        </div>
      </main>
    </div>
  );
}
