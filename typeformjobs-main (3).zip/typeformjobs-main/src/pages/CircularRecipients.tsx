import { useEffect, useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card } from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { toast } from "@/hooks/use-toast";
import { ArrowLeft, Trash2, UserPlus, Search, Users, Send } from "lucide-react";

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

type Recipient = {
  id: string;
  name: string | null;
  email: string;
  created_at: string;
  last_sent_at: string | null;
};

export default function CircularRecipients() {
  const navigate = useNavigate();
  const [rows, setRows] = useState<Recipient[]>([]);
  const [loading, setLoading] = useState(true);
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [saving, setSaving] = useState(false);
  const [search, setSearch] = useState("");
  const [pendingDelete, setPendingDelete] = useState<Recipient | null>(null);

  const load = async () => {
    setLoading(true);
    const { data, error } = await supabase
      .from("circular_recipients" as any)
      .select("id, name, email, created_at, last_sent_at")
      .order("created_at", { ascending: false });
    if (error) {
      toast({ title: "Failed to load recipients", description: error.message, variant: "destructive" });
    } else {
      setRows((data as any as Recipient[]) || []);
    }
    setLoading(false);
  };

  useEffect(() => { load(); }, []);

  const addRecipient = async (e: React.FormEvent) => {
    e.preventDefault();
    const cleanEmail = email.trim();
    const cleanName = name.trim();
    if (!EMAIL_RE.test(cleanEmail)) {
      toast({ title: "Invalid email", description: "Enter a valid email address.", variant: "destructive" });
      return;
    }
    setSaving(true);
    // Dedupe on lower(email): if the person already exists, update the name;
    // otherwise insert. The DB also enforces this via a unique lower(email) index.
    const { data: existing } = await supabase
      .from("circular_recipients" as any)
      .select("id")
      .ilike("email", cleanEmail)
      .maybeSingle();

    let error;
    if (existing) {
      ({ error } = await supabase
        .from("circular_recipients" as any)
        .update({ name: cleanName || null })
        .eq("id", (existing as any).id));
    } else {
      ({ error } = await supabase
        .from("circular_recipients" as any)
        .insert({ name: cleanName || null, email: cleanEmail }));
    }

    if (error) {
      toast({ title: "Could not save", description: error.message, variant: "destructive" });
      setSaving(false);
      return;
    }
    toast({
      title: existing ? "Recipient updated" : "Recipient saved",
      description: cleanEmail,
    });
    setName("");
    setEmail("");
    setSaving(false);
    load();
  };

  const confirmDelete = async () => {
    if (!pendingDelete) return;
    const { error } = await supabase
      .from("circular_recipients" as any)
      .delete()
      .eq("id", pendingDelete.id);
    if (error) {
      toast({ title: "Delete failed", description: error.message, variant: "destructive" });
    } else {
      toast({ title: "Recipient removed", description: pendingDelete.email });
      setRows((prev) => prev.filter((r) => r.id !== pendingDelete.id));
    }
    setPendingDelete(null);
  };

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    if (!q) return rows;
    return rows.filter(
      (r) =>
        (r.name || "").toLowerCase().includes(q) ||
        r.email.toLowerCase().includes(q),
    );
  }, [rows, search]);

  const fmt = (v: string | null) =>
    v ? new Date(v).toLocaleDateString(undefined, { year: "numeric", month: "short", day: "numeric" }) : "—";

  return (
    <div className="min-h-screen bg-background">
      <div className="max-w-4xl mx-auto px-4 py-6 space-y-6">
        <div className="flex items-center gap-3">
          <Button variant="ghost" size="sm" onClick={() => navigate("/dashboard")}>
            <ArrowLeft className="h-4 w-4 mr-1.5" /> Back
          </Button>
          <div className="flex items-center gap-2">
            <Users className="h-5 w-5 text-primary" />
            <h1 className="text-xl font-semibold">Circular Recipients</h1>
          </div>
          <Button size="sm" className="ml-auto" onClick={() => navigate("/dashboard/circulars/new")}>
            <Send className="h-4 w-4 mr-1.5" /> New Circular
          </Button>
        </div>

        <p className="text-sm text-muted-foreground">
          A standalone, auto-growing contact list for Circular Notices. Add people here once and reuse them.
          Adding the same email again will not create a duplicate.
        </p>

        <Card className="p-4">
          <form onSubmit={addRecipient} className="grid gap-3 sm:grid-cols-[1fr_1fr_auto] sm:items-end">
            <div className="space-y-1.5">
              <Label htmlFor="cr-name">Name</Label>
              <Input id="cr-name" value={name} onChange={(e) => setName(e.target.value)} placeholder="Juliet" />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="cr-email">Email</Label>
              <Input
                id="cr-email"
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="juliet@gmail.com"
                required
              />
            </div>
            <Button type="submit" disabled={saving}>
              <UserPlus className="h-4 w-4 mr-1.5" />
              {saving ? "Saving…" : "Add"}
            </Button>
          </form>
        </Card>

        <div className="relative">
          <Search className="h-4 w-4 absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
          <Input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search by name or email…"
            className="pl-9"
          />
        </div>

        <Card>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Name</TableHead>
                <TableHead>Email</TableHead>
                <TableHead>Last sent</TableHead>
                <TableHead className="w-12" />
              </TableRow>
            </TableHeader>
            <TableBody>
              {loading ? (
                <TableRow>
                  <TableCell colSpan={4} className="text-center text-muted-foreground py-8">
                    Loading…
                  </TableCell>
                </TableRow>
              ) : filtered.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={4} className="text-center text-muted-foreground py-8">
                    {rows.length === 0 ? "No recipients yet. Add one above." : "No matches."}
                  </TableCell>
                </TableRow>
              ) : (
                filtered.map((r) => (
                  <TableRow key={r.id}>
                    <TableCell className="font-medium">{r.name || "—"}</TableCell>
                    <TableCell className="font-mono text-sm">{r.email}</TableCell>
                    <TableCell className="text-muted-foreground">{fmt(r.last_sent_at)}</TableCell>
                    <TableCell>
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => setPendingDelete(r)}
                        aria-label={`Remove ${r.email}`}
                      >
                        <Trash2 className="h-4 w-4 text-destructive" />
                      </Button>
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </Card>

        <p className="text-xs text-muted-foreground">
          {rows.length} saved recipient{rows.length === 1 ? "" : "s"}.
        </p>
      </div>

      <AlertDialog open={!!pendingDelete} onOpenChange={(o) => !o && setPendingDelete(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Remove recipient?</AlertDialogTitle>
            <AlertDialogDescription>
              This removes <span className="font-mono">{pendingDelete?.email}</span> from the saved list.
              Past circulars are not affected.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={confirmDelete}>Remove</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
