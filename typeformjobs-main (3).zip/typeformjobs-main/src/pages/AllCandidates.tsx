import { useEffect, useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from "@/components/ui/table";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import { Search, ArrowLeft, User as UserIcon, ExternalLink, FileText, Eye } from "lucide-react";
import {
  type CandidateAction,
  detectContactQuestionIds,
} from "@/lib/candidateActions";
import { ActionsCell } from "@/components/action-dialogs/ActionsCell";
import { SelfieThumb, FilePreviewDialog, parseFilePath } from "@/components/FilePreview";

type Form = { id: string; title: string };
type Question = { id: string; form_id: string; type: string; label: string; order_index?: number };
type Response = {
  id: string;
  form_id: string;
  applicant_id: string;
  submitted_at: string;
  scheduled_at: string | null;
  status: string | null;
  override_email: string | null;
};
type Answer = {
  response_id: string;
  question_id: string;
  answer_text: string | null;
  file_url: string | null;
};

type StatusKey =
  | "applied" | "scheduled" | "round1_sent" | "round2_sent" | "offer_sent" | "signed";

const STATUS_LABEL: Record<StatusKey, string> = {
  applied: "Applied", scheduled: "Scheduled", round1_sent: "Round 1 sent",
  round2_sent: "Round 2 sent", offer_sent: "Offer sent", signed: "Signed",
};

const STATUS_COLOR: Record<StatusKey, string> = {
  applied: "bg-slate-100 text-slate-800",
  scheduled: "bg-amber-100 text-amber-900",
  round1_sent: "bg-blue-100 text-blue-800",
  round2_sent: "bg-indigo-100 text-indigo-800",
  offer_sent: "bg-purple-100 text-purple-800",
  signed: "bg-green-100 text-green-800",
};

const deriveStatus = (r: Response, a: CandidateAction | null): StatusKey => {
  if (a?.offer_status === "signed") return "signed";
  if (a?.offer_status === "sent") return "offer_sent";
  if (a?.round2_status === "sent") return "round2_sent";
  if (a?.round1_status === "sent") return "round1_sent";
  if (r.scheduled_at) return "scheduled";
  return "applied";
};

const fmtDate = (iso: string) =>
  new Date(iso).toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" });
const fmtDateTime = (iso: string) =>
  new Date(iso).toLocaleString("en-US", { month: "short", day: "numeric", hour: "numeric", minute: "2-digit" });

type SortKey = "date_desc" | "date_asc" | "name_asc" | "status";

const AllCandidates = () => {
  const navigate = useNavigate();
  const { user } = useAuth();
  const [loading, setLoading] = useState(true);
  const [forms, setForms] = useState<Form[]>([]);
  const [questions, setQuestions] = useState<Question[]>([]);
  const [responses, setResponses] = useState<Response[]>([]);
  const [answers, setAnswers] = useState<Answer[]>([]);
  const [actionsByResp, setActionsByResp] = useState<Record<string, CandidateAction>>({});
  const [signedPdfByOffer, setSignedPdfByOffer] = useState<Record<string, string>>({});
  const [previewFile, setPreviewFile] = useState<string | null>(null);

  const [formFilter, setFormFilter] = useState<string>("all");
  const [statusFilter, setStatusFilter] = useState<string>("all");
  const [search, setSearch] = useState("");
  const [sort, setSort] = useState<SortKey>("date_desc");

  const load = async () => {
    setLoading(true);
    const [{ data: fs }, { data: qs }, { data: rs }] = await Promise.all([
      supabase.from("forms").select("id, title").order("title"),
      supabase.from("questions").select("id, form_id, type, label, order_index"),
      supabase
        .from("responses")
        .select("id, form_id, applicant_id, submitted_at, scheduled_at, status, override_email")
        .order("submitted_at", { ascending: false })
        .limit(1000),
    ]);
    setForms((fs || []) as Form[]);
    setQuestions((qs || []) as Question[]);
    setResponses((rs || []) as Response[]);

    if (rs && rs.length) {
      const respIds = rs.map((r: any) => r.id);
      const { data: ans } = await supabase
        .from("answers")
        .select("response_id, question_id, answer_text, file_url")
        .in("response_id", respIds);
      setAnswers((ans || []) as Answer[]);

      const { data: acts } = await supabase
        .from("candidate_actions").select("*").in("response_id", respIds);
      const map: Record<string, CandidateAction> = {};
      for (const a of (acts || []) as CandidateAction[]) {
        if (a.response_id) map[a.response_id] = a;
      }
      setActionsByResp(map);

      const offerIds = Object.values(map)
        .filter((a) => a.offer_status === "signed" && a.job_offer_id)
        .map((a) => a.job_offer_id!) as string[];
      if (offerIds.length) {
        const { data: offers } = await supabase
          .from("job_offers").select("id, signed_pdf_url").in("id", offerIds);
        const om: Record<string, string> = {};
        for (const o of (offers || []) as any[]) if (o.signed_pdf_url) om[o.id] = o.signed_pdf_url;
        setSignedPdfByOffer(om);
      }
    } else {
      setAnswers([]); setActionsByResp({}); setSignedPdfByOffer({});
    }
    setLoading(false);
  };

  useEffect(() => { document.title = "All Candidates — EIA"; load(); }, []);

  const formTitleById = useMemo(() => {
    const m: Record<string, string> = {};
    for (const f of forms) m[f.id] = f.title;
    return m;
  }, [forms]);

  // Per-form: contact qids, selfie qid, resume qid.
  // Photos & resumes are both stored as type=file_upload in this project,
  // so we disambiguate by label keywords.
  const formQMaps = useMemo(() => {
    const byForm: Record<string, Question[]> = {};
    for (const q of questions) (byForm[q.form_id] = byForm[q.form_id] || []).push(q);
    const map: Record<string, {
      nameQid?: string; emailQid?: string; selfieQid?: string; resumeQid?: string; onlinejobsQid?: string;
    }> = {};
    const PHOTO_RE = /(photo|selfie|picture|headshot|portrait|image)/i;
    const RESUME_RE = /(resume|cv|curriculum)/i;
    const OJ_RE = /(onlinejob|online\s*jobs?|oj\s*profile|onlinejobs\.ph)/i;
    for (const [fid, qs] of Object.entries(byForm)) {
      const contacts = detectContactQuestionIds(
        qs.map((q) => ({ id: q.id, type: q.type, label: q.label })),
      );
      const sorted = [...qs].sort((a, b) => (a.order_index || 0) - (b.order_index || 0));
      const uploads = sorted.filter((q) => q.type === "file_upload" || q.type === "selfie");
      const selfieQ =
        uploads.find((q) => q.type === "selfie") ||
        uploads.find((q) => PHOTO_RE.test(q.label || ""));
      const resumeQ = uploads.find((q) => RESUME_RE.test(q.label || ""));
      const onlinejobsQ = sorted.find((q) => OJ_RE.test(q.label || ""));
      map[fid] = {
        ...contacts,
        selfieQid: selfieQ?.id,
        resumeQid: resumeQ?.id,
        onlinejobsQid: onlinejobsQ?.id,
      };
    }
    return map;
  }, [questions]);

  const findAnswer = (responseId: string, qid?: string) =>
    qid ? answers.find((a) => a.response_id === responseId && a.question_id === qid) : undefined;

  type Row = {
    response: Response;
    name: string;
    email: string;
    selfieUrl?: string;
    resumeUrl?: string;
    onlinejobsUrl?: string;
    formTitle: string;
    status: StatusKey;
    action: CandidateAction | null;
    scheduledIso: string | null;
  };

  const rows: Row[] = useMemo(() => {
    return responses.map((r) => {
      const qids = formQMaps[r.form_id] || {};
      const nameA = findAnswer(r.id, qids.nameQid);
      const emailA = findAnswer(r.id, qids.emailQid);
      const selfieA = findAnswer(r.id, qids.selfieQid);
      const resumeA = findAnswer(r.id, qids.resumeQid);
      const ojA = findAnswer(r.id, (qids as any).onlinejobsQid);
      const action = actionsByResp[r.id] || null;
      const status = deriveStatus(r, action);
      const scheduledIso = r.scheduled_at || action?.round1_appointment_date || null;
      const answerEmail = (emailA?.answer_text || "").trim();
      const effectiveEmail = (r.override_email || answerEmail || "").trim();
      const ojRaw = (ojA?.answer_text || "").trim();
      return {
        response: r,
        name: (nameA?.answer_text || "").trim(),
        email: effectiveEmail,
        selfieUrl: selfieA?.file_url || undefined,
        resumeUrl: resumeA?.file_url || undefined,
        onlinejobsUrl: ojRaw || undefined,
        formTitle: formTitleById[r.form_id] || "—",
        status, action, scheduledIso,
      };
    });
  }, [responses, answers, formQMaps, actionsByResp, formTitleById]);

  const filtered: Row[] = useMemo(() => {
    const q = search.trim().toLowerCase();
    let list = rows.filter((row) => {
      if (formFilter !== "all" && row.response.form_id !== formFilter) return false;
      if (statusFilter !== "all" && row.status !== statusFilter) return false;
      if (q && !(row.name.toLowerCase().includes(q) || row.email.toLowerCase().includes(q))) return false;
      return true;
    });
    switch (sort) {
      case "date_asc":
        list = [...list].sort((a, b) => +new Date(a.response.submitted_at) - +new Date(b.response.submitted_at));
        break;
      case "name_asc":
        list = [...list].sort((a, b) => (a.name || "").localeCompare(b.name || ""));
        break;
      case "status":
        list = [...list].sort((a, b) => a.status.localeCompare(b.status));
        break;
      default:
        list = [...list].sort((a, b) => +new Date(b.response.submitted_at) - +new Date(a.response.submitted_at));
    }
    return list;
  }, [rows, formFilter, statusFilter, search, sort]);

  const handleActionChanged = (responseId: string, updated: CandidateAction) => {
    setActionsByResp((prev) => ({ ...prev, [responseId]: updated }));
  };

  return (
    <div className="min-h-screen bg-background">
      <header className="bg-background" style={{ borderBottom: "1px solid #e1e4ec" }}>
        <div className="max-w-[1400px] mx-auto px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Button variant="ghost" size="sm" onClick={() => navigate("/dashboard")}>
              <ArrowLeft className="h-4 w-4 mr-1.5" /> Dashboard
            </Button>
            <h1 className="text-lg font-semibold" style={{ color: "#1a2547" }}>All Candidates</h1>
          </div>
          <span className="text-xs text-muted-foreground">{user?.email}</span>
        </div>
      </header>

      <main className="max-w-[1400px] mx-auto px-6 py-8">
        <div className="flex flex-wrap items-center gap-3 mb-6">
          <div className="relative flex-1 min-w-[220px]">
            <Search className="h-4 w-4 absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
            <Input
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search by name or email"
              className="pl-9"
            />
          </div>
          <Select value={formFilter} onValueChange={setFormFilter}>
            <SelectTrigger className="w-[220px]"><SelectValue placeholder="All forms" /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All forms</SelectItem>
              {forms.map((f) => (
                <SelectItem key={f.id} value={f.id}>{f.title}</SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Select value={statusFilter} onValueChange={setStatusFilter}>
            <SelectTrigger className="w-[180px]"><SelectValue placeholder="All statuses" /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All statuses</SelectItem>
              {(Object.keys(STATUS_LABEL) as StatusKey[]).map((k) => (
                <SelectItem key={k} value={k}>{STATUS_LABEL[k]}</SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Select value={sort} onValueChange={(v) => setSort(v as SortKey)}>
            <SelectTrigger className="w-[180px]"><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="date_desc">Newest first</SelectItem>
              <SelectItem value="date_asc">Oldest first</SelectItem>
              <SelectItem value="name_asc">Name (A–Z)</SelectItem>
              <SelectItem value="status">Status</SelectItem>
            </SelectContent>
          </Select>
          <div className="ml-auto text-sm text-muted-foreground">
            {loading ? "Loading…" : `${filtered.length} candidate${filtered.length === 1 ? "" : "s"}`}
          </div>
        </div>

        <div className="border border-border rounded-lg bg-card overflow-hidden">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead className="w-[100px]">Photo</TableHead>
                <TableHead>Resume</TableHead>
                <TableHead>Email</TableHead>
                <TableHead>Name</TableHead>
                <TableHead>Position / Form</TableHead>
                <TableHead>Applied</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Interview</TableHead>
                <TableHead className="text-center w-[260px]">Actions</TableHead>
                <TableHead>OnlineJobs</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {loading ? (
                Array.from({ length: 6 }).map((_, i) => (
                  <TableRow key={i}>
                    {Array.from({ length: 10 }).map((__, j) => (
                      <TableCell key={j}><Skeleton className="h-6 w-full" /></TableCell>
                    ))}
                  </TableRow>
                ))
              ) : filtered.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={10} className="text-center py-12 text-sm text-muted-foreground">
                    No candidates match the current filters.
                  </TableCell>
                </TableRow>
              ) : (
                filtered.map((row) => {
                  const qids = formQMaps[row.response.form_id] || {};
                  const signedUrl = row.action?.job_offer_id
                    ? signedPdfByOffer[row.action.job_offer_id]
                    : undefined;
                  const resumeName = row.resumeUrl ? parseFilePath(row.resumeUrl).name : "";
                  return (
                    <TableRow key={row.response.id}>
                      <TableCell>
                        {row.selfieUrl ? (
                          <SelfieThumb
                            file_url={row.selfieUrl}
                            size={80}
                            onPreview={() => setPreviewFile(row.selfieUrl!)}
                          />
                        ) : (
                          <div className="h-20 w-20 rounded-lg bg-secondary border border-border flex items-center justify-center text-muted-foreground">
                            <UserIcon className="h-6 w-6" />
                          </div>
                        )}
                      </TableCell>
                      <TableCell>
                        {row.resumeUrl ? (
                          <button
                            type="button"
                            onClick={() => setPreviewFile(row.resumeUrl!)}
                            className="inline-flex items-center gap-1.5 text-sm text-primary hover:underline max-w-[180px]"
                            title={resumeName}
                          >
                            <FileText className="h-4 w-4 shrink-0" />
                            <span className="truncate">View Resume</span>
                          </button>
                        ) : (
                          <span className="text-xs text-muted-foreground">No resume</span>
                        )}
                      </TableCell>
                      <TableCell>
                        <div className="text-sm text-foreground break-all">{row.email || "—"}</div>
                      </TableCell>
                      <TableCell>
                        <div className="font-medium">{row.name || <span className="text-muted-foreground italic">No name</span>}</div>
                      </TableCell>
                      <TableCell>
                        <button
                          className="inline-flex items-center gap-1 text-sm hover:underline"
                          onClick={() => navigate(`/forms/${row.response.form_id}/results`)}
                        >
                          {row.formTitle}
                          <ExternalLink className="h-3 w-3" />
                        </button>
                      </TableCell>
                      <TableCell className="text-sm text-muted-foreground">
                        {fmtDate(row.response.submitted_at)}
                      </TableCell>
                      <TableCell>
                        <Badge className={`${STATUS_COLOR[row.status]} hover:${STATUS_COLOR[row.status]} border-0`}>
                          {STATUS_LABEL[row.status]}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-sm text-muted-foreground">
                        {row.scheduledIso ? fmtDateTime(row.scheduledIso) : "—"}
                      </TableCell>
                      <TableCell>
                        <div className="flex items-center justify-center gap-2">
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() =>
                              navigate(`/forms/${row.response.form_id}/results?candidate=${row.response.id}`)
                            }
                            title="View full application"
                          >
                            <Eye className="h-4 w-4 mr-1.5" /> View
                          </Button>
                          <ActionsCell
                            formId={row.response.form_id}
                            responseId={row.response.id}
                            applicantId={row.response.applicant_id}
                            candidateName={row.name}
                            candidateEmail={row.email}
                            nameQid={qids.nameQid}
                            emailQid={qids.emailQid}
                            action={row.action}
                            signedPdfUrl={signedUrl}
                            size="sm"
                            onChanged={(a) => handleActionChanged(row.response.id, a)}
                            onContactUpdated={() => load()}
                          />
                        </div>
                      </TableCell>
                      <TableCell>
                        {row.onlinejobsUrl ? (
                          <a
                            href={/^https?:\/\//i.test(row.onlinejobsUrl) ? row.onlinejobsUrl : `https://${row.onlinejobsUrl}`}
                            target="_blank"
                            rel="noreferrer"
                            className="inline-flex items-center gap-1 text-sm text-primary hover:underline"
                          >
                            Profile <ExternalLink className="h-3 w-3" />
                          </a>
                        ) : (
                          <span className="text-xs text-muted-foreground">—</span>
                        )}
                      </TableCell>
                    </TableRow>
                  );
                })
              )}
            </TableBody>
          </Table>
        </div>
      </main>

      <FilePreviewDialog file_url={previewFile} onClose={() => setPreviewFile(null)} />
    </div>
  );
};

export default AllCandidates;
