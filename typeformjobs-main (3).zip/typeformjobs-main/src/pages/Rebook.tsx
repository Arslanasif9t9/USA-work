import { useEffect, useMemo, useState } from "react";
import { useParams } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Loader2, CheckCircle2, CalendarOff } from "lucide-react";
import { toast } from "sonner";
import { cn } from "@/lib/utils";
import EiaWordmark from "@/components/EiaWordmark";

const NAVY = "#1a2547";
const GOLD = "#b08d57";
const CREAM = "#faf8f3";

type SlotItem = { id: string; slot_start: string; display_time: string; available: boolean };
type Payload = {
  ooo_active?: boolean; ooo_end?: string;
  extended_window?: boolean;
  visible_days?: number;
  curated?: boolean;
  slots_by_date?: Record<string, SlotItem[]>;
};
type TokenInfo = {
  valid: boolean; reason?: string;
  stage?: "reschedule" | "round1" | "round2" | "ai_scheduled";
  candidate_name?: string; candidate_email?: string;
  expires_at?: string; position_title?: string | null;
  has_curated?: boolean;
};

const fmt = (opts: Intl.DateTimeFormatOptions) =>
  new Intl.DateTimeFormat("en-US", { timeZone: "Asia/Manila", ...opts });

const tabLabel = (dateStr: string) => {
  const [y, m, d] = dateStr.split("-").map(Number);
  const noonUtc = new Date(Date.UTC(y, m - 1, d, 4));
  return {
    top: fmt({ weekday: "short" }).format(noonUtc),
    bottom: `${fmt({ month: "short" }).format(noonUtc)} ${fmt({ day: "numeric" }).format(noonUtc)}`,
  };
};

const SectionLabel = ({ children }: { children: React.ReactNode }) => (
  <div style={{ fontFamily: "'Inter', sans-serif", fontWeight: 600, fontSize: "11px", color: GOLD, textTransform: "uppercase", letterSpacing: "3px" }}>
    {children}
  </div>
);

const PageShell = ({ subtitle, children }: { subtitle: string; children: React.ReactNode }) => (
  <div className="min-h-screen" style={{ backgroundColor: CREAM }}>
    <div className="max-w-3xl mx-auto px-6 py-10 md:py-14">
      <div className="mb-8 flex justify-center">
        <EiaWordmark subtitle={subtitle} align="center" />
      </div>
      {children}
    </div>
  </div>
);

export default function Rebook() {
  const { token } = useParams<{ token: string }>();
  const [tokenInfo, setTokenInfo] = useState<TokenInfo | null>(null);
  const [payload, setPayload] = useState<Payload | null>(null);
  const [loading, setLoading] = useState(true);
  const [activeDate, setActiveDate] = useState<string | null>(null);
  const [picked, setPicked] = useState<SlotItem | null>(null);
  const [reserving, setReserving] = useState(false);
  const [confirming, setConfirming] = useState(false);
  const [done, setDone] = useState<{ display_date: string; display_time: string } | null>(null);

  const loadAll = async () => {
    if (!token) return;
    const [{ data: t }, { data: p }] = await Promise.all([
      supabase.functions.invoke<TokenInfo>("validate-rebook-token", { body: { token } }),
      supabase.functions.invoke<Payload>("get-available-slots", { body: { token } }),
    ]);
    setTokenInfo(t || { valid: false });
    setPayload(p || {});
    const visible = Object.keys(p?.slots_by_date || {}).sort();
    setActiveDate(visible.find((d) => (p?.slots_by_date?.[d]?.length || 0) > 0) || visible[0] || null);
    setLoading(false);
  };

  useEffect(() => { loadAll(); /* eslint-disable-next-line react-hooks/exhaustive-deps */ }, [token]);

  const dates = useMemo(() => Object.keys(payload?.slots_by_date || {}).sort(), [payload]);
  const slots = useMemo(() => (activeDate && payload?.slots_by_date?.[activeDate]) || [], [activeDate, payload]);

  const stage = tokenInfo?.stage || "reschedule";
  const isInvite = stage === "round1" || stage === "round2";
  const isAiScheduled = stage === "ai_scheduled";
  const roundLabel = stage === "round1" ? "Round 1" : stage === "round2" ? "Round 2" : "";
  const subtitle = isAiScheduled ? "AI INTERVIEW" : isInvite ? `${roundLabel.toUpperCase()} INTERVIEW` : "RESCHEDULE INTERVIEW";

  const handlePick = async (slot: SlotItem) => {
    if (reserving || confirming || !token) return;
    if (picked?.id === slot.id) { setPicked(null); return; }
    setReserving(true);
    try {
      const { data: res, error: rErr } = await supabase.functions.invoke<any>("reserve-slot", { body: { slot_id: slot.id } });
      if (rErr || !res?.success) {
        toast.error("That slot was just taken. Pick another.");
        await loadAll();
        return;
      }
      setPicked(slot);
    } finally {
      setReserving(false);
    }
  };

  const handleConfirm = async () => {
    if (!picked || !token) return;
    setConfirming(true);
    try {
      const fn = stage === "ai_scheduled" ? "rebook-confirm-ai" : "rebook-confirm";
      const { data: bk, error: bErr } = await supabase.functions.invoke<any>(fn, {
        body: { token, slot_id: picked.id },
      });
      if (bErr || bk?.error) {
        toast.error(bk?.error || "Could not complete booking.");
        return;
      }
      setDone({
        display_date: fmt({ weekday: "long", month: "long", day: "numeric", year: "numeric" }).format(new Date(picked.slot_start)),
        display_time: fmt({ hour: "numeric", minute: "2-digit", hour12: true }).format(new Date(picked.slot_start)),
      });
    } catch {
      toast.error("Something went wrong. Please try again.");
    } finally {
      setConfirming(false);
    }
  };

  if (loading) {
    return (
      <PageShell subtitle={subtitle}>
        <div className="flex items-center justify-center py-20">
          <Loader2 className="h-6 w-6 animate-spin" style={{ color: NAVY }} />
        </div>
      </PageShell>
    );
  }

  if (!tokenInfo?.valid) {
    const msg = tokenInfo?.reason === "used"
      ? "This scheduling link has already been used."
      : tokenInfo?.reason === "expired"
      ? "This scheduling link has expired. Please contact us if you still wish to interview."
      : "This scheduling link is invalid. Please contact us if you still wish to interview.";
    return (
      <PageShell subtitle={subtitle}>
        <Card className="border-0 shadow-sm">
          <CardContent className="pt-8 pb-8 text-center space-y-3">
            <SectionLabel>Link Unavailable</SectionLabel>
            <h1 style={{ fontFamily: "'Cormorant Garamond', serif", fontWeight: 600, fontSize: "26px", color: NAVY }}>
              We can't open this link
            </h1>
            <p className="text-sm text-muted-foreground max-w-md mx-auto">{msg}</p>
          </CardContent>
        </Card>
      </PageShell>
    );
  }

  if (done) {
    return (
      <PageShell subtitle={subtitle}>
        <Card className="border-0 shadow-sm">
          <CardContent className="pt-8 pb-8 text-center space-y-3">
            <CheckCircle2 className="h-12 w-12 mx-auto" style={{ color: "#16a34a" }} />
            <SectionLabel>{isAiScheduled ? "Interview Scheduled" : "Interview Confirmed"}</SectionLabel>
            <h1 style={{ fontFamily: "'Cormorant Garamond', serif", fontWeight: 600, fontSize: "30px", color: NAVY, lineHeight: 1.1 }}>
              You're confirmed
            </h1>
            <p className="text-base" style={{ color: NAVY }}>{done.display_date}</p>
            <p className="text-lg font-medium" style={{ color: NAVY }}>{done.display_time} <span className="text-sm text-muted-foreground">(PHT)</span></p>
            <p className="text-sm text-muted-foreground pt-2 max-w-md mx-auto">
              {isAiScheduled
                ? "A confirmation email with your interview link and a calendar invite (.ics) has been sent. Please check your inbox and return at your scheduled time to begin your interview."
                : "A confirmation email with your Zoom link and a calendar invite (.ics) has been sent. Please check your inbox."}
            </p>
          </CardContent>
        </Card>
      </PageShell>
    );
  }

  if (payload?.ooo_active) {
    return (
      <PageShell subtitle={subtitle}>
        <Card className="border-0 shadow-sm">
          <CardContent className="pt-8 pb-8 text-center space-y-3">
            <CalendarOff className="h-10 w-10 mx-auto text-muted-foreground" />
            <SectionLabel>Temporarily Unavailable</SectionLabel>
            <h1 style={{ fontFamily: "'Cormorant Garamond', serif", fontWeight: 600, fontSize: "26px", color: NAVY }}>
              We're still out of office
            </h1>
            <p className="text-sm text-muted-foreground max-w-md mx-auto">
              Bookings reopen on {payload.ooo_end}. Your link stays valid for 3 days — please try again then.
            </p>
          </CardContent>
        </Card>
      </PageShell>
    );
  }

  const firstName = (tokenInfo.candidate_name || "").split(" ")[0] || "there";
  const position = tokenInfo.position_title;

  return (
    <PageShell subtitle={subtitle}>
      <div className="text-center mb-6 space-y-2">
        <SectionLabel>{isInvite ? `Schedule Your ${roundLabel} Interview` : "Reschedule Your Interview"}</SectionLabel>
        <h1 style={{ fontFamily: "'Cormorant Garamond', serif", fontWeight: 600, fontSize: "32px", color: NAVY, lineHeight: 1.1 }}>
          Hi {firstName}
        </h1>
        <p className="text-sm md:text-base text-muted-foreground max-w-xl mx-auto">
          {isInvite ? "Please choose a time for your interview" : "Please choose a new time for your interview"}
          {position ? <> for the <span style={{ color: NAVY, fontWeight: 500 }}>{position}</span> position</> : null}.
        </p>
      </div>

      <div className="text-center text-xs mb-6 py-2 px-4 rounded" style={{ color: NAVY, backgroundColor: "#fff", border: `1px solid ${GOLD}40`, letterSpacing: "1px", textTransform: "uppercase", fontWeight: 500 }}>
        All times shown in Philippine Standard Time (PHT)
      </div>

      {payload?.extended_window && !payload?.curated && (
        <div className="mb-4 rounded-md px-4 py-3 text-center" style={{ backgroundColor: `${GOLD}14`, border: `1px solid ${GOLD}55`, color: NAVY }}>
          <p className="text-sm font-medium">Additional days shown due to high demand</p>
          <p className="text-xs text-muted-foreground mt-0.5">Earlier days are fully booked — newly opened dates are highlighted below.</p>
        </div>
      )}

      <Card className="border-0 shadow-sm">
        <CardContent className="p-5 md:p-6 space-y-5">
          <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-6 gap-2">
            {dates.map((d) => {
              const { top, bottom } = tabLabel(d);
              const active = d === activeDate;
              const count = payload?.slots_by_date?.[d]?.length || 0;
              const isFull = count === 0;
              return (
                <button
                  key={d}
                  onClick={() => setActiveDate(d)}
                  disabled={isFull}
                  className={cn("rounded-lg px-3 py-3 text-center transition border-2", isFull && "opacity-50 cursor-not-allowed")}
                  style={{
                    borderColor: active ? NAVY : isFull ? "#e5e7eb" : `${GOLD}66`,
                    backgroundColor: active ? `${NAVY}08` : isFull ? "#f3f4f6" : "#fff",
                  }}
                >
                  <div className="text-[11px] font-semibold uppercase tracking-wider" style={{ color: active ? NAVY : "#6b7280" }}>{top}</div>
                  <div className="text-sm font-medium" style={{ color: NAVY }}>{bottom}</div>
                  <div className="text-[10px] mt-1" style={{ color: isFull ? "#9ca3af" : GOLD, fontWeight: isFull ? 400 : 600 }}>
                    {isFull ? "Full" : `${count} slot${count === 1 ? "" : "s"}`}
                  </div>
                </button>
              );
            })}
          </div>

          {slots.length === 0 ? (
            <p className="text-center py-8 text-sm text-muted-foreground">No slots available on this day. Try another day.</p>
          ) : (
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
              {slots.map((s) => {
                const isPicked = picked?.id === s.id;
                return (
                  <Button
                    key={s.id}
                    variant={isPicked ? "default" : "outline"}
                    disabled={reserving || confirming}
                    onClick={() => handlePick(s)}
                    style={isPicked
                      ? { backgroundColor: NAVY, color: "#fff", borderColor: NAVY }
                      : { borderColor: "#e5e7eb", color: NAVY }}
                  >
                    {s.display_time}
                  </Button>
                );
              })}
            </div>
          )}

          {reserving && (
            <div className="text-center text-sm text-muted-foreground">
              <Loader2 className="h-4 w-4 inline animate-spin mr-2" />Holding slot…
            </div>
          )}

          {picked && !reserving && (
            <div className="border-t pt-4 space-y-3">
              <div className="text-center space-y-1">
                <SectionLabel>Selected time</SectionLabel>
                <p className="text-base font-medium" style={{ color: NAVY }}>
                  {fmt({ weekday: "long", month: "long", day: "numeric" }).format(new Date(picked.slot_start))}
                  {" — "}{picked.display_time} (PHT)
                </p>
                <p className="text-xs text-muted-foreground">Slot held for you. Click Confirm to book.</p>
              </div>
              <div className="flex gap-2 justify-center">
                <Button variant="outline" disabled={confirming} onClick={() => setPicked(null)} style={{ borderColor: "#e5e7eb", color: NAVY }}>
                  Change time
                </Button>
                <Button
                  disabled={confirming}
                  onClick={handleConfirm}
                  style={{ backgroundColor: NAVY, color: "#fff" }}
                  className="min-w-[180px]"
                >
                  {confirming ? <><Loader2 className="h-4 w-4 animate-spin mr-2" />Confirming…</> : "Confirm Booking"}
                </Button>
              </div>
            </div>
          )}
        </CardContent>
      </Card>
    </PageShell>
  );
}
