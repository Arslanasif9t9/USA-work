import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Loader2, ArrowLeft, Save, Mail, KeyRound, Eye, EyeOff } from "lucide-react";
import { toast } from "sonner";

const HR_ALLOWLIST = ["hr1@expert.com", "hr2@expert.com"] as const;

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const MASTER_ADMIN_EMAIL = "spark11179@gmail.com";

/**
 * /dashboard/settings — master-admin-only system settings page.
 * Currently exposes the editable "Internal Backup Copy Email" (hr_copy_email)
 * config row. Designed as a container so future settings can be added below
 * as new sections.
 */
const Settings = () => {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [email, setEmail] = useState("");
  const [original, setOriginal] = useState("");
  const [mainBackup, setMainBackup] = useState("");
  const [mainBackupOriginal, setMainBackupOriginal] = useState("");
  const [savingMain, setSavingMain] = useState(false);
  const [allowed, setAllowed] = useState<boolean | null>(null);

  // Reset HR Password state
  const [pwDialogOpen, setPwDialogOpen] = useState(false);
  const [pwTarget, setPwTarget] = useState<string>(HR_ALLOWLIST[0]);
  const [pwNew, setPwNew] = useState("");
  const [pwConfirm, setPwConfirm] = useState("");
  const [pwShow, setPwShow] = useState(false);
  const [pwBusy, setPwBusy] = useState(false);

  const resetPwFields = () => { setPwNew(""); setPwConfirm(""); setPwShow(false); setPwTarget(HR_ALLOWLIST[0]); };

  const submitResetHrPassword = async () => {
    if (!HR_ALLOWLIST.includes(pwTarget as any)) { toast.error("Pick an allowed HR account"); return; }
    if (pwNew.length < 8) { toast.error("Password must be at least 8 characters"); return; }
    if (pwNew !== pwConfirm) { toast.error("Passwords do not match"); return; }
    setPwBusy(true);
    try {
      const { data, error } = await supabase.functions.invoke<any>("update-hr-password", {
        body: { target_email: pwTarget, new_password: pwNew },
      });
      if (error) { toast.error(error.message || "Could not reset password"); return; }
      if (!data?.ok) { toast.error(data?.error || "Could not reset password"); return; }
      toast.success(`Password reset for ${pwTarget}`);
      resetPwFields();
      setPwDialogOpen(false);
    } finally {
      setPwBusy(false);
    }
  };

  useEffect(() => {
    document.title = "EIA — System Settings";
  }, []);

  useEffect(() => {
    if (!user) return;
    const isMaster = (user.email || "").toLowerCase() === MASTER_ADMIN_EMAIL;
    setAllowed(isMaster);
    if (!isMaster) {
      setLoading(false);
      return;
    }
    (async () => {
      const { data, error } = await supabase
        .from("app_settings" as any)
        .select("hr_copy_email, main_backup_email")
        .eq("id", 1)
        .maybeSingle();
      if (!error && data) {
        const v = (data as any).hr_copy_email || "";
        const m = (data as any).main_backup_email || "";
        setEmail(v); setOriginal(v);
        setMainBackup(m); setMainBackupOriginal(m);
      }
      setLoading(false);
    })();
  }, [user]);

  const save = async () => {
    const cleaned = email.trim();
    if (!EMAIL_RE.test(cleaned)) {
      toast.error("Enter a valid email address");
      return;
    }
    setSaving(true);
    const prev = original;
    setOriginal(cleaned); // optimistic
    const { error } = await supabase
      .from("app_settings" as any)
      .update({ hr_copy_email: cleaned, updated_at: new Date().toISOString() })
      .eq("id", 1);
    setSaving(false);
    if (error) {
      setOriginal(prev);
      toast.error(error.message || "Could not save");
      return;
    }
    toast.success("Internal Backup Copy Email updated");
  };

  const saveMain = async () => {
    const cleaned = mainBackup.trim();
    if (!EMAIL_RE.test(cleaned)) { toast.error("Enter a valid email address"); return; }
    setSavingMain(true);
    const prev = mainBackupOriginal;
    setMainBackupOriginal(cleaned);
    const { error } = await supabase
      .from("app_settings" as any)
      .update({ main_backup_email: cleaned, updated_at: new Date().toISOString() })
      .eq("id", 1);
    setSavingMain(false);
    if (error) { setMainBackupOriginal(prev); toast.error(error.message || "Could not save"); return; }
    toast.success("Main Backup Email updated");
  };

  if (allowed === false) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center px-6">
        <div className="text-center max-w-md">
          <h1 className="text-xl font-semibold mb-2" style={{ fontFamily: "'Cormorant Garamond', serif", color: "#1a2547" }}>
            Settings — Restricted
          </h1>
          <p className="text-sm text-muted-foreground mb-4">
            This page is restricted to the master admin.
          </p>
          <Button variant="outline" onClick={() => navigate("/dashboard")}>
            <ArrowLeft className="h-4 w-4 mr-1.5" /> Back to Dashboard
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <header className="bg-background" style={{ borderBottom: "1px solid #e1e4ec" }}>
        <div className="max-w-3xl mx-auto px-6 py-4 flex items-center justify-between">
          <div className="flex flex-col leading-tight">
            <h1
              style={{
                fontFamily: "'Cormorant Garamond', serif",
                fontWeight: 600,
                fontSize: "18px",
                color: "#1a2547",
                letterSpacing: "1px",
                margin: 0,
                cursor: "pointer",
              }}
              onClick={() => navigate("/dashboard")}
            >
              EIA Talent Recruiting System
            </h1>
            <span
              style={{
                fontFamily: "'Inter', sans-serif",
                fontWeight: 400,
                fontSize: "9px",
                color: "#6b7280",
                textTransform: "uppercase",
                letterSpacing: "1px",
                marginTop: "2px",
              }}
            >
              System Settings
            </span>
          </div>
          <Button variant="ghost" size="sm" onClick={() => navigate("/dashboard")}>
            <ArrowLeft className="h-4 w-4 mr-1.5" /> Back
          </Button>
        </div>
      </header>

      <main className="max-w-3xl mx-auto px-6 py-10 space-y-8">
        <h2 className="text-3xl font-bold tracking-tight" style={{ fontFamily: "'Cormorant Garamond', serif", color: "#1a2547" }}>
          System Settings
        </h2>

        <section className="bg-card border rounded-lg p-6 space-y-4" style={{ borderColor: "#e1e4ec" }}>
          <div className="flex items-start gap-3">
            <div
              className="h-9 w-9 rounded-md flex items-center justify-center shrink-0"
              style={{ backgroundColor: "#1a254710", color: "#1a2547" }}
            >
              <Mail className="h-4 w-4" />
            </div>
            <div className="flex-1 min-w-0">
              <h3 className="text-base font-semibold" style={{ color: "#1a2547" }}>
                Internal Backup Copy Email
              </h3>
              <p className="text-sm text-muted-foreground mt-0.5">
                Internal safety-net inbox monitored by 2–3 staff. When HR ticks
                "Send a copy to internal backup inbox" on a send, the FINAL
                signed/completed record is copied here once the recipient
                completes the action. This is not tied to any individual person.
              </p>
            </div>
          </div>

          {loading ? (
            <div className="flex items-center gap-2 text-sm text-muted-foreground">
              <Loader2 className="h-4 w-4 animate-spin" /> Loading current value…
            </div>
          ) : (
            <div className="space-y-3">
              <div className="space-y-1.5">
                <Label htmlFor="hr-copy-email">Destination email</Label>
                <Input
                  id="hr-copy-email"
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="talent.expertadvisor@outlook.com"
                  disabled={saving}
                />
                <p className="text-xs text-muted-foreground">
                  Read live at copy time — updating here applies to all future copies immediately.
                </p>
              </div>
              <div className="flex items-center gap-2">
                <Button
                  onClick={save}
                  disabled={saving || email.trim() === original.trim() || !EMAIL_RE.test(email.trim())}
                  style={{ backgroundColor: "#1a2547" }}
                  className="text-white"
                >
                  {saving ? <><Loader2 className="h-4 w-4 mr-1.5 animate-spin" /> Saving…</> : <><Save className="h-4 w-4 mr-1.5" /> Save</>}
                </Button>
                {email.trim() !== original.trim() && (
                  <Button variant="ghost" disabled={saving} onClick={() => setEmail(original)}>
                    Discard changes
                  </Button>
                )}
              </div>
            </div>
          )}
        </section>

        <section className="bg-card border rounded-lg p-6 space-y-4" style={{ borderColor: "#e1e4ec" }}>
          <div className="flex items-start gap-3">
            <div className="h-9 w-9 rounded-md flex items-center justify-center shrink-0" style={{ backgroundColor: "#1a254710", color: "#1a2547" }}>
              <Mail className="h-4 w-4" />
            </div>
            <div className="flex-1 min-w-0">
              <h3 className="text-base font-semibold" style={{ color: "#1a2547" }}>Main Backup Email (Always-On)</h3>
              <p className="text-sm text-muted-foreground mt-0.5">
                Every signed/completed document (offer, NDAs, settlement, leave, termination) and every completed interview video is automatically copied here. No checkbox — always fires on completion. Default: <code>talent.expertadvisor@outlook.com</code>.
              </p>
            </div>
          </div>
          {!loading && (
            <div className="space-y-3">
              <div className="space-y-1.5">
                <Label htmlFor="main-backup-email">Destination email</Label>
                <Input id="main-backup-email" type="email" value={mainBackup} onChange={(e) => setMainBackup(e.target.value)} placeholder="talent.expertadvisor@outlook.com" disabled={savingMain} />
                <p className="text-xs text-muted-foreground">Read live at completion time — updates apply to all future completions immediately.</p>
              </div>
              <div className="flex items-center gap-2">
                <Button onClick={saveMain} disabled={savingMain || mainBackup.trim() === mainBackupOriginal.trim() || !EMAIL_RE.test(mainBackup.trim())} style={{ backgroundColor: "#1a2547" }} className="text-white">
                  {savingMain ? <><Loader2 className="h-4 w-4 mr-1.5 animate-spin" /> Saving…</> : <><Save className="h-4 w-4 mr-1.5" /> Save</>}
                </Button>
                {mainBackup.trim() !== mainBackupOriginal.trim() && (
                  <Button variant="ghost" disabled={savingMain} onClick={() => setMainBackup(mainBackupOriginal)}>Discard changes</Button>
                )}
              </div>
            </div>
          )}
        </section>

        <section className="bg-card border rounded-lg p-6 space-y-4" style={{ borderColor: "#e1e4ec" }}>
          <div className="flex items-start gap-3">
            <div className="h-9 w-9 rounded-md flex items-center justify-center shrink-0" style={{ backgroundColor: "#1a254710", color: "#1a2547" }}>
              <KeyRound className="h-4 w-4" />
            </div>
            <div className="flex-1 min-w-0">
              <h3 className="text-base font-semibold" style={{ color: "#1a2547" }}>Reset HR Password</h3>
              <p className="text-sm text-muted-foreground mt-0.5">
                Master-admin only. Set a new login password for an HR account ({HR_ALLOWLIST.join(", ")}). Action is recorded to the password audit log. The password value itself is never logged.
              </p>
            </div>
          </div>
          <Button onClick={() => { resetPwFields(); setPwDialogOpen(true); }} style={{ backgroundColor: "#1a2547" }} className="text-white">
            <KeyRound className="h-4 w-4 mr-1.5" /> Reset HR Password
          </Button>
        </section>
      </main>

      <Dialog open={pwDialogOpen} onOpenChange={(o) => { if (!pwBusy) { setPwDialogOpen(o); if (!o) resetPwFields(); } }}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <KeyRound className="h-5 w-5" style={{ color: "#1a2547" }} /> Reset HR Password
            </DialogTitle>
            <DialogDescription>
              Choose the HR account and set a new password. Minimum 8 characters. The HR user will need to use this password on their next login.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-3 text-sm">
            <div className="space-y-1.5">
              <Label>Target HR account</Label>
              <Select value={pwTarget} onValueChange={setPwTarget} disabled={pwBusy}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  {HR_ALLOWLIST.map((e) => (<SelectItem key={e} value={e}>{e}</SelectItem>))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1.5">
              <Label>New password</Label>
              <div className="flex gap-2">
                <Input type={pwShow ? "text" : "password"} value={pwNew} onChange={(e) => setPwNew(e.target.value)} placeholder="Min 8 characters" disabled={pwBusy} autoComplete="new-password" />
                <Button type="button" variant="outline" size="icon" onClick={() => setPwShow((s) => !s)} disabled={pwBusy} title={pwShow ? "Hide" : "Show"}>
                  {pwShow ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                </Button>
              </div>
            </div>
            <div className="space-y-1.5">
              <Label>Confirm new password</Label>
              <Input type={pwShow ? "text" : "password"} value={pwConfirm} onChange={(e) => setPwConfirm(e.target.value)} placeholder="Re-enter password" disabled={pwBusy} autoComplete="new-password" />
              {pwConfirm.length > 0 && pwNew !== pwConfirm && (
                <p className="text-xs" style={{ color: "#dc2626" }}>Passwords do not match.</p>
              )}
            </div>
          </div>
          <DialogFooter>
            <Button variant="ghost" onClick={() => { if (!pwBusy) { setPwDialogOpen(false); resetPwFields(); } }} disabled={pwBusy}>Cancel</Button>
            <Button
              onClick={submitResetHrPassword}
              disabled={pwBusy || pwNew.length < 8 || pwNew !== pwConfirm || !HR_ALLOWLIST.includes(pwTarget as any)}
              style={{ backgroundColor: "#1a2547" }}
              className="text-white"
            >
              {pwBusy ? <><Loader2 className="h-4 w-4 mr-1.5 animate-spin" /> Saving…</> : <><Save className="h-4 w-4 mr-1.5" /> Save</>}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default Settings;
