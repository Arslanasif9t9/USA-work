import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { FullPageLoader, Spinner } from "@/components/FullPageLoader";
import { usePageSeo } from "@/components/PageSeo";


const Login = () => {
  const navigate = useNavigate();
  const { session, loading } = useAuth();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [err, setErr] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  usePageSeo({
    title: "Sign In — EIA Talent Recruiting System",
    description: "Sign in to the Expert Intuitive Advisor Inc. talent recruiting system for HR staff and hiring managers.",
    path: "/login",
  });

  useEffect(() => {
    if (!loading && session) navigate("/dashboard", { replace: true });
  }, [session, loading, navigate]);

  const onSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErr(null);
    setBusy(true);
    const { error } = await supabase.auth.signInWithPassword({ email, password });
    if (error) {
      setBusy(false);
      setErr(error.message);
      return;
    }
    // Success: keep busy=true so the disabled form / loader stays visible
    // until React Router unmounts this page.
    navigate("/dashboard", { replace: true });
  };

  // Show branded full-page loader on success so the user never sees empty fields.
  if (busy && session) return <FullPageLoader label="Signing you in…" />;

  return (
    <main
      className="min-h-screen flex items-center justify-center px-4 py-12"
      style={{ background: "linear-gradient(180deg, #fafaf7 0%, #f3f1ea 100%)" }}
    >
      <div
        className="w-full max-w-[440px] bg-white rounded-lg px-10 py-12 animate-in fade-in duration-500"
        style={{ border: "1px solid #e1e4ec", boxShadow: "0 4px 24px -8px rgba(26, 37, 71, 0.08)" }}
      >
        {/* Brand block */}
        <div className="text-center">
          <h1
            style={{
              fontFamily: "'Cormorant Garamond', serif",
              fontWeight: 600,
              fontSize: "56px",
              color: "#1a2547",
              letterSpacing: "2px",
              lineHeight: 1,
              margin: 0,
            }}
          >
            EIA<span className="sr-only"> — Internal HR Talent Recruiting System</span>
          </h1>
          <p
            style={{
              fontFamily: "'Cormorant Garamond', serif",
              fontWeight: 400,
              fontSize: "18px",
              color: "#1a2547",
              marginTop: "12px",
            }}
          >
            Expert Intuitive Advisor Inc.
          </p>
          <p
            style={{
              fontFamily: "'Inter', sans-serif",
              fontWeight: 400,
              fontSize: "11px",
              color: "#6b7280",
              fontStyle: "italic",
              letterSpacing: "1px",
              textTransform: "uppercase",
              marginTop: "8px",
            }}
          >
            Internal HR Talent Recruiting System
          </p>
          <div
            style={{
              width: "80px",
              height: "1px",
              backgroundColor: "#b08d57",
              margin: "20px auto 0",
            }}
          />
        </div>

        {/* Sign in heading */}
        <p
          className="text-center"
          style={{
            fontFamily: "'Inter', sans-serif",
            fontWeight: 600,
            fontSize: "14px",
            color: "#1a2236",
            marginTop: "24px",
            marginBottom: "20px",
          }}
        >
          Sign in to continue
        </p>

        {/* Form */}
        <form onSubmit={onSubmit} className="space-y-4" style={{ fontFamily: "'Inter', sans-serif" }}>
          <div className="space-y-1.5">
            <label htmlFor="email" style={{ fontSize: "12px", fontWeight: 500, color: "#1a2236" }}>
              Email
            </label>
            <input
              id="email"
              type="email"
              required
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              autoComplete="email"
              disabled={busy}
              className="w-full outline-none transition-all focus:ring-2 disabled:opacity-60 disabled:cursor-not-allowed"
              style={{
                padding: "12px",
                border: "1px solid #e1e4ec",
                borderRadius: "8px",
                fontSize: "14px",
                fontFamily: "'Inter', sans-serif",
                color: "#1a2236",
                background: busy ? "#f8f8f8" : "#ffffff",
              }}
              onFocus={(e) => !busy && (e.target.style.borderColor = "#1a2547")}
              onBlur={(e) => (e.target.style.borderColor = "#e1e4ec")}
            />
          </div>
          <div className="space-y-1.5">
            <label htmlFor="password" style={{ fontSize: "12px", fontWeight: 500, color: "#1a2236" }}>
              Password
            </label>
            <input
              id="password"
              type="password"
              required
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              autoComplete="current-password"
              disabled={busy}
              className="w-full outline-none transition-all disabled:opacity-60 disabled:cursor-not-allowed"
              style={{
                padding: "12px",
                border: "1px solid #e1e4ec",
                borderRadius: "8px",
                fontSize: "14px",
                fontFamily: "'Inter', sans-serif",
                color: "#1a2236",
                background: busy ? "#f8f8f8" : "#ffffff",
              }}
              onFocus={(e) => !busy && (e.target.style.borderColor = "#1a2547")}
              onBlur={(e) => (e.target.style.borderColor = "#e1e4ec")}
            />
          </div>
          {err && (
            <p style={{ fontSize: "12px", color: "#b91c1c", fontFamily: "'Inter', sans-serif" }}>
              {err}
            </p>
          )}
          <button
            type="submit"
            disabled={busy}
            className="w-full flex items-center justify-center transition-all hover:scale-[1.02] disabled:opacity-60 disabled:hover:scale-100"
            style={{
              backgroundColor: "#1a2547",
              color: "#ffffff",
              fontFamily: "'Inter', sans-serif",
              fontWeight: 600,
              fontSize: "14px",
              padding: "12px",
              borderRadius: "8px",
              border: "none",
              cursor: busy ? "not-allowed" : "pointer",
              marginTop: "8px",
            }}
            onMouseEnter={(e) => !busy && (e.currentTarget.style.backgroundColor = "#131c38")}
            onMouseLeave={(e) => (e.currentTarget.style.backgroundColor = "#1a2547")}
          >
            {busy ? (
              <>
                <Spinner size={16} className="mr-2" /> Signing in…
              </>
            ) : (
              "Sign In"
            )}
          </button>
        </form>

        {/* Footer tagline */}
        <p
          className="text-center"
          style={{
            fontFamily: "'Inter', sans-serif",
            fontWeight: 400,
            fontSize: "10px",
            fontStyle: "italic",
            color: "#6b7280",
            marginTop: "32px",
          }}
        >
          The intelligence layer between humans and AI.
        </p>
      </div>
    </main>
  );
};

export default Login;
