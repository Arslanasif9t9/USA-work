// NotificationCenter — passive HR review page. Lists "misses" computed live from
// responses. No emails, popups, push, or badges. Auto-clears (filters out)
// anything whose triggering timestamp is older than 30 days.
import { useEffect, useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { BRAND } from "@/config/brand";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { ArrowLeft } from "lucide-react";

type RespRow = {
  id: string;
  form_id: string;
  applicant_id: string;
  round_stage: string | null;
  round_1_sent_at: string | null;
  round_2_sent_at: string | null;
  offer_sent_at: string | null;
  scheduled_slot_id: string | null;
  appointment_cancelled: boolean | null;
  final_outcome: string | null;
  disqualified_at: string | null;
};

type Miss = {
  key: string;
  response_id: string;
  form_id: string;
  candidateName: string;
  position: string;
  label: string;
  triggeredAt: string;
};

const DAY_MS = 24 * 60 * 60 * 1000;
const THIRTY_DAYS = 30 * DAY_MS;
const THREE_DAYS = 3 * DAY_MS;

const daysAgo = (iso: string) => {
  const d = Math.floor((Date.now() - Date.parse(iso)) / DAY_MS);
  if (d <= 0) return "today";
  if (d === 1) return "1 day ago";
  return `${d} days ago`;
};

const NotificationCenter = () => {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(true);
  const [misses, setMisses] = useState<Miss[]>([]);

  useEffect(() => {
    document.title = "Notification Center — EIA";
    (async () => {
      setLoading(true);
      try {
        // Pull recent candidates in the relevant stages only.
        const { data: resp } = await supabase
          .from("responses")
          .select(
            "id, form_id, applicant_id, round_stage, round_1_sent_at, round_2_sent_at, offer_sent_at, scheduled_slot_id, appointment_cancelled, final_outcome, disqualified_at"
          )
          .in("round_stage", ["round_1_sent", "round2_ai", "offer_expired"])
          .is("disqualified_at", null);

        const rows: RespRow[] = (resp || []) as any[];
        if (!rows.length) {
          setMisses([]);
          setLoading(false);
          return;
        }

        const now = Date.now();
        const formIds = Array.from(new Set(rows.map((r) => r.form_id)));

        // Resolve position via form_metadata.position_title
        const { data: meta } = await supabase
          .from("form_metadata")
          .select("form_id, position_title")
          .in("form_id", formIds);
        const positionByForm = new Map<string, string>();
        (meta || []).forEach((m: any) => positionByForm.set(m.form_id, (m.position_title || "").trim()));

        // Resolve candidate name via answers + questions (label ~ /name/i)
        const { data: qs } = await supabase
          .from("questions")
          .select("id, form_id, label, type")
          .in("form_id", formIds);
        const nameQByForm = new Map<string, string>();
        (qs || []).forEach((q: any) => {
          if (nameQByForm.has(q.form_id)) return;
          if (/name/i.test(q.label || "") && q.type === "short_text") {
            nameQByForm.set(q.form_id, q.id);
          }
        });
        // Fallback: any /name/i question
        (qs || []).forEach((q: any) => {
          if (nameQByForm.has(q.form_id)) return;
          if (/name/i.test(q.label || "")) nameQByForm.set(q.form_id, q.id);
        });

        const nameQIds = Array.from(new Set(Array.from(nameQByForm.values())));
        const respIds = rows.map((r) => r.id);
        const { data: ans } = nameQIds.length
          ? await supabase
              .from("answers")
              .select("response_id, question_id, answer_text")
              .in("response_id", respIds)
              .in("question_id", nameQIds)
          : { data: [] as any[] };
        const nameByResp = new Map<string, string>();
        (ans || []).forEach((a: any) => {
          if (!nameByResp.has(a.response_id)) nameByResp.set(a.response_id, (a.answer_text || "").trim());
        });

        const out: Miss[] = [];
        for (const r of rows) {
          const pending = !r.scheduled_slot_id && !r.appointment_cancelled;
          const candidateName = nameByResp.get(r.id) || "Unnamed candidate";
          const position = positionByForm.get(r.form_id) || "";

          // Expired Round 1 link — SAME definition as MyBookings/StageTrackingView
          if (
            pending &&
            r.round_stage === "round_1_sent" &&
            r.round_1_sent_at &&
            now - Date.parse(r.round_1_sent_at) > THREE_DAYS
          ) {
            out.push({
              key: `r1-${r.id}`,
              response_id: r.id,
              form_id: r.form_id,
              candidateName,
              position,
              label: "Round 1 link expired",
              triggeredAt: r.round_1_sent_at,
            });
          }

          // Expired Round 2 link — analogous: round2_ai, pending, sent > 3 days ago
          if (
            pending &&
            r.round_stage === "round2_ai" &&
            r.round_2_sent_at &&
            now - Date.parse(r.round_2_sent_at) > THREE_DAYS
          ) {
            out.push({
              key: `r2-${r.id}`,
              response_id: r.id,
              form_id: r.form_id,
              candidateName,
              position,
              label: "Round 2 link expired",
              triggeredAt: r.round_2_sent_at,
            });
          }

          // Offer unsigned past expiry
          if (r.round_stage === "offer_expired") {
            const ts = r.offer_sent_at || r.round_2_sent_at || r.round_1_sent_at;
            if (ts) {
              out.push({
                key: `oe-${r.id}`,
                response_id: r.id,
                form_id: r.form_id,
                candidateName,
                position,
                label: "Offer unsigned past expiry",
                triggeredAt: ts,
              });
            }
          }
        }

        // 30-day auto-clear: drop anything triggered more than 30 days ago.
        const filtered = out.filter((m) => now - Date.parse(m.triggeredAt) <= THIRTY_DAYS);
        // Most recent first.
        filtered.sort((a, b) => Date.parse(b.triggeredAt) - Date.parse(a.triggeredAt));
        setMisses(filtered);
      } finally {
        setLoading(false);
      }
    })();
  }, []);

  const headerStyle = useMemo(
    () => ({
      fontFamily: "'Cormorant Garamond', serif",
      color: BRAND.colors.navy,
    }),
    []
  );

  return (
    <div className="min-h-screen" style={{ background: BRAND.colors.cream }}>
      <header style={{ borderBottom: `1px solid ${BRAND.colors.rule}`, background: "#fff" }}>
        <div className="max-w-4xl mx-auto px-4 sm:px-6 py-4 flex items-center justify-between gap-3">
          <Button
            variant="ghost"
            size="sm"
            onClick={() => navigate("/dashboard")}
            style={{ color: BRAND.colors.navy }}
          >
            <ArrowLeft className="h-4 w-4 mr-1.5" /> Dashboard
          </Button>
          <h1 className="text-xl sm:text-2xl" style={{ ...headerStyle, fontWeight: 600, letterSpacing: "0.5px", margin: 0 }}>
            Notification Center
          </h1>
          <span className="w-[88px]" aria-hidden />
        </div>
      </header>

      <main className="max-w-4xl mx-auto px-4 sm:px-6 py-8 sm:py-12">
        <p
          className="text-sm mb-6 sm:mb-8"
          style={{ fontFamily: "'Inter', sans-serif", color: "#5b6478" }}
        >
          A quiet review of things that may have slipped by. Entries clear themselves after 30 days.
        </p>

        {loading ? (
          <div className="space-y-3">
            {[0, 1, 2].map((i) => (
              <Skeleton key={i} className="h-20 w-full rounded-md" />
            ))}
          </div>
        ) : misses.length === 0 ? (
          <div
            className="rounded-md p-10 text-center"
            style={{
              background: "#fff",
              border: `1px solid ${BRAND.colors.rule}`,
            }}
          >
            <p
              className="text-lg"
              style={{ ...headerStyle, fontWeight: 500 }}
            >
              Nothing needs your attention right now.
            </p>
          </div>
        ) : (
          <ul className="space-y-3">
            {misses.map((m) => (
              <li
                key={m.key}
                className="rounded-md p-4 sm:p-5 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2"
                style={{
                  background: "#fff",
                  border: `1px solid ${BRAND.colors.rule}`,
                }}
              >
                <div className="min-w-0">
                  <div
                    className="text-base sm:text-lg truncate"
                    style={{ ...headerStyle, fontWeight: 600 }}
                  >
                    {m.candidateName}
                    {m.position ? (
                      <span
                        className="ml-2 text-sm"
                        style={{ fontFamily: "'Inter', sans-serif", color: "#6b7280", fontWeight: 400 }}
                      >
                        · {m.position}
                      </span>
                    ) : null}
                  </div>
                  <div
                    className="text-sm mt-1"
                    style={{ fontFamily: "'Inter', sans-serif", color: BRAND.colors.navy }}
                  >
                    {m.label}
                  </div>
                </div>
                <div
                  className="text-xs sm:text-sm shrink-0"
                  style={{ fontFamily: "'Inter', sans-serif", color: "#8a8270" }}
                >
                  {daysAgo(m.triggeredAt)}
                </div>
              </li>
            ))}
          </ul>
        )}
      </main>
    </div>
  );
};

export default NotificationCenter;
