import { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent } from "@/components/ui/card";
import { Loader2, ExternalLink } from "lucide-react";
import EiaWordmark from "@/components/EiaWordmark";
import { SignedThumb, SignedFileLink } from "@/components/onboarding/SignedFile";

const NAVY = "#1a2547";
const GOLD = "#b08d57";
const CREAM = "#faf8f3";

type Submission = {
  id: string;
  response_id: string;
  full_name: string | null;
  email: string | null;
  position_title: string | null;
  phone: string | null;
  onlinejobs_profile_url: string | null;
  digital_pay_gcash: string | null;
  profile_photo_url: string | null;
  speedtest_screenshot_url: string | null;
  typing_screenshot_url: string | null;
  onboarding_status: string;
  submitted_at: string | null;
};

const fmtDateTime = (d: string | null) =>
  d ? new Date(d).toLocaleString("en-US", { dateStyle: "medium", timeStyle: "short" }) : "—";

const statusPill = (status: string) => {
  const map: Record<string, { bg: string; color: string; label: string }> = {
    pending: { bg: "#fef3c7", color: "#92400e", label: "Pending" },
    approved: { bg: "#dcfce7", color: "#166534", label: "Approved" },
    rejected: { bg: "#fee2e2", color: "#991b1b", label: "Rejected" },
  };
  const m = map[status] || { bg: "#e5e7eb", color: "#374151", label: status };
  return (
    <span style={{ background: m.bg, color: m.color }} className="inline-flex px-2 py-0.5 rounded text-xs font-medium">
      {m.label}
    </span>
  );
};

const Field = ({ label, children }: { label: string; children: React.ReactNode }) => (
  <div className="space-y-1">
    <div className="text-[11px] font-semibold uppercase tracking-wider" style={{ color: GOLD }}>
      {label}
    </div>
    <div className="text-sm" style={{ color: NAVY }}>
      {children}
    </div>
  </div>
);

export default function OnboardingSubmissionView() {
  const { response_id } = useParams();
  const [loading, setLoading] = useState(true);
  const [sub, setSub] = useState<Submission | null>(null);

  useEffect(() => {
    (async () => {
      setLoading(true);
      const { data } = await (supabase.from("onboarding_submissions") as any)
        .select(
          "id, response_id, full_name, email, position_title, phone, onlinejobs_profile_url, digital_pay_gcash, profile_photo_url, speedtest_screenshot_url, typing_screenshot_url, onboarding_status, submitted_at"
        )
        .eq("response_id", response_id)
        .maybeSingle();
      setSub((data as Submission) || null);
      setLoading(false);
    })();
  }, [response_id]);

  return (
    <div className="min-h-screen" style={{ backgroundColor: CREAM }}>
      <div className="max-w-2xl mx-auto px-6 py-10 md:py-14">
        <div className="mb-8 flex justify-center">
          <EiaWordmark subtitle="ONBOARDING SUBMISSION" align="center" />
        </div>

        {loading ? (
          <div className="flex items-center justify-center py-20">
            <Loader2 className="h-6 w-6 animate-spin" style={{ color: NAVY }} />
          </div>
        ) : !sub || !sub.submitted_at ? (
          <Card className="border-0 shadow-sm">
            <CardContent className="pt-8 pb-8 text-center space-y-2">
              <h2 style={{ fontFamily: "'Cormorant Garamond', serif", fontWeight: 600, fontSize: 24, color: NAVY }}>
                No onboarding submission found
              </h2>
              <p className="text-sm text-muted-foreground">
                This employee has not submitted their onboarding form yet.
              </p>
            </CardContent>
          </Card>
        ) : (
          <Card className="border-0 shadow-sm">
            <CardContent className="pt-8 pb-8 space-y-6">
              <div className="flex items-center gap-4">
                <SignedThumb filePath={sub.profile_photo_url} label="profile photo" size={88} />
                <div>
                  <h1 style={{ fontFamily: "'Cormorant Garamond', serif", fontWeight: 600, fontSize: 26, color: NAVY }}>
                    {sub.full_name || "—"}
                  </h1>
                  <div className="mt-1">{statusPill(sub.onboarding_status)}</div>
                  <div className="text-xs text-muted-foreground mt-1">
                    Submitted {fmtDateTime(sub.submitted_at)}
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <Field label="Email">{sub.email || "—"}</Field>
                <Field label="Position">{sub.position_title || "—"}</Field>
                <Field label="Phone">{sub.phone || "—"}</Field>
                <Field label="Digital Pay / GCash">{sub.digital_pay_gcash || "—"}</Field>
                <Field label="OnlineJobs.ph Profile">
                  {sub.onlinejobs_profile_url ? (
                    <a
                      href={sub.onlinejobs_profile_url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-1 text-primary underline underline-offset-2 break-all hover:opacity-80"
                    >
                      {sub.onlinejobs_profile_url} <ExternalLink className="h-3 w-3 shrink-0" />
                    </a>
                  ) : (
                    "—"
                  )}
                </Field>
              </div>

              <div className="space-y-3">
                <div className="text-[11px] font-semibold uppercase tracking-wider" style={{ color: GOLD }}>
                  Uploads
                </div>
                <div className="flex flex-wrap gap-6">
                  <div className="space-y-2">
                    <div className="text-xs text-muted-foreground">Speed-test screenshot</div>
                    <SignedThumb filePath={sub.speedtest_screenshot_url} label="speed-test screenshot" size={120} />
                    <div className="text-xs">
                      <SignedFileLink filePath={sub.speedtest_screenshot_url} label="Open full image" />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <div className="text-xs text-muted-foreground">Typing-test screenshot</div>
                    <SignedThumb filePath={sub.typing_screenshot_url} label="typing-test screenshot" size={120} />
                    <div className="text-xs">
                      <SignedFileLink filePath={sub.typing_screenshot_url} label="Open full image" />
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}
