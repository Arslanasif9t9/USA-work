import { useEffect, useMemo, useRef, useState } from "react";
import { useNavigate, useSearchParams } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { useHrIdentity } from "@/hooks/useHrIdentity";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { toast } from "sonner";
import { LogOut, CalendarClock, ExternalLink, Loader2, BarChart3, Plus, Video, Trash2 } from "lucide-react";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import PasswordGateModal from "@/components/PasswordGateModal";
import { RescheduleButton } from "@/components/RescheduleButton";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";

type Slot = {
  id: string;
  slot_start: string;
  slot_end: string;
  status: string;
  claimed_by_hr_id: string | null;
  claimed_at: string | null;
  completed_at: string | null;
  completion_method: string | null;
  notes: string | null;
  response_id: string | null;
  zoom_meeting_id: string | null;
  taken_over_from_hr_id: string | null;
};

type Enriched = Slot & {
  candidate_name: string;
  candidate_email: string;
  position: string;
  zoom_url: string;
  claimer_name: string | null;
};

type TabKey = "today" | "upcoming" | "past" | "unclaimed" | "mine";

const TZ = "Asia/Manila";
const fmtDateTime = (iso: string) =>
  new Date(iso).toLocaleString("en-US", {
    timeZone: TZ, month: "short", day: "numeric", hour: "numeric", minute: "2-digit",
  });

function RegenerateAllZoomButton() {
  const [open, setOpen] = useState(false);
  const [busy, setBusy] = useState(false);
  const [result, setResult] = useState<{ ok: number; failed: number; total: number } | null>(null);

  const run = async () => {
    setBusy(true);
    setResult(null);
    try {
      const { data, error } = await supabase.functions.invoke("regenerate-zoom-meeting", {
        body: { batch_all_upcoming: true },
      });
      if (error) throw error;
      const r = data as any;
      setResult({ ok: r?.ok ?? 0, failed: r?.failed ?? 0, total: r?.total ?? 0 });
      if ((r?.failed ?? 0) === 0) {
        toast.success(`Regenerated ${r?.ok ?? 0} Zoom links and re-sent confirmations.`);
      } else {
        toast.warning(`Done: ${r?.ok ?? 0} succeeded, ${r?.failed ?? 0} failed. See console.`);
        console.warn("regenerate-zoom-meeting results:", r?.results);
      }
    } catch (e: any) {
      toast.error(e?.message || "Batch regenerate failed");
    } finally {
      setBusy(false);
    }
  };

  return (
    <>
      <Button variant="outline" size="sm" onClick={() => setOpen(true)}>
        <Video className="h-4 w-4 mr-1.5" /> Regen All Zoom Links
      </Button>
      <AlertDialog open={open} onOpenChange={(o) => { setOpen(o); if (!o) setResult(null); }}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Regenerate Zoom links for all upcoming bookings?</AlertDialogTitle>
            <AlertDialogDescription>
              Creates fresh Zoom meetings on the active account for every upcoming booked/reserved slot,
              repoints each booking, marks old meetings cancelled, and re-sends each candidate a
              confirmation email with the new working link. Use this after switching Zoom accounts.
              {result && (
                <span className="block mt-3 text-foreground">
                  Last run: <strong>{result.ok}</strong> succeeded, <strong>{result.failed}</strong> failed
                  {" "}(of {result.total}).
                </span>
              )}
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={busy}>Close</AlertDialogCancel>
            <AlertDialogAction onClick={run} disabled={busy}>
              {busy ? <Loader2 className="h-4 w-4 animate-spin mr-2" /> : null}
              Run batch regenerate
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
}

function timeUntil(iso: string) {
  const diff = new Date(iso).getTime() - Date.now();
  if (diff < 0) {
    const past = Math.abs(diff);
    if (past < 60 * 60 * 1000) return `${Math.floor(past / 60000)} min ago`;
    if (past < 24 * 60 * 60 * 1000) return `${Math.floor(past / 3600000)}h ago`;
    return `passed`;
  }
  if (diff < 60 * 60 * 1000) return `in ${Math.floor(diff / 60000)} min`;
  if (diff < 24 * 60 * 60 * 1000) return `in ${Math.floor(diff / 3600000)}h`;
  return `in ${Math.floor(diff / 86400000)} days`;
}

const NAVY = "#1a2547";

function StatCard({ label, value, danger, active, onClick }: { label: string; value: number; danger?: boolean; active?: boolean; onClick?: () => void }) {
  return (
    <button
      onClick={onClick}
      className={`text-left bg-card rounded-md p-4 border transition-all ${
        active ? "border-primary shadow-sm" : "border-border hover:border-foreground/30"
      }`}
    >
      <div
        style={{ fontFamily: "'Cormorant Garamond', serif", fontWeight: 600, fontSize: 28, color: danger && value > 0 ? "#b91c1c" : NAVY, lineHeight: 1 }}
      >
        {value}
      </div>
      <div className="mt-2 text-[11px] uppercase tracking-wider text-muted-foreground font-medium">{label}</div>
    </button>
  );
}

function StatusBadge({ slot, hrId, hrMap }: { slot: Enriched; hrId: string | null; hrMap: Record<string, string> }) {
  const now = Date.now();
  const ended = new Date(slot.slot_end).getTime() < now;
  if (slot.status === "cancelled") return <Badge variant="outline" className="border-red-300 text-red-700">Cancelled</Badge>;
  if (slot.completed_at) {
    if (slot.completion_method === "no_show") return <Badge className="bg-red-100 text-red-800 hover:bg-red-100 border-0">No-Show</Badge>;
    if (slot.completion_method === "boss_override") return <Badge className="bg-purple-100 text-purple-800 hover:bg-purple-100 border-0">Force Completed</Badge>;
    return <Badge className="bg-green-100 text-green-800 hover:bg-green-100 border-0">Completed</Badge>;
  }
  if (!slot.claimed_by_hr_id) {
    if (ended) return <Badge className="bg-red-200 text-red-900 hover:bg-red-200 border-0">Both Missed</Badge>;
    return <Badge className="bg-amber-100 text-amber-900 hover:bg-amber-100 border-0">Unclaimed</Badge>;
  }
  if (slot.claimed_by_hr_id === hrId) return <Badge className="bg-blue-100 text-blue-800 hover:bg-blue-100 border-0">Claimed by Me</Badge>;
  return <Badge variant="secondary">Claimed by {hrMap[slot.claimed_by_hr_id] || "HR"}</Badge>;
}

const BookingsDashboard = () => {
  const navigate = useNavigate();
  const [params, setParams] = useSearchParams();
  const { user, signOut } = useAuth();
  const hr = useHrIdentity();
  const [slots, setSlots] = useState<Enriched[]>([]);
  const [hrMap, setHrMap] = useState<Record<string, string>>({});
  const [loading, setLoading] = useState(true);
  const [tab, setTab] = useState<TabKey>((params.get("tab") as TabKey) || "today");
  const [actionBusy, setActionBusy] = useState<string | null>(null);
  const [gate, setGate] = useState<null | { kind: "force_claim" | "send_recovery" | "force_complete"; slotId: string; prefillEmail?: string }>(null);
  const [customOpen, setCustomOpen] = useState(false);
  const [customDate, setCustomDate] = useState("");
  const [customTime, setCustomTime] = useState("");
  const [customNotes, setCustomNotes] = useState("");
  const [customBusy, setCustomBusy] = useState(false);
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const [confirmDeleteId, setConfirmDeleteId] = useState<string | null>(null);
  const [deleting, setDeleting] = useState(false);

  // Single-row delete by id from interview_slots (the booking row this page lists). No responses/answers touched.
  const handleDelete = async (id: string) => {
    setDeleting(true);
    try {
      const { error } = await supabase.from("interview_slots").delete().eq("id", id);
      if (error) throw error;
      setSlots((prev) => prev.filter((s) => s.id !== id));
      toast.success("Booking deleted");
      setConfirmDeleteId(null);
    } catch (e: any) {
      toast.error(e?.message || "Failed to delete booking");
    } finally {
      setDeleting(false);
    }
  };

  useEffect(() => { document.title = "EIA — Booking Dashboard"; }, []);

  const loadHrs = async () => {
    const { data } = await supabase.from("hr_users").select("id, display_name");
    const m: Record<string, string> = {};
    (data || []).forEach((h: any) => { m[h.id] = h.display_name; });
    setHrMap(m);
  };

  const load = async () => {
    setLoading(true);
    const since = new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString();
    const until = new Date(Date.now() + 14 * 24 * 60 * 60 * 1000).toISOString();
    const { data: rows, error } = await supabase
      .from("interview_slots")
      .select("id, slot_start, slot_end, status, claimed_by_hr_id, claimed_at, completed_at, completion_method, notes, response_id, zoom_meeting_id, taken_over_from_hr_id")
      .gte("slot_start", since)
      .lte("slot_start", until)
      .in("status", ["booked", "cancelled"])
      .order("slot_start", { ascending: true });
    if (error) { toast.error(error.message); setLoading(false); return; }

    const responseIds = (rows || []).map((s) => s.response_id).filter(Boolean) as string[];
    const zoomIds = (rows || []).map((s) => s.zoom_meeting_id).filter(Boolean) as string[];

    const [respRes, zoomRes] = await Promise.all([
      responseIds.length
        ? supabase.from("responses").select("id, form_id").in("id", responseIds)
        : Promise.resolve({ data: [] as any[] }),
      zoomIds.length
        ? supabase.from("zoom_meetings").select("id, join_url").in("id", zoomIds)
        : Promise.resolve({ data: [] as any[] }),
    ]);

    const formIds = Array.from(new Set((respRes.data || []).map((r: any) => r.form_id)));
    const [qsRes, ansRes, metaRes] = await Promise.all([
      formIds.length ? supabase.from("questions").select("id, form_id, type, label").in("form_id", formIds) : Promise.resolve({ data: [] as any[] }),
      responseIds.length ? supabase.from("answers").select("response_id, question_id, answer_text").in("response_id", responseIds) : Promise.resolve({ data: [] as any[] }),
      formIds.length ? supabase.from("form_metadata").select("form_id, position_title").in("form_id", formIds) : Promise.resolve({ data: [] as any[] }),
    ]);

    const respMap: Record<string, string> = {};
    (respRes.data || []).forEach((r: any) => { respMap[r.id] = r.form_id; });
    const zoomMap: Record<string, string> = {};
    (zoomRes.data || []).forEach((z: any) => { zoomMap[z.id] = z.join_url; });
    const metaMap: Record<string, string> = {};
    (metaRes.data || []).forEach((m: any) => { metaMap[m.form_id] = m.position_title || ""; });

    // questions per form: pick email + name
    const emailQByForm: Record<string, string> = {};
    const nameQByForm: Record<string, string> = {};
    (qsRes.data || []).forEach((q: any) => {
      if (q.type === "email" && !emailQByForm[q.form_id]) emailQByForm[q.form_id] = q.id;
    });
    (qsRes.data || []).forEach((q: any) => {
      if (q.type === "short_text" && !nameQByForm[q.form_id] && /name/i.test(q.label || "")) {
        nameQByForm[q.form_id] = q.id;
      }
    });
    (qsRes.data || []).forEach((q: any) => {
      if (q.type === "short_text" && !nameQByForm[q.form_id]) nameQByForm[q.form_id] = q.id;
    });

    const ansByResp: Record<string, Record<string, string>> = {};
    (ansRes.data || []).forEach((a: any) => {
      ansByResp[a.response_id] ??= {};
      ansByResp[a.response_id][a.question_id] = a.answer_text || "";
    });

    const enriched: Enriched[] = (rows || []).map((s: any) => {
      const formId = s.response_id ? respMap[s.response_id] : undefined;
      const eq = formId ? emailQByForm[formId] : undefined;
      const nq = formId ? nameQByForm[formId] : undefined;
      const ans = s.response_id ? ansByResp[s.response_id] || {} : {};
      return {
        ...s,
        candidate_name: (nq && ans[nq]) || "Candidate",
        candidate_email: (eq && ans[eq]) || "",
        position: formId ? metaMap[formId] || "—" : "—",
        zoom_url: s.zoom_meeting_id ? zoomMap[s.zoom_meeting_id] || "" : "",
        claimer_name: null,
      };
    });
    setSlots(enriched);
    setLoading(false);
  };

  useEffect(() => { if (!hr.loading) { loadHrs(); load(); } }, [hr.loading]);

  // Realtime
  useEffect(() => {
    const channel = supabase
      .channel("bookings-dash")
      .on("postgres_changes", { event: "*", schema: "public", table: "interview_slots" }, (payload) => {
        if (payload.eventType === "INSERT" || (payload.eventType === "UPDATE" && (payload.new as any)?.status === "booked" && (payload.old as any)?.status !== "booked")) {
          const start = (payload.new as any)?.slot_start;
          toast.success(`🔔 New booking ${start ? "at " + fmtDateTime(start) : ""}`);
          try { audioRef.current?.play(); } catch {}
        }
        load();
      })
      .subscribe();
    return () => { supabase.removeChannel(channel); };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const startOfDay = (d: Date) => { const x = new Date(d); x.setHours(0,0,0,0); return x; };
  const today = startOfDay(new Date());
  const todayEnd = new Date(today.getTime() + 24 * 60 * 60 * 1000);
  const in3Days = new Date(today.getTime() + 4 * 24 * 60 * 60 * 1000);
  const weekAgoStart = (() => {
    const d = startOfDay(new Date());
    const dow = d.getDay(); // 0 sun
    d.setDate(d.getDate() - dow);
    return d;
  })();

  const stats = useMemo(() => {
    const todayCount = slots.filter((s) => new Date(s.slot_start) >= today && new Date(s.slot_start) < todayEnd && s.status !== "cancelled").length;
    const unclaimed = slots.filter((s) => !s.claimed_by_hr_id && !s.completed_at && s.status === "booked" && new Date(s.slot_end) > new Date(Date.now() - 60*60*1000)).length;
    const completedToday = slots.filter((s) => s.completed_at && new Date(s.completed_at) >= today && s.claimed_by_hr_id === hr.hrId && s.completion_method !== "no_show").length;
    const weekTotal = slots.filter((s) => s.completed_at && new Date(s.completed_at) >= weekAgoStart && s.claimed_by_hr_id === hr.hrId && s.completion_method !== "no_show").length;
    return { todayCount, unclaimed, completedToday, weekTotal };
  }, [slots, hr.hrId]);

  const filtered = useMemo(() => {
    return slots.filter((s) => {
      const start = new Date(s.slot_start);
      if (tab === "today") return start >= today && start < todayEnd;
      if (tab === "upcoming") return start >= todayEnd && start < in3Days;
      if (tab === "past") return start < today;
      if (tab === "unclaimed") return !s.claimed_by_hr_id && !s.completed_at && s.status === "booked";
      if (tab === "mine") return s.claimed_by_hr_id === hr.hrId && s.completed_at && s.completion_method !== "no_show";
      return true;
    });
  }, [slots, tab, hr.hrId]);

  const setTabAndUrl = (t: TabKey) => { setTab(t); setParams({ tab: t }); };

  const call = async (path: string, body: any) => {
    const { data: { session } } = await supabase.auth.getSession();
    const r = await fetch(`${import.meta.env.VITE_SUPABASE_URL}/functions/v1/${path}`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${session?.access_token}`,
      },
      body: JSON.stringify(body),
    });
    const j = await r.json().catch(() => ({}));
    if (!r.ok) throw new Error(j?.error || `Request failed (${r.status})`);
    return j;
  };

  const onClaim = async (slotId: string) => {
    setActionBusy(slotId);
    try { await call("claim-interview", { slot_id: slotId }); toast.success("Claimed"); await load(); }
    catch (e: any) { toast.error(e.message); } finally { setActionBusy(null); }
  };
  const onUnclaim = async (slotId: string) => {
    setActionBusy(slotId);
    try { await call("unclaim-interview", { slot_id: slotId }); toast.success("Unclaimed"); await load(); }
    catch (e: any) { toast.error(e.message); } finally { setActionBusy(null); }
  };
  const onAttended = async (slotId: string) => {
    setActionBusy(slotId);
    try { await call("mark-attended", { slot_id: slotId }); toast.success("Marked attended"); await load(); }
    catch (e: any) { toast.error(e.message); } finally { setActionBusy(null); }
  };
  const onNoShow = async (slotId: string) => {
    setActionBusy(slotId);
    try { await call("mark-no-show", { slot_id: slotId }); toast.success("Marked no-show"); await load(); }
    catch (e: any) { toast.error(e.message); } finally { setActionBusy(null); }
  };
  const onBlock = async (slotId: string) => {
    setActionBusy(slotId);
    try {
      const { data: { session } } = await supabase.auth.getSession();
      const r = await fetch(`${import.meta.env.VITE_SUPABASE_URL}/functions/v1/block-slot`, {
        method: "POST",
        headers: { "Content-Type": "application/json", Authorization: `Bearer ${session?.access_token}` },
        body: JSON.stringify({ slot_id: slotId, reason: "HR unavailable" }),
      });
      if (!r.ok) throw new Error("block_failed");
      toast.success("Blocked");
      await load();
    } catch (e: any) { toast.error(e.message); } finally { setActionBusy(null); }
  };

  const onGateConfirm = async (password: string, extras?: { email?: string }) => {
    if (!gate) return;
    const path = gate.kind === "force_claim" ? "force-claim" : gate.kind === "send_recovery" ? "send-recovery-email" : "force-complete";
    const body: Record<string, unknown> = { slot_id: gate.slotId, password };
    if (gate.kind === "force_complete") body.reason = "Override";
    if (gate.kind === "send_recovery" && extras?.email) body.override_email = extras.email;
    await call(path, body);
    toast.success("Done");
    setGate(null);
    await load();
  };

  const submitCustomSlot = async () => {
    if (!customDate || !customTime) {
      toast.error("Date and time are required");
      return;
    }
    setCustomBusy(true);
    try {
      await call("add-custom-slot", {
        slot_date: customDate,
        slot_time: customTime,
        notes: customNotes || null,
      });
      toast.success(`Custom slot added: ${customDate} at ${customTime}`);
      setCustomOpen(false);
      setCustomDate(""); setCustomTime(""); setCustomNotes("");
      await load();
    } catch (e: any) {
      toast.error(e.message || "Failed to add slot");
    } finally {
      setCustomBusy(false);
    }
  };

  const renderActions = (s: Enriched) => {
    const now = Date.now();
    const ended = new Date(s.slot_end).getTime() < now;
    const startedPlus30 = new Date(s.slot_start).getTime() + 30 * 60 * 1000 < now;
    const endedPlus5 = new Date(s.slot_end).getTime() + 5 * 60 * 1000 < now;
    const busy = actionBusy === s.id;

    if (s.status === "cancelled") {
      return <span className="text-xs text-muted-foreground">Cancelled</span>;
    }
    if (s.completed_at) {
      if (s.completion_method === "no_show") {
        return (
          <RescheduleButton
            slotId={s.id}
            candidateName={s.candidate_name || ""}
            candidateEmail={s.candidate_email || ""}
            onDone={load}
            label="Send Reschedule"
          />
        );
      }
      return <span className="text-xs text-muted-foreground">Done</span>;
    }
    if (!s.claimed_by_hr_id) {
      if (ended) {
        // Both missed
        return (
          <RescheduleButton
            slotId={s.id}
            candidateName={s.candidate_name || ""}
            candidateEmail={s.candidate_email || ""}
            onDone={load}
            variant="destructive"
            label="Send Recovery Email"
          />
        );
      }
      return (
        <div className="flex gap-2 flex-wrap">
          <Button size="sm" disabled={busy} onClick={() => onClaim(s.id)} style={{ backgroundColor: NAVY }}>
            {busy ? <Loader2 className="h-4 w-4 animate-spin" /> : "Claim"}
          </Button>
          <Button size="sm" variant="ghost" onClick={() => onBlock(s.id)}>Block Slot</Button>
        </div>
      );
    }
    if (s.claimed_by_hr_id === hr.hrId) {
      return (
        <div className="flex gap-2 flex-wrap">
          {s.zoom_url && (
            <Button size="sm" asChild className="bg-amber-500 hover:bg-amber-600 text-white">
              <a href={s.zoom_url} target="_blank" rel="noreferrer"><ExternalLink className="h-3 w-3 mr-1" />Join Zoom</a>
            </Button>
          )}
          <Button size="sm" variant="ghost" onClick={() => onUnclaim(s.id)}>Unclaim</Button>
          {endedPlus5 && (
            <>
              <Button size="sm" className="bg-green-600 hover:bg-green-700 text-white" onClick={() => onAttended(s.id)}>I Attended</Button>
              <Button size="sm" variant="ghost" className="text-red-600 hover:text-red-700" onClick={() => onNoShow(s.id)}>No-Show</Button>
            </>
          )}
        </div>
      );
    }
    // Claimed by other
    return (
      <div className="flex gap-2 flex-wrap">
        {startedPlus30 && (
          <Button size="sm" className="bg-amber-500 hover:bg-amber-600 text-white" onClick={() => setGate({ kind: "force_claim", slotId: s.id })}>
            Take Over
          </Button>
        )}
        <span className="text-xs text-muted-foreground self-center">Claimed by {hrMap[s.claimed_by_hr_id] || "HR"}</span>
      </div>
    );
  };

  const handleLogout = async () => { await signOut(); navigate("/login", { replace: true }); };

  const welcomeName = hr.displayName || (user?.email || "").split("@")[0];
  const todayStr = new Date().toLocaleDateString("en-US", { weekday: "long", month: "long", day: "numeric", year: "numeric" });

  return (
    <div className="min-h-screen bg-background">
      <audio ref={audioRef} preload="auto" src="data:audio/wav;base64,UklGRiQAAABXQVZFZm10IBAAAAABAAEAQB8AAEAfAAABAAgAZGF0YQAAAAA=" />
      <header className="bg-background" style={{ borderBottom: "1px solid #e1e4ec" }}>
        <div className="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-6">
            <button onClick={() => navigate("/dashboard")} className="text-left">
              <div style={{ fontFamily: "'Cormorant Garamond', serif", fontWeight: 600, fontSize: 18, color: NAVY, letterSpacing: 1 }}>EIA Talent Recruiting System</div>
              <span className="text-[9px] uppercase tracking-widest text-muted-foreground">Internal HR Tool</span>
            </button>
            <nav className="flex items-center gap-1 ml-4">
              <Button variant="ghost" size="sm" onClick={() => navigate("/dashboard")}>Forms</Button>
              <Button variant="secondary" size="sm" className="gap-1.5">
                <CalendarClock className="h-4 w-4" /> Bookings {stats.unclaimed > 0 && <span className="ml-1 px-1.5 py-0.5 text-[10px] bg-red-600 text-white rounded-full">{stats.unclaimed}</span>}
              </Button>
              {hr.role === "master_admin" && (
                <Button variant="ghost" size="sm" onClick={() => navigate("/dashboard/bookings/stats")}><BarChart3 className="h-4 w-4 mr-1" />Stats</Button>
              )}
            </nav>
          </div>
          <Button variant="ghost" size="sm" onClick={handleLogout}><LogOut className="h-4 w-4 mr-2" />{user?.email}</Button>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-6 py-8">
        <div className="mb-6 flex items-start justify-between gap-4 flex-wrap">
          <div>
            <h1 style={{ fontFamily: "'Cormorant Garamond', serif", fontWeight: 600, fontSize: 32, color: NAVY, margin: 0 }}><span className="sr-only">EIA — </span>Bookings Dashboard</h1>
            <p className="text-sm text-muted-foreground mt-1">Welcome, {welcomeName} · {todayStr}</p>
          </div>
          <div className="flex items-center gap-2">
            <RegenerateAllZoomButton />
            <Button onClick={() => setCustomOpen(true)} style={{ backgroundColor: NAVY }} className="text-white">
              <Plus className="h-4 w-4 mr-1.5" /> Add Custom Slot
            </Button>
          </div>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-6">
          <StatCard label="Today" value={stats.todayCount} active={tab === "today"} onClick={() => setTabAndUrl("today")} />
          <StatCard label="Unclaimed" value={stats.unclaimed} danger active={tab === "unclaimed"} onClick={() => setTabAndUrl("unclaimed")} />
          <StatCard label="Completed (Me)" value={stats.completedToday} active={tab === "mine"} onClick={() => setTabAndUrl("mine")} />
          <StatCard label="Total This Week" value={stats.weekTotal} />
        </div>

        <div className="flex gap-1 mb-4 overflow-x-auto border-b">
          {(["today","upcoming","past","unclaimed","mine"] as TabKey[]).map((t) => (
            <button
              key={t}
              onClick={() => setTabAndUrl(t)}
              className={`px-4 py-2 text-sm whitespace-nowrap border-b-2 -mb-px transition-colors ${
                tab === t ? "border-primary text-foreground font-medium" : "border-transparent text-muted-foreground hover:text-foreground"
              }`}
            >
              {t === "today" ? "Today" : t === "upcoming" ? "Upcoming" : t === "past" ? "Past" : t === "unclaimed" ? "Unclaimed" : "My Completions"}
            </button>
          ))}
        </div>

        {loading ? (
          <div className="text-center py-16 text-muted-foreground"><Loader2 className="h-6 w-6 animate-spin inline-block" /></div>
        ) : filtered.length === 0 ? (
          <div className="text-center py-16 text-muted-foreground border border-dashed rounded-lg">No interviews in this view</div>
        ) : (
          <>
            {/* Desktop table */}
            <div className="hidden md:block border rounded-md overflow-hidden">
              <table className="w-full text-sm">
                <thead className="bg-muted/50">
                  <tr className="text-left">
                    <th className="px-3 py-2 font-medium">Status</th>
                    <th className="px-3 py-2 font-medium">When</th>
                    <th className="px-3 py-2 font-medium">In</th>
                    <th className="px-3 py-2 font-medium">Candidate</th>
                    <th className="px-3 py-2 font-medium">Position</th>
                    <th className="px-3 py-2 font-medium">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {filtered.map((s) => (
                    <tr key={s.id} className="border-t hover:bg-muted/30">
                      <td className="px-3 py-2"><StatusBadge slot={s} hrId={hr.hrId} hrMap={hrMap} /></td>
                      <td className="px-3 py-2 whitespace-nowrap">{fmtDateTime(s.slot_start)}</td>
                      <td className="px-3 py-2 whitespace-nowrap text-muted-foreground">{timeUntil(s.slot_start)}</td>
                      <td className="px-3 py-2">
                        <div className="font-medium">{s.candidate_name}</div>
                        <div className="text-xs text-muted-foreground">{s.candidate_email}</div>
                      </td>
                      <td className="px-3 py-2">{s.position}</td>
                      <td className="px-3 py-2">
                        <div className="flex items-center gap-2">
                          {renderActions(s)}
                          <Button
                            variant="ghost"
                            size="icon"
                            className="h-9 w-9 text-red-600 hover:text-red-700 hover:bg-red-50 border border-red-200 shrink-0"
                            onClick={() => setConfirmDeleteId(s.id)}
                            aria-label="Delete booking"
                          >
                            <Trash2 className="h-5 w-5" />
                          </Button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            {/* Mobile cards */}
            <div className="md:hidden space-y-3">
              {filtered.map((s) => (
                <div key={s.id} className="border rounded-md p-3 bg-card">
                  <div className="flex items-center justify-between mb-2">
                    <div className="font-medium">{s.candidate_name}</div>
                    <StatusBadge slot={s} hrId={hr.hrId} hrMap={hrMap} />
                  </div>
                  <div className="text-xs text-muted-foreground mb-1">{s.candidate_email}</div>
                  <div className="text-xs mb-1">{fmtDateTime(s.slot_start)} · <span className="text-muted-foreground">{timeUntil(s.slot_start)}</span></div>
                  <div className="text-xs text-muted-foreground mb-3">{s.position}</div>
                  <div className="flex items-center gap-2">
                    <div className="flex-1">{renderActions(s)}</div>
                    <Button
                      variant="ghost"
                      size="icon"
                      className="h-9 w-9 text-red-600 hover:text-red-700 hover:bg-red-50 border border-red-200 shrink-0"
                      onClick={() => setConfirmDeleteId(s.id)}
                      aria-label="Delete booking"
                    >
                      <Trash2 className="h-5 w-5" />
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          </>
        )}
      </main>

      <PasswordGateModal
        open={!!gate}
        onOpenChange={(o) => !o && setGate(null)}
        title={
          gate?.kind === "force_claim" ? "Take over this interview" :
          gate?.kind === "send_recovery" ? "Send recovery email" :
          "Force complete"
        }
        description={
          gate?.kind === "force_claim" ? "Enter the Claim2828 override password." :
          gate?.kind === "send_recovery" ? "Enter the EMAIL2828 override password. The slot will be cancelled and the candidate will receive a 3-day rebook link." :
          "Enter the Boss2828 override password."
        }
        confirmLabel="Confirm"
        emailField={
          gate?.kind === "send_recovery"
            ? {
                label: "Send recovery link to",
                initialValue: gate.prefillEmail || "",
                helpText: "Pre-filled from the candidate's application. Edit to correct.",
              }
            : undefined
        }
        onConfirm={onGateConfirm}
      />

      <Dialog open={customOpen} onOpenChange={setCustomOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Add Custom Time Slot</DialogTitle>
            <DialogDescription>
              Add a slot outside default working hours (Sundays, evenings, early mornings, etc.). It will be immediately available to candidates.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-2">
            <div className="space-y-1.5">
              <Label htmlFor="cs-date">Date (Manila / PHT)</Label>
              <Input
                id="cs-date"
                type="date"
                value={customDate}
                min={new Date().toISOString().slice(0, 10)}
                onChange={(e) => setCustomDate(e.target.value)}
              />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="cs-time">Time (24h, any 30-min increment)</Label>
              <Input
                id="cs-time"
                type="time"
                step={1800}
                value={customTime}
                onChange={(e) => setCustomTime(e.target.value)}
              />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="cs-notes">Notes (optional)</Label>
              <Textarea
                id="cs-notes"
                placeholder="e.g. HR2 night shift"
                value={customNotes}
                onChange={(e) => setCustomNotes(e.target.value)}
                rows={2}
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setCustomOpen(false)} disabled={customBusy}>Cancel</Button>
            <Button onClick={submitCustomSlot} disabled={customBusy} style={{ backgroundColor: NAVY }} className="text-white">
              {customBusy ? <><Loader2 className="h-4 w-4 mr-2 animate-spin" />Saving…</> : "Save Slot"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <AlertDialog open={confirmDeleteId !== null} onOpenChange={(o) => { if (!o) setConfirmDeleteId(null); }}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete this booking?</AlertDialogTitle>
            <AlertDialogDescription>
              Permanently delete this booking row? This cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={deleting}>Cancel</AlertDialogCancel>
            <AlertDialogAction
              className="bg-red-600 hover:bg-red-700"
              disabled={deleting}
              onClick={(e) => { e.preventDefault(); if (confirmDeleteId) handleDelete(confirmDeleteId); }}
            >
              {deleting ? "Deleting…" : "Delete"}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
};

export default BookingsDashboard;
