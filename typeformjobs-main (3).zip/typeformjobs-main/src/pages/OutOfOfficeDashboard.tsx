import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { toast } from "sonner";
import { Loader2, CalendarOff, ArrowLeft, Trash2 } from "lucide-react";
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import PasswordGateModal from "@/components/PasswordGateModal";

type Cfg = {
  is_out_of_office: boolean;
  out_of_office_start: string | null;
  out_of_office_end: string | null;
  ooo_active_period_id: string | null;
};
type Period = {
  id: string; start_date: string; end_date: string; reason: string | null;
  enabled_at: string; disabled_at: string | null;
};

const MASTER_EMAIL = "spark11179@gmail.com";

export default function OutOfOfficeDashboard() {
  const { user, loading: authLoading } = useAuth();
  const navigate = useNavigate();
  const [cfg, setCfg] = useState<Cfg | null>(null);
  const [periods, setPeriods] = useState<Period[]>([]);
  const [loading, setLoading] = useState(true);
  const [start, setStart] = useState("");
  const [end, setEnd] = useState("");
  const [reason, setReason] = useState("");
  const [enableOpen, setEnableOpen] = useState(false);
  const [endOpen, setEndOpen] = useState(false);
  const [confirmDeleteId, setConfirmDeleteId] = useState<string | null>(null);
  const [deleting, setDeleting] = useState(false);

  const isMaster = (user?.email || "").toLowerCase() === MASTER_EMAIL;

  // Single-row delete by id from out_of_office_periods (this page's History records). No cascade.
  const handleDelete = async (id: string) => {
    setDeleting(true);
    try {
      const { error } = await supabase.from("out_of_office_periods").delete().eq("id", id);
      if (error) throw error;
      setPeriods((prev) => prev.filter((p) => p.id !== id));
      toast.success("Out of Office record deleted");
      setConfirmDeleteId(null);
    } catch (e: any) {
      toast.error(e?.message || "Failed to delete record");
    } finally {
      setDeleting(false);
    }
  };

  const load = async () => {
    setLoading(true);
    const [{ data: c }, { data: p }] = await Promise.all([
      supabase.from("scheduling_config").select("is_out_of_office, out_of_office_start, out_of_office_end, ooo_active_period_id").eq("id", 1).maybeSingle(),
      supabase.from("out_of_office_periods").select("*").order("enabled_at", { ascending: false }).limit(50),
    ]);
    setCfg(c as any);
    setPeriods((p || []) as any);
    setLoading(false);
  };

  useEffect(() => { if (!authLoading) load(); }, [authLoading]);

  if (authLoading) return <div className="p-8"><Loader2 className="h-5 w-5 animate-spin" /></div>;
  if (!user) { navigate("/login"); return null; }
  if (!isMaster) {
    return (
      <div className="min-h-screen p-8 max-w-2xl mx-auto">
        <h1 className="text-2xl font-bold mb-2">Restricted</h1>
        <p className="text-muted-foreground">Out of Office controls are limited to the master admin.</p>
        <Button variant="outline" className="mt-4" onClick={() => navigate("/dashboard")}>Back to dashboard</Button>
      </div>
    );
  }

  const handleEnable = async (password: string) => {
    if (!start || !end) throw new Error("Pick start and end dates");
    if (end < start) throw new Error("End date must be after start date");
    const { data, error } = await supabase.functions.invoke("enable-out-of-office", {
      body: { password, start_date: start, end_date: end, reason },
    });
    if (error || (data as any)?.error) throw new Error((data as any)?.error || error?.message || "Failed");
    toast.success(`OOO enabled. ${(data as any).affected} bookings cancelled, ${(data as any).emails_sent} candidates notified.`);
    setStart(""); setEnd(""); setReason("");
    await load();
  };

  const handleEndEarly = async (password: string) => {
    const { data, error } = await supabase.functions.invoke("end-out-of-office", { body: { password } });
    if (error || (data as any)?.error) throw new Error((data as any)?.error || error?.message || "Failed");
    toast.success("Out of Office ended.");
    await load();
  };

  const active = !!cfg?.is_out_of_office;
  const todayIso = new Date().toISOString().slice(0, 10);

  return (
    <div className="min-h-screen p-6 max-w-4xl mx-auto space-y-6">
      <Button variant="ghost" size="sm" onClick={() => navigate("/dashboard")}><ArrowLeft className="h-4 w-4 mr-1" />Dashboard</Button>
      <div>
        <h1 className="text-3xl font-bold flex items-center gap-2"><CalendarOff className="h-7 w-7" />Out of Office</h1>
        <p className="text-muted-foreground mt-1">Pause new interview bookings, cancel affected interviews, auto-email candidates with a rebook link.</p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Current Status</CardTitle>
        </CardHeader>
        <CardContent>
          {loading ? <Loader2 className="h-5 w-5 animate-spin" /> : active ? (
            <div className="space-y-3">
              <Badge className="bg-red-600 hover:bg-red-700">Active</Badge>
              <p className="text-sm"><strong>{cfg?.out_of_office_start}</strong> → <strong>{cfg?.out_of_office_end}</strong></p>
              <Button variant="destructive" onClick={() => setEndOpen(true)}>End Out of Office Now</Button>
            </div>
          ) : (
            <div className="space-y-2">
              <Badge variant="secondary">None</Badge>
              <p className="text-sm text-muted-foreground">Bookings are open as normal.</p>
            </div>
          )}
        </CardContent>
      </Card>

      {!active && (
        <Card>
          <CardHeader>
            <CardTitle>Enable Out of Office</CardTitle>
            <CardDescription>Requires Boss2929 password. This will cancel all booked interviews in range and email candidates a rebook link.</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label>Start date</Label>
                <Input type="date" value={start} min={todayIso} onChange={(e) => setStart(e.target.value)} />
              </div>
              <div>
                <Label>End date</Label>
                <Input type="date" value={end} min={start || todayIso} onChange={(e) => setEnd(e.target.value)} />
              </div>
            </div>
            <div>
              <Label>Reason (optional, internal)</Label>
              <Textarea value={reason} onChange={(e) => setReason(e.target.value)} placeholder="e.g. Family emergency" />
            </div>
            <Button disabled={!start || !end} onClick={() => setEnableOpen(true)}>Enable Out of Office</Button>
          </CardContent>
        </Card>
      )}

      <Card>
        <CardHeader><CardTitle>History</CardTitle></CardHeader>
        <CardContent>
          {periods.length === 0 ? (
            <p className="text-sm text-muted-foreground">No previous OOO periods.</p>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Start</TableHead><TableHead>End</TableHead>
                  <TableHead>Reason</TableHead><TableHead>Enabled</TableHead><TableHead>Ended</TableHead>
                  <TableHead className="w-[60px] text-right">Delete</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {periods.map((p) => (
                  <TableRow key={p.id}>
                    <TableCell>{p.start_date}</TableCell>
                    <TableCell>{p.end_date}</TableCell>
                    <TableCell className="max-w-[200px] truncate">{p.reason || "—"}</TableCell>
                    <TableCell>{new Date(p.enabled_at).toLocaleDateString()}</TableCell>
                    <TableCell>{p.disabled_at ? new Date(p.disabled_at).toLocaleDateString() : <Badge>Active</Badge>}</TableCell>
                    <TableCell className="text-right">
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-9 w-9 text-red-600 hover:text-red-700 hover:bg-red-50 border border-red-200"
                        onClick={() => setConfirmDeleteId(p.id)}
                        aria-label="Delete out of office record"
                      >
                        <Trash2 className="h-5 w-5" />
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>

      <PasswordGateModal
        open={enableOpen}
        onOpenChange={setEnableOpen}
        title="Confirm Enable Out of Office"
        description="Enter the Boss2929 override password to cancel affected bookings and notify candidates."
        confirmLabel="Enable OOO"
        onConfirm={handleEnable}
      />
      <PasswordGateModal
        open={endOpen}
        onOpenChange={setEndOpen}
        title="End Out of Office Early"
        description="Enter the Boss2929 override password to reopen bookings now."
        confirmLabel="End OOO"
        onConfirm={handleEndEarly}
      />

      <AlertDialog open={confirmDeleteId !== null} onOpenChange={(o) => { if (!o) setConfirmDeleteId(null); }}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete this Out of Office record?</AlertDialogTitle>
            <AlertDialogDescription>
              Permanently delete this Out of Office history record? This cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={deleting}>Cancel</AlertDialogCancel>
            <AlertDialogAction
              className="bg-red-600 hover:bg-red-700"
              disabled={deleting}
              onClick={(e) => { e.preventDefault(); if (confirmDeleteId) handleDelete(confirmDeleteId); }}
            >
              {deleting ? "Deleting…" : "Delete"}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
