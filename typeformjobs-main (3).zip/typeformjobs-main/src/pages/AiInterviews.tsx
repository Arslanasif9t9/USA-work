import { useCallback, useEffect, useMemo, useRef, useState, type Dispatch, type SetStateAction } from "react";
import { useNavigate, useSearchParams } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { ArrowLeft, Check, X, Eye, Video, MessageSquare, MapPin, Trash2, Loader2, Download } from "lucide-react";
import { toast } from "sonner";
import { detectContactQuestionIds } from "@/lib/candidateActions";
import { cleanPositionTitle } from "@/lib/positionTitle";
import { InvalidateAllLinksButton } from "@/components/InvalidateAllLinksButton";
import { RecoverInterviewButton } from "@/components/RecoverInterviewButton";
import { RescueCandidateButton } from "@/components/RescueCandidateButton";

import { SendCustomMessageDialog } from "@/components/SendCustomMessageDialog";
import { StopRemindersButton } from "@/components/StopRemindersButton";
import { SelfieThumb, FilePreviewDialog } from "@/components/FilePreview";
import { DisqualifyButton } from "@/components/DisqualifyButton";
import { HrNicknameField } from "@/components/HrNicknameField";
import { HrBadgePill, HrBadgeSelect } from "@/components/HrBadge";
import { AiTierBadge } from "@/components/AiTierBadge";
import { InterviewVideoDialog, videoRoundFromStage, buildVttFromTranscript, resolveHealthiestVideoSession } from "@/components/InterviewVideoDialog";


type Session = {
  id: string;
  response_id: string | null;
  retell_call_id: string | null;
  ended_at: string | null;
  duration_seconds: number | null;
  termination_reason: string | null;
  created_at: string;
  stage: string | null;
  session_hidden: boolean | null;
};
type Evaluation = {
  id: string;
  session_id: string;
  response_id: string | null;
  tier: string | null;
  ai_recommended: boolean | null;
  verdict: string | null;
  red_flags: string | null;
  summary: string | null;
};
type Resp = { id: string; form_id: string; round_stage: string | null; final_outcome: string | null; override_email: string | null; override_name: string | null; appointment_cancelled: boolean | null; appointment_permanently_deleted: boolean | null };
type FormRow = { id: string; title: string };
type Meta = { form_id: string; position_title: string | null };
type Question = { id: string; form_id: string; type: string; label: string; order_index?: number };
type Answer = { response_id: string; question_id: string; answer_text: string | null; file_url: string | null };
type Extra = { response_id: string; photo_file_url: string | null; hr_nickname: string | null; hr_badge: string | null };

const TIER_COLOR: Record<string, string> = {
  "best one": "bg-emerald-100 text-emerald-800",
  "breadwinner": "bg-sky-100 text-sky-800",
  "steady": "bg-blue-100 text-blue-800",
  "edgy": "bg-amber-100 text-amber-800",
  "red flag": "bg-rose-100 text-rose-800",
};

const tierClass = (t: string | null | undefined) =>
  TIER_COLOR[(t || "").toLowerCase().trim()] || "bg-slate-100 text-slate-700";

const fmtDuration = (s: number | null | undefined) => {
  if (!s || s <= 0) return "—";
  const m = Math.floor(s / 60);
  const r = s % 60;
  return m > 0 ? `${m}m ${r}s` : `${r}s`;
};

const fmtDate = (iso: string | null | undefined) => {
  if (!iso) return "—";
  try {
    return new Date(iso).toLocaleString("en-US", {
      month: "short", day: "numeric", year: "numeric",
      hour: "numeric", minute: "2-digit",
    });
  } catch { return "—"; }
};

const isFailedSession = (s: Session) => {
  const r = (s.termination_reason || "").toLowerCase();
  return /(error|not_joined|failed|abandon)/i.test(r);
};

// SMART COMPLETION RULE (identical in cron, RecoverInterviewButton, AiInterviews):
//   completed = NOT trueBail AND ( agentEnded OR duration_seconds >= 240 )
// agentEnded = the AGENT ended the call (a real finished interview even if short,
// e.g. Christine hangs up at 3:47). trueBail = error/not_joined/failed/abandon.
const COMPLETED_MIN_SECONDS = 240;
const AGENT_ENDED_REASONS = new Set(["agent_hangup", "max_duration_reached"]);
const isCompletedSession = (s: Session) => {
  if (isFailedSession(s)) return false;
  const reason = (s.termination_reason || "").toLowerCase();
  const agentEnded = AGENT_ENDED_REASONS.has(reason);
  return agentEnded || (s.duration_seconds ?? 0) >= COMPLETED_MIN_SECONDS;
};

// A candidate can live in three places. Route Locate Me to the right one so the
// ?locate highlight/scroll/flash actually finds them:
//  - disqualified → /dashboard/disqualified
//  - deleted/cancelled appointment → /dashboard/my-bookings (the page auto-opens
//    its "Deleted Appointments" tab when the located row is appointment_cancelled)
//  - otherwise (active) → /dashboard/my-bookings
const locatePath = (responseId: string, roundStage: string | null, appointmentCancelled?: boolean | null, email?: string | null) => {
  if (roundStage === "disqualified") return `/dashboard/disqualified?locate=${responseId}`;
  const emailParam = email ? `&locate_email=${encodeURIComponent(email.trim())}` : "";
  return `/dashboard/my-bookings?locate=${responseId}${emailParam}`;
};

const AiInterviews = () => {
  const navigate = useNavigate();
  const [searchParams, setSearchParams] = useSearchParams();
  // Locate-in-Scout receiver: mirrors the My Bookings "Locate Me" pattern.
  const [highlightId, setHighlightId] = useState<string | null>(null);
  const locateHandledRef = useRef<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [sessions, setSessions] = useState<Session[]>([]);
  const [evaluations, setEvaluations] = useState<Evaluation[]>([]);
  const [responses, setResponses] = useState<Resp[]>([]);
  const [forms, setForms] = useState<FormRow[]>([]);
  const [meta, setMeta] = useState<Meta[]>([]);
  const [questions, setQuestions] = useState<Question[]>([]);
  const [answers, setAnswers] = useState<Answer[]>([]);
  const [extras, setExtras] = useState<Extra[]>([]);
  // HR nickname/note per response (own value; optimistic on save).
  const [nicknames, setNicknames] = useState<Record<string, string>>({});
  // Cross-response nickname lookup by lowercased email (follow-the-person model).
  const [nicknameByEmail, setNicknameByEmail] = useState<Record<string, string>>({});
  // HR badge per response (own value; optimistic on save) + cross-email follow.
  const [badges, setBadges] = useState<Record<string, string>>({});
  const [badgeByEmail, setBadgeByEmail] = useState<Record<string, string>>({});
  const [previewFile, setPreviewFile] = useState<string | null>(null);
  // response_ids that currently hold an ACTIVE rebook_token (used_at null,
  // expires_at > now) → eligible to receive the daily 6 AM recover reminder.
  const [activeTokenResponseIds, setActiveTokenResponseIds] = useState<Set<string>>(new Set());
  const [tokenNames, setTokenNames] = useState<Record<string, string>>({});

  const [search, setSearch] = useState("");
  const [tierFilter, setTierFilter] = useState<string>("all");
  const [recommendedOnly, setRecommendedOnly] = useState(false);
  // Pure DISPLAY-ONLY visual filters (show/hide already-loaded rows). No DB writes,
  // no effect on sessions/videos/stages. Checked sets are AI-Tier and HR-Remark tags.
  const [tierChecks, setTierChecks] = useState<Set<string>>(new Set());
  const [remarkChecks, setRemarkChecks] = useState<Set<string>>(new Set());
  // Round tab: "R1" (Christine, default) | "R2" (Marissa). Pure display filter.
  const [activeTab, setActiveTab] = useState<"R1" | "R2">("R1");
  // Target for the Send Custom Message dialog (per-row).
  const [customMsgTarget, setCustomMsgTarget] = useState<{ responseId: string; name: string; email: string } | null>(null);

  // Bulk-select + quarantine (mirrors My Bookings runPermanentDelete). Quarantining
  // sets appointment_permanently_deleted + quarantine_moved_at on the response row
  // so it appears in Quarantine → Deleted Appointments, while the responses/answers
  // record stays intact (the Typeform Results entry is preserved). We never call
  // purge-candidate-completely and never touch the answers table.
  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set());
  const [removedIds, setRemovedIds] = useState<Set<string>>(new Set());
  const [deleting, setDeleting] = useState(false);
  // null = closed; "bulk" = bulk action; otherwise a single responseId.
  const [confirmTarget, setConfirmTarget] = useState<string | "bulk" | null>(null);

  // Bulk video download (read-only): which round is currently downloading + progress.
  // Resolves the healthiest video per candidate exactly like InterviewVideoDialog,
  // presigns via the existing get-r2-download-url fn, and triggers per-file browser
  // downloads named by candidate. Never writes to the DB.
  const [downloadingRound, setDownloadingRound] = useState<null | "R1" | "R2">(null);
  // Separate busy flag for the "Download Selected" run so its button shows its own
  // progress while still locking the All buttons (shared downloadProgress).
  const [downloadingSelected, setDownloadingSelected] = useState(false);
  const [downloadProgress, setDownloadProgress] = useState<{ current: number; total: number }>({ current: 0, total: 0 });


  const loadScout = useCallback(async () => {
      setLoading(true);
      // ai_interview_sessions can exceed PostgREST's db-max-rows=1000 cap, which
      // silently drops rows past 1000. With DESC order that would lose the OLDEST
      // sessions → older R1 candidates vanish from Scout. Page through with
      // .range() until a short page is returned (mirrors the answers loop below).
      const SESSIONS_PAGE = 1000;
      const sessionsList: Session[] = [];
      for (let from = 0; ; from += SESSIONS_PAGE) {
        const { data: page } = await supabase
          .from("ai_interview_sessions")
          .select("id, response_id, retell_call_id, ended_at, duration_seconds, termination_reason, created_at, stage, session_hidden")
          .order("created_at", { ascending: false })
          .range(from, from + SESSIONS_PAGE - 1);
        const rows = (page || []) as Session[];
        sessionsList.push(...rows);
        if (rows.length < SESSIONS_PAGE) break;
      }
      setSessions(sessionsList);

      const responseIds = Array.from(new Set(sessionsList.map((s) => s.response_id).filter(Boolean))) as string[];
      const sessionIds = sessionsList.map((s) => s.id);

      const [evalsRes, respRes, tokRes, extrasRes] = await Promise.all([
        sessionIds.length
          ? supabase.from("ai_interview_evaluations").select("id, session_id, response_id, tier, ai_recommended, verdict, red_flags, summary").in("session_id", sessionIds)
          : Promise.resolve({ data: [] as Evaluation[] } as any),
        responseIds.length
          ? supabase.from("responses").select("id, form_id, round_stage, final_outcome, override_email, override_name, appointment_cancelled, appointment_permanently_deleted").in("id", responseIds)
          : Promise.resolve({ data: [] as Resp[] } as any),
        responseIds.length
          ? supabase.from("rebook_tokens").select("response_id, used_at, expires_at, candidate_name").in("response_id", responseIds)
          : Promise.resolve({ data: [] as any[] } as any),
        responseIds.length
          ? supabase.from("hr_candidate_extras").select("response_id, photo_file_url, hr_nickname, hr_badge").in("response_id", responseIds)
          : Promise.resolve({ data: [] as Extra[] } as any),
      ]);
      setEvaluations((evalsRes.data || []) as Evaluation[]);
      const respList = (respRes.data || []) as Resp[];
      setResponses(respList);
      const extrasList = (extrasRes.data || []) as Extra[];
      setExtras(extrasList);
      const ownNick: Record<string, string> = {};
      for (const e of extrasList) if (e.hr_nickname) ownNick[e.response_id] = e.hr_nickname;
      setNicknames(ownNick);
      const ownBadge: Record<string, string> = {};
      for (const e of extrasList) if (e.hr_badge) ownBadge[e.response_id] = e.hr_badge;
      setBadges(ownBadge);

      const nowMs = Date.now();
      const activeSet = new Set<string>();
      const tokNames: Record<string, string> = {};
      for (const t of ((tokRes.data || []) as any[])) {
        if (t.response_id && !t.used_at && t.expires_at && new Date(t.expires_at).getTime() > nowMs) {
          activeSet.add(t.response_id);
        }
        if (t.response_id && t.candidate_name && !tokNames[t.response_id]) {
          tokNames[t.response_id] = String(t.candidate_name).trim();
        }
      }
      setActiveTokenResponseIds(activeSet);
      setTokenNames(tokNames);

      const formIds = Array.from(new Set(respList.map((r) => r.form_id)));
      if (formIds.length) {
        const [fRes, mRes, qRes] = await Promise.all([
          supabase.from("forms").select("id, title").in("id", formIds),
          supabase.from("form_metadata").select("form_id, position_title").in("form_id", formIds),
          supabase.from("questions").select("id, form_id, type, label, order_index").in("form_id", formIds),
        ]);
        setForms((fRes.data || []) as FormRow[]);
        setMeta((mRes.data || []) as Meta[]);
        const qs = (qRes.data || []) as Question[];
        setQuestions(qs);

        if (respList.length) {
          // Answers can exceed PostgREST's db-max-rows=1000 cap, which silently
          // drops rows past 1000 and loses name/photo for those candidates.
          // Page through with .range() ordered stably until a short page is returned.
          const respIds = respList.map((r) => r.id);
          const PAGE = 1000;
          const allAnswers: Answer[] = [];
          for (let from = 0; ; from += PAGE) {
            const { data: page } = await supabase
              .from("answers")
              .select("response_id, question_id, answer_text, file_url")
              .in("response_id", respIds)
              .order("response_id", { ascending: true })
              .order("question_id", { ascending: true })
              .range(from, from + PAGE - 1);
            const rows = (page || []) as Answer[];
            allAnswers.push(...rows);
            if (rows.length < PAGE) break;
          }
          setAnswers(allAnswers);
        }
      }
      setLoading(false);
  }, []);

  useEffect(() => {
    document.title = "AI Interviews — EIA";
    loadScout();
  }, [loadScout]);

  // Round classification per session (unchanged rule).
  const roundOf = (s: Session): "R1" | "R2" =>
    (s.stage === "round2_ai" || s.stage === "round2") ? "R2" : "R1";

  // Latest session PER ROUND per response_id (sessions already sorted desc).
  // A candidate who did both Christine (R1) and Marissa (R2) keeps the latest of
  // EACH round → one row in each tab. Completing R2 must never drop them from R1.
  const latestByResponseRound = useMemo(() => {
    const map = new Map<string, { R1?: Session; R2?: Session }>();
    for (const s of sessions) {
      if (!s.response_id) continue;
      const entry = map.get(s.response_id) || {};
      const rd = roundOf(s);
      if (!entry[rd]) entry[rd] = s; // first seen = latest (sorted desc)
      map.set(s.response_id, entry);
    }
    return map;
  }, [sessions]);


  const evalBySession = useMemo(() => {
    const m = new Map<string, Evaluation>();
    for (const e of evaluations) {
      // pick latest evaluation by created order — we didn't order, just take last seen
      m.set(e.session_id, e);
    }
    return m;
  }, [evaluations]);

  const respById = useMemo(() => {
    const m = new Map<string, Resp>();
    responses.forEach((r) => m.set(r.id, r));
    return m;
  }, [responses]);

  const formById = useMemo(() => {
    const m = new Map<string, FormRow>();
    forms.forEach((f) => m.set(f.id, f));
    return m;
  }, [forms]);

  const metaByForm = useMemo(() => {
    const m = new Map<string, Meta>();
    meta.forEach((x) => m.set(x.form_id, x));
    return m;
  }, [meta]);

  const questionsByForm = useMemo(() => {
    const m = new Map<string, Question[]>();
    questions.forEach((q) => {
      const a = m.get(q.form_id) || [];
      a.push(q);
      m.set(q.form_id, a);
    });
    return m;
  }, [questions]);

  const answerByResp = useMemo(() => {
    const m = new Map<string, Map<string, string>>();
    answers.forEach((a) => {
      let inner = m.get(a.response_id);
      if (!inner) { inner = new Map(); m.set(a.response_id, inner); }
      if (a.question_id) inner.set(a.question_id, a.answer_text || "");
    });
    return m;
  }, [answers]);

  // qid -> file_url per response (selfie/resume uploads live here, not answer_text).
  const fileByResp = useMemo(() => {
    const m = new Map<string, Map<string, string>>();
    answers.forEach((a) => {
      if (!a.file_url) return;
      let inner = m.get(a.response_id);
      if (!inner) { inner = new Map(); m.set(a.response_id, inner); }
      if (a.question_id) inner.set(a.question_id, a.file_url);
    });
    return m;
  }, [answers]);

  const photoByResp = useMemo(() => {
    const m = new Map<string, string>();
    extras.forEach((e) => { if (e.photo_file_url) m.set(e.response_id, e.photo_file_url); });
    return m;
  }, [extras]);

  const PHOTO_RE = /(photo|selfie|picture|headshot|portrait|image)/i;

  const rows = useMemo(() => {
    // Build rows ONLY after every row-gating fetch has resolved. setSessions()
    // lands BEFORE setResponses(), so on the intermediate render `respById` is
    // empty and the appointment_permanently_deleted filter (below) can't run yet
    // — that produced the 7→2 flicker (7 sessions shown, then 5 deleted rows
    // dropped once responses arrived). Returning [] while loading keeps rows AND
    // tab counts off the unstable intermediate state; they appear once, stable.
    if (loading) return [] as Array<{
      responseId: string;
      session: Session;
      evaluation: Evaluation | undefined;
      candidateName: string;
      candidateEmail: string;
      selfieUrl: string | null;
      positionTitle: string;
      failed: boolean;
      incomplete: boolean;
      autoReminding: boolean;
      roundStage: string | null;
      finalOutcome: string | null;
      appointmentCancelled: boolean | null;
      round: "R1" | "R2";
    }>;
    const list: Array<{
      responseId: string;
      session: Session;
      evaluation: Evaluation | undefined;
      candidateName: string;
      candidateEmail: string;
      selfieUrl: string | null;
      positionTitle: string;
      failed: boolean;
      incomplete: boolean;
      autoReminding: boolean;
      roundStage: string | null;
      finalOutcome: string | null;
      appointmentCancelled: boolean | null;
      round: "R1" | "R2";
    }> = [];
    // Flatten to up to TWO (responseId, session) pairs per candidate: their
    // latest R1 session and their latest R2 session, each becoming its own row.
    const roundPairs: Array<{ responseId: string; session: Session }> = [];
    for (const [responseId, entry] of latestByResponseRound.entries()) {
      if (entry.R1) roundPairs.push({ responseId, session: entry.R1 });
      if (entry.R2) roundPairs.push({ responseId, session: entry.R2 });
    }
    for (const { responseId, session } of roundPairs) {
      const evaluation = evalBySession.get(session.id);
      const resp = respById.get(responseId);
      // Hide rows whose session was quarantined. Runs independently of `resp`
      // so ORPHAN sessions (no matching responses row) are excluded too.
      if (session.session_hidden === true) continue;
      if (resp?.appointment_permanently_deleted) continue;
      const form = resp ? formById.get(resp.form_id) : undefined;
      const m = resp ? metaByForm.get(resp.form_id) : undefined;
      const positionTitle = cleanPositionTitle(m?.position_title || form?.title || "") || "—";

      let candidateName = "—";
      let candidateEmail = "";
      let selfieUrl: string | null = null;
      if (resp) {
        const qs = questionsByForm.get(resp.form_id) || [];
        const { nameQid, emailQid } = detectContactQuestionIds(qs);
        const ans = answerByResp.get(responseId);
        const files = fileByResp.get(responseId);
        if (nameQid && ans?.get(nameQid)) candidateName = ans.get(nameQid)!.trim() || "—";
        candidateEmail = (resp.override_email || (emailQid ? ans?.get(emailQid) : "") || "").trim();

        // Detect the selfie/photo upload question (same as the detail page),
        // resolve its file_url, fall back to hr_candidate_extras photo.
        const sorted = [...qs].sort((a, b) => (a.order_index || 0) - (b.order_index || 0));
        const uploads = sorted.filter((q) => q.type === "file_upload" || q.type === "selfie");
        const selfieQ = uploads.find((q) => q.type === "selfie") || uploads.find((q) => PHOTO_RE.test(q.label || ""));
        selfieUrl = (selfieQ && files?.get(selfieQ.id)) || photoByResp.get(responseId) || null;
      }
      if (candidateName === "—") {
        const fallback = (resp?.override_name || tokenNames[responseId] || "").trim();
        candidateName = fallback || "Direct Link Candidate";
      }

      const failed =
        isFailedSession(session) ||
        !evaluation ||
        (!evaluation.tier && !evaluation.verdict && evaluation.ai_recommended === null && !evaluation.summary);

      // INCOMPLETE under the 4-min rule = latest session is not a real >=240s
      // non-error interview. autoReminding = incomplete AND an active token
      // exists → the candidate is currently in the daily 6 AM reminder net.
      const incomplete = !isCompletedSession(session);
      const autoReminding = incomplete && activeTokenResponseIds.has(responseId);

      const round: "R1" | "R2" = (session.stage === "round2_ai" || session.stage === "round2") ? "R2" : "R1";
      list.push({ responseId, session, evaluation, candidateName, candidateEmail, selfieUrl, positionTitle, failed, incomplete, autoReminding, roundStage: resp?.round_stage ?? null, finalOutcome: resp?.final_outcome ?? null, appointmentCancelled: resp?.appointment_cancelled ?? null, round });
    }
    // sort by ended_at or created_at desc
    list.sort((a, b) => {
      const at = a.session.ended_at || a.session.created_at;
      const bt = b.session.ended_at || b.session.created_at;
      return (bt || "").localeCompare(at || "");
    });
    return list;
  }, [loading, latestByResponseRound, evalBySession, respById, formById, metaByForm, questionsByForm, answerByResp, fileByResp, photoByResp, activeTokenResponseIds, tokenNames]);

  const ADMIN_EMAIL = "spark11179@gmail.com";

  // Follow-the-person-by-email: after rows build, fetch nicknames set on ANY
  // response sharing a displayed email (incl. non-Scout responses). Read-only,
  // non-blocking. Never shares the admin email's nickname across people.
  useEffect(() => {
    let cancelled = false;
    const norm = (s: string | null | undefined) => (s || "").trim().toLowerCase();
    (async () => {
      const emails = Array.from(
        new Set(rows.map((r) => norm(r.candidateEmail)).filter((e) => e && e !== ADMIN_EMAIL))
      );
      if (!emails.length) { if (!cancelled) { setNicknameByEmail({}); setBadgeByEmail({}); } return; }
      const { data: resps } = await supabase
        .from("responses").select("id, override_email").in("override_email", emails);
      const emailById: Record<string, string> = {};
      for (const r of (resps || []) as any[]) emailById[r.id] = norm(r.override_email);
      const ids = Object.keys(emailById);
      if (!ids.length) { if (!cancelled) { setNicknameByEmail({}); setBadgeByEmail({}); } return; }
      const { data: ex } = await supabase
        .from("hr_candidate_extras").select("response_id, hr_nickname, hr_badge, updated_at").in("response_id", ids);
      // Prefer most recent nickname/badge per email.
      const bestNick: Record<string, { v: string; ts: number }> = {};
      const bestBadge: Record<string, { v: string; ts: number }> = {};
      for (const e of (ex || []) as any[]) {
        const em = emailById[e.response_id];
        if (!em || em === ADMIN_EMAIL) continue;
        const ts = e.updated_at ? Date.parse(e.updated_at) : 0;
        if (e.hr_nickname && (!bestNick[em] || ts > bestNick[em].ts)) bestNick[em] = { v: e.hr_nickname, ts };
        if (e.hr_badge && (!bestBadge[em] || ts > bestBadge[em].ts)) bestBadge[em] = { v: e.hr_badge, ts };
      }
      const nickMap: Record<string, string> = {};
      for (const [em, v] of Object.entries(bestNick)) nickMap[em] = v.v;
      const badgeMap: Record<string, string> = {};
      for (const [em, v] of Object.entries(bestBadge)) badgeMap[em] = v.v;
      if (!cancelled) { setNicknameByEmail(nickMap); setBadgeByEmail(badgeMap); }
    })().catch(() => { if (!cancelled) { setNicknameByEmail({}); setBadgeByEmail({}); } });
    return () => { cancelled = true; };
  }, [rows]);

  // Resolved nickname for display: own value wins, else borrow same-email (non-admin).
  const resolveNickname = (responseId: string, email: string): string => {
    const own = nicknames[responseId];
    if (own) return own;
    const e = (email || "").trim().toLowerCase();
    if (e && e !== ADMIN_EMAIL) return nicknameByEmail[e] || "";
    return "";
  };

  // Resolved badge for display: own value wins, else borrow same-email (non-admin).
  const resolveBadge = (responseId: string, email: string): string => {
    const own = badges[responseId];
    if (own) return own;
    const e = (email || "").trim().toLowerCase();
    if (e && e !== ADMIN_EMAIL) return badgeByEmail[e] || "";
    return "";
  };

  // Save edit: optimistic own + same-email surface, upsert ONLY hr_nickname.
  const saveNickname = async (responseId: string, email: string, value: string) => {
    const prev = nicknames[responseId] ?? "";
    const e = (email || "").trim().toLowerCase();
    const prevEmailMap = nicknameByEmail;
    setNicknames((m) => ({ ...m, [responseId]: value }));
    if (e && e !== ADMIN_EMAIL) setNicknameByEmail((m) => ({ ...m, [e]: value }));
    const { error } = await supabase
      .from("hr_candidate_extras")
      .upsert({ response_id: responseId, hr_nickname: value || null }, { onConflict: "response_id" });
    if (error) {
      setNicknames((m) => ({ ...m, [responseId]: prev }));
      setNicknameByEmail(prevEmailMap);
      toast.error("Couldn't save note");
    }
  };

  // Save badge: optimistic own + same-email surface, upsert ONLY hr_badge.
  const saveBadge = async (responseId: string, email: string, value: string) => {
    const prev = badges[responseId] ?? "";
    const e = (email || "").trim().toLowerCase();
    const prevEmailMap = badgeByEmail;
    setBadges((m) => ({ ...m, [responseId]: value }));
    if (e && e !== ADMIN_EMAIL) setBadgeByEmail((m) => ({ ...m, [e]: value }));
    const { error } = await supabase
      .from("hr_candidate_extras")
      .upsert({ response_id: responseId, hr_badge: value || null }, { onConflict: "response_id" });
    if (error) {
      setBadges((m) => ({ ...m, [responseId]: prev }));
      setBadgeByEmail(prevEmailMap);
      toast.error("Couldn't save badge");
    }
  };



  // After a disqualify from the Scout Report list, patch the local responses state
  // so the red Disqualified badge appears immediately (row stays visible).
  const handleDisqualified = (responseId: string) => {
    setResponses((prev) =>
      prev.map((r) => (r.id === responseId ? { ...r, round_stage: "disqualified" as any } : r))
    );
  };

  // Per-round counts (excluding removed rows) for the tab labels.
  const roundCounts = useMemo(() => {
    let R1 = 0, R2 = 0;
    for (const r of rows) {
      if (removedIds.has(r.responseId)) continue;
      if (r.round === "R2") R2++; else R1++;
    }
    return { R1, R2 };
  }, [rows, removedIds]);

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    const anyTagChecked = tierChecks.size > 0 || remarkChecks.size > 0;
    return rows.filter((r) => {
      if (removedIds.has(r.responseId)) return false;
      if (r.round !== activeTab) return false;
      if (recommendedOnly && !(r.evaluation?.ai_recommended === true)) return false;
      if (tierFilter !== "all") {
        const t = (r.evaluation?.tier || "").toLowerCase().trim();
        if (t !== tierFilter) return false;
      }
      // Pure visual tag filter (union of AI-Tier OR HR-Remark). Nothing checked = show all.
      if (anyTagChecked) {
        const t = (r.evaluation?.tier || "").toLowerCase().trim();
        const remarkKey = resolveBadge(r.responseId, r.candidateEmail) || "__none__";
        const tierMatch = !!t && tierChecks.has(t);
        const remarkMatch = remarkChecks.has(remarkKey);
        if (!tierMatch && !remarkMatch) return false;
      }
      if (q) {
        const hay = `${r.candidateName} ${r.positionTitle}`.toLowerCase();
        if (!hay.includes(q)) return false;
      }
      return true;
    });
  }, [rows, search, tierFilter, recommendedOnly, removedIds, activeTab, tierChecks, remarkChecks, badges, badgeByEmail]);

  // Consume ?locate=<response_id> from My Bookings "Locate in Scout".
  // Mirrors the StageTrackingView "Locate Me" receiver: clear filters, switch to
  // the row's round tab, then scroll to + briefly highlight it. No crash if absent.
  useEffect(() => {
    if (loading) return;
    const locate = (searchParams.get("locate") || "").trim();
    if (!locate) return;
    if (locateHandledRef.current === locate) return;
    locateHandledRef.current = locate;

    const roundParam = (searchParams.get("round") || "").trim();
    const validRound = roundParam === "R1" || roundParam === "R2" ? (roundParam as "R1" | "R2") : null;

    const target = validRound
      ? rows.find((r) => r.responseId === locate && r.round === validRound) || rows.find((r) => r.responseId === locate)
      : rows.find((r) => r.responseId === locate);
    const clearParam = () => {
      const next = new URLSearchParams(searchParams);
      next.delete("locate");
      next.delete("round");
      setSearchParams(next, { replace: true });
    };
    if (!target) { clearParam(); return; }

    setSearch("");
    setTierFilter("all");
    setRecommendedOnly(false);
    setActiveTab(validRound || target.round);
    setHighlightId(target.responseId);
    clearParam();
  }, [loading, rows, searchParams, setSearchParams]);

  // Scroll to + briefly highlight the located row once it is rendered.
  useEffect(() => {
    if (!highlightId) return;
    const scrollTimer = setTimeout(() => {
      const el = document.querySelector(`[data-response-id="${highlightId}"]`);
      if (el) el.scrollIntoView({ behavior: "smooth", block: "center" });
    }, 150);
    const clearTimer = setTimeout(() => setHighlightId(null), 2600);
    return () => { clearTimeout(scrollTimer); clearTimeout(clearTimer); };
  }, [highlightId, filtered, activeTab]);

  // Bulk-select helpers — same shape as StageTrackingView.
  const allSelected = filtered.length > 0 && filtered.every((r) => selectedIds.has(r.responseId));
  // Count of selected rows in the CURRENT tab only (selection is per-tab for downloads).
  const selectedInTabCount = filtered.filter((r) => selectedIds.has(r.responseId)).length;
  const toggleSelectAll = () => {
    if (allSelected) setSelectedIds(new Set());
    else setSelectedIds(new Set(filtered.map((r) => r.responseId)));
  };
  const toggleOne = (id: string) => {
    setSelectedIds((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id); else next.add(id);
      return next;
    });
  };

  // QUARANTINE (record-preserving — exact mirror of runPermanentDelete in
  // StageTrackingView): flag each response so it surfaces in Quarantine → Deleted
  // Appointments while the responses/answers record (Typeform Results) stays intact.
  const runQuarantine = async (ids: string[]) => {
    if (!ids.length) return;
    setDeleting(true);
    // Recover the session(s) backing each selected Scout row. The delete must hide
    // the SESSION (this is what kills orphan ghosts that have no responses row) AND
    // flag the responses row (existing behavior for real candidates). `ids` carry
    // responseId; the rows array pairs each responseId with its session.
    const idSet = new Set(ids);
    const targets = rows.filter((r) => idSet.has(r.responseId));
    let ok = 0, fail = 0;
    let firstError = "";
    const hiddenResponseIds = new Set<string>();
    const failedResponseIds = new Set<string>();
    for (const r of targets) {
      // 1) Hide the session — the write that removes orphans.
      const { error: sErr } = await supabase
        .from("ai_interview_sessions")
        .update({ session_hidden: true })
        .eq("id", r.session.id);
      // 2) Flag the responses row — keeps existing behavior; hits zero rows
      //    harmlessly for orphans that have no matching responses row.
      if (r.responseId) {
        await supabase
          .from("responses")
          .update({ appointment_permanently_deleted: true, quarantine_moved_at: new Date().toISOString() })
          .eq("id", r.responseId);
      }
      if (sErr) {
        fail++;
        if (!firstError) firstError = sErr.message;
        failedResponseIds.add(r.responseId);
      } else {
        ok++;
        hiddenResponseIds.add(r.responseId);
      }
    }
    // Only optimistically hide rows whose session_hidden write SUCCEEDED.
    const toRemove = Array.from(hiddenResponseIds).filter((id) => !failedResponseIds.has(id));
    setRemovedIds((prev) => { const next = new Set(prev); toRemove.forEach((id) => next.add(id)); return next; });
    setSelectedIds(new Set());
    setDeleting(false);
    setConfirmTarget(null);
    if (fail === 0) {
      toast.success(`Moved ${ok} to Quarantine → Deleted Appointments`);
    } else {
      toast.error(`Moved ${ok}, ${fail} failed${firstError ? `: ${firstError}` : ""}`);
      // A failed write must not falsely hide rows — refetch the authoritative list.
      loadScout();
    }
  };


  // ---- Bulk video download (read-only) ----------------------------------------
  // Strip filesystem-illegal chars from a candidate name for use as a filename.
  const sanitizeFilename = (name: string) =>
    (name || "").replace(/[/\\:*?"<>|]/g, "").replace(/\s+/g, " ").trim() || "Unknown";

  // Real extension from the presigned URL / content-type — never hardcoded.
  const extFromUrlOrType = (url: string, contentType: string | null): string => {
    const ct = (contentType || "").toLowerCase();
    if (ct.includes("webm")) return "webm";
    if (ct.includes("mp4")) return "mp4";
    try {
      const path = new URL(url).pathname.toLowerCase();
      const m = path.match(/\.(mp4|webm|mov|m4v)$/);
      if (m) return m[1];
    } catch { /* not a URL */ }
    return "mp4";
  };

  // Trigger a browser file download for an in-memory blob.
  const triggerBlobDownload = (blob: Blob, filename: string) => {
    const objUrl = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = objUrl;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    a.remove();
    URL.revokeObjectURL(objUrl);
  };

  // Shared bulk-download core. Resolves the HEALTHIEST video per candidate exactly
  // like InterviewVideoDialog, presigns via get-r2-download-url, downloads the file
  // AND a sidecar WebVTT subtitle file built from the SAME buildVttFromTranscript
  // helper the green single-watch path uses (transcript → WebVTT). Read-only.
  const runBulkDownload = async (round: "R1" | "R2", roundRows: typeof rows, scope: "all" | "selected") => {
    const responseIds = roundRows.map((r) => r.responseId);
    if (!responseIds.length) {
      toast.info(`No ${round} candidates to download.`);
      return;
    }
    setDownloadProgress({ current: 0, total: 0 });
    try {
      // Resolve each candidate's video with the EXACT same logic as the green
      // "Watch Interview Video" button: videoRoundFromStage(stage) → shared
      // resolveHealthiestVideoSession. Unknown/ai_scheduled/null stages map to
      // undefined → fallback search across ALL the candidate's sessions, so bulk
      // can download anyone the watch button can play. (The old path hard-filtered
      // sessions by stage IN (round1) / (round2_ai,round2), so candidates whose
      // session stage was not in that list were wrongly reported "no video".)
      const usedNames = new Map<string, number>();
      const targets: Array<{ url: string; filename: string; transcript: any; captionAgent: string }> = [];
      for (const r of roundRows) {
        const resolveRound = roundOf(r.session);
        const best = await resolveHealthiestVideoSession(r.responseId, resolveRound);
        const videoUrl = best?.merged_video_url || best?.video_url || null;
        if (!videoUrl) continue; // no healthy video → skip (mirrors hideWhenNoVideo)
        const isPlaceholder = !r.candidateName || r.candidateName === "Direct Link Candidate" || r.candidateName === "—";
        const base = sanitizeFilename(isPlaceholder ? `Unknown ${r.responseId.slice(0, 8)}` : r.candidateName);
        const key = `${base} - ${round}`.toLowerCase();
        const n = (usedNames.get(key) || 0) + 1;
        usedNames.set(key, n);
        const suffix = n > 1 ? ` (${n})` : "";
        // Caption agent name matches the watch path: Marissa for R2 sessions.
        const captionAgent =
          resolveRound === "R2" || best?.stage === "round2_ai" || round === "R2" ? "Marissa" : "Christine";
        targets.push({ url: videoUrl, filename: `${base} - ${round}${suffix}`, transcript: best?.transcript, captionAgent });
      }

      if (!targets.length) {
        toast.info(`No ${round} videos available to download.`);
        return;
      }

      setDownloadProgress({ current: 0, total: targets.length });
      let success = 0;
      const failures: string[] = [];
      // Sequential loop — an expired/missing file is skipped, never aborts the run.
      for (let i = 0; i < targets.length; i++) {
        const t = targets[i];
        setDownloadProgress({ current: i + 1, total: targets.length });
        try {
          const { data, error } = await supabase.functions.invoke("get-r2-download-url", {
            body: { video_url: t.url },
          });
          const signed = (data as any)?.url;
          if (error || !signed) { failures.push(t.filename); continue; }
          const res = await fetch(signed);
          if (!res.ok) { failures.push(t.filename); continue; }
          const blob = await res.blob();
          const ext = extFromUrlOrType(signed, res.headers.get("content-type"));
          triggerBlobDownload(blob, `${t.filename}.${ext}`);
          // Sidecar subtitles — identical mechanism to the single-watch button:
          // transcript → WebVTT via buildVttFromTranscript. Skip if no transcript.
          const vtt = buildVttFromTranscript(t.transcript, t.captionAgent);
          if (vtt) {
            triggerBlobDownload(new Blob([vtt], { type: "text/vtt" }), `${t.filename}.vtt`);
          }
          success++;
        } catch {
          failures.push(t.filename);
        }
      }

      console.log(
        `[bulk-download ${round} ${scope}] candidates=${roundRows.length} withVideo=${targets.length} processed=${targets.length} success=${success} skipped/failed=${failures.length}`,
        failures.length ? { failures } : ""
      );
      if (failures.length === 0) {
        toast.success(`Downloaded ${success} ${round} video${success === 1 ? "" : "s"} (with subtitles).`);
      } else {
        toast.warning(
          `Downloaded ${success}/${targets.length} ${round} videos. ${failures.length} skipped: ` +
            `${failures.slice(0, 5).join(", ")}${failures.length > 5 ? "…" : ""}`
        );
      }
    } finally {
      setDownloadProgress({ current: 0, total: 0 });
    }
  };

  const downloadAllVideos = async (round: "R1" | "R2") => {
    if (downloadingRound || downloadingSelected) return;
    // Every row in this round's tab (excluding rows already removed/quarantined).
    const roundRows = rows.filter((r) => r.round === round && !removedIds.has(r.responseId));
    setDownloadingRound(round);
    try {
      await runBulkDownload(round, roundRows, "all");
    } finally {
      setDownloadingRound(null);
    }
  };

  // Download Selected — only the checked rows in the CURRENT tab (per-tab selection:
  // `filtered` is already scoped to activeTab, so R1/R2 selections never mix).
  const downloadSelectedVideos = async () => {
    if (downloadingRound || downloadingSelected) return;
    const selectedRows = filtered.filter((r) => selectedIds.has(r.responseId));
    if (!selectedRows.length) {
      toast.info("No candidates selected.");
      return;
    }
    setDownloadingSelected(true);
    try {
      await runBulkDownload(activeTab, selectedRows, "selected");
      // Clear the selection after a completed run.
      setSelectedIds(new Set());
    } finally {
      setDownloadingSelected(false);
    }
  };


  const tierOptions = useMemo(() => {
    const set = new Set<string>();
    rows.forEach((r) => { const t = (r.evaluation?.tier || "").toLowerCase().trim(); if (t) set.add(t); });
    return Array.from(set);
  }, [rows]);

  // Fixed HR-Remark options for the visual filter (keys match hr_badge storage; "__none__" = No Remarks).
  const REMARK_OPTS: { key: string; label: string }[] = [
    { key: "shortlisted", label: "Short Listed" },
    { key: "favorite", label: "Favorite" },
    { key: "bad", label: "Bad" },
    { key: "very_bad", label: "Very Bad" },
    { key: "__none__", label: "No Remarks" },
  ];
  const toggleSet = (
    setter: Dispatch<SetStateAction<Set<string>>>,
    key: string,
    on: boolean,
  ) => setter((prev) => {
    const next = new Set(prev);
    if (on) next.add(key); else next.delete(key);
    return next;
  });

  return (
    <div className="min-h-screen bg-background">
      <header className="bg-background" style={{ borderBottom: "1px solid #e1e4ec" }}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-4 flex flex-wrap items-center gap-3">
          <Button variant="ghost" size="sm" onClick={() => navigate("/dashboard")} className="min-h-[44px]">
            <ArrowLeft className="h-4 w-4 mr-1.5" /> Back
          </Button>
          <h1 className="text-lg sm:text-xl font-semibold flex items-center gap-2">
            <Video className="h-5 w-5" /> AI Interviews — Scout Reports
          </h1>
          <div className="ml-auto flex flex-wrap items-center gap-2">
            <Button
              variant="outline"
              size="sm"
              className="min-h-[40px]"
              disabled={!!downloadingRound || downloadingSelected}
              onClick={() => downloadAllVideos("R1")}
            >
              {downloadingRound === "R1" ? (
                <><Loader2 className="h-4 w-4 mr-1.5 animate-spin" /> Downloading {downloadProgress.current} / {downloadProgress.total}…</>
              ) : (
                <><Download className="h-4 w-4 mr-1.5" /> Download All R1 Videos</>
              )}
            </Button>
            <Button
              variant="outline"
              size="sm"
              className="min-h-[40px]"
              disabled={!!downloadingRound || downloadingSelected}
              onClick={() => downloadAllVideos("R2")}
            >
              {downloadingRound === "R2" ? (
                <><Loader2 className="h-4 w-4 mr-1.5 animate-spin" /> Downloading {downloadProgress.current} / {downloadProgress.total}…</>
              ) : (
                <><Download className="h-4 w-4 mr-1.5" /> Download All R2 Videos</>
              )}
            </Button>
            <Button
              variant="default"
              size="sm"
              className="min-h-[40px]"
              disabled={!!downloadingRound || downloadingSelected || selectedInTabCount === 0}
              onClick={downloadSelectedVideos}
            >
              {downloadingSelected ? (
                <><Loader2 className="h-4 w-4 mr-1.5 animate-spin" /> Downloading {downloadProgress.current} / {downloadProgress.total}…</>
              ) : (
                <><Download className="h-4 w-4 mr-1.5" /> Download Selected ({selectedInTabCount})</>
              )}
            </Button>
            <InvalidateAllLinksButton agent="christine" label="Invalidate All Christine Links" />
            <InvalidateAllLinksButton agent="marissa" label="Invalidate All Marissa Links" />
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 py-6 sm:py-8">
        {/* Round tabs — pure display filter (R1 Christine default, R2 Marissa) */}
        <div className="inline-flex rounded-lg border border-border bg-muted/40 p-1 mb-5">
          {([
            { key: "R1" as const, label: "Round 1 — Christine", count: roundCounts.R1 },
            { key: "R2" as const, label: "Round 2 — Marissa", count: roundCounts.R2 },
          ]).map((t) => (
            <button
              key={t.key}
              type="button"
              onClick={() => setActiveTab(t.key)}
              className={`min-h-[40px] px-4 rounded-md text-sm font-semibold transition-colors ${
                activeTab === t.key
                  ? "bg-[#0f1b3d] text-white shadow-sm"
                  : "text-muted-foreground hover:text-foreground"
              }`}
            >
              {t.label} ({t.count})
            </button>
          ))}
        </div>

        <div className="flex flex-col sm:flex-row gap-3 mb-5">
          <Input
            placeholder="Search by name or position…"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="sm:max-w-xs min-h-[44px]"
          />
          <Select value={tierFilter} onValueChange={setTierFilter}>
            <SelectTrigger className="sm:max-w-[200px] min-h-[44px]">
              <SelectValue placeholder="All tiers" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All tiers</SelectItem>
              {tierOptions.map((t) => (
                <SelectItem key={t} value={t}>{t.replace(/\b\w/g, (c) => c.toUpperCase())}</SelectItem>
              ))}
            </SelectContent>
          </Select>
          <label className="flex items-center gap-2 px-3 min-h-[44px] cursor-pointer select-none">
            <Checkbox
              checked={recommendedOnly}
              onCheckedChange={(v) => setRecommendedOnly(v === true)}
            />
            <span className="text-sm">AI Recommended only</span>
          </label>
        </div>

        {/* DISPLAY-ONLY visual filters: show/hide already-loaded rows. No DB writes. */}
        <div className="flex flex-col gap-3 mb-5 rounded-lg border border-border bg-muted/30 p-3">
          <div className="flex flex-wrap items-center gap-x-4 gap-y-2">
            <span className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">AI Tier</span>
            {tierOptions.length === 0 ? (
              <span className="text-xs text-muted-foreground">No tiers in data</span>
            ) : (
              tierOptions.map((t) => (
                <label key={t} className="flex items-center gap-1.5 text-sm cursor-pointer select-none">
                  <Checkbox
                    checked={tierChecks.has(t)}
                    onCheckedChange={(v) => toggleSet(setTierChecks, t, v === true)}
                  />
                  <span>{t.replace(/\b\w/g, (c) => c.toUpperCase())}</span>
                </label>
              ))
            )}
          </div>
          <div className="flex flex-wrap items-center gap-x-4 gap-y-2">
            <span className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">HR Remark</span>
            {REMARK_OPTS.map((o) => (
              <label key={o.key} className="flex items-center gap-1.5 text-sm cursor-pointer select-none">
                <Checkbox
                  checked={remarkChecks.has(o.key)}
                  onCheckedChange={(v) => toggleSet(setRemarkChecks, o.key, v === true)}
                />
                <span>{o.label}</span>
              </label>
            ))}
            {(tierChecks.size > 0 || remarkChecks.size > 0) && (
              <button
                type="button"
                onClick={() => { setTierChecks(new Set()); setRemarkChecks(new Set()); }}
                className="text-xs font-medium text-muted-foreground underline underline-offset-2 hover:text-foreground"
              >
                Clear filters
              </button>
            )}
          </div>
        </div>



        {loading ? (
          <div className="space-y-2" aria-busy="true">
            {[0, 1, 2, 3].map((i) => <Skeleton key={i} className="h-14 w-full" />)}
          </div>
        ) : rows.length === 0 ? (
          <div className="border border-dashed border-border rounded-xl p-12 text-center">
            <div className="mx-auto mb-4 h-14 w-14 rounded-full bg-secondary flex items-center justify-center">
              <Video className="h-6 w-6 text-muted-foreground" />
            </div>
            <h3 className="text-lg font-semibold mb-1">No AI interviews yet</h3>
            <p className="text-sm text-muted-foreground">
              Once candidates complete their Christine AI interview, they'll appear here.
            </p>
          </div>
        ) : (
          <>
            {/* Select-all header + bulk quarantine bar */}
            <div className="flex flex-wrap items-center gap-3 mb-3">
              <label className="flex items-center gap-2 cursor-pointer select-none">
                <Checkbox checked={allSelected} onCheckedChange={toggleSelectAll} />
                <span className="text-sm text-muted-foreground">Select all ({filtered.length})</span>
              </label>
              {selectedIds.size > 0 && (
                <Button
                  size="sm"
                  variant="destructive"
                  disabled={deleting}
                  onClick={() => setConfirmTarget("bulk")}
                >
                  <Trash2 className="h-4 w-4 mr-1.5" /> Delete Selected ({selectedIds.size})
                </Button>
              )}
            </div>

            {/* Desktop rows */}
            <div className="hidden md:block space-y-3">
              {filtered.map((r) => (
                <div key={r.responseId} data-response-id={r.responseId} className={`border border-border rounded-lg p-4 bg-card flex items-start gap-4${highlightId === r.responseId ? " locate-flash" : ""}`}>
                  {/* Select checkbox */}
                  <div className="pt-1 shrink-0">
                    <Checkbox
                      checked={selectedIds.has(r.responseId)}
                      onCheckedChange={() => toggleOne(r.responseId)}
                    />
                  </div>
                  {/* Photo + Locate Me (far left, stacked) */}
                  <div className="flex flex-col items-center gap-2 w-[140px] shrink-0">
                    {r.selfieUrl ? (
                      <SelfieThumb file_url={r.selfieUrl} size={120} onPreview={() => setPreviewFile(r.selfieUrl)} />
                    ) : (
                      <div className="rounded-lg bg-secondary border border-border flex items-center justify-center text-[10px] text-muted-foreground" style={{ width: 120, height: 120 }}>—</div>
                    )}
                    <Button
                      size="sm"
                      variant="outline"
                      className="w-full min-h-[32px]"
                      onClick={() => navigate(locatePath(r.responseId, r.roundStage, r.appointmentCancelled, r.candidateEmail))}
                    >
                      <MapPin className="h-4 w-4 mr-1.5" /> Locate Me
                    </Button>
                  </div>


                  {/* Name + badges + meta + actions (horizontal flow to the right) */}
                  <div className="flex-1 min-w-0 flex flex-col gap-2">
                    <div className="flex flex-wrap items-center gap-2">
                      <span className="font-medium">{r.candidateName}</span>
                      <HrBadgePill value={resolveBadge(r.responseId, r.candidateEmail)} />
                      {r.failed ? (
                        <Badge variant="secondary" className="bg-slate-100 text-slate-600">No interview completed</Badge>
                      ) : r.evaluation?.tier ? (
                        <AiTierBadge tier={r.evaluation.tier} />
                      ) : null}
                      {r.roundStage === "disqualified" && (
                        <Badge className="border-0 bg-red-600 text-white">Disqualified</Badge>
                      )}
                      {r.finalOutcome === "matched" ? (
                        <Badge className="border-0 bg-[#d4af37] text-black font-bold">HIRED</Badge>
                      ) : r.roundStage === "terminated" ? (
                        <Badge className="border-0 bg-red-700 text-white">TERMINATED</Badge>
                      ) : null}
                      {r.autoReminding ? (
                        <Badge className="border-0 bg-amber-100 text-amber-800">Auto-reminding</Badge>
                      ) : r.incomplete ? (
                        <Badge variant="secondary" className="bg-slate-100 text-slate-500">Reminder expired</Badge>
                      ) : null}
                    </div>

                    {/* HR note (editable inline) */}
                    <HrNicknameField
                      value={resolveNickname(r.responseId, r.candidateEmail)}
                      onSave={(v) => saveNickname(r.responseId, r.candidateEmail, v)}
                    />

                    {/* HR badge picker (editable here in Scout only) */}
                    <div className="flex flex-wrap items-center gap-2">
                      <HrBadgeSelect
                        value={resolveBadge(r.responseId, r.candidateEmail)}
                        onChange={(v) => saveBadge(r.responseId, r.candidateEmail, v)}
                      />
                      {/* Reuses the shared detail-page video flow (presign + in-page player).
                          Renders nothing when this candidate has no interview video. */}
                      <InterviewVideoDialog
                        responseId={r.responseId}
                        round={roundOf(r.session)}
                        buttonLabel="Watch Interview"
                        buttonVariant="outline"
                        buttonSize="sm"
                        buttonClassName="bg-teal-600 text-white border-teal-600 hover:bg-teal-700 hover:text-white"
                        hideWhenNoVideo
                      />
                    </div>




                    <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-xs text-muted-foreground">
                      {r.positionTitle && <span>{r.positionTitle}</span>}
                      <span>
                        Recommended:{" "}
                        {r.failed ? "—"
                          : r.evaluation?.ai_recommended === true ? "Yes"
                          : r.evaluation?.ai_recommended === false ? "No" : "—"}
                      </span>
                      <span>{fmtDate(r.session.ended_at || r.session.created_at)}</span>
                      <span>{fmtDuration(r.session.duration_seconds)}</span>
                    </div>

                    <div className="flex flex-row flex-wrap items-center gap-2">
                      <Button
                        size="lg"
                        className="min-h-[48px] px-6 text-base font-semibold shadow-md bg-emerald-600 hover:bg-emerald-700 text-white"
                        onClick={() => navigate(`/dashboard/ai-interviews/${r.responseId}/${r.round}`)}
                      >
                        <Eye className="h-5 w-5 mr-2" /> View Report
                      </Button>
                      <RecoverInterviewButton
                        responseId={r.responseId}
                        candidateName={r.candidateName === "Direct Link Candidate" ? "" : r.candidateName}
                        candidateEmail={r.candidateEmail}
                        appearance="outline"
                        eligible={true}
                      />
                      {r.round === "R1" && (
                        <RescueCandidateButton
                          responseId={r.responseId}
                          candidateName={r.candidateName === "Direct Link Candidate" ? "" : r.candidateName}
                          candidateEmail={r.candidateEmail}
                          appearance="outline"
                          round={1}
                        />
                      )}
                      {r.round === "R2" && (
                        <RescueCandidateButton
                          responseId={r.responseId}
                          candidateName={r.candidateName === "Direct Link Candidate" ? "" : r.candidateName}
                          candidateEmail={r.candidateEmail}
                          appearance="outline"
                          round={2}
                        />
                      )}
                      <StopRemindersButton responseId={r.responseId} appearance="outline" />
                      <Button
                        size="sm"
                        className="min-h-[36px] bg-violet-600 hover:bg-violet-700 text-white"
                        onClick={() => setCustomMsgTarget({
                          responseId: r.responseId,
                          name: r.candidateName === "Direct Link Candidate" ? "" : r.candidateName,
                          email: r.candidateEmail,
                        })}
                      >
                        <MessageSquare className="h-4 w-4 mr-1.5" /> Send Message
                      </Button>
                      <DisqualifyButton
                        responseId={r.responseId}
                        candidateName={r.candidateName === "Direct Link Candidate" ? "" : r.candidateName}
                        onDisqualified={() => handleDisqualified(r.responseId)}
                      />
                      <Button
                        size="sm"
                        variant="outline"
                        className="min-h-[36px] text-red-600 hover:text-red-700 border-red-200 hover:bg-red-50"
                        disabled={deleting}
                        onClick={() => setConfirmTarget(r.responseId)}
                        aria-label="Send to Quarantine"
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            {/* Mobile cards */}
            <div className="md:hidden space-y-3">
              {filtered.map((r) => (
                <div key={r.responseId} data-response-id={r.responseId} className={`border border-border rounded-lg p-4 bg-card${highlightId === r.responseId ? " locate-flash" : ""}`}>
                  <div className="flex items-start gap-3 mb-3">
                    <div className="pt-1 shrink-0">
                      <Checkbox
                        checked={selectedIds.has(r.responseId)}
                        onCheckedChange={() => toggleOne(r.responseId)}
                      />
                    </div>
                    {/* Photo + Locate Me (left, stacked) */}
                    <div className="flex flex-col items-center gap-2 w-[120px] shrink-0">
                      {r.selfieUrl ? (
                        <SelfieThumb file_url={r.selfieUrl} size={120} onPreview={() => setPreviewFile(r.selfieUrl)} />
                      ) : (
                        <div className="rounded-lg bg-secondary border border-border flex items-center justify-center text-[10px] text-muted-foreground" style={{ width: 120, height: 120 }}>—</div>
                      )}
                      <Button
                        size="sm"
                        variant="outline"
                        className="w-full min-h-[32px]"
                        onClick={() => navigate(locatePath(r.responseId, r.roundStage, r.appointmentCancelled, r.candidateEmail))}
                      >
                        <MapPin className="h-4 w-4 mr-1.5" /> Locate Me
                      </Button>
                    </div>
                    {/* Name + badges */}
                    <div className="flex-1 min-w-0 flex flex-col gap-1.5">
                      <div className="font-semibold">{r.candidateName}</div>
                      <div className="text-xs text-muted-foreground">{r.positionTitle}</div>
                      <HrNicknameField
                        value={resolveNickname(r.responseId, r.candidateEmail)}
                        onSave={(v) => saveNickname(r.responseId, r.candidateEmail, v)}
                      />
                      <div className="flex flex-wrap items-center gap-2">
                        <HrBadgePill value={resolveBadge(r.responseId, r.candidateEmail)} />
                        <HrBadgeSelect
                          value={resolveBadge(r.responseId, r.candidateEmail)}
                          onChange={(v) => saveBadge(r.responseId, r.candidateEmail, v)}
                        />
                        <InterviewVideoDialog
                          responseId={r.responseId}
                          round={roundOf(r.session)}
                          buttonLabel="Watch Interview"
                          buttonVariant="outline"
                          buttonSize="sm"
                          buttonClassName="bg-teal-600 text-white border-teal-600 hover:bg-teal-700 hover:text-white"
                          hideWhenNoVideo
                        />
                      </div>
                      <div className="flex flex-wrap items-center gap-1.5">
                        {r.failed ? (
                          <Badge variant="secondary" className="bg-slate-100 text-slate-600">No interview</Badge>
                        ) : r.evaluation?.tier ? (
                          <AiTierBadge tier={r.evaluation.tier} />
                        ) : null}
                        {r.roundStage === "disqualified" && (
                          <Badge className="border-0 bg-red-600 text-white">Disqualified</Badge>
                        )}
                        {r.finalOutcome === "matched" ? (
                          <Badge className="border-0 bg-[#d4af37] text-black font-bold">HIRED</Badge>
                        ) : r.roundStage === "terminated" ? (
                          <Badge className="border-0 bg-red-700 text-white">TERMINATED</Badge>
                        ) : null}
                        {r.autoReminding ? (
                          <Badge className="border-0 bg-amber-100 text-amber-800">Auto-reminding</Badge>
                        ) : r.incomplete ? (
                          <Badge variant="secondary" className="bg-slate-100 text-slate-500">Reminder expired</Badge>
                        ) : null}
                      </div>
                    </div>
                  </div>
                  <div className="grid grid-cols-2 gap-2 text-xs text-muted-foreground mb-3">
                    <div>
                      <div className="font-medium text-foreground">Recommended</div>
                      {r.failed ? "—"
                        : r.evaluation?.ai_recommended === true ? "Yes"
                        : r.evaluation?.ai_recommended === false ? "No" : "—"}
                    </div>
                    <div>
                      <div className="font-medium text-foreground">Duration</div>
                      {fmtDuration(r.session.duration_seconds)}
                    </div>
                    <div className="col-span-2">
                      <div className="font-medium text-foreground">Interview Date</div>
                      {fmtDate(r.session.ended_at || r.session.created_at)}
                    </div>
                  </div>
                  <div className="flex flex-row flex-wrap items-center gap-2">
                    <Button
                      size="lg"
                      className="min-h-[48px] px-6 text-base font-semibold shadow-md bg-emerald-600 hover:bg-emerald-700 text-white"
                      onClick={() => navigate(`/dashboard/ai-interviews/${r.responseId}/${r.round}`)}
                    >
                      <Eye className="h-5 w-5 mr-2" /> View Report
                    </Button>
                    <RecoverInterviewButton
                      responseId={r.responseId}
                        candidateName={r.candidateName === "Direct Link Candidate" ? "" : r.candidateName}
                        candidateEmail={r.candidateEmail}
                        appearance="outline"
                        eligible={true}
                      />
                      {r.round === "R1" && (
                        <RescueCandidateButton
                          responseId={r.responseId}
                          candidateName={r.candidateName === "Direct Link Candidate" ? "" : r.candidateName}
                          candidateEmail={r.candidateEmail}
                          appearance="outline"
                          round={1}
                        />
                      )}
                      {r.round === "R2" && (
                        <RescueCandidateButton
                          responseId={r.responseId}
                          candidateName={r.candidateName === "Direct Link Candidate" ? "" : r.candidateName}
                          candidateEmail={r.candidateEmail}
                          appearance="outline"
                          round={2}
                        />
                      )}
                      <StopRemindersButton responseId={r.responseId} appearance="outline" />
                      <Button
                        size="sm"
                        className="min-h-[44px] bg-violet-600 hover:bg-violet-700 text-white"
                        onClick={() => setCustomMsgTarget({
                          responseId: r.responseId,
                          name: r.candidateName === "Direct Link Candidate" ? "" : r.candidateName,
                          email: r.candidateEmail,
                        })}
                      >
                        <MessageSquare className="h-4 w-4 mr-1.5" /> Send Message
                      </Button>
                      <DisqualifyButton
                        responseId={r.responseId}
                        candidateName={r.candidateName === "Direct Link Candidate" ? "" : r.candidateName}
                        onDisqualified={() => handleDisqualified(r.responseId)}
                      />
                      <Button
                        size="sm"
                        variant="outline"
                        className="min-h-[44px] text-red-600 hover:text-red-700 border-red-200 hover:bg-red-50"
                        disabled={deleting}
                        onClick={() => setConfirmTarget(r.responseId)}
                        aria-label="Send to Quarantine"
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                  </div>
                </div>
              ))}
            </div>

            {filtered.length === 0 && (
              <div className="text-center text-sm text-muted-foreground py-8">
                No interviews match your filters.
              </div>
            )}
          </>
        )}
      </main>

      <SendCustomMessageDialog
        open={!!customMsgTarget}
        onOpenChange={(o) => { if (!o) setCustomMsgTarget(null); }}
        initialName={customMsgTarget?.name}
        initialEmail={customMsgTarget?.email}
        responseId={customMsgTarget?.responseId}
      />

      <FilePreviewDialog file_url={previewFile} onClose={() => setPreviewFile(null)} />

      {/* Quarantine confirm — single or bulk. */}
      <AlertDialog open={confirmTarget !== null} onOpenChange={(o) => { if (!o) setConfirmTarget(null); }}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>
              Send to Quarantine{confirmTarget === "bulk" ? ` (${selectedIds.size})` : ""}?
            </AlertDialogTitle>
            <AlertDialogDescription>
              Their interview record moves to Quarantine; their application stays in Results.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={deleting}>Cancel</AlertDialogCancel>
            <AlertDialogAction
              className="bg-red-600 hover:bg-red-700 text-white"
              disabled={deleting}
              onClick={(e) => {
                e.preventDefault();
                const ids = confirmTarget === "bulk" ? Array.from(selectedIds) : confirmTarget ? [confirmTarget] : [];
                runQuarantine(ids);
              }}
            >
              {deleting ? (<><Loader2 className="h-4 w-4 mr-2 animate-spin" /> Moving…</>) : "Send to Quarantine"}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
};

export default AiInterviews;
