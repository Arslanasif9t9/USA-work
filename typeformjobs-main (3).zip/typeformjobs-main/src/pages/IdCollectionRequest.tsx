import { useEffect, useRef, useState } from "react";
import { useParams } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Loader2, CheckCircle2, Upload as UploadIcon, X, ImageIcon } from "lucide-react";
import { toast } from "sonner";
import EiaWordmark from "@/components/EiaWordmark";

const NAVY = "#1a2547";
const GOLD = "#b08d57";
const CREAM = "#faf8f3";

const BUCKET = "candidate-files";

type Validate = {
  valid: boolean;
  reason?: string;
  external_reference?: string;
  signer_name?: string;
  signer_email?: string;
  response_id?: string;
};

const SectionLabel = ({ children }: { children: React.ReactNode }) => (
  <div style={{ fontFamily: "'Inter', sans-serif", fontWeight: 600, fontSize: 11, color: GOLD, textTransform: "uppercase", letterSpacing: 3 }}>
    {children}
  </div>
);

const PageShell = ({ subtitle, children }: { subtitle: string; children: React.ReactNode }) => (
  <div className="min-h-screen" style={{ backgroundColor: CREAM }}>
    <div className="max-w-2xl mx-auto px-6 py-10 md:py-14">
      <div className="mb-8 flex justify-center">
        <EiaWordmark subtitle={subtitle} align="center" />
      </div>
      {children}
      <div className="mt-10 text-center text-xs text-muted-foreground">
        &copy; {new Date().getFullYear()} Expert Intuitive Advisor Inc.
      </div>
    </div>
  </div>
);

const FieldLabel = ({ children, required }: { children: React.ReactNode; required?: boolean }) => (
  <Label className="text-sm font-medium block mb-1.5" style={{ color: NAVY }}>
    {children} {required && <span style={{ color: "#dc2626" }}>*</span>}
  </Label>
);

// Live typed-signature preview rendered in Allura script (matches the offer-letter PDF signature).
function TypedSignaturePreview({ name }: { name: string }) {
  return (
    <div
      className="rounded-md border bg-white flex items-center justify-center px-4"
      style={{ borderColor: `${GOLD}66`, minHeight: 90 }}
    >
      {name.trim() ? (
        <span
          style={{
            fontFamily: "'Allura', cursive",
            fontSize: 44,
            lineHeight: 1,
            color: NAVY,
            whiteSpace: "nowrap",
            overflow: "hidden",
            textOverflow: "ellipsis",
            maxWidth: "100%",
          }}
        >
          {name}
        </span>
      ) : (
        <span className="text-xs text-muted-foreground">
          Your typed name will appear here as your signature
        </span>
      )}
    </div>
  );
}

const manilaToday = () =>
  new Intl.DateTimeFormat("en-CA", { timeZone: "Asia/Manila", year: "numeric", month: "2-digit", day: "2-digit" })
    .format(new Date());

const IMAGE_RE = /\.(jpe?g|png|gif|webp|bmp|heic|heif|avif|tiff?)$/i;

// One image upload slot. Uploads to candidate-files at idcollection/{token}/...
// Shows a local thumbnail preview (HEIC converted client-side via heic2any).
// Stores the resulting "{bucket}/{path}" URL via onChange.
function IdPhotoSlot({
  token,
  slot,
  label,
  value,
  onChange,
}: {
  token: string;
  slot: 1 | 2;
  label: string;
  value: string | null;
  onChange: (url: string | null) => void;
}) {
  const inputRef = useRef<HTMLInputElement>(null);
  const [uploading, setUploading] = useState(false);
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const previewRef = useRef<string | null>(null);

  useEffect(() => {
    return () => {
      if (previewRef.current) URL.revokeObjectURL(previewRef.current);
    };
  }, []);

  const makePreview = async (file: File) => {
    if (previewRef.current) {
      URL.revokeObjectURL(previewRef.current);
      previewRef.current = null;
    }
    try {
      let blob: Blob = file;
      if (/\.(heic|heif)$/i.test(file.name) || file.type === "image/heic" || file.type === "image/heif") {
        const heic2any = (await import("heic2any")).default;
        const converted = await heic2any({ blob: file, toType: "image/jpeg", quality: 0.8 });
        blob = (Array.isArray(converted) ? converted[0] : converted) as Blob;
      }
      const url = URL.createObjectURL(blob);
      previewRef.current = url;
      setPreviewUrl(url);
    } catch {
      setPreviewUrl(null);
    }
  };

  const onFile = async (file: File) => {
    if (!IMAGE_RE.test(file.name)) {
      toast.error("Please upload an image file (JPG, PNG, WEBP, HEIC, AVIF).");
      return;
    }
    setUploading(true);
    try {
      const ext = (file.name.split(".").pop() || "jpg").toLowerCase();
      const ts = Date.now();
      const path = `idcollection/${token}/photo${slot}-${ts}.${ext}`;
      const { error } = await supabase.storage.from(BUCKET).upload(path, file, {
        contentType: file.type || "application/octet-stream",
        upsert: false,
      });
      if (error) {
        toast.error("Upload failed. Please try again.");
        return;
      }
      await makePreview(file);
      onChange(`${BUCKET}/${path}`);
    } finally {
      setUploading(false);
    }
  };

  const clear = () => {
    if (previewRef.current) {
      URL.revokeObjectURL(previewRef.current);
      previewRef.current = null;
    }
    setPreviewUrl(null);
    onChange(null);
    if (inputRef.current) inputRef.current.value = "";
  };

  return (
    <div>
      <FieldLabel required>{label}</FieldLabel>
      <input
        ref={inputRef}
        type="file"
        accept="image/*"
        className="hidden"
        onChange={(e) => {
          const f = e.target.files?.[0];
          if (f) onFile(f);
        }}
      />
      {value && previewUrl ? (
        <div className="rounded-md border p-3 flex items-center gap-3" style={{ borderColor: `${GOLD}66` }}>
          <div className="h-20 w-20 rounded-md overflow-hidden bg-secondary flex items-center justify-center shrink-0">
            <img src={previewUrl} alt={label} className="w-full h-full object-cover" />
          </div>
          <div className="flex-1 min-w-0">
            <div className="text-sm font-medium" style={{ color: NAVY }}>Photo uploaded</div>
            <div className="text-xs text-muted-foreground">Stored securely for HR review.</div>
          </div>
          <button
            type="button"
            onClick={clear}
            className="p-1 text-muted-foreground hover:text-destructive"
            aria-label="Remove"
          >
            <X className="h-4 w-4" />
          </button>
        </div>
      ) : value && !previewUrl ? (
        <div className="rounded-md border p-3 flex items-center gap-3" style={{ borderColor: `${GOLD}66` }}>
          <div className="h-20 w-20 rounded-md overflow-hidden bg-secondary flex items-center justify-center shrink-0">
            <ImageIcon className="h-7 w-7 text-muted-foreground" />
          </div>
          <div className="flex-1 min-w-0">
            <div className="text-sm font-medium" style={{ color: NAVY }}>Photo uploaded</div>
            <div className="text-xs text-muted-foreground">Stored securely for HR review.</div>
          </div>
          <button type="button" onClick={clear} className="p-1 text-muted-foreground hover:text-destructive" aria-label="Remove">
            <X className="h-4 w-4" />
          </button>
        </div>
      ) : (
        <Button
          type="button"
          variant="outline"
          disabled={uploading}
          onClick={() => inputRef.current?.click()}
          className="h-11 w-full"
          style={{ borderColor: `${GOLD}66`, color: NAVY }}
        >
          {uploading ? (
            <><Loader2 className="h-4 w-4 animate-spin mr-2" /> Uploading…</>
          ) : (
            <><UploadIcon className="h-4 w-4 mr-2" /> Upload {label}</>
          )}
        </Button>
      )}
    </div>
  );
}

export default function IdCollectionRequest() {
  const { token } = useParams<{ token: string }>();
  const [loading, setLoading] = useState(true);
  const [info, setInfo] = useState<Validate | null>(null);
  const [hrMessage, setHrMessage] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);
  const [done, setDone] = useState(false);

  // Fields
  const [photo1, setPhoto1] = useState<string | null>(null);
  const [photo2, setPhoto2] = useState<string | null>(null);
  const [bodyNote, setBodyNote] = useState("");
  const [typedName, setTypedName] = useState("");
  const [showErrors, setShowErrors] = useState(false);

  const signatureDate = manilaToday();

  useEffect(() => {
    if (!token) return;
    (async () => {
      const { data } = await supabase.functions.invoke<Validate>("validate-leave-token", { body: { token } });
      const v = data || { valid: false };
      setInfo(v);
      if (v.valid && v.signer_name) setTypedName(v.signer_name);
      // Load the optional HR message (read-only branch of submit-id-collection).
      if (v.valid) {
        try {
          const { data: loaded } = await supabase.functions.invoke<{ ok: boolean; id_hr_message?: string | null }>(
            "submit-id-collection",
            { body: { token, action: "load" } },
          );
          if (loaded?.ok && loaded.id_hr_message) setHrMessage(loaded.id_hr_message);
        } catch (_e) { /* non-fatal */ }
      }
      setLoading(false);
    })();
  }, [token]);

  const missing = {
    photo1: !photo1,
    photo2: !photo2,
    typedName: !typedName.trim(),
  };
  const hasErrors = Object.values(missing).some(Boolean);

  const submit = async () => {
    if (!token) return;
    if (hasErrors) {
      setShowErrors(true);
      toast.error("Please upload both ID photos and type your name.");
      return;
    }
    setSubmitting(true);
    try {
      const { data, error } = await supabase.functions.invoke<{ ok: boolean; reason?: string }>("submit-id-collection", {
        body: {
          token,
          id_photo_1_url: photo1,
          id_photo_2_url: photo2,
          id_body_note: bodyNote,
          typed_name: typedName,
          signature_data: null,
          signature_date: signatureDate,
        },
      });
      if (error || !data?.ok) {
        toast.error(data?.reason ? `Could not submit (${data.reason}).` : "Could not submit. Please try again.");
        return;
      }
      setDone(true);
    } finally {
      setSubmitting(false);
    }
  };

  if (loading) {
    return (
      <PageShell subtitle="ID COLLECTION">
        <div className="flex items-center justify-center py-20">
          <Loader2 className="h-6 w-6 animate-spin" style={{ color: NAVY }} />
        </div>
      </PageShell>
    );
  }

  if (!info?.valid) {
    const msg =
      info?.reason === "expired"
        ? "This ID collection link has expired. Please contact HR for a new one."
        : info?.reason === "used"
        ? "This ID collection request has already been submitted."
        : "This link is not valid.";
    return (
      <PageShell subtitle="ID COLLECTION">
        <Card className="border-0 shadow-sm">
          <CardContent className="pt-8 pb-8 text-center space-y-3">
            <SectionLabel>Link Unavailable</SectionLabel>
            <h2 style={{ fontFamily: "'Cormorant Garamond', serif", fontWeight: 600, fontSize: 26, color: NAVY }}>
              {msg}
            </h2>
          </CardContent>
        </Card>
      </PageShell>
    );
  }

  if (done) {
    return (
      <PageShell subtitle="ID COLLECTION">
        <Card className="border-0 shadow-sm">
          <CardContent className="pt-8 pb-8 text-center space-y-4">
            <CheckCircle2 className="h-12 w-12 mx-auto" style={{ color: "#16a34a" }} />
            <SectionLabel>Submitted</SectionLabel>
            <h2 style={{ fontFamily: "'Cormorant Garamond', serif", fontWeight: 600, fontSize: 28, color: NAVY, lineHeight: 1.1 }}>
              Thank you, {(typedName || "").split(" ")[0] || "your details are in"}
            </h2>
            <p className="text-sm md:text-base max-w-md mx-auto" style={{ color: NAVY }}>
              Your ID details have been submitted securely to our team.
            </p>
            <p className="text-sm text-muted-foreground max-w-md mx-auto">
              You'll hear from us if anything further is needed.
            </p>
          </CardContent>
        </Card>
      </PageShell>
    );
  }

  const ErrHint = ({ show }: { show: boolean }) =>
    show && showErrors ? <p className="text-xs mt-1" style={{ color: "#dc2626" }}>Required</p> : null;

  return (
    <PageShell subtitle="ID COLLECTION">
      <div className="text-center mb-6 space-y-2">
        <SectionLabel>ID Collection</SectionLabel>
        <h1 style={{ fontFamily: "'Cormorant Garamond', serif", fontWeight: 600, fontSize: 32, color: NAVY, lineHeight: 1.1 }}>
          Submit Your Identification
        </h1>
        <p className="text-sm text-muted-foreground max-w-xl mx-auto">
          Please upload clear photos of your identification below so our team can complete your records securely.
        </p>
      </div>

      {hrMessage && (
        <div
          className="rounded-md border p-4 mb-6"
          style={{ borderColor: `${GOLD}66`, backgroundColor: "#fff", borderLeftWidth: 4, borderLeftColor: GOLD }}
        >
          <SectionLabel>A note from our team</SectionLabel>
          <p className="text-sm mt-1.5 whitespace-pre-wrap" style={{ color: NAVY }}>{hrMessage}</p>
        </div>
      )}

      <Card className="border-0 shadow-sm">
        <CardContent className="p-6 md:p-8 space-y-6">

          {token && (
            <IdPhotoSlot token={token} slot={1} label="ID Photo 1" value={photo1} onChange={setPhoto1} />
          )}
          <ErrHint show={missing.photo1} />

          {token && (
            <IdPhotoSlot token={token} slot={2} label="ID Photo 2" value={photo2} onChange={setPhoto2} />
          )}
          <ErrHint show={missing.photo2} />

          <div>
            <FieldLabel>Notes (optional)</FieldLabel>
            <Textarea
              value={bodyNote}
              onChange={(e) => setBodyNote(e.target.value)}
              rows={4}
              placeholder="Write anything you'd like our team to know."
            />
          </div>

          <div className="border-t pt-5 space-y-4">
            <SectionLabel>Signature</SectionLabel>

            <div>
              <FieldLabel required>Type your full name</FieldLabel>
              <Input value={typedName} onChange={(e) => setTypedName(e.target.value)} className="h-11" />
              <ErrHint show={missing.typedName} />
            </div>

            <div>
              <FieldLabel>Signature preview</FieldLabel>
              <TypedSignaturePreview name={typedName} />
              <p className="text-xs text-muted-foreground mt-1.5">
                Your typed name is your signature. It confirms the details you submitted above.
              </p>
            </div>

            <div>
              <FieldLabel>Date</FieldLabel>
              <Input value={signatureDate} readOnly className="h-11 bg-muted/60 text-muted-foreground" />
            </div>
          </div>

          <div className="border-t pt-5 flex flex-col items-center gap-2">
            <Button
              onClick={submit}
              disabled={submitting}
              style={{ backgroundColor: NAVY, color: "#fff" }}
              className="min-w-[240px] h-11"
            >
              {submitting ? <><Loader2 className="h-4 w-4 animate-spin mr-2" /> Submitting…</> : "Submit ID Collection"}
            </Button>
          </div>

        </CardContent>
      </Card>
    </PageShell>
  );
}
