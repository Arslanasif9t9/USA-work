import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Plus, LogOut, MoreHorizontal, FileText, Loader2, CalendarClock, Users, ShieldAlert, Link2, ExternalLink, Pencil, BarChart3, Trash2, Copy as CopyIcon, UsersRound, ClipboardList, CheckCircle2, Ban, Video, UserCog, Mail, Settings as SettingsIcon, Rocket, LayoutGrid, FileCheck2, MessageCircle } from "lucide-react";
import { SendCustomMessageDialog } from "@/components/SendCustomMessageDialog";
import { getPublicFormUrl } from "@/lib/publicUrl";
import { Skeleton } from "@/components/ui/skeleton";
import { withProgress } from "@/lib/progress";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Badge } from "@/components/ui/badge";
import { toast } from "sonner";
import { generateUniqueSlug } from "@/lib/slug";
import { duplicateForm } from "@/lib/duplicateForm";
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";

type Form = {
  id: string;
  title: string;
  slug: string;
  status: string;
  updated_at: string;
};

const Dashboard = () => {
  const { user, signOut } = useAuth();
  const navigate = useNavigate();
  const [forms, setForms] = useState<Form[]>([]);
  const [counts, setCounts] = useState<Record<string, number>>({});
  const [unread, setUnread] = useState<Record<string, number>>({});
  const [loading, setLoading] = useState(true);
  const [creating, setCreating] = useState(false);
  const [renameId, setRenameId] = useState<string | null>(null);
  const [renameValue, setRenameValue] = useState("");
  const [deleteId, setDeleteId] = useState<string | null>(null);
  const [dupId, setDupId] = useState<string | null>(null);
  const [duplicating, setDuplicating] = useState(false);
  const [customMsgOpen, setCustomMsgOpen] = useState(false);

  const load = async () => {
    setLoading(true);
    const { data, error } = await supabase
      .from("forms")
      .select("id, title, slug, status, updated_at")
      .order("updated_at", { ascending: false });
    if (error) {
      toast.error(error.message);
      setLoading(false);
      return;
    }
    setForms(data || []);
    if (data && data.length) {
      const ids = data.map((f) => f.id);
      const { data: resp } = await supabase
        .from("responses")
        .select("form_id, viewed_at")
        .in("form_id", ids);
      const c: Record<string, number> = {};
      const u: Record<string, number> = {};
      (resp || []).forEach((r: any) => {
        c[r.form_id] = (c[r.form_id] || 0) + 1;
        if (!r.viewed_at) u[r.form_id] = (u[r.form_id] || 0) + 1;
      });
      setCounts(c);
      setUnread(u);
    }
    setLoading(false);
  };

  useEffect(() => {
    document.title = "EIA Talent Recruiting System — Dashboard";
    load();
  }, []);


  const handleLogout = async () => {
    await signOut();
    navigate("/login", { replace: true });
  };

  const handleCreate = async () => {
    if (!user) return;
    setCreating(true);
    try {
      const slug = await generateUniqueSlug("Untitled Form");
      const { data: form, error } = await supabase
        .from("forms")
        .insert({
          title: "Untitled Form",
          slug,
          status: "draft",
          created_by: user.id,
        })
        .select()
        .single();
      if (error) throw error;

      const { error: qErr } = await supabase.from("questions").insert([
        {
          form_id: form.id,
          type: "welcome",
          label: "Welcome to our application",
          description: "We are excited to learn more about you.",
          required: false,
          order_index: 0,
        },
        {
          form_id: form.id,
          type: "thank_you",
          label: "Thank you!",
          description: "Your application has been submitted successfully.",
          required: false,
          order_index: 9999,
        },
      ]);
      if (qErr) throw qErr;
      navigate(`/forms/${form.id}`);
    } catch (e: any) {
      toast.error(e.message || "Failed to create form");
    } finally {
      setCreating(false);
    }
  };

  const handleRename = async () => {
    if (!renameId) return;
    const title = renameValue.trim() || "Untitled Form";
    const slug = await generateUniqueSlug(title, renameId);
    const { error } = await supabase
      .from("forms")
      .update({ title, slug })
      .eq("id", renameId);
    if (error) toast.error(error.message);
    else toast.success("Renamed");
    setRenameId(null);
    load();
  };

  const [deletingForm, setDeletingForm] = useState(false);
  const handleDelete = async () => {
    if (!deleteId) return;
    setDeletingForm(true);
    const { error } = await withProgress(async () => await supabase.from("forms").delete().eq("id", deleteId));
    setDeletingForm(false);
    if (error) toast.error(error.message);
    else toast.success("Form deleted");
    setDeleteId(null);
    load();
  };

  const dupForm = forms.find((f) => f.id === dupId);
  const handleDuplicate = async () => {
    if (!dupId || !user) return;
    setDuplicating(true);
    try {
      const newForm = await withProgress(() => duplicateForm(dupId, user.id));
      toast.success(`Duplicated to "${newForm.title}". Click to edit.`, {
        duration: 5000,
        action: { label: "Edit", onClick: () => navigate(`/forms/${newForm.id}`) },
      });
      setDupId(null);
      navigate(`/forms/${newForm.id}`);
    } catch (e: any) {
      toast.error("Could not duplicate form. Please try again.");
    } finally {
      setDuplicating(false);
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <header className="bg-background" style={{ borderBottom: "1px solid #e1e4ec" }}>
        <div className="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between">
          <div className="flex flex-col leading-tight">
            <h1
              style={{
                fontFamily: "'Cormorant Garamond', serif",
                fontWeight: 600,
                fontSize: "18px",
                color: "#1a2547",
                letterSpacing: "1px",
                margin: 0,
                cursor: "pointer",
              }}
              onClick={() => navigate("/dashboard")}
            >
              EIA Talent Recruiting System
            </h1>
            <span
              style={{
                fontFamily: "'Inter', sans-serif",
                fontWeight: 400,
                fontSize: "9px",
                color: "#6b7280",
                textTransform: "uppercase",
                letterSpacing: "1px",
                marginTop: "2px",
              }}
            >
              Internal HR Tool
            </span>
          </div>
          <div className="flex flex-wrap items-center gap-2">
            {/* All Candidates nav hidden — route still accessible at /dashboard/candidates */}
            <Button variant="ghost" size="sm" onClick={() => navigate("/dashboard/my-bookings")}>
              <ClipboardList className="h-4 w-4 mr-1.5" /> My Bookings
            </Button>
            <Button variant="ghost" size="sm" onClick={() => navigate("/dashboard/ai-interviews")}>
              <Video className="h-4 w-4 mr-1.5" /> AI Interviews
            </Button>
            <Button variant="ghost" size="sm" onClick={() => navigate("/dashboard/candidate-wall")}>
              <LayoutGrid className="h-4 w-4 mr-1.5" /> Candidate Wall
            </Button>

            <Button variant="ghost" size="sm" onClick={() => navigate("/dashboard/disqualified")}>
              <Ban className="h-4 w-4 mr-1.5" /> Disqualified
            </Button>
            {/* Bookings page hidden — superseded by My Bookings. Route still exists at /dashboard/bookings. */}
            <Button variant="ghost" size="sm" onClick={() => navigate("/dashboard/employees")}>
              <Users className="h-4 w-4 mr-1.5" /> Employees
            </Button>
            <Button variant="ghost" size="sm" onClick={() => navigate("/dashboard/sylvia")}>
              <UserCog className="h-4 w-4 mr-1.5" /> Agent Sylvia Settings
            </Button>
            <Button variant="ghost" size="sm" onClick={() => navigate("/dashboard/launch")}>
              <Rocket className="h-4 w-4 mr-1.5" /> Launch Sylvia
            </Button>
            <Button variant="ghost" size="sm" onClick={() => navigate("/dashboard/quarantine")}>
              <ShieldAlert className="h-4 w-4 mr-1.5" /> Quarantine
            </Button>
            <Button variant="ghost" size="sm" onClick={() => navigate("/dashboard/sick-leaves")}>
              <CalendarClock className="h-4 w-4 mr-1.5" /> H.R Approval
            </Button>
            <Button variant="ghost" size="sm" onClick={() => navigate("/dashboard/signed-documents")}>
              <FileCheck2 className="h-4 w-4 mr-1.5" /> Signed Documents
            </Button>
            <Button variant="ghost" size="sm" onClick={() => navigate("/dashboard/circular-recipients")}>
              <UsersRound className="h-4 w-4 mr-1.5" /> Circular Recipients
            </Button>
            <Button variant="ghost" size="sm" onClick={() => navigate("/dashboard/circulars")}>
              <FileText className="h-4 w-4 mr-1.5" /> Circulars
            </Button>
            {/* Out-of-Office button hidden — legacy human-Zoom flow. Route /dashboard/out-of-office and enable-out-of-office function still exist; unhide to restore. */}
            <Button variant="ghost" size="sm" onClick={() => navigate("/job-scope-library")}>
              Job Scope Library
            </Button>
            {/* Notifications button hidden — passive page HR finds unused. Route /dashboard/notifications and all data/logic remain intact; unhide to restore. */}
            {/* <Button variant="ghost" size="sm" onClick={() => navigate("/dashboard/notifications")}>
              Notifications
            </Button> */}
            <Button variant="ghost" size="sm" onClick={() => setCustomMsgOpen(true)}>
              <Mail className="h-4 w-4 mr-1.5" /> Send Custom Message
            </Button>
            <Button variant="ghost" size="sm" onClick={() => navigate("/dashboard/whatsapp-chat")}>
              <MessageCircle className="h-4 w-4 mr-1.5" /> WhatsApp Chat
            </Button>
            {(user?.email || "").toLowerCase() === "spark11179@gmail.com" && (
              <Button variant="ghost" size="sm" onClick={() => navigate("/dashboard/settings")}>
                <SettingsIcon className="h-4 w-4 mr-1.5" /> Settings
              </Button>
            )}
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="sm">{user?.email}</Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuLabel>Account</DropdownMenuLabel>
                <DropdownMenuSeparator />
                <DropdownMenuItem onClick={handleLogout}>
                  <LogOut className="mr-2 h-4 w-4" /> Logout
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </div>
      </header>


      <main className="max-w-7xl mx-auto px-6 py-12">
        <div className="flex items-center justify-between mb-8">
          <h2 className="text-3xl font-bold tracking-tight">Forms</h2>
          <Button onClick={handleCreate} disabled={creating}>
            {creating ? (<><Loader2 className="mr-2 h-4 w-4 animate-spin" /> Creating...</>) : (<><Plus className="mr-2 h-4 w-4" /> Create Form</>)}
          </Button>
        </div>

        {loading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6" aria-busy="true">
            {[0, 1, 2].map((i) => (
              <div key={i} className="bg-card border border-border rounded-lg p-6 space-y-4">
                <Skeleton className="h-5 w-3/4" />
                <Skeleton className="h-5 w-16 rounded-full" />
                <div className="space-y-2 pt-2">
                  <Skeleton className="h-3 w-32" />
                  <Skeleton className="h-3 w-24" />
                </div>
              </div>
            ))}
          </div>
        ) : forms.length === 0 ? (
          <div className="border border-dashed border-border rounded-xl p-12 text-center">
            <div className="mx-auto mb-4 h-14 w-14 rounded-full bg-secondary flex items-center justify-center">
              <FileText className="h-6 w-6 text-muted-foreground" />
            </div>
            <h3 className="text-lg font-semibold mb-1">No forms yet</h3>
            <p className="text-sm text-muted-foreground mb-6">
              Create your first hiring form to get started.
            </p>
            <Button onClick={handleCreate} disabled={creating}>
              {creating ? (<><Loader2 className="mr-2 h-4 w-4 animate-spin" /> Creating...</>) : (<><Plus className="mr-2 h-4 w-4" /> Create Form</>)}
            </Button>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {forms.map((f) => (
              <div
                key={f.id}
                onClick={() => navigate(`/forms/${f.id}`)}
                className="group relative bg-card border border-border rounded-lg p-6 cursor-pointer transition-all hover:border-foreground/30 hover:shadow-sm"
              >
                <div className="absolute top-3 right-3 flex items-center gap-2" onClick={(e) => e.stopPropagation()}>
                  {unread[f.id] > 0 && (
                    <span className="bg-primary text-primary-foreground text-[11px] font-semibold rounded-full px-2 py-0.5">
                      {unread[f.id]} new
                    </span>
                  )}
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="ghost" size="icon" className="h-8 w-8">
                        <MoreHorizontal className="h-4 w-4" />
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end" className="w-56">
                      <DropdownMenuItem
                        onClick={async () => {
                          const url = getPublicFormUrl(f.slug);
                          try {
                            await navigator.clipboard.writeText(url);
                            toast.success("Form link copied");
                          } catch {
                            toast.error("Could not copy link");
                          }
                        }}
                      >
                        <CopyIcon className="mr-2 h-4 w-4" /> Copy form link
                      </DropdownMenuItem>
                      <DropdownMenuSeparator />
                      <DropdownMenuItem onClick={() => navigate(`/forms/${f.id}`)}>
                        <Pencil className="mr-2 h-4 w-4" /> Edit form
                      </DropdownMenuItem>
                      <DropdownMenuItem onClick={() => navigate(`/forms/${f.id}/results`)}>
                        <BarChart3 className="mr-2 h-4 w-4" /> View results
                      </DropdownMenuItem>
                      <DropdownMenuSeparator />
                      <DropdownMenuItem
                        onClick={() => {
                          setRenameId(f.id);
                          setRenameValue(f.title);
                        }}
                      >
                        Rename
                      </DropdownMenuItem>
                      <DropdownMenuItem onClick={() => setDupId(f.id)}>
                        Duplicate
                      </DropdownMenuItem>
                      <DropdownMenuItem
                        className="text-destructive focus:text-destructive"
                        onClick={() => setDeleteId(f.id)}
                      >
                        <Trash2 className="mr-2 h-4 w-4" /> Delete form
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </div>

                <h3 className="text-lg font-semibold pr-8 mb-3 line-clamp-2">{f.title}</h3>
                <div className="flex items-center gap-2 mb-4">
                  {f.status === "live" ? (
                    <Badge className="bg-green-100 text-green-800 hover:bg-green-100 border-0">Live</Badge>
                  ) : (
                    <Badge variant="secondary">Draft</Badge>
                  )}
                </div>
                <div className="text-xs text-muted-foreground space-y-1">
                  <div>
                    Updated{" "}
                    {new Date(f.updated_at).toLocaleDateString("en-US", {
                      month: "short",
                      day: "numeric",
                      year: "numeric",
                    })}
                  </div>
                  <div>{counts[f.id] || 0} {(counts[f.id] || 0) === 1 ? "response" : "responses"}</div>
                </div>
                <Button
                  size="sm"
                  className="mt-4 w-full bg-blue-600 hover:bg-blue-700 text-white"
                  onClick={(e) => {
                    e.stopPropagation();
                    navigate(`/forms/${f.id}/results`);
                  }}
                >
                  <BarChart3 className="mr-2 h-4 w-4" /> View Results
                </Button>
              </div>
            ))}
          </div>
        )}
      </main>

      <Dialog open={!!renameId} onOpenChange={(o) => !o && setRenameId(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Rename form</DialogTitle>
          </DialogHeader>
          <Input
            value={renameValue}
            onChange={(e) => setRenameValue(e.target.value)}
            placeholder="Form title"
            autoFocus
          />
          <DialogFooter>
            <Button variant="ghost" onClick={() => setRenameId(null)}>
              Cancel
            </Button>
            <Button onClick={handleRename}>Save</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <AlertDialog open={!!deleteId} onOpenChange={(o) => !o && setDeleteId(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete this form?</AlertDialogTitle>
            <AlertDialogDescription>
              This will permanently delete all responses.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={deletingForm}>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={(e) => { e.preventDefault(); handleDelete(); }} disabled={deletingForm}>
              {deletingForm ? (<><Loader2 className="h-4 w-4 mr-2 animate-spin" /> Deleting...</>) : "Delete"}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      <AlertDialog open={!!dupId} onOpenChange={(o) => !o && !duplicating && setDupId(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Duplicate this form?</AlertDialogTitle>
            <AlertDialogDescription>
              A copy of "{dupForm?.title}" will be created with all its questions. The copy starts as a draft.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={duplicating}>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={(e) => { e.preventDefault(); handleDuplicate(); }} disabled={duplicating}>
              {duplicating ? "Duplicating..." : "Duplicate"}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
      <SendCustomMessageDialog open={customMsgOpen} onOpenChange={setCustomMsgOpen} />
    </div>
  );
};

export default Dashboard;
