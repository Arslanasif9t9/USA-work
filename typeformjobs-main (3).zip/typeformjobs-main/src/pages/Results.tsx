import { useEffect, useMemo, useRef, useState } from "react";
import { useParams, Navigate, useSearchParams } from "react-router-dom";
import FormTopBar, { useFormHeader } from "@/components/FormTopBar";
import { EmailInlineEditor } from "@/components/EmailInlineEditor";
import { supabase } from "@/integrations/supabase/client";
import { parsePhoneNumberFromString } from "libphonenumber-js";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
} from "@/components/ui/sheet";
import { Dialog, DialogContent } from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Calendar } from "@/components/ui/calendar";
import { toast } from "sonner";
import {
  Download,
  FileText as FileIcon,
  FileText,
  Image as ImageIcon,
  File as FileGeneric,
  Search,
  X,
  SlidersHorizontal,
  Columns3,
  ArrowUp,
  ArrowDown,
  ArrowUpDown,
  Eye,
  EyeOff,
  CalendarIcon,
  Inbox,
  SearchX,
  Loader2,
  CalendarPlus,
  Send,
  Check,
  Trash2,
} from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import Papa from "papaparse";
import { format as fmtFn } from "date-fns";
import {
  type CandidateAction,
  extractCandidateInfo,
  fetchCandidateActionsForForm,
  detectContactQuestionIds,
} from "@/lib/candidateActions";
import { ActionsCell } from "@/components/action-dialogs/ActionsCell";
import { computePipelineStage } from "@/lib/pipelineStage";
import ScheduledSendChip from "@/components/ScheduledSendChip";
import { cn } from "@/lib/utils";

type Q = {
  id: string;
  type: string;
  label: string;
  order_index: number;
  options?: any;
};
type Response = {
  id: string;
  submitted_at: string;
  viewed_at: string | null;
  applicant_id: string;
  status?: string | null;
  last_activity_at?: string | null;
  current_question_index?: number | null;
  session_token?: string | null;
  override_email?: string | null;
  override_name?: string | null;
  round_stage?: string | null;
  disqualified_at_stage?: string | null;
  appointment_cancelled?: boolean | null;
};
type Answer = {
  response_id: string;
  question_id: string;
  answer_text: string | null;
  file_url: string | null;
};

const fmtDate = (iso: string) =>
  new Date(iso).toLocaleString("en-US", {
    month: "long",
    day: "numeric",
    year: "numeric",
    hour: "numeric",
    minute: "2-digit",
  });

const fmtCompactDate = (iso: string) => {
  const d = new Date(iso);
  const m = d.getMonth() + 1;
  const day = d.getDate();
  const y = String(d.getFullYear()).slice(-2);
  return `${m}/${day}/${y}`;
};
const fmtCompactTime = (iso: string) =>
  new Date(iso).toLocaleTimeString("en-US", { hour: "numeric", minute: "2-digit" });

const KNOWN_BUCKETS = ["candidate-files", "candidate-selfies", "resumes", "selfies"];

const parseFilePath = (file_url: string): { bucket: string; path: string; name: string } => {
  const parts = file_url.split("/");
  let bucket = "candidate-files";
  let pathParts = parts;
  if (parts.length > 1 && KNOWN_BUCKETS.includes(parts[0])) {
    bucket = parts[0];
    pathParts = parts.slice(1);
  }
  const path = pathParts.join("/");
  const last = pathParts[pathParts.length - 1] || "file";
  const name = last.replace(/^\d+-/, "");
  return { bucket, path, name };
};

const downloadFile = async (file_url: string) => {
  try {
    const { bucket, path, name } = parseFilePath(file_url);
    const { data, error } = await supabase.storage
      .from(bucket)
      .createSignedUrl(path, 60, { download: name });
    if (error || !data?.signedUrl) {
      toast.error("Could not download file");
      return;
    }
    let objectUrl: string | null = null;
    let href = data.signedUrl;
    try {
      const resp = await fetch(data.signedUrl);
      const blob = await resp.blob();
      objectUrl = URL.createObjectURL(blob);
      href = objectUrl;
    } catch {}
    const a = document.createElement("a");
    a.href = href;
    a.download = name;
    a.rel = "noopener";
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    if (objectUrl) setTimeout(() => URL.revokeObjectURL(objectUrl!), 1000);
  } catch {
    toast.error("Could not download file");
  }
};

const isImageName = (name: string) => /\.(jpe?g|png|gif|webp|bmp|svg|heic|heif|avif|tiff?)$/i.test(name);
const isHeicName = (name: string) => /\.(heic|heif)$/i.test(name);
const isPdfName = (name: string) => /\.pdf$/i.test(name);
const isOfficeName = (name: string) => /\.(docx?|xlsx?|pptx?)$/i.test(name);
const mimeFromName = (name: string) => {
  const ext = name.split(".").pop()?.toLowerCase();
  switch (ext) {
    case "jpg":
    case "jpeg":
      return "image/jpeg";
    case "png":
      return "image/png";
    case "gif":
      return "image/gif";
    case "webp":
      return "image/webp";
    case "bmp":
      return "image/bmp";
    case "svg":
      return "image/svg+xml";
    case "avif":
      return "image/avif";
    case "heic":
      return "image/heic";
    case "heif":
      return "image/heif";
    case "tif":
    case "tiff":
      return "image/tiff";
    case "pdf":
      return "application/pdf";
    default:
      return "application/octet-stream";
  }
};

const FileChip = ({ file_url, onPreview }: { file_url: string; onPreview: () => void }) => {
  const { name } = parseFilePath(file_url);
  const truncated = name.length > 15 ? name.slice(0, 15) + "..." : name;
  const Icon = isImageName(name) ? ImageIcon : isPdfName(name) ? FileText : FileGeneric;
  return (
    <TooltipProvider delayDuration={150}>
      <Tooltip>
        <TooltipTrigger asChild>
          <button
            type="button"
            onClick={(e) => { e.stopPropagation(); onPreview(); }}
            className="inline-flex items-center gap-1.5 px-2 py-1 rounded-md text-xs text-ink hover:text-navy hover:font-semibold hover:bg-soft-bg transition-colors max-w-full"
          >
            <Icon className="h-3.5 w-3.5 text-gold shrink-0" />
            <span className="truncate">{truncated}</span>
          </button>
        </TooltipTrigger>
        <TooltipContent side="top" className="max-w-xs break-all">{name}</TooltipContent>
      </Tooltip>
    </TooltipProvider>
  );
};

const FileCard = ({ file_url, display_name, onPreview }: { file_url: string; display_name?: string; onPreview: () => void }) => {
  const { name } = parseFilePath(file_url);
  const fileName = display_name || name;
  return (
    <button
      type="button"
      onClick={onPreview}
      className="w-full bg-secondary/50 border border-border rounded-lg p-4 flex items-center gap-3 hover:bg-secondary/70 transition-colors text-left"
    >
      <div className="h-10 w-10 rounded-md bg-background flex items-center justify-center flex-shrink-0">
        <FileIcon className="h-5 w-5 text-muted-foreground" />
      </div>
      <div className="flex-1 min-w-0">
        <div className="text-sm font-medium truncate" title={fileName}>{fileName}</div>
        <div className="text-xs text-muted-foreground">Click to preview</div>
      </div>
      <span className="inline-flex items-center gap-1.5 h-9 px-3 rounded-md bg-primary text-primary-foreground text-sm font-medium">
        <Eye className="h-4 w-4" /> Preview
      </span>
    </button>
  );
};

const SelfieThumb = ({ file_url, size = 48, onPreview }: { file_url: string; size?: number; onPreview: () => void }) => {
  const [url, setUrl] = useState<string | null>(null);
  const [failed, setFailed] = useState(false);
  useEffect(() => {
    const meta = parseFilePath(file_url);
    let cancelled = false;
    let objectUrl: string | null = null;
    setFailed(false);
    setUrl(null);
    (async () => {
      const { data } = await supabase.storage.from(meta.bucket).createSignedUrl(meta.path, 600);
      if (cancelled || !data?.signedUrl) return;
      if (isHeicName(meta.name)) {
        try {
          const resp = await fetch(data.signedUrl);
          const blob = await resp.blob();
          const heic2any = (await import("heic2any")).default;
          const converted = await heic2any({ blob, toType: "image/jpeg", quality: 0.8 });
          const outBlob = Array.isArray(converted) ? converted[0] : converted;
          objectUrl = URL.createObjectURL(outBlob as Blob);
          if (!cancelled) setUrl(objectUrl);
        } catch {
          if (!cancelled) setFailed(true);
        }
      } else {
        if (!cancelled) setUrl(data.signedUrl);
      }
    })();
    return () => {
      cancelled = true;
      if (objectUrl) URL.revokeObjectURL(objectUrl);
    };
  }, [file_url]);
  return (
    <button
      type="button"
      onClick={(e) => { e.stopPropagation(); onPreview(); }}
      className="rounded-lg overflow-hidden border border-border bg-secondary hover:ring-2 hover:ring-primary/60 transition-all inline-block align-middle cursor-pointer"
      style={{ width: size, height: size }}
      aria-label="View image"
    >
      {url ? (
        <img
          src={url}
          alt="Candidate file preview thumbnail"
          className="w-full h-full object-cover"
          onError={() => setFailed(true)}
        />
      ) : failed ? (
        <div className="w-full h-full flex items-center justify-center text-muted-foreground text-[10px]">img</div>
      ) : (
        <div className="w-full h-full flex items-center justify-center text-muted-foreground text-[10px]">…</div>
      )}
    </button>
  );
};

const FilePreviewDialog = ({ file_url, onClose }: { file_url: string | null; onClose: () => void }) => {
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const [remoteUrl, setRemoteUrl] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const meta = file_url ? parseFilePath(file_url) : null;

  useEffect(() => {
    if (!file_url || !meta) { setPreviewUrl(null); return; }
    let cancelled = false;
    let objectUrl: string | null = null;
    setLoading(true);
    setPreviewUrl(null);
    setRemoteUrl(null);
    supabase.storage.from(meta.bucket).createSignedUrl(meta.path, 600).then(async ({ data, error }) => {
      if (error || !data?.signedUrl) {
        if (!cancelled) {
          toast.error("Could not load file");
          setLoading(false);
        }
        return;
      }
      try {
        if (isOfficeName(meta.name)) {
          if (!cancelled) setRemoteUrl(data.signedUrl);
          return;
        }
        const resp = await fetch(data.signedUrl);
        if (!resp.ok) throw new Error("Preview fetch failed");
        let blob = await resp.blob();
        let outType = mimeFromName(meta.name);
        if (isHeicName(meta.name)) {
          const heic2any = (await import("heic2any")).default;
          const converted = await heic2any({ blob, toType: "image/jpeg", quality: 0.9 });
          blob = (Array.isArray(converted) ? converted[0] : converted) as Blob;
          outType = "image/jpeg";
        }
        const typedBlob = new Blob([blob], { type: outType });
        objectUrl = URL.createObjectURL(typedBlob);
        if (!cancelled) setPreviewUrl(objectUrl);
      } catch {
        if (!cancelled) {
          toast.error("Could not load file");
        }
      } finally {
        if (!cancelled) setLoading(false);
      }
    });
    return () => {
      cancelled = true;
      if (objectUrl) URL.revokeObjectURL(objectUrl);
    };
  }, [file_url]);

  useEffect(() => {
    return () => {
      if (previewUrl) URL.revokeObjectURL(previewUrl);
    };
  }, [previewUrl]);

  const isImg = meta && isImageName(meta.name);
  const isPdf = meta && isPdfName(meta.name);
  const isOffice = meta && isOfficeName(meta.name);

  return (
    <Dialog open={!!file_url} onOpenChange={(o) => !o && onClose()}>
      <DialogContent showClose={false} className="max-w-5xl w-[95vw] h-[90vh] p-0 flex flex-col gap-0">
        <button
          type="button"
          onClick={onClose}
          aria-label="Close preview"
          className="absolute top-3 right-3 z-[999] flex items-center justify-center min-w-[44px] min-h-[44px] rounded-full text-white bg-black/50 hover:bg-black/75 transition-colors"
        >
          <X className="h-5 w-5" />
        </button>
        <div className="flex items-center justify-between gap-3 px-4 py-3 border-b border-border">
          <div className="text-sm font-medium truncate flex-1" title={meta?.name}>{meta?.name}</div>
          <Button
            size="sm"
            onClick={() => file_url && downloadFile(file_url)}
            className="shrink-0 mr-12"
          >
            <Download className="h-4 w-4 mr-1.5" /> Download
          </Button>
        </div>
        <div className="flex-1 min-h-0 bg-muted/30 overflow-auto flex items-center justify-center">
          {loading || (!previewUrl && !remoteUrl) ? (
            <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
          ) : isImg ? (
            <img src={previewUrl} alt={meta?.name} className="max-w-full max-h-full object-contain" />
          ) : isPdf ? (
            <iframe src={previewUrl} title={meta?.name} className="w-full h-full border-0" />
          ) : isOffice && remoteUrl ? (
            <iframe
              src={`https://view.officeapps.live.com/op/embed.aspx?src=${encodeURIComponent(remoteUrl)}`}
              title={meta?.name}
              className="w-full h-full border-0"
              onError={() => toast.error("Preview unavailable. Please download the file.")}
            />
          ) : (
            <div className="text-center p-8 space-y-3">
              <FileIcon className="h-12 w-12 mx-auto text-muted-foreground" />
              <div className="text-sm text-muted-foreground">Preview not available for this file type.</div>
              <Button onClick={() => file_url && downloadFile(file_url)}>
                <Download className="h-4 w-4 mr-1.5" /> Download
              </Button>
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
};


const countryFlagEmoji = (country?: string): string => {
  if (!country || country.length !== 2) return "";
  return country
    .toUpperCase()
    .replace(/./g, (char) => String.fromCodePoint(127397 + char.charCodeAt(0)));
};

const renderCellText = (q: Q, ans: Answer | undefined): string => {
  if (!ans) return "";
  const text = ans.answer_text;
  if (text === null || text === "") return "";
  switch (q.type) {
    case "multiple_choice":
      try {
        const arr = JSON.parse(text);
        return Array.isArray(arr) ? arr.join(", ") : text;
      } catch {
        return text;
      }
    case "rating":
      return `${text}/5`;
    case "legal_checkbox":
      return text === "accepted" ? "✓" : text;
    case "phone":
      try {
        const pn = parsePhoneNumberFromString(text);
        if (pn) return `${countryFlagEmoji(pn.country)} ${pn.formatInternational()}`.trim();
      } catch {}
      return text;
    default:
      return text;
  }
};

const csvCellValue = (q: Q, ans: Answer | undefined): string => {
  if (!ans) return "";
  if (q.type === "file_upload") return ""; // resolved later async
  const text = ans.answer_text;
  if (text === null || text === "") return "";
  switch (q.type) {
    case "yes_no":
      return text === "yes" ? "Yes" : text === "no" ? "No" : text;
    case "multiple_choice":
      try {
        const arr = JSON.parse(text);
        return Array.isArray(arr) ? arr.join(", ") : text;
      } catch { return text; }
    case "legal_checkbox":
      return text === "accepted" ? "Yes" : "No";
    default:
      return text;
  }
};

const truncate = (s: string, n = 50) => (s.length > n ? s.slice(0, n) + "..." : s);

const statusLabel = (status?: string | null) => {
  if (status === "in_progress") return "In Progress";
  if (status === "abandoned") return "Abandoned";
  return "Completed";
};

const relativeActivity = (iso?: string | null) => {
  if (!iso) return "No activity yet";
  const mins = Math.max(0, Math.floor((Date.now() - new Date(iso).getTime()) / 60000));
  if (mins < 1) return "Just now";
  if (mins < 60) return `${mins} min ago`;
  const hrs = Math.floor(mins / 60);
  if (hrs < 24) return `${hrs} hr${hrs === 1 ? "" : "s"} ago`;
  const days = Math.floor(hrs / 24);
  return `${days} day${days === 1 ? "" : "s"} ago`;
};

const ResponseStatusBadge = ({ status }: { status?: string | null }) => (
  <span className={cn(
    "inline-flex items-center rounded-md border px-2 py-0.5 text-[11px] font-semibold uppercase tracking-wide",
    status === "in_progress" && "border-gold bg-accent-soft text-navy",
    status === "abandoned" && "border-border bg-secondary text-muted-foreground",
    (!status || status === "completed") && "border-primary/30 bg-primary/5 text-primary",
  )}>
    {statusLabel(status)}
  </span>
);

// Current pipeline-stage pill (separate from the form-status badge). Data-backed only.
const PipelineStatusPill = ({ stage }: { stage: ReturnType<typeof computePipelineStage> }) => {
  if (!stage) return null;
  return (
    <span
      className="inline-flex items-center rounded-full px-2 py-0.5 text-[11px] font-semibold text-white whitespace-nowrap leading-none"
      style={{ backgroundColor: stage.color }}
    >
      {stage.label}
    </span>
  );
};

type SortState = { col: string; dir: "asc" | "desc" } | null;

type Filters = {
  status: "all" | "completed" | "in_progress" | "abandoned";
  date: "all" | "today" | "7d" | "30d" | "custom";
  from?: Date;
  to?: Date;
  showRead: boolean;
  showUnread: boolean;
  perQuestion: Record<string, string[]>; // question id -> selected values
};

const defaultFilters: Filters = {
  status: "all",
  date: "all",
  showRead: true,
  showUnread: true,
  perQuestion: {},
};

const Results = () => {
  const { id } = useParams<{ id: string }>();
  if (!id) return <Navigate to="/dashboard" replace />;
  const { form, refresh } = useFormHeader(id);
  const [searchParams, setSearchParams] = useSearchParams();
  useEffect(() => {
    document.title = "EIA Talent Recruiting System — Results";
  }, []);
  const [questions, setQuestions] = useState<Q[]>([]);
  const [responses, setResponses] = useState<Response[]>([]);
  const [answers, setAnswers] = useState<Answer[]>([]);
  const [activeResp, setActiveResp] = useState<Response | null>(null);
  const [deleteOpen, setDeleteOpen] = useState(false);
  const [bulkDeleteOpen, setBulkDeleteOpen] = useState(false);
  const [bulkDeleteInput, setBulkDeleteInput] = useState("");
  const [loading, setLoading] = useState(true);
  const [previewFile, setPreviewFile] = useState<string | null>(null);
  const [actionsByResp, setActionsByResp] = useState<Record<string, CandidateAction>>({});
  const [signedPdfByOffer, setSignedPdfByOffer] = useState<Record<string, string>>({});

  // Search
  const [searchInput, setSearchInput] = useState("");
  const [search, setSearch] = useState("");
  useEffect(() => {
    const t = setTimeout(() => setSearch(searchInput.trim().toLowerCase()), 300);
    return () => clearTimeout(t);
  }, [searchInput]);

  // Filters
  const [filters, setFilters] = useState<Filters>(defaultFilters);
  const [draftFilters, setDraftFilters] = useState<Filters>(defaultFilters);
  const [filterOpen, setFilterOpen] = useState(false);

  // Sort
  const [sort, setSort] = useState<SortState>(null);

  // Selection
  const [selected, setSelected] = useState<Set<string>>(new Set());
  // True only when the current selection came from the "Select No-Name/No-Email"
  // shortcut — this is the ONLY path allowed to skip the "type DELETE" gate.
  const [junkDeleteMode, setJunkDeleteMode] = useState(false);
  // Per-row trash confirm
  const [rowDeleteTarget, setRowDeleteTarget] = useState<Response | null>(null);
  const [rowDeleteBusy, setRowDeleteBusy] = useState(false);

  // Column visibility / order
  const [colVis, setColVis] = useState<Record<string, boolean>>({});
  const [colOrder, setColOrder] = useState<string[]>([]);
  const [colOpen, setColOpen] = useState(false);

  // Export
  const [exporting, setExporting] = useState(false);
  const [bulkBusy, setBulkBusy] = useState(false);

  const load = async () => {
    if (!id) return;
    setLoading(true);
    const [{ data: qs }, { data: rs }] = await Promise.all([
      supabase
        .from("questions")
        .select("id, type, label, order_index, options")
        .eq("form_id", id)
        .order("order_index", { ascending: true }),
      supabase
        .from("responses")
        .select("id, submitted_at, viewed_at, applicant_id, status, last_activity_at, current_question_index, session_token, override_email, override_name, round_stage, disqualified_at_stage, appointment_cancelled")
        .eq("form_id", id)
        .order("submitted_at", { ascending: false }),
    ]);
    const filteredQs = (qs || []).filter((q: any) => q.type !== "welcome" && q.type !== "thank_you");
    setQuestions(filteredQs);
    setResponses(rs || []);
    if (rs && rs.length) {
      const [{ data: ans }, actions] = await Promise.all([
        supabase
          .from("answers")
          .select("response_id, question_id, answer_text, file_url")
          .in("response_id", rs.map((r) => r.id)),
        fetchCandidateActionsForForm(id),
      ]);
      setAnswers(ans || []);
      setActionsByResp(actions);
      const offerIds = Object.values(actions)
        .filter((a) => a.offer_status === "signed" && a.job_offer_id)
        .map((a) => a.job_offer_id!) as string[];
      if (offerIds.length) {
        const { data: offers } = await supabase
          .from("job_offers")
          .select("id, signed_pdf_url")
          .in("id", offerIds);
        const map: Record<string, string> = {};
        for (const o of (offers || []) as any[]) {
          if (o.signed_pdf_url) map[o.id] = o.signed_pdf_url;
        }
        setSignedPdfByOffer(map);
      } else {
        setSignedPdfByOffer({});
      }
    } else {
      setAnswers([]);
      setActionsByResp({});
      setSignedPdfByOffer({});
    }
    setLoading(false);
  };

  useEffect(() => { load(); }, [id]);

  // Realtime: subscribe to candidate_actions updates for this form
  useEffect(() => {
    if (!id) return;
    const channel = supabase
      .channel(`candidate_actions:${id}`)
      .on(
        "postgres_changes",
        { event: "UPDATE", schema: "public", table: "candidate_actions", filter: `form_id=eq.${id}` },
        (payload) => {
          const next = payload.new as CandidateAction;
          const prev = payload.old as Partial<CandidateAction> | undefined;
          if (!next?.response_id) return;
          setActionsByResp((curr) => ({ ...curr, [next.response_id!]: next }));
          if (next.offer_status === "signed" && prev?.offer_status !== "signed") {
            if (next.job_offer_id) {
              supabase
                .from("job_offers")
                .select("signed_pdf_url")
                .eq("id", next.job_offer_id)
                .maybeSingle()
                .then(({ data }) => {
                  const url = (data as any)?.signed_pdf_url;
                  if (url) {
                    setSignedPdfByOffer((m) => ({ ...m, [next.job_offer_id!]: url }));
                  }
                });
            }
            toast.success("🎉 A candidate just signed their offer!", {
              duration: 5000,
              action: {
                label: "View",
                onClick: () => {
                  const el = document.querySelector(`[data-response-id="${next.response_id}"]`);
                  el?.scrollIntoView({ behavior: "smooth", block: "center" });
                },
              },
            });
          }
        },
      )
      .subscribe();
    return () => { supabase.removeChannel(channel); };
  }, [id]);

  // Realtime: subscribe to responses INSERT/UPDATE for this form (live list refresh)
  useEffect(() => {
    if (!id) return;
    const channel = supabase
      .channel(`responses:${id}`)
      .on(
        "postgres_changes",
        { event: "UPDATE", schema: "public", table: "responses", filter: `form_id=eq.${id}` },
        (payload) => {
          const next = payload.new as Response;
          if (!next?.id) return;
          // In-place patch: replace the matching row so existing memos recompute.
          setResponses((prev) =>
            prev.map((x) => (x.id === next.id ? { ...x, ...next } : x)),
          );
        },
      )
      .on(
        "postgres_changes",
        { event: "INSERT", schema: "public", table: "responses", filter: `form_id=eq.${id}` },
        (payload) => {
          const row = payload.new as Response;
          if (!row?.id) return;
          // Insert in submitted_at order (newest first), guarding against duplicates.
          setResponses((prev) => {
            if (prev.some((x) => x.id === row.id)) return prev;
            const merged = [row, ...prev];
            merged.sort(
              (a, b) =>
                new Date(b.submitted_at).getTime() - new Date(a.submitted_at).getTime(),
            );
            return merged;
          });
          // Targeted sub-fetch: just this candidate's answers + actions so cells/buttons render.
          (async () => {
            const [{ data: ans }, actions] = await Promise.all([
              supabase
                .from("answers")
                .select("response_id, question_id, answer_text, file_url")
                .eq("response_id", row.id),
              fetchCandidateActionsForForm(id),
            ]);
            if (ans && ans.length) {
              setAnswers((prev) => {
                const without = prev.filter((a) => a.response_id !== row.id);
                return [...without, ...ans];
              });
            }
            setActionsByResp((curr) => ({ ...curr, ...actions }));
          })();
        },
      )
      .subscribe();
    return () => { supabase.removeChannel(channel); };
  }, [id]);



  // Load column prefs
  useEffect(() => {
    if (!id || !questions.length) return;
    const key = `column-prefs-${id}`;
    let saved: any = null;
    try { saved = JSON.parse(localStorage.getItem(key) || "null"); } catch {}
    const allIds = ["__submitted", ...questions.map((q) => q.id)];
    if (saved && saved.order && saved.vis) {
      const order = [...saved.order.filter((c: string) => allIds.includes(c)), ...allIds.filter((c) => !saved.order.includes(c))];
      const vis: Record<string, boolean> = { __submitted: true };
      allIds.forEach((c) => { vis[c] = c === "__submitted" ? true : (saved.vis[c] ?? true); });
      setColOrder(order);
      setColVis(vis);
    } else {
      const vis: Record<string, boolean> = {};
      allIds.forEach((c) => { vis[c] = true; });
      setColOrder(allIds);
      setColVis(vis);
    }
  }, [id, questions]);

  // Persist
  useEffect(() => {
    if (!id || !colOrder.length) return;
    localStorage.setItem(`column-prefs-${id}`, JSON.stringify({ order: colOrder, vis: colVis }));
  }, [id, colVis, colOrder]);

  const answerFor = (rid: string, qid: string) =>
    answers.find((a) => a.response_id === rid && a.question_id === qid);

  // Auto-open candidate sheet when ?candidate=<id> is in URL
  useEffect(() => {
    const candidateId = searchParams.get("candidate");
    if (!candidateId || loading) return;
    const target = responses.find((r) => r.id === candidateId);
    if (target) {
      setActiveResp(target);
      setTimeout(() => {
        const el = document.querySelector(`[data-response-id="${candidateId}"]`);
        el?.scrollIntoView({ behavior: "smooth", block: "center" });
      }, 100);
      searchParams.delete("candidate");
      setSearchParams(searchParams, { replace: true });
    }
  }, [loading, responses, searchParams, setSearchParams]);

  // Filtering
  const filteredResponses = useMemo(() => {
    let rs = responses;
    if (filters.status !== "all") {
      rs = rs.filter((r) => (r.status || "completed") === filters.status);
    }
    // read/unread
    rs = rs.filter((r) => {
      const isRead = !!r.viewed_at;
      if (isRead && !filters.showRead) return false;
      if (!isRead && !filters.showUnread) return false;
      return true;
    });
    // date
    if (filters.date !== "all") {
      const now = new Date();
      let from: Date | null = null;
      let to: Date | null = null;
      if (filters.date === "today") {
        from = new Date(now.getFullYear(), now.getMonth(), now.getDate());
      } else if (filters.date === "7d") {
        from = new Date(now.getTime() - 7 * 86400000);
      } else if (filters.date === "30d") {
        from = new Date(now.getTime() - 30 * 86400000);
      } else if (filters.date === "custom") {
        from = filters.from || null;
        to = filters.to || null;
      }
      rs = rs.filter((r) => {
        const d = new Date(r.submitted_at);
        if (from && d < from) return false;
        if (to && d > new Date(to.getTime() + 86400000)) return false;
        return true;
      });
    }
    // per-question filters
    const pqEntries = Object.entries(filters.perQuestion).filter(([, v]) => v && v.length);
    if (pqEntries.length) {
      rs = rs.filter((r) => {
        return pqEntries.every(([qid, selVals]) => {
          const ans = answerFor(r.id, qid);
          if (!ans?.answer_text) return false;
          const q = questions.find((x) => x.id === qid);
          if (!q) return false;
          if (q.type === "multiple_choice") {
            let arr: string[] = [];
            try { const p = JSON.parse(ans.answer_text); arr = Array.isArray(p) ? p : [p]; } catch { arr = [ans.answer_text]; }
            return arr.some((v) => selVals.includes(v));
          }
          if (q.type === "yes_no") {
            return selVals.includes(ans.answer_text);
          }
          if (q.type === "rating") {
            return selVals.includes(String(ans.answer_text));
          }
          return selVals.includes(ans.answer_text);
        });
      });
    }
    // search
    if (search) {
      const responseIds = new Set(rs.map((r) => r.id));
      const matches = new Set<string>();
      for (const a of answers) {
        if (!responseIds.has(a.response_id)) continue;
        if (a.answer_text && a.answer_text.toLowerCase().includes(search)) {
          matches.add(a.response_id);
        }
      }
      rs = rs.filter((r) => matches.has(r.id));
    }
    return rs;
  }, [responses, filters, search, answers, questions]);

  // Sorting
  const sortedResponses = useMemo(() => {
    if (!sort) return filteredResponses;
    const { col, dir } = sort;
    const factor = dir === "asc" ? 1 : -1;
    const arr = [...filteredResponses];
    arr.sort((a, b) => {
      const getVal = (r: Response): { empty: boolean; v: any } => {
        if (col === "__submitted") return { empty: false, v: new Date(r.submitted_at).getTime() };
        const ans = answerFor(r.id, col);
        const t = ans?.answer_text;
        if (t === null || t === undefined || t === "") return { empty: true, v: "" };
        const q = questions.find((x) => x.id === col);
        if (q?.type === "rating") return { empty: false, v: Number(t) || 0 };
        if (q?.type === "date") {
          const d = new Date(t).getTime();
          return { empty: false, v: isNaN(d) ? t.toLowerCase() : d };
        }
        return { empty: false, v: String(renderCellText(q!, ans)).toLowerCase() };
      };
      const va = getVal(a);
      const vb = getVal(b);
      if (va.empty && vb.empty) return 0;
      if (va.empty) return 1;
      if (vb.empty) return -1;
      if (va.v < vb.v) return -1 * factor;
      if (va.v > vb.v) return 1 * factor;
      return 0;
    });
    return arr;
  }, [filteredResponses, sort, answers, questions]);

  const toggleSort = (col: string) => {
    setSort((s) => {
      if (!s || s.col !== col) return { col, dir: "asc" };
      if (s.dir === "asc") return { col, dir: "desc" };
      return null;
    });
  };

  const sortIcon = (col: string) => {
    if (!sort || sort.col !== col) return <ArrowUpDown className="h-3 w-3 opacity-30 inline ml-1" />;
    return sort.dir === "asc" ? <ArrowUp className="h-3 w-3 inline ml-1" /> : <ArrowDown className="h-3 w-3 inline ml-1" />;
  };

  // Selection helpers
  const allSelected = sortedResponses.length > 0 && sortedResponses.every((r) => selected.has(r.id));
  const someSelected = sortedResponses.some((r) => selected.has(r.id)) && !allSelected;

  const toggleSelectAll = () => {
    // Manual selection change — never keep the no-typing junk bypass.
    setJunkDeleteMode(false);
    setSelected((prev) => {
      const next = new Set(prev);
      if (allSelected) {
        sortedResponses.forEach((r) => next.delete(r.id));
      } else {
        sortedResponses.forEach((r) => next.add(r.id));
      }
      return next;
    });
  };

  const toggleSelect = (rid: string) => {
    // Manual selection change — never keep the no-typing junk bypass.
    setJunkDeleteMode(false);
    setSelected((prev) => {
      const next = new Set(prev);
      if (next.has(rid)) next.delete(rid);
      else next.add(rid);
      return next;
    });
  };

  // Junk = no name (override_name or answer name) AND no email (override or answer).
  const junkIds = useMemo(
    () =>
      sortedResponses
        .filter((r) => {
          const info = extractCandidateInfo(questions, answers, r.id, r.override_email);
          return !((r.override_name?.trim()) || info.name) && !info.email;
        })
        .map((r) => r.id),
    [sortedResponses, questions, answers],
  );
  const junkCount = junkIds.length;

  const selectJunk = () => {
    setSelected(new Set(junkIds));
    setJunkDeleteMode(true);
  };

  const detailAnswers = activeResp
    ? questions.map((q) => ({ q, ans: answerFor(activeResp.id, q.id) }))
    : [];

  const copyShareLink = () => {
    if (!form) return;
    const url = `${window.location.origin}/form/${form.slug}`;
    navigator.clipboard.writeText(url);
    toast.success("Link copied");
  };

  const handleDelete = async () => {
    if (!activeResp) return;
    const deletedId = activeResp.id;
    const { data, error } = await supabase.functions.invoke("purge-candidate-completely", {
      body: { response_id: deletedId },
    });
    const errMsg = error?.message || (data as any)?.failures?.[0]?.error;
    if (errMsg || (data as any)?.ok === false) {
      // Restore from server only on failure (matches My Bookings).
      load();
      return toast.error(errMsg || "Delete failed");
    }
    toast.success("Candidate permanently purged");
    setDeleteOpen(false);
    setActiveResp(null);
    // Optimistic in-place removal — no full re-fetch on success.
    setResponses((prev) => prev.filter((x) => x.id !== deletedId));
    setSelected((prev) => { const n = new Set(prev); n.delete(deletedId); return n; });
  };

  // Bulk actions
  const selectedIds = useMemo(() => Array.from(selected), [selected]);
  const selectedCount = selectedIds.length;

  const handleBulkMarkRead = async () => {
    setBulkBusy(true);
    const { error } = await supabase.from("responses").update({ viewed_at: new Date().toISOString() }).in("id", selectedIds).is("viewed_at", null);
    setBulkBusy(false);
    if (error) return toast.error(error.message);
    toast.success(`Marked ${selectedCount} as read`);
    load();
  };
  const handleBulkMarkUnread = async () => {
    setBulkBusy(true);
    const { error } = await supabase.from("responses").update({ viewed_at: null }).in("id", selectedIds);
    setBulkBusy(false);
    if (error) return toast.error(error.message);
    toast.success(`Marked ${selectedCount} as unread`);
    load();
  };
  const handleBulkDelete = async () => {
    const idsToDelete = selectedIds;
    setBulkBusy(true);
    const { data, error } = await supabase.functions.invoke("purge-candidate-completely", {
      body: { response_ids: idsToDelete },
    });
    setBulkBusy(false);
    setBulkDeleteOpen(false);
    setBulkDeleteInput("");
    const errMsg = error?.message;
    if (errMsg) {
      // Restore from server only on failure.
      load();
      return toast.error(errMsg);
    }
    const deleted = (data as any)?.deleted ?? 0;
    const failed = ((data as any)?.failures || []).length;
    if (failed > 0) {
      toast.error(`Purged ${deleted}, ${failed} failed`);
      // Partial failure — re-fetch to reflect true server state.
      setSelected(new Set());
      load();
      return;
    }
    toast.success(`Permanently purged ${deleted} candidate${deleted === 1 ? "" : "s"}`);
    // Optimistic in-place removal — no full re-fetch on full success.
    setResponses((prev) => prev.filter((x) => !idsToDelete.includes(x.id)));
    setSelected(new Set());
  };

  // Per-row single purge — mirrors handleDelete: same edge function, optimistic removal, no reload.
  const handleRowDelete = async () => {
    if (!rowDeleteTarget) return;
    const deletedId = rowDeleteTarget.id;
    setRowDeleteBusy(true);
    const { data, error } = await supabase.functions.invoke("purge-candidate-completely", {
      body: { response_id: deletedId },
    });
    setRowDeleteBusy(false);
    const errMsg = error?.message || (data as any)?.failures?.[0]?.error;
    if (errMsg || (data as any)?.ok === false) {
      load();
      return toast.error(errMsg || "Delete failed");
    }
    toast.success("Candidate permanently purged");
    setRowDeleteTarget(null);
    setResponses((prev) => prev.filter((x) => x.id !== deletedId));
    setSelected((prev) => { const n = new Set(prev); n.delete(deletedId); return n; });
  };

  const anySelectedUnread = selectedIds.some((id) => {
    const r = responses.find((x) => x.id === id);
    return r && !r.viewed_at;
  });

  // Active filter summary
  const activeFilterChips = useMemo(() => {
    const chips: { key: string; label: string; remove: () => void }[] = [];
    if (filters.date !== "all") {
      const map: any = { today: "Today", "7d": "Last 7 days", "30d": "Last 30 days", custom: "Custom range" };
      chips.push({ key: "date", label: map[filters.date], remove: () => setFilters({ ...filters, date: "all", from: undefined, to: undefined }) });
    }
    if (!filters.showRead) chips.push({ key: "hide-read", label: "Hide read", remove: () => setFilters({ ...filters, showRead: true }) });
    if (!filters.showUnread) chips.push({ key: "hide-unread", label: "Hide unread", remove: () => setFilters({ ...filters, showUnread: true }) });
    Object.entries(filters.perQuestion).forEach(([qid, vals]) => {
      if (!vals?.length) return;
      const q = questions.find((x) => x.id === qid);
      if (!q) return;
      vals.forEach((v) => {
        chips.push({
          key: `${qid}:${v}`,
          label: `${truncate(q.label, 20)}: ${v}`,
          remove: () => {
            const next = { ...filters.perQuestion };
            next[qid] = (next[qid] || []).filter((x) => x !== v);
            if (!next[qid].length) delete next[qid];
            setFilters({ ...filters, perQuestion: next });
          },
        });
      });
    });
    return chips;
  }, [filters, questions]);

  const filterCount = activeFilterChips.length;

  const clearAllFilters = () => {
    setFilters(defaultFilters);
    setDraftFilters(defaultFilters);
  };

  // CSV export
  const handleExport = async () => {
    if (exporting) return;
    setExporting(true);
    try {
      const visibleQuestionIds = colOrder.filter((c) => c !== "__submitted" && colVis[c]);
      const visibleQuestions = visibleQuestionIds
        .map((qid) => questions.find((q) => q.id === qid))
        .filter(Boolean) as Q[];

      // Pre-resolve signed URLs for file_upload answers in filtered set
      const fileSignedUrls = new Map<string, string>();
      const fileTasks: Promise<void>[] = [];
      for (const r of sortedResponses) {
        for (const q of visibleQuestions) {
          if (q.type !== "file_upload") continue;
          const a = answerFor(r.id, q.id);
          if (!a?.file_url) continue;
          const key = a.file_url;
          if (fileSignedUrls.has(key)) continue;
          fileSignedUrls.set(key, "");
          const { bucket, path } = parseFilePath(key);
          fileTasks.push(
            supabase.storage.from(bucket).createSignedUrl(path, 60 * 60 * 24 * 7).then(({ data }) => {
              if (data?.signedUrl) fileSignedUrls.set(key, data.signedUrl);
            })
          );
        }
      }
      await Promise.all(fileTasks);

      const includeSubmitted = colVis["__submitted"] !== false;
      const headers: string[] = [];
      if (includeSubmitted) headers.push("Submitted");
      headers.push("Read");
      visibleQuestions.forEach((q) => headers.push(q.label));

      const rows = sortedResponses.map((r) => {
        const row: string[] = [];
        if (includeSubmitted) row.push(fmtDate(r.submitted_at));
        row.push(r.viewed_at ? "Yes" : "No");
        visibleQuestions.forEach((q) => {
          if (q.type === "file_upload") {
            const a = answerFor(r.id, q.id);
            row.push(a?.file_url ? (fileSignedUrls.get(a.file_url) || "") : "");
          } else {
            row.push(csvCellValue(q, answerFor(r.id, q.id)));
          }
        });
        return row;
      });

      const csv = Papa.unparse({ fields: headers, data: rows });
      const blob = new Blob(["\uFEFF" + csv], { type: "text/csv;charset=utf-8;" });
      const url = URL.createObjectURL(blob);
      const date = fmtFn(new Date(), "yyyyMMdd");
      const filename = `${form?.slug || "form"}-responses-${date}.csv`;
      const a = document.createElement("a");
      a.href = url;
      a.download = filename;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      setTimeout(() => URL.revokeObjectURL(url), 1000);
      toast.success("CSV downloaded");
    } catch (e: any) {
      toast.error("Export failed");
    } finally {
      setExporting(false);
    }
  };

  // Reset columns
  const resetColumns = () => {
    const allIds = ["__submitted", ...questions.map((q) => q.id)];
    const vis: Record<string, boolean> = {};
    allIds.forEach((c) => { vis[c] = true; });
    setColOrder(allIds);
    setColVis(vis);
  };

  if (!form) {
    return <div className="min-h-screen flex items-center justify-center" aria-busy="true"><Loader2 className="h-6 w-6 text-muted-foreground animate-spin" /></div>;
  }

  const totalCount = responses.length;
  const filteredCount = sortedResponses.length;
  const showFilteredCount = filteredCount !== totalCount;

  // Visible columns for table
  const visibleCols = colOrder.filter((c) => colVis[c]);
  const visibleQuestionsForTable = (visibleCols
    .filter((c) => c !== "__submitted")
    .map((qid) => questions.find((q) => q.id === qid))
    .filter(Boolean) as Q[])
    .slice()
    .sort((a, b) => {
      // Default display order: name, email, photo, resume, DOB, others,
      // onlinejobs link last. Pure visual reorder — doesn't change DB or
      // saved column order.
      const PHOTO_RE = /(photo|selfie|picture|headshot|portrait|image)/i;
      const RESUME_RE = /(resume|cv|curriculum)/i;
      const NAME_RE = /name/i;
      const DOB_RE = /(date\s*of\s*birth|birth\s*date|birthday|\bd\.?o\.?b\.?\b)/i;
      const OJ_RE = /(onlinejob|online\s*jobs?|oj\s*profile|onlinejobs\.ph)/i;
      const rank = (q: Q) => {
        if (OJ_RE.test(q.label || "")) return 90;
        if (DOB_RE.test(q.label || "")) return 4;
        if (q.type === "short_text" && NAME_RE.test(q.label || "")) return 0;
        if (q.type === "email") return 1;
        if (q.type === "selfie" || (q.type === "file_upload" && PHOTO_RE.test(q.label || ""))) return 2;
        if (q.type === "file_upload" && RESUME_RE.test(q.label || "")) return 3;
        return 10;
      };
      const ra = rank(a), rb = rank(b);
      if (ra !== rb) return ra - rb;
      return 0;
    });

  // The detected email question for this form (label-aware). Used to swap in
  // responses.override_email at the cell level so the corrected email shows in
  // the Email column everywhere this candidate appears.
  const emailQidForForm = detectContactQuestionIds(
    questions.map((q) => ({ id: q.id, type: q.type, label: q.label })),
  ).emailQid;
  const resolveEmailText = (q: Q, r: Response, ans: Answer | undefined): string | null => {
    if (q.id !== emailQidForForm) return null;
    const override = (r.override_email || "").trim();
    if (override) return override;
    return null;
  };
  const submittedVisible = colVis["__submitted"] !== false;

  return (
    <div className="min-h-screen flex flex-col bg-background">
      <FormTopBar form={form} onChange={refresh} active="results" />
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 md:px-6 py-8 md:py-12">
        <div className="flex items-baseline gap-3 mb-4">
          <h1 className="text-2xl font-bold">Responses</h1>
          <span className="text-sm text-muted-foreground">
            {showFilteredCount
              ? `Showing ${filteredCount} of ${totalCount} responses`
              : `${totalCount} ${totalCount === 1 ? "response" : "responses"}`}
          </span>
        </div>

        {/* Toolbar */}
        <div className="flex items-center gap-2 mb-3 flex-wrap">
          <div className="relative flex-1 max-w-md min-w-[220px]">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground pointer-events-none" />
            <Input
              value={searchInput}
              onChange={(e) => setSearchInput(e.target.value)}
              placeholder="Search responses..."
              className="pl-9 pr-9"
            />
            {searchInput && (
              <button
                onClick={() => setSearchInput("")}
                className="absolute right-2 top-1/2 -translate-y-1/2 h-6 w-6 inline-flex items-center justify-center rounded hover:bg-accent"
                aria-label="Clear search"
              >
                <X className="h-3.5 w-3.5" />
              </button>
            )}
          </div>

          <Select
            value={filters.status}
            onValueChange={(v) => setFilters({ ...filters, status: v as Filters["status"] })}
          >
            <SelectTrigger className="h-9 w-[150px]">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All statuses</SelectItem>
              <SelectItem value="completed">Completed</SelectItem>
              <SelectItem value="in_progress">In progress</SelectItem>
              <SelectItem value="abandoned">Abandoned</SelectItem>
            </SelectContent>
          </Select>

          <Popover open={filterOpen} onOpenChange={(o) => { setFilterOpen(o); if (o) setDraftFilters(filters); }}>

            <PopoverTrigger asChild>
              <Button variant="outline" size="sm">
                <SlidersHorizontal className="h-4 w-4 mr-2" />
                Filters{filterCount > 0 ? ` (${filterCount})` : ""}
              </Button>
            </PopoverTrigger>
            <PopoverContent align="start" className="w-[340px] max-h-[70vh] overflow-y-auto p-4">
              <FilterPanel
                draft={draftFilters}
                setDraft={setDraftFilters}
                questions={questions}
                onApply={() => { setFilters(draftFilters); setFilterOpen(false); }}
                onClear={() => { setDraftFilters(defaultFilters); setFilters(defaultFilters); setFilterOpen(false); }}
              />
            </PopoverContent>
          </Popover>

          <Popover open={colOpen} onOpenChange={setColOpen}>
            <PopoverTrigger asChild>
              <Button variant="outline" size="sm">
                <Columns3 className="h-4 w-4 mr-2" /> Columns
              </Button>
            </PopoverTrigger>
            <PopoverContent align="start" className="w-[300px] p-3">
              <div className="text-sm font-semibold mb-2">Column settings</div>
              <div className="space-y-1 max-h-[50vh] overflow-y-auto">
                {colOrder.map((cid) => {
                  const isSubmitted = cid === "__submitted";
                  const label = isSubmitted ? "Submitted" : questions.find((q) => q.id === cid)?.label || "(deleted)";
                  const visible = colVis[cid] !== false;
                  return (
                    <div key={cid} className="flex items-center gap-2 px-2 py-1.5 rounded hover:bg-accent">
                      <span className="flex-1 text-sm truncate" title={label}>{label}</span>
                      <button
                        type="button"
                        disabled={isSubmitted}
                        onClick={() => setColVis({ ...colVis, [cid]: !visible })}
                        className="h-7 w-7 inline-flex items-center justify-center rounded hover:bg-secondary disabled:opacity-30"
                        aria-label={visible ? "Hide column" : "Show column"}
                      >
                        {visible ? <Eye className="h-4 w-4" /> : <EyeOff className="h-4 w-4" />}
                      </button>
                    </div>
                  );
                })}
              </div>
              <button onClick={resetColumns} className="text-xs text-primary hover:underline mt-3">
                Reset to default
              </button>
            </PopoverContent>
          </Popover>

          <div className="flex-1" />

          <Button variant="outline" size="sm" onClick={handleExport} disabled={exporting || filteredCount === 0}>
            {exporting ? (<><Loader2 className="h-4 w-4 mr-2 animate-spin" /> Generating CSV...</>) : (<><Download className="h-4 w-4 mr-2" /> Export CSV</>)}
          </Button>
        </div>

        {/* Active filter chips */}
        {activeFilterChips.length > 0 && (
          <div className="flex flex-wrap gap-2 mb-3">
            {activeFilterChips.map((chip) => (
              <button
                key={chip.key}
                onClick={chip.remove}
                className="inline-flex items-center gap-1 px-2 py-1 text-xs rounded-md bg-secondary hover:bg-secondary/70"
              >
                {chip.label}
                <X className="h-3 w-3" />
              </button>
            ))}
            <button onClick={clearAllFilters} className="text-xs text-muted-foreground hover:text-foreground px-2 py-1">
              Clear all
            </button>
          </div>
        )}

        {/* Junk cleanup shortcut */}
        <div className="mb-3 flex items-center gap-2">
          <Button
            size="sm"
            variant="outline"
            onClick={selectJunk}
            disabled={junkCount === 0}
            className="gap-1.5"
          >
            <Trash2 className="h-4 w-4" />
            Select No-Name/No-Email ({junkCount})
          </Button>
        </div>

        {/* Bulk action toolbar */}
        {selectedCount > 0 && (
          <div className="sticky top-0 z-20 bg-background border border-border rounded-lg p-3 mb-3 flex items-center gap-3 shadow-sm">
            <span className="text-sm font-medium">{selectedCount} selected</span>
            <button onClick={() => { setSelected(new Set()); setJunkDeleteMode(false); }} className="text-xs text-muted-foreground hover:text-foreground">
              Clear selection
            </button>
            <div className="flex-1" />
            <Button size="sm" variant="outline" onClick={handleBulkMarkRead} disabled={bulkBusy || !anySelectedUnread}>
              {bulkBusy ? <Loader2 className="h-4 w-4 animate-spin" /> : "Mark as read"}
            </Button>
            <Button size="sm" variant="outline" onClick={handleBulkMarkUnread} disabled={bulkBusy}>
              {bulkBusy ? <Loader2 className="h-4 w-4 animate-spin" /> : "Mark as unread"}
            </Button>
            <Button size="sm" variant="destructive" onClick={() => setBulkDeleteOpen(true)} disabled={bulkBusy}>
              Delete
            </Button>
          </div>
        )}

        {loading ? (
          <div className="border border-border rounded-lg overflow-hidden" aria-busy="true">
            <div className="p-3 border-b border-border flex gap-3">
              <Skeleton className="h-4 w-4" />
              <Skeleton className="h-4 w-32" />
              <Skeleton className="h-4 w-40" />
              <Skeleton className="h-4 w-40" />
            </div>
            {[0, 1, 2, 3, 4].map((i) => (
              <div key={i} className="p-3 border-b border-border last:border-b-0 flex gap-3">
                <Skeleton className="h-4 w-4" />
                <Skeleton className="h-4 w-32" />
                <Skeleton className="h-4 w-40" />
                <Skeleton className="h-4 w-40" />
              </div>
            ))}
          </div>
        ) : totalCount === 0 ? (
          <div className="border border-dashed border-border rounded-xl p-12 text-center">
            <div className="mx-auto mb-4 h-14 w-14 rounded-full bg-secondary flex items-center justify-center">
              <Inbox className="h-6 w-6 text-muted-foreground" />
            </div>
            <h3 className="text-lg font-semibold mb-1">No responses yet</h3>
            <p className="text-sm text-muted-foreground mb-6">
              Share your form link to start collecting applications.
            </p>
            {form.status === "live" ? (
              <Button variant="outline" onClick={copyShareLink}>Copy share link</Button>
            ) : (
              <Button onClick={() => (window.location.href = `/forms/${form.id}/share`)}>Publish form</Button>
            )}
          </div>
        ) : filteredCount === 0 ? (
          <div className="border border-dashed border-border rounded-xl p-12 text-center">
            <div className="mx-auto mb-4 h-14 w-14 rounded-full bg-secondary flex items-center justify-center">
              <SearchX className="h-6 w-6 text-muted-foreground" />
            </div>
            <h3 className="text-lg font-semibold mb-1">No matching responses</h3>
            <p className="text-sm text-muted-foreground mb-6">
              Try a different search term or clear filters.
            </p>
            <Button variant="outline" size="sm" onClick={clearAllFilters}>Clear filters</Button>
          </div>
        ) : (
          <>
            {/* Mobile card list */}
            <div className="md:hidden space-y-3">
              {sortedResponses.map((r) => {
                const openDetail = async () => {
                  setActiveResp(r);
                  if (!r.viewed_at) {
                    await supabase.from("responses").update({ viewed_at: new Date().toISOString() }).eq("id", r.id).is("viewed_at", null);
                    setResponses((prev) => prev.map((x) => x.id === r.id ? { ...x, viewed_at: new Date().toISOString() } : x));
                  }
                };
                return (
                  <div
                    key={r.id}
                    className="relative w-full bg-card border border-hairline rounded-lg p-4 hover:border-navy/30 transition-colors"
                  >
                    <button
                      type="button"
                      onClick={(e) => { e.stopPropagation(); setRowDeleteTarget(r); }}
                      className="absolute top-2 left-2 z-10 p-1.5 rounded-md text-ink-muted hover:text-destructive hover:bg-destructive/10 transition-colors"
                      aria-label="Delete this candidate"
                      title="Delete this candidate"
                    >
                      <Trash2 className="h-4 w-4" />
                    </button>
                    <button onClick={openDetail} className="w-full text-left">
                      <div className="flex items-start justify-between mb-3 gap-3">
                        <div className="flex items-center gap-2 pl-8">
                          {!r.viewed_at && (
                            <span className="h-2 w-2 rounded-full bg-navy" aria-label="Unread" />
                          )}
                        </div>
                        <div className="text-right shrink-0">
                          <div className="text-sm font-semibold text-ink leading-tight">{fmtCompactDate(r.submitted_at)}</div>
                          <div className="text-xs text-ink-muted">{fmtCompactTime(r.submitted_at)}</div>
                          {(() => {
                            const a = actionsByResp[r.id];
                            const stage = computePipelineStage({
                              roundStage: r.round_stage,
                              disqualifiedAtStage: r.disqualified_at_stage,
                              round1Status: a?.round1_status,
                              round2Status: a?.round2_status,
                              offerStatus: a?.offer_status,
                            });
                            return stage ? <div className="mt-1 flex flex-col items-end gap-1"><PipelineStatusPill stage={stage} /><ScheduledSendChip responseId={r.id} /></div> : <div className="mt-1 flex justify-end"><ScheduledSendChip responseId={r.id} /></div>;
                          })()}
                        </div>
                      </div>
                      <div className="space-y-2">
                        {visibleQuestionsForTable.slice(0, 4).map((q) => {
                          const ans = answerFor(r.id, q.id);
                          if (q.type === "file_upload" || q.type === "selfie") {
                            const { name } = ans?.file_url ? parseFilePath(ans.file_url) : { name: "" };
                            const Icon = !name ? FileGeneric : isImageName(name) ? ImageIcon : isPdfName(name) ? FileText : FileGeneric;
                            const truncated = name.length > 18 ? name.slice(0, 18) + "..." : name;
                            return (
                              <div key={q.id} className="text-sm">
                                <div className="text-xs text-ink-muted truncate">{truncate(q.label, 40)}</div>
                                {ans?.file_url ? (
                                  <div className="flex items-center gap-1.5 mt-0.5">
                                    <Icon className="h-3.5 w-3.5 text-gold shrink-0" />
                                    <span className="font-medium text-ink truncate" title={name}>{truncated}</span>
                                  </div>
                                ) : (
                                  <div className="text-ink-muted">—</div>
                                )}
                              </div>
                            );
                          }
                          const val =
                            resolveEmailText(q, r, ans) ??
                            (String(renderCellText(q, ans) ?? "") || "—");
                          return (
                            <div key={q.id} className="text-sm">
                              <div className="text-xs text-ink-muted truncate">{truncate(q.label, 40)}</div>
                              <div className="font-medium text-ink truncate">{truncate(val, 60)}</div>
                            </div>
                          );
                        })}
                      </div>
                    </button>
                    <div className="mt-4 pt-3 border-t border-hairline" onClick={(e) => e.stopPropagation()}>
                      {(() => {
                        const { nameQid, emailQid } = detectContactQuestionIds(questions);
                        const info = extractCandidateInfo(questions, answers, r.id, r.override_email);
                        return (
                          <ActionsCell
                            formId={id}
                            responseId={r.id}
                            applicantId={r.applicant_id}
                            candidateName={info.name}
                            candidateEmail={info.email}
                            nameQid={nameQid}
                            emailQid={emailQid}
                            action={actionsByResp[r.id] || null}
                            signedPdfUrl={actionsByResp[r.id]?.job_offer_id ? signedPdfByOffer[actionsByResp[r.id].job_offer_id!] : undefined}
                            size="lg"
                            context="results"
                            roundStage={r.round_stage}
                            disqualifiedAtStage={r.disqualified_at_stage}
                            onChanged={(a) => setActionsByResp((m) => ({ ...m, [r.id]: a }))}
                            onContactUpdated={({ email }) => { if (email) setResponses((prev) => prev.map((x) => x.id === r.id ? { ...x, override_email: email } : x)); }}
                            onRound1Sent={() => setResponses((prev) => prev.map((x) => x.id === r.id ? { ...x, round_stage: "round_1_sent" } : x))}
                            onCandidateRemoved={() => {
                              setResponses((prev) => prev.filter((x) => x.id !== r.id));
                              setSelected((prev) => { const n = new Set(prev); n.delete(r.id); return n; });
                              setActiveResp((cur) => (cur?.id === r.id ? null : cur));
                            }}
                            onCandidateRestored={() => {
                              setResponses((prev) => prev.some((x) => x.id === r.id) ? prev : [r, ...prev]);
                            }}
                          />

                        );
                      })()}
                    </div>
                  </div>
                );
              })}
            </div>

            {/* Tablet+ table */}
            <div className="hidden md:block border border-hairline rounded-lg overflow-hidden bg-card">
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader className="sticky top-0 z-10">
                    <TableRow className="bg-soft-bg hover:bg-soft-bg border-b border-hairline">
                      <TableHead className="w-10 px-4 py-3">
                        <Checkbox
                          checked={allSelected ? true : someSelected ? "indeterminate" : false}
                          onCheckedChange={toggleSelectAll}
                          aria-label="Select all responses"
                        />
                      </TableHead>
                      {submittedVisible && (
                        <TableHead
                          className="whitespace-nowrap cursor-pointer select-none px-4 py-3 text-[11px] font-semibold uppercase tracking-[2px] text-navy w-[90px]"
                          onClick={() => toggleSort("__submitted")}
                        >
                          Submitted{sortIcon("__submitted")}
                        </TableHead>
                      )}
                      <TableHead className="px-4 py-3 text-[11px] font-semibold uppercase tracking-[2px] text-navy bg-action-tint w-[190px] text-center">
                        Actions
                      </TableHead>
                      {visibleQuestionsForTable.map((q) => {
                        const isFile = q.type === "file_upload" || q.type === "selfie";
                        return (
                          <TableHead
                            key={q.id}
                            className={`cursor-pointer select-none px-4 py-3 text-[11px] font-semibold uppercase tracking-[2px] text-navy ${
                              isFile ? "w-[140px] max-w-[140px]" : "w-[180px] max-w-[180px]"
                            }`}
                            onClick={() => toggleSort(q.id)}
                          >
                            <div className="flex items-center gap-1 min-w-0">
                              <span className="truncate block" title={q.label}>{truncate(q.label, 22)}</span>
                              {sortIcon(q.id)}
                            </div>
                          </TableHead>
                        );
                      })}
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {sortedResponses.map((r) => (
                      <TableRow
                        key={r.id}
                        onClick={async () => {
                          setActiveResp(r);
                          if (!r.viewed_at) {
                            await supabase.from("responses").update({ viewed_at: new Date().toISOString() }).eq("id", r.id).is("viewed_at", null);
                            setResponses((prev) => prev.map((x) => x.id === r.id ? { ...x, viewed_at: new Date().toISOString() } : x));
                          }
                        }}
                        className="cursor-pointer border-b border-hairline last:border-b-0 hover:bg-soft-bg/60 transition-colors"
                        data-state={selected.has(r.id) ? "selected" : undefined}
                      >
                        <TableCell onClick={(e) => e.stopPropagation()} className="relative px-4 py-3 align-middle">
                          {!r.viewed_at && (
                            <span className="absolute left-1 top-1/2 -translate-y-1/2 h-2 w-2 rounded-full bg-navy" aria-label="Unread" />
                          )}
                          <div className="flex items-center gap-1.5">
                            <Checkbox
                              checked={selected.has(r.id)}
                              onCheckedChange={() => toggleSelect(r.id)}
                              aria-label="Select response"
                            />
                            <button
                              type="button"
                              onClick={(e) => { e.stopPropagation(); setRowDeleteTarget(r); }}
                              className="p-1 rounded-md text-ink-muted hover:text-destructive hover:bg-destructive/10 transition-colors"
                              aria-label="Delete this candidate"
                              title="Delete this candidate"
                            >
                              <Trash2 className="h-3.5 w-3.5" />
                            </button>
                          </div>
                        </TableCell>
                        {submittedVisible && (
                          <TableCell className="whitespace-nowrap px-4 py-3 align-middle">
                            <div className="text-sm font-semibold text-ink leading-tight">{fmtCompactDate(r.submitted_at)}</div>
                            <div className="text-xs text-ink-muted">{fmtCompactTime(r.submitted_at)}</div>
                            <div className="mt-1"><ResponseStatusBadge status={r.status} /></div>
                            {(() => {
                              const a = actionsByResp[r.id];
                              const stage = computePipelineStage({
                                roundStage: r.round_stage,
                                disqualifiedAtStage: r.disqualified_at_stage,
                                round1Status: a?.round1_status,
                                round2Status: a?.round2_status,
                                offerStatus: a?.offer_status,
                              });
                              return stage ? <div className="mt-1 flex flex-col gap-1"><PipelineStatusPill stage={stage} /><ScheduledSendChip responseId={r.id} /></div> : <div className="mt-1"><ScheduledSendChip responseId={r.id} /></div>;
                            })()}
                          </TableCell>
                        )}
                        <TableCell
                          onClick={(e) => e.stopPropagation()}
                          className="px-3 py-3 align-middle bg-action-tint/60"
                        >
                          {(() => {
                            const { nameQid, emailQid } = detectContactQuestionIds(questions);
                            const info = extractCandidateInfo(questions, answers, r.id, r.override_email);
                            return (
                              <ActionsCell
                                formId={id}
                                responseId={r.id}
                                applicantId={r.applicant_id}
                                candidateName={info.name}
                                candidateEmail={info.email}
                                nameQid={nameQid}
                                emailQid={emailQid}
                                action={actionsByResp[r.id] || null}
                                signedPdfUrl={actionsByResp[r.id]?.job_offer_id ? signedPdfByOffer[actionsByResp[r.id].job_offer_id!] : undefined}
                                size="sm"
                                context="results"
                                roundStage={r.round_stage}
                                disqualifiedAtStage={r.disqualified_at_stage}
                                onChanged={(a) => setActionsByResp((m) => ({ ...m, [r.id]: a }))}
                                onContactUpdated={({ email }) => { if (email) setResponses((prev) => prev.map((x) => x.id === r.id ? { ...x, override_email: email } : x)); }}
                                onRound1Sent={() => setResponses((prev) => prev.map((x) => x.id === r.id ? { ...x, round_stage: "round_1_sent" } : x))}
                                onCandidateRemoved={() => {
                                  setResponses((prev) => prev.filter((x) => x.id !== r.id));
                                  setSelected((prev) => { const n = new Set(prev); n.delete(r.id); return n; });
                                  setActiveResp((cur) => (cur?.id === r.id ? null : cur));
                                }}
                                onCandidateRestored={() => {
                                  setResponses((prev) => prev.some((x) => x.id === r.id) ? prev : [r, ...prev]);
                                }}
                              />

                            );
                          })()}
                        </TableCell>
                        {visibleQuestionsForTable.map((q) => {
                          const ans = answerFor(r.id, q.id);
                          if (q.type === "selfie") {
                            return (
                              <TableCell key={q.id} className="text-sm px-4 py-3 align-middle">
                                {ans?.file_url ? (
                                  <SelfieThumb file_url={ans.file_url} size={120} onPreview={() => setPreviewFile(ans.file_url!)} />
                                ) : (
                                  <span className="text-ink-muted">—</span>
                                )}
                              </TableCell>
                            );
                          }
                          if (q.type === "file_upload") {
                            const fname = ans?.file_url ? parseFilePath(ans.file_url).name : "";
                            const isImg = isImageName(fname);
                            return (
                              <TableCell key={q.id} className="text-sm px-4 py-3 align-middle" style={{ maxWidth: isImg ? 160 : 200 }}>
                                {ans?.file_url ? (
                                  isImg ? (
                                    <SelfieThumb file_url={ans.file_url} size={120} onPreview={() => setPreviewFile(ans.file_url!)} />
                                  ) : (
                                    <FileChip file_url={ans.file_url} onPreview={() => setPreviewFile(ans.file_url!)} />
                                  )
                                ) : (
                                  <span className="text-ink-muted">—</span>
                                )}
                              </TableCell>
                            );
                          }
                          const val = resolveEmailText(q, r, ans) ?? String(renderCellText(q, ans) ?? "");
                          if (q.id === emailQidForForm) {
                            return (
                              <TableCell key={q.id} className="text-sm px-4 py-3 max-w-[260px] align-middle text-ink" onClick={(e) => e.stopPropagation()}>
                                <EmailInlineEditor
                                  responseId={r.id}
                                  email={val}
                                  onSaved={(newEmail) =>
                                    setResponses((prev) => prev.map((x) => x.id === r.id ? { ...x, override_email: newEmail } : x))
                                  }
                                  onRevert={(prevEmail) =>
                                    setResponses((prev) => prev.map((x) => x.id === r.id ? { ...x, override_email: prevEmail || null } : x))
                                  }
                                />
                              </TableCell>
                            );
                          }
                          return (
                            <TableCell key={q.id} className="text-sm px-4 py-3 max-w-[240px] align-middle text-ink" title={val}>
                              {val ? truncate(val) : <span className="text-ink-muted">—</span>}
                            </TableCell>
                          );
                        })}
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </div>
          </>
        )}
      </main>

      <Sheet open={!!activeResp} onOpenChange={(o) => !o && setActiveResp(null)}>
        <SheetContent className="w-full sm:max-w-lg overflow-y-auto">
          <SheetHeader>
            <SheetTitle>
              {activeResp ? `Response from ${fmtDate(activeResp.submitted_at)}` : "Response"}
            </SheetTitle>
          </SheetHeader>
          <div className="mt-6 space-y-5">
            {detailAnswers.map(({ q, ans }) => {
              if (q.type === "selfie") {
                return (
                  <div key={q.id}>
                    <div className="text-xs text-muted-foreground mb-1">{q.label}</div>
                    {ans?.file_url ? (
                      <SelfieThumb file_url={ans.file_url} size={160} onPreview={() => setPreviewFile(ans.file_url!)} />
                    ) : (
                      <div className="text-sm text-muted-foreground">—</div>
                    )}
                  </div>
                );
              }
              if (q.type === "file_upload") {
                return (
                  <div key={q.id}>
                    <div className="text-xs text-muted-foreground mb-1">{q.label}</div>
                    {ans?.file_url ? (
                      <FileCard file_url={ans.file_url} display_name={ans.answer_text || undefined} onPreview={() => setPreviewFile(ans.file_url!)} />
                    ) : (
                      <div className="text-sm text-muted-foreground">—</div>
                    )}
                  </div>
                );
              }
              const val =
                (activeResp ? resolveEmailText(q, activeResp, ans) : null) ??
                String(renderCellText(q, ans) ?? "");
              if (q.id === emailQidForForm && activeResp) {
                return (
                  <div key={q.id}>
                    <div className="text-xs text-muted-foreground mb-1">{q.label}</div>
                    <EmailInlineEditor
                      responseId={activeResp.id}
                      email={val}
                      onSaved={(newEmail) => {
                        setResponses((prev) => prev.map((x) => x.id === activeResp.id ? { ...x, override_email: newEmail } : x));
                        setActiveResp((cur) => cur ? { ...cur, override_email: newEmail } : cur);
                      }}
                      onRevert={(prevEmail) => {
                        setResponses((prev) => prev.map((x) => x.id === activeResp.id ? { ...x, override_email: prevEmail || null } : x));
                        setActiveResp((cur) => cur ? { ...cur, override_email: prevEmail || null } : cur);
                      }}
                    />
                  </div>
                );
              }
              return (
                <div key={q.id}>
                  <div className="text-xs text-muted-foreground mb-1">{q.label}</div>
                  <div className={`text-sm ${val ? "text-foreground" : "text-muted-foreground"}`}>
                    {val || "—"}
                  </div>
                </div>
              );
            })}
          </div>
          <div className="mt-8 pt-4 border-t border-border">
            <Button variant="destructive" onClick={() => setDeleteOpen(true)}>
              Delete response
            </Button>
          </div>
        </SheetContent>
      </Sheet>

      <AlertDialog open={deleteOpen} onOpenChange={setDeleteOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>
              Permanently delete{(() => {
                if (!activeResp) return "";
                const info = extractCandidateInfo(questions, answers, activeResp.id, activeResp.override_email);
                return info.name ? ` ${info.name}` : "";
              })()}?
            </AlertDialogTitle>
            <AlertDialogDescription>
              This permanently purges their application, files, emails, and history — cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={handleDelete}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              Permanently delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      <AlertDialog open={bulkDeleteOpen} onOpenChange={(o) => { setBulkDeleteOpen(o); if (!o) setBulkDeleteInput(""); }}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>
              {junkDeleteMode
                ? `Permanently delete ${selectedCount} candidate${selectedCount === 1 ? "" : "s"} with no name/email?`
                : `Permanently delete ${selectedCount} candidate${selectedCount === 1 ? "" : "s"}?`}
            </AlertDialogTitle>
            <AlertDialogDescription>
              This permanently purges their applications, files, emails, and history — cannot be undone.
              {selectedCount > 1 && !junkDeleteMode && (
                <> Type <span className="font-semibold text-foreground">DELETE</span> to confirm.</>
              )}
            </AlertDialogDescription>
          </AlertDialogHeader>
          {selectedCount > 1 && !junkDeleteMode && (
            <Input
              autoFocus
              value={bulkDeleteInput}
              onChange={(e) => setBulkDeleteInput(e.target.value)}
              placeholder="DELETE"
            />
          )}
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={handleBulkDelete}
              disabled={bulkBusy || (selectedCount > 1 && !junkDeleteMode && bulkDeleteInput !== "DELETE")}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              {bulkBusy ? <Loader2 className="h-4 w-4 animate-spin" /> : "Permanently delete"}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Per-row single delete confirm (no typing) */}
      <AlertDialog open={!!rowDeleteTarget} onOpenChange={(o) => { if (!o) setRowDeleteTarget(null); }}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>
              Permanently delete{(() => {
                if (!rowDeleteTarget) return " this candidate";
                const info = extractCandidateInfo(questions, answers, rowDeleteTarget.id, rowDeleteTarget.override_email);
                const label = (rowDeleteTarget.override_name?.trim() || info.name || info.email || "").trim();
                return label ? ` ${label}` : " this candidate";
              })()}?
            </AlertDialogTitle>
            <AlertDialogDescription>
              This permanently purges their application, files, emails, and history — cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={handleRowDelete}
              disabled={rowDeleteBusy}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              {rowDeleteBusy ? <Loader2 className="h-4 w-4 animate-spin" /> : "Permanently delete"}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      <FilePreviewDialog file_url={previewFile} onClose={() => setPreviewFile(null)} />
    </div>
  );
};

const FilterPanel = ({
  draft,
  setDraft,
  questions,
  onApply,
  onClear,
}: {
  draft: Filters;
  setDraft: (f: Filters) => void;
  questions: Q[];
  onApply: () => void;
  onClear: () => void;
}) => {
  const filterableQs = questions.filter((q) => ["yes_no", "multiple_choice", "rating"].includes(q.type));

  const togglePQ = (qid: string, val: string) => {
    const cur = draft.perQuestion[qid] || [];
    const next = cur.includes(val) ? cur.filter((x) => x !== val) : [...cur, val];
    const nextMap = { ...draft.perQuestion, [qid]: next };
    if (!next.length) delete nextMap[qid];
    setDraft({ ...draft, perQuestion: nextMap });
  };

  return (
    <div className="space-y-4">
      <div>
        <div className="text-xs font-semibold text-muted-foreground mb-2">Submitted</div>
        <RadioGroup
          value={draft.date}
          onValueChange={(v) => setDraft({ ...draft, date: v as any })}
          className="space-y-1"
        >
          {[
            ["all", "All time"],
            ["today", "Today"],
            ["7d", "Last 7 days"],
            ["30d", "Last 30 days"],
            ["custom", "Custom range"],
          ].map(([v, l]) => (
            <div key={v} className="flex items-center gap-2">
              <RadioGroupItem value={v} id={`date-${v}`} />
              <Label htmlFor={`date-${v}`} className="text-sm font-normal cursor-pointer">{l}</Label>
            </div>
          ))}
        </RadioGroup>
        {draft.date === "custom" && (
          <div className="mt-2 grid grid-cols-2 gap-2">
            <DateRangePick label="From" value={draft.from} onChange={(d) => setDraft({ ...draft, from: d })} />
            <DateRangePick label="To" value={draft.to} onChange={(d) => setDraft({ ...draft, to: d })} />
          </div>
        )}
      </div>

      <div>
        <div className="text-xs font-semibold text-muted-foreground mb-2">Read status</div>
        <div className="space-y-1">
          <label className="flex items-center gap-2 text-sm cursor-pointer">
            <Checkbox checked={draft.showRead} onCheckedChange={(c) => setDraft({ ...draft, showRead: !!c })} />
            Show read
          </label>
          <label className="flex items-center gap-2 text-sm cursor-pointer">
            <Checkbox checked={draft.showUnread} onCheckedChange={(c) => setDraft({ ...draft, showUnread: !!c })} />
            Show unread
          </label>
        </div>
      </div>

      {filterableQs.map((q) => {
        const opts = (q.options as any) || {};
        let values: string[] = [];
        if (q.type === "yes_no") values = ["yes", "no"];
        else if (q.type === "multiple_choice") {
          values = Array.isArray(opts.choices) ? [...opts.choices] : [];
          if (opts.allowOther) values.push("Other");
        } else if (q.type === "rating") {
          const scale = opts.scale || 5;
          values = Array.from({ length: scale }, (_, i) => String(i + 1));
        }
        const selected = draft.perQuestion[q.id] || [];
        return (
          <div key={q.id}>
            <div className="text-xs font-semibold text-muted-foreground mb-2 truncate" title={q.label}>{truncate(q.label, 32)}</div>
            <div className="space-y-1 max-h-32 overflow-y-auto">
              {values.map((v) => (
                <label key={v} className="flex items-center gap-2 text-sm cursor-pointer">
                  <Checkbox checked={selected.includes(v)} onCheckedChange={() => togglePQ(q.id, v)} />
                  <span className="capitalize">{q.type === "rating" ? `${v} star${v === "1" ? "" : "s"}` : v}</span>
                </label>
              ))}
            </div>
          </div>
        );
      })}

      <div className="flex justify-between pt-2 border-t border-border">
        <Button size="sm" variant="ghost" onClick={onClear}>Clear all</Button>
        <Button size="sm" onClick={onApply}>Apply filters</Button>
      </div>
    </div>
  );
};

const DateRangePick = ({ label, value, onChange }: { label: string; value?: Date; onChange: (d?: Date) => void }) => {
  const [open, setOpen] = useState(false);
  return (
    <Popover open={open} onOpenChange={setOpen}>
      <PopoverTrigger asChild>
        <Button variant="outline" size="sm" className="justify-start font-normal w-full">
          <CalendarIcon className="h-3 w-3 mr-1" />
          {value ? fmtFn(value, "MMM d") : label}
        </Button>
      </PopoverTrigger>
      <PopoverContent className="w-auto p-0" align="start">
        <Calendar mode="single" selected={value} onSelect={(d) => { onChange(d || undefined); setOpen(false); }} className="p-3 pointer-events-auto" />
      </PopoverContent>
    </Popover>
  );
};

export default Results;
