import { useEffect, useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card } from "@/components/ui/card";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import { Switch } from "@/components/ui/switch";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { toast } from "@/hooks/use-toast";
import { ArrowLeft, Search, Send, UserPlus, X, Users, Sparkles, Loader2 } from "lucide-react";
import SendScheduleControl, { type SendScheduleValue } from "@/components/SendScheduleControl";
import { insertScheduledSend, formatScheduledFor } from "@/lib/scheduledSends";

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

type SavedRecipient = { id: string; name: string | null; email: string };
type ManualRecipient = { name: string; email: string };

export default function CircularCompose() {
  const navigate = useNavigate();
  const [title, setTitle] = useState("");
  const [body, setBody] = useState("");
  const [explanation, setExplanation] = useState("");
  const [branded, setBranded] = useState(false);

  const [aiIdea, setAiIdea] = useState("");
  const [drafting, setDrafting] = useState(false);

  const [saved, setSaved] = useState<SavedRecipient[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [picked, setPicked] = useState<Record<string, boolean>>({}); // keyed by lower(email)

  const [manualName, setManualName] = useState("");
  const [manualEmail, setManualEmail] = useState("");
  const [manual, setManual] = useState<ManualRecipient[]>([]);

  const [confirmOpen, setConfirmOpen] = useState(false);
  const [sending, setSending] = useState(false);
  const [schedule, setSchedule] = useState<SendScheduleValue>({ mode: "now" });

  useEffect(() => {
    (async () => {
      setLoading(true);
      const { data, error } = await supabase
        .from("circular_recipients" as any)
        .select("id, name, email")
        .order("created_at", { ascending: false });
      if (error) {
        toast({ title: "Failed to load recipients", description: error.message, variant: "destructive" });
      } else {
        setSaved((data as any as SavedRecipient[]) || []);
      }
      setLoading(false);
    })();
  }, []);

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    if (!q) return saved;
    return saved.filter((r) => (r.name || "").toLowerCase().includes(q) || r.email.toLowerCase().includes(q));
  }, [saved, search]);

  // Combined, de-duplicated recipient set (lower(email)). Saved picks take precedence for the name.
  const recipients = useMemo(() => {
    const map = new Map<string, ManualRecipient>();
    for (const r of saved) {
      if (picked[r.email.toLowerCase()]) {
        map.set(r.email.toLowerCase(), { name: (r.name || "").trim(), email: r.email });
      }
    }
    for (const m of manual) {
      const key = m.email.toLowerCase();
      if (!map.has(key)) map.set(key, m);
    }
    return Array.from(map.values());
  }, [saved, picked, manual]);

  const togglePick = (email: string) => {
    const key = email.toLowerCase();
    setPicked((p) => ({ ...p, [key]: !p[key] }));
  };

  const addManual = () => {
    const email = manualEmail.trim();
    const name = manualName.trim();
    if (!EMAIL_RE.test(email)) {
      toast({ title: "Invalid email", description: "Enter a valid email address.", variant: "destructive" });
      return;
    }
    const key = email.toLowerCase();
    if (manual.some((m) => m.email.toLowerCase() === key) || saved.some((s) => s.email.toLowerCase() === key && picked[key])) {
      toast({ title: "Already added", description: email });
      return;
    }
    setManual((m) => [...m, { name, email }]);
    setManualName("");
    setManualEmail("");
  };

  const removeManual = (email: string) => {
    setManual((m) => m.filter((x) => x.email.toLowerCase() !== email.toLowerCase()));
  };

  const draftBody = async () => {
    const idea = aiIdea.trim();
    if (!idea) {
      toast({ title: "Add a rough idea first", description: "Type a few words about what the notice should say." });
      return;
    }
    setDrafting(true);
    try {
      const { data, error } = await supabase.functions.invoke("circular-draft-assist", {
        body: { idea, title: title.trim() },
      });
      if (error || !(data as any)?.draft) {
        toast({
          title: "Couldn't draft the notice",
          description: error?.message || (data as any)?.error || "Please try again in a moment.",
          variant: "destructive",
        });
        return;
      }
      setBody((data as any).draft);
      toast({ title: "Draft ready", description: "Review and edit the notice below before sending." });
    } catch (e: any) {
      toast({ title: "Couldn't draft the notice", description: e?.message || "Please try again.", variant: "destructive" });
    } finally {
      setDrafting(false);
    }
  };


  const send = async () => {
    setSending(true);

    // Scheduled branch: store a pending row with the EXACT Send-Now payload
    // (whole recipient list) and do NOT call send-circular now. At fire time
    // send-circular does its own per-recipient isolation exactly as today.
    if (schedule.mode === "schedule") {
      try {
        await insertScheduledSend({
          send_type: "circular",
          target_function: "send-circular",
          payload: { title: title.trim(), body, explanation: explanation.trim() || null, recipients, branded_letterhead: branded },
          response_id: null,
          scheduled_for_utc: schedule.scheduled_for_utc,
          timezone: schedule.timezone,
        });
        toast({
          title: "Circular scheduled",
          description: `Will send to ${recipients.length} recipient${recipients.length === 1 ? "" : "s"} on ${formatScheduledFor(schedule.scheduled_for_utc, schedule.timezone)}.`,
        });
        setSending(false);
        setConfirmOpen(false);
        navigate("/dashboard/circular-recipients");
      } catch (e: any) {
        setSending(false);
        toast({ title: "Could not schedule", description: e?.message || "Unknown error", variant: "destructive" });
      }
      return;
    }

    const { data, error } = await supabase.functions.invoke("send-circular", {
      body: { title: title.trim(), body, explanation: explanation.trim() || null, recipients, branded_letterhead: branded },
    });
    setSending(false);
    setConfirmOpen(false);
    if (error || !(data as any)?.ok) {
      toast({
        title: "Send failed",
        description: error?.message || (data as any)?.reason || "Unknown error",
        variant: "destructive",
      });
      return;
    }
    const d = data as any;
    toast({
      title: "Circular sent",
      description: `${d.sent} sent, ${d.failed} failed of ${d.total} recipient(s).`,
    });
    navigate("/dashboard/circular-recipients");
  };

  const canSend = body.trim().length > 0 && recipients.length > 0;

  return (
    <div className="min-h-screen bg-background">
      <div className="max-w-4xl mx-auto px-4 py-6 space-y-6">
        <div className="flex items-center gap-3">
          <Button variant="ghost" size="sm" onClick={() => navigate("/dashboard/circular-recipients")}>
            <ArrowLeft className="h-4 w-4 mr-1.5" /> Back
          </Button>
          <div className="flex items-center gap-2">
            <Send className="h-5 w-5 text-primary" />
            <h1 className="text-xl font-semibold">New Circular Notice</h1>
          </div>
        </div>

        <Card className="p-4 space-y-4">
          <div className="space-y-1.5">
            <Label htmlFor="circ-title">Title</Label>
            <Input
              id="circ-title"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="e.g. Updated Remote Work Policy"
            />
          </div>
          <div className="space-y-2 rounded-md border border-dashed bg-muted/30 p-3">
            <div className="flex items-center gap-2">
              <Sparkles className="h-4 w-4 text-primary" />
              <Label htmlFor="circ-ai-idea" className="font-medium">Help me write</Label>
            </div>
            <p className="text-xs text-muted-foreground">
              Type a rough idea and let AI draft the notice for you. You can edit it afterwards.
            </p>
            <Textarea
              id="circ-ai-idea"
              value={aiIdea}
              onChange={(e) => setAiIdea(e.target.value)}
              placeholder="e.g. remind everyone the office will be closed for the holidays from Dec 24 to Jan 1, and to submit pending reports before leaving"
              className="min-h-[70px]"
              disabled={drafting}
            />
            <Button type="button" size="sm" variant="secondary" onClick={draftBody} disabled={drafting || !aiIdea.trim()}>
              {drafting ? (
                <><Loader2 className="h-4 w-4 mr-1.5 animate-spin" /> Drafting…</>
              ) : (
                <><Sparkles className="h-4 w-4 mr-1.5" /> Draft notice with AI</>
              )}
            </Button>
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="circ-body">Notice body</Label>
            <Textarea
              id="circ-body"
              value={body}
              onChange={(e) => setBody(e.target.value)}
              placeholder="Type the full notice here. It can be as long as you need — it will flow onto more pages automatically."
              className="min-h-[220px]"
            />
            <p className="text-xs text-muted-foreground">Plain text. It will flow onto more pages automatically.</p>
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="circ-explanation">Explanation / note to recipient <span className="text-muted-foreground font-normal">(optional)</span></Label>
            <Textarea
              id="circ-explanation"
              value={explanation}
              onChange={(e) => setExplanation(e.target.value)}
              placeholder="A short note or instructions shown to the recipient on the signing page, before the notice."
              className="min-h-[90px]"
            />
            <p className="text-xs text-muted-foreground">Shown to each recipient above the notice when they open the link to sign.</p>
          </div>

          <div className="flex items-start justify-between gap-4 rounded-md border p-3">
            <div className="space-y-0.5">
              <Label htmlFor="circ-branded">Branded letterhead</Label>
              <p className="text-xs text-muted-foreground">
                Off = plain notice (internal rules). On = full EIA letterhead on every page (appreciation, warnings, official notices).
              </p>
            </div>
            <Switch id="circ-branded" checked={branded} onCheckedChange={setBranded} />
          </div>
        </Card>

        <Card className="p-4 space-y-4">
          <div className="flex items-center gap-2">
            <Users className="h-4 w-4 text-primary" />
            <h2 className="font-medium">Recipients</h2>
            <Badge variant="secondary" className="ml-auto">{recipients.length} selected</Badge>
          </div>

          <Tabs defaultValue="list">
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="list">Add from list</TabsTrigger>
              <TabsTrigger value="manual">Add manually</TabsTrigger>
            </TabsList>

            <TabsContent value="list" className="space-y-3 pt-3">
              <div className="relative">
                <Search className="h-4 w-4 absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
                <Input
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                  placeholder="Search saved recipients…"
                  className="pl-9"
                />
              </div>
              <div className="max-h-64 overflow-y-auto rounded-md border divide-y">
                {loading ? (
                  <p className="text-sm text-muted-foreground text-center py-6">Loading…</p>
                ) : filtered.length === 0 ? (
                  <p className="text-sm text-muted-foreground text-center py-6">
                    {saved.length === 0 ? "No saved recipients yet." : "No matches."}
                  </p>
                ) : (
                  filtered.map((r) => {
                    const key = r.email.toLowerCase();
                    return (
                      <label key={r.id} className="flex items-center gap-3 px-3 py-2 cursor-pointer hover:bg-muted/50">
                        <Checkbox checked={!!picked[key]} onCheckedChange={() => togglePick(r.email)} />
                        <span className="flex-1 min-w-0">
                          <span className="font-medium">{r.name || "—"}</span>
                          <span className="block text-xs font-mono text-muted-foreground truncate">{r.email}</span>
                        </span>
                      </label>
                    );
                  })
                )}
              </div>
            </TabsContent>

            <TabsContent value="manual" className="space-y-3 pt-3">
              <div className="grid gap-3 sm:grid-cols-[1fr_1fr_auto] sm:items-end">
                <div className="space-y-1.5">
                  <Label htmlFor="m-name">Name</Label>
                  <Input id="m-name" value={manualName} onChange={(e) => setManualName(e.target.value)} placeholder="Juliet" />
                </div>
                <div className="space-y-1.5">
                  <Label htmlFor="m-email">Email</Label>
                  <Input
                    id="m-email"
                    type="email"
                    value={manualEmail}
                    onChange={(e) => setManualEmail(e.target.value)}
                    placeholder="juliet@gmail.com"
                    onKeyDown={(e) => { if (e.key === "Enter") { e.preventDefault(); addManual(); } }}
                  />
                </div>
                <Button type="button" onClick={addManual}>
                  <UserPlus className="h-4 w-4 mr-1.5" /> Add
                </Button>
              </div>
              <p className="text-xs text-muted-foreground">
                Manually added people are saved to your recipient list automatically when you send.
              </p>
              {manual.length > 0 && (
                <div className="flex flex-wrap gap-2">
                  {manual.map((m) => (
                    <Badge key={m.email} variant="outline" className="gap-1.5">
                      {m.name ? `${m.name} · ` : ""}{m.email}
                      <button type="button" onClick={() => removeManual(m.email)} aria-label={`Remove ${m.email}`}>
                        <X className="h-3 w-3" />
                      </button>
                    </Badge>
                  ))}
                </div>
              )}
            </TabsContent>
          </Tabs>
        </Card>

        <Card className="p-4 space-y-3">
          <Label>When to send</Label>
          <SendScheduleControl onChange={setSchedule} />
        </Card>

        <div className="flex items-center justify-end gap-3">
          <p className="text-sm text-muted-foreground mr-auto">
            Each recipient gets their own private copy — no one sees who else received it.
          </p>
          <Button disabled={!canSend} onClick={() => setConfirmOpen(true)}>
            <Send className="h-4 w-4 mr-1.5" />
            {schedule.mode === "schedule" ? "Schedule" : "Send"} Circular to {recipients.length} recipient{recipients.length === 1 ? "" : "s"}
          </Button>
        </div>
      </div>

      <AlertDialog open={confirmOpen} onOpenChange={(o) => !sending && setConfirmOpen(o)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>{schedule.mode === "schedule" ? "Schedule this circular?" : "Send this circular?"}</AlertDialogTitle>
            <AlertDialogDescription>
              {schedule.mode === "schedule" ? (
                <>
                  This will schedule <strong>{recipients.length}</strong> separate, private email{recipients.length === 1 ? "" : "s"} —
                  one per recipient — to send on {formatScheduledFor(schedule.scheduled_for_utc, schedule.timezone)} ({schedule.timezone}).
                </>
              ) : (
                <>
                  This will send <strong>{recipients.length}</strong> separate, private email{recipients.length === 1 ? "" : "s"} —
                  one per recipient. Each person receives their own signing link. This cannot be undone.
                </>
              )}
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={sending}>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={(e) => { e.preventDefault(); send(); }} disabled={sending}>
              {sending ? (schedule.mode === "schedule" ? "Scheduling…" : "Sending…") : (schedule.mode === "schedule" ? "Schedule" : `Send to ${recipients.length}`)}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
