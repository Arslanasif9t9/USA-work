import { useEffect, useMemo, useRef, useState } from "react";
import { useNavigate, useSearchParams } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from "@/components/ui/table";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle,
} from "@/components/ui/dialog";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import { toast } from "sonner";
import { Textarea } from "@/components/ui/textarea";
import {
  ArrowLeft, ChevronDown, ChevronRight, ExternalLink, RefreshCw, X, Trash2,
} from "lucide-react";
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { SelfieThumb, FilePreviewDialog } from "@/components/FilePreview";
import OnboardingSubmissionsSection from "@/components/OnboardingSubmissionsSection";
import OnboardingTestApprovalsSection from "@/components/OnboardingTestApprovalsSection";

type LeaveRow = {
  id: string;
  response_id: string | null;
  matched_response_id: string | null;
  matched_at: string | null;
  external_reference: string;
  signer_name: string | null;
  signer_email: string | null;
  leave_type: string | null;
  reason: string | null;
  start_date: string | null;
  num_days: string | null;
  hours_missed: string | null;
  makeup_choice: string | null;
  makeup_plan: string | null;
  coverer_name: string | null;
  agreed_with_coverer: boolean | null;
  trained_coverer: boolean | null;
  typed_name: string | null;
  status: string;
  hr_decision_note: string | null;
  decided_at: string | null;
  signed_pdf_url: string | null;
  created_at: string;
  signature_date: string | null;
  doc_type: string | null;
  ca_amount: string | null;
  ca_reason: string | null;
  ca_repayment_method: string | null;
  id_photo_1_url: string | null;
  id_photo_2_url: string | null;
  id_hr_message: string | null;
  id_body_note: string | null;
  pc_amount: string | null;
  pc_duration: string | null;
  pc_preferred_time: string | null;
  pc_hr_message: string | null;
};

const LEAVE_SELECT =
  "id, response_id, matched_response_id, matched_at, external_reference, signer_name, signer_email, leave_type, reason, start_date, num_days, hours_missed, makeup_choice, makeup_plan, coverer_name, agreed_with_coverer, trained_coverer, typed_name, status, hr_decision_note, decided_at, signed_pdf_url, created_at, signature_date, doc_type, ca_amount, ca_reason, ca_repayment_method, id_photo_1_url, id_photo_2_url, id_hr_message, id_body_note, pc_amount, pc_duration, pc_preferred_time, pc_hr_message";

const fmtDate = (d: string | null) =>
  d ? new Date(d).toLocaleDateString("en-US", { year: "numeric", month: "short", day: "numeric" }) : "—";
const fmtDateTime = (d: string | null) =>
  d ? new Date(d).toLocaleString("en-US", { dateStyle: "medium", timeStyle: "short" }) : "—";

const toDaysNum = (s: string | null): number => {
  if (!s) return 0;
  const n = parseFloat(String(s).replace(/[^\d.]/g, ""));
  return isFinite(n) ? n : 0;
};

const statusPill = (status: string) => {
  const map: Record<string, { bg: string; color: string; label: string }> = {
    invited:          { bg: "#e5e7eb", color: "#374151", label: "Invited" },
    pending_approval: { bg: "#fef3c7", color: "#92400e", label: "Pending" },
    approved:         { bg: "#dcfce7", color: "#166534", label: "Approved" },
    declined:         { bg: "#fee2e2", color: "#991b1b", label: "Declined" },
  };
  const m = map[status] || { bg: "#e5e7eb", color: "#374151", label: status };
  return (
    <span style={{ background: m.bg, color: m.color }} className="inline-flex px-2 py-0.5 rounded text-xs font-medium">
      {m.label}
    </span>
  );
};

const typePill = (t: string | null) => {
  const isSick = t === "sick";
  return (
    <span
      style={{ background: isSick ? "#fee2e2" : "#e5e7eb", color: isSick ? "#991b1b" : "#374151" }}
      className="inline-flex px-2 py-0.5 rounded text-xs font-medium"
    >
      {isSick ? "Sick" : "General"}
    </span>
  );
};

// Branch the Type pill by doc_type: cash advances get a distinct gold/amber pill;
// leave rows keep their existing Sick/General pill.
const docTypePill = (r: { doc_type: string | null; leave_type: string | null }) => {
  if (r.doc_type === "cash_advance") {
    return (
      <span
        style={{ background: "#fde68a", color: "#78350f" }}
        className="inline-flex px-2 py-0.5 rounded text-xs font-medium"
      >
        Cash Advance
      </span>
    );
  }
  if (r.doc_type === "id_collection") {
    return (
      <span
        style={{ background: "#e0e7ff", color: "#3730a3" }}
        className="inline-flex px-2 py-0.5 rounded text-xs font-medium"
      >
        ID Collection
      </span>
    );
  }
  if (r.doc_type === "pre_consultation") {
    return (
      <span
        style={{ background: "#ede9fe", color: "#5b21b6" }}
        className="inline-flex px-2 py-0.5 rounded text-xs font-medium"
      >
        Pre-Consultation
      </span>
    );
  }
  return typePill(r.leave_type);
};

const PAGE_SIZE = 25;

const daysAgo = (d: number) => {
  const x = new Date();
  x.setDate(x.getDate() - d);
  x.setHours(0, 0, 0, 0);
  return x;
};
const toInput = (d: Date) => d.toISOString().slice(0, 10);

export default function SickLeavesDashboard() {
  const navigate = useNavigate();
  const [params, setParams] = useSearchParams();

  const [loading, setLoading] = useState(true);
  const [rows, setRows] = useState<LeaveRow[]>([]);
  const [empNameByResp, setEmpNameByResp] = useState<Record<string, string>>({});

  // Filters
  const initialSigner = params.get("signer") || "";
  const [fromDate, setFromDate] = useState(toInput(daysAgo(90)));
  const [toDate, setToDate] = useState(toInput(new Date()));
  const [typeFilter, setTypeFilter] = useState<"all" | "sick" | "general">("all");
  const [statusFilter, setStatusFilter] = useState<"all" | "invited" | "pending_approval" | "approved" | "declined">("all");
  const [matchFilter, setMatchFilter] = useState<"all" | "matched" | "unmatched">("all");
  const [searchText, setSearchText] = useState(initialSigner);
  const [page, setPage] = useState(1);

  const [repeatWindow, setRepeatWindow] = useState<30 | 90>(30);
  const [unmatchedOpen, setUnmatchedOpen] = useState(true);

  const [viewLeave, setViewLeave] = useState<LeaveRow | null>(null);
  const [rematchingId, setRematchingId] = useState<string | null>(null);
  const [decideNote, setDecideNote] = useState("");
  const [decideBusy, setDecideBusy] = useState<null | "approved" | "declined">(null);
  const [previewFile, setPreviewFile] = useState<string | null>(null);
  const [confirmDeleteId, setConfirmDeleteId] = useState<string | null>(null);
  const [deleting, setDeleting] = useState(false);

  // Single-row delete by id from leave_requests (covers leave/cash_advance/id_collection/pre_consultation).
  const handleDelete = async (id: string) => {
    setDeleting(true);
    try {
      const { error } = await (supabase.from("leave_requests") as any).delete().eq("id", id);
      if (error) throw error;
      setRows((prev) => prev.filter((r) => r.id !== id));
      toast.success("Filed record deleted");
      setConfirmDeleteId(null);
    } catch (e: any) {
      toast.error(e?.message || "Failed to delete record");
    } finally {
      setDeleting(false);
    }
  };

  const mainTableRef = useRef<HTMLDivElement | null>(null);

  const load = async () => {
    setLoading(true);
    const { data, error } = await (supabase.from("leave_requests") as any)
      .select(LEAVE_SELECT)
      .order("created_at", { ascending: false })
      .limit(1000);
    if (error) {
      toast.error(error.message);
      setRows([]);
      setLoading(false);
      return;
    }
    const list = (data as LeaveRow[]) || [];
    setRows(list);

    // Resolve matched employee names via job_offers (via responses.applicant_id)
    const matchedRespIds = Array.from(new Set(list.map((r) => r.matched_response_id).filter(Boolean) as string[]));
    if (matchedRespIds.length) {
      const { data: resps } = await (supabase.from("responses") as any)
        .select("id, applicant_id")
        .in("id", matchedRespIds);
      const applicantByResp: Record<string, string> = {};
      const applicantIds: string[] = [];
      for (const r of (resps as any[]) || []) {
        if (r.applicant_id) {
          applicantByResp[r.id] = r.applicant_id;
          applicantIds.push(r.applicant_id);
        }
      }
      const nameByResp: Record<string, string> = {};
      if (applicantIds.length) {
        const { data: offs } = await (supabase.from("job_offers") as any)
          .select("candidate_id, candidate_name, signed_at")
          .in("candidate_id", applicantIds)
          .order("signed_at", { ascending: false });
        const nameByApp: Record<string, string> = {};
        for (const o of (offs as any[]) || []) {
          if (o.candidate_id && !nameByApp[o.candidate_id]) nameByApp[o.candidate_id] = o.candidate_name;
        }
        for (const [rid, aid] of Object.entries(applicantByResp)) {
          if (nameByApp[aid]) nameByResp[rid] = nameByApp[aid];
        }
      }
      setEmpNameByResp(nameByResp);
    } else {
      setEmpNameByResp({});
    }

    setLoading(false);
  };

  useEffect(() => { load(); }, []);

  // Apply filters
  const filtered = useMemo(() => {
    const from = new Date(fromDate + "T00:00:00").getTime();
    const to = new Date(toDate + "T23:59:59").getTime();
    const q = searchText.trim().toLowerCase();
    return rows.filter((r) => {
      const t = new Date(r.created_at).getTime();
      if (t < from || t > to) return false;
      if (typeFilter !== "all" && (r.leave_type || "general") !== typeFilter) return false;
      if (statusFilter !== "all" && r.status !== statusFilter) return false;
      if (matchFilter === "matched" && !r.matched_response_id) return false;
      if (matchFilter === "unmatched" && r.matched_response_id) return false;
      if (q) {
        const hay = `${r.signer_name || ""} ${r.signer_email || ""}`.toLowerCase();
        if (!hay.includes(q)) return false;
      }
      return true;
    });
  }, [rows, fromDate, toDate, typeFilter, statusFilter, matchFilter, searchText]);

  const pageCount = Math.max(1, Math.ceil(filtered.length / PAGE_SIZE));
  const pageRows = filtered.slice((page - 1) * PAGE_SIZE, page * PAGE_SIZE);

  useEffect(() => { setPage(1); }, [fromDate, toDate, typeFilter, statusFilter, matchFilter, searchText]);

  // Repeat-filer aggregation
  const repeatFilers = useMemo(() => {
    const since = daysAgo(repeatWindow).getTime();
    type Agg = { key: string; name: string; email: string; count: number; days: number; last: string; unmatched: boolean };
    const map = new Map<string, Agg>();
    for (const r of rows) {
      if (new Date(r.created_at).getTime() < since) continue;
      if (r.status === "invited") continue; // not yet signed/filed
      const unmatched = !r.matched_response_id;
      const key = unmatched
        ? `unm:${(r.signer_email || "").toLowerCase()}`
        : `m:${r.matched_response_id}`;
      const cur = map.get(key);
      const name = r.signer_name || "—";
      const email = r.signer_email || "—";
      if (cur) {
        cur.count += 1;
        cur.days += toDaysNum(r.num_days);
        if (r.created_at > cur.last) cur.last = r.created_at;
      } else {
        map.set(key, { key, name, email, count: 1, days: toDaysNum(r.num_days), last: r.created_at, unmatched });
      }
    }
    return Array.from(map.values())
      .filter((a) => a.count >= 2)
      .sort((a, b) => (b.count - a.count) || (b.last.localeCompare(a.last)));
  }, [rows, repeatWindow]);

  const unmatchedSigned = useMemo(
    () => rows.filter((r) => !r.matched_response_id && r.status !== "invited"),
    [rows],
  );

  const clearFilters = () => {
    setFromDate(toInput(daysAgo(90)));
    setToDate(toInput(new Date()));
    setTypeFilter("all");
    setStatusFilter("all");
    setMatchFilter("all");
    setSearchText("");
    setParams({});
  };

  const focusEmail = (email: string) => {
    setSearchText(email);
    setMatchFilter("all");
    setStatusFilter("all");
    setTypeFilter("all");
    setTimeout(() => mainTableRef.current?.scrollIntoView({ behavior: "smooth", block: "start" }), 50);
  };

  const tryRematch = async (leaveId: string) => {
    setRematchingId(leaveId);
    try {
      const { data, error } = await supabase.functions.invoke<any>("rematch-leave", { body: { leave_id: leaveId } });
      if (error) throw error;
      if (data?.matched) {
        toast.success("Matched to employee.");
      } else if (data?.already) {
        toast.message("Already matched.");
      } else {
        toast.warning("No match found.");
      }
      await load();
    } catch (e: any) {
      toast.error(e?.message || "Re-match failed");
    } finally {
      setRematchingId(null);
    }
  };

  // Approve / decline a pending row. Branch the edge function by doc_type:
  // cash advances -> decide-cash-advance, leaves -> decide-leave (unchanged).
  const decide = async (row: LeaveRow, decision: "approved" | "declined") => {
    setDecideBusy(decision);
    try {
      const fn =
        row.doc_type === "cash_advance" ? "decide-cash-advance"
        : row.doc_type === "id_collection" ? "decide-id-collection"
        : row.doc_type === "pre_consultation" ? "decide-pre-consultation"
        : "decide-leave";
      const { data, error } = await supabase.functions.invoke<any>(fn, {
        body: { leave_request_id: row.id, decision, note: decideNote.trim() || null },
      });
      if (error || !data?.ok) {
        toast.error(`Could not ${decision === "approved" ? "approve" : "decline"}: ${data?.reason || error?.message || "failed"}`);
        return;
      }
      if (data?.pdf_warning || data?.email_warning) {
        toast.warning(`Decision saved, but: ${data.pdf_warning || data.email_warning}`);
      } else {
        const docLabel =
          row.doc_type === "cash_advance" ? "Cash advance"
          : row.doc_type === "id_collection" ? "ID collection"
          : row.doc_type === "pre_consultation" ? "Pre-consultation"
          : "Leave";
        toast.success(`${docLabel} ${decision}.`);
      }
      setDecideNote("");
      await load();
      // Refetch the single row so the dialog shows updated status + signed PDF.
      const { data: fresh } = await (supabase.from("leave_requests") as any)
        .select(LEAVE_SELECT)
        .eq("id", row.id)
        .maybeSingle();
      if (fresh) setViewLeave(fresh as LeaveRow);
    } finally {
      setDecideBusy(null);
    }
  };



  return (
    <div className="min-h-screen bg-background">
      <div className="border-b">
        <div className="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Button variant="ghost" size="sm" onClick={() => navigate("/dashboard")}>
              <ArrowLeft className="h-4 w-4 mr-1.5" /> Dashboard
            </Button>
            <div>
              <h1 className="text-xl font-semibold">H.R Approval</h1>
              <p className="text-sm text-muted-foreground">Filed leave and request history across the team.</p>
            </div>
          </div>
          <Button variant="outline" size="sm" onClick={load} disabled={loading}>
            <RefreshCw className={`h-4 w-4 mr-1.5 ${loading ? "animate-spin" : ""}`} /> Refresh
          </Button>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-6 py-6 space-y-6">
        {/* Onboarding video+quiz approvals (passed, awaiting HR) */}
        <OnboardingTestApprovalsSection />

        {/* Onboarding Submissions queue */}
        <OnboardingSubmissionsSection />

        {/* B. Repeat-Filer Panel */}
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-base">Repeat Filers</CardTitle>
            <div className="flex gap-1">
              <Button
                size="sm"
                variant={repeatWindow === 30 ? "default" : "outline"}
                onClick={() => setRepeatWindow(30)}
              >Last 30 days</Button>
              <Button
                size="sm"
                variant={repeatWindow === 90 ? "default" : "outline"}
                onClick={() => setRepeatWindow(90)}
              >Last 90 days</Button>
            </div>
          </CardHeader>
          <CardContent>
            {repeatFilers.length === 0 ? (
              <p className="text-sm text-muted-foreground py-4">No repeat filers in this window — clean record.</p>
            ) : (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Employee / Signer</TableHead>
                    <TableHead>Email</TableHead>
                    <TableHead className="text-right"># Leaves</TableHead>
                    <TableHead className="text-right">Days Total</TableHead>
                    <TableHead>Last Filed</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {repeatFilers.map((a) => (
                    <TableRow
                      key={a.key}
                      className="cursor-pointer hover:bg-muted/50"
                      onClick={() => focusEmail(a.email)}
                    >
                      <TableCell>
                        <div className="flex items-center gap-2">
                          <span className="font-medium">{a.name}</span>
                          {a.unmatched && (
                            <Badge variant="outline" className="text-xs">Unmatched signer</Badge>
                          )}
                        </div>
                      </TableCell>
                      <TableCell className="text-muted-foreground">{a.email}</TableCell>
                      <TableCell className="text-right font-semibold">{a.count}</TableCell>
                      <TableCell className="text-right">{a.days || "—"}</TableCell>
                      <TableCell>{fmtDate(a.last)}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            )}
          </CardContent>
        </Card>

        {/* C. Filter bar */}
        <Card>
          <CardContent className="py-4">
            <div className="flex flex-wrap items-end gap-3">
              <div>
                <label className="text-xs text-muted-foreground block mb-1">From</label>
                <Input type="date" value={fromDate} onChange={(e) => setFromDate(e.target.value)} className="w-[150px]" />
              </div>
              <div>
                <label className="text-xs text-muted-foreground block mb-1">To</label>
                <Input type="date" value={toDate} onChange={(e) => setToDate(e.target.value)} className="w-[150px]" />
              </div>
              <div>
                <label className="text-xs text-muted-foreground block mb-1">Type</label>
                <Select value={typeFilter} onValueChange={(v: any) => setTypeFilter(v)}>
                  <SelectTrigger className="w-[120px]"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All</SelectItem>
                    <SelectItem value="sick">Sick</SelectItem>
                    <SelectItem value="general">General</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <label className="text-xs text-muted-foreground block mb-1">Status</label>
                <Select value={statusFilter} onValueChange={(v: any) => setStatusFilter(v)}>
                  <SelectTrigger className="w-[160px]"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All</SelectItem>
                    <SelectItem value="invited">Invited</SelectItem>
                    <SelectItem value="pending_approval">Pending approval</SelectItem>
                    <SelectItem value="approved">Approved</SelectItem>
                    <SelectItem value="declined">Declined</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <label className="text-xs text-muted-foreground block mb-1">Matched</label>
                <Select value={matchFilter} onValueChange={(v: any) => setMatchFilter(v)}>
                  <SelectTrigger className="w-[150px]"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All</SelectItem>
                    <SelectItem value="matched">Matched only</SelectItem>
                    <SelectItem value="unmatched">Unmatched only</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="flex-1 min-w-[200px]">
                <label className="text-xs text-muted-foreground block mb-1">Search name or email</label>
                <Input value={searchText} onChange={(e) => setSearchText(e.target.value)} placeholder="signer name or email" />
              </div>
              <Button variant="outline" size="sm" onClick={clearFilters}>
                <X className="h-4 w-4 mr-1" /> Clear
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* D. Main table */}
        <Card ref={mainTableRef as any}>
          <CardHeader className="pb-2">
            <CardTitle className="text-base">All Filed Leaves ({filtered.length})</CardTitle>
          </CardHeader>
          <CardContent>
            {loading ? (
              <p className="text-sm text-muted-foreground py-6">Loading…</p>
            ) : filtered.length === 0 ? (
              <p className="text-sm text-muted-foreground py-6">No leaves match the current filters.</p>
            ) : (
              <>
                <Table className="w-full table-fixed text-xs [&_th]:px-2 [&_th]:py-2 [&_td]:px-2 [&_td]:py-2 [&_td]:align-top">
                  <TableHeader>
                    <TableRow>
                      <TableHead className="w-9"></TableHead>
                      <TableHead className="w-[12%]">Signer</TableHead>
                      <TableHead className="w-[16%]">Email</TableHead>
                      <TableHead className="w-[9%]">Type</TableHead>
                      <TableHead className="w-[9%]">Start</TableHead>
                      <TableHead className="w-[5%]">Days</TableHead>
                      <TableHead className="w-[16%]">Reason</TableHead>
                      <TableHead className="w-[9%]">Status</TableHead>
                      <TableHead className="w-[11%]">Matched</TableHead>
                      <TableHead className="w-[9%]">Filed</TableHead>
                      <TableHead className="w-[7%] text-right">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {pageRows.map((r) => {
                      const empName = r.matched_response_id ? empNameByResp[r.matched_response_id] : null;
                      return (
                        <TableRow key={r.id}>
                          <TableCell>
                            <Button
                              variant="ghost"
                              size="icon"
                              className="h-7 w-7 text-red-600 hover:text-red-700 hover:bg-red-50 border border-red-200"
                              onClick={() => setConfirmDeleteId(r.id)}
                              aria-label="Delete filed record"
                              title="Delete this record permanently"
                            >
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </TableCell>
                          <TableCell className="font-medium whitespace-normal break-words">{r.signer_name || "—"}</TableCell>
                          <TableCell className="text-muted-foreground whitespace-normal break-all">{r.signer_email || "—"}</TableCell>
                          <TableCell>{docTypePill(r)}</TableCell>
                          <TableCell className="whitespace-normal break-words">{r.start_date || "—"}</TableCell>
                          <TableCell>{r.num_days || "—"}</TableCell>
                          <TableCell className="whitespace-normal break-words">
                            <span title={r.reason || ""}>{r.reason || "—"}</span>
                          </TableCell>
                          <TableCell>{statusPill(r.status)}</TableCell>
                          <TableCell className="whitespace-normal break-words">
                            {r.matched_response_id ? (
                              <span title={empName || ""}>✓ {empName || "Employee"}</span>
                            ) : (
                              <span className="text-muted-foreground">— Unmatched</span>
                            )}
                          </TableCell>
                          <TableCell className="whitespace-normal break-words">{fmtDate(r.created_at)}</TableCell>
                          <TableCell className="text-right">
                            <Button size="sm" variant="outline" className="h-7 px-2" onClick={() => { setViewLeave(r); setDecideNote(""); }}>View</Button>
                          </TableCell>
                        </TableRow>
                      );
                    })}
                  </TableBody>
                </Table>
                {pageCount > 1 && (
                  <div className="flex items-center justify-between pt-3">
                    <span className="text-xs text-muted-foreground">Page {page} of {pageCount}</span>
                    <div className="flex gap-1">
                      <Button size="sm" variant="outline" disabled={page === 1} onClick={() => setPage(page - 1)}>Prev</Button>
                      <Button size="sm" variant="outline" disabled={page === pageCount} onClick={() => setPage(page + 1)}>Next</Button>
                    </div>
                  </div>
                )}
              </>
            )}
          </CardContent>
        </Card>

        {/* E. Unmatched panel */}
        <Card>
          <CardHeader className="pb-2">
            <button
              type="button"
              className="flex items-center gap-2 text-left"
              onClick={() => setUnmatchedOpen((o) => !o)}
            >
              {unmatchedOpen ? <ChevronDown className="h-4 w-4" /> : <ChevronRight className="h-4 w-4" />}
              <CardTitle className="text-base">Unmatched Leaves ({unmatchedSigned.length})</CardTitle>
            </button>
          </CardHeader>
          {unmatchedOpen && (
            <CardContent>
              {unmatchedSigned.length === 0 ? (
                <p className="text-sm text-muted-foreground py-2">All signed leaves are linked to an employee.</p>
              ) : (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Signer</TableHead>
                      <TableHead>Email</TableHead>
                      <TableHead>Filed</TableHead>
                      <TableHead className="text-right">Action</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {unmatchedSigned.map((r) => (
                      <TableRow key={r.id}>
                        <TableCell>{r.signer_name || "—"}</TableCell>
                        <TableCell className="text-muted-foreground">{r.signer_email || "—"}</TableCell>
                        <TableCell>{fmtDate(r.created_at)}</TableCell>
                        <TableCell className="text-right">
                          <Button
                            size="sm"
                            variant="outline"
                            disabled={rematchingId === r.id}
                            onClick={() => tryRematch(r.id)}
                          >
                            {rematchingId === r.id ? "…" : "Try Re-match"}
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              )}
            </CardContent>
          )}
        </Card>
      </div>

      {/* View dialog */}
      <Dialog open={!!viewLeave} onOpenChange={(o) => { if (!o) { setViewLeave(null); setDecideNote(""); } }}>
        <DialogContent className="max-w-2xl max-h-[90vh] flex flex-col">
          <DialogHeader className="shrink-0">
            <DialogTitle>
              {viewLeave?.doc_type === "cash_advance"
                ? "Cash advance details"
                : viewLeave?.doc_type === "id_collection"
                ? "ID collection details"
                : viewLeave?.doc_type === "pre_consultation"
                ? "Pre-consultation details"
                : "Leave details"} — {viewLeave?.signer_name}
            </DialogTitle>
          </DialogHeader>
          {viewLeave && (
            <>
              <div className="flex-1 min-h-0 overflow-y-auto space-y-3 text-sm">
              {viewLeave.doc_type === "id_collection" ? (
                <>
                  {/* ID collection fields */}
                  <div className="grid grid-cols-2 gap-3">
                    <div><span className="text-muted-foreground">Reference:</span> {viewLeave.external_reference}</div>
                    <div><span className="text-muted-foreground">Type:</span> {docTypePill(viewLeave)}</div>
                    <div><span className="text-muted-foreground">Status:</span> {statusPill(viewLeave.status)}</div>
                    <div><span className="text-muted-foreground">Filed:</span> {fmtDateTime(viewLeave.created_at)}</div>
                    <div><span className="text-muted-foreground">Signed name:</span> {viewLeave.typed_name || "—"}</div>
                    <div><span className="text-muted-foreground">Signed date:</span> {viewLeave.signature_date || "—"}</div>
                    <div>
                      <span className="text-muted-foreground">Matched:</span>{" "}
                      {viewLeave.matched_response_id ? "✓ Matched" : "— Unmatched"}
                    </div>
                  </div>
                  {viewLeave.id_hr_message && (
                    <div>
                      <div className="text-muted-foreground text-xs mb-1">HR message</div>
                      <div className="whitespace-pre-wrap rounded border p-2 bg-muted/30">{viewLeave.id_hr_message}</div>
                    </div>
                  )}
                  <div>
                    <div className="text-muted-foreground text-xs mb-1">Body note</div>
                    <div className="whitespace-pre-wrap rounded border p-2 bg-muted/30">{viewLeave.id_body_note || "—"}</div>
                  </div>
                  <div>
                    <div className="text-muted-foreground text-xs mb-1">ID photos</div>
                    {viewLeave.id_photo_1_url || viewLeave.id_photo_2_url ? (
                      <div className="flex gap-3">
                        {viewLeave.id_photo_1_url && (
                          <SelfieThumb file_url={viewLeave.id_photo_1_url} size={96} onPreview={() => setPreviewFile(viewLeave.id_photo_1_url)} />
                        )}
                        {viewLeave.id_photo_2_url && (
                          <SelfieThumb file_url={viewLeave.id_photo_2_url} size={96} onPreview={() => setPreviewFile(viewLeave.id_photo_2_url)} />
                        )}
                      </div>
                    ) : (
                      <div className="text-muted-foreground">—</div>
                    )}
                  </div>
                </>
              ) : viewLeave.doc_type === "pre_consultation" ? (
                <>
                  {/* Pre-consultation fields */}
                  <div className="grid grid-cols-2 gap-3">
                    <div><span className="text-muted-foreground">Reference:</span> {viewLeave.external_reference}</div>
                    <div><span className="text-muted-foreground">Type:</span> {docTypePill(viewLeave)}</div>
                    <div><span className="text-muted-foreground">Status:</span> {statusPill(viewLeave.status)}</div>
                    <div><span className="text-muted-foreground">Filed:</span> {fmtDateTime(viewLeave.created_at)}</div>
                    <div><span className="text-muted-foreground">Signed name:</span> {viewLeave.typed_name || "—"}</div>
                    <div><span className="text-muted-foreground">Signed date:</span> {viewLeave.signature_date || "—"}</div>
                    <div><span className="text-muted-foreground">Amount:</span> {viewLeave.pc_amount || "—"}</div>
                    <div><span className="text-muted-foreground">Duration:</span> {viewLeave.pc_duration || "—"}</div>
                    <div>
                      <span className="text-muted-foreground">Matched:</span>{" "}
                      {viewLeave.matched_response_id ? "✓ Matched" : "— Unmatched"}
                    </div>
                  </div>
                  <div>
                    <div className="text-muted-foreground text-xs mb-1">Preferred time</div>
                    <div className="whitespace-pre-wrap rounded border p-2 bg-muted/30">{viewLeave.pc_preferred_time || "—"}</div>
                  </div>
                  {viewLeave.pc_hr_message && (
                    <div>
                      <div className="text-muted-foreground text-xs mb-1">Message to recipient</div>
                      <div className="whitespace-pre-wrap rounded border p-2 bg-muted/30">{viewLeave.pc_hr_message}</div>
                    </div>
                  )}
                  <div className="rounded border p-2 bg-muted/30 text-xs" style={{ color: "#5b21b6" }}>
                    ✓ Client ticked and agreed to all 10 acknowledgment clauses (including the Arbutration Agreement) and signed.
                  </div>
                </>
              ) : viewLeave.doc_type === "cash_advance" ? (
                <>
                  {/* Cash advance fields */}
                  <div className="grid grid-cols-2 gap-3">
                    <div><span className="text-muted-foreground">Reference:</span> {viewLeave.external_reference}</div>
                    <div><span className="text-muted-foreground">Type:</span> {docTypePill(viewLeave)}</div>
                    <div><span className="text-muted-foreground">Status:</span> {statusPill(viewLeave.status)}</div>
                    <div><span className="text-muted-foreground">Filed:</span> {fmtDateTime(viewLeave.created_at)}</div>
                    <div><span className="text-muted-foreground">Signed name:</span> {viewLeave.typed_name || "—"}</div>
                    <div><span className="text-muted-foreground">Signed date:</span> {viewLeave.signature_date || "—"}</div>
                    <div>
                      <span className="text-muted-foreground">Matched:</span>{" "}
                      {viewLeave.matched_response_id ? "✓ Matched" : "— Unmatched"}
                    </div>
                  </div>
                  <div>
                    <div className="text-muted-foreground text-xs mb-1">Amount Requested</div>
                    <div className="whitespace-pre-wrap rounded border p-2 bg-muted/30">{viewLeave.ca_amount || "—"}</div>
                  </div>
                  <div>
                    <div className="text-muted-foreground text-xs mb-1">Reason for Request</div>
                    <div className="whitespace-pre-wrap rounded border p-2 bg-muted/30">{viewLeave.ca_reason || "—"}</div>
                  </div>
                  <div>
                    <div className="text-muted-foreground text-xs mb-1">Repayment / Deduction Method</div>
                    <div className="whitespace-pre-wrap rounded border p-2 bg-muted/30">{viewLeave.ca_repayment_method || "—"}</div>
                  </div>
                </>
              ) : (
                <>
                  {/* Leave fields */}
                  <div className="grid grid-cols-2 gap-3">
                    <div><span className="text-muted-foreground">Reference:</span> {viewLeave.external_reference}</div>
                    <div><span className="text-muted-foreground">Type:</span> {docTypePill(viewLeave)}</div>
                    <div><span className="text-muted-foreground">Status:</span> {statusPill(viewLeave.status)}</div>
                    <div><span className="text-muted-foreground">Filed:</span> {fmtDateTime(viewLeave.created_at)}</div>
                    <div><span className="text-muted-foreground">Start date:</span> {viewLeave.start_date || "—"}</div>
                    <div><span className="text-muted-foreground">Days:</span> {viewLeave.num_days || "—"}</div>
                    <div><span className="text-muted-foreground">Hours missed:</span> {viewLeave.hours_missed || "—"}</div>
                    <div><span className="text-muted-foreground">Make-up:</span> {viewLeave.makeup_choice || "—"}</div>
                    <div><span className="text-muted-foreground">Coverer:</span> {viewLeave.coverer_name || "—"}</div>
                    <div><span className="text-muted-foreground">Agreed w/ coverer:</span> {viewLeave.agreed_with_coverer ? "Yes" : "No"}</div>
                    <div><span className="text-muted-foreground">Trained coverer:</span> {viewLeave.trained_coverer ? "Yes" : "No"}</div>
                    <div><span className="text-muted-foreground">Signed:</span> {viewLeave.signature_date || "—"}</div>
                  </div>
                  <div>
                    <div className="text-muted-foreground text-xs mb-1">Reason</div>
                    <div className="whitespace-pre-wrap rounded border p-2 bg-muted/30">{viewLeave.reason || "—"}</div>
                  </div>
                  {viewLeave.makeup_plan && (
                    <div>
                      <div className="text-muted-foreground text-xs mb-1">Make-up plan</div>
                      <div className="whitespace-pre-wrap rounded border p-2 bg-muted/30">{viewLeave.makeup_plan}</div>
                    </div>
                  )}
                </>
              )}

              {viewLeave.hr_decision_note && (
                <div>
                  <div className="text-muted-foreground text-xs mb-1">HR decision note</div>
                  <div className="whitespace-pre-wrap rounded border p-2 bg-muted/30">{viewLeave.hr_decision_note}</div>
                </div>
              )}
              {viewLeave.signed_pdf_url && (
                <Button asChild variant="outline" size="sm">
                  <a href={viewLeave.signed_pdf_url} target="_blank" rel="noreferrer">
                    <ExternalLink className="h-4 w-4 mr-1.5" /> Open signed PDF
                  </a>
                </Button>
              )}
              </div>

              {/* Approve / decline — only for pending rows. Branches by doc_type. */}
              {viewLeave.status === "pending_approval" && (
                <div className="shrink-0 border-t pt-3 space-y-2">
                  <div className="text-muted-foreground text-xs">Decision note (optional)</div>
                  <Textarea
                    value={decideNote}
                    onChange={(e) => setDecideNote(e.target.value)}
                    placeholder="Add an optional note for the employee…"
                    rows={2}
                  />
                  <div className="flex gap-2">
                    <Button
                      size="sm"
                      className="bg-green-600 hover:bg-green-700 text-white"
                      disabled={!!decideBusy}
                      onClick={() => decide(viewLeave, "approved")}
                    >
                      {decideBusy === "approved" ? "Approving…" : "Approve"}
                    </Button>
                    <Button
                      size="sm"
                      variant="destructive"
                      disabled={!!decideBusy}
                      onClick={() => decide(viewLeave, "declined")}
                    >
                      {decideBusy === "declined" ? "Declining…" : "Decline"}
                    </Button>
                  </div>
                </div>
              )}
            </>
          )}
        </DialogContent>
      </Dialog>

      <FilePreviewDialog file_url={previewFile} onClose={() => setPreviewFile(null)} />

      <AlertDialog open={confirmDeleteId !== null} onOpenChange={(o) => { if (!o) setConfirmDeleteId(null); }}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete this record permanently?</AlertDialogTitle>
            <AlertDialogDescription>
              This cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={deleting}>Cancel</AlertDialogCancel>
            <AlertDialogAction
              className="bg-red-600 hover:bg-red-700"
              disabled={deleting}
              onClick={(e) => { e.preventDefault(); if (confirmDeleteId) handleDelete(confirmDeleteId); }}
            >
              {deleting ? "Deleting…" : "Delete"}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
