import { useEffect, useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { toast } from "@/hooks/use-toast";
import { ArrowLeft, FileText, ExternalLink, ChevronDown, ChevronUp, Trash2 } from "lucide-react";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";

type Circular = {
  id: string;
  title: string | null;
  body: string | null;
  recipient_count: number;
  created_at: string;
};

type Signature = {
  id: string;
  signer_name: string | null;
  signer_email: string | null;
  status: string;
  sent_at: string;
  signed_at: string | null;
  understanding_text: string | null;
  signed_pdf_url: string | null;
};

export default function CircularsList() {
  const navigate = useNavigate();
  const [circulars, setCirculars] = useState<Circular[]>([]);
  const [signatures, setSignatures] = useState<Signature[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [expandedUnderstanding, setExpandedUnderstanding] = useState<Record<string, boolean>>({});
  const [confirmDeleteId, setConfirmDeleteId] = useState<string | null>(null);
  const [deleting, setDeleting] = useState(false);

  // Single-row delete by id: remove child circular_signatures first, then the circular row.
  const handleDelete = async (circularId: string) => {
    setDeleting(true);
    try {
      const { error: childErr } = await supabase
        .from("circular_signatures" as any)
        .delete()
        .eq("circular_id", circularId);
      if (childErr) throw childErr;
      const { error: parentErr } = await supabase
        .from("circulars" as any)
        .delete()
        .eq("id", circularId);
      if (parentErr) throw parentErr;
      setCirculars((prev) => prev.filter((c) => c.id !== circularId));
      setSignatures((prev) => (prev as any).filter((s: any) => s.circular_id !== circularId));
      toast({ title: "Circular deleted" });
      setConfirmDeleteId(null);
    } catch (e: any) {
      toast({ title: "Failed to delete circular", description: e.message, variant: "destructive" });
    } finally {
      setDeleting(false);
    }
  };

  const load = async () => {
    setLoading(true);
    const [{ data: circs, error: circErr }, { data: sigs, error: sigErr }] = await Promise.all([
      supabase
        .from("circulars" as any)
        .select("id, title, body, recipient_count, created_at")
        .order("created_at", { ascending: false }),
      supabase
        .from("circular_signatures" as any)
        .select("id, circular_id, signer_name, signer_email, status, sent_at, signed_at, understanding_text, signed_pdf_url"),
    ]);

    if (circErr) {
      toast({ title: "Failed to load circulars", description: circErr.message, variant: "destructive" });
    } else {
      setCirculars((circs as any as Circular[]) || []);
    }
    if (sigErr) {
      toast({ title: "Failed to load signatures", description: sigErr.message, variant: "destructive" });
    } else {
      setSignatures((sigs as any as (Signature & { circular_id: string })[]) || []);
    }
    setLoading(false);
  };

  useEffect(() => { load(); }, []);

  const signaturesByCircular = useMemo(() => {
    const map: Record<string, Signature[]> = {};
    (signatures as any).forEach((s: Signature & { circular_id: string }) => {
      if (!map[s.circular_id]) map[s.circular_id] = [];
      map[s.circular_id].push(s);
    });
    return map;
  }, [signatures]);

  const selectedCircular = useMemo(
    () => circulars.find((c) => c.id === selectedId) || null,
    [circulars, selectedId],
  );

  const selectedSigs = useMemo(
    () => (selectedId ? signaturesByCircular[selectedId] || [] : []),
    [selectedId, signaturesByCircular],
  );

  const fmtDate = (v: string | null) =>
    v ? new Date(v).toLocaleDateString(undefined, { year: "numeric", month: "short", day: "numeric", hour: "2-digit", minute: "2-digit" }) : "—";

  const signedCount = (cid: string) =>
    (signaturesByCircular[cid] || []).filter((s) => s.status === "signed").length;

  if (selectedCircular) {
    return (
      <div className="min-h-screen bg-background">
        <div className="max-w-5xl mx-auto px-4 py-6 space-y-6">
          <div className="flex items-center gap-3">
            <Button variant="ghost" size="sm" onClick={() => setSelectedId(null)}>
              <ArrowLeft className="h-4 w-4 mr-1.5" /> Back to list
            </Button>
            <div className="flex items-center gap-2">
              <FileText className="h-5 w-5 text-primary" />
              <h1 className="text-xl font-semibold">Circular Detail</h1>
            </div>
          </div>

          <Card className="p-6 space-y-4">
            <div>
              <h2 className="text-lg font-semibold">{selectedCircular.title || "Untitled Circular"}</h2>
              <p className="text-sm text-muted-foreground mt-1">
                Sent {selectedCircular.recipient_count} recipient{selectedCircular.recipient_count === 1 ? "" : "s"} · {fmtDate(selectedCircular.created_at)}
              </p>
            </div>
            {selectedCircular.body && (
              <div className="bg-muted/50 rounded-lg p-4 text-sm whitespace-pre-wrap leading-relaxed">
                {selectedCircular.body}
              </div>
            )}
          </Card>

          <div className="space-y-3">
            <h3 className="text-base font-semibold">Recipients</h3>
            <Card>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Name</TableHead>
                    <TableHead>Email</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Sent</TableHead>
                    <TableHead>Signed</TableHead>
                    <TableHead>Understanding</TableHead>
                    <TableHead>Signed PDF</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {selectedSigs.length === 0 ? (
                    <TableRow>
                      <TableCell colSpan={7} className="text-center text-muted-foreground py-8">
                        No recipients found for this circular.
                      </TableCell>
                    </TableRow>
                  ) : (
                    selectedSigs.map((s) => {
                      const isExpanded = !!expandedUnderstanding[s.id];
                      const text = s.understanding_text || "";
                      const shouldTruncate = text.length > 200;
                      const displayText = shouldTruncate && !isExpanded ? text.slice(0, 200) + "…" : text;
                      return (
                        <TableRow key={s.id}>
                          <TableCell className="font-medium">{s.signer_name || "—"}</TableCell>
                          <TableCell className="font-mono text-sm">{s.signer_email || "—"}</TableCell>
                          <TableCell>
                            {s.status === "signed" ? (
                              <Badge className="bg-green-100 text-green-800 hover:bg-green-100 border-0">Signed</Badge>
                            ) : (
                              <Badge variant="secondary">Sent</Badge>
                            )}
                          </TableCell>
                          <TableCell className="text-muted-foreground text-sm">{fmtDate(s.sent_at)}</TableCell>
                          <TableCell className="text-muted-foreground text-sm">{fmtDate(s.signed_at)}</TableCell>
                          <TableCell className="max-w-md">
                            {text ? (
                              <div className="text-sm">
                                <span className="whitespace-pre-wrap">{displayText}</span>
                                {shouldTruncate && (
                                  <Button
                                    variant="ghost"
                                    size="sm"
                                    className="h-auto p-0 ml-1 text-primary inline-flex items-center"
                                    onClick={() =>
                                      setExpandedUnderstanding((prev) => ({
                                        ...prev,
                                        [s.id]: !prev[s.id],
                                      }))
                                    }
                                  >
                                    {isExpanded ? (
                                      <><ChevronUp className="h-3 w-3 mr-0.5" /> Show less</>
                                    ) : (
                                      <><ChevronDown className="h-3 w-3 mr-0.5" /> Show more</>
                                    )}
                                  </Button>
                                )}
                              </div>
                            ) : (
                              <span className="text-muted-foreground text-sm">—</span>
                            )}
                          </TableCell>
                          <TableCell>
                            {s.signed_pdf_url ? (
                              <a
                                href={s.signed_pdf_url}
                                target="_blank"
                                rel="noopener noreferrer"
                                className="inline-flex items-center gap-1 text-sm text-primary hover:underline"
                              >
                                <ExternalLink className="h-3.5 w-3.5" /> View
                              </a>
                            ) : (
                              <span className="text-muted-foreground text-sm">—</span>
                            )}
                          </TableCell>
                        </TableRow>
                      );
                    })
                  )}
                </TableBody>
              </Table>
            </Card>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <div className="max-w-4xl mx-auto px-4 py-6 space-y-6">
        <div className="flex items-center gap-3">
          <Button variant="ghost" size="sm" onClick={() => navigate("/dashboard")}>
            <ArrowLeft className="h-4 w-4 mr-1.5" /> Back
          </Button>
          <div className="flex items-center gap-2">
            <FileText className="h-5 w-5 text-primary" />
            <h1 className="text-xl font-semibold">Circulars</h1>
          </div>
        </div>

        <p className="text-sm text-muted-foreground">
          Review all Circular Notices sent, check signing progress, and read each recipient’s understanding summary.
        </p>

        {loading ? (
          <div className="text-center text-muted-foreground py-12">Loading…</div>
        ) : circulars.length === 0 ? (
          <Card className="p-12 text-center space-y-3">
            <div className="mx-auto h-14 w-14 rounded-full bg-secondary flex items-center justify-center">
              <FileText className="h-6 w-6 text-muted-foreground" />
            </div>
            <h3 className="text-lg font-semibold">No circulars yet</h3>
            <p className="text-sm text-muted-foreground">
              Send your first Circular Notice from the Recipients page.
            </p>
            <Button size="sm" onClick={() => navigate("/dashboard/circular-recipients")}>
              Go to Circular Recipients
            </Button>
          </Card>
        ) : (
          <div className="space-y-3">
            {circulars.map((c) => {
              const signed = signedCount(c.id);
              const total = c.recipient_count;
              return (
                <Card
                  key={c.id}
                  className="p-5 cursor-pointer transition-all hover:border-foreground/30 hover:shadow-sm"
                  onClick={() => setSelectedId(c.id)}
                >
                  <div className="flex items-start justify-between gap-4">
                    <div className="space-y-1 min-w-0">
                      <h3 className="text-base font-semibold truncate">{c.title || "Untitled Circular"}</h3>
                      <p className="text-xs text-muted-foreground">
                        {fmtDate(c.created_at)} · {total} recipient{total === 1 ? "" : "s"}
                      </p>
                    </div>
                    <div className="flex items-center gap-3 shrink-0">
                      <div className="text-right">
                        <div className="text-sm font-medium">
                          {signed} of {total} signed
                        </div>
                        <div className="w-32 h-2 bg-muted rounded-full mt-1 overflow-hidden">
                          <div
                            className="h-full bg-primary rounded-full transition-all"
                            style={{ width: total > 0 ? `${(signed / total) * 100}%` : "0%" }}
                          />
                        </div>
                      </div>
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-9 w-9 text-red-600 hover:text-red-700 hover:bg-red-50 border border-red-200"
                        onClick={(e) => { e.stopPropagation(); setConfirmDeleteId(c.id); }}
                        aria-label="Delete circular"
                      >
                        <Trash2 className="h-5 w-5" />
                      </Button>
                      <ArrowLeft className="h-4 w-4 text-muted-foreground rotate-180" />
                    </div>
                  </div>
                </Card>
              );
            })}
          </div>
        )}
      </div>

      <AlertDialog open={confirmDeleteId !== null} onOpenChange={(o) => { if (!o) setConfirmDeleteId(null); }}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete this circular?</AlertDialogTitle>
            <AlertDialogDescription>
              This permanently removes the circular and all of its recipient signature records. This cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={deleting}>Cancel</AlertDialogCancel>
            <AlertDialogAction
              className="bg-red-600 hover:bg-red-700"
              disabled={deleting}
              onClick={(e) => { e.preventDefault(); if (confirmDeleteId) handleDelete(confirmDeleteId); }}
            >
              {deleting ? "Deleting…" : "Delete"}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
