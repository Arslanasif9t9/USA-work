// Public candidate-facing tracking page. Token-gated via validate-tracking-token.
// EIA-branded, warm copy. Never blames the candidate. No internal data exposed.
import { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { BRAND } from "@/config/brand";

type TrackPayload = {
  valid: boolean;
  reason?: string;
  round_stage?: string | null;
  position_title?: string | null;
  first_name?: string | null;
};

type StatusKey =
  | "in_review"
  | "round_1_sent"
  | "ai_interview_completed"
  | "round_2_sent"
  | "offer_sent"
  | "offer_signed"
  | "offer_expired"
  | "filled";

const COPY: Record<StatusKey, { headline: string; body: string; accent?: string }> = {
  in_review: {
    headline: "Your application is being reviewed",
    body: "Thank you for applying. Our team is reviewing your application carefully. We'll update you here as soon as there's news.",
  },
  round_1_sent: {
    headline: "Your interview invitation is on its way",
    body: "We've received your application and your interview invitation has been sent. Please check your email — including spam — for next steps.",
  },
  ai_interview_completed: {
    headline: "Thank you for completing your interview",
    body: "We've received your interview and our team is reviewing it now. You'll hear from us within 5-7 business days. Please keep this link — we'll update it here as soon as there's news.",
    accent: "Under review",
  },
  round_2_sent: {
    headline: "Great progress — you've advanced to the next stage",
    body: "Congratulations on moving forward. Details for the next conversation are on their way to your inbox.",
    accent: "Advanced",
  },
  offer_sent: {
    headline: "Good news is on its way",
    body: "Please check your email for an important update from our team.",
    accent: "Offer in progress",
  },
  offer_signed: {
    headline: "Welcome aboard — we're excited to have you",
    body: "Thank you for accepting. Our team will be in touch with the next steps shortly.",
    accent: "Welcome",
  },
  offer_expired: {
    headline: "Your offer window has closed",
    body: "If you're still interested in joining us, you're warmly welcome to reach out or reapply for a future opening.",
  },
  filled: {
    headline: "Thank you for your interest",
    body: "This position has already been filled. We genuinely encourage you to apply again for future openings — we'd love to consider you for the right role.",
  },
};

function mapStage(stage: string | null | undefined): StatusKey {
  switch (stage) {
    case "round_1_sent": return "round_1_sent";
    case "ai_interview_completed": return "ai_interview_completed";
    case "round_2_sent": return "round_2_sent";
    case "offer_sent": return "offer_sent";
    case "offer_signed": return "offer_signed";
    case "offer_expired": return "offer_expired";
    case "disqualified": return "filled";
    case "terminated": return "filled";
    default: return "in_review";
  }
}

const Track = () => {
  const { token } = useParams<{ token: string }>();
  const [state, setState] = useState<"loading" | "valid" | "invalid">("loading");
  const [data, setData] = useState<TrackPayload | null>(null);
  const [lastUpdated, setLastUpdated] = useState<Date | null>(null);

  useEffect(() => {
    let cancelled = false;
    async function load() {
      if (!token) { setState("invalid"); return; }
      try {
        const { data: resp, error } = await supabase.functions.invoke("validate-tracking-token", {
          body: { token },
        });
        if (cancelled) return;
        if (error || !resp || !resp.valid) {
          setState("invalid");
        } else {
          setData(resp as TrackPayload);
          setLastUpdated(new Date());
          setState("valid");
        }
      } catch {
        if (!cancelled) setState("invalid");
      }
    }
    load();
    return () => { cancelled = true; };
  }, [token]);

  const c = BRAND.colors;

  const Shell = ({ children }: { children: React.ReactNode }) => (
    <div
      style={{
        minHeight: "100vh",
        background: c.cream,
        color: c.navy,
        fontFamily: "Inter, system-ui, -apple-system, sans-serif",
        padding: "32px 20px",
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
      }}
    >
      <header style={{ maxWidth: 640, width: "100%", marginBottom: 36 }}>
        {BRAND.logoUrl ? (
          <img src={BRAND.logoUrl} alt={BRAND.companyShortName} style={{ height: 28 }} />
        ) : (
          <div
            style={{
              fontFamily: "'Cormorant Garamond', Georgia, serif",
              fontWeight: 600,
              letterSpacing: "0.18em",
              fontSize: 22,
              color: c.navy,
            }}
          >
            {BRAND.wordmarkText}
          </div>
        )}
        <div style={{ height: 1, background: c.rule, marginTop: 14 }} />
      </header>
      <main style={{ maxWidth: 640, width: "100%" }}>{children}</main>
      <footer
        style={{
          maxWidth: 640,
          width: "100%",
          marginTop: 48,
          paddingTop: 20,
          borderTop: `1px solid ${c.rule}`,
          fontSize: 12,
          color: "#7a7563",
          textAlign: "center",
        }}
      >
        {BRAND.companyName}
      </footer>
    </div>
  );

  if (state === "loading") {
    return (
      <Shell>
        <div
          aria-busy="true"
          style={{ color: "#7a7563", fontSize: 14, textAlign: "center", padding: "40px 0" }}
        >
          Loading…
        </div>
      </Shell>
    );
  }

  if (state === "invalid") {
    return (
      <Shell>
        <h1
          style={{
            fontFamily: "'Cormorant Garamond', Georgia, serif",
            fontWeight: 500,
            fontSize: 32,
            lineHeight: 1.2,
            margin: "8px 0 14px",
            color: c.navy,
          }}
        >
          This tracking link is no longer available
        </h1>
        <p style={{ fontSize: 16, lineHeight: 1.65, color: "#3d4458", margin: 0 }}>
          If you believe this is a mistake, please reply to the most recent email from our team and
          we'll be glad to help.
        </p>
      </Shell>
    );
  }

  const key = mapStage(data?.round_stage);
  const copy = COPY[key];
  const greeting = data?.first_name ? `Hi ${data.first_name},` : "Hi there,";

  return (
    <Shell>
      <div style={{ color: c.gold, fontSize: 12, letterSpacing: "0.18em", textTransform: "uppercase", marginBottom: 12 }}>
        Application status
      </div>
      {data?.position_title && (
        <div
          style={{
            fontFamily: "'Cormorant Garamond', Georgia, serif",
            fontWeight: 500,
            fontSize: 20,
            color: c.navy,
            marginBottom: 4,
          }}
        >
          {data.position_title}
        </div>
      )}
      <h1
        style={{
          fontFamily: "'Cormorant Garamond', Georgia, serif",
          fontWeight: 500,
          fontSize: 34,
          lineHeight: 1.2,
          margin: "10px 0 18px",
          color: c.navy,
        }}
      >
        {copy.headline}
      </h1>
      <p style={{ fontSize: 16, lineHeight: 1.7, color: "#3d4458", margin: "0 0 8px" }}>
        {greeting}
      </p>
      <p style={{ fontSize: 16, lineHeight: 1.7, color: "#3d4458", margin: 0 }}>
        {copy.body}
      </p>

      {copy.accent && (
        <div
          style={{
            marginTop: 28,
            display: "inline-block",
            padding: "6px 14px",
            border: `1px solid ${c.gold}`,
            color: c.gold,
            fontSize: 11,
            letterSpacing: "0.16em",
            textTransform: "uppercase",
            borderRadius: 999,
          }}
        >
          {copy.accent}
        </div>
      )}

      {lastUpdated && (
        <div style={{ marginTop: 36, fontSize: 12, color: "#9a9586" }}>
          Last refreshed{" "}
          {lastUpdated.toLocaleString(undefined, {
            month: "short",
            day: "numeric",
            hour: "numeric",
            minute: "2-digit",
          })}
        </div>
      )}
    </Shell>
  );
};

export default Track;
