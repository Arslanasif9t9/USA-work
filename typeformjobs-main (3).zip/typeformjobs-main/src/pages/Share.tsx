import { useEffect, useState } from "react";
import { useParams, Navigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import FormTopBar, { useFormHeader } from "@/components/FormTopBar";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";
import { Copy, Loader2 } from "lucide-react";
import { getPublicFormUrl } from "@/lib/publicUrl";

const SLUG_REGEX = /^[a-z0-9-]+$/;

const Share = () => {
  const { id } = useParams<{ id: string }>();
  if (!id) return <Navigate to="/dashboard" replace />;
  const { form, refresh } = useFormHeader(id);
  const [publishing, setPublishing] = useState(false);
  const [slugVal, setSlugVal] = useState("");
  const [slugError, setSlugError] = useState<string | null>(null);
  const [savingSlug, setSavingSlug] = useState(false);

  useEffect(() => {
    if (form) setSlugVal(form.slug);
  }, [form?.id]);

  if (!form) {
    return <div className="min-h-screen flex items-center justify-center" aria-busy="true"><Loader2 className="h-6 w-6 text-muted-foreground animate-spin" /></div>;
  }

  const url = getPublicFormUrl(form.slug);

  const publish = async () => {
    setPublishing(true);
    const { error } = await supabase.from("forms").update({ status: "live" }).eq("id", form.id);
    setPublishing(false);
    if (error) return toast.error(error.message);
    toast.success("Form is now live.");
    refresh();
  };

  const copy = async () => {
    await navigator.clipboard.writeText(url);
    toast.success("Copied!", { duration: 2000 });
  };

  const saveSlug = async () => {
    const slug = slugVal.trim();
    if (!slug) return setSlugError("Slug cannot be empty.");
    if (!SLUG_REGEX.test(slug))
      return setSlugError("Slug can only contain lowercase letters, numbers, and hyphens.");
    setSavingSlug(true);
    const { data: exists } = await supabase
      .from("forms")
      .select("id")
      .eq("slug", slug)
      .maybeSingle();
    if (exists && exists.id !== form.id) {
      setSavingSlug(false);
      return setSlugError("This slug is already taken. Please choose another.");
    }
    const { error } = await supabase.from("forms").update({ slug }).eq("id", form.id);
    setSavingSlug(false);
    if (error) return toast.error(error.message);
    setSlugError(null);
    toast.success("URL updated");
    refresh();
  };

  const slugDirty = slugVal !== form.slug;

  return (
    <div className="min-h-screen flex flex-col bg-background">
      <FormTopBar form={form} onChange={refresh} active="share" />
      <main className="flex-1 max-w-2xl w-full mx-auto px-6 py-12">
        <h1 className="text-2xl font-bold mb-6">Share your form</h1>

        {form.status === "draft" ? (
          <div className="border border-border rounded-lg p-6 bg-secondary/30">
            <p className="text-sm text-foreground mb-4">
              This form is in draft. Publish it to start collecting responses.
            </p>
            <Button onClick={publish} disabled={publishing}>
              {publishing ? (<><Loader2 className="h-4 w-4 mr-2 animate-spin" /> Publishing...</>) : "Publish Form"}
            </Button>
          </div>
        ) : (
          <div className="space-y-6">
            <div>
              <Label className="text-sm mb-2 block">Form link</Label>
              <div className="flex items-center gap-2">
                <Input
                  value={url}
                  readOnly
                  onFocus={(e) => e.currentTarget.select()}
                  className="flex-1 font-mono text-sm"
                  style={{ color: "#1a2547", borderColor: "#e1e4ec" }}
                />
                <Button onClick={copy} style={{ backgroundColor: "#1a2547" }} className="text-white shrink-0">
                  <Copy className="h-4 w-4 mr-2" /> Copy
                </Button>
              </div>
            </div>

            <div className="space-y-2">
              <Label className="text-sm">Custom URL slug</Label>
              <div className="flex gap-2">
                <Input value={slugVal} onChange={(e) => setSlugVal(e.target.value)} />
                <Button onClick={saveSlug} disabled={!slugDirty || savingSlug}>
                  {savingSlug ? (<><Loader2 className="h-4 w-4 mr-2 animate-spin" /> Saving...</>) : "Save"}
                </Button>
              </div>
              <p className="text-xs text-muted-foreground">
                Only lowercase letters, numbers, and hyphens
              </p>
              {slugError && <p className="text-xs text-destructive">{slugError}</p>}
            </div>

            <p className="text-sm text-muted-foreground">
              Share this link with candidates. They don't need an account.
            </p>
          </div>
        )}
      </main>
    </div>
  );
};

export default Share;
