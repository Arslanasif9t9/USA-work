import { useCallback, useEffect, useMemo, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { ArrowLeft, Check, X, Video, FileText as FileIcon, Sparkles, MessageSquare, MapPin } from "lucide-react";
import { detectContactQuestionIds, type CandidateAction } from "@/lib/candidateActions";
import { cleanPositionTitle } from "@/lib/positionTitle";
import { SelfieThumb, FilePreviewDialog } from "@/components/FilePreview";
import { DisqualifyButton } from "@/components/DisqualifyButton";
import { InvalidateRoundsButton } from "@/components/InvalidateRoundsButton";
import { SendRound2Button } from "@/components/SendRound2Button";
import { SendOfferButton } from "@/components/SendOfferButton";
import { RecoverInterviewButton } from "@/components/RecoverInterviewButton";
import { RescueCandidateButton } from "@/components/RescueCandidateButton";
import { InvolveHumanButton } from "@/components/InvolveHumanButton";
import { SendCustomMessageDialog } from "@/components/SendCustomMessageDialog";
import { InterviewVideoDialog } from "@/components/InterviewVideoDialog";

type Session = {
  id: string;
  response_id: string | null;
  retell_call_id: string | null;
  stage: string | null;
  ended_at: string | null;
  duration_seconds: number | null;
  termination_reason: string | null;
  transcript: any;
  video_url: string | null;
  merged_video_url: string | null;
  created_at: string;
};
type Evaluation = {
  id: string;
  session_id: string;
  response_id: string | null;
  tier: string | null;
  ai_recommended: boolean | null;
  verdict: string | null;
  summary: string | null;
  red_flags: string | null;
  sentiment: string | null;
  hunger: string | null;
  availability: string | null;
};

const TIER_COLOR: Record<string, string> = {
  "best one": "bg-emerald-100 text-emerald-800",
  "breadwinner": "bg-sky-100 text-sky-800",
  "steady": "bg-blue-100 text-blue-800",
  "edgy": "bg-amber-100 text-amber-800",
  "red flag": "bg-rose-100 text-rose-800",
};
const tierClass = (t: string | null | undefined) =>
  TIER_COLOR[(t || "").toLowerCase().trim()] || "bg-slate-100 text-slate-700";

const fmtDuration = (s: number | null | undefined) => {
  if (!s || s <= 0) return "—";
  const m = Math.floor(s / 60);
  const r = s % 60;
  return m > 0 ? `${m}m ${r}s` : `${r}s`;
};
const fmtDate = (iso: string | null | undefined) => {
  if (!iso) return "—";
  try {
    return new Date(iso).toLocaleString("en-US", {
      month: "short", day: "numeric", year: "numeric",
      hour: "numeric", minute: "2-digit",
    });
  } catch { return "—"; }
};
const isFailedSession = (s: Session | null) => {
  if (!s) return false;
  const r = (s.termination_reason || "").toLowerCase();
  return r.includes("user_not_joined") || r.includes("not_joined") || r.startsWith("error_");
};

// (WebVTT caption generation now lives in the shared InterviewVideoDialog.)

// Parse Retell-style transcript jsonb into a list of {role, content}
const parseTranscript = (t: any): Array<{ role: string; content: string }> => {
  if (!t) return [];
  if (Array.isArray(t)) {
    return t
      .map((m: any) => ({
        role: String(m?.role || m?.speaker || "agent"),
        content: String(m?.content || m?.text || m?.message || "").trim(),
      }))
      .filter((m) => m.content.length > 0);
  }
  if (typeof t === "object" && Array.isArray((t as any).messages)) return parseTranscript((t as any).messages);
  if (typeof t === "string") {
    return t.split(/\r?\n/).filter(Boolean).map((line) => ({ role: "transcript", content: line }));
  }
  return [];
};

const Field = ({ label, value }: { label: string; value: React.ReactNode }) => (
  <div className="space-y-1">
    <div className="text-xs uppercase tracking-wide text-muted-foreground font-medium">{label}</div>
    <div className="text-sm text-foreground whitespace-pre-wrap">{value}</div>
  </div>
);

const AiInterviewReport = () => {
  const navigate = useNavigate();
  const { responseId, round } = useParams<{ responseId: string; round?: string }>();
  // Round the user opened: "R2" → Round 2 (Marissa); anything else (incl. undefined) → R1 (Christine).
  const resolvedRound: "R1" | "R2" = round === "R2" ? "R2" : "R1";
  const [loading, setLoading] = useState(true);
  const [notFound, setNotFound] = useState(false);


  const [session, setSession] = useState<Session | null>(null);
  const [evaluation, setEvaluation] = useState<Evaluation | null>(null);
  const [candidateName, setCandidateName] = useState<string>("—");
  const [candidateEmail, setCandidateEmail] = useState<string>("");
  const [positionTitle, setPositionTitle] = useState<string>("—");
  const [formId, setFormId] = useState<string | null>(null);
  const [roundStage, setRoundStage] = useState<string | null>(null);
  const [selfieUrl, setSelfieUrl] = useState<string | null>(null);
  const [resumeUrl, setResumeUrl] = useState<string | null>(null);
  const [action, setAction] = useState<CandidateAction | null>(null);
  const [nameQid, setNameQid] = useState<string | undefined>();
  const [emailQid, setEmailQid] = useState<string | undefined>();

  const [previewFile, setPreviewFile] = useState<string | null>(null);
  const [customMsgOpen, setCustomMsgOpen] = useState(false);



  const load = useCallback(async () => {
    if (!responseId) return;
    setLoading(true);
    setNotFound(false);

    // Newest healthy session for this response_id WITHIN the round the user opened.
    const roundStages = resolvedRound === "R2" ? ["round2_ai", "round2"] : ["round1", "ai_scheduled"];
    const { data: ss } = await supabase
      .from("ai_interview_sessions")
      .select("id, response_id, retell_call_id, stage, ended_at, duration_seconds, termination_reason, transcript, video_url, merged_video_url, created_at")
      .eq("response_id", responseId)
      .in("stage", roundStages)
      .order("created_at", { ascending: false })
      .limit(1);
    const latestSession = (ss && ss[0]) as Session | undefined;

    if (!latestSession) {
      setNotFound(true);
      setLoading(false);
      return;
    }
    setSession(latestSession);

    const [evalRes, respRes, extrasRes] = await Promise.all([
      supabase.from("ai_interview_evaluations")
        .select("id, session_id, response_id, tier, ai_recommended, verdict, summary, red_flags, sentiment, hunger, availability")
        .eq("session_id", latestSession.id)
        .order("created_at", { ascending: false })
        .limit(1),
      supabase.from("responses")
        .select("id, form_id, round_stage, override_email")
        .eq("id", responseId)
        .maybeSingle(),
      supabase.from("hr_candidate_extras")
        .select("photo_file_url")
        .eq("response_id", responseId)
        .maybeSingle(),
    ]);

    setEvaluation((evalRes.data && (evalRes.data as any)[0]) || null);
    const resp = (respRes as any).data;
    const extras = (extrasRes as any).data;
    setRoundStage(resp?.round_stage || null);

    if (resp?.form_id) {
      setFormId(resp.form_id);
      const [formRes, metaRes, qRes] = await Promise.all([
        supabase.from("forms").select("title").eq("id", resp.form_id).maybeSingle(),
        supabase.from("form_metadata").select("position_title").eq("form_id", resp.form_id).maybeSingle(),
        supabase.from("questions").select("id, type, label, order_index").eq("form_id", resp.form_id),
      ]);
      const fTitle = (formRes as any).data?.title || "";
      const pTitle = (metaRes as any).data?.position_title || "";
      setPositionTitle(cleanPositionTitle(pTitle || fTitle) || "—");

      const qs = ((qRes as any).data || []) as Array<{ id: string; type: string; label: string; order_index?: number }>;
      const contacts = detectContactQuestionIds(qs);
      setNameQid(contacts.nameQid);
      setEmailQid(contacts.emailQid);

      const PHOTO_RE = /(photo|selfie|picture|headshot|portrait|image)/i;
      const RESUME_RE = /(resume|cv|curriculum)/i;
      const sorted = [...qs].sort((a, b) => (a.order_index || 0) - (b.order_index || 0));
      const uploads = sorted.filter((q) => q.type === "file_upload" || q.type === "selfie");
      const selfieQ = uploads.find((q) => q.type === "selfie") || uploads.find((q) => PHOTO_RE.test(q.label || ""));
      const resumeQ = uploads.find((q) => RESUME_RE.test(q.label || ""));

      const wantedQids = [contacts.nameQid, contacts.emailQid, selfieQ?.id, resumeQ?.id].filter(Boolean) as string[];
      if (wantedQids.length) {
        const { data: ans } = await supabase
          .from("answers")
          .select("question_id, answer_text, file_url")
          .eq("response_id", responseId)
          .in("question_id", wantedQids);
        const get = (qid?: string) => (ans || []).find((a: any) => a.question_id === qid);
        const nameA = get(contacts.nameQid);
        const emailA = get(contacts.emailQid);
        const selfieA = get(selfieQ?.id);
        const resumeA = get(resumeQ?.id);
        setCandidateName(((nameA as any)?.answer_text || "").trim() || "Direct Link Candidate");
        setCandidateEmail((resp.override_email || (emailA as any)?.answer_text || "").trim());
        setSelfieUrl((selfieA as any)?.file_url || extras?.photo_file_url || null);
        setResumeUrl((resumeA as any)?.file_url || null);
      } else {
        setCandidateName("Direct Link Candidate");
        setSelfieUrl(extras?.photo_file_url || null);
      }

      // Fetch candidate_actions for stage-gated action buttons
      const { data: caRow } = await supabase
        .from("candidate_actions")
        .select("*")
        .eq("response_id", responseId)
        .maybeSingle();
      setAction((caRow as any) || null);
    }

    setLoading(false);
  }, [responseId, resolvedRound]);

  useEffect(() => { document.title = "Scout Report — EIA"; load(); }, [load]);

  const failed = useMemo(
    () => isFailedSession(session) || (!evaluation || (!evaluation.tier && !evaluation.verdict && evaluation.ai_recommended === null && !evaluation.summary)),
    [session, evaluation],
  );

  const transcript = useMemo(() => parseTranscript(session?.transcript), [session?.transcript]);

  // Derive the interview round from the session stage (same mapping as the
  // Scout list button in AiInterviews.tsx) so the inside video button routes
  // through InterviewVideoDialog's shared round-aware healthiest-video resolver.
  // Fall back to round_stage, then to undefined (existing behavior) so it never crashes.
  const videoRound = useMemo<"R1" | "R2" | undefined>(() => {
    const stage = (session?.stage || roundStage || "").toLowerCase();
    if (stage === "round2_ai" || stage === "round2" || stage === "round_2_sent") return "R2";
    // 'ai_scheduled' is a batch of candidates' real Round 1 stage — treat as R1.
    if (stage === "round1" || stage === "round_1_sent" || stage === "ai_scheduled") return "R1";
    return undefined;
  }, [session?.stage, roundStage]);

  const showRound2 = !!action && roundStage !== "disqualified" && roundStage !== "terminated"
    && (action.round1_status === "sent" || roundStage === "round_1_sent");
  const showOffer = !!action && roundStage !== "disqualified" && roundStage !== "terminated"
    && (action.round2_status === "sent" || roundStage === "round_2_sent");

  return (
    <div className="min-h-screen bg-background">
      <header className="bg-background sticky top-0 z-10" style={{ borderBottom: "1px solid #e1e4ec" }}>
        <div className="max-w-5xl mx-auto px-4 sm:px-6 py-4 flex flex-wrap items-center gap-3">
          <Button variant="ghost" size="sm" onClick={() => navigate(`/dashboard/ai-interviews?locate=${responseId}${videoRound ? `&round=${videoRound}` : ""}`)} className="min-h-[44px]">
            <ArrowLeft className="h-4 w-4 mr-1.5" /> Back
          </Button>
          <h1 className="text-lg sm:text-xl font-semibold flex items-center gap-2">
            <Sparkles className="h-5 w-5" /> Scout Report
          </h1>
          {responseId && !loading && !notFound && (
            <div className="ml-auto flex flex-wrap items-center gap-2">
              <RecoverInterviewButton
                responseId={responseId}
                candidateName={candidateName === "Direct Link Candidate" ? "" : candidateName}
                candidateEmail={candidateEmail}
                appearance="outline"
                eligible={true}
              />
              <RescueCandidateButton
                responseId={responseId}
                candidateName={candidateName === "Direct Link Candidate" ? "" : candidateName}
                candidateEmail={candidateEmail}
                appearance="outline"
              />
              <Button
                size="sm"
                className="min-h-[36px] bg-violet-600 hover:bg-violet-700 text-white"
                onClick={() => setCustomMsgOpen(true)}
              >
                <MessageSquare className="h-4 w-4 mr-1.5" /> Send Message
              </Button>
              <Button
                size="sm"
                className="min-h-[36px] bg-slate-600 hover:bg-slate-700 text-white"
                onClick={() => navigate(roundStage === "disqualified" ? `/dashboard/disqualified?locate=${responseId}` : `/dashboard/my-bookings?locate=${responseId}`)}
              >
                <MapPin className="h-4 w-4 mr-1.5" /> Locate Me
              </Button>
              <InvolveHumanButton
                responseId={responseId}
                candidateName={candidateName === "Direct Link Candidate" ? "" : candidateName}
                appearance="outline"
              />
              <DisqualifyButton
                responseId={responseId}
                candidateName={candidateName === "Direct Link Candidate" ? "" : candidateName}
                onDisqualified={() => setRoundStage("disqualified")}
              />
            </div>
          )}
        </div>
      </header>

      <main className="max-w-5xl mx-auto px-4 sm:px-6 py-6 sm:py-8 space-y-6">
        {loading ? (
          <div className="space-y-4" aria-busy="true">
            <Skeleton className="h-24 w-full" />
            <Skeleton className="h-48 w-full" />
            <Skeleton className="h-64 w-full" />
          </div>
        ) : notFound ? (
          <div className="border border-dashed border-border rounded-xl p-12 text-center">
            <h2 className="text-lg font-semibold mb-1">No interview found</h2>
            <p className="text-sm text-muted-foreground">This candidate has no AI interview session yet.</p>
          </div>
        ) : (
          <>
            {/* Candidate header card */}
            <section className="border border-border rounded-lg bg-card p-5">
              <div className="flex flex-col sm:flex-row sm:items-start sm:justify-between gap-4">
                <div className="min-w-0">
                  <h2 className="text-xl sm:text-2xl font-semibold truncate">{candidateName}</h2>
                  <div className="text-sm text-muted-foreground mt-1">{positionTitle}</div>
                  {candidateEmail ? <div className="text-xs text-muted-foreground mt-1 truncate">{candidateEmail}</div> : null}
                  <div className="mt-3 flex flex-wrap gap-x-6 gap-y-1 text-xs text-muted-foreground">
                    <div><span className="font-medium text-foreground">Date:</span> {fmtDate(session?.ended_at || session?.created_at)}</div>
                    <div><span className="font-medium text-foreground">Duration:</span> {fmtDuration(session?.duration_seconds)}</div>
                  </div>
                </div>
                <div className="flex flex-row sm:flex-col items-start gap-2 shrink-0">
                  {!failed && evaluation?.tier ? (
                    <Badge className={`${tierClass(evaluation.tier)} border-0 text-sm px-3 py-1`}>{evaluation.tier}</Badge>
                  ) : null}
                  {roundStage === "disqualified" && (
                    <Badge className="border-0 bg-red-600 text-white text-sm px-3 py-1">Disqualified</Badge>
                  )}
                </div>
              </div>
            </section>

            {/* Verdict */}
            <section className="border border-border rounded-lg bg-card p-5">
              <h3 className="text-base font-semibold mb-4 flex items-center gap-2">
                <Sparkles className="h-4 w-4" /> {resolvedRound === "R2" ? "Marissa's Verdict" : "Christine's Verdict"}
              </h3>

              {failed ? (
                <div className="rounded-md border border-amber-200 bg-amber-50 text-amber-900 p-4 text-sm">
                  No interview was completed — the candidate did not join or the interview failed.
                  {session?.termination_reason ? (
                    <div className="mt-1 text-xs opacity-80">Reason: {session.termination_reason}</div>
                  ) : null}
                </div>
              ) : (
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-x-6 gap-y-4">
                  {evaluation?.ai_recommended !== null && evaluation?.ai_recommended !== undefined ? (
                    <Field
                      label="AI Recommended"
                      value={
                        evaluation.ai_recommended ? (
                          <span className="inline-flex items-center gap-1 text-emerald-700 font-medium"><Check className="h-4 w-4" /> Yes</span>
                        ) : (
                          <span className="inline-flex items-center gap-1 text-rose-700 font-medium"><X className="h-4 w-4" /> No</span>
                        )
                      }
                    />
                  ) : null}
                  {evaluation?.tier ? <Field label="Tier" value={evaluation.tier} /> : null}
                  {evaluation?.sentiment ? <Field label="Sentiment" value={evaluation.sentiment} /> : null}
                  {evaluation?.hunger ? <Field label="Hunger" value={evaluation.hunger} /> : null}
                  {evaluation?.availability ? <Field label="Availability" value={evaluation.availability} /> : null}
                  {evaluation?.verdict ? (
                    <div className="sm:col-span-2"><Field label="Verdict" value={evaluation.verdict} /></div>
                  ) : null}
                  {evaluation?.summary ? (
                    <div className="sm:col-span-2"><Field label="Summary" value={evaluation.summary} /></div>
                  ) : null}
                  {evaluation?.red_flags ? (
                    <div className="sm:col-span-2">
                      <div className="text-xs uppercase tracking-wide text-rose-700 font-medium mb-1">Red Flags</div>
                      <div className="text-sm text-rose-900 whitespace-pre-wrap bg-rose-50 border border-rose-200 rounded p-3">
                        {evaluation.red_flags}
                      </div>
                    </div>
                  ) : null}
                </div>
              )}
            </section>

            {/* Video — shared embedded player with on-the-fly readable captions */}
            <section className="border border-border rounded-lg bg-card p-5">
              <h3 className="text-base font-semibold mb-3 flex items-center gap-2">
                <Video className="h-4 w-4" /> Interview Video
              </h3>
              {session?.merged_video_url || session?.video_url ? (
                <div className="flex items-center gap-3 flex-wrap">
                  {responseId && videoRound ? (
                    <InterviewVideoDialog responseId={responseId} round={videoRound} buttonClassName="min-h-[44px]" />
                  ) : (
                    <InterviewVideoDialog session={session} buttonClassName="min-h-[44px]" />
                  )}
                  {session?.merged_video_url ? null : (
                    <span className="text-xs text-muted-foreground">Audio still processing — showing video only.</span>
                  )}
                </div>
              ) : (
                <p className="text-sm text-muted-foreground">Video not available.</p>
              )}
            </section>


            {/* Photo + Résumé */}
            <section className="border border-border rounded-lg bg-card p-5">
              <h3 className="text-base font-semibold mb-3">Candidate Files</h3>
              <div className="flex flex-col sm:flex-row sm:items-start gap-6">
                <div className="space-y-2">
                  <div className="text-xs uppercase tracking-wide text-muted-foreground font-medium">Photo</div>
                  {selfieUrl ? (
                    <SelfieThumb file_url={selfieUrl} size={120} onPreview={() => setPreviewFile(selfieUrl)} />
                  ) : (
                    <div className="w-[120px] h-[120px] rounded-lg border border-dashed border-border bg-secondary flex items-center justify-center text-xs text-muted-foreground text-center px-2">
                      No photo
                    </div>
                  )}
                </div>
                <div className="space-y-2 flex-1 min-w-0">
                  <div className="text-xs uppercase tracking-wide text-muted-foreground font-medium">Résumé</div>
                  {resumeUrl ? (
                    <Button variant="outline" className="min-h-[44px]" onClick={() => setPreviewFile(resumeUrl)}>
                      <FileIcon className="h-4 w-4 mr-2" /> View Résumé
                    </Button>
                  ) : (
                    <div className="text-sm text-muted-foreground">No résumé on file.</div>
                  )}
                </div>
              </div>
            </section>

            {/* Transcript */}
            <section className="border border-border rounded-lg bg-card p-5">
              <h3 className="text-base font-semibold mb-3">Transcript</h3>
              {transcript.length === 0 ? (
                <p className="text-sm text-muted-foreground">No transcript available.</p>
              ) : (
                <div className="max-h-[480px] overflow-y-auto pr-1 space-y-3">
                  {transcript.map((m, i) => {
                    const isAgent = /agent|christine|assistant|ai|bot/i.test(m.role);
                    const agentName = session?.stage === "round2_ai" ? "Marissa" : "Christine";
                    return (
                      <div key={i} className={`flex ${isAgent ? "justify-start" : "justify-end"}`}>
                        <div className={`max-w-[85%] rounded-lg px-3 py-2 text-sm whitespace-pre-wrap ${
                          isAgent ? "bg-secondary text-foreground" : "bg-primary/10 text-foreground"
                        }`}>
                          <div className="text-[10px] uppercase tracking-wide opacity-60 mb-0.5">
                            {isAgent ? agentName : "Candidate"}
                          </div>
                          {m.content}
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </section>

            {/* Actions */}
            <section className="border border-border rounded-lg bg-card p-5">
              <h3 className="text-base font-semibold mb-3">Actions</h3>
              <div className="flex flex-wrap gap-2">
                {showRound2 && formId ? (
                  <SendRound2Button
                    responseId={responseId!}
                    candidateName={candidateName}
                    candidateEmail={candidateEmail}
                    action={action}
                    onChanged={() => load()}
                  />
                ) : null}
                {showOffer && formId ? (
                  <SendOfferButton
                    formId={formId}
                    responseId={responseId!}
                    candidateName={candidateName}
                    candidateEmail={candidateEmail}
                    nameQid={nameQid}
                    emailQid={emailQid}
                    action={action}
                    onChanged={() => load()}
                  />
                ) : null}
                <DisqualifyButton
                  responseId={responseId!}
                  candidateName={candidateName}
                  onDisqualified={() => load()}
                />
                <InvalidateRoundsButton
                  responseId={responseId!}
                  candidateName={candidateName}
                />
              </div>
              {roundStage ? (
                <div className="text-xs text-muted-foreground mt-3">Current stage: <span className="font-medium text-foreground">{roundStage}</span></div>
              ) : null}
            </section>
          </>
        )}
      </main>

      <FilePreviewDialog file_url={previewFile} onClose={() => setPreviewFile(null)} />

      <SendCustomMessageDialog
        open={customMsgOpen}
        onOpenChange={setCustomMsgOpen}
        initialEmail={candidateEmail}
        initialName={candidateName === "Direct Link Candidate" ? "" : candidateName}
        responseId={responseId}
      />
    </div>
  );
};

export default AiInterviewReport;
