import { useEffect, useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { TEAM_OPTIONS } from "@/lib/teams";
import { parseInvokeError } from "@/lib/invokeError";
import { InlineLoader, LoadError } from "@/components/FullPageLoader";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter,
} from "@/components/ui/dialog";
import {
  AlertDialog, AlertDialogContent, AlertDialogHeader, AlertDialogTitle,
  AlertDialogDescription, AlertDialogFooter, AlertDialogCancel, AlertDialogAction,
} from "@/components/ui/alert-dialog";
import { Table, TableHeader, TableBody, TableRow, TableHead, TableCell } from "@/components/ui/table";
import { Avatar, AvatarImage, AvatarFallback } from "@/components/ui/avatar";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import { ArrowLeft, Loader2, Users, AlertTriangle, ShieldAlert, Send, Check, FileSignature, Palmtree, ThumbsUp, ThumbsDown, ExternalLink, Lock, UserMinus, Mail, ChevronDown, ChevronRight, CalendarClock, PauseCircle, PlayCircle, Pencil } from "lucide-react";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";
import { DisqualifyButton } from "@/components/DisqualifyButton";
import { EmployeeUniversalDocButtons } from "@/components/EmployeeUniversalDocButtons";
import { EmployeeHrNotesDialog } from "@/components/EmployeeHrNotesDialog";
import { EditEmployeeDetailsDialog } from "@/components/EditEmployeeDetailsDialog";
import { HrCopyCheckbox, defaultHrCopyState, type HrCopyState } from "@/components/HrCopyCheckbox";
import { AssignToSylviaDialog } from "@/components/AssignToSylviaDialog";
import { Sparkles, GraduationCap } from "lucide-react";
import SendOnboardingTestDialog from "@/components/SendOnboardingTestDialog";
import { useHrIdentity } from "@/hooks/useHrIdentity";
import SendScheduleControl, { type SendScheduleValue } from "@/components/SendScheduleControl";
import { insertScheduledSend, formatScheduledFor } from "@/lib/scheduledSends";

type LeaveRow = {
  id: string;
  response_id: string | null;
  external_reference: string;
  signer_name: string | null;
  signer_email: string | null;
  doc_type: string | null;
  reason: string | null;
  start_date: string | null;
  num_days: string | null;
  hours_missed: string | null;
  status: "invited" | "pending_approval" | "approved" | "declined";
  hr_decision_note: string | null;
  decided_at: string | null;
  signed_pdf_url: string | null;
  created_at: string;
};

type Offer = {
  id: string;
  candidate_id: string | null;
  candidate_name: string;
  candidate_email: string;
  position_title: string;
  start_date: string | null;
  trial_weeks: number;
  trial_weekly_salary: number;
  post_trial_weekly_salary: number;
  currency: string;
  welcome_resend_count?: number;
  signed_at: string | null;
  employment_status: string;
  override_email?: string | null;
  terminated_at?: string | null;
  termination_reason?: string | null;
  // On Hold (Piece 1) — reversible pause, SEPARATE from employment_status.
  hold_status?: string | null;
  hold_effective_date?: string | null;
  hold_set_at?: string | null;
  hold_set_by_hr_id?: string | null;
  hold_rejoin_date?: string | null;
  hold_remark?: string | null;
};

const daysBetween = (start: string | null) => {
  if (!start) return 0;
  const d = new Date(start);
  const now = new Date();
  return Math.max(0, Math.floor((now.getTime() - d.getTime()) / 86400000));
};

const trialStatus = (start: string | null, trialWeeks: number) => {
  const days = daysBetween(start);
  const trialDays = trialWeeks * 7;
  if (days < trialDays) {
    const weeksLeft = Math.ceil((trialDays - days) / 7);
    return { label: `Trial — ${weeksLeft}w left`, inTrial: true };
  }
  return { label: "Post-Trial", inTrial: false };
};

const fmtCurrency = (n: number | null | undefined, ccy: string | null | undefined) => {
  const amount = typeof n === "number" && Number.isFinite(n) ? n : 0;
  // Guard: Intl.NumberFormat throws RangeError on an invalid/empty currency code.
  // Fall back gracefully so a bad currency value can never blank the dashboard.
  try {
    return new Intl.NumberFormat("en-US", { style: "currency", currency: (ccy || "USD").toUpperCase(), maximumFractionDigits: 0 }).format(amount);
  } catch {
    return `${ccy || ""}${ccy ? " " : ""}${Math.round(amount).toLocaleString("en-US")}`.trim();
  }
};

const fmtDate = (d: string | null) =>
  d ? new Date(d).toLocaleDateString("en-US", { year: "numeric", month: "short", day: "numeric" }) : "—";

// TEAM_OPTIONS + teamNameById now live in a shared constant so the inline
// dropdown here and the AssignToSylviaDialog never drift.
// (imported at top of file)

const initialsOf = (name?: string) => {
  const parts = (name || "").trim().split(/\s+/).filter(Boolean);
  if (!parts.length) return "?";
  return (parts[0][0] + (parts.length > 1 ? parts[parts.length - 1][0] : "")).toUpperCase();
};

// Circular profile avatar reusing the SAME stored photo as the Results page
// (the candidate's photo/selfie file_upload answer). Resolves a short-lived
// signed URL for the private bucket; falls back to the person's initials.
const EmployeeAvatar = ({ filePath, name }: { filePath?: string | null; name: string }) => {
  const [url, setUrl] = useState<string | null>(null);
  useEffect(() => {
    let cancelled = false;
    setUrl(null);
    if (!filePath) return;
    (async () => {
      const slash = filePath.indexOf("/");
      if (slash < 0) return;
      const bucket = filePath.slice(0, slash);
      const path = filePath.slice(slash + 1);
      const { data } = await supabase.storage.from(bucket).createSignedUrl(path, 600);
      if (!cancelled && data?.signedUrl) setUrl(data.signedUrl);
    })();
    return () => { cancelled = true; };
  }, [filePath]);
  return (
    <Avatar className="h-14 w-14 shrink-0">
      {url && <AvatarImage src={url} alt={name} className="object-cover" />}
      <AvatarFallback className="text-base font-medium">{initialsOf(name)}</AvatarFallback>
    </Avatar>
  );
};



export default function EmployeesDashboard() {
  const navigate = useNavigate();
  const { hrId } = useHrIdentity();
  const [offers, setOffers] = useState<Offer[]>([]);
  const [terminatedOffers, setTerminatedOffers] = useState<Offer[]>([]);
  const [showTerminated, setShowTerminated] = useState(false);
  // Restore (un-terminate) confirm dialog
  const [restoreTarget, setRestoreTarget] = useState<Offer | null>(null);
  const [restoreBusy, setRestoreBusy] = useState(false);
  const [resendTarget, setResendTarget] = useState<Offer | null>(null);
  const [resendEmail, setResendEmail] = useState("");
  const [resendPwd, setResendPwd] = useState("");
  const [resendBusy, setResendBusy] = useState(false);
  const [loading, setLoading] = useState(true);
  const [loadError, setLoadError] = useState<string | null>(null);

  // Offboard / Terminate modal state (consolidated picker)
  type OffboardAction = "evaluation" | "regular" | "settlement" | "resign_nda1" | "resign_nda2";
  type OffboardChannel = "email" | "whatsapp";
  const [target, setTarget] = useState<Offer | null>(null);
  const [action, setAction] = useState<OffboardAction>("evaluation");
  const [channel, setChannel] = useState<OffboardChannel>("email");
  const [termType, setTermType] = useState<"evaluation" | "regular">("evaluation");
  const [step, setStep] = useState<"confirm" | "password">("confirm");
  const [notes, setNotes] = useState("");
  const [pwd, setPwd] = useState("");
  const [sendToEmail, setSendToEmail] = useState("");
  const [sendEmail, setSendEmail] = useState(true);
  const [busy, setBusy] = useState(false);
  const [hrCopy, setHrCopy] = useState<HrCopyState>(defaultHrCopyState);

  // applicant_id -> response_id (latest matched response)
  const [respIdByCandidate, setRespIdByCandidate] = useState<Record<string, string>>({});

  // response_id -> completed-timing hours (read-only permanent footprint)
  const [r1HoursByResp, setR1HoursByResp] = useState<Record<string, number>>({});
  const [r2HoursByResp, setR2HoursByResp] = useState<Record<string, number>>({});
  const [offerHoursByResp, setOfferHoursByResp] = useState<Record<string, number>>({});

  // response_id -> submitted_at (for the onboarding tick)
  const [onboardingByResp, setOnboardingByResp] = useState<Record<string, string>>({});

  // response_id -> profile photo storage path (same source as the Results page)
  const [photoByResp, setPhotoByResp] = useState<Record<string, string>>({});


  // response_id -> assigned_group_id (for the team dropdown)
  const [teamByResp, setTeamByResp] = useState<Record<string, string>>({});

  // Onboarding invite modal
  const [obTarget, setObTarget] = useState<Offer | null>(null);
  const [obEmail, setObEmail] = useState("");
  const [obBusy, setObBusy] = useState(false);
  const [welcomeTarget, setWelcomeTarget] = useState<Offer | null>(null);
  const [welcomeEmail, setWelcomeEmail] = useState("");
  const [welcomeBusy, setWelcomeBusy] = useState(false);

  // NDA send modal + status map
  type NdaStatus = { status: "sent" | "signed"; signed_at: string | null };
  const [ndaByResp, setNdaByResp] = useState<Record<string, NdaStatus>>({});
  const [ndaTarget, setNdaTarget] = useState<Offer | null>(null);
  const [ndaEmail, setNdaEmail] = useState("");
  const [ndaBusy, setNdaBusy] = useState(false);

  // Joining NDA (NDA 1) — separate map + modal
  const [joiningNdaByResp, setJoiningNdaByResp] = useState<Record<string, NdaStatus>>({});
  const [joiningNdaTarget, setJoiningNdaTarget] = useState<Offer | null>(null);
  const [joiningNdaEmail, setJoiningNdaEmail] = useState("");
  const [joiningNdaBusy, setJoiningNdaBusy] = useState(false);

  // Exit NDA (NDA 2) — separate map + modal
  const [exitNdaByResp, setExitNdaByResp] = useState<Record<string, NdaStatus>>({});
  const [exitNdaTarget, setExitNdaTarget] = useState<Offer | null>(null);
  const [exitNdaEmail, setExitNdaEmail] = useState("");
  const [exitNdaBusy, setExitNdaBusy] = useState(false);

  // Leave requests state
  const [pendingLeaves, setPendingLeaves] = useState<LeaveRow[]>([]);
  const [leavesByResp, setLeavesByResp] = useState<Record<string, LeaveRow[]>>({});
  const [decideTarget, setDecideTarget] = useState<{ leave: LeaveRow; decision: "approved" | "declined" } | null>(null);
  const [decideNote, setDecideNote] = useState("");
  const [decideBusy, setDecideBusy] = useState(false);
  const [leavesPopupFor, setLeavesPopupFor] = useState<{ offer: Offer; rows: LeaveRow[] } | null>(null);

  // Total leave count per matched response (for the "X leaves filed" badge)
  const [leaveCountByResp, setLeaveCountByResp] = useState<Record<string, number>>({});

  // HR Notes (payment + private notes) dialog
  const [hrNotesTarget, setHrNotesTarget] = useState<{ responseId: string; name: string } | null>(null);

  // Edit Employee Details dialog
  const [editTarget, setEditTarget] = useState<Offer | null>(null);

  // Assign-to-Sylvia dialog
  const [sylviaTarget, setSylviaTarget] = useState<{ responseId: string; name: string } | null>(null);

  // ── On Hold (Piece 1 status + Piece 2 email) — reversible pause ──
  const [holdTarget, setHoldTarget] = useState<Offer | null>(null);        // Put On Hold modal
  const [holdDate, setHoldDate] = useState("");                            // optional effective date (yyyy-mm-dd)
  const [holdBusy, setHoldBusy] = useState(false);
  const [removeHoldTarget, setRemoveHoldTarget] = useState<Offer | null>(null); // Remove On Hold modal
  const [rejoinDate, setRejoinDate] = useState("");                        // optional re-joining date (yyyy-mm-dd)
  const [removeHoldBusy, setRemoveHoldBusy] = useState(false);

  // ── On Hold (Piece 2) — send options for both popups ──
  const HOLD_EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  // Put On Hold popup send options
  const [holdEmailOn, setHoldEmailOn] = useState(true);
  const [holdName, setHoldName] = useState("");
  const [holdEmail, setHoldEmail] = useState("");
  const [holdHrCopy, setHoldHrCopy] = useState<HrCopyState>(defaultHrCopyState);
  const [holdSchedule, setHoldSchedule] = useState<SendScheduleValue>({ mode: "now" });
  // Remove On Hold popup send options
  const [removeEmailOn, setRemoveEmailOn] = useState(true);
  const [removeName, setRemoveName] = useState("");
  const [removeEmail, setRemoveEmail] = useState("");
  const [removeHrCopy, setRemoveHrCopy] = useState<HrCopyState>(defaultHrCopyState);
  const [removeSchedule, setRemoveSchedule] = useState<SendScheduleValue>({ mode: "now" });

  // Auto-fetch name/email from the employee when each popup opens.
  useEffect(() => {
    if (holdTarget) {
      setHoldName(holdTarget.candidate_name || "");
      setHoldEmail(holdTarget.override_email || holdTarget.candidate_email || "");
      setHoldEmailOn(true);
      setHoldHrCopy(defaultHrCopyState);
      setHoldSchedule({ mode: "now" });
    }
  }, [holdTarget]);
  useEffect(() => {
    if (removeHoldTarget) {
      setRemoveName(removeHoldTarget.candidate_name || "");
      setRemoveEmail(removeHoldTarget.override_email || removeHoldTarget.candidate_email || "");
      setRemoveEmailOn(true);
      setRemoveHrCopy(defaultHrCopyState);
      setRemoveSchedule({ mode: "now" });
    }
  }, [removeHoldTarget]);

  // Shared sender for both On Hold notices. Now -> invoke; Later -> schedule.
  // Returns a label for the success toast. Throws on failure so the caller can surface it.
  const sendHoldNotice = async (opts: {
    kind: "on_hold" | "reactivation";
    name: string;
    email: string;
    effectiveDate: string | null;
    rejoinDate: string | null;
    responseId: string | null;
    hrCopy: HrCopyState;
    schedule: SendScheduleValue;
  }): Promise<string> => {
    const name = opts.name.trim();
    const email = opts.email.trim();
    if (!name) throw new Error("Recipient name is required to send the notice");
    if (!email || !HOLD_EMAIL_RE.test(email)) throw new Error("Valid recipient email is required to send the notice");

    // EXACT payload reused for Now + Later so a scheduled replay is identical.
    const payload = {
      kind: opts.kind,
      name,
      email,
      effective_date: opts.effectiveDate,
      rejoin_date: opts.rejoinDate,
      response_id: opts.responseId,
      hr_copy_requested: opts.hrCopy.requested === true,
      hr_copy_email_override: opts.hrCopy.requested && opts.hrCopy.override ? opts.hrCopy.override : null,
    };

    if (opts.schedule.mode === "schedule") {
      await insertScheduledSend({
        send_type: opts.kind === "on_hold" ? "hold_notice" : "reactivation_notice",
        target_function: "send-hold-notice",
        payload,
        response_id: opts.responseId,
        scheduled_for_utc: opts.schedule.scheduled_for_utc,
        timezone: opts.schedule.timezone,
      });
      return `Notice scheduled for ${formatScheduledFor(opts.schedule.scheduled_for_utc, opts.schedule.timezone)}`;
    }

    const { data, error } = await supabase.functions.invoke("send-hold-notice", { body: payload });
    if (error) {
      const reason = (data as any)?.error || error.message || "send_failed";
      throw new Error(String(reason));
    }
    if ((data as any)?.error) throw new Error(String((data as any).error));
    return `Notice sent to ${email}`;
  };

  // Put an employee On Hold — single-row write by id. Does NOT touch employment_status.
  const confirmPutOnHold = async () => {
    if (!holdTarget) return;
    setHoldBusy(true);
    try {
      const effective = holdDate ? new Date(holdDate + "T00:00:00").toISOString() : new Date().toISOString();
      const remark = holdDate
        ? `On Hold — pay and hours stop counting effective ${fmtDate(effective)}.`
        : "On Hold — pay and hours stop counting effective immediately.";
      const { error } = await supabase
        .from("job_offers")
        .update({
          hold_status: "on_hold",
          hold_effective_date: effective,
          hold_set_at: new Date().toISOString(),
          hold_set_by_hr_id: hrId,
          hold_remark: remark,
        })
        .eq("id", holdTarget.id);
      if (error) throw error;
      setOffers((prev) => prev.map((x) => x.id === holdTarget.id
        ? { ...x, hold_status: "on_hold", hold_effective_date: effective, hold_set_at: new Date().toISOString(), hold_set_by_hr_id: hrId, hold_remark: remark }
        : x));
      toast.success(`${holdTarget.candidate_name} placed On Hold.`);

      // Piece 2: send the On Hold notice (additive — status already set above).
      // Unchecked => set status silently, send nothing.
      if (holdEmailOn) {
        const responseId = holdTarget.candidate_id ? (respIdByCandidate[holdTarget.candidate_id] ?? null) : null;
        try {
          const msg = await sendHoldNotice({
            kind: "on_hold",
            name: holdName,
            email: holdEmail,
            effectiveDate: holdDate ? effective : null,
            rejoinDate: null,
            responseId,
            hrCopy: holdHrCopy,
            schedule: holdSchedule,
          });
          toast.success(msg);
        } catch (mailErr: any) {
          toast.error(`On Hold set, but the email failed: ${mailErr?.message || "send_failed"}`);
        }
      }

      setHoldTarget(null);
      setHoldDate("");
    } catch (e: any) {
      toast.error(e?.message || "Failed to place on hold");
    } finally {
      setHoldBusy(false);
    }
  };

  // Remove On Hold — single-row write by id. Clears the pause, keeps re-joining date.
  const confirmRemoveOnHold = async () => {
    if (!removeHoldTarget) return;
    setRemoveHoldBusy(true);
    try {
      const rejoin = rejoinDate ? new Date(rejoinDate + "T00:00:00").toISOString() : new Date().toISOString();
      const remark = rejoinDate
        ? `Resumed — pay and hours count again effective ${fmtDate(rejoin)}.`
        : "Resumed — pay and hours count again effective immediately.";
      const { error } = await supabase
        .from("job_offers")
        .update({
          hold_status: null,
          hold_rejoin_date: rejoin,
          hold_effective_date: null,
          hold_set_at: null,
          hold_remark: remark,
        })
        .eq("id", removeHoldTarget.id);
      if (error) throw error;
      setOffers((prev) => prev.map((x) => x.id === removeHoldTarget.id
        ? { ...x, hold_status: null, hold_rejoin_date: rejoin, hold_effective_date: null, hold_set_at: null, hold_remark: remark }
        : x));
      toast.success(`${removeHoldTarget.candidate_name} removed from On Hold.`);

      // Piece 2: send the Reactivation notice (additive — status already cleared above).
      // Unchecked => clear status silently, send nothing.
      if (removeEmailOn) {
        const responseId = removeHoldTarget.candidate_id ? (respIdByCandidate[removeHoldTarget.candidate_id] ?? null) : null;
        try {
          const msg = await sendHoldNotice({
            kind: "reactivation",
            name: removeName,
            email: removeEmail,
            effectiveDate: null,
            rejoinDate: rejoinDate ? rejoin : null,
            responseId,
            hrCopy: removeHrCopy,
            schedule: removeSchedule,
          });
          toast.success(msg);
        } catch (mailErr: any) {
          toast.error(`Removed from On Hold, but the email failed: ${mailErr?.message || "send_failed"}`);
        }
      }

      setRemoveHoldTarget(null);
      setRejoinDate("");
    } catch (e: any) {
      toast.error(e?.message || "Failed to remove on hold");
    } finally {
      setRemoveHoldBusy(false);
    }
  };




  const loadLeaves = async (respIds: string[]) => {
    // Pending always loaded (incl. universal/no-response)
    const { data: pend } = await (supabase
      .from("leave_requests") as any)
      .select("id, response_id, external_reference, signer_name, signer_email, doc_type, reason, start_date, num_days, hours_missed, status, hr_decision_note, decided_at, signed_pdf_url, created_at")
      .eq("status", "pending_approval")
      .order("created_at", { ascending: false });
    setPendingLeaves((pend as LeaveRow[]) || []);

    if (respIds.length) {
      const { data: decided } = await (supabase
        .from("leave_requests") as any)
        .select("id, response_id, external_reference, signer_name, signer_email, doc_type, reason, start_date, num_days, hours_missed, status, hr_decision_note, decided_at, signed_pdf_url, created_at")
        .in("response_id", respIds)
        .in("status", ["approved", "declined", "pending_approval"])
        .order("created_at", { ascending: false });
      const map: Record<string, LeaveRow[]> = {};
      for (const r of ((decided as LeaveRow[]) || [])) {
        if (!r.response_id) continue;
        (map[r.response_id] ||= []).push(r);
      }
      setLeavesByResp(map);
    } else {
      setLeavesByResp({});
    }
  };


  const load = async () => {
    setLoading(true);
    setLoadError(null);
    try {
    const { data, error } = await supabase
      .from("job_offers")
      .select("id, candidate_id, candidate_name, candidate_email, position_title, start_date, trial_weeks, trial_weekly_salary, post_trial_weekly_salary, currency, signed_at, employment_status, override_email, welcome_resend_count, hold_status, hold_effective_date, hold_set_at, hold_set_by_hr_id, hold_rejoin_date, hold_remark")
      .eq("status", "signed")
      .eq("employment_status", "active")
      .order("signed_at", { ascending: false });
    if (error) { toast.error(error.message); throw error; }
    // Only show candidates HR explicitly marked "Matched". Until then the
    // signed offer sits in My Bookings under the baby-blue "Offer Signed" badge.
    const rows = (data as Offer[]) || [];
    const candIds = Array.from(new Set(rows.map((o) => o.candidate_id).filter(Boolean) as string[]));
    let matchedSet = new Set<string>();
    const idMap: Record<string, string> = {};
    if (candIds.length) {
      // Primary read: include timing-footprint columns.
      let { data: resps, error: respsError } = await (supabase
        .from("responses") as any)
        .select("id, applicant_id, form_id, final_outcome, assigned_group_id, r1_completed_hours, r2_completed_hours, offer_signed_hours")
        .in("applicant_id", candIds)
        .eq("final_outcome", "matched");
      // Graceful degradation: if the timing columns are missing/extra (e.g. a
      // schema-vs-build skew), the query above errors and would otherwise blank
      // the whole page. Retry WITHOUT the timing columns so the employee list
      // still renders — just without the timing footprint.
      if (respsError) {
        console.error("[EmployeesDashboard] responses timing query failed, retrying without timing columns:", respsError);
        const fallback = await (supabase
          .from("responses") as any)
          .select("id, applicant_id, form_id, final_outcome, assigned_group_id")
          .in("applicant_id", candIds)
          .eq("final_outcome", "matched");
        if (fallback.error) {
          console.error("[EmployeesDashboard] responses fallback query also failed:", fallback.error);
        }
        resps = fallback.data;
      }
      for (const r of ((resps as any[]) || [])) {
        matchedSet.add(r.applicant_id);
        idMap[r.applicant_id] = r.id;
      }
      const teamMap: Record<string, string> = {};
      const hoursMap: Record<string, number> = {};
      const hours2Map: Record<string, number> = {};
      const offerHoursMap: Record<string, number> = {};
      for (const r of ((resps as any[]) || [])) {
        if (r.assigned_group_id) teamMap[r.id] = r.assigned_group_id;
        if (r.r1_completed_hours != null) hoursMap[r.id] = Number(r.r1_completed_hours);
        if (r.r2_completed_hours != null) hours2Map[r.id] = Number(r.r2_completed_hours);
        if (r.offer_signed_hours != null) offerHoursMap[r.id] = Number(r.offer_signed_hours);
      }
      setTeamByResp(teamMap);
      setR1HoursByResp(hoursMap);
      setR2HoursByResp(hours2Map);
      setOfferHoursByResp(offerHoursMap);

      // Profile photos — same stored value the Results page renders: the
      // candidate's photo/selfie file_upload answer. Map response_id -> path.
      try {
        const respFormPairs = ((resps as any[]) || [])
          .map((r) => ({ rid: r.id as string, fid: r.form_id as string | null }))
          .filter((p) => p.rid && p.fid);
        const formIds = Array.from(new Set(respFormPairs.map((p) => p.fid))) as string[];
        const photoMap: Record<string, string> = {};
        if (formIds.length) {
          const { data: pqs } = await (supabase
            .from("questions") as any)
            .select("id, form_id, type, label")
            .in("form_id", formIds);
          const photoRe = /photo|selfie|picture|headshot|portrait|image/i;
          const photoQByForm: Record<string, string> = {};
          for (const q of ((pqs as any[]) || [])) {
            if (photoQByForm[q.form_id]) continue;
            if (q.type === "selfie" || (q.type === "file_upload" && photoRe.test(q.label || ""))) {
              photoQByForm[q.form_id] = q.id;
            }
          }
          const photoQIds = Array.from(new Set(Object.values(photoQByForm)));
          const photoRespIds = respFormPairs.map((p) => p.rid);
          if (photoQIds.length && photoRespIds.length) {
            const { data: pans } = await (supabase
              .from("answers") as any)
              .select("response_id, question_id, file_url")
              .in("response_id", photoRespIds)
              .in("question_id", photoQIds)
              .not("file_url", "is", null);
            for (const a of ((pans as any[]) || [])) {
              if (a.file_url && !photoMap[a.response_id]) photoMap[a.response_id] = a.file_url;
            }
          }
        }
        setPhotoByResp(photoMap);
      } catch (e) {
        console.error("[EmployeesDashboard] profile photo lookup failed:", e);
        setPhotoByResp({});
      }
    }
    setRespIdByCandidate(idMap);
    const filtered = rows.filter((o) => o.candidate_id && matchedSet.has(o.candidate_id));
    setOffers(filtered);

    // Supplementary read: which of these employees have an onboarding submission?
    const respIds = filtered.map((o) => o.candidate_id ? idMap[o.candidate_id] : null).filter(Boolean) as string[];
    if (respIds.length) {
      const { data: subs } = await (supabase
        .from("onboarding_submissions") as any)
        .select("response_id, submitted_at")
        .in("response_id", respIds);
      const map: Record<string, string> = {};
      for (const s of ((subs as any[]) || [])) {
        if (s.submitted_at) map[s.response_id] = s.submitted_at;
      }
      setOnboardingByResp(map);
    } else {
      setOnboardingByResp({});
    }

    // NDA status per response (split by doc_type)
    if (respIds.length) {
      const { data: ndas } = await (supabase
        .from("nda_signatures") as any)
        .select("response_id, status, signed_at, created_at, doc_type")
        .in("response_id", respIds)
        .order("created_at", { ascending: false });
      const ndaMap: Record<string, NdaStatus> = {};
      const joiningMap: Record<string, NdaStatus> = {};
      const exitMap: Record<string, NdaStatus> = {};
      for (const n of ((ndas as any[]) || [])) {
        const target =
          n.doc_type === "joining_nda" ? joiningMap :
          n.doc_type === "exit_nda" ? exitMap :
          (n.doc_type === "nda" || !n.doc_type) ? ndaMap : null;
        if (!target) continue;
        const prev = target[n.response_id];
        if (!prev || (n.status === "signed" && prev.status !== "signed")) {
          target[n.response_id] = { status: n.status === "signed" ? "signed" : "sent", signed_at: n.signed_at };
        }
      }
      setNdaByResp(ndaMap);
      setJoiningNdaByResp(joiningMap);
      setExitNdaByResp(exitMap);
    } else {
      setNdaByResp({});
      setJoiningNdaByResp({});
      setExitNdaByResp({});
    }

    await loadLeaves(respIds);

    // Batched count of ALL leave_requests per matched_response_id (for badge)
    if (respIds.length) {
      const { data: leaveAll } = await (supabase
        .from("leave_requests") as any)
        .select("matched_response_id")
        .in("matched_response_id", respIds);
      const cmap: Record<string, number> = {};
      for (const r of ((leaveAll as any[]) || [])) {
        const k = r.matched_response_id as string;
        if (k) cmap[k] = (cmap[k] || 0) + 1;
      }
      setLeaveCountByResp(cmap);
    } else {
      setLeaveCountByResp({});
    }


    // Terminated employees — separate query, do not merge into active.
    const { data: termData } = await (supabase
      .from("job_offers") as any)
      .select("id, candidate_id, candidate_name, candidate_email, position_title, start_date, trial_weeks, trial_weekly_salary, post_trial_weekly_salary, currency, signed_at, employment_status, override_email, terminated_at, termination_reason")
      .eq("status", "signed")
      .in("employment_status", ["terminated_evaluation", "terminated_regular"])
      .order("terminated_at", { ascending: false });
    const termRows = (termData as Offer[]) || [];
    setTerminatedOffers(termRows);

    // Resolve response ids for terminated employees too, so the offboarding
    // action buttons (Exit NDA / Settlement / via Sylvia) work on terminated rows.
    const termCandIds = Array.from(new Set(termRows.map((o) => o.candidate_id).filter(Boolean) as string[]));
    if (termCandIds.length) {
      const { data: termResps } = await (supabase
        .from("responses") as any)
        .select("id, applicant_id, submitted_at")
        .in("applicant_id", termCandIds)
        .order("submitted_at", { ascending: false });
      const merged: Record<string, string> = { ...idMap };
      for (const r of ((termResps as any[]) || [])) {
        if (r.applicant_id && !merged[r.applicant_id]) merged[r.applicant_id] = r.id;
      }
      setRespIdByCandidate(merged);
    }
    } catch (e: any) {
      setLoadError(e?.message || "Couldn't load employees");
    } finally {
      setLoading(false);
    }
  };

  const updateTeam = async (responseId: string, teamId: string | null) => {
    const prev = teamByResp[responseId] || null;
    setTeamByResp((prevMap) => ({ ...prevMap, [responseId]: teamId || "" }));
    const { error } = await supabase
      .from("responses")
      .update({ assigned_group_id: teamId || null })
      .eq("id", responseId);
    if (error) {
      toast.error(`Failed to update team: ${error.message}`);
      setTeamByResp((prevMap) => ({ ...prevMap, [responseId]: prev || "" }));
      return;
    }
    toast.success("Team updated");
  };

  useEffect(() => { load(); }, []);

  // Realtime: flip NDA badges live (e.g. "Joining NDA sent" -> "signed")
  // when the signflow webhook updates nda_signatures, without a manual refresh.
  useEffect(() => {
    const ch = supabase
      .channel("employees-nda")
      .on(
        "postgres_changes",
        { event: "*", schema: "public", table: "nda_signatures" },
        () => load()
      )
      .subscribe();
    return () => { supabase.removeChannel(ch); };
  }, []);

  const stats = useMemo(() => {
    let trial = 0, post = 0;
    for (const o of offers) {
      const t = trialStatus(o.start_date, o.trial_weeks);
      if (t.inTrial) trial++; else post++;
    }
    return { active: offers.length, trial, post };
  }, [offers]);

  const [terminatedThisMonth, setTerminatedThisMonth] = useState(0);
  useEffect(() => {
    (async () => {
      const start = new Date();
      start.setDate(1); start.setHours(0, 0, 0, 0);
      const { count } = await supabase
        .from("job_offers")
        .select("id", { count: "exact", head: true })
        .in("employment_status", ["terminated_evaluation", "terminated_regular"])
        .gte("terminated_at", start.toISOString());
      setTerminatedThisMonth(count ?? 0);
    })();
  }, [offers.length]);

  const openOffboard = (o: Offer, opts?: { action?: OffboardAction; channel?: OffboardChannel }) => {
    setTarget(o);
    const a = opts?.action ?? "evaluation";
    setAction(a);
    setChannel(opts?.channel ?? "email");
    setTermType(a === "regular" ? "regular" : "evaluation");
    setNotes(""); setPwd(""); setStep("confirm");
    // FIX #34 — pre-fill the recipient with the employee's email (same pattern as openResend/other dialogs).
    setSendToEmail(((o as any).override_email || o.candidate_email || "").trim());
    setSendEmail(true);
    setHrCopy(defaultHrCopyState);
  };

  const closeModal = () => {
    if (!busy) {
      setTarget(null); setStep("confirm"); setNotes(""); setPwd("");
      setSendToEmail(""); setSendEmail(true);
      setAction("evaluation"); setChannel("email");
    }
  };

  const isTerminateAction = action === "evaluation" || action === "regular";
  const needsEmailField = channel === "email" && (
    !isTerminateAction || sendEmail
  );

  const actionLabel = (a: OffboardAction) =>
    a === "evaluation" ? "Trial Termination"
    : a === "regular" ? "Termination"
    : a === "settlement" ? "Send Settlement (Zero-Balance)"
    : a === "resign_nda1" ? "Re-Send NDA 1 (Joining NDA)"
    : "Re-Send NDA 2 (Exit NDA)";

  const confirmLabel = (a: OffboardAction) =>
    a === "evaluation" || a === "regular" ? "Confirm termination"
    : a === "settlement" ? "Send Settlement"
    : a === "resign_nda1" ? "Re-Send NDA 1"
    : "Re-Send NDA 2";

  const submitOffboard = async () => {
    if (!target) return;
    const recipient = sendToEmail.trim();
    const respId = target.candidate_id ? respIdByCandidate[target.candidate_id] : undefined;

    // Validate email when channel=email and the action will actually send
    if (channel === "email") {
      if (isTerminateAction && sendEmail) {
        if (!recipient || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(recipient)) {
          toast.error("Enter a valid recipient email"); return;
        }
      } else if (!isTerminateAction) {
        if (!recipient || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(recipient)) {
          toast.error("Enter a valid recipient email"); return;
        }
      }
    }
    if (!isTerminateAction && !respId) {
      toast.error("Missing response link for this employee — cannot send document.");
      return;
    }

    setBusy(true);
    try {
      if (isTerminateAction) {
        // TERMINATE flow — existing backend, untouched.
        // WhatsApp channel: still call terminate-employee (it natively supports
        // skip_email) and additionally queue a notification_log row.
        const effectiveSkipEmail = channel === "whatsapp" ? true : !sendEmail;
        const { data, error } = await supabase.functions.invoke("terminate-employee", {
          body: {
            job_offer_id: target.id,
            termination_type: action,
            password: pwd,
            internal_notes: notes || null,
            override_email: (!effectiveSkipEmail) ? recipient : null,
            skip_email: effectiveSkipEmail,
            hr_copy_requested: hrCopy.requested === true,
            hr_copy_email_override: hrCopy.requested && hrCopy.override ? hrCopy.override : null,
          },
        });
        if (error) throw error;
        if ((data as any)?.error) {
          if ((data as any).error === "wrong_password") { toast.error("Incorrect password"); setBusy(false); return; }
          throw new Error((data as any).error);
        }

        if (channel === "whatsapp") {
          // Placeholder audit row — no actual WhatsApp send yet.
          await (supabase.from("notification_log") as any).insert({
            event_type: `whatsapp_pending:terminate_${action}`,
            recipient_email: recipient || target.candidate_email || "(unknown)",
            related_resource_id: target.id,
            status: "queued",
          });
          toast.success("WhatsApp delivery is queued — Sylvia will send when her channel is connected. (No email sent.)");
        } else if (effectiveSkipEmail) {
          toast.success(`${target.candidate_name} terminated. No email sent.`);
        } else {
          toast.success(`${target.candidate_name} terminated. Email sent to ${recipient}.`);
        }
      } else {
        // SETTLEMENT / RE-SIGN NDA flow — existing backends, untouched.
        if (channel === "whatsapp") {
          // Placeholder: do NOT invoke the send-* function (those always email
          // and have no skip_email). Just queue an audit row.
          await (supabase.from("notification_log") as any).insert({
            event_type: `whatsapp_pending:${action}`,
            recipient_email: recipient || target.candidate_email || "(unknown)",
            related_resource_id: target.id,
            status: "queued",
          });
          toast.success("WhatsApp delivery is queued — Sylvia will send when her channel is connected. (No email sent.)");
        } else {
          const fn = action === "settlement" ? "send-settlement"
                  : action === "resign_nda1" ? "send-joining-nda"
                  : "send-exit-nda";
          const { data, error } = await supabase.functions.invoke(fn, {
            body: {
              response_id: respId,
              override_email: recipient || null,
              hr_copy_requested: hrCopy.requested === true,
              hr_copy_email_override: hrCopy.requested && hrCopy.override ? hrCopy.override : null,
            },
          });
          if (error) throw error;
          if (data && (data as any).ok === false) {
            throw new Error((data as any).reason || "send_failed");
          }
          toast.success(
            action === "settlement" ? `Settlement sent to ${recipient}.`
            : action === "resign_nda1" ? `NDA 1 re-sent to ${recipient}.`
            : `NDA 2 re-sent to ${recipient}.`
          );
        }
      }

      closeModal();
      load();
    } catch (e: any) {
      const { message } = await parseInvokeError(e);
      toast.error(message); // dialog stays open for retry
    } finally {
      setBusy(false);
    }
  };

  const openResend = (o: Offer) => {
    setResendTarget(o);
    setResendEmail(((o as any).override_email || o.candidate_email || "").trim());
    setResendPwd("");
  };

  const closeResend = () => {
    if (resendBusy) return;
    setResendTarget(null);
    setResendEmail("");
    setResendPwd("");
  };

  const submitResend = async () => {
    if (!resendTarget) return;
    const recipient = resendEmail.trim();
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(recipient)) {
      toast.error("Enter a valid recipient email"); return;
    }
    if (!resendPwd) { toast.error("Enter Boss password"); return; }
    setResendBusy(true);
    try {
      const { data, error } = await supabase.functions.invoke("resend-termination-email", {
        body: { job_offer_id: resendTarget.id, override_email: recipient, password: resendPwd },
      });
      if (error) throw error;
      if ((data as any)?.error) {
        if ((data as any).error === "wrong_password") { toast.error("Incorrect password"); setResendBusy(false); return; }
        throw new Error((data as any).error);
      }
      toast.success(`Termination notice sent to ${recipient}.`);
      setResendTarget(null);
      setResendEmail("");
      setResendPwd("");
      load();
    } catch (e: any) {
      const { message } = await parseInvokeError(e);
      toast.error(message); // dialog stays open for retry
    } finally {
      setResendBusy(false);
    }
  };

  // FIX #32 — Restore a terminated employee back to active (single-row write by id).
  const submitRestore = async () => {
    if (!restoreTarget) return;
    setRestoreBusy(true);
    try {
      const { error } = await supabase
        .from("job_offers")
        .update({
          employment_status: "active",
          terminated_at: null,
          termination_reason: null,
          terminated_by_hr_id: null,
        })
        .eq("id", restoreTarget.id);
      if (error) throw error;
      toast.success(`${restoreTarget.candidate_name} restored to the active list.`);
      setRestoreTarget(null);
      load();
    } catch (e: any) {
      const { message } = await parseInvokeError(e);
      toast.error(message); // dialog stays open for retry
    } finally {
      setRestoreBusy(false);
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <header className="border-b bg-card">
        <div className="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between">
          <Button variant="ghost" size="sm" onClick={() => navigate("/dashboard")}>
            <ArrowLeft className="h-4 w-4 mr-1.5" /> Back
          </Button>
          <div className="flex items-center gap-2 flex-wrap justify-end">
            <EmployeeUniversalDocButtons />
            {/* Quarantine header button hidden to free up header space — re-enable to restore.
            <Button variant="outline" size="sm" onClick={() => navigate("/dashboard/quarantine")}>
              <ShieldAlert className="h-4 w-4 mr-1.5" /> Quarantine
            </Button>
            */}
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-6 py-10">
        <div className="mb-8">
          <h1 className="text-4xl font-semibold tracking-tight" style={{ fontFamily: "'Cormorant Garamond', serif", color: "#1a2547" }}>
            Employees
          </h1>
          <p className="text-muted-foreground mt-1">Active hires and termination management</p>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
          <StatCard label="Total Active" value={stats.active} />
          <StatCard label="Trial Period" value={stats.trial} />
          <StatCard label="Post-Trial" value={stats.post} />
          <StatCard label="Terminated This Month" value={terminatedThisMonth} />
        </div>

        {/* Pending Leave Requests card */}
        {pendingLeaves.length > 0 && (
          <Card className="mb-6" style={{ borderColor: "#fcd34d" }}>
            <CardContent className="p-5">
              <div className="flex items-center gap-2 mb-3">
                <Palmtree className="h-5 w-5" style={{ color: "#b45309" }} />
                <h2 className="text-lg font-semibold" style={{ color: "#1a2547" }}>
                  Pending Leave Requests ({pendingLeaves.length})
                </h2>
              </div>
              <div className="space-y-3">
                {pendingLeaves.map((lr) => (
                  <div
                    key={lr.id}
                    className="border rounded-md p-3 flex flex-col md:flex-row md:items-start md:justify-between gap-3"
                    style={{ background: "#fffbeb" }}
                  >
                    <div className="text-sm flex-1 min-w-0">
                      <div className="font-medium flex items-center gap-2 flex-wrap">
                        <span>{lr.signer_name || "—"}</span>
                        {!lr.response_id && (
                          <span className="text-[10px] uppercase tracking-wide px-1.5 py-0.5 rounded" style={{ background: "#e0e7ff", color: "#3730a3" }}>
                            not in system
                          </span>
                        )}
                        <span className="text-xs text-muted-foreground">{lr.external_reference}</span>
                      </div>
                      <div className="text-xs text-muted-foreground mt-0.5">{lr.signer_email}</div>
                      <div className="mt-1.5 text-sm">
                        <span className="text-muted-foreground">Reason:</span>{" "}
                        <span className="line-clamp-2 inline">{lr.reason || "—"}</span>
                      </div>
                      <div className="mt-1 text-xs text-muted-foreground flex flex-wrap gap-x-3 gap-y-0.5">
                        <span>Start: <span className="text-foreground">{lr.start_date || "—"}</span></span>
                        <span>Days: <span className="text-foreground">{lr.num_days || "—"}</span></span>
                        <span>Hours missed: <span className="text-foreground">{lr.hours_missed || "—"}</span></span>
                      </div>
                    </div>
                    <div className="flex gap-2 md:flex-shrink-0">
                      <Button
                        size="sm"
                        onClick={() => { setDecideTarget({ leave: lr, decision: "approved" }); setDecideNote(""); }}
                        style={{ background: "#16a34a", color: "white", minHeight: 44 }}
                      >
                        <ThumbsUp className="h-3.5 w-3.5 mr-1" /> Approve
                      </Button>
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => { setDecideTarget({ leave: lr, decision: "declined" }); setDecideNote(""); }}
                        style={{ borderColor: "#dc2626", color: "#dc2626", minHeight: 44 }}
                      >
                        <ThumbsDown className="h-3.5 w-3.5 mr-1" /> Decline
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        )}

        <Card>
          <CardContent className="p-0">
            {loading ? (
              <InlineLoader label="Loading employees…" />
            ) : loadError ? (
              <LoadError onRetry={() => load()} message="Couldn't load employees" />
            ) : offers.length === 0 ? (
              <div className="p-10 text-center text-muted-foreground">
                <Users className="h-10 w-10 mx-auto mb-3 opacity-40" />
                No active employees yet.
              </div>
            ) : (
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Name</TableHead>
                      <TableHead>Position</TableHead>
                      <TableHead>Start Date</TableHead>
                      <TableHead>Days Active</TableHead>
                      <TableHead>Trial Status</TableHead>
                      <TableHead>Compensation</TableHead>
                      <TableHead>Assigned Team</TableHead>
                      <TableHead className="text-right w-[380px] max-w-[380px]">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {offers.map((o) => {
                      const t = trialStatus(o.start_date, o.trial_weeks);
                      const comp = t.inTrial ? o.trial_weekly_salary : o.post_trial_weekly_salary;
                      return (
                        <TableRow key={o.id}>
                          <TableCell>
                            <div className="flex items-center gap-2">
                              <EmployeeAvatar
                                filePath={o.candidate_id ? photoByResp[respIdByCandidate[o.candidate_id] || ""] : undefined}
                                name={o.candidate_name}
                              />
                              <div>
                                <div className="font-medium flex items-center gap-2">
                                  {o.candidate_name}
                                  {o.hold_status === "on_hold" && (
                                    <span
                                      title={o.hold_remark || "On Hold — pay and hours paused"}
                                      className="inline-flex items-center gap-1 text-xs px-1.5 py-0.5 rounded font-semibold"
                                      style={{ background: "#fef3c7", color: "#b45309", border: "1px solid #f59e0b" }}
                                    >
                                      <PauseCircle className="h-3 w-3" /> On Hold
                                    </span>
                                  )}
                                </div>
                                <div className="text-xs text-muted-foreground">{o.candidate_email}</div>
                                {(() => {
                                  // Permanent completed-timing footprint. Each line shows ONLY
                                  // if that value is non-null. Amber when over the 72h threshold.
                                  const respId = o.candidate_id ? respIdByCandidate[o.candidate_id] : undefined;
                                  const r1h = respId != null ? r1HoursByResp[respId] : undefined;
                                  const r2h = respId != null ? r2HoursByResp[respId] : undefined;
                                  const ofh = respId != null ? offerHoursByResp[respId] : undefined;
                                  if (r1h == null && r2h == null && ofh == null) return null;
                                  const line = (h: number, label: string) => (
                                    <div className={`text-[11px] mt-0.5 ${h > 72 ? "text-amber-700 font-medium" : "text-muted-foreground"}`}>
                                      {label} in {h}h{h > 72 ? " (over 72h)" : ""}
                                    </div>
                                  );
                                  return (
                                    <div className="mt-0.5">
                                      {r1h != null && line(r1h, "Round 1 completed")}
                                      {r2h != null && line(r2h, "Round 2 completed")}
                                      {ofh != null && line(ofh, "Offer signed")}
                                    </div>
                                  );
                                })()}
                              </div>
                              {o.candidate_id && respIdByCandidate[o.candidate_id] && onboardingByResp[respIdByCandidate[o.candidate_id]] && (
                                <span
                                  title={`Onboarding submitted ${fmtDate(onboardingByResp[respIdByCandidate[o.candidate_id]])}`}
                                  className="inline-flex items-center gap-1 text-xs px-1.5 py-0.5 rounded"
                                  style={{ background: "#dcfce7", color: "#166534" }}
                                >
                                  <Check className="h-3 w-3" /> Onboarding
                                </span>
                              )}
                              {(() => {
                                const respId = o.candidate_id ? respIdByCandidate[o.candidate_id] : undefined;
                                const rows = respId ? (leavesByResp[respId] || []) : [];
                                if (!rows.length) return null;
                                return (
                                  <button
                                    type="button"
                                    onClick={() => setLeavesPopupFor({ offer: o, rows })}
                                    className="inline-flex items-center gap-1 text-xs px-1.5 py-0.5 rounded hover:opacity-80"
                                    style={{ background: "#fef3c7", color: "#92400e", minHeight: 24 }}
                                    title="View leave requests"
                                  >
                                    🌴 Leaves ({rows.length})
                                  </button>
                                );
                              })()}
                              {(() => {
                                const respId = o.candidate_id ? respIdByCandidate[o.candidate_id] : undefined;
                                const count = respId ? (leaveCountByResp[respId] || 0) : 0;
                                if (!count) return null;
                                const email = ((o as any).override_email || o.candidate_email || "").trim();
                                return (
                                  <button
                                    type="button"
                                    onClick={() => navigate(`/dashboard/sick-leaves?signer=${encodeURIComponent(email)}`)}
                                    className="inline-flex items-center gap-1 text-xs px-1.5 py-0.5 rounded hover:opacity-80 border"
                                    style={{ borderColor: "#c9a84c", color: "#92400e", background: "#fffbeb", minHeight: 24 }}
                                    title="Open H.R Approval dashboard filtered to this employee"
                                  >
                                    <CalendarClock className="h-3 w-3" /> {count} leave{count === 1 ? "" : "s"} filed
                                  </button>
                                );
                              })()}
                            </div>
                          </TableCell>
                          <TableCell>{o.position_title}</TableCell>
                          <TableCell>{fmtDate(o.start_date)}</TableCell>
                          <TableCell>{daysBetween(o.start_date)}</TableCell>
                          <TableCell>
                            <Badge variant={t.inTrial ? "secondary" : "outline"}>{t.label}</Badge>
                          </TableCell>
                          <TableCell>{fmtCurrency(comp, o.currency)}/wk</TableCell>
                          <TableCell>
                            {(() => {
                              const respId = o.candidate_id ? respIdByCandidate[o.candidate_id] : undefined;
                              if (!respId) return <span className="text-xs text-muted-foreground">—</span>;
                              // Radix <SelectItem> must NOT have an empty-string value
                              // (it throws and would blank the page). Use a sentinel.
                              const NO_TEAM = "__no_team__";
                              const current = teamByResp[respId] || NO_TEAM;
                              return (
                                <Select
                                  value={current}
                                  onValueChange={(v) => updateTeam(respId, v === NO_TEAM ? null : v)}
                                >
                                  <SelectTrigger className="w-[220px] text-xs h-8">
                                    <SelectValue placeholder="— No team —" />
                                  </SelectTrigger>
                                  <SelectContent>
                                    <SelectItem value={NO_TEAM}>— No team —</SelectItem>
                                    {TEAM_OPTIONS.map((t) => (
                                      <SelectItem key={t.id} value={t.id}>{t.name}</SelectItem>
                                    ))}
                                  </SelectContent>
                                </Select>
                              );
                            })()}
                          </TableCell>
                          <TableCell className="text-right w-[380px] max-w-[380px]">
                            <div className="flex justify-end gap-2 flex-wrap ml-auto">
                              {o.candidate_id && respIdByCandidate[o.candidate_id] && (
                                <DisqualifyButton
                                  responseId={respIdByCandidate[o.candidate_id]}
                                  candidateName={o.candidate_name}
                                  forcedStageLabel="Disqualified after Matched / Employee"
                                  extraUpdate={{ final_outcome: "disqualified_after_matched" }}
                                  hideEmailOption
                                  onOptimisticRemove={() =>
                                    setOffers((prev) => prev.filter((x) => x.id !== o.id))
                                  }
                                  onRevert={() => load()}
                                  onDisqualified={() => load()}
                                />
                              )}
                              <Button
                                size="sm"
                                variant="outline"
                                onClick={() => {
                                  setObTarget(o);
                                  setObEmail(((o as any).override_email || o.candidate_email || "").trim());
                                }}
                                style={{ borderColor: "#1a2547", color: "#1a2547", minHeight: 44 }}
                              >
                                <Send className="h-3.5 w-3.5 mr-1" /> Send Onboarding Form
                              </Button>
                              {(() => {
                                const respId = o.candidate_id ? respIdByCandidate[o.candidate_id] : undefined;
                                if (!respId) return null;
                                return (
                                  <>
                                    <Button
                                      size="sm"
                                      variant="outline"
                                      onClick={() => setHrNotesTarget({ responseId: respId, name: o.candidate_name })}
                                      style={{ borderColor: "#b08d57", color: "#b08d57", minHeight: 44 }}
                                      title="HR-only payment details & private notes"
                                    >
                                      <Lock className="h-3.5 w-3.5 mr-1" /> HR Notes
                                    </Button>
                                    <Button
                                      size="sm"
                                      variant="outline"
                                      onClick={() => setEditTarget(o)}
                                      style={{ borderColor: "#1a2547", color: "#1a2547", minHeight: 44 }}
                                      title="Edit this employee's onboarding details"
                                    >
                                      <Pencil className="h-3.5 w-3.5 mr-1" /> Edit Details
                                    </Button>
                                    <Button
                                      size="sm"
                                      variant="outline"
                                      onClick={() => setSylviaTarget({ responseId: respId, name: o.candidate_name })}
                                      style={{ borderColor: "#1a2547", color: "#1a2547", minHeight: 44 }}
                                      title="Assign team & custom instruction for Sylvia"
                                    >
                                      <Sparkles className="h-3.5 w-3.5 mr-1" /> Assign to Sylvia
                                    </Button>
                                    {(() => {
                                      const wc = (o as any).welcome_resend_count ?? 0;
                                      const wtone =
                                        wc >= 5 ? { background: "#dc2626", color: "white", borderColor: "#b91c1c" }
                                        : wc >= 3 ? { background: "#f97316", color: "white", borderColor: "#ea580c" }
                                        : wc >= 1 ? { background: "#fbbf24", color: "#451a03", borderColor: "#f59e0b" }
                                        : { borderColor: "#b08d57", color: "#1a2547" };
                                      return (
                                        <Button
                                          size="sm"
                                          variant="outline"
                                          onClick={() => {
                                            setWelcomeTarget(o);
                                            setWelcomeEmail(((o as any).override_email || o.candidate_email || "").trim());
                                          }}
                                          style={{ ...wtone, minHeight: 44 }}
                                          title="Send the warm welcome email — Sylvia will reach out on WhatsApp"
                                        >
                                          <Send className="h-3.5 w-3.5 mr-1" /> {wc > 0 ? `Re-send Welcome +${wc}` : "Send Welcome Email"}
                                        </Button>
                                      );
                                    })()}
                                  </>
                                );
                              })()}
                              {(() => {
                                const respId = o.candidate_id ? respIdByCandidate[o.candidate_id] : undefined;
                                const nda = respId ? ndaByResp[respId] : undefined;
                                return (
                                  <div className="flex items-center gap-2">
                                    <Button
                                      size="sm"
                                      variant="outline"
                                      disabled={!respId || nda?.status === "signed"}
                                      onClick={() => {
                                        setNdaTarget(o);
                                        setNdaEmail(((o as any).override_email || o.candidate_email || "").trim());
                                      }}
                                      style={{ borderColor: "#b08d57", color: "#b08d57", minHeight: 44 }}
                                      title={!respId ? "Missing response link" : (nda?.status === "signed" ? "NDA already signed" : "Send NDA for e-signature")}
                                    >
                                      <FileSignature className="h-3.5 w-3.5 mr-1" /> Send NDA
                                    </Button>
                                    {nda?.status === "signed" && (
                                      <span className="text-xs px-1.5 py-0.5 rounded" style={{ background: "#dcfce7", color: "#166534" }}>
                                        <Check className="h-3 w-3 inline" /> NDA signed
                                      </span>
                                    )}
                                    {nda?.status === "sent" && (
                                      <span className="text-xs px-1.5 py-0.5 rounded" style={{ background: "#fef3c7", color: "#92400e" }}>
                                        NDA sent
                                      </span>
                                    )}
                                  </div>
                                );
                              })()}
                              <SendOnboardingTestDialog
                                prefillName={o.candidate_name}
                                prefillEmail={((o as any).override_email || o.candidate_email || "").trim()}
                                onSent={load}
                                renderTrigger={(openDialog) => (
                                  <Button
                                    size="sm"
                                    variant="outline"
                                    onClick={openDialog}
                                    style={{ borderColor: "#1a2547", color: "#1a2547", minHeight: 44 }}
                                    title="Send the onboarding video + quiz to this employee"
                                  >
                                    <GraduationCap className="h-3.5 w-3.5 mr-1" /> Send Onboarding Test
                                  </Button>
                                )}
                              />
                              {(() => {
                                const respId = o.candidate_id ? respIdByCandidate[o.candidate_id] : undefined;
                                const jnda = respId ? joiningNdaByResp[respId] : undefined;
                                return (
                                  <div className="flex items-center gap-2">
                                    <Button
                                      size="sm"
                                      variant="outline"
                                      disabled={!respId || jnda?.status === "signed"}
                                      onClick={() => {
                                        setJoiningNdaTarget(o);
                                        setJoiningNdaEmail(((o as any).override_email || o.candidate_email || "").trim());
                                      }}
                                      style={{ borderColor: "#b08d57", color: "#b08d57", minHeight: 44 }}
                                      title={!respId ? "Missing response link" : (jnda?.status === "signed" ? "Joining NDA already signed" : "Send Joining NDA (NDA 1) for e-signature")}
                                    >
                                      <FileSignature className="h-3.5 w-3.5 mr-1" /> Send Joining NDA
                                    </Button>
                                    {jnda?.status === "signed" && (
                                      <span className="text-xs px-1.5 py-0.5 rounded" style={{ background: "#dcfce7", color: "#166534" }}>
                                        <Check className="h-3 w-3 inline" /> Joining NDA signed
                                      </span>
                                    )}
                                    {jnda?.status === "sent" && (
                                      <span className="text-xs px-1.5 py-0.5 rounded" style={{ background: "#fef3c7", color: "#92400e" }}>
                                        Joining NDA sent
                                      </span>
                                    )}
                                  </div>
                                );
                              })()}
                              {(() => {
                                const respId = o.candidate_id ? respIdByCandidate[o.candidate_id] : undefined;
                                const enda = respId ? exitNdaByResp[respId] : undefined;
                                return (
                                  <div className="flex items-center gap-2">
                                    <Button
                                      size="sm"
                                      variant="outline"
                                      disabled={!respId || enda?.status === "signed"}
                                      onClick={() => {
                                        setExitNdaTarget(o);
                                        setExitNdaEmail(((o as any).override_email || o.candidate_email || "").trim());
                                      }}
                                      style={{ borderColor: "#b08d57", color: "#b08d57", minHeight: 44 }}
                                      title={!respId ? "Missing response link" : (enda?.status === "signed" ? "Exit NDA already signed" : "Send Exit NDA (NDA 2 — settlement + post-departure obligations) for e-signature")}
                                    >
                                      <FileSignature className="h-3.5 w-3.5 mr-1" /> Send Exit NDA
                                    </Button>
                                    {enda?.status === "signed" && (
                                      <span className="text-xs px-1.5 py-0.5 rounded" style={{ background: "#dcfce7", color: "#166534" }}>
                                        <Check className="h-3 w-3 inline" /> Exit NDA signed
                                      </span>
                                    )}
                                    {enda?.status === "sent" && (
                                      <span className="text-xs px-1.5 py-0.5 rounded" style={{ background: "#fef3c7", color: "#92400e" }}>
                                        Exit NDA sent
                                      </span>
                                    )}
                                  </div>
                                );
                              })()}
                              <Button
                                size="sm"
                                onClick={() => openOffboard(o)}
                                style={{ background: "#dc2626", color: "white", minHeight: 44 }}
                                title="Offboard / Terminate — pick action and channel"
                              >
                                <UserMinus className="h-3.5 w-3.5 mr-1" /> Offboard / Terminate
                              </Button>
                              {/* On Hold (Piece 1) — reversible pause, separate from Terminate */}
                              {o.hold_status === "on_hold" ? (
                                <Button
                                  size="sm"
                                  onClick={() => { setRemoveHoldTarget(o); setRejoinDate(""); }}
                                  style={{ background: "#16a34a", color: "white", minHeight: 44 }}
                                  title="Remove On Hold — employee resumes; pay and hours count again"
                                >
                                  <PlayCircle className="h-3.5 w-3.5 mr-1" /> Remove On Hold
                                </Button>
                              ) : (
                                <Button
                                  size="sm"
                                  onClick={() => { setHoldTarget(o); setHoldDate(""); }}
                                  style={{ background: "#b91c1c", color: "white", minHeight: 44 }}
                                  title="Put On Hold — reversible pause; pay and hours stop counting"
                                >
                                  <PauseCircle className="h-3.5 w-3.5 mr-1" /> On Hold
                                </Button>
                              )}
                            </div>
                          </TableCell>
                        </TableRow>
                      );
                    })}
                  </TableBody>
                </Table>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Terminated Employees — collapsed by default */}
        <div className="mt-8">
          <button
            type="button"
            onClick={() => setShowTerminated((v) => !v)}
            className="inline-flex items-center gap-2 text-sm font-medium hover:opacity-80"
            style={{ color: "#1a2547", minHeight: 36 }}
          >
            {showTerminated ? <ChevronDown className="h-4 w-4" /> : <ChevronRight className="h-4 w-4" />}
            {showTerminated ? "Hide" : "Show"} terminated employees
            <span className="text-xs px-1.5 py-0.5 rounded" style={{ background: "#fee2e2", color: "#991b1b" }}>
              {terminatedOffers.length}
            </span>
          </button>

          {showTerminated && (
            <Card className="mt-3" style={{ opacity: 0.92 }}>
              <CardContent className="p-0">
                {terminatedOffers.length === 0 ? (
                  <div className="p-8 text-center text-muted-foreground text-sm">
                    No terminated employees on record.
                  </div>
                ) : (
                  <div className="overflow-x-auto">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Name</TableHead>
                          <TableHead>Position</TableHead>
                          <TableHead>Terminated</TableHead>
                          <TableHead>Type</TableHead>
                          <TableHead className="text-right w-[380px] max-w-[380px]">Actions</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {terminatedOffers.map((o) => {
                          const isEval = o.employment_status === "terminated_evaluation";
                          const respId = o.candidate_id ? respIdByCandidate[o.candidate_id] : undefined;
                          return (
                            <TableRow key={o.id} style={{ opacity: 0.85 }}>
                              <TableCell>
                                <div className="font-medium">{o.candidate_name}</div>
                                <div className="text-xs text-muted-foreground">{o.candidate_email}</div>
                              </TableCell>
                              <TableCell>{o.position_title}</TableCell>
                              <TableCell>{fmtDate(o.terminated_at ?? null)}</TableCell>
                              <TableCell>
                                <Badge
                                  variant="outline"
                                  style={{
                                    borderColor: isEval ? "#d97706" : "#dc2626",
                                    color: isEval ? "#d97706" : "#dc2626",
                                  }}
                                >
                                  {isEval ? "Trial Termination" : "Termination"}
                                </Badge>
                              </TableCell>
                               <TableCell className="text-right w-[380px] max-w-[380px]">
                                <div className="flex justify-end gap-2 flex-wrap ml-auto">
                                  {/* Send Termination Letter — full offboard terminate flow (sends the letter) */}
                                  <Button
                                    size="sm"
                                    variant="outline"
                                    onClick={() => openOffboard(o, { action: "regular", channel: "email" })}
                                    style={{ borderColor: "#dc2626", color: "#dc2626", minHeight: 44 }}
                                    title="Send the formal termination letter"
                                  >
                                    <Mail className="h-3.5 w-3.5 mr-1" /> Send Termination Letter
                                  </Button>
                                  {/* Send Termination via Sylvia — queued WhatsApp no-op until channel connects */}
                                  <Button
                                    size="sm"
                                    variant="outline"
                                    onClick={() => openOffboard(o, { action: "regular", channel: "whatsapp" })}
                                    style={{ borderColor: "#1a2547", color: "#1a2547", minHeight: 44 }}
                                    title="Send termination via Sylvia (WhatsApp — queued until the channel is connected)"
                                  >
                                    <Sparkles className="h-3.5 w-3.5 mr-1" /> Send Termination via Sylvia
                                  </Button>
                                  {/* Send Exit NDA — reuse the existing exit-NDA dialog */}
                                  <Button
                                    size="sm"
                                    variant="outline"
                                    disabled={!respId}
                                    onClick={() => {
                                      setExitNdaTarget(o);
                                      setExitNdaEmail(((o as any).override_email || o.candidate_email || "").trim());
                                    }}
                                    style={{ borderColor: "#b08d57", color: "#b08d57", minHeight: 44 }}
                                    title={!respId ? "Missing response link" : "Send Exit NDA (NDA 2) for e-signature"}
                                  >
                                    <FileSignature className="h-3.5 w-3.5 mr-1" /> Send Exit NDA
                                  </Button>
                                  {/* Send Settlement (Zero-Balance) — reuse the offboard settlement flow */}
                                  <Button
                                    size="sm"
                                    variant="outline"
                                    onClick={() => openOffboard(o, { action: "settlement", channel: "email" })}
                                    style={{ borderColor: "#b08d57", color: "#b08d57", minHeight: 44 }}
                                    title="Send Settlement (Zero-Balance)"
                                  >
                                    <FileSignature className="h-3.5 w-3.5 mr-1" /> Send Settlement (Zero-Balance)
                                  </Button>
                                  {/* Existing — re-send the on-file Notice of Termination (no status change) */}
                                  <Button
                                    size="sm"
                                    variant="outline"
                                    onClick={() => openResend(o)}
                                    style={{ borderColor: "#d97706", color: "#d97706", minHeight: 44 }}
                                    title="Send (or re-send) the formal Notice of Termination email"
                                  >
                                    <Mail className="h-3.5 w-3.5 mr-1" /> Send Termination Email Later
                                  </Button>
                                  {/* Restore — flip employment_status back to active */}
                                  <Button
                                    size="sm"
                                    onClick={() => setRestoreTarget(o)}
                                    style={{ background: "#16a34a", color: "white", minHeight: 44 }}
                                    title="Restore this employee to the active list"
                                  >
                                    <PlayCircle className="h-3.5 w-3.5 mr-1" /> Restore
                                  </Button>
                                </div>
                              </TableCell>
                            </TableRow>
                          );
                        })}
                      </TableBody>
                    </Table>
                  </div>
                )}
              </CardContent>
            </Card>
          )}
        </div>
      </main>

      {/* Send Termination Email Later modal */}
      <Dialog open={!!resendTarget} onOpenChange={(o) => { if (!o) closeResend(); }}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Mail className="h-5 w-5" style={{ color: "#d97706" }} />
              Send Termination Email — {resendTarget?.candidate_name}
            </DialogTitle>
            <DialogDescription>
              Sends the formal Notice of Termination using the exact wording on file. Does not change employment status.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-3 text-sm">
            <div>
              <Label className="text-sm font-medium">Send to</Label>
              <Input
                type="email"
                value={resendEmail}
                onChange={(e) => setResendEmail(e.target.value)}
                placeholder="employee@example.com"
              />
              <p className="text-xs text-muted-foreground mt-1">Pre-filled from the offer. Edit to correct.</p>
            </div>
            <div>
              <Label className="text-sm font-medium">Boss password</Label>
              <Input
                type="password"
                value={resendPwd}
                onChange={(e) => setResendPwd(e.target.value)}
                onKeyDown={(e) => { if (e.key === "Enter" && resendPwd && resendEmail) submitResend(); }}
                placeholder="Password"
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="ghost" onClick={closeResend} disabled={resendBusy}>Cancel</Button>
            <Button
              onClick={submitResend}
              disabled={resendBusy || !resendPwd || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(resendEmail.trim())}
              style={{ background: "#d97706", color: "white" }}
            >
              {resendBusy ? <Loader2 className="h-4 w-4 animate-spin" /> : "Send Termination Email"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Restore (un-terminate) confirm modal */}
      <Dialog open={!!restoreTarget} onOpenChange={(o) => { if (!o && !restoreBusy) setRestoreTarget(null); }}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <PlayCircle className="h-5 w-5" style={{ color: "#16a34a" }} />
              Restore {restoreTarget?.candidate_name}?
            </DialogTitle>
            <DialogDescription>
              This sets the employee's status back to active and returns them to the active employees list. No email is sent.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button variant="ghost" onClick={() => { if (!restoreBusy) setRestoreTarget(null); }} disabled={restoreBusy}>Cancel</Button>
            <Button onClick={submitRestore} disabled={restoreBusy} style={{ background: "#16a34a", color: "white" }}>
              {restoreBusy ? <Loader2 className="h-4 w-4 animate-spin" /> : "Restore to Active"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>




      {/* Offboard / Terminate consolidated modal */}
      <Dialog open={!!target} onOpenChange={(o) => { if (!o) closeModal(); }}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <UserMinus className="h-5 w-5" style={{ color: "#dc2626" }} />
              Offboard / Terminate Employee — {target?.candidate_name}
            </DialogTitle>
            <DialogDescription>
              {target?.position_title} · Started {fmtDate(target?.start_date ?? null)} · {target ? daysBetween(target.start_date) : 0} days active
            </DialogDescription>
          </DialogHeader>

          {target && step === "confirm" && (
            <div className="space-y-4 text-sm">
              {/* ACTION picker */}
              <div className="space-y-2">
                <Label className="text-sm font-semibold">Action</Label>
                <RadioGroup
                  value={action}
                  onValueChange={(v) => {
                    const a = v as OffboardAction;
                    setAction(a);
                    if (a === "evaluation" || a === "regular") setTermType(a);
                  }}
                  className="space-y-1.5"
                >
                  {(["evaluation","regular","settlement","resign_nda1","resign_nda2"] as OffboardAction[]).map((a) => (
                    <label key={a} htmlFor={`act-${a}`} className="flex items-center gap-2 cursor-pointer min-h-[36px]">
                      <RadioGroupItem id={`act-${a}`} value={a} />
                      <span className={a === "regular" ? "text-red-600 font-medium" : a === "evaluation" ? "text-amber-700 font-medium" : ""}>
                        {actionLabel(a)}
                      </span>
                    </label>
                  ))}
                </RadioGroup>
              </div>

              {/* CHANNEL picker */}
              <div className="space-y-2">
                <Label className="text-sm font-semibold">Channel</Label>
                <RadioGroup
                  value={channel}
                  onValueChange={(v) => setChannel(v as OffboardChannel)}
                  className="flex gap-4"
                >
                  <label htmlFor="ch-email" className="flex items-center gap-2 cursor-pointer min-h-[36px]">
                    <RadioGroupItem id="ch-email" value="email" />
                    <span>Email</span>
                  </label>
                  <label htmlFor="ch-wa" className="flex items-center gap-2 cursor-pointer min-h-[36px]">
                    <RadioGroupItem id="ch-wa" value="whatsapp" />
                    <span>WhatsApp via Sylvia</span>
                  </label>
                </RadioGroup>
                {channel === "whatsapp" && (
                  <p className="text-xs text-muted-foreground">
                    WhatsApp delivery is not yet connected. Submitting will queue the intent in the audit log and (for terminate actions) still update the employee's status without sending any email.
                  </p>
                )}
              </div>

              {/* SUPPRESS checkbox — only for terminate actions on Email channel */}
              {isTerminateAction && channel === "email" && (
                <div className="rounded-md border p-3 space-y-2">
                  <label htmlFor="term-send-email" className="flex items-center gap-3 cursor-pointer min-h-[44px]">
                    <Checkbox
                      id="term-send-email"
                      checked={!sendEmail}
                      onCheckedChange={(v) => setSendEmail(!(v === true))}
                      className="h-5 w-5"
                    />
                    <span className="text-sm font-medium">Don't send the termination email (HR already informed the candidate outside the app)</span>
                  </label>
                </div>
              )}

              {/* EMAIL field — only when channel=email and action sends a message */}
              {needsEmailField && (
                <div>
                  <Label className="text-sm font-medium">Send to</Label>
                  <Input
                    type="email"
                    value={sendToEmail}
                    onChange={(e) => setSendToEmail(e.target.value)}
                    placeholder="employee@example.com"
                  />
                  <p className="text-xs text-muted-foreground mt-1">Enter the recipient's email address.</p>
                </div>
              )}

              {/* INTERNAL NOTES — only for terminate actions */}
              {isTerminateAction && (
                <div>
                  <Label className="text-sm font-medium">Reason for termination (optional — internal only, not sent to employee)</Label>
                  <Textarea value={notes} onChange={(e) => setNotes(e.target.value)} rows={3} placeholder="e.g. performance issues, attendance, role mismatch…" />
                </div>
              )}

              {/* HR backup copy opt-in — applies to terminate (immediate) and settlement/NDA (on completion) */}
              {(channel === "email" && (!isTerminateAction || sendEmail)) && (
                <HrCopyCheckbox
                  value={hrCopy}
                  onChange={setHrCopy}
                  disabled={busy}
                  label={
                    isTerminateAction
                      ? "Send copy of termination email to internal backup inbox"
                      : `If ${action === "settlement" ? "settlement" : action === "resign_nda1" ? "NDA 1" : "NDA 2"} is signed, send copy to internal backup inbox`
                  }
                  idPrefix={`offb-hrcopy-${action}`}
                />
              )}
            </div>
          )}

          {target && step === "password" && (
            <div className="space-y-2">
              <p className="text-sm">Enter Boss password to confirm termination.</p>
              <Input
                type="password" value={pwd} autoFocus
                onChange={(e) => setPwd(e.target.value)}
                onKeyDown={(e) => { if (e.key === "Enter" && pwd) submitOffboard(); }}
                placeholder="Password"
              />
            </div>
          )}

          <DialogFooter>
            <Button variant="ghost" onClick={closeModal} disabled={busy}>Cancel</Button>
            {step === "confirm" ? (
              isTerminateAction ? (
                <Button
                  onClick={() => setStep("password")}
                  disabled={channel === "email" && sendEmail && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(sendToEmail.trim())}
                  style={{ background: action === "evaluation" ? "#d97706" : "#dc2626", color: "white" }}
                >
                  Continue
                </Button>
              ) : (
                <Button
                  onClick={submitOffboard}
                  disabled={busy || (channel === "email" && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(sendToEmail.trim()))}
                  style={{ background: "#1a2547", color: "white" }}
                >
                  {busy ? <Loader2 className="h-4 w-4 animate-spin" /> : confirmLabel(action)}
                </Button>
              )
            ) : (
              <Button onClick={submitOffboard} disabled={busy || !pwd} style={{ background: action === "evaluation" ? "#d97706" : "#dc2626", color: "white" }}>
                {busy ? <Loader2 className="h-4 w-4 animate-spin" /> : confirmLabel(action)}
              </Button>
            )}
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Onboarding invite modal */}
      <Dialog open={!!obTarget} onOpenChange={(o) => { if (!o && !obBusy) { setObTarget(null); setObEmail(""); } }}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Send className="h-5 w-5" style={{ color: "#1a2547" }} />
              Send Onboarding Form to {obTarget?.candidate_name}?
            </DialogTitle>
            <DialogDescription>
              They'll receive a branded email with a 30-day link to complete their onboarding form.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-3 text-sm">
            <div>
              <label className="text-sm font-medium">Send onboarding email to</label>
              <Input
                type="email"
                value={obEmail}
                onChange={(e) => setObEmail(e.target.value)}
                placeholder="employee@example.com"
              />
              <p className="text-xs text-muted-foreground mt-1">Pre-filled from the offer. Edit to correct.</p>
            </div>
          </div>
          <DialogFooter>
            <Button variant="ghost" onClick={() => { if (!obBusy) { setObTarget(null); setObEmail(""); } }} disabled={obBusy}>Cancel</Button>
            <Button
              disabled={obBusy || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(obEmail.trim()) || !obTarget?.candidate_id || !respIdByCandidate[obTarget!.candidate_id!]}
              onClick={async () => {
                if (!obTarget?.candidate_id) return;
                const respId = respIdByCandidate[obTarget.candidate_id];
                if (!respId) { toast.error("Missing response link for this employee."); return; }
                setObBusy(true);
                try {
                  const { data: mintData, error: mintErr } = await supabase.functions.invoke<any>("mint-onboarding-token", { body: { response_id: respId } });
                  if (mintErr || !mintData?.token) { toast.error(mintData?.error || "Could not create onboarding link."); return; }
                  const { data: sendData, error: sendErr } = await supabase.functions.invoke<any>("send-onboarding-invite", {
                    body: { response_id: respId, token: mintData.token, override_email: obEmail.trim() },
                  });
                  if (sendErr || sendData?.error || !sendData?.success) { toast.error(sendData?.error || "Could not send email."); return; }
                  toast.success(`Onboarding form sent to ${obEmail.trim()}`);
                  setObTarget(null); setObEmail("");
                } finally {
                  setObBusy(false);
                }
              }}
              style={{ background: "#1a2547", color: "white" }}
            >
              {obBusy ? <Loader2 className="h-4 w-4 animate-spin" /> : "Send onboarding form"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Send Welcome (Sylvia) modal */}
      <Dialog open={!!welcomeTarget} onOpenChange={(o) => { if (!o && !welcomeBusy) { setWelcomeTarget(null); setWelcomeEmail(""); } }}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Send className="h-5 w-5" style={{ color: "#b08d57" }} />
              Send Welcome Email to {welcomeTarget?.candidate_name}?
            </DialogTitle>
            <DialogDescription>
              They'll receive a warm welcome from EIA letting them know Sylvia will reach out on WhatsApp (+1 917 735 8220) to start onboarding.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-3 text-sm">
            <div>
              <label className="text-sm font-medium">Send welcome email to</label>
              <Input
                type="email"
                value={welcomeEmail}
                onChange={(e) => setWelcomeEmail(e.target.value)}
                placeholder="employee@example.com"
              />
              <p className="text-xs text-muted-foreground mt-1">Pre-filled from the offer. Edit to correct.</p>
            </div>
          </div>
          <DialogFooter>
            <Button variant="ghost" onClick={() => { if (!welcomeBusy) { setWelcomeTarget(null); setWelcomeEmail(""); } }} disabled={welcomeBusy}>Cancel</Button>
            <Button
              disabled={welcomeBusy || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(welcomeEmail.trim()) || !welcomeTarget?.candidate_id}
              onClick={async () => {
                if (!welcomeTarget?.candidate_id) return;
                setWelcomeBusy(true);
                try {
                  const { data, error } = await supabase.functions.invoke<any>("send-sylvia-welcome", {
                    body: { candidate_id: welcomeTarget.candidate_id, override_email: welcomeEmail.trim() },
                  });
                  if (error || !data?.ok) {
                    const err = data?.error || error?.message || "send_failed";
                    if (err === "no_email") toast.error("No email on file for this candidate");
                    else toast.error(`Could not send welcome email: ${err}`);
                    return;
                  }
                  toast.success(`Welcome email sent to ${welcomeEmail.trim()}`);
                  // Bump + persist the welcome re-send counter (mirrors Re-Send Round 1).
                  const next = (welcomeTarget.welcome_resend_count ?? 0) + 1;
                  const offerId = welcomeTarget.id;
                  setOffers((prev) => prev.map((x) => x.id === offerId ? { ...x, welcome_resend_count: next } : x));
                  const { error: bumpErr } = await supabase
                    .from("job_offers")
                    .update({ welcome_resend_count: next })
                    .eq("id", offerId);
                  if (bumpErr) {
                    setOffers((prev) => prev.map((x) => x.id === offerId ? { ...x, welcome_resend_count: next - 1 } : x));
                  }
                  setWelcomeTarget(null); setWelcomeEmail("");
                } finally {
                  setWelcomeBusy(false);
                }
              }}
              style={{ background: "#1a2547", color: "white" }}
            >
              {welcomeBusy ? <Loader2 className="h-4 w-4 animate-spin" /> : "Send welcome email"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Send NDA modal */}
      <Dialog open={!!ndaTarget} onOpenChange={(o) => { if (!o && !ndaBusy) { setNdaTarget(null); setNdaEmail(""); } }}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <FileSignature className="h-5 w-5" style={{ color: "#b08d57" }} />
              Send NDA to {ndaTarget?.candidate_name}?
            </DialogTitle>
            <DialogDescription>
              They'll receive a branded email with a secure link to review and sign the Non-Disclosure Agreement.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-3 text-sm">
            <div>
              <label className="text-sm font-medium">Send NDA email to</label>
              <Input
                type="email"
                value={ndaEmail}
                onChange={(e) => setNdaEmail(e.target.value)}
                placeholder="employee@example.com"
              />
              <p className="text-xs text-muted-foreground mt-1">Pre-filled from the offer. Edit to correct (will be saved as the new contact email).</p>
            </div>
          </div>
          <DialogFooter>
            <Button variant="ghost" onClick={() => { if (!ndaBusy) { setNdaTarget(null); setNdaEmail(""); } }} disabled={ndaBusy}>Cancel</Button>
            <Button
              disabled={ndaBusy || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(ndaEmail.trim()) || !ndaTarget?.candidate_id || !respIdByCandidate[ndaTarget!.candidate_id!]}
              onClick={async () => {
                if (!ndaTarget?.candidate_id) return;
                const respId = respIdByCandidate[ndaTarget.candidate_id];
                if (!respId) { toast.error("Missing response link for this employee."); return; }
                const recipient = ndaEmail.trim();
                setNdaBusy(true);
                try {
                  // Persist override_email single-row (matches pattern used elsewhere)
                  if (recipient && recipient !== (ndaTarget as any).override_email) {
                    await (supabase.from("responses") as any).update({ override_email: recipient }).eq("id", respId);
                  }
                  const { data, error } = await supabase.functions.invoke<any>("send-nda", {
                    body: { response_id: respId, override_email: recipient },
                  });
                  if (error || !data?.ok) {
                    const reason = data?.reason || error?.message || "send_failed";
                    toast.error(`NDA send failed: ${reason}`);
                    return;
                  }
                  toast.success(`NDA sent to ${recipient}`);
                  // Optimistic status update
                  setNdaByResp((prev) => ({ ...prev, [respId]: { status: "sent", signed_at: null } }));
                  setNdaTarget(null); setNdaEmail("");
                } finally {
                  setNdaBusy(false);
                }
              }}
              style={{ background: "#b08d57", color: "white" }}
            >
              {ndaBusy ? <Loader2 className="h-4 w-4 animate-spin" /> : "Send NDA"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Send Joining NDA modal */}
      <Dialog open={!!joiningNdaTarget} onOpenChange={(o) => { if (!o && !joiningNdaBusy) { setJoiningNdaTarget(null); setJoiningNdaEmail(""); } }}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <FileSignature className="h-5 w-5" style={{ color: "#b08d57" }} />
              Send Joining NDA to {joiningNdaTarget?.candidate_name}?
            </DialogTitle>
            <DialogDescription>
              They'll receive a branded email with a secure link to review and sign the Joining NDA (NDA 1 — full confidentiality &amp; non-compete).
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-3 text-sm">
            <div>
              <label className="text-sm font-medium">Send Joining NDA email to</label>
              <Input
                type="email"
                value={joiningNdaEmail}
                onChange={(e) => setJoiningNdaEmail(e.target.value)}
                placeholder="employee@example.com"
              />
              <p className="text-xs text-muted-foreground mt-1">Pre-filled from the offer. Edit to correct (will be saved as the new contact email).</p>
            </div>
          </div>
          <DialogFooter>
            <Button variant="ghost" onClick={() => { if (!joiningNdaBusy) { setJoiningNdaTarget(null); setJoiningNdaEmail(""); } }} disabled={joiningNdaBusy}>Cancel</Button>
            <Button
              disabled={joiningNdaBusy || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(joiningNdaEmail.trim()) || !joiningNdaTarget?.candidate_id || !respIdByCandidate[joiningNdaTarget!.candidate_id!]}
              onClick={async () => {
                if (!joiningNdaTarget?.candidate_id) return;
                const respId = respIdByCandidate[joiningNdaTarget.candidate_id];
                if (!respId) { toast.error("Missing response link for this employee."); return; }
                const recipient = joiningNdaEmail.trim();
                setJoiningNdaBusy(true);
                try {
                  if (recipient && recipient !== (joiningNdaTarget as any).override_email) {
                    await (supabase.from("responses") as any).update({ override_email: recipient }).eq("id", respId);
                  }
                  const { data, error } = await supabase.functions.invoke<any>("send-joining-nda", {
                    body: { response_id: respId, override_email: recipient },
                  });
                  if (error || !data?.ok) {
                    const reason = data?.reason || error?.message || "send_failed";
                    toast.error(`Joining NDA send failed: ${reason}`);
                    return;
                  }
                  toast.success(`Joining NDA sent to ${recipient}`);
                  setJoiningNdaByResp((prev) => ({ ...prev, [respId]: { status: "sent", signed_at: null } }));
                  setJoiningNdaTarget(null); setJoiningNdaEmail("");
                } finally {
                  setJoiningNdaBusy(false);
                }
              }}
              style={{ background: "#b08d57", color: "white" }}
            >
              {joiningNdaBusy ? <Loader2 className="h-4 w-4 animate-spin" /> : "Send Joining NDA"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Send Exit NDA modal */}
      <Dialog open={!!exitNdaTarget} onOpenChange={(o) => { if (!o && !exitNdaBusy) { setExitNdaTarget(null); setExitNdaEmail(""); } }}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <FileSignature className="h-5 w-5" style={{ color: "#b08d57" }} />
              Send Exit NDA to {exitNdaTarget?.candidate_name}?
            </DialogTitle>
            <DialogDescription>
              They'll receive a branded email with a secure link to review and sign the Exit Settlement &amp; Confidentiality Agreement (NDA 2 — zero-balance settlement, reaffirmed NDA 1 obligations, mandatory data deletion).
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-3 text-sm">
            <div>
              <label className="text-sm font-medium">Send Exit NDA email to</label>
              <Input
                type="email"
                value={exitNdaEmail}
                onChange={(e) => setExitNdaEmail(e.target.value)}
                placeholder="employee@example.com"
              />
              <p className="text-xs text-muted-foreground mt-1">Pre-filled from the offer. Edit to correct (will be saved as the new contact email).</p>
            </div>
          </div>
          <DialogFooter>
            <Button variant="ghost" onClick={() => { if (!exitNdaBusy) { setExitNdaTarget(null); setExitNdaEmail(""); } }} disabled={exitNdaBusy}>Cancel</Button>
            <Button
              disabled={exitNdaBusy || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(exitNdaEmail.trim()) || !exitNdaTarget?.candidate_id || !respIdByCandidate[exitNdaTarget!.candidate_id!]}
              onClick={async () => {
                if (!exitNdaTarget?.candidate_id) return;
                const respId = respIdByCandidate[exitNdaTarget.candidate_id];
                if (!respId) { toast.error("Missing response link for this employee."); return; }
                const recipient = exitNdaEmail.trim();
                setExitNdaBusy(true);
                try {
                  if (recipient && recipient !== (exitNdaTarget as any).override_email) {
                    await (supabase.from("responses") as any).update({ override_email: recipient }).eq("id", respId);
                  }
                  const { data, error } = await supabase.functions.invoke<any>("send-exit-nda", {
                    body: { response_id: respId, override_email: recipient },
                  });
                  if (error || !data?.ok) {
                    const reason = data?.reason || error?.message || "send_failed";
                    toast.error(`Exit NDA send failed: ${reason}`);
                    return;
                  }
                  toast.success(`Exit NDA sent to ${recipient}`);
                  setExitNdaByResp((prev) => ({ ...prev, [respId]: { status: "sent", signed_at: null } }));
                  setExitNdaTarget(null); setExitNdaEmail("");
                } finally {
                  setExitNdaBusy(false);
                }
              }}
              style={{ background: "#b08d57", color: "white" }}
            >
              {exitNdaBusy ? <Loader2 className="h-4 w-4 animate-spin" /> : "Send Exit NDA"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>




      {/* Decision (Approve/Decline) popup */}
      <AlertDialog
        open={!!decideTarget}
        onOpenChange={(o) => { if (!o && !decideBusy) { setDecideTarget(null); setDecideNote(""); } }}
      >
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>
              {decideTarget?.decision === "approved" ? "Approve" : "Decline"} leave for {decideTarget?.leave.signer_name || "this employee"}?
            </AlertDialogTitle>
            <AlertDialogDescription>
              {decideTarget?.decision === "approved"
                ? "An approval email + signed PDF will be sent to the employee."
                : "A warm decline email + decision PDF will be sent to the employee."}
            </AlertDialogDescription>
          </AlertDialogHeader>
          <div className="space-y-2 py-2">
            <label className="text-sm font-medium">
              {decideTarget?.decision === "approved"
                ? "Note to employee (optional — e.g. partial approval terms)"
                : "Reason for declining (shown to employee)"}
            </label>
            <Textarea
              value={decideNote}
              onChange={(e) => setDecideNote(e.target.value)}
              rows={4}
              placeholder={decideTarget?.decision === "approved"
                ? "Approved as requested. Please coordinate with your coverer."
                : "We can't approve this time because…"}
            />
          </div>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={decideBusy}>Cancel</AlertDialogCancel>
            <AlertDialogAction
              disabled={decideBusy}
              onClick={async (e) => {
                e.preventDefault();
                if (!decideTarget) return;
                setDecideBusy(true);
                const { leave, decision } = decideTarget;
                try {
                  const fn =
                    leave.doc_type === "cash_advance" ? "decide-cash-advance"
                    : leave.doc_type === "id_collection" ? "decide-id-collection"
                    : leave.doc_type === "pre_consultation" ? "decide-pre-consultation"
                    : "decide-leave";
                  const { data, error } = await supabase.functions.invoke<any>(fn, {
                    body: { leave_request_id: leave.id, decision, note: decideNote.trim() || null },
                  });
                  if (error || !data?.ok) {
                    toast.error(`Could not ${decision === "approved" ? "approve" : "decline"}: ${data?.reason || error?.message || "failed"}`);
                    return;
                  }
                  const partial = data?.pdf_warning || data?.email_warning;
                  if (partial) {
                    toast.warning(`Decision saved, but: ${data.pdf_warning || data.email_warning}`);
                  } else {
                    toast.success(`Leave ${decision} — email sent to ${leave.signer_name || "employee"}.`);
                  }
                  // Optimistic UI: remove from pending; refresh leavesByResp by reloading
                  setPendingLeaves((prev) => prev.filter((x) => x.id !== leave.id));
                  if (leave.response_id) {
                    setLeavesByResp((prev) => {
                      const list = (prev[leave.response_id!] || []).map((r) =>
                        r.id === leave.id
                          ? { ...r, status: decision as any, hr_decision_note: decideNote.trim() || null, signed_pdf_url: data?.pdf_url ?? r.signed_pdf_url, decided_at: new Date().toISOString() }
                          : r
                      );
                      // Add it if missing
                      if (!list.find((r) => r.id === leave.id)) {
                        list.unshift({ ...leave, status: decision as any, hr_decision_note: decideNote.trim() || null, signed_pdf_url: data?.pdf_url ?? null, decided_at: new Date().toISOString() });
                      }
                      return { ...prev, [leave.response_id!]: list };
                    });
                  }
                  setDecideTarget(null); setDecideNote("");
                } finally {
                  setDecideBusy(false);
                }
              }}
              className={decideTarget?.decision === "approved" ? "bg-green-600 hover:bg-green-700" : "bg-destructive text-destructive-foreground hover:bg-destructive/90"}
            >
              {decideBusy ? <Loader2 className="h-4 w-4 mr-2 animate-spin" /> : null}
              {decideTarget?.decision === "approved" ? "Approve leave" : "Decline leave"}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Filed leaves popup */}
      <Dialog open={!!leavesPopupFor} onOpenChange={(o) => { if (!o) setLeavesPopupFor(null); }}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle>Leave requests — {leavesPopupFor?.offer.candidate_name}</DialogTitle>
            <DialogDescription>All filed leave requests for this employee.</DialogDescription>
          </DialogHeader>
          <div className="space-y-2 max-h-[60vh] overflow-y-auto">
            {(leavesPopupFor?.rows || []).map((lr) => {
              const badge = lr.status === "approved"
                ? { bg: "#dcfce7", color: "#166534", label: "Approved" }
                : lr.status === "declined"
                ? { bg: "#fee2e2", color: "#991b1b", label: "Declined" }
                : { bg: "#fef3c7", color: "#92400e", label: "Pending" };
              return (
                <div key={lr.id} className="border rounded-md p-3 text-sm">
                  <div className="flex items-center justify-between gap-2 mb-1">
                    <span className="text-xs text-muted-foreground">{lr.external_reference}</span>
                    <span className="text-xs px-2 py-0.5 rounded" style={{ background: badge.bg, color: badge.color }}>
                      {badge.label}
                    </span>
                  </div>
                  <div><span className="text-muted-foreground">Reason:</span> {lr.reason || "—"}</div>
                  <div className="text-xs text-muted-foreground mt-1">
                    Start {lr.start_date || "—"} · {lr.num_days || "—"} day(s) · {lr.hours_missed || "—"} hrs
                  </div>
                  {lr.hr_decision_note && (
                    <div className="text-xs mt-1"><span className="text-muted-foreground">HR note:</span> {lr.hr_decision_note}</div>
                  )}
                  {lr.signed_pdf_url && (
                    <a
                      href={lr.signed_pdf_url}
                      target="_blank" rel="noopener noreferrer"
                      className="inline-flex items-center gap-1 text-xs mt-2 underline"
                      style={{ color: "#1a2547" }}
                    >
                      <ExternalLink className="h-3 w-3" /> View signed PDF
                    </a>
                  )}
                </div>
              );
            })}
          </div>
          <DialogFooter>
            <Button variant="ghost" onClick={() => setLeavesPopupFor(null)}>Close</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <EmployeeHrNotesDialog
        open={!!hrNotesTarget}
        onClose={() => setHrNotesTarget(null)}
        responseId={hrNotesTarget?.responseId || null}
        candidateName={hrNotesTarget?.name}
      />

      <EditEmployeeDetailsDialog
        open={!!editTarget}
        onClose={() => setEditTarget(null)}
        responseId={editTarget?.candidate_id ? (respIdByCandidate[editTarget.candidate_id] || null) : null}
        fallbackName={editTarget?.candidate_name}
        fallbackEmail={editTarget?.candidate_email}
        fallbackPosition={editTarget?.position_title}
        onSaved={() => load()}
      />



      {sylviaTarget && (
        <AssignToSylviaDialog
          open={!!sylviaTarget}
          onOpenChange={(v) => { if (!v) setSylviaTarget(null); }}
          responseId={sylviaTarget.responseId}
          candidateName={sylviaTarget.name}
        />
      )}

      {/* Put On Hold modal (Piece 1 status + Piece 2 email) */}
      <Dialog open={!!holdTarget} onOpenChange={(v) => { if (!v) { setHoldTarget(null); setHoldDate(""); } }}>
        <DialogContent className="max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Put On Hold — {holdTarget?.candidate_name}</DialogTitle>
            <DialogDescription>
              A reversible pause (e.g. laid off or employee went missing). Pay and hours stop counting.
              This does NOT terminate the employee — they stay in the Employees list and can be reinstated anytime.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="hold-effective-date">Effective working date (leave blank for immediate)</Label>
              <Input
                id="hold-effective-date"
                type="date"
                value={holdDate}
                onChange={(e) => setHoldDate(e.target.value)}
                disabled={holdBusy}
              />
            </div>

            <label htmlFor="hold-email-on" className="flex items-start gap-2 cursor-pointer rounded-md border bg-muted/30 p-3">
              <Checkbox
                id="hold-email-on"
                checked={holdEmailOn}
                onCheckedChange={(v) => setHoldEmailOn(!!v)}
                disabled={holdBusy}
                className="mt-0.5"
              />
              <div className="flex-1 min-w-0">
                <div className="text-sm font-medium text-foreground leading-snug">Email the employee an On Hold notice</div>
                <div className="text-xs text-muted-foreground mt-0.5">
                  On by default. Uncheck to set the status silently with no email.
                </div>
              </div>
            </label>

            {holdEmailOn && (
              <div className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="hold-name">Recipient name</Label>
                  <Input id="hold-name" value={holdName} onChange={(e) => setHoldName(e.target.value)} disabled={holdBusy} placeholder="Jane Doe" />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="hold-email">Recipient email</Label>
                  <Input id="hold-email" type="email" value={holdEmail} onChange={(e) => setHoldEmail(e.target.value)} disabled={holdBusy} placeholder="jane@example.com" />
                </div>
                <p className="text-xs text-muted-foreground">
                  A copy is always sent to the internal Outlook backup inbox.
                </p>
                <HrCopyCheckbox
                  value={holdHrCopy}
                  onChange={setHoldHrCopy}
                  disabled={holdBusy}
                  label="Also send a copy to"
                  idPrefix="hold-hrcopy"
                />
                <SendScheduleControl onChange={setHoldSchedule} />
              </div>
            )}
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => { setHoldTarget(null); setHoldDate(""); }} disabled={holdBusy}>Cancel</Button>
            <Button
              onClick={confirmPutOnHold}
              disabled={holdBusy}
              style={{ background: "#b91c1c", color: "white" }}
            >
              {holdBusy ? <Loader2 className="h-4 w-4 mr-1 animate-spin" /> : <PauseCircle className="h-4 w-4 mr-1" />}
              Confirm On Hold
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Remove On Hold modal (Piece 1 status + Piece 2 reactivation email) */}
      <Dialog open={!!removeHoldTarget} onOpenChange={(v) => { if (!v) { setRemoveHoldTarget(null); setRejoinDate(""); } }}>
        <DialogContent className="max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Remove On Hold — {removeHoldTarget?.candidate_name}</DialogTitle>
            <DialogDescription>
              The employee resumes. Pay and hours start counting again from the re-joining date.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="rejoin-date">Re-joining date (leave blank for immediate)</Label>
              <Input
                id="rejoin-date"
                type="date"
                value={rejoinDate}
                onChange={(e) => setRejoinDate(e.target.value)}
                disabled={removeHoldBusy}
              />
            </div>

            <label htmlFor="remove-email-on" className="flex items-start gap-2 cursor-pointer rounded-md border bg-muted/30 p-3">
              <Checkbox
                id="remove-email-on"
                checked={removeEmailOn}
                onCheckedChange={(v) => setRemoveEmailOn(!!v)}
                disabled={removeHoldBusy}
                className="mt-0.5"
              />
              <div className="flex-1 min-w-0">
                <div className="text-sm font-medium text-foreground leading-snug">Email the employee a Welcome Back notice</div>
                <div className="text-xs text-muted-foreground mt-0.5">
                  On by default. Uncheck to clear the status silently with no email.
                </div>
              </div>
            </label>

            {removeEmailOn && (
              <div className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="remove-name">Recipient name</Label>
                  <Input id="remove-name" value={removeName} onChange={(e) => setRemoveName(e.target.value)} disabled={removeHoldBusy} placeholder="Jane Doe" />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="remove-email">Recipient email</Label>
                  <Input id="remove-email" type="email" value={removeEmail} onChange={(e) => setRemoveEmail(e.target.value)} disabled={removeHoldBusy} placeholder="jane@example.com" />
                </div>
                <p className="text-xs text-muted-foreground">
                  A copy is always sent to the internal Outlook backup inbox.
                </p>
                <HrCopyCheckbox
                  value={removeHrCopy}
                  onChange={setRemoveHrCopy}
                  disabled={removeHoldBusy}
                  label="Also send a copy to"
                  idPrefix="remove-hrcopy"
                />
                <SendScheduleControl onChange={setRemoveSchedule} />
              </div>
            )}
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => { setRemoveHoldTarget(null); setRejoinDate(""); }} disabled={removeHoldBusy}>Cancel</Button>
            <Button
              onClick={confirmRemoveOnHold}
              disabled={removeHoldBusy}
              style={{ background: "#16a34a", color: "white" }}
            >
              {removeHoldBusy ? <Loader2 className="h-4 w-4 mr-1 animate-spin" /> : <PlayCircle className="h-4 w-4 mr-1" />}
              Confirm Remove On Hold
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

    </div>
  );
}

function StatCard({ label, value }: { label: string; value: number }) {
  return (
    <Card>
      <CardContent className="p-4">
        <div className="text-xs uppercase tracking-wide text-muted-foreground">{label}</div>
        <div className="text-3xl font-semibold mt-1" style={{ color: "#1a2547" }}>{value}</div>
      </CardContent>
    </Card>
  );
}
