import { useEffect, useMemo, useRef, useState, useCallback } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { uploadPublicStorageObject } from "@/lib/publicStorageUpload";
import { useAuth } from "@/hooks/useAuth";
import { useHrIdentity } from "@/hooks/useHrIdentity";
import { toast } from "sonner";
import {
  ArrowLeft,
  Search,
  Send,
  Paperclip,
  FileText,
  Check,
  CheckCheck,
  MessageCircle,
  Loader2,
  X,
} from "lucide-react";

// ── Types ──
type WaMessage = {
  id: string;
  direction: "inbound" | "outbound";
  wa_message_id: string | null;
  phone: string;
  contact_name: string | null;
  type: string | null;
  body: string | null;
  media_url: string | null;
  media_mime: string | null;
  status: string | null;
  response_id: string | null;
  raw: unknown;
  created_at: string;
};

type Conversation = {
  phone: string;
  name: string | null;
  messages: WaMessage[];
  last: WaMessage;
  unread: boolean;
};

// Reuse the EXISTING upload pattern/bucket — do NOT create a new bucket.
const UPLOAD_BUCKET = "candidate-files";

// ── Launch Sylvia (reuse the EXACT call from LaunchDashboard.tsx) ──
const AGENT_ID = "agent_4501ksmjapkvf4gbqgwcfnjhjrgt";
const E164_RE = /^\+?\d{8,15}$/;
function normalizeE164(v: string): string | null {
  const t = (v || "").trim();
  if (!E164_RE.test(t.replace(/\s/g, ""))) return null;
  const digits = t.replace(/[^\d]/g, "");
  if (digits.length < 8 || digits.length > 15) return null;
  return `+${digits}`;
}



// ── Helpers ──
const initialOf = (name: string | null, phone: string) => {
  const src = (name || phone || "?").trim();
  const ch = src.replace(/^\+?\d/, src[0]).charAt(0);
  return (ch || "#").toUpperCase();
};

const fmtTime = (iso: string) => {
  const d = new Date(iso);
  return d.toLocaleTimeString([], { hour: "numeric", minute: "2-digit" });
};

const fmtListTime = (iso: string) => {
  const d = new Date(iso);
  const now = new Date();
  const sameDay = d.toDateString() === now.toDateString();
  if (sameDay) return d.toLocaleTimeString([], { hour: "numeric", minute: "2-digit" });
  const diff = (now.getTime() - d.getTime()) / 86400000;
  if (diff < 7) return d.toLocaleDateString([], { weekday: "short" });
  return d.toLocaleDateString([], { month: "short", day: "numeric" });
};

const isImage = (m: WaMessage) =>
  m.type === "image" || (m.media_mime?.startsWith("image/") ?? false);
const isDocument = (m: WaMessage) =>
  !isImage(m) && (m.type === "document" || !!m.media_url);

const StatusTick = ({ status }: { status: string | null }) => {
  if (!status) return null;
  if (status === "read")
    return <CheckCheck className="inline h-3.5 w-3.5 text-gold" aria-label="read" />;
  if (status === "delivered")
    return <CheckCheck className="inline h-3.5 w-3.5 text-white/60" aria-label="delivered" />;
  if (status === "failed")
    return <X className="inline h-3.5 w-3.5 text-red-300" aria-label="failed" />;
  return <Check className="inline h-3.5 w-3.5 text-white/60" aria-label="sent" />;
};

// Merge incoming rows into existing state by id — update in place, append new,
// and drop any optimistic placeholder the real (server) row now supersedes.
// No wipe-and-rebuild, so the list never flickers and scroll position is kept.
function mergeMessages(prev: WaMessage[], incoming: WaMessage[]): WaMessage[] {
  if (!incoming.length) return prev;
  let next = prev.slice();
  for (const row of incoming) {
    const isRealOutbound = row.direction === "outbound" && !String(row.id).startsWith("temp-");
    if (isRealOutbound) {
      next = next.filter(
        (m) =>
          !(
            String(m.id).startsWith("temp-") &&
            m.direction === "outbound" &&
            m.phone === row.phone &&
            (m.body ?? "") === (row.body ?? "")
          ),
      );
    }
    const idx = next.findIndex((m) => m.id === row.id);
    if (idx >= 0) next[idx] = { ...next[idx], ...row };
    else next.push(row);
  }
  return next;
}

export default function WhatsAppChat() {
  const navigate = useNavigate();
  const [messages, setMessages] = useState<WaMessage[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedPhone, setSelectedPhone] = useState<string | null>(null);
  const [search, setSearch] = useState("");
  const [composer, setComposer] = useState("");
  const [sending, setSending] = useState(false);
  const [lightbox, setLightbox] = useState<string | null>(null);
  const [seenPhones, setSeenPhones] = useState<Set<string>>(new Set());

  // ── Launch Sylvia launcher (additive; reuses LaunchDashboard's exact call) ──
  const { user } = useAuth();
  const hrIdentity = useHrIdentity();
  const [launchName, setLaunchName] = useState("");
  const [launchNumber, setLaunchNumber] = useState("");
  const [launching, setLaunching] = useState(false);

  const launchSylvia = async () => {
    if (launching) return;
    const phone = normalizeE164(launchNumber);
    if (!launchName.trim()) { toast.error("Enter a candidate name"); return; }
    if (!phone) { toast.error("Enter a valid WhatsApp number in E.164 (e.g. +639171234567)"); return; }
    setLaunching(true);
    try {
      const insertRow: any = {
        candidate_name: launchName.trim(),
        whatsapp_number: phone,
        contact_timezone: "Asia/Manila",
        sylvia_instruction: null,
        mode: "now",
        scheduled_for: null,
        status: "pending",
        created_by: user?.email || hrIdentity.email || null,
      };
      const { data: row, error } = await (supabase.from("launches") as any)
        .insert(insertRow).select("id").single();
      if (error) { toast.error(error.message); return; }

      const { data, error: invErr } = await supabase.functions.invoke<any>("launch-sylvia", {
        body: { launch_id: row.id, agent_id: AGENT_ID },
      });
      if (invErr) {
        await (supabase.from("launches") as any)
          .update({ status: "failed", error_message: (invErr.message || "invoke_failed").slice(0, 2000) })
          .eq("id", row.id);
        toast.error(invErr.message || "Launch failed");
        return;
      }
      if (!data?.ok) {
        await (supabase.from("launches") as any)
          .update({ status: "failed", error_message: (data?.error || "launch_failed").slice(0, 2000) })
          .eq("id", row.id);
        toast.error(data?.error || "Launch failed");
        return;
      }
      toast.success(`Sylvia launched to ${launchName.trim()}`);
      setLaunchName("");
      setLaunchNumber("");
    } catch (e: any) {
      toast.error(e?.message || "Launch failed");
    } finally {
      setLaunching(false);
    }
  };

  const fileInputRef = useRef<HTMLInputElement>(null);
  const threadRef = useRef<HTMLDivElement>(null);
  const selectedPhoneRef = useRef<string | null>(null);
  selectedPhoneRef.current = selectedPhone;

  // ── Re-fetch all messages and merge into state (no flicker, no scroll loss) ──
  const fetchMessages = useCallback(async (opts?: { showError?: boolean }) => {
    const { data, error } = await supabase
      .from("whatsapp_messages")
      .select("*")
      .order("created_at", { ascending: true });
    if (error) {
      if (opts?.showError) toast.error(`Failed to load messages: ${error.message}`);
      return;
    }
    setMessages((prev) => mergeMessages(prev, (data as WaMessage[]) ?? []));
  }, []);

  // ── Initial load ──
  useEffect(() => {
    let active = true;
    (async () => {
      await fetchMessages({ showError: true });
      if (active) setLoading(false);
    })();
    return () => {
      active = false;
    };
  }, [fetchMessages]);

  // ── Realtime: INSERT + UPDATE ──
  useEffect(() => {
    const channel = supabase
      .channel("whatsapp_messages_live")
      .on(
        "postgres_changes",
        { event: "INSERT", schema: "public", table: "whatsapp_messages" },
        (payload) => {
          const row = payload.new as WaMessage;
          setMessages((prev) => mergeMessages(prev, [row]));
        },
      )
      .on(
        "postgres_changes",
        { event: "UPDATE", schema: "public", table: "whatsapp_messages" },
        (payload) => {
          const row = payload.new as WaMessage;
          setMessages((prev) => mergeMessages(prev, [row]));
        },
      )
      .subscribe();
    return () => {
      supabase.removeChannel(channel);
    };
  }, []);

  // ── Safety net: refetch on tab focus + every 15s while visible ──
  // (mobile browsers drop the websocket when the screen sleeps; this keeps the
  //  thread current even if a realtime event is ever missed)
  useEffect(() => {
    const onVisible = () => {
      if (document.visibilityState === "visible") fetchMessages();
    };
    document.addEventListener("visibilitychange", onVisible);
    const intervalId = window.setInterval(() => {
      if (document.visibilityState === "visible") fetchMessages();
    }, 15000);
    return () => {
      document.removeEventListener("visibilitychange", onVisible);
      window.clearInterval(intervalId);
    };
  }, [fetchMessages]);


  // ── Group into conversations ──
  const conversations = useMemo<Conversation[]>(() => {
    const byPhone = new Map<string, WaMessage[]>();
    for (const m of messages) {
      const arr = byPhone.get(m.phone) ?? [];
      arr.push(m);
      byPhone.set(m.phone, arr);
    }
    const list: Conversation[] = [];
    for (const [phone, arr] of byPhone.entries()) {
      arr.sort((a, b) => +new Date(a.created_at) - +new Date(b.created_at));
      const last = arr[arr.length - 1];
      const name = arr.find((m) => m.contact_name)?.contact_name ?? null;
      const unread =
        last.direction === "inbound" &&
        !seenPhones.has(phone) &&
        selectedPhone !== phone;
      list.push({ phone, name, messages: arr, last, unread });
    }
    list.sort((a, b) => +new Date(b.last.created_at) - +new Date(a.last.created_at));
    return list;
  }, [messages, seenPhones, selectedPhone]);

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    if (!q) return conversations;
    return conversations.filter(
      (c) =>
        c.phone.toLowerCase().includes(q) ||
        (c.name ?? "").toLowerCase().includes(q),
    );
  }, [conversations, search]);

  const active = useMemo(
    () => conversations.find((c) => c.phone === selectedPhone) ?? null,
    [conversations, selectedPhone],
  );

  // ── Auto-scroll to newest when thread changes ──
  useEffect(() => {
    const el = threadRef.current;
    if (!el) return;
    el.scrollTop = el.scrollHeight;
  }, [active?.phone, active?.messages.length]);

  const openConversation = useCallback((phone: string) => {
    setSelectedPhone(phone);
    setSeenPhones((prev) => {
      const next = new Set(prev);
      next.add(phone);
      return next;
    });
  }, []);

  // ── Surface real function errors ──
  const surfaceInvokeError = async (error: any, data: any) => {
    let detail = "";
    const ctx = error?.context;
    if (ctx && typeof ctx.json === "function") {
      try {
        const body = await ctx.json();
        detail = body?.meta?.error?.message || body?.error || body?.detail || "";
      } catch {
        /* ignore */
      }
    }
    if (!detail && data?.error) detail = data.error;
    if (!detail) detail = error?.message || "Send failed";
    toast.error(detail);
  };

  // ── Send text ──
  const sendText = async () => {
    const body = composer.trim();
    if (!body || !active || sending) return;
    setSending(true);
    // Optimistic display — show the message immediately; mergeMessages will
    // replace this placeholder once the real row arrives via realtime/refetch.
    const tempId = `temp-${Date.now()}`;
    const optimistic: WaMessage = {
      id: tempId,
      direction: "outbound",
      wa_message_id: null,
      phone: active.phone,
      contact_name: active.name,
      type: "text",
      body,
      media_url: null,
      media_mime: null,
      status: "sent",
      response_id: null,
      raw: null,
      created_at: new Date().toISOString(),
    };
    setMessages((prev) => [...prev, optimistic]);
    setComposer("");
    try {
      const { data, error } = await supabase.functions.invoke("whatsapp-send-message", {
        body: { to: active.phone, body },
      });
      if (error || (data && data.error)) {
        // Roll back the optimistic message on failure.
        setMessages((prev) => prev.filter((m) => m.id !== tempId));
        setComposer(body);
        await surfaceInvokeError(error, data);
        return;
      }
    } catch (e: any) {
      setMessages((prev) => prev.filter((m) => m.id !== tempId));
      setComposer(body);
      toast.error(e?.message || "Send failed");
    } finally {
      setSending(false);
    }

  };

  // ── Attach + send (reuse existing upload pattern) ──
  const handleAttach = async (file: File) => {
    if (!active || sending) return;
    setSending(true);
    try {
      const safeName = (file.name || `file-${Date.now()}`).replace(/[^a-zA-Z0-9._-]/g, "_");
      const path = `whatsapp/${active.phone}/${Date.now()}-${safeName}`;
      const contentType = file.type || "application/octet-stream";
      await uploadPublicStorageObject({ bucket: UPLOAD_BUCKET, path, file, contentType });

      // Signed URL so Meta can fetch the file at send time.
      const { data: signed, error: signErr } = await supabase.storage
        .from(UPLOAD_BUCKET)
        .createSignedUrl(path, 60 * 60 * 24 * 7);
      if (signErr || !signed?.signedUrl) {
        toast.error(signErr?.message || "Could not generate file URL");
        return;
      }

      const isImg = contentType.startsWith("image/");
      const { data, error } = await supabase.functions.invoke("whatsapp-send-media", {
        body: {
          to: active.phone,
          media_url: signed.signedUrl,
          type: isImg ? "image" : "document",
          caption: composer.trim() || undefined,
          filename: isImg ? undefined : file.name,
        },
      });
      if (error || (data && data.error)) {
        await surfaceInvokeError(error, data);
        return;
      }
      setComposer("");
    } catch (e: any) {
      toast.error(e?.message || "Attachment send failed");
    } finally {
      setSending(false);
      if (fileInputRef.current) fileInputRef.current.value = "";
    }
  };

  const showThreadOnMobile = !!selectedPhone;

  return (
    <div className="h-screen w-full overflow-hidden flex flex-col" style={{ backgroundColor: "#faf8f3" }}>
      {/* Top bar */}
      <header
        className="flex items-center gap-3 px-4 py-3"
        style={{ backgroundColor: "#ffffff", borderBottom: "1px solid #e1e4ec" }}
      >
        <button
          onClick={() => navigate("/dashboard")}
          className="rounded-md p-1.5 transition-colors hover:bg-[#faf8f3]"
          style={{ color: "#6b7280" }}
          aria-label="Back to dashboard"
        >
          <ArrowLeft className="h-5 w-5" />
        </button>
        <div className="flex items-center gap-2.5">
          <div
            className="flex h-9 w-9 items-center justify-center rounded-full"
            style={{ backgroundColor: "#1a2547", color: "#b08d57" }}
          >
            <MessageCircle className="h-4 w-4" />
          </div>
          <div className="leading-tight">
            <h1
              style={{
                fontFamily: "'Cormorant Garamond', serif",
                fontWeight: 600,
                fontSize: 22,
                letterSpacing: "0.5px",
                color: "#1a2547",
                borderBottom: "2px solid #b08d57",
                display: "inline-block",
                paddingBottom: "1px",
              }}
            >
              Expert Intuitive Advisor Inc.
            </h1>
            <span className="block text-[10px] uppercase tracking-wider" style={{ color: "#b08d57", marginTop: 2 }}>
              Live Conversations
            </span>
          </div>
        </div>
      </header>

      {/* Launch Sylvia launcher (additive) */}
      <div
        className="flex flex-wrap items-end gap-2 px-4 py-3"
        style={{ backgroundColor: "#ffffff", borderBottom: "1px solid #e1e4ec" }}
      >
        <div className="flex items-center gap-2">
          <div
            className="flex h-8 w-8 items-center justify-center rounded-full"
            style={{ backgroundColor: "#1a2547", color: "#b08d57" }}
          >
            <MessageCircle className="h-4 w-4" />
          </div>
          <span className="text-[10px] uppercase tracking-wider" style={{ color: "#6b7280" }}>
            Launch Sylvia
          </span>
        </div>
        <input
          value={launchName}
          onChange={(e) => setLaunchName(e.target.value)}
          placeholder="Candidate name"
          className="min-w-[140px] flex-1 rounded-full px-3 py-2 text-sm outline-none transition focus:border-gold focus:ring-1 focus:ring-gold/30"
          style={{ backgroundColor: "#faf8f3", border: "1px solid #e1e4ec", color: "#1a2236" }}
        />
        <input
          value={launchNumber}
          onChange={(e) => setLaunchNumber(e.target.value)}
          placeholder="WhatsApp number (E.164)"
          className="min-w-[160px] flex-1 rounded-full px-3 py-2 text-sm outline-none transition focus:border-gold focus:ring-1 focus:ring-gold/30"
          style={{ backgroundColor: "#faf8f3", border: "1px solid #e1e4ec", color: "#1a2236" }}
        />
        <button
          onClick={launchSylvia}
          disabled={launching}
          className="flex items-center gap-2 rounded-full px-4 py-2 text-sm font-medium transition-colors hover:bg-[#0f1730] disabled:opacity-40"
          style={{ backgroundColor: "#1a2547", color: "#b08d57" }}
        >
          {launching ? <Loader2 className="h-4 w-4 animate-spin" /> : <Send className="h-4 w-4" />}
          Launch Sylvia
        </button>
      </div>



      <div className="flex min-h-0 flex-1">
        {/* LEFT RAIL */}
        <aside
          className={`${showThreadOnMobile ? "hidden" : "flex"} w-full flex-col md:flex md:w-[340px] md:min-w-[340px]`}
          style={{ backgroundColor: "#ffffff", borderRight: "1px solid #e1e4ec" }}
        >
          <div className="p-3" style={{ borderBottom: "1px solid #e1e4ec" }}>
            <div className="relative">
              <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2" style={{ color: "#6b7280" }} />
              <input
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="Search name or number…"
                className="w-full rounded-full py-2 pl-9 pr-3 text-sm outline-none transition focus:border-gold focus:ring-1 focus:ring-gold/30"
                style={{ backgroundColor: "#faf8f3", border: "1px solid #e1e4ec", color: "#1a2236" }}
              />
            </div>
          </div>

          <div className="min-h-0 flex-1 overflow-y-auto">
            {loading ? (
              <div className="flex h-32 items-center justify-center text-muted-foreground">
                <Loader2 className="h-5 w-5 animate-spin" />
              </div>
            ) : filtered.length === 0 ? (
              <div className="p-8 text-center text-sm text-muted-foreground">
                No conversations yet.
              </div>
            ) : (
              filtered.map((c) => {
                const selected = c.phone === selectedPhone;
                return (
                  <button
                    key={c.phone}
                    onClick={() => openConversation(c.phone)}
                    className="mx-2 my-0.5 flex w-[calc(100%-1rem)] items-center gap-3 rounded-lg px-3 py-3 text-left transition-colors"
                    style={
                      selected
                        ? { backgroundColor: "rgba(176,141,87,0.10)", borderLeft: "3px solid #b08d57" }
                        : { borderLeft: "3px solid transparent" }
                    }
                    onMouseEnter={(e) => {
                      if (!selected) e.currentTarget.style.backgroundColor = "#faf8f3";
                    }}
                    onMouseLeave={(e) => {
                      if (!selected) e.currentTarget.style.backgroundColor = "transparent";
                    }}
                  >
                    <div
                      className="relative flex h-11 w-11 shrink-0 items-center justify-center rounded-full text-sm font-semibold"
                      style={{ backgroundColor: "#1a2547", color: "#b08d57" }}
                    >
                      {initialOf(c.name, c.phone)}
                    </div>
                    <div className="min-w-0 flex-1">
                      <div className="flex items-center justify-between gap-2">
                        <span className="truncate font-medium" style={{ color: "#1a2236" }}>
                          {c.name || `+${c.phone}`}
                        </span>
                        <span className="shrink-0 text-[11px]" style={{ color: "#6b7280" }}>
                          {fmtListTime(c.last.created_at)}
                        </span>
                      </div>
                      <div className="flex items-center justify-between gap-2">
                        <span className="truncate text-[13px]" style={{ color: "#6b7280" }}>
                          {c.last.direction === "outbound" ? "You: " : ""}
                          {c.last.body ||
                            (isImage(c.last) ? "Photo" : c.last.media_url ? "Document" : "—")}
                        </span>
                        {c.unread && (
                          <span className="h-2.5 w-2.5 shrink-0 rounded-full" style={{ backgroundColor: "#b08d57" }} aria-label="unread" />
                        )}
                      </div>
                    </div>
                  </button>
                );
              })
            )}
          </div>
        </aside>

        {/* RIGHT PANE */}
        <main
          className={`${showThreadOnMobile ? "flex" : "hidden"} min-w-0 flex-1 flex-col md:flex`}
          style={{ backgroundColor: "#0f1730" }}
        >
          {!active ? (
            <div className="flex flex-1 flex-col items-center justify-center gap-3 text-center">
              <div
                className="flex h-16 w-16 items-center justify-center rounded-full"
                style={{ backgroundColor: "rgba(176,141,87,0.12)", color: "#b08d57" }}
              >
                <MessageCircle className="h-7 w-7" />
              </div>
              <p
                style={{ fontFamily: "'Cormorant Garamond', serif", fontWeight: 600, fontSize: 22, color: "#ffffff" }}
              >
                Select a conversation
              </p>
              <p className="max-w-xs text-sm" style={{ color: "#c9ced8" }}>
                Choose a contact on the left to read the thread and reply with text or attachments.
              </p>
            </div>
          ) : (
            <>
              {/* Thread header */}
              <div
                className="flex items-center gap-3 px-4 py-3"
                style={{ backgroundColor: "#ffffff", borderBottom: "1px solid #e1e4ec" }}
              >
                <button
                  onClick={() => setSelectedPhone(null)}
                  className="rounded-md p-1.5 hover:bg-[#faf8f3] md:hidden"
                  style={{ color: "#6b7280" }}
                  aria-label="Back to list"
                >
                  <ArrowLeft className="h-5 w-5" />
                </button>
                <div
                  className="flex h-10 w-10 items-center justify-center rounded-full text-sm font-semibold"
                  style={{ backgroundColor: "#1a2547", color: "#b08d57" }}
                >
                  {initialOf(active.name, active.phone)}
                </div>
                <div className="leading-tight">
                  <div className="font-medium" style={{ color: "#1a2236" }}>{active.name || `+${active.phone}`}</div>
                  <div className="text-xs" style={{ color: "#6b7280" }}>+{active.phone}</div>
                </div>
              </div>

              {/* Messages */}
              <div
                ref={threadRef}
                className="min-h-0 flex-1 space-y-2 overflow-y-auto px-4 py-5"
                style={{ backgroundColor: "#0f1730" }}
              >
                {active.messages.length === 0 ? (
                  <div className="flex h-full items-center justify-center text-sm" style={{ color: "#6b7280" }}>
                    No messages yet
                  </div>
                ) : (
                  active.messages.map((m) => {
                    const outbound = m.direction === "outbound";
                    return (
                      <div
                        key={m.id}
                        className={`flex ${outbound ? "justify-end" : "justify-start"}`}
                      >
                        <div
                          className={`max-w-[78%] rounded-2xl px-3.5 py-2.5 ${
                            outbound ? "rounded-br-sm" : "rounded-bl-sm"
                          }`}
                          style={
                            outbound
                              ? {
                                  backgroundColor: "#1a2547",
                                  color: "#ffffff",
                                  boxShadow: "0 2px 6px rgba(15,23,48,0.18)",
                                }
                              : {
                                  backgroundColor: "#ffffff",
                                  color: "#1a2236",
                                  border: "1px solid #e1e4ec",
                                  boxShadow: "0 1px 3px rgba(26,34,54,0.05)",
                                }
                          }
                        >
                          {/* Media */}
                          {m.media_url && isImage(m) && (
                            <img
                              src={m.media_url}
                              alt={m.body || "image"}
                              onClick={() => setLightbox(m.media_url)}
                              className="mb-1 max-h-64 cursor-pointer rounded-lg object-cover"
                              onError={(e) => {
                                (e.currentTarget as HTMLImageElement).style.display = "none";
                              }}
                            />
                          )}
                          {m.media_url && !isImage(m) && isDocument(m) && (
                            <a
                              href={m.media_url}
                              target="_blank"
                              rel="noreferrer"
                              className={`mb-1 flex items-center gap-2 rounded-lg p-2 ${
                                outbound ? "bg-white/10" : "bg-muted"
                              }`}
                            >
                              <FileText className={`h-7 w-7 ${outbound ? "text-gold" : "text-navy"}`} />
                              <div className="min-w-0">
                                <div className="truncate text-sm font-medium">
                                  {m.body || "Document"}
                                </div>
                                <div className={`text-xs ${outbound ? "text-white/70" : "text-muted-foreground"}`}>
                                  Open
                                </div>
                              </div>
                            </a>
                          )}

                          {/* Text body (skip if it's only the doc filename already shown) */}
                          {m.body && !(isDocument(m) && !isImage(m)) && (
                            <div className="whitespace-pre-wrap break-words text-sm">{m.body}</div>
                          )}

                          <div
                            className={`mt-0.5 flex items-center justify-end gap-1 text-[10px] ${
                              outbound ? "text-white/60" : "text-muted-foreground"
                            }`}
                          >
                            {fmtTime(m.created_at)}
                            {outbound && <StatusTick status={m.status} />}
                          </div>
                        </div>
                      </div>
                    );
                  })
                )}
              </div>

              {/* Composer */}
              <div
                className="flex items-end gap-2 px-3 py-3"
                style={{ backgroundColor: "#ffffff", borderTop: "1px solid #e1e4ec" }}
              >
                <input
                  ref={fileInputRef}
                  type="file"
                  accept="image/*,application/pdf"
                  className="hidden"
                  onChange={(e) => {
                    const f = e.target.files?.[0];
                    if (f) handleAttach(f);
                  }}
                />
                <button
                  onClick={() => fileInputRef.current?.click()}
                  disabled={sending}
                  className="rounded-full p-2.5 transition-colors hover:bg-[#faf8f3] disabled:opacity-50"
                  style={{ color: "#1a2547" }}
                  aria-label="Attach photo or PDF"
                >
                  <Paperclip className="h-5 w-5" />
                </button>
                <textarea
                  value={composer}
                  onChange={(e) => setComposer(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === "Enter" && !e.shiftKey) {
                      e.preventDefault();
                      sendText();
                    }
                  }}
                  rows={1}
                  placeholder="Type a message…"
                  className="max-h-32 min-h-[42px] flex-1 resize-none rounded-2xl px-4 py-2.5 text-sm outline-none transition focus:border-gold focus:ring-1 focus:ring-gold/30"
                  style={{ backgroundColor: "#faf8f3", border: "1px solid #e1e4ec", color: "#1a2236" }}
                />
                <button
                  onClick={sendText}
                  disabled={sending || !composer.trim()}
                  className="flex h-[42px] w-[42px] items-center justify-center rounded-full transition-colors hover:bg-[#0f1730] disabled:opacity-40"
                  style={{ backgroundColor: "#1a2547", color: "#b08d57" }}
                  aria-label="Send"
                >
                  {sending ? <Loader2 className="h-5 w-5 animate-spin" /> : <Send className="h-5 w-5" />}
                </button>
              </div>
            </>
          )}
        </main>
      </div>

      {/* Lightbox */}
      {lightbox && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 p-4"
          onClick={() => setLightbox(null)}
        >
          <button
            className="absolute right-5 top-5 rounded-full bg-white/10 p-2 text-white hover:bg-white/20"
            aria-label="Close"
          >
            <X className="h-5 w-5" />
          </button>
          <img
            src={lightbox}
            alt="attachment"
            className="max-h-[90vh] max-w-[90vw] rounded-lg object-contain"
            onClick={(e) => e.stopPropagation()}
          />
        </div>
      )}
    </div>
  );
}
