import { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import SlideRunner from "@/components/SlideRunner";
import { SlideQuestion } from "@/components/Slide";
import { Skeleton } from "@/components/ui/skeleton";
import { LinkIcon } from "lucide-react";
import { mergeTypography, typographyStyle, FormTypography } from "@/lib/typography";
import PageSeo from "@/components/PageSeo";

const PublicForm = () => {
  const { slug } = useParams<{ slug: string }>();
  const [loading, setLoading] = useState(true);
  const [questions, setQuestions] = useState<SlideQuestion[] | null>(null);
  const [formId, setFormId] = useState<string | null>(null);
  const [theme, setTheme] = useState<string | null>(null);
  const [typo, setTypo] = useState<FormTypography>({});

  useEffect(() => {
    (async () => {
      if (!slug) return;
      const { data: form } = await supabase
        .from("forms")
        .select("id, status, theme, typography")
        .eq("slug", slug)
        .eq("status", "live")
        .maybeSingle();
      if (!form) {
        setQuestions(null);
        setLoading(false);
        return;
      }
      setFormId(form.id);
      setTheme((form as any).theme ?? "darkblue");
      setTypo(mergeTypography((form as any).typography));
      const { data: qs } = await supabase
        .from("questions")
        .select("id, type, label, description, placeholder, order_index, required, options")
        .eq("form_id", form.id)
        .order("order_index", { ascending: true });
      // Self-booking widget removed from candidate-facing forms.
      // HR sends Zoom invites via Round 1/2 emails instead. Filter out any
      // legacy schedule_call questions so the previous question becomes the
      // final submit step (fires body.complete → thank-you email).
      const filtered = ((qs as SlideQuestion[]) || []).filter((q) => q.type !== "schedule_call");
      setQuestions(filtered);
      setLoading(false);
    })();
  }, [slug]);

  if (loading) {
    return (
      <div className="min-h-[100dvh] flex items-center justify-center px-6" aria-busy="true">
        <div className="w-full max-w-xl space-y-6">
          <Skeleton className="h-10 w-3/4 mx-auto" />
          <Skeleton className="h-4 w-1/2 mx-auto" />
          <Skeleton className="h-12 w-full" />
        </div>
      </div>
    );
  }

  if (!questions) {
    return (
      <div className="min-h-[100dvh] flex flex-col items-center justify-center text-center px-6 bg-background">
        <div className="mx-auto mb-6 h-16 w-16 rounded-full bg-secondary flex items-center justify-center">
          <LinkIcon className="h-8 w-8 text-muted-foreground" />
        </div>
        <h1 className="text-2xl md:text-3xl font-bold mb-2">Form not available</h1>
        <p className="text-muted-foreground max-w-md">
          This form may have been removed or is no longer accepting responses.
        </p>
      </div>
    );
  }

  const hasScheduleCall = !!questions?.some((q) => q.type === "schedule_call");

  return (
    <div className="ftype-scope" style={typographyStyle(typo)}>
      <PageSeo
        title="Apply Now — EIA Talent Recruiting"
        description="Submit your application to Expert Intuitive Advisor Inc. Answer a few quick questions to start the recruiting process."
        path={slug ? `/form/${slug}` : undefined}
      />
      {hasScheduleCall && (
        <div className="fixed top-1 left-1/2 -translate-x-1/2 z-40 pointer-events-none">
          <div className="rounded-full border border-[#b08d57]/40 bg-background/90 backdrop-blur px-3 py-1">
            <p className="text-[10px] font-semibold tracking-[1px] uppercase" style={{ color: "#b08d57" }}>
              Times shown in Philippine Standard Time (PHT)
            </p>
          </div>
        </div>
      )}
      <SlideRunner questions={questions} mode="candidate" formId={formId || undefined} theme={theme} />
    </div>
  );
};


export default PublicForm;
