import { useEffect, useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from "@/components/ui/table";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import { toast } from "sonner";
import { ArrowLeft, ExternalLink, RefreshCw, FileCheck2, Trash2 } from "lucide-react";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";

type SignedDoc = {
  id: string;
  source: "nda" | "offer";
  type_key: string;
  type_label: string;
  reference: string;
  signer: string;
  signed_date: string | null;
  url: string;
};

const fmtDateTime = (d: string | null) =>
  d ? new Date(d).toLocaleString("en-US", { dateStyle: "medium", timeStyle: "short" }) : "—";

// type_key -> { label, pill colors }
const TYPE_META: Record<string, { label: string; bg: string; color: string }> = {
  offer:           { label: "Offer",           bg: "#1a2547", color: "#e8c87a" },
  nda:             { label: "NDA",             bg: "#dbeafe", color: "#1e40af" },
  joining_nda:     { label: "Joining NDA",     bg: "#dcfce7", color: "#166534" },
  exit_nda:        { label: "Exit NDA",        bg: "#fef3c7", color: "#92400e" },
  settlement:      { label: "Settlement",      bg: "#ede9fe", color: "#5b21b6" },
  custom_document: { label: "Custom Document", bg: "#1a2547", color: "#e8c87a" },
};

const TypePill = ({ typeKey }: { typeKey: string }) => {
  const m = TYPE_META[typeKey] || { label: typeKey, bg: "#e5e7eb", color: "#374151" };
  return (
    <span
      style={{ background: m.bg, color: m.color }}
      className="inline-flex px-2.5 py-0.5 rounded text-xs font-semibold whitespace-nowrap"
    >
      {m.label}
    </span>
  );
};

const TYPE_FILTERS: { value: string; label: string }[] = [
  { value: "all", label: "All Types" },
  { value: "offer", label: "Offer" },
  { value: "nda", label: "NDA" },
  { value: "joining_nda", label: "Joining NDA" },
  { value: "exit_nda", label: "Exit NDA" },
  { value: "settlement", label: "Settlement" },
  { value: "custom_document", label: "Custom Document" },
];

export default function SignedDocumentsDashboard() {
  const navigate = useNavigate();
  const [docs, setDocs] = useState<SignedDoc[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchText, setSearchText] = useState("");
  const [typeFilter, setTypeFilter] = useState<string>("all");
  const [confirmTarget, setConfirmTarget] = useState<SignedDoc | null>(null);
  const [deleting, setDeleting] = useState(false);

  // Single-row delete by id from the correct source table (nda_signatures OR job_offers).
  // Only the table row is removed — the underlying PDF in storage is left untouched.
  const handleDelete = async (doc: SignedDoc) => {
    setDeleting(true);
    try {
      const table = doc.source === "offer" ? "job_offers" : "nda_signatures";
      const { error } = await (supabase.from(table) as any).delete().eq("id", doc.id);
      if (error) throw error;
      setDocs((prev) => prev.filter((d) => !(d.id === doc.id && d.source === doc.source)));
      toast.success("Signed document record deleted");
      setConfirmTarget(null);
    } catch (e: any) {
      toast.error(e?.message || "Failed to delete record");
    } finally {
      setDeleting(false);
    }
  };


  const load = async () => {
    setLoading(true);
    const [ndaRes, offerRes] = await Promise.all([
      (supabase.from("nda_signatures") as any)
        .select("id, doc_type, external_reference, signer_name, signed_at, signed_pdf_url")
        .not("signed_pdf_url", "is", null)
        .order("signed_at", { ascending: false })
        .limit(1000),
      (supabase.from("job_offers") as any)
        .select("id, offer_reference_id, candidate_name, signed_at, signed_pdf_url, status")
        .not("signed_pdf_url", "is", null)
        .order("signed_at", { ascending: false })
        .limit(1000),
    ]);

    if (ndaRes.error) toast.error(ndaRes.error.message);
    if (offerRes.error) toast.error(offerRes.error.message);

    const ndaDocs: SignedDoc[] = ((ndaRes.data as any[]) || []).map((r) => ({
      id: r.id,
      source: "nda",
      type_key: r.doc_type || "nda",
      type_label: TYPE_META[r.doc_type as string]?.label || "NDA",
      reference: r.external_reference || "—",
      signer: r.signer_name || "—",
      signed_date: r.signed_at,
      url: r.signed_pdf_url,
    }));

    const offerDocs: SignedDoc[] = ((offerRes.data as any[]) || []).map((r) => ({
      id: r.id,
      source: "offer",
      type_key: "offer",
      type_label: "Offer",
      reference: r.offer_reference_id || "—",
      signer: r.candidate_name || "—",
      signed_date: r.signed_at,
      url: r.signed_pdf_url,
    }));

    const merged = [...ndaDocs, ...offerDocs].sort((a, b) => {
      const ta = a.signed_date ? new Date(a.signed_date).getTime() : 0;
      const tb = b.signed_date ? new Date(b.signed_date).getTime() : 0;
      return tb - ta;
    });

    setDocs(merged);
    setLoading(false);
  };

  useEffect(() => { load(); }, []);

  const filtered = useMemo(() => {
    const q = searchText.trim().toLowerCase();
    return docs.filter((d) => {
      if (typeFilter !== "all" && d.type_key !== typeFilter) return false;
      if (q) {
        const hay = `${d.signer} ${d.reference}`.toLowerCase();
        if (!hay.includes(q)) return false;
      }
      return true;
    });
  }, [docs, searchText, typeFilter]);

  return (
    <div className="min-h-screen bg-background">
      <div className="border-b">
        <div className="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Button variant="ghost" size="sm" onClick={() => navigate("/dashboard")}>
              <ArrowLeft className="h-4 w-4 mr-1.5" /> Dashboard
            </Button>
            <div>
              <h1 className="text-xl font-semibold">Signed Documents</h1>
              <p className="text-sm text-muted-foreground">
                View-only archive of signed offers, NDAs, and settlements.
              </p>
            </div>
          </div>
          <Button variant="outline" size="sm" onClick={load} disabled={loading}>
            <RefreshCw className={`h-4 w-4 mr-1.5 ${loading ? "animate-spin" : ""}`} /> Refresh
          </Button>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-6 py-6 space-y-6">
        <Card>
          <CardContent className="py-4">
            <div className="flex flex-wrap items-end gap-3">
              <div className="flex-1 min-w-[220px]">
                <label className="text-xs text-muted-foreground block mb-1">Search</label>
                <Input
                  placeholder="Search by signer or reference…"
                  value={searchText}
                  onChange={(e) => setSearchText(e.target.value)}
                />
              </div>
              <div>
                <label className="text-xs text-muted-foreground block mb-1">Type</label>
                <Select value={typeFilter} onValueChange={(v) => setTypeFilter(v)}>
                  <SelectTrigger className="w-[160px]"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {TYPE_FILTERS.map((t) => (
                      <SelectItem key={t.value} value={t.value}>{t.label}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="text-sm text-muted-foreground pb-2">
                {filtered.length} {filtered.length === 1 ? "document" : "documents"}
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-0">
            {loading ? (
              <p className="text-sm text-muted-foreground p-8 text-center">Loading…</p>
            ) : filtered.length === 0 ? (
              <div className="flex flex-col items-center justify-center gap-2 py-16 text-center">
                <FileCheck2 className="h-10 w-10 text-muted-foreground/50" />
                <p className="text-sm text-muted-foreground">
                  {docs.length === 0 ? "No signed documents yet." : "No documents match your filters."}
                </p>
              </div>
            ) : (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="w-[140px]">Type</TableHead>
                    <TableHead>Reference</TableHead>
                    <TableHead>Signer</TableHead>
                    <TableHead>Signed Date</TableHead>
                    <TableHead className="text-right">View</TableHead>
                    <TableHead className="w-[60px] text-right">Delete</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filtered.map((d, i) => (
                    <TableRow key={`${d.source}-${d.id}-${i}`}>
                      <TableCell><TypePill typeKey={d.type_key} /></TableCell>
                      <TableCell className="font-medium">{d.reference}</TableCell>
                      <TableCell>{d.signer}</TableCell>
                      <TableCell className="text-muted-foreground">{fmtDateTime(d.signed_date)}</TableCell>
                      <TableCell className="text-right">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => window.open(d.url, "_blank", "noopener,noreferrer")}
                        >
                          <ExternalLink className="h-4 w-4 mr-1.5" /> View
                        </Button>
                      </TableCell>
                      <TableCell className="text-right">
                        <Button
                          variant="ghost"
                          size="icon"
                          className="h-9 w-9 text-red-600 hover:text-red-700 hover:bg-red-50 border border-red-200"
                          onClick={() => setConfirmTarget(d)}
                          aria-label="Delete signed document record"
                        >
                          <Trash2 className="h-5 w-5" />
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            )}
          </CardContent>
        </Card>
      </div>

      <AlertDialog open={confirmTarget !== null} onOpenChange={(o) => { if (!o) setConfirmTarget(null); }}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete signed document record?</AlertDialogTitle>
            <AlertDialogDescription>
              Permanently delete this signed document record? This cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={deleting}>Cancel</AlertDialogCancel>
            <AlertDialogAction
              className="bg-red-600 hover:bg-red-700"
              disabled={deleting}
              onClick={(e) => { e.preventDefault(); if (confirmTarget) handleDelete(confirmTarget); }}
            >
              {deleting ? "Deleting…" : "Delete"}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
