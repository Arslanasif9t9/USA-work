import { useEffect, useMemo, useState } from "react";
import { useParams } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { Loader2, CheckCircle2, ShieldAlert } from "lucide-react";
import EiaWordmark from "@/components/EiaWordmark";

const NAVY = "#1a2547";
const GOLD = "#b08d57";
const CREAM = "#faf8f3";
const RULE = "#e6e0d1";

const MIN_CHARS = 80;
const MIN_WORDS = 15;

type TokenInfo = {
  valid: boolean;
  reason?: string;
  title?: string;
  body?: string;
  explanation?: string;
  signer_name?: string;
  signing_url?: string;
};

const SectionLabel = ({ children }: { children: React.ReactNode }) => (
  <div style={{ fontFamily: "'Inter', sans-serif", fontWeight: 600, fontSize: "11px", color: GOLD, textTransform: "uppercase", letterSpacing: "3px" }}>
    {children}
  </div>
);

const PageShell = ({ children }: { children: React.ReactNode }) => (
  <div className="min-h-screen" style={{ backgroundColor: CREAM }}>
    <div className="max-w-3xl mx-auto px-6 py-10 md:py-14">
      <div className="mb-8 flex justify-center">
        <EiaWordmark subtitle="CIRCULAR NOTICE" align="center" />
      </div>
      {children}
    </div>
  </div>
);

const wordCount = (s: string) => s.trim().split(/\s+/).filter(Boolean).length;

export default function Circular() {
  const { token } = useParams<{ token: string }>();
  const [info, setInfo] = useState<TokenInfo | null>(null);
  const [loading, setLoading] = useState(true);
  const [understanding, setUnderstanding] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let active = true;
    (async () => {
      if (!token) { setLoading(false); return; }
      const { data } = await supabase.functions.invoke<TokenInfo>("validate-circular-token", { body: { token } });
      if (!active) return;
      setInfo(data || { valid: false });
      setLoading(false);
    })();
    return () => { active = false; };
  }, [token]);

  const chars = understanding.trim().length;
  const words = useMemo(() => wordCount(understanding), [understanding]);
  const meetsMin = chars >= MIN_CHARS && words >= MIN_WORDS;

  const handleContinue = async () => {
    if (!token || !meetsMin || submitting) return;
    setSubmitting(true);
    setError(null);
    const { data, error: fnErr } = await supabase.functions.invoke<{ ok: boolean; signing_url?: string; reason?: string }>(
      "save-circular-understanding",
      { body: { token, understanding_text: understanding.trim() } },
    );
    if (fnErr || !data?.ok || !data?.signing_url) {
      setSubmitting(false);
      setError("We couldn't save your response just now. Please try again in a moment.");
      return;
    }
    // Forward to SignFlow to actually sign.
    window.location.href = data.signing_url;
  };

  if (loading) {
    return (
      <PageShell>
        <div className="flex justify-center py-20">
          <Loader2 className="h-8 w-8 animate-spin" style={{ color: NAVY }} />
        </div>
      </PageShell>
    );
  }

  if (!info?.valid) {
    const completed = info?.reason === "completed";
    return (
      <PageShell>
        <div
          className="rounded-2xl px-8 py-12 text-center"
          style={{ backgroundColor: "#ffffff", border: `1px solid ${RULE}` }}
        >
          <CheckCircle2 className="mx-auto h-12 w-12 mb-5" style={{ color: GOLD }} />
          <h1 style={{ fontFamily: "'Cormorant Garamond', serif", fontSize: 30, color: NAVY, fontWeight: 600 }}>
            {completed ? "This notice has already been completed" : "This link is no longer active"}
          </h1>
          <p style={{ fontFamily: "'Inter', sans-serif", color: "rgba(26,37,71,0.62)", marginTop: 12, fontSize: 15 }}>
            {completed
              ? "Thank you — there's nothing more you need to do."
              : "If you believe this is a mistake, simply reply to the email you received and we'll help."}
          </p>
        </div>
      </PageShell>
    );
  }

  return (
    <PageShell>
      <div className="rounded-2xl overflow-hidden" style={{ backgroundColor: "#ffffff", border: `1px solid ${RULE}` }}>
        {/* Notice */}
        <div className="px-8 pt-9 pb-7" style={{ borderBottom: `1px solid ${RULE}` }}>
          <SectionLabel>Please read carefully</SectionLabel>
          <h1 style={{ fontFamily: "'Cormorant Garamond', serif", fontSize: 32, color: NAVY, fontWeight: 600, marginTop: 8, lineHeight: 1.2 }}>
            {info.title}
          </h1>
          {info.signer_name && (
            <p style={{ fontFamily: "'Inter', sans-serif", fontSize: 13, color: "rgba(26,37,71,0.55)", marginTop: 6 }}>
              For: {info.signer_name}
            </p>
          )}
          {info.explanation && (
            <div
              style={{
                marginTop: 20,
                padding: "14px 16px",
                borderRadius: 12,
                backgroundColor: CREAM,
                border: `1px solid ${RULE}`,
                borderLeft: `3px solid ${GOLD}`,
              }}
            >
              <div style={{ fontFamily: "'Inter', sans-serif", fontWeight: 600, fontSize: 11, color: GOLD, textTransform: "uppercase", letterSpacing: "2px", marginBottom: 6 }}>
                A note from HR
              </div>
              <div style={{ fontFamily: "'Inter', sans-serif", fontSize: 14.5, color: NAVY, lineHeight: 1.65, whiteSpace: "pre-wrap" }}>
                {info.explanation}
              </div>
            </div>
          )}
          <div
            style={{
              fontFamily: "'Inter', sans-serif",
              fontSize: 15.5,
              color: NAVY,
              lineHeight: 1.7,
              marginTop: 20,
              whiteSpace: "pre-wrap",
            }}
          >
            {info.body}
          </div>
        </div>

        {/* Understanding */}
        <div className="px-8 py-8">
          <SectionLabel>Your understanding</SectionLabel>
          <label
            htmlFor="understanding"
            style={{ display: "block", fontFamily: "'Inter', sans-serif", fontSize: 14.5, color: NAVY, marginTop: 10, lineHeight: 1.55 }}
          >
            In your own words, explain what you understood from this notice. Please do not use AI to write this — write in
            your own words so we can be sure you understood. (Answers are read individually.)
          </label>
          <textarea
            id="understanding"
            value={understanding}
            onChange={(e) => setUnderstanding(e.target.value)}
            rows={6}
            placeholder="Write here, in your own words…"
            className="w-full mt-3 rounded-xl px-4 py-3 outline-none"
            style={{
              fontFamily: "'Inter', sans-serif",
              fontSize: 15,
              color: NAVY,
              backgroundColor: CREAM,
              border: `1px solid ${RULE}`,
              resize: "vertical",
            }}
          />
          <div
            className="flex items-center gap-2 mt-2"
            style={{ fontFamily: "'Inter', sans-serif", fontSize: 12.5, color: meetsMin ? "#2f6d4f" : "rgba(26,37,71,0.5)" }}
          >
            <ShieldAlert className="h-3.5 w-3.5" />
            {meetsMin
              ? "Thank you — you can continue to sign."
              : `Please write a little more (at least ${MIN_WORDS} words).`}
          </div>

          {error && (
            <p style={{ fontFamily: "'Inter', sans-serif", fontSize: 13, color: "#E2445C", marginTop: 10 }}>{error}</p>
          )}

          <button
            type="button"
            onClick={handleContinue}
            disabled={!meetsMin || submitting}
            className="w-full mt-6 rounded-full transition"
            style={{
              padding: "14px 28px",
              minHeight: 52,
              fontFamily: "'Inter', sans-serif",
              fontSize: 13,
              letterSpacing: "0.18em",
              textTransform: "uppercase",
              fontWeight: 600,
              background: !meetsMin || submitting ? "rgba(26,37,71,0.40)" : NAVY,
              color: !meetsMin || submitting ? "rgba(250,248,243,0.7)" : CREAM,
              cursor: !meetsMin || submitting ? "not-allowed" : "pointer",
            }}
          >
            {submitting ? "Saving…" : "Continue to Sign"}
          </button>
        </div>
      </div>
    </PageShell>
  );
}
