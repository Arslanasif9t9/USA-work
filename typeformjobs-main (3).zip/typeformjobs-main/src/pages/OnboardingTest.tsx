import { useEffect, useRef, useState } from "react";
import { useParams } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import VimeoWatchGate from "@/components/VimeoWatchGate";
import { DEFAULT_ONBOARDING_VIDEO_URL } from "@/config/onboarding";

/* ───────────────────────────────────────────────────────────
   EIA Onboarding — token-gated training + certification.
   VISUAL restyle to the approved dark "standard" design.
   All logic preserved: token validation, Vimeo watch-lock,
   no-skip seek guard, server-side scoring / pass mark,
   3-attempt kill-switch, permanent-test exemption.
   ─────────────────────────────────────────────────────────── */

// palette (isolated branded public page — intentionally hard-coded)
const BG = "#080d1a";
const GOLD = "#b08d57";
const GOLD_HOVER = "#c4a06a";
const EMERALD = "#0f9d63";
const EMERALD_HOVER = "#13b272";
const INK = "#0a1020";
const HEAD = "#f4f1ea";
const BODY = "#e8ecf5";
const MUTE = "#99a1b8";
const MUTE2 = "#8a93ad";
const MUTE3 = "#c4cbdc";
const DIM = "#6b7488";
const DIM2 = "#59617a";

const MONO = "'IBM Plex Mono', monospace";
const SERIF = "'Cormorant Garamond', serif";
const SANS = "'Inter', sans-serif";

type QuizQuestion = { id: string; question: string; options: string[] };

type ValidateResp = {
  valid: boolean;
  reason?: string;
  status?: string;
  candidate_name?: string | null;
  candidate_email?: string | null;
  video_url?: string | null;
  attempts_used?: number;
  max_attempts?: number;
};

type VerifyResp = ValidateResp & {
  questions?: QuizQuestion[];
  total_questions?: number;
  pass_mark?: number;
};

type SubmitResp = {
  valid: boolean;
  reason?: string;
  passed?: boolean;
  score?: number;
  total?: number;
  pass_mark?: number;
  attempt_number?: number;
  attempts_left?: number;
  finished?: boolean;
};

type Stage = "loading" | "dead" | "main";

const deadCopy: Record<string, { tag: string; title: string; body: string }> = {
  not_found: { tag: "Link · Unrecognised", title: "This link isn't recognised.", body: "We can't find this onboarding link. Please contact your HR representative for a fresh one." },
  expired: { tag: "Link · Expired", title: "This link has expired.", body: "This onboarding link is no longer valid. Reach out to HR and they'll issue a new one." },
  invalidated: { tag: "Link · Closed", title: "This link is closed.", body: "This onboarding link has already been completed and is no longer active." },
  no_attempts_left: { tag: "Certification · Closed", title: "This certification is closed.", body: "All attempts for this onboarding check have been used. Please contact your HR representative to discuss next steps." },
  passed: { tag: "Certification · Cleared", title: "You're already cleared.", body: "You've completed your onboarding check — there's nothing more to do here. HR will be in touch with your next step." },
  failed_out: { tag: "Certification · Closed", title: "This certification is closed.", body: "This onboarding check has been used. Please contact your HR representative to talk through next steps." },
  default: { tag: "Link · Unavailable", title: "This link can't open right now.", body: "Please contact your HR representative for assistance." },
};

const ANIM = `
@keyframes eiaBlink { 0%,100%{opacity:1} 50%{opacity:.25} }
@keyframes eiaScan { from{transform:translateY(-100%)} to{transform:translateY(900%)} }
@keyframes eiaRise { from{transform:translateY(16px);opacity:.4} to{transform:none;opacity:1} }
@keyframes eiaPulse { 0%,100%{transform:scale(1);opacity:.5} 50%{transform:scale(1.12);opacity:.15} }
@keyframes eiaSpin { from{transform:rotate(0)} to{transform:rotate(360deg)} }
@keyframes eiaSpinR { from{transform:rotate(360deg)} to{transform:rotate(0)} }
@keyframes eiaGlow { 0%,100%{opacity:.35} 50%{opacity:.85} }
@keyframes eiaSweep { 0%{left:-30%} 100%{left:130%} }
@keyframes eiaReadyGlow {
  0%,100%{ box-shadow:0 0 0 0 rgba(15,157,99,0.45), 0 22px 52px -18px rgba(15,157,99,0.65); }
  50%{ box-shadow:0 0 0 16px rgba(15,157,99,0), 0 26px 66px -16px rgba(15,157,99,0.9); }
}
@keyframes eiaReadyBob { 0%,100%{transform:translateY(0)} 50%{transform:translateY(-3px)} }
`;

const SPEC = [
  { no: "01", title: "The 4 Performance Zones", sub: "Foundation to Frontier — how growth is measured." },
  { no: "02", title: "How the platform works", sub: "Your operating surface, from day one onward." },
  { no: "03", title: "Your daily task flow", sub: "The rhythm of a day, first task to last." },
  { no: "04", title: "What's expected of you", sub: "Clear standards, set from the start." },
];

export default function OnboardingTest() {
  const { token } = useParams<{ token: string }>();
  const isTest = token === "permanent-test";

  const [stage, setStage] = useState<Stage>("loading");
  const [deadReason, setDeadReason] = useState<string>("default");

  const [videoUrl, setVideoUrl] = useState<string | null>(null);
  const [attemptsUsed, setAttemptsUsed] = useState(0);
  const [maxAttempts, setMaxAttempts] = useState(3);

  // captured for record-keeping (pre-filled from token, submitted with attempt)
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");

  // quiz
  const [questions, setQuestions] = useState<QuizQuestion[]>([]);
  const [qIndex, setQIndex] = useState(0);
  const [answers, setAnswers] = useState<Record<string, number>>({});
  const [submitting, setSubmitting] = useState(false);

  // video
  const [videoStarted, setVideoStarted] = useState(false);
  const [videoEnded, setVideoEnded] = useState(false);
  const [thumbUrl, setThumbUrl] = useState<string | null>(null);
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const videoSectionRef = useRef<HTMLDivElement | null>(null);

  // flow: "video" = watch screen, "quiz" = certification screen
  const [screen, setScreen] = useState<"video" | "quiz">("video");

  // result
  const [result, setResult] = useState<SubmitResp | null>(null);

  // styled "you're leaving mid-flow" warning
  const [showLeaveWarning, setShowLeaveWarning] = useState(false);

  // brief "watch the video first" hint shown when the grayed button is tapped
  const [showWatchHint, setShowWatchHint] = useState(false);
  const watchHintTimer = useRef<number | null>(null);



  useEffect(() => {
    if (!token) return;
    (async () => {
      const { data: v } = await supabase.functions.invoke<ValidateResp>("validate-onboarding-quiz-token", { body: { token } });
      if (!v || !v.valid) {
        setDeadReason((v?.reason as string) || "default");
        setStage("dead");
        return;
      }
      const nm = v.candidate_name ?? "";
      const em = v.candidate_email ?? "";
      setName(nm);
      setEmail(em);
      setVideoUrl(v.video_url?.trim() || DEFAULT_ONBOARDING_VIDEO_URL);
      setAttemptsUsed(v.attempts_used ?? 0);
      setMaxAttempts(v.max_attempts ?? 3);

      // load questions (verify never consumes an attempt)
      const { data: ver } = await supabase.functions.invoke<VerifyResp>("validate-onboarding-quiz-token", {
        body: { token, action: "verify", name: nm, email: em },
      });
      if (!ver || !ver.valid) {
        setDeadReason((ver?.reason as string) || "default");
        setStage("dead");
        return;
      }
      setQuestions(ver.questions || []);
      setVideoUrl(ver.video_url?.trim() || v.video_url?.trim() || DEFAULT_ONBOARDING_VIDEO_URL);
      setAttemptsUsed(ver.attempts_used ?? v.attempts_used ?? 0);
      setMaxAttempts(ver.max_attempts ?? v.max_attempts ?? 3);
      setStage("main");
    })();
  }, [token]);

  // Fetch the real Vimeo thumbnail (oEmbed) to show before play.
  // Pure visual enhancement — never blocks the page if it fails.
  useEffect(() => {
    if (!videoUrl || !/vimeo\.com/i.test(videoUrl)) return;
    const m = videoUrl.match(/(?:video\/|vimeo\.com\/)(\d+)/i);
    const id = m?.[1];
    if (!id) return;
    let cancelled = false;
    (async () => {
      try {
        const res = await fetch(
          `https://vimeo.com/api/oembed.json?url=https://vimeo.com/${id}&width=1280`
        );
        if (!res.ok) return;
        const data = (await res.json()) as { thumbnail_url?: string };
        let url = data.thumbnail_url;
        if (!url) return;
        // request a large size by bumping the dimension suffix (e.g. _295x166 → _1280)
        url = url.replace(/_\d+x\d+(\.\w+)?$/, "_1280$1").replace(/-d_\d+x\d+$/, "-d_1280");
        if (!cancelled) setThumbUrl(url);
      } catch {
        /* fall back to dark frame */
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [videoUrl]);

  const choose = (qid: string, idx: number) => {
    if (result) return;
    setAnswers((p) => ({ ...p, [qid]: idx }));
  };

  const onSubmit = () => {
    const q = questions[qIndex];
    if (!q || typeof answers[q.id] !== "number") return;
    if (qIndex < questions.length - 1) {
      // FORWARD-ONLY: advance, no going back
      setQIndex((i) => i + 1);
    } else {
      submitQuiz();
    }
  };

  const submitQuiz = async () => {
    if (!token) return;
    setSubmitting(true);
    const payload = questions.map((q) => ({ question_id: q.id, selected_index: answers[q.id] ?? -1 }));
    const { data } = await supabase.functions.invoke<SubmitResp>("submit-onboarding-quiz-attempt", {
      body: { token, name: name.trim(), email: email.trim(), answers: payload },
    });
    setSubmitting(false);
    if (!data || !data.valid) {
      setDeadReason((data?.reason as string) || "default");
      setStage("dead");
      return;
    }
    setResult(data);
    if (typeof data.attempt_number === "number") setAttemptsUsed(data.attempt_number);
  };

  const onRetry = () => {
    setResult(null);
    setAnswers({});
    setQIndex(0);
    setVideoEnded(false);
    setVideoStarted(false);
    setScreen("video");
    scrollToVideo();
  };

  const scrollToVideo = () => {
    try {
      videoSectionRef.current?.scrollIntoView({ behavior: "smooth", block: "start" });
    } catch {
      window.scrollTo(0, 0);
    }
  };

  const onRewatch = () => {
    setVideoEnded(false);
    setVideoStarted(false);
    setScreen("video");
    scrollToVideo();
  };

  const onStartTest = () => {
    setScreen("quiz");
    try {
      window.scrollTo({ top: 0, behavior: "smooth" });
    } catch {
      window.scrollTo(0, 0);
    }
  };

  // ─── derived ───
  const hasVideo = !!videoUrl;
  const isVimeo = !!videoUrl && /player\.vimeo\.com|vimeo\.com/i.test(videoUrl);
  const isYouTube = !!videoUrl && /youtube\.com|youtu\.be/i.test(videoUrl);
  const unlocked = isTest || !hasVideo || (isYouTube && !isVimeo) || videoEnded;

  // ─── mid-flow guard ───
  // Active from the moment the candidate presses play until they reach a FINAL
  // screen (passed, final-fail, or link dead). The retry screen is NOT final —
  // they can still continue — so the guard stays on. Applies to every token,
  // including permanent-test, by design.
  const isFinalScreen = stage === "dead" || (!!result && (!!result.passed || !!result.finished));
  const midFlow = stage === "main" && videoStarted && !isFinalScreen;

  useEffect(() => {
    if (!midFlow) {
      setShowLeaveWarning(false);
      return;
    }
    const onBeforeUnload = (e: BeforeUnloadEvent) => {
      e.preventDefault();
      e.returnValue = "";
      return "";
    };
    const onPopState = () => {
      // Re-pin the URL and surface our own styled warning instead of leaving.
      window.history.pushState(null, "", window.location.href);
      setShowLeaveWarning(true);
    };
    window.addEventListener("beforeunload", onBeforeUnload);
    window.history.pushState(null, "", window.location.href);
    window.addEventListener("popstate", onPopState);
    return () => {
      window.removeEventListener("beforeunload", onBeforeUnload);
      window.removeEventListener("popstate", onPopState);
    };
  }, [midFlow]);

  const statusLabel = videoEnded ? "Complete" : videoStarted ? "Playing" : "Standby";

  // Vimeo embed URL with autoplay + a clean chrome (no title/byline/portrait/
  // badge/like-share buttons) so the player sits neatly inside the EIA frame.
  const vimeoSrc = (() => {
    if (!videoUrl || !isVimeo) return videoUrl ?? "";
    const wanted: Record<string, string> = {
      autoplay: "1",
      title: "0",
      byline: "0",
      portrait: "0",
      badge: "0",
      dnt: "1",
      pip: "0",
    };
    const sep = videoUrl.includes("?") ? "&" : "?";
    const extra = Object.entries(wanted)
      .filter(([k]) => !new RegExp(`[?&]${k}=`).test(videoUrl))
      .map(([k, v]) => `${k}=${v}`)
      .join("&");
    return extra ? `${videoUrl}${sep}${extra}` : videoUrl;
  })();

  // ─── shells ───
  const Shell = ({ children }: { children: React.ReactNode }) => (
    <div
      style={{
        fontFamily: SANS,
        color: BODY,
        background: BG,
        backgroundImage:
          "linear-gradient(rgba(176,141,87,0.045) 1px, transparent 1px), linear-gradient(90deg, rgba(176,141,87,0.045) 1px, transparent 1px)",
        backgroundSize: "72px 72px",
        width: "100%",
        minHeight: "100vh",
        WebkitFontSmoothing: "antialiased",
      }}
    >
      <style>{ANIM}</style>
      {children}
    </div>
  );

  const TopBar = () => (
    <div
      style={{
        borderBottom: "1px solid rgba(255,255,255,0.07)",
        padding: "16px 28px",
        display: "flex",
        alignItems: "center",
        justifyContent: "space-between",
        gap: 16,
        background: "rgba(8,13,26,0.6)",
        backdropFilter: "blur(8px)",
        WebkitBackdropFilter: "blur(8px)",
        position: "sticky",
        top: 0,
        zIndex: 50,
      }}
    >
      <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
        <div style={{ width: 22, height: 22, border: `1px solid ${GOLD}`, display: "flex", alignItems: "center", justifyContent: "center", fontFamily: SERIF, fontSize: 14, fontWeight: 600, color: GOLD }}>E</div>
        <span style={{ fontFamily: MONO, fontSize: 11.5, letterSpacing: "0.22em", textTransform: "uppercase", color: MUTE3, fontWeight: 500 }}>Expert Intuitive Advisor</span>
      </div>
      <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
        <span style={{ width: 6, height: 6, borderRadius: "50%", background: GOLD, animation: "eiaBlink 1.8s ease-in-out infinite" }} />
        <span style={{ fontFamily: MONO, fontSize: 11, letterSpacing: "0.2em", textTransform: "uppercase", color: DIM, fontWeight: 500 }}>Onboarding · Active</span>
      </div>
    </div>
  );

  const Footer = () => (
    <footer style={{ padding: "clamp(44px,6vh,72px) 24px clamp(36px,5vh,56px)", borderTop: "1px solid rgba(255,255,255,0.07)", textAlign: "center" }}>
      <div style={{ maxWidth: 760, margin: "0 auto", display: "flex", flexDirection: "column", alignItems: "center" }}>
        <div style={{ width: 44, height: 1, background: GOLD, marginBottom: 22 }} />
        <div style={{ fontFamily: SERIF, fontSize: 27, fontWeight: 600, lineHeight: 1.2, color: HEAD }}>Expert Intuitive Advisor</div>
        <div style={{ display: "flex", alignItems: "center", gap: 14, marginTop: 18, fontFamily: MONO, fontSize: 10.5, letterSpacing: "0.18em", textTransform: "uppercase", color: DIM2 }}>
          <span>EIA</span>
          <span style={{ width: 3, height: 3, borderRadius: "50%", background: DIM2 }} />
          <span>© {new Date().getFullYear()}</span>
          <span style={{ width: 3, height: 3, borderRadius: "50%", background: DIM2 }} />
          <span>Confidential</span>
        </div>
      </div>
    </footer>
  );

  // ─── loading ───
  if (stage === "loading") {
    return (
      <Shell>
        <TopBar />
        <div style={{ display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", gap: 18, padding: "120px 24px" }}>
          <div style={{ position: "relative", width: 56, height: 56 }}>
            <span style={{ position: "absolute", inset: 0, border: "1px dashed rgba(176,141,87,0.45)", borderRadius: "50%", animation: "eiaSpin 16s linear infinite" }} />
            <span style={{ position: "absolute", inset: 6, border: "1px solid rgba(176,141,87,0.35)", borderTopColor: "rgba(176,141,87,0.9)", borderRadius: "50%", animation: "eiaSpinR 1.2s linear infinite" }} />
          </div>
          <div style={{ fontFamily: MONO, fontSize: 11, letterSpacing: "0.24em", textTransform: "uppercase", color: MUTE }}>Preparing your onboarding…</div>
        </div>
      </Shell>
    );
  }

  // ─── dead ───
  if (stage === "dead") {
    const c = deadCopy[deadReason] || deadCopy.default;
    return (
      <Shell>
        <TopBar />
        <section style={{ padding: "clamp(60px,12vh,140px) 24px", display: "flex", justifyContent: "center" }}>
          <div style={{ position: "relative", maxWidth: 520, width: "100%", background: "rgba(15,23,48,0.55)", border: "1px solid rgba(255,255,255,0.1)", padding: "clamp(30px,5vw,52px)", textAlign: "center" }}>
            <div style={{ position: "absolute", top: -1, left: -1, width: 16, height: 16, borderTop: `1px solid ${GOLD}`, borderLeft: `1px solid ${GOLD}` }} />
            <div style={{ position: "absolute", top: -1, right: -1, width: 16, height: 16, borderTop: `1px solid ${GOLD}`, borderRight: `1px solid ${GOLD}` }} />
            <div style={{ position: "absolute", bottom: -1, left: -1, width: 16, height: 16, borderBottom: `1px solid ${GOLD}`, borderLeft: `1px solid ${GOLD}` }} />
            <div style={{ position: "absolute", bottom: -1, right: -1, width: 16, height: 16, borderBottom: `1px solid ${GOLD}`, borderRight: `1px solid ${GOLD}` }} />
            <div style={{ width: 58, height: 58, margin: "0 auto", border: `1px solid rgba(176,141,87,0.6)`, display: "flex", alignItems: "center", justifyContent: "center", color: GOLD, background: "rgba(176,141,87,0.06)" }}>
              <svg width="20" height="22" viewBox="0 0 22 24" fill="none"><rect x="2.5" y="10" width="17" height="12" rx="1.5" stroke="currentColor" strokeWidth="1.4" /><path d="M6 10V6.5a5 5 0 0110 0V10" stroke="currentColor" strokeWidth="1.4" /><circle cx="11" cy="15.5" r="1.3" fill="currentColor" /></svg>
            </div>
            <span style={{ display: "block", fontFamily: MONO, fontSize: 11, letterSpacing: "0.24em", textTransform: "uppercase", color: GOLD, marginTop: 24 }}>{c.tag}</span>
            <h1 style={{ fontFamily: SERIF, fontWeight: 600, fontSize: "clamp(1.9rem,4vw,2.6rem)", lineHeight: 1.2, color: HEAD, margin: "14px 0 0" }}>{c.title}</h1>
            <p style={{ fontSize: 15, color: MUTE2, lineHeight: 1.65, margin: "16px auto 0", maxWidth: 380 }}>{c.body}</p>
          </div>
        </section>
        <Footer />
      </Shell>
    );
  }

  // ─── main ───
  const q = questions[qIndex];
  const sel = q ? answers[q.id] : undefined;
  const total = questions.length;
  const isLast = qIndex === total - 1;
  const submitDisabled = typeof sel !== "number" || submitting;
  const submitLabel = submitting ? "Saving…" : isLast ? "Submit & finish" : "Submit answer";

  const passed = !!result?.passed;
  const finished = !!result?.finished;
  const isRetry = !!result && !passed && !finished;
  const score = result?.score ?? 0;
  const resultTotal = result?.total ?? total;

  return (
    <Shell>
      <TopBar />

      {/* ===== LEAVE-MID-FLOW WARNING ===== */}
      {showLeaveWarning && (
        <div
          role="dialog"
          aria-modal="true"
          style={{
            position: "fixed", inset: 0, zIndex: 1000,
            background: "rgba(5,8,18,0.78)", backdropFilter: "blur(6px)",
            display: "flex", alignItems: "center", justifyContent: "center",
            padding: 24, animation: "eiaRise .25s ease both",
          }}
        >
          <div
            style={{
              position: "relative", width: "100%", maxWidth: 460,
              background: "rgba(15,23,48,0.96)", border: "1px solid rgba(255,255,255,0.12)",
              borderTop: `3px solid ${GOLD}`, padding: "clamp(28px,5vw,40px)",
              textAlign: "center", boxSizing: "border-box",
              boxShadow: "0 40px 90px -30px rgba(0,0,0,0.8)",
            }}
          >
            <div style={{ fontFamily: MONO, fontSize: 11, letterSpacing: "0.26em", textTransform: "uppercase", color: GOLD }}>
              Hold on — almost there
            </div>
            <h3 style={{ fontFamily: SERIF, fontWeight: 600, fontSize: "clamp(1.6rem,4vw,2.1rem)", lineHeight: 1.25, color: HEAD, margin: "14px 0 0" }}>
              Don't leave just yet.
            </h3>
            <p style={{ fontSize: 15, color: MUTE3, lineHeight: 1.65, margin: "14px 0 0" }}>
              You have not completed the test. Please complete it, or your onboarding will not be completed.
            </p>
            <button
              onClick={() => setShowLeaveWarning(false)}
              style={{
                marginTop: 28, background: GOLD, color: INK, border: "none",
                fontFamily: SANS, fontSize: 14.5, fontWeight: 600,
                padding: "15px 36px", cursor: "pointer", letterSpacing: "0.01em",
              }}
              onMouseEnter={(e) => (e.currentTarget.style.background = GOLD_HOVER)}
              onMouseLeave={(e) => (e.currentTarget.style.background = GOLD)}
            >
              Continue the test
            </button>
          </div>
        </div>
      )}



      {/* ===== HERO + VIDEO ===== */}
      {screen === "video" && (
      <>
      <section ref={videoSectionRef} style={{ padding: "clamp(28px,4vh,52px) 24px clamp(40px,6vh,72px)" }}>
        <div style={{ width: "100%", maxWidth: 1000, margin: "0 auto", display: "flex", flexDirection: "column", alignItems: "center", animation: "eiaRise 1s ease both" }}>

          {/* VIDEO VIEWPORT — now the first thing on the page */}
          <div style={{ position: "relative", width: "100%", maxWidth: 900, margin: "0 auto" }}>
            {/* corner reticles */}
            <div style={{ position: "absolute", top: -7, left: -7, width: 20, height: 20, borderTop: `1.5px solid ${GOLD}`, borderLeft: `1.5px solid ${GOLD}`, animation: "eiaGlow 3s ease-in-out infinite" }} />
            <div style={{ position: "absolute", top: -7, right: -7, width: 20, height: 20, borderTop: `1.5px solid ${GOLD}`, borderRight: `1.5px solid ${GOLD}`, animation: "eiaGlow 3s ease-in-out infinite .4s" }} />
            <div style={{ position: "absolute", bottom: -7, left: -7, width: 20, height: 20, borderBottom: `1.5px solid ${GOLD}`, borderLeft: `1.5px solid ${GOLD}`, animation: "eiaGlow 3s ease-in-out infinite .8s" }} />
            <div style={{ position: "absolute", bottom: -7, right: -7, width: 20, height: 20, borderBottom: `1.5px solid ${GOLD}`, borderRight: `1.5px solid ${GOLD}`, animation: "eiaGlow 3s ease-in-out infinite 1.2s" }} />
            {/* mid-edge HUD ticks */}
            <div style={{ position: "absolute", top: -5, left: "50%", width: 1, height: 9, background: "rgba(176,141,87,0.6)" }} />
            <div style={{ position: "absolute", bottom: -5, left: "50%", width: 1, height: 9, background: "rgba(176,141,87,0.6)" }} />
            <div style={{ position: "absolute", left: -5, top: "50%", width: 9, height: 1, background: "rgba(176,141,87,0.6)" }} />
            <div style={{ position: "absolute", right: -5, top: "50%", width: 9, height: 1, background: "rgba(176,141,87,0.6)" }} />

            <div
              style={{
                position: "relative",
                width: "100%",
                aspectRatio: "16 / 9",
                background: "linear-gradient(155deg, #11204a 0%, #0a1020 70%)",
                border: "1px solid rgba(176,141,87,0.35)",
                overflow: "hidden",
                boxShadow: "0 40px 90px -40px rgba(0,0,0,0.8), 0 0 70px -24px rgba(176,141,87,0.3)",
              }}
            >
              {/* ambient layers */}
              <div style={{ position: "absolute", inset: 0, background: "radial-gradient(circle at 50% 45%, rgba(176,141,87,0.12), transparent 55%)", pointerEvents: "none" }} />
              <div style={{ position: "absolute", inset: 0, backgroundImage: "linear-gradient(rgba(255,255,255,0.025) 1px, transparent 1px), linear-gradient(90deg, rgba(255,255,255,0.025) 1px, transparent 1px)", backgroundSize: "40px 40px", pointerEvents: "none" }} />
              {!videoStarted && (
                <div style={{ position: "absolute", top: 0, bottom: 0, width: 90, background: "linear-gradient(90deg, transparent, rgba(176,141,87,0.08), transparent)", animation: "eiaSweep 6s linear infinite", pointerEvents: "none", zIndex: 1 }} />
              )}

              {/* real thumbnail (oEmbed) shown before play, with dark overlay */}
              {!videoStarted && thumbUrl && (
                <>
                  <div
                    style={{
                      position: "absolute",
                      inset: 0,
                      backgroundImage: `url("${thumbUrl}")`,
                      backgroundSize: "cover",
                      backgroundPosition: "center",
                      pointerEvents: "none",
                    }}
                  />
                  <div style={{ position: "absolute", inset: 0, background: "linear-gradient(180deg, rgba(8,13,26,0.55), rgba(8,13,26,0.72))", pointerEvents: "none" }} />
                </>
              )}

              {/* real player (mounted after the candidate hits play) */}
              {videoStarted && hasVideo && (
                <div style={{ position: "absolute", inset: 0, zIndex: 1 }}>
                  {isVimeo ? (
                    <VimeoWatchGate src={vimeoSrc} onEnded={() => setVideoEnded(true)} />
                  ) : isYouTube ? (
                    <iframe
                      src={videoUrl!}
                      title="Orientation video"
                      allow="autoplay; fullscreen; picture-in-picture"
                      allowFullScreen
                      style={{ position: "absolute", inset: 0, width: "100%", height: "100%", border: 0 }}
                    />
                  ) : (
                    <video
                      ref={videoRef}
                      src={videoUrl!}
                      autoPlay
                      controls
                      controlsList="nodownload noplaybackrate"
                      onContextMenu={(e) => e.preventDefault()}
                      onEnded={() => setVideoEnded(true)}
                      style={{ position: "absolute", inset: 0, width: "100%", height: "100%", display: "block", background: "#000" }}
                    />
                  )}
                </div>
              )}

              {/* telemetry top */}
              <div style={{ position: "absolute", top: 0, left: 0, right: 0, padding: "14px 18px", display: "flex", alignItems: "center", justifyContent: "space-between", fontFamily: MONO, fontSize: 10.5, letterSpacing: "0.16em", textTransform: "uppercase", pointerEvents: "none", zIndex: 2 }}>
                <span style={{ display: "flex", alignItems: "center", gap: 7, color: GOLD }}>
                  <span style={{ width: 5, height: 5, borderRadius: "50%", background: GOLD, animation: "eiaBlink 1.6s ease-in-out infinite" }} />
                  {statusLabel}
                </span>
                <span style={{ color: DIM2 }}>Onboarding Training · 06:00</span>
              </div>

              {/* idle play overlay */}
              {!videoStarted && (
                <button
                  onClick={() => hasVideo && setVideoStarted(true)}
                  disabled={!hasVideo}
                  style={{ position: "absolute", inset: 0, zIndex: 3, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", gap: 20, background: "transparent", border: "none", cursor: hasVideo ? "pointer" : "default" }}
                >
                  <div style={{ position: "relative", width: 92, height: 92, display: "flex", alignItems: "center", justifyContent: "center" }}>
                    <span style={{ position: "absolute", inset: -8, border: "1px dashed rgba(176,141,87,0.45)", borderRadius: "50%", animation: "eiaSpin 16s linear infinite" }} />
                    <span style={{ position: "absolute", inset: 4, border: "1px solid rgba(176,141,87,0.35)", borderTopColor: "rgba(176,141,87,0.9)", borderRadius: "50%", animation: "eiaSpinR 6s linear infinite" }} />
                    <span style={{ position: "absolute", inset: 0, border: "1px solid rgba(176,141,87,0.4)", borderRadius: "50%", animation: "eiaPulse 3s ease-in-out infinite" }} />
                    <span style={{ position: "absolute", inset: 18, border: "1px solid rgba(176,141,87,0.7)", borderRadius: "50%", background: "rgba(176,141,87,0.06)" }} />
                    <svg width="20" height="22" viewBox="0 0 22 24" fill="none" style={{ marginLeft: 4, position: "relative" }}><path d="M1 1.8L20.5 12 1 22.2V1.8Z" fill={GOLD} /></svg>
                  </div>
                  <div style={{ fontFamily: MONO, fontSize: 11, letterSpacing: "0.24em", textTransform: "uppercase", color: MUTE }}>
                    {hasVideo ? "Play onboarding training" : "Training video pending"}
                  </div>
                </button>
              )}
            </div>
          </div>

          {/* READY → START THE TEST (always visible; grayed until video ends) */}
          <div style={{ width: "100%", maxWidth: 760, margin: "clamp(28px,4vh,44px) auto 0", textAlign: "center" }}>
            {unlocked && (
              <div style={{ fontFamily: SERIF, fontSize: "clamp(1.35rem,3vw,1.9rem)", fontWeight: 600, color: HEAD, lineHeight: 1.3, marginBottom: "clamp(18px,2.4vh,26px)", animation: "eiaRise .6s ease both" }}>
                One step left — complete your certification.
              </div>
            )}
            <div style={{ position: "relative", display: "inline-block", width: "min(100%, 480px)", maxWidth: "100%" }}>
              <button
                onClick={() => {
                  if (unlocked) {
                    onStartTest();
                    return;
                  }
                  setShowWatchHint(true);
                  if (watchHintTimer.current) window.clearTimeout(watchHintTimer.current);
                  watchHintTimer.current = window.setTimeout(() => setShowWatchHint(false), 3200);
                }}
                aria-disabled={!unlocked}
                style={{
                  background: unlocked ? EMERALD : "rgba(255,255,255,0.05)",
                  color: unlocked ? "#ffffff" : MUTE2,
                  border: unlocked ? "none" : "1px solid rgba(255,255,255,0.1)",
                  borderRadius: 10,
                  fontFamily: SANS,
                  fontSize: "clamp(17px,2.4vw,21px)",
                  fontWeight: 700,
                  padding: "clamp(20px,2.6vh,26px) clamp(40px,7vw,72px)",
                  width: "100%",
                  cursor: unlocked ? "pointer" : "not-allowed",
                  letterSpacing: "0.01em",
                  animation: unlocked ? "eiaReadyGlow 2.4s ease-in-out infinite" : "none",
                  transition: "background-color .15s ease, transform .15s ease",
                }}
                onMouseEnter={(e) => {
                  if (!unlocked) return;
                  e.currentTarget.style.background = EMERALD_HOVER;
                  e.currentTarget.style.transform = "translateY(-2px)";
                }}
                onMouseLeave={(e) => {
                  if (!unlocked) return;
                  e.currentTarget.style.background = EMERALD;
                  e.currentTarget.style.transform = "none";
                }}
              >
                I'm ready — Start the Test
              </button>

              {/* calm watch-hint shown when the grayed button is tapped */}
              {showWatchHint && !unlocked && (
                <div
                  style={{
                    position: "absolute",
                    top: "calc(100% + 12px)",
                    left: "50%",
                    transform: "translateX(-50%)",
                    background: "rgba(15,23,48,0.97)",
                    border: `1px solid rgba(176,141,87,0.5)`,
                    borderRadius: 8,
                    padding: "11px 18px",
                    whiteSpace: "nowrap",
                    fontFamily: MONO,
                    fontSize: 11,
                    letterSpacing: "0.12em",
                    textTransform: "uppercase",
                    color: GOLD,
                    boxShadow: "0 18px 40px -16px rgba(0,0,0,0.7)",
                    zIndex: 5,
                    animation: "eiaRise .25s ease both",
                  }}
                >
                  Watch the complete video to unlock the test.
                </div>
              )}
            </div>
            <div style={{ fontFamily: MONO, fontSize: 11, letterSpacing: "0.2em", textTransform: "uppercase", color: DIM, marginTop: 18 }}>
              {unlocked
                ? isTest ? "Test mode · quiz unlocked" : "Training complete · the certification awaits"
                : "Locked · finish the orientation video to begin"}
            </div>
          </div>

          {/* GATE RAIL — progress strip now sits below the button */}
          <div style={{ width: "100%", maxWidth: 760, margin: "clamp(28px,4vh,44px) auto 0", border: "1px solid rgba(255,255,255,0.08)", background: "rgba(15,23,48,0.5)", padding: "22px 26px", display: "flex", alignItems: "center", gap: "clamp(16px,4vw,36px)" }}>
            <div style={{ display: "flex", flexDirection: "column", gap: 6, minWidth: 88 }}>
              <span style={{ fontFamily: MONO, fontSize: 10.5, letterSpacing: "0.18em", color: GOLD }}>01 · WATCH</span>
              <span style={{ fontFamily: MONO, fontSize: 13, color: BODY, fontWeight: 500 }}>{unlocked ? "Done" : videoStarted ? "Watching" : "Standby"}</span>
            </div>
            <div style={{ flex: 1, position: "relative", height: 2, background: "rgba(255,255,255,0.1)" }}>
              <div style={{ position: "absolute", left: 0, top: 0, height: "100%", width: unlocked ? "100%" : videoStarted ? "50%" : "0%", background: GOLD, transition: "width .3s ease" }} />
            </div>
            <div style={{ display: "flex", flexDirection: "column", gap: 6, minWidth: 88, textAlign: "right", alignItems: "flex-end" }}>
              <span style={{ fontFamily: MONO, fontSize: 10.5, letterSpacing: "0.18em", color: unlocked ? GOLD : DIM }}>02 · QUIZ</span>
              <span style={{ display: "inline-flex", alignItems: "center", gap: 6, fontFamily: MONO, fontSize: 13, fontWeight: 500, color: unlocked ? BODY : DIM }}>
                {!unlocked && (
                  <svg width="10" height="12" viewBox="0 0 14 16" fill="none"><rect x="1.5" y="6.5" width="11" height="8" rx="1" stroke="currentColor" strokeWidth="1.3" /><path d="M4 6.5V4.5a3 3 0 016 0v2" stroke="currentColor" strokeWidth="1.3" /></svg>
                )}
                {unlocked ? "Ready" : "Locked"}
              </span>
            </div>
          </div>
        </div>
      </section>

      {/* ===== SPEC SHEET ===== */}
      <section style={{ padding: "clamp(40px,6vh,72px) 24px", borderTop: "1px solid rgba(255,255,255,0.07)" }}>
        <div style={{ maxWidth: 1080, margin: "0 auto" }}>
          <div style={{ display: "flex", alignItems: "baseline", justifyContent: "space-between", flexWrap: "wrap", gap: 12, marginBottom: 36 }}>
            <h2 style={{ fontFamily: SERIF, fontWeight: 600, fontSize: "clamp(1.8rem,3.4vw,2.6rem)", lineHeight: 1.15, margin: 0, color: HEAD }}>What this orientation covers</h2>
            <span style={{ fontFamily: MONO, fontSize: 11, letterSpacing: "0.2em", textTransform: "uppercase", color: DIM }}>04 Modules</span>
          </div>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(230px, 1fr))", borderTop: "1px solid rgba(255,255,255,0.1)", borderLeft: "1px solid rgba(255,255,255,0.1)" }}>
            {SPEC.map((it) => (
              <div key={it.no} style={{ padding: "28px 26px 32px", borderRight: "1px solid rgba(255,255,255,0.1)", borderBottom: "1px solid rgba(255,255,255,0.1)", background: "rgba(255,255,255,0.008)", display: "flex", flexDirection: "column" }}>
                <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
                  <span style={{ width: 8, height: 8, border: `1px solid ${GOLD}`, borderRadius: "50%" }} />
                  <span style={{ fontFamily: MONO, fontSize: 11, letterSpacing: "0.16em", color: DIM2 }}>{it.no}</span>
                </div>
                <div style={{ display: "flex", flexDirection: "column", gap: 9, marginTop: 26 }}>
                  <div style={{ fontFamily: SERIF, fontSize: 21, fontWeight: 600, lineHeight: 1.25, color: HEAD }}>{it.title}</div>
                  <div style={{ fontSize: 13, color: MUTE2, lineHeight: 1.55 }}>{it.sub}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>
      </>
      )}



      {/* ===== CERTIFICATION CONSOLE ===== */}
      {screen === "quiz" && (
      <section style={{ padding: "clamp(44px,7vh,88px) 24px clamp(60px,9vh,104px)", borderTop: "1px solid rgba(255,255,255,0.07)" }}>
        <div style={{ maxWidth: 760, margin: "0 auto" }}>
          <div style={{ textAlign: "center", marginBottom: 38 }}>
            <span style={{ fontFamily: MONO, fontSize: 11, letterSpacing: "0.28em", textTransform: "uppercase", color: GOLD }}>Step 02 / 02 — Certification</span>
            <h2 style={{ fontFamily: SERIF, fontWeight: 600, fontSize: "clamp(2rem,4.2vw,3rem)", lineHeight: 1.18, margin: "16px 0 0", color: HEAD }}>Clear the quiz to continue.</h2>
            <p style={{ fontSize: 14.5, color: MUTE2, margin: "14px 0 0", lineHeight: 1.6 }}>Every answer is in the training — rewatch any time.</p>
          </div>

          <div style={{ position: "relative" }}>
            {/* panel corner ticks */}
            <div style={{ position: "absolute", top: -1, left: -1, width: 16, height: 16, borderTop: `1px solid ${GOLD}`, borderLeft: `1px solid ${GOLD}`, zIndex: 2 }} />
            <div style={{ position: "absolute", top: -1, right: -1, width: 16, height: 16, borderTop: `1px solid ${GOLD}`, borderRight: `1px solid ${GOLD}`, zIndex: 2 }} />
            <div style={{ position: "absolute", bottom: -1, left: -1, width: 16, height: 16, borderBottom: `1px solid ${GOLD}`, borderLeft: `1px solid ${GOLD}`, zIndex: 2 }} />
            <div style={{ position: "absolute", bottom: -1, right: -1, width: 16, height: 16, borderBottom: `1px solid ${GOLD}`, borderRight: `1px solid ${GOLD}`, zIndex: 2 }} />

            <div
              style={{
                position: "relative",
                background: "rgba(15,23,48,0.55)",
                border: "1px solid rgba(255,255,255,0.1)",
                padding: "clamp(26px,4vw,44px)",
                boxSizing: "border-box",
                opacity: unlocked ? 1 : 0.5,
                pointerEvents: unlocked ? "auto" : "none",
                filter: unlocked ? "none" : "saturate(0.7)",
                transition: "opacity .4s ease",
              }}
            >
              {result ? (
                /* RESULT */
                <div style={{ display: "flex", flexDirection: "column", alignItems: "center", textAlign: "center", padding: "16px 0 8px" }}>
                  <div style={{ width: 64, height: 64, borderRadius: "50%", display: "flex", alignItems: "center", justifyContent: "center", border: `1px solid ${passed ? GOLD : "rgba(255,255,255,0.18)"}`, background: passed ? "rgba(176,141,87,0.1)" : "rgba(255,255,255,0.03)", color: GOLD }}>
                    {passed ? (
                      <svg width="28" height="28" viewBox="0 0 24 24" fill="none"><path d="M5 12.5l4.2 4.2L19 7" stroke={GOLD} strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round" /></svg>
                    ) : (
                      <svg width="26" height="26" viewBox="0 0 24 24" fill="none"><path d="M12 8v5M12 16.5v.01" stroke={GOLD} strokeWidth="1.7" strokeLinecap="round" /><circle cx="12" cy="12" r="9" stroke={GOLD} strokeWidth="1.3" /></svg>
                    )}
                  </div>
                  <span style={{ fontFamily: MONO, fontSize: 11, letterSpacing: "0.24em", textTransform: "uppercase", color: GOLD, marginTop: 26 }}>
                    {`Result · ${score}/${resultTotal} · ${passed ? "Cleared" : finished ? "Closed" : "Review"}`}
                  </span>
                  <h3 style={{ fontFamily: SERIF, fontWeight: 600, fontSize: "clamp(2rem,4.2vw,2.9rem)", lineHeight: 1.25, color: HEAD, margin: "14px 0 0", maxWidth: 440 }}>
                    {passed ? "You're all set." : finished ? "Thank you for trying." : "Review and try again."}
                  </h3>
                  <p style={{ fontSize: 15, color: MUTE2, lineHeight: 1.65, maxWidth: 420, margin: "16px 0 0" }}>
                    {passed
                      ? "You understand how EIA operates and what comes next. Welcome aboard — HR will be in touch shortly with your next step. You can safely close this page."
                      : finished
                      ? "You've used all of your attempts for this onboarding check. Please reach out to your HR representative — they'll be glad to talk through next steps with you."
                      : "A few answers need another look. Every answer is in the training — rewatch it, then run the certification once more." +
                        (typeof result?.attempts_left === "number" && result.attempts_left > 0
                          ? ` You have ${result.attempts_left} ${result.attempts_left === 1 ? "attempt" : "attempts"} remaining.`
                          : "")}
                  </p>

                  <div style={{ display: "flex", alignItems: "center", gap: 16, marginTop: 34, flexWrap: "wrap", justifyContent: "center" }}>
                    {isRetry && (
                      <>
                        <button onClick={onRetry} style={{ background: GOLD, color: INK, border: "none", fontFamily: SANS, fontSize: 13.5, fontWeight: 600, padding: "15px 32px", cursor: "pointer", letterSpacing: "0.01em" }}>Try again</button>
                        <button onClick={onRewatch} style={{ background: "none", border: "1px solid rgba(255,255,255,0.16)", color: BODY, fontFamily: SANS, fontSize: 13.5, fontWeight: 500, padding: "14px 28px", cursor: "pointer" }}>Rewatch training</button>
                      </>
                    )}
                  </div>
                </div>
              ) : (
                /* QUESTION */
                <>
                  <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 18 }}>
                    <span style={{ fontFamily: MONO, fontSize: 11, letterSpacing: "0.18em", textTransform: "uppercase", color: DIM }}>Certification · {total} items</span>
                    <span style={{ fontFamily: MONO, fontSize: 11, letterSpacing: "0.18em", color: GOLD }}>Q.{String(qIndex + 1).padStart(2, "0")} / {total}</span>
                  </div>
                  <div style={{ display: "flex", gap: 4, marginBottom: 30 }}>
                    {Array.from({ length: total }, (_, i) => (
                      <div key={i} style={{ flex: 1, height: 3, background: i <= qIndex ? GOLD : "rgba(255,255,255,0.1)", transition: "background-color .3s ease" }} />
                    ))}
                  </div>

                  <div key={`q${qIndex}`}>
                    <h3 style={{ fontFamily: SERIF, fontWeight: 600, fontSize: "clamp(1.55rem,3vw,2.05rem)", lineHeight: 1.28, color: HEAD, margin: "0 0 28px" }}>{q ? q.question : "No questions are available yet. Please contact HR."}</h3>

                    <div style={{ display: "flex", flexDirection: "column", gap: 9 }}>
                      {q?.options.map((opt, i) => {
                        const selected = sel === i;
                        return (
                          <div
                            key={i}
                            onClick={() => choose(q.id, i)}
                            style={{
                              display: "flex",
                              alignItems: "center",
                              gap: 16,
                              padding: "15px 18px",
                              minHeight: 58,
                              boxSizing: "border-box",
                              border: `1px solid ${selected ? GOLD : "rgba(255,255,255,0.1)"}`,
                              cursor: "pointer",
                              background: selected ? "rgba(176,141,87,0.12)" : "rgba(255,255,255,0.012)",
                              transition: "border-color .15s ease, background-color .12s ease",
                              userSelect: "none",
                            }}
                          >
                            <div style={{ width: 26, height: 26, flexShrink: 0, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 12, fontWeight: 500, fontFamily: MONO, border: `1px solid ${selected ? GOLD : "rgba(255,255,255,0.16)"}`, background: selected ? GOLD : "transparent", color: selected ? INK : "#8a93ad" }}>{"ABCD"[i]}</div>
                            <span style={{ flex: 1, fontSize: 15, fontWeight: 400, lineHeight: 1.4, color: selected ? HEAD : MUTE3, fontFamily: SANS }}>{opt}</span>
                            <div style={{ width: 20, height: 20, borderRadius: "50%", flexShrink: 0, display: "flex", alignItems: "center", justifyContent: "center", background: selected ? GOLD : "transparent", opacity: selected ? 1 : 0, transition: "opacity .12s ease" }}>
                              <svg width="14" height="14" viewBox="0 0 24 24" fill="none"><path d="M5 12.5l4.2 4.2L19 7" stroke={INK} strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" /></svg>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </div>

                  <div style={{ display: "flex", alignItems: "center", gap: 22, marginTop: 32, flexWrap: "wrap" }}>
                    <button
                      onClick={onSubmit}
                      disabled={submitDisabled}
                      style={{
                        background: submitDisabled ? "rgba(255,255,255,0.06)" : GOLD,
                        color: submitDisabled ? DIM2 : INK,
                        border: "none",
                        fontFamily: SANS,
                        fontSize: 13.5,
                        fontWeight: 600,
                        padding: "15px 34px",
                        cursor: submitDisabled ? "not-allowed" : "pointer",
                        letterSpacing: "0.01em",
                        transition: "background-color .15s ease",
                      }}
                    >
                      {submitLabel}
                    </button>
                    <button
                      onClick={onRewatch}
                      style={{ background: "none", border: "none", color: MUTE2, fontFamily: MONO, fontSize: 12, letterSpacing: "0.12em", textTransform: "uppercase", cursor: "pointer", padding: "8px 2px", display: "inline-flex", alignItems: "center", gap: 8 }}
                    >
                      <svg width="13" height="13" viewBox="0 0 24 24" fill="none"><path d="M20 11a8 8 0 10-2.3 5.6M20 5v6h-6" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round" /></svg>
                      Rewatch training
                    </button>
                  </div>
                </>
              )}
            </div>

            {/* LOCK OVERLAY */}
            {!unlocked && (
              <div style={{ position: "absolute", inset: 0, background: "rgba(8,13,26,0.72)", backdropFilter: "blur(4px)", WebkitBackdropFilter: "blur(4px)", display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", textAlign: "center", padding: 28, overflow: "hidden" }}>
                <div style={{ position: "absolute", left: 0, right: 0, height: 1, background: "linear-gradient(90deg, transparent, rgba(176,141,87,0.4), transparent)", animation: "eiaScan 4s linear infinite" }} />
                <div style={{ width: 58, height: 58, border: "1px solid rgba(176,141,87,0.6)", display: "flex", alignItems: "center", justifyContent: "center", color: GOLD, background: "rgba(176,141,87,0.06)" }}>
                  <svg width="20" height="22" viewBox="0 0 22 24" fill="none"><rect x="2.5" y="10" width="17" height="12" rx="1.5" stroke="currentColor" strokeWidth="1.4" /><path d="M6 10V6.5a5 5 0 0110 0V10" stroke="currentColor" strokeWidth="1.4" /><circle cx="11" cy="15.5" r="1.3" fill="currentColor" /></svg>
                </div>
                <span style={{ fontFamily: MONO, fontSize: 11, letterSpacing: "0.26em", textTransform: "uppercase", color: GOLD, marginTop: 22 }}>Access locked</span>
                <div style={{ fontFamily: SERIF, fontSize: 23, fontWeight: 600, lineHeight: 1.3, color: HEAD, marginTop: 12, maxWidth: 340 }}>Finish the training to unlock the quiz.</div>
                <div style={{ fontFamily: MONO, fontSize: 11.5, color: DIM, marginTop: 14, letterSpacing: "0.04em" }}>{videoStarted ? "Keep watching · the quiz unlocks at the end" : "Runtime · 06:00"}</div>
              </div>
            )}
          </div>
        </div>
      </section>
      )}

      <Footer />
    </Shell>
  );
}
