import StageTrackingView from "@/components/StageTrackingView";
export default function Disqualified() { return <StageTrackingView mode="disqualified" />; }
