import { useEffect, useRef, useState } from "react";
import { useNavigate, useSearchParams } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "@/components/ui/dialog";
import { Table, TableHeader, TableBody, TableRow, TableHead, TableCell } from "@/components/ui/table";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { ArrowLeft, Lock, Loader2, ShieldAlert, Eye, Trash2, Mail, FileSignature } from "lucide-react";
import { toast } from "sonner";

type Offer = {
  id: string;
  candidate_id: string | null;
  candidate_name: string;
  candidate_email: string;
  position_title: string;
  start_date: string | null;
  signed_at: string | null;
  signed_pdf_url: string | null;
  employment_status: string;
  terminated_at: string | null;
  termination_reason: string | null;
  terminated_by_hr_id: string | null;
  internal_notes: string | null;
};
type HrUser = { id: string; display_name: string | null; role: string | null; email: string };
type Answer = { id: string; response_id: string; question_id: string; answer_text: string | null; file_url: string | null };
type Resp = { id: string; applicant_id: string; form_id: string; submitted_at: string };
type Question = { id: string; form_id: string; label: string; type: string; order_index: number };
type EmailLog = { id: string; job_offer_id: string | null; subject: string; status: string; sent_at: string | null; stage: string; to_address: string; created_at: string };
type SettlementSig = { id: string; response_id: string | null; signer_email: string | null; external_reference: string; status: string; signed_at: string | null; signing_url: string | null; signed_pdf_url: string | null; doc_type: string; created_at: string };

const SESSION_KEY = "quarantine_unlocked_at";
const SESSION_TTL_MS = 30 * 60 * 1000;

const fmtDateTime = (d: string | null) => d ? new Date(d).toLocaleString("en-US") : "—";
const fmtDate = (d: string | null) => d ? new Date(d).toLocaleDateString("en-US", { year: "numeric", month: "short", day: "numeric" }) : "—";
const daysBetween = (a: string | null, b: string | null) => (!a || !b) ? 0 : Math.max(0, Math.floor((new Date(b).getTime() - new Date(a).getTime()) / 86400000));

export default function QuarantineDashboard() {
  const navigate = useNavigate();
  const [searchParams, setSearchParams] = useSearchParams();
  const [highlightId, setHighlightId] = useState<string | null>(null);
  const locateHandledRef = useRef<string | null>(null);
  const [unlocked, setUnlocked] = useState(false);
  const [pwd, setPwd] = useState("");
  const [busy, setBusy] = useState(false);
  const [storedPwd, setStoredPwd] = useState<string>(""); // kept in memory only, for re-confirm on delete

  const [offers, setOffers] = useState<Offer[]>([]);
  const [hrUsers, setHrUsers] = useState<HrUser[]>([]);
  const [responses, setResponses] = useState<Resp[]>([]);
  const [answers, setAnswers] = useState<Answer[]>([]);
  const [questions, setQuestions] = useState<Question[]>([]);
  const [emailLogs, setEmailLogs] = useState<EmailLog[]>([]);
  const [settlementSigs, setSettlementSigs] = useState<SettlementSig[]>([]);
  const [deletedAppointments, setDeletedAppointments] = useState<{ id: string; name: string; email: string; position: string; moved_at: string | null; submitted_at: string | null }[]>([]);

  const [viewOffer, setViewOffer] = useState<Offer | null>(null);
  const [deleteOffer, setDeleteOffer] = useState<Offer | null>(null);
  const [deletePwd, setDeletePwd] = useState("");

  // Resend termination notice
  const [resendOffer, setResendOffer] = useState<Offer | null>(null);
  const [resendEmail, setResendEmail] = useState("");
  const [resendPwd, setResendPwd] = useState("");

  // Send settlement form
  const [settleOffer, setSettleOffer] = useState<Offer | null>(null);
  const [settleEmail, setSettleEmail] = useState("");

  // Re-Sign NDA
  const [ndaOffer, setNdaOffer] = useState<Offer | null>(null);
  const [ndaEmail, setNdaEmail] = useState("");
  const [ndaSigs, setNdaSigs] = useState<SettlementSig[]>([]);

  // Check session on mount
  useEffect(() => {
    const ts = sessionStorage.getItem(SESSION_KEY);
    if (ts && Date.now() - Number(ts) < SESSION_TTL_MS) {
      // Still need the password again to fetch data — sessionStorage only suppresses re-prompt UX
      // We can't restore the password from storage for security, so require re-entry on reload.
      // Clear the marker since we must re-prompt.
      sessionStorage.removeItem(SESSION_KEY);
    }
  }, []);

  // Consume ?locate=<response_id> from the Results page "Locate Me" button.
  // Quarantine is password-gated: hold the locate intent (do NOT clear the
  // param) until the list is unlocked and loaded, then map the response_id to
  // its terminated offer row, scroll to it and flash it gold.
  useEffect(() => {
    const locate = (searchParams.get("locate") || "").trim();
    if (!locate) return;
    // Wait for unlock + data; keep the param so it survives the password flow.
    if (!unlocked || !offers.length) return;
    if (locateHandledRef.current === locate) return;
    locateHandledRef.current = locate;

    const clearParam = () => {
      const next = new URLSearchParams(searchParams);
      next.delete("locate");
      setSearchParams(next, { replace: true });
    };

    // response_id -> applicant_id -> offer.candidate_id -> offer row id.
    const resp = responses.find((r) => r.id === locate);
    const offer = resp
      ? offers.find((o) => o.candidate_id === resp.applicant_id)
      : undefined;
    if (!offer) {
      toast.error("Candidate not found in current view");
      clearParam();
      return;
    }
    setHighlightId(offer.id);
    clearParam();
  }, [unlocked, offers, responses, searchParams, setSearchParams]);

  // Scroll to + briefly highlight the located row once it is rendered.
  useEffect(() => {
    if (!highlightId) return;
    const scrollTimer = setTimeout(() => {
      const el = document.querySelector(`[data-response-id="${highlightId}"]`);
      if (el) el.scrollIntoView({ behavior: "smooth", block: "center" });
    }, 150);
    const clearTimer = setTimeout(() => setHighlightId(null), 2600);
    return () => { clearTimeout(scrollTimer); clearTimeout(clearTimer); };
  }, [highlightId, offers]);

  async function fetchNdaSigs(offerList?: Offer[]) {
    const list = offerList || offers;
    const candIds = Array.from(new Set(list.map(o => o.candidate_id).filter(Boolean)));
    if (!candIds.length) { setNdaSigs([]); return; }
    try {
      const { data: respData } = await supabase.from("responses").select("id, applicant_id").in("applicant_id", candIds);
      const respIds = (respData || []).map(r => r.id);
      const emails = Array.from(new Set(list.map(o => (o.candidate_email || "").toLowerCase()).filter(Boolean)));
      if (!respIds.length && !emails.length) { setNdaSigs([]); return; }
      const filters = [
        respIds.length ? `response_id.in.(${respIds.join(",")})` : null,
        emails.length ? `signer_email.in.(${emails.map(e => `"${e}"`).join(",")})` : null,
      ].filter(Boolean).join(",");
      const { data } = await supabase.from("nda_signatures")
        .select("id, response_id, signer_email, external_reference, status, signed_at, signing_url, signed_pdf_url, doc_type, created_at")
        .eq("doc_type", "nda")
        .or(filters);
      setNdaSigs(data || []);
    } catch (_) { setNdaSigs([]); }
  }

  const unlock = async () => {
    if (!pwd) return;
    setBusy(true);
    try {
      const { data, error } = await supabase.functions.invoke("quarantine-access", { body: { password: pwd } });
      if (error) throw error;
      const d: any = data;
      if (d?.error === "wrong_password") { toast.error("Incorrect password"); setBusy(false); setPwd(""); return; }
      if (d?.error) throw new Error(d.error);
      setOffers(d.offers || []);
      setHrUsers(d.hr_users || []);
      setResponses(d.responses || []);
      setAnswers(d.answers || []);
      setQuestions(d.questions || []);
      setEmailLogs(d.email_logs || []);
      setSettlementSigs(d.settlement_signatures || []);
      setDeletedAppointments(d.deleted_appointments || []);
      setStoredPwd(pwd);
      setUnlocked(true);
      sessionStorage.setItem(SESSION_KEY, String(Date.now()));
      setPwd("");
      await fetchNdaSigs(d.offers || []);
    } catch (e: any) {
      toast.error(e?.message || "Failed to unlock");
    } finally {
      setBusy(false);
    }
  };

  const refresh = async () => {
    if (!storedPwd) return;
    try {
      const { data } = await supabase.functions.invoke("quarantine-access", { body: { password: storedPwd } });
      const d: any = data;
      if (d?.ok) {
        setOffers(d.offers || []);
        setEmailLogs(d.email_logs || []);
        setSettlementSigs(d.settlement_signatures || []);
        setDeletedAppointments(d.deleted_appointments || []);
        await fetchNdaSigs(d.offers || []);
      }
    } catch (_) { /* ignore */ }
  };

  const hrName = (id: string | null) => {
    if (!id) return "Unknown";
    const u = hrUsers.find(h => h.id === id);
    return u?.display_name || u?.email || "Unknown";
  };

  const doDelete = async () => {
    if (!deleteOffer) return;
    if (deletePwd !== storedPwd) { toast.error("Password mismatch"); return; }
    setBusy(true);
    try {
      const { data, error } = await supabase.functions.invoke("quarantine-delete-employee", {
        body: { job_offer_id: deleteOffer.id, password: deletePwd },
      });
      if (error) throw error;
      const d: any = data;
      if (d?.error === "wrong_password") { toast.error("Incorrect password"); setBusy(false); return; }
      if (d?.error) throw new Error(d.error);
      toast.success(`${deleteOffer.candidate_name} removed from Quarantine (Results record kept).`);
      setDeleteOffer(null); setDeletePwd("");
      await refresh();
    } catch (e: any) {
      toast.error(e?.message || "Delete failed");
    } finally {
      setBusy(false);
    }
  };

  const doResendTermination = async () => {
    if (!resendOffer) return;
    if (!resendPwd) { toast.error("Boss password required"); return; }
    if (!resendEmail || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(resendEmail)) {
      toast.error("Valid recipient email required"); return;
    }
    setBusy(true);
    try {
      const { data, error } = await supabase.functions.invoke("resend-termination-email", {
        body: { job_offer_id: resendOffer.id, override_email: resendEmail, password: resendPwd },
      });
      if (error) throw error;
      const d: any = data;
      if (d?.error === "wrong_password") { toast.error("Incorrect boss password"); setBusy(false); return; }
      if (d?.error === "not_terminated") { toast.error("Employee is not terminated"); setBusy(false); return; }
      if (d?.error) throw new Error(d.error);
      if (d?.ok === false) throw new Error(d?.reason || "Send failed");
      toast.success(`Termination notice sent to ${d?.recipient || resendEmail}.`);
      setResendOffer(null); setResendEmail(""); setResendPwd("");
      await refresh();
    } catch (e: any) {
      toast.error(e?.message || "Send failed");
    } finally {
      setBusy(false);
    }
  };

  const doSendSettlement = async () => {
    if (!settleOffer) return;
    if (!settleEmail || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(settleEmail)) {
      toast.error("Valid recipient email required"); return;
    }
    setBusy(true);
    try {
      const resp = responses.find(r => r.applicant_id === settleOffer.candidate_id);
      const body: any = resp
        ? { response_id: resp.id, override_email: settleEmail }
        : { name: settleOffer.candidate_name, email: settleEmail };
      const { data, error } = await supabase.functions.invoke("send-settlement", { body });
      if (error) throw error;
      const d: any = data;
      if (d?.ok === false) throw new Error(d?.reason || "Send failed");
      toast.success(`Settlement form sent to ${d?.recipient || settleEmail}.`);
      setSettleOffer(null); setSettleEmail("");
      await refresh();
    } catch (e: any) {
      toast.error(e?.message || "Send failed");
    } finally {
      setBusy(false);
    }
  };

  const doSendNda = async () => {
    if (!ndaOffer) return;
    if (!ndaEmail || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(ndaEmail)) {
      toast.error("Valid recipient email required"); return;
    }
    setBusy(true);
    try {
      const resp = responses.find(r => r.applicant_id === ndaOffer.candidate_id);
      const body: any = resp
        ? { response_id: resp.id, override_email: ndaEmail }
        : { name: ndaOffer.candidate_name, email: ndaEmail };
      const { data, error } = await supabase.functions.invoke("send-nda", { body });
      if (error) throw error;
      const d: any = data;
      if (d?.ok === false) throw new Error(d?.reason || "Send failed");
      toast.success(`NDA sent to ${d?.recipient || ndaEmail} to re-sign.`);
      setNdaOffer(null); setNdaEmail("");
      await refresh();
    } catch (e: any) {
      toast.error(e?.message || "Send failed");
    } finally {
      setBusy(false);
    }
  };





  // ---- Gate ----
  if (!unlocked) {
    return (
      <div className="min-h-screen bg-background flex flex-col">
        <header className="border-b bg-card">
          <div className="max-w-7xl mx-auto px-6 py-4">
            <Button variant="ghost" size="sm" onClick={() => navigate("/dashboard")}><ArrowLeft className="h-4 w-4 mr-1.5" /> Back</Button>
          </div>
        </header>
        <div className="flex-1 flex items-center justify-center px-6">
          <Card className="w-full max-w-md">
            <CardContent className="p-8 space-y-4 text-center">
              <Lock className="h-10 w-10 mx-auto" style={{ color: "#dc2626" }} />
              <h1 className="text-2xl font-semibold" style={{ color: "#1a2547" }}>Quarantine — Restricted Access</h1>
              <p className="text-sm text-muted-foreground">Enter the Quarantine password to continue. Access is logged and audited.</p>
              <Input
                type="password" value={pwd} autoFocus
                onChange={(e) => setPwd(e.target.value)}
                onKeyDown={(e) => { if (e.key === "Enter") unlock(); }}
                placeholder="Quarantine password"
              />
              <Button onClick={unlock} disabled={busy || !pwd} className="w-full" style={{ background: "#dc2626", color: "white" }}>
                {busy ? <Loader2 className="h-4 w-4 animate-spin" /> : "Unlock"}
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  // ---- Unlocked content ----
  return (
    <div className="min-h-screen bg-background">
      <header className="border-b bg-card">
        <div className="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between">
          <Button variant="ghost" size="sm" onClick={() => navigate("/dashboard")}><ArrowLeft className="h-4 w-4 mr-1.5" /> Back</Button>
          <Badge variant="destructive" className="gap-1"><Lock className="h-3 w-3" /> Quarantine session active</Badge>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-6 py-10">
        <div className="mb-6">
          <h1 className="text-4xl font-semibold tracking-tight flex items-center gap-3" style={{ fontFamily: "'Cormorant Garamond', serif", color: "#1a2547" }}>
            <ShieldAlert className="h-8 w-8" style={{ color: "#dc2626" }} /> QUARANTINE — Restricted Access
          </h1>
        </div>

        <div className="mb-6 p-4 rounded-md border-l-4" style={{ borderColor: "#dc2626", background: "#fef2f2" }}>
          <p className="text-sm" style={{ color: "#7f1d1d" }}>
            <strong>This section contains terminated employee data. Handle with care.</strong>
            <br />Terminated employees cannot be rehired from this section. To re-engage someone, they must submit a new application through the normal hiring form.
          </p>
        </div>

        <Tabs defaultValue="terminated" className="w-full">
          <TabsList className="mb-4">
            <TabsTrigger value="terminated">Terminated Employees</TabsTrigger>
            <TabsTrigger value="deleted-appointments">Deleted Appointments {deletedAppointments.length > 0 ? `(${deletedAppointments.length})` : ""}</TabsTrigger>
          </TabsList>

          <TabsContent value="terminated">
            <Card>
              <CardContent className="p-0">
                {offers.length === 0 ? (
                  <div className="p-10 text-center text-muted-foreground">No terminated employees.</div>
                ) : (
                  <div className="overflow-x-auto">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Name</TableHead>
                          <TableHead>Position</TableHead>
                          <TableHead>Type</TableHead>
                          <TableHead>Terminated</TableHead>
                          <TableHead>Days Active</TableHead>
                          <TableHead>Terminated By</TableHead>
                          <TableHead>Reason</TableHead>
                          <TableHead className="text-right">Actions</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {offers.map((o) => (
                          <TableRow key={o.id} data-response-id={o.id} className={highlightId === o.id ? "locate-flash" : undefined} title="Terminated employees cannot be reactivated. They must apply again as new candidates.">
                            <TableCell>
                              <div className="font-medium">{o.candidate_name}</div>
                              <div className="text-xs text-muted-foreground">{o.candidate_email}</div>
                            </TableCell>
                            <TableCell>{o.position_title}</TableCell>
                            <TableCell>
                              {o.employment_status === "terminated_evaluation"
                                ? <Badge style={{ background: "#d97706", color: "white" }}>Failed Evaluation</Badge>
                                : <Badge style={{ background: "#dc2626", color: "white" }}>Regular</Badge>}
                            </TableCell>
                            <TableCell>{fmtDateTime(o.terminated_at)}</TableCell>
                            <TableCell>{daysBetween(o.start_date, o.terminated_at)}</TableCell>
                            <TableCell>{hrName(o.terminated_by_hr_id)}</TableCell>
                            <TableCell className="max-w-[200px] truncate text-xs text-muted-foreground">{o.internal_notes || "—"}</TableCell>
                            <TableCell className="text-right">
                              <div className="flex justify-end gap-2 flex-wrap items-start">
                                <Button size="sm" variant="outline" className="min-h-[44px] sm:min-h-0" onClick={() => setViewOffer(o)}>
                                  <Eye className="h-3.5 w-3.5 mr-1" /> View
                                </Button>

                                {/* Offboarding group */}
                                <div className="flex flex-col items-end gap-1.5">
                                  <span className="text-[10px] uppercase tracking-wider text-muted-foreground font-medium">Offboarding</span>
                                  <div className="flex gap-2 flex-wrap justify-end">
                                    {/* Re-Sign NDA */}
                                    <Button
                                      size="sm"
                                      variant="outline"
                                      className="min-h-[44px] sm:min-h-0 border-[#1a2547] text-[#1a2547] hover:bg-[#1a2547] hover:text-white"
                                      onClick={() => { setNdaOffer(o); setNdaEmail(o.candidate_email || ""); }}
                                    >
                                      <FileSignature className="h-3.5 w-3.5 mr-1" /> Re-Sign NDA
                                    </Button>

                                    {/* Send Settlement Form */}
                                    <Button
                                      size="sm"
                                      variant="outline"
                                      className="min-h-[44px] sm:min-h-0 border-[#b08c57] text-[#8a6b3a] hover:bg-[#b08c57] hover:text-white"
                                      onClick={() => { setSettleOffer(o); setSettleEmail(o.candidate_email || ""); }}
                                    >
                                      <FileSignature className="h-3.5 w-3.5 mr-1" /> Send Settlement Form
                                    </Button>

                                    {/* Termination Notice */}
                                    {(() => {
                                      const termEmails = emailLogs.filter(e => e.job_offer_id === o.id && (e.stage === "stage_termination_evaluation" || e.stage === "stage_termination_regular"));
                                      const hasSent = termEmails.some(e => e.status === "sent");
                                      const label = hasSent ? "Re-send Termination Notice" : "Send Termination Notice";
                                      return (
                                        <Button
                                          size="sm"
                                          variant="outline"
                                          className="min-h-[44px] sm:min-h-0 border-[#1a2547] text-[#1a2547] hover:bg-[#1a2547] hover:text-white"
                                          onClick={() => {
                                            setResendOffer(o);
                                            setResendEmail(o.candidate_email || "");
                                            setResendPwd("");
                                          }}
                                        >
                                          <Mail className="h-3.5 w-3.5 mr-1" /> {label}
                                        </Button>
                                      );
                                    })()}
                                  </div>

                                  {/* Status hints */}
                                  {(() => {
                                    const resp = responses.find(r => r.applicant_id === o.candidate_id);
                                    const ndaSigned = ndaSigs.find(s =>
                                      (resp && s.response_id === resp.id) ||
                                      (s.signer_email && s.signer_email.toLowerCase() === (o.candidate_email || "").toLowerCase())
                                    )?.status === "signed";
                                    const sigs = settlementSigs.filter(s =>
                                      (resp && s.response_id === resp.id) ||
                                      (s.signer_email && s.signer_email.toLowerCase() === (o.candidate_email || "").toLowerCase())
                                    );
                                    const settlementSigned = sigs.find(s => s.status === "signed");
                                    const settlementSent = sigs.find(s => s.status === "sent");
                                    const termEmails = emailLogs.filter(e => e.job_offer_id === o.id && (e.stage === "stage_termination_evaluation" || e.stage === "stage_termination_regular"));
                                    const termSent = termEmails.some(e => e.status === "sent");
                                    return (
                                      <div className="flex gap-1.5 flex-wrap justify-end">
                                        {ndaSigned && <Badge style={{ background: "#16a34a", color: "white" }}>NDA signed ✓</Badge>}
                                        {settlementSigned && <Badge style={{ background: "#16a34a", color: "white" }}>Settlement signed ✓</Badge>}
                                        {settlementSent && !settlementSigned && <Badge style={{ background: "#d97706", color: "white" }}>Settlement sent</Badge>}
                                        {termSent && <Badge style={{ background: "#16a34a", color: "white" }}>Notice sent ✓</Badge>}
                                      </div>
                                    );
                                  })()}
                                </div>

                                <Button size="sm" className="min-h-[44px] sm:min-h-0" onClick={() => { setDeleteOffer(o); setDeletePwd(""); }} style={{ background: "#dc2626", color: "white" }}>
                                  <Trash2 className="h-3.5 w-3.5 mr-1" /> Remove from Quarantine
                                </Button>
                              </div>
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="deleted-appointments">
            <div className="mb-4 p-4 rounded-md border-l-4" style={{ borderColor: "#b08c57", background: "#faf6ee" }}>
              <p className="text-sm" style={{ color: "#8a6b3a" }}>
                <strong>Booking graveyard.</strong> These appointments were permanently deleted from My Bookings. This is a read-only archive — the candidate's application record still exists and remains the source of truth on the Results page.
              </p>
            </div>
            <Card>
              <CardContent className="p-0">
                {deletedAppointments.length === 0 ? (
                  <div className="p-10 text-center text-muted-foreground">No deleted appointments.</div>
                ) : (
                  <div className="overflow-x-auto">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Name</TableHead>
                          <TableHead>Email</TableHead>
                          <TableHead>Position</TableHead>
                          <TableHead>Date Moved</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {deletedAppointments.map((d) => (
                          <TableRow key={d.id} data-response-id={d.id} className={highlightId === d.id ? "locate-flash" : undefined}>
                            <TableCell className="font-medium">{d.name || "—"}</TableCell>
                            <TableCell className="text-xs text-muted-foreground">{d.email || "—"}</TableCell>
                            <TableCell>{d.position || "—"}</TableCell>
                            <TableCell>{fmtDateTime(d.moved_at)}</TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </main>

      {/* View modal */}
      <Dialog open={!!viewOffer} onOpenChange={(o) => { if (!o) setViewOffer(null); }}>
        <DialogContent className="max-w-2xl max-h-[85vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Full record — {viewOffer?.candidate_name}</DialogTitle>
            <DialogDescription>Read-only. {viewOffer?.position_title}</DialogDescription>
          </DialogHeader>
          {viewOffer && (() => {
            const resp = responses.find(r => r.applicant_id === viewOffer.candidate_id);
            const respAnswers = resp ? answers.filter(a => a.response_id === resp.id) : [];
            const qById = new Map(questions.map(q => [q.id, q]));
            const sortedAnswers = [...respAnswers].sort((a, b) => (qById.get(a.question_id)?.order_index ?? 0) - (qById.get(b.question_id)?.order_index ?? 0));
            const offerEmails = emailLogs.filter(e => e.job_offer_id === viewOffer.id);
            return (
              <div className="space-y-5 text-sm">
                <Section title="Termination">
                  <div>Type: <strong>{viewOffer.employment_status}</strong></div>
                  <div>Date: {fmtDateTime(viewOffer.terminated_at)}</div>
                  <div>Terminated by: {hrName(viewOffer.terminated_by_hr_id)}</div>
                  <div>Notes: {viewOffer.internal_notes || "—"}</div>
                </Section>
                <Section title="Offer letter">
                  <div>Signed at: {fmtDateTime(viewOffer.signed_at)}</div>
                  {viewOffer.signed_pdf_url
                    ? <a href={viewOffer.signed_pdf_url} target="_blank" rel="noreferrer" className="text-primary underline">Open signed PDF</a>
                    : <div className="text-muted-foreground">No signed PDF on file.</div>}
                </Section>
                <Section title={`Application data ${resp ? `(submitted ${fmtDate(resp.submitted_at)})` : ""}`}>
                  {sortedAnswers.length === 0
                    ? <div className="text-muted-foreground">No application data found.</div>
                    : sortedAnswers.map(a => (
                      <div key={a.id} className="py-1 border-b last:border-0">
                        <div className="text-xs uppercase text-muted-foreground">{qById.get(a.question_id)?.label || "—"}</div>
                        <div>{a.answer_text || (a.file_url ? <a href={a.file_url} target="_blank" rel="noreferrer" className="text-primary underline">View file</a> : "—")}</div>
                      </div>
                    ))}
                </Section>
                <Section title={`Email history (${offerEmails.length})`}>
                  {offerEmails.length === 0
                    ? <div className="text-muted-foreground">No emails on file.</div>
                    : offerEmails.map(e => (
                      <div key={e.id} className="py-1 border-b last:border-0 text-xs">
                        <div><strong>{e.subject}</strong></div>
                        <div className="text-muted-foreground">{e.stage} · {e.status} · {fmtDateTime(e.sent_at || e.created_at)} · to {e.to_address}</div>
                      </div>
                    ))}
                </Section>
              </div>
            );
          })()}
        </DialogContent>
      </Dialog>

      {/* Delete confirm */}
      <Dialog open={!!deleteOffer} onOpenChange={(o) => { if (!o && !busy) { setDeleteOffer(null); setDeletePwd(""); } }}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="text-destructive">Remove {deleteOffer?.candidate_name} from Quarantine?</DialogTitle>
            <DialogDescription>
              This removes {deleteOffer?.candidate_name} from the Quarantine view only. Their full record stays intact on the Results page and is not destroyed. A true purge can only be done from the Results page.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-2">
            <p className="text-sm">Re-enter the Quarantine password to confirm.</p>
            <Input type="password" value={deletePwd} autoFocus onChange={(e) => setDeletePwd(e.target.value)} placeholder="Quarantine password" />
          </div>
          <DialogFooter>
            <Button variant="ghost" onClick={() => { setDeleteOffer(null); setDeletePwd(""); }} disabled={busy}>Cancel</Button>
            <Button onClick={doDelete} disabled={busy || !deletePwd} style={{ background: "#dc2626", color: "white" }}>
              {busy ? <Loader2 className="h-4 w-4 animate-spin" /> : "Remove from Quarantine"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      {/* Resend termination notice */}
      <Dialog open={!!resendOffer} onOpenChange={(o) => { if (!o && !busy) { setResendOffer(null); setResendEmail(""); setResendPwd(""); } }}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Send Termination Notice — {resendOffer?.candidate_name}</DialogTitle>
            <DialogDescription>
              Sends the {resendOffer?.employment_status === "terminated_evaluation" ? "failed-evaluation" : "regular"} termination email (signed Cathy Anderson, BCC HR + boss). Requires the Boss password.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-3">
            <div>
              <label className="text-xs uppercase text-muted-foreground">Recipient email</label>
              <Input type="email" value={resendEmail} onChange={(e) => setResendEmail(e.target.value)} placeholder="employee@example.com" className="min-h-[44px]" />
            </div>
            <div>
              <label className="text-xs uppercase text-muted-foreground">Boss password</label>
              <Input type="password" value={resendPwd} onChange={(e) => setResendPwd(e.target.value)} placeholder="Boss password" className="min-h-[44px]" />
            </div>
          </div>
          <DialogFooter>
            <Button variant="ghost" onClick={() => { setResendOffer(null); setResendEmail(""); setResendPwd(""); }} disabled={busy}>Cancel</Button>
            <Button onClick={doResendTermination} disabled={busy || !resendPwd || !resendEmail} style={{ background: "#1a2547", color: "white" }} className="min-h-[44px] sm:min-h-0">
              {busy ? <Loader2 className="h-4 w-4 animate-spin" /> : (<><Mail className="h-4 w-4 mr-1.5" /> Send</>)}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Send settlement form */}
      <Dialog open={!!settleOffer} onOpenChange={(o) => { if (!o && !busy) { setSettleOffer(null); setSettleEmail(""); } }}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Send Settlement Form — {settleOffer?.candidate_name}</DialogTitle>
            <DialogDescription>
              Sends the Final Payment &amp; Full Settlement Acknowledgment for e-signature via SignFlow.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-3">
            <div>
              <label className="text-xs uppercase text-muted-foreground">Recipient email</label>
              <Input type="email" value={settleEmail} onChange={(e) => setSettleEmail(e.target.value)} placeholder="employee@example.com" className="min-h-[44px]" />
            </div>
          </div>
          <DialogFooter>
            <Button variant="ghost" onClick={() => { setSettleOffer(null); setSettleEmail(""); }} disabled={busy}>Cancel</Button>
            <Button onClick={doSendSettlement} disabled={busy || !settleEmail} style={{ background: "#b08c57", color: "white" }} className="min-h-[44px] sm:min-h-0">
              {busy ? <Loader2 className="h-4 w-4 animate-spin" /> : (<><FileSignature className="h-4 w-4 mr-1.5" /> Send</>)}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Re-Sign NDA */}
      <Dialog open={!!ndaOffer} onOpenChange={(o) => { if (!o && !busy) { setNdaOffer(null); setNdaEmail(""); } }}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Re-Sign NDA — {ndaOffer?.candidate_name}</DialogTitle>
            <DialogDescription>
              Sends a fresh NDA for e-signature via SignFlow. No password required.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-3">
            <div>
              <label className="text-xs uppercase text-muted-foreground">Recipient email</label>
              <Input type="email" value={ndaEmail} onChange={(e) => setNdaEmail(e.target.value)} placeholder="employee@example.com" className="min-h-[44px]" />
            </div>
          </div>
          <DialogFooter>
            <Button variant="ghost" onClick={() => { setNdaOffer(null); setNdaEmail(""); }} disabled={busy}>Cancel</Button>
            <Button onClick={doSendNda} disabled={busy || !ndaEmail} style={{ background: "#1a2547", color: "white" }} className="min-h-[44px] sm:min-h-0">
              {busy ? <Loader2 className="h-4 w-4 animate-spin" /> : (<><FileSignature className="h-4 w-4 mr-1.5" /> Send</>)}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}

function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div>
      <h3 className="text-xs uppercase tracking-wide text-muted-foreground mb-2">{title}</h3>
      <div className="space-y-1">{children}</div>
    </div>
  );
}
