import { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Loader2, CheckCircle2 } from "lucide-react";
import { toast } from "sonner";
import EiaWordmark from "@/components/EiaWordmark";

const NAVY = "#1a2547";
const GOLD = "#b08d57";
const CREAM = "#faf8f3";

type Validate = {
  valid: boolean;
  reason?: string;
  external_reference?: string;
  signer_name?: string;
  signer_email?: string;
  response_id?: string;
};

const SectionLabel = ({ children }: { children: React.ReactNode }) => (
  <div style={{ fontFamily: "'Inter', sans-serif", fontWeight: 600, fontSize: 11, color: GOLD, textTransform: "uppercase", letterSpacing: 3 }}>
    {children}
  </div>
);

const PageShell = ({ subtitle, children }: { subtitle: string; children: React.ReactNode }) => (
  <div className="min-h-screen" style={{ backgroundColor: CREAM }}>
    <div className="max-w-2xl mx-auto px-6 py-10 md:py-14">
      <div className="mb-8 flex justify-center">
        <EiaWordmark subtitle={subtitle} align="center" />
      </div>
      {children}
      <div className="mt-10 text-center text-xs text-muted-foreground">
        &copy; {new Date().getFullYear()} Expert Intuitive Advisor Inc.
      </div>
    </div>
  </div>
);

const FieldLabel = ({ children, required }: { children: React.ReactNode; required?: boolean }) => (
  <Label className="text-sm font-medium block mb-1.5" style={{ color: NAVY }}>
    {children} {required && <span style={{ color: "#dc2626" }}>*</span>}
  </Label>
);

// Live typed-signature preview rendered in Allura script (matches the offer-letter PDF signature).
function TypedSignaturePreview({ name }: { name: string }) {
  return (
    <div
      className="rounded-md border bg-white flex items-center justify-center px-4"
      style={{ borderColor: `${GOLD}66`, minHeight: 90 }}
    >
      {name.trim() ? (
        <span
          style={{
            fontFamily: "'Allura', cursive",
            fontSize: 44,
            lineHeight: 1,
            color: NAVY,
            whiteSpace: "nowrap",
            overflow: "hidden",
            textOverflow: "ellipsis",
            maxWidth: "100%",
          }}
        >
          {name}
        </span>
      ) : (
        <span className="text-xs text-muted-foreground">
          Your typed name will appear here as your signature
        </span>
      )}
    </div>
  );
}

const manilaToday = () =>
  new Intl.DateTimeFormat("en-CA", { timeZone: "Asia/Manila", year: "numeric", month: "2-digit", day: "2-digit" })
    .format(new Date());

export default function CashAdvanceRequest() {
  const { token } = useParams<{ token: string }>();
  const [loading, setLoading] = useState(true);
  const [info, setInfo] = useState<Validate | null>(null);
  const [submitting, setSubmitting] = useState(false);
  const [done, setDone] = useState(false);

  // Fields
  const [caAmount, setCaAmount] = useState("");
  const [caReason, setCaReason] = useState("");
  const [caRepaymentMethod, setCaRepaymentMethod] = useState("");
  const [typedName, setTypedName] = useState("");
  const [showErrors, setShowErrors] = useState(false);

  const signatureDate = manilaToday();

  useEffect(() => {
    if (!token) return;
    (async () => {
      const { data } = await supabase.functions.invoke<Validate>("validate-leave-token", { body: { token } });
      const v = data || { valid: false };
      setInfo(v);
      if (v.valid && v.signer_name) setTypedName(v.signer_name);
      setLoading(false);
    })();
  }, [token]);

  const missing = {
    caAmount: !caAmount.trim(),
    caReason: !caReason.trim(),
    caRepaymentMethod: !caRepaymentMethod.trim(),
    typedName: !typedName.trim(),
  };
  const hasErrors = Object.values(missing).some(Boolean);

  const submit = async () => {
    if (!token) return;
    if (hasErrors) {
      setShowErrors(true);
      toast.error("Please complete all required fields.");
      return;
    }
    setSubmitting(true);
    try {
      const { data, error } = await supabase.functions.invoke<{ ok: boolean; reason?: string }>("submit-cash-advance", {
        body: {
          token,
          ca_amount: caAmount,
          ca_reason: caReason,
          ca_repayment_method: caRepaymentMethod,
          typed_name: typedName,
          signature_data: null,
          signature_date: signatureDate,
        },
      });
      if (error || !data?.ok) {
        toast.error(data?.reason ? `Could not submit (${data.reason}).` : "Could not submit. Please try again.");
        return;
      }
      setDone(true);
    } finally {
      setSubmitting(false);
    }
  };

  if (loading) {
    return (
      <PageShell subtitle="CASH ADVANCE REQUEST">
        <div className="flex items-center justify-center py-20">
          <Loader2 className="h-6 w-6 animate-spin" style={{ color: NAVY }} />
        </div>
      </PageShell>
    );
  }

  if (!info?.valid) {
    const msg =
      info?.reason === "expired"
        ? "This cash advance request link has expired. Please contact HR for a new one."
        : info?.reason === "used"
        ? "This cash advance request has already been submitted."
        : "This link is not valid.";
    return (
      <PageShell subtitle="CASH ADVANCE REQUEST">
        <Card className="border-0 shadow-sm">
          <CardContent className="pt-8 pb-8 text-center space-y-3">
            <SectionLabel>Link Unavailable</SectionLabel>
            <h2 style={{ fontFamily: "'Cormorant Garamond', serif", fontWeight: 600, fontSize: 26, color: NAVY }}>
              {msg}
            </h2>
          </CardContent>
        </Card>
      </PageShell>
    );
  }

  if (done) {
    return (
      <PageShell subtitle="CASH ADVANCE REQUEST">
        <Card className="border-0 shadow-sm">
          <CardContent className="pt-8 pb-8 text-center space-y-4">
            <CheckCircle2 className="h-12 w-12 mx-auto" style={{ color: "#16a34a" }} />
            <SectionLabel>Request Submitted</SectionLabel>
            <h2 style={{ fontFamily: "'Cormorant Garamond', serif", fontWeight: 600, fontSize: 28, color: NAVY, lineHeight: 1.1 }}>
              Thank you, {(typedName || "").split(" ")[0] || "your request is in"}
            </h2>
            <p className="text-sm md:text-base max-w-md mx-auto" style={{ color: NAVY }}>
              Your cash advance request has been submitted and is now awaiting approval.
            </p>
            <p className="text-sm text-muted-foreground max-w-md mx-auto">
              You'll receive an email once a decision is made.
            </p>
          </CardContent>
        </Card>
      </PageShell>
    );
  }

  const ErrHint = ({ show }: { show: boolean }) =>
    show && showErrors ? <p className="text-xs mt-1" style={{ color: "#dc2626" }}>Required</p> : null;

  return (
    <PageShell subtitle="CASH ADVANCE REQUEST">
      <div className="text-center mb-6 space-y-2">
        <SectionLabel>Cash Advance Request</SectionLabel>
        <h1 style={{ fontFamily: "'Cormorant Garamond', serif", fontWeight: 600, fontSize: 32, color: NAVY, lineHeight: 1.1 }}>
          Request a Cash Advance
        </h1>
        <p className="text-sm text-muted-foreground max-w-xl mx-auto">
          We're glad to help. Please share the details below so HR can review your cash advance request.
        </p>
      </div>

      <Card className="border-0 shadow-sm">
        <CardContent className="p-6 md:p-8 space-y-6">

          <div>
            <FieldLabel required>Amount Requested</FieldLabel>
            <Input
              value={caAmount}
              onChange={(e) => setCaAmount(e.target.value)}
              className="h-11"
              placeholder="e.g. 5,000 PHP"
            />
            <ErrHint show={missing.caAmount} />
          </div>

          <div>
            <FieldLabel required>Reason for Request</FieldLabel>
            <Textarea
              value={caReason}
              onChange={(e) => setCaReason(e.target.value)}
              rows={3}
              placeholder="Briefly describe why you need this cash advance"
            />
            <ErrHint show={missing.caReason} />
          </div>

          <div>
            <FieldLabel required>Repayment / Deduction Method</FieldLabel>
            <Textarea
              value={caRepaymentMethod}
              onChange={(e) => setCaRepaymentMethod(e.target.value)}
              rows={3}
              placeholder="How would you like this deducted from your pay or repaid?"
            />
            <ErrHint show={missing.caRepaymentMethod} />
          </div>

          <div className="border-t pt-5 space-y-4">
            <SectionLabel>Signature</SectionLabel>

            <div>
              <FieldLabel required>Type your full name</FieldLabel>
              <Input value={typedName} onChange={(e) => setTypedName(e.target.value)} className="h-11" />
              <ErrHint show={missing.typedName} />
            </div>

            <div>
              <FieldLabel>Signature preview</FieldLabel>
              <TypedSignaturePreview name={typedName} />
              <p className="text-xs text-muted-foreground mt-1.5">
                Your typed name is your signature. It will appear on the signed PDF exactly as shown above.
              </p>
            </div>

            <div>
              <FieldLabel>Date</FieldLabel>
              <Input value={signatureDate} readOnly className="h-11 bg-muted/60 text-muted-foreground" />
            </div>
          </div>

          <div className="border-t pt-5 flex flex-col items-center gap-2">
            <Button
              onClick={submit}
              disabled={submitting}
              style={{ backgroundColor: NAVY, color: "#fff" }}
              className="min-w-[240px] h-11"
            >
              {submitting ? <><Loader2 className="h-4 w-4 animate-spin mr-2" /> Submitting…</> : "Submit Cash Advance Request"}
            </Button>
          </div>

        </CardContent>
      </Card>
    </PageShell>
  );
}
