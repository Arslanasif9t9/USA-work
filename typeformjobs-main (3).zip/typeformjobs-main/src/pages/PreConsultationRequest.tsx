import { useEffect, useMemo, useState } from "react";
import { useParams } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { Loader2, CheckCircle2 } from "lucide-react";
import { toast } from "sonner";

// Standalone "Psychic John" branding — purple accent only. NO EIA logo, navy/gold,
// address, phone, domain, or email footer. One clean page.
const PURPLE = "#7c3aed";
const PURPLE_DARK = "#5b21b6";
const INK = "#2a1a3a";
const BG = "#faf7ff";

type LoadResult = {
  ok: boolean;
  valid?: boolean;
  reason?: string;
  signer_name?: string;
  pc_amount?: string | null;
  pc_duration?: string | null;
  pc_hr_message?: string | null;
};

const manilaToday = () =>
  new Intl.DateTimeFormat("en-CA", { timeZone: "Asia/Manila", year: "numeric", month: "2-digit", day: "2-digit" })
    .format(new Date());

function amountDisplay(raw: string | null | undefined): string {
  const v = (raw || "").trim();
  if (!v) return "$___";
  return v.startsWith("$") ? v : `$${v}`;
}

function buildClauses(amount: string | null | undefined, duration: string | null | undefined): string[] {
  const dur = (duration || "").trim() || "the agreed time";
  const amt = amountDisplay(amount);
  return [
    "I understand this reading/consultation is for guidance and entertainment purposes only.",
    `I understand my session is ${dur} and cannot go beyond that time.`,
    "It is my responsibility to ask all my questions during the session, in a timely manner — not at the last minute. If I forget to ask something, that is on me, and I will need to book and pay for a new session for new questions.",
    `I will not use confusion as a tactic (for example "I didn't understand," "I'm confused," "please repeat") to get free follow-ups after the session has ended.`,
    `I understand the ${amt} I paid covers this ${dur} session only. Psychic John's rate is $599 per hour, so this is not a full hour of time.`,
    "I understand predictions are not guaranteed. My own actions, choices, and karma shape my life. Psychic John only guides and reads my chart, and is not responsible for outcomes.",
    "I understand Psychic John is not a financial advisor and does not guarantee any financial result, that any specific person will contact me, or any specific outcome.",
    "I understand that if someone does not contact me, that is their own free will — not Psychic John's fault, and not something he can guarantee.",
    "I agree that no outcome or result can be blamed on Psychic John later.",
  ];
}

const ARBITRATION_CLAUSE =
  "I agree that any dispute will be resolved through binding arbitration, and I waive any right to file a lawsuit or court case regarding this reading or consultation.";

// Live typed-signature preview in Allura script (same component pattern as cash advance).
function TypedSignaturePreview({ name }: { name: string }) {
  return (
    <div
      className="rounded-md border bg-white flex items-center justify-center px-4"
      style={{ borderColor: `${PURPLE}55`, minHeight: 90 }}
    >
      {name.trim() ? (
        <span
          style={{
            fontFamily: "'Allura', cursive",
            fontSize: 44,
            lineHeight: 1,
            color: PURPLE_DARK,
            whiteSpace: "nowrap",
            overflow: "hidden",
            textOverflow: "ellipsis",
            maxWidth: "100%",
          }}
        >
          {name}
        </span>
      ) : (
        <span className="text-xs text-muted-foreground">
          Your typed name will appear here as your signature
        </span>
      )}
    </div>
  );
}

const PageShell = ({ children }: { children: React.ReactNode }) => (
  <div className="min-h-screen" style={{ backgroundColor: BG }}>
    <div className="max-w-2xl mx-auto px-6 py-10 md:py-14">
      <div className="mb-8">
        <div
          style={{
            fontFamily: "'Cormorant Garamond', serif",
            fontWeight: 700,
            fontSize: 28,
            color: PURPLE,
            letterSpacing: 0.5,
          }}
        >
          Psychic John
        </div>
      </div>
      {children}
    </div>
  </div>
);

export default function PreConsultationRequest() {
  const { token } = useParams<{ token: string }>();
  const [loading, setLoading] = useState(true);
  const [info, setInfo] = useState<LoadResult | null>(null);
  const [submitting, setSubmitting] = useState(false);
  const [done, setDone] = useState(false);

  const clauses = useMemo(() => buildClauses(info?.pc_amount, info?.pc_duration), [info?.pc_amount, info?.pc_duration]);
  const [agreed, setAgreed] = useState(false);
  const [preferredTime, setPreferredTime] = useState("");
  const [typedName, setTypedName] = useState("");
  const [showErrors, setShowErrors] = useState(false);

  const signatureDate = manilaToday();

  useEffect(() => {
    if (!token) return;
    (async () => {
      const { data } = await supabase.functions.invoke<LoadResult>("submit-pre-consultation", {
        body: { action: "load", token },
      });
      const v = data || { ok: false };
      setInfo(v);
      if (v?.signer_name) setTypedName(v.signer_name);
      setLoading(false);
    })();
  }, [token]);

  const nameMissing = !typedName.trim();
  const canSubmit = agreed && !nameMissing;

  const submit = async () => {
    if (!token) return;
    if (!canSubmit) {
      setShowErrors(true);
      toast.error("Please agree to all clauses and type your name.");
      return;
    }
    setSubmitting(true);
    try {
      const { data, error } = await supabase.functions.invoke<{ ok: boolean; reason?: string }>(
        "submit-pre-consultation",
        {
          body: {
            token,
            pc_preferred_time: preferredTime,
            pc_body_note: null,
            typed_name: typedName,
            signature_data: null,
            signature_date: signatureDate,
          },
        },
      );
      if (error || !data?.ok) {
        toast.error(data?.reason ? `Could not submit (${data.reason}).` : "Could not submit. Please try again.");
        return;
      }
      setDone(true);
    } finally {
      setSubmitting(false);
    }
  };

  if (loading) {
    return (
      <PageShell>
        <div className="flex items-center justify-center py-20">
          <Loader2 className="h-6 w-6 animate-spin" style={{ color: PURPLE }} />
        </div>
      </PageShell>
    );
  }

  if (!info?.valid) {
    const msg =
      info?.reason === "expired"
        ? "This pre-consultation link has expired. Please contact Psychic John for a new one."
        : info?.reason === "used"
        ? "This pre-consultation form has already been submitted."
        : "This link is not valid.";
    return (
      <PageShell>
        <Card className="border-0 shadow-sm">
          <CardContent className="pt-8 pb-8 text-center space-y-3">
            <h2 style={{ fontFamily: "'Cormorant Garamond', serif", fontWeight: 600, fontSize: 26, color: PURPLE_DARK }}>
              {msg}
            </h2>
          </CardContent>
        </Card>
      </PageShell>
    );
  }

  if (done) {
    return (
      <PageShell>
        <Card className="border-0 shadow-sm">
          <CardContent className="pt-8 pb-8 text-center space-y-4">
            <CheckCircle2 className="h-12 w-12 mx-auto" style={{ color: "#16a34a" }} />
            <h2 style={{ fontFamily: "'Cormorant Garamond', serif", fontWeight: 600, fontSize: 28, color: PURPLE_DARK, lineHeight: 1.1 }}>
              Thank you, {(typedName || "").split(" ")[0] || "you're all set"}
            </h2>
            <p className="text-sm md:text-base max-w-md mx-auto" style={{ color: INK }}>
              Your pre-consultation agreement has been received. Psychic John looks forward to your reading.
            </p>
          </CardContent>
        </Card>
      </PageShell>
    );
  }

  return (
    <PageShell>
      <div className="mb-6 space-y-2">
        <h1 style={{ fontFamily: "'Cormorant Garamond', serif", fontWeight: 600, fontSize: 30, color: PURPLE_DARK, lineHeight: 1.15 }}>
          Pre-Consultation Acknowledgment &amp; Service Agreement
        </h1>
        <p className="text-sm" style={{ color: INK }}>
          Please read and agree before your reading with Psychic John.
        </p>
      </div>

      {info.pc_hr_message && (
        <div
          className="mb-5 rounded-md border p-3 text-sm whitespace-pre-wrap"
          style={{ borderColor: `${PURPLE}33`, background: "#f3edff", color: INK }}
        >
          {info.pc_hr_message}
        </div>
      )}

      <Card className="border-0 shadow-sm">
        <CardContent className="p-6 md:p-8 space-y-5">
          {/* 10 clauses as a clean read-only numbered list */}
          <div className="space-y-4">
            <ol className="list-decimal list-inside space-y-3">
              {clauses.map((c, i) => (
                <li key={i} className="text-sm leading-relaxed" style={{ color: INK }}>
                  {c}
                </li>
              ))}
              <li key="arb" className="text-sm leading-relaxed" style={{ color: INK }}>
                {ARBITRATION_CLAUSE}
              </li>
            </ol>
          </div>

          {/* Single "I agree" checkbox */}
          <div className="border-t pt-5">
            <label className="flex items-start gap-3 cursor-pointer">
              <Checkbox
                checked={agreed}
                onCheckedChange={(v) => setAgreed(v === true)}
                className="mt-0.5"
                style={{ borderColor: PURPLE }}
              />
              <span className="text-sm leading-relaxed font-medium" style={{ color: PURPLE_DARK }}>
                I have read and I agree to all of the above.
                {showErrors && !agreed && (
                  <span className="block text-xs mt-0.5" style={{ color: "#dc2626" }}>Please tick to agree</span>
                )}
              </span>
            </label>
          </div>

          {/* Preferred time */}
          <div className="border-t pt-5">
            <Label className="text-sm font-medium block mb-1.5" style={{ color: PURPLE_DARK }}>
              What time would you prefer for your session?
            </Label>
            <Input
              value={preferredTime}
              onChange={(e) => setPreferredTime(e.target.value)}
              className="h-11"
              placeholder="e.g. 3:00 PM, weekday evenings"
            />
            <p className="text-xs text-muted-foreground mt-1.5">
              This time is only a suggestion, not a guarantee that Psychic John will call you at this time.
            </p>
          </div>

          {/* Signature */}
          <div className="border-t pt-5 space-y-4">
            <div>
              <Label className="text-sm font-medium block mb-1.5" style={{ color: PURPLE_DARK }}>
                Type your full name <span style={{ color: "#dc2626" }}>*</span>
              </Label>
              <Input value={typedName} onChange={(e) => setTypedName(e.target.value)} className="h-11" />
              {showErrors && nameMissing && <p className="text-xs mt-1" style={{ color: "#dc2626" }}>Required</p>}
            </div>

            <div>
              <Label className="text-sm font-medium block mb-1.5" style={{ color: PURPLE_DARK }}>Signature preview</Label>
              <TypedSignaturePreview name={typedName} />
              <p className="text-xs text-muted-foreground mt-1.5">
                Your typed name is your signature. It will appear on the signed PDF exactly as shown above.
              </p>
            </div>

            <div>
              <Label className="text-sm font-medium block mb-1.5" style={{ color: PURPLE_DARK }}>Date</Label>
              <Input value={signatureDate} readOnly className="h-11 bg-muted/60 text-muted-foreground" />
            </div>
          </div>

          <div className="border-t pt-5 flex flex-col items-center gap-2">
            <Button
              onClick={submit}
              disabled={submitting || !canSubmit}
              style={{ backgroundColor: canSubmit ? PURPLE : "#c4b5fd", color: "#fff" }}
              className="min-w-[240px] h-11"
            >
              {submitting ? <><Loader2 className="h-4 w-4 animate-spin mr-2" /> Submitting…</> : "I Agree to All"}
            </Button>
            {!agreed && (
              <p className="text-xs text-muted-foreground">Tick the agreement box above to enable.</p>
            )}
          </div>
        </CardContent>
      </Card>
    </PageShell>
  );
}
