// LaunchDashboard — HR/master-admin gated page that schedules or fires
// Sylvia WhatsApp launches via the launch-sylvia edge function.
//
// Three sections:
//   A) HIRED EMPLOYEES — auto-list of active/matched employees from job_offers
//      cross-referenced to responses.final_outcome='matched'. Each row gets a
//      "Launch Sylvia" button with Now / Schedule modes.
//   B) UNIVERSAL LAUNCH — manual form for off-list / VIP cases.
//   C) LAUNCH LOG — chronological log of launches rows with cancel for pending.
//
// All writes are single-row by id. Phone source is hr_candidate_extras.phone
// (existing column). The launches row snapshots whatsapp_number at create.
import { useEffect, useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { useHrIdentity } from "@/hooks/useHrIdentity";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import {
  Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle,
} from "@/components/ui/dialog";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { ArrowLeft, Rocket, Loader2, RefreshCw, XCircle, Trash2 } from "lucide-react";
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { toast } from "sonner";
import { InlineLoader, LoadError } from "@/components/FullPageLoader";

const AGENT_ID = "agent_4501ksmjapkvf4gbqgwcfnjhjrgt";

type Hire = {
  candidate_id: string;
  response_id: string | null;
  candidate_name: string | null;
  position_title: string | null;
  assigned_group_id: string | null;
  contact_timezone: string | null;
  preferred_contact_time: string | null;
  sylvia_instruction: string | null;
  phone: string | null;
};

type Launch = {
  id: string;
  candidate_name: string | null;
  whatsapp_number: string;
  contact_timezone: string | null;
  scheduled_for: string | null;
  status: "pending" | "sent" | "failed" | "cancelled" | string;
  mode: "now" | "scheduled" | string;
  sylvia_instruction: string | null;
  error_message: string | null;
  sent_at: string | null;
  created_by: string | null;
  created_at: string;
};

const E164_RE = /^\+?\d{8,15}$/;

function normalizeE164(v: string): string | null {
  const t = (v || "").trim();
  if (!E164_RE.test(t.replace(/\s/g, ""))) return null;
  const digits = t.replace(/[^\d]/g, "");
  if (digits.length < 8 || digits.length > 15) return null;
  return `+${digits}`;
}

/** Combine a local date+time string (YYYY-MM-DD and HH:MM) interpreted in a
 *  given IANA timezone into a UTC ISO string. Uses Intl to compute the
 *  timezone's offset at that wall-clock instant. */
function localToUtcIso(dateStr: string, timeStr: string, tz: string): string | null {
  if (!dateStr || !timeStr) return null;
  try {
    const [y, m, d] = dateStr.split("-").map(Number);
    const [hh, mm] = timeStr.split(":").map(Number);
    // Start with a UTC guess of the wall time.
    const guess = Date.UTC(y, (m || 1) - 1, d || 1, hh || 0, mm || 0, 0);
    // Format that UTC instant in the target tz to find offset.
    const fmt = new Intl.DateTimeFormat("en-US", {
      timeZone: tz, year: "numeric", month: "2-digit", day: "2-digit",
      hour: "2-digit", minute: "2-digit", hour12: false,
    });
    const parts = fmt.formatToParts(new Date(guess));
    const get = (t: string) => Number(parts.find((p) => p.type === t)?.value || 0);
    const asTz = Date.UTC(get("year"), get("month") - 1, get("day"), get("hour"), get("minute"), 0);
    const offset = asTz - guess; // tz - utc, in ms
    const utcMs = guess - offset;
    return new Date(utcMs).toISOString();
  } catch {
    return null;
  }
}

function fmtLocal(iso: string | null, tz: string | null) {
  if (!iso) return "—";
  try {
    return new Intl.DateTimeFormat(undefined, {
      timeZone: tz || undefined,
      year: "numeric", month: "short", day: "2-digit",
      hour: "2-digit", minute: "2-digit",
    }).format(new Date(iso));
  } catch {
    return new Date(iso).toLocaleString();
  }
}

const COMMON_TZS = [
  "Asia/Manila", "Asia/Kolkata", "Asia/Singapore", "Asia/Dubai",
  "Europe/London", "Europe/Berlin", "America/New_York", "America/Los_Angeles", "UTC",
];

export default function LaunchDashboard() {
  const { user } = useAuth();
  const hrIdentity = useHrIdentity();
  const navigate = useNavigate();

  const [allowed, setAllowed] = useState<boolean | null>(null);

  const [hires, setHires] = useState<Hire[]>([]);
  const [loadingHires, setLoadingHires] = useState(true);
  const [hiresError, setHiresError] = useState<string | null>(null);

  const [launches, setLaunches] = useState<Launch[]>([]);
  const [loadingLog, setLoadingLog] = useState(true);
  const [logError, setLogError] = useState<string | null>(null);

  // Dialog state for per-hire launch
  const [launchHire, setLaunchHire] = useState<Hire | null>(null);
  const [launchMode, setLaunchMode] = useState<"now" | "scheduled">("now");
  const [launchPhone, setLaunchPhone] = useState(""); // editable, pre-filled WhatsApp number
  const [launchDate, setLaunchDate] = useState("");
  const [launchTime, setLaunchTime] = useState("");
  const [launchTz, setLaunchTz] = useState("Asia/Manila");
  const [launchBusy, setLaunchBusy] = useState(false);

  // Universal form
  const [uName, setUName] = useState("");
  const [uPhone, setUPhone] = useState("");
  const [uTz, setUTz] = useState("Asia/Manila");
  const [uMode, setUMode] = useState<"now" | "scheduled">("now");
  const [uDate, setUDate] = useState("");
  const [uTime, setUTime] = useState("");
  const [uInstruction, setUInstruction] = useState("");
  const [uBusy, setUBusy] = useState(false);

  // Delete confirmation state for the launch log
  const [pendingDelete, setPendingDelete] = useState<Launch | null>(null);
  const [confirmClear, setConfirmClear] = useState(false);
  const [deleteBusy, setDeleteBusy] = useState(false);

  useEffect(() => { document.title = "EIA — Launch Sylvia"; }, []);

  // Gate: any signed-in HR user (master_admin or hr). Block everyone else.
  useEffect(() => {
    if (hrIdentity.loading) return;
    setAllowed(hrIdentity.role === "master_admin" || hrIdentity.role === "hr");
  }, [hrIdentity.loading, hrIdentity.role]);

  const loadHires = async () => {
    setLoadingHires(true); setHiresError(null);
    try {
      const { data: offers, error } = await supabase
        .from("job_offers")
        .select("candidate_id, candidate_name, position_title, signed_at, employment_status, status")
        .eq("status", "signed")
        .eq("employment_status", "active")
        .order("signed_at", { ascending: false });
      if (error) throw error;
      const candIds = Array.from(new Set(((offers as any[]) || []).map((o) => o.candidate_id).filter(Boolean)));
      if (candIds.length === 0) { setHires([]); setLoadingHires(false); return; }

      const { data: resps } = await (supabase.from("responses") as any)
        .select("id, applicant_id, final_outcome, assigned_group_id, sylvia_instruction, contact_timezone, preferred_contact_time")
        .in("applicant_id", candIds)
        .eq("final_outcome", "matched");
      const respByCand: Record<string, any> = {};
      for (const r of ((resps as any[]) || [])) respByCand[r.applicant_id] = r;

      const respIds = Object.values(respByCand).map((r: any) => r.id);
      let phoneByResp: Record<string, string | null> = {};
      if (respIds.length) {
        // PRIMARY source: the candidate's own application answer to the
        // phone / WhatsApp question (answers.answer_text). answers has no FK to
        // questions, so resolve question labels in a second read. READ-ONLY.
        const { data: ans } = await (supabase.from("answers") as any)
          .select("response_id, question_id, answer_text")
          .in("response_id", respIds);
        const qids = Array.from(new Set(((ans as any[]) || []).map((a) => a.question_id).filter(Boolean)));
        const labelByQ: Record<string, string> = {};
        if (qids.length) {
          const { data: qs } = await (supabase.from("questions") as any)
            .select("id, label").in("id", qids);
          for (const q of ((qs as any[]) || [])) labelByQ[q.id] = (q.label || "").toLowerCase();
        }
        const byResp: Record<string, any[]> = {};
        for (const a of ((ans as any[]) || [])) (byResp[a.response_id] ||= []).push(a);
        const PHONE_LABEL = /phone|whats|mobile|contact\s*number|cell/;
        for (const id of respIds) {
          const list = byResp[id] || [];
          const labelMatch = list.find(
            (a) => PHONE_LABEL.test(labelByQ[a.question_id] || "") && (a.answer_text || "").trim()
          );
          const valMatch = list.find((a) => {
            const t = (a.answer_text || "").replace(/[^\d]/g, "");
            return t.length >= 10 && t.length <= 15;
          });
          const pick = labelMatch || valMatch;
          if (pick) phoneByResp[id] = (pick.answer_text || "").trim();
        }
        // FALLBACK: hr_candidate_extras.phone for any response still missing.
        const missing = respIds.filter((id) => !phoneByResp[id]);
        if (missing.length) {
          const { data: extras } = await (supabase.from("hr_candidate_extras") as any)
            .select("response_id, phone")
            .in("response_id", missing);
          for (const e of ((extras as any[]) || [])) {
            if (!phoneByResp[e.response_id]) phoneByResp[e.response_id] = e.phone || null;
          }
        }
      }

      const merged: Hire[] = ((offers as any[]) || [])
        .filter((o) => o.candidate_id && respByCand[o.candidate_id])
        .map((o) => {
          const r = respByCand[o.candidate_id];
          return {
            candidate_id: o.candidate_id,
            response_id: r.id,
            candidate_name: o.candidate_name,
            position_title: o.position_title,
            assigned_group_id: r.assigned_group_id || null,
            contact_timezone: r.contact_timezone || null,
            preferred_contact_time: r.preferred_contact_time || null,
            sylvia_instruction: r.sylvia_instruction || null,
            phone: phoneByResp[r.id] ?? null,
          };
        });
      setHires(merged);
    } catch (e: any) {
      setHiresError(e?.message || "Couldn't load hired employees");
    } finally {
      setLoadingHires(false);
    }
  };

  const loadLog = async () => {
    setLoadingLog(true); setLogError(null);
    try {
      const { data, error } = await (supabase.from("launches") as any)
        .select("*")
        .order("created_at", { ascending: false })
        .limit(200);
      if (error) throw error;
      setLaunches((data as Launch[]) || []);
    } catch (e: any) {
      setLogError(e?.message || "Couldn't load launch log");
    } finally {
      setLoadingLog(false);
    }
  };

  useEffect(() => {
    if (allowed) { loadHires(); loadLog(); }
  }, [allowed]);

  const openLaunchDialog = (h: Hire) => {
    setLaunchHire(h);
    setLaunchMode("now");
    setLaunchPhone(normalizeE164(h.phone || "") || (h.phone || "")); // pre-fill, editable
    setLaunchTz(h.contact_timezone || "Asia/Manila");
    // Prefill date = today (in their tz), time = preferred_contact_time if HH:MM
    const today = new Date().toISOString().slice(0, 10);
    setLaunchDate(today);
    const pref = (h.preferred_contact_time || "").match(/^(\d{1,2}):(\d{2})/);
    setLaunchTime(pref ? `${pref[1].padStart(2, "0")}:${pref[2]}` : "10:00");
  };

  const closeLaunchDialog = () => {
    setLaunchHire(null);
  };

  const previewUtc = useMemo(() => {
    if (launchMode !== "scheduled") return null;
    return localToUtcIso(launchDate, launchTime, launchTz);
  }, [launchMode, launchDate, launchTime, launchTz]);

  // When an immediate (mode='now') invoke errors or returns non-ok, mark the
  // launch row failed so it is visible instead of an orphaned 'pending'.
  const markLaunchFailed = async (id: string, msg: string) => {
    await (supabase.from("launches") as any)
      .update({ status: "failed", error_message: (msg || "launch_failed").slice(0, 2000) })
      .eq("id", id);
  };

  const submitHireLaunch = async () => {
    if (!launchHire) return;
    const phone = normalizeE164(launchPhone || "");
    if (!phone) { toast.error("Enter a valid WhatsApp number (E.164, e.g. +639171234567)."); return; }
    if (launchMode === "scheduled" && !previewUtc) { toast.error("Pick a valid date and time."); return; }
    setLaunchBusy(true);
    try {
      const insertRow: any = {
        response_id: launchHire.response_id,
        candidate_name: launchHire.candidate_name,
        whatsapp_number: phone,
        contact_timezone: launchTz,
        sylvia_instruction: launchHire.sylvia_instruction,
        mode: launchMode,
        scheduled_for: launchMode === "scheduled" ? previewUtc : null,
        status: "pending",
        created_by: user?.email || hrIdentity.email || null,
      };
      const { data: row, error } = await (supabase.from("launches") as any)
        .insert(insertRow).select("id").single();
      if (error) { toast.error(error.message); return; }

      if (launchMode === "now") {
        const { data, error: invErr } = await supabase.functions.invoke<any>("launch-sylvia", {
          body: { launch_id: row.id, agent_id: AGENT_ID },
        });
        if (invErr) { await markLaunchFailed(row.id, invErr.message || "invoke_failed"); toast.error(invErr.message || "Launch failed"); }
        else if (!data?.ok) { await markLaunchFailed(row.id, data?.error || "launch_failed"); toast.error(data?.error || "Launch failed"); }
        else { toast.success(`Sylvia launched to ${launchHire.candidate_name}`); }
      } else {
        toast.success(`Scheduled — cron will fire it at ${fmtLocal(previewUtc, launchTz)}`);
      }
      closeLaunchDialog();
      loadLog();
    } finally {
      setLaunchBusy(false);
    }
  };

  const submitUniversalLaunch = async () => {
    const phone = normalizeE164(uPhone);
    if (!uName.trim()) { toast.error("Enter a candidate name"); return; }
    if (!phone) { toast.error("Enter a valid WhatsApp number in E.164 (e.g. +639171234567)"); return; }
    let utc: string | null = null;
    if (uMode === "scheduled") {
      utc = localToUtcIso(uDate, uTime, uTz);
      if (!utc) { toast.error("Pick a valid date and time"); return; }
    }
    setUBusy(true);
    try {
      const insertRow: any = {
        candidate_name: uName.trim(),
        whatsapp_number: phone,
        contact_timezone: uTz,
        sylvia_instruction: uInstruction.trim() || null,
        mode: uMode,
        scheduled_for: utc,
        status: "pending",
        created_by: user?.email || hrIdentity.email || null,
      };
      const { data: row, error } = await (supabase.from("launches") as any)
        .insert(insertRow).select("id").single();
      if (error) { toast.error(error.message); return; }

      if (uMode === "now") {
        const { data, error: invErr } = await supabase.functions.invoke<any>("launch-sylvia", {
          body: { launch_id: row.id, agent_id: AGENT_ID },
        });
        if (invErr) { await markLaunchFailed(row.id, invErr.message || "invoke_failed"); toast.error(invErr.message || "Launch failed"); }
        else if (!data?.ok) { await markLaunchFailed(row.id, data?.error || "launch_failed"); toast.error(data?.error || "Launch failed"); }
        else { toast.success(`Sylvia launched to ${uName.trim()}`); }
      } else {
        toast.success(`Scheduled — cron will fire it at ${fmtLocal(utc, uTz)}`);
      }
      setUName(""); setUPhone(""); setUInstruction("");
      setUDate(""); setUTime("");
      loadLog();
    } finally {
      setUBusy(false);
    }
  };

  const cancelLaunch = async (id: string) => {
    const { error } = await (supabase.from("launches") as any)
      .update({ status: "cancelled" })
      .eq("id", id)
      .eq("status", "pending");
    if (error) { toast.error(error.message); return; }
    toast.success("Launch cancelled");
    loadLog();
  };

  // Single-row delete by id — removes only this launch-attempt record.
  const deleteLaunch = async (id: string) => {
    setDeleteBusy(true);
    try {
      const { error } = await (supabase.from("launches") as any).delete().eq("id", id);
      if (error) { toast.error(error.message); return; }
      toast.success("Launch record deleted");
      setPendingDelete(null);
      loadLog();
    } finally {
      setDeleteBusy(false);
    }
  };

  // Bulk clear — removes sent/failed/cancelled rows only; leaves pending in-flight rows.
  const clearFinishedLaunches = async () => {
    setDeleteBusy(true);
    try {
      const { error } = await (supabase.from("launches") as any)
        .delete()
        .in("status", ["sent", "failed", "cancelled"]);
      if (error) { toast.error(error.message); return; }
      toast.success("Cleared sent/failed/cancelled launches");
      setConfirmClear(false);
      loadLog();
    } finally {
      setDeleteBusy(false);
    }
  };

  if (hrIdentity.loading || allowed === null) {
    return <div className="p-8"><InlineLoader label="Loading…" /></div>;
  }
  if (!allowed) {
    return (
      <div className="max-w-xl mx-auto p-8">
        <h1 className="text-2xl font-semibold mb-2">Launch Sylvia</h1>
        <p className="text-muted-foreground">This page is only available to HR and master admin.</p>
        <Button variant="outline" className="mt-4" onClick={() => navigate("/dashboard")}>
          <ArrowLeft className="h-4 w-4 mr-1.5" /> Back
        </Button>
      </div>
    );
  }

  const statusBadge = (s: string) => {
    const color =
      s === "sent" ? "bg-green-100 text-green-800" :
      s === "failed" ? "bg-red-100 text-red-800" :
      s === "cancelled" ? "bg-gray-200 text-gray-700" :
      "bg-amber-100 text-amber-800";
    return <Badge className={`${color} hover:${color}`}>{s}</Badge>;
  };

  return (
    <div className="max-w-7xl mx-auto p-6 space-y-8">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-semibold flex items-center gap-2">
            <Rocket className="h-6 w-6" /> Launch Sylvia
          </h1>
          <p className="text-sm text-muted-foreground">
            Live WhatsApp send via ElevenLabs. Schedule or fire now. Cron picks up scheduled launches every 5 minutes.
          </p>
        </div>
        <Button variant="outline" onClick={() => navigate("/dashboard")}>
          <ArrowLeft className="h-4 w-4 mr-1.5" /> Back
        </Button>
      </div>

      {/* A) HIRED EMPLOYEES */}
      <section className="border rounded-md">
        <div className="flex items-center justify-between p-4 border-b">
          <h2 className="font-medium">Hired employees</h2>
          <Button variant="ghost" size="sm" onClick={loadHires}>
            <RefreshCw className="h-4 w-4 mr-1.5" /> Refresh
          </Button>
        </div>
        {loadingHires ? (
          <div className="p-6"><InlineLoader label="Loading hired employees…" /></div>
        ) : hiresError ? (
          <div className="p-6"><LoadError message={hiresError} onRetry={loadHires} /></div>
        ) : hires.length === 0 ? (
          <div className="p-6 text-sm text-muted-foreground">No active matched employees.</div>
        ) : (
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Name</TableHead>
                <TableHead>Position</TableHead>
                <TableHead>Team</TableHead>
                <TableHead>Timezone</TableHead>
                <TableHead>Preferred time</TableHead>
                <TableHead>WhatsApp</TableHead>
                <TableHead className="text-right">Action</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {hires.map((h) => {
                const phoneOk = !!normalizeE164(h.phone || "");
                return (
                  <TableRow key={h.candidate_id}>
                    <TableCell className="font-medium">{h.candidate_name || "—"}</TableCell>
                    <TableCell>{h.position_title || "—"}</TableCell>
                    <TableCell>{h.assigned_group_id || "—"}</TableCell>
                    <TableCell>{h.contact_timezone || "—"}</TableCell>
                    <TableCell>{h.preferred_contact_time || "—"}</TableCell>
                    <TableCell>
                      {phoneOk ? (
                        <span className="font-mono text-xs">{normalizeE164(h.phone || "")}</span>
                      ) : (
                        <span className="text-xs text-muted-foreground italic">none</span>
                      )}
                    </TableCell>
                    <TableCell className="text-right">
                      <Button
                        size="sm"
                        disabled={!phoneOk}
                        onClick={() => openLaunchDialog(h)}
                        title={phoneOk ? "" : "No WhatsApp number on file."}
                      >
                        <Rocket className="h-3.5 w-3.5 mr-1.5" /> Launch Sylvia
                      </Button>
                    </TableCell>
                  </TableRow>
                );
              })}
            </TableBody>
          </Table>
        )}
      </section>

      {/* B) UNIVERSAL LAUNCH */}
      <section className="border rounded-md p-4 space-y-3">
        <h2 className="font-medium">Universal launch (off-list / VIP)</h2>
        <div className="grid md:grid-cols-2 gap-3">
          <div>
            <Label>Candidate name</Label>
            <Input value={uName} onChange={(e) => setUName(e.target.value)} placeholder="Full name" />
          </div>
          <div>
            <Label>WhatsApp number (E.164)</Label>
            <Input value={uPhone} onChange={(e) => setUPhone(e.target.value)} placeholder="+639171234567" />
          </div>
          <div>
            <Label>Timezone</Label>
            <select className="w-full h-10 rounded-md border px-3" value={uTz} onChange={(e) => setUTz(e.target.value)}>
              {COMMON_TZS.map((tz) => <option key={tz} value={tz}>{tz}</option>)}
            </select>
          </div>
          <div>
            <Label>Mode</Label>
            <RadioGroup value={uMode} onValueChange={(v) => setUMode(v as any)} className="flex gap-4 mt-2">
              <label className="flex items-center gap-2 text-sm">
                <RadioGroupItem value="now" /> Launch now
              </label>
              <label className="flex items-center gap-2 text-sm">
                <RadioGroupItem value="scheduled" /> Schedule
              </label>
            </RadioGroup>
          </div>
          {uMode === "scheduled" && (
            <>
              <div>
                <Label>Date (local to tz above)</Label>
                <Input type="date" value={uDate} onChange={(e) => setUDate(e.target.value)} />
              </div>
              <div>
                <Label>Time (local to tz above)</Label>
                <Input type="time" value={uTime} onChange={(e) => setUTime(e.target.value)} />
              </div>
            </>
          )}
          <div className="md:col-span-2">
            <Label>Custom Sylvia instruction (optional)</Label>
            <Textarea value={uInstruction} onChange={(e) => setUInstruction(e.target.value)} rows={2} />
          </div>
        </div>
        {uMode === "scheduled" && uDate && uTime && (
          <div className="text-xs text-muted-foreground">
            Will send at <strong>{uDate} {uTime}</strong> ({uTz}) = <strong>{localToUtcIso(uDate, uTime, uTz) || "—"}</strong> UTC
          </div>
        )}
        <Button onClick={submitUniversalLaunch} disabled={uBusy}>
          {uBusy ? <Loader2 className="h-4 w-4 mr-1.5 animate-spin" /> : <Rocket className="h-4 w-4 mr-1.5" />}
          {uMode === "now" ? "Launch now" : "Schedule launch"}
        </Button>
      </section>

      {/* C) LAUNCH LOG */}
      <section className="border rounded-md">
        <div className="flex items-center justify-between p-4 border-b">
          <h2 className="font-medium">Launch log</h2>
          <div className="flex items-center gap-2">
            <Button
              variant="outline"
              size="sm"
              onClick={() => setConfirmClear(true)}
              disabled={!launches.some((L) => ["sent", "failed", "cancelled"].includes(L.status))}
            >
              <Trash2 className="h-4 w-4 mr-1.5" /> Clear sent/failed/cancelled
            </Button>
            <Button variant="ghost" size="sm" onClick={loadLog}>
              <RefreshCw className="h-4 w-4 mr-1.5" /> Refresh
            </Button>
          </div>
        </div>
        {loadingLog ? (
          <div className="p-6"><InlineLoader label="Loading log…" /></div>
        ) : logError ? (
          <div className="p-6"><LoadError message={logError} onRetry={loadLog} /></div>
        ) : launches.length === 0 ? (
          <div className="p-6 text-sm text-muted-foreground">No launches yet.</div>
        ) : (
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Name</TableHead>
                <TableHead>WhatsApp</TableHead>
                <TableHead>Mode</TableHead>
                <TableHead>Scheduled (local)</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Sent at</TableHead>
                <TableHead>Error</TableHead>
                <TableHead className="text-right">Action</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {launches.map((L) => (
                <TableRow key={L.id}>
                  <TableCell className="font-medium">{L.candidate_name || "—"}</TableCell>
                  <TableCell><span className="font-mono text-xs">{L.whatsapp_number}</span></TableCell>
                  <TableCell>{L.mode}</TableCell>
                  <TableCell className="text-xs">
                    {L.scheduled_for ? fmtLocal(L.scheduled_for, L.contact_timezone) : "—"}
                  </TableCell>
                  <TableCell>{statusBadge(L.status)}</TableCell>
                  <TableCell className="text-xs">{L.sent_at ? new Date(L.sent_at).toLocaleString() : "—"}</TableCell>
                  <TableCell className="text-xs max-w-[280px] truncate" title={L.error_message || ""}>
                    {L.error_message || "—"}
                  </TableCell>
                  <TableCell className="text-right">
                    <div className="flex items-center justify-end gap-2">
                      {L.status === "pending" && L.mode === "scheduled" && (
                        <Button size="sm" variant="outline" onClick={() => cancelLaunch(L.id)}>
                          <XCircle className="h-3.5 w-3.5 mr-1.5" /> Cancel
                        </Button>
                      )}
                      <Button
                        size="sm"
                        variant="ghost"
                        className="text-destructive hover:text-destructive"
                        onClick={() => setPendingDelete(L)}
                        title="Delete this launch record"
                      >
                        <Trash2 className="h-3.5 w-3.5" />
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        )}
      </section>

      {/* Per-hire launch dialog */}
      <Dialog open={!!launchHire} onOpenChange={(o) => !o && closeLaunchDialog()}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Launch Sylvia → {launchHire?.candidate_name}</DialogTitle>
            <DialogDescription>
              Confirm or edit the candidate's WhatsApp number before launching.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label>WhatsApp number (E.164)</Label>
              <Input
                value={launchPhone}
                onChange={(e) => setLaunchPhone(e.target.value)}
                placeholder="+639171234567"
                className="font-mono"
              />
              <p className="text-xs text-muted-foreground mt-1">
                Pre-filled from the candidate's application. Edit if they use a different WhatsApp number.
              </p>
            </div>
            <RadioGroup value={launchMode} onValueChange={(v) => setLaunchMode(v as any)} className="flex gap-4">
              <label className="flex items-center gap-2 text-sm">
                <RadioGroupItem value="now" /> Launch now
              </label>
              <label className="flex items-center gap-2 text-sm">
                <RadioGroupItem value="scheduled" /> Schedule
              </label>
            </RadioGroup>
            {launchMode === "scheduled" && (
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <Label>Date</Label>
                  <Input type="date" value={launchDate} onChange={(e) => setLaunchDate(e.target.value)} />
                </div>
                <div>
                  <Label>Time</Label>
                  <Input type="time" value={launchTime} onChange={(e) => setLaunchTime(e.target.value)} />
                </div>
                <div className="col-span-2">
                  <Label>Timezone</Label>
                  <select className="w-full h-10 rounded-md border px-3" value={launchTz} onChange={(e) => setLaunchTz(e.target.value)}>
                    {COMMON_TZS.map((tz) => <option key={tz} value={tz}>{tz}</option>)}
                  </select>
                </div>
                {previewUtc && (
                  <div className="col-span-2 text-xs text-muted-foreground">
                    Will send at <strong>{launchDate} {launchTime}</strong> ({launchTz}) = <strong>{previewUtc}</strong> UTC
                  </div>
                )}
              </div>
            )}
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={closeLaunchDialog} disabled={launchBusy}>Cancel</Button>
            <Button onClick={submitHireLaunch} disabled={launchBusy}>
              {launchBusy ? <Loader2 className="h-4 w-4 mr-1.5 animate-spin" /> : <Rocket className="h-4 w-4 mr-1.5" />}
              {launchMode === "now" ? "Launch now" : "Schedule"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Confirm single-row delete */}
      <AlertDialog open={!!pendingDelete} onOpenChange={(o) => !o && setPendingDelete(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete this launch record?</AlertDialogTitle>
            <AlertDialogDescription>
              This removes only the launch-attempt log entry for{" "}
              <strong>{pendingDelete?.candidate_name || "this contact"}</strong>. The candidate,
              their application, and all employment status are untouched.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={deleteBusy}>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={(e) => { e.preventDefault(); if (pendingDelete) deleteLaunch(pendingDelete.id); }}
              disabled={deleteBusy}
            >
              {deleteBusy ? <Loader2 className="h-4 w-4 mr-1.5 animate-spin" /> : <Trash2 className="h-4 w-4 mr-1.5" />}
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Confirm bulk clear of sent/failed/cancelled */}
      <AlertDialog open={confirmClear} onOpenChange={(o) => !o && setConfirmClear(false)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Clear sent/failed/cancelled launches?</AlertDialogTitle>
            <AlertDialogDescription>
              This permanently removes all finished launch records (sent, failed, cancelled).
              Pending in-flight launches are left untouched. Candidate and application data are
              not affected.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={deleteBusy}>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={(e) => { e.preventDefault(); clearFinishedLaunches(); }}
              disabled={deleteBusy}
            >
              {deleteBusy ? <Loader2 className="h-4 w-4 mr-1.5 animate-spin" /> : <Trash2 className="h-4 w-4 mr-1.5" />}
              Clear them
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
