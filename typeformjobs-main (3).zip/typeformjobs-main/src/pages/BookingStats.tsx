import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { useHrIdentity } from "@/hooks/useHrIdentity";
import { Button } from "@/components/ui/button";

const NAVY = "#1a2547";

type Row = { hr_id: string; name: string; claimed: number; completed: number; noShows: number };

const BookingStats = () => {
  const navigate = useNavigate();
  const hr = useHrIdentity();
  const [rows, setRows] = useState<Row[]>([]);
  const [audit, setAudit] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => { document.title = "EIA — Booking Stats"; }, []);

  useEffect(() => {
    if (hr.loading) return;
    if (hr.role !== "master_admin") { navigate("/dashboard/bookings"); return; }
    (async () => {
      const [{ data: hrs }, { data: slots }, { data: aud }] = await Promise.all([
        supabase.from("hr_users").select("id, display_name").eq("role", "hr"),
        supabase.from("interview_slots").select("claimed_by_hr_id, completed_at, completion_method"),
        supabase.from("password_audit_log").select("*").order("timestamp", { ascending: false }).limit(100),
      ]);
      const aggregated: Row[] = (hrs || []).map((h: any) => {
        const claimed = (slots || []).filter((s: any) => s.claimed_by_hr_id === h.id).length;
        const completed = (slots || []).filter((s: any) => s.claimed_by_hr_id === h.id && s.completed_at && s.completion_method !== "no_show").length;
        const noShows = (slots || []).filter((s: any) => s.claimed_by_hr_id === h.id && s.completion_method === "no_show").length;
        return { hr_id: h.id, name: h.display_name, claimed, completed, noShows };
      });
      setRows(aggregated);
      setAudit(aud || []);
      setLoading(false);
    })();
  }, [hr.loading, hr.role, navigate]);

  if (hr.loading || loading) return <div className="p-8 text-muted-foreground">Loading…</div>;

  return (
    <div className="min-h-screen bg-background">
      <header className="border-b">
        <div className="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between">
          <h1 style={{ fontFamily: "'Cormorant Garamond', serif", fontWeight: 600, fontSize: 22, color: NAVY }}>Booking Stats</h1>
          <Button variant="ghost" size="sm" onClick={() => navigate("/dashboard/bookings")}>← Back to Dashboard</Button>
        </div>
      </header>
      <main className="max-w-7xl mx-auto px-6 py-8 space-y-8">
        <section>
          <h2 className="text-lg font-semibold mb-3">HR Attribution</h2>
          <div className="border rounded-md overflow-hidden">
            <table className="w-full text-sm">
              <thead className="bg-muted/50 text-left">
                <tr>
                  <th className="px-3 py-2 font-medium">HR</th>
                  <th className="px-3 py-2 font-medium">Claimed</th>
                  <th className="px-3 py-2 font-medium">Completed</th>
                  <th className="px-3 py-2 font-medium">No-Shows</th>
                  <th className="px-3 py-2 font-medium">Completion Rate</th>
                </tr>
              </thead>
              <tbody>
                {rows.map((r) => (
                  <tr key={r.hr_id} className="border-t">
                    <td className="px-3 py-2 font-medium">{r.name}</td>
                    <td className="px-3 py-2">{r.claimed}</td>
                    <td className="px-3 py-2">{r.completed}</td>
                    <td className="px-3 py-2">{r.noShows}</td>
                    <td className="px-3 py-2">{r.claimed ? Math.round((r.completed / r.claimed) * 100) + "%" : "—"}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </section>

        <section>
          <h2 className="text-lg font-semibold mb-3">Override Password Usage</h2>
          <div className="border rounded-md overflow-hidden">
            <table className="w-full text-sm">
              <thead className="bg-muted/50 text-left">
                <tr>
                  <th className="px-3 py-2 font-medium">When</th>
                  <th className="px-3 py-2 font-medium">HR</th>
                  <th className="px-3 py-2 font-medium">Password</th>
                  <th className="px-3 py-2 font-medium">Action</th>
                  <th className="px-3 py-2 font-medium">Target</th>
                </tr>
              </thead>
              <tbody>
                {audit.length === 0 && <tr><td colSpan={5} className="px-3 py-6 text-center text-muted-foreground">No overrides used yet</td></tr>}
                {audit.map((a) => (
                  <tr key={a.id} className="border-t">
                    <td className="px-3 py-2 whitespace-nowrap">{new Date(a.timestamp).toLocaleString()}</td>
                    <td className="px-3 py-2">{a.hr_user_id || "—"}</td>
                    <td className="px-3 py-2"><code className="text-xs">{a.password_used}</code></td>
                    <td className="px-3 py-2">{a.action_taken}</td>
                    <td className="px-3 py-2 text-xs text-muted-foreground">{a.target_resource_id}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </section>
      </main>
    </div>
  );
};

export default BookingStats;
