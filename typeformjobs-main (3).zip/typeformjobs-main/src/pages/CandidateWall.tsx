import { useEffect, useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import {
  ArrowLeft, Eye, Video, MessageSquare, Ban, LayoutGrid, List, Search,
} from "lucide-react";
import { detectContactQuestionIds } from "@/lib/candidateActions";
import { cleanPositionTitle } from "@/lib/positionTitle";
import { DisqualifyButton } from "@/components/DisqualifyButton";
import { RecoverInterviewButton } from "@/components/RecoverInterviewButton";
import { SendCustomMessageDialog } from "@/components/SendCustomMessageDialog";
import { SelfieThumb, FilePreviewDialog } from "@/components/FilePreview";

type Session = {
  id: string;
  response_id: string | null;
  duration_seconds: number | null;
  termination_reason: string | null;
  created_at: string;
  ended_at: string | null;
};

type Evaluation = {
  id: string;
  session_id: string;
  response_id: string | null;
  tier: string | null;
  ai_recommended: boolean | null;
  verdict: string | null;
};

type Resp = {
  id: string;
  form_id: string;
  round_stage: string | null;
  override_email: string | null;
  appointment_cancelled: boolean | null;
};

type FormRow = { id: string; title: string };

type Meta = { form_id: string; position_title: string | null };

type Question = { id: string; form_id: string; type: string; label: string; order_index?: number };

type Answer = { response_id: string; question_id: string; answer_text: string | null; file_url: string | null };

type Extra = { response_id: string; photo_file_url: string | null };

const TIER_COLOR: Record<string, string> = {
  "best one": "bg-emerald-100 text-emerald-800",
  "breadwinner": "bg-sky-100 text-sky-800",
  "steady": "bg-blue-100 text-blue-800",
  "edgy": "bg-amber-100 text-amber-800",
  "red flag": "bg-rose-100 text-rose-800",
};

const tierClass = (t: string | null | undefined) =>
  TIER_COLOR[(t || "").toLowerCase().trim()] || "bg-slate-100 text-slate-700";

const PHOTO_RE = /(photo|selfie|picture|headshot|portrait|image)/i;

const CandidateWall = () => {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(true);
  const [viewMode, setViewMode] = useState<"grid" | "list">("grid");

  const [responses, setResponses] = useState<Resp[]>([]);
  const [forms, setForms] = useState<FormRow[]>([]);
  const [meta, setMeta] = useState<Meta[]>([]);
  const [questions, setQuestions] = useState<Question[]>([]);
  const [answers, setAnswers] = useState<Answer[]>([]);
  const [sessions, setSessions] = useState<Session[]>([]);
  const [evaluations, setEvaluations] = useState<Evaluation[]>([]);
  const [extras, setExtras] = useState<Extra[]>([]);

  const [search, setSearch] = useState("");
  const [tierFilter, setTierFilter] = useState<string>("all");
  const [recommendedOnly, setRecommendedOnly] = useState(false);
  const [positionFilter, setPositionFilter] = useState<string>("all");
  const [customMsgTarget, setCustomMsgTarget] = useState<{
    responseId: string;
    name: string;
    email: string;
  } | null>(null);
  const [previewFile, setPreviewFile] = useState<string | null>(null);

  useEffect(() => {
    document.title = "Candidate Wall — EIA";
    (async () => {
      setLoading(true);
      const { data: rs } = await supabase
        .from("responses")
        .select("id, form_id, round_stage, override_email, appointment_cancelled")
        .order("submitted_at", { ascending: false })
        .limit(1000);
      const respList = (rs || []) as Resp[];
      setResponses(respList);

      const responseIds = respList.map((r) => r.id);
      const formIds = Array.from(new Set(respList.map((r) => r.form_id).filter(Boolean)));

      const [sessRes, evalRes, extrasRes] = await Promise.all([
        responseIds.length
          ? supabase
              .from("ai_interview_sessions")
              .select("id, response_id, duration_seconds, termination_reason, created_at, ended_at")
              .in("response_id", responseIds)
              .order("created_at", { ascending: false })
          : Promise.resolve({ data: [] as Session[] } as any),
        responseIds.length
          ? supabase
              .from("ai_interview_evaluations")
              .select("id, session_id, response_id, tier, ai_recommended, verdict")
              .in("response_id", responseIds)
          : Promise.resolve({ data: [] as Evaluation[] } as any),
        responseIds.length
          ? supabase
              .from("hr_candidate_extras")
              .select("response_id, photo_file_url")
              .in("response_id", responseIds)
          : Promise.resolve({ data: [] as Extra[] } as any),
      ]);

      setSessions((sessRes.data || []) as Session[]);
      setEvaluations((evalRes.data || []) as Evaluation[]);
      setExtras((extrasRes.data || []) as Extra[]);

      if (formIds.length) {
        const [fRes, mRes, qRes] = await Promise.all([
          supabase.from("forms").select("id, title").in("id", formIds),
          supabase.from("form_metadata").select("form_id, position_title").in("form_id", formIds),
          supabase.from("questions").select("id, form_id, type, label, order_index").in("form_id", formIds),
        ]);
        setForms((fRes.data || []) as FormRow[]);
        setMeta((mRes.data || []) as Meta[]);
        const qs = (qRes.data || []) as Question[];
        setQuestions(qs);

        if (respList.length) {
          const { data: aRes } = await supabase
            .from("answers")
            .select("response_id, question_id, answer_text, file_url")
            .in("response_id", respList.map((r) => r.id));
          setAnswers((aRes || []) as Answer[]);
        }
      }

      setLoading(false);
    })();
  }, []);

  const respById = useMemo(() => {
    const m = new Map<string, Resp>();
    responses.forEach((r) => m.set(r.id, r));
    return m;
  }, [responses]);

  const formById = useMemo(() => {
    const m = new Map<string, FormRow>();
    forms.forEach((f) => m.set(f.id, f));
    return m;
  }, [forms]);

  const metaByForm = useMemo(() => {
    const m = new Map<string, Meta>();
    meta.forEach((x) => m.set(x.form_id, x));
    return m;
  }, [meta]);

  const questionsByForm = useMemo(() => {
    const m = new Map<string, Question[]>();
    questions.forEach((q) => {
      const a = m.get(q.form_id) || [];
      a.push(q);
      m.set(q.form_id, a);
    });
    return m;
  }, [questions]);

  const answerByResp = useMemo(() => {
    const m = new Map<string, Map<string, string>>();
    answers.forEach((a) => {
      let inner = m.get(a.response_id);
      if (!inner) { inner = new Map(); m.set(a.response_id, inner); }
      if (a.question_id) inner.set(a.question_id, a.answer_text || "");
    });
    return m;
  }, [answers]);

  const fileByResp = useMemo(() => {
    const m = new Map<string, Map<string, string>>();
    answers.forEach((a) => {
      if (!a.file_url) return;
      let inner = m.get(a.response_id);
      if (!inner) { inner = new Map(); m.set(a.response_id, inner); }
      if (a.question_id) inner.set(a.question_id, a.file_url);
    });
    return m;
  }, [answers]);

  const photoByResp = useMemo(() => {
    const m = new Map<string, string>();
    extras.forEach((e) => { if (e.photo_file_url) m.set(e.response_id, e.photo_file_url); });
    return m;
  }, [extras]);

  // Latest session per response_id
  const latestSessionByResp = useMemo(() => {
    const m = new Map<string, Session>();
    for (const s of sessions) {
      if (!s.response_id) continue;
      if (!m.has(s.response_id)) m.set(s.response_id, s);
    }
    return m;
  }, [sessions]);

  const evalBySession = useMemo(() => {
    const m = new Map<string, Evaluation>();
    for (const e of evaluations) {
      m.set(e.session_id, e);
    }
    return m;
  }, [evaluations]);

  const rows = useMemo(() => {
    const list: Array<{
      responseId: string;
      session: Session | undefined;
      evaluation: Evaluation | undefined;
      candidateName: string;
      candidateEmail: string;
      selfieUrl: string | null;
      positionTitle: string;
      roundStage: string | null;
      appointmentCancelled: boolean | null;
    }> = [];

    for (const resp of responses) {
      const form = formById.get(resp.form_id);
      const m = metaByForm.get(resp.form_id);
      const positionTitle = cleanPositionTitle(m?.position_title || form?.title || "") || "—";

      let candidateName = "—";
      let candidateEmail = "";
      let selfieUrl: string | null = null;

      const qs = questionsByForm.get(resp.form_id) || [];
      const { nameQid, emailQid } = detectContactQuestionIds(qs);
      const ans = answerByResp.get(resp.id);
      const files = fileByResp.get(resp.id);

      if (nameQid && ans?.get(nameQid)) candidateName = ans.get(nameQid)!.trim() || "—";
      candidateEmail = (resp.override_email || (emailQid ? ans?.get(emailQid) : "") || "").trim();

      const sorted = [...qs].sort((a, b) => (a.order_index || 0) - (b.order_index || 0));
      const uploads = sorted.filter((q) => q.type === "file_upload" || q.type === "selfie");
      const selfieQ = uploads.find((q) => q.type === "selfie") || uploads.find((q) => PHOTO_RE.test(q.label || ""));
      selfieUrl = (selfieQ && files?.get(selfieQ.id)) || photoByResp.get(resp.id) || null;

      if (candidateName === "—") candidateName = "Direct Link Candidate";

      const session = latestSessionByResp.get(resp.id);
      const evaluation = session ? evalBySession.get(session.id) : undefined;

      list.push({
        responseId: resp.id,
        session,
        evaluation,
        candidateName,
        candidateEmail,
        selfieUrl,
        positionTitle,
        roundStage: resp.round_stage ?? null,
        appointmentCancelled: resp.appointment_cancelled ?? null,
      });
    }
    return list;
  }, [responses, formById, metaByForm, questionsByForm, answerByResp, fileByResp, photoByResp, latestSessionByResp, evalBySession]);

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    return rows.filter((r) => {
      if (recommendedOnly && !(r.evaluation?.ai_recommended === true)) return false;
      if (tierFilter !== "all") {
        const t = (r.evaluation?.tier || "").toLowerCase().trim();
        if (t !== tierFilter) return false;
      }
      if (positionFilter !== "all" && r.positionTitle !== positionFilter) return false;
      if (q) {
        const hay = `${r.candidateName} ${r.positionTitle}`.toLowerCase();
        if (!hay.includes(q)) return false;
      }
      return true;
    });
  }, [rows, search, tierFilter, recommendedOnly, positionFilter]);

  const tierOptions = useMemo(() => {
    const set = new Set<string>();
    rows.forEach((r) => { const t = (r.evaluation?.tier || "").toLowerCase().trim(); if (t) set.add(t); });
    return Array.from(set);
  }, [rows]);

  const positionOptions = useMemo(() => {
    const set = new Set<string>();
    rows.forEach((r) => { if (r.positionTitle) set.add(r.positionTitle); });
    return Array.from(set).sort();
  }, [rows]);

  // Group by position
  const grouped = useMemo(() => {
    const m = new Map<string, typeof filtered>();
    for (const r of filtered) {
      const pos = r.positionTitle;
      const arr = m.get(pos) || [];
      arr.push(r);
      m.set(pos, arr);
    }
    return m;
  }, [filtered]);

  const handleDisqualified = (responseId: string) => {
    setResponses((prev) =>
      prev.map((r) => (r.id === responseId ? { ...r, round_stage: "disqualified" as any } : r))
    );
  };

  const CandidateCard = ({ r }: { r: (typeof rows)[0] }) => (
    <div className="border border-border rounded-lg bg-card p-4 flex flex-col gap-3 hover:shadow-sm transition-shadow">
      <div className="flex items-start gap-3">
        <div className="shrink-0">
          {r.selfieUrl ? (
            <SelfieThumb file_url={r.selfieUrl} size={80} onPreview={() => setPreviewFile(r.selfieUrl)} />
          ) : (
            <div className="rounded-lg bg-secondary border border-border flex items-center justify-center text-[10px] text-muted-foreground" style={{ width: 80, height: 80 }}>
              —
            </div>
          )}
        </div>
        <div className="flex-1 min-w-0">
          <div className="font-semibold text-sm truncate">{r.candidateName}</div>
          <div className="text-xs text-muted-foreground truncate">{r.positionTitle}</div>
          <div className="flex flex-wrap items-center gap-1.5 mt-2">
            {r.evaluation?.tier ? (
              <Badge className={`${tierClass(r.evaluation.tier)} border-0 text-[11px]`}>{r.evaluation.tier}</Badge>
            ) : null}
            {r.evaluation?.ai_recommended === true ? (
              <Badge className="border-0 bg-emerald-100 text-emerald-800 text-[11px]">Recommended</Badge>
            ) : r.evaluation?.ai_recommended === false ? (
              <Badge className="border-0 bg-rose-100 text-rose-800 text-[11px]">Not Recommended</Badge>
            ) : null}
            {r.roundStage === "disqualified" && (
              <Badge className="border-0 bg-red-600 text-white text-[11px]">Disqualified</Badge>
            )}
            {r.appointmentCancelled && (
              <Badge className="border-0 bg-slate-100 text-slate-600 text-[11px]">Cancelled</Badge>
            )}
          </div>
        </div>
      </div>

      <div className="flex flex-row flex-wrap items-center gap-2 mt-auto">
        <Button
          size="sm"
          className="bg-emerald-600 hover:bg-emerald-700 text-white"
          onClick={() => navigate(`/dashboard/ai-interviews/${r.responseId}`)}
        >
          <Eye className="h-3.5 w-3.5 mr-1" /> Scout Report
        </Button>
        <RecoverInterviewButton
          responseId={r.responseId}
          candidateName={r.candidateName === "Direct Link Candidate" ? "" : r.candidateName}
          candidateEmail={r.candidateEmail}
          appearance="outline"
          eligible={true}
        />
        <Button
          size="sm"
          className="bg-violet-600 hover:bg-violet-700 text-white"
          onClick={() => setCustomMsgTarget({
            responseId: r.responseId,
            name: r.candidateName === "Direct Link Candidate" ? "" : r.candidateName,
            email: r.candidateEmail,
          })}
        >
          <MessageSquare className="h-3.5 w-3.5 mr-1" /> Message
        </Button>
        <DisqualifyButton
          responseId={r.responseId}
          candidateName={r.candidateName === "Direct Link Candidate" ? "" : r.candidateName}
          onDisqualified={() => handleDisqualified(r.responseId)}
        />
      </div>
    </div>
  );

  const CandidateListRow = ({ r }: { r: (typeof rows)[0] }) => (
    <div className="border border-border rounded-lg bg-card p-4 flex items-start gap-4">
      <div className="shrink-0">
        {r.selfieUrl ? (
          <SelfieThumb file_url={r.selfieUrl} size={60} onPreview={() => setPreviewFile(r.selfieUrl)} />
        ) : (
          <div className="rounded-lg bg-secondary border border-border flex items-center justify-center text-[10px] text-muted-foreground" style={{ width: 60, height: 60 }}>
            —
          </div>
        )}
      </div>
      <div className="flex-1 min-w-0 flex flex-col gap-1">
        <div className="flex flex-wrap items-center gap-2">
          <span className="font-medium">{r.candidateName}</span>
          {r.evaluation?.tier ? (
            <Badge className={`${tierClass(r.evaluation.tier)} border-0`}>{r.evaluation.tier}</Badge>
          ) : null}
          {r.evaluation?.ai_recommended === true ? (
            <Badge className="border-0 bg-emerald-100 text-emerald-800">Recommended</Badge>
          ) : r.evaluation?.ai_recommended === false ? (
            <Badge className="border-0 bg-rose-100 text-rose-800">Not Recommended</Badge>
          ) : null}
          {r.roundStage === "disqualified" && (
            <Badge className="border-0 bg-red-600 text-white">Disqualified</Badge>
          )}
        </div>
        <div className="text-xs text-muted-foreground">{r.positionTitle}</div>
      </div>
      <div className="flex flex-row flex-wrap items-center gap-2 shrink-0">
        <Button
          size="sm"
          className="bg-emerald-600 hover:bg-emerald-700 text-white"
          onClick={() => navigate(`/dashboard/ai-interviews/${r.responseId}`)}
        >
          <Eye className="h-3.5 w-3.5 mr-1" /> Scout Report
        </Button>
        <RecoverInterviewButton
          responseId={r.responseId}
          candidateName={r.candidateName === "Direct Link Candidate" ? "" : r.candidateName}
          candidateEmail={r.candidateEmail}
          appearance="outline"
          eligible={true}
        />
        <Button
          size="sm"
          className="bg-violet-600 hover:bg-violet-700 text-white"
          onClick={() => setCustomMsgTarget({
            responseId: r.responseId,
            name: r.candidateName === "Direct Link Candidate" ? "" : r.candidateName,
            email: r.candidateEmail,
          })}
        >
          <MessageSquare className="h-3.5 w-3.5 mr-1" /> Message
        </Button>
        <DisqualifyButton
          responseId={r.responseId}
          candidateName={r.candidateName === "Direct Link Candidate" ? "" : r.candidateName}
          onDisqualified={() => handleDisqualified(r.responseId)}
        />
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-background">
      <header className="bg-background" style={{ borderBottom: "1px solid #e1e4ec" }}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-4 flex flex-wrap items-center gap-3">
          <Button variant="ghost" size="sm" onClick={() => navigate("/dashboard")} className="min-h-[44px]">
            <ArrowLeft className="h-4 w-4 mr-1.5" /> Back
          </Button>
          <h1 className="text-lg sm:text-xl font-semibold flex items-center gap-2">
            <LayoutGrid className="h-5 w-5" /> Candidate Wall
          </h1>
          <div className="ml-auto flex items-center gap-2">
            <Button
              variant={viewMode === "grid" ? "default" : "outline"}
              size="sm"
              onClick={() => setViewMode("grid")}
            >
              <LayoutGrid className="h-4 w-4" />
            </Button>
            <Button
              variant={viewMode === "list" ? "default" : "outline"}
              size="sm"
              onClick={() => setViewMode("list")}
            >
              <List className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 py-6 sm:py-8">
        {/* Filters */}
        <div className="flex flex-col sm:flex-row gap-3 mb-6">
          <div className="relative flex-1 sm:max-w-xs">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search by name or position…"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="pl-9 min-h-[44px]"
            />
          </div>
          <Select value={positionFilter} onValueChange={setPositionFilter}>
            <SelectTrigger className="sm:max-w-[220px] min-h-[44px]">
              <SelectValue placeholder="All positions" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All positions</SelectItem>
              {positionOptions.map((p) => (
                <SelectItem key={p} value={p}>{p}</SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Select value={tierFilter} onValueChange={setTierFilter}>
            <SelectTrigger className="sm:max-w-[180px] min-h-[44px]">
              <SelectValue placeholder="All tiers" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All tiers</SelectItem>
              {tierOptions.map((t) => (
                <SelectItem key={t} value={t}>{t.replace(/\b\w/g, (c) => c.toUpperCase())}</SelectItem>
              ))}
            </SelectContent>
          </Select>
          <label className="flex items-center gap-2 px-3 min-h-[44px] cursor-pointer select-none">
            <Checkbox
              checked={recommendedOnly}
              onCheckedChange={(v) => setRecommendedOnly(v === true)}
            />
            <span className="text-sm">AI Recommended only</span>
          </label>
        </div>

        {loading ? (
          viewMode === "grid" ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4" aria-busy="true">
              {[0, 1, 2, 3, 4, 5].map((i) => (
                <Skeleton key={i} className="h-48 w-full rounded-lg" />
              ))}
            </div>
          ) : (
            <div className="space-y-3" aria-busy="true">
              {[0, 1, 2, 3, 4].map((i) => (
                <Skeleton key={i} className="h-20 w-full rounded-lg" />
              ))}
            </div>
          )
        ) : filtered.length === 0 ? (
          <div className="border border-dashed border-border rounded-xl p-12 text-center">
            <div className="mx-auto mb-4 h-14 w-14 rounded-full bg-secondary flex items-center justify-center">
              <Video className="h-6 w-6 text-muted-foreground" />
            </div>
            <h3 className="text-lg font-semibold mb-1">No candidates found</h3>
            <p className="text-sm text-muted-foreground">
              Try adjusting your filters or search terms.
            </p>
          </div>
        ) : (
          <div className="space-y-8">
            {Array.from(grouped.entries()).map(([position, candidates]) => (
              <section key={position}>
                <h2 className="text-lg font-semibold mb-4 flex items-center gap-2">
                  {position}
                  <Badge variant="secondary" className="text-xs">{candidates.length}</Badge>
                </h2>
                {viewMode === "grid" ? (
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
                    {candidates.map((r) => (
                      <CandidateCard key={r.responseId} r={r} />
                    ))}
                  </div>
                ) : (
                  <div className="space-y-3">
                    {candidates.map((r) => (
                      <CandidateListRow key={r.responseId} r={r} />
                    ))}
                  </div>
                )}
              </section>
            ))}
          </div>
        )}
      </main>

      <SendCustomMessageDialog
        open={!!customMsgTarget}
        onOpenChange={(o) => { if (!o) setCustomMsgTarget(null); }}
        initialName={customMsgTarget?.name}
        initialEmail={customMsgTarget?.email}
        responseId={customMsgTarget?.responseId}
      />

      <FilePreviewDialog file_url={previewFile} onClose={() => setPreviewFile(null)} />
    </div>
  );
};

export default CandidateWall;
