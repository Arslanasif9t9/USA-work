import { useEffect, useState, useCallback } from "react";
import { useParams, Navigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import FormTopBar, { useFormHeader } from "@/components/FormTopBar";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Plus, Eye, Pencil, X, Copy, Settings as SettingsIcon, GripVertical, List, ChevronLeft, ChevronRight, Inbox, Loader2, Palette, Check, Menu, PanelRightClose, PanelRightOpen, ArrowUp, ArrowDown } from "lucide-react";
import Slide, { SlideQuestion } from "@/components/Slide";
import SlideRunner from "@/components/SlideRunner";
import EiaWordmark from "@/components/EiaWordmark";
import QuestionPicker, { QuestionTypeDef } from "@/components/QuestionPicker";
import { THEMES, getThemeClass, isValidTheme, type ThemeId } from "@/lib/theme";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import QuestionSettings from "@/components/QuestionSettings";
import PositionTitleSection from "@/components/PositionTitleSection";
import TypographyPicker from "@/components/TypographyPicker";
import { FormTypography, mergeTypography, typographyEqual, typographyStyle } from "@/lib/typography";
import { Skeleton } from "@/components/ui/skeleton";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetTrigger } from "@/components/ui/sheet";
import {
  DndContext,
  closestCenter,
  PointerSensor,
  KeyboardSensor,
  TouchSensor,
  useSensor,
  useSensors,
  DragEndEvent,
} from "@dnd-kit/core";
import {
  SortableContext,
  sortableKeyboardCoordinates,
  useSortable,
  verticalListSortingStrategy,
  arrayMove,
} from "@dnd-kit/sortable";
import { CSS } from "@dnd-kit/utilities";

const Builder = () => {
  const { id } = useParams<{ id: string }>();
  if (!id) return <Navigate to="/dashboard" replace />;
  const { form, refresh } = useFormHeader(id);
  useEffect(() => {
    document.title = form?.title
      ? `EIA Talent Recruiting System — ${form.title}`
      : "EIA Talent Recruiting System";
  }, [form?.title]);
  const [questions, setQuestions] = useState<SlideQuestion[]>([]);
  // Theme: savedTheme is what's live; draftTheme is admin's current selection.
  const [savedTheme, setSavedTheme] = useState<ThemeId>("darkblue");
  const [draftTheme, setDraftTheme] = useState<ThemeId>("darkblue");
  const [savingTheme, setSavingTheme] = useState(false);
  const themeDirty = draftTheme !== savedTheme;
  const themeClass = getThemeClass(draftTheme);
  const [savedTypo, setSavedTypo] = useState<FormTypography>({});
  const [draftTypo, setDraftTypo] = useState<FormTypography>({});
  const [savingTypo, setSavingTypo] = useState(false);
  const typoStyle = typographyStyle(mergeTypography(draftTypo));
  const [loadingQs, setLoadingQs] = useState(true);
  const [activeId, setActiveId] = useState<string | null>(null);
  const [mode, setMode] = useState<"edit" | "preview">("edit");
  const [pickerOpen, setPickerOpen] = useState(false);
  const [mobileSettingsOpen, setMobileSettingsOpen] = useState(false);
  const [mobileQsOpen, setMobileQsOpen] = useState(false);
  const [modeHint, setModeHint] = useState<string | null>(null);
  const [leftOpen, setLeftOpen] = useState(true);
  const [rightOpen, setRightOpen] = useState(true);

  const loadQuestions = useCallback(async () => {
    const { data } = await supabase
      .from("questions")
      .select("id, type, label, description, placeholder, order_index, required, options")
      .eq("form_id", id)
      .order("order_index", { ascending: true });
    if (data) {
      // Normalize order_index: welcome=0, middle=1..N, thank_you=9999. Persist drift.
      let next = 1;
      const normalized = (data as any[]).map((q) => {
        let order_index: number;
        if (q.type === "welcome") order_index = 0;
        else if (q.type === "thank_you") order_index = 9999;
        else order_index = next++;
        return { ...q, order_index };
      });
      const drifted = normalized.filter((q, i) => q.order_index !== (data[i] as any).order_index);
      if (drifted.length) {
        await Promise.all(
          drifted.map((q) => supabase.from("questions").update({ order_index: q.order_index }).eq("id", q.id)),
        );
      }
      setQuestions(normalized as SlideQuestion[]);
      if (!activeId && normalized.length) setActiveId(normalized[0].id);
    }
    setLoadingQs(false);
  }, [id, activeId]);

  useEffect(() => { loadQuestions(); }, [id]);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (!e.altKey || (e.key !== "ArrowUp" && e.key !== "ArrowDown")) return;
      if (!activeId) return;
      const tgt = e.target as HTMLElement | null;
      if (tgt && (tgt.tagName === "INPUT" || tgt.tagName === "TEXTAREA" || tgt.isContentEditable)) return;
      const mid = questions.filter((q) => q.type !== "welcome" && q.type !== "thank_you");
      const idx = mid.findIndex((m) => m.id === activeId);
      if (idx < 0) return;
      const dir: -1 | 1 = e.key === "ArrowUp" ? -1 : 1;
      const newIdx = idx + dir;
      if (newIdx < 0 || newIdx >= mid.length) return;
      e.preventDefault();
      const newMiddle = [...mid];
      const [moved] = newMiddle.splice(idx, 1);
      newMiddle.splice(newIdx, 0, moved);
      const updated = questions.map((q) => {
        if (q.type === "welcome" || q.type === "thank_you") return q;
        const i = newMiddle.findIndex((m) => m.id === q.id);
        return { ...q, order_index: i + 1 };
      });
      setQuestions(updated);
      Promise.all(
        newMiddle.map((q, i) => supabase.from("questions").update({ order_index: i + 1 }).eq("id", q.id)),
      ).then((results) => {
        if (results.some((r) => r.error)) {
          toast.error("Failed to save new order. Please try again.");
          loadQuestions();
        }
      });
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [activeId, questions, loadQuestions]);


  // Sync theme from form
  useEffect(() => {
    if (form) {
      const t = isValidTheme(form.theme) ? form.theme : "darkblue";
      setSavedTheme(t);
      setDraftTheme(t);
      const ty = mergeTypography((form as any).typography);
      setSavedTypo(ty);
      setDraftTypo(ty);
    }
  }, [form?.theme, JSON.stringify((form as any)?.typography || {})]);

  const saveTypo = async () => {
    if (typographyEqual(draftTypo, savedTypo)) return;
    setSavingTypo(true);
    const { error } = await supabase.from("forms").update({ typography: draftTypo as any }).eq("id", id);
    setSavingTypo(false);
    if (error) return toast.error(error.message);
    setSavedTypo(draftTypo);
    toast.success("Typography saved — now live for candidates");
    refresh();
  };
  const resetTypo = () => setDraftTypo(savedTypo);

  const saveTheme = async () => {
    if (!themeDirty) return;
    setSavingTheme(true);
    const { error } = await supabase.from("forms").update({ theme: draftTheme }).eq("id", id);
    setSavingTheme(false);
    if (error) return toast.error(error.message);
    setSavedTheme(draftTheme);
    toast.success("Theme saved — now live for candidates");
    refresh();
  };

  const resetTheme = () => setDraftTheme(savedTheme);

  const sensors = useSensors(
    useSensor(PointerSensor, { activationConstraint: { distance: 4 } }),
    useSensor(TouchSensor, { activationConstraint: { delay: 200, tolerance: 5 } }),
    useSensor(KeyboardSensor, { coordinateGetter: sortableKeyboardCoordinates }),
  );

  if (!form) {
    return <div className="min-h-screen flex items-center justify-center" aria-busy="true"><Loader2 className="h-6 w-6 text-muted-foreground animate-spin" /></div>;
  }

  const active = questions.find((q) => q.id === activeId) || questions[0] || null;
  const welcome = questions.find((q) => q.type === "welcome");
  const thanks = questions.find((q) => q.type === "thank_you");
  const middle = questions.filter((q) => q.type !== "welcome" && q.type !== "thank_you");

  const updateQuestion = async (qid: string, patch: Partial<SlideQuestion>) => {
    // Optimistic update for snappy UI
    setQuestions((prev) => prev.map((q) => (q.id === qid ? { ...q, ...patch } as SlideQuestion : q)));
    const { error } = await supabase.from("questions").update(patch).eq("id", qid);
    if (error) { toast.error(error.message); loadQuestions(); return; }

    // Smart defaults: remember last-used per question type (skip welcome/thank_you)
    const target = questions.find((q) => q.id === qid);
    if (target && target.type !== "welcome" && target.type !== "thank_you") {
      const merged = { ...target, ...patch } as any;
      try {
        const payload: any = {
          label: merged.label || "",
          description: merged.description || "",
          placeholder: merged.placeholder || "",
        };
        if (merged.type === "multiple_choice" && merged.options?.choices) {
          payload.choices = merged.options.choices;
        }
        localStorage.setItem(`typehire-last-used-${merged.type}`, JSON.stringify(payload));
      } catch {}
    }
  };

  const handleAddQuestion = async (def: QuestionTypeDef) => {
    // Only one schedule_call per form.
    if (def.type === "schedule_call" && questions.some((q) => q.type === "schedule_call")) {
      setPickerOpen(false);
      toast.error("Only one Schedule a Call question is allowed per form.");
      return;
    }
    const thankIdx = thanks?.order_index ?? 9999;
    const middleMax = middle.length ? Math.max(...middle.map((m) => m.order_index)) : 0;
    const newOrder = Math.min(middleMax + 1, thankIdx - 1);


    // Smart defaults: pull last-used values from localStorage
    let label = def.defaults.label;
    let description: string | null = null;
    let placeholder = def.defaults.placeholder;
    let options = def.defaults.options;
    try {
      const raw = localStorage.getItem(`typehire-last-used-${def.type}`);
      if (raw) {
        const last = JSON.parse(raw);
        if (typeof last.label === "string" && last.label) label = last.label;
        if (typeof last.description === "string") description = last.description || null;
        if (typeof last.placeholder === "string") placeholder = last.placeholder;
        if (def.type === "multiple_choice" && Array.isArray(last.choices) && last.choices.length) {
          options = { ...options, choices: last.choices };
        }
      }
    } catch {}

    if (def.type === "schedule_call") {
      label = label || "Schedule Your Interview";
      if (!description) {
        description =
          "Booking a time slot does not guarantee an interview. Your selection is provisional and remains subject to review by our hiring team. You will receive formal confirmation via email only if your application advances to the interview stage.";
      }
    }


    const { data, error } = await supabase
      .from("questions")
      .insert({
        form_id: form.id,
        type: def.type,
        label,
        description,
        placeholder,
        required: def.defaults.required,
        options,
        order_index: newOrder,
      })
      .select()
      .single();
    setPickerOpen(false);
    if (error) return toast.error(error.message);
    await loadQuestions();
    if (data) setActiveId(data.id);
  };

  const handleDuplicateQuestion = async (qid: string) => {
    const orig = questions.find((q) => q.id === qid);
    if (!orig || orig.type === "welcome" || orig.type === "thank_you") return;
    const origOrder = orig.order_index;
    // Shift subsequent middle questions up by 1
    const toShift = middle.filter((m) => m.order_index > origOrder);
    await Promise.all(
      toShift.map((m) => supabase.from("questions").update({ order_index: m.order_index + 1 }).eq("id", m.id)),
    );
    const { data, error } = await supabase
      .from("questions")
      .insert({
        form_id: form.id,
        type: orig.type,
        label: orig.label,
        description: orig.description,
        placeholder: orig.placeholder,
        required: orig.required,
        options: orig.options,
        order_index: origOrder + 1,
      })
      .select()
      .single();
    if (error) {
      toast.error(error.message);
      await loadQuestions();
      return;
    }
    toast.success("Question duplicated");
    await loadQuestions();
    if (data) setActiveId(data.id);
  };

  const handleDeleteQuestion = async (qid: string) => {
    const snap = questions.find((q) => q.id === qid);
    if (!snap || snap.type === "welcome" || snap.type === "thank_you") return;
    const idxOf = questions.findIndex((q) => q.id === qid);
    const { error } = await supabase.from("questions").delete().eq("id", qid);
    if (error) return toast.error(error.message);
    if (activeId === qid) {
      const next = questions[idxOf - 1] || questions[idxOf + 1];
      setActiveId(next ? next.id : null);
    }
    await loadQuestions();
    toast.success("Question deleted", {
      action: {
        label: "Undo",
        onClick: async () => {
          const { error: insErr } = await supabase.from("questions").insert({
            id: snap.id,
            form_id: form.id,
            type: snap.type,
            label: snap.label,
            description: snap.description,
            placeholder: snap.placeholder,
            required: snap.required,
            options: snap.options as any,
            order_index: snap.order_index,
          });
          if (insErr) return toast.error("Couldn't undo: " + insErr.message);
          await loadQuestions();
          setActiveId(snap.id);
        },
      },
      duration: 5000,
    });
  };

  const switchMode = (m: "edit" | "preview") => {
    setMode(m);
    setModeHint(m === "edit" ? "Edit mode" : "Preview mode");
    setTimeout(() => setModeHint(null), 1800);
  };

  const StaticItem = ({ q, num }: { q: SlideQuestion; num: string }) => (
    <div
      className={`group w-full flex items-center gap-1 rounded-md transition-colors border-l-2 ${
        activeId === q.id ? "bg-secondary border-foreground" : "border-transparent hover:bg-secondary/50"
      }`}
    >
      <button onClick={() => setActiveId(q.id)} className="flex-1 text-left px-3 py-2 text-sm flex items-center gap-2 min-w-0">
        <span className="text-xs text-muted-foreground w-6 shrink-0">{num}</span>
        <span className="truncate">{q.label || "Untitled"}</span>
      </button>
      <button
        onClick={(e) => { e.stopPropagation(); handleDeleteQuestion(q.id); }}
        className="opacity-0 group-hover:opacity-100 p-1 mr-1 text-muted-foreground hover:text-destructive rounded"
        aria-label="Delete question"
      >
        <X className="h-3 w-3" />
      </button>
    </div>
  );

  const moveQuestion = async (qid: string, direction: -1 | 1) => {
    const idx = middle.findIndex((m) => m.id === qid);
    if (idx < 0) return;
    const newIdx = idx + direction;
    if (newIdx < 0 || newIdx >= middle.length) return;
    const newMiddle = arrayMove(middle, idx, newIdx);
    const prevQuestions = questions;
    const updated = questions.map((q) => {
      if (q.type === "welcome" || q.type === "thank_you") return q;
      const i = newMiddle.findIndex((m) => m.id === q.id);
      return { ...q, order_index: i + 1 };
    });
    setQuestions(updated);
    setActiveId(qid);
    const results = await Promise.all(
      newMiddle.map((q, i) => supabase.from("questions").update({ order_index: i + 1 }).eq("id", q.id)),
    );
    if (results.some((r) => r.error)) {
      setQuestions(prevQuestions);
      toast.error("Failed to save new order. Please try again.");
    }
  };






  const SortableItem = ({ q, num, index, total }: { q: SlideQuestion; num: string; index: number; total: number }) => {
    const { attributes, listeners, setNodeRef, transform, transition, isDragging, isOver } = useSortable({ id: q.id });
    const style: React.CSSProperties = {
      transform: CSS.Transform.toString(transform),
      transition,
      zIndex: isDragging ? 50 : undefined,
    };
    const isFirst = index === 0;
    const isLast = index === total - 1;
    return (
      <div
        ref={setNodeRef}
        style={style}
        className={`group relative w-full flex items-center gap-0.5 rounded-md border-l-2 bg-background ${
          activeId === q.id ? "bg-secondary border-foreground ring-1 ring-foreground/20" : "border-transparent hover:bg-secondary/50"
        } ${isDragging ? "shadow-lg scale-[1.02] !bg-background" : "transition-colors"} ${isOver && !isDragging ? "before:absolute before:left-0 before:right-0 before:-top-px before:h-0.5 before:bg-primary before:rounded-full" : ""}`}
      >
        <button
          {...attributes}
          {...listeners}
          aria-label="Drag to reorder"
          className="px-1 py-2 text-muted-foreground/60 hover:text-foreground cursor-grab active:cursor-grabbing touch-none"
        >
          <GripVertical className="h-4 w-4" />
        </button>
        <button onClick={() => setActiveId(q.id)} className="flex-1 text-left px-1 py-2 text-sm flex items-center gap-2 min-w-0">
          <span className="text-xs text-muted-foreground w-6 shrink-0">{num}</span>
          <span className="truncate">{q.label || "Untitled"}</span>
        </button>
        <button
          onClick={(e) => { e.stopPropagation(); moveQuestion(q.id, -1); }}
          disabled={isFirst}
          className="p-1 text-muted-foreground hover:text-foreground rounded disabled:opacity-30 disabled:cursor-not-allowed"
          aria-label="Move question up"
          title="Move up"
        >
          <ArrowUp className="h-3.5 w-3.5" />
        </button>
        <button
          onClick={(e) => { e.stopPropagation(); moveQuestion(q.id, 1); }}
          disabled={isLast}
          className="p-1 text-muted-foreground hover:text-foreground rounded disabled:opacity-30 disabled:cursor-not-allowed"
          aria-label="Move question down"
          title="Move down"
        >
          <ArrowDown className="h-3.5 w-3.5" />
        </button>
        <button
          onClick={(e) => { e.stopPropagation(); handleDuplicateQuestion(q.id); }}
          className="opacity-0 group-hover:opacity-100 md:opacity-0 max-md:opacity-100 p-1 text-muted-foreground hover:text-foreground rounded"
          aria-label="Duplicate question"
          title="Duplicate"
        >
          <Copy className="h-3 w-3" />
        </button>
        <button
          onClick={(e) => { e.stopPropagation(); handleDeleteQuestion(q.id); }}
          className="opacity-0 group-hover:opacity-100 md:opacity-0 max-md:opacity-100 p-1 mr-1 text-muted-foreground hover:text-destructive rounded"
          aria-label="Delete question"
        >
          <X className="h-3 w-3" />
        </button>
      </div>
    );
  };


  const handleDragEnd = async (event: DragEndEvent) => {
    const { active, over } = event;
    if (!over || active.id === over.id) return;
    const oldIdx = middle.findIndex((q) => q.id === active.id);
    const newIdx = middle.findIndex((q) => q.id === over.id);
    if (oldIdx < 0 || newIdx < 0) return;
    const newMiddle = arrayMove(middle, oldIdx, newIdx);
    const prevQuestions = questions;
    // Optimistic: assign 1..N to middle items
    const updated = questions.map((q) => {
      if (q.type === "welcome" || q.type === "thank_you") return q;
      const i = newMiddle.findIndex((m) => m.id === q.id);
      return { ...q, order_index: i + 1 };
    });
    setQuestions(updated);
    const results = await Promise.all(
      newMiddle.map((q, i) => supabase.from("questions").update({ order_index: i + 1 }).eq("id", q.id)),
    );
    if (results.some((r) => r.error)) {
      setQuestions(prevQuestions);
      toast.error("Failed to save new order. Please try again.");
    }
  };

  const middleIdx =
    active && active.type !== "welcome" && active.type !== "thank_you"
      ? middle.findIndex((q) => q.id === active.id) + 1
      : 0;

  const settingsContent = <QuestionSettings question={active} formId={id || ""} onUpdate={(patch) => active && updateQuestion(active.id, patch)} />;

  const QuestionsList = (
    <>
      <div className="flex items-center justify-between mb-3">
        <h3 className="text-sm font-semibold">Questions</h3>
        <Button size="sm" variant="ghost" onClick={() => { setPickerOpen(true); setMobileQsOpen(false); }} aria-label="Add question">
          <Plus className="h-3 w-3 mr-1" /> Add
        </Button>
      </div>
      {loadingQs ? (
        <div className="space-y-2" aria-busy="true">
          {[0, 1, 2, 3].map((i) => <Skeleton key={i} className="h-8 w-full" />)}
        </div>
      ) : (
        <>
          <div className="space-y-1">
            {welcome && <StaticItem q={welcome} num="◉" />}
            <DndContext sensors={sensors} collisionDetection={closestCenter} onDragEnd={handleDragEnd}>
              <SortableContext items={middle.map((q) => q.id)} strategy={verticalListSortingStrategy}>
                {middle.map((q, i) => (
                  <SortableItem key={q.id} q={q} num={String(i + 1)} index={i} total={middle.length} />
                ))}
              </SortableContext>
            </DndContext>
          </div>
          {thanks && (
            <div className="mt-6">
              <h4 className="text-xs uppercase tracking-wide text-muted-foreground mb-2 px-3">Endings</h4>
              <StaticItem q={thanks} num="✓" />
            </div>
          )}
        </>
      )}
    </>
  );

  const goPrevQuestion = () => {
    const idx = questions.findIndex((q) => q.id === activeId);
    if (idx > 0) setActiveId(questions[idx - 1].id);
  };
  const goNextQuestion = () => {
    const idx = questions.findIndex((q) => q.id === activeId);
    if (idx >= 0 && idx < questions.length - 1) setActiveId(questions[idx + 1].id);
  };

  return (
    <div className="min-h-screen flex flex-col bg-background">
      <FormTopBar form={form} onChange={refresh} active="build" />
      <PositionTitleSection formId={form.id} formTitle={form.title} onTitleSynced={refresh} />

      {/* Mobile top bar — three icon buttons */}
      <div className="lg:hidden sticky top-0 z-20 border-b border-border bg-background h-14 flex items-center justify-around px-4">
        <Sheet open={mobileQsOpen} onOpenChange={setMobileQsOpen}>
          <SheetTrigger asChild>
            <Button variant="ghost" size="icon" className="h-11 w-11" aria-label="Open questions list">
              <List className="h-5 w-5" />
            </Button>
          </SheetTrigger>
          <SheetContent side="left" className="w-[85vw] sm:w-[320px] overflow-y-auto">
            <SheetHeader>
              <SheetTitle>Questions</SheetTitle>
            </SheetHeader>
            <div className="mt-4">{QuestionsList}</div>
          </SheetContent>
        </Sheet>

        <div className="relative">
          <Button
            variant="ghost"
            size="icon"
            className="h-11 w-11"
            onClick={() => switchMode(mode === "edit" ? "preview" : "edit")}
            aria-label={mode === "edit" ? "Switch to preview mode" : "Switch to edit mode"}
          >
            {mode === "edit" ? <Pencil className="h-5 w-5" /> : <Eye className="h-5 w-5" />}
          </Button>
          {modeHint && (
            <div className="absolute top-full left-1/2 -translate-x-1/2 mt-1 px-2 py-1 rounded-md bg-foreground text-background text-xs whitespace-nowrap shadow-md animate-in fade-in slide-in-from-top-1">
              {modeHint}
            </div>
          )}
        </div>

        <Sheet open={mobileSettingsOpen} onOpenChange={setMobileSettingsOpen}>
          <SheetTrigger asChild>
            <Button variant="ghost" size="icon" className="h-11 w-11" aria-label="Open question settings">
              <SettingsIcon className="h-5 w-5" />
            </Button>
          </SheetTrigger>
          <SheetContent side="right" className="w-[85vw] sm:w-[360px] overflow-y-auto">
            <SheetHeader>
              <SheetTitle>Question settings</SheetTitle>
            </SheetHeader>
            <div className="mt-4">{settingsContent}</div>
          </SheetContent>
        </Sheet>
      </div>

      {/* Desktop edit/preview toggle */}
      <div className="hidden lg:flex border-b border-border bg-background px-4 py-2 items-center gap-2">
        <Button
          variant="ghost"
          size="icon"
          className="h-7 w-7"
          onClick={() => setLeftOpen((v) => !v)}
          aria-label={leftOpen ? "Hide questions panel" : "Show questions panel"}
          title={leftOpen ? "Hide questions" : "Show questions"}
        >
          <Menu className="h-4 w-4" />
        </Button>
        <div className="flex-1" />
        <Popover>
          <PopoverTrigger asChild>
            <Button variant="outline" size="sm" className="h-7 gap-1.5" aria-label="Form theme">
              <Palette className="h-3.5 w-3.5" />
              <span className="text-xs">Theme</span>
              {themeDirty && <span className="ml-1 h-1.5 w-1.5 rounded-full bg-amber-500" aria-label="Unsaved" />}
            </Button>
          </PopoverTrigger>
          <PopoverContent align="end" className="w-64 p-2">
            <p className="text-xs font-medium text-muted-foreground px-2 pb-2">Form theme</p>
            <div className="space-y-1">
              {THEMES.map((t) => (
                <button
                  key={t.id}
                  onClick={() => setDraftTheme(t.id)}
                  className="w-full flex items-center gap-2 px-2 py-1.5 rounded-md hover:bg-secondary text-left text-sm"
                >
                  <span
                    className="h-5 w-5 rounded-full border border-border shrink-0 flex items-center justify-center"
                    style={{ background: t.bg, color: t.fg }}
                  >
                    <span className="text-[10px] font-bold">Aa</span>
                  </span>
                  <span className="flex-1">{t.name}</span>
                  {draftTheme === t.id && <Check className="h-3.5 w-3.5" />}
                </button>
              ))}
            </div>
            <div className="flex items-center gap-2 pt-2 border-t border-border mt-2">
              <Button size="sm" variant="ghost" className="flex-1 h-7 text-xs" onClick={resetTheme} disabled={!themeDirty || savingTheme}>
                Cancel
              </Button>
              <Button size="sm" className="flex-1 h-7 text-xs" onClick={saveTheme} disabled={!themeDirty || savingTheme}>
                {savingTheme ? <Loader2 className="h-3 w-3 animate-spin" /> : "Save"}
              </Button>
            </div>
            <p className="text-[10px] text-muted-foreground px-1 pt-2">
              {themeDirty ? "Preview only — Save to make it live for candidates." : "Live theme. Pick another to preview."}
            </p>
          </PopoverContent>
        </Popover>
        <TypographyPicker
          draft={draftTypo}
          saved={savedTypo}
          onChange={setDraftTypo}
          onSave={saveTypo}
          onReset={resetTypo}
          saving={savingTypo}
        />
        <div className="inline-flex border border-border rounded-md overflow-hidden">
          <button
            onClick={() => setMode("edit")}
            className={`px-3 py-1 text-xs flex items-center gap-1 ${mode === "edit" ? "bg-foreground text-background" : "bg-background text-muted-foreground"}`}
            aria-label="Edit mode"
          >
            <Pencil className="h-3 w-3" /> Edit
          </button>
          <button
            onClick={() => setMode("preview")}
            className={`px-3 py-1 text-xs flex items-center gap-1 ${mode === "preview" ? "bg-foreground text-background" : "bg-background text-muted-foreground"}`}
            aria-label="Preview mode"
          >
            <Eye className="h-3 w-3" /> Preview
          </button>
        </div>
        <Button
          variant="ghost"
          size="icon"
          className="h-7 w-7"
          onClick={() => setRightOpen((v) => !v)}
          aria-label={rightOpen ? "Hide settings panel" : "Show settings panel"}
          title={rightOpen ? "Hide settings" : "Show settings"}
        >
          {rightOpen ? <PanelRightClose className="h-4 w-4" /> : <PanelRightOpen className="h-4 w-4" />}
        </Button>
      </div>

      <div className={`flex-1 grid grid-cols-1 pb-20 lg:pb-0 ${leftOpen && rightOpen ? "lg:grid-cols-[250px_1fr_320px]" : leftOpen ? "lg:grid-cols-[250px_1fr]" : rightOpen ? "lg:grid-cols-[1fr_320px]" : "lg:grid-cols-1"}`}>
        {/* LEFT - desktop only */}
        {leftOpen && (
          <aside className="hidden lg:block border-r border-border p-4 overflow-y-auto">
            {QuestionsList}
          </aside>
        )}

        {/* CENTER */}
        <section className="p-6 md:p-8 flex items-center justify-center bg-secondary/30 relative">
          {mode === "preview" && (
            <div className="absolute top-2 left-1/2 -translate-x-1/2 px-3 py-1 rounded-full bg-amber-50 border border-amber-200 text-amber-800 text-xs z-10">
              Preview mode — answers are not saved
            </div>
          )}
          {mode === "preview" ? (
            <div className="w-full ftype-scope" style={typoStyle}>
              <SlideRunner questions={questions} mode="preview" activeId={activeId} theme={draftTheme} />
            </div>
          ) : active ? (
            <div className={`relative w-full min-h-[60vh] flex items-center justify-center ftype-scope ${themeClass}`} style={typoStyle}>
              <EiaWordmark align="right" className="absolute top-4 right-4 md:top-5 md:right-6 z-20 pointer-events-none select-none" />
              <Slide
                key={active.id}
                question={active}
                index={middleIdx}
                mode="edit"
                onUpdateLabel={(label) => updateQuestion(active.id, { label })}
                onUpdateDescription={(description) => updateQuestion(active.id, { description })}
              />
            </div>
          ) : (
            <div className="text-center max-w-sm mx-auto">
              <div className="mx-auto mb-4 h-12 w-12 rounded-full bg-background flex items-center justify-center border border-border">
                <Inbox className="h-6 w-6 text-muted-foreground" />
              </div>
              <p className="text-sm text-muted-foreground">
                Select a question on the left to edit, or click "+ Add" to create a new one.
              </p>
            </div>
          )}
        </section>

        {/* RIGHT - Desktop only */}
        {rightOpen && (
          <aside className="hidden lg:block border-l border-border p-4 overflow-y-auto">
            {settingsContent}
          </aside>
        )}
      </div>

      {/* Mobile bottom bar */}
      <div
        className="lg:hidden fixed bottom-0 left-0 right-0 z-30 border-t border-border bg-background flex items-center justify-between px-4 py-3"
        style={{ boxShadow: "0 -2px 8px rgba(0,0,0,0.04)", paddingBottom: "calc(0.75rem + env(safe-area-inset-bottom))" }}
      >
        <Button
          variant="ghost"
          size="icon"
          onClick={goPrevQuestion}
          disabled={(() => { const i = questions.findIndex(q => q.id === activeId); return i <= 0; })()}
          aria-label="Previous question"
        >
          <ChevronLeft className="h-5 w-5" />
        </Button>
        <Button onClick={() => setPickerOpen(true)} className="rounded-full px-6" aria-label="Add question">
          <Plus className="h-4 w-4 mr-1" /> Add
        </Button>
        <Button
          variant="ghost"
          size="icon"
          onClick={goNextQuestion}
          disabled={(() => { const i = questions.findIndex(q => q.id === activeId); return i < 0 || i >= questions.length - 1; })()}
          aria-label="Next question"
        >
          <ChevronRight className="h-5 w-5" />
        </Button>
      </div>

      <QuestionPicker open={pickerOpen} onOpenChange={setPickerOpen} onPick={handleAddQuestion} />

    </div>
  );
};

export default Builder;
