import StageTrackingView from "@/components/StageTrackingView";
export default function MyBookings() { return <StageTrackingView mode="bookings" />; }
