import { useEffect, useRef, useState } from "react";
import { useParams } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Loader2, CheckCircle2, Upload as UploadIcon, Lock, Copy, Check } from "lucide-react";
import { toast } from "sonner";
import EiaWordmark from "@/components/EiaWordmark";
import { uploadPublicStorageObject } from "@/lib/publicStorageUpload";
import { usePageSeo } from "@/components/PageSeo";

const NAVY = "#1a2547";
const GOLD = "#b08d57";
const CREAM = "#faf8f3";
const BUCKET = "candidate-files";

type Validate = {
  valid: boolean;
  reason?: string;
  response_id?: string;
  expires_at?: string;
  prefill?: { full_name: string; email: string; position_title: string; phone: string };
  hr_extras?: { bank_account_details: string; digital_pay_gcash: string; other_notes: string };
  existing_photo_path?: string | null;
  existing_photo_url?: string | null;
  submission?: any;
};

const SectionLabel = ({ children }: { children: React.ReactNode }) => (
  <div style={{ fontFamily: "'Inter', sans-serif", fontWeight: 600, fontSize: 11, color: GOLD, textTransform: "uppercase", letterSpacing: 3 }}>
    {children}
  </div>
);

const PageShell = ({ subtitle, children }: { subtitle: string; children: React.ReactNode }) => (
  <div className="min-h-screen" style={{ backgroundColor: CREAM }}>
    <div className="max-w-2xl mx-auto px-6 py-10 md:py-14">
      <div className="mb-8 flex justify-center">
        <EiaWordmark subtitle={subtitle} align="center" />
      </div>
      {children}
      <div className="mt-10 text-center text-xs text-muted-foreground">
        &copy; {new Date().getFullYear()} Expert Intuitive Advisor Inc.
      </div>
    </div>
  </div>
);

type UploadKind = "photo" | "speedtest" | "typing";

function useUploader(responseId: string | undefined, kind: UploadKind) {
  const [uploading, setUploading] = useState(false);
  const [url, setUrl] = useState<string | null>(null);
  const [displayUrl, setDisplayUrl] = useState<string | null>(null);
  const [fileName, setFileName] = useState<string | null>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  const upload = async (file: File) => {
    if (!responseId) {
      toast.error("Link not ready yet");
      return;
    }
    setUploading(true);
    try {
      const ext = (file.name.split(".").pop() || "jpg").toLowerCase();
      const ts = Date.now();
      const path = `responses/${responseId}/onboarding/${kind}/${ts}.${ext}`;
      const contentType = file.type || "application/octet-stream";
      // Force the anon publishable key as the Authorization header (same helper
      // PublicForm uses) so a stale/non-anon localStorage session token can't
      // make this request fail the anon-insert storage policy.
      try {
        await uploadPublicStorageObject({ bucket: BUCKET, path, file, contentType });
      } catch (e: any) {
        toast.error(`Upload failed: ${e?.message || "Please try again."}`);
        return;
      }
      setUrl(`${BUCKET}/${path}`);
      setFileName(file.name);
      // Best-effort preview via signed URL
      try {
        const { data: signed } = await supabase.storage.from(BUCKET).createSignedUrl(path, 3600);
        if (signed?.signedUrl) setDisplayUrl(signed.signedUrl);
      } catch {}
    } finally {
      setUploading(false);
    }
  };

  return { uploading, url, displayUrl, fileName, inputRef, upload, setUrl, setDisplayUrl, setFileName };
}

function CopyUrlButton({ url }: { url: string }) {
  const [copied, setCopied] = useState(false);
  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(url);
      setCopied(true);
      setTimeout(() => setCopied(false), 1500);
    } catch {
      toast.error("Could not copy link");
    }
  };
  return (
    <button
      type="button"
      onClick={handleCopy}
      aria-label={copied ? "Link copied" : "Copy link"}
      title={copied ? "Copied" : "Copy link"}
      className="inline-flex items-center align-middle ml-1 rounded p-0.5 hover:bg-muted transition-colors"
      style={{ color: copied ? "#16a34a" : NAVY }}
    >
      {copied ? <Check className="h-3.5 w-3.5" /> : <Copy className="h-3.5 w-3.5" />}
    </button>
  );
}

function SiteLink({ href, label }: { href: string; label: string }) {
  return (
    <a
      href={href}
      target="_blank"
      rel="noopener noreferrer"
      className="underline font-medium"
      style={{ color: NAVY }}
    >
      {label}
    </a>
  );
}

function RequiredMark() {
  return (
    <>
      {" "}<span style={{ color: "#dc2626" }}>*</span>{" "}
      <span className="text-xs font-medium" style={{ color: "#dc2626" }}>required</span>
    </>
  );
}



function FileBlock({
  label, instruction, accept, uploader, kind,
}: {
  label: string; instruction: React.ReactNode; accept: string;
  uploader: ReturnType<typeof useUploader>; kind: UploadKind;
}) {
  const done = !!uploader.url;
  return (
    <div className="space-y-2">
      <div className="flex items-center justify-between">
        <Label className="text-base font-medium" style={{ color: NAVY }}>{label}<RequiredMark /></Label>
        {done && <span className="text-sm flex items-center gap-1" style={{ color: "#16a34a" }}><CheckCircle2 className="h-3.5 w-3.5" /> Uploaded</span>}
      </div>
      <p className="text-sm text-muted-foreground">{instruction}</p>
      <input
        ref={uploader.inputRef}
        type="file"
        accept={accept}
        className="hidden"
        onChange={(e) => { const f = e.target.files?.[0]; if (f) uploader.upload(f); }}
      />
      <div className="flex items-center gap-3">
        <Button
          type="button"
          variant="outline"
          disabled={uploader.uploading}
          onClick={() => uploader.inputRef.current?.click()}
          style={{ borderColor: done ? "#16a34a" : `${GOLD}88`, color: NAVY }}
        >
          {uploader.uploading ? <Loader2 className="h-4 w-4 animate-spin mr-2" /> : <UploadIcon className="h-4 w-4 mr-2" />}
          {done ? "Replace file" : `Upload ${kind === "photo" ? "photo" : "screenshot"}`}
        </Button>
        {uploader.fileName && <span className="text-sm text-muted-foreground truncate max-w-[220px]">{uploader.fileName}</span>}
      </div>
      {uploader.displayUrl && kind === "photo" && (
        <img src={uploader.displayUrl} alt="Profile preview" className="mt-2 h-32 w-32 object-cover rounded-md border" style={{ borderColor: `${GOLD}55` }} />
      )}
      {uploader.displayUrl && kind !== "photo" && (
        <a href={uploader.displayUrl} target="_blank" rel="noreferrer" className="text-sm underline" style={{ color: NAVY }}>Preview uploaded screenshot</a>
      )}
    </div>
  );
}

function LockedPhotoBlock({ url }: { url: string }) {
  return (
    <div className="space-y-2">
      <div className="flex items-center gap-2">
        <Label className="text-base font-medium text-muted-foreground">Profile photo</Label>
        <Lock className="h-3.5 w-3.5 text-muted-foreground" />
      </div>
      <p className="text-sm text-muted-foreground">This is the photo we have on file from your application. It can't be changed here.</p>
      <img
        src={url}
        alt="Profile photo on file"
        className="mt-2 h-32 w-32 object-cover rounded-md border"
        style={{ borderColor: `${GOLD}55` }}
      />
    </div>
  );
}



export default function Onboarding() {
  const { token } = useParams<{ token: string }>();
  usePageSeo({
    title: "New Hire Onboarding — EIA Talent",
    description: "Finish your onboarding with Expert Intuitive Advisor Inc. Confirm your details and upload the required documents to complete your hire.",
    path: token ? `/onboarding/${token}` : undefined,
  });
  const [loading, setLoading] = useState(true);
  const [info, setInfo] = useState<Validate | null>(null);
  const [submitting, setSubmitting] = useState(false);
  const [done, setDone] = useState(false);

  const [fullName, setFullName] = useState("");
  const [email, setEmail] = useState("");
  const [position, setPosition] = useState("");
  const [phone, setPhone] = useState("");
  const [onlinejobsUrl, setOnlinejobsUrl] = useState("");


  const [hrBank, setHrBank] = useState("");
  const [gcash, setGcash] = useState("");
  const [hrNotes, setHrNotes] = useState("");

  // When the candidate already has a profile photo on file (same one shown on
  // the form Results page), we lock the upload and show it read-only.
  const [lockedPhotoUrl, setLockedPhotoUrl] = useState<string | null>(null);

  // Universal (response-less) tokens have no response_id — fall back to the
  // token itself as the storage namespace so uploads still work.
  const uploadKey = info?.response_id || token;
  const photo = useUploader(uploadKey, "photo");
  const speed = useUploader(uploadKey, "speedtest");
  const typing = useUploader(uploadKey, "typing");

  useEffect(() => {
    if (!token) return;
    (async () => {
      const { data } = await supabase.functions.invoke<Validate>("validate-onboarding-token", { body: { token } });
      const v = data || { valid: false };
      setInfo(v);
      if (v.valid) {
        setFullName(v.prefill?.full_name || "");
        setEmail(v.prefill?.email || "");
        setPosition(v.prefill?.position_title || "");
        setPhone(v.prefill?.phone || "");
        setHrBank(v.hr_extras?.bank_account_details || "");
        setGcash(v.hr_extras?.digital_pay_gcash || "");
        setHrNotes(v.hr_extras?.other_notes || "");

        // Pre-fill + lock the profile photo with the candidate's existing
        // photo on file (the same image rendered on the Results page).
        if (v.existing_photo_path && v.existing_photo_url) {
          photo.setUrl(v.existing_photo_path);
          photo.setDisplayUrl(v.existing_photo_url);
          setLockedPhotoUrl(v.existing_photo_url);
        }

        const sub = v.submission;
        if (sub) {
          if (sub.profile_photo_url) photo.setUrl(sub.profile_photo_url);
          if (sub.speedtest_screenshot_url) speed.setUrl(sub.speedtest_screenshot_url);
          if (sub.typing_screenshot_url) typing.setUrl(sub.typing_screenshot_url);
          if (sub.phone) setPhone(sub.phone);
          if (sub.full_name) setFullName(sub.full_name);
          if (sub.email) setEmail(sub.email);
          setOnlinejobsUrl(sub.onlinejobs_profile_url ?? "");
          setGcash(sub.digital_pay_gcash ?? (v.hr_extras?.digital_pay_gcash || ""));
        }
      }
      setLoading(false);
    })();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [token]);

  const canSubmit = !!photo.url && !!speed.url && !!typing.url && !!gcash.trim() && !!onlinejobsUrl.trim() && !submitting;

  const submit = async () => {
    if (!token) return;
    if (!photo.url || !speed.url || !typing.url) {
      toast.error("Please upload your photo, speed-test screenshot, and typing screenshot before submitting.");
      return;
    }
    if (!gcash.trim()) {
      toast.error("Please enter your Digital Pay / GCash details before submitting.");
      return;
    }
    if (!onlinejobsUrl.trim()) {
      toast.error("Please enter your OnlineJobs.ph profile link before submitting.");
      return;
    }
    setSubmitting(true);
    try {
      const { data, error } = await supabase.functions.invoke<any>("submit-onboarding", {
        body: {
          token,
          full_name: fullName,
          email,
          phone,
          onlinejobs_profile_url: onlinejobsUrl.trim() || null,
          digital_pay_gcash: gcash.trim() || null,
          profile_photo_url: photo.url,
          speedtest_screenshot_url: speed.url,
          typing_screenshot_url: typing.url,
        },
      });
      if (error || data?.error) {
        toast.error(data?.error || "Could not submit. Please try again.");
        return;
      }
      setDone(true);
    } finally {
      setSubmitting(false);
    }
  };

  if (loading) {
    return (
      <PageShell subtitle="ONBOARDING">
        <div className="flex items-center justify-center py-20">
          <Loader2 className="h-6 w-6 animate-spin" style={{ color: NAVY }} />
        </div>
      </PageShell>
    );
  }

  if (!info?.valid) {
    return (
      <PageShell subtitle="ONBOARDING">
        <Card className="border-0 shadow-sm">
          <CardContent className="pt-8 pb-8 text-center space-y-3">
            <SectionLabel>Link Unavailable</SectionLabel>
            <h2 style={{ fontFamily: "'Cormorant Garamond', serif", fontWeight: 600, fontSize: 26, color: NAVY }}>
              This onboarding link is no longer active
            </h2>
            <p className="text-sm text-muted-foreground max-w-md mx-auto">
              Please contact us and we'll send you a fresh link.
            </p>
          </CardContent>
        </Card>
      </PageShell>
    );
  }

  if (done) {
    return (
      <PageShell subtitle="ONBOARDING">
        <Card className="border-0 shadow-sm">
          <CardContent className="pt-8 pb-8 text-center space-y-4">
            <CheckCircle2 className="h-12 w-12 mx-auto" style={{ color: "#16a34a" }} />
            <SectionLabel>Onboarding Received</SectionLabel>
            <h2 style={{ fontFamily: "'Cormorant Garamond', serif", fontWeight: 600, fontSize: 28, color: NAVY, lineHeight: 1.1 }}>
              Thank you, {(fullName || "").split(" ")[0] || "you're all set"}
            </h2>
            <p className="text-sm md:text-base max-w-md mx-auto" style={{ color: NAVY }}>
              Please add your onboarding specialist <strong>Sylvia</strong> on WhatsApp:
            </p>
            <p className="text-xl font-semibold" style={{ color: NAVY }}>+1 917 735 8220</p>
            <p className="text-sm text-muted-foreground max-w-md mx-auto">
              She will guide you through your next steps. You can revisit this link any time within the next 30 days to update your information.
            </p>
          </CardContent>
        </Card>
      </PageShell>
    );
  }

  const LockedField = ({
    id, value, type = "text",
  }: { id: string; value: string; type?: string }) => (
    <div className="relative">
      <Input
        id={id}
        type={type}
        value={value}
        readOnly
        disabled
        className="bg-muted/60 text-muted-foreground cursor-not-allowed"
      />
      <Lock className="h-3.5 w-3.5 absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
    </div>
  );

  return (
    <PageShell subtitle="ONBOARDING">
      <div className="text-center mb-6 space-y-2">
        <SectionLabel>Welcome Aboard</SectionLabel>
        <h1 style={{ fontFamily: "'Cormorant Garamond', serif", fontWeight: 600, fontSize: 32, color: NAVY, lineHeight: 1.1 }}>
          Your Onboarding Form
        </h1>
        <p className="text-base text-muted-foreground max-w-xl mx-auto">
          Please upload your photo and the two screenshots below, and confirm your details. This link stays active for 30 days.
        </p>
      </div>

      <Card className="border-0 shadow-sm">
        <CardContent className="p-6 md:p-8 space-y-7">

          {lockedPhotoUrl ? (
            <LockedPhotoBlock url={lockedPhotoUrl} />
          ) : (
            <FileBlock
              label="Profile photo"
              instruction="A clear, professional photo of yourself (a photo ID-style headshot works best)."
              accept="image/*"
              uploader={photo}
              kind="photo"
            />
          )}

          <div className="border-t pt-5 space-y-4">
            <SectionLabel>Your Details</SectionLabel>

            <div className="space-y-1.5">
              <Label className="text-base font-medium" style={{ color: NAVY }}>Full name</Label>
              <LockedField id="full_name" value={fullName} />
            </div>

            <div className="space-y-1.5">
              <Label className="text-base font-medium" style={{ color: NAVY }}>Email</Label>
              <LockedField id="email" value={email} type="email" />
            </div>

            <div className="space-y-1.5">
              <Label className="text-base font-medium" style={{ color: NAVY }}>Position</Label>
              <LockedField id="position" value={position} />
            </div>

            <div className="space-y-1.5">
              <Label className="text-base font-medium" style={{ color: NAVY }}>Phone</Label>
              <Input value={phone} onChange={(e) => setPhone(e.target.value)} placeholder="e.g. +63 9XX XXX XXXX" />
            </div>

            <div className="space-y-1.5">
              <Label className="text-base font-medium" style={{ color: NAVY }}>OnlineJobs.ph Profile Link<RequiredMark /></Label>
              <Input
                type="url"
                value={onlinejobsUrl}
                onChange={(e) => setOnlinejobsUrl(e.target.value)}
                placeholder="https://www.onlinejobs.ph/jobseekers/info/..."
              />
              <p className="text-sm text-muted-foreground">Paste your OnlineJobs.ph profile URL.</p>
            </div>
          </div>

          <div className="border-t pt-5">
            <FileBlock
              label="Internet speed-test screenshot"
              instruction={<>Open <SiteLink href="https://www.speedtest.net" label="speedtest.net" /><CopyUrlButton url="https://www.speedtest.net" />, run the test, screenshot the result, and upload it here.</>}
              accept="image/*"
              uploader={speed}
              kind="speedtest"
            />
          </div>

          <div className="border-t pt-5">
            <FileBlock
              label="Typing-test screenshot"
              instruction={<>Go to <SiteLink href="https://www.10fastfingers.com" label="www.10fastfingers.com" /><CopyUrlButton url="https://www.10fastfingers.com" />, take the 1-minute typing test, screenshot your result, and upload it here.</>}
              accept="image/*"
              uploader={typing}
              kind="typing"
            />
          </div>

          <div className="border-t pt-5 space-y-1.5">
            <Label className="text-base font-medium" style={{ color: NAVY }}>Digital Pay / GCash<RequiredMark /></Label>
            <Input
              value={gcash}
              onChange={(e) => setGcash(e.target.value)}
              placeholder="Your GCash number or digital pay details"
            />
            <p className="text-sm text-muted-foreground">Enter your GCash or preferred digital pay details.</p>
          </div>

          <div className="border-t pt-5 space-y-4">
            <div className="flex items-center gap-2">
              <Lock className="h-3.5 w-3.5 text-muted-foreground" />
              <SectionLabel>HR Use Only</SectionLabel>
              <span className="text-xs text-muted-foreground uppercase tracking-wider">— you cannot edit this</span>
            </div>

            <div className="space-y-1.5">
              <Label className="text-base font-medium text-muted-foreground">Bank Account Details</Label>
              <div className="relative">
                <Input
                  value={hrBank}
                  disabled
                  placeholder="To be completed by HR"
                  className="bg-muted/60 text-muted-foreground cursor-not-allowed"
                />
                <Lock className="h-3.5 w-3.5 absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
              </div>
            </div>


            <div className="space-y-1.5">
              <Label className="text-base font-medium text-muted-foreground">Others</Label>
              <div className="relative">
                <Input
                  value={hrNotes}
                  disabled
                  placeholder="To be completed by HR"
                  className="bg-muted/60 text-muted-foreground cursor-not-allowed"
                />
                <Lock className="h-3.5 w-3.5 absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
              </div>
            </div>
          </div>

          <div className="border-t pt-5 flex flex-col items-center gap-2">
            <Button
              disabled={!canSubmit}
              onClick={submit}
              style={{ backgroundColor: canSubmit ? NAVY : "#9ca3af", color: "#fff" }}
              className="min-w-[220px] h-11"
            >
              {submitting ? <><Loader2 className="h-4 w-4 animate-spin mr-2" /> Submitting…</> : "Submit Onboarding"}
            </Button>
            {!canSubmit && !submitting && (
              <p className="text-sm text-muted-foreground">All three uploads and your Digital Pay / GCash details are required.</p>
            )}
          </div>

        </CardContent>
      </Card>
    </PageShell>
  );
}
