import { lazy, Suspense } from "react";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Route, Routes, Navigate, useParams } from "react-router-dom";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { AuthProvider } from "@/hooks/useAuth";
import { ProtectedRoute, RootRedirect } from "@/components/ProtectedRoute";
import Login from "./pages/Login";
import Dashboard from "./pages/Dashboard";
import NotFound from "./pages/NotFound";
import RouteProgress from "@/components/RouteProgress";
import { FullPageLoader } from "@/components/FullPageLoader";

const Builder = lazy(() => import("./pages/Builder"));
const Share = lazy(() => import("./pages/Share"));
const Results = lazy(() => import("./pages/Results"));
const PublicForm = lazy(() => import("./pages/PublicForm"));
const JobScopeLibrary = lazy(() => import("./pages/JobScopeLibrary"));
const BookingsDashboard = lazy(() => import("./pages/BookingsDashboard"));
const BookingStats = lazy(() => import("./pages/BookingStats"));
const EmployeesDashboard = lazy(() => import("./pages/EmployeesDashboard"));
const SylviaDashboard = lazy(() => import("./pages/SylviaDashboard"));
const QuarantineDashboard = lazy(() => import("./pages/QuarantineDashboard"));
const SickLeavesDashboard = lazy(() => import("./pages/SickLeavesDashboard"));
const SignedDocumentsDashboard = lazy(() => import("./pages/SignedDocumentsDashboard"));
const OutOfOfficeDashboard = lazy(() => import("./pages/OutOfOfficeDashboard"));
const Rebook = lazy(() => import("./pages/Rebook"));
const AiInterview = lazy(() => import("./pages/AiInterview"));
const Track = lazy(() => import("./pages/Track"));
const Onboarding = lazy(() => import("./pages/Onboarding"));
const OnboardingTest = lazy(() => import("./pages/OnboardingTest"));
const OnboardingSubmissionView = lazy(() => import("./pages/OnboardingSubmissionView"));
const LeaveRequest = lazy(() => import("./pages/LeaveRequest"));
const CashAdvanceRequest = lazy(() => import("./pages/CashAdvanceRequest"));
const PreConsultationRequest = lazy(() => import("./pages/PreConsultationRequest"));
const IdCollectionRequest = lazy(() => import("./pages/IdCollectionRequest"));
import InterviewErrorBoundary from "@/components/InterviewErrorBoundary";
const AllCandidates = lazy(() => import("./pages/AllCandidates"));
const MyBookings = lazy(() => import("./pages/MyBookings"));

const Disqualified = lazy(() => import("./pages/Disqualified"));
const AiInterviews = lazy(() => import("./pages/AiInterviews"));
const AiInterviewReport = lazy(() => import("./pages/AiInterviewReport"));
const CandidateWall = lazy(() => import("./pages/CandidateWall"));
const NotificationCenter = lazy(() => import("./pages/NotificationCenter"));
const Settings = lazy(() => import("./pages/Settings"));
const LaunchDashboard = lazy(() => import("./pages/LaunchDashboard"));
const CircularRecipients = lazy(() => import("./pages/CircularRecipients"));
const CircularCompose = lazy(() => import("./pages/CircularCompose"));
const Circular = lazy(() => import("./pages/Circular"));
const CircularsList = lazy(() => import("./pages/CircularsList"));
const WhatsAppChat = lazy(() => import("./pages/WhatsAppChat"));


const BookingsRedirect = () => {
  const { id } = useParams();
  return <Navigate to={`/forms/${id}/results`} replace />;
};

const queryClient = new QueryClient();

const RouteFallback = () => <FullPageLoader />;

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <Toaster />
      <Sonner />
      <BrowserRouter>
        <AuthProvider>
          <RouteProgress />
          <Suspense fallback={<RouteFallback />}>
            <Routes>
              <Route path="/" element={<RootRedirect />} />
              <Route path="/login" element={<Login />} />
              <Route path="/form/:slug" element={<PublicForm />} />
              <Route path="/rebook/:token" element={<Rebook />} />
              <Route path="/ai-interview/:token" element={<InterviewErrorBoundary><AiInterview /></InterviewErrorBoundary>} />
              <Route path="/track/:token" element={<InterviewErrorBoundary><Track /></InterviewErrorBoundary>} />
              <Route path="/onboarding/:token" element={<Onboarding />} />
              <Route path="/onboarding-test/:token" element={<OnboardingTest />} />
              <Route path="/leave/:token" element={<LeaveRequest />} />
              <Route path="/cash-advance/:token" element={<CashAdvanceRequest />} />
              <Route path="/pre-consultation/:token" element={<PreConsultationRequest />} />
              <Route path="/id-collection/:token" element={<IdCollectionRequest />} />
              <Route path="/circular/:token" element={<Circular />} />
              <Route
                path="/dashboard"
                element={
                  <ProtectedRoute>
                    <Dashboard />
                  </ProtectedRoute>
                }
              />
              <Route
                path="/forms/:id"
                element={
                  <ProtectedRoute>
                    <Builder />
                  </ProtectedRoute>
                }
              />
              <Route
                path="/forms/:id/share"
                element={
                  <ProtectedRoute>
                    <Share />
                  </ProtectedRoute>
                }
              />
              <Route
                path="/forms/:id/results"
                element={
                  <ProtectedRoute>
                    <Results />
                  </ProtectedRoute>
                }
              />
              <Route
                path="/forms/:id/bookings"
                element={<BookingsRedirect />}
              />
              <Route
                path="/job-scope-library"
                element={
                  <ProtectedRoute>
                    <JobScopeLibrary />
                  </ProtectedRoute>
                }
              />
              <Route
                path="/dashboard/bookings"
                element={
                  <ProtectedRoute>
                    <BookingsDashboard />
                  </ProtectedRoute>
                }
              />
              <Route
                path="/dashboard/bookings/stats"
                element={
                  <ProtectedRoute>
                    <BookingStats />
                  </ProtectedRoute>
                }
              />
              <Route
                path="/dashboard/employees"
                element={
                  <ProtectedRoute>
                    <EmployeesDashboard />
                  </ProtectedRoute>
                }
              />
              <Route
                path="/dashboard/sylvia"
                element={
                  <ProtectedRoute>
                    <SylviaDashboard />
                  </ProtectedRoute>
                }
              />
              <Route
                path="/dashboard/quarantine"
                element={
                  <ProtectedRoute>
                    <QuarantineDashboard />
                  </ProtectedRoute>
                }
              />
              <Route
                path="/dashboard/circular-recipients"
                element={
                  <ProtectedRoute>
                    <CircularRecipients />
                  </ProtectedRoute>
                }
              />
              <Route
                path="/dashboard/circulars"
                element={
                  <ProtectedRoute>
                    <CircularsList />
                  </ProtectedRoute>
                }
              />
              <Route
                path="/dashboard/circulars/new"
                element={
                  <ProtectedRoute>
                    <CircularCompose />
                  </ProtectedRoute>
                }
              />
              <Route
                path="/dashboard/sick-leaves"
                element={
                  <ProtectedRoute>
                    <SickLeavesDashboard />
                  </ProtectedRoute>
                }
              />
              <Route
                path="/onboarding-submission/:response_id"
                element={
                  <ProtectedRoute>
                    <OnboardingSubmissionView />
                  </ProtectedRoute>
                }
              />
              <Route
                path="/dashboard/signed-documents"
                element={
                  <ProtectedRoute>
                    <SignedDocumentsDashboard />
                  </ProtectedRoute>
                }
              />
              <Route
                path="/dashboard/out-of-office"
                element={
                  <ProtectedRoute>
                    <OutOfOfficeDashboard />
                  </ProtectedRoute>
                }
              />
              <Route
                path="/dashboard/candidates"
                element={
                  <ProtectedRoute>
                    <AllCandidates />
                  </ProtectedRoute>
                }
              />
              <Route
                path="/dashboard/my-bookings"
                element={
                  <ProtectedRoute>
                    <MyBookings />
                  </ProtectedRoute>
                }
              />
              <Route
                path="/dashboard/completed"
                element={<Navigate to="/dashboard/my-bookings" replace />}
              />
              <Route
                path="/dashboard/disqualified"
                element={
                  <ProtectedRoute>
                    <Disqualified />
                  </ProtectedRoute>
                }
              />
              <Route
                path="/dashboard/ai-interviews"
                element={
                  <ProtectedRoute>
                    <AiInterviews />
                  </ProtectedRoute>
                }
              />
              <Route
                path="/dashboard/ai-interviews/:responseId/:round?"
                element={
                  <ProtectedRoute>
                    <AiInterviewReport />
                  </ProtectedRoute>
                }
              />
              <Route
                path="/dashboard/candidate-wall"
                element={
                  <ProtectedRoute>
                    <CandidateWall />
                  </ProtectedRoute>
                }
              />
              <Route
                path="/dashboard/notifications"
                element={
                  <ProtectedRoute>
                    <NotificationCenter />
                  </ProtectedRoute>
                }
              />
              <Route
                path="/dashboard/settings"
                element={
                  <ProtectedRoute>
                    <Settings />
                  </ProtectedRoute>
                }
              />
              <Route
                path="/dashboard/launch"
                element={
                  <ProtectedRoute>
                    <LaunchDashboard />
                  </ProtectedRoute>
                }
              />
              <Route
                path="/dashboard/whatsapp-chat"
                element={
                  <ProtectedRoute>
                    <WhatsAppChat />
                  </ProtectedRoute>
                }
              />
              <Route path="*" element={<NotFound />} />

            </Routes>
          </Suspense>
        </AuthProvider>
      </BrowserRouter>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;
