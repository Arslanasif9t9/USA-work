import { useEffect, useState } from "react";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Loader2, AlertTriangle } from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { parseInvokeError } from "@/lib/invokeError";

type Props = {
  open: boolean;
  onOpenChange: (o: boolean) => void;
  initialEmail?: string;
  initialName?: string;
  responseId?: string | null;
};

const MAX = 1000;
const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

export function SendPerformanceWarningDialog({ open, onOpenChange, initialEmail, initialName, responseId }: Props) {
  const [email, setEmail] = useState(initialEmail || "");
  const [name, setName] = useState(initialName || "");
  const [remarks, setRemarks] = useState("");
  const [password, setPassword] = useState("");
  const [sending, setSending] = useState(false);

  useEffect(() => {
    if (open) {
      setEmail(initialEmail || "");
      setName(initialName || "");
      setRemarks("");
      setPassword("");
    }
  }, [open, initialEmail, initialName]);

  const submit = async () => {
    if (!name.trim()) {
      toast.error("Recipient name is required");
      return;
    }
    if (!email.trim() || !EMAIL_RE.test(email.trim())) {
      toast.error("Please enter a valid recipient email");
      return;
    }
    if (!password) {
      toast.error("Password is required");
      return;
    }
    setSending(true);
    try {
      const { data, error } = await supabase.functions.invoke("send-performance-warning", {
        body: {
          recipient_email: email.trim(),
          recipient_name: name.trim(),
          remarks: remarks.trim() || undefined,
          password,
          response_id: responseId || undefined,
        },
      });
      if (error) {
        const { message } = await parseInvokeError(error, data);
        toast.error(message); // dialog stays open for retry
        return;
      }
      if ((data as any)?.error) {
        const { message } = await parseInvokeError(null, data);
        toast.error(message);
        return;
      }
      toast.success("Performance warning sent");
      onOpenChange(false);
    } catch (e: any) {
      const { message } = await parseInvokeError(e);
      toast.error(message);
    } finally {
      setSending(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={(o) => !sending && onOpenChange(o)}>
      <DialogContent className="max-w-lg w-[calc(100vw-32px)]">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2" style={{ fontFamily: "'Cormorant Garamond', serif", color: "#1a2547" }}>
            <AlertTriangle className="h-5 w-5" style={{ color: "#d97706" }} />
            Send Performance Warning
          </DialogTitle>
          <DialogDescription>
            Sends a polite-but-serious performance warning email to any name + email — employee or not. Requires the HR password.
          </DialogDescription>
        </DialogHeader>
        <div className="grid gap-3">
          <div className="grid gap-1.5">
            <Label htmlFor="spw-name">Recipient Name</Label>
            <Input id="spw-name" value={name} onChange={(e) => setName(e.target.value)} placeholder="Jane Doe" className="h-11" disabled={sending} />
          </div>
          <div className="grid gap-1.5">
            <Label htmlFor="spw-email">Recipient Email</Label>
            <Input id="spw-email" type="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="jane@example.com" className="h-11" disabled={sending} />
          </div>
          <div className="grid gap-1.5">
            <Label htmlFor="spw-remarks">Remarks (optional)</Label>
            <Textarea
              id="spw-remarks"
              value={remarks}
              onChange={(e) => setRemarks(e.target.value.slice(0, MAX))}
              rows={4}
              disabled={sending}
              placeholder="Optional — specifics to include in the email (e.g. concerns from this week). Leave blank for a generic warning."
            />
            <div className="text-xs text-muted-foreground text-right">{remarks.length} / {MAX}</div>
          </div>
          <div className="grid gap-1.5">
            <Label htmlFor="spw-pw">Password</Label>
            <Input id="spw-pw" type="password" value={password} onChange={(e) => setPassword(e.target.value)} className="h-11" disabled={sending} autoComplete="off" />
          </div>
        </div>
        <DialogFooter className="gap-2">
          <Button variant="outline" onClick={() => onOpenChange(false)} disabled={sending} className="min-h-11">Cancel</Button>
          <Button onClick={submit} disabled={sending} className="min-h-11 text-white" style={{ backgroundColor: "#d97706" }}>
            {sending ? <><Loader2 className="h-4 w-4 mr-2 animate-spin" /> Sending…</> : "Send Warning"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
