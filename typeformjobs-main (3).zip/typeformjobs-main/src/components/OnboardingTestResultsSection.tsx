import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Table, TableHeader, TableBody, TableRow, TableHead, TableCell } from "@/components/ui/table";
import { Loader2, GraduationCap, RefreshCw } from "lucide-react";
import SendOnboardingTestDialog from "@/components/SendOnboardingTestDialog";

type TokenRow = {
  id: string;
  candidate_name: string;
  candidate_email: string;
  attempts_used: number;
  status: string;
  passed: boolean;
  passed_at: string | null;
  created_at: string;
};

type AttemptRow = { token_id: string | null; score: number; total: number; created_at: string };

const STATUS_META: Record<string, { label: string; bg: string; color: string }> = {
  invited: { label: "Invited / not started", bg: "#fdf6e9", color: "#8a6d1f" },
  active: { label: "In progress", bg: "#eef2ff", color: "#3730a3" },
  passed_pending: { label: "Passed — pending HR", bg: "#dcfce7", color: "#166534" },
  passed_approved: { label: "Passed — approved", bg: "#dcfce7", color: "#166534" },
  passed_declined: { label: "Passed — declined", bg: "#fef3c7", color: "#92400e" },
  failed_out: { label: "Did not pass", bg: "#fee2e2", color: "#991b1b" },
  invalidated: { label: "Closed", bg: "#f3f4f6", color: "#374151" },
};

const fmtDate = (s: string | null) =>
  s ? new Date(s).toLocaleDateString("en-US", { year: "numeric", month: "short", day: "numeric" }) : "—";

export default function OnboardingTestResultsSection() {
  const [loading, setLoading] = useState(true);
  const [tokens, setTokens] = useState<TokenRow[]>([]);
  const [bestByToken, setBestByToken] = useState<Record<string, { score: number; total: number }>>({});

  const load = async () => {
    setLoading(true);
    const { data: toks } = await supabase
      .from("onboarding_quiz_tokens")
      .select("id, candidate_name, candidate_email, attempts_used, status, passed, passed_at, created_at")
      .order("created_at", { ascending: false });
    const { data: atts } = await supabase
      .from("onboarding_quiz_attempts")
      .select("token_id, score, total, created_at");

    const best: Record<string, { score: number; total: number }> = {};
    (atts as AttemptRow[] | null)?.forEach((a) => {
      if (!a.token_id) return;
      const cur = best[a.token_id];
      if (!cur || a.score > cur.score) best[a.token_id] = { score: a.score, total: a.total };
    });
    setBestByToken(best);
    setTokens((toks as TokenRow[]) || []);
    setLoading(false);
  };

  useEffect(() => { load(); }, []);

  return (
    <div className="mb-8 border rounded-md bg-card">
      <div className="flex items-center justify-between px-5 py-4 border-b">
        <div className="flex items-center gap-2">
          <GraduationCap className="h-5 w-5" style={{ color: "#b8860b" }} />
          <h2 className="text-lg font-semibold">Onboarding Test Results</h2>
        </div>
        <div className="flex items-center gap-2">
          <SendOnboardingTestDialog onSent={load} />
          <Button variant="ghost" size="sm" onClick={load} disabled={loading}>
            <RefreshCw className={`h-4 w-4 ${loading ? "animate-spin" : ""}`} />
          </Button>
        </div>
      </div>
      {loading ? (
        <div className="flex items-center justify-center py-12">
          <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
        </div>
      ) : tokens.length === 0 ? (
        <div className="text-center py-12 text-muted-foreground text-sm">No onboarding tests issued yet.</div>
      ) : (
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Name</TableHead>
              <TableHead>Email</TableHead>
              <TableHead>Best score</TableHead>
              <TableHead>Result</TableHead>
              <TableHead>Attempts</TableHead>
              <TableHead>Date</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {tokens.map((t) => {
              const statusKey = t.status === "active" && t.attempts_used === 0 ? "invited" : t.status;
              const meta = STATUS_META[statusKey] || STATUS_META.invalidated;
              const best = bestByToken[t.id];
              return (
                <TableRow key={t.id}>
                  <TableCell className="font-medium">{t.candidate_name}</TableCell>
                  <TableCell className="text-muted-foreground">{t.candidate_email}</TableCell>
                  <TableCell>{best ? `${best.score} / ${best.total}` : "—"}</TableCell>
                  <TableCell>
                    <Badge style={{ backgroundColor: meta.bg, color: meta.color }} className="border-0">{meta.label}</Badge>
                  </TableCell>
                  <TableCell>{t.attempts_used} / 3</TableCell>
                  <TableCell className="text-muted-foreground">{fmtDate(t.passed_at || t.created_at)}</TableCell>
                </TableRow>
              );
            })}
          </TableBody>
        </Table>
      )}
    </div>
  );
}
