import { useEffect, useState } from "react";
import { Zap, Loader2 } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";

type Props = {
  slotId: string;
  candidateName?: string;
  size?: "sm" | "lg";
  onRegenerated?: (newJoinUrl?: string) => void;
};

/**
 * Quick "Re-Send Round 1" nudge button.
 * - Re-sends the existing booking confirmation (same time, same Zoom link, fresh .ics).
 * - Only calls regenerate-zoom-meeting if the existing Zoom link is missing/dead — minimizes
 *   Zoom create calls (PMR reuse keeps us under the daily cap).
 * - Tracks click count in interview_slots.appointment_resend_count and shifts color as count grows.
 */
export const RegenerateZoomButton = ({ slotId, candidateName, size = "sm", onRegenerated }: Props) => {
  const [busy, setBusy] = useState(false);
  const [count, setCount] = useState(0);

  // Hydrate the current resend count once.
  useEffect(() => {
    let alive = true;
    (async () => {
      const { data } = await supabase
        .from("interview_slots")
        .select("appointment_resend_count")
        .eq("id", slotId)
        .maybeSingle();
      if (alive && data && typeof (data as any).appointment_resend_count === "number") {
        setCount((data as any).appointment_resend_count);
      }
    })();
    return () => { alive = false; };
  }, [slotId]);

  const run = async () => {
    if (busy) return;
    setBusy(true);
    // Optimistic counter bump.
    const prev = count;
    const next = prev + 1;
    setCount(next);
    try {
      // Resolve response_id + existing join_url.
      const { data: slot, error: slotErr } = await supabase
        .from("interview_slots")
        .select("response_id, zoom_meeting_id")
        .eq("id", slotId)
        .maybeSingle();
      if (slotErr) throw slotErr;
      if (!slot?.response_id) throw new Error("No candidate attached to this slot");

      let joinUrl = "";
      if (slot.zoom_meeting_id) {
        const { data: zm } = await supabase
          .from("zoom_meetings")
          .select("join_url")
          .eq("id", slot.zoom_meeting_id)
          .maybeSingle();
        joinUrl = (zm?.join_url || "").trim();
      }

      if (joinUrl) {
        // Quick path — just re-send the existing confirmation email.
        const { error } = await supabase.functions.invoke("send-interview-confirmed-email", {
          body: { response_id: slot.response_id },
        });
        if (error) throw error;
        onRegenerated?.(joinUrl);
      } else {
        // Fallback — link missing, regenerate then send.
        const { data, error } = await supabase.functions.invoke("regenerate-zoom-meeting", {
          body: { slot_id: slotId },
        });
        if (error) throw error;
        const result = (data as any)?.results?.[0];
        if (!result?.ok) throw new Error(result?.reason || "regen_failed");
        onRegenerated?.(result.new_join_url);
      }

      // Persist counter (single-row, exact id).
      await supabase
        .from("interview_slots")
        .update({ appointment_resend_count: next })
        .eq("id", slotId);

      toast.success(`Re-sent to ${candidateName || "candidate"} (${next}×)`);
    } catch (e: any) {
      setCount(prev);
      toast.error(e?.message || "Could not re-send appointment");
    } finally {
      setBusy(false);
    }
  };

  // Color shift based on count.
  const tone =
    count >= 5 ? "bg-red-600 hover:bg-red-700 text-white border-red-700"
    : count >= 3 ? "bg-orange-500 hover:bg-orange-600 text-white border-orange-600"
    : count >= 1 ? "bg-amber-400 hover:bg-amber-500 text-amber-950 border-amber-500"
    : "";

  const baseCls = `action-btn ${size === "lg" ? "action-btn--lg" : ""} ${tone ? tone : "action-btn--primary"}`;
  const ico = size === "lg" ? "h-4 w-4 mr-2" : "h-3.5 w-3.5 mr-1.5";

  return (
    <button
      type="button"
      className={baseCls}
      onClick={run}
      disabled={busy}
      title="Quick nudge — re-sends the same appointment details"
    >
      {busy
        ? <Loader2 className={`${ico} animate-spin`} />
        : <Zap className={ico} />}
      Re-Send Round 1{count > 0 ? ` +${count}` : ""}
    </button>
  );
};
