import { useEffect } from "react";
import { Helmet } from "react-helmet-async";

const SITE_URL = "https://jobs.expertintuitiveadvisor.com";

/**
 * Imperative head setter for components with many early returns where
 * mounting <PageSeo /> in every branch is impractical. Sets a unique
 * title, meta description, and self-referencing canonical, restoring the
 * brand defaults on unmount.
 */
export function usePageSeo({ title, description, path }: PageSeoProps) {
  useEffect(() => {
    const prevTitle = document.title;
    document.title = title;

    const setMeta = (selector: string, attr: string, value: string, content: string) => {
      let el = document.head.querySelector<HTMLElement>(selector);
      if (!el) {
        el = document.createElement(selector.startsWith("link") ? "link" : "meta");
        el.setAttribute(attr, value);
        document.head.appendChild(el);
      }
      el.setAttribute(selector.startsWith("link") ? "href" : "content", content);
      return el;
    };

    setMeta('meta[name="description"]', "name", "description", description);
    setMeta('meta[property="og:title"]', "property", "og:title", title);
    setMeta('meta[property="og:description"]', "property", "og:description", description);
    if (path) {
      const url = `${SITE_URL}${path}`;
      setMeta('link[rel="canonical"]', "rel", "canonical", url);
      setMeta('meta[property="og:url"]', "property", "og:url", url);
    }


    return () => {
      document.title = prevTitle;
    };
  }, [title, description, path]);
}


type PageSeoProps = {
  title: string;
  description: string;
  /** Path beginning with "/". When omitted, no canonical is emitted. */
  path?: string;
  noindex?: boolean;
};

/**
 * Per-route head tags. Sets a unique <title> (kept short by callers),
 * a unique meta description, and a self-referencing canonical link.
 */
const PageSeo = ({ title, description, path, noindex }: PageSeoProps) => {
  const canonical = path ? `${SITE_URL}${path}` : undefined;
  return (
    <Helmet>
      <title>{title}</title>
      <meta name="description" content={description} />
      {canonical && <link rel="canonical" href={canonical} />}
      <meta property="og:title" content={title} />
      <meta property="og:description" content={description} />
      {canonical && <meta property="og:url" content={canonical} />}
      {noindex && <meta name="robots" content="noindex" />}
    </Helmet>
  );
};

export default PageSeo;
