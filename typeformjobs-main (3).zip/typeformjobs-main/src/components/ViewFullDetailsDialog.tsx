import { useEffect, useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { FileText, User as UserIcon, Mail, CheckCircle2, XCircle, Clock, UserCog } from "lucide-react";
import { SelfieThumb, parseFilePath } from "@/components/FilePreview";
import { supabase } from "@/integrations/supabase/client";
import { HrCandidateExtrasEditor } from "@/components/HrCandidateExtrasEditor";


type Question = { id: string; type: string; label: string; order_index?: number };
type Answer = { question_id: string; answer_text: string | null; file_url: string | null };

type Props = {
  open: boolean;
  onClose: () => void;
  positionTitle: string;
  formTitle?: string;
  candidateName: string;
  candidateEmail: string;
  selfieUrl?: string;
  resumeUrl?: string;
  candidateId?: string;
  responseId?: string;
  hasApplicationPhoto?: boolean;
  questions: Question[];
  answers: Answer[];
  onPreviewFile: (file_url: string) => void;
  onExtrasChanged?: () => void;
};

const STAGE_LABEL: Record<string, string> = {
  round_1_invite: "Round 1 invite sent",
  round_1_reminder: "Round 1 reminder",
  round_2_invite: "Round 2 invite sent",
  round_2_reminder: "Round 2 reminder",
  interview_confirmed: "Interview confirmation",
  offer_sent: "Offer letter sent",
  offer_signed: "Offer signed confirmation",
  offer_followup: "Offer follow-up reminder",
  offer_expired: "Offer expired notice",
  recovery: "Reschedule link",
  rejection: "Rejection email",
};

export const ViewFullDetailsDialog = ({
  open, onClose, positionTitle, formTitle, candidateName, candidateEmail,
  selfieUrl, resumeUrl, candidateId, responseId, hasApplicationPhoto,
  questions, answers, onPreviewFile, onExtrasChanged,
}: Props) => {
  const ordered = [...questions].sort((a, b) => (a.order_index || 0) - (b.order_index || 0));
  const ansByQ: Record<string, Answer> = {};
  for (const a of answers) ansByQ[a.question_id] = a;

  const [history, setHistory] = useState<Array<{ id: string; stage: string; subject: string; to_address: string; status: string; sent_at: string | null; created_at: string; error_message: string | null }>>([]);
  const [historyLoading, setHistoryLoading] = useState(false);

  useEffect(() => {
    if (!open || !candidateId) { setHistory([]); return; }
    setHistoryLoading(true);
    supabase
      .from("email_log")
      .select("id, stage, subject, to_address, status, sent_at, created_at, error_message")
      .eq("candidate_id", candidateId)
      .order("created_at", { ascending: false })
      .limit(50)
      .then(({ data }) => {
        setHistory((data as any) || []);
        setHistoryLoading(false);
      });
  }, [open, candidateId]);


  return (
    <Dialog open={open} onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="max-w-3xl max-h-[85vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-base">Full Application Details</DialogTitle>
        </DialogHeader>

        <div className="rounded-lg border border-border bg-secondary/40 px-4 py-3 mb-4">
          <div className="text-xs uppercase tracking-wide text-muted-foreground mb-1">Applied To</div>
          <div className="text-lg font-semibold" style={{ color: "#1a2547" }}>
            {positionTitle || formTitle || "Untitled Form"}
          </div>
          {formTitle && formTitle !== positionTitle && (
            <div className="text-xs text-muted-foreground mt-0.5">Form: {formTitle}</div>
          )}
        </div>

        <div className="flex items-start gap-4 mb-4">
          <div className="shrink-0">
            {selfieUrl ? (
              <SelfieThumb file_url={selfieUrl} size={96} onPreview={() => onPreviewFile(selfieUrl)} />
            ) : (
              <div className="h-24 w-24 rounded-lg bg-secondary border border-border flex items-center justify-center text-muted-foreground">
                <UserIcon className="h-7 w-7" />
              </div>
            )}
          </div>
          <div className="flex-1 min-w-0 space-y-1">
            <div className="font-medium text-base">
              {candidateName || <span className="text-muted-foreground italic">No name</span>}
            </div>
            <div className="text-sm text-muted-foreground break-all">{candidateEmail || "—"}</div>
            {resumeUrl && (
              <Button
                type="button"
                variant="outline"
                size="sm"
                onClick={() => onPreviewFile(resumeUrl)}
                className="mt-1"
              >
                <FileText className="h-3.5 w-3.5 mr-1.5" />
                View Resume ({parseFilePath(resumeUrl).name})
              </Button>
          )}
        </div>

        <div className="space-y-3 mt-6 pt-4 border-t">
          <div className="text-sm font-semibold text-foreground flex items-center gap-2">
            <Mail className="h-4 w-4" /> Email & Action History
          </div>
          {historyLoading ? (
            <div className="text-sm text-muted-foreground">Loading…</div>
          ) : history.length === 0 ? (
            <div className="text-sm text-muted-foreground italic">No emails recorded yet.</div>
          ) : (
            <div className="space-y-2">
              {history.map((h) => {
                const ok = h.status === "sent";
                const when = h.sent_at || h.created_at;
                return (
                  <div key={h.id} className="rounded-md border border-border p-3 flex items-start gap-3">
                    <div className="mt-0.5 shrink-0">
                      {ok ? <CheckCircle2 className="h-4 w-4 text-green-600" /> :
                       h.status === "failed" ? <XCircle className="h-4 w-4 text-destructive" /> :
                       <Clock className="h-4 w-4 text-muted-foreground" />}
                    </div>
                    <div className="flex-1 min-w-0 space-y-0.5">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="text-sm font-medium">{STAGE_LABEL[h.stage] || h.stage}</span>
                        <Badge variant="outline" className="text-[10px] font-normal">{h.status}</Badge>
                      </div>
                      <div className="text-xs text-muted-foreground break-words">{h.subject}</div>
                      <div className="text-xs text-muted-foreground">
                        to {h.to_address} · {new Date(when).toLocaleString("en-US", { timeZone: "Asia/Manila", month: "short", day: "numeric", year: "numeric", hour: "numeric", minute: "2-digit" })}
                      </div>
                      {h.error_message && (
                        <div className="text-xs text-destructive break-words">{h.error_message}</div>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>

        </div>

        {responseId && (
          <div className="space-y-3 mt-6 pt-4 border-t">
            <div className="text-sm font-semibold text-foreground flex items-center gap-2">
              <UserCog className="h-4 w-4" /> HR Details (optional)
            </div>
            <HrCandidateExtrasEditor
              responseId={responseId}
              hasApplicationPhoto={!!hasApplicationPhoto}
              onPreviewFile={onPreviewFile}
              onChanged={onExtrasChanged}
            />
          </div>
        )}

        <div className="space-y-3 mt-6 pt-4 border-t">
          <div className="text-sm font-semibold text-foreground">All Answers</div>
          {ordered.length === 0 ? (
            <div className="text-sm text-muted-foreground">No questions found.</div>
          ) : (
            ordered.map((q) => {
              const a = ansByQ[q.id];
              const isFile = q.type === "file_upload" || q.type === "selfie";
              return (
                <div key={q.id} className="rounded-md border border-border p-3">
                  <div className="text-xs text-muted-foreground mb-1 flex items-center gap-2">
                    <span>{q.label || "(no label)"}</span>
                    <Badge variant="outline" className="text-[10px] font-normal">{q.type}</Badge>
                  </div>
                  {isFile ? (
                    a?.file_url ? (
                      <button
                        type="button"
                        onClick={() => onPreviewFile(a.file_url!)}
                        className="inline-flex items-center gap-1.5 text-sm text-primary hover:underline"
                      >
                        <FileText className="h-4 w-4" />
                        {parseFilePath(a.file_url).name}
                      </button>
                    ) : (
                      <span className="text-sm text-muted-foreground italic">No file</span>
                    )
                  ) : (
                    <div className="text-sm whitespace-pre-wrap break-words">
                      {a?.answer_text?.trim() || <span className="text-muted-foreground italic">No answer</span>}
                    </div>
                  )}
                </div>
              );
            })
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default ViewFullDetailsDialog;
