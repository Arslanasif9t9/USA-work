import { useState } from "react";
import { z } from "zod";
import { Pencil, Plus, Loader2 } from "lucide-react";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";

const emailSchema = z.string().trim().email("Invalid email").max(255);

type Props = {
  responseId: string;
  email: string;
  /** Called immediately (optimistic) and again after a successful save. */
  onSaved: (newEmail: string) => void;
  /** Optional: called if the background save fails so the parent can revert
   *  its optimistic state back to the previous email. */
  onRevert?: (prevEmail: string) => void;
};

export const EmailInlineEditor = ({ responseId, email, onSaved, onRevert }: Props) => {
  const [open, setOpen] = useState(false);
  const [val, setVal] = useState(email || "");
  const [busy, setBusy] = useState(false);
  const [inlineError, setInlineError] = useState<string | null>(null);

  const save = async () => {
    const parsed = emailSchema.safeParse(val);
    if (!parsed.success) {
      setInlineError(parsed.error.issues[0]?.message || "Invalid email");
      return;
    }
    setInlineError(null);
    const prev = email || "";
    const next = parsed.data;

    // Optimistic: update parent + close popover immediately.
    onSaved(next);
    setOpen(false);
    setBusy(true);

    const { error } = await supabase
      .from("responses")
      .update({ override_email: next })
      .eq("id", responseId);

    setBusy(false);

    if (error) {
      // Revert and surface error inline (no page refresh).
      onRevert?.(prev);
      setVal(prev);
      setInlineError(error.message || "Could not save email");
      setOpen(true);
      toast.error("Could not save email — reverted");
      return;
    }
    toast.success("Email saved");
  };

  return (
    <div className="flex items-center gap-1.5">
      {email ? (
        <span className="text-sm text-foreground break-all">{email}</span>
      ) : (
        <span className="text-sm text-muted-foreground">—</span>
      )}
      <Popover
        open={open}
        onOpenChange={(o) => {
          setOpen(o);
          if (o) { setVal(email || ""); setInlineError(null); }
        }}
      >
        <PopoverTrigger asChild>
          <Button
            type="button"
            variant="ghost"
            size="sm"
            className="h-6 px-1.5 text-xs text-muted-foreground hover:text-foreground"
            title={email ? "Edit email" : "Add email"}
          >
            {email ? <Pencil className="h-3 w-3" /> : (<><Plus className="h-3 w-3 mr-1" />Add email</>)}
          </Button>
        </PopoverTrigger>
        <PopoverContent className="w-72" align="start">
          <form onSubmit={(e) => { e.preventDefault(); save(); }} className="space-y-2">
            <label className="text-xs font-medium">Candidate email</label>
            <Input
              type="email"
              value={val}
              onChange={(e) => { setVal(e.target.value); if (inlineError) setInlineError(null); }}
              placeholder="name@example.com"
              autoFocus
            />
            {inlineError && (
              <div className="text-xs text-destructive">{inlineError}</div>
            )}
            <div className="flex justify-end gap-1.5">
              <Button type="button" size="sm" variant="ghost" onClick={() => setOpen(false)}>
                Cancel
              </Button>
              <Button type="submit" size="sm" disabled={busy}>
                {busy ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : "Save"}
              </Button>
            </div>
          </form>
        </PopoverContent>
      </Popover>
    </div>
  );
};
