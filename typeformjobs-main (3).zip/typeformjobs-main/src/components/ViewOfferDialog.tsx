import { useEffect, useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { ExternalLink, FileText, Loader2 } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";

type Props = {
  candidateId: string | null;
  responseId?: string;
  onClose: () => void;
};

type OfferRow = {
  id: string;
  offer_reference_id: string;
  candidate_name: string;
  candidate_email: string;
  override_email: string | null;
  position_title: string;
  currency: string;
  trial_weekly_salary: number;
  post_trial_weekly_salary: number;
  performance_bonus_enabled: boolean;
  performance_bonus_amount: number | null;
  include_adaptability_clause: boolean;
  start_date: string | null;
  status: string;
  sent_at: string | null;
  signed_at: string | null;
  signed_pdf_url: string | null;
};

const SUPABASE_URL = import.meta.env.VITE_SUPABASE_URL;

const buildPdfUrl = (refId: string, candidateName: string): string => {
  const last = candidateName.trim().split(/\s+/).slice(-1)[0] || "Candidate";
  const safe = last.replace(/[^A-Za-z0-9_-]/g, "_");
  return `${SUPABASE_URL}/storage/v1/object/public/offer-letters/${refId}-${safe}.pdf`;
};

const fmtMoney = (n: number, ccy: string) =>
  new Intl.NumberFormat("en-US", { style: "currency", currency: ccy || "PHP", maximumFractionDigits: 0 }).format(n);

const fmtDate = (iso: string | null) =>
  iso ? new Date(iso).toLocaleString("en-US", { dateStyle: "medium", timeStyle: "short" }) : "—";

export function ViewOfferDialog({ candidateId, responseId, onClose }: Props) {
  const [loading, setLoading] = useState(false);
  const [offer, setOffer] = useState<OfferRow | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!candidateId) { setOffer(null); setError(null); return; }
    let cancelled = false;
    setLoading(true);
    setError(null);
    (async () => {
      let offerId: string | null = null;
      if (responseId) {
        const { data: action } = await supabase
          .from("candidate_actions")
          .select("job_offer_id")
          .eq("response_id", responseId)
          .maybeSingle();
        offerId = (action as any)?.job_offer_id || null;
      }
      let query = supabase
        .from("job_offers")
        .select("id, offer_reference_id, candidate_name, candidate_email, override_email, position_title, currency, trial_weekly_salary, post_trial_weekly_salary, performance_bonus_enabled, performance_bonus_amount, include_adaptability_clause, start_date, status, sent_at, signed_at, signed_pdf_url")
        .order("created_at", { ascending: false })
        .limit(1);
      query = offerId ? query.eq("id", offerId) : query.eq("candidate_id", candidateId);
      const { data, error } = await query.maybeSingle();
        if (cancelled) return;
        if (error) setError(error.message);
        else if (!data) setError("No offer found for this candidate.");
        else setOffer(data as OfferRow);
        setLoading(false);
    })();
    return () => { cancelled = true; };
  }, [candidateId, responseId]);

  const isSigned = offer?.status === "signed" || !!offer?.signed_at || !!offer?.signed_pdf_url;
  const recipient = offer?.override_email || offer?.candidate_email || "—";
  const pdfUrl = offer ? buildPdfUrl(offer.offer_reference_id, offer.candidate_name) : null;

  return (
    <Dialog open={!!candidateId} onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle>Offer Details</DialogTitle>
          <DialogDescription>
            {offer ? `Reference: ${offer.offer_reference_id}` : "Loading offer record…"}
          </DialogDescription>
        </DialogHeader>

        {loading ? (
          <div className="flex justify-center py-10">
            <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
          </div>
        ) : error ? (
          <div className="text-sm text-destructive py-6">{error}</div>
        ) : offer ? (
          <div className="space-y-4 text-sm">
            <div className="flex items-center gap-2">
              <Badge className={isSigned ? "bg-green-100 text-green-800 border-0" : "bg-purple-100 text-purple-800 border-0"}>
                {isSigned ? "Offer Signed" : "Offer Sent"}
              </Badge>
              {isSigned && offer.signed_at && (
                <span className="text-xs text-muted-foreground">Signed {fmtDate(offer.signed_at)}</span>
              )}
            </div>

            <div className="grid grid-cols-2 gap-3">
              <Field label="Candidate" value={offer.candidate_name} />
              <Field label="Recipient email" value={recipient} />
              <Field label="Position" value={offer.position_title} />
              <Field label="Start date" value={offer.start_date ? new Date(offer.start_date).toLocaleDateString() : "—"} />
              <Field label="Trial weekly salary" value={fmtMoney(Number(offer.trial_weekly_salary || 0), offer.currency)} />
              <Field label="Post-trial weekly salary" value={fmtMoney(Number(offer.post_trial_weekly_salary || 0), offer.currency)} />
              <Field
                label="Performance bonus"
                value={offer.performance_bonus_enabled
                  ? `Enabled · ${fmtMoney(Number(offer.performance_bonus_amount || 0), offer.currency)}`
                  : "Not included"}
              />
              <Field label="Adaptability clause" value={offer.include_adaptability_clause ? "Included" : "Not included"} />
              <Field label="Sent at" value={fmtDate(offer.sent_at)} />
            </div>

            <div className="flex flex-wrap gap-2 pt-2 border-t border-border">
              {pdfUrl && (
                <Button variant="outline" size="sm" asChild>
                  <a href={pdfUrl} target="_blank" rel="noopener noreferrer">
                    <FileText className="h-4 w-4 mr-1.5" /> View Offer PDF
                    <ExternalLink className="h-3 w-3 ml-1.5 opacity-60" />
                  </a>
                </Button>
              )}
              {isSigned && offer.signed_pdf_url && (
                <Button size="sm" asChild>
                  <a href={offer.signed_pdf_url} target="_blank" rel="noopener noreferrer">
                    <FileText className="h-4 w-4 mr-1.5" /> View Signed PDF
                    <ExternalLink className="h-3 w-3 ml-1.5 opacity-60" />
                  </a>
                </Button>
              )}
            </div>
          </div>
        ) : null}
      </DialogContent>
    </Dialog>
  );
}

const Field = ({ label, value }: { label: string; value: string }) => (
  <div>
    <div className="text-xs uppercase tracking-wide text-muted-foreground">{label}</div>
    <div className="font-medium break-words">{value}</div>
  </div>
);

export default ViewOfferDialog;
