import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter,
} from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { GraduationCap, Loader2, Copy, Check } from "lucide-react";
import { toast } from "sonner";
import { DEFAULT_ONBOARDING_VIDEO_URL } from "@/config/onboarding";

const PUBLIC_BASE = "https://jobs.expertintuitiveadvisor.com";
const NO_TEAM = "__none__";

type Group = { id: string; name: string };

export default function SendOnboardingTestDialog({
  onSent,
  prefillName,
  prefillEmail,
  renderTrigger,
}: {
  onSent?: () => void;
  /** Optional pre-filled candidate name (HR can still edit). */
  prefillName?: string;
  /** Optional pre-filled candidate email (HR can still edit). */
  prefillEmail?: string;
  /** Optional custom trigger; receives an opener fn. Falls back to the default button. */
  renderTrigger?: (openDialog: () => void) => React.ReactNode;
}) {
  const [open, setOpen] = useState(false);
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [groupId, setGroupId] = useState<string>(NO_TEAM);
  const [groups, setGroups] = useState<Group[]>([]);
  const [autoMode, setAutoMode] = useState(false); // false = HR approves first (default)
  const [loading, setLoading] = useState(false);
  const [link, setLink] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    if (!open) return;
    (async () => {
      const { data } = await supabase.functions.invoke<{ ok: boolean; groups: Group[] }>("list-team-groups", { body: {} });
      if (data?.ok && Array.isArray(data.groups)) setGroups(data.groups);
    })();
  }, [open]);

  const reset = () => {
    setName(""); setEmail(""); setGroupId(NO_TEAM); setAutoMode(false);
    setLink(null); setCopied(false);
  };
  // Apply any prefill values, then open. HR can still edit before sending.
  const openDialog = () => {
    setLink(null); setCopied(false); setAutoMode(false); setGroupId(NO_TEAM);
    setName(prefillName?.trim() || "");
    setEmail(prefillEmail?.trim() || "");
    setOpen(true);
  };
  const close = () => { if (!loading) { reset(); setOpen(false); } };

  const copyLink = async () => {
    if (!link) return;
    try { await navigator.clipboard.writeText(link); setCopied(true); setTimeout(() => setCopied(false), 2000); }
    catch { toast.error("Could not copy — select and copy manually"); }
  };

  const submit = async () => {
    if (!name.trim()) return toast.error("Name is required");
    if (!email.trim() || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim())) {
      return toast.error("Valid email is required");
    }
    setLoading(true);
    try {
      const { data: mint, error: mintErr } = await supabase.functions.invoke<any>("mint-onboarding-quiz-token", {
        body: {
          candidate_name: name.trim(),
          candidate_email: email.trim(),
          assigned_group_id: groupId === NO_TEAM ? null : groupId,
          after_pass_mode: autoMode ? "auto" : "manual",
          video_url: DEFAULT_ONBOARDING_VIDEO_URL,
        },
      });
      // Token-persist guard: if the token didn't mint/read-back, do NOT email.
      if (mintErr || !mint?.token) {
        toast.error(String(mint?.error || mintErr?.message || "Could not create the link — nothing was sent"));
        return;
      }
      const { data: sent, error: sendErr } = await supabase.functions.invoke<any>("send-onboarding-test-invite", {
        body: { token: mint.token },
      });
      if (sendErr || sent?.error) {
        toast.error("Link created but the email failed to send. You can still copy the link.");
      } else {
        toast.success(`Onboarding test sent to ${email.trim()}`);
      }
      setLink(`${PUBLIC_BASE}/onboarding-test/${mint.token}`);
      onSent?.();
    } catch (e: any) {
      toast.error(e?.message || "Network error — please retry");
    } finally {
      setLoading(false);
    }
  };

  return (
    <>
      {renderTrigger ? (
        renderTrigger(openDialog)
      ) : (
        <Button
          size="sm"
          variant="outline"
          onClick={openDialog}
          className="min-h-[44px] sm:min-h-0"
          style={{ borderColor: "#1a2547", color: "#1a2547" }}
          title="Send the onboarding video + quiz to a new hire"
        >
          <GraduationCap className="h-4 w-4 mr-1.5" /> Send Onboarding Test
        </Button>
      )}
      <Dialog open={open} onOpenChange={(o) => !o && close()}>
        <DialogContent className="sm:max-w-[480px]">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <GraduationCap className="h-4 w-4" style={{ color: "#1a2547" }} /> Send Onboarding Test
            </DialogTitle>
            <DialogDescription>
              Issue a private, single-use link to the orientation video + 11-question check. The link is locked to this exact name and email.
            </DialogDescription>
          </DialogHeader>

          {link ? (
            <div className="space-y-4">
              <Label>Onboarding test link (also emailed)</Label>
              <div className="flex items-center gap-2">
                <Input readOnly value={link} className="min-h-[44px] sm:min-h-0 text-xs" onFocus={(e) => e.currentTarget.select()} />
                <Button type="button" onClick={copyLink} className="min-h-[44px] sm:min-h-0 text-white shrink-0" style={{ backgroundColor: "#1a2547" }}>
                  {copied ? <Check className="h-4 w-4" /> : <Copy className="h-4 w-4" />}
                </Button>
              </div>
              <DialogFooter>
                <Button variant="outline" onClick={close} className="min-h-[44px] sm:min-h-0">Done</Button>
              </DialogFooter>
            </div>
          ) : (
            <>
              <div className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="ot-name">Full Name</Label>
                  <Input id="ot-name" value={name} onChange={(e) => setName(e.target.value)} placeholder="Jane Doe" className="min-h-[44px] sm:min-h-0" disabled={loading} />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="ot-email">Email</Label>
                  <Input id="ot-email" type="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="jane@example.com" className="min-h-[44px] sm:min-h-0" disabled={loading} />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="ot-team">Target PMS Team <span className="text-muted-foreground font-normal">(optional)</span></Label>
                  <Select value={groupId} onValueChange={setGroupId} disabled={loading}>
                    <SelectTrigger id="ot-team" className="min-h-[44px] sm:min-h-0"><SelectValue placeholder="Select a team" /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value={NO_TEAM}>No team yet</SelectItem>
                      {groups.map((g) => <SelectItem key={g.id} value={g.id}>{g.name}</SelectItem>)}
                    </SelectContent>
                  </Select>
                </div>
                <div className="flex items-center justify-between rounded-md border p-3">
                  <div>
                    <Label htmlFor="ot-auto" className="block">After they pass</Label>
                    <p className="text-xs text-muted-foreground mt-0.5">
                      {autoMode ? "Auto-approve and send the pass email automatically." : "HR approves first (default)."}
                    </p>
                  </div>
                  <Switch id="ot-auto" checked={autoMode} onCheckedChange={setAutoMode} disabled={loading} />
                </div>
              </div>
              <DialogFooter>
                <Button variant="outline" onClick={close} disabled={loading} className="min-h-[44px] sm:min-h-0">Cancel</Button>
                <Button onClick={submit} disabled={loading} className="min-h-[44px] sm:min-h-0 text-white" style={{ backgroundColor: "#1a2547" }}>
                  {loading ? <><Loader2 className="h-4 w-4 mr-1.5 animate-spin" /> Sending…</> : "Send Onboarding Test"}
                </Button>
              </DialogFooter>
            </>
          )}
        </DialogContent>
      </Dialog>
    </>
  );
}
