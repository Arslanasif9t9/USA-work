import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { UserPlus, Loader2, X, UserCheck } from "lucide-react";
import { toast } from "sonner";
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Button } from "@/components/ui/button";

type Props = {
  responseId: string;
  candidateName: string;
  size?: "sm" | "lg";
  /**
   * Visual style:
   *  - "stack"   → per-row action-btn helper (My Bookings ActionsCell)
   *  - "outline" → shadcn outline Button (Scout Report action area)
   */
  appearance?: "stack" | "outline";
};

const stackClass = (size: "sm" | "lg") =>
  `action-btn ${size === "lg" ? "action-btn--lg" : ""} action-btn--primary`;

export const InvolveHumanButton = ({
  responseId, candidateName, size = "sm", appearance = "stack",
}: Props) => {
  const [flagged, setFlagged] = useState<boolean | null>(null);
  const [open, setOpen] = useState(false);
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    let cancelled = false;
    (async () => {
      const { data } = await supabase
        .from("responses")
        .select("needs_human")
        .eq("id", responseId)
        .maybeSingle();
      if (cancelled) return;
      setFlagged(!!(data as any)?.needs_human);
    })();
    return () => { cancelled = true; };
  }, [responseId]);

  if (flagged === null) return null;

  const confirmFlag = async () => {
    setBusy(true);
    try {
      const { data, error } = await supabase.functions.invoke("involve-human", {
        body: { response_id: responseId },
      });
      const errMsg = (data as any)?.error || error?.message;
      if (errMsg) { toast.error(errMsg); return; }
      setFlagged(true);
      setOpen(false);
      toast.success(
        (data as any)?.email_sent
          ? "Flagged for human follow-up — HR notified"
          : "Flagged for human follow-up"
      );
    } catch (e: any) {
      toast.error(e?.message || "Could not flag candidate");
    } finally {
      setBusy(false);
    }
  };

  const clearFlag = async () => {
    setBusy(true);
    try {
      const { error } = await supabase
        .from("responses")
        .update({ needs_human: false })
        .eq("id", responseId);
      if (error) { toast.error(error.message); return; }
      setFlagged(false);
      toast.success("Cleared the human-follow-up flag");
    } catch (e: any) {
      toast.error(e?.message || "Could not clear flag");
    } finally {
      setBusy(false);
    }
  };

  const ico = size === "lg" ? "h-4 w-4 mr-2" : "h-3.5 w-3.5 mr-1.5";

  // ── Flagged: show a "Needs Human" badge with an inline Clear control ──
  if (flagged) {
    return (
      <span className="inline-flex items-center gap-1 rounded-md border border-amber-500/40 bg-amber-500/10 px-2 py-1 text-xs font-medium text-amber-700 dark:text-amber-400">
        <UserCheck className="h-3.5 w-3.5" /> Needs Human
        <button
          type="button"
          onClick={clearFlag}
          disabled={busy}
          title="Clear flag"
          className="ml-0.5 rounded p-0.5 hover:bg-amber-500/20 disabled:opacity-50"
        >
          {busy ? <Loader2 className="h-3 w-3 animate-spin" /> : <X className="h-3 w-3" />}
        </button>
      </span>
    );
  }

  // ── Not flagged: the Involve Human action button ──
  return (
    <>
      {appearance === "outline" ? (
        <Button size="sm" className="min-h-[36px] bg-rose-600 hover:bg-rose-700 text-white" onClick={() => setOpen(true)}>
          <UserPlus className="h-4 w-4 mr-1.5" /> Involve Human
        </Button>
      ) : (
        <button type="button" className={stackClass(size)} onClick={() => setOpen(true)}>
          <UserPlus className={ico} /> Involve Human
        </button>
      )}

      <AlertDialog open={open} onOpenChange={(o) => !busy && setOpen(o)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle className="flex items-center gap-2">
              <UserPlus className="h-4 w-4" /> Involve a human?
            </AlertDialogTitle>
            <AlertDialogDescription>
              This flags {candidateName || "this candidate"} for a manual HR follow-up (e.g. a Zoom
              call) and notifies the HR inbox. It does <strong>not</strong> change their stage or
              interview link — they still need to complete their AI interview.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={busy}>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={(e) => { e.preventDefault(); confirmFlag(); }}
              disabled={busy}
            >
              {busy ? <Loader2 className="h-4 w-4 mr-2 animate-spin" /> : <UserPlus className="h-4 w-4 mr-2" />}
              Flag & notify HR
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
};

export default InvolveHumanButton;
