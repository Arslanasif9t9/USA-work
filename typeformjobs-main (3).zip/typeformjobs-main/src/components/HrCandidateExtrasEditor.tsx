import { useEffect, useRef, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { SelfieThumb } from "@/components/FilePreview";
import { Upload, Loader2, Save, Image as ImageIcon } from "lucide-react";
import { toast } from "sonner";
import { useHrIdentity } from "@/hooks/useHrIdentity";

const BUCKET = "candidate-files";
const ACCEPT = "image/jpeg,image/png,image/webp,image/heic,image/heif,image/avif,image/gif";

type Extras = {
  response_id: string;
  photo_file_url: string | null;
  notes: string | null;
  phone: string | null;
};

export function HrCandidateExtrasEditor({
  responseId,
  hasApplicationPhoto,
  onPreviewFile,
  onChanged,
}: {
  responseId: string;
  hasApplicationPhoto: boolean;
  onPreviewFile: (file_url: string) => void;
  onChanged?: () => void;
}) {
  const { hrId } = useHrIdentity();
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [extras, setExtras] = useState<Extras>({ response_id: responseId, photo_file_url: null, notes: null, phone: null });
  const [notes, setNotes] = useState("");
  const [phone, setPhone] = useState("");
  const fileRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    let active = true;
    setLoading(true);
    supabase
      .from("hr_candidate_extras")
      .select("response_id, photo_file_url, notes, phone")
      .eq("response_id", responseId)
      .maybeSingle()
      .then(({ data }) => {
        if (!active) return;
        const e = (data as Extras | null) || { response_id: responseId, photo_file_url: null, notes: null, phone: null };
        setExtras(e);
        setNotes(e.notes || "");
        setPhone(e.phone || "");
        setLoading(false);
      });
    return () => { active = false; };
  }, [responseId]);

  const upsert = async (patch: Partial<Extras>) => {
    const payload = {
      response_id: responseId,
      photo_file_url: patch.photo_file_url ?? extras.photo_file_url,
      notes: patch.notes ?? extras.notes,
      phone: patch.phone ?? extras.phone,
      updated_by_hr_id: hrId || null,
    };
    const { data, error } = await supabase
      .from("hr_candidate_extras")
      .upsert(payload, { onConflict: "response_id" })
      .select("response_id, photo_file_url, notes, phone")
      .maybeSingle();
    if (error) throw error;
    if (data) setExtras(data as Extras);
    onChanged?.();
  };

  const onFile = async (file: File) => {
    if (!file.type.startsWith("image/")) { toast.error("Please choose an image file"); return; }
    if (file.size > 20 * 1024 * 1024) { toast.error("Image must be under 20MB"); return; }
    setUploading(true);
    try {
      const ts = Date.now();
      const ext = (file.name.split(".").pop() || "jpg").toLowerCase();
      const path = `responses/${responseId}/hr-extras/${ts}.${ext}`;
      const { error: upErr } = await supabase.storage.from(BUCKET).upload(path, file, {
        contentType: file.type || undefined,
        upsert: false,
      });
      if (upErr) throw upErr;
      const file_url = `${BUCKET}/${path}`;
      await upsert({ photo_file_url: file_url });
      toast.success("Photo uploaded");
    } catch (e: any) {
      toast.error(e?.message || "Upload failed — please try again");
    } finally {
      setUploading(false);
      if (fileRef.current) fileRef.current.value = "";
    }
  };

  const save = async () => {
    setSaving(true);
    try {
      await upsert({ notes: notes.trim() || null, phone: phone.trim() || null });
      toast.success("Saved");
    } catch (e: any) {
      toast.error(e?.message || "Save failed");
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return <div className="text-sm text-muted-foreground">Loading HR details…</div>;
  }

  return (
    <div className="space-y-4">
      <div className="flex items-start gap-4">
        <div className="shrink-0">
          {extras.photo_file_url ? (
            <SelfieThumb file_url={extras.photo_file_url} size={88} onPreview={() => onPreviewFile(extras.photo_file_url!)} />
          ) : (
            <div className="h-[88px] w-[88px] rounded-lg bg-secondary border border-border flex items-center justify-center text-muted-foreground">
              <ImageIcon className="h-6 w-6" />
            </div>
          )}
        </div>
        <div className="flex-1 space-y-2">
          <Button
            type="button"
            size="sm"
            variant="outline"
            onClick={() => fileRef.current?.click()}
            disabled={uploading}
            className="min-h-[40px]"
          >
            {uploading ? <><Loader2 className="h-4 w-4 mr-1.5 animate-spin" /> Uploading…</>
              : <><Upload className="h-4 w-4 mr-1.5" /> {extras.photo_file_url ? "Replace HR photo" : "Upload HR photo"}</>}
          </Button>
          <input
            ref={fileRef}
            type="file"
            accept={ACCEPT}
            className="hidden"
            onChange={(e) => { const f = e.target.files?.[0]; if (f) onFile(f); }}
          />
          <p className="text-xs text-muted-foreground">
            Optional. {hasApplicationPhoto
              ? "Applicant already submitted a photo — that one stays primary; this is an HR-only add-on."
              : "Used as the candidate's photo wherever a photo is shown."}
          </p>
        </div>
      </div>

      <div className="space-y-2">
        <Label htmlFor="hr-extras-phone">Phone (optional)</Label>
        <Input
          id="hr-extras-phone"
          value={phone}
          onChange={(e) => setPhone(e.target.value)}
          placeholder="e.g. +63 9XX XXX XXXX"
          className="min-h-[40px]"
        />
      </div>

      <div className="space-y-2">
        <Label htmlFor="hr-extras-notes">HR Notes (optional)</Label>
        <Textarea
          id="hr-extras-notes"
          value={notes}
          onChange={(e) => setNotes(e.target.value)}
          placeholder="Private notes visible to HR only."
          rows={4}
        />
      </div>

      <div className="flex justify-end">
        <Button onClick={save} disabled={saving} className="min-h-[40px]">
          {saving ? <><Loader2 className="h-4 w-4 mr-1.5 animate-spin" /> Saving…</>
            : <><Save className="h-4 w-4 mr-1.5" /> Save details</>}
        </Button>
      </div>
    </div>
  );
}
