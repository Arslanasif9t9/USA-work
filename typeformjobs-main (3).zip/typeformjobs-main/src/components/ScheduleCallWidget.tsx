import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Loader2, Clock, Calendar as CalIcon } from "lucide-react";
import { toast } from "sonner";
import { cn } from "@/lib/utils";

export type ScheduleCallValue = {
  slot_id?: string;
  slot_start?: string;          // ISO UTC
  reserved_until?: string;      // ISO UTC
  display_date?: string;        // e.g. "Monday, May 19, 2026"
  display_time?: string;        // e.g. "2:00 PM"
  ooo?: boolean;
  ooo_end?: string | null;
};

type Props = {
  value?: ScheduleCallValue | null;
  onChange?: (v: ScheduleCallValue | null) => void;
  disabled?: boolean;
};

type SlotItem = { id: string; slot_start: string; display_time: string; available: boolean };
type Payload = {
  ooo_active?: boolean;
  ooo_end?: string;
  timezone?: string;
  extended_window?: boolean;
  visible_days?: number;
  config?: { lock_days_ahead?: number; min_advance_hours?: number; slot_duration_minutes?: number };
  slots_by_date?: Record<string, SlotItem[]>;
};

const fmt = (opts: Intl.DateTimeFormatOptions) =>
  new Intl.DateTimeFormat("en-US", { timeZone: "Asia/Manila", ...opts });

const manilaYMD = (d: Date) => {
  const parts = new Intl.DateTimeFormat("en-CA", {
    timeZone: "Asia/Manila", year: "numeric", month: "2-digit", day: "2-digit",
  }).formatToParts(d);
  const y = parts.find((p) => p.type === "year")?.value;
  const m = parts.find((p) => p.type === "month")?.value;
  const day = parts.find((p) => p.type === "day")?.value;
  return `${y}-${m}-${day}`;
};

const tabLabel = (dateStr: string): { top: string; bottom: string } => {
  const [y, m, d] = dateStr.split("-").map(Number);
  // Build a UTC noon date for that Manila calendar day (safe for weekday formatting).
  const noonUtc = new Date(Date.UTC(y, m - 1, d, 4, 0, 0)); // 12pm Manila ≈ 4am UTC
  const today = manilaYMD(new Date());
  const tomorrow = manilaYMD(new Date(Date.now() + 86400000));
  const weekday = fmt({ weekday: "short" }).format(noonUtc);
  const month = fmt({ month: "short" }).format(noonUtc);
  const dayN = fmt({ day: "numeric" }).format(noonUtc);
  const bottom = `${weekday} ${month} ${dayN}`;
  let top = weekday;
  if (dateStr === today) top = "Today";
  else if (dateStr === tomorrow) top = "Tomorrow";
  return { top, bottom };
};

const fullDate = (iso: string) => fmt({ weekday: "long", month: "long", day: "numeric", year: "numeric" }).format(new Date(iso));
const fullTime = (iso: string) => fmt({ hour: "numeric", minute: "2-digit", hour12: true }).format(new Date(iso));

const ScheduleCallWidget = ({ value, onChange, disabled }: Props) => {
  const [loading, setLoading] = useState(true);
  const [loadErr, setLoadErr] = useState<string | null>(null);
  const [payload, setPayload] = useState<Payload | null>(null);
  const [activeDate, setActiveDate] = useState<string | null>(null);
  const [pendingSlotId, setPendingSlotId] = useState<string | null>(null);
  const [secondsLeft, setSecondsLeft] = useState<number>(0);
  const [expired, setExpired] = useState(false);
  // Tracks slot IDs that returned 409 in this session so we mark them taken in UI.
  const [takenIds, setTakenIds] = useState<Set<string>>(new Set());
  const lastClickRef = useRef<{ id: string; at: number } | null>(null);

  const reservedUntilRef = useRef<number | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    setLoadErr(null);
    try {
      const { data, error } = await supabase.functions.invoke<Payload>("get-available-slots", { body: {} });
      if (error) throw error;
      setPayload(data || {});
      if (data?.ooo_active) {
        onChange?.({ ooo: true, ooo_end: data.ooo_end || null });
      } else {
        setActiveDate(null);
      }
    } catch (e: any) {
      setLoadErr("Could not load times. Please refresh and try again.");
    } finally {
      setLoading(false);
    }
  }, [onChange]);

  useEffect(() => { load(); /* eslint-disable-next-line react-hooks/exhaustive-deps */ }, []);

  useEffect(() => {
    if (!payload || payload.ooo_active) return;
    const visible = Object.keys(payload.slots_by_date || {}).sort();
    if (activeDate && !visible.includes(activeDate)) setActiveDate(null);
  }, [payload, activeDate]);

  // Timer
  useEffect(() => {
    if (!value?.reserved_until) {
      setSecondsLeft(0);
      reservedUntilRef.current = null;
      return;
    }
    reservedUntilRef.current = new Date(value.reserved_until).getTime();
    const tick = () => {
      const ms = (reservedUntilRef.current || 0) - Date.now();
      const s = Math.max(0, Math.floor(ms / 1000));
      setSecondsLeft(s);
      if (s <= 0) {
        setExpired(true);
        onChange?.(null);
      }
    };
    tick();
    const t = setInterval(tick, 1000);
    return () => clearInterval(t);
  }, [value?.reserved_until, onChange]);

  const dates = useMemo(() => Object.keys(payload?.slots_by_date || {}).sort(), [payload]);
  const slots = useMemo(() => (activeDate && payload?.slots_by_date?.[activeDate]) || [], [activeDate, payload]);

  const pickSlot = async (slot: SlotItem) => {
    if (disabled) return;
    if (takenIds.has(slot.id)) return;
    // Debounce: ignore rapid duplicate clicks on same slot
    const now = Date.now();
    if (lastClickRef.current && lastClickRef.current.id === slot.id && now - lastClickRef.current.at < 500) return;
    lastClickRef.current = { id: slot.id, at: now };
    if (pendingSlotId === slot.id) return;

    // Optimistic UI: show selection immediately with a temporary 10-min reservation
    setExpired(false);
    setPendingSlotId(slot.id);
    const optimisticUntil = new Date(Date.now() + 10 * 60 * 1000).toISOString();
    const prevValue = value;
    onChange?.({
      slot_id: slot.id,
      slot_start: slot.slot_start,
      reserved_until: optimisticUntil,
      display_date: fullDate(slot.slot_start),
      display_time: fullTime(slot.slot_start),
      ooo: false,
    });

    try {
      const { data, error } = await supabase.functions.invoke<{
        success: boolean; slot_id: string; reserved_until: string; reservation_seconds: number;
      }>("reserve-slot", { body: { slot_id: slot.id } });
      if (error || !data?.success) {
        const code = (error as any)?.context?.status || (data as any)?.error;
        if (code === 409 || `${code}`.includes("unavailable") || `${code}`.includes("taken")) {
          setTakenIds((s) => new Set(s).add(slot.id));
          toast.error("That slot was just taken. Pick another time.");
        } else {
          toast.error("Could not reserve that slot. Please try again.");
        }
        onChange?.(prevValue ?? null);
        return;
      }
      // Reconcile with server's authoritative reserved_until
      onChange?.({
        slot_id: data.slot_id,
        slot_start: slot.slot_start,
        reserved_until: data.reserved_until,
        display_date: fullDate(slot.slot_start),
        display_time: fullTime(slot.slot_start),
        ooo: false,
      });
    } catch {
      toast.error("Could not reserve that slot. Please try again.");
      onChange?.(prevValue ?? null);
    } finally {
      setPendingSlotId((cur) => (cur === slot.id ? null : cur));
    }
  };

  const changeSlot = () => {
    onChange?.(null);
    setSecondsLeft(0);
    setExpired(false);
  };

  // ---- Render ----
  if (loading) {
    return (
      <div className="w-full max-w-3xl mx-auto py-8 flex items-center justify-center text-muted-foreground">
        <Loader2 className="h-5 w-5 mr-2 animate-spin" /> Loading available times…
      </div>
    );
  }
  if (loadErr) {
    return (
      <div className="w-full max-w-3xl mx-auto py-8 text-center space-y-3">
        <p className="text-destructive font-medium">{loadErr}</p>
        <Button variant="outline" onClick={load}>Try again</Button>
      </div>
    );
  }

  // OOO state
  if (payload?.ooo_active) {
    return (
      <div className="w-full max-w-2xl mx-auto rounded-lg border border-border bg-secondary/30 p-6 text-center space-y-3">
        <CalIcon className="h-8 w-8 mx-auto text-muted-foreground" />
        <h3 className="text-lg font-semibold">Our Talent Team is currently unavailable</h3>
        {payload.ooo_end && (
          <p className="text-sm text-muted-foreground">We're back on {payload.ooo_end}.</p>
        )}
        <p className="text-sm text-muted-foreground">
          Please continue your application — we'll reach out when we return.
        </p>
      </div>
    );
  }

  const totalSec = (payload?.config?.lock_days_ahead ? 10 : 10) * 60; // reservation default 10 min
  const pct = value?.reserved_until ? Math.max(0, (secondsLeft / Math.max(totalSec, 1)) * 100) : 0;
  const timerColor =
    secondsLeft <= 30 ? "text-red-600 border-red-300 bg-red-50" :
    secondsLeft <= 120 ? "text-amber-600 border-amber-300 bg-amber-50" :
    "text-primary border-primary/30 bg-primary/5";

  const mm = String(Math.floor(secondsLeft / 60)).padStart(1, "0");
  const ss = String(secondsLeft % 60).padStart(2, "0");

  return (
    <div className="w-full max-w-3xl mx-auto space-y-5">
      {/* PHT banner */}
      <div className="border-t border-b border-[#b08d57]/40 py-3 text-center">
        <p className="text-[11px] font-semibold tracking-[1px] uppercase" style={{ color: "#b08d57" }}>
          All times shown in Philippine Standard Time (PHT)
        </p>
      </div>

      {payload?.extended_window && (
        <div className="rounded-lg border border-primary/30 bg-primary/5 px-4 py-3 text-center">
          <p className="text-sm font-medium text-primary">Additional days shown due to high demand</p>
        </div>
      )}

      {/* Reservation timer */}
      {value?.slot_id && !expired && secondsLeft > 0 && (
        <div className={cn("sticky top-1 z-10 rounded-lg border px-4 py-3 flex items-center gap-3", timerColor)}>
          <Clock className="h-4 w-4 shrink-0" />
          <div className="flex-1 min-w-0">
            <div className="font-semibold text-sm">
              Reserved for {mm}:{ss} remaining
            </div>
            <p className="text-xs opacity-80">
              Complete the rest of the form before time runs out to lock in your slot.
            </p>
          </div>
        </div>
      )}

      {/* Expired banner */}
      {expired && (
        <div className="rounded-lg border border-red-300 bg-red-50 text-red-700 px-4 py-3 text-sm font-medium">
          Reservation expired. Please pick another slot.
        </div>
      )}

      {/* Day tabs */}
      <div className={cn("grid gap-2", dates.length > 3 ? "grid-cols-2 sm:grid-cols-4" : "grid-cols-3")}>
        {dates.map((d) => {
          const { top, bottom } = tabLabel(d);
          const isActive = d === activeDate;
          return (
            <button
              key={d}
              type="button"
              onClick={() => setActiveDate(d)}
              className={cn(
                "rounded-lg border px-3 py-2 text-center transition-colors",
                isActive
                  ? "bg-primary text-primary-foreground border-primary"
                  : "bg-background text-foreground border-border hover:border-primary/50"
              )}
            >
              <div className="text-[10px] uppercase tracking-wide opacity-80">{top}</div>
              <div className="text-sm font-semibold">{bottom}</div>
            </button>
          );
        })}
      </div>

      {/* Slot grid */}
      {!activeDate ? (
        <div className="text-center text-sm text-muted-foreground py-6">
          Select a day to see available time slots.
        </div>
      ) : slots.length === 0 ? (
        <div className="text-center text-sm text-muted-foreground py-6">
          No slots available for this day.
        </div>
      ) : (
        <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
          {slots.map((s) => {
            const isSelected = value?.slot_id === s.id;
            const isTaken = takenIds.has(s.id);
            return (
              <button
                key={s.id}
                type="button"
                disabled={disabled || isTaken}
                onClick={() => pickSlot(s)}
                className={cn(
                  "min-h-[48px] rounded-lg border px-3 py-3 text-sm font-semibold transition-all relative",
                  isTaken && "bg-secondary text-muted-foreground border-border cursor-not-allowed",
                  !isTaken && !isSelected && "bg-background text-foreground border-border hover:ring-2 hover:ring-primary/30 cursor-pointer",
                  isSelected && "bg-primary text-primary-foreground border-primary ring-2 ring-[#b08d57]"
                )}
                aria-pressed={isSelected}
              >
                {isTaken ? "Taken" : s.display_time}
                {pendingSlotId === s.id && (
                  <Loader2 className="absolute top-1 right-1 h-3 w-3 animate-spin opacity-70" />
                )}
              </button>
            );
          })}
        </div>
      )}

      {/* Selected confirmation */}
      {value?.slot_id && !expired && secondsLeft > 0 && (
        <div className="rounded-lg border border-border bg-secondary/30 p-4">
          <p className="text-xs uppercase tracking-wide text-muted-foreground mb-1">Your selected time</p>
          <p className="text-lg font-semibold text-primary">
            {value.display_date} at {value.display_time} (PHT)
          </p>
          <p className="text-sm text-muted-foreground mt-1">Confirmed Zoom interview · 30 minutes</p>
          <button
            type="button"
            onClick={changeSlot}
            className="mt-2 text-xs underline text-muted-foreground hover:text-foreground"
          >
            Change slot
          </button>
        </div>
      )}
    </div>
  );
};

export default ScheduleCallWidget;
