import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Loader2, Save, Lock } from "lucide-react";
import { toast } from "sonner";
import { useHrIdentity } from "@/hooks/useHrIdentity";

type Props = {
  open: boolean;
  onClose: () => void;
  responseId: string | null;
  candidateName?: string;
};

export function EmployeeHrNotesDialog({ open, onClose, responseId, candidateName }: Props) {
  const { hrId } = useHrIdentity();
  const [loading, setLoading] = useState(false);
  const [saving, setSaving] = useState(false);
  const [bank, setBank] = useState("");
  const [gcash, setGcash] = useState("");
  const [other, setOther] = useState("");

  useEffect(() => {
    if (!open || !responseId) return;
    let active = true;
    setLoading(true);
    (supabase.from("hr_candidate_extras") as any)
      .select("bank_account_details, digital_pay_gcash, other_notes")
      .eq("response_id", responseId)
      .maybeSingle()
      .then(({ data }: any) => {
        if (!active) return;
        setBank(data?.bank_account_details || "");
        setGcash(data?.digital_pay_gcash || "");
        setOther(data?.other_notes || "");
        setLoading(false);
      });
    return () => { active = false; };
  }, [open, responseId]);

  const save = async () => {
    if (!responseId) return;
    setSaving(true);
    try {
      const { error } = await (supabase.from("hr_candidate_extras") as any).upsert({
        response_id: responseId,
        bank_account_details: bank.trim() || null,
        digital_pay_gcash: gcash.trim() || null,
        other_notes: other.trim() || null,
        updated_by_hr_id: hrId || null,
      }, { onConflict: "response_id" });
      if (error) throw error;
      toast.success("HR notes saved");
      onClose();
    } catch (e: any) {
      toast.error(e?.message || "Save failed");
    } finally {
      setSaving(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={(o) => { if (!o && !saving) onClose(); }}>
      <DialogContent className="max-w-lg">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2" style={{ color: "#1a2547" }}>
            <Lock className="h-4 w-4" /> HR Only — Payment & Notes
          </DialogTitle>
          <DialogDescription>
            {candidateName ? <>For <strong>{candidateName}</strong>. </> : null}
            Private to HR. The candidate cannot see or edit these fields.
          </DialogDescription>
        </DialogHeader>

        {loading ? (
          <div className="py-8 flex justify-center"><Loader2 className="h-5 w-5 animate-spin text-muted-foreground" /></div>
        ) : (
          <div className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="hr-bank">Bank Account Details</Label>
              <Textarea
                id="hr-bank"
                value={bank}
                onChange={(e) => setBank(e.target.value)}
                rows={4}
                placeholder="Bank name, account name, account number, branch…"
                className="min-h-[112px]"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="hr-gcash">Digital Pay / GCash</Label>
              <Input
                id="hr-gcash"
                value={gcash}
                onChange={(e) => setGcash(e.target.value)}
                placeholder="e.g. GCash +63 9XX XXX XXXX"
                className="min-h-[44px]"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="hr-other">Others</Label>
              <Textarea
                id="hr-other"
                value={other}
                onChange={(e) => setOther(e.target.value)}
                rows={4}
                placeholder="Any other HR-only notes…"
                className="min-h-[112px]"
              />
            </div>
          </div>
        )}

        <DialogFooter>
          <Button variant="outline" onClick={onClose} disabled={saving} className="min-h-[44px]">Cancel</Button>
          <Button
            onClick={save}
            disabled={saving || loading || !responseId}
            className="min-h-[44px]"
            style={{ background: "#1a2547", color: "white" }}
          >
            {saving ? <><Loader2 className="h-4 w-4 mr-1.5 animate-spin" /> Saving…</> : <><Save className="h-4 w-4 mr-1.5" /> Save</>}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
