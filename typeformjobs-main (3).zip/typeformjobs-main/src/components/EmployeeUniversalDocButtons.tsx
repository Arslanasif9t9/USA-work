import { useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { Loader2, FileSignature, FileText, Palmtree, FileWarning, AlertTriangle, Banknote, IdCard, Sparkles, Copy, Check, Mail, UserPlus, FilePlus } from "lucide-react";
import { toast } from "sonner";
import { HrCopyCheckbox, defaultHrCopyState, type HrCopyState } from "@/components/HrCopyCheckbox";
import { SendPerformanceWarningDialog } from "@/components/SendPerformanceWarningDialog";
import SendScheduleControl, { type SendScheduleValue } from "@/components/SendScheduleControl";
import { AiAssistButton } from "@/components/AiAssistButton";
import { insertScheduledSend, formatScheduledFor } from "@/lib/scheduledSends";
import { UniversalHoldButtons } from "@/components/UniversalHoldButtons";
import SendOnboardingTestDialog from "@/components/SendOnboardingTestDialog";

type DocKind = "nda" | "joining_nda" | "exit_nda" | "settlement" | "leave" | "cash_advance" | "id_collection";

// Scheduler send_type per doc kind (target_function is META[kind].fn).
const SCHEDULE_SEND_TYPE: Record<DocKind, string> = {
  nda: "nda",
  joining_nda: "nda_joining",
  exit_nda: "nda_exit",
  settlement: "settlement",
  leave: "sick_leave",
  cash_advance: "cash_advance",
  id_collection: "id_collection",
};

const META: Record<DocKind, {
  fn: string;
  title: string;
  icon: React.ComponentType<{ className?: string }>;
  successLabel: string;
  description: string;
}> = {
  nda: {
    fn: "send-nda",
    title: "Send NDA to Anyone",
    icon: FileSignature,
    successLabel: "NDA",
    description: "Send an NDA signing link to any name + email. No system lookup — uses what you enter verbatim.",
  },
  joining_nda: {
    fn: "send-joining-nda",
    title: "Send Joining NDA to Anyone",
    icon: FileSignature,
    successLabel: "Joining NDA",
    description: "Send the Joining NDA (NDA 1 — full confidentiality & non-compete) signing link to any name + email. No system lookup — uses what you enter verbatim.",
  },
  exit_nda: {
    fn: "send-exit-nda",
    title: "Send Exit NDA to Anyone",
    icon: FileSignature,
    successLabel: "Exit NDA",
    description: "Send the Exit Settlement & Confidentiality Agreement (NDA 2 — zero-balance settlement + post-departure obligations + data deletion) signing link to any name + email. No system lookup — uses what you enter verbatim.",
  },
  settlement: {
    fn: "send-settlement",
    title: "Send Settlement to Anyone",
    icon: FileText,
    successLabel: "Settlement form",
    description: "Send a settlement form link to any name + email. No system lookup — uses what you enter verbatim.",
  },
  leave: {
    fn: "send-leave-form",
    title: "Send Leave Form to Anyone",
    icon: Palmtree,
    successLabel: "Leave form",
    description: "Send a leave request form to any name + email. No system lookup — uses what you enter verbatim.",
  },
  cash_advance: {
    fn: "send-cash-advance-form",
    title: "Send Cash Advance Form to Anyone",
    icon: Banknote,
    successLabel: "Cash advance form",
    description: "Send a cash advance request form to any name + email. No system lookup — uses what you enter verbatim.",
  },
  id_collection: {
    fn: "send-id-collection-form",
    title: "Send ID Collection Form to Anyone",
    icon: IdCard,
    successLabel: "ID collection form",
    description: "Send an ID collection form to any name + email. No system lookup — uses what you enter verbatim.",
  },
};

export function EmployeeUniversalDocButtons() {
  const [open, setOpen] = useState<DocKind | null>(null);
  const [perfWarnOpen, setPerfWarnOpen] = useState(false);
  return (
    <>
      <Button
        size="sm"
        variant="outline"
        onClick={() => setOpen("joining_nda")}
        className="min-h-[44px] sm:min-h-0"
        style={{ borderColor: "#b08d57", color: "#b08d57" }}
        title="Send the Joining NDA (NDA 1) to any name + email"
      >
        <FileSignature className="h-4 w-4 mr-1.5" /> Send Joining NDA to Anyone
      </Button>
      <Button
        size="sm"
        variant="outline"
        onClick={() => setOpen("exit_nda")}
        className="min-h-[44px] sm:min-h-0"
        style={{ borderColor: "#b08d57", color: "#b08d57" }}
        title="Send the Exit NDA (NDA 2) to any name + email"
      >
        <FileSignature className="h-4 w-4 mr-1.5" /> Send Exit NDA to Anyone
      </Button>
      <Button
        size="sm"
        variant="outline"
        onClick={() => setOpen("settlement")}
        className="min-h-[44px] sm:min-h-0"
        style={{ borderColor: "#b45309", color: "#b45309" }}
        title="Send a settlement form to any name + email"
      >
        <FileText className="h-4 w-4 mr-1.5" /> Send Settlement to Anyone
      </Button>
      <Button
        size="sm"
        variant="outline"
        onClick={() => setOpen("leave")}
        className="min-h-[44px] sm:min-h-0"
        style={{ borderColor: "#1a2547", color: "#1a2547" }}
        title="Send a leave form to any name + email"
      >
        <Palmtree className="h-4 w-4 mr-1.5" /> Send Leave Form to Anyone
      </Button>
      <Button
        size="sm"
        variant="outline"
        onClick={() => setOpen("cash_advance")}
        className="min-h-[44px] sm:min-h-0"
        style={{ borderColor: "#15803d", color: "#15803d" }}
        title="Send a cash advance form to any name + email"
      >
        <Banknote className="h-4 w-4 mr-1.5" /> Send Cash Advance Form to Anyone
      </Button>
      <UniversalPreConsultationButton />
      <Button
        size="sm"
        variant="outline"
        onClick={() => setOpen("id_collection")}
        className="min-h-[44px] sm:min-h-0"
        style={{ borderColor: "#6d28d9", color: "#6d28d9" }}
        title="Send an ID collection form to any name + email"
      >
        <IdCard className="h-4 w-4 mr-1.5" /> Send ID Collection Form to Anyone
      </Button>
      <Button
        size="sm"
        variant="outline"
        onClick={() => setPerfWarnOpen(true)}
        className="min-h-[44px] sm:min-h-0"
        style={{ borderColor: "#d97706", color: "#d97706" }}
        title="Send a performance warning to any name + email"
      >
        <AlertTriangle className="h-4 w-4 mr-1.5" /> Send Performance Warning
      </Button>
      <UniversalTerminationButton />
      <UniversalCustomDocumentButton />
      <UniversalWelcomeEmailButton />
      <UniversalOnboardingFormButton />
      <SendOnboardingTestDialog />
      <UniversalHoldButtons />

      {open && (
        <UniversalDocModal kind={open} onClose={() => setOpen(null)} />
      )}
      <SendPerformanceWarningDialog open={perfWarnOpen} onOpenChange={setPerfWarnOpen} />
    </>
  );
}

function UniversalTerminationButton() {
  const [open, setOpen] = useState(false);
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [termType, setTermType] = useState<"evaluation" | "regular">("regular");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const [hrCopy, setHrCopy] = useState<HrCopyState>(defaultHrCopyState);

  const reset = () => { setName(""); setEmail(""); setTermType("regular"); setPassword(""); setHrCopy(defaultHrCopyState); };

  const submit = async () => {
    if (!name.trim()) return toast.error("Name is required");
    if (!email.trim() || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim())) {
      return toast.error("Valid email is required");
    }
    if (!password.trim()) return toast.error("Boss password is required");
    setLoading(true);
    try {
      const { data, error } = await supabase.functions.invoke("send-universal-termination", {
        body: {
          name: name.trim(),
          email: email.trim(),
          termination_type: termType,
          password,
          hr_copy_requested: hrCopy.requested === true,
          hr_copy_email_override: hrCopy.requested && hrCopy.override ? hrCopy.override : null,
        },
      });
      if (error) {
        const reason = (data as any)?.error || (data as any)?.reason || error.message || "send_failed";
        toast.error(String(reason));
        return;
      }
      const d: any = data;
      if (d?.ok === false || d?.error) {
        toast.error(String(d?.reason || d?.error || "send_failed"));
        return;
      }
      toast.success(`Termination notice sent to ${email.trim()}`);
      reset();
      setOpen(false);
    } catch (e: any) {
      toast.error(e?.message || "Network error — please retry");
    } finally {
      setLoading(false);
    }
  };

  return (
    <>
      <Button
        size="sm"
        variant="outline"
        onClick={() => setOpen(true)}
        className="min-h-[44px] sm:min-h-0"
        style={{ borderColor: "#dc2626", color: "#dc2626" }}
        title="Send a formal Notice of Termination to any name + email"
      >
        <FileWarning className="h-4 w-4 mr-1.5" /> Send Termination Notice to Anyone
      </Button>
      <Dialog open={open} onOpenChange={(o) => !o && !loading && (reset(), setOpen(false))}>
        <DialogContent className="sm:max-w-[480px]">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <FileWarning className="h-4 w-4" style={{ color: "#dc2626" }} /> Send Termination Notice to Anyone
            </DialogTitle>
            <DialogDescription>
              Sends a formal "Notice of Termination" email to any name + email. No system lookup — no employee record is created or modified. Requires the boss termination password.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="ut-name">Full Name</Label>
              <Input id="ut-name" value={name} onChange={(e) => setName(e.target.value)} placeholder="Jane Doe" className="min-h-[44px] sm:min-h-0" disabled={loading} />
            </div>
            <div className="space-y-2">
              <Label htmlFor="ut-email">Email</Label>
              <Input id="ut-email" type="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="jane@example.com" className="min-h-[44px] sm:min-h-0" disabled={loading} />
            </div>
            <div className="space-y-2">
              <Label>Type (internal audit only — recipient sees one formal message)</Label>
              <RadioGroup value={termType} onValueChange={(v) => setTermType(v as "evaluation" | "regular")} className="flex flex-col gap-2">
                <div className="flex items-center gap-2">
                  <RadioGroupItem id="ut-regular" value="regular" disabled={loading} />
                  <Label htmlFor="ut-regular" className="font-normal cursor-pointer">Termination</Label>
                </div>
                <div className="flex items-center gap-2">
                  <RadioGroupItem id="ut-eval" value="evaluation" disabled={loading} />
                  <Label htmlFor="ut-eval" className="font-normal cursor-pointer">Trial Termination</Label>
                </div>
              </RadioGroup>
            </div>
            <div className="space-y-2">
              <Label htmlFor="ut-pwd">Boss Password</Label>
              <Input id="ut-pwd" type="password" value={password} onChange={(e) => setPassword(e.target.value)} placeholder="••••••••" className="min-h-[44px] sm:min-h-0" disabled={loading} autoComplete="off" />
            </div>
            <HrCopyCheckbox
              value={hrCopy}
              onChange={setHrCopy}
              disabled={loading}
              label="If sent, send copy to internal backup inbox"
              idPrefix="ut-hrcopy"
            />
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => { reset(); setOpen(false); }} disabled={loading} className="min-h-[44px] sm:min-h-0">
              Cancel
            </Button>
            <Button
              onClick={submit}
              disabled={loading}
              className="min-h-[44px] sm:min-h-0 text-white"
              style={{ backgroundColor: "#dc2626" }}
            >
              {loading ? <><Loader2 className="h-4 w-4 mr-1.5 animate-spin" /> Sending…</> : "Send Termination Notice"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}

// Universal "Send Custom Document" — produces ANY one-page signable document
// (contract, NDA, agreement, letter). Body fully custom + AI assist, optional
// custom-company branding. Goes through SignFlow and lands in Signed Documents.
const CUSTOM_DOC_SOFT_CAP = 1800;

function UniversalCustomDocumentButton() {
  const [open, setOpen] = useState(false);
  const [loading, setLoading] = useState(false);
  const [title, setTitle] = useState("");
  const [bodyText, setBodyText] = useState("");
  const [managerName, setManagerName] = useState("Cathy Anderson");
  const [signerName, setSignerName] = useState("");
  const [signerEmail, setSignerEmail] = useState("");
  const [customCompany, setCustomCompany] = useState(false);
  const [companyName, setCompanyName] = useState("");
  const [companyEmail, setCompanyEmail] = useState("");
  const [companyWebsite, setCompanyWebsite] = useState("");
  const [hrCopy, setHrCopy] = useState<HrCopyState>(defaultHrCopyState);
  const [signingUrl, setSigningUrl] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);

  const reset = () => {
    setTitle(""); setBodyText(""); setManagerName("Cathy Anderson");
    setSignerName(""); setSignerEmail("");
    setCustomCompany(false); setCompanyName(""); setCompanyEmail(""); setCompanyWebsite("");
    setHrCopy(defaultHrCopyState); setSigningUrl(null); setCopied(false);
  };

  const close = () => { if (!loading) { reset(); setOpen(false); } };

  const charCount = bodyText.length;
  const overSoft = charCount > CUSTOM_DOC_SOFT_CAP;
  const nearSoft = !overSoft && charCount > CUSTOM_DOC_SOFT_CAP * 0.85;

  const submit = async () => {
    if (!title.trim()) return toast.error("Document title is required");
    if (!bodyText.trim()) return toast.error("Document body is required");
    if (!signerName.trim()) return toast.error("Signer name is required");
    if (!signerEmail.trim() || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(signerEmail.trim())) {
      return toast.error("Valid signer email is required");
    }
    if (customCompany && !companyName.trim()) {
      return toast.error("Company name is required in Custom Company mode");
    }
    setLoading(true);
    try {
      const branding = customCompany
        ? { companyName: companyName.trim(), email: companyEmail.trim(), website: companyWebsite.trim() }
        : null;
      const { data, error } = await supabase.functions.invoke("send-custom-document", {
        body: {
          document_title: title.trim(),
          body_text: bodyText.trim(),
          manager_name: managerName.trim() || "Cathy Anderson",
          branding,
          signer_name: signerName.trim(),
          signer_email: signerEmail.trim(),
          hr_copy_requested: hrCopy.requested === true,
          hr_copy_email_override: hrCopy.requested && hrCopy.override ? hrCopy.override : null,
        },
      });
      if (error) {
        const reason = (data as any)?.reason || (data as any)?.error || error.message || "send_failed";
        toast.error(String(reason));
        return;
      }
      const d: any = data;
      if (d?.ok === false || d?.error) {
        toast.error(String(d?.reason || d?.error || "send_failed"));
        return;
      }
      toast.success(`Custom document sent to ${signerEmail.trim()}`);
      if (d?.signing_url) setSigningUrl(String(d.signing_url));
    } catch (e: any) {
      toast.error(e?.message || "Network error — please retry");
    } finally {
      setLoading(false);
    }
  };

  return (
    <>
      <Button
        size="sm"
        variant="outline"
        onClick={() => setOpen(true)}
        className="min-h-[44px] sm:min-h-0"
        style={{ borderColor: "#1a2547", color: "#1a2547" }}
        title="Create and send any one-page signable document to any name + email"
      >
        <FilePlus className="h-4 w-4 mr-1.5" /> Send Custom Document
      </Button>
      <Dialog open={open} onOpenChange={(o) => !o && close()}>
        <DialogContent className="sm:max-w-[560px] max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <FilePlus className="h-4 w-4" style={{ color: "#1a2547" }} /> Send Custom Document
            </DialogTitle>
            <DialogDescription>
              Create any one-page signable document (contract, NDA, agreement, letter). It goes through SignFlow e-sign and lands in Signed Documents once signed. No approval step.
            </DialogDescription>
          </DialogHeader>

          {signingUrl ? (
            <div className="space-y-4">
              <p className="text-sm text-muted-foreground">
                Document sent. The signing link below was emailed to the signer:
              </p>
              <div className="flex items-center gap-2">
                <Input readOnly value={signingUrl} className="min-h-[44px] sm:min-h-0 text-xs" />
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  className="min-h-[44px] sm:min-h-0 shrink-0"
                  onClick={() => { navigator.clipboard.writeText(signingUrl); setCopied(true); setTimeout(() => setCopied(false), 1500); }}
                >
                  {copied ? <Check className="h-4 w-4" /> : <Copy className="h-4 w-4" />}
                </Button>
              </div>
              <DialogFooter>
                <Button onClick={close} className="min-h-[44px] sm:min-h-0">Done</Button>
              </DialogFooter>
            </div>
          ) : (
            <>
              <div className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="ucd-title">Document Title</Label>
                  <Input id="ucd-title" value={title} onChange={(e) => setTitle(e.target.value)} placeholder="e.g. Universal Freelancer Contract" className="min-h-[44px] sm:min-h-0" disabled={loading} />
                </div>

                <div className="space-y-3 rounded-md border p-3">
                  <div className="flex items-center justify-between">
                    <Label htmlFor="ucd-brand" className="cursor-pointer">
                      Branding: {customCompany ? "Custom Company" : "Expert Intuitive Advisor"}
                    </Label>
                    <Switch id="ucd-brand" checked={customCompany} onCheckedChange={setCustomCompany} disabled={loading} />
                  </div>
                  {customCompany && (
                    <div className="space-y-3">
                      <div className="space-y-2">
                        <Label htmlFor="ucd-company">Company Name</Label>
                        <Input id="ucd-company" value={companyName} onChange={(e) => setCompanyName(e.target.value)} placeholder="Acme Holdings Inc." className="min-h-[44px] sm:min-h-0" disabled={loading} />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="ucd-cemail">Company Email</Label>
                        <Input id="ucd-cemail" value={companyEmail} onChange={(e) => setCompanyEmail(e.target.value)} placeholder="hr@acme.com" className="min-h-[44px] sm:min-h-0" disabled={loading} />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="ucd-cweb">Company Website</Label>
                        <Input id="ucd-cweb" value={companyWebsite} onChange={(e) => setCompanyWebsite(e.target.value)} placeholder="acme.com" className="min-h-[44px] sm:min-h-0" disabled={loading} />
                      </div>
                    </div>
                  )}
                </div>

                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <Label htmlFor="ucd-body">Document Body</Label>
                    <AiAssistButton
                      long
                      context={title.trim() ? `a professional one-page "${title.trim()}" body` : "a professional one-page document body"}
                      title="AI Assist — write the document body"
                      placeholder={`Describe the document you want, e.g. "a freelance services contract for a graphic designer, monthly retainer, IP assigned to client, confidentiality, 30-day termination notice"`}
                      onAccept={(text) => setBodyText(text)}
                    />
                  </div>
                  <Textarea
                    id="ucd-body"
                    value={bodyText}
                    onChange={(e) => setBodyText(e.target.value)}
                    placeholder="Write the full document body here, or use AI Assist…"
                    rows={9}
                    disabled={loading}
                  />
                  <div className="flex items-center justify-between text-xs">
                    <span className={overSoft ? "text-destructive font-medium" : nearSoft ? "text-amber-600 font-medium" : "text-muted-foreground"}>
                      {charCount} / {CUSTOM_DOC_SOFT_CAP}
                    </span>
                    {(nearSoft || overSoft) && (
                      <span className="text-muted-foreground">Longer documents may flow to a second page.</span>
                    )}
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="ucd-manager">Manager Signature Name</Label>
                  <Input id="ucd-manager" value={managerName} onChange={(e) => setManagerName(e.target.value)} placeholder="Cathy Anderson" className="min-h-[44px] sm:min-h-0" disabled={loading} />
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div className="space-y-2">
                    <Label htmlFor="ucd-signer">Signer Name</Label>
                    <Input id="ucd-signer" value={signerName} onChange={(e) => setSignerName(e.target.value)} placeholder="Jane Doe" className="min-h-[44px] sm:min-h-0" disabled={loading} />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="ucd-semail">Signer Email</Label>
                    <Input id="ucd-semail" type="email" value={signerEmail} onChange={(e) => setSignerEmail(e.target.value)} placeholder="jane@example.com" className="min-h-[44px] sm:min-h-0" disabled={loading} />
                  </div>
                </div>

                <HrCopyCheckbox
                  value={hrCopy}
                  onChange={setHrCopy}
                  disabled={loading}
                  label="When signed, send copy to internal backup inbox"
                  idPrefix="ucd-hrcopy"
                />
              </div>
              <DialogFooter>
                <Button variant="outline" onClick={close} disabled={loading} className="min-h-[44px] sm:min-h-0">Cancel</Button>
                <Button onClick={submit} disabled={loading} className="min-h-[44px] sm:min-h-0 text-white" style={{ backgroundColor: "#1a2547" }}>
                  {loading ? <><Loader2 className="h-4 w-4 mr-1.5 animate-spin" /> Sending…</> : "Send Custom Document"}
                </Button>
              </DialogFooter>
            </>
          )}
        </DialogContent>
      </Dialog>
    </>
  );
}


function UniversalDocModal({ kind, onClose }: { kind: DocKind; onClose: () => void }) {
  const meta = META[kind];
  const Icon = meta.icon;
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [hrMessage, setHrMessage] = useState("");
  const [idTextStyle, setIdTextStyle] = useState("bullets");
  const [loading, setLoading] = useState(false);
  const [hrCopy, setHrCopy] = useState<HrCopyState>(defaultHrCopyState);
  const [schedule, setSchedule] = useState<SendScheduleValue>({ mode: "now" });

  const submit = async () => {
    if (!name.trim()) return toast.error("Name is required");
    if (!email.trim() || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim())) {
      return toast.error("Valid email is required");
    }
    setLoading(true);
    try {
      // The EXACT Send-Now payload — reused for both paths so replay is identical.
      const body = {
        name: name.trim(),
        email: email.trim(),
        hr_copy_requested: hrCopy.requested === true,
        hr_copy_email_override: hrCopy.requested && hrCopy.override ? hrCopy.override : null,
        // Only the ID collection form carries an optional HR message to the recipient.
        ...(kind === "id_collection" && hrMessage.trim() ? { id_hr_message: hrMessage.trim() } : {}),
        ...(kind === "id_collection" ? { id_text_style: idTextStyle } : {}),
      };

      // Scheduled branch: persist a pending row and do NOT send now.
      if (schedule.mode === "schedule") {
        await insertScheduledSend({
          send_type: SCHEDULE_SEND_TYPE[kind],
          target_function: meta.fn,
          payload: body,
          response_id: null,
          scheduled_for_utc: schedule.scheduled_for_utc,
          timezone: schedule.timezone,
        });
        toast.success(
          `${meta.successLabel} scheduled for ${formatScheduledFor(schedule.scheduled_for_utc, schedule.timezone)}`,
        );
        onClose();
        return;
      }

      const { data, error } = await supabase.functions.invoke(meta.fn, { body });
      if (error) {
        const reason = (data as any)?.reason || (data as any)?.error || error.message || "send_failed";
        toast.error(String(reason));
        return;
      }
      const d: any = data;
      if (d?.ok === false || d?.error) {
        toast.error(String(d?.reason || d?.error || "send_failed"));
        return;
      }
      toast.success(`${meta.successLabel} sent to ${email.trim()}`);
      onClose();
    } catch (e: any) {
      toast.error(e?.message || "Network error — please retry");
    } finally {
      setLoading(false);
    }
  };

  return (
    <Dialog open onOpenChange={(o) => !o && !loading && onClose()}>
      <DialogContent className="sm:max-w-[440px]">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Icon className="h-4 w-4" /> {meta.title}
          </DialogTitle>
          <DialogDescription>{meta.description}</DialogDescription>
        </DialogHeader>
        <div className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="udoc-name">Full Name</Label>
            <Input
              id="udoc-name"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="Jane Doe"
              className="min-h-[44px] sm:min-h-0"
              disabled={loading}
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="udoc-email">Email</Label>
            <Input
              id="udoc-email"
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="jane@example.com"
              className="min-h-[44px] sm:min-h-0"
              disabled={loading}
            />
          </div>
          {kind === "id_collection" && (
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <Label htmlFor="udoc-id-message">Message to recipient (optional)</Label>
                <AiAssistButton
                  context="ID collection request message to a candidate"
                  onAccept={(text) => setHrMessage(text.slice(0, 20000))}
                />
              </div>
              <Textarea
                id="udoc-id-message"
                value={hrMessage}
                onChange={(e) => setHrMessage(e.target.value)}
                placeholder="e.g. Please upload a clear photo of your government ID (front and back)."
                rows={3}
                maxLength={20000}
                disabled={loading}
              />
              <p className="text-xs text-muted-foreground">Shown to the recipient as a read-only note at the top of their form.</p>
              <div className="space-y-2 pt-1">
                <Label htmlFor="udoc-id-text-style">Text style</Label>
                <Select value={idTextStyle} onValueChange={setIdTextStyle} disabled={loading}>
                  <SelectTrigger id="udoc-id-text-style" className="min-h-[44px] sm:min-h-0">
                    <SelectValue placeholder="Choose a text style" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="bullets">Bullet points + line spacing</SelectItem>
                    <SelectItem value="spacing">Line spacing only</SelectItem>
                    <SelectItem value="paragraphs">Paragraphs with line spacing</SelectItem>
                  </SelectContent>
                </Select>
                <p className="text-xs text-muted-foreground">Controls how your message is formatted in the generated form/PDF.</p>
              </div>
            </div>
          )}
          <HrCopyCheckbox
            value={hrCopy}
            onChange={setHrCopy}
            disabled={loading}
            label={`If ${meta.successLabel.toLowerCase()} is completed, send copy to internal backup inbox`}
            idPrefix={`udoc-hrcopy-${kind}`}
          />
          <SendScheduleControl onChange={setSchedule} />
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={onClose} disabled={loading} className="min-h-[44px] sm:min-h-0">
            Cancel
          </Button>
          <Button onClick={submit} disabled={loading} className="min-h-[44px] sm:min-h-0">
            {loading ? <><Loader2 className="h-4 w-4 mr-1.5 animate-spin" /> {schedule.mode === "schedule" ? "Scheduling…" : "Sending…"}</> : (schedule.mode === "schedule" ? "Schedule" : "Send")}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

// Standalone "Psychic John" pre-consultation sender. Purple, password-gated
// (password = "John", hardcoded inline like other universal doc buttons),
// supports Send by Email or Generate Link only.
function UniversalPreConsultationButton() {
  const [open, setOpen] = useState(false);
  const [unlocked, setUnlocked] = useState(false);
  const [password, setPassword] = useState("");
  const [mode, setMode] = useState<"email" | "link">("email");
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [amount, setAmount] = useState("");
  const [duration, setDuration] = useState("");
  const [message, setMessage] = useState("");
  const [loading, setLoading] = useState(false);
  const [link, setLink] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);

  const reset = () => {
    setUnlocked(false); setPassword(""); setMode("email");
    setName(""); setEmail(""); setAmount(""); setDuration(""); setMessage("");
    setLink(null); setCopied(false);
  };

  const close = () => { if (!loading) { reset(); setOpen(false); } };

  const unlock = () => {
    if (password.trim() === "John") setUnlocked(true);
    else toast.error("Incorrect password");
  };

  const copyLink = async () => {
    if (!link) return;
    try {
      await navigator.clipboard.writeText(link);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch {
      toast.error("Could not copy — select and copy manually");
    }
  };

  const submit = async () => {
    if (!name.trim()) return toast.error("Name is required");
    if (mode === "email" && (!email.trim() || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim()))) {
      return toast.error("Valid email is required");
    }
    if (!amount.trim()) return toast.error("Amount is required");
    if (!duration.trim()) return toast.error("Session duration is required");
    setLoading(true);
    try {
      const { data, error } = await supabase.functions.invoke<any>("send-pre-consultation-form", {
        body: {
          name: name.trim(),
          email: mode === "email" ? email.trim() : (email.trim() || ""),
          send_mode: mode,
          pc_amount: amount.trim(),
          pc_duration: duration.trim(),
          pc_hr_message: message.trim() || null,
        },
      });
      if (error || data?.ok === false || data?.error) {
        toast.error(String(data?.reason || data?.error || error?.message || "send_failed"));
        return;
      }
      if (mode === "link") {
        setLink(data?.link || null);
        toast.success("Link generated");
      } else {
        toast.success(`Pre-consultation form sent to ${email.trim()}`);
        close();
      }
    } catch (e: any) {
      toast.error(e?.message || "Network error — please retry");
    } finally {
      setLoading(false);
    }
  };

  return (
    <>
      <Button
        size="sm"
        variant="outline"
        onClick={() => setOpen(true)}
        className="min-h-[44px] sm:min-h-0"
        style={{ borderColor: "#7c3aed", color: "#7c3aed" }}
        title="Send a Psychic John pre-consultation form to anyone"
      >
        <Sparkles className="h-4 w-4 mr-1.5" /> Send Pre-Consultation Form to Anyone
      </Button>
      <Dialog open={open} onOpenChange={(o) => !o && close()}>
        <DialogContent className="sm:max-w-[480px]">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Sparkles className="h-4 w-4" style={{ color: "#7c3aed" }} /> Send Pre-Consultation Form to Anyone
            </DialogTitle>
            <DialogDescription>
              Sends the "Psychic John" pre-consultation agreement to any name. Send by email or generate a copyable link. Protected by password.
            </DialogDescription>
          </DialogHeader>

          {!unlocked ? (
            <div className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="pc-pwd">Password</Label>
                <Input
                  id="pc-pwd"
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  onKeyDown={(e) => { if (e.key === "Enter") unlock(); }}
                  placeholder="••••••••"
                  className="min-h-[44px] sm:min-h-0"
                  autoComplete="off"
                />
              </div>
              <DialogFooter>
                <Button variant="outline" onClick={close} className="min-h-[44px] sm:min-h-0">Cancel</Button>
                <Button onClick={unlock} className="min-h-[44px] sm:min-h-0 text-white" style={{ backgroundColor: "#7c3aed" }}>
                  Unlock
                </Button>
              </DialogFooter>
            </div>
          ) : link ? (
            <div className="space-y-4">
              <Label>Copyable link (no email sent)</Label>
              <div className="flex items-center gap-2">
                <Input readOnly value={link} className="min-h-[44px] sm:min-h-0 text-xs" onFocus={(e) => e.currentTarget.select()} />
                <Button
                  type="button"
                  onClick={copyLink}
                  className="min-h-[44px] sm:min-h-0 text-white shrink-0"
                  style={{ backgroundColor: "#7c3aed" }}
                >
                  {copied ? <Check className="h-4 w-4" /> : <Copy className="h-4 w-4" />}
                </Button>
              </div>
              <DialogFooter>
                <Button variant="outline" onClick={close} className="min-h-[44px] sm:min-h-0">Done</Button>
              </DialogFooter>
            </div>
          ) : (
            <div className="space-y-4">
              <div className="space-y-2">
                <Label>Delivery</Label>
                <RadioGroup value={mode} onValueChange={(v) => setMode(v as "email" | "link")} className="flex flex-col gap-2">
                  <div className="flex items-center gap-2">
                    <RadioGroupItem id="pc-mode-email" value="email" disabled={loading} />
                    <Label htmlFor="pc-mode-email" className="font-normal cursor-pointer">Send by Email</Label>
                  </div>
                  <div className="flex items-center gap-2">
                    <RadioGroupItem id="pc-mode-link" value="link" disabled={loading} />
                    <Label htmlFor="pc-mode-link" className="font-normal cursor-pointer">Generate Link only</Label>
                  </div>
                </RadioGroup>
              </div>
              <div className="space-y-2">
                <Label htmlFor="pc-name">Full Name</Label>
                <Input id="pc-name" value={name} onChange={(e) => setName(e.target.value)} placeholder="Jane Doe" className="min-h-[44px] sm:min-h-0" disabled={loading} />
              </div>
              <div className="space-y-2">
                <Label htmlFor="pc-email">Email {mode === "link" && <span className="text-muted-foreground font-normal">(optional)</span>}</Label>
                <Input id="pc-email" type="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="jane@example.com" className="min-h-[44px] sm:min-h-0" disabled={loading} />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-2">
                  <Label htmlFor="pc-amount">Amount</Label>
                  <Input id="pc-amount" value={amount} onChange={(e) => setAmount(e.target.value)} placeholder="e.g. 200" className="min-h-[44px] sm:min-h-0" disabled={loading} />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="pc-duration">Session duration</Label>
                  <Input id="pc-duration" value={duration} onChange={(e) => setDuration(e.target.value)} placeholder="e.g. 25 minutes" className="min-h-[44px] sm:min-h-0" disabled={loading} />
                </div>
              </div>
              <div className="space-y-2">
                <Label htmlFor="pc-message">Message to recipient (optional)</Label>
                <Textarea id="pc-message" value={message} onChange={(e) => setMessage(e.target.value)} rows={3} maxLength={2000} placeholder="Optional note shown at the top of their form." disabled={loading} />
              </div>
              <DialogFooter>
                <Button variant="outline" onClick={close} disabled={loading} className="min-h-[44px] sm:min-h-0">Cancel</Button>
                <Button onClick={submit} disabled={loading} className="min-h-[44px] sm:min-h-0 text-white" style={{ backgroundColor: "#7c3aed" }}>
                  {loading ? <><Loader2 className="h-4 w-4 mr-1.5 animate-spin" /> {mode === "link" ? "Generating…" : "Sending…"}</> : (mode === "link" ? "Generate Link" : "Send Form")}
                </Button>
              </DialogFooter>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </>
  );
}

// Universal "Send Welcome Email to Anyone" — sends the same branded EIA welcome
// email (Angela Stein / HR signature, Sylvia WhatsApp line) to any name + email,
// plus a Position line. Admin-gated server-side. Additive — does not touch the
// per-row send-sylvia-welcome flow.
function UniversalWelcomeEmailButton() {
  const [open, setOpen] = useState(false);
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [position, setPosition] = useState("");
  const [loading, setLoading] = useState(false);

  const reset = () => { setName(""); setEmail(""); setPosition(""); };
  const close = () => { if (!loading) { reset(); setOpen(false); } };

  const submit = async () => {
    if (!name.trim()) return toast.error("Name is required");
    if (!email.trim() || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim())) {
      return toast.error("Valid email is required");
    }
    if (!position.trim()) return toast.error("Position is required");
    setLoading(true);
    try {
      const { data, error } = await supabase.functions.invoke<any>("send-welcome-email-universal", {
        body: { name: name.trim(), email: email.trim(), position: position.trim() },
      });
      if (error || data?.ok === false || data?.error) {
        toast.error(String(data?.reason || data?.error || error?.message || "send_failed"));
        return;
      }
      toast.success(`Welcome email sent to ${email.trim()}`);
      close();
    } catch (e: any) {
      toast.error(e?.message || "Network error — please retry");
    } finally {
      setLoading(false);
    }
  };

  return (
    <>
      <Button
        size="sm"
        variant="outline"
        onClick={() => setOpen(true)}
        className="min-h-[44px] sm:min-h-0"
        style={{ borderColor: "#1a2547", color: "#1a2547" }}
        title="Send the branded EIA welcome email to any name + email"
      >
        <Mail className="h-4 w-4 mr-1.5" /> Send Welcome Email to Anyone
      </Button>
      <Dialog open={open} onOpenChange={(o) => !o && close()}>
        <DialogContent className="sm:max-w-[440px]">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Mail className="h-4 w-4" style={{ color: "#1a2547" }} /> Send Welcome Email to Anyone
            </DialogTitle>
            <DialogDescription>
              Sends the branded EIA welcome email (same template everyone gets) to any name + email. No system lookup — uses what you enter verbatim.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="uwe-name">Full Name</Label>
              <Input id="uwe-name" value={name} onChange={(e) => setName(e.target.value)} placeholder="Jane Doe" className="min-h-[44px] sm:min-h-0" disabled={loading} />
            </div>
            <div className="space-y-2">
              <Label htmlFor="uwe-email">Email</Label>
              <Input id="uwe-email" type="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="jane@example.com" className="min-h-[44px] sm:min-h-0" disabled={loading} />
            </div>
            <div className="space-y-2">
              <Label htmlFor="uwe-position">Position</Label>
              <Input id="uwe-position" value={position} onChange={(e) => setPosition(e.target.value)} placeholder="e.g. Customer Support Specialist" className="min-h-[44px] sm:min-h-0" disabled={loading} />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={close} disabled={loading} className="min-h-[44px] sm:min-h-0">Cancel</Button>
            <Button onClick={submit} disabled={loading} className="min-h-[44px] sm:min-h-0 text-white" style={{ backgroundColor: "#1a2547" }}>
              {loading ? <><Loader2 className="h-4 w-4 mr-1.5 animate-spin" /> Sending…</> : "Send Welcome Email"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}

// Universal "Send Onboarding Form to Anyone" — mints a response-less onboarding
// token carrying HR's pre-filled text values, then sends the same branded
// onboarding invite email. The receiver fills only blanks + uploads. Admin-gated
// server-side. Additive — does not touch the per-hire onboarding send.
function UniversalOnboardingFormButton() {
  const [open, setOpen] = useState(false);
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [position, setPosition] = useState("");
  const [phone, setPhone] = useState("");
  const [onlinejobsUrl, setOnlinejobsUrl] = useState("");
  const [bank, setBank] = useState("");
  const [gcash, setGcash] = useState("");
  const [notes, setNotes] = useState("");
  const [loading, setLoading] = useState(false);
  const [link, setLink] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);

  const reset = () => {
    setName(""); setEmail(""); setPosition(""); setPhone(""); setOnlinejobsUrl("");
    setBank(""); setGcash(""); setNotes(""); setLink(null); setCopied(false);
  };
  const close = () => { if (!loading) { reset(); setOpen(false); } };

  const copyLink = async () => {
    if (!link) return;
    try {
      await navigator.clipboard.writeText(link);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch {
      toast.error("Could not copy — select and copy manually");
    }
  };

  const submit = async () => {
    if (!name.trim()) return toast.error("Name is required");
    if (!email.trim() || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim())) {
      return toast.error("Valid email is required");
    }
    setLoading(true);
    try {
      const prefill_data = {
        full_name: name.trim(),
        email: email.trim(),
        position_title: position.trim(),
        phone: phone.trim(),
        onlinejobs_profile_url: onlinejobsUrl.trim() || null,
        bank_account_details: bank.trim(),
        digital_pay_gcash: gcash.trim(),
        other_notes: notes.trim(),
      };
      const { data, error } = await supabase.functions.invoke<any>("send-onboarding-form-universal", {
        body: { name: name.trim(), email: email.trim(), position: position.trim(), prefill_data },
      });
      if (error || data?.ok === false || data?.error) {
        toast.error(String(data?.reason || data?.error || error?.message || "send_failed"));
        return;
      }
      toast.success(`Onboarding form sent to ${email.trim()}`);
      setLink(data?.link || null);
    } catch (e: any) {
      toast.error(e?.message || "Network error — please retry");
    } finally {
      setLoading(false);
    }
  };

  return (
    <>
      <Button
        size="sm"
        variant="outline"
        onClick={() => setOpen(true)}
        className="min-h-[44px] sm:min-h-0"
        style={{ borderColor: "#0f766e", color: "#0f766e" }}
        title="Send the onboarding form to any name + email, pre-filling the text fields"
      >
        <UserPlus className="h-4 w-4 mr-1.5" /> Send Onboarding Form to Anyone
      </Button>
      <Dialog open={open} onOpenChange={(o) => !o && close()}>
        <DialogContent className="sm:max-w-[480px]">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <UserPlus className="h-4 w-4" style={{ color: "#0f766e" }} /> Send Onboarding Form to Anyone
            </DialogTitle>
            <DialogDescription>
              Pre-fill any text fields below — the receiver can correct them and fills the rest, then uploads their photo and screenshots. No system lookup.
            </DialogDescription>
          </DialogHeader>

          {link ? (
            <div className="space-y-4">
              <Label>Onboarding link (also emailed)</Label>
              <div className="flex items-center gap-2">
                <Input readOnly value={link} className="min-h-[44px] sm:min-h-0 text-xs" onFocus={(e) => e.currentTarget.select()} />
                <Button type="button" onClick={copyLink} className="min-h-[44px] sm:min-h-0 text-white shrink-0" style={{ backgroundColor: "#0f766e" }}>
                  {copied ? <Check className="h-4 w-4" /> : <Copy className="h-4 w-4" />}
                </Button>
              </div>
              <DialogFooter>
                <Button variant="outline" onClick={close} className="min-h-[44px] sm:min-h-0">Done</Button>
              </DialogFooter>
            </div>
          ) : (
            <>
              <div className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="uof-name">Full Name</Label>
                  <Input id="uof-name" value={name} onChange={(e) => setName(e.target.value)} placeholder="Jane Doe" className="min-h-[44px] sm:min-h-0" disabled={loading} />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="uof-email">Email</Label>
                  <Input id="uof-email" type="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="jane@example.com" className="min-h-[44px] sm:min-h-0" disabled={loading} />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="uof-position">Position</Label>
                  <Input id="uof-position" value={position} onChange={(e) => setPosition(e.target.value)} placeholder="e.g. Customer Support Specialist" className="min-h-[44px] sm:min-h-0" disabled={loading} />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="uof-phone">Phone <span className="text-muted-foreground font-normal">(optional)</span></Label>
                  <Input id="uof-phone" value={phone} onChange={(e) => setPhone(e.target.value)} placeholder="e.g. +63 9XX XXX XXXX" className="min-h-[44px] sm:min-h-0" disabled={loading} />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="uof-onlinejobs">OnlineJobs.ph Profile Link <span className="text-muted-foreground font-normal">(optional)</span></Label>
                  <Input id="uof-onlinejobs" type="url" value={onlinejobsUrl} onChange={(e) => setOnlinejobsUrl(e.target.value)} placeholder="https://www.onlinejobs.ph/jobseekers/info/..." className="min-h-[44px] sm:min-h-0" disabled={loading} />
                  <p className="text-xs text-muted-foreground">Paste the candidate's OnlineJobs.ph profile URL (optional).</p>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="uof-bank">Bank Account Details <span className="text-muted-foreground font-normal">(HR only, optional)</span></Label>
                  <Input id="uof-bank" value={bank} onChange={(e) => setBank(e.target.value)} className="min-h-[44px] sm:min-h-0" disabled={loading} />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="uof-gcash">Digital Pay / GCash <span className="text-muted-foreground font-normal">(optional)</span></Label>
                  <Input id="uof-gcash" value={gcash} onChange={(e) => setGcash(e.target.value)} className="min-h-[44px] sm:min-h-0" disabled={loading} />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="uof-notes">Others <span className="text-muted-foreground font-normal">(HR only, optional)</span></Label>
                  <Input id="uof-notes" value={notes} onChange={(e) => setNotes(e.target.value)} className="min-h-[44px] sm:min-h-0" disabled={loading} />
                </div>
                <p className="text-xs text-muted-foreground">Upload fields (photo, speed-test, typing test) are always filled by the receiver.</p>
              </div>
              <DialogFooter>
                <Button variant="outline" onClick={close} disabled={loading} className="min-h-[44px] sm:min-h-0">Cancel</Button>
                <Button onClick={submit} disabled={loading} className="min-h-[44px] sm:min-h-0 text-white" style={{ backgroundColor: "#0f766e" }}>
                  {loading ? <><Loader2 className="h-4 w-4 mr-1.5 animate-spin" /> Sending…</> : "Send Onboarding Form"}
                </Button>
              </DialogFooter>
            </>
          )}
        </DialogContent>
      </Dialog>
    </>
  );
}
