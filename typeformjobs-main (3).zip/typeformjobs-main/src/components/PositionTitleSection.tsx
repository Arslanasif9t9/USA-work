import { useEffect, useState, useCallback } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { AlertTriangle, Loader2 } from "lucide-react";
import { toast } from "sonner";
import {
  cleanPositionTitle,
  emitPositionTitleUpdated,
  POSITION_TITLE_UPDATED_EVENT,
} from "@/lib/positionTitle";
import { generateUniqueSlug } from "@/lib/slug";


type Props = {
  formId: string;
  formTitle: string;
  onTitleSynced?: () => void;
};


const INPUT_ID = "position-title-input";

const PositionTitleSection = ({ formId, formTitle, onTitleSynced }: Props) => {
  const [loaded, setLoaded] = useState(false);
  const [savedTitle, setSavedTitle] = useState<string | null>(null);
  const [draft, setDraft] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);

  const load = useCallback(async () => {
    const { data } = await supabase
      .from("form_metadata")
      .select("position_title")
      .eq("form_id", formId)
      .maybeSingle();
    const pt = (data?.position_title || null) as string | null;
    setSavedTitle(pt);
    if (pt && pt.trim()) {
      setDraft(pt);
    } else {
      // Auto-suggest from form name on first open
      setDraft(cleanPositionTitle(formTitle));
    }
    setLoaded(true);
  }, [formId, formTitle]);

  useEffect(() => {
    load();
  }, [load]);

  useEffect(() => {
    const handler = (e: Event) => {
      const detail = (e as CustomEvent).detail;
      // Only refetch for events about OTHER forms; our own save already
      // updated local state and an immediate refetch may read stale data.
      if (detail && detail.formId && detail.formId !== formId) return;
      if (!detail) load();
    };
    window.addEventListener(POSITION_TITLE_UPDATED_EVENT, handler);
    return () => window.removeEventListener(POSITION_TITLE_UPDATED_EVENT, handler);
  }, [formId, load]);

  const handleSave = async () => {
    const trimmed = draft.trim();
    if (!trimmed) {
      setError("Position title cannot be empty.");
      return;
    }
    if (trimmed.length > 80) {
      setError("Must be 80 characters or fewer.");
      return;
    }
    setError(null);
    setSaving(true);
    const isFirstSet = !savedTitle || !savedTitle.trim();
    const { error: err } = await supabase
      .from("form_metadata")
      .upsert(
        {
          form_id: formId,
          position_title: trimmed,
          updated_at: new Date().toISOString(),
        },
        { onConflict: "form_id" },
      );
    if (err) {
      setSaving(false);
      toast.error(err.message);
      return;
    }

    // Sync the form's display title to match the position title.
    // Only regenerate the slug on the very first set so existing shared
    // links keep working after later renames.
    const formUpdate: { title: string; slug?: string } = { title: trimmed };
    if (isFirstSet) {
      try {
        formUpdate.slug = await generateUniqueSlug(trimmed, formId);
      } catch {
        // fall back to leaving slug stable
      }
    }
    const { error: fErr } = await supabase
      .from("forms")
      .update(formUpdate)
      .eq("id", formId);
    setSaving(false);
    if (fErr) {
      toast.error(fErr.message);
      return;
    }
    setSavedTitle(trimmed);
    setDraft(trimmed);
    toast.success("Position title saved");
    emitPositionTitleUpdated(formId);
    onTitleSynced?.();
  };


  const focusInput = () => {
    const el = document.getElementById(INPUT_ID) as HTMLInputElement | null;
    if (el) {
      el.scrollIntoView({ behavior: "smooth", block: "center" });
      setTimeout(() => el.focus(), 250);
    }
  };

  const isMissing = loaded && (!savedTitle || !savedTitle.trim());
  const dirty = (draft || "").trim() !== (savedTitle || "").trim();

  return (
    <div className="border-b border-border bg-background">
      {isMissing && (
        <div
          className="flex flex-col sm:flex-row sm:items-center gap-2 sm:gap-3 px-4 md:px-6 py-3 bg-amber-50 border-b border-amber-200 text-amber-900"
          role="alert"
        >
          <div className="flex items-start gap-2 flex-1 min-w-0">
            <AlertTriangle className="h-4 w-4 mt-0.5 shrink-0" />
            <p className="text-sm leading-snug">
              No position title set. Required before next offer letter can be sent for this role.
            </p>
          </div>
          <Button
            size="sm"
            variant="outline"
            onClick={focusInput}
            className="min-h-[44px] sm:min-h-0 sm:h-9 bg-background shrink-0"
          >
            Set position title
          </Button>
        </div>
      )}

      <div className="px-4 md:px-6 py-4">
        <div className="max-w-2xl">
          <Label htmlFor={INPUT_ID} className="text-sm">
            Position Title <span className="text-destructive">*</span>
          </Label>
          <div className="mt-1.5 flex flex-col sm:flex-row gap-2">
            <Input
              id={INPUT_ID}
              value={draft}
              maxLength={80}
              onChange={(e) => {
                setDraft(e.target.value);
                if (error) setError(null);
              }}
              placeholder="e.g. Real Estate Lead Coordinator"
              className="min-h-[44px] sm:min-h-0 flex-1"
              aria-invalid={!!error}
              aria-describedby="position-title-help"
            />
            <Button
              onClick={handleSave}
              disabled={saving || !dirty}
              className="min-h-[44px] sm:min-h-0 sm:h-10"
            >
              {saving ? (
                <>
                  <Loader2 className="h-4 w-4 mr-2 animate-spin" /> Saving...
                </>
              ) : (
                "Save"
              )}
            </Button>
          </div>
          {error ? (
            <p className="text-xs text-destructive mt-1.5">{error}</p>
          ) : (
            <p id="position-title-help" className="text-xs text-muted-foreground mt-1.5">
              This is the official role name that appears in the candidate's offer letter and emails.
            </p>
          )}
        </div>
      </div>
    </div>
  );
};

export default PositionTitleSection;
