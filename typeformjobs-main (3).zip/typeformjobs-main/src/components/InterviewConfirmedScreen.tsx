import { CheckCircle2 } from "lucide-react";

type Props = {
  positionTitle?: string | null;
  candidateEmail?: string | null;
  displayDate: string;        // e.g. "Monday, May 19, 2026"
  displayTime: string;        // e.g. "2:00 PM"
};

const InterviewConfirmedScreen = ({ positionTitle, displayDate, displayTime }: Props) => {
  const GOLD = "#b08d57";
  const NAVY = "#1a2547";
  const INK = "#2b2b2b";

  return (
    <div className="w-full max-w-2xl mx-auto text-center px-4 space-y-6 py-10">
      <div
        className="mx-auto w-20 h-20 rounded-full flex items-center justify-center border-2"
        style={{ borderColor: GOLD }}
      >
        <CheckCircle2 className="h-11 w-11" style={{ color: GOLD }} />
      </div>

      <div className="space-y-3">
        <h1
          className="text-3xl md:text-[36px] leading-tight font-semibold"
          style={{ fontFamily: "'Cormorant Garamond', serif", color: NAVY }}
        >
          Application Received
        </h1>
        <p className="text-base" style={{ fontFamily: "'Inter', sans-serif", color: INK }}>
          Thank you for applying{positionTitle ? ` to ${positionTitle}` : ""}.
        </p>
      </div>

      <div className="mx-auto" style={{ width: 60, height: 1, background: GOLD }} />

      <div
        className="text-left max-w-md mx-auto space-y-4"
        style={{ fontFamily: "'Inter', sans-serif", color: INK, fontSize: 14, lineHeight: 1.7 }}
      >
        <p>
          We have successfully received your application along with your selected interview time:
        </p>
        <p className="text-center font-semibold" style={{ color: NAVY }}>
          {displayDate} at {displayTime} (Philippine Standard Time)
        </p>
        <p>
          If you are selected to move forward, our Talent Team will contact you with a Zoom meeting
          invitation for your scheduled interview time.
        </p>
        <p>
          If you do not hear from us with a Zoom invitation, this means we have not moved forward
          with your application at this time. We will keep your information on file for future
          opportunities that may match your profile.
        </p>
        <p>
          We appreciate the time you have invested in this application and wish you the best in your
          career journey.
        </p>
      </div>

      <p
        className="pt-4 italic text-muted-foreground"
        style={{ fontFamily: "'Inter', sans-serif", fontSize: 12 }}
      >
        Expert Intuitive Advisor Inc.
      </p>
    </div>
  );
};

export default InterviewConfirmedScreen;
