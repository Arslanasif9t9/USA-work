import { useEffect, useState, useRef } from "react";
import { SlideQuestion } from "./Slide";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Plus, X, GripVertical, Type, AlignLeft, Mail, Phone, Calendar, Clock, ToggleLeft, ListChecks, Star, Upload, Camera, CalendarClock } from "lucide-react";

import DatePicker from "./DatePicker";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";

const TYPE_DEFS: { type: string; name: string; icon: any; defaultOptions: any }[] = [
  { type: "short_text", name: "Short Text", icon: Type, defaultOptions: {} },
  { type: "long_text", name: "Long Text", icon: AlignLeft, defaultOptions: {} },
  { type: "email", name: "Email", icon: Mail, defaultOptions: {} },
  { type: "phone", name: "Phone", icon: Phone, defaultOptions: { defaultCountry: "PH" } },
  { type: "date", name: "Date", icon: Calendar, defaultOptions: {} },
  { type: "time", name: "Time", icon: Clock, defaultOptions: {} },
  { type: "file_upload", name: "File Upload", icon: Upload, defaultOptions: { accept: "*", maxSizeMB: 10, bucket: "resumes" } },
  { type: "yes_no", name: "Yes/No", icon: ToggleLeft, defaultOptions: {} },
  { type: "multiple_choice", name: "Multiple Choice", icon: ListChecks, defaultOptions: { choices: ["Option 1", "Option 2", "Option 3"], multiple: false, allowOther: false } },
  { type: "rating", name: "Rating", icon: Star, defaultOptions: { scale: 5, style: "stars", leftLabel: "", rightLabel: "" } },
  { type: "selfie", name: "Selfie", icon: Camera, defaultOptions: {} },
  { type: "schedule_call", name: "Schedule a Call", icon: CalendarClock, defaultOptions: {} },
];

const LETTERS = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";

type Props = {
  question: SlideQuestion | null;
  formId?: string;
  onUpdate: (patch: Partial<SlideQuestion>) => void;
};

const Section = ({ title, children }: { title?: string; children: React.ReactNode }) => (
  <div className="space-y-3">
    {title && <h4 className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">{title}</h4>}
    {children}
  </div>
);

const ToggleRow = ({ label, checked, onChange, helper }: any) => (
  <div className="flex items-center justify-between gap-3">
    <div>
      <Label className="text-sm">{label}</Label>
      {helper && <p className="text-[11px] text-muted-foreground">{helper}</p>}
    </div>
    <Switch checked={!!checked} onCheckedChange={onChange} />
  </div>
);

const TYPE_NAMES: Record<string, string> = {
  welcome: "Welcome Screen",
  thank_you: "Thank You Screen",
  short_text: "Short Text",
  long_text: "Long Text",
  email: "Email",
  phone: "Phone",
  date: "Date",
  time: "Time",
  yes_no: "Yes/No",
  multiple_choice: "Multiple Choice",
  rating: "Rating",
  file_upload: "File Upload",
  selfie: "Selfie",
  schedule_call: "Schedule a Call",
};

const QuestionSettings = ({ question, formId, onUpdate }: Props) => {
  if (!question) {
    return (
      <div className="text-sm text-muted-foreground p-4 text-center">
        Select a question from the left to edit its settings
      </div>
    );
  }

  const q = question;
  const opts = (q.options as any) || {};
  const setOpts = (patch: any) => onUpdate({ options: { ...opts, ...patch } });
  const typeName = TYPE_NAMES[q.type] || "Question";
  const lockedType = q.type === "welcome" || q.type === "thank_you";

  const requestTypeChange = async (newType: string) => {
    if (newType === q.type) return;
    const def = TYPE_DEFS.find((d) => d.type === newType);
    const newOptions = def ? def.defaultOptions : {};
    await onUpdate({ type: newType, options: newOptions } as any);
    toast.success(`Question type changed to ${def?.name || newType}`);
  };

  return (
    <div className="w-full">
      <h3 className="text-sm font-semibold mb-4">{typeName} Settings</h3>
      <div className="space-y-6">
        {!lockedType && (
          <Section title="Question Type">
            <Select value={q.type} onValueChange={requestTypeChange}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                {TYPE_DEFS.map((d) => {
                  const Icon = d.icon;
                  return (
                    <SelectItem key={d.type} value={d.type}>
                      <span className="flex items-center gap-2">
                        <Icon className="h-4 w-4 text-muted-foreground" />
                        {d.name}
                      </span>
                    </SelectItem>
                  );
                })}
              </SelectContent>
            </Select>
          </Section>
        )}
        {q.type === "schedule_call" ? (
          <Section title="General">
            <div>
              <Label className="text-xs">Question label</Label>
              <Textarea rows={1} className="resize-none overflow-hidden [field-sizing:content]" value={q.label} onChange={(e) => onUpdate({ label: e.target.value })} />
            </div>
            <div>
              <Label className="text-xs">Description</Label>
              <Textarea
                rows={1}
                className="resize-none overflow-hidden [field-sizing:content]"
                value={q.description || ""}
                onChange={(e) => onUpdate({ description: e.target.value || null })}
              />
            </div>
            <p className="text-xs text-muted-foreground">
              Candidates pick a 30-minute interview slot from the next 3 working days (Manila time).
              This question is always required and only one Schedule a Call question is allowed per form.
            </p>
          </Section>
        ) : (
          <SettingsBody q={q} opts={opts} onUpdate={onUpdate} setOpts={setOpts} />
        )}

      </div>

    </div>
  );
};

const SettingsBody = ({ q, opts, onUpdate, setOpts }: any) => {
  // Common label/desc/placeholder editor (synced with center)
  const labelInput = (
    <div>
      <Label className="text-xs">Question label</Label>
      <Textarea
        rows={1}
        className="resize-none overflow-hidden [field-sizing:content]"
        value={q.label}
        onChange={(e) => onUpdate({ label: e.target.value })}
      />
    </div>
  );
  const descInput = (
    <div>
      <Label className="text-xs">Description</Label>
      <Textarea
        rows={1}
        className="resize-none overflow-hidden [field-sizing:content]"
        value={q.description || ""}
        onChange={(e) => onUpdate({ description: e.target.value || null })}
      />
    </div>
  );
  const placeholderInput = (
    <div>
      <Label className="text-xs">Placeholder</Label>
      <Input
        value={q.placeholder || ""}
        onChange={(e) => onUpdate({ placeholder: e.target.value || null })}
      />
    </div>
  );
  const requiredToggle = (
    <ToggleRow
      label="Required"
      checked={q.required}
      onChange={(c: boolean) => onUpdate({ required: c })}
    />
  );

  // Welcome
  if (q.type === "welcome") {
    return (
      <Section>
        <div>
          <Label className="text-xs">Title</Label>
          <Input value={q.label} onChange={(e) => onUpdate({ label: e.target.value })} />
        </div>
        {descInput}
        <div>
          <Label className="text-xs">Button text</Label>
          <Input
            value={opts.buttonText || "Start"}
            onChange={(e) => setOpts({ buttonText: e.target.value })}
          />
        </div>
      </Section>
    );
  }

  // Thank you
  if (q.type === "thank_you") {
    return (
      <Section>
        <div>
          <Label className="text-xs">Title</Label>
          <Input value={q.label} onChange={(e) => onUpdate({ label: e.target.value })} />
        </div>
        {descInput}
        <ToggleRow
          label='Show "Submit another response" button'
          checked={!!opts.showAnotherButton}
          onChange={(c: boolean) => setOpts({ showAnotherButton: c })}
        />
      </Section>
    );
  }

  const generalContent = (
    <Section title="General">
      {labelInput}
      {descInput}
    </Section>
  );

  switch (q.type) {
    case "short_text":
    case "long_text":
      return (
        <>
          {generalContent}
          <Section title="Behavior">
            {requiredToggle}
            {placeholderInput}
            <div>
              <Label className="text-xs">Max length (optional)</Label>
              <Input
                type="number"
                value={opts.maxLength || ""}
                onChange={(e) => setOpts({ maxLength: e.target.value ? parseInt(e.target.value, 10) : undefined })}
              />
            </div>
          </Section>
        </>
      );

    case "email":
      return (
        <>
          {generalContent}
          <Section title="Behavior">
            {requiredToggle}
            {placeholderInput}
          </Section>
        </>
      );

    case "phone":
      return (
        <>
          {generalContent}
          <Section title="Behavior">
            {requiredToggle}
            <div>
              <Label className="text-xs">Default country</Label>
              <Select value={opts.defaultCountry || "PH"} onValueChange={(v) => setOpts({ defaultCountry: v })}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  {["PH", "US", "CA", "GB", "AU", "DE", "FR", "ES", "IT", "NL", "BR", "MX", "IN", "JP", "CN"].map((c) => (
                    <SelectItem key={c} value={c}>{c}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </Section>
        </>
      );

    case "time":
      return (
        <>
          {generalContent}
          <Section title="Behavior">{requiredToggle}</Section>
        </>
      );

    case "date":
      return (
        <>
          {generalContent}
          <Section title="Behavior">
            {requiredToggle}
            <div>
              <Label className="text-xs">Date format</Label>
              <Select value={opts.format || "MMM D, YYYY"} onValueChange={(v) => setOpts({ format: v })}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="MMM D, YYYY">MMM D, YYYY</SelectItem>
                  <SelectItem value="DD/MM/YYYY">DD/MM/YYYY</SelectItem>
                  <SelectItem value="MM/DD/YYYY">MM/DD/YYYY</SelectItem>
                  <SelectItem value="YYYY-MM-DD">YYYY-MM-DD</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label className="text-xs">Min date</Label>
              <DatePicker variant="input" value={opts.minDate || null} onChange={(v) => setOpts({ minDate: v || undefined })} placeholder="No minimum" />
            </div>
            <div>
              <Label className="text-xs">Max date</Label>
              <DatePicker variant="input" value={opts.maxDate || null} onChange={(v) => setOpts({ maxDate: v || undefined })} placeholder="No maximum" />
            </div>
          </Section>
        </>
      );

    case "yes_no":
      return (
        <>
          {generalContent}
          <Section title="Behavior">{requiredToggle}</Section>
        </>
      );

    case "multiple_choice":
      return (
        <>
          {generalContent}
          <Section title="Behavior">
            {requiredToggle}
            <ToggleRow
              label="Allow multiple selection"
              checked={!!opts.multiple}
              onChange={(c: boolean) => setOpts({ multiple: c })}
            />
            <ToggleRow
              label='Add an "Other" option'
              checked={!!opts.allowOther}
              onChange={(c: boolean) => setOpts({ allowOther: c })}
            />
          </Section>
          <ChoicesEditor
            choices={Array.isArray(opts.choices) && opts.choices.length ? opts.choices : ["Option 1", "Option 2"]}
            onChange={(choices) => setOpts({ choices })}
          />
        </>
      );

    case "rating":
      return (
        <>
          {generalContent}
          <Section title="Behavior">
            {requiredToggle}
            <div>
              <Label className="text-xs">Scale</Label>
              <Select value={String(opts.scale || 5)} onValueChange={(v) => setOpts({ scale: parseInt(v, 10) })}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="3">1 to 3</SelectItem>
                  <SelectItem value="5">1 to 5</SelectItem>
                  <SelectItem value="7">1 to 7</SelectItem>
                  <SelectItem value="10">1 to 10</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label className="text-xs">Style</Label>
              <Select value={opts.style || "stars"} onValueChange={(v) => setOpts({ style: v })}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="stars">Stars</SelectItem>
                  <SelectItem value="numbers">Numbers</SelectItem>
                  <SelectItem value="hearts">Hearts</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label className="text-xs">Left label</Label>
              <Input value={opts.leftLabel || ""} onChange={(e) => setOpts({ leftLabel: e.target.value })} />
            </div>
            <div>
              <Label className="text-xs">Right label</Label>
              <Input value={opts.rightLabel || ""} onChange={(e) => setOpts({ rightLabel: e.target.value })} />
            </div>
          </Section>
        </>
      );

    case "file_upload":
      return (
        <>
          {generalContent}
          <Section title="Behavior">
            {requiredToggle}
            <div>
              <Label className="text-xs">Accepted file types</Label>
              <Select value={opts.accept || "*"} onValueChange={(v) => setOpts({ accept: v })}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="*">Any file</SelectItem>
                  <SelectItem value="image/*">Images only</SelectItem>
                  <SelectItem value="application/pdf">PDFs only</SelectItem>
                  <SelectItem value=".pdf,.doc,.docx">Documents (PDF, DOC, DOCX)</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label className="text-xs">Max file size (MB)</Label>
              <Input
                type="number"
                value={opts.maxSizeMB || 10}
                onChange={(e) => setOpts({ maxSizeMB: parseInt(e.target.value, 10) || 10 })}
              />
            </div>
            <div>
              <Label className="text-xs">Storage bucket</Label>
              <Select value={opts.bucket || "resumes"} onValueChange={(v) => setOpts({ bucket: v })}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="resumes">resumes</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </Section>
        </>
      );

    case "selfie":
      return (
        <>
          {generalContent}
          <Section title="Behavior">{requiredToggle}</Section>
        </>
      );

    default:
      return (
        <>
          {generalContent}
          <Section title="Behavior">{requiredToggle}</Section>
        </>
      );
  }
};

const ChoicesEditor = ({ choices, onChange }: { choices: string[]; onChange: (c: string[]) => void }) => {
  const [local, setLocal] = useState<string[]>(choices);
  const refs = useRef<(HTMLInputElement | null)[]>([]);

  useEffect(() => { setLocal(choices); }, [choices.join("|")]);

  const commit = (next: string[]) => {
    setLocal(next);
    onChange(next);
  };

  const update = (i: number, v: string) => {
    const next = [...local];
    next[i] = v;
    setLocal(next);
  };

  const blur = () => onChange(local);

  const addAt = (i: number) => {
    const next = [...local];
    next.splice(i + 1, 0, `Option ${next.length + 1}`);
    commit(next);
    setTimeout(() => refs.current[i + 1]?.focus(), 0);
  };

  const removeAt = (i: number) => {
    if (local.length <= 2) return;
    const next = local.filter((_, idx) => idx !== i);
    commit(next);
  };

  return (
    <Section title="Choices">
      <div className="space-y-2">
        {local.map((c, i) => (
          <div key={i} className="flex items-center gap-2">
            <GripVertical className="h-4 w-4 text-muted-foreground/50" />
            <span className="text-xs font-semibold w-5 text-muted-foreground">{LETTERS[i]}</span>
            <Input
              ref={(el) => (refs.current[i] = el)}
              value={c}
              onChange={(e) => update(i, e.target.value)}
              onBlur={blur}
              onKeyDown={(e) => {
                if (e.key === "Enter") {
                  e.preventDefault();
                  // commit local changes first
                  onChange(local);
                  addAt(i);
                } else if (e.key === "Backspace" && c === "" && local.length > 2) {
                  e.preventDefault();
                  removeAt(i);
                }
              }}
            />
            <button
              type="button"
              onClick={() => removeAt(i)}
              disabled={local.length <= 2}
              className="p-1 text-muted-foreground hover:text-destructive disabled:opacity-30"
              aria-label="Delete choice"
            >
              <X className="h-3 w-3" />
            </button>
          </div>
        ))}
      </div>
      <Button variant="ghost" size="sm" onClick={() => addAt(local.length - 1)} className="mt-2">
        <Plus className="h-3 w-3 mr-1" /> Add choice
      </Button>
    </Section>
  );
};

export default QuestionSettings;
