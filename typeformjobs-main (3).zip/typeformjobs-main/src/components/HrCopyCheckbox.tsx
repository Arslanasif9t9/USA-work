import { useEffect, useState } from "react";
import { Checkbox } from "@/components/ui/checkbox";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useHrCopyEmail } from "@/hooks/useHrCopyEmail";
import { Pencil, X } from "lucide-react";

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

export type HrCopyState = {
  /** Whether HR ticked the "send a copy to internal backup inbox" checkbox. Default false. */
  requested: boolean;
  /**
   * Optional one-off override email. Empty/null means "use the live backup
   * setting at completion time". When set, this overrides the live setting
   * for this single record only.
   */
  override: string | null;
};

type Props = {
  value: HrCopyState;
  onChange: (next: HrCopyState) => void;
  disabled?: boolean;
  /** Customize label suffix (e.g. for interview surfaces). */
  label?: string;
  /** Tighter compact rendering for in-table use */
  compact?: boolean;
  idPrefix?: string;
};

/**
 * Universal additive opt-in checkbox for "send a copy to internal backup inbox".
 * - Default UNCHECKED.
 * - Shows the current backup email dynamically (read live from app_settings).
 * - Allows inline one-off override of the destination email.
 * - Never modifies anything itself; the parent persists `value` to the relevant
 *   record at send time, and the completion-time handler reads it back.
 */
export function HrCopyCheckbox({ value, onChange, disabled, label, compact, idPrefix = "hr-copy" }: Props) {
  const { email: liveEmail } = useHrCopyEmail();
  const [editing, setEditing] = useState(false);
  const [draft, setDraft] = useState(value.override ?? "");

  useEffect(() => { setDraft(value.override ?? ""); }, [value.override]);

  const id = `${idPrefix}-toggle`;
  const dest = (value.override && EMAIL_RE.test(value.override)) ? value.override : liveEmail;
  const overrideValid = !draft.trim() || EMAIL_RE.test(draft.trim());

  return (
    <div
      className={`rounded-md border bg-muted/30 ${compact ? "p-2.5" : "p-3"} space-y-2`}
      style={{ borderColor: "#e1e4ec" }}
    >
      <label htmlFor={id} className="flex items-start gap-2 cursor-pointer">
        <Checkbox
          id={id}
          checked={value.requested}
          onCheckedChange={(v) => onChange({ ...value, requested: !!v })}
          disabled={disabled}
          className="mt-0.5"
        />
        <div className="flex-1 min-w-0">
          <div className={`${compact ? "text-xs" : "text-sm"} font-medium text-foreground leading-snug`}>
            {label || "Send a copy to internal backup inbox"}
          </div>
          <div className={`${compact ? "text-[11px]" : "text-xs"} text-muted-foreground mt-0.5 break-all`}>
            Destination: <span className="font-mono">{dest}</span>
            {!editing && (
              <button
                type="button"
                onClick={(e) => { e.preventDefault(); setEditing(true); }}
                className="ml-1.5 inline-flex items-center gap-0.5 text-[11px] underline hover:no-underline"
                disabled={disabled}
              >
                <Pencil className="h-3 w-3" /> edit for this send
              </button>
            )}
          </div>
          <div className="text-[11px] text-muted-foreground/80 mt-0.5">
            Only fires when the recipient fully completes the action.
          </div>
        </div>
      </label>

      {editing && (
        <div className="flex items-center gap-2 pl-6">
          <Input
            type="email"
            value={draft}
            onChange={(e) => setDraft(e.target.value)}
            placeholder="leave blank to use the live setting"
            className="h-8 text-xs"
            disabled={disabled}
            autoFocus
          />
          <button
            type="button"
            className="text-[11px] text-primary underline hover:no-underline"
            disabled={disabled || !overrideValid}
            onClick={(e) => {
              e.preventDefault();
              const trimmed = draft.trim();
              onChange({ ...value, override: trimmed && EMAIL_RE.test(trimmed) ? trimmed : null });
              setEditing(false);
            }}
          >
            Save
          </button>
          <button
            type="button"
            className="text-[11px] text-muted-foreground inline-flex items-center"
            onClick={(e) => { e.preventDefault(); setDraft(value.override ?? ""); setEditing(false); }}
          >
            <X className="h-3 w-3" />
          </button>
        </div>
      )}
    </div>
  );
}

export const defaultHrCopyState: HrCopyState = { requested: false, override: null };
