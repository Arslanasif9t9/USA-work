import { useState } from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { toast } from "sonner";
import {
  Type,
  AlignLeft,
  Mail,
  Phone,
  Calendar,
  Clock,
  ToggleLeft,
  ListChecks,
  Star,
  Upload,
  Camera,
} from "lucide-react";


export type QuestionTypeDef = {
  type: string;
  name: string;
  description: string;
  icon: any;
  defaults: {
    label: string;
    placeholder: string | null;
    required: boolean;
    options: any;
  };
};

export const QUESTION_TYPES: QuestionTypeDef[] = [
  { type: "short_text", name: "Short Text", description: "Single-line text answer", icon: Type,
    defaults: { label: "Short answer question", placeholder: "Type your answer here...", required: false, options: {} } },
  { type: "long_text", name: "Long Text", description: "Multi-line text answer", icon: AlignLeft,
    defaults: { label: "Long answer question", placeholder: "Type your answer here...", required: false, options: {} } },
  { type: "email", name: "Email", description: "Validated email address", icon: Mail,
    defaults: { label: "What is your email address?", placeholder: "name@example.com", required: true, options: {} } },
  { type: "phone", name: "Phone", description: "Phone number with formatting", icon: Phone,
    defaults: { label: "What is your phone number?", placeholder: "Enter phone number", required: true, options: { defaultCountry: "PH" } } },
  { type: "date", name: "Date", description: "Date picker", icon: Calendar,
    defaults: { label: "Pick a date", placeholder: "", required: false, options: {} } },
  { type: "time", name: "Time", description: "Hour / minute / AM·PM (e.g. time of birth)", icon: Clock,
    defaults: { label: "Time of birth", placeholder: "", required: false, options: {} } },
  { type: "yes_no", name: "Yes/No", description: "Single yes or no answer", icon: ToggleLeft,
    defaults: { label: "Yes or no?", placeholder: "", required: false, options: {} } },
  { type: "multiple_choice", name: "Multiple Choice", description: "Pick one or more from a list", icon: ListChecks,
    defaults: { label: "Choose one or more", placeholder: "", required: false, options: { choices: ["Option 1", "Option 2", "Option 3"], multiple: false, allowOther: false } } },
  { type: "rating", name: "Rating", description: "1 to 5 star rating", icon: Star,
    defaults: { label: "How would you rate this?", placeholder: "", required: false, options: { scale: 5, style: "stars", leftLabel: "Worst", rightLabel: "Best" } } },
  { type: "file_upload", name: "File Upload", description: "Upload a file (resume, photo, etc.)", icon: Upload,
    defaults: { label: "Upload a file", placeholder: "", required: false, options: { accept: "*", maxSizeMB: 10, bucket: "resumes" } } },
  { type: "selfie", name: "Selfie", description: "Capture a photo with the camera", icon: Camera,
    defaults: { label: "Please take a selfie", placeholder: "", required: true, options: {} } },
];

type Props = {
  open: boolean;
  onOpenChange: (o: boolean) => void;
  onPick: (def: QuestionTypeDef) => void;
};

const QuestionPicker = ({ open, onOpenChange, onPick }: Props) => {
  const [search, setSearch] = useState("");
  const filtered = QUESTION_TYPES.filter(
    (t) =>
      t.name.toLowerCase().includes(search.toLowerCase()) ||
      t.description.toLowerCase().includes(search.toLowerCase()),
  );
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle>Add a question</DialogTitle>
        </DialogHeader>
        <Input
          autoFocus
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder="Search question types..."
        />
        <div className="max-h-[400px] overflow-y-auto -mx-2">
          {filtered.length === 0 ? (
            <p className="text-sm text-muted-foreground text-center py-6">No matches</p>
          ) : (
            filtered.map((t) => {
              const Icon = t.icon;
              return (
                <button
                  key={t.type}
                  onClick={() => {
                    onPick(t);
                    setSearch("");
                  }}
                  className="w-full flex items-start gap-3 px-3 py-2.5 rounded-md hover:bg-secondary text-left transition-colors"
                >
                  <Icon className="h-5 w-5 mt-0.5 text-muted-foreground shrink-0" />
                  <div className="min-w-0">
                    <div className="text-sm font-medium">{t.name}</div>
                    <div className="text-xs text-muted-foreground">{t.description}</div>
                  </div>
                </button>
              );
            })
          )}
        </div>
        <div className="border-t pt-2 -mx-6 px-6 flex justify-end">
          <button
            type="button"
            onClick={() => {
              try {
                Object.keys(localStorage)
                  .filter((k) => k.startsWith("typehire-last-used-"))
                  .forEach((k) => localStorage.removeItem(k));
                toast.success("Question defaults reset");
              } catch {
                toast.error("Couldn't reset defaults");
              }
            }}
            className="text-xs text-muted-foreground hover:text-foreground"
          >
            Reset defaults
          </button>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default QuestionPicker;
