import { useEffect, useMemo, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from "@/components/ui/table";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import { Check, X, ExternalLink, Loader2, RefreshCw, Trash2 } from "lucide-react";
import { toast } from "sonner";
import { SignedThumb } from "@/components/onboarding/SignedFile";
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
} from "@/components/ui/alert-dialog";

type Submission = {
  id: string;
  response_id: string;
  full_name: string | null;
  email: string | null;
  position_title: string | null;
  phone: string | null;
  onlinejobs_profile_url: string | null;
  digital_pay_gcash: string | null;
  profile_photo_url: string | null;
  speedtest_screenshot_url: string | null;
  typing_screenshot_url: string | null;
  onboarding_status: string;
  submitted_at: string | null;
};

const SELECT =
  "id, response_id, full_name, email, position_title, phone, onlinejobs_profile_url, digital_pay_gcash, profile_photo_url, speedtest_screenshot_url, typing_screenshot_url, onboarding_status, submitted_at";

const fmtDateTime = (d: string | null) =>
  d ? new Date(d).toLocaleString("en-US", { dateStyle: "medium", timeStyle: "short" }) : "—";

const statusPill = (status: string) => {
  const map: Record<string, { bg: string; color: string; label: string }> = {
    pending: { bg: "#fef3c7", color: "#92400e", label: "Pending" },
    approved: { bg: "#dcfce7", color: "#166534", label: "Approved" },
    rejected: { bg: "#fee2e2", color: "#991b1b", label: "Rejected" },
  };
  const m = map[status] || { bg: "#e5e7eb", color: "#374151", label: status };
  return (
    <span style={{ background: m.bg, color: m.color }} className="inline-flex px-2 py-0.5 rounded text-xs font-medium">
      {m.label}
    </span>
  );
};

export default function OnboardingSubmissionsSection() {
  const [rows, setRows] = useState<Submission[]>([]);
  const [loading, setLoading] = useState(true);
  const [busyId, setBusyId] = useState<string | null>(null);
  const [statusFilter, setStatusFilter] = useState<"pending" | "approved" | "rejected" | "all">("all");
  const [pendingDelete, setPendingDelete] = useState<Submission | null>(null);
  const [deleting, setDeleting] = useState(false);

  const handleDelete = async () => {
    if (!pendingDelete) return;
    setDeleting(true);
    try {
      const { error } = await (supabase.from("onboarding_submissions") as any)
        .delete()
        .eq("id", pendingDelete.id);
      if (error) throw error;
      setRows((prev) => prev.filter((r) => r.id !== pendingDelete.id));
      toast.success("Record deleted.");
      setPendingDelete(null);
    } catch (e: any) {
      toast.error(e?.message || "Could not delete record");
    } finally {
      setDeleting(false);
    }
  };

  const load = async () => {
    setLoading(true);
    const { data, error } = await (supabase.from("onboarding_submissions") as any)
      .select(SELECT)
      .not("submitted_at", "is", null)
      .order("submitted_at", { ascending: false })
      .limit(1000);
    if (error) {
      toast.error(error.message);
      setRows([]);
    } else {
      setRows((data as Submission[]) || []);
    }
    setLoading(false);
  };

  useEffect(() => { load(); }, []);

  const decide = async (row: Submission, decision: "approved" | "rejected") => {
    setBusyId(row.id);
    try {
      const { error } = await (supabase.from("onboarding_submissions") as any)
        .update({ onboarding_status: decision })
        .eq("id", row.id);
      if (error) throw error;
      setRows((prev) => prev.map((r) => (r.id === row.id ? { ...r, onboarding_status: decision } : r)));
      toast.success(`Onboarding ${decision}.`);
      // Fire-and-forget approval email — only on approve. Failure never undoes the approval.
      if (decision === "approved") {
        supabase.functions
          .invoke("send-onboarding-approval", { body: { submission_id: row.id } })
          .then(({ data, error: fnErr }) => {
            if (fnErr || (data && (data as any).ok === false)) {
              toast.error("Approved, but the email failed to send");
            }
          })
          .catch(() => {
            toast.error("Approved, but the email failed to send");
          });
      }
    } catch (e: any) {
      toast.error(e?.message || "Could not update status");
    } finally {
      setBusyId(null);
    }
  };

  const filtered = useMemo(() => {
    const list = statusFilter === "all" ? rows : rows.filter((r) => r.onboarding_status === statusFilter);
    // pending first, then by submitted_at desc
    return [...list].sort((a, b) => {
      const ap = a.onboarding_status === "pending" ? 0 : 1;
      const bp = b.onboarding_status === "pending" ? 0 : 1;
      if (ap !== bp) return ap - bp;
      return (b.submitted_at || "").localeCompare(a.submitted_at || "");
    });
  }, [rows, statusFilter]);

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <CardTitle className="text-base">Onboarding Submissions</CardTitle>
        <div className="flex items-center gap-2">
          <Select value={statusFilter} onValueChange={(v) => setStatusFilter(v as any)}>
            <SelectTrigger className="h-8 w-[140px]">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="pending">Pending</SelectItem>
              <SelectItem value="approved">Approved</SelectItem>
              <SelectItem value="rejected">Rejected</SelectItem>
              <SelectItem value="all">All</SelectItem>
            </SelectContent>
          </Select>
          <Button variant="outline" size="sm" onClick={load} disabled={loading}>
            <RefreshCw className={`h-4 w-4 mr-1.5 ${loading ? "animate-spin" : ""}`} /> Refresh
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        {loading ? (
          <div className="flex items-center justify-center py-10">
            <Loader2 className="h-5 w-5 animate-spin text-muted-foreground" />
          </div>
        ) : filtered.length === 0 ? (
          <div className="text-sm text-muted-foreground py-8 text-center">
            No {statusFilter === "all" ? "" : statusFilter} onboarding submissions.
          </div>
        ) : (
          <div className="w-full">
            <Table className="table-fixed w-full">
              <TableHeader>
                <TableRow>
                  <TableHead className="w-9 px-1" />
                  <TableHead className="w-[7%] px-2">Photo</TableHead>
                  <TableHead className="w-[15%] px-2">Name / Email</TableHead>
                  <TableHead className="w-[11%] px-2">Position</TableHead>
                  <TableHead className="w-[9%] px-2">Phone</TableHead>
                  <TableHead className="w-[8%] px-2">OnlineJobs.ph</TableHead>
                  <TableHead className="w-[10%] px-2">GCash</TableHead>
                  <TableHead className="w-[11%] px-2">Screenshots</TableHead>
                  <TableHead className="w-[10%] px-2">Submitted</TableHead>
                  <TableHead className="w-[7%] px-2">Status</TableHead>
                  <TableHead className="w-[12%] px-2 text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filtered.map((r) => (
                  <TableRow key={r.id}>
                    <TableCell className="px-1 align-top">
                      <Button
                        size="icon"
                        variant="ghost"
                        className="h-7 w-7 text-red-600 hover:text-red-700 hover:bg-red-50"
                        onClick={() => setPendingDelete(r)}
                        aria-label="Delete record"
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </TableCell>
                    <TableCell className="px-2 align-top">
                      <SignedThumb filePath={r.profile_photo_url} label="profile photo" size={40} />
                    </TableCell>
                    <TableCell className="px-2 align-top">
                      <div className="font-medium whitespace-normal break-words">{r.full_name || "—"}</div>
                      <div className="text-xs text-muted-foreground whitespace-normal break-words">{r.email || "—"}</div>
                    </TableCell>
                    <TableCell className="px-2 align-top whitespace-normal break-words">{r.position_title || "—"}</TableCell>
                    <TableCell className="px-2 align-top whitespace-normal break-words text-xs">{r.phone || "—"}</TableCell>
                    <TableCell className="px-2 align-top">
                      {r.onlinejobs_profile_url ? (
                        <a
                          href={r.onlinejobs_profile_url}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="inline-flex items-center gap-1 text-primary underline underline-offset-2 hover:opacity-80 text-xs"
                        >
                          Profile <ExternalLink className="h-3 w-3" />
                        </a>
                      ) : (
                        "—"
                      )}
                    </TableCell>
                    <TableCell className="px-2 align-top whitespace-normal break-words text-xs">{r.digital_pay_gcash || "—"}</TableCell>
                    <TableCell className="px-2 align-top">
                      <div className="flex items-center gap-1.5">
                        <SignedThumb filePath={r.speedtest_screenshot_url} label="speed-test screenshot" size={38} />
                        <SignedThumb filePath={r.typing_screenshot_url} label="typing-test screenshot" size={38} />
                      </div>
                    </TableCell>
                    <TableCell className="px-2 align-top whitespace-normal break-words text-xs">{fmtDateTime(r.submitted_at)}</TableCell>
                    <TableCell className="px-2 align-top">{statusPill(r.onboarding_status)}</TableCell>
                    <TableCell className="px-2 align-top text-right">
                      <div className="flex flex-col items-end gap-1.5">
                        <Button
                          size="sm"
                          variant="outline"
                          className="h-7 px-2 text-green-700 border-green-300 hover:bg-green-50"
                          disabled={busyId === r.id || r.onboarding_status === "approved"}
                          onClick={() => decide(r, "approved")}
                        >
                          <Check className="h-3.5 w-3.5 mr-1" /> Approve
                        </Button>
                        <Button
                          size="sm"
                          variant="outline"
                          className="h-7 px-2 text-red-700 border-red-300 hover:bg-red-50"
                          disabled={busyId === r.id || r.onboarding_status === "rejected"}
                          onClick={() => decide(r, "rejected")}
                        >
                          <X className="h-3.5 w-3.5 mr-1" /> Reject
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        )}
      </CardContent>

      <AlertDialog open={!!pendingDelete} onOpenChange={(o) => !o && setPendingDelete(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete this record permanently? This cannot be undone.</AlertDialogTitle>
            <AlertDialogDescription>
              {pendingDelete?.full_name || pendingDelete?.email || "This onboarding submission"} will be removed.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={deleting}>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={(e) => { e.preventDefault(); handleDelete(); }}
              disabled={deleting}
              className="bg-red-600 hover:bg-red-700"
            >
              {deleting ? "Deleting…" : "Delete"}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </Card>
  );
}
