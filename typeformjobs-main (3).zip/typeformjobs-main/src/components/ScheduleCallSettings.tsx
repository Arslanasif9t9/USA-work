import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Badge } from "@/components/ui/badge";
import { Loader2, CalendarRange } from "lucide-react";
import { toast } from "sonner";
import {
  SchedulingConfig, DAY_KEYS, DAY_LABELS, defaultWorkingHours, detectBrowserTimezone,
  DEFAULT_DISCLAIMER, COMMON_TIMEZONES, WorkingHours,
} from "@/lib/scheduling";
import SchedulingCalendarEditor from "./SchedulingCalendarEditor";
import type { SlideQuestion } from "./Slide";

type Props = {
  question: SlideQuestion;
  formId: string;
  onUpdate: (patch: Partial<SlideQuestion>) => void;
};

const Section = ({ title, children }: { title?: string; children: React.ReactNode }) => (
  <div className="space-y-3">
    {title && <h4 className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">{title}</h4>}
    {children}
  </div>
);

const Chips = ({ values, value, onChange, suffix }: { values: number[]; value: number; onChange: (v: number) => void; suffix?: string }) => (
  <div className="flex flex-wrap gap-2">
    {values.map((v) => (
      <button
        key={v}
        type="button"
        onClick={() => onChange(v)}
        className={`px-3 h-8 rounded-md border text-sm transition-colors ${
          value === v ? "border-primary bg-primary/10 text-primary" : "border-border hover:bg-secondary"
        }`}
      >
        {v}{suffix ? ` ${suffix}` : ""}
      </button>
    ))}
  </div>
);

const ScheduleCallSettings = ({ question, formId, onUpdate }: Props) => {
  const [config, setConfig] = useState<SchedulingConfig | null>(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [editorOpen, setEditorOpen] = useState(false);
  const [disclaimerLocal, setDisclaimerLocal] = useState("");

  // Load or create config row
  useEffect(() => {
    let cancelled = false;
    (async () => {
      setLoading(true);
      const { data, error } = await supabase
        .from("scheduling_configs")
        .select("*")
        .eq("question_id", question.id)
        .maybeSingle();
      if (cancelled) return;
      if (error) {
        toast.error("Couldn't load scheduling settings");
        setLoading(false);
        return;
      }
      if (data) {
        setConfig(data as any);
        setDisclaimerLocal((data as any).disclaimer_text);
      } else {
        const tz = detectBrowserTimezone();
        const ins = {
          question_id: question.id,
          form_id: formId,
          calendar_source: "internal",
          timezone: tz,
          slot_duration_minutes: 30,
          buffer_minutes: 0,
          working_hours: defaultWorkingHours(),
          advance_notice_hours: 24,
          booking_window_days: 30,
          disclaimer_text: DEFAULT_DISCLAIMER,
        };
        const { data: created, error: ce } = await supabase
          .from("scheduling_configs").insert(ins).select().single();
        if (ce) toast.error(ce.message);
        else {
          setConfig(created as any);
          setDisclaimerLocal((created as any).disclaimer_text);
        }
      }
      setLoading(false);
    })();
    return () => { cancelled = true; };
  }, [question.id, formId]);

  const saveConfig = async (patch: Partial<SchedulingConfig>) => {
    if (!config) return;
    setSaving(true);
    const next = { ...config, ...patch } as SchedulingConfig;
    setConfig(next);
    const { error } = await supabase
      .from("scheduling_configs").update(patch as any).eq("id", config.id);
    setSaving(false);
    if (error) toast.error(error.message);
  };

  const setHours = (day: keyof WorkingHours, value: [string, string] | null) => {
    if (!config) return;
    const next: WorkingHours = { ...config.working_hours, [day]: value };
    saveConfig({ working_hours: next });
  };

  if (loading || !config) {
    return (
      <div className="flex items-center gap-2 text-sm text-muted-foreground py-4">
        <Loader2 className="h-4 w-4 animate-spin" /> Loading scheduling settings…
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <Section title="General">
        <div>
          <Label className="text-xs">Question label</Label>
          <Input value={question.label} onChange={(e) => onUpdate({ label: e.target.value })} />
        </div>
        <div>
          <Label className="text-xs">Description</Label>
          <Textarea
            rows={1}
            className="resize-none overflow-hidden [field-sizing:content]"
            value={question.description || ""}
            onChange={(e) => onUpdate({ description: e.target.value || null })}
          />
        </div>
      </Section>

      <Section title="Calendar Source">
        <RadioGroup
          value={config.calendar_source}
          onValueChange={(v) => saveConfig({ calendar_source: v as any })}
          className="space-y-2"
        >
          <label className="flex items-center gap-2 cursor-pointer">
            <RadioGroupItem value="internal" />
            <span className="text-sm">Internal Calendar</span>
            <Badge variant="secondary" className="ml-auto text-[10px]">Active</Badge>
          </label>
          <label className="flex items-center gap-2 opacity-60 cursor-not-allowed">
            <RadioGroupItem value="google_calendar" disabled />
            <span className="text-sm">Google Calendar</span>
            <Badge variant="outline" className="ml-auto text-[10px]">Coming soon</Badge>
          </label>
          <label className="flex items-center gap-2 opacity-60 cursor-not-allowed">
            <RadioGroupItem value="calendly" disabled />
            <span className="text-sm">Calendly</span>
            <Badge variant="outline" className="ml-auto text-[10px]">Coming soon</Badge>
          </label>
        </RadioGroup>
      </Section>

      <Section title="Availability">
        <div>
          <Label className="text-xs">Timezone</Label>
          <Select value={config.timezone} onValueChange={(v) => saveConfig({ timezone: v })}>
            <SelectTrigger><SelectValue /></SelectTrigger>
            <SelectContent>
              {COMMON_TIMEZONES.includes(config.timezone) ? null : (
                <SelectItem value={config.timezone}>{config.timezone}</SelectItem>
              )}
              {COMMON_TIMEZONES.map((tz) => (
                <SelectItem key={tz} value={tz}>{tz}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <div>
          <Label className="text-xs">Slot duration</Label>
          <Chips values={[15, 30, 45, 60]} value={config.slot_duration_minutes}
            onChange={(v) => saveConfig({ slot_duration_minutes: v })} suffix="min" />
        </div>

        <div>
          <Label className="text-xs">Buffer between calls</Label>
          <Chips values={[0, 5, 10, 15]} value={config.buffer_minutes}
            onChange={(v) => saveConfig({ buffer_minutes: v })} suffix="min" />
        </div>

        <div className="space-y-2">
          <Label className="text-xs">Working hours</Label>
          <div className="space-y-1.5">
            {DAY_KEYS.map((dk) => {
              const hours = config.working_hours?.[dk] || null;
              const enabled = !!hours;
              return (
                <div key={dk} className="flex items-center gap-2">
                  <Switch
                    checked={enabled}
                    onCheckedChange={(c) => setHours(dk, c ? ["09:00", "17:00"] : null)}
                  />
                  <span className="text-xs w-10">{DAY_LABELS[dk].slice(0, 3)}</span>
                  <Input
                    type="time"
                    disabled={!enabled}
                    value={hours?.[0] || "09:00"}
                    onChange={(e) => setHours(dk, [e.target.value, hours?.[1] || "17:00"])}
                    className="h-8 text-xs"
                  />
                  <span className="text-xs text-muted-foreground">to</span>
                  <Input
                    type="time"
                    disabled={!enabled}
                    value={hours?.[1] || "17:00"}
                    onChange={(e) => setHours(dk, [hours?.[0] || "09:00", e.target.value])}
                    className="h-8 text-xs"
                  />
                </div>
              );
            })}
          </div>
        </div>

        <div className="flex items-center gap-2">
          <Label className="text-xs whitespace-nowrap">Advance notice</Label>
          <Input
            type="number"
            min={0}
            value={config.advance_notice_hours}
            onChange={(e) => saveConfig({ advance_notice_hours: parseInt(e.target.value, 10) || 0 })}
            className="h-8 w-20"
          />
          <span className="text-xs text-muted-foreground">hours before slot</span>
        </div>

        <div className="flex items-center gap-2">
          <Label className="text-xs whitespace-nowrap">Booking window</Label>
          <Input
            type="number"
            min={1}
            value={config.booking_window_days}
            onChange={(e) => saveConfig({ booking_window_days: parseInt(e.target.value, 10) || 1 })}
            className="h-8 w-20"
          />
          <span className="text-xs text-muted-foreground">days from today</span>
        </div>
      </Section>

      <Section title="Manage Blocked Slots">
        <Button variant="outline" onClick={() => setEditorOpen(true)} className="w-full">
          <CalendarRange className="h-4 w-4" /> Open Calendar Editor
        </Button>
      </Section>

      <Section title="Disclaimer">
        <Textarea
          rows={5}
          value={disclaimerLocal}
          onChange={(e) => setDisclaimerLocal(e.target.value)}
          onBlur={() => {
            const v = disclaimerLocal.trim();
            if (!v) {
              toast.error("Disclaimer can't be empty");
              setDisclaimerLocal(config.disclaimer_text);
              return;
            }
            if (v !== config.disclaimer_text) saveConfig({ disclaimer_text: v });
          }}
        />
        <p className="text-[11px] text-muted-foreground">
          This message will be shown prominently to candidates above the calendar.
        </p>
      </Section>

      <Section title="Behavior">
        <div className="flex items-center justify-between">
          <Label className="text-sm">Required</Label>
          <Switch checked={!!question.required} onCheckedChange={(c) => onUpdate({ required: c })} />
        </div>
      </Section>

      {saving && (
        <p className="text-[11px] text-muted-foreground flex items-center gap-1">
          <Loader2 className="h-3 w-3 animate-spin" /> Saving…
        </p>
      )}

      {editorOpen && (
        <SchedulingCalendarEditor
          open={editorOpen}
          onOpenChange={setEditorOpen}
          config={config}
          questionLabel={question.label}
        />
      )}
    </div>
  );
};

export default ScheduleCallSettings;
