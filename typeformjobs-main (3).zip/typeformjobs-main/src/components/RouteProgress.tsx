import { useEffect, useRef } from "react";
import { useLocation } from "react-router-dom";
import NProgress from "nprogress";

const RouteProgress = () => {
  const location = useLocation();
  const first = useRef(true);

  useEffect(() => {
    if (first.current) {
      first.current = false;
      return;
    }
    NProgress.start();
    const t = setTimeout(() => NProgress.done(), 350);
    return () => clearTimeout(t);
  }, [location.pathname]);

  return null;
};

export default RouteProgress;
