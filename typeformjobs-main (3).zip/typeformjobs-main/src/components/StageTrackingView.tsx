import { useEffect, useMemo, useRef, useState } from "react";
import { useNavigate, useSearchParams } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { ArrowLeft, FileText, User as UserIcon, RotateCcw, Loader2, Eye, Trash2, Info, Video, Search, X, Check, Target, Sparkles } from "lucide-react";
import { AppointmentCountdown } from "@/components/AppointmentCountdown";
import { CancelAppointmentButton } from "@/components/CancelAppointmentButton";
import { MarkAttendanceButton } from "@/components/MarkAttendanceButton";
import { SendRound2Button } from "@/components/SendRound2Button";
import { SendOfferButton } from "@/components/SendOfferButton";
import { MatchedOutcomeButtons } from "@/components/MatchedOutcomeButtons";
import ScheduledSendChip from "@/components/ScheduledSendChip";
import { Checkbox } from "@/components/ui/checkbox";
import { Input } from "@/components/ui/input";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter,
} from "@/components/ui/dialog";
import { ViewOfferDialog } from "@/components/ViewOfferDialog";
import { ViewFullDetailsDialog } from "@/components/ViewFullDetailsDialog";
import { detectContactQuestionIds } from "@/lib/candidateActions";
import { SelfieThumb, FilePreviewDialog, parseFilePath } from "@/components/FilePreview";
import { DisqualifyButton } from "@/components/DisqualifyButton";
import { HrNicknameField } from "@/components/HrNicknameField";
import { HrBadgePill } from "@/components/HrBadge";
import { AiTierBadge } from "@/components/AiTierBadge";
import { ActionsCell } from "@/components/action-dialogs/ActionsCell";
import { InviteRoundDialog } from "@/components/action-dialogs/InviteRoundDialog";
import { SendCustomMessageDialog } from "@/components/SendCustomMessageDialog";
import { Mail, Bookmark, BookmarkX } from "lucide-react";
import type { CandidateAction } from "@/lib/candidateActions";
import { EmailInlineEditor } from "@/components/EmailInlineEditor";
import { RescheduleButton } from "@/components/RescheduleButton";
import { FollowUpOfferButton } from "@/components/FollowUpOfferButton";
import { RegenerateZoomButton } from "@/components/RegenerateZoomButton";
import { WatchInterviewVideoButton } from "@/components/WatchInterviewVideoButton";
import { InterviewVideoDialog } from "@/components/InterviewVideoDialog";

import { StopRemindersButton } from "@/components/StopRemindersButton";
import { UniversalCandidateButtons, UniversalCandidateModal } from "@/components/UniversalCandidateButtons";
import { cleanPositionTitle } from "@/lib/positionTitle";
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { toast } from "sonner";

type HrUser = { id: string; display_name: string; nickname: string | null };

// Display-only rename: the DB nickname stays "Cherry" (Zoom routing relies on it),
// but the on-screen label shows "Angela Stein". Never persist this back to hr_users.
const displayHrNickname = (nick: string | null | undefined): string =>
  nick === "Cherry" ? "Angela Stein" : (nick || "");
type Question = { id: string; form_id: string; type: string; label: string; order_index?: number };
type Answer = { response_id: string; question_id: string; answer_text: string | null; file_url: string | null };
type Resp = {
  id: string;
  form_id: string;
  applicant_id: string;
  override_email: string | null;
  round_stage: string | null;
  handled_by_hr_id: string | null;
  round_1_sent_at: string | null;
  round_2_sent_at: string | null;
  offer_sent_at: string | null;
  scheduled_slot_id: string | null;
  appointment_cancelled: boolean | null;
  disqualified_at: string | null;
  disqualified_by_hr_id: string | null;
  final_outcome: string | null;
  disqualified_at_stage: string | null;
  removal_reason: string | null;
  custom_position: string | null;
  r1_completed_hours: number | null;
  r2_completed_hours: number | null;
  offer_signed_hours: number | null;
  future_shortlisted: boolean | null;


};

type Mode = "bookings" | "completed" | "disqualified";

const STATUS_LABEL_BOOKINGS: Record<string, string> = {
  round_1_sent: "Round 1 Sent",
  round_2_sent: "Round 2 Sent",
  offer_sent: "Offer Sent (not signed yet)",
  offer_signed: "Offer Signed",
  offer_expired: "Offer Expired",
  ai_interview_completed: "Interview Completed",
};
const STATUS_LABEL_COMPLETED: Record<string, string> = {
  offer_sent: "Offer Sent (not signed yet)",
  offer_signed: "Offer Signed",
  offer_expired: "Offer Expired",
};
const STATUS_COLOR: Record<string, string> = {
  round_1_sent: "bg-blue-100 text-blue-800",
  round_2_sent: "bg-indigo-100 text-indigo-800",
  offer_sent: "bg-blue-100 text-blue-800",
  offer_signed: "bg-sky-100 text-sky-800",
  offer_expired: "bg-slate-200 text-slate-700",
  ai_interview_completed: "bg-emerald-100 text-emerald-800",
};


const SHARED_PMR_URL = "https://us05web.zoom.us/j/86246183040?pwd=BFfm7cTkoMBSlsaSO452szCoo2iB1Y.1";

export const StageTrackingView = ({ mode }: { mode: Mode }) => {
  const navigate = useNavigate();
  const [searchParams, setSearchParams] = useSearchParams();
  const [search, setSearch] = useState("");
  const [highlightId, setHighlightId] = useState<string | null>(null);
  const locateHandledRef = useRef<string | null>(null);
  const title =
    mode === "bookings" ? "My Bookings"
    : mode === "completed" ? "Completed Candidates"
    : "Disqualified";

  const [loading, setLoading] = useState(true);
  const [hrUsers, setHrUsers] = useState<HrUser[]>([]);
  const [responses, setResponses] = useState<Resp[]>([]);
  const [questions, setQuestions] = useState<Question[]>([]);
  const [answers, setAnswers] = useState<Answer[]>([]);
  const [filter, setFilter] = useState<"all" | string>("all");
  const [formFilter, setFormFilter] = useState<"all" | string>("all");
  const [bookingFilter, setBookingFilter] = useState<"all" | "cancelled" | "shortlisted">("all");
  const [formInfo, setFormInfo] = useState<Record<string, { title: string; positionTitle: string }>>({});
  const [detailsRowId, setDetailsRowId] = useState<string | null>(null);
  const [previewFile, setPreviewFile] = useState<string | null>(null);
  const [slotHrMap, setSlotHrMap] = useState<Record<string, string>>({});
  const [slotInfo, setSlotInfo] = useState<Record<string, { start: string | null; joinUrl: string | null }>>({});
  const [actionsByResponse, setActionsByResponse] = useState<Record<string, CandidateAction>>({});
  const [extrasByResponse, setExtrasByResponse] = useState<Record<string, { photo_file_url: string | null; hr_nickname: string | null; hr_badge: string | null }>>({});
  // Read-only cross-response nickname lookup by lowercased email (follow-the-person).
  const [nicknameByEmail, setNicknameByEmail] = useState<Record<string, string>>({});
  // Read-only cross-response badge lookup by lowercased email (follow-the-person).
  const [badgeByEmail, setBadgeByEmail] = useState<Record<string, string>>({});
  // Display-only AI verdict tier (from ai_interview_evaluations). Own response wins,
  // else borrow from a same-email response's most recent completed interview.
  const [tierByResponse, setTierByResponse] = useState<Record<string, string>>({});
  const [tierByEmail, setTierByEmail] = useState<Record<string, string>>({});
  // Display-only "has a Scout Report presence" (a completed AI interview session exists).
  // ownSessionSet: booking response_ids that have ≥1 session of their own.
  // sessionRespByEmail: email -> response_id carrying that person's most-recent session
  // (used to navigate split/borrowed people to the Scout page that actually has data).
  const [ownSessionSet, setOwnSessionSet] = useState<Record<string, true>>({});
  const [sessionRespByEmail, setSessionRespByEmail] = useState<Record<string, string>>({});
  // Display-only: EVERY response_id that has ≥1 ai_interview_sessions row, loaded
  // once on page load (same pattern as the other lookups in this file). This is the
  // single source of truth for "did this person interview at all" — even a 1-second
  // session counts. The Scout Report link is keyed ONLY off membership in this set
  // (own response_id), independent of round_stage, video, attendance, or appointment
  // state. Empty intersection → no Scout link.
  const [sessionRespIds, setSessionRespIds] = useState<Set<string>>(new Set());
  // Display-only photo borrow: map of booking response_id -> borrowed photo url
  // (same person's photo found on another response by email). Never written to the DB.
  const [borrowedByResponse, setBorrowedByResponse] = useState<Record<string, string>>({});
  // Additive (display-only): set of response_ids that are Universal Zoom bookings (from rebook_tokens).
  const [universalZoomIds, setUniversalZoomIds] = useState<Set<string>>(new Set());
  // Additive (display-only): when ON, ALSO surface blank/null round_stage applicants
  // in My Bookings. Default OFF = list behaves exactly as before. No DB writes.
  const [showAllApplicants, setShowAllApplicants] = useState(false);
  const [extraNullStageCount, setExtraNullStageCount] = useState(0);
  const [restoring, setRestoring] = useState<Resp | null>(null);
  const [restoreBusy, setRestoreBusy] = useState(false);
  const [viewOfferTarget, setViewOfferTarget] = useState<{ candidateId: string; responseId?: string } | null>(null);
  const [customMsgTarget, setCustomMsgTarget] = useState<{ responseId: string; name: string; email: string } | null>(null);
  // Per-row launcher for the EXISTING Universal Zoom modal, pre-filled with this row's name/email.
  // Mints a SEPARATE universal-zoom record; the existing candidate's row is untouched by design.
  const [zoomTarget, setZoomTarget] = useState<{ responseId: string; name: string; email: string } | null>(null);
  // "Send Round 1 (AI)" on a BOOKED row → opens InviteRoundDialog with force_direct.
  // slotId is the row's current scheduled_slot_id so we can free it after sending.
  const [aiR1Target, setAiR1Target] = useState<{ responseId: string; name: string; email: string; slotId: string | null } | null>(null);
  const disqSnapshotRef = useRef<Resp[] | null>(null);
  // Disqualified bulk-delete state
  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set());
  const [trashAllOpen, setTrashAllOpen] = useState(false);
  const [trashAllInput, setTrashAllInput] = useState("");
  const [deleteSelectedOpen, setDeleteSelectedOpen] = useState(false);
  // Bookings bulk-cancel (move selected to Deleted Appointments via release-slot)
  const [cancelSelectedOpen, setCancelSelectedOpen] = useState(false);
  // Deleted Appointments → "Permanently Delete" = VIEW-MOVE into Quarantine (flag only).
  // Single = simple confirm; bulk = typed-DELETE confirm. Never destroys the record.
  const [permDeleteRow, setPermDeleteRow] = useState<{ id: string; name: string } | null>(null);
  const [permDeleteSelectedOpen, setPermDeleteSelectedOpen] = useState(false);
  const [permDeleteInput, setPermDeleteInput] = useState("");
  const [deleting, setDeleting] = useState(false);
  const [interviewMode, setInterviewMode] = useState<string>("ai_direct");
  // Password gate for flipping Interview Mode (AI Direct <-> AI Scheduled).
  // The DB write only fires after password "2828" is entered correctly.
  const [modePwOpen, setModePwOpen] = useState(false);
  const [modePwValue, setModePwValue] = useState("");
  const [pendingMode, setPendingMode] = useState<"ai_direct" | "ai_scheduled" | null>(null);
  // Live elapsed-time refresh for "sent Xh ago" timing badges. No DB writes.
  const [nowTick, setNowTick] = useState<number>(() => Date.now());
  useEffect(() => {
    const t = setInterval(() => setNowTick(Date.now()), 60000);
    return () => clearInterval(t);
  }, []);

  const load = async () => {
    setLoading(true);
    const { data: hrs } = await supabase.from("hr_users").select("id, display_name, nickname").order("display_name");
    setHrUsers((hrs || []) as HrUser[]);

    const respCols = "id, form_id, applicant_id, override_email, override_name, round_stage, handled_by_hr_id, round_1_sent_at, round_2_sent_at, offer_sent_at, scheduled_slot_id, appointment_cancelled, disqualified_at, disqualified_by_hr_id, final_outcome, disqualified_at_stage, removal_reason, custom_position, r1_completed_hours, r2_completed_hours, offer_signed_hours, future_shortlisted";
    let resps: (Resp & { applicant_id?: string })[] = [];
    const slotMap: Record<string, string> = {};

    if (mode === "bookings") {
      try {
        const { data: cfg } = await supabase
          .from("scheduling_config")
          .select("interview_mode")
          .eq("id", 1)
          .maybeSingle();
        setInterviewMode((cfg as any)?.interview_mode === "ai_scheduled" ? "ai_scheduled" : "ai_direct");
      } catch { /* keep default */ }
      const stages = ["round_1_sent", "round_2_sent", "offer_sent", "offer_signed", "ai_interview_completed"];
      const { data: trackedRs } = await supabase
        .from("responses")
        .select(respCols)
        .in("round_stage", stages)
        .is("final_outcome", null)
        .eq("appointment_permanently_deleted", false)
        .limit(1000);
      const { data: cancelledRs } = await supabase
        .from("responses")
        .select(respCols)
        .eq("appointment_cancelled", true)
        .is("final_outcome", null)
        .eq("appointment_permanently_deleted", false)
        .limit(1000);
      const { data: claimedSlots } = await supabase
        .from("interview_slots")
        .select("id, response_id, claimed_by_hr_id, slot_start, zoom_meeting_id")
        .not("claimed_by_hr_id", "is", null)
        .not("response_id", "is", null)
        .limit(1000);
      const claimedRespIds = Array.from(new Set((claimedSlots || []).map((s: any) => s.response_id).filter(Boolean)));
      for (const s of claimedSlots || []) slotMap[s.id] = s.claimed_by_hr_id;

      let claimedResps: any[] = [];
      if (claimedRespIds.length) {
        const { data } = await supabase
          .from("responses")
          .select(respCols)
          .in("id", claimedRespIds)
          .eq("appointment_permanently_deleted", false)
          .limit(1000);
        claimedResps = data || [];
      }
      const byId = new Map<string, any>();
      for (const r of trackedRs || []) byId.set(r.id, r);
      for (const r of cancelledRs || []) byId.set(r.id, r);
      for (const r of claimedResps) if (!byId.has(r.id)) byId.set(r.id, r);

      // Query D (additive, display-only): ONLY when the toggle is ON, ALSO surface
      // blank/null round_stage applicants. Existing rows win; never added twice.
      let extraNullStage = 0;
      if (showAllApplicants) {
        const { data: nullStageRs } = await supabase
          .from("responses")
          .select(respCols)
          .or("round_stage.is.null,round_stage.eq.")
          .is("final_outcome", null)
          .eq("appointment_permanently_deleted", false)
          .limit(1000);
        for (const r of nullStageRs || []) {
          if (!byId.has(r.id)) {
            byId.set(r.id, r);
            extraNullStage++;
          }
        }
      }
      setExtraNullStageCount(extraNullStage);

      // Keep offer_sent / offer_signed visible here until HR marks Matched / Not Matched.
      // Exclude only fully-decided (final_outcome set) and disqualified rows.
      const merged = Array.from(byId.values()).filter(
        (r) => r.round_stage !== "disqualified" && !r.final_outcome
      );
      resps = merged;
    } else if (mode === "completed") {
      const { data } = await supabase
        .from("responses")
        .select(respCols)
        .in("round_stage", ["offer_sent", "offer_signed"])
        .order("offer_sent_at", { ascending: false })
        .limit(1000);
      resps = (data || []) as any;
    } else {
      const { data } = await supabase
        .from("responses")
        .select(respCols)
        .eq("round_stage", "disqualified")
        .eq("removed_from_disqualified_view", false)
        .order("disqualified_at", { ascending: false })
        .limit(1000);
      resps = (data || []) as any;
    }

    setSlotHrMap(slotMap);
    setResponses(resps as Resp[]);

    // Bookings: load slot times + zoom join URLs for the appointment column.
    if (mode === "bookings") {
      const slotIds = Array.from(new Set(resps.map((r: any) => r.scheduled_slot_id).filter(Boolean)));
      const sInfo: Record<string, { start: string | null; joinUrl: string | null }> = {};
      if (slotIds.length) {
        const { data: slotRows } = await supabase
          .from("interview_slots")
          .select("id, slot_start, zoom_meeting_id")
          .in("id", slotIds);
        const zoomIds = Array.from(new Set((slotRows || []).map((s: any) => s.zoom_meeting_id).filter(Boolean)));
        let joinByZoomId: Record<string, string> = {};
        if (zoomIds.length) {
          const { data: zms } = await supabase
            .from("zoom_meetings")
            .select("id, join_url")
            .in("id", zoomIds);
          for (const z of zms || []) joinByZoomId[(z as any).id] = (z as any).join_url;
        }
        for (const s of slotRows || []) {
          sInfo[(s as any).id] = {
            start: (s as any).slot_start,
            joinUrl: (s as any).zoom_meeting_id ? joinByZoomId[(s as any).zoom_meeting_id] || null : null,
          };
        }
      }
      setSlotInfo(sInfo);
    } else {
      setSlotInfo({});
    }

    if (resps.length) {
      const respIds = resps.map((r) => r.id);
      const formIds = Array.from(new Set(resps.map((r) => r.form_id)));
      const [{ data: qs }, { data: forms }, { data: metas }, { data: acts }, { data: extras }] = await Promise.all([
        supabase.from("questions").select("id, form_id, type, label, order_index").in("form_id", formIds).limit(10000),
        supabase.from("forms").select("id, title").in("id", formIds),
        supabase.from("form_metadata").select("form_id, position_title").in("form_id", formIds),
        supabase.from("candidate_actions").select("*").in("response_id", respIds).limit(5000),
        supabase.from("hr_candidate_extras").select("response_id, photo_file_url, hr_nickname, hr_badge").in("response_id", respIds),
      ]);
      // Answers can exceed PostgREST's db-max-rows=1000 cap (e.g. 125 candidates ≈ 2166 rows),
      // which silently drops rows past 1000 and loses name/photo for those candidates.
      // Page through with .range() ordered stably until a short page is returned.
      const PAGE = 1000;
      const allAnswers: any[] = [];
      for (let from = 0; ; from += PAGE) {
        const { data: page } = await supabase
          .from("answers")
          .select("response_id, question_id, answer_text, file_url")
          .in("response_id", respIds)
          .order("response_id", { ascending: true })
          .order("question_id", { ascending: true })
          .range(from, from + PAGE - 1);
        const rows = page || [];
        allAnswers.push(...rows);
        if (rows.length < PAGE) break;
      }
      setQuestions((qs || []) as Question[]);
      setAnswers(allAnswers as Answer[]);
      const actMap: Record<string, CandidateAction> = {};
      for (const a of (acts || []) as any[]) if (a.response_id) actMap[a.response_id] = a as CandidateAction;
      setActionsByResponse(actMap);
      const exMap: Record<string, { photo_file_url: string | null; hr_nickname: string | null; hr_badge: string | null }> = {};
      for (const e of (extras || []) as any[]) exMap[e.response_id] = { photo_file_url: e.photo_file_url ?? null, hr_nickname: e.hr_nickname ?? null, hr_badge: e.hr_badge ?? null };
      setExtrasByResponse(exMap);
      const info: Record<string, { title: string; positionTitle: string }> = {};
      for (const f of (forms || []) as any[]) {
        info[f.id] = { title: f.title || "Untitled Form", positionTitle: "" };
      }
      for (const m of (metas || []) as any[]) {
        const pt = cleanPositionTitle(m.position_title || "");
        if (!info[m.form_id]) info[m.form_id] = { title: "Untitled Form", positionTitle: pt };
        else info[m.form_id].positionTitle = pt;
      }
      // Fallback: derive positionTitle from form title when missing
      for (const fid of Object.keys(info)) {
        if (!info[fid].positionTitle) info[fid].positionTitle = cleanPositionTitle(info[fid].title);
      }
      setFormInfo(info);

      // Additive read (display-only): flag Universal Zoom bookings in bookings mode.
      if (mode === "bookings") {
        const { data: uzToks } = await supabase
          .from("rebook_tokens")
          .select("response_id")
          .eq("is_universal_zoom", true)
          .in("response_id", respIds);
        const uzSet = new Set<string>();
        for (const t of (uzToks || []) as any[]) if (t.response_id) uzSet.add(t.response_id as string);
        setUniversalZoomIds(uzSet);
      } else {
        setUniversalZoomIds(new Set());
      }
    } else {
      setQuestions([]); setAnswers([]); setFormInfo({}); setActionsByResponse({}); setExtrasByResponse({}); setUniversalZoomIds(new Set());
    }
    setLoading(false);
  };

  useEffect(() => { document.title = `${title} — EIA`; load(); /* eslint-disable-next-line */ }, [mode]);
  // Re-run the load when the "Show All Applicants" toggle changes (bookings mode only).
  useEffect(() => { if (mode === "bookings") load(); /* eslint-disable-next-line */ }, [showAllApplicants]);

  // Realtime (display refresh only): keep candidate_actions fresh so a webhook-driven
  // attendance write — e.g. retell-webhook-receiver auto-marking
  // round1_attendance_status='attended' when a Christine AI R1 interview completes —
  // flips the Send Round 2 button from greyed to enabled WITHOUT a manual reload.
  // Patches the changed row in place (never refetches the page, never reloads, never
  // scroll-jumps) and only touches rows already on screen, so filters/selection survive.
  useEffect(() => {
    const channel = supabase
      .channel("stage-tracking-candidate-actions")
      .on(
        "postgres_changes",
        { event: "UPDATE", schema: "public", table: "candidate_actions" },
        (payload) => {
          const next = payload.new as CandidateAction;
          const rid = next?.response_id;
          if (!rid) return;
          // Only patch a row that's currently loaded — never inject off-screen rows.
          setActionsByResponse((curr) => (curr[rid] ? { ...curr, [rid]: next } : curr));
        },
      )
      .subscribe();
    return () => { supabase.removeChannel(channel); };
  }, []);


  const formQMaps = useMemo(() => {
    const byForm: Record<string, Question[]> = {};
    for (const q of questions) (byForm[q.form_id] = byForm[q.form_id] || []).push(q);
    const PHOTO_RE = /(photo|selfie|picture|headshot|portrait|image)/i;
    const RESUME_RE = /(resume|cv|curriculum)/i;
    const map: Record<string, { nameQid?: string; emailQid?: string; selfieQid?: string; resumeQid?: string }> = {};
    for (const [fid, qs] of Object.entries(byForm)) {
      const contacts = detectContactQuestionIds(qs.map((q) => ({ id: q.id, type: q.type, label: q.label })));
      const sorted = [...qs].sort((a, b) => (a.order_index || 0) - (b.order_index || 0));
      const uploads = sorted.filter((q) => q.type === "file_upload" || q.type === "selfie");
      const selfieQ = uploads.find((q) => q.type === "selfie") || uploads.find((q) => PHOTO_RE.test(q.label || ""));
      const resumeQ = uploads.find((q) => RESUME_RE.test(q.label || ""));
      map[fid] = { ...contacts, selfieQid: selfieQ?.id, resumeQid: resumeQ?.id };
    }
    return map;
  }, [questions]);

  const findAnswer = (rid: string, qid?: string) =>
    qid ? answers.find((a) => a.response_id === rid && a.question_id === qid) : undefined;

  const hrLabelById = useMemo(() => {
    const m: Record<string, string> = {};
    for (const h of hrUsers) {
      m[h.id] = h.nickname ? `${h.display_name} / ${displayHrNickname(h.nickname)}` : h.display_name;
    }
    return m;
  }, [hrUsers]);

  const resolveHrId = (r: Resp): string | null => {
    if (mode === "disqualified") return r.disqualified_by_hr_id;
    return r.handled_by_hr_id || (r.scheduled_slot_id ? slotHrMap[r.scheduled_slot_id] || null : null);
  };

  const rows = useMemo(() => {
    return responses.map((r) => {
      const qids = formQMaps[r.form_id] || {};
      const nameA = findAnswer(r.id, qids.nameQid);
      const emailA = findAnswer(r.id, qids.emailQid);
      const selfieA = findAnswer(r.id, qids.selfieQid);
      const resumeA = findAnswer(r.id, qids.resumeQid);
      const hrId = resolveHrId(r);
      const effectiveStage = r.round_stage || "";
      const info = formInfo[r.form_id];
      const si = r.scheduled_slot_id ? slotInfo[r.scheduled_slot_id] : undefined;
      return {
        response: r,
        hrId,
        effectiveStage,
        name: ((r as any).override_name || nameA?.answer_text || "").trim(),
        email: (r.override_email || emailA?.answer_text || "").trim(),
        // Own photo first; if none, fall back to a display-only borrowed photo (same email).
        selfieUrl: selfieA?.file_url || extrasByResponse[r.id]?.photo_file_url || borrowedByResponse[r.id] || undefined,
        resumeUrl: resumeA?.file_url || undefined,
        bookedBy: hrId ? hrLabelById[hrId] || "—" : "—",
        positionTitle: (r.custom_position || "").trim() || info?.positionTitle || "",
        formTitle: info?.title || "",
        appointmentStart: si?.start || null,
        joinUrl: si?.joinUrl || null,
        isUniversalZoom: universalZoomIds.has(r.id),
      };
    });
  }, [responses, formQMaps, answers, hrLabelById, slotHrMap, mode, formInfo, slotInfo, extrasByResponse, borrowedByResponse, universalZoomIds]);

  // ── Email-level Round 1 completion (duplicate-row safe) ────────────────────
  // A person can have MORE THAN ONE responses row (applied/booked twice). The
  // interview + "attended" mark may land on one row while My Bookings renders a
  // different (booked) row. To keep Send Round 2 correct, treat R1 as completed
  // for EVERY row sharing the same candidate email if ANY of that person's
  // already-loaded rows is R1-completed — i.e. its candidate_actions has
  // round1_attendance_status === 'attended' OR its round_stage is
  // 'ai_interview_completed'. Read-only across loaded data; never merges/deletes
  // rows and never touches Zoom/slots/no-show/offer logic.
  const emailR1Completed = useMemo(() => {
    const norm = (s: string | null | undefined) => (s || "").trim().toLowerCase();
    const map: Record<string, boolean> = {};
    for (const r of responses) {
      const qids = formQMaps[r.form_id] || {};
      const emailAns = findAnswer(r.id, qids.emailQid);
      const email = norm(r.override_email || emailAns?.answer_text);
      if (!email) continue;
      const completed =
        actionsByResponse[r.id]?.round1_attendance_status === "attended" ||
        r.round_stage === "ai_interview_completed";
      if (completed) map[email] = true;
      else if (!(email in map)) map[email] = false;
    }
    return map;
  }, [responses, formQMaps, answers, actionsByResponse]);

  // ── Display-only photo borrow (bookings only) ──────────────────────────────
  // Rows whose own selfie/extras photo is empty borrow the SAME person's photo
  // from another response, matched by email. Read-only; runs after main rows so
  // the page paints first, then borrowed photos fill in. Never writes the DB.
  useEffect(() => {
    if (mode !== "bookings") { setBorrowedByResponse({}); return; }
    let cancelled = false;
    const ADMIN_EMAIL = "spark11179@gmail.com";
    const norm = (s: string | null | undefined) => (s || "").trim().toLowerCase();

    (async () => {
      // STEP 1: collect no-photo rows + their (lowercased) emails.
      const noPhoto: { id: string; form_id: string; email: string }[] = [];
      for (const r of responses) {
        const qids = formQMaps[r.form_id] || {};
        const ownSelfie = qids.selfieQid
          ? answers.find((a) => a.response_id === r.id && a.question_id === qids.selfieQid)?.file_url
          : undefined;
        const ownExtra = extrasByResponse[r.id]?.photo_file_url;
        if (ownSelfie || ownExtra) continue;
        const emailAns = qids.emailQid
          ? answers.find((a) => a.response_id === r.id && a.question_id === qids.emailQid)?.answer_text
          : undefined;
        const email = norm(r.override_email || emailAns);
        if (!email || email === ADMIN_EMAIL) continue; // never borrow for admin email
        noPhoto.push({ id: r.id, form_id: r.form_id, email });
      }
      if (!noPhoto.length) { if (!cancelled) setBorrowedByResponse({}); return; }
      const emails = Array.from(new Set(noPhoto.map((n) => n.email)));

      // STEP 2: find candidate SOURCE responses (incl. non-booking) by email,
      // via override_email or an email-valued answer.
      const [{ data: byOverride }, { data: byAnswer }] = await Promise.all([
        supabase.from("responses").select("id, form_id, override_email, submitted_at").in("override_email", emails),
        supabase.from("answers").select("response_id, answer_text").in("answer_text", emails),
      ]);

      const srcMeta: Record<string, { form_id: string | null; submitted_at: string | null; email: string }> = {};
      for (const r of (byOverride || []) as any[]) {
        srcMeta[r.id] = { form_id: r.form_id, submitted_at: r.submitted_at, email: norm(r.override_email) };
      }
      const answerEmailById: Record<string, string> = {};
      for (const a of (byAnswer || []) as any[]) answerEmailById[a.response_id] = norm(a.answer_text);
      const missingMetaIds = Object.keys(answerEmailById).filter((id) => !srcMeta[id]);
      if (missingMetaIds.length) {
        const { data: extraResps } = await supabase
          .from("responses").select("id, form_id, submitted_at").in("id", missingMetaIds);
        for (const r of (extraResps || []) as any[]) {
          srcMeta[r.id] = { form_id: r.form_id, submitted_at: r.submitted_at, email: answerEmailById[r.id] };
        }
      }
      const srcIds = Object.keys(srcMeta);
      if (!srcIds.length) { if (!cancelled) setBorrowedByResponse({}); return; }

      // Fetch the source forms' questions to detect each form's selfie question,
      // plus the source responses' answers + extras (all read-only, single .in()).
      const srcFormIds = Array.from(new Set(Object.values(srcMeta).map((m) => m.form_id).filter(Boolean))) as string[];
      const [{ data: srcQs }, { data: srcExtras }] = await Promise.all([
        srcFormIds.length
          ? supabase.from("questions").select("id, form_id, type, label, order_index").in("form_id", srcFormIds).limit(10000)
          : Promise.resolve({ data: [] as any[] } as any),
        supabase.from("hr_candidate_extras").select("response_id, photo_file_url").in("response_id", srcIds),
      ]);
      // Page answers for source responses (can exceed 1000 rows).
      const PHOTO_RE = /(photo|selfie|picture|headshot|portrait|image)/i;
      const srcAnswers: { response_id: string; question_id: string; file_url: string | null }[] = [];
      const PAGE = 1000;
      for (let from = 0; ; from += PAGE) {
        const { data: page } = await supabase
          .from("answers")
          .select("response_id, question_id, file_url")
          .in("response_id", srcIds)
          .order("response_id", { ascending: true })
          .order("question_id", { ascending: true })
          .range(from, from + PAGE - 1);
        const pg = page || [];
        srcAnswers.push(...(pg as any[]));
        if (pg.length < PAGE) break;
      }

      // Per source form, detect selfie question id (same logic as formQMaps).
      const selfieQidByForm: Record<string, string | undefined> = {};
      const qByForm: Record<string, any[]> = {};
      for (const q of (srcQs || []) as any[]) (qByForm[q.form_id] = qByForm[q.form_id] || []).push(q);
      for (const [fid, qs] of Object.entries(qByForm)) {
        const sorted = [...qs].sort((a, b) => (a.order_index || 0) - (b.order_index || 0));
        const uploads = sorted.filter((q) => q.type === "file_upload" || q.type === "selfie");
        const selfieQ = uploads.find((q) => q.type === "selfie") || uploads.find((q) => PHOTO_RE.test(q.label || ""));
        selfieQidByForm[fid] = selfieQ?.id;
      }
      const extraBySrc: Record<string, string | null> = {};
      for (const e of (srcExtras || []) as any[]) extraBySrc[e.response_id] = e.photo_file_url ?? null;

      // Build per-source photo candidates (only sources that actually HAVE a photo).
      type Cand = { id: string; email: string; form_id: string | null; submitted_at: number; selfieUrl?: string; extraUrl?: string };
      const candidates: Cand[] = [];
      for (const id of srcIds) {
        const meta = srcMeta[id];
        const selfieQid = meta.form_id ? selfieQidByForm[meta.form_id] : undefined;
        const selfieUrl = selfieQid
          ? srcAnswers.find((a) => a.response_id === id && a.question_id === selfieQid)?.file_url || undefined
          : undefined;
        const extraUrl = extraBySrc[id] || undefined;
        if (!selfieUrl && !extraUrl) continue;
        candidates.push({
          id, email: meta.email, form_id: meta.form_id,
          submitted_at: meta.submitted_at ? Date.parse(meta.submitted_at) : 0,
          selfieUrl, extraUrl,
        });
      }

      // STEP 3: pick the best borrowed photo per no-photo row with the tiebreak:
      // (1) same form_id, (2) real selfie answer over extras, (3) most recent.
      // Skip when genuinely ambiguous (equally-ranked, differing photos).
      const borrowMap: Record<string, string> = {};
      for (const row of noPhoto) {
        const pool = candidates.filter((c) => c.email === row.email && c.id !== row.id);
        if (!pool.length) continue;
        const rank = (c: Cand): [number, number, number] => [
          c.form_id === row.form_id ? 1 : 0,
          c.selfieUrl ? 1 : 0,
          c.submitted_at,
        ];
        const cmp = (a: Cand, b: Cand) => {
          const ra = rank(a), rb = rank(b);
          for (let i = 0; i < ra.length; i++) if (ra[i] !== rb[i]) return rb[i] - ra[i];
          return 0;
        };
        const sorted = [...pool].sort(cmp);
        const top = sorted[0];
        const topUrl = top.selfieUrl || top.extraUrl!;
        // Ambiguity guard: if another candidate ties on rank but has a different photo, skip.
        const tiedDifferent = sorted
          .slice(1)
          .some((c) => cmp(top, c) === 0 && (c.selfieUrl || c.extraUrl) !== topUrl);
        if (tiedDifferent) continue;
        borrowMap[row.id] = topUrl;
      }

      if (!cancelled) setBorrowedByResponse(borrowMap);
    })().catch(() => { if (!cancelled) setBorrowedByResponse({}); });

    return () => { cancelled = true; };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [mode, responses, answers, extrasByResponse, formQMaps]);

  // ── Display-only HR nickname follow-by-email (bookings only) ────────────────
  // A row's own hr_nickname is loaded with extras. Here we surface a nickname set
  // on ANY other response that shares the row's email. Read-only; runs after rows
  // paint; never shares the admin email's nickname. Editing happens only in Scout.
  useEffect(() => {
    if (mode !== "bookings") { setNicknameByEmail({}); setBadgeByEmail({}); return; }
    let cancelled = false;
    const ADMIN_EMAIL = "spark11179@gmail.com";
    const norm = (s: string | null | undefined) => (s || "").trim().toLowerCase();
    (async () => {
      const emails = new Set<string>();
      for (const r of responses) {
        const qids = formQMaps[r.form_id] || {};
        const emailAns = qids.emailQid
          ? answers.find((a) => a.response_id === r.id && a.question_id === qids.emailQid)?.answer_text
          : undefined;
        const e = norm(r.override_email || emailAns);
        if (e && e !== ADMIN_EMAIL) emails.add(e);
      }
      const emailList = Array.from(emails);
      if (!emailList.length) { if (!cancelled) { setNicknameByEmail({}); setBadgeByEmail({}); } return; }
      const { data: resps } = await supabase
        .from("responses").select("id, override_email").in("override_email", emailList);
      const emailById: Record<string, string> = {};
      for (const r of (resps || []) as any[]) emailById[r.id] = norm(r.override_email);
      const ids = Object.keys(emailById);
      if (!ids.length) { if (!cancelled) { setNicknameByEmail({}); setBadgeByEmail({}); } return; }
      const { data: ex } = await supabase
        .from("hr_candidate_extras").select("response_id, hr_nickname, hr_badge, updated_at").in("response_id", ids);
      const bestNick: Record<string, { v: string; ts: number }> = {};
      const bestBadge: Record<string, { v: string; ts: number }> = {};
      for (const e of (ex || []) as any[]) {
        const em = emailById[e.response_id];
        if (!em || em === ADMIN_EMAIL) continue;
        const ts = e.updated_at ? Date.parse(e.updated_at) : 0;
        if (e.hr_nickname && (!bestNick[em] || ts > bestNick[em].ts)) bestNick[em] = { v: e.hr_nickname, ts };
        if (e.hr_badge && (!bestBadge[em] || ts > bestBadge[em].ts)) bestBadge[em] = { v: e.hr_badge, ts };
      }
      const nickMap: Record<string, string> = {};
      for (const [em, v] of Object.entries(bestNick)) nickMap[em] = v.v;
      const badgeMap: Record<string, string> = {};
      for (const [em, v] of Object.entries(bestBadge)) badgeMap[em] = v.v;
      if (!cancelled) { setNicknameByEmail(nickMap); setBadgeByEmail(badgeMap); }
    })().catch(() => { if (!cancelled) { setNicknameByEmail({}); setBadgeByEmail({}); } });
    return () => { cancelled = true; };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [mode, responses, answers, extrasByResponse, formQMaps]);

  // Resolved read-only nickname for a booking row (own wins, else same-email borrow).
  const resolveNickname = (responseId: string, email: string): string => {
    const own = extrasByResponse[responseId]?.hr_nickname;
    if (own) return own;
    const e = (email || "").trim().toLowerCase();
    if (e && e !== "spark11179@gmail.com") return nicknameByEmail[e] || "";
    return "";
  };

  // Resolved read-only badge for a booking row (own wins, else same-email borrow).
  const resolveBadge = (responseId: string, email: string): string => {
    const own = extrasByResponse[responseId]?.hr_badge;
    if (own) return own;
    const e = (email || "").trim().toLowerCase();
    if (e && e !== "spark11179@gmail.com") return badgeByEmail[e] || "";
    return "";
  };

  // ── Display-only AI verdict tier (bookings only) ────────────────────────────
  // Resolves each booking row's AI tier from ai_interview_evaluations via its
  // most recent ai_interview_sessions (by response_id). Also follows-the-person
  // by email: a row with no tier of its own borrows the tier from a same-email
  // response's most recent completed interview. Read-only; post-paint; never
  // borrows across the admin email. No DB writes.
  useEffect(() => {
    if (mode !== "bookings") { setTierByResponse({}); setTierByEmail({}); setOwnSessionSet({}); setSessionRespByEmail({}); return; }
    let cancelled = false;
    const ADMIN_EMAIL = "spark11179@gmail.com";
    const norm = (s: string | null | undefined) => (s || "").trim().toLowerCase();
    (async () => {
      // Booking row response ids + their emails.
      const bookingIds = responses.map((r) => r.id);
      const emailByResponse: Record<string, string> = {};
      const emails = new Set<string>();
      for (const r of responses) {
        const qids = formQMaps[r.form_id] || {};
        const emailAns = qids.emailQid
          ? answers.find((a) => a.response_id === r.id && a.question_id === qids.emailQid)?.answer_text
          : undefined;
        const e = norm(r.override_email || emailAns);
        emailByResponse[r.id] = e;
        if (e && e !== ADMIN_EMAIL) emails.add(e);
      }
      // Same-email responses (for borrow), mirroring the nickname/badge effect.
      const emailList = Array.from(emails);
      const emailById: Record<string, string> = {};
      if (emailList.length) {
        const { data: resps } = await supabase
          .from("responses").select("id, override_email").in("override_email", emailList);
        for (const r of (resps || []) as any[]) emailById[r.id] = norm(r.override_email);
      }
      // All response ids we need tiers for.
      const allIds = Array.from(new Set([...bookingIds, ...Object.keys(emailById)]));
      if (!allIds.length) { if (!cancelled) { setTierByResponse({}); setTierByEmail({}); setOwnSessionSet({}); setSessionRespByEmail({}); } return; }
      // Sessions for those responses (carry created_at for "most recent").
      const { data: sessions } = await supabase
        .from("ai_interview_sessions")
        .select("id, response_id, created_at")
        .in("response_id", allIds)
        .limit(10000);
      const sessList = (sessions || []) as any[];
      const sessIds = sessList.map((s) => s.id).filter(Boolean);
      // ── "Has a Scout presence" maps (session existing = R1 completed), built from
      // session existence alone (independent of whether a tier/eval was written). ──
      const bookingIdSet = new Set(bookingIds);
      const ownSess: Record<string, true> = {};
      const bestSessByEmail: Record<string, { rid: string; ts: number }> = {};
      for (const s of sessList) {
        if (!s.response_id) continue;
        if (bookingIdSet.has(s.response_id)) ownSess[s.response_id] = true;
        const em = emailByResponse[s.response_id] || emailById[s.response_id];
        if (!em || em === ADMIN_EMAIL) continue;
        const ts = s.created_at ? Date.parse(s.created_at) : 0;
        const cur = bestSessByEmail[em];
        if (!cur || ts > cur.ts) bestSessByEmail[em] = { rid: s.response_id, ts };
      }
      const sessEmailMap: Record<string, string> = {};
      for (const [em, v] of Object.entries(bestSessByEmail)) sessEmailMap[em] = v.rid;
      if (!sessIds.length) { if (!cancelled) { setTierByResponse({}); setTierByEmail({}); setOwnSessionSet(ownSess); setSessionRespByEmail(sessEmailMap); } return; }
      // Evaluations carrying the tier, keyed by session_id.
      const tierBySession: Record<string, string> = {};
      // Page through evaluations in case of >1000.
      const PAGE = 1000;
      for (let i = 0; i < sessIds.length; i += PAGE) {
        const chunk = sessIds.slice(i, i + PAGE);
        const { data: evals } = await supabase
          .from("ai_interview_evaluations")
          .select("session_id, tier")
          .in("session_id", chunk)
          .limit(10000);
        for (const ev of (evals || []) as any[]) {
          const t = (ev.tier || "").trim();
          if (ev.session_id && t) tierBySession[ev.session_id] = t;
        }
      }
      // Most recent session WITH a tier per response_id.
      const bestByResp: Record<string, { tier: string; ts: number }> = {};
      for (const s of sessList) {
        const t = tierBySession[s.id];
        if (!t || !s.response_id) continue;
        const ts = s.created_at ? Date.parse(s.created_at) : 0;
        const cur = bestByResp[s.response_id];
        if (!cur || ts > cur.ts) bestByResp[s.response_id] = { tier: t, ts };
      }
      const respMap: Record<string, string> = {};
      for (const [rid, v] of Object.entries(bestByResp)) respMap[rid] = v.tier;
      // Per-email best (most recent across all that email's responses).
      const bestByEmail: Record<string, { tier: string; ts: number }> = {};
      for (const s of sessList) {
        const t = tierBySession[s.id];
        if (!t || !s.response_id) continue;
        const em = emailByResponse[s.response_id] || emailById[s.response_id];
        if (!em || em === ADMIN_EMAIL) continue;
        const ts = s.created_at ? Date.parse(s.created_at) : 0;
        const cur = bestByEmail[em];
        if (!cur || ts > cur.ts) bestByEmail[em] = { tier: t, ts };
      }
      const emailMap: Record<string, string> = {};
      for (const [em, v] of Object.entries(bestByEmail)) emailMap[em] = v.tier;
      if (!cancelled) { setTierByResponse(respMap); setTierByEmail(emailMap); setOwnSessionSet(ownSess); setSessionRespByEmail(sessEmailMap); }
    })().catch(() => { if (!cancelled) { setTierByResponse({}); setTierByEmail({}); setOwnSessionSet({}); setSessionRespByEmail({}); } });
    return () => { cancelled = true; };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [mode, responses, answers, formQMaps]);

  // Load EVERY response_id that has ≥1 ai_interview_sessions row, once per page load.
  // This is the authoritative "interviewed at all" set that drives the Scout link,
  // keyed purely on session existence (not round_stage / video / attendance / appt).
  useEffect(() => {
    if (mode !== "bookings") { setSessionRespIds(new Set()); return; }
    let cancelled = false;
    (async () => {
      const ids = new Set<string>();
      const PAGE = 1000;
      for (let from = 0; ; from += PAGE) {
        const { data, error } = await supabase
          .from("ai_interview_sessions")
          .select("response_id")
          .not("response_id", "is", null)
          .range(from, from + PAGE - 1);
        if (error || !data || !data.length) break;
        for (const r of data as any[]) if (r.response_id) ids.add(r.response_id);
        if (data.length < PAGE) break;
      }
      if (!cancelled) setSessionRespIds(ids);
    })().catch(() => { if (!cancelled) setSessionRespIds(new Set()); });
    return () => { cancelled = true; };
  }, [mode]);

  // Resolved read-only AI tier for a booking row (own wins, else same-email borrow).
  const resolveTier = (responseId: string, email: string): string => {
    const own = tierByResponse[responseId];
    if (own) return own;
    const e = (email || "").trim().toLowerCase();
    if (e && e !== "spark11179@gmail.com") return tierByEmail[e] || "";
    return "";
  };

  // Read-only "Scout shortcut" resolver. A row gets a Scout link if its OWN response
  // has any interview session (global sessionRespIds set — even a 1-second session),
  // OR (legacy borrow) a same-email response carries the session. Keyed off session
  // existence ALONE — never round_stage, video, attendance, or appointment state.
  // Empty string = this person never interviewed → no Scout button. Admin email is
  // never borrowed across people.
  const resolveScout = (responseId: string, email: string): string => {
    if (sessionRespIds.has(responseId) || ownSessionSet[responseId]) return responseId;
    const e = (email || "").trim().toLowerCase();
    if (e && e !== "spark11179@gmail.com") return sessionRespByEmail[e] || "";
    return "";
  };





  const formOptions = useMemo(() => {
    const seen = new Map<string, string>();
    for (const r of rows) {
      if (!seen.has(r.response.form_id)) {
        seen.set(r.response.form_id, r.positionTitle || r.formTitle || "Untitled Form");
      }
    }
    return Array.from(seen.entries())
      .map(([id, label]) => ({ id, label }))
      .sort((a, b) => a.label.localeCompare(b.label));
  }, [rows]);

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    const base = rows.filter((row) => {
      if (filter !== "all" && row.hrId !== filter) return false;
      if (formFilter !== "all" && row.response.form_id !== formFilter) return false;
      if (mode === "bookings") {
        const isCancelled = !!row.response.appointment_cancelled;
        const isShortlisted = !!row.response.future_shortlisted;
        if (bookingFilter === "shortlisted") {
          // Future Shortlisted tab: only parked rows, never cancelled.
          if (!isShortlisted || isCancelled) return false;
        } else if (bookingFilter === "cancelled") {
          if (!isCancelled) return false;
          // shortlisted rows never leak into the Deleted tab.
          if (isShortlisted) return false;
        } else if (isCancelled) {
          // active "All" list excludes every cancelled row by flag alone;
          // they live only in the Cancelled tab.
          return false;
        } else if (isShortlisted) {
          // active "Current" list excludes parked rows; they live in the
          // Future Shortlisted tab only.
          return false;
        }
      }
      if (q) {
        const name = (row.name || "").toLowerCase();
        const email = (row.email || "").toLowerCase();
        if (!name.includes(q) && !email.includes(q)) return false;
      }
      return true;
    });
    if (mode === "bookings") {
      // Soonest appointment first; rows without a booking go to the bottom.
      return [...base].sort((a, b) => {
        const at = a.appointmentStart ? new Date(a.appointmentStart).getTime() : Number.POSITIVE_INFINITY;
        const bt = b.appointmentStart ? new Date(b.appointmentStart).getTime() : Number.POSITIVE_INFINITY;
        return at - bt;
      });
    }
    return base;
  }, [rows, filter, formFilter, bookingFilter, mode, search]);

  // Consume ?locate=<response_id> from the Results page "Locate Me" button.
  useEffect(() => {
    if (loading) return;
    const locate = (searchParams.get("locate") || "").trim();
    if (!locate) return;
    if (locateHandledRef.current === locate) return;
    locateHandledRef.current = locate;

    const ADMIN_EMAIL = "spark11179@gmail.com";
    const locateEmail = (searchParams.get("locate_email") || "").trim().toLowerCase();

    const clearParam = () => {
      const next = new URLSearchParams(searchParams);
      next.delete("locate");
      next.delete("locate_email");
      setSearchParams(next, { replace: true });
    };

    // 1) Try exact response_id match. 2) Fall back to email (handles split identity).
    let target = rows.find((r) => r.response.id === locate);
    if (!target && locateEmail && locateEmail !== ADMIN_EMAIL) {
      target = rows.find((r) => {
        const e = (r.email || "").trim().toLowerCase();
        return e && e !== ADMIN_EMAIL && e === locateEmail;
      });
    }
    if (!target) {
      toast.error("Candidate not found in current view");
      clearParam();
      return;
    }

    // Make the candidate visible regardless of the current tab/filter state.
    setFilter("all");
    setFormFilter("all");
    setSearch("");
    if (mode === "bookings") {
      setBookingFilter(
        target.response.appointment_cancelled ? "cancelled"
        : target.response.future_shortlisted ? "shortlisted"
        : "all"
      );
    }
    setHighlightId(target.response.id);
    clearParam();
  }, [loading, rows, searchParams, setSearchParams, mode]);

  // Scroll to + briefly highlight the located row once it is rendered.
  useEffect(() => {
    if (!highlightId) return;
    const scrollTimer = setTimeout(() => {
      const el = document.querySelector(`[data-response-id="${highlightId}"]`);
      if (el) el.scrollIntoView({ behavior: "smooth", block: "center" });
    }, 150);
    const clearTimer = setTimeout(() => setHighlightId(null), 2600);
    return () => { clearTimeout(scrollTimer); clearTimeout(clearTimer); };
  }, [highlightId, filtered]);




  const bookingCounts = useMemo(() => {
    if (mode !== "bookings") return { all: 0, booked: 0, cancelled: 0, unbooked: 0, shortlisted: 0 };
    const base = rows.filter((row) => {
      if (filter !== "all" && row.hrId !== filter) return false;
      if (formFilter !== "all" && row.response.form_id !== formFilter) return false;
      return true;
    });
    let booked = 0, cancelled = 0, unbooked = 0, shortlisted = 0;
    for (const r of base) {
      if (r.response.appointment_cancelled) cancelled++;
      else if (r.response.scheduled_slot_id) booked++;
      else unbooked++;
      // Parked rows (not cancelled) are counted separately and removed from "All".
      if (r.response.future_shortlisted && !r.response.appointment_cancelled) shortlisted++;
    }
    // "All" = active only (excludes cancelled AND shortlisted); each lives only in its own tab.
    return { all: base.length - cancelled - shortlisted, booked, cancelled, unbooked, shortlisted };
  }, [rows, filter, formFilter, mode]);

  const handleRestore = async () => {
    if (!restoring) return;
    setRestoreBusy(true);
    const target = restoring;
    const snapshot = responses;
    try {
      let nextStage: string | null = null;
      if (target.offer_sent_at) nextStage = "offer_sent";
      else if (target.round_2_sent_at) nextStage = "round_2_sent";
      else if (target.round_1_sent_at) nextStage = "round_1_sent";

      // Optimistic: remove from the Disqualified list now.
      setResponses((prev) => prev.filter((r) => r.id !== target.id));
      setRestoring(null);

      const { error } = await supabase
        .from("responses")
        .update({
          round_stage: nextStage,
          disqualified_at: null,
          disqualified_by_hr_id: null,
          disqualified_at_stage: null,
          final_outcome: null,
          removal_reason: null,
        })
        .eq("id", target.id);
      if (error) throw error;
      toast.success("Candidate restored");
    } catch (e: any) {
      setResponses(snapshot);
      toast.error(e?.message || "Could not restore — reverted");
    } finally {
      setRestoreBusy(false);
    }
  };

  const labelMap = mode === "bookings" ? STATUS_LABEL_BOOKINGS : STATUS_LABEL_COMPLETED;
  const noun = mode === "bookings" ? "Bookings" : mode === "completed" ? "Candidates" : "Disqualified";

  const showDisqualifiedAtCol = mode === "disqualified";
  const showStatusCol = mode !== "disqualified";
  const showSelectCol = mode === "disqualified" || mode === "bookings";
  const showAppointmentCol = mode === "bookings";
  // Photo, Name, Position, Email, Resume, [Appointment?], [Status?], [DisqAt?], BookedBy, Actions, [Select?]
  

  const allSelected = showSelectCol && filtered.length > 0 && filtered.every((r) => selectedIds.has(r.response.id));
  const toggleSelectAll = () => {
    if (allSelected) setSelectedIds(new Set());
    else setSelectedIds(new Set(filtered.map((r) => r.response.id)));
  };
  const toggleOne = (id: string) => {
    setSelectedIds((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id); else next.add(id);
      return next;
    });
  };

  // VIEW-ONLY: removes the candidate from the Disqualified view only.
  // Flags removed_from_disqualified_view; the responses/Results record survives.
  // (The ONLY true destroy is purge-candidate-completely on the Results page.)
  const deleteOne = async (id: string): Promise<boolean> => {
    const { error } = await supabase
      .from("responses")
      .update({ removed_from_disqualified_view: true })
      .eq("id", id);
    return !error;
  };

  const runBulkDelete = async (ids: string[]) => {
    setDeleting(true);
    const snapshot = responses;
    // Optimistic remove
    setResponses((prev) => prev.filter((r) => !ids.includes(r.id)));
    setSelectedIds(new Set());
    let ok = 0, fail = 0;
    for (const id of ids) {
      const success = await deleteOne(id);
      if (success) ok++; else fail++;
    }
    setDeleting(false);
    if (fail === 0) {
      toast.success(`Removed ${ok} candidate${ok === 1 ? "" : "s"} from this view`);
    } else {
      toast.error(`Deleted ${ok}, ${fail} failed — restoring failed rows`);
      // Restore failed rows by reloading
      load();
      // ensure snapshot var is referenced to satisfy linter
      void snapshot;
    }
  };

  // Bookings: bulk "Delete Appointment" — marks appointment_cancelled=true via
  // release-slot (same as the single Delete), moving rows to the Deleted tab.
  // Does NOT permanently delete; candidate records are preserved.
  const runBulkCancel = async (ids: string[]) => {
    setDeleting(true);
    const snapshot = responses;
    // Optimistic: flag cancelled so rows shift to the Deleted Appointments tab.
    setResponses((prev) =>
      prev.map((r) =>
        ids.includes(r.id)
          ? { ...r, scheduled_slot_id: null, appointment_cancelled: true }
          : r
      )
    );
    setSelectedIds(new Set());
    let ok = 0, fail = 0;
    for (const id of ids) {
      const src = snapshot.find((r) => r.id === id);
      const body: Record<string, unknown> = { reason: "admin_cancel_appointment", response_id: id };
      if (src?.scheduled_slot_id) body.slot_id = src.scheduled_slot_id;
      const { data, error } = await supabase.functions.invoke("release-slot", { body });
      const errMsg = (data as any)?.error || error?.message;
      if (!errMsg) ok++; else fail++;
    }
    setDeleting(false);
    if (fail === 0) {
      toast.success(`Moved ${ok} to Deleted Appointments`);
    } else {
      toast.error(`Deleted ${ok}, ${fail} failed — refreshing`);
      load();
      void snapshot;
    }
  };

  // VIEW-MOVE only: "Permanently Delete" in the Deleted Appointments tab moves a
  // row OUT of My Bookings and INTO the Quarantine "Deleted Appointments" tab by
  // setting appointment_permanently_deleted=true (single-row by id). This NEVER
  // destroys the responses/answers record — the Results record survives. The only
  // true destroy is purge-candidate-completely on the Results page.
  const runPermanentDelete = async (ids: string[]) => {
    if (!ids.length) return;
    setDeleting(true);
    const snapshot = responses;
    // Optimistic: drop the rows from the Deleted Appointments tab immediately.
    setResponses((prev) => prev.filter((r) => !ids.includes(r.id)));
    setSelectedIds(new Set());
    let ok = 0, fail = 0;
    for (const id of ids) {
      const { error } = await supabase
        .from("responses")
        .update({ appointment_permanently_deleted: true, quarantine_moved_at: new Date().toISOString() })
        .eq("id", id);
      if (error) fail++; else ok++;
    }
    setDeleting(false);
    if (fail === 0) {
      toast.success(`Moved ${ok} to Quarantine → Deleted Appointments`);
    } else {
      toast.error(`Moved ${ok}, ${fail} failed — refreshing`);
      load();
      void snapshot;
    }
  };

  // Switching to AI Direct flips immediately (no password). Switching to
  // AI Scheduled opens the password prompt — only "2828" confirms the flip.
  const requestInterviewModeChange = async (newMode: "ai_direct" | "ai_scheduled") => {
    if (newMode === interviewMode) return;
    if (newMode === "ai_direct") {
      // No gate for AI Direct — run the scheduling_config update immediately.
      const { data, error } = await supabase
        .from("scheduling_config")
        .update({ interview_mode: "ai_direct" })
        .eq("id", 1)
        .select("interview_mode")
        .maybeSingle();
      if (error || !data) {
        toast.error("Could not change interview mode.");
        return;
      }
      const confirmed = (data as any)?.interview_mode === "ai_scheduled" ? "ai_scheduled" : "ai_direct";
      setInterviewMode(confirmed);
      toast.success(`Interview mode: ${confirmed === "ai_direct" ? "AI Direct" : "AI Scheduled"}`);
      return;
    }
    // AI Scheduled stays password-gated.
    setPendingMode(newMode);
    setModePwValue("");
    setModePwOpen(true);
  };

  // The actual flip — only reached after the correct password is entered.
  const confirmInterviewModeChange = async () => {
    if (modePwValue !== "2828") {
      toast.error("Incorrect password");
      setModePwValue("");
      return;
    }
    const newMode = pendingMode;
    if (!newMode) return;
    setModePwOpen(false);
    setModePwValue("");
    setPendingMode(null);
    // GLITCH 7 fix: confirm the DB write FIRST, then update local state from the
    // confirmed DB value. Prevents the pill ever showing a value the DB doesn't have.
    const { data, error } = await supabase
      .from("scheduling_config")
      .update({ interview_mode: newMode })
      .eq("id", 1)
      .select("interview_mode")
      .maybeSingle();
    if (error || !data) {
      toast.error("Could not change interview mode.");
      return;
    }
    const confirmed = (data as any)?.interview_mode === "ai_scheduled" ? "ai_scheduled" : "ai_direct";
    setInterviewMode(confirmed);
    toast.success(`Interview mode: ${confirmed === "ai_direct" ? "AI Direct" : "AI Scheduled"}`);
  };

  return (
    <div className="min-h-screen bg-background">
      <header className="bg-background" style={{ borderBottom: "1px solid #e1e4ec" }}>
        <div className="max-w-[1400px] mx-auto px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Button variant="ghost" size="sm" onClick={() => navigate("/dashboard")}>
              <ArrowLeft className="h-4 w-4 mr-1.5" /> Dashboard
            </Button>
            <h1 className="text-lg font-semibold" style={{ color: "#1a2547" }}>{title}</h1>
          </div>
          <div className="flex items-center gap-4">
            {mode === "bookings" && (
              <>
                <UniversalCandidateButtons onCreated={load} />
                <div className="flex items-center gap-3">
                  <span className="text-[11px] uppercase tracking-wide text-muted-foreground hidden sm:inline">
                    Interview Mode
                  </span>
                  <div
                    role="radiogroup"
                    aria-label="Interview Mode"
                    className="inline-flex items-center rounded-full border border-border bg-muted/40 p-0.5 text-xs font-medium"
                  >
                    <button
                      type="button"
                      role="radio"
                      aria-checked={interviewMode === "ai_direct"}
                      onClick={() => requestInterviewModeChange("ai_direct")}
                      className={`px-3 py-1 rounded-full transition-colors ${
                        interviewMode === "ai_direct"
                          ? "text-white shadow-sm"
                          : "text-muted-foreground hover:text-foreground"
                      }`}
                      style={interviewMode === "ai_direct" ? { backgroundColor: "#1a2547" } : undefined}
                    >
                      AI Direct
                    </button>
                    <button
                      type="button"
                      role="radio"
                      aria-checked={interviewMode === "ai_scheduled"}
                      onClick={() => requestInterviewModeChange("ai_scheduled")}
                      className={`px-3 py-1 rounded-full transition-colors ${
                        interviewMode === "ai_scheduled"
                          ? "text-white shadow-sm"
                          : "text-muted-foreground hover:text-foreground"
                      }`}
                      style={interviewMode === "ai_scheduled" ? { backgroundColor: "#b08d57" } : undefined}
                    >
                      AI Scheduled
                    </button>
                  </div>
                </div>
                {/* Password gate for flipping Interview Mode — write only fires on "2828". */}
                <Dialog open={modePwOpen} onOpenChange={(o) => { setModePwOpen(o); if (!o) { setModePwValue(""); setPendingMode(null); } }}>
                  <DialogContent className="max-w-sm">
                    <DialogHeader>
                      <DialogTitle>Password required</DialogTitle>
                      <DialogDescription>
                        Enter the password to switch Interview Mode to{" "}
                        {pendingMode === "ai_scheduled" ? "AI Scheduled" : "AI Direct"}.
                      </DialogDescription>
                    </DialogHeader>
                    <form onSubmit={(e) => { e.preventDefault(); confirmInterviewModeChange(); }} className="space-y-3">
                      <Input
                        type="password"
                        value={modePwValue}
                        onChange={(e) => setModePwValue(e.target.value)}
                        autoFocus
                        placeholder="Password"
                      />
                      <DialogFooter>
                        <Button type="button" variant="outline" onClick={() => { setModePwOpen(false); setModePwValue(""); setPendingMode(null); }}>Cancel</Button>
                        <Button type="submit" disabled={!modePwValue}>Confirm</Button>
                      </DialogFooter>
                    </form>
                  </DialogContent>
                </Dialog>
                <Button
                  size="sm"
                  onClick={() => window.open(SHARED_PMR_URL, "_blank", "noopener,noreferrer")}
                  className="bg-emerald-600 hover:bg-emerald-700 text-white"
                  title="Open the shared Zoom meeting room"
                >
                  <Video className="h-4 w-4 mr-1.5" /> Visit Meeting Room
                </Button>
                <Button
                  size="sm"
                  onClick={() => navigate("/dashboard/ai-interviews")}
                  className="px-5 bg-gradient-to-r from-pink-500 to-rose-500 hover:from-pink-600 hover:to-rose-600 text-white shadow-sm hover:shadow-md transition-all font-medium"
                  title="Open the AI Interviews Scout Reports"
                >
                  <Video className="h-4 w-4 mr-1.5" /> AI Interviews
                </Button>
                {selectedIds.size > 0 && bookingFilter === "cancelled" && (
                  <Button
                    size="sm"
                    variant="destructive"
                    disabled={deleting}
                    onClick={() => { setPermDeleteInput(""); setPermDeleteSelectedOpen(true); }}
                  >
                    <Trash2 className="h-4 w-4 mr-1.5" /> Permanently Delete Selected ({selectedIds.size})
                  </Button>
                )}
                {selectedIds.size > 0 && bookingFilter !== "cancelled" && (
                  <Button
                    size="sm"
                    variant="outline"
                    disabled={deleting}
                    onClick={() => setCancelSelectedOpen(true)}
                  >
                    <Trash2 className="h-4 w-4 mr-1.5" /> Delete Selected ({selectedIds.size})
                  </Button>
                )}
              </>
            )}
            {mode === "disqualified" && (
              <>
                <Button
                  size="sm"
                  variant="outline"
                  disabled={selectedIds.size === 0 || deleting}
                  onClick={() => setDeleteSelectedOpen(true)}
                >
                  <Trash2 className="h-4 w-4 mr-1.5" /> Delete Selected ({selectedIds.size})
                </Button>
                <Button
                  size="sm"
                  variant="destructive"
                  disabled={responses.length === 0 || deleting}
                  onClick={() => { setTrashAllInput(""); setTrashAllOpen(true); }}
                >
                  <Trash2 className="h-4 w-4 mr-1.5" /> Trash All
                </Button>
              </>
            )}
            <span className="text-xs text-muted-foreground">
              {loading ? "Loading…" : `${filtered.length} candidate${filtered.length === 1 ? "" : "s"}`}
            </span>
          </div>
        </div>
      </header>

      <main className="max-w-[1400px] mx-auto px-6 py-8">
        <div className="flex flex-wrap items-center gap-2 mb-6">
          <Button
            size="sm"
            variant={filter === "all" ? "default" : "outline"}
            onClick={() => setFilter("all")}
          >
            Show All {noun}
          </Button>
          {hrUsers.map((hr) => (
            <Button
              key={hr.id}
              size="sm"
              variant={filter === hr.id ? "default" : "outline"}
              onClick={() => setFilter(hr.id)}
            >
              Show {hr.display_name}
              {hr.nickname ? ` (${displayHrNickname(hr.nickname)})` : ""} {noun}
            </Button>
          ))}
        </div>

        <div className="flex flex-wrap items-center gap-3 mb-4">
          <div className="flex items-center gap-2">
            <span className="text-xs font-medium text-muted-foreground uppercase tracking-wide">Form:</span>
            <Select value={formFilter} onValueChange={(v) => setFormFilter(v)}>
              <SelectTrigger className="h-9 w-[260px]">
                <SelectValue placeholder="All forms" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All forms</SelectItem>
                {formOptions.map((f) => (
                  <SelectItem key={f.id} value={f.id}>{f.label}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="relative w-full sm:w-[300px]">
            <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground pointer-events-none" />
            <Input
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search by name or email…"
              className="h-9 pl-8 pr-8"
            />
            {search && (
              <button
                type="button"
                onClick={() => setSearch("")}
                className="absolute right-2 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
                aria-label="Clear search"
              >
                <X className="h-4 w-4" />
              </button>
            )}
          </div>
          <div className="text-xs text-muted-foreground inline-flex items-center gap-1">
            <Info className="h-3.5 w-3.5" /> All times shown in Philippine Standard Time (PHT)
          </div>
        </div>

        {mode === "bookings" && (
          <div className="flex flex-wrap items-center gap-2 mb-4">
            {([
              { key: "all", label: `Current Appointments (${bookingCounts.all})` },
              { key: "cancelled", label: `Deleted Appointments (${bookingCounts.cancelled})` },
              { key: "shortlisted", label: `Future Waiting List (${bookingCounts.shortlisted})` },
            ] as const).map((b) => (
              <Button
                key={b.key}
                size="sm"
                variant={bookingFilter === b.key ? "default" : "outline"}
                onClick={() => setBookingFilter(b.key)}
              >
                {b.label}
              </Button>
            ))}
            <Button
              size="sm"
              variant={showAllApplicants ? "default" : "outline"}
              onClick={() => setShowAllApplicants((v) => !v)}
            >
              {showAllApplicants
                ? `Showing All Applicants (${extraNullStageCount})`
                : "Show All Applicants"}
            </Button>
          </div>
        )}

        <div className="flex flex-col gap-3">
          {showSelectCol && !loading && filtered.length > 0 && (
            <div className="flex items-center gap-2 px-1">
              <Checkbox
                checked={allSelected}
                onCheckedChange={toggleSelectAll}
                aria-label="Select all"
              />
              <span className="text-sm text-muted-foreground">Select all</span>
            </div>
          )}
          {loading ? (
            Array.from({ length: 5 }).map((_, i) => (
              <div key={i} className="border border-border rounded-lg p-4 bg-card flex items-start gap-4">
                <Skeleton className="h-[120px] w-[120px] rounded-lg shrink-0" />
                <div className="flex-1 space-y-2">
                  <Skeleton className="h-6 w-1/3" />
                  <Skeleton className="h-4 w-2/3" />
                  <Skeleton className="h-9 w-full" />
                </div>
              </div>
            ))
          ) : filtered.length === 0 ? (
            <div className="border border-border rounded-lg bg-card text-center py-12 text-sm text-muted-foreground">
              {search.trim() ? `No candidates match "${search.trim()}".` : "No candidates yet."}
            </div>
          ) : (
            filtered.map((row) => {
              const stage = row.effectiveStage || "";
              const resumeName = row.resumeUrl ? parseFilePath(row.resumeUrl).name : "";
              return (
                <div
                  key={row.response.id}
                  data-response-id={row.response.id}
                  className={`border border-border rounded-lg p-4 bg-card flex items-start gap-4${highlightId === row.response.id ? " locate-flash" : ""}`}
                >
                  {showSelectCol && (
                    <div className="pt-1 shrink-0">
                      <Checkbox
                        checked={selectedIds.has(row.response.id)}
                        onCheckedChange={() => toggleOne(row.response.id)}
                        aria-label="Select row"
                      />
                    </div>
                  )}
                  {/* LEFT: photo + position + view details */}
                  <div className="flex flex-col items-center gap-2 w-[140px] shrink-0">
                    {row.selfieUrl ? (
                      <SelfieThumb
                        file_url={row.selfieUrl}
                        size={120}
                        onPreview={() => setPreviewFile(row.selfieUrl!)}
                      />
                    ) : (
                      <div className="h-[120px] w-[120px] rounded-lg bg-secondary border border-border flex items-center justify-center text-muted-foreground">
                        <UserIcon className="h-9 w-9" />
                      </div>
                    )}
                    {row.positionTitle || row.formTitle ? (
                      <Badge variant="outline" className="font-normal text-[10px] leading-tight px-1.5 py-0.5 max-w-[140px] text-center whitespace-normal break-words">
                        {row.positionTitle || row.formTitle}
                      </Badge>
                    ) : (
                      <span className="text-[10px] text-muted-foreground italic">No position</span>
                    )}
                    <Button
                      type="button"
                      variant="ghost"
                      size="sm"
                      className="h-6 px-1.5 text-[11px] text-primary hover:text-primary"
                      onClick={() => setDetailsRowId(row.response.id)}
                    >
                      <Eye className="h-3 w-3 mr-1" /> View Full Details
                    </Button>
                  </div>
                  {/* RIGHT: name + badges + meta + actions */}
                  <div className="flex-1 min-w-0 flex flex-col gap-2">
                    {/* Row 1: name + status/tier badges */}
                    <div className="flex flex-wrap items-center gap-2">
                      <span className="font-medium">
                        {row.name || <span className="text-muted-foreground italic">No name</span>}
                      </span>
                      {mode === "bookings" && (
                        <AiTierBadge tier={resolveTier(row.response.id, row.email)} />
                      )}
                      {mode === "bookings" && (
                        <HrBadgePill value={resolveBadge(row.response.id, row.email)} />
                      )}
                      {/* Uniform Scout shortcut: shown on EVERY booking row whose
                          response_id has ≥1 interview session (resolveScout, keyed off
                          the global session-existence set — own session or same-email
                          borrow), independent of round_stage / video / attendance /
                          appointment. Completed candidates also keep the pink "R1 done"
                          status button below; this guarantees a clearly-labeled Scout
                          link on every interviewed row. */}
                      {mode === "bookings" && (() => {
                        const scoutId = resolveScout(row.response.id, row.email);
                        if (!scoutId) return null;
                        return (
                          <Button
                            type="button"
                            size="sm"
                            variant="outline"
                            className="h-7 px-2 rounded-full text-[11px] font-semibold border-pink-300 text-pink-700 hover:bg-pink-50"
                            title="Locate this candidate in Scout Report"
                            onClick={(e) => { e.stopPropagation(); navigate('/dashboard/ai-interviews?locate=' + scoutId); }}
                          >
                            <Target className="h-3.5 w-3.5 mr-1" /> Locate in Scout
                          </Button>
                        );
                      })()}
                      {/* R1 status indicator on rows with NO interview session at all:
                          muted "NOT DONE R1 YET" pill (no link). Keyed off the same
                          session-existence check, so it never collides with the Scout
                          link above. */}
                      {mode === "bookings" &&
                        resolveScout(row.response.id, row.email) === "" && (
                          <span
                            className="inline-flex items-center h-7 px-2.5 rounded-full text-[11px] font-semibold bg-muted text-muted-foreground border border-border"
                            title="No completed AI interview (Round 1) yet"
                          >
                            NOT DONE R1 YET
                          </span>
                        )}
                      {/* Change 1: "Watch Interview" video shortcut on EVERY row that
                          has a surviving video. InterviewVideoDialog self-resolves the
                          video from the responseId and renders nothing when none exists
                          (hideWhenNoVideo) — no new query here. */}
                      {mode === "bookings" && (() => {
                        const scoutId = resolveScout(row.response.id, row.email);
                        if (!scoutId) return null;
                        // This is a SHORTCUT to the candidate's Round 1 (Christine) interview —
                        // the same R1 interview shown in Scout Report. Always R1, no round logic.
                        return (
                          <InterviewVideoDialog
                            responseId={scoutId}
                            round="R1"
                            buttonLabel="Watch Interview"
                            buttonVariant="outline"
                            buttonSize="sm"
                            buttonClassName="bg-teal-600 text-white border-teal-600 hover:bg-teal-700 hover:text-white"
                            hideWhenNoVideo
                          />
                        );
                      })()}
                      {showStatusCol && (
                        <div className="flex flex-wrap items-center gap-1">
                          {(() => {
                            if (mode === "bookings") {
                              const r = row.response;
                              // ---- Live + completed timing helpers (additive). Live elapsed = now − sent_at. ----
                              const GREEN = "bg-emerald-100 text-emerald-800 hover:bg-emerald-100 border-0";
                              const BLUE = "bg-blue-100 text-blue-800 hover:bg-blue-100 border-0";
                              const AMBER = "bg-amber-100 text-amber-900 hover:bg-amber-100 border-0";
                              const elapsedHrs = (iso: string) =>
                                Math.max(0, Math.floor((nowTick - Date.parse(iso)) / 3_600_000));
                              const doneBadge = (h: number, txt: string) =>
                                <Badge className={Number(h) > 72 ? AMBER : GREEN}>{txt}</Badge>;
                              const liveBadge = (h: number, base: string, notDoneWord: string) =>
                                <Badge className={h > 72 ? AMBER : BLUE}>
                                  {`${base} — ${h}h ago, ${h > 72 ? "still " : ""}${notDoneWord}`}
                                </Badge>;
                              const r1h = r.r1_completed_hours;
                              const r2h = r.r2_completed_hours;
                              const ofh = r.offer_signed_hours;

                              // Offer-stage takes precedence over booking state.
                              if (stage === "offer_signed") {
                                if (ofh != null) return doneBadge(Number(ofh), `Offer signed in ${ofh}h`);
                                return <Badge className="bg-sky-100 text-sky-800 hover:bg-sky-100 border-0">🩵 Offer Signed</Badge>;
                              }
                              if (stage === "offer_sent") {
                                if (r.offer_sent_at) return liveBadge(elapsedHrs(r.offer_sent_at), "Offer sent", "not signed");
                                return <Badge className="bg-blue-100 text-blue-800 hover:bg-blue-100 border-0">Offer Sent</Badge>;
                              }
                              if (stage === "ai_interview_completed") {
                                const scoutId = resolveScout(r.id, row.email) || r.id;
                                const onClickBadge = (e: React.MouseEvent) => { e.stopPropagation(); navigate('/dashboard/ai-interviews/' + scoutId + '/R1'); };
                                const overdue = r1h != null && Number(r1h) > 72;
                                const label = r1h != null ? `R1 done in ${r1h}h` : "Interview Completed";
                                return (
                                  <Button
                                    type="button"
                                    size="sm"
                                    onClick={onClickBadge}
                                    title="Open Scout Report"
                                    className={`rounded-full min-h-[36px] font-semibold text-white shadow-sm transition-colors ${overdue ? "bg-amber-500 hover:bg-amber-600" : "bg-pink-600 hover:bg-pink-700"}`}
                                  >
                                    <Check className="h-3.5 w-3.5 mr-1.5" /> {label}
                                  </Button>
                                );
                              }


                              const cancelled = !!r.appointment_cancelled;
                              const booked = !cancelled && !!r.scheduled_slot_id;
                              const pending = !cancelled && !booked;
                              const apptMs = row.appointmentStart ? new Date(row.appointmentStart).getTime() : null;
                              const expired = booked && apptMs !== null && apptMs < Date.now();
                               if (cancelled) {
                                 return <Badge className="bg-red-100 text-red-800 hover:bg-red-100 border-0">Cancelled</Badge>;
                               }
                               if (expired) {
                                 const act = actionsByResponse[r.id];
                                 const attField = stage === "round_2_sent" ? "round2_attendance_status" : "round1_attendance_status";
                                 const att = (act as any)?.[attField];
                                 if (att === "attended") {
                                   return <Badge className="bg-emerald-100 text-emerald-800 hover:bg-emerald-100 border-0">{stage === "round_2_sent" ? "R2 Done · Ready for Offer" : "R1 Done · Ready for R2"}</Badge>;
                                 }
                                 if (att === "no_show") {
                                   return <Badge className="bg-amber-100 text-amber-900 hover:bg-amber-100 border-0">No-Show</Badge>;
                                 }
                                 return <Badge className="bg-slate-200 text-slate-700 hover:bg-slate-200 border-0">Expired</Badge>;
                               }
                               const round1LinkExpired =
                                 pending &&
                                 stage === "round_1_sent" &&
                                 !!r.round_1_sent_at &&
                                 (Date.now() - Date.parse(r.round_1_sent_at)) > 3 * 24 * 60 * 60 * 1000;
                               if (round1LinkExpired) {
                                 return <Badge className="bg-slate-200 text-slate-700 hover:bg-slate-200 border-0">Round 1 link expired</Badge>;
                               }
                               // ---- Completed timing (newest step first): persists the recorded hours-to-complete. ----
                               if (r2h != null) return doneBadge(Number(r2h), `R2 done in ${r2h}h`);
                               if (r1h != null && stage !== "round_2_sent") return doneBadge(Number(r1h), `R1 done in ${r1h}h`);
                               // ---- Existing booked states preserved ----
                               if (booked) {
                                if (stage === "round_2_sent") {
                                  return <Badge className="bg-indigo-100 text-indigo-800 hover:bg-indigo-100 border-0">Round 2 Booked</Badge>;
                                }
                                return <Badge className="bg-emerald-100 text-emerald-800 hover:bg-emerald-100 border-0">Booked</Badge>;
                              }
                               // ---- LIVE elapsed for the current active (sent, not completed) step → replaces plain Pending ----
                               if (stage === "round_2_sent" && r.round_2_sent_at) {
                                 return liveBadge(elapsedHrs(r.round_2_sent_at), "Round 2 sent", "not completed");
                               }
                               if (stage === "round_1_sent" && r.round_1_sent_at) {
                                 return liveBadge(elapsedHrs(r.round_1_sent_at), "Round 1 sent", "not completed");
                               }
                              if (pending) {
                                return <Badge className="bg-yellow-100 text-yellow-900 hover:bg-yellow-100 border-0">Pending</Badge>;
                              }
                            }
                            return (
                              <Badge className={`${STATUS_COLOR[stage] || "bg-slate-100 text-slate-800"} hover:${STATUS_COLOR[stage] || "bg-slate-100"} border-0`}>
                                {labelMap[stage] || stage}
                              </Badge>
                            );
                          })()}
                          {/* Display-only: Zoom pill beside the Booked badge for Universal Zoom bookings. */}
                          {mode === "bookings" && row.isUniversalZoom && (
                            <Badge className="bg-blue-100 text-blue-800 hover:bg-blue-100 border-0 rounded-full">Zoom</Badge>
                          )}
                          {/* Additive: amber chip when a pending scheduled send exists for this response. */}
                          <ScheduledSendChip responseId={row.response.id} />
                        </div>
                      )}
                    </div>
                    {/* HR note (read-only here; editable only in Scout Report) */}
                    {(() => {
                      const nick = resolveNickname(row.response.id, row.email);
                      return nick ? <HrNicknameField value={nick} /> : null;
                    })()}
                    {/* Row 2: meta line (email, resume, appointment, bookedBy, disqualified-at) */}
                    <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-sm text-muted-foreground">
                      <EmailInlineEditor
                        responseId={row.response.id}
                        email={row.email}
                        onSaved={(newEmail) =>
                          setResponses((prev) =>
                            prev.map((x) => x.id === row.response.id ? { ...x, override_email: newEmail } : x)
                          )
                        }
                        onRevert={(prevEmail) =>
                          setResponses((prev) =>
                            prev.map((x) => x.id === row.response.id ? { ...x, override_email: prevEmail || null } : x)
                          )
                        }
                      />
                      {row.resumeUrl ? (
                        <button
                          type="button"
                          onClick={() => setPreviewFile(row.resumeUrl!)}
                          className="inline-flex items-center gap-1.5 text-sm text-primary hover:underline max-w-[180px]"
                          title={resumeName}
                        >
                          <FileText className="h-4 w-4 shrink-0" />
                          <span className="truncate">View Resume</span>
                        </button>
                      ) : (
                        <span className="text-xs text-muted-foreground">No resume</span>
                      )}
                      {showAppointmentCol && (
                        <AppointmentCountdown startIso={row.appointmentStart} />
                      )}
                      <span>{mode === "disqualified" ? "Disqualified by" : "Booked by"}: {row.bookedBy}</span>
                      {showDisqualifiedAtCol && (
                        <span className="inline-flex flex-col">
                          <span>
                            {row.response.disqualified_at
                              ? new Date(row.response.disqualified_at).toLocaleDateString("en-US", { timeZone: "Asia/Manila", month: "short", day: "numeric", year: "numeric" })
                              : "—"}
                          </span>
                          {row.response.disqualified_at_stage && (
                            <span className="text-[11px] text-muted-foreground mt-0.5">
                              at: <span className="font-medium text-foreground/80">{row.response.disqualified_at_stage}</span>
                            </span>
                          )}
                          {row.response.removal_reason && (
                            <span className="text-[11px] text-muted-foreground mt-0.5 max-w-[260px] whitespace-pre-wrap">
                              reason: <span className="text-foreground/80">{row.response.removal_reason}</span>
                            </span>
                          )}
                        </span>
                      )}
                    </div>
                    {/* Row 3: full action button cluster */}
                    <div className="flex flex-row flex-wrap items-center gap-2 [&_button]:min-h-[36px]">
                      {mode === "disqualified" ? (
                        <>
                          <Button
                            type="button"
                            variant="outline"
                            size="sm"
                            onClick={() => setRestoring(row.response)}
                          >
                            <RotateCcw className="h-3.5 w-3.5 mr-1.5" /> Restore
                          </Button>
                          <WatchInterviewVideoButton responseId={row.response.id} />
                        </>
                      ) : mode === "bookings" && bookingFilter === "shortlisted" ? (
                        <>
                          {/* Future Waiting List: the ONLY action is Resume to My Bookings.
                              All other send/action buttons are hidden here. Row info,
                              status text, badges, and View Full Details remain visible. */}
                          <Button
                            type="button"
                            variant="outline"
                            size="sm"
                            className="min-h-[36px]"
                            title="Move this candidate back to Current Appointments with their original status untouched"
                            onClick={async () => {
                              const id = row.response.id;
                              setResponses((prev) => prev.map((r) => (r.id === id ? { ...r, future_shortlisted: false } : r)));
                              const { error } = await (supabase.from("responses") as any)
                                .update({ future_shortlisted: false })
                                .eq("id", id);
                              if (error) {
                                setResponses((prev) => prev.map((r) => (r.id === id ? { ...r, future_shortlisted: true } : r)));
                                toast.error("Could not resume — reverted");
                              } else {
                                toast.success(`${row.name || "Candidate"} resumed to My Bookings`);
                              }
                            }}
                          >
                            <BookmarkX className="h-3.5 w-3.5 mr-1.5" /> Resume to My Bookings
                          </Button>
                        </>
                      ) : (
                        <>
                          {mode === "completed" && (
                            <Button
                              type="button"
                              variant="outline"
                              size="sm"
                              onClick={() => setViewOfferTarget({ candidateId: row.response.applicant_id, responseId: row.response.id })}
                            >
                              <Eye className="h-3.5 w-3.5 mr-1.5" /> View Offer
                            </Button>
                          )}
                          {mode === "bookings" && row.response.appointment_cancelled ? (
                            <>
                              <ActionsCell
                                formId={row.response.form_id}
                                responseId={row.response.id}
                                applicantId={row.response.applicant_id}
                                candidateName={row.name}
                                candidateEmail={row.email}
                                nameQid={formQMaps[row.response.form_id]?.nameQid}
                                emailQid={formQMaps[row.response.form_id]?.emailQid}
                                action={actionsByResponse[row.response.id] || null}
                                size="sm"
                                context="bookings"
                                cancelledOnly
                                onRound1Sent={() => {
                                  setResponses((prev) =>
                                    prev.map((r) =>
                                      r.id === row.response.id
                                        ? { ...r, appointment_cancelled: false, scheduled_slot_id: null, round_stage: "round_1_sent" }
                                        : r
                                    )
                                  );
                                }}
                                onChanged={(a) =>
                                  setActionsByResponse((prev) => ({ ...prev, [row.response.id]: a }))
                                }
                                onContactUpdated={(vals) => {
                                  if (vals.email !== undefined) {
                                    setResponses((prev) =>
                                      prev.map((x) =>
                                        x.id === row.response.id
                                          ? { ...x, override_email: vals.email || x.override_email }
                                          : x
                                      )
                                    );
                                  }
                                }}
                                onCandidateRemoved={() => {
                                  disqSnapshotRef.current = responses;
                                  setResponses((prev) => prev.filter((r) => r.id !== row.response.id));
                                }}
                                onCandidateRestored={() => {
                                  if (disqSnapshotRef.current) setResponses(disqSnapshotRef.current);
                                  disqSnapshotRef.current = null;
                                }}
                              />
                              {/* VIEW-MOVE only: flags the row into Quarantine → Deleted
                                  Appointments. Does NOT destroy the record. */}
                              <Button
                                type="button"
                                variant="destructive"
                                size="sm"
                                disabled={deleting}
                                onClick={() => setPermDeleteRow({ id: row.response.id, name: row.name || "this candidate" })}
                                title="Move to Quarantine → Deleted Appointments (record is kept)"
                              >
                                <Trash2 className="h-3.5 w-3.5 mr-1.5" /> Permanently Delete
                              </Button>
                            </>
                          ) : mode === "bookings" && (row.response.round_stage === "offer_sent" || row.response.round_stage === "offer_signed" || row.response.round_stage === "offer_expired") ? (
                            <>
                              <Button
                                type="button"
                                variant="outline"
                                size="sm"
                                onClick={() => setViewOfferTarget({ candidateId: row.response.applicant_id, responseId: row.response.id })}
                              >
                                <Eye className="h-3.5 w-3.5 mr-1.5" /> View Offer
                              </Button>
                              {row.response.round_stage === "offer_sent" && (
                                <FollowUpOfferButton responseId={row.response.id} candidateName={row.name} />
                              )}
                              {row.response.round_stage === "offer_signed" && (
                                <MatchedOutcomeButtons
                                  responseId={row.response.id}
                                  candidateName={row.name}
                                  onOptimisticRemove={() => {
                                    disqSnapshotRef.current = responses;
                                    setResponses((prev) => prev.filter((r) => r.id !== row.response.id));
                                  }}
                                  onRevert={() => {
                                    if (disqSnapshotRef.current) setResponses(disqSnapshotRef.current);
                                    disqSnapshotRef.current = null;
                                  }}
                                />
                              )}
                              <DisqualifyButton
                                responseId={row.response.id}
                                candidateName={row.name}
                                onOptimisticRemove={() => {
                                  disqSnapshotRef.current = responses;
                                  setResponses((prev) => prev.filter((r) => r.id !== row.response.id));
                                }}
                                onRevert={() => {
                                  if (disqSnapshotRef.current) setResponses(disqSnapshotRef.current);
                                  disqSnapshotRef.current = null;
                                }}
                              />
                            </>
                          ) : null}
                          {/* Duplicate top "Send Round 2" removed (UI only). The working
                              Send Round 2 button still renders below Round 1 attendance. */}



                          {mode === "bookings" && !row.response.appointment_cancelled && row.response.scheduled_slot_id &&
                            row.response.round_stage !== "offer_sent" &&
                            row.response.round_stage !== "offer_signed" && (
                            <>
                              {row.joinUrl && (
                                <Button
                                  type="button"
                                  size="sm"
                                  onClick={() => window.open(row.joinUrl!, "_blank", "noopener,noreferrer")}
                                  title="Join the Zoom interview now"
                                  className="bg-emerald-600 hover:bg-emerald-700 text-white"
                                >
                                  <Video className="h-3.5 w-3.5 mr-1.5" /> Attend
                                </Button>
                              )}
                              <RescheduleButton
                                slotId={row.response.scheduled_slot_id}
                                responseId={row.response.id}
                                candidateName={row.name}
                                candidateEmail={row.email}
                                onDone={() => {
                                  setResponses((prev) =>
                                    prev.map((r) =>
                                      r.id === row.response.id
                                         ? { ...r, scheduled_slot_id: null, appointment_cancelled: true }
                                        : r
                                    )
                                  );
                                }}
                              />
                              {/* Additive: re-send the DIRECT Christine AI Round 1 invite
                                  on a booked row. Opens InviteRoundDialog with force_direct
                                  so it sends the /ai-interview link regardless of global mode. */}
                              <Button
                                type="button"
                                size="sm"
                                variant="outline"
                                className="border-pink-300 text-pink-700 hover:bg-pink-50"
                                title="Send the direct Christine AI Round 1 interview link"
                                onClick={() =>
                                  setAiR1Target({
                                    responseId: row.response.id,
                                    name: row.name,
                                    email: row.email,
                                    slotId: row.response.scheduled_slot_id || null,
                                  })
                                }
                              >
                                <Sparkles className="h-3.5 w-3.5 mr-1.5" /> Send Round 1 (AI)
                              </Button>
                              {row.joinUrl && (
                                <RegenerateZoomButton
                                  slotId={row.response.scheduled_slot_id}
                                  candidateName={row.name}
                                />
                              )}
                              <CancelAppointmentButton
                                slotId={row.response.scheduled_slot_id}
                                responseId={row.response.id}
                                candidateName={row.name}
                                onCancelled={() => {
                                  setResponses((prev) =>
                                    prev.map((r) =>
                                      r.id === row.response.id
                                        ? { ...r, scheduled_slot_id: null, appointment_cancelled: true }
                                        : r
                                    )
                                  );
                                }}
                              />
                              {/* Attendance + advancement for booked rows.
                                  Round 1 attendance → Send Round 2.
                                  Round 2 attendance → Send Offer. */}
                              {(() => {
                                 const act = actionsByResponse[row.response.id] || null;
                                 const round2Sent = row.response.round_stage === "round_2_sent";
                                 const round = round2Sent ? 2 : 1;
                                 // Email-level R1 completion: enable Send Round 2 if THIS row
                                 // OR any same-email row of this person completed Round 1.
                                 const personR1Completed = !!emailR1Completed[(row.email || "").trim().toLowerCase()];
                                return (
                                  <>
                                    {/* AI-flow isolation: attendance marking depends ONLY on the
                                        candidate having reached this round — NEVER on whether a
                                        booked Zoom slot time has elapsed. AI candidates with no
                                        real slot must always be markable. */}
                                    <MarkAttendanceButton
                                      action={act}
                                      round={round}
                                      appointmentPassed={true}
                                      onChanged={(a) =>
                                        setActionsByResponse((prev) => ({ ...prev, [row.response.id]: a }))
                                      }
                                    />
                                    {/* Send Round 2 unlocks on Round 1 ATTENDANCE
                                        (manual or auto from an AI completion), NOT on
                                        whether the booked slot time has passed. An AI
                                        candidate who completed Christine is "attended"
                                        even if their slot time hasn't arrived. The
                                        button itself gates on attended + keeps the
                                        Boss-password override for the not-attended case,
                                        mirroring the no-slot ActionsCell.Round2Btn. */}
                                    {/* Always render Send Round 2 (no round2Sent wrapper):
                                        appears for everyone — including R2 no-shows and
                                        already-sent-R2 candidates — so HR can re-send.
                                        Enable/greyed gates ONLY on R1 completion. */}
                                    <SendRound2Button
                                      responseId={row.response.id}
                                      candidateName={row.name}
                                      candidateEmail={row.email}
                                      action={act}
                                      r1Completed={personR1Completed}
                                      onChanged={(a) => {
                                        setActionsByResponse((prev) => ({ ...prev, [row.response.id]: a }));
                                        setResponses((prev) =>
                                          prev.map((r) =>
                                            r.id === row.response.id ? { ...r, round_stage: "round_2_sent" } : r
                                          )
                                        );
                                      }}
                                    />

                                    {/* Always render Send Offer (no round2Sent wrapper) — gray-locked until R2 attended, Boss2828 override */}
                                    <SendOfferButton
                                      formId={row.response.form_id}
                                      responseId={row.response.id}
                                      candidateName={row.name}
                                      candidateEmail={row.email}
                                      nameQid={formQMaps[row.response.form_id]?.nameQid}
                                      emailQid={formQMaps[row.response.form_id]?.emailQid}
                                      action={act}
                                      onChanged={(a) => {
                                        setActionsByResponse((prev) => ({ ...prev, [row.response.id]: a }));
                                        setResponses((prev) =>
                                          prev.map((r) =>
                                            r.id === row.response.id ? { ...r, round_stage: "offer_sent", offer_sent_at: a.offer_sent_at || new Date().toISOString() } : r
                                          )
                                        );
                                      }}
                                    />
                                  </>
                                );
                              })()}

                            </>
                          )}
                          {mode === "bookings" && !row.response.appointment_cancelled && !row.response.scheduled_slot_id &&
                            row.response.round_stage !== "offer_sent" &&
                            row.response.round_stage !== "offer_signed" && (
                            <ActionsCell
                              formId={row.response.form_id}
                              responseId={row.response.id}
                              applicantId={row.response.applicant_id}
                              candidateName={row.name}
                              candidateEmail={row.email}
                              nameQid={formQMaps[row.response.form_id]?.nameQid}
                              emailQid={formQMaps[row.response.form_id]?.emailQid}
                              action={actionsByResponse[row.response.id] || null}
                              size="sm"
                              context="bookings"
                              onChanged={(a) =>
                                setActionsByResponse((prev) => ({ ...prev, [row.response.id]: a }))
                              }
                              onContactUpdated={(vals) => {
                                if (vals.email !== undefined) {
                                  setResponses((prev) =>
                                    prev.map((x) =>
                                      x.id === row.response.id
                                        ? { ...x, override_email: vals.email || x.override_email }
                                        : x
                                    )
                                  );
                                }
                              }}
                              onCandidateRemoved={() => {
                                disqSnapshotRef.current = responses;
                                setResponses((prev) => prev.filter((r) => r.id !== row.response.id));
                              }}
                              onCandidateRestored={() => {
                                if (disqSnapshotRef.current) setResponses(disqSnapshotRef.current);
                                disqSnapshotRef.current = null;
                              }}
                            />
                          )}
                          {/* Delete Appointment restored for no-slot active rows.
                              Marks appointment_cancelled=true via release-slot →
                              row moves to the Deleted Appointments tab. Separate
                              from Disqualify. */}
                          {mode === "bookings" && !row.response.appointment_cancelled && !row.response.scheduled_slot_id &&
                            row.response.round_stage !== "offer_sent" &&
                            row.response.round_stage !== "offer_signed" && (
                            <CancelAppointmentButton
                              responseId={row.response.id}
                              candidateName={row.name}
                              onCancelled={() => {
                                setResponses((prev) =>
                                  prev.map((r) =>
                                    r.id === row.response.id
                                      ? { ...r, scheduled_slot_id: null, appointment_cancelled: true }
                                      : r
                                  )
                                );
                              }}
                            />
                          )}
                          {/* GLITCH 6 fix: Delete Appointment for booked rows renders
                              in the slot block above (L1100). */}
                          {mode !== "bookings" && (
                            <DisqualifyButton
                              responseId={row.response.id}
                              candidateName={row.name}
                              onOptimisticRemove={() => {
                                disqSnapshotRef.current = responses;
                                setResponses((prev) => prev.filter((r) => r.id !== row.response.id));
                              }}
                              onRevert={() => {
                                if (disqSnapshotRef.current) setResponses(disqSnapshotRef.current);
                                disqSnapshotRef.current = null;
                              }}
                            />
                          )}
                          {mode === "bookings" && row.response.scheduled_slot_id &&
                            row.response.round_stage !== "offer_sent" &&
                            row.response.round_stage !== "offer_signed" && (
                            <DisqualifyButton
                              responseId={row.response.id}
                              candidateName={row.name}
                              onOptimisticRemove={() => {
                                disqSnapshotRef.current = responses;
                                setResponses((prev) => prev.filter((r) => r.id !== row.response.id));
                              }}
                              onRevert={() => {
                                if (disqSnapshotRef.current) setResponses(disqSnapshotRef.current);
                                disqSnapshotRef.current = null;
                              }}
                            />
                          )}
                          {mode === "bookings" && (() => {
                            const zoomCount = actionsByResponse[row.response.id]?.zoom_send_count ?? 0;
                            const zoomTone =
                              zoomCount >= 5 ? "bg-red-600 hover:bg-red-700 text-white"
                              : zoomCount >= 3 ? "bg-orange-500 hover:bg-orange-600 text-white"
                              : zoomCount >= 1 ? "bg-amber-400 hover:bg-amber-500 text-amber-950"
                              : "bg-blue-600 hover:bg-blue-700 text-white";
                            return (
                              <Button
                                type="button"
                                size="sm"
                                className={`min-h-[36px] ${zoomTone}`}
                                onClick={() => setZoomTarget({ responseId: row.response.id, name: row.name || "", email: row.email || "" })}
                                title="Send a Universal Zoom booking link to this candidate"
                              >
                                <Video className="h-3.5 w-3.5 mr-1.5" /> Zoom{zoomCount > 0 ? ` +${zoomCount}` : ""}
                              </Button>
                            );
                          })()}
                          {mode === "bookings" && (
                            <Button
                              type="button"
                              variant="outline"
                              size="sm"
                              className="min-h-[36px]"
                              onClick={() => setCustomMsgTarget({ responseId: row.response.id, name: row.name || "", email: row.email || "" })}
                              title="Send a one-off custom message"
                            >
                              <Mail className="h-3.5 w-3.5 mr-1.5" /> Send Custom Message
                            </Button>
                          )}
                          {mode === "bookings" && (
                            <StopRemindersButton responseId={row.response.id} appearance="outline" />
                          )}
                          {mode === "bookings" && bookingFilter !== "shortlisted" && !row.response.appointment_cancelled && (
                            <Button
                              type="button"
                              variant="outline"
                              size="sm"
                              className="min-h-[36px] text-violet-700 border-violet-200 hover:bg-violet-50 hover:text-violet-800"
                              title="Park this candidate in the Future Waiting List (removes them from Current, keeps everything else)"
                              onClick={async () => {
                                const id = row.response.id;
                                setResponses((prev) => prev.map((r) => (r.id === id ? { ...r, future_shortlisted: true } : r)));
                                const { error } = await (supabase.from("responses") as any)
                                  .update({ future_shortlisted: true })
                                  .eq("id", id);
                                if (error) {
                                  setResponses((prev) => prev.map((r) => (r.id === id ? { ...r, future_shortlisted: false } : r)));
                                  toast.error("Could not move — reverted");
                                } else {
                                  toast.success(`${row.name || "Candidate"} moved to Future Waiting List`);
                                }
                              }}
                            >
                              <Bookmark className="h-3.5 w-3.5 mr-1.5" /> Move to Future Waiting List
                            </Button>
                          )}
                        </>
                      )}
                    </div>
                  </div>
                </div>
              );
            })
          )}
        </div>
      </main>

      <FilePreviewDialog file_url={previewFile} onClose={() => setPreviewFile(null)} />
      <SendCustomMessageDialog
        open={!!customMsgTarget}
        onOpenChange={(o) => { if (!o) setCustomMsgTarget(null); }}
        initialEmail={customMsgTarget?.email}
        initialName={customMsgTarget?.name}
        responseId={customMsgTarget?.responseId || null}
      />
      {aiR1Target && (
        <InviteRoundDialog
          open={!!aiR1Target}
          onOpenChange={(o) => { if (!o) setAiR1Target(null); }}
          responseId={aiR1Target.responseId}
          round={1}
          candidateName={aiR1Target.name}
          initialEmail={aiR1Target.email}
          isResend
          forceDirect
          onSent={() => {
            const rid = aiR1Target.responseId;
            const oldSlotId = aiR1Target.slotId;
            // Optimistic single-row reset (same shape as the cancelled path).
            setResponses((prev) =>
              prev.map((r) =>
                r.id === rid
                  ? { ...r, appointment_cancelled: false, scheduled_slot_id: null, round_stage: "round_1_sent", round_2_sent_at: null, offer_sent_at: null }
                  : r
              )
            );
            // Best-effort: free the old slot back to the available pool. A failure
            // here must NOT block the send that already succeeded.
            if (oldSlotId) {
              supabase.functions
                .invoke("release-slot", { body: { reason: "ai_round1_resend", response_id: rid, slot_id: oldSlotId, slot_only: true } })
                .catch(() => { /* best-effort */ });
            }
            setAiR1Target(null);
          }}
        />
      )}
      {zoomTarget && (
        <UniversalCandidateModal
          type="zoom"
          initialName={zoomTarget.name}
          initialEmail={zoomTarget.email}
          onClose={() => setZoomTarget(null)}
          onCreated={() => {
            // Successful Universal Zoom send → bump this row's counter (optimistic),
            // persist single-row by response_id, roll back on failure. No reload.
            const rid = zoomTarget.responseId;
            const prevCount = actionsByResponse[rid]?.zoom_send_count ?? 0;
            const next = prevCount + 1;
            setActionsByResponse((prev) => {
              const existing = prev[rid];
              if (!existing) return prev;
              return { ...prev, [rid]: { ...existing, zoom_send_count: next } };
            });
            supabase
              .from("candidate_actions")
              .update({ zoom_send_count: next })
              .eq("response_id", rid)
              .then(({ error }) => {
                if (error) {
                  setActionsByResponse((prev) => {
                    const existing = prev[rid];
                    if (!existing) return prev;
                    return { ...prev, [rid]: { ...existing, zoom_send_count: prevCount } };
                  });
                }
              });
            setZoomTarget(null);
          }}
        />
      )}
      <ViewOfferDialog
        candidateId={viewOfferTarget?.candidateId || null}
        responseId={viewOfferTarget?.responseId}
        onClose={() => setViewOfferTarget(null)}
      />
      {(() => {
        const detailsRow = detailsRowId ? rows.find((r) => r.response.id === detailsRowId) : null;
        if (!detailsRow) return null;
        const formQs = questions.filter((q) => q.form_id === detailsRow.response.form_id);
        const formAns = answers.filter((a) => a.response_id === detailsRow.response.id);
        return (
          <ViewFullDetailsDialog
            open={!!detailsRowId}
            onClose={() => setDetailsRowId(null)}
            positionTitle={detailsRow.positionTitle}
            formTitle={detailsRow.formTitle}
            candidateName={detailsRow.name}
            candidateEmail={detailsRow.email}
            selfieUrl={detailsRow.selfieUrl}
            resumeUrl={detailsRow.resumeUrl}
            candidateId={detailsRow.response.applicant_id}
            responseId={detailsRow.response.id}
            hasApplicationPhoto={!!detailsRow.selfieUrl}
            questions={formQs}
            answers={formAns}
            onPreviewFile={(url) => setPreviewFile(url)}
            onExtrasChanged={load}
          />

        );
      })()}

      <AlertDialog open={!!restoring} onOpenChange={(o) => !o && !restoreBusy && setRestoring(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Restore this candidate?</AlertDialogTitle>
            <AlertDialogDescription>
              They will return to the active pipeline at their previous stage.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={restoreBusy}>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={(e) => { e.preventDefault(); handleRestore(); }}
              disabled={restoreBusy}
            >
              {restoreBusy ? (<><Loader2 className="h-4 w-4 mr-2 animate-spin" /> Restoring…</>) : "Restore"}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Delete Selected (disqualified) */}
      <AlertDialog open={deleteSelectedOpen} onOpenChange={(o) => !o && !deleting && setDeleteSelectedOpen(o)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Remove {selectedIds.size} candidate{selectedIds.size === 1 ? "" : "s"} from this view?</AlertDialogTitle>
            <AlertDialogDescription>
              This only removes them from the Disqualified view. Their full record stays intact on the Results page and is not destroyed.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={deleting}>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={(e) => {
                e.preventDefault();
                const ids = Array.from(selectedIds);
                setDeleteSelectedOpen(false);
                runBulkDelete(ids);
              }}
              disabled={deleting || selectedIds.size === 0}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              {deleting ? (<><Loader2 className="h-4 w-4 mr-2 animate-spin" /> Removing…</>) : `Remove ${selectedIds.size}`}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Delete Selected (bookings) — moves to Deleted Appointments, not destroyed */}
      <AlertDialog open={cancelSelectedOpen} onOpenChange={(o) => !o && !deleting && setCancelSelectedOpen(o)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete {selectedIds.size} appointment{selectedIds.size === 1 ? "" : "s"}?</AlertDialogTitle>
            <AlertDialogDescription>
              This frees their slots, cancels any Zoom meetings, and moves them to the
              Deleted Appointments tab. The candidate records are not destroyed — you can
              Re-Send or Reschedule them later. No email is sent.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={deleting}>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={(e) => {
                e.preventDefault();
                const ids = Array.from(selectedIds);
                setCancelSelectedOpen(false);
                runBulkCancel(ids);
              }}
              disabled={deleting || selectedIds.size === 0}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              {deleting ? (<><Loader2 className="h-4 w-4 mr-2 animate-spin" /> Deleting…</>) : `Delete ${selectedIds.size}`}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Permanently Delete — single (simple confirm). VIEW-MOVE into Quarantine. */}
      <AlertDialog open={!!permDeleteRow} onOpenChange={(o) => !o && !deleting && setPermDeleteRow(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Permanently delete {permDeleteRow?.name}?</AlertDialogTitle>
            <AlertDialogDescription>
              This moves the row out of Deleted Appointments and into Quarantine →
              Deleted Appointments. The candidate's full record is NOT destroyed — it
              stays on the Results page. Only the Results page can truly purge a record.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={deleting}>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={(e) => {
                e.preventDefault();
                const id = permDeleteRow?.id;
                setPermDeleteRow(null);
                if (id) runPermanentDelete([id]);
              }}
              disabled={deleting || !permDeleteRow}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              {deleting ? (<><Loader2 className="h-4 w-4 mr-2 animate-spin" /> Moving…</>) : "Permanently Delete"}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Permanently Delete Selected — bulk (typed DELETE). VIEW-MOVE into Quarantine. */}
      <AlertDialog open={permDeleteSelectedOpen} onOpenChange={(o) => !o && !deleting && setPermDeleteSelectedOpen(o)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Permanently delete {selectedIds.size} appointment{selectedIds.size === 1 ? "" : "s"}?</AlertDialogTitle>
            <AlertDialogDescription>
              This moves the selected rows out of Deleted Appointments and into
              Quarantine → Deleted Appointments. The candidate records are NOT destroyed —
              they stay on the Results page. Type <span className="font-semibold">DELETE</span> to confirm.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <Input
            value={permDeleteInput}
            onChange={(e) => setPermDeleteInput(e.target.value)}
            placeholder="Type DELETE to confirm"
            autoFocus
          />
          <AlertDialogFooter>
            <AlertDialogCancel disabled={deleting}>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={(e) => {
                e.preventDefault();
                const ids = Array.from(selectedIds);
                setPermDeleteSelectedOpen(false);
                runPermanentDelete(ids);
              }}
              disabled={deleting || permDeleteInput !== "DELETE" || selectedIds.size === 0}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              {deleting ? (<><Loader2 className="h-4 w-4 mr-2 animate-spin" /> Moving…</>) : `Permanently Delete ${selectedIds.size}`}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>




      {/* Trash All (disqualified) — requires typing DELETE */}
      <AlertDialog open={trashAllOpen} onOpenChange={(o) => !o && !deleting && setTrashAllOpen(o)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Remove ALL {responses.length} disqualified candidates from this view?</AlertDialogTitle>
            <AlertDialogDescription>
              This only clears the Disqualified view. Every candidate's full record stays intact on the Results page and is not destroyed.
              Type <span className="font-semibold">DELETE</span> to confirm.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <Input
            value={trashAllInput}
            onChange={(e) => setTrashAllInput(e.target.value)}
            placeholder="Type DELETE to confirm"
            autoFocus
          />
          <AlertDialogFooter>
            <AlertDialogCancel disabled={deleting}>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={(e) => {
                e.preventDefault();
                const ids = responses.map((r) => r.id);
                setTrashAllOpen(false);
                runBulkDelete(ids);
              }}
              disabled={deleting || trashAllInput !== "DELETE" || responses.length === 0}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              {deleting ? (<><Loader2 className="h-4 w-4 mr-2 animate-spin" /> Removing…</>) : "Remove all from view"}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
};

export default StageTrackingView;
