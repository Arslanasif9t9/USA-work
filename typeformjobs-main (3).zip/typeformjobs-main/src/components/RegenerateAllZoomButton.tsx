import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Video, Loader2 } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
} from "@/components/ui/alert-dialog";

export function RegenerateAllZoomButton() {
  const [open, setOpen] = useState(false);
  const [busy, setBusy] = useState(false);
  const [password, setPassword] = useState("");
  const [result, setResult] = useState<{ ok: number; failed: number; total: number } | null>(null);

  const run = async () => {
    if (password !== "2828") {
      toast.error("Incorrect password. Access denied.");
      return;
    }
    setBusy(true);
    setResult(null);
    try {
      const { data, error } = await supabase.functions.invoke("regenerate-zoom-meeting", {
        body: { batch_all_upcoming: true },
      });
      if (error) throw error;
      const r = data as any;
      setResult({ ok: r?.ok ?? 0, failed: r?.failed ?? 0, total: r?.total ?? 0 });
      if ((r?.failed ?? 0) === 0) toast.success(`Regenerated ${r?.ok ?? 0} Zoom links.`);
      else toast.warning(`${r?.ok ?? 0} ok, ${r?.failed ?? 0} failed`);
    } catch (e: any) {
      toast.error(e?.message || "Batch regenerate failed");
    } finally {
      setBusy(false);
    }
  };

  return (
    <>
      <Button variant="outline" size="sm" onClick={() => setOpen(true)}>
        <Video className="h-4 w-4 mr-1.5" /> Regen All Zoom Links
      </Button>
      <AlertDialog open={open} onOpenChange={(o) => { setOpen(o); if (!o) { setResult(null); setPassword(""); } }}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Regenerate Zoom links for all upcoming bookings?</AlertDialogTitle>
            <AlertDialogDescription>
              Creates fresh Zoom meetings for every upcoming booked/reserved slot, repoints each
              booking, and re-sends each candidate a confirmation email with the new link.
              <label className="block mt-4 text-sm font-medium text-foreground">
                Password
                <Input
                  type="password"
                  placeholder="Enter password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="mt-1"
                  disabled={busy}
                />
              </label>
              {result && (
                <span className="block mt-3 text-foreground">
                  Result: {result.ok} ok / {result.failed} failed of {result.total}
                </span>
              )}
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={busy}>Close</AlertDialogCancel>
            <AlertDialogAction onClick={(e) => { e.preventDefault(); run(); }} disabled={busy}>
              {busy ? (<><Loader2 className="h-4 w-4 mr-2 animate-spin" />Running…</>) : "Regenerate All"}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
}

export default RegenerateAllZoomButton;
