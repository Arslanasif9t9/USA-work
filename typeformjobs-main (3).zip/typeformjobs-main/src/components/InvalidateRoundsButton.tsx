import { useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import {
  AlertDialog,
  AlertDialogContent,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogCancel,
  AlertDialogAction,
} from "@/components/ui/alert-dialog";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { ShieldX, Loader2 } from "lucide-react";
import { toast } from "sonner";

type Props = {
  responseId: string;
  candidateName?: string;
  size?: "sm" | "lg";
  className?: string;
  /**
   * Optional active-token count passed from the parent row data to avoid N+1
   * queries on long lists. When omitted, the button runs its own small query.
   */
  activeTokenCount?: number;
  /** Called after a successful invalidation so the parent can refetch the row. */
  onInvalidated?: () => void;
};

export const InvalidateRoundsButton = ({
  responseId,
  candidateName,
  size = "sm",
  className,
  activeTokenCount,
  onInvalidated,
}: Props) => {
  const [open, setOpen] = useState(false);
  const [busy, setBusy] = useState(false);
  const queryClient = useQueryClient();

  // Source of truth = DB. Only run the per-button query when the parent did not
  // already supply the count (avoids N+1 on long lists).
  const hasProp = typeof activeTokenCount === "number";
  const { data: queriedCount, refetch } = useQuery({
    queryKey: ["active-tokens", responseId],
    enabled: !hasProp && !!responseId,
    queryFn: async () => {
      const nowIso = new Date().toISOString();
      const { count, error } = await supabase
        .from("rebook_tokens")
        .select("id", { count: "exact", head: true })
        .eq("response_id", responseId)
        .is("used_at", null)
        .gt("expires_at", nowIso);
      if (error) throw error;
      return count ?? 0;
    },
  });

  const activeCount = hasProp ? (activeTokenCount as number) : (queriedCount ?? 0);
  const disabled = activeCount === 0;

  const handleConfirm = async () => {
    setBusy(true);
    try {
      const { data, error } = await supabase.functions.invoke("invalidate-candidate-tokens", {
        body: { response_id: responseId },
      });
      if (error || !data?.ok) {
        throw new Error(error?.message || data?.error || "invalidation failed");
      }
      const count = data.count_invalidated ?? 0;
      if (count === 0) {
        toast.success("No active links to invalidate — already clean.");
      } else {
        toast.success(`Invalidated ${count} active link(s). Candidate's interview links are now expired.`);
      }
      setOpen(false);
      // DB is source of truth — refetch so the button flips to disabled and stays
      // disabled after a page refresh.
      if (hasProp) {
        onInvalidated?.();
      } else {
        await refetch();
      }
      queryClient.invalidateQueries({ queryKey: ["active-tokens", responseId] });
      onInvalidated?.();
    } catch (e: any) {
      toast.error("Failed to invalidate — please retry.");
    } finally {
      setBusy(false);
    }
  };

  const btnSize = size === "lg" ? "default" : "sm";

  return (
    <>
      <TooltipProvider delayDuration={150}>
        <Tooltip>
          <TooltipTrigger asChild>
            {/* span wrapper so the tooltip still fires when the button is disabled */}
            <span className={`inline-flex ${className || ""}`}>
              <Button
                type="button"
                variant="outline"
                size={btnSize}
                disabled={disabled}
                aria-disabled={disabled}
                className={
                  disabled
                    ? "text-muted-foreground border-border opacity-50 cursor-not-allowed"
                    : "text-destructive border-destructive/40 hover:bg-destructive/10 hover:text-destructive"
                }
                onClick={(e) => {
                  e.stopPropagation();
                  if (disabled) return;
                  setOpen(true);
                }}
              >
                <ShieldX className={size === "lg" ? "h-4 w-4 mr-2" : "h-3.5 w-3.5 mr-1.5"} />
                {disabled ? "No Active Links" : "Invalidate Rounds"}
              </Button>
            </span>
          </TooltipTrigger>
          <TooltipContent>
            {disabled
              ? "No active interview links to invalidate."
              : "Expire all active AI interview links for this candidate. Sending Round 1 again later will work as usual."}
          </TooltipContent>
        </Tooltip>
      </TooltipProvider>

      <AlertDialog open={open} onOpenChange={(o) => { if (!busy) setOpen(o); }}>
        <AlertDialogContent onClick={(e) => e.stopPropagation()}>
          <AlertDialogHeader>
            <AlertDialogTitle>Invalidate all active AI interview links?</AlertDialogTitle>
            <AlertDialogDescription>
              Invalidate all active AI interview links for {candidateName || "this candidate"}? Any link
              already sent will stop working. You can resend Round 1 later to re-enable. This action is reversible.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={busy} autoFocus>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={(e) => { e.preventDefault(); handleConfirm(); }}
              disabled={busy}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              {busy ? (<><Loader2 className="h-4 w-4 mr-2 animate-spin" /> Working…</>) : "Yes, Invalidate"}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
};

export default InvalidateRoundsButton;
