import { AlertTriangle } from "lucide-react";

const NAVY = "#1a2547";
const GOLD = "#b08d57";
const CREAM = "#faf8f3";

type SpinnerProps = { size?: number; className?: string };

/** Branded smooth-spinning ring — navy with a gold accent arc. */
export const Spinner = ({ size = 40, className = "" }: SpinnerProps) => {
  const stroke = Math.max(2, Math.round(size / 12));
  const r = (size - stroke) / 2;
  const c = size / 2;
  return (
    <svg
      width={size}
      height={size}
      viewBox={`0 0 ${size} ${size}`}
      className={`animate-spin ${className}`}
      role="status"
      aria-label="Loading"
      style={{ animationDuration: "0.9s" }}
    >
      {/* faint navy ring */}
      <circle
        cx={c}
        cy={c}
        r={r}
        fill="none"
        stroke={NAVY}
        strokeOpacity={0.15}
        strokeWidth={stroke}
      />
      {/* gold arc */}
      <circle
        cx={c}
        cy={c}
        r={r}
        fill="none"
        stroke={GOLD}
        strokeWidth={stroke}
        strokeLinecap="round"
        strokeDasharray={`${2 * Math.PI * r * 0.28} ${2 * Math.PI * r}`}
      />
    </svg>
  );
};

/** Full-viewport branded loader. Use during auth gate / route chunk load. */
export const FullPageLoader = ({ label = "Loading…" }: { label?: string }) => (
  <div
    className="min-h-screen flex flex-col items-center justify-center gap-4"
    style={{ background: CREAM, fontFamily: "Inter, sans-serif" }}
    aria-busy="true"
    aria-live="polite"
  >
    <Spinner size={44} />
    <div
      className="text-sm tracking-wide"
      style={{ color: NAVY, opacity: 0.75 }}
    >
      {label}
    </div>
  </div>
);

/** Inline loader for in-card / in-table loading states. */
export const InlineLoader = ({ label = "Loading…" }: { label?: string }) => (
  <div
    className="p-10 flex flex-col items-center justify-center gap-3"
    style={{ fontFamily: "Inter, sans-serif" }}
    aria-busy="true"
    aria-live="polite"
  >
    <Spinner size={32} />
    <div className="text-xs" style={{ color: NAVY, opacity: 0.7 }}>
      {label}
    </div>
  </div>
);

/** Failed-fetch retry block. */
export const LoadError = ({
  onRetry,
  message = "Couldn't load",
}: {
  onRetry: () => void;
  message?: string;
}) => (
  <div
    className="p-10 flex flex-col items-center justify-center gap-3"
    style={{ fontFamily: "Inter, sans-serif" }}
    role="alert"
  >
    <AlertTriangle className="h-6 w-6" style={{ color: GOLD }} />
    <div className="text-sm" style={{ color: NAVY }}>
      {message}
    </div>
    <button
      type="button"
      onClick={onRetry}
      className="px-4 py-2 rounded-md text-sm font-medium transition-colors"
      style={{ background: NAVY, color: "#fff" }}
    >
      Retry
    </button>
  </div>
);
