import { Navigate } from "react-router-dom";
import { useAuth } from "@/hooks/useAuth";
import InterviewReminderWatcher from "@/components/InterviewReminderWatcher";
import { FullPageLoader } from "@/components/FullPageLoader";
import DashboardErrorBoundary from "@/components/DashboardErrorBoundary";

export const ProtectedRoute = ({ children }: { children: React.ReactNode }) => {
  const { session, loading } = useAuth();
  if (loading) return <FullPageLoader label="Signing you in…" />;
  if (!session) return <Navigate to="/login" replace />;
  // Shared error boundary so a render-time throw on ANY /dashboard/* (or other
  // protected HR) page shows a friendly message instead of blanking the app.
  return (
    <DashboardErrorBoundary>
      {children}
      <InterviewReminderWatcher />
    </DashboardErrorBoundary>
  );
};

export const RootRedirect = () => {
  const { session, loading } = useAuth();
  if (loading) return <FullPageLoader />;
  return <Navigate to={session ? "/dashboard" : "/login"} replace />;
};
