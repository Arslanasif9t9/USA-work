import { Trophy, Award, ShieldCheck, Flame, OctagonAlert, type LucideIcon } from "lucide-react";

/**
 * Big, display-only AI verdict tier badge for My Bookings rows.
 * Source: ai_interview_evaluations.tier (written by retell-webhook-receiver),
 * resolved per candidate by response_id -> most recent ai_interview_sessions ->
 * its evaluation tier, with same-email borrow. Read-only — HR cannot edit it.
 */
export type AiTierKey = "Best One" | "Breadwinner" | "Steady" | "Edgy" | "Red Flag";

const TIERS: Record<string, { label: string; Icon: LucideIcon; className: string }> = {
  "best one": {
    label: "Best One",
    Icon: Trophy,
    className: "bg-green-700 text-white border border-green-800 shadow-sm",
  },
  breadwinner: {
    label: "Breadwinner",
    Icon: Award,
    className: "bg-amber-500 text-white border border-amber-600 shadow-sm",
  },
  steady: {
    label: "Steady",
    Icon: ShieldCheck,
    className: "bg-blue-600 text-white border border-blue-700 shadow-sm",
  },
  edgy: {
    label: "Edgy",
    Icon: Flame,
    className: "bg-orange-500 text-white border border-orange-600 shadow-sm",
  },
  "red flag": {
    label: "Red Flag",
    Icon: OctagonAlert,
    className: "bg-red-600 text-white border border-red-700 shadow-sm",
  },
};

export function AiTierBadge({ tier }: { tier: string | null | undefined }) {
  const key = (tier || "").trim().toLowerCase();
  const cfg = key ? TIERS[key] : undefined;
  if (!cfg) return null;
  const { Icon, label, className } = cfg;
  return (
    <span
      className={`inline-flex items-center gap-1.5 rounded-md px-3 py-1 text-sm font-bold tracking-wide ${className}`}
      title={`AI verdict: ${label}`}
    >
      <Icon className="h-4 w-4 shrink-0" />
      {label}
    </span>
  );
}
