import { useEffect, useState } from "react";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Loader2 } from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { parseInvokeError } from "@/lib/invokeError";
import { AiAssistButton } from "@/components/AiAssistButton";
import SendScheduleControl, { type SendScheduleValue } from "@/components/SendScheduleControl";
import { insertScheduledSend } from "@/lib/scheduledSends";

type Props = {
  open: boolean;
  onOpenChange: (o: boolean) => void;
  initialEmail?: string;
  initialName?: string;
  responseId?: string | null;
};

const MAX = 4000;

export function SendCustomMessageDialog({ open, onOpenChange, initialEmail, initialName, responseId }: Props) {
  const [email, setEmail] = useState(initialEmail || "");
  const [name, setName] = useState(initialName || "");
  const [message, setMessage] = useState("");
  const [password, setPassword] = useState("");
  const [sending, setSending] = useState(false);
  const [schedule, setSchedule] = useState<SendScheduleValue>({ mode: "now" });

  useEffect(() => {
    if (open) {
      setEmail(initialEmail || "");
      setName(initialName || "");
      setMessage("");
      setPassword("");
      setSchedule({ mode: "now" });
    }
  }, [open, initialEmail, initialName]);

  const submit = async () => {
    if (!email.trim() || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim())) {
      toast.error("Please enter a valid recipient email");
      return;
    }
    if (!message.trim()) {
      toast.error("Message is required");
      return;
    }
    if (!password) {
      toast.error("Password is required");
      return;
    }
    setSending(true);
    try {
      if (schedule.mode === "schedule") {
        await insertScheduledSend({
          send_type: "custom_message",
          target_function: "send-custom-message",
          payload: {
            recipient_email: email.trim(),
            recipient_name: name.trim() || undefined,
            message_body: message,
            password,
            response_id: responseId || undefined,
          },
          response_id: responseId || null,
          scheduled_for_utc: schedule.scheduled_for_utc,
          timezone: schedule.timezone,
        });
        toast.success("Message scheduled");
        onOpenChange(false);
        return;
      }
      const { data, error } = await supabase.functions.invoke("send-custom-message", {
        body: {
          recipient_email: email.trim(),
          recipient_name: name.trim() || undefined,
          message_body: message,
          password,
          response_id: responseId || undefined,
        },
      });
      if (error) {
        const { message: msg } = await parseInvokeError(error, data);
        toast.error(msg); // dialog stays open for retry
        return;
      }
      if ((data as any)?.error) {
        const { message: msg } = await parseInvokeError(null, data);
        toast.error(msg);
        return;
      }
      toast.success("Message sent");
      onOpenChange(false);
    } catch (e: any) {
      const { message: msg } = await parseInvokeError(e);
      toast.error(msg);
    } finally {
      setSending(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={(o) => !sending && onOpenChange(o)}>
      <DialogContent className="max-w-lg w-[calc(100vw-32px)]">
        <DialogHeader>
          <DialogTitle style={{ fontFamily: "'Cormorant Garamond', serif", color: "#1a2547" }}>
            Send Custom Message
          </DialogTitle>
          <DialogDescription>
            One-off branded message from Expert Intuitive Advisor — Human Resources.
          </DialogDescription>
        </DialogHeader>
        <div className="grid gap-3">
          <div className="grid gap-1.5">
            <Label htmlFor="scm-name">Recipient Name (optional)</Label>
            <Input id="scm-name" value={name} onChange={(e) => setName(e.target.value)} className="h-11" />
          </div>
          <div className="grid gap-1.5">
            <Label htmlFor="scm-email">Recipient Email</Label>
            <Input id="scm-email" type="email" autoComplete="off" value={email} onChange={(e) => setEmail(e.target.value)} className="h-11" />
          </div>
          <div className="grid gap-1.5">
            <div className="flex items-center justify-between">
              <Label htmlFor="scm-msg">Message</Label>
              <AiAssistButton
                context="custom message to a candidate"
                onAccept={(text) => setMessage(text.slice(0, MAX))}
              />
            </div>
            <Textarea
              id="scm-msg"
              value={message}
              onChange={(e) => setMessage(e.target.value.slice(0, MAX))}
              rows={5}
              placeholder="Type a short message (2–4 lines)…"
            />
            <div className="text-xs text-muted-foreground text-right">{message.length} / {MAX}</div>
          </div>
          <div className="grid gap-1.5">
            <Label htmlFor="scm-pw">Password</Label>
            <Input id="scm-pw" type="password" value={password} onChange={(e) => setPassword(e.target.value)} className="h-11" />
          </div>
          <SendScheduleControl onChange={setSchedule} />
        </div>
        <DialogFooter className="gap-2">
          <Button variant="outline" onClick={() => onOpenChange(false)} disabled={sending} className="min-h-11">Cancel</Button>
          <Button onClick={submit} disabled={sending} className="min-h-11" style={{ background: "#1a2547" }}>
            {sending ? <><Loader2 className="h-4 w-4 mr-2 animate-spin" /> Sending…</> : "Send Message"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
