import { useState } from "react";
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Loader2, CalendarX } from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";

type Props = {
  slotId: string;
  candidateName?: string;
  onReleased?: () => void;
  size?: "sm" | "lg";
};

export const ReleaseSlotButton = ({ slotId, candidateName, onReleased, size = "sm" }: Props) => {
  const [open, setOpen] = useState(false);
  const [busy, setBusy] = useState(false);

  const ico = size === "lg" ? "h-4 w-4 mr-2" : "h-3.5 w-3.5 mr-1.5";
  const cls =
    size === "lg"
      ? "action-btn action-btn--lg"
      : "action-btn";

  const submit = async () => {
    setBusy(true);
    try {
      const { data, error } = await supabase.functions.invoke("release-slot", {
        body: { slot_id: slotId, reason: "manual_release" },
      });
      const errMsg = (data as any)?.error || error?.message;
      if (errMsg) throw new Error(errMsg);
      toast.success("Slot released — now available to others");
      setOpen(false);
      onReleased?.();
    } catch (e: any) {
      toast.error(e?.message || "Could not release slot");
    } finally {
      setBusy(false);
    }
  };

  return (
    <>
      <button
        type="button"
        className={`${cls} text-destructive border-destructive/40 hover:bg-destructive/10`}
        onClick={() => setOpen(true)}
      >
        <CalendarX className={ico} /> Release Slot
      </button>

      <AlertDialog open={open} onOpenChange={(o) => !busy && setOpen(o)}>
        <AlertDialogContent onClick={(e) => e.stopPropagation()}>
          <AlertDialogHeader>
            <AlertDialogTitle>Release this slot?</AlertDialogTitle>
            <AlertDialogDescription>
              This frees the booked time for {candidateName || "this candidate"} back
              to availability and cancels the Zoom meeting. The candidate's interview
              record stays — only the time slot is released.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={busy}>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={(e) => { e.preventDefault(); submit(); }}
              disabled={busy}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              {busy ? (<><Loader2 className="h-4 w-4 mr-2 animate-spin" /> Releasing…</>) : "Release Slot"}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
};

export default ReleaseSlotButton;
