import { useEffect, useMemo, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter,
} from "@/components/ui/dialog";
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Loader2, X, ChevronLeft, ChevronRight } from "lucide-react";
import { toast } from "sonner";
import {
  SchedulingConfig, BlockedSlot, Booking, generateSlotsForDate, getSlotState,
  ymdInTz, formatTimeInTz, formatFullDateInTz,
} from "@/lib/scheduling";

type Props = {
  open: boolean;
  onOpenChange: (o: boolean) => void;
  config: SchedulingConfig;
  questionLabel: string;
};

const startOfMonth = (d: Date) => new Date(d.getFullYear(), d.getMonth(), 1);
const addMonths = (d: Date, n: number) => new Date(d.getFullYear(), d.getMonth() + n, 1);
const daysInMonth = (d: Date) => new Date(d.getFullYear(), d.getMonth() + 1, 0).getDate();

const SchedulingCalendarEditor = ({ open, onOpenChange, config, questionLabel }: Props) => {
  const [month, setMonth] = useState(() => startOfMonth(new Date()));
  const [selectedDate, setSelectedDate] = useState<Date>(() => new Date());
  const [blocked, setBlocked] = useState<BlockedSlot[]>([]);
  const [bookings, setBookings] = useState<Booking[]>([]);
  const [loading, setLoading] = useState(false);
  const [rangeOpen, setRangeOpen] = useState(false);
  const [rangeStart, setRangeStart] = useState("");
  const [rangeEnd, setRangeEnd] = useState("");
  const [rangeReason, setRangeReason] = useState("");
  const [pendingBlock, setPendingBlock] = useState<{ start: Date; end: Date; reason: string; warnCount: number } | null>(null);

  const reload = async () => {
    setLoading(true);
    const [b, k] = await Promise.all([
      supabase.from("scheduling_blocked_slots").select("*").eq("config_id", config.id),
      supabase.from("scheduling_bookings").select("*").eq("config_id", config.id),
    ]);
    if (b.error) toast.error(b.error.message);
    if (k.error) toast.error(k.error.message);
    setBlocked((b.data as any) || []);
    setBookings((k.data as any) || []);
    setLoading(false);
  };

  useEffect(() => { if (open) reload(); /* eslint-disable-next-line */ }, [open, config.id]);

  const daySlots = useMemo(() => generateSlotsForDate(selectedDate, config), [selectedDate, config]);

  const dayHasBooking = (d: Date) => {
    const { y, m, d: day } = ymdInTz(d, config.timezone);
    return bookings.some((b) => {
      if (b.status === "cancelled" || b.status === "rejected") return false;
      const bd = ymdInTz(new Date(b.slot_start), config.timezone);
      return bd.y === y && bd.m === m && bd.d === day;
    });
  };

  const dayFullyBlocked = (d: Date) => {
    const slots = generateSlotsForDate(d, config);
    if (slots.length === 0) return false;
    return slots.every((s) => getSlotState(s, config, blocked, []) === "blocked");
  };

  const dayHasAvailable = (d: Date) => {
    const slots = generateSlotsForDate(d, config);
    return slots.some((s) => getSlotState(s, config, blocked, bookings) === "available");
  };

  const unblockSlot = async (slotStart: Date) => {
    // Find blocked slot that covers exactly this start time and matches duration.
    const s = slotStart.getTime();
    const candidate = blocked.find((b) => new Date(b.start_at).getTime() === s);
    if (!candidate) {
      // If covered by a larger range, do nothing (need ranges removed via day-level)
      toast.info("This slot is covered by a date-range block. Use unblock on the range.");
      return;
    }
    const { error } = await supabase.from("scheduling_blocked_slots").delete().eq("id", candidate.id);
    if (error) toast.error(error.message);
    else reload();
  };

  const blockSlot = async (slotStart: Date, slotEnd: Date) => {
    const { error } = await supabase.from("scheduling_blocked_slots").insert({
      config_id: config.id,
      start_at: slotStart.toISOString(),
      end_at: slotEnd.toISOString(),
    });
    if (error) toast.error(error.message);
    else reload();
  };

  const blockRange = async (startDate: Date, endDate: Date, reason: string) => {
    // Count pending bookings in range
    const s = startDate.getTime();
    const e = endDate.getTime();
    const warnCount = bookings.filter(
      (b) =>
        (b.status === "pending_approval" || b.status === "approved") &&
        new Date(b.slot_start).getTime() >= s &&
        new Date(b.slot_start).getTime() < e,
    ).length;
    if (warnCount > 0) {
      setPendingBlock({ start: startDate, end: endDate, reason, warnCount });
      return;
    }
    await doBlockRange(startDate, endDate, reason);
  };

  const doBlockRange = async (startDate: Date, endDate: Date, reason: string) => {
    const { error } = await supabase.from("scheduling_blocked_slots").insert({
      config_id: config.id,
      start_at: startDate.toISOString(),
      end_at: endDate.toISOString(),
      reason: reason || null,
    });
    if (error) toast.error(error.message);
    else {
      toast.success("Block added");
      setRangeOpen(false);
      setRangeStart(""); setRangeEnd(""); setRangeReason("");
      reload();
    }
  };

  const blockWholeDay = async () => {
    const { y, m, d } = ymdInTz(selectedDate, config.timezone);
    // Block 24h window in config tz
    const start = new Date(Date.UTC(y, m - 1, d, 0, 0, 0));
    const end = new Date(Date.UTC(y, m - 1, d + 1, 0, 0, 0));
    await blockRange(start, end, "Full day");
  };

  // Month grid
  const firstDow = new Date(month.getFullYear(), month.getMonth(), 1).getDay();
  const total = daysInMonth(month);
  const cells: (Date | null)[] = [];
  for (let i = 0; i < firstDow; i++) cells.push(null);
  for (let d = 1; d <= total; d++) cells.push(new Date(month.getFullYear(), month.getMonth(), d));

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-5xl w-[95vw] h-[90vh] flex flex-col p-0 gap-0">
        <DialogHeader className="px-6 py-4 border-b">
          <DialogTitle className="flex items-center justify-between">
            <span>Manage Availability — {questionLabel}</span>
          </DialogTitle>
        </DialogHeader>

        <div className="flex-1 grid grid-cols-1 md:grid-cols-2 overflow-hidden">
          {/* Calendar */}
          <div className="border-r p-4 overflow-y-auto">
            <div className="flex items-center justify-between mb-3">
              <Button variant="ghost" size="icon" onClick={() => setMonth(addMonths(month, -1))}>
                <ChevronLeft className="h-4 w-4" />
              </Button>
              <div className="text-sm font-semibold">
                {month.toLocaleString(undefined, { month: "long", year: "numeric" })}
              </div>
              <Button variant="ghost" size="icon" onClick={() => setMonth(addMonths(month, 1))}>
                <ChevronRight className="h-4 w-4" />
              </Button>
            </div>
            <div className="grid grid-cols-7 gap-1 text-[11px] text-muted-foreground mb-1">
              {["Sun","Mon","Tue","Wed","Thu","Fri","Sat"].map((d) => (
                <div key={d} className="text-center py-1">{d}</div>
              ))}
            </div>
            <div className="grid grid-cols-7 gap-1">
              {cells.map((c, i) => {
                if (!c) return <div key={i} />;
                const isSel =
                  selectedDate.getFullYear() === c.getFullYear() &&
                  selectedDate.getMonth() === c.getMonth() &&
                  selectedDate.getDate() === c.getDate();
                const hasBook = dayHasBooking(c);
                const fullBlock = dayFullyBlocked(c);
                const hasAvail = dayHasAvailable(c);
                return (
                  <button
                    key={i}
                    onClick={() => setSelectedDate(c)}
                    className={`aspect-square rounded-md text-sm flex flex-col items-center justify-center transition-colors ${
                      isSel ? "bg-primary text-primary-foreground"
                        : "hover:bg-secondary"
                    }`}
                  >
                    <span>{c.getDate()}</span>
                    <div className="flex gap-0.5 mt-0.5 h-1.5">
                      {hasAvail && <span className="w-1.5 h-1.5 rounded-full bg-green-500" />}
                      {fullBlock && <span className="w-1.5 h-1.5 rounded-full bg-red-500" />}
                      {hasBook && <span className="w-1.5 h-1.5 rounded-full bg-blue-500" />}
                    </div>
                  </button>
                );
              })}
            </div>
            <div className="mt-4 flex flex-wrap gap-2 text-[11px] text-muted-foreground">
              <span className="flex items-center gap-1"><span className="w-2 h-2 rounded-full bg-green-500" /> Available</span>
              <span className="flex items-center gap-1"><span className="w-2 h-2 rounded-full bg-red-500" /> Blocked</span>
              <span className="flex items-center gap-1"><span className="w-2 h-2 rounded-full bg-blue-500" /> Booked</span>
            </div>

            <div className="mt-4 space-y-2 border-t pt-4">
              <Button variant="outline" size="sm" onClick={blockWholeDay} className="w-full">
                Block this entire day
              </Button>
              <Button variant="outline" size="sm" onClick={() => setRangeOpen(true)} className="w-full">
                Block date range…
              </Button>
            </div>
          </div>

          {/* Day detail */}
          <div className="p-4 overflow-y-auto">
            <div className="text-sm font-semibold mb-3">
              {formatFullDateInTz(selectedDate, config.timezone)}
            </div>
            {loading ? (
              <div className="flex items-center gap-2 text-sm text-muted-foreground">
                <Loader2 className="h-4 w-4 animate-spin" /> Loading…
              </div>
            ) : daySlots.length === 0 ? (
              <p className="text-sm text-muted-foreground">Outside working hours.</p>
            ) : (
              <div className="space-y-1.5">
                {daySlots.map((s) => {
                  const state = getSlotState(s, config, blocked, bookings);
                  const booking = bookings.find(
                    (b) => new Date(b.slot_start).getTime() === s.start.getTime()
                      && (b.status === "pending_approval" || b.status === "approved"),
                  );
                  const colors: Record<string, string> = {
                    available: "border-green-500/40 bg-green-500/5 text-green-700 dark:text-green-400",
                    blocked: "border-red-500/40 bg-red-500/5 text-red-700 dark:text-red-400",
                    booked: "border-blue-500/40 bg-blue-500/5 text-blue-700 dark:text-blue-400",
                    too_soon: "border-border bg-muted text-muted-foreground",
                    outside_hours: "border-border bg-muted text-muted-foreground",
                  };
                  return (
                    <div
                      key={s.key}
                      className={`flex items-center justify-between px-3 py-2 rounded-md border text-sm ${colors[state]}`}
                    >
                      <span className="font-medium">
                        {formatTimeInTz(s.start, config.timezone)} — {formatTimeInTz(s.end, config.timezone)}
                      </span>
                      <div className="flex items-center gap-2">
                        {state === "booked" && booking && (
                          <span className="text-xs">
                            {booking.candidate_name || "Booked"}
                            {booking.status === "pending_approval" && " (pending)"}
                          </span>
                        )}
                        {state === "available" && (
                          <Button size="sm" variant="ghost" onClick={() => blockSlot(s.start, s.end)}>
                            Block
                          </Button>
                        )}
                        {state === "blocked" && (
                          <Button size="sm" variant="ghost" onClick={() => unblockSlot(s.start)}>
                            Unblock
                          </Button>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </div>

        <DialogFooter className="px-6 py-3 border-t">
          <Button variant="ghost" onClick={() => onOpenChange(false)}>
            <X className="h-4 w-4" /> Close
          </Button>
        </DialogFooter>

        {/* Range block sub-dialog */}
        <Dialog open={rangeOpen} onOpenChange={setRangeOpen}>
          <DialogContent>
            <DialogHeader><DialogTitle>Block date range</DialogTitle></DialogHeader>
            <div className="space-y-3">
              <div>
                <Label className="text-xs">From</Label>
                <Input type="datetime-local" value={rangeStart} onChange={(e) => setRangeStart(e.target.value)} />
              </div>
              <div>
                <Label className="text-xs">To</Label>
                <Input type="datetime-local" value={rangeEnd} onChange={(e) => setRangeEnd(e.target.value)} />
              </div>
              <div>
                <Label className="text-xs">Reason (optional)</Label>
                <Input value={rangeReason} onChange={(e) => setRangeReason(e.target.value)} placeholder="e.g. Vacation" />
              </div>
            </div>
            <DialogFooter>
              <Button variant="ghost" onClick={() => setRangeOpen(false)}>Cancel</Button>
              <Button
                onClick={() => {
                  if (!rangeStart || !rangeEnd) return toast.error("Pick start and end");
                  const s = new Date(rangeStart);
                  const e = new Date(rangeEnd);
                  if (e <= s) return toast.error("End must be after start");
                  blockRange(s, e, rangeReason);
                }}
              >
                Block
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>

        <AlertDialog open={!!pendingBlock} onOpenChange={(o) => !o && setPendingBlock(null)}>
          <AlertDialogContent>
            <AlertDialogHeader>
              <AlertDialogTitle>Block range with existing bookings?</AlertDialogTitle>
              <AlertDialogDescription>
                {pendingBlock?.warnCount} active booking(s) fall within this range.
                Existing bookings will not be cancelled automatically, but new bookings will be blocked.
              </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel>Cancel</AlertDialogCancel>
              <AlertDialogAction
                onClick={(e) => {
                  e.preventDefault();
                  if (pendingBlock) doBlockRange(pendingBlock.start, pendingBlock.end, pendingBlock.reason);
                  setPendingBlock(null);
                }}
              >
                Block anyway
              </AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>
      </DialogContent>
    </Dialog>
  );
};

export default SchedulingCalendarEditor;
