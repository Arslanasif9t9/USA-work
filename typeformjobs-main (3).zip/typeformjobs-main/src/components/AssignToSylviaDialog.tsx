import { useEffect, useMemo, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter,
} from "@/components/ui/dialog";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue, SelectGroup, SelectLabel, SelectSeparator,
} from "@/components/ui/select";
import { Loader2 } from "lucide-react";
import { toast } from "sonner";
import { TEAM_OPTIONS } from "@/lib/teams";

type Group = { id: string; name: string };

const COMMON_TZS = [
  "Asia/Manila",
  "America/Los_Angeles",
  "America/New_York",
  "Europe/London",
];

// Build the full IANA list from the browser's Intl when available; otherwise
// fall back to a curated set so the dropdown always renders something.
const buildAllTzs = (): string[] => {
  try {
    const fn = (Intl as any)?.supportedValuesOf;
    if (typeof fn === "function") {
      const all = fn("timeZone") as string[];
      if (Array.isArray(all) && all.length > 0) return all;
    }
  } catch { /* ignore */ }
  return [
    "UTC",
    "Asia/Manila", "Asia/Singapore", "Asia/Hong_Kong", "Asia/Tokyo", "Asia/Seoul", "Asia/Kolkata", "Asia/Dubai",
    "America/Los_Angeles", "America/Denver", "America/Chicago", "America/New_York", "America/Toronto", "America/Mexico_City", "America/Sao_Paulo",
    "Europe/London", "Europe/Dublin", "Europe/Paris", "Europe/Berlin", "Europe/Madrid", "Europe/Rome", "Europe/Amsterdam",
    "Australia/Sydney", "Australia/Melbourne", "Pacific/Auckland",
  ];
};

export function AssignToSylviaDialog({
  open, onOpenChange, responseId, candidateName,
}: {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  responseId: string;
  candidateName: string;
}) {
  const [loading, setLoading] = useState(false);
  const [saving, setSaving] = useState(false);
  // The 5 real teams are always available (shared constant). No more PMS bridge.
  const groups: Group[] = TEAM_OPTIONS;
  const [mode, setMode] = useState<"pick" | "manual">("pick");
  const [picked, setPicked] = useState<string>("");
  const [typed, setTyped] = useState<string>("");
  const [instruction, setInstruction] = useState<string>("");
  const [tz, setTz] = useState<string>("Asia/Manila");
  const [contactTime, setContactTime] = useState<string>("09:00");

  const allTzs = useMemo(() => {
    const all = buildAllTzs();
    // Deduplicate against the "common" header section.
    return all.filter((z) => !COMMON_TZS.includes(z)).sort();
  }, []);

  useEffect(() => {
    if (!open) return;
    let cancelled = false;
    (async () => {
      setLoading(true);
      // Fetch the current row (teams come from the shared TEAM_OPTIONS constant).
      const rowRes = await supabase
        .from("responses")
        .select("assigned_group_id, sylvia_instruction, contact_timezone, preferred_contact_time")
        .eq("id", responseId)
        .maybeSingle();
      if (cancelled) return;
      const row = (rowRes.data as any) || {};
      const current = (row.assigned_group_id || "").trim();
      const currentInstr = row.sylvia_instruction || "";
      setInstruction(currentInstr);
      const matched = groups.find((g) => g.name === current || g.id === current);
      const looksLikeUuid = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(current);
      if (current && matched) {
        // Store the group UUID (matches the inline Employees dropdown + Sylvia's map).
        setMode("pick"); setPicked(matched.id); setTyped("");
      } else if (current && looksLikeUuid) {
        setMode("pick"); setPicked(""); setTyped("");   // stale id, no leak
      } else if (current) {
        setMode("manual"); setTyped(current); setPicked("");   // genuine custom text only
      } else {
        setMode("pick"); setPicked(""); setTyped("");   // nothing yet — default to pick
      }
      // Pre-fill contact time
      setContactTime((row.preferred_contact_time || "09:00").slice(0, 5));

      // Timezone: prefer saved value; else seed from latest scheduling_bookings.candidate_timezone; else Asia/Manila.
      let nextTz: string = (row.contact_timezone || "").trim();
      if (!nextTz) {
        const { data: booking } = await supabase
          .from("scheduling_bookings")
          .select("candidate_timezone, created_at")
          .eq("response_id", responseId)
          .not("candidate_timezone", "is", null)
          .order("created_at", { ascending: false })
          .limit(1)
          .maybeSingle();
        nextTz = (booking?.candidate_timezone || "").trim() || "Asia/Manila";
      }
      if (!cancelled) setTz(nextTz);
      setLoading(false);
    })();
    return () => { cancelled = true; };
  }, [open, responseId]);

  const save = async () => {
    const value = mode === "pick" ? picked.trim() : typed.trim();
    setSaving(true);
    const { error } = await supabase
      .from("responses")
      .update({
        assigned_group_id: value || null,
        sylvia_instruction: instruction.trim() || null,
        contact_timezone: tz.trim() || null,
        preferred_contact_time: contactTime.trim() || null,
      })
      .eq("id", responseId);
    setSaving(false);
    if (error) {
      toast.error(`Save failed: ${error.message}`);
      return;
    }
    toast.success("Assigned to Sylvia");
    onOpenChange(false);
  };

  // Teams always available now (shared constant).
  const hasGroups = groups.length > 0;
  // Ensure the saved/seeded TZ is always pickable even if not in our list.
  const extraTz = tz && !COMMON_TZS.includes(tz) && !allTzs.includes(tz) ? tz : null;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Assign {candidateName} to Sylvia</DialogTitle>
          <DialogDescription>
            Choose a team, optional note, and when Sylvia should reach out.
          </DialogDescription>
        </DialogHeader>

        {loading ? (
          <div className="flex items-center justify-center py-8">
            <Loader2 className="h-5 w-5 animate-spin" />
          </div>
        ) : (
          <div className="space-y-4">
            <div className="space-y-2">
              <Label className="text-sm font-semibold">Team assignment</Label>
              <RadioGroup value={mode} onValueChange={(v) => setMode(v as "pick" | "manual")}>
                <div className="flex items-start gap-2">
                  <RadioGroupItem value="pick" id="syl-pick" disabled={!hasGroups} className="mt-1" />
                  <div className="flex-1 space-y-1">
                    <Label htmlFor="syl-pick" className="font-normal">
                      Pick from list
                    </Label>
                    <Select
                      value={picked}
                      onValueChange={setPicked}
                      disabled={mode !== "pick" || !hasGroups}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder={hasGroups ? "Select a team…" : "No teams available"} />
                      </SelectTrigger>
                      <SelectContent>
                        {groups.map((g) => (
                          <SelectItem key={g.id} value={g.id}>{g.name}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div className="flex items-start gap-2">
                  <RadioGroupItem value="manual" id="syl-manual" className="mt-1" />
                  <div className="flex-1 space-y-1">
                    <Label htmlFor="syl-manual" className="font-normal">Type manually</Label>
                    <Input
                      value={typed}
                      onChange={(e) => setTyped(e.target.value)}
                      placeholder="Team name"
                      disabled={mode !== "manual"}
                    />
                  </div>
                </div>
              </RadioGroup>
            </div>

            <div className="space-y-2">
              <Label className="text-sm font-semibold">Custom instruction (optional)</Label>
              <Textarea
                value={instruction}
                onChange={(e) => setInstruction(e.target.value)}
                placeholder="Optional note for Sylvia about this person (e.g. VIP, special handling, what to emphasize)."
                rows={4}
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div className="space-y-2">
                <Label className="text-sm font-semibold">Contact timezone</Label>
                <Select value={tz} onValueChange={setTz}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select timezone…" />
                  </SelectTrigger>
                  <SelectContent className="max-h-72">
                    <SelectGroup>
                      <SelectLabel>Common</SelectLabel>
                      {COMMON_TZS.map((z) => (
                        <SelectItem key={z} value={z}>{z}</SelectItem>
                      ))}
                    </SelectGroup>
                    <SelectSeparator />
                    {extraTz && (
                      <>
                        <SelectGroup>
                          <SelectLabel>Current</SelectLabel>
                          <SelectItem value={extraTz}>{extraTz}</SelectItem>
                        </SelectGroup>
                        <SelectSeparator />
                      </>
                    )}
                    <SelectGroup>
                      <SelectLabel>All timezones</SelectLabel>
                      {allTzs.map((z) => (
                        <SelectItem key={z} value={z}>{z}</SelectItem>
                      ))}
                    </SelectGroup>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label className="text-sm font-semibold">Preferred contact time</Label>
                <Input
                  type="time"
                  value={contactTime}
                  onChange={(e) => setContactTime(e.target.value)}
                />
              </div>
            </div>
            <p className="text-xs text-muted-foreground">
              Sylvia will send her first WhatsApp message around this local time.
            </p>
          </div>
        )}

        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)} disabled={saving}>
            Cancel
          </Button>
          <Button onClick={save} disabled={saving || loading} style={{ background: "#1a2547" }}>
            {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : "Save"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
