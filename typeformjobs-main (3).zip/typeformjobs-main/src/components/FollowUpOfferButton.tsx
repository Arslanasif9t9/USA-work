import { useState } from "react";
import { Button } from "@/components/ui/button";
import { BellRing, Loader2 } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";

export const FollowUpOfferButton = ({ responseId, candidateName }: { responseId: string; candidateName?: string }) => {
  const [busy, setBusy] = useState(false);
  const click = async () => {
    setBusy(true);
    try {
      const { data, error } = await supabase.functions.invoke("send-offer-followup", {
        body: { response_id: responseId, mode: "followup" },
      });
      const errMsg = (data as any)?.error || error?.message;
      if (errMsg) { toast.error(errMsg); return; }
      toast.success(`Follow-up reminder sent${candidateName ? ` to ${candidateName}` : ""}`);
    } finally { setBusy(false); }
  };
  return (
    <Button type="button" variant="outline" size="sm" onClick={click} disabled={busy}>
      {busy ? <Loader2 className="h-3.5 w-3.5 mr-1.5 animate-spin" /> : <BellRing className="h-3.5 w-3.5 mr-1.5" />}
      Follow Up
    </Button>
  );
};

export default FollowUpOfferButton;
