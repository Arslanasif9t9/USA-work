import { useEffect, useMemo, useState } from "react";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Loader2, Plus, Calendar as CalIcon, X, RotateCcw, EyeOff } from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";

type SlotItem = { id: string; slot_start: string; display_time: string };
type Payload = { slots_by_date?: Record<string, SlotItem[]>; ooo_active?: boolean };

type Props = {
  open: boolean;
  onOpenChange: (o: boolean) => void;
  initialSelected?: string[];
  /** If provided, save mode = persist immediately to this token via set-curated-slots. */
  token?: string;
  /** Otherwise pure picker mode: returns selected IDs via onSave. */
  onSave?: (slotIds: string[]) => void;
};

const fmtDate = (dateStr: string) => {
  const [y, m, d] = dateStr.split("-").map(Number);
  const noonUtc = new Date(Date.UTC(y, m - 1, d, 4));
  return new Intl.DateTimeFormat("en-US", {
    timeZone: "Asia/Manila", weekday: "short", month: "short", day: "numeric",
  }).format(noonUtc);
};

export const EditSlotsDialog = ({ open, onOpenChange, initialSelected = [], token, onSave }: Props) => {
  const [loading, setLoading] = useState(false);
  const [payload, setPayload] = useState<Payload | null>(null);
  // "hidden" = slot ids HR removed (red X) for this candidate.
  const [hidden, setHidden] = useState<Set<string>>(new Set());
  const [busy, setBusy] = useState(false);

  // Custom slot form
  const [customDate, setCustomDate] = useState("");
  const [customTime, setCustomTime] = useState("");
  const [addingCustom, setAddingCustom] = useState(false);

  const allSlotIds = useMemo(() => {
    const ids: string[] = [];
    const byDate = payload?.slots_by_date || {};
    for (const d of Object.keys(byDate)) for (const s of byDate[d]) ids.push(s.id);
    return ids;
  }, [payload]);

  const refresh = async () => {
    setLoading(true);
    const { data } = await supabase.functions.invoke<Payload>("get-available-slots", { body: {} });
    setPayload(data || {});
    setLoading(false);
  };

  useEffect(() => {
    if (open) {
      // Derive initial "hidden" from initialSelected (curated list = what candidate SEES).
      // If initialSelected is empty → nothing hidden (default availability).
      // Otherwise → hidden = all - initialSelected (computed after refresh below).
      setHidden(new Set());
      refresh();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open]);

  // Once slots load, if HR previously curated this candidate, mark missing ones as hidden.
  useEffect(() => {
    if (!payload || initialSelected.length === 0) return;
    const visible = new Set(initialSelected);
    setHidden(new Set(allSlotIds.filter((id) => !visible.has(id))));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [payload]);

  const dates = useMemo(() => Object.keys(payload?.slots_by_date || {}).sort(), [payload]);

  const hideSlot = (id: string) => {
    setHidden((prev) => {
      const next = new Set(prev); next.add(id); return next;
    });
  };

  const restoreAll = () => setHidden(new Set());

  const hideAll = () => setHidden(new Set(allSlotIds));

  const hideAllForDay = (date: string) => {
    const daySlots = payload?.slots_by_date?.[date] || [];
    setHidden((prev) => {
      const next = new Set(prev);
      for (const s of daySlots) next.add(s.id);
      return next;
    });
  };

  const restoreAllForDay = (date: string) => {
    const daySlots = payload?.slots_by_date?.[date] || [];
    setHidden((prev) => {
      const next = new Set(prev);
      for (const s of daySlots) next.delete(s.id);
      return next;
    });
  };

  const addCustom = async () => {
    if (!customDate || !customTime) {
      toast.error("Pick a date and time");
      return;
    }
    setAddingCustom(true);
    try {
      const { data, error } = await supabase.functions.invoke<any>("add-custom-slot", {
        body: { slot_date: customDate, slot_time: customTime },
      });
      const errMsg = (data as any)?.error || error?.message;
      if (errMsg) {
        toast.error(errMsg === "slot_exists" ? "That slot already exists" : errMsg);
        return;
      }
      toast.success("Custom slot added");
      setCustomDate(""); setCustomTime("");
      await refresh();
    } finally {
      setAddingCustom(false);
    }
  };

  const save = async () => {
    // Visible = all - hidden. If nothing hidden, treat as "default availability" (null).
    const visibleIds = allSlotIds.filter((id) => !hidden.has(id));
    const ids = hidden.size === 0 ? [] : visibleIds;
    setBusy(true);
    try {
      if (token) {
        const { data, error } = await supabase.functions.invoke<any>("set-curated-slots", {
          body: { token, slot_ids: ids.length ? ids : null },
        });
        const errMsg = (data as any)?.error || error?.message;
        if (errMsg) { toast.error(errMsg); return; }
        toast.success(
          hidden.size === 0
            ? "Cleared curation — full availability"
            : `Hidden ${hidden.size} slot${hidden.size === 1 ? "" : "s"} for this candidate`,
        );
      }
      onSave?.(ids);
      onOpenChange(false);
    } finally {
      setBusy(false);
    }
  };

  const visibleCount = allSlotIds.length - hidden.size;

  return (
    <Dialog open={open} onOpenChange={(o) => !busy && onOpenChange(o)}>
      <DialogContent className="max-w-2xl max-h-[85vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <CalIcon className="h-4 w-4" /> Edit slots for this candidate
          </DialogTitle>
          <DialogDescription>
            All available slots are shown by default. Click the red <X className="inline h-3 w-3 align-text-bottom text-destructive" /> on a slot to hide it from THIS candidate only — it stays available for everyone else.
          </DialogDescription>
        </DialogHeader>

        {loading ? (
          <div className="py-10 flex justify-center"><Loader2 className="h-5 w-5 animate-spin" /></div>
        ) : (
          <div className="space-y-4">
            {dates.length === 0 && (
              <p className="text-sm text-muted-foreground text-center py-4">
                No upcoming available slots. Add a custom slot below.
              </p>
            )}
            {dates.map((d) => {
              const daySlots = payload?.slots_by_date?.[d] || [];
              const slots = daySlots.filter((s) => !hidden.has(s.id));
              const dayHiddenCount = daySlots.filter((s) => hidden.has(s.id)).length;
              return (
                <div key={d} className="space-y-2">
                  <div className="flex items-center justify-between">
                    <div className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">
                      {fmtDate(d)} <span className="font-normal normal-case">— {slots.length} shown</span>
                    </div>
                    <div className="flex items-center gap-3">
                      {slots.length > 0 && (
                        <button
                          type="button"
                          onClick={() => hideAllForDay(d)}
                          className="inline-flex items-center gap-1 text-xs text-primary hover:underline"
                        >
                          <EyeOff className="h-3 w-3" /> Hide all
                        </button>
                      )}
                      {dayHiddenCount > 0 && (
                        <button
                          type="button"
                          onClick={() => restoreAllForDay(d)}
                          className="inline-flex items-center gap-1 text-xs text-primary hover:underline"
                        >
                          <RotateCcw className="h-3 w-3" /> Restore all
                        </button>
                      )}
                    </div>
                  </div>
                  {slots.length === 0 ? (
                    <p className="text-xs text-muted-foreground italic">All slots hidden for this candidate on this day</p>
                  ) : (
                    <div className="grid grid-cols-3 sm:grid-cols-4 gap-2">
                      {slots.map((s) => (
                        <div
                          key={s.id}
                          className="relative group px-2 py-1.5 text-sm rounded border border-border bg-background"
                        >
                          <div className="text-center font-medium">{s.display_time}</div>
                          <button
                            type="button"
                            onClick={() => hideSlot(s.id)}
                            title="Hide this slot from this candidate"
                            className="absolute -top-2 -right-2 h-5 w-5 rounded-full bg-destructive text-destructive-foreground border border-background shadow-sm flex items-center justify-center hover:bg-destructive/90 transition"
                            aria-label={`Hide ${s.display_time}`}
                          >
                            <X className="h-3 w-3" />
                          </button>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              );
            })}

            <div className="border-t pt-4 space-y-2">
              <Label className="flex items-center gap-1.5 text-xs"><Plus className="h-3.5 w-3.5" /> Add custom slot (PHT)</Label>
              <div className="flex gap-2">
                <Input type="date" value={customDate} onChange={(e) => setCustomDate(e.target.value)} className="flex-1" />
                <Input type="time" value={customTime} onChange={(e) => setCustomTime(e.target.value)} className="w-32" />
                <Button type="button" size="sm" variant="outline" onClick={addCustom} disabled={addingCustom}>
                  {addingCustom ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : "Add"}
                </Button>
              </div>
              <p className="text-xs text-muted-foreground">
                Any date/time. New slot is created and immediately visible.
              </p>
            </div>
          </div>
        )}

        <DialogFooter className="gap-2 sm:gap-2">
          <div className="text-xs text-muted-foreground mr-auto self-center flex items-center gap-3">
            <span>
              {hidden.size === 0
                ? `Default availability (${visibleCount} slots shown)`
                : `${visibleCount} shown · ${hidden.size} hidden for this candidate`}
            </span>
            {hidden.size > 0 && (
              <button
                type="button"
                onClick={restoreAll}
                className="inline-flex items-center gap-1 text-primary hover:underline"
              >
                <RotateCcw className="h-3 w-3" /> Restore all
              </button>
            )}
          </div>
          <Button type="button" variant="outline" onClick={() => onOpenChange(false)} disabled={busy}>Cancel</Button>
          <Button type="button" onClick={save} disabled={busy}>
            {busy ? <Loader2 className="h-4 w-4 animate-spin" /> : "Save selection"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

export default EditSlotsDialog;
