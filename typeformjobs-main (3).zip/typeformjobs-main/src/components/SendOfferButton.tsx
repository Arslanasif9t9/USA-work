import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Send, Loader2 } from "lucide-react";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog";
import { toast } from "sonner";
import SendOfferModal from "@/components/SendOfferModal";
import { supabase } from "@/integrations/supabase/client";
import { markStageSent, type CandidateAction } from "@/lib/candidateActions";

type Props = {
  formId: string;
  responseId: string;
  candidateName: string;
  candidateEmail: string;
  nameQid?: string;
  emailQid?: string;
  action: CandidateAction | null;
  onChanged?: (a: CandidateAction) => void;
};

// Same Boss password force-complete validates against (BOSS_PASSWORD = "Boss2828").
// The attendance gate is UI-only — the send backend accepts the request regardless —
// so this client-side check is purely an HR speed-bump, not a security boundary.
const BOSS_PASSWORD = "Boss2828";

/**
 * Send Offer button for booked Round-2 candidates.
 * - Enabled directly once HR marks the Round 2 interview as "attended".
 * - Otherwise grayed: HR may still override with the Boss password (e.g. the
 *   candidate completed Round 2 outside the normal AI flow / Universal Zoom).
 */
export const SendOfferButton = ({
  formId,
  responseId,
  candidateName,
  candidateEmail,
  nameQid,
  emailQid,
  action,
  onChanged,
}: Props) => {
  const [open, setOpen] = useState(false);
  const [pwOpen, setPwOpen] = useState(false);
  const [pwValue, setPwValue] = useState("");
  const [pwBusy, setPwBusy] = useState(false);
  const [confirmOpen, setConfirmOpen] = useState(false);

  const attended = action?.round2_attendance_status === "attended";
  const noShow = action?.round2_attendance_status === "no_show";
  const offerSent = (action?.offer_status || "not_sent") !== "not_sent";

  if (offerSent) return null;

  const disabled = !attended;
  const hint = noShow
    ? "Round 2 was a no-show — rebook or disqualify (or override)"
    : !action?.round2_attendance_status
      ? "Mark Round 2 attended first (or override)"
      : "";

  const handleClick = () => {
    if (!disabled) {
      setOpen(true);
    } else {
      setPwValue("");
      setPwOpen(true);
    }
  };

  const submitPassword = () => {
    if (!pwValue) return;
    setPwBusy(true);
    const ok = pwValue === BOSS_PASSWORD;
    setPwBusy(false);
    if (!ok) {
      toast.error("Incorrect password");
      setPwValue("");
      return;
    }
    setPwOpen(false);
    setPwValue("");
    setConfirmOpen(true);
  };

  const btn = (
    <Button
      type="button"
      size="sm"
      variant={disabled ? "secondary" : "default"}
      // Locked rows stay visually gray (read as locked) but remain clickable —
      // clicking prompts for the Boss override password (see handleClick).
      className={disabled ? "bg-muted text-muted-foreground hover:bg-muted/80 border border-input cursor-pointer" : "bg-purple-600 hover:bg-purple-700 text-white"}
      onClick={handleClick}
    >
      <Send className="h-3.5 w-3.5 mr-1.5" /> Send Offer
    </Button>
  );

  return (
    <>
      {disabled && hint ? (
        <TooltipProvider delayDuration={150}>
          <Tooltip>
            <TooltipTrigger asChild><span>{btn}</span></TooltipTrigger>
            <TooltipContent>{hint}</TooltipContent>
          </Tooltip>
        </TooltipProvider>
      ) : (
        btn
      )}

      {/* Boss-password override prompt (only used when the attendance gate isn't met) */}
      <Dialog open={pwOpen} onOpenChange={(o) => { if (!pwBusy) { setPwOpen(o); if (!o) setPwValue(""); } }}>
        <DialogContent className="max-w-sm">
          <DialogHeader>
            <DialogTitle>Override required</DialogTitle>
            <DialogDescription>
              Round 2 isn't marked attended. Enter the Boss password to send the offer anyway.
            </DialogDescription>
          </DialogHeader>
          <form onSubmit={(e) => { e.preventDefault(); submitPassword(); }} className="space-y-3">
            <Input
              type="password"
              value={pwValue}
              onChange={(e) => setPwValue(e.target.value)}
              autoFocus
              placeholder="Boss password"
            />
            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => setPwOpen(false)}>Cancel</Button>
              <Button type="submit" disabled={pwBusy || !pwValue}>
                {pwBusy ? <Loader2 className="h-4 w-4 animate-spin" /> : "Unlock"}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      {/* Confirm AlertDialog after a correct Boss password */}
      <AlertDialog open={confirmOpen} onOpenChange={setConfirmOpen}>
        <AlertDialogContent className="max-w-sm">
          <AlertDialogHeader>
            <AlertDialogTitle>Override offer send?</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure this candidate completed Round 2? You're about to send the offer.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={() => { setConfirmOpen(false); setOpen(true); }}>
              Yes, send offer
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {open && action && (
        <SendOfferModal
          open={open}
          onClose={() => setOpen(false)}
          formId={formId}
          candidateName={candidateName}
          candidateEmail={candidateEmail}
          responseId={responseId}
          nameQid={nameQid}
          emailQid={emailQid}
          isResend={false}
          existingOfferId={null}
          onSaved={async (_offerRef, savedOfferId) => {
            try {
              let jobOfferId = savedOfferId || null;
              if (!jobOfferId) {
                const { data: latest } = await supabase
                  .from("job_offers")
                  .select("id")
                  .eq("form_id", formId)
                  .eq("candidate_email", candidateEmail)
                  .order("created_at", { ascending: false })
                  .limit(1)
                  .maybeSingle();
                jobOfferId = (latest as any)?.id || null;
              }
              await markStageSent(action.id, "offer", { jobOfferId: jobOfferId || undefined });
            } catch { /* server may have patched */ }
            const { data } = await supabase
              .from("candidate_actions")
              .select("*")
              .eq("id", action.id)
              .maybeSingle();
            if (data) onChanged?.(data as CandidateAction);
          }}
        />
      )}
    </>
  );
};

export default SendOfferButton;
