import { useEffect, useMemo, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Info, Loader2, ChevronLeft, ChevronRight, Check } from "lucide-react";
import {
  SchedulingConfig, BlockedSlot, Booking, generateSlotsForDate, getSlotState, Slot,
  formatTimeInTz, formatDateInTz, formatFullDateInTz, COMMON_TIMEZONES, detectBrowserTimezone,
  ymdInTz,
} from "@/lib/scheduling";

type Props = {
  questionId: string;
  value: { booking_id: string; slot_start: string; slot_end: string } | null;
  onChange: (v: any) => void;
  disabled?: boolean;
  responseId?: string;
};

const PAGE_SIZE = 7;

const ScheduleCallField = ({ questionId, value, onChange, disabled, responseId }: Props) => {
  const [config, setConfig] = useState<SchedulingConfig | null>(null);
  const [blocked, setBlocked] = useState<BlockedSlot[]>([]);
  const [bookings, setBookings] = useState<Booking[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [candidateTz, setCandidateTz] = useState<string>(detectBrowserTimezone());
  const [dateOffset, setDateOffset] = useState(0); // pages
  const [selectedDate, setSelectedDate] = useState<Date | null>(null);
  const [selectedSlot, setSelectedSlot] = useState<Slot | null>(null);
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    let cancelled = false;
    (async () => {
      setLoading(true);
      const cfg = await supabase
        .from("scheduling_configs").select("*").eq("question_id", questionId).maybeSingle();
      if (cancelled) return;
      if (cfg.error || !cfg.data) {
        setError("Scheduling is not configured for this question.");
        setLoading(false);
        return;
      }
      const c = cfg.data as any as SchedulingConfig;
      setConfig(c);
      const [b, k] = await Promise.all([
        supabase.from("scheduling_blocked_slots").select("*").eq("config_id", c.id),
        supabase.from("scheduling_bookings").select("*").eq("config_id", c.id),
      ]);
      if (cancelled) return;
      setBlocked((b.data as any) || []);
      setBookings((k.data as any) || []);
      setLoading(false);
    })();
    return () => { cancelled = true; };
  }, [questionId]);

  const refreshBookings = async () => {
    if (!config) return;
    const k = await supabase.from("scheduling_bookings").select("*").eq("config_id", config.id);
    setBookings((k.data as any) || []);
  };

  const visibleDates = useMemo(() => {
    if (!config) return [];
    const out: Date[] = [];
    const start = dateOffset * PAGE_SIZE;
    for (let i = 0; i < PAGE_SIZE; i++) {
      const d = new Date();
      d.setHours(0, 0, 0, 0);
      d.setDate(d.getDate() + start + i);
      out.push(d);
    }
    return out;
  }, [config, dateOffset]);

  const maxOffset = useMemo(() => {
    if (!config) return 0;
    return Math.max(0, Math.ceil(config.booking_window_days / PAGE_SIZE) - 1);
  }, [config]);

  const dayHasAvailable = (d: Date): boolean => {
    if (!config) return false;
    const slots = generateSlotsForDate(d, config);
    return slots.some((s) => getSlotState(s, config, blocked, bookings) === "available");
  };

  const isDateWithinWindow = (d: Date): boolean => {
    if (!config) return false;
    const today = new Date(); today.setHours(0, 0, 0, 0);
    const max = new Date(today);
    max.setDate(max.getDate() + config.booking_window_days);
    return d >= today && d <= max;
  };

  const slots = useMemo(() => {
    if (!config || !selectedDate) return [] as { slot: Slot; available: boolean }[];
    return generateSlotsForDate(selectedDate, config).map((s) => ({
      slot: s, available: getSlotState(s, config, blocked, bookings) === "available",
    }));
  }, [selectedDate, config, blocked, bookings]);

  const confirm = async () => {
    if (!config || !selectedSlot) return;
    setSubmitting(true);
    setError(null);

    // Race-condition re-check
    await refreshBookings();
    const stillFree = !bookings.some(
      (b) => (b.status === "pending_approval" || b.status === "approved")
        && new Date(b.slot_start).getTime() === selectedSlot.start.getTime(),
    );
    if (!stillFree) {
      setError("This slot was just booked by another candidate. Please choose another time.");
      setSelectedSlot(null);
      setSubmitting(false);
      return;
    }

    const { data, error: ie } = await supabase
      .from("scheduling_bookings")
      .insert({
        config_id: config.id,
        response_id: responseId || null,
        slot_start: selectedSlot.start.toISOString(),
        slot_end: selectedSlot.end.toISOString(),
        candidate_timezone: candidateTz,
        status: "pending_approval",
      })
      .select().single();
    setSubmitting(false);
    if (ie) {
      if ((ie as any).code === "23505") {
        setError("This slot was just booked by another candidate. Please choose another time.");
        setSelectedSlot(null);
        await refreshBookings();
      } else {
        setError(ie.message);
      }
      return;
    }
    onChange({
      booking_id: (data as any).id,
      slot_start: (data as any).slot_start,
      slot_end: (data as any).slot_end,
    });
  };

  if (loading) {
    return (
      <div className="flex items-center gap-2 text-sm text-muted-foreground py-6">
        <Loader2 className="h-4 w-4 animate-spin" /> Loading available times…
      </div>
    );
  }

  if (error && !config) {
    return <p className="text-sm text-destructive">{error}</p>;
  }

  if (!config) return null;

  // Confirmed state
  if (value?.booking_id) {
    return (
      <div className="rounded-lg border-2 border-primary/40 bg-primary/5 p-4 flex items-start gap-3">
        <Check className="h-5 w-5 text-primary mt-0.5" />
        <div className="flex-1">
          <p className="text-sm font-semibold">Booking confirmed (pending review)</p>
          <p className="text-sm">
            {formatFullDateInTz(new Date(value.slot_start), candidateTz)} at{" "}
            {formatTimeInTz(new Date(value.slot_start), candidateTz)} ({candidateTz})
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-5">
      {/* Disclaimer */}
      <div className="rounded-lg border border-amber-300 bg-amber-50 dark:bg-amber-900/20 p-3 flex items-start gap-2">
        <Info className="h-5 w-5 text-amber-700 dark:text-amber-400 mt-0.5 shrink-0" />
        <p className="text-sm text-amber-900 dark:text-amber-100">{config.disclaimer_text}</p>
      </div>

      {/* Timezone */}
      <div className="flex items-center gap-2 text-sm">
        <span className="text-muted-foreground">Times shown in:</span>
        <Select value={candidateTz} onValueChange={setCandidateTz}>
          <SelectTrigger className="h-8 w-auto min-w-[180px]"><SelectValue /></SelectTrigger>
          <SelectContent>
            {!COMMON_TIMEZONES.includes(candidateTz) && (
              <SelectItem value={candidateTz}>{candidateTz}</SelectItem>
            )}
            {COMMON_TIMEZONES.map((tz) => (
              <SelectItem key={tz} value={tz}>{tz}</SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      {/* Date strip */}
      <div className="flex items-center gap-2">
        <Button
          variant="ghost" size="icon"
          disabled={dateOffset === 0}
          onClick={() => { setDateOffset((o) => Math.max(0, o - 1)); setSelectedDate(null); setSelectedSlot(null); }}
        >
          <ChevronLeft className="h-4 w-4" />
        </Button>
        <div className="grid grid-cols-7 gap-1 flex-1">
          {visibleDates.map((d) => {
            const within = isDateWithinWindow(d);
            const hasSlots = within && dayHasAvailable(d);
            const isSel = selectedDate &&
              ymdInTz(d, candidateTz).y === ymdInTz(selectedDate, candidateTz).y &&
              ymdInTz(d, candidateTz).m === ymdInTz(selectedDate, candidateTz).m &&
              ymdInTz(d, candidateTz).d === ymdInTz(selectedDate, candidateTz).d;
            return (
              <button
                key={d.toISOString()}
                disabled={!hasSlots || disabled}
                onClick={() => { setSelectedDate(d); setSelectedSlot(null); }}
                className={`p-2 rounded-md text-center text-xs border-2 transition-colors min-h-[60px] ${
                  isSel ? "border-primary bg-primary/10"
                    : hasSlots ? "border-border hover:border-primary/60"
                    : "border-border opacity-40 cursor-not-allowed"
                }`}
              >
                <div className="text-[10px] uppercase text-muted-foreground">
                  {formatDateInTz(d, candidateTz).split(",")[0]}
                </div>
                <div className="text-base font-semibold">{d.getDate()}</div>
              </button>
            );
          })}
        </div>
        <Button
          variant="ghost" size="icon"
          disabled={dateOffset >= maxOffset}
          onClick={() => { setDateOffset((o) => Math.min(maxOffset, o + 1)); setSelectedDate(null); setSelectedSlot(null); }}
        >
          <ChevronRight className="h-4 w-4" />
        </Button>
      </div>

      {/* Slots */}
      {selectedDate ? (
        slots.length === 0 ? (
          <p className="text-sm text-muted-foreground text-center py-4">
            No slots available on this day. Try another date.
          </p>
        ) : slots.filter((s) => s.available).length === 0 ? (
          <p className="text-sm text-muted-foreground text-center py-4">
            All slots on this day are full or unavailable.
          </p>
        ) : (
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-2">
            {slots.filter((s) => s.available).map(({ slot }) => {
              const isSel = selectedSlot?.key === slot.key;
              return (
                <button
                  key={slot.key}
                  disabled={disabled}
                  onClick={() => setSelectedSlot(slot)}
                  className={`min-h-[44px] px-3 rounded-md border-2 text-sm font-medium transition-colors ${
                    isSel ? "border-primary bg-primary/10 text-primary"
                      : "border-border hover:border-primary/60 hover:bg-secondary/40"
                  }`}
                >
                  {formatTimeInTz(slot.start, candidateTz)}
                </button>
              );
            })}
          </div>
        )
      ) : (
        <p className="text-sm text-muted-foreground text-center py-2">
          Select a date above to see available times.
        </p>
      )}

      {/* Confirmation */}
      {selectedSlot && (
        <div className="rounded-lg border-2 border-primary/30 bg-primary/5 p-4 space-y-3">
          <p className="text-sm">
            You've selected{" "}
            <strong>{formatFullDateInTz(selectedSlot.start, candidateTz)}</strong> at{" "}
            <strong>{formatTimeInTz(selectedSlot.start, candidateTz)}</strong>{" "}
            ({candidateTz}).
          </p>
          <Button onClick={confirm} disabled={submitting || disabled}>
            {submitting ? (<><Loader2 className="h-4 w-4 mr-2 animate-spin" /> Booking…</>) : "Confirm booking"}
          </Button>
        </div>
      )}

      {error && <p className="text-sm text-destructive">{error}</p>}
    </div>
  );
};

export default ScheduleCallField;
