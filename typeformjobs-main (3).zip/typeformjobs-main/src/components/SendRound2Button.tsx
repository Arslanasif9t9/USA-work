import { useState } from "react";
import { Button } from "@/components/ui/button";
import { CalendarPlus, Loader2 } from "lucide-react";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog";
import { toast } from "sonner";
import { InviteRoundDialog } from "@/components/action-dialogs/InviteRoundDialog";
import { supabase } from "@/integrations/supabase/client";
import { markStageSent, markStageResent, type CandidateAction } from "@/lib/candidateActions";

type Props = {
  responseId: string;
  candidateName: string;
  candidateEmail: string;
  action: CandidateAction | null;
  /** Email-level R1 completion: true when THIS person (any same-email response row)
   *  completed Round 1, even if this exact row's candidate_actions isn't "attended".
   *  Enables the button without needing the Boss override for duplicate-row people. */
  r1Completed?: boolean;
  onChanged?: (a: CandidateAction) => void;
};

// Same Boss password force-complete validates against (BOSS_PASSWORD = "Boss2828").
// The attendance gate is UI-only — the send backend accepts the request regardless —
// so this client-side check is purely an HR speed-bump, not a security boundary.
const BOSS_PASSWORD = "Boss2828";

/**
 * Send Round 2 button for booked rows.
 * - Enabled directly once Round 1 attendance is marked "attended".
 * - Otherwise grayed: HR may still override with the Boss password (e.g. the
 *   candidate completed Round 1 outside the normal AI flow / Universal Zoom).
 */
export const SendRound2Button = ({ responseId, candidateName, candidateEmail, action, r1Completed, onChanged }: Props) => {
  const [open, setOpen] = useState(false);
  const [pwOpen, setPwOpen] = useState(false);
  const [pwValue, setPwValue] = useState("");
  const [pwBusy, setPwBusy] = useState(false);
  const [confirmOpen, setConfirmOpen] = useState(false);

  // Enabled when THIS row is attended OR the person completed R1 on any same-email row.
  const attended = action?.round1_attendance_status === "attended" || !!r1Completed;
  const noShow = action?.round1_attendance_status === "no_show";
  const round2Sent = action?.round2_status === "sent";

  // Additive send-count for Round 2 (mirrors the Re-Send Round 1 nudge counter).
  // Display "+N" once it's been sent at least once, with the same neutral→amber→
  // orange→red escalation. Purely cosmetic — does not affect send/enable gating.
  const sendCount = action?.round2_send_count ?? 0;



  const disabled = !attended;
  const hint = noShow
    ? "Round 1 was a no-show — rebook or disqualify (or override)"
    : !action?.round1_attendance_status
      ? "Mark Round 1 attended first (or override)"
      : "";

  const handleClick = () => {
    if (!disabled) {
      setOpen(true);
    } else {
      setPwValue("");
      setPwOpen(true);
    }
  };

  const submitPassword = () => {
    if (!pwValue) return;
    setPwBusy(true);
    const ok = pwValue === BOSS_PASSWORD;
    setPwBusy(false);
    if (!ok) {
      toast.error("Incorrect password");
      setPwValue("");
      return;
    }
    setPwOpen(false);
    setPwValue("");
    setConfirmOpen(true);
  };

  // Color escalation for the enabled button, mirroring the R1 nudge counter.
  const enabledTone =
    sendCount >= 5 ? "bg-red-600 hover:bg-red-700 text-white"
    : sendCount >= 3 ? "bg-orange-500 hover:bg-orange-600 text-white"
    : sendCount >= 1 ? "bg-amber-400 hover:bg-amber-500 text-amber-950"
    : "bg-[#1a2547] hover:bg-[#243264] text-white";

  const btn = (
    <Button
      type="button"
      size="sm"
      variant={disabled ? "secondary" : "default"}
      // Locked rows stay visually gray (read as locked) but remain clickable —
      // clicking prompts for the Boss override password (see handleClick).
      className={disabled ? "bg-muted text-muted-foreground hover:bg-muted/80 border border-input cursor-pointer" : enabledTone}
      onClick={handleClick}
    >
      <CalendarPlus className="h-3.5 w-3.5 mr-1.5" /> Send Round 2{sendCount > 0 ? ` +${sendCount}` : ""}
    </Button>
  );


  return (
    <>
      {disabled && hint ? (
        <TooltipProvider delayDuration={150}>
          <Tooltip>
            <TooltipTrigger asChild>
              <span>{btn}</span>
            </TooltipTrigger>
            <TooltipContent>{hint}</TooltipContent>
          </Tooltip>
        </TooltipProvider>
      ) : (
        btn
      )}

      {/* Boss-password override prompt (only used when the attendance gate isn't met) */}
      <Dialog open={pwOpen} onOpenChange={(o) => { if (!pwBusy) { setPwOpen(o); if (!o) setPwValue(""); } }}>
        <DialogContent className="max-w-sm">
          <DialogHeader>
            <DialogTitle>Override required</DialogTitle>
            <DialogDescription>
              Round 1 isn't marked attended. Enter the Boss password to send Round 2 anyway.
            </DialogDescription>
          </DialogHeader>
          <form onSubmit={(e) => { e.preventDefault(); submitPassword(); }} className="space-y-3">
            <Input
              type="password"
              value={pwValue}
              onChange={(e) => setPwValue(e.target.value)}
              autoFocus
              placeholder="Boss password"
            />
            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => setPwOpen(false)}>Cancel</Button>
              <Button type="submit" disabled={pwBusy || !pwValue}>
                {pwBusy ? <Loader2 className="h-4 w-4 animate-spin" /> : "Unlock"}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      {/* Confirm AlertDialog after a correct Boss password */}
      <AlertDialog open={confirmOpen} onOpenChange={setConfirmOpen}>
        <AlertDialogContent className="max-w-sm">
          <AlertDialogHeader>
            <AlertDialogTitle>Override Round 2 send?</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure this candidate completed Round 1? You're about to send the Round 2 invite.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={() => { setConfirmOpen(false); setOpen(true); }}>
              Yes, send Round 2
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {open && action && (
        <InviteRoundDialog
          open={open}
          onOpenChange={(o) => { if (!o) setOpen(false); }}
          responseId={responseId}
          round={2}
          candidateName={candidateName}
          initialEmail={candidateEmail}
          isResend={false}
          resendCount={action.round2_resend_count || 0}
          onSent={async () => {
            try {
              await markStageSent(action.id, "round2");
            } catch { /* server may have already patched */ }
            // Additive Round 2 send-count bump (display-only counter). Does not
            // touch send/email/token logic or the show/enable gating.
            try {
              await supabase
                .from("candidate_actions")
                .update({ round2_send_count: (action.round2_send_count ?? 0) + 1 })
                .eq("id", action.id);
            } catch { /* counter is best-effort */ }
            const { data } = await supabase
              .from("candidate_actions")
              .select("*")
              .eq("id", action.id)
              .maybeSingle();
            if (data) onChanged?.(data as CandidateAction);
          }}

        />
      )}
    </>
  );
};
