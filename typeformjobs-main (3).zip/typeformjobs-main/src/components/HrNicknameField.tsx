import { useEffect, useRef, useState } from "react";
import { Pencil } from "lucide-react";

/**
 * Quiet HR-only inline note per candidate (e.g. "business owner", "troll candidate").
 * Click to edit, blur or Enter saves, Escape cancels. Small, italic, muted — not a badge.
 * Display-only callers can omit onSave (renders the text without edit affordance).
 */
export function HrNicknameField({
  value,
  onSave,
}: {
  value: string;
  onSave?: (next: string) => void | Promise<void>;
}) {
  const [editing, setEditing] = useState(false);
  const [draft, setDraft] = useState(value);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (!editing) setDraft(value);
  }, [value, editing]);

  useEffect(() => {
    if (editing) inputRef.current?.focus();
  }, [editing]);

  // Read-only mode: just the muted italic text (no edit).
  if (!onSave) {
    if (!value) return null;
    return (
      <span className="text-xs italic text-muted-foreground/80 truncate max-w-[260px]">
        {value}
      </span>
    );
  }

  const commit = () => {
    setEditing(false);
    const trimmed = draft.trim();
    if (trimmed === (value || "").trim()) return;
    void onSave(trimmed);
  };

  if (editing) {
    return (
      <input
        ref={inputRef}
        value={draft}
        onChange={(e) => setDraft(e.target.value)}
        onBlur={commit}
        onKeyDown={(e) => {
          if (e.key === "Enter") {
            e.preventDefault();
            commit();
          } else if (e.key === "Escape") {
            setDraft(value);
            setEditing(false);
          }
        }}
        placeholder="Add a note…"
        className="w-full max-w-[220px] bg-transparent border-b border-dashed border-border text-xs italic text-muted-foreground focus:outline-none focus:border-primary py-0.5"
      />
    );
  }

  return (
    <button
      type="button"
      onClick={() => setEditing(true)}
      className="group inline-flex items-center gap-1 text-xs italic text-muted-foreground hover:text-foreground transition-colors max-w-[260px]"
      title="HR note"
    >
      <span className={value ? "truncate" : "opacity-50"}>{value || "Add a note…"}</span>
      <Pencil className="h-3 w-3 opacity-0 group-hover:opacity-60 shrink-0" />
    </button>
  );
}
