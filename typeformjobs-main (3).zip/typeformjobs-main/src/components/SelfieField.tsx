import { useEffect, useRef, useState, useCallback } from "react";
import { Camera, Check, RotateCcw, X, Upload as UploadIcon, AlertTriangle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { supabase } from "@/integrations/supabase/client";
import { cn } from "@/lib/utils";

type Props = {
  value?: any;
  onChange: (v: any) => void;
  disabled?: boolean;
  formId?: string;
  questionId: string;
  uploadSessionId?: string;
  setError: (e: string | null) => void;
};

const BUCKET = "candidate-files";

export const SelfieField = ({ value, onChange, disabled, formId, questionId, uploadSessionId, setError }: Props) => {
  const [open, setOpen] = useState(false);
  const [stream, setStream] = useState<MediaStream | null>(null);
  const [permError, setPermError] = useState<string | null>(null);
  const [captured, setCaptured] = useState<Blob | null>(null);
  const [capturedUrl, setCapturedUrl] = useState<string | null>(null);
  const [uploading, setUploading] = useState(false);
  const [progress, setProgress] = useState(0);
  const [uploadDone, setUploadDone] = useState(false);
  const [uploadError, setUploadError] = useState(false);
  const [tooDark, setTooDark] = useState(false);
  const [faceCenterOk, setFaceCenterOk] = useState(true); // simple, always ok unless dark
  const videoRef = useRef<HTMLVideoElement>(null);
  const sampleCanvasRef = useRef<HTMLCanvasElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const sampleTimerRef = useRef<number | null>(null);
  const progressTimerRef = useRef<number | null>(null);

  const stopStream = useCallback(() => {
    if (stream) {
      stream.getTracks().forEach((t) => t.stop());
    }
    setStream(null);
  }, [stream]);

  const cleanup = useCallback(() => {
    stopStream();
    if (sampleTimerRef.current) {
      window.clearInterval(sampleTimerRef.current);
      sampleTimerRef.current = null;
    }
    if (progressTimerRef.current) {
      window.clearInterval(progressTimerRef.current);
      progressTimerRef.current = null;
    }
    if (capturedUrl) URL.revokeObjectURL(capturedUrl);
    setCapturedUrl(null);
    setCaptured(null);
    setProgress(0);
    setUploading(false);
    setUploadDone(false);
    setUploadError(false);
    setTooDark(false);
  }, [stopStream, capturedUrl]);

  const closeModal = useCallback(() => {
    cleanup();
    setOpen(false);
    document.body.style.overflow = "";
  }, [cleanup]);

  const startCamera = async () => {
    setError(null);
    setPermError(null);
    if (!navigator.mediaDevices?.getUserMedia) {
      setPermError("Camera not supported on this device.");
      return;
    }
    try {
      const s = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: "user", width: { ideal: 1280 }, height: { ideal: 720 } },
        audio: false,
      });
      setStream(s);
      setOpen(true);
      document.body.style.overflow = "hidden";
    } catch (e: any) {
      setPermError(e?.message || "Camera permission denied or unavailable.");
    }
  };

  // Attach stream to video
  useEffect(() => {
    if (videoRef.current && stream) {
      videoRef.current.srcObject = stream;
      videoRef.current.play().catch(() => {});
    }
  }, [stream]);

  // Brightness sampling loop
  useEffect(() => {
    if (!stream || captured) return;
    const sample = () => {
      const v = videoRef.current;
      const c = sampleCanvasRef.current;
      if (!v || !c || v.readyState < 2) return;
      const w = 64, h = 48;
      c.width = w; c.height = h;
      const ctx = c.getContext("2d");
      if (!ctx) return;
      try {
        ctx.drawImage(v, 0, 0, w, h);
        const data = ctx.getImageData(0, 0, w, h).data;
        let sum = 0;
        for (let i = 0; i < data.length; i += 4) {
          sum += 0.299 * data[i] + 0.587 * data[i + 1] + 0.114 * data[i + 2];
        }
        const avg = sum / (w * h);
        setTooDark(avg < 60);
      } catch {}
    };
    sample();
    sampleTimerRef.current = window.setInterval(sample, 500);
    return () => {
      if (sampleTimerRef.current) {
        window.clearInterval(sampleTimerRef.current);
        sampleTimerRef.current = null;
      }
    };
  }, [stream, captured]);

  const capture = () => {
    const v = videoRef.current;
    if (!v) return;
    const w = v.videoWidth || 1280;
    const h = v.videoHeight || 720;
    const canvas = document.createElement("canvas");
    canvas.width = w;
    canvas.height = h;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    ctx.drawImage(v, 0, 0, w, h);
    canvas.toBlob(
      (blob) => {
        if (!blob) return;
        setCaptured(blob);
        setCapturedUrl(URL.createObjectURL(blob));
        // Stop tracks while reviewing to free camera light
        stopStream();
      },
      "image/jpeg",
      0.85,
    );
  };

  const retake = async () => {
    if (capturedUrl) URL.revokeObjectURL(capturedUrl);
    setCaptured(null);
    setCapturedUrl(null);
    setUploadError(false);
    // restart camera
    try {
      const s = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: "user" },
        audio: false,
      });
      setStream(s);
    } catch (e: any) {
      setPermError(e?.message || "Camera unavailable");
    }
  };

  const startProgressSimulation = () => {
    setProgress(0);
    progressTimerRef.current = window.setInterval(() => {
      setProgress((p) => {
        if (p >= 90) return p;
        return Math.min(90, p + Math.max(1, (90 - p) * 0.08));
      });
    }, 120);
  };

  const finishProgress = () => {
    if (progressTimerRef.current) {
      window.clearInterval(progressTimerRef.current);
      progressTimerRef.current = null;
    }
    setProgress(100);
  };

  const upload = async () => {
    if (!captured) return;
    setUploading(true);
    setUploadError(false);
    setUploadDone(false);
    startProgressSimulation();
    const ts = Date.now();
    const sessionId =
      uploadSessionId ||
      sessionStorage.getItem("candidate_id") ||
      (() => {
        const id = crypto.randomUUID();
        sessionStorage.setItem("candidate_id", id);
        return id;
      })();
    const path = `responses/${sessionId}/questions/${questionId}/${ts}.jpg`;
    const file = new File([captured], `${ts}.jpg`, { type: "image/jpeg" });
    const { error: upErr } = await supabase.storage.from(BUCKET).upload(path, file, {
      contentType: "image/jpeg",
      upsert: false,
    });
    if (upErr) {
      finishProgress();
      setUploadError(true);
      setUploading(false);
      return;
    }
    finishProgress();
    setUploadDone(true);
    onChange({
      bucket: BUCKET,
      path,
      name: `${ts}.jpg`,
      size: captured.size,
      type: "image/jpeg",
    });
    window.setTimeout(() => {
      closeModal();
    }, 1100);
  };

  const onFallbackFile = async (file: File) => {
    setError(null);
    setUploading(true);
    setProgress(0);
    startProgressSimulation();
    const ts = Date.now();
    const sessionId =
      uploadSessionId ||
      sessionStorage.getItem("candidate_id") ||
      (() => {
        const id = crypto.randomUUID();
        sessionStorage.setItem("candidate_id", id);
        return id;
      })();
    const ext = (file.name.split(".").pop() || "jpg").toLowerCase();
    const path = `responses/${sessionId}/questions/${questionId}/${ts}.${ext}`;
    const { error: upErr } = await supabase.storage.from(BUCKET).upload(path, file, {
      upsert: false,
    });
    finishProgress();
    setUploading(false);
    if (upErr) {
      console.error("Selfie upload failed:", upErr);
      setError("Upload failed. Please try again.");
      return;
    }
    onChange({
      bucket: BUCKET,
      path,
      name: file.name,
      size: file.size,
      type: file.type,
    });
  };

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      if (stream) stream.getTracks().forEach((t) => t.stop());
      if (progressTimerRef.current) window.clearInterval(progressTimerRef.current);
      if (sampleTimerRef.current) window.clearInterval(sampleTimerRef.current);
      if (capturedUrl) URL.revokeObjectURL(capturedUrl);
      document.body.style.overflow = "";
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // ESC closes
  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") closeModal();
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [open, closeModal]);

  if (value && value.path) {
    return (
      <div className="space-y-3">
        <p className="text-xs text-muted-foreground">
          Your photo is stored securely and only visible to the hiring team.
        </p>
        <div className="border-2 border-border rounded-lg p-4 flex items-center gap-3">
          <div className="h-14 w-14 rounded-md bg-secondary flex items-center justify-center overflow-hidden">
            <Camera className="h-6 w-6 text-muted-foreground" />
          </div>
          <div className="flex-1 min-w-0">
            <div className="text-sm font-medium truncate">Selfie captured</div>
            <div className="text-xs text-muted-foreground">{(value.size / 1024).toFixed(1)} KB</div>
          </div>
          <button
            type="button"
            disabled={disabled}
            onClick={() => { onChange(null); startCamera(); }}
            className="text-sm text-muted-foreground hover:text-foreground underline"
          >
            Retake
          </button>
          <button
            type="button"
            disabled={disabled}
            onClick={() => onChange(null)}
            className="p-1 text-muted-foreground hover:text-destructive"
            aria-label="Remove"
          >
            <X className="h-4 w-4" />
          </button>
        </div>
      </div>
    );
  }

  return (
    <>
      <div className="space-y-3">
        <p className="text-xs text-muted-foreground">
          🔒 Your photo is stored securely and only visible to the hiring team.
        </p>
        {permError ? (
          <div className="space-y-3">
            <div className="rounded-lg border border-amber-500/40 bg-amber-500/5 p-3 text-sm">
              Camera unavailable — upload a photo instead.
            </div>
            <Button
              type="button"
              disabled={disabled}
              onClick={() => fileInputRef.current?.click()}
              className="h-11"
            >
              <UploadIcon className="h-4 w-4 mr-2" /> Upload a photo
            </Button>
            <input
              ref={fileInputRef}
              type="file"
              accept="image/*"
              capture="user"
              className="hidden"
              onChange={(e) => {
                const f = e.target.files?.[0];
                if (f) onFallbackFile(f);
              }}
            />
          </div>
        ) : (
          <Button
            type="button"
            disabled={disabled}
            onClick={startCamera}
            className="h-12 px-6 text-base bg-gradient-to-r from-[#00f0ff] to-[#ff00e5] text-black hover:opacity-90 font-semibold shadow-lg"
          >
            <Camera className="h-5 w-5 mr-2" /> Take Selfie
          </Button>
        )}
      </div>

      {open && (
        <SelfieModal
          videoRef={videoRef}
          sampleCanvasRef={sampleCanvasRef}
          captured={!!captured}
          capturedUrl={capturedUrl}
          tooDark={tooDark}
          faceCenterOk={faceCenterOk}
          uploading={uploading}
          uploadDone={uploadDone}
          uploadError={uploadError}
          progress={progress}
          onCapture={capture}
          onRetake={retake}
          onUse={upload}
          onCancel={closeModal}
        />
      )}
    </>
  );
};

// ─── Modal ───
type ModalProps = {
  videoRef: React.RefObject<HTMLVideoElement>;
  sampleCanvasRef: React.RefObject<HTMLCanvasElement>;
  captured: boolean;
  capturedUrl: string | null;
  tooDark: boolean;
  faceCenterOk: boolean;
  uploading: boolean;
  uploadDone: boolean;
  uploadError: boolean;
  progress: number;
  onCapture: () => void;
  onRetake: () => void;
  onUse: () => void;
  onCancel: () => void;
};

const SelfieModal = ({
  videoRef,
  sampleCanvasRef,
  captured,
  capturedUrl,
  tooDark,
  faceCenterOk,
  uploading,
  uploadDone,
  uploadError,
  progress,
  onCapture,
  onRetake,
  onUse,
  onCancel,
}: ModalProps) => {
  const StatusLine = ({ ok, label, warning }: { ok: boolean | null; label: string; warning?: string }) => {
    let color = "text-zinc-400";
    let icon: React.ReactNode = <span className="inline-block h-2 w-2 rounded-full bg-zinc-500" />;
    if (ok === true) {
      color = "text-emerald-400";
      icon = <Check className="h-4 w-4" />;
    } else if (ok === false) {
      color = "text-amber-400";
      icon = <AlertTriangle className="h-4 w-4" />;
    }
    return (
      <li className={cn("flex items-center gap-2 text-sm md:text-base", color)}>
        <span className="w-5 inline-flex justify-center">{icon}</span>
        <span>{warning && ok === false ? warning : label}</span>
      </li>
    );
  };

  return (
    <div
      className="fixed inset-0 z-[100] flex items-center justify-center selfie-modal-backdrop"
      role="dialog"
      aria-modal="true"
      aria-label="Selfie capture"
    >
      <style>{`
        @keyframes selfieGlow { 0%,100% { opacity: .7 } 50% { opacity: 1 } }
        @keyframes selfieRingPulse { 0%,100% { opacity:.5; transform: translate(-50%,-50%) scale(1) } 50% { opacity:.8; transform: translate(-50%,-50%) scale(1.03) } }
        @keyframes selfieCheckPop { 0% { transform: scale(0) } 60% { transform: scale(1.2) } 100% { transform: scale(1) } }
        .selfie-modal-backdrop { background: rgba(0,0,0,0.92); }
        .selfie-frame {
          position: relative; border-radius: 16px; overflow: hidden;
          background: #000;
          border: 3px solid transparent;
          background-image: linear-gradient(#000,#000), linear-gradient(135deg,#00f0ff 0%, #ff00e5 100%);
          background-origin: border-box; background-clip: padding-box, border-box;
          box-shadow: 0 0 20px 2px rgba(0,240,255,0.55), 0 0 30px 6px rgba(255,0,229,0.45);
          animation: selfieGlow 2s ease-in-out infinite;
        }
        .selfie-vignette { position:absolute; inset:0; pointer-events:none; box-shadow: inset 0 0 80px 20px rgba(0,0,0,0.55); border-radius: 13px; }
        .selfie-circle { position: absolute; left: 50%; top: 50%; width: 60%; aspect-ratio: 1/1; border-radius: 50%; border: 2px dashed rgba(0,240,255,0.5); transform: translate(-50%,-50%); pointer-events:none; animation: selfieRingPulse 2.4s ease-in-out infinite; }
        .selfie-circle-label { position:absolute; left:50%; bottom: 14%; transform: translateX(-50%); color: rgba(255,255,255,0.85); font-size: 12px; text-shadow: 0 1px 2px rgba(0,0,0,.6); pointer-events:none; }
        .selfie-cta { background: linear-gradient(135deg,#00f0ff 0%, #ff00e5 100%); color: #000; font-weight: 700; transition: transform .15s ease, filter .15s ease; }
        .selfie-cta:hover { transform: scale(1.02); filter: brightness(1.1); }
        .selfie-progress-ring { transform: rotate(-90deg); }
        .selfie-check-pop { animation: selfieCheckPop .5s ease-out forwards; }
        @media (prefers-reduced-motion: reduce) {
          .selfie-frame { animation: none }
          .selfie-circle { animation: none }
        }
      `}</style>

      <canvas ref={sampleCanvasRef} className="hidden" aria-hidden="true" />

      <div className="w-full max-w-[480px] mx-auto px-4 py-6 max-h-screen overflow-y-auto">
        {/* Status checklist */}
        {!uploading && !uploadDone && (
          <ul className="mb-3 space-y-1 text-white" aria-live="polite">
            <StatusLine ok={true} label="Look at the center of the camera" />
            <StatusLine
              ok={tooDark ? false : true}
              label="Lighting looks good"
              warning="⚠ Lighting is dim — try moving to a brighter area"
            />
            <StatusLine ok={faceCenterOk ? true : null} label="Face detected in frame" />
          </ul>
        )}

        {/* Frame area */}
        <div className="selfie-frame aspect-[4/5] w-full">
          {captured && capturedUrl ? (
            <>
              <img
                src={capturedUrl}
                alt="Captured selfie"
                className="absolute inset-0 w-full h-full object-cover"
              />
              {uploading && (
                <div className="absolute inset-0 bg-black/60 flex flex-col items-center justify-center gap-3 text-white">
                  <ProgressRing progress={progress} done={uploadDone} thumb={capturedUrl} />
                  <p className="text-sm">
                    {uploadDone ? "✓ Upload successful" : uploadError ? "Upload failed — please try again" : "Uploading your selfie..."}
                  </p>
                </div>
              )}
              {uploadDone && !uploading && (
                <div className="absolute inset-0 bg-black/60 flex flex-col items-center justify-center gap-3 text-white">
                  <div className="h-16 w-16 rounded-full bg-emerald-500/20 border-2 border-emerald-400 flex items-center justify-center selfie-check-pop">
                    <Check className="h-8 w-8 text-emerald-300" />
                  </div>
                  <p className="text-sm">✓ Upload successful</p>
                </div>
              )}
            </>
          ) : (
            <>
              <video
                ref={videoRef}
                playsInline
                muted
                autoPlay
                className="absolute inset-0 w-full h-full object-cover"
              />
              <div className="selfie-vignette" />
              <div className="selfie-circle" />
              <div className="selfie-circle-label">Align your face inside the circle</div>
            </>
          )}
        </div>

        {/* Brightness banner */}
        {tooDark && !captured && !uploading && (
          <div className="mt-3 rounded-md bg-amber-500/15 border border-amber-500/40 text-amber-200 text-xs px-3 py-2 transition-opacity">
            Low light detected. You can still capture, but a brighter photo is recommended.
          </div>
        )}

        {/* Actions */}
        {!uploading && !uploadDone && !uploadError && (
          <div className="mt-4 space-y-2">
            {captured ? (
              <div className="flex gap-2">
                <Button
                  variant="outline"
                  onClick={onRetake}
                  className="flex-1 h-12 border-white/30 bg-transparent text-white hover:bg-white/10 hover:text-white"
                  aria-label="Retake photo"
                >
                  <RotateCcw className="h-4 w-4 mr-2" /> Retake
                </Button>
                <Button
                  onClick={onUse}
                  className="flex-1 h-12 selfie-cta"
                  aria-label="Use this photo"
                >
                  <Check className="h-4 w-4 mr-2" /> Use This Photo
                </Button>
              </div>
            ) : (
              <Button
                onClick={onCapture}
                className="w-full h-12 selfie-cta text-base"
                aria-label="Capture selfie"
              >
                📸 Capture Selfie
              </Button>
            )}
            <button
              type="button"
              onClick={onCancel}
              className="w-full text-center text-sm text-white/70 hover:text-white py-2"
              aria-label="Cancel and close camera"
            >
              Cancel
            </button>
          </div>
        )}

        {uploadError && (
          <div className="mt-4 flex gap-2">
            <Button
              variant="outline"
              onClick={onUse}
              className="flex-1 h-11 border-white/30 bg-transparent text-white hover:bg-white/10 hover:text-white"
            >
              Retry
            </Button>
            <Button
              onClick={onRetake}
              className="flex-1 h-11 selfie-cta"
            >
              Use Different Photo
            </Button>
          </div>
        )}
      </div>
    </div>
  );
};

const ProgressRing = ({ progress, done, thumb }: { progress: number; done: boolean; thumb: string }) => {
  const size = 120;
  const stroke = 8;
  const r = (size - stroke) / 2;
  const c = 2 * Math.PI * r;
  const off = c - (Math.min(100, Math.max(0, progress)) / 100) * c;
  const id = "selfieRingGrad";
  return (
    <div className="relative" style={{ width: size, height: size }}>
      <svg width={size} height={size} className="selfie-progress-ring">
        <defs>
          <linearGradient id={id} x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#00f0ff" />
            <stop offset="100%" stopColor="#ff00e5" />
          </linearGradient>
        </defs>
        <circle cx={size / 2} cy={size / 2} r={r} stroke="rgba(255,255,255,0.15)" strokeWidth={stroke} fill="none" />
        <circle
          cx={size / 2}
          cy={size / 2}
          r={r}
          stroke={`url(#${id})`}
          strokeWidth={stroke}
          fill="none"
          strokeLinecap="round"
          strokeDasharray={c}
          strokeDashoffset={off}
          style={{ transition: "stroke-dashoffset 200ms ease" }}
        />
      </svg>
      <div className="absolute inset-0 flex items-center justify-center">
        <div className="h-[72px] w-[72px] rounded-full overflow-hidden border border-white/20">
          <img src={thumb} alt="" className="w-full h-full object-cover opacity-70" />
        </div>
      </div>
      <div className="absolute inset-0 flex items-center justify-center">
        <span className="text-white font-semibold text-sm drop-shadow">{done ? "100%" : `${Math.floor(progress)}%`}</span>
      </div>
    </div>
  );
};

export default SelfieField;
