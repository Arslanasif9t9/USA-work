import { useState, useMemo, useEffect } from "react";
import { format } from "date-fns";
import { Calendar as CalendarIcon, CheckCircle2 } from "lucide-react";
import { DayPicker } from "react-day-picker";
import "react-day-picker/dist/style.css";
import { cn } from "@/lib/utils";

type Props = {
  value?: string | null; // ISO yyyy-MM-dd
  onChange: (v: string | null) => void;
  disabled?: boolean;
  error?: boolean;
  format?: string;
  minDate?: string;
  maxDate?: string;
  placeholder?: string;
  variant?: "underline" | "input";
  /** Fires true when user changed month/year dropdown but hasn't committed a day yet. */
  onPendingChange?: (pending: boolean) => void;
};

const FMT_MAP: Record<string, string> = {
  "MMM D, YYYY": "MMM d, yyyy",
  "DD/MM/YYYY": "dd/MM/yyyy",
  "MM/DD/YYYY": "MM/dd/yyyy",
  "YYYY-MM-DD": "yyyy-MM-dd",
};

const toISO = (d: Date) => {
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, "0");
  const day = String(d.getDate()).padStart(2, "0");
  return `${y}-${m}-${day}`;
};

const parseISO = (s?: string | null) => {
  if (!s) return undefined;
  const [y, m, d] = s.split("-").map(Number);
  if (!y || !m || !d) return undefined;
  return new Date(y, m - 1, d);
};

export const DatePicker = ({
  value,
  onChange,
  disabled,
  error,
  format: fmtToken = "MMM D, YYYY",
  minDate,
  maxDate,
  placeholder = "Select a date",
  variant = "underline",
  onPendingChange,
}: Props) => {
  const selected = parseISO(value);
  const min = parseISO(minDate);
  const max = parseISO(maxDate);
  const [open, setOpen] = useState(false);
  const [month, setMonth] = useState<Date>(selected || new Date());
  const [pendingDay, setPendingDay] = useState(false);

  const display = FMT_MAP[fmtToken] || "MMM d, yyyy";
  const triggerLabel = selected ? format(selected, display) : placeholder;

  const now = new Date();
  const fromYear = useMemo(() => (min ? min.getFullYear() : now.getFullYear() - 100), [min]);
  const toYear = useMemo(() => (max ? max.getFullYear() : now.getFullYear() + 10), [max]);

  // Close on outside click
  const handleBlur = (e: React.FocusEvent) => {
    if (!e.currentTarget.contains(e.relatedTarget as Node)) setOpen(false);
  };

  // Treat any month/year navigation as a pending state until the user taps a day.
  const handleMonthChange = (m: Date) => {
    setMonth(m);
    setPendingDay(true);
    onPendingChange?.(true);
  };

  // If the committed value changes externally (or matches the visible month), clear pending.
  useEffect(() => {
    if (selected) {
      setPendingDay(false);
      onPendingChange?.(false);
    }
  }, [value]); // eslint-disable-line react-hooks/exhaustive-deps

  const monthLongLabel = month.toLocaleString("en-US", { month: "long" });
  const yearLabel = month.getFullYear();

  return (
    <div className="relative inline-block w-full" onBlur={handleBlur}>
      {variant === "underline" ? (
        <button
          type="button"
          disabled={disabled}
          onClick={() => !disabled && setOpen((o) => !o)}
          className={cn(
            "w-full flex items-center gap-3 border-b-2 pb-2 text-left bg-transparent outline-none",
            error ? "border-destructive" : "border-input focus:border-primary hover:border-primary/60",
            disabled && "opacity-60 cursor-not-allowed",
          )}
        >
          <CalendarIcon className="h-5 w-5 opacity-60" />
          <span className={cn("flex-1 text-xl md:text-2xl", !selected && "text-muted-foreground/50")}>
            {triggerLabel}
          </span>
        </button>
      ) : (
        <button
          type="button"
          disabled={disabled}
          onClick={() => !disabled && setOpen((o) => !o)}
          className={cn(
            "w-full flex items-center gap-2 h-10 px-3 rounded-md border border-input bg-background text-sm text-left outline-none focus:border-primary",
            disabled && "opacity-60 cursor-not-allowed",
          )}
        >
          <CalendarIcon className="h-4 w-4 opacity-60" />
          <span className={cn("flex-1", !selected && "text-muted-foreground")}>{triggerLabel}</span>
        </button>
      )}

      {open && (
        <div
          tabIndex={-1}
          className="absolute z-50 mt-2 rounded-xl border bg-popover text-popover-foreground shadow-lg p-3 animate-in fade-in-0 zoom-in-95 duration-150"
          style={{ left: 0 }}
        >
          <DayPicker
            mode="single"
            selected={selected}
            month={month}
            onMonthChange={handleMonthChange}
            onSelect={(d) => {
              if (d) {
                setPendingDay(false);
                onPendingChange?.(false);
                onChange(toISO(d));
                setOpen(false);
              }
            }}
            captionLayout="dropdown-buttons"
            fromYear={fromYear}
            toYear={toYear}
            disabled={[
              ...(min ? [{ before: min }] : []),
              ...(max ? [{ after: max }] : []),
            ] as any}
            showOutsideDays
            className="pointer-events-auto"
            classNames={{
              months: "flex flex-col",
              month: "space-y-3",
              caption: "flex justify-center pt-1 relative items-center",
              caption_label: "hidden",
              caption_dropdowns: "flex gap-2",
              dropdown: "bg-background border border-input rounded-md px-3 py-2 text-base min-h-[44px] outline-none focus:border-primary",
              dropdown_month: "",
              dropdown_year: "",
              nav: "hidden",
              table: "w-full border-collapse",
              head_row: "flex",
              head_cell: "text-muted-foreground rounded-md w-11 font-normal text-[0.75rem]",
              row: "flex w-full mt-1",
              cell: "h-11 w-11 text-center text-sm p-0 relative",
              day: "h-11 w-11 p-0 font-normal rounded-md hover:bg-secondary aria-selected:opacity-100",
              day_selected: "bg-primary text-primary-foreground hover:bg-primary",
              day_today: "ring-1 ring-primary/40",
              day_outside: "text-muted-foreground/40",
              day_disabled: "opacity-30 cursor-not-allowed",
            }}
          />

          {/* Live-updating guidance / confirmation line */}
          <div className="px-1 pt-1 min-h-[2.5rem]">
            {pendingDay ? (
              <p className="text-sm font-medium text-primary leading-snug" role="status" aria-live="polite">
                You selected {monthLongLabel} {yearLabel}. Now tap the day you were born to confirm.
              </p>
            ) : selected ? (
              <p className="text-sm font-medium text-emerald-600 leading-snug inline-flex items-center gap-1.5">
                <CheckCircle2 className="h-4 w-4 shrink-0" />
                Date of birth set: {format(selected, display)}
              </p>
            ) : (
              <p className="text-sm text-muted-foreground leading-snug">
                Pick the month, year, then tap the exact day.
              </p>
            )}
          </div>

          <div className="flex items-center justify-between pt-2 mt-1 border-t">
            <button
              type="button"
              onClick={() => {
                const t = new Date();
                setMonth(t);
                setPendingDay(false);
                onPendingChange?.(false);
                onChange(toISO(t));
                setOpen(false);
              }}
              className="text-xs text-muted-foreground hover:text-foreground transition-colors min-h-[44px] px-2"
            >
              Today
            </button>
            {selected && (
              <button
                type="button"
                onClick={() => {
                  setPendingDay(false);
                  onPendingChange?.(false);
                  onChange(null);
                  setOpen(false);
                }}
                className="text-xs text-muted-foreground hover:text-foreground transition-colors min-h-[44px] px-2"
              >
                Clear
              </button>
            )}
          </div>
        </div>
      )}
    </div>
  );
};

export default DatePicker;
