import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Loader2, Save, Lock, Pencil } from "lucide-react";
import { toast } from "sonner";
import { useHrIdentity } from "@/hooks/useHrIdentity";

type Props = {
  open: boolean;
  onClose: () => void;
  responseId: string | null;
  /** Fallback values from the signed offer when no onboarding submission exists yet. */
  fallbackName?: string;
  fallbackEmail?: string;
  fallbackPosition?: string;
  /** Called after a successful save so the parent row can refresh. */
  onSaved?: () => void;
};

export function EditEmployeeDetailsDialog({
  open,
  onClose,
  responseId,
  fallbackName,
  fallbackEmail,
  fallbackPosition,
  onSaved,
}: Props) {
  const { hrId } = useHrIdentity();
  const [loading, setLoading] = useState(false);
  const [saving, setSaving] = useState(false);

  // Onboarding submission text fields
  const [fullName, setFullName] = useState("");
  const [email, setEmail] = useState("");
  const [position, setPosition] = useState("");
  const [phone, setPhone] = useState("");

  // HR-only fields (hr_candidate_extras)
  const [bank, setBank] = useState("");
  const [gcash, setGcash] = useState("");
  const [other, setOther] = useState("");

  useEffect(() => {
    if (!open || !responseId) return;
    let active = true;
    setLoading(true);
    (async () => {
      const [{ data: sub }, { data: extras }] = await Promise.all([
        (supabase.from("onboarding_submissions") as any)
          .select("full_name, email, position_title, phone")
          .eq("response_id", responseId)
          .maybeSingle(),
        (supabase.from("hr_candidate_extras") as any)
          .select("bank_account_details, digital_pay_gcash, other_notes")
          .eq("response_id", responseId)
          .maybeSingle(),
      ]);
      if (!active) return;
      setFullName(sub?.full_name ?? fallbackName ?? "");
      setEmail(sub?.email ?? fallbackEmail ?? "");
      setPosition(sub?.position_title ?? fallbackPosition ?? "");
      setPhone(sub?.phone ?? "");
      setBank(extras?.bank_account_details ?? "");
      setGcash(extras?.digital_pay_gcash ?? "");
      setOther(extras?.other_notes ?? "");
      setLoading(false);
    })();
    return () => { active = false; };
  }, [open, responseId, fallbackName, fallbackEmail, fallbackPosition]);

  const save = async () => {
    if (!responseId) return;
    setSaving(true);
    try {
      // Update onboarding submission text fields. Upsert so it works whether the
      // candidate already submitted the form or the link was only sent.
      // Empty values are persisted as null so HR can clear a field.
      const { error: subErr } = await (supabase.from("onboarding_submissions") as any).upsert({
        response_id: responseId,
        full_name: fullName.trim() || null,
        email: email.trim() || null,
        position_title: position.trim() || null,
        phone: phone.trim() || null,
      }, { onConflict: "response_id" });
      if (subErr) throw subErr;

      // Update HR-only payment/notes fields.
      const { error: extrasErr } = await (supabase.from("hr_candidate_extras") as any).upsert({
        response_id: responseId,
        bank_account_details: bank.trim() || null,
        digital_pay_gcash: gcash.trim() || null,
        other_notes: other.trim() || null,
        updated_by_hr_id: hrId || null,
      }, { onConflict: "response_id" });
      if (extrasErr) throw extrasErr;

      toast.success("Employee details saved");
      onSaved?.();
      onClose();
    } catch (e: any) {
      toast.error(e?.message || "Save failed");
    } finally {
      setSaving(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={(o) => { if (!o && !saving) onClose(); }}>
      <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2" style={{ color: "#1a2547" }}>
            <Pencil className="h-4 w-4" /> Edit Employee Details
          </DialogTitle>
          <DialogDescription>
            Update this employee's onboarding details. All fields are editable any time.
          </DialogDescription>
        </DialogHeader>

        {loading ? (
          <div className="py-8 flex justify-center"><Loader2 className="h-5 w-5 animate-spin text-muted-foreground" /></div>
        ) : (
          <div className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="edit-fullname">Full Name</Label>
              <Input
                id="edit-fullname"
                value={fullName}
                onChange={(e) => setFullName(e.target.value)}
                placeholder="Full name"
                className="min-h-[44px]"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="edit-email">Email</Label>
              <Input
                id="edit-email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="name@example.com"
                className="min-h-[44px]"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="edit-position">Position</Label>
              <Input
                id="edit-position"
                value={position}
                onChange={(e) => setPosition(e.target.value)}
                placeholder="Position / role title"
                className="min-h-[44px]"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="edit-phone">Phone <span className="text-muted-foreground font-normal">(optional)</span></Label>
              <Input
                id="edit-phone"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                placeholder="e.g. +63 9XX XXX XXXX"
                className="min-h-[44px]"
              />
            </div>

            <div className="pt-2 border-t">
              <div className="flex items-center gap-2 text-sm font-semibold pt-3 pb-1" style={{ color: "#b08d57" }}>
                <Lock className="h-3.5 w-3.5" /> HR Only — never shown to the candidate
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor="edit-bank">Bank Account Details <span className="text-muted-foreground font-normal">(optional)</span></Label>
              <Textarea
                id="edit-bank"
                value={bank}
                onChange={(e) => setBank(e.target.value)}
                rows={3}
                placeholder="Bank name, account name, account number, branch…"
                className="min-h-[88px]"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="edit-gcash">Digital Pay / GCash <span className="text-muted-foreground font-normal">(optional)</span></Label>
              <Input
                id="edit-gcash"
                value={gcash}
                onChange={(e) => setGcash(e.target.value)}
                placeholder="e.g. GCash +63 9XX XXX XXXX"
                className="min-h-[44px]"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="edit-other">Others <span className="text-muted-foreground font-normal">(optional)</span></Label>
              <Textarea
                id="edit-other"
                value={other}
                onChange={(e) => setOther(e.target.value)}
                rows={3}
                placeholder="Any other HR-only notes…"
                className="min-h-[88px]"
              />
            </div>
          </div>
        )}

        <DialogFooter>
          <Button variant="outline" onClick={onClose} disabled={saving} className="min-h-[44px]">Cancel</Button>
          <Button
            onClick={save}
            disabled={saving || loading || !responseId}
            className="min-h-[44px]"
            style={{ background: "#1a2547", color: "white" }}
          >
            {saving ? <><Loader2 className="h-4 w-4 mr-1.5 animate-spin" /> Saving…</> : <><Save className="h-4 w-4 mr-1.5" /> Save</>}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
