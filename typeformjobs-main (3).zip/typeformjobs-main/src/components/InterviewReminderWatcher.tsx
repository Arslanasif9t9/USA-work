import { useEffect, useRef, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useHrIdentity } from "@/hooks/useHrIdentity";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { ExternalLink, Clock } from "lucide-react";

type Upcoming = {
  key: string; // actionId + round
  candidateName: string;
  positionTitle: string;
  round: 1 | 2;
  scheduledAt: Date;
  zoomUrl: string | null;
};

const MANILA_TZ = "Asia/Manila";
const fmt = (d: Date) =>
  new Intl.DateTimeFormat("en-US", {
    timeZone: MANILA_TZ, hour: "numeric", minute: "2-digit", hour12: true,
  }).format(d);

// Short tone via Web Audio API — no asset file needed.
function playChime() {
  try {
    const Ctx = (window.AudioContext || (window as any).webkitAudioContext);
    if (!Ctx) return;
    const ctx = new Ctx();
    const playTone = (freq: number, start: number, dur: number) => {
      const o = ctx.createOscillator();
      const g = ctx.createGain();
      o.connect(g); g.connect(ctx.destination);
      o.type = "sine"; o.frequency.value = freq;
      g.gain.setValueAtTime(0, ctx.currentTime + start);
      g.gain.linearRampToValueAtTime(0.25, ctx.currentTime + start + 0.02);
      g.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + start + dur);
      o.start(ctx.currentTime + start);
      o.stop(ctx.currentTime + start + dur);
    };
    playTone(880, 0, 0.35);
    playTone(660, 0.4, 0.35);
    playTone(880, 0.8, 0.5);
  } catch {}
}

const EMAIL_LABEL_RE = /e[\s-]?mail/i;
const EMAIL_EXCLUDE_RE = /(onlinejob|online\s*jobs?|profile|link|url)/i;
const findNameQid = (qs: any[]) =>
  (qs.find((q) => q.type === "short_text" && /name/i.test(q.label || ""))?.id)
  || (qs.find((q) => q.type === "short_text")?.id);

export const InterviewReminderWatcher = () => {
  const { hrId } = useHrIdentity();
  const [current, setCurrent] = useState<Upcoming | null>(null);
  const shownRef = useRef<Set<string>>(new Set());

  useEffect(() => {
    if (!hrId) return;

    let cancelled = false;

    const check = async () => {
      const nowMs = Date.now();
      const windowEnd = new Date(nowMs + 10 * 60 * 1000 + 30 * 1000).toISOString();
      const windowStart = new Date(nowMs).toISOString();

      // Find candidate_actions whose response is handled by this HR with a round appt in window
      const { data: actions } = await supabase
        .from("candidate_actions")
        .select(
          "id, form_id, response_id, round1_appointment_date, round1_zoom_join_url, round2_appointment_date, round2_zoom_join_url, job_offer_id",
        )
        .or(
          `and(round1_appointment_date.gte.${windowStart},round1_appointment_date.lte.${windowEnd}),and(round2_appointment_date.gte.${windowStart},round2_appointment_date.lte.${windowEnd})`,
        );

      if (cancelled || !actions || actions.length === 0) return;

      const responseIds = [...new Set(actions.map((a: any) => a.response_id).filter(Boolean))];
      if (responseIds.length === 0) return;

      const { data: responses } = await supabase
        .from("responses")
        .select("id, handled_by_hr_id, form_id")
        .in("id", responseIds);
      const myResponseIds = new Set(
        (responses || []).filter((r: any) => r.handled_by_hr_id === hrId).map((r: any) => r.id),
      );
      const mine = actions.filter((a: any) => a.response_id && myResponseIds.has(a.response_id));
      if (mine.length === 0) return;

      const formIds = [...new Set(mine.map((a: any) => a.form_id))];
      const [{ data: questions }, { data: answers }, { data: forms }, { data: offers }] = await Promise.all([
        supabase.from("questions").select("id, form_id, type, label").in("form_id", formIds),
        supabase.from("answers").select("response_id, question_id, answer_text").in("response_id", responseIds),
        supabase.from("forms").select("id, title").in("id", formIds),
        (() => {
          const oids = mine.map((a: any) => a.job_offer_id).filter(Boolean);
          return oids.length
            ? supabase.from("job_offers").select("id, position_title").in("id", oids)
            : Promise.resolve({ data: [] as any[] });
        })(),
      ]);

      const nameQidByForm: Record<string, string | undefined> = {};
      const qByForm: Record<string, any[]> = {};
      for (const q of questions || []) (qByForm[q.form_id] = qByForm[q.form_id] || []).push(q);
      for (const fid of Object.keys(qByForm)) nameQidByForm[fid] = findNameQid(qByForm[fid]);

      const ansByResp: Record<string, Record<string, string>> = {};
      for (const a of answers || []) {
        ansByResp[a.response_id] = ansByResp[a.response_id] || {};
        ansByResp[a.response_id][a.question_id] = a.answer_text || "";
      }
      const formTitle: Record<string, string> = {};
      for (const f of forms || []) formTitle[f.id] = (f as any).title || "";
      const offerTitle: Record<string, string> = {};
      for (const o of offers || []) offerTitle[(o as any).id] = (o as any).position_title || "";

      for (const a of mine) {
        for (const round of [1, 2] as const) {
          const appt = round === 1 ? a.round1_appointment_date : a.round2_appointment_date;
          const zoom = round === 1 ? a.round1_zoom_join_url : a.round2_zoom_join_url;
          if (!appt) continue;
          const d = new Date(appt);
          const diffMs = d.getTime() - nowMs;
          if (diffMs < 0 || diffMs > 10 * 60 * 1000 + 30 * 1000) continue;
          const key = `${a.id}:${round}`;
          if (shownRef.current.has(key)) continue;
          const nameQid = nameQidByForm[a.form_id];
          const candidateName = (a.response_id && nameQid && ansByResp[a.response_id]?.[nameQid]) || "Candidate";
          const positionTitle = (a.job_offer_id && offerTitle[a.job_offer_id]) || formTitle[a.form_id] || "Interview";
          shownRef.current.add(key);
          setCurrent({
            key, candidateName, positionTitle, round, scheduledAt: d, zoomUrl: zoom,
          });
          playChime();
          return; // show one at a time
        }
      }
    };

    check();
    const id = setInterval(check, 30 * 1000);
    return () => { cancelled = true; clearInterval(id); };
  }, [hrId]);

  if (!current) return null;
  const minsLeft = Math.max(0, Math.round((current.scheduledAt.getTime() - Date.now()) / 60000));

  return (
    <Dialog open={!!current} onOpenChange={(v) => { if (!v) setCurrent(null); }}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-xl font-semibold">
            <Clock className="h-5 w-5 text-amber-500" />
            Interview in {minsLeft} {minsLeft === 1 ? "minute" : "minutes"}
          </DialogTitle>
        </DialogHeader>
        <div className="space-y-2 text-base">
          <div><span className="text-muted-foreground">Candidate:</span> <b>{current.candidateName}</b></div>
          <div><span className="text-muted-foreground">Position:</span> {current.positionTitle}</div>
          <div><span className="text-muted-foreground">Round:</span> {current.round}</div>
          <div><span className="text-muted-foreground">Scheduled:</span> {fmt(current.scheduledAt)} (Manila)</div>
        </div>
        <DialogFooter className="flex gap-2 sm:justify-end">
          <Button variant="outline" onClick={() => setCurrent(null)}>Dismiss</Button>
          {current.zoomUrl && (
            <Button asChild>
              <a href={current.zoomUrl} target="_blank" rel="noreferrer">
                Open Zoom <ExternalLink className="ml-2 h-4 w-4" />
              </a>
            </Button>
          )}
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

export default InterviewReminderWatcher;
