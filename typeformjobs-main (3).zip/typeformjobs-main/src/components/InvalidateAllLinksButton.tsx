import { useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Loader2, ShieldX } from "lucide-react";
import { toast } from "sonner";
import { parseInvokeError } from "@/lib/invokeError";

type Props = {
  agent: "christine" | "marissa";
  label: string;
};

/**
 * Emergency, password-gated button that expires EVERY active interview link for
 * one agent at once (Christine = Round 1 path, Marissa = Round 2 path). Only
 * expires existing tokens — newly sent invites still work. Password = "flush".
 */
export const InvalidateAllLinksButton = ({ agent, label }: Props) => {
  const [open, setOpen] = useState(false);
  const [pw, setPw] = useState("");
  const [busy, setBusy] = useState(false);

  const who = agent === "christine" ? "Christine" : "Marissa";

  const reset = () => { setPw(""); setBusy(false); };

  const submit = async () => {
    if (!pw || busy) return;
    setBusy(true);
    try {
      const { data, error } = await supabase.functions.invoke<{ ok?: boolean; count_invalidated?: number; error?: string }>(
        "invalidate-all-tokens",
        { body: { agent, password: pw } },
      );
      if (error || !data?.ok) {
        const parsed = await parseInvokeError(error, data);
        toast.error(parsed.message);
        setPw("");
        setBusy(false);
        return;
      }
      const n = data.count_invalidated ?? 0;
      toast.success(`Invalidated ${n} ${who} link${n === 1 ? "" : "s"}`);
      setOpen(false);
      reset();
    } catch (e) {
      const parsed = await parseInvokeError(e);
      toast.error(parsed.message);
      setBusy(false);
    }
  };

  return (
    <>
      <Button
        type="button"
        variant="outline"
        size="sm"
        className="text-destructive border-destructive/40 hover:bg-destructive/10 hover:text-destructive min-h-[40px]"
        onClick={() => { reset(); setOpen(true); }}
      >
        <ShieldX className="h-4 w-4 mr-1.5" /> {label}
      </Button>

      <Dialog open={open} onOpenChange={(o) => { if (!busy) { setOpen(o); if (!o) reset(); } }}>
        <DialogContent className="max-w-sm">
          <DialogHeader>
            <DialogTitle>{label}</DialogTitle>
            <DialogDescription>
              This immediately expires every active {agent === "christine" ? "Round 1 (Christine)" : "Round 2 (Marissa)"} interview
              link. Any newly sent invite afterwards will still work normally. Enter the emergency password to confirm.
            </DialogDescription>
          </DialogHeader>
          <form onSubmit={(e) => { e.preventDefault(); submit(); }} className="space-y-3">
            <Input
              type="password"
              value={pw}
              onChange={(e) => setPw(e.target.value)}
              autoFocus
              placeholder="Password"
            />
            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => { if (!busy) { setOpen(false); reset(); } }}>
                Cancel
              </Button>
              <Button type="submit" variant="destructive" disabled={busy || !pw}>
                {busy ? <Loader2 className="h-4 w-4 animate-spin" /> : "Invalidate All"}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
    </>
  );
};

export default InvalidateAllLinksButton;
