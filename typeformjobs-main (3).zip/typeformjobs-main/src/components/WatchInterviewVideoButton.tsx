import { InterviewVideoDialog } from "@/components/InterviewVideoDialog";

/**
 * Watch Interview Video button (Disqualified page).
 *
 * Piece 2: now plays the video IN-PAGE in an embedded dialog WITH on-the-fly
 * captions (white / large / dark band) via the shared InterviewVideoDialog,
 * instead of presigning + opening a raw R2 file in a new tab.
 *
 * Purely additive / read-only: it never mutates session data or any flow.
 * Note: R2 videos purge ~7 days after the interview, so playback is temporary.
 * If there is no session / no video, the shared component renders nothing.
 */
export function WatchInterviewVideoButton({ responseId }: { responseId: string }) {
  return (
    <InterviewVideoDialog
      responseId={responseId}
      buttonVariant="outline"
      buttonSize="sm"
      hideWhenNoVideo
    />
  );
}
