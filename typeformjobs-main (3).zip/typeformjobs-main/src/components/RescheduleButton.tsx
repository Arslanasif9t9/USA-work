import { useEffect, useState } from "react";
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Loader2, CalendarClock, Sparkles, Mail } from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import EditSlotsDialog from "@/components/EditSlotsDialog";

type Props = {
  slotId: string;
  candidateName: string;
  candidateEmail: string;
  /** Optional: pass when known so the edge function never falls back to a possibly-NULL slot.response_id. */
  responseId?: string;
  onDone?: () => void;
  variant?: "outline" | "destructive";
  size?: "sm" | "default";
  label?: string;
};

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

export const RescheduleButton = ({ slotId, candidateName, candidateEmail, responseId, onDone, variant = "outline", size = "sm", label = "Reschedule" }: Props) => {
  const [open, setOpen] = useState(false);
  const [email, setEmail] = useState(candidateEmail || "");
  const [busy, setBusy] = useState(false);
  const [curatedIds, setCuratedIds] = useState<string[]>([]);
  const [editOpen, setEditOpen] = useState(false);

  // When dialog opens, re-resolve the latest email from responses.override_email
  // (the same field the send functions read from) so what HR sees == what gets sent.
  useEffect(() => {
    if (!open) return;
    setEmail(candidateEmail || "");
    setCuratedIds([]);
    (async () => {
      const { data: slot } = await supabase
        .from("interview_slots")
        .select("response_id")
        .eq("id", slotId)
        .maybeSingle();
      const respId = (slot as any)?.response_id;
      if (!respId) return;
      const { data: resp } = await supabase
        .from("responses")
        .select("override_email")
        .eq("id", respId)
        .maybeSingle();
      const ov = (resp as any)?.override_email;
      if (ov && typeof ov === "string" && ov.trim()) setEmail(ov.trim());
    })();
  }, [open, slotId, candidateEmail]);

  const submit = async () => {
    const cleaned = email.trim();
    if (!EMAIL_RE.test(cleaned)) {
      toast.error("Enter a valid candidate email");
      return;
    }
    setBusy(true);
    try {
      // Guard: never reschedule a disqualified candidate. HR must Restore first,
      // otherwise the row ends up in a half-state (round_stage reset but
      // disqualified_at still set) and disappears from both views.
      let respIdForGuard = responseId;
      if (!respIdForGuard) {
        const { data: slot } = await supabase
          .from("interview_slots").select("response_id").eq("id", slotId).maybeSingle();
        respIdForGuard = (slot as any)?.response_id || undefined;
      }
      if (respIdForGuard) {
        const { data: resp } = await supabase
          .from("responses")
          .select("round_stage, disqualified_at, final_outcome")
          .eq("id", respIdForGuard)
          .maybeSingle();
        const r: any = resp || {};
        if (r.round_stage === "disqualified" || r.disqualified_at || r.final_outcome) {
          toast.error("This candidate is disqualified. Restore them from the Disqualified page before rescheduling.");
          setBusy(false);
          return;
        }
      }
      // Always send override_email so the edge function persists it to
      // responses.override_email (the same field Send Round 1/2/Offer read).
      const body: Record<string, unknown> = { slot_id: slotId, override_email: cleaned };
      if (responseId) body.response_id = responseId;
      if (curatedIds.length > 0) body.curated_slot_ids = curatedIds;
      const { data, error } = await supabase.functions.invoke("send-recovery-email", { body });

      const errMsg = (data as any)?.error || error?.message;
      if (errMsg) {
        if (errMsg === "missing_email") toast.error("Add an email for this candidate first");
        else toast.error(errMsg);
        return;
      }
      toast.success(
        curatedIds.length > 0
          ? `Reschedule link sent to ${cleaned} with ${curatedIds.length} curated slot${curatedIds.length === 1 ? "" : "s"}`
          : `Reschedule link sent to ${cleaned}`,
      );
      setOpen(false); setCuratedIds([]);
      onDone?.();
    } catch (err: any) {
      toast.error(err?.message || "Failed to send reschedule link");
    } finally {
      setBusy(false);
    }
  };

  return (
    <>
      <Button type="button" variant={variant} size={size} onClick={() => setOpen(true)}>
        <CalendarClock className="h-3.5 w-3.5 mr-1.5" /> {label}
      </Button>
      <AlertDialog open={open} onOpenChange={(o) => !busy && setOpen(o)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Send reschedule link to {candidateName || "this candidate"}?</AlertDialogTitle>
            <AlertDialogDescription>
              Their current interview time will be cancelled, the Zoom meeting deleted, and they'll receive a 3-day rebook link to pick a new time.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <div className="space-y-1.5">
            <Label className="flex items-center gap-1.5">
              <Mail className="h-3.5 w-3.5" /> Send to
            </Label>
            <Input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="name@example.com"
              autoFocus={!candidateEmail}
            />
            <p className="text-xs text-muted-foreground">
              Edits here save as the override email for this candidate.
            </p>
          </div>
          <div className="rounded-md border bg-muted/30 p-3 flex items-start gap-3">
            <Sparkles className="h-4 w-4 mt-0.5 text-primary shrink-0" />
            <div className="flex-1 space-y-1">
              <div className="text-sm font-medium">
                {curatedIds.length === 0 ? "Default availability" : `Curated: ${curatedIds.length} slot${curatedIds.length === 1 ? "" : "s"}`}
              </div>
              <p className="text-xs text-muted-foreground">
                {curatedIds.length === 0
                  ? "Candidate sees all available slots automatically."
                  : "Candidate sees only the slots you picked."}
              </p>
            </div>
            <Button type="button" variant="outline" size="sm" onClick={() => setEditOpen(true)} disabled={busy}>
              Edit Slots
            </Button>
          </div>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={busy}>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={(e) => { e.preventDefault(); submit(); }}
              disabled={busy || !EMAIL_RE.test(email.trim())}
            >
              {busy ? <Loader2 className="h-4 w-4 animate-spin" /> : "Send reschedule link"}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      <EditSlotsDialog
        open={editOpen}
        onOpenChange={setEditOpen}
        initialSelected={curatedIds}
        onSave={(ids) => setCuratedIds(ids)}
      />
    </>
  );
};

export default RescheduleButton;
