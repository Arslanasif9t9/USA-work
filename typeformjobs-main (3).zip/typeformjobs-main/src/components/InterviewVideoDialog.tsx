import { useCallback, useEffect, useRef, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogClose } from "@/components/ui/dialog";
import { Video, Loader2, X } from "lucide-react";
import { toast } from "sonner";

/**
 * Shared embedded interview-video player with on-the-fly captions.
 *
 * Clones the proven Piece 1 pattern from AiInterviewReport.tsx:
 *  - presigns the R2 URL via get-r2-download-url
 *  - builds a WebVTT track from ai_interview_sessions.transcript (one cue per
 *    segment, "Christine:"/"Candidate:" prefixed, default-on, CC-toggleable)
 *  - plays in an embedded <video> dialog (NOT a new tab)
 *
 * Captions are styled readable (white, large, dark band) via the
 * `.interview-video::cue` rule in index.css.
 *
 * Read-only: never mutates session data, transcripts, or R2 functions.
 */

// Seconds → WebVTT timestamp (HH:MM:SS.mmm)
const toVttTime = (sec: number): string => {
  const s = Math.max(0, Number(sec) || 0);
  const hh = Math.floor(s / 3600);
  const mm = Math.floor((s % 3600) / 60);
  const ss = Math.floor(s % 60);
  const ms = Math.round((s - Math.floor(s)) * 1000);
  const pad = (n: number, len = 2) => String(n).padStart(len, "0");
  return `${pad(hh)}:${pad(mm)}:${pad(ss)}.${pad(ms, 3)}`;
};

// Build a WebVTT caption string from the raw transcript JSONB array.
// One cue per segment using per-word start/end seconds. Returns null if unusable.
// (Identical logic to Piece 1's buildVttFromTranscript.)
export const buildVttFromTranscript = (t: any, agentName: string = "Christine"): string | null => {
  if (!Array.isArray(t) || t.length === 0) return null;
  const cues: string[] = [];
  let fallbackStart = 0;
  const MAX_CHARS = 42;
  const MAX_WORDS = 7;
  for (const seg of t) {
    const content = String(seg?.content || seg?.text || seg?.message || "").trim();
    if (!content) continue;
    const role = String(seg?.role || seg?.speaker || "agent").toLowerCase();
    const speaker = role === "user" ? "Candidate" : agentName;
    const words = Array.isArray(seg?.words) ? seg.words : [];

    // Fallback: no per-word timings → keep today's single-cue behavior.
    if (words.length === 0) {
      const start = fallbackStart;
      const end = start + Math.max(2, content.length / 14);
      fallbackStart = end;
      cues.push(`${toVttTime(start)} --> ${toVttTime(end)}\n${speaker}: ${content}`);
      continue;
    }

    // YouTube-style rolling cues: walk words and flush short chunks.
    let chunk: any[] = [];
    let chunkText = "";
    let firstCueOfSegment = true;
    const flush = () => {
      if (!chunk.length) return;
      const first = chunk.find((w: any) => typeof w?.start === "number");
      const lastEnd = [...chunk].reverse().find((w: any) => typeof w?.end === "number");
      let s = first ? first.start : fallbackStart;
      let e = lastEnd ? lastEnd.end : s + Math.max(1.2, chunkText.length / 14);
      if (e <= s) e = s + 1.2;
      fallbackStart = e;
      const prefix = firstCueOfSegment ? `${speaker}: ` : "";
      cues.push(`${toVttTime(s)} --> ${toVttTime(e)}\n${prefix}${chunkText.trim()}`);
      firstCueOfSegment = false;
      chunk = [];
      chunkText = "";
    };
    for (const w of words) {
      const wt = String(w?.word ?? "");
      chunk.push(w);
      chunkText += wt;
      if (
        chunk.length >= MAX_WORDS ||
        chunkText.trim().length >= MAX_CHARS ||
        /[.?!]\s*$/.test(wt) ||
        /\n/.test(wt)
      ) {
        flush();
      }
    }
    flush();
  }
  if (cues.length === 0) return null;
  return `WEBVTT\n\n${cues.join("\n\n")}`;
};

// Shared stage→round mapping. Used by BOTH the inside report (AiInterviewReport)
// and the Scout list (AiInterviews) so they resolve video the SAME way and can
// never diverge. Unmapped stages (e.g. "ai_scheduled", null) return undefined →
// the resolver then searches ALL sessions for the response_id (no round filter)
// and picks the healthiest video, exactly like the inside report's fallback.
export function videoRoundFromStage(stage?: string | null): "R1" | "R2" | undefined {
  const s = (stage || "").toLowerCase();
  if (s === "round2_ai" || s === "round2" || s === "round_2_sent") return "R2";
  if (s === "round1" || s === "round_1_sent") return "R1";
  return undefined;
}

type SessionLike = {
  video_url?: string | null;
  merged_video_url?: string | null;
  transcript?: any;
  stage?: string | null;
  duration_seconds?: number | null;
  created_at?: string | null;
};

/**
 * SINGLE SOURCE OF TRUTH for "which video does this candidate have".
 *
 * Resolves the HEALTHIEST video session for a response_id, optionally constrained
 * to one round. This is the EXACT logic the green "Watch Interview Video" button
 * uses, extracted so the Scout bulk-download path (Download All / Download
 * Selected) can reuse it verbatim instead of re-implementing a divergent query.
 *
 * Round handling MUST mirror the watch path:
 *   - "R1"  → only stage = "round1"
 *   - "R2"  → only stage in ("round2_ai", "round2")
 *   - undefined → NO stage filter: search ALL of the candidate's sessions.
 *     (Callers pass videoRoundFromStage(stage); unknown/ai_scheduled/null stages
 *      return undefined → this fallback finds the healthiest video regardless of
 *      stage, which is why the watch button can play candidates the old bulk
 *      stage-filtered query reported as "no video".)
 *
 * Health ranking: merged_video_url (2M) > video_url (1M) > none, +duration_seconds
 * as tiebreak, then most-recent created_at. Read-only: never mutates session data.
 */
export async function resolveHealthiestVideoSession(
  responseId: string,
  round?: "R1" | "R2",
): Promise<SessionLike | null> {
  if (!responseId) return null;
  // No round passed → never scan across all sessions (that cross-resolved to the
  // longest merged R2 video for AI-scheduled candidates). Require an explicit round.
  if (round !== "R1" && round !== "R2") return null;
  let query = supabase
    .from("ai_interview_sessions")
    .select("merged_video_url, video_url, transcript, created_at, duration_seconds, stage")
    .eq("response_id", responseId);
  if (round === "R1") {
    query = query.in("stage", ["round1", "ai_scheduled"]);
  } else if (round === "R2") {
    query = query.in("stage", ["round2_ai", "round2"]);
  }
  const { data } = await query.order("created_at", { ascending: false });
  const list = (data as any[]) || [];
  const score = (r: any) => {
    const dur = Number(r?.duration_seconds) || 0;
    if (r?.merged_video_url) return 2_000_000 + dur; // merged final: always best
    if (r?.video_url) return 1_000_000 + dur; // raw final: prefer longest
    return dur; // no video at all
  };
  const best = list.reduce((acc: any, cur: any) => {
    if (!acc) return cur;
    const sc = score(cur), sa = score(acc);
    if (sc !== sa) return sc > sa ? cur : acc;
    // equal health → most recent (list is already created_at desc)
    return acc;
  }, null);
  return (best as SessionLike) || null;
}

type Props = {
  /** Provide a pre-loaded session (detail page) ... */
  session?: SessionLike | null;
  /** ... or a response_id to fetch the latest session for (list/disqualified). */
  responseId?: string;
  /**
   * Constrain video resolution to a single interview round. A candidate can have
   * BOTH a round1 (Christine) and round2 (Marissa) session under the same
   * response_id. Without this, the "healthiest video" picker can cross rounds
   * (e.g. an R2 row showing the longer/healthier R1 video). When provided, only
   * sessions of THIS round are considered.
   *   - "R1" → stage = "round1"
   *   - "R2" → stage in ("round2_ai", "round2")
   */
  round?: "R1" | "R2";
  /** Button label + styling so each call site keeps its look. */
  buttonLabel?: string;
  buttonVariant?: "default" | "outline" | "secondary" | "ghost";
  buttonSize?: "default" | "sm" | "lg";
  buttonClassName?: string;
  /** When true and there is no video, render nothing instead of a disabled button. */
  hideWhenNoVideo?: boolean;
};

export function InterviewVideoDialog({
  session,
  responseId,
  round,
  buttonLabel = "Watch Interview Video",
  buttonVariant = "default",
  buttonSize = "default",
  buttonClassName,
  hideWhenNoVideo = false,
}: Props) {
  const [resolved, setResolved] = useState<SessionLike | null>(session ?? null);
  const [resolving, setResolving] = useState(!session && !!responseId);
  const [loading, setLoading] = useState(false);

  const [videoOpen, setVideoOpen] = useState(false);
  const [videoSrc, setVideoSrc] = useState<string | null>(null);
  const [vttUrl, setVttUrl] = useState<string | null>(null);
  const vttUrlRef = useRef<string | null>(null);

  useEffect(() => {
    vttUrlRef.current = vttUrl;
  }, [vttUrl]);
  useEffect(() => {
    return () => {
      if (vttUrlRef.current) URL.revokeObjectURL(vttUrlRef.current);
    };
  }, []);

  // Keep in sync if the parent passes a session directly.
  useEffect(() => {
    if (session) setResolved(session);
  }, [session]);

  // Resolve the HEALTHIEST video session for a response_id when no session was
  // provided. A candidate can have MULTIPLE sessions in the same round (e.g. an
  // aborted first attempt that left a tiny/stray stub plus the real interview).
  // Picking the latest by created_at can land on the unplayable stub, so Watch
  // wouldn't play. Instead we fetch all sessions and rank by video health:
  //   1) a merged_video_url present (post-merge final) always wins,
  //   2) else a video_url present, preferring the LONGEST interview
  //      (duration_seconds) — the real final, not a 0s/short stray part,
  //   3) tie-break on most recent created_at.
  // Read-only: this never mutates session data.
  useEffect(() => {
    if (session || !responseId) return;
    let cancelled = false;
    (async () => {
      setResolving(true);
      // Shared resolver — identical health/round logic now reused by Scout bulk
      // download so a candidate is downloadable iff the watch button can play it.
      const best = await resolveHealthiestVideoSession(responseId, round);
      if (cancelled) return;
      setResolved(best || null);
      setResolving(false);
    })();
    return () => {
      cancelled = true;
    };
  }, [session, responseId, round]);

  const targetUrl = resolved?.merged_video_url || resolved?.video_url || null;

  const handleWatch = useCallback(async () => {
    if (!targetUrl) return;
    setLoading(true);
    try {
      const { data, error } = await supabase.functions.invoke("get-r2-download-url", {
        body: { video_url: targetUrl },
      });
      const url = (data as any)?.url;
      if (error || !url) {
        toast.error("Video link could not be generated");
        return;
      }
      // Build captions on the fly from the transcript (if any).
      const captionAgentName =
        round === "R2" || resolved?.stage === "round2_ai" ? "Marissa" : "Christine";
      const vtt = buildVttFromTranscript(resolved?.transcript, captionAgentName);
      if (vttUrlRef.current) {
        URL.revokeObjectURL(vttUrlRef.current);
        vttUrlRef.current = null;
      }
      const nextVtt = vtt ? URL.createObjectURL(new Blob([vtt], { type: "text/vtt" })) : null;
      setVttUrl(nextVtt);
      setVideoSrc(url);
      setVideoOpen(true);
    } catch {
      toast.error("Video link could not be generated");
    } finally {
      setLoading(false);
    }
  }, [targetUrl, resolved, round]);

  if (resolving) return null;
  if (!targetUrl && hideWhenNoVideo) return null;

  return (
    <>
      <Button
        type="button"
        variant={buttonVariant}
        size={buttonSize}
        className={buttonClassName}
        disabled={loading || !targetUrl}
        onClick={handleWatch}
      >
        {loading ? (
          <>
            <Loader2 className="h-4 w-4 mr-2 animate-spin" /> Preparing video…
          </>
        ) : (
          <>
            <Video className="h-4 w-4 mr-2" /> {buttonLabel}
          </>
        )}
      </Button>

      <Dialog
        open={videoOpen}
        onOpenChange={(o) => {
          setVideoOpen(o);
          if (!o) {
            setVideoSrc(null);
            if (vttUrlRef.current) {
              URL.revokeObjectURL(vttUrlRef.current);
              vttUrlRef.current = null;
            }
            setVttUrl(null);
          }
        }}
      >
        <DialogContent
          showClose={false}
          className="max-w-[95vw] sm:max-w-3xl max-h-[90vh] overflow-y-auto p-4"
        >
          {/* Always-visible, high-contrast close button pinned top-right inside the viewport */}
          <DialogClose
            aria-label="Close video"
            className="absolute right-3 top-3 z-50 inline-flex h-9 w-9 items-center justify-center rounded-full bg-black/70 text-white shadow-lg ring-1 ring-white/30 transition hover:bg-black/90 focus:outline-none focus-visible:ring-2 focus-visible:ring-white"
          >
            <X className="h-5 w-5" />
            <span className="sr-only">Close</span>
          </DialogClose>

          <DialogHeader className="pr-12">
            <DialogTitle className="flex items-center gap-2">
              <Video className="h-4 w-4" /> Interview Video
            </DialogTitle>
          </DialogHeader>
          {videoSrc ? (
            <video
              key={videoSrc}
              controls
              autoPlay
              crossOrigin="anonymous"
              className="interview-video mx-auto block w-auto max-w-full max-h-[75vh] rounded-md bg-black object-contain"
            >
              <source src={videoSrc} />
              {vttUrl ? (
                <track kind="subtitles" srcLang="en" label="Transcript" src={vttUrl} default />
              ) : null}
            </video>
          ) : null}
          {!vttUrl ? (
            <p className="text-xs text-muted-foreground">
              No transcript available — captions are off for this interview.
            </p>
          ) : null}
        </DialogContent>
      </Dialog>
    </>
  );
}
