// SendScheduleControl — shared "Now / Later" toggle for every send
// popup (wired into popups in Pieces 2/3). In this piece it is built + exported.
//
// CRITICAL: defaults are REGISTERED in state on mount (not just displayed):
//   time = 06:00, timezone = Asia/Manila, date = next 6 AM Manila.
// The parent reads the current value via onChange / the value prop, so a
// scheduled send is valid with ZERO clicks.
import { useEffect, useMemo, useState } from "react";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import { Clock, CalendarClock } from "lucide-react";
import { cn } from "@/lib/utils";
import {
  MANILA_TZ, nextSixAmManilaDate, wallToUtcIso, formatScheduledFor,
} from "@/lib/scheduledSends";

export type SendScheduleValue =
  | { mode: "now" }
  | { mode: "schedule"; scheduled_for_utc: string; timezone: string };

const TIMEZONES = [
  "Asia/Manila",
  "UTC",
  "America/New_York",
  "America/Los_Angeles",
  "Europe/London",
  "Asia/Singapore",
  "Australia/Sydney",
];

type Props = {
  onChange?: (value: SendScheduleValue) => void;
  className?: string;
};

export default function SendScheduleControl({ onChange, className }: Props) {
  const [mode, setMode] = useState<"now" | "schedule">("now");
  // Defaults computed once at mount and SET INTO STATE (not visual-only).
  const [date, setDate] = useState<string>(() => nextSixAmManilaDate());
  const [time, setTime] = useState<string>("06:00");
  const [timezone, setTimezone] = useState<string>(MANILA_TZ);

  // Compute the current value from state. For "schedule", convert wall-clock to UTC.
  const value: SendScheduleValue = useMemo(() => {
    if (mode === "now") return { mode: "now" };
    return {
      mode: "schedule",
      scheduled_for_utc: wallToUtcIso(date, time, timezone),
      timezone,
    };
  }, [mode, date, time, timezone]);

  // Emit on every change (including the first render, so defaults register).
  useEffect(() => {
    onChange?.(value);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [value]);

  const previewUtc = mode === "schedule" ? wallToUtcIso(date, time, timezone) : null;

  return (
    <div className={cn("space-y-3", className)}>
      <div className="grid grid-cols-2 gap-2">
        <button
          type="button"
          onClick={() => setMode("now")}
          className={cn(
            "flex items-center justify-center gap-2 rounded-md border px-3 py-2 text-sm font-medium transition-colors",
            mode === "now"
              ? "border-primary bg-primary/10 text-primary"
              : "border-input bg-background text-muted-foreground hover:border-primary/50",
          )}
        >
          <Clock className="h-4 w-4" /> Now
        </button>
        <button
          type="button"
          onClick={() => setMode("schedule")}
          className={cn(
            "flex items-center justify-center gap-2 rounded-md border px-3 py-2 text-sm font-medium transition-colors",
            mode === "schedule"
              ? "border-primary bg-primary/10 text-primary"
              : "border-input bg-background text-muted-foreground hover:border-primary/50",
          )}
        >
          <CalendarClock className="h-4 w-4" /> Later
        </button>
      </div>

      {mode === "schedule" && (
        <div className="space-y-3 rounded-md border bg-muted/30 p-3">
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1">
              <Label className="text-xs">Date</Label>
              <Input type="date" value={date} onChange={(e) => setDate(e.target.value)} className="h-9" />
            </div>
            <div className="space-y-1">
              <Label className="text-xs">Time</Label>
              <Input type="time" value={time} onChange={(e) => setTime(e.target.value)} className="h-9" />
            </div>
          </div>
          <div className="space-y-1">
            <Label className="text-xs">Timezone</Label>
            <Select value={timezone} onValueChange={setTimezone}>
              <SelectTrigger className="h-9"><SelectValue /></SelectTrigger>
              <SelectContent>
                {TIMEZONES.map((tz) => (
                  <SelectItem key={tz} value={tz}>{tz}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          {previewUtc && (
            <p className="text-xs text-muted-foreground">
              Will send: <span className="font-medium text-foreground">{formatScheduledFor(previewUtc, timezone)}</span> ({timezone})
            </p>
          )}
        </div>
      )}
    </div>
  );
}
