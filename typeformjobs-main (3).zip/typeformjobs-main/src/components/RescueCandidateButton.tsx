import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { HeartHandshake, Loader2, Mail } from "lucide-react";
import { toast } from "sonner";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter,
} from "@/components/ui/dialog";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

const DURATION_OPTIONS = [
  "under 1 minute", "1 minute", "2 minutes", "3 minutes",
  "4 minutes", "5 minutes", "6 minutes",
] as const;

type Props = {
  responseId: string;
  candidateName: string;
  candidateEmail?: string;
  /** "outline" → shadcn outline Button (Scout Report). Default outline. */
  appearance?: "stack" | "outline";
  /** 1 → Christine R1 rescue (amber). 2 → Marissa Round 2 rescue (purple). Default 1. */
  round?: 1 | 2;
};

export const RescueCandidateButton = ({
  responseId, candidateName, candidateEmail = "", appearance = "outline", round = 1,
}: Props) => {
  const isR2 = round === 2;
  const interviewerName = isR2 ? "Marissa" : "Christine";
  const [open, setOpen] = useState(false);
  const [confirming, setConfirming] = useState(false);
  const [email, setEmail] = useState(candidateEmail);
  const [duration, setDuration] = useState<string>("under 1 minute");
  const [remark, setRemark] = useState("");
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    if (open) { setEmail(candidateEmail || ""); setConfirming(false); }
  }, [open, candidateEmail]);

  const startConfirm = () => {
    if (!EMAIL_RE.test(email.trim())) { toast.error("Enter a valid candidate email"); return; }
    setConfirming(true);
  };

  const submit = async () => {
    const cleaned = email.trim();
    if (!EMAIL_RE.test(cleaned)) { toast.error("Enter a valid candidate email"); return; }
    setBusy(true);
    try {
      const { data, error } = await supabase.functions.invoke("rescue-interview-email", {
        body: {
          response_id: responseId,
          override_email: cleaned,
          interview_duration_label: duration,
          hr_remark: remark.trim() || undefined,
          force_round: round,
        },
      });
      const errMsg = (data as any)?.error || error?.message;
      if (errMsg) {
        if (errMsg === "missing_email") toast.error("Add an email for this candidate first");
        else if (errMsg === "not_recoverable") toast.error("This candidate is no longer eligible");
        else toast.error(errMsg);
        return;
      }
      toast.success(`Rescue email sent to ${cleaned}`);
      setOpen(false);
    } catch (e: any) {
      toast.error(e?.message || "Could not send rescue email");
    } finally {
      setBusy(false);
    }
  };

  const fullWidth = appearance === "stack";

  return (
    <>
      <Button
        size="sm"
        className={`${isR2 ? "bg-purple-600 hover:bg-purple-700" : "bg-amber-500 hover:bg-amber-600"} text-white ${fullWidth ? "w-full min-h-[44px]" : "min-h-[36px]"}`}
        onClick={() => setOpen(true)}
      >
        <HeartHandshake className="h-4 w-4 mr-1.5" /> {isR2 ? "Rescue (Round 2)" : "Rescue Candidate"}
      </Button>

      <Dialog open={open} onOpenChange={(o) => !busy && setOpen(o)}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <HeartHandshake className="h-4 w-4" /> {isR2 ? "Rescue candidate (Round 2)" : "Rescue candidate"}
            </DialogTitle>
            <DialogDescription>
              {candidateName || "The candidate"} will receive a warm, genuine second-chance
              email with a fresh link to complete their {isR2 ? "Round 2" : ""} interview with {interviewerName}. The link expires in 3 days.
            </DialogDescription>
          </DialogHeader>

          {!confirming ? (
            <form onSubmit={(e) => { e.preventDefault(); startConfirm(); }} className="space-y-3">
              <div className="space-y-1.5">
                <Label className="flex items-center gap-1.5">
                  <Mail className="h-3.5 w-3.5" /> Send to
                </Label>
                <Input
                  type="email"
                  autoComplete="off"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="name@example.com"
                  autoFocus={!candidateEmail}
                />
              </div>
              <div className="space-y-1.5">
                <Label>Interview ended after about</Label>
                <Select value={duration} onValueChange={setDuration}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {DURATION_OPTIONS.map((d) => (
                      <SelectItem key={d} value={d}>{d}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-1.5">
                <Label>Note for the candidate (optional)</Label>
                <Textarea
                  value={remark}
                  onChange={(e) => setRemark(e.target.value)}
                  placeholder="e.g. no video found, audio unclear"
                  rows={2}
                  maxLength={1000}
                />
              </div>
              <DialogFooter>
                <Button type="button" variant="ghost" onClick={() => setOpen(false)}>
                  Cancel
                </Button>
                <Button type="submit">
                  <HeartHandshake className="h-4 w-4 mr-2" /> Review &amp; send
                </Button>
              </DialogFooter>
            </form>
          ) : (
            <div className="space-y-3">
              <div className="rounded-md border border-border bg-muted/40 p-3 text-sm space-y-1">
                <div><span className="text-muted-foreground">Send to:</span> {email.trim()}</div>
                <div><span className="text-muted-foreground">Ended after:</span> {duration}</div>
                {remark.trim() && (
                  <div><span className="text-muted-foreground">Note:</span> {remark.trim()}</div>
                )}
              </div>
              <p className="text-sm text-muted-foreground">
                Send this second-chance email now? A fresh interview link will be generated.
              </p>
              <DialogFooter>
                <Button type="button" variant="ghost" onClick={() => setConfirming(false)} disabled={busy}>
                  Back
                </Button>
                <Button type="button" onClick={submit} disabled={busy}>
                  {busy ? <Loader2 className="h-4 w-4 mr-2 animate-spin" /> : <HeartHandshake className="h-4 w-4 mr-2" />}
                  Confirm &amp; send
                </Button>
              </DialogFooter>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </>
  );
};

export default RescueCandidateButton;
