import { useEffect, useMemo, useRef, useState } from "react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Check, CheckCircle2, ArrowLeft, ArrowRight, Loader2, Star, Heart, Upload, X, Camera } from "lucide-react";
import SelfieField from "@/components/SelfieField";
import ScheduleCallWidget from "@/components/ScheduleCallWidget";
import DatePicker from "@/components/DatePicker";
import PhoneInput from "react-phone-number-input";
import { isValidPhoneNumber } from "libphonenumber-js";
import "react-phone-number-input/style.css";
import { cn } from "@/lib/utils";
import { supabase } from "@/integrations/supabase/client";
import { uploadPublicStorageObject } from "@/lib/publicStorageUpload";

export type SlideQuestion = {
  id: string;
  type: string;
  label: string;
  description: string | null;
  placeholder: string | null;
  order_index: number;
  required?: boolean;
  options?: any;
};

type Mode = "edit" | "preview" | "candidate";

type Props = {
  question: SlideQuestion;
  index: number;
  mode: Mode;
  value?: any;
  onChange?: (v: any) => void;
  onAdvance?: (valueOverride?: any) => void;
  onPrev?: () => void;
  canPrev?: boolean;
  onUpdateLabel?: (label: string) => void;
  onUpdateDescription?: (desc: string | null) => void;
  submitting?: boolean;
  submitLabel?: string;
  formId?: string;
  uploadSessionId?: string;
};

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const LETTERS = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
const isMac = typeof navigator !== "undefined" && /Mac/.test(navigator.platform);
const META_LABEL = isMac ? "⌘" : "Ctrl";

// Normalize legacy types
const effectiveType = (t: string) => {
  if (t === "dropdown") return "multiple_choice";
  if (t === "legal_checkbox") return "short_text";
  return t;
};

export const Slide = ({
  question: q,
  index,
  mode,
  value,
  onChange,
  onAdvance,
  onPrev,
  canPrev,
  onUpdateLabel,
  onUpdateDescription,
  submitting,
  submitLabel,
  formId,
  uploadSessionId,
}: Props) => {
  const inputRef = useRef<HTMLInputElement | HTMLTextAreaElement | null>(null);
  const welcomeTitleRef = useRef<HTMLTextAreaElement | null>(null);
  const [labelVal, setLabelVal] = useState(q.label);
  const [descVal, setDescVal] = useState(q.description || "");
  const [error, setError] = useState<string | null>(null);
  const [datePending, setDatePending] = useState(false);
  const qType = effectiveType(q.type);

  useEffect(() => {
    setLabelVal(q.label);
    setDescVal(q.description || "");
    setError(null);
  }, [q.id, q.label, q.description]);

  useEffect(() => {
    if (mode === "candidate" && inputRef.current) {
      setTimeout(() => inputRef.current?.focus(), 100);
    }
  }, [q.id, mode]);

  useEffect(() => {
    if (mode !== "edit" || q.type !== "welcome" || !welcomeTitleRef.current) return;
    welcomeTitleRef.current.style.height = "auto";
    welcomeTitleRef.current.style.height = `${welcomeTitleRef.current.scrollHeight}px`;
  }, [labelVal, mode, q.type]);

  const interactive = mode === "candidate" || mode === "preview";
  const editable = mode === "edit";
  const required = !!q.required;

  const choices: string[] = useMemo(() => {
    const opts = q.options as any;
    if (Array.isArray(opts?.choices) && opts.choices.length) return opts.choices;
    return ["Option 1", "Option 2", "Option 3"];
  }, [q.options]);
  const multiple = !!(q.options as any)?.multiple;
  const allowOther = !!(q.options as any)?.allowOther;
  const scale: number = (q.options as any)?.scale || 5;
  const ratingStyle: string = (q.options as any)?.style || "stars";
  const leftLabel: string = (q.options as any)?.leftLabel || "";
  const rightLabel: string = (q.options as any)?.rightLabel || "";

  // Keyboard shortcuts for choice/rating
  useEffect(() => {
    if (mode !== "candidate") return;
    if (!["multiple_choice", "rating"].includes(qType)) return;
    const onKey = (e: KeyboardEvent) => {
      const tag = (e.target as HTMLElement)?.tagName;
      if (tag === "INPUT" || tag === "TEXTAREA") return;
      if (qType === "multiple_choice") {
        const i = LETTERS.indexOf(e.key.toUpperCase());
        if (i >= 0 && i < choices.length) {
          e.preventDefault();
          if (multiple) {
            const cur: string[] = Array.isArray(value) ? value : [];
            const next = cur.includes(choices[i]) ? cur.filter((c) => c !== choices[i]) : [...cur, choices[i]];
            onChange?.(next);
          } else {
            onChange?.(choices[i]);
            setTimeout(() => onAdvance?.(choices[i]), 250);
          }
        }
      } else if (qType === "rating") {
        const n = parseInt(e.key, 10);
        if (!isNaN(n) && n >= 1 && n <= scale) {
          e.preventDefault();
          onChange?.(n);
          setTimeout(() => onAdvance?.(n), 250);
        }
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [q.id, qType, mode, choices, multiple, scale, value, onChange, onAdvance]);

  const TitleEl = editable ? (
    <textarea
      value={labelVal}
      onChange={(e) => {
        setLabelVal(e.target.value);
        const el = e.currentTarget;
        el.style.height = "auto";
        el.style.height = el.scrollHeight + "px";
      }}
      onFocus={(e) => {
        const el = e.currentTarget;
        el.style.height = "auto";
        el.style.height = el.scrollHeight + "px";
      }}
      onBlur={() => labelVal !== q.label && onUpdateLabel?.(labelVal || "Untitled")}
      placeholder="Untitled question"
      rows={1}
      className="w-full overflow-hidden whitespace-pre-wrap break-words text-2xl md:text-3xl font-bold leading-tight bg-transparent outline-none focus:bg-secondary/40 rounded px-2 py-1 resize-none"
    />
  ) : (
    <h1 className="text-2xl md:text-3xl font-bold leading-tight whitespace-pre-wrap break-words">
      {q.type !== "welcome" && q.type !== "thank_you" && index > 0 && (
        <span className="text-muted-foreground mr-2 font-medium">{index} →</span>
      )}
      {q.label}
      {required && q.type !== "welcome" && q.type !== "thank_you" && (
        <span className="text-destructive ml-1">*</span>
      )}
    </h1>
  );

  const DescEl = editable ? (
    <textarea
      value={descVal}
      onChange={(e) => setDescVal(e.target.value)}
      onBlur={() => (descVal || null) !== q.description && onUpdateDescription?.(descVal || null)}
      placeholder="Add a description..."
      rows={1}
      className="w-full text-base text-muted-foreground bg-transparent outline-none focus:bg-secondary/40 rounded px-2 py-1 resize-none overflow-hidden [field-sizing:content]"
    />
  ) : q.description ? (
    <p className="text-base text-muted-foreground max-w-xl whitespace-pre-wrap break-words">{q.description}</p>
  ) : null;

  // Welcome
  if (q.type === "welcome") {
    const buttonText = (q.options as any)?.buttonText || "Start";
    return (
      <div className="w-full max-w-2xl mx-auto text-center space-y-6 px-4">
        <h1 className="text-3xl md:text-5xl font-bold">
          {editable ? (
            <textarea
              ref={welcomeTitleRef}
              value={labelVal}
              onChange={(e) => setLabelVal(e.target.value)}
              onBlur={() => labelVal !== q.label && onUpdateLabel?.(labelVal || "Untitled")}
              rows={1}
              className="w-full overflow-hidden text-3xl md:text-5xl font-bold leading-tight text-center bg-transparent outline-none focus:bg-secondary/40 rounded px-2 py-1 resize-none"
            />
          ) : q.label}
        </h1>
        {editable ? DescEl : q.description ? (
          <p className="text-base md:text-lg text-muted-foreground whitespace-pre-wrap break-words">{q.description}</p>
        ) : null}
        <div className="pt-4 flex items-center justify-center gap-3 flex-wrap">
          <Button size="lg" onClick={() => interactive && onAdvance?.()} className="px-8 h-12 rounded-lg shadow-sm">
            {buttonText} <ArrowRight className="h-4 w-4 ml-1" />
          </Button>
        </div>
      </div>
    );
  }

  // Thank you
  if (q.type === "thank_you") {
    const showAnother = !!(q.options as any)?.showAnotherButton;
    return (
      <div className="w-full max-w-2xl mx-auto text-center space-y-6 px-4">
        <div className="w-16 h-16 rounded-full bg-green-50 border border-green-200 mx-auto flex items-center justify-center">
          <CheckCircle2 className="h-9 w-9 text-green-600" />
        </div>
        <h1 className="text-3xl md:text-5xl font-bold">
          {editable ? (
            <input
              value={labelVal}
              onChange={(e) => setLabelVal(e.target.value)}
              onBlur={() => labelVal !== q.label && onUpdateLabel?.(labelVal || "Untitled")}
              className="w-full text-3xl md:text-5xl font-bold text-center bg-transparent outline-none focus:bg-secondary/40 rounded px-2 py-1"
            />
          ) : q.label}
        </h1>
        {editable ? DescEl : q.description ? (
          <p className="text-base md:text-lg text-muted-foreground whitespace-pre-wrap break-words">{q.description}</p>
        ) : null}
        {mode === "candidate" && showAnother && (
          <Button variant="outline" onClick={() => window.location.reload()}>
            Submit another response
          </Button>
        )}
        {mode === "candidate" && (
          <p className="text-xs text-muted-foreground pt-8">Powered by Expert Intuitive Advisor Inc</p>
        )}
      </div>
    );
  }

  const clearError = () => error && setError(null);

  const validate = (candidateValue: any = value): boolean => {
    const v = candidateValue;
    if (qType === "email") {
      if (!v) { if (required) { setError("Email is required"); return false; } return true; }
      if (!EMAIL_RE.test(String(v).trim())) { setError("Please enter a valid email address"); return false; }
    } else if (qType === "phone") {
      if (!v) { if (required) { setError("Phone number is required"); return false; } return true; }
      if (!isValidPhoneNumber(String(v))) { setError("Please enter a valid phone number"); return false; }
    } else if (qType === "date") {
      if (!v && required) { setError("Please select a date"); return false; }
      if (datePending) { setError("Please tap the exact day you were born to continue."); return false; }
    } else if (qType === "time") {
      const normalized = normalizeTimeValue(v);
      if (!normalized) {
        if (required) { setError("Please select hour, minute, and AM/PM"); return false; }
        return true;
      }
    } else if (qType === "multiple_choice") {
      const empty = multiple ? !Array.isArray(v) || v.length === 0 : !v;
      if (empty && required) { setError("Please choose an option"); return false; }
      const isOtherStr = (s: any) => typeof s === "string" && (s === "Other:" || s === "Other" || s.startsWith("Other: "));
      const otherTextOf = (s: string) => s.startsWith("Other: ") ? s.slice(7) : "";
      if (multiple && Array.isArray(v)) {
        const o = v.find(isOtherStr);
        if (o && !otherTextOf(o).trim()) { setError("Please specify"); return false; }
      } else if (typeof v === "string" && isOtherStr(v) && !otherTextOf(v).trim()) {
        setError("Please specify"); return false;
      }
    } else if (qType === "rating") {
      if (!v && required) { setError("Please select a rating"); return false; }
    } else if (qType === "file_upload" || qType === "selfie") {
      if (!v && required) { setError(qType === "selfie" ? "Please take a selfie" : "Please upload a file"); return false; }
    } else if (qType === "schedule_call") {
      const hasSlot = v && (v.slot_id || v.ooo);
      if (!hasSlot && required) { setError("Please select a time slot"); return false; }

    } else {
      if (!v && required) { setError("This field is required"); return false; }
    }
    return true;
  };

  const tryAdvance = (valueOverride?: any) => {
    if (!interactive || submitting) return;
    // For email: use HTML5 native validation first
    if (qType === "email" && inputRef.current && (inputRef.current as HTMLInputElement).type === "email") {
      const el = inputRef.current as HTMLInputElement;
      if (!el.checkValidity()) {
        el.reportValidity();
        if (required && !el.value) setError("Email is required");
        else setError("Please enter a valid email address");
        return;
      }
    }
    const normalizedOverride = qType === "time" ? normalizeTimeValue(valueOverride ?? value) : valueOverride;
    if (!validate(qType === "time" ? normalizedOverride : valueOverride)) return;
    if (qType === "time" && normalizedOverride) {
      clearError();
      onChange?.(normalizedOverride);
      onAdvance?.(normalizedOverride);
      return;
    }
    onAdvance?.(valueOverride);
  };

  const renderInput = () => {
    const disabled = mode === "edit";

    switch (qType) {
      case "long_text":
        return (
          <Textarea
            ref={inputRef as any}
            disabled={disabled}
            value={value || ""}
            onChange={(e) => {
              clearError();
              onChange?.(e.target.value);
              const el = e.currentTarget;
              el.style.height = "auto";
              el.style.height = Math.min(el.scrollHeight, 300) + "px";
            }}
            onKeyDown={(e) => {
              if (e.key === "Enter" && (e.metaKey || e.ctrlKey)) {
                e.preventDefault();
                tryAdvance();
              }
            }}
            placeholder={q.placeholder || "Type your answer here..."}
            className={cn(
              "w-full text-xl md:text-2xl border-0 border-b-2 rounded-none px-0 focus-visible:ring-0 focus-visible:border-primary placeholder:text-muted-foreground/50 resize-none overflow-auto",
              error && "border-destructive"
            )}
            style={{ minHeight: 100, maxHeight: 300 }}
          />
        );

      case "date":
        return <DateField value={value} onChange={(v) => { clearError(); onChange?.(v); }} disabled={disabled} error={!!error} format={(q.options as any)?.format} minDate={(q.options as any)?.minDate} maxDate={(q.options as any)?.maxDate} onPendingChange={(p) => { setDatePending(p); if (p) clearError(); }} />;

      case "time":
        return <TimeField key={q.id} value={value} onChange={(v) => { clearError(); onChange?.(v); }} disabled={disabled} error={!!error} errorText={error} options={q.options || {}} />;

      case "email":
        return (
          <input
            ref={inputRef as any}
            type="email"
            required={required}
            inputMode="email"
            autoComplete="email"
            disabled={disabled}
            value={value || ""}
            onChange={(e) => { clearError(); onChange?.(e.target.value); }}
            placeholder={q.placeholder || "name@example.com"}
            className={cn(
              "w-full text-xl md:text-2xl bg-transparent border-0 border-b-2 border-input pb-2 px-0 outline-none focus:border-primary placeholder:text-muted-foreground/50",
              error && "border-destructive"
            )}
          />
        );

      case "phone":
        return (
          <SplitPhone
            value={value || ""}
            onChange={(v) => { clearError(); onChange?.(v); }}
            disabled={disabled}
            error={!!error}
            defaultCountry={(q.options as any)?.defaultCountry && (q.options as any)?.defaultCountry !== "US" ? (q.options as any).defaultCountry : "PH"}
          />
        );

      case "short_text":
        return (
          <input
            ref={inputRef as any}
            type="text"
            disabled={disabled}
            value={value || ""}
            onChange={(e) => { clearError(); onChange?.(e.target.value); }}
            placeholder={q.placeholder || "Type your answer here..."}
            maxLength={(q.options as any)?.maxLength || undefined}
            className={cn(
              "w-full text-xl md:text-2xl bg-transparent border-0 border-b-2 border-input pb-2 px-0 outline-none focus:border-primary placeholder:text-muted-foreground/50",
              error && "border-destructive"
            )}
          />
        );

      case "yes_no": {
        const yn = (val: "yes" | "no") => {
          clearError();
          onChange?.(val);
          if (interactive) setTimeout(() => onAdvance?.(val), 250);
        };
        const Btn = ({ val, letter, label }: { val: "yes" | "no"; letter: string; label: string }) => {
          const selected = value === val;
          return (
            <button
              type="button"
              disabled={disabled}
              onClick={() => yn(val)}
              className={cn(
                "relative flex items-center justify-center gap-2 min-h-[64px] min-w-[200px] w-full md:w-auto rounded-xl border-2 bg-background text-lg font-medium transition-all px-6",
                selected ? "border-primary bg-primary/5" : "border-border hover:border-primary/60 hover:bg-secondary/40"
              )}
            >
              <span className="absolute top-2 left-2 text-[10px] font-bold bg-secondary text-secondary-foreground rounded px-1.5 py-0.5">
                {letter}
              </span>
              {label}
              {selected && <Check className="h-5 w-5 text-primary" />}
            </button>
          );
        };
        return (
          <div className="flex flex-col md:flex-row gap-3 justify-center pt-2">
            <Btn val="yes" letter="Y" label="Yes" />
            <Btn val="no" letter="N" label="No" />
          </div>
        );
      }

      case "multiple_choice": {
        const isOtherStr = (s: string) => typeof s === "string" && s.startsWith("Other: ") || s === "Other:" || s === "Other";
        const otherValueFrom = (s: string) => s.startsWith("Other: ") ? s.slice(7) : s.startsWith("Other:") ? s.slice(6) : "";

        const otherSelected = multiple
          ? Array.isArray(value) && value.some(isOtherStr)
          : typeof value === "string" && isOtherStr(value);
        const otherText = multiple
          ? (Array.isArray(value) ? otherValueFrom(value.find(isOtherStr) || "") : "")
          : (typeof value === "string" && isOtherStr(value) ? otherValueFrom(value) : "");

        const isSelected = (c: string) => {
          if (multiple) return Array.isArray(value) && value.includes(c);
          return value === c;
        };
        const select = (c: string) => {
          clearError();
          if (multiple) {
            const cur: string[] = Array.isArray(value) ? value.filter((x) => !isOtherStr(x)) : [];
            onChange?.(cur.includes(c) ? cur.filter((x) => x !== c) : [...cur, c]);
          } else {
            onChange?.(c);
            if (interactive) setTimeout(() => onAdvance?.(c), 300);
          }
        };
        const selectOther = () => {
          clearError();
          if (multiple) {
            const cur: string[] = Array.isArray(value) ? value : [];
            if (otherSelected) {
              onChange?.(cur.filter((x) => !isOtherStr(x)));
            } else {
              onChange?.([...cur, "Other: "]);
            }
          } else {
            onChange?.("Other: " + otherText);
          }
          setTimeout(() => {
            const el = document.getElementById(`other-input-${q.id}`) as HTMLInputElement | null;
            el?.focus();
          }, 50);
        };
        const updateOther = (txt: string) => {
          clearError();
          const newOther = "Other: " + txt;
          if (multiple) {
            const cur: string[] = Array.isArray(value) ? value : [];
            const filtered = cur.filter((x) => !isOtherStr(x));
            onChange?.([...filtered, newOther]);
          } else {
            onChange?.(newOther);
          }
        };

        return (
          <div className="space-y-2">
            {choices.map((c, i) => {
              const selected = isSelected(c);
              return (
                <button
                  type="button"
                  key={c + i}
                  disabled={disabled}
                  onClick={() => select(c)}
                  className={cn(
                    "w-full flex items-center gap-3 p-4 rounded-lg border-2 text-left transition-all",
                    selected ? "border-primary bg-primary/5" : "border-border hover:border-primary/60 hover:bg-secondary/40"
                  )}
                >
                  <span className={cn(
                    "flex items-center justify-center h-8 w-8 rounded border text-sm font-semibold flex-shrink-0",
                    selected ? "border-primary bg-primary text-primary-foreground" : "border-border bg-background"
                  )}>
                    {LETTERS[i]}
                  </span>
                  <span className="flex-1 text-base md:text-lg">{c}</span>
                  {selected && <Check className="h-5 w-5 text-primary" />}
                </button>
              );
            })}
            {allowOther && (
              <div className="space-y-2">
                <button
                  type="button"
                  disabled={disabled}
                  onClick={selectOther}
                  className={cn(
                    "w-full flex items-center gap-3 p-4 rounded-lg border-2 text-left transition-all",
                    otherSelected ? "border-primary bg-primary/5" : "border-border hover:border-primary/60 hover:bg-secondary/40"
                  )}
                >
                  <span className={cn(
                    "flex items-center justify-center h-8 w-8 rounded border text-sm font-semibold flex-shrink-0",
                    otherSelected ? "border-primary bg-primary text-primary-foreground" : "border-border bg-background"
                  )}>
                    {LETTERS[choices.length]}
                  </span>
                  <span className="flex-1 text-base md:text-lg">Other</span>
                  {otherSelected && <Check className="h-5 w-5 text-primary" />}
                </button>
                {otherSelected && (
                  <div className="pl-11 pr-2">
                    <input
                      id={`other-input-${q.id}`}
                      type="text"
                      disabled={disabled}
                      value={otherText}
                      onChange={(e) => updateOther(e.target.value)}
                      onKeyDown={(e) => {
                        if (e.key === "Enter") {
                          e.preventDefault();
                          if (otherText.trim()) tryAdvance();
                        }
                      }}
                      placeholder="Please specify..."
                      className="w-full bg-transparent border-0 border-b-2 border-input pb-1 px-0 outline-none focus:border-primary text-base placeholder:text-muted-foreground/50"
                    />
                    {!otherText.trim() && (
                      <p className="text-xs text-muted-foreground mt-1">Please specify</p>
                    )}
                  </div>
                )}
              </div>
            )}
          </div>
        );
      }

      case "rating": {
        const cur = Number(value) || 0;
        const Icon = ratingStyle === "hearts" ? Heart : Star;
        return (
          <div className="space-y-2">
            <div className="flex items-center justify-center gap-2 flex-wrap">
              {Array.from({ length: scale }).map((_, i) => {
                const n = i + 1;
                const filled = cur >= n;
                return (
                  <button
                    type="button"
                    key={n}
                    disabled={disabled}
                    onClick={() => { clearError(); onChange?.(n); if (interactive) setTimeout(() => onAdvance?.(n), 250); }}
                    className="p-1 transition-transform hover:scale-110"
                    aria-label={`Rate ${n}`}
                  >
                    {ratingStyle === "numbers" ? (
                      <span className={cn(
                        "inline-flex items-center justify-center h-10 w-10 rounded-full border-2 text-base font-semibold",
                        filled ? "bg-primary text-primary-foreground border-primary" : "border-border text-muted-foreground"
                      )}>{n}</span>
                    ) : (
                      <Icon className={cn(
                        "h-10 w-10 transition-colors",
                        filled ? "fill-primary text-primary" : "text-muted-foreground/40"
                      )} />
                    )}
                  </button>
                );
              })}
            </div>
            {(leftLabel || rightLabel) && (
              <div className="flex justify-between text-xs text-muted-foreground px-2">
                <span>{leftLabel}</span>
                <span>{rightLabel}</span>
              </div>
            )}
          </div>
        );
      }

      case "file_upload":
        return (
          <FileUploadField
            value={value}
            onChange={(v) => { clearError(); onChange?.(v); }}
            disabled={disabled || mode === "preview"}
            options={q.options || {}}
            formId={formId}
            questionId={q.id}
            uploadSessionId={uploadSessionId}
            setError={setError}
          />
        );

      case "selfie":
        return (
          <SelfieField
            value={value}
            onChange={(v) => { clearError(); onChange?.(v); }}
            disabled={disabled || mode === "preview"}
            formId={formId}
            questionId={q.id}
            uploadSessionId={uploadSessionId}
            setError={setError}
          />
        );

      case "schedule_call":
        return (
          <div className="space-y-2">
            <ScheduleCallWidget
              value={value || null}
              onChange={(v) => { clearError(); onChange?.(v); }}
              disabled={disabled || mode === "preview"}
            />
            {error && (
              <p className="text-sm text-destructive text-center" role="alert">
                {error}
              </p>
            )}
          </div>
        );


      default:
        return null;
    }
  };

  const isYesNo = qType === "yes_no";
  const isAutoAdvance = isYesNo || (qType === "multiple_choice" && !multiple) || qType === "rating";
  const okDisabled = mode === "edit";
  const showOk = !isYesNo;
  const showHint = !isAutoAdvance;
  const longTextHint = qType === "long_text";

  return (
    <div className="w-full max-w-2xl mx-auto space-y-6 px-4">
      <div className="space-y-3 text-left">
        {TitleEl}
        {DescEl}
      </div>
      <div className="pt-2">{renderInput()}</div>
      {error && qType !== "time" && qType !== "schedule_call" && (
        <p className="text-sm text-destructive -mt-3" role="alert">{error}</p>
      )}
      {longTextHint && !error && (
        <p className="text-xs text-muted-foreground -mt-3">
          Press {META_LABEL} + Enter to continue
        </p>
      )}
      {showOk && (
        <div className="pt-8 flex items-center justify-center gap-4 md:gap-5 flex-wrap">
          {mode === "candidate" && canPrev && (
            <Button
              type="button"
              variant="outline"
              onClick={onPrev}
              disabled={submitting}
              className="h-11 md:h-12 px-6 rounded-lg font-semibold text-[15px] transition-transform hover:scale-[1.02] active:scale-[0.95]"
            >
              <ArrowLeft className="h-4 w-4 mr-1" /> Back
            </Button>
          )}
          <Button
            onClick={() => tryAdvance()}
            disabled={okDisabled || submitting}
            className="h-11 md:h-12 px-6 rounded-lg font-semibold text-[15px] shadow-sm transition-transform hover:scale-[1.02] active:scale-[0.95]"
          >
            {submitting ? (
              <><Loader2 className="h-4 w-4 mr-2 animate-spin" /> Submitting...</>
            ) : (
              <>{submitLabel || "OK"} <ArrowRight className="h-4 w-4 ml-1" /></>
            )}
          </Button>
        </div>
      )}
      {mode === "candidate" && canPrev && !showOk && (
        <div className="pt-6 flex items-center justify-center">
          <Button
            type="button"
            variant="outline"
            onClick={onPrev}
            className="h-11 px-6 rounded-lg font-semibold text-[15px]"
          >
            <ArrowLeft className="h-4 w-4 mr-1" /> Back
          </Button>
        </div>
      )}
    </div>
  );
};

// ─── Time field — 3 plain dropdowns (hour / minute / AM-PM) ───
const HOUR_OPTIONS = ["1","2","3","4","5","6","7","8","9","10","11","12"];
const MINUTE_OPTIONS = ["00","05","10","15","20","25","30","35","40","45","50","55"];

const parseTimeString = (v: any): { h: string; m: string; p: "AM" | "PM" | "" } => {
  if (!v || typeof v !== "string") return { h: "", m: "", p: "" };
  const match = v.trim().toUpperCase().replace(/\s+/g, "").match(/^(\d{1,2}):(\d{2})(AM|PM)$/);
  if (!match) return { h: "", m: "", p: "" };
  return { h: String(Number(match[1])), m: match[2], p: match[3] as "AM" | "PM" };
};

const normalizeTimeValue = (value: unknown): string | null => {
  if (!value || typeof value !== "string") return null;
  const p = parseTimeString(value);
  if (!p.h || !p.m || !p.p) return null;
  return `${p.h}:${p.m} ${p.p}`;
};

const TimeField = ({ value, onChange, disabled, error, errorText }: any) => {
  const initial = parseTimeString(value);
  const [hour, setHour] = useState<string>(initial.h);
  const [minute, setMinute] = useState<string>(initial.m);
  const [period, setPeriod] = useState<"AM" | "PM" | "">(initial.p);

  useEffect(() => {
    if (typeof value !== "string" || !value) return;
    const p = parseTimeString(value);
    setHour(p.h);
    setMinute(p.m);
    setPeriod(p.p);
  }, [value]);

  const emit = (h: string, m: string, p: string) => {
    if (h && m && p) onChange?.(`${h}:${m} ${p}`);
    else onChange?.("");
  };

  const selectCls = cn(
    "h-12 rounded-lg border bg-background px-3 text-base text-foreground focus:outline-none focus:ring-2 focus:ring-primary/20",
    error ? "border-destructive" : "border-input",
    disabled && "cursor-not-allowed opacity-60",
  );

  return (
    <div className="space-y-2">
      <div className="flex flex-wrap gap-2">
        <select
          disabled={disabled}
          value={hour}
          onChange={(e) => { const v = e.target.value; setHour(v); emit(v, minute || "00", period); }}
          className={selectCls}
          aria-label="Hour"
        >
          <option value="">Hour</option>
          {HOUR_OPTIONS.map((h) => <option key={h} value={h}>{h}</option>)}
        </select>
        <select
          disabled={disabled}
          value={minute}
          onChange={(e) => { const v = e.target.value; setMinute(v); emit(hour, v, period); }}
          className={selectCls}
          aria-label="Minute"
        >
          <option value="">Minute</option>
          {MINUTE_OPTIONS.map((m) => <option key={m} value={m}>{m}</option>)}
        </select>
        <select
          disabled={disabled}
          value={period}
          onChange={(e) => { const v = e.target.value as "AM" | "PM" | ""; setPeriod(v); emit(hour, minute, v); }}
          className={selectCls}
          aria-label="AM or PM"
        >
          <option value="">AM/PM</option>
          <option value="AM">AM</option>
          <option value="PM">PM</option>
        </select>
      </div>
      {error && errorText && (
        <p className="text-sm text-destructive" role="alert">{errorText}</p>
      )}
    </div>
  );
};


// ─── Date field (custom premium picker) ───
const DateField = ({ value, onChange, disabled, error, format: fmt, minDate, maxDate, onPendingChange }: any) => {
  return (
    <DatePicker
      value={value || null}
      onChange={(v) => onChange(v)}
      disabled={disabled}
      error={error}
      format={fmt}
      minDate={minDate}
      maxDate={maxDate}
      variant="underline"
      onPendingChange={onPendingChange}
    />
  );
};

// ─── International phone input — stores E.164 (+639171234567) ───
const SplitPhone = ({ value, onChange, disabled, error, defaultCountry }: any) => {
  return (
    <div className={cn("th-phone-wrapper", error && "th-phone-wrapper--error")}>
      <PhoneInput
        international
        defaultCountry={(defaultCountry || "PH") as any}
        countryCallingCodeEditable={false}
        value={value || undefined}
        onChange={(v) => onChange(v || "")}
        placeholder="Enter phone number"
        disabled={disabled}
        className={cn(
          "rounded-md border border-hairline bg-background px-3 py-3 text-base font-normal transition-colors",
          "focus-within:border-navy focus-within:ring-2 focus-within:ring-navy/15",
          error && "border-destructive focus-within:border-destructive focus-within:ring-destructive/15",
          disabled && "opacity-60 cursor-not-allowed",
        )}
      />
    </div>
  );
};

// ─── File upload ───
const FileUploadField = ({ value, onChange, disabled, options, formId, questionId, uploadSessionId, setError }: any) => {
  const [uploading, setUploading] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);
  const accept: string = options.accept || "*";
  const maxMB: number = options.maxSizeMB || 10;
  // Unified bucket — every file upload question (any number per form) lands here.
  // Per-question uniqueness comes from the path, not the bucket name.
  const bucket = "candidate-files";

  const acceptLabel =
    accept === "*" ? "Any file" :
    accept === "image/*" ? "Images" :
    accept === "application/pdf" ? "PDF" :
    accept;

  const handleFile = async (file: File) => {
    setError(null);
    if (file.size > maxMB * 1024 * 1024) {
      setError(`File is too large. Max ${maxMB}MB allowed.`);
      return;
    }
    if (accept !== "*") {
      const allowed = accept.split(",").map((s: string) => s.trim());
      const matches = allowed.some((a: string) => {
        if (a.endsWith("/*")) return file.type.startsWith(a.slice(0, -1));
        if (a.startsWith(".")) return file.name.toLowerCase().endsWith(a.toLowerCase());
        return file.type === a;
      });
      if (!matches) {
        setError(`Only ${acceptLabel} are accepted.`);
        return;
      }
    }
    setUploading(true);
    const safeName = (file.name || `upload-${Date.now()}`).replace(/[^a-zA-Z0-9._-]/g, "_");
    const sessionId = uploadSessionId || formId || "preview";
    // Path: responses/{sessionId}/questions/{questionId}/{timestamp}-{filename}
    // Works for any number of file upload questions per form without collision.
    const path = `responses/${sessionId}/questions/${questionId}/${Date.now()}-${safeName}`;
    const contentType = file.type || "application/octet-stream";
    try {
      await uploadPublicStorageObject({ bucket, path, file, contentType });
      onChange({ bucket, path, name: file.name, size: file.size, type: contentType });
    } catch (e: any) {
      if (e?.status || e?.statusCode) {
        const status = e.statusCode || e.status;
        console.error("File upload failed:", {
          bucket, path, contentType, size: file.size,
          status, message: e.message, name: e.name, body: e.body, endpoint: e.endpoint,
        });
        if (String(status) === "413" || /too large|exceeded/i.test(e.message || "")) {
          setError(`That file is too large. Please upload one under ${maxMB}MB.`);
        } else if (String(status) === "409" || /already exists/i.test(e.message || "")) {
          setError("That file already exists. Please try again.");
        } else {
          setError("Upload failed. Please try again.");
        }
        return;
      }
      console.error("File upload threw:", e);
      setError("Upload failed. Please check your connection and try again.");
    } finally {
      setUploading(false);
    }
  };

  const onDrop = (e: React.DragEvent) => {
    e.preventDefault();
    if (disabled) return;
    const file = e.dataTransfer.files?.[0];
    if (file) handleFile(file);
  };

  if (value && value.name) {
    return (
      <div className="border-2 border-border rounded-lg p-4 flex items-center gap-3">
        <Check className="h-5 w-5 text-primary" />
        <div className="flex-1 min-w-0">
          <div className="text-sm font-medium truncate">{value.name}</div>
          <div className="text-xs text-muted-foreground">{(value.size / 1024).toFixed(1)} KB</div>
        </div>
        <button
          type="button"
          disabled={disabled}
          onClick={() => { onChange(null); inputRef.current?.click(); }}
          className="text-sm text-muted-foreground hover:text-foreground underline"
        >
          Replace
        </button>
        <button
          type="button"
          disabled={disabled}
          onClick={() => onChange(null)}
          className="p-1 text-muted-foreground hover:text-destructive"
          aria-label="Remove"
        >
          <X className="h-4 w-4" />
        </button>
        <input
          ref={inputRef}
          type="file"
          accept={accept === "*" ? undefined : accept}
          className="hidden"
          onChange={(e) => { const f = e.target.files?.[0]; if (f) handleFile(f); }}
        />
      </div>
    );
  }

  return (
    <div>
      <div
        onDragOver={(e) => e.preventDefault()}
        onDrop={onDrop}
        onClick={() => !disabled && !uploading && inputRef.current?.click()}
        className={cn(
          "border-2 border-dashed border-border rounded-lg p-8 text-center cursor-pointer hover:border-primary/60 hover:bg-secondary/30 transition-colors",
          disabled && "opacity-60 cursor-not-allowed"
        )}
      >
        {uploading ? (
          <div className="flex items-center justify-center gap-2 text-muted-foreground">
            <Loader2 className="h-4 w-4 animate-spin" /> Uploading...
          </div>
        ) : (
          <>
            <Upload className="h-8 w-8 mx-auto text-muted-foreground mb-2" />
            <p className="text-sm font-medium">Drag a file here or click to upload</p>
            <p className="text-xs text-muted-foreground mt-1">
              {acceptLabel} · max {maxMB}MB
            </p>
          </>
        )}
      </div>
      <input
        ref={inputRef}
        type="file"
        accept={accept === "*" ? undefined : accept}
        className="hidden"
        onChange={(e) => { const f = e.target.files?.[0]; if (f) handleFile(f); }}
      />
    </div>
  );
};

export default Slide;
