// ScheduledSendChip — display-only amber chip shown next to a candidate row's
// existing status pill when a pending scheduled send exists for that response.
// Additive: does NOT modify round_stage or any existing badge.
import { useEffect, useState } from "react";
import { CalendarClock } from "lucide-react";
import {
  getPendingScheduledForResponse, formatScheduledFor, type PendingScheduledSend,
} from "@/lib/scheduledSends";

export default function ScheduledSendChip({ responseId }: { responseId?: string | null }) {
  const [pending, setPending] = useState<PendingScheduledSend | null>(null);

  useEffect(() => {
    let active = true;
    if (!responseId) { setPending(null); return; }
    getPendingScheduledForResponse(responseId).then((p) => {
      if (active) setPending(p);
    });
    return () => { active = false; };
  }, [responseId]);

  if (!pending) return null;

  return (
    <span className="inline-flex items-center gap-1 rounded-full border border-amber-400/50 bg-amber-100 px-2 py-0.5 text-[11px] font-medium text-amber-800 dark:bg-amber-500/15 dark:text-amber-300">
      <CalendarClock className="h-3 w-3" />
      Scheduled for {formatScheduledFor(pending.scheduled_for, pending.timezone)}
    </span>
  );
}
