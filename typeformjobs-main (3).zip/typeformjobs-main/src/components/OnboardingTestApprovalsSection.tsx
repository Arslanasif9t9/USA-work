import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Table, TableHeader, TableBody, TableRow, TableHead, TableCell } from "@/components/ui/table";
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Loader2, ClipboardCheck, RefreshCw, Trash2 } from "lucide-react";
import { toast } from "sonner";

type PendingRow = {
  id: string;
  candidate_name: string;
  candidate_email: string;
  assigned_group_id: string | null;
  after_pass_mode: string;
  attempts_used: number;
  passed_at: string | null;
};

type AttemptRow = { token_id: string | null; score: number; total: number };

const fmtDate = (s: string | null) =>
  s ? new Date(s).toLocaleDateString("en-US", { year: "numeric", month: "short", day: "numeric" }) : "—";

export default function OnboardingTestApprovalsSection() {
  const [loading, setLoading] = useState(true);
  const [rows, setRows] = useState<PendingRow[]>([]);
  const [bestByToken, setBestByToken] = useState<Record<string, { score: number; total: number }>>({});
  const [busy, setBusy] = useState<string | null>(null);
  const [pendingDelete, setPendingDelete] = useState<PendingRow | null>(null);
  const [deleting, setDeleting] = useState(false);

  const load = async () => {
    setLoading(true);
    const { data: toks } = await supabase
      .from("onboarding_quiz_tokens")
      .select("id, candidate_name, candidate_email, assigned_group_id, after_pass_mode, attempts_used, passed_at")
      .eq("status", "passed_pending")
      .order("passed_at", { ascending: false });
    const list = (toks as PendingRow[]) || [];
    setRows(list);

    if (list.length) {
      const ids = list.map((r) => r.id);
      const { data: atts } = await supabase
        .from("onboarding_quiz_attempts")
        .select("token_id, score, total")
        .in("token_id", ids);
      const best: Record<string, { score: number; total: number }> = {};
      (atts as AttemptRow[] | null)?.forEach((a) => {
        if (!a.token_id) return;
        const cur = best[a.token_id];
        if (!cur || a.score > cur.score) best[a.token_id] = { score: a.score, total: a.total };
      });
      setBestByToken(best);
    } else {
      setBestByToken({});
    }
    setLoading(false);
  };

  useEffect(() => { load(); }, []);

  const decide = async (tokenId: string, decision: "approved" | "declined") => {
    setBusy(`${tokenId}:${decision}`);
    const { data, error } = await supabase.functions.invoke("decide-onboarding-quiz", {
      body: { token_id: tokenId, decision },
    });
    setBusy(null);
    if (error || (data as any)?.error) {
      toast.error("Could not save the decision. Please try again.");
      return;
    }
    toast.success(decision === "approved" ? "Approved." : "Declined.");
    load();
  };

  const confirmDelete = async () => {
    if (!pendingDelete) return;
    setDeleting(true);
    const { error } = await supabase
      .from("onboarding_quiz_tokens")
      .delete()
      .eq("id", pendingDelete.id);
    setDeleting(false);
    if (error) {
      toast.error("Could not delete this record. Please try again.");
      return;
    }
    setRows((prev) => prev.filter((r) => r.id !== pendingDelete.id));
    setPendingDelete(null);
    toast.success("Record deleted.");
  };



  return (
    <div className="mb-8 border rounded-md bg-card">
      <div className="flex items-center justify-between px-5 py-4 border-b">
        <div className="flex items-center gap-2">
          <ClipboardCheck className="h-5 w-5" style={{ color: "#b8860b" }} />
          <h2 className="text-lg font-semibold">Onboarding Test Approvals</h2>
        </div>
        <Button variant="ghost" size="sm" onClick={load} disabled={loading}>
          <RefreshCw className={`h-4 w-4 ${loading ? "animate-spin" : ""}`} />
        </Button>
      </div>
      {loading ? (
        <div className="flex items-center justify-center py-12">
          <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
        </div>
      ) : rows.length === 0 ? (
        <div className="text-center py-12 text-muted-foreground text-sm">No onboarding tests are waiting for approval.</div>
      ) : (
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead className="w-10"></TableHead>
              <TableHead>Name</TableHead>
              <TableHead>Email</TableHead>
              <TableHead>Score</TableHead>
              <TableHead>Team</TableHead>
              <TableHead>Passed</TableHead>
              <TableHead className="text-right">Action</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {rows.map((r) => {
              const best = bestByToken[r.id];
              return (
                <TableRow key={r.id}>
                  <TableCell>
                    <Button
                      size="sm"
                      variant="outline"
                      className="text-red-600 hover:text-red-700 border-red-200 hover:bg-red-50"
                      onClick={() => setPendingDelete(r)}
                      disabled={!!busy}
                      title="Delete this record permanently"
                      aria-label="Delete record"
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </TableCell>
                  <TableCell className="font-medium">{r.candidate_name}</TableCell>
                  <TableCell className="text-muted-foreground">{r.candidate_email}</TableCell>
                  <TableCell>{best ? `${best.score} / ${best.total}` : "—"}</TableCell>
                  <TableCell className="text-muted-foreground">{r.assigned_group_id || "—"}</TableCell>
                  <TableCell className="text-muted-foreground">{fmtDate(r.passed_at)}</TableCell>
                  <TableCell className="text-right">
                    <div className="flex items-center justify-end gap-2">
                      <Badge className="border-0" style={{ backgroundColor: "#dcfce7", color: "#166534" }}>Pending</Badge>
                      <Button
                        size="sm"
                        onClick={() => decide(r.id, "approved")}
                        disabled={!!busy}
                        style={{ backgroundColor: "#1a2547", color: "#fff" }}
                      >
                        {busy === `${r.id}:approved` ? <Loader2 className="h-4 w-4 animate-spin" /> : "Approve"}
                      </Button>
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => decide(r.id, "declined")}
                        disabled={!!busy}
                      >
                        {busy === `${r.id}:declined` ? <Loader2 className="h-4 w-4 animate-spin" /> : "Decline"}
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              );
            })}
          </TableBody>
        </Table>
      )}

      <AlertDialog open={!!pendingDelete} onOpenChange={(o) => !deleting && !o && setPendingDelete(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete this record permanently?</AlertDialogTitle>
            <AlertDialogDescription>
              This cannot be undone.
              {pendingDelete ? ` (${pendingDelete.candidate_name})` : ""}
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={deleting}>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={(e) => { e.preventDefault(); confirmDelete(); }}
              disabled={deleting}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              {deleting ? (<><Loader2 className="h-4 w-4 mr-2 animate-spin" /> Deleting…</>) : "Delete"}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
