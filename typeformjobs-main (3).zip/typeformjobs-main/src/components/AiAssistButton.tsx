import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Loader2, Sparkles, RotateCw, Check } from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { parseInvokeError } from "@/lib/invokeError";

type Props = {
  /** Parent puts the accepted text into its own message field. */
  onAccept: (text: string) => void;
  /** Optional hint about what this message is for (e.g. "ID collection request"). */
  context?: string;
  /** Optional smaller styling for inline placement. */
  size?: "sm" | "default";
  className?: string;
  /** When true, requests a full multi-paragraph document body (not a short message). */
  long?: boolean;
  /** Optional placeholder for the description textarea. */
  placeholder?: string;
  /** Optional title shown above the description textarea. */
  title?: string;
};

const MAX_DESC = 2000;
const MAX_DESC_LONG = 6000;

export function AiAssistButton({ onAccept, context, size = "sm", className, long = false, placeholder, title }: Props) {
  const [open, setOpen] = useState(false);
  const [description, setDescription] = useState("");
  const [generating, setGenerating] = useState(false);
  const [result, setResult] = useState<string | null>(null);

  const maxDesc = long ? MAX_DESC_LONG : MAX_DESC;

  const reset = () => {
    setDescription("");
    setResult(null);
    setGenerating(false);
  };

  const generate = async () => {
    const desc = description.trim();
    if (!desc) {
      toast.error("Describe what you want to say first");
      return;
    }
    setGenerating(true);
    try {
      const { data, error } = await supabase.functions.invoke("ai-write-message", {
        body: { description: desc, context: context || undefined, ...(long ? { long: true } : {}) },
      });
      if (error) {
        const { message: msg } = await parseInvokeError(error, data);
        toast.error(msg);
        return;
      }
      if ((data as any)?.error) {
        const { message: msg } = await parseInvokeError(null, data);
        toast.error(msg);
        return;
      }
      const text = String((data as any)?.message ?? "").trim();
      if (!text) {
        toast.error("AI returned an empty message. Please try again.");
        return;
      }
      setResult(text);
    } catch (e: any) {
      const { message: msg } = await parseInvokeError(e);
      toast.error(msg);
    } finally {
      setGenerating(false);
    }
  };

  const accept = () => {
    if (result) onAccept(result);
    setOpen(false);
    reset();
  };

  return (
    <Popover
      open={open}
      onOpenChange={(o) => {
        setOpen(o);
        if (!o) reset();
      }}
    >
      <PopoverTrigger asChild>
        <Button type="button" variant="outline" size={size} className={className}>
          <Sparkles className="h-4 w-4 mr-1.5" /> AI Assist
        </Button>
      </PopoverTrigger>
      <PopoverContent className="w-[340px] max-w-[calc(100vw-32px)]" align="start">
        <div className="grid gap-3">
          <div className="text-sm font-medium">{title || "AI Assist — write a message"}</div>
          <Textarea
            value={description}
            onChange={(e) => setDescription(e.target.value.slice(0, maxDesc))}
            rows={long ? 4 : 3}
            placeholder={placeholder || "Describe what you want to say…"}
            disabled={generating}
          />
          {!result ? (
            <Button type="button" onClick={generate} disabled={generating} className="min-h-10">
              {generating ? (
                <><Loader2 className="h-4 w-4 mr-2 animate-spin" /> Writing…</>
              ) : (
                <><Sparkles className="h-4 w-4 mr-2" /> Write it</>
              )}
            </Button>
          ) : (
            <>
              <div className="rounded-md border bg-muted/40 p-2.5 text-sm whitespace-pre-wrap">
                {result}
              </div>
              <div className="flex gap-2">
                <Button type="button" onClick={accept} className="flex-1 min-h-10">
                  <Check className="h-4 w-4 mr-1.5" /> Use this
                </Button>
                <Button
                  type="button"
                  variant="outline"
                  onClick={generate}
                  disabled={generating}
                  className="min-h-10"
                >
                  {generating ? (
                    <Loader2 className="h-4 w-4 animate-spin" />
                  ) : (
                    <><RotateCw className="h-4 w-4 mr-1.5" /> Regenerate</>
                  )}
                </Button>
              </div>
            </>
          )}
        </div>
      </PopoverContent>
    </Popover>
  );
}
