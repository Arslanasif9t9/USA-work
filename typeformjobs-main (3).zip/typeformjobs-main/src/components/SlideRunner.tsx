import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import Slide, { SlideQuestion } from "./Slide";
import EiaWordmark from "@/components/EiaWordmark";
import InterviewConfirmedScreen from "@/components/InterviewConfirmedScreen";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Loader2, RotateCcw, ArrowRight } from "lucide-react";
import { getThemeClass } from "@/lib/theme";

type Props = {
  questions: SlideQuestion[];
  mode: "candidate" | "preview";
  formId?: string;
  activeId?: string | null;
  theme?: string | null;
};

const SYNTHETIC_THANKS: SlideQuestion = {
  id: "__synthetic_thanks__",
  type: "thank_you",
  label: "Thank you. Your application has been submitted.",
  description: null,
  placeholder: null,
  order_index: 9999,
  options: { showAnotherButton: true },
};

const RESUME_KEY = (formId: string) => `eia.resume.${formId}`;
const RESUME_MAX_AGE_MS = 24 * 3600 * 1000;

type ResumeEnvelope = {
  responseId: string;
  sessionToken: string;
  formId: string;
  startedAt: number;
};

const loadResume = (formId: string): ResumeEnvelope | null => {
  try {
    const raw = localStorage.getItem(RESUME_KEY(formId));
    if (!raw) return null;
    const r = JSON.parse(raw) as ResumeEnvelope;
    if (!r?.sessionToken || !r?.responseId) return null;
    if (Date.now() - (r.startedAt || 0) > RESUME_MAX_AGE_MS) return null;
    return r;
  } catch { return null; }
};
const saveResume = (formId: string, env: ResumeEnvelope) => {
  try { localStorage.setItem(RESUME_KEY(formId), JSON.stringify(env)); } catch {}
};
const clearResume = (formId: string) => {
  try { localStorage.removeItem(RESUME_KEY(formId)); } catch {}
};

export const SlideRunner = ({ questions: rawQuestions, mode, formId, activeId, theme }: Props) => {
  const themeClass = getThemeClass(theme ?? null);
  const questions = useMemo(() => {
    if (mode === "candidate" && !rawQuestions.some((q) => q.type === "thank_you")) {
      return [...rawQuestions, SYNTHETIC_THANKS];
    }
    return rawQuestions;
  }, [rawQuestions, mode]);

  const [idx, setIdx] = useState(0);
  const [answers, setAnswers] = useState<Record<string, any>>({});
  const [transitioning, setTransitioning] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [submitError, setSubmitError] = useState<string | null>(null);
  const [submitted, setSubmitted] = useState(false);
  const [bookedInterview, setBookedInterview] = useState<{
    displayDate: string; displayTime: string; email: string | null;
  } | null>(null);
  const [positionTitle, setPositionTitle] = useState<string | null>(null);

  // Per-session response identifier (created when candidate starts the form).
  const [responseId, setResponseId] = useState<string | null>(null);
  const [sessionToken, setSessionToken] = useState<string | null>(null);
  const [saveStatus, setSaveStatus] = useState<"idle" | "saving" | "saved" | "error">("idle");

  // Resume prompt state
  const [resumePrompt, setResumePrompt] = useState<null | {
    answers: Record<string, any>;
    questionIndex: number;
    responseId: string;
    sessionToken: string;
  }>(null);
  const [resumeChecked, setResumeChecked] = useState(false);

  // Stable per-session id used to namespace all candidate file uploads in this attempt.
  const uploadSessionIdRef = useRef<string>(crypto.randomUUID());
  const uploadSessionId = uploadSessionIdRef.current;

  useEffect(() => {
    if (!formId) return;
    supabase
      .from("form_metadata")
      .select("position_title")
      .eq("form_id", formId)
      .maybeSingle()
      .then(({ data }) => setPositionTitle((data as any)?.position_title || null));
  }, [formId]);

  const total = questions.length;
  const current = questions[idx];
  const thankIdx = questions.findIndex((q) => q.type === "thank_you");
  const lastBeforeThank = thankIdx > 0 ? thankIdx - 1 : total - 1;

  const middleQs = useMemo(
    () => questions.filter((q) => q.type !== "welcome" && q.type !== "thank_you"),
    [questions]
  );

  const serializeAnswer = (q: SlideQuestion, v: any): { text: string | null; file_url: string | null } => {
    if (v === undefined || v === null || v === "") return { text: null, file_url: null };
    const t = q.type === "dropdown" ? "multiple_choice" : q.type === "legal_checkbox" ? "short_text" : q.type;
    switch (t) {
      case "yes_no":
        return { text: v === "yes" ? "Yes" : "No", file_url: null };
      case "multiple_choice":
        if (Array.isArray(v)) return { text: JSON.stringify(v), file_url: null };
        return { text: String(v), file_url: null };
      case "rating":
        return { text: String(v), file_url: null };
      case "file_upload":
      case "selfie":
        if (typeof v === "object" && v.path) {
          return { text: v.name || null, file_url: `${v.bucket}/${v.path}` };
        }
        return { text: null, file_url: null };
      case "schedule_call":
        if (v && typeof v === "object") {
          if (v.ooo) return { text: "OOO: candidate notified — Talent Team away", file_url: null };
          if (v.slot_id) return { text: `${v.slot_start}|${v.slot_id}`, file_url: null };
        }
        return { text: null, file_url: null };
      default:
        return { text: String(v), file_url: null };
    }
  };

  const findScheduleQ = useCallback(
    () => middleQs.find((q) => q.type === "schedule_call"),
    [middleQs]
  );

  // ─── Resume detection ─────────────────────────────────────────────────────
  useEffect(() => {
    if (mode !== "candidate" || !formId || resumeChecked) return;
    const run = async () => {
      // Prefer ?resume=<token> in URL (cross-device link); else localStorage.
      const url = new URL(window.location.href);
      const urlToken = url.searchParams.get("resume");
      const stored = loadResume(formId);
      const token = urlToken || stored?.sessionToken || null;
      if (!token) { setResumeChecked(true); return; }
      try {
        const { data, error } = await supabase.functions.invoke<{
          found: boolean;
          response_id?: string;
          form_id?: string;
          current_question_index?: number;
          answers?: { question_id: string; answer_text: string | null; file_url: string | null }[];
        }>("resume-response", { body: { session_token: token, form_id: formId } });
        if (error || !data?.found || !data.response_id) {
          clearResume(formId);
          setResumeChecked(true);
          return;
        }
        // Rehydrate answers map from stored rows.
        const restored: Record<string, any> = {};
        for (const a of data.answers || []) {
          const q = middleQs.find((q) => q.id === a.question_id);
          if (!q) continue;
          if (q.type === "file_upload" || q.type === "selfie") {
            if (a.file_url) {
              const [bucket, ...rest] = a.file_url.split("/");
              restored[a.question_id] = { bucket, path: rest.join("/"), name: a.answer_text || "" };
            }
          } else if (q.type === "multiple_choice") {
            try { restored[a.question_id] = JSON.parse(a.answer_text || ""); }
            catch { restored[a.question_id] = a.answer_text; }
          } else if (q.type === "yes_no") {
            restored[a.question_id] = a.answer_text === "Yes" ? "yes" : "no";
          } else {
            restored[a.question_id] = a.answer_text;
          }
        }
        setResumePrompt({
          answers: restored,
          questionIndex: Math.max(0, Math.min(data.current_question_index ?? 0, total - 1)),
          responseId: data.response_id,
          sessionToken: token,
        });
      } catch (e) {
        console.warn("[resume] check failed", e);
      } finally {
        setResumeChecked(true);
      }
    };
    run();
  }, [formId, mode, middleQs, total, resumeChecked]);

  const continueResume = () => {
    if (!resumePrompt || !formId) return;
    setAnswers(resumePrompt.answers);
    setResponseId(resumePrompt.responseId);
    setSessionToken(resumePrompt.sessionToken);
    saveResume(formId, {
      responseId: resumePrompt.responseId,
      sessionToken: resumePrompt.sessionToken,
      formId,
      startedAt: Date.now(),
    });
    setIdx(resumePrompt.questionIndex);
    setResumePrompt(null);
  };
  const startOverResume = () => {
    if (formId) clearResume(formId);
    setResumePrompt(null);
  };

  // ─── save-progress wrapper ────────────────────────────────────────────────
  const wait = (ms: number) => new Promise((resolve) => setTimeout(resolve, ms));

  const saveProgress = useCallback(
    async (opts: {
      questionToSave?: SlideQuestion | null;
      nextIndex?: number;
      complete?: boolean;
      answerSnapshot?: Record<string, any>;
    }) => {
      if (mode !== "candidate" || !formId) return { ok: true };
      const { questionToSave, nextIndex, complete } = opts;
      const answerSnapshot = opts.answerSnapshot || answers;
      const ser = questionToSave
        ? serializeAnswer(questionToSave, answerSnapshot[questionToSave.id])
        : { text: null, file_url: null };

      // For completion: find schedule_call slot if any and attach metadata.
      let slotId: string | null = null;
      let candidateEmail: string | null = null;
      let candidateName: string | null = null;
      if (complete) {
        const sq = findScheduleQ();
        const sv = sq ? answerSnapshot[sq.id] : null;
        if (sv?.slot_id && !sv?.ooo) slotId = sv.slot_id;
        for (const q of middleQs) {
          if (q.type === "email" && !candidateEmail && answerSnapshot[q.id]) {
            candidateEmail = String(answerSnapshot[q.id]);
          }
          if (q.type === "short_text" && !candidateName && /name/i.test(q.label || "") && answerSnapshot[q.id]) {
            candidateName = String(answerSnapshot[q.id]);
          }
        }
      }

      setSaveStatus("saving");
      try {
        let data: any = null;
        let error: any = null;
        const body = {
          response_id: responseId || undefined,
          session_token: sessionToken || undefined,
          form_id: formId,
          question_id: questionToSave?.id,
          answer_text: questionToSave ? ser.text : undefined,
          file_url: questionToSave ? ser.file_url : undefined,
          current_question_index: typeof nextIndex === "number" ? nextIndex : undefined,
          complete: !!complete,
          slot_id: slotId,
          candidate_email: candidateEmail,
          candidate_name: candidateName,
        };
        for (let attempt = 0; attempt < 3; attempt += 1) {
          const res = await supabase.functions.invoke("save-progress", { body });
          data = res.data;
          error = res.error;
          if (!error && data?.ok) break;
          if (attempt < 2) await wait(300 * (attempt + 1));
        }
        if (error || !data?.ok) {
          console.error("[save-progress] failed", { error, data, responseId, qid: questionToSave?.id });
          setSaveStatus("error");
          return {
            ok: false,
            errorCode: (data as any)?.error || (error as any)?.message || "save_failed",
            booking: null as any,
          };
        }
        if (data.response_id && data.response_id !== responseId) {
          setResponseId(data.response_id);
        }
        if (data.session_token && data.session_token !== sessionToken) {
          setSessionToken(data.session_token);
        }
        if (formId && data.response_id && data.session_token) {
          saveResume(formId, {
            responseId: data.response_id,
            sessionToken: data.session_token,
            formId,
            startedAt: Date.now(),
          });
        }
        setSaveStatus("saved");
        return { ok: true, booking: data.booking || null };
      } catch (err) {
        console.error("[save-progress] threw", err);
        setSaveStatus("error");
        return { ok: false, errorCode: "network", booking: null as any };
      }
    },
    [answers, formId, mode, responseId, sessionToken, middleQs, findScheduleQ]
  );

  // ─── Navigation ───────────────────────────────────────────────────────────
  const goTo = (n: number) => {
    setTransitioning(true);
    setTimeout(() => {
      setIdx(n);
      setTransitioning(false);
    }, 200);
  };

  const advance = async (valueOverride?: any) => {
    if (mode === "preview") {
      // Preview keeps simple behavior — no persistence, just navigate.
      if (idx >= total - 1) return;
      goTo(Math.min(idx + 1, total - 1));
      return;
    }

    if (!current || submitting) return;

    // Welcome → create response if needed, then jump to first middle question.
    if (current.type === "welcome") {
      setSubmitting(true);
      setSubmitError(null);
      const res = await saveProgress({ nextIndex: 1 });
      setSubmitting(false);
      if (!res.ok) {
        setSubmitError("We couldn't start your application. Please check your connection and try again.");
        return;
      }
      goTo(Math.min(idx + 1, total - 1));
      return;
    }

    // Already past the last answerable question (e.g. on thank_you) → no-op.
    if (current.type === "thank_you") return;

    const isLast = idx === lastBeforeThank;
    const answerSnapshot = valueOverride !== undefined ? { ...answers, [current.id]: valueOverride } : answers;

    setSubmitting(true);
    setSubmitError(null);
    const res = await saveProgress({
      questionToSave: current,
      nextIndex: isLast ? idx : idx + 1,
      complete: isLast,
      answerSnapshot,
    });
    setSubmitting(false);

    if (!res.ok) {
      const code = (res as any).errorCode || "";
      let msg = "Couldn't save your answer. Please check your connection and try again.";
      if (code === "booking_failed") {
        msg = "Your reserved slot is no longer available. Please pick a new time.";
        const sq = findScheduleQ();
        if (sq) {
          setAnswers((a) => ({ ...a, [sq.id]: null }));
          const i = questions.findIndex((q) => q.id === sq.id);
          if (i >= 0) setTimeout(() => goTo(i), 100);
        }
      } else if (code === "booking_unavailable") {
        msg = "Booking system temporarily unavailable. Please try again shortly.";
      } else if (code === "form_not_live") {
        msg = "This form is no longer accepting responses.";
      } else if (code === "already_completed") {
        msg = "This application has already been submitted.";
      } else if (code) {
        msg = `${msg} (${code})`;
      }
      setSubmitError(msg);
      return;
    }

    if (isLast) {
      setSubmitted(true);
      if (res.booking) {
        const candidateEmail =
          middleQs.map((q) => (q.type === "email" ? answerSnapshot[q.id] : null)).find(Boolean) || null;
        setBookedInterview({
          displayDate: res.booking.display_date,
          displayTime: res.booking.display_time,
          email: candidateEmail ? String(candidateEmail) : null,
        });
      }
      if (formId) clearResume(formId);
      if (thankIdx >= 0) goTo(thankIdx);
      return;
    }

    goTo(Math.min(idx + 1, total - 1));
  };

  const prev = () => {
    if (idx <= 0) return;
    goTo(Math.max(idx - 1, 0));
  };

  useEffect(() => {
    setIdx(0);
    setAnswers({});
    setSubmitted(false);
  }, [questions.map((q) => q.id).join(",")]);

  // Preview-mode external selection
  useEffect(() => {
    if (mode !== "preview" || !activeId) return;
    const i = questions.findIndex((q) => q.id === activeId);
    if (i >= 0) setIdx(i);
  }, [activeId, mode, questions]);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (submitting) return;
      const tag = (e.target as HTMLElement)?.tagName;
      const isInput = tag === "INPUT" || tag === "TEXTAREA";
      if (!current) return;
      if (current.type === "yes_no" && !isInput) {
        if (e.key === "y" || e.key === "Y") {
          setAnswers((a) => ({ ...a, [current.id]: "yes" }));
          setTimeout(advance, 250);
        } else if (e.key === "n" || e.key === "N") {
          setAnswers((a) => ({ ...a, [current.id]: "no" }));
          setTimeout(advance, 250);
        }
        return;
      }
      if (e.key === "Enter") {
        if (current.type === "long_text" && isInput && !(e.metaKey || e.ctrlKey)) return;
        if (current.type === "thank_you") return;
        e.preventDefault();
        advance();
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [current, idx, answers, submitting]);

  if (!current) return null;

  const middleIdx =
    current.type !== "welcome" && current.type !== "thank_you"
      ? middleQs.findIndex((q) => q.id === current.id) + 1
      : 0;

  const isLastAnswerable = mode === "candidate" && idx === lastBeforeThank;
  const progress = total ? ((idx + 1) / total) * 100 : 0;

  // ─── Resume overlay ───────────────────────────────────────────────────────
  if (mode === "candidate" && resumePrompt) {
    return (
      <div className={`relative w-full ${themeClass} min-h-[100dvh] flex items-center justify-center px-4`}>
        <div className="w-full max-w-md rounded-xl border border-border bg-background p-6 text-center space-y-4 shadow-lg">
          <RotateCcw className="h-8 w-8 mx-auto text-primary" />
          <h2 className="text-xl font-semibold">Welcome back</h2>
          <p className="text-sm text-muted-foreground">
            You started this application earlier. Pick up where you left off, or start fresh.
          </p>
          <div className="flex gap-3 pt-2">
            <Button variant="outline" className="flex-1" onClick={startOverResume}>
              Start over
            </Button>
            <Button className="flex-1" onClick={continueResume}>
              Continue <ArrowRight className="h-4 w-4 ml-1" />
            </Button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className={`relative w-full ${themeClass}`} style={{ minHeight: mode === "candidate" ? "100dvh" : "100%" }}>
      <div
        className="fixed top-0 left-0 right-0 h-[4px] bg-secondary z-20 shadow-sm"
        hidden={mode !== "candidate"}
      >
        <div
          className="h-full bg-primary transition-all duration-300 ease-out"
          style={{ width: `${progress}%` }}
        />
      </div>
      <EiaWordmark
        align="right"
        className="absolute top-4 right-4 md:top-5 md:right-6 z-30 pointer-events-none select-none"
      />
      {mode === "candidate" && (
        <div className="fixed top-3 left-4 md:top-4 md:left-6 text-xs md:text-sm text-muted-foreground font-medium z-20 px-2 py-1 flex items-center gap-2">
          <span>{idx + 1} <span className="opacity-50 mx-0.5">/</span> {total}</span>
          {saveStatus === "saving" && (
            <span className="text-[10px] uppercase tracking-wide opacity-70 flex items-center gap-1">
              <Loader2 className="h-3 w-3 animate-spin" /> Saving…
            </span>
          )}
          {saveStatus === "saved" && (
            <span className="text-[10px] uppercase tracking-wide opacity-60">Saved</span>
          )}
          {saveStatus === "error" && (
            <span className="text-[10px] uppercase tracking-wide text-destructive">Save failed</span>
          )}
        </div>
      )}
      <div
        className={`flex items-center justify-center w-full transition-all duration-300 ease-out ${
          transitioning ? "opacity-0 translate-y-2" : "opacity-100 translate-y-0"
        }`}
        style={{ minHeight: mode === "candidate" ? "100dvh" : "60vh" }}
      >
        <div className="w-full">
          {current.type === "thank_you" && bookedInterview && mode === "candidate" ? (
            <InterviewConfirmedScreen
              positionTitle={positionTitle}
              candidateEmail={bookedInterview.email}
              displayDate={bookedInterview.displayDate}
              displayTime={bookedInterview.displayTime}
            />
          ) : (
            <Slide
              question={current}
              index={middleIdx}
              mode={mode}
              value={answers[current.id]}
              onChange={(v) => setAnswers((a) => ({ ...a, [current.id]: v }))}
              onAdvance={advance}
              onPrev={prev}
              canPrev={idx > 0 && current.type !== "thank_you" && current.type !== "welcome"}
              submitting={submitting}
              submitLabel={isLastAnswerable ? "Submit" : undefined}
              formId={formId}
              uploadSessionId={uploadSessionId}
            />
          )}

          {/* Welcome-screen privacy notice */}
          {mode === "candidate" && current.type === "welcome" && (
            <p className="max-w-md mx-auto mt-6 px-4 text-center text-xs text-muted-foreground">
              Your responses are saved automatically as you progress. You can return to complete this application within 24 hours.
            </p>
          )}

          {submitError && mode === "candidate" && (
            <div className="max-w-2xl mx-auto px-4 mt-6 text-center space-y-3" role="alert">
              <p className="text-base font-semibold text-destructive">
                Something went wrong
              </p>
              <p className="text-sm text-muted-foreground whitespace-pre-line">
                {submitError}
              </p>
              <div className="flex flex-col items-center gap-2 pt-2">
                <Button onClick={advance} disabled={submitting}>
                  {submitting ? (
                    <><Loader2 className="h-4 w-4 mr-2 animate-spin" /> Retrying...</>
                  ) : (
                    "Retry"
                  )}
                </Button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default SlideRunner;
