import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Dialog, DialogContent } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Download, FileText as FileIcon, Loader2, X } from "lucide-react";
import { toast } from "sonner";

const KNOWN_BUCKETS = ["candidate-files", "candidate-selfies", "resumes", "selfies"];

export const parseFilePath = (file_url: string): { bucket: string; path: string; name: string } => {
  const parts = file_url.split("/");
  let bucket = "candidate-files";
  let pathParts = parts;
  if (parts.length > 1 && KNOWN_BUCKETS.includes(parts[0])) {
    bucket = parts[0];
    pathParts = parts.slice(1);
  }
  const path = pathParts.join("/");
  const last = pathParts[pathParts.length - 1] || "file";
  const name = last.replace(/^\d+-/, "");
  return { bucket, path, name };
};

export const isImageName = (name: string) =>
  /\.(jpe?g|png|gif|webp|bmp|svg|heic|heif|avif|tiff?)$/i.test(name);
export const isHeicName = (name: string) => /\.(heic|heif)$/i.test(name);
export const isPdfName = (name: string) => /\.pdf$/i.test(name);
export const isOfficeName = (name: string) => /\.(docx?|xlsx?|pptx?)$/i.test(name);

const mimeFromName = (name: string) => {
  const ext = name.split(".").pop()?.toLowerCase();
  switch (ext) {
    case "jpg": case "jpeg": return "image/jpeg";
    case "png": return "image/png";
    case "gif": return "image/gif";
    case "webp": return "image/webp";
    case "bmp": return "image/bmp";
    case "svg": return "image/svg+xml";
    case "avif": return "image/avif";
    case "heic": return "image/heic";
    case "heif": return "image/heif";
    case "tif": case "tiff": return "image/tiff";
    case "pdf": return "application/pdf";
    default: return "application/octet-stream";
  }
};

export const downloadFile = async (file_url: string) => {
  try {
    const { bucket, path, name } = parseFilePath(file_url);
    const { data, error } = await supabase.storage
      .from(bucket).createSignedUrl(path, 60, { download: name });
    if (error || !data?.signedUrl) { toast.error("Could not download file"); return; }
    let objectUrl: string | null = null;
    let href = data.signedUrl;
    try {
      const resp = await fetch(data.signedUrl);
      const blob = await resp.blob();
      objectUrl = URL.createObjectURL(blob);
      href = objectUrl;
    } catch {}
    const a = document.createElement("a");
    a.href = href; a.download = name; a.rel = "noopener";
    document.body.appendChild(a); a.click(); document.body.removeChild(a);
    if (objectUrl) setTimeout(() => URL.revokeObjectURL(objectUrl!), 1000);
  } catch { toast.error("Could not download file"); }
};

export const SelfieThumb = ({
  file_url, size = 80, onPreview, className,
}: { file_url: string; size?: number; onPreview: () => void; className?: string }) => {
  const [url, setUrl] = useState<string | null>(null);
  const [failed, setFailed] = useState(false);
  useEffect(() => {
    const meta = parseFilePath(file_url);
    let cancelled = false;
    let objectUrl: string | null = null;
    setFailed(false); setUrl(null);
    (async () => {
      const { data } = await supabase.storage.from(meta.bucket).createSignedUrl(meta.path, 600);
      if (cancelled || !data?.signedUrl) return;
      if (isHeicName(meta.name)) {
        try {
          const resp = await fetch(data.signedUrl);
          const blob = await resp.blob();
          const heic2any = (await import("heic2any")).default;
          const converted = await heic2any({ blob, toType: "image/jpeg", quality: 0.8 });
          const outBlob = Array.isArray(converted) ? converted[0] : converted;
          objectUrl = URL.createObjectURL(outBlob as Blob);
          if (!cancelled) setUrl(objectUrl);
        } catch { if (!cancelled) setFailed(true); }
      } else {
        if (!cancelled) setUrl(data.signedUrl);
      }
    })();
    return () => { cancelled = true; if (objectUrl) URL.revokeObjectURL(objectUrl); };
  }, [file_url]);
  return (
    <button
      type="button"
      onClick={(e) => { e.stopPropagation(); onPreview(); }}
      className={
        "rounded-lg overflow-hidden border border-border bg-secondary hover:ring-2 hover:ring-primary/60 transition-all inline-block align-middle cursor-pointer " +
        (className || "")
      }
      style={{ width: size, height: size }}
      aria-label="View image"
    >
      {url ? (
        <img src={url} alt="File preview thumbnail" className="w-full h-full object-cover" onError={() => setFailed(true)} />
      ) : failed ? (
        <div className="w-full h-full flex items-center justify-center text-muted-foreground text-[10px]">img</div>
      ) : (
        <div className="w-full h-full flex items-center justify-center text-muted-foreground text-[10px]">…</div>
      )}
    </button>
  );
};

export const FilePreviewDialog = ({
  file_url, onClose,
}: { file_url: string | null; onClose: () => void }) => {
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const [remoteUrl, setRemoteUrl] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const meta = file_url ? parseFilePath(file_url) : null;

  useEffect(() => {
    if (!file_url || !meta) { setPreviewUrl(null); return; }
    let cancelled = false;
    let objectUrl: string | null = null;
    setLoading(true); setPreviewUrl(null); setRemoteUrl(null);
    supabase.storage.from(meta.bucket).createSignedUrl(meta.path, 600).then(async ({ data, error }) => {
      if (error || !data?.signedUrl) {
        if (!cancelled) { toast.error("Could not load file"); setLoading(false); }
        return;
      }
      try {
        if (isOfficeName(meta.name)) { if (!cancelled) setRemoteUrl(data.signedUrl); return; }
        const resp = await fetch(data.signedUrl);
        if (!resp.ok) throw new Error("Preview fetch failed");
        let blob = await resp.blob();
        let outType = mimeFromName(meta.name);
        if (isHeicName(meta.name)) {
          const heic2any = (await import("heic2any")).default;
          const converted = await heic2any({ blob, toType: "image/jpeg", quality: 0.9 });
          blob = (Array.isArray(converted) ? converted[0] : converted) as Blob;
          outType = "image/jpeg";
        }
        const typedBlob = new Blob([blob], { type: outType });
        objectUrl = URL.createObjectURL(typedBlob);
        if (!cancelled) setPreviewUrl(objectUrl);
      } catch { if (!cancelled) toast.error("Could not load file"); }
      finally { if (!cancelled) setLoading(false); }
    });
    return () => { cancelled = true; if (objectUrl) URL.revokeObjectURL(objectUrl); };
  }, [file_url]);

  useEffect(() => () => { if (previewUrl) URL.revokeObjectURL(previewUrl); }, [previewUrl]);

  const isImg = meta && isImageName(meta.name);
  const isPdf = meta && isPdfName(meta.name);
  const isOffice = meta && isOfficeName(meta.name);

  return (
    <Dialog open={!!file_url} onOpenChange={(o) => !o && onClose()}>
      <DialogContent showClose={false} className="max-w-5xl w-[95vw] h-[90vh] p-0 flex flex-col gap-0">
        <button
          type="button"
          onClick={onClose}
          aria-label="Close preview"
          className="absolute top-3 right-3 z-50 flex items-center justify-center min-w-[44px] min-h-[44px] rounded-full text-white bg-black/50 hover:bg-black/75 transition-colors"
        >
          <X className="h-5 w-5" />
        </button>
        <div className="flex items-center justify-between gap-3 px-4 py-3 border-b border-border">
          <div className="text-sm font-medium truncate flex-1" title={meta?.name}>{meta?.name}</div>
          <Button size="sm" onClick={() => file_url && downloadFile(file_url)} className="shrink-0 mr-12">
            <Download className="h-4 w-4 mr-1.5" /> Download
          </Button>
        </div>
        <div className="flex-1 min-h-0 bg-muted/30 overflow-auto flex items-center justify-center">
          {loading || (!previewUrl && !remoteUrl) ? (
            <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
          ) : isImg ? (
            <img src={previewUrl!} alt={meta?.name} className="max-w-full max-h-full object-contain" />
          ) : isPdf ? (
            <iframe src={previewUrl!} title={meta?.name} className="w-full h-full border-0" />
          ) : isOffice && remoteUrl ? (
            <iframe
              src={`https://view.officeapps.live.com/op/embed.aspx?src=${encodeURIComponent(remoteUrl)}`}
              title={meta?.name} className="w-full h-full border-0"
            />
          ) : (
            <div className="text-center p-8 space-y-3">
              <FileIcon className="h-12 w-12 mx-auto text-muted-foreground" />
              <div className="text-sm text-muted-foreground">Preview not available for this file type.</div>
              <Button onClick={() => file_url && downloadFile(file_url)}>
                <Download className="h-4 w-4 mr-1.5" /> Download
              </Button>
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
};
