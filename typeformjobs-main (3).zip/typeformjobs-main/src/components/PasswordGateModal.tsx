import { useEffect, useState } from "react";
import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Loader2 } from "lucide-react";

type EmailField = {
  label?: string;
  initialValue?: string;
  helpText?: string;
};

type Props = {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  title: string;
  description?: string;
  confirmLabel?: string;
  emailField?: EmailField;
  onConfirm: (password: string, extras?: { email?: string }) => Promise<void> | void;
};

export default function PasswordGateModal({
  open, onOpenChange, title, description, confirmLabel = "Confirm", emailField, onConfirm,
}: Props) {
  const [pwd, setPwd] = useState("");
  const [email, setEmail] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (open) {
      setEmail(emailField?.initialValue || "");
      setPwd("");
      setError(null);
    }
  }, [open, emailField?.initialValue]);

  const emailValid = !emailField || /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim());

  const handle = async () => {
    if (emailField && !emailValid) {
      setError("Enter a valid email address");
      return;
    }
    setError(null);
    setBusy(true);
    try {
      await onConfirm(pwd, emailField ? { email: email.trim() } : undefined);
      setPwd("");
      onOpenChange(false);
    } catch (e: any) {
      setError(e?.message || "Incorrect password");
    } finally {
      setBusy(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={(o) => { if (!busy) { onOpenChange(o); if (!o) { setPwd(""); setError(null); } } }}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>{title}</DialogTitle>
          {description && <DialogDescription>{description}</DialogDescription>}
        </DialogHeader>
        <div className="space-y-3">
          {emailField && (
            <div className="space-y-1.5">
              <Label htmlFor="pgm-email">{emailField.label || "Send to"}</Label>
              <Input
                id="pgm-email"
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="name@example.com"
              />
              {emailField.helpText && (
                <p className="text-xs text-muted-foreground">{emailField.helpText}</p>
              )}
            </div>
          )}
          <div className="space-y-1.5">
            {emailField && <Label htmlFor="pgm-pwd">Override password</Label>}
            <Input
              id="pgm-pwd"
              type="password"
              value={pwd}
              autoFocus={!emailField}
              placeholder="Enter override password"
              onChange={(e) => setPwd(e.target.value)}
              onKeyDown={(e) => { if (e.key === "Enter") handle(); }}
            />
          </div>
          {error && <p className="text-sm text-destructive">{error}</p>}
        </div>
        <DialogFooter>
          <Button variant="ghost" onClick={() => onOpenChange(false)} disabled={busy}>Cancel</Button>
          <Button onClick={handle} disabled={busy || !pwd || (emailField ? !emailValid : false)}>
            {busy ? <><Loader2 className="h-4 w-4 mr-2 animate-spin" />Verifying</> : confirmLabel}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
