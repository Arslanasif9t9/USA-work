import { useEffect, useRef, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { LifeBuoy, Loader2, Mail } from "lucide-react";
import { toast } from "sonner";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import SendScheduleControl, { type SendScheduleValue } from "@/components/SendScheduleControl";
import ScheduledSendChip from "@/components/ScheduledSendChip";
import { insertScheduledSend } from "@/lib/scheduledSends";

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

type Props = {
  responseId: string;
  candidateName: string;
  candidateEmail: string;
  size?: "sm" | "lg";
  /**
   * Visual style:
   *  - "stack"  → uses the per-row action-btn helper (My Bookings ActionsCell)
   *  - "outline" → shadcn outline Button (Scout Report action area)
   */
  appearance?: "stack" | "outline";
  /**
   * Eligibility override. When provided (e.g. Scout Report already knows the
   * session failed), the button renders without doing its own DB check. When
   * omitted, the component self-determines eligibility from the response's
   * round_stage + latest ai_interview_sessions row.
   */
  eligible?: boolean;
};

const stackClass = (size: "sm" | "lg") =>
  `action-btn ${size === "lg" ? "action-btn--lg" : ""} action-btn--primary`;

// "invited but not completed": round_stage in round_1_sent/round_2_sent/
// ai_interview_completed (the webhook flips to completed on ANY call_ended,
// even a 6-second bail), not disqualified/cancelled, AND the candidate is
// NOT truly completed — i.e. NOT (a session >= 240s / 4 min with a non-error
// termination). No session, short sessions, or only failed sessions = still
// recoverable.
const COMPLETED_MIN_SECONDS = 240; // 4 minutes
const isFailedReason = (reason: string | null | undefined) => {
  const r = (reason || "").toLowerCase();
  return /(error|not_joined|failed|abandon)/i.test(r);
};
// agentEnded = the AGENT ended the call (a real finished interview even if short).
const AGENT_ENDED_REASONS = new Set(["agent_hangup", "max_duration_reached"]);
// SMART COMPLETION RULE: completed = NOT trueBail AND (agentEnded OR dur >= 240).
const isSessionCompleted = (reason: string | null | undefined, dur: number | null | undefined) => {
  if (isFailedReason(reason)) return false;
  const agentEnded = AGENT_ENDED_REASONS.has((reason || "").toLowerCase());
  return agentEnded || (dur ?? 0) >= COMPLETED_MIN_SECONDS;
};
// Cooldown so a rapid second click cannot double-send (in addition to busy).
const NUDGE_COOLDOWN_MS = 4000;

export const RecoverInterviewButton = ({
  responseId, candidateName, candidateEmail, size = "sm", appearance = "stack", eligible,
}: Props) => {
  const [show, setShow] = useState(eligible === true);
  const [checked, setChecked] = useState(eligible !== undefined);
  const [open, setOpen] = useState(false);
  const [email, setEmail] = useState(candidateEmail || "");
  const [busy, setBusy] = useState(false);
  // Now / Later schedule choice (defaults to "now", registered on mount).
  const [schedule, setSchedule] = useState<SendScheduleValue>({ mode: "now" });
  // Bump to force the ScheduledSendChip to re-fetch after a Later schedule.
  const [chipKey, setChipKey] = useState(0);
  // Nudge send counter (+1/+2/+3 badge) sourced from candidate_actions.
  const [nudgeCount, setNudgeCount] = useState(0);
  // Cooldown timestamp: blocks a rapid second click from double-sending.
  const lastSendRef = useRef(0);

  useEffect(() => {
    let cancelled = false;
    (async () => {
      const { data } = await supabase
        .from("candidate_actions")
        .select("nudge_resend_count")
        .eq("response_id", responseId)
        .maybeSingle();
      if (!cancelled) setNudgeCount((data as any)?.nudge_resend_count ?? 0);
    })();
    return () => { cancelled = true; };
  }, [responseId, chipKey]);

  // Self-determine eligibility only when no override is supplied.
  useEffect(() => {
    if (eligible !== undefined) { setShow(eligible === true); setChecked(true); return; }
    let cancelled = false;
    (async () => {
      const { data: resp } = await supabase
        .from("responses")
        .select("round_stage, appointment_cancelled, disqualified_at")
        .eq("id", responseId)
        .maybeSingle();
      if (cancelled) return;
      const stage = (resp as any)?.round_stage;
      const invited = stage === "round_1_sent" || stage === "round_2_sent" || stage === "ai_interview_completed";
      const blocked = (resp as any)?.disqualified_at || stage === "disqualified" || (resp as any)?.appointment_cancelled === true;
      if (!invited || blocked) { setShow(false); setChecked(true); return; }

      // Latest session for this response.
      const { data: sess } = await supabase
        .from("ai_interview_sessions")
        .select("duration_seconds, termination_reason")
        .eq("response_id", responseId)
        .order("created_at", { ascending: false })
        .limit(1)
        .maybeSingle();
      if (cancelled) return;
      const noSession = !sess;
      // SMART COMPLETION RULE: agent-ended OR >=240s, and not a true bail.
      const completed = !!sess &&
        isSessionCompleted((sess as any).termination_reason, (sess as any).duration_seconds);
      setShow(noSession || !completed);
      setChecked(true);
    })();
    return () => { cancelled = true; };
  }, [responseId, eligible]);

  useEffect(() => { if (open) setEmail(candidateEmail || ""); }, [open, candidateEmail]);

  if (!checked || !show) return null;

  const submit = async () => {
    const cleaned = email.trim();
    if (!EMAIL_RE.test(cleaned)) { toast.error("Enter a valid candidate email"); return; }
    // Cooldown guard: ignore a rapid second click (in addition to busy state).
    if (busy) return;
    const nowMs = Date.now();
    if (schedule.mode !== "schedule" && nowMs - lastSendRef.current < NUDGE_COOLDOWN_MS) return;
    lastSendRef.current = nowMs;
    setBusy(true);
    try {
      // Payload is byte-identical for the Now path and the scheduled Later path.
      const payload = { response_id: responseId, override_email: cleaned };

      if (schedule.mode === "schedule") {
        await insertScheduledSend({
          send_type: "nudge",
          target_function: "recover-interview-email",
          payload,
          response_id: responseId,
          scheduled_for_utc: schedule.scheduled_for_utc,
          timezone: schedule.timezone,
        });
        toast.success(`Nudge scheduled for ${cleaned}`);
        setChipKey((k) => k + 1);
        setOpen(false);
        return;
      }

      const { data, error } = await supabase.functions.invoke("recover-interview-email", {
        body: payload,
      });
      const errMsg = (data as any)?.error || error?.message;
      if (errMsg) {
        if (errMsg === "missing_email") toast.error("Add an email for this candidate first");
        else if (errMsg === "not_recoverable") toast.error("This candidate is no longer eligible for recovery");
        else toast.error(errMsg);
        return;
      }
      const newCount = (data as any)?.nudge_resend_count;
      if (typeof newCount === "number") setNudgeCount(newCount);
      else setNudgeCount((n) => n + 1);
      toast.success(`Nudge sent to ${cleaned}`);
      setOpen(false);
    } catch (e: any) {
      toast.error(e?.message || "Could not send nudge");
    } finally {
      setBusy(false);
    }
  };

  const ico = size === "lg" ? "h-4 w-4 mr-2" : "h-3.5 w-3.5 mr-1.5";

  return (
    <>
      {appearance === "outline" ? (
        <span className="inline-flex items-center gap-2">
          <Button size="sm" className="min-h-[36px] bg-blue-600 hover:bg-blue-700 text-white" onClick={() => setOpen(true)}>
            <LifeBuoy className="h-4 w-4 mr-1.5" /> Nudge Now
            {nudgeCount > 0 && (
              <span className={`ml-1.5 inline-flex items-center justify-center rounded-full px-1.5 text-[11px] font-semibold ${
                nudgeCount >= 3 ? "bg-rose-100 text-rose-700"
                : nudgeCount === 2 ? "bg-amber-100 text-amber-700"
                : "bg-sky-100 text-sky-700"
              }`}>+{nudgeCount}</span>
            )}
          </Button>
          <ScheduledSendChip key={chipKey} responseId={responseId} />
        </span>
      ) : (
        <button type="button" className={stackClass(size)} onClick={() => setOpen(true)}>
          <LifeBuoy className={ico} /> Recover — Not Completed
          {nudgeCount > 0 && <span className="ml-1.5 font-semibold">+{nudgeCount}</span>}
        </button>
      )}

      <Dialog open={open} onOpenChange={(o) => !busy && setOpen(o)}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <LifeBuoy className="h-4 w-4" /> Nudge candidate
            </DialogTitle>
            <DialogDescription>
              {candidateName || "The candidate"} will receive a warm, no-blame reminder with a
              fresh link to finish their interview. The link expires in 3 days.
            </DialogDescription>
          </DialogHeader>
          <form onSubmit={(e) => { e.preventDefault(); submit(); }} className="space-y-3">
            <div className="space-y-1.5">
              <Label className="flex items-center gap-1.5">
                <Mail className="h-3.5 w-3.5" /> Send to
              </Label>
              <Input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="name@example.com"
                autoComplete="off"
                autoFocus={!candidateEmail}
              />
              <p className="text-xs text-muted-foreground">
                Edits here save as the override email for this candidate.
              </p>
            </div>
            <SendScheduleControl onChange={setSchedule} />
            <DialogFooter>
              <Button type="button" variant="ghost" onClick={() => setOpen(false)} disabled={busy}>
                Cancel
              </Button>
              <Button type="submit" disabled={busy}>
                {busy ? <Loader2 className="h-4 w-4 mr-2 animate-spin" /> : <LifeBuoy className="h-4 w-4 mr-2" />}
                {schedule.mode === "schedule" ? "Schedule nudge" : "Send nudge now"}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
    </>
  );
};

export default RecoverInterviewButton;
