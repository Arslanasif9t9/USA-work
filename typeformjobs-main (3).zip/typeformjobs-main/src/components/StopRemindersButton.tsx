import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { BellOff, BellRing, Loader2 } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";

type Props = {
  responseId: string;
  /**
   * Visual style:
   *  - "outline" → shadcn outline Button (Scout Report action area)
   *  - "stack"   → full-width button for My Bookings card stacks
   */
  appearance?: "stack" | "outline";
};

/**
 * Per-candidate toggle for the daily recover-reminder cron. Flips
 * candidate_actions.recover_reminder_opt_out (additive column, single-row write
 * by response_id). When opted out the cron skips the candidate entirely.
 * Self-fetches the current state so it can drop into any row unchanged.
 */
export const StopRemindersButton = ({ responseId, appearance = "outline" }: Props) => {
  const [optedOut, setOptedOut] = useState<boolean | null>(null);
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    let cancelled = false;
    (async () => {
      const { data } = await supabase
        .from("candidate_actions")
        .select("recover_reminder_opt_out")
        .eq("response_id", responseId)
        .maybeSingle();
      if (cancelled) return;
      setOptedOut(!!(data as any)?.recover_reminder_opt_out);
    })();
    return () => { cancelled = true; };
  }, [responseId]);

  if (optedOut === null) return null;

  const toggle = async () => {
    const next = !optedOut;
    setBusy(true);
    try {
      const { error } = await (supabase.from("candidate_actions") as any)
        .update({ recover_reminder_opt_out: next })
        .eq("response_id", responseId);
      if (error) throw error;
      setOptedOut(next);
      toast.success(next ? "Reminders stopped for this candidate" : "Reminders resumed");
    } catch (e: any) {
      toast.error(e?.message || "Could not update reminders");
    } finally {
      setBusy(false);
    }
  };

  const fullWidth = appearance === "stack";
  const sizeClass = fullWidth ? "w-full min-h-[44px]" : "min-h-[36px]";

  return (
    <Button
      size="sm"
      variant="outline"
      className={`${sizeClass} ${optedOut ? "text-emerald-700 border-emerald-300 hover:bg-emerald-50" : "text-amber-700 border-amber-300 hover:bg-amber-50"}`}
      onClick={toggle}
      disabled={busy}
    >
      {busy ? (
        <Loader2 className="h-4 w-4 mr-1.5 animate-spin" />
      ) : optedOut ? (
        <BellRing className="h-4 w-4 mr-1.5" />
      ) : (
        <BellOff className="h-4 w-4 mr-1.5" />
      )}
      {optedOut ? "Resume Reminders" : "Stop Reminders"}
    </Button>
  );
};

export default StopRemindersButton;
