import { useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useHrIdentity } from "@/hooks/useHrIdentity";
import { Button } from "@/components/ui/button";
import {
  AlertDialog,
  AlertDialogContent,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogCancel,
  AlertDialogAction,
} from "@/components/ui/alert-dialog";
import { Checkbox } from "@/components/ui/checkbox";
import { Textarea } from "@/components/ui/textarea";
import { Ban, Loader2 } from "lucide-react";
import { toast } from "sonner";

type Props = {
  responseId: string;
  candidateName?: string;
  size?: "sm" | "lg";
  className?: string;
  /** Optional override for the stage label saved on the row.
   *  Used by the Employees section ("Disqualified after Matched / Employee"). */
  forcedStageLabel?: string;
  /** Extra fields to merge into the update (e.g. final_outcome). */
  extraUpdate?: Record<string, any>;
  /** Hide the rejection-email opt-in (defaults to false). */
  hideEmailOption?: boolean;
  /** Called once the disqualify succeeds (parent may re-sync). */
  onDisqualified?: () => void;
  /** Called immediately on confirm (before DB) so the parent can remove
   *  the row optimistically. */
  onOptimisticRemove?: () => void;
  /** Called if the background update fails, so the parent can restore the row. */
  onRevert?: () => void;
};

export const DisqualifyButton = ({
  responseId,
  candidateName,
  size = "sm",
  className,
  forcedStageLabel,
  extraUpdate,
  hideEmailOption,
  onDisqualified,
  onOptimisticRemove,
  onRevert,
}: Props) => {
  const { hrId } = useHrIdentity();
  const [open, setOpen] = useState(false);
  const [sendEmail, setSendEmail] = useState(false);
  const [reason, setReason] = useState("");
  const [busy, setBusy] = useState(false);

  const handleConfirm = async () => {
    setBusy(true);
    // Optimistic: close dialog and remove row immediately.
    setOpen(false);
    onOptimisticRemove?.();
    try {
      // Look up any currently booked slot + current stage so we can record both.
      const { data: respRow } = await supabase
        .from("responses")
        .select("scheduled_slot_id, round_stage")
        .eq("id", responseId)
        .maybeSingle();
      const slotId = (respRow as any)?.scheduled_slot_id || null;
      const currentStage = (respRow as any)?.round_stage as string | null;
      const stageLabel = forcedStageLabel ||
        (currentStage === "round_1_sent" ? "Round 1"
        : currentStage === "round_2_sent" ? "Round 2"
        : currentStage === "offer_sent" ? "Offer Sent"
        : currentStage === "offer_signed" ? "Offer Signed"
        : "Pre-Round 1");

      const update: Record<string, any> = {
        round_stage: "disqualified",
        disqualified_at: new Date().toISOString(),
        disqualified_by_hr_id: hrId || null,
        disqualified_at_stage: stageLabel,
        removal_reason: reason.trim() || null,
        ...(extraUpdate || {}),
      };

      const { error } = await (supabase
        .from("responses") as any)
        .update(update)
        .eq("id", responseId);
      if (error) throw error;

      // Free the booked slot + cancel Zoom (best-effort, doesn't block UI).
      if (slotId) {
        supabase.functions.invoke("release-slot", {
          body: { slot_id: slotId, reason: "disqualified" },
        }).catch(() => {});
      }

      // Auto-invalidate any active AI interview links so a disqualified
      // candidate can't burn money on a stale link (best-effort, additive).
      supabase.functions.invoke("invalidate-candidate-tokens", {
        body: { response_id: responseId, on_disqualify: true },
      }).catch(() => {});

      // Stop the recover-reminder cron from ever nudging a disqualified
      // candidate (single-row write by response_id, additive only).
      (supabase.from("candidate_actions") as any)
        .update({ recover_reminder_opt_out: true })
        .eq("response_id", responseId)
        .then(() => {}, () => {});

      if (sendEmail && !hideEmailOption) {
        const { error: emailErr } = await supabase.functions.invoke("send-rejection-email", {
          body: { response_id: responseId },
        });
        if (emailErr) {
          toast.warning("Disqualified, but rejection email failed: " + emailErr.message);
        } else {
          toast.success("Disqualified — rejection email sent");
        }
      } else {
        toast.success(slotId ? "Disqualified — slot freed" : "Candidate disqualified");
      }
      onDisqualified?.();
      setReason("");
    } catch (e: any) {
      onRevert?.();
      toast.error(e?.message || "Could not disqualify — reverted");
    } finally {
      setBusy(false);
    }
  };

  const btnSize = size === "lg" ? "default" : "sm";

  return (
    <>
      <Button
        type="button"
        variant="outline"
        size={btnSize}
        className={`text-destructive border-destructive/40 hover:bg-destructive/10 hover:text-destructive ${className || ""}`}
        onClick={(e) => {
          e.stopPropagation();
          setOpen(true);
        }}
      >
        <Ban className={size === "lg" ? "h-4 w-4 mr-2" : "h-3.5 w-3.5 mr-1.5"} />
        Disqualify
      </Button>

      <AlertDialog open={open} onOpenChange={(o) => { if (!busy) { setOpen(o); if (!o) setReason(""); } }}>
        <AlertDialogContent onClick={(e) => e.stopPropagation()}>
          <AlertDialogHeader>
            <AlertDialogTitle>Disqualify {candidateName || "this candidate"}?</AlertDialogTitle>
            <AlertDialogDescription>
              They will move to the Disqualified section. They can re-apply with a new application anytime.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <div className="space-y-3 py-2">
            <div>
              <label className="text-sm font-medium">Reason (optional)</label>
              <Textarea
                value={reason}
                onChange={(e) => setReason(e.target.value)}
                placeholder="e.g. no-show at work, quit before starting, performance concerns…"
                rows={3}
              />
            </div>
            {!hideEmailOption && (
              <label className="flex items-center gap-2 text-sm cursor-pointer">
                <Checkbox checked={sendEmail} onCheckedChange={(v) => setSendEmail(!!v)} />
                <span>Send rejection email to candidate</span>
              </label>
            )}
          </div>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={busy}>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={(e) => { e.preventDefault(); handleConfirm(); }}
              disabled={busy}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              {busy ? (<><Loader2 className="h-4 w-4 mr-2 animate-spin" /> Working…</>) : "Disqualify"}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
};

export default DisqualifyButton;
