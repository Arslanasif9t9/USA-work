import { useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import { Loader2, PauseCircle, PlayCircle } from "lucide-react";
import { toast } from "sonner";
import { HrCopyCheckbox, defaultHrCopyState, type HrCopyState } from "@/components/HrCopyCheckbox";
import SendScheduleControl, { type SendScheduleValue } from "@/components/SendScheduleControl";
import { insertScheduledSend, formatScheduledFor } from "@/lib/scheduledSends";
import { useHrIdentity } from "@/hooks/useHrIdentity";

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

// Shared sender for the universal On Hold / Reactivation notices.
// Now -> invoke; Later -> schedule. Reuses the SAME send-hold-notice payload as Piece 2.
async function sendUniversalHoldNotice(opts: {
  kind: "on_hold" | "reactivation";
  name: string;
  email: string;
  hrCopy: HrCopyState;
  schedule: SendScheduleValue;
}): Promise<string> {
  const name = opts.name.trim();
  const email = opts.email.trim();
  if (!name) throw new Error("Recipient name is required to send the notice");
  if (!email || !EMAIL_RE.test(email)) throw new Error("Valid recipient email is required to send the notice");

  // EXACT payload reused for Now + Later so a scheduled replay is identical.
  // No employee record -> response_id null; recipient guardrail carries the typed email.
  const payload = {
    kind: opts.kind,
    name,
    email,
    effective_date: null,
    rejoin_date: null,
    response_id: null,
    hr_copy_requested: opts.hrCopy.requested === true,
    hr_copy_email_override: opts.hrCopy.requested && opts.hrCopy.override ? opts.hrCopy.override : null,
  };

  if (opts.schedule.mode === "schedule") {
    await insertScheduledSend({
      send_type: opts.kind === "on_hold" ? "hold_notice" : "reactivation_notice",
      target_function: "send-hold-notice",
      payload,
      response_id: null,
      scheduled_for_utc: opts.schedule.scheduled_for_utc,
      timezone: opts.schedule.timezone,
    });
    return `Notice scheduled for ${formatScheduledFor(opts.schedule.scheduled_for_utc, opts.schedule.timezone)}`;
  }

  const { data, error } = await supabase.functions.invoke("send-hold-notice", { body: payload });
  if (error) {
    const reason = (data as any)?.error || error.message || "send_failed";
    throw new Error(String(reason));
  }
  if ((data as any)?.error) throw new Error(String((data as any).error));
  return `Notice sent to ${email}`;
}

export function UniversalHoldButtons() {
  const [holdOpen, setHoldOpen] = useState(false);
  const [removeOpen, setRemoveOpen] = useState(false);
  return (
    <>
      <Button
        size="sm"
        variant="outline"
        onClick={() => setHoldOpen(true)}
        className="min-h-[44px] sm:min-h-0"
        style={{ borderColor: "#b91c1c", color: "#b91c1c" }}
        title="Put any name + email on hold (blocks Sylvia even with no employee record)"
      >
        <PauseCircle className="h-4 w-4 mr-1.5" /> On Hold Anyone
      </Button>
      <Button
        size="sm"
        variant="outline"
        onClick={() => setRemoveOpen(true)}
        className="min-h-[44px] sm:min-h-0"
        style={{ borderColor: "#16a34a", color: "#16a34a" }}
        title="Remove an On Hold block for any name + email"
      >
        <PlayCircle className="h-4 w-4 mr-1.5" /> Remove On Hold Anyone
      </Button>

      {holdOpen && <OnHoldAnyoneModal onClose={() => setHoldOpen(false)} />}
      {removeOpen && <RemoveOnHoldAnyoneModal onClose={() => setRemoveOpen(false)} />}
    </>
  );
}

function OnHoldAnyoneModal({ onClose }: { onClose: () => void }) {
  const { hrId } = useHrIdentity();
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [reason, setReason] = useState("");
  const [emailOn, setEmailOn] = useState(true);
  const [hrCopy, setHrCopy] = useState<HrCopyState>(defaultHrCopyState);
  const [schedule, setSchedule] = useState<SendScheduleValue>({ mode: "now" });
  const [busy, setBusy] = useState(false);

  const submit = async () => {
    const n = name.trim();
    const e = email.trim();
    if (!n && !e) return toast.error("Enter at least a full name or an email");
    if (emailOn && (!e || !EMAIL_RE.test(e))) return toast.error("A valid email is required to send the notice (or uncheck the email option)");
    if (emailOn && !n) return toast.error("A name is required to send the notice (or uncheck the email option)");
    setBusy(true);
    try {
      // Blocklist insert — ACTIVE block (removed_at null). No employee record touched.
      const { error } = await supabase.from("sylvia_blocklist").insert({
        full_name: n || null,
        email: e || null,
        reason: reason.trim() || null,
        created_by_hr_id: hrId,
      });
      if (error) throw error;
      toast.success(`On Hold block added for ${n || e}.`);

      // Optional notice (additive). Unchecked => block silently, send nothing.
      if (emailOn) {
        try {
          const msg = await sendUniversalHoldNotice({ kind: "on_hold", name: n, email: e, hrCopy, schedule });
          toast.success(msg);
        } catch (mailErr: any) {
          toast.error(`Block added, but the email failed: ${mailErr?.message || "send_failed"}`);
        }
      }
      onClose();
    } catch (err: any) {
      toast.error(err?.message || "Failed to add On Hold block");
    } finally {
      setBusy(false);
    }
  };

  return (
    <Dialog open onOpenChange={(o) => !o && !busy && onClose()}>
      <DialogContent className="sm:max-w-[480px] max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <PauseCircle className="h-4 w-4" style={{ color: "#b91c1c" }} /> On Hold Anyone
          </DialogTitle>
          <DialogDescription>
            Put any typed name and/or email on hold — even if there is no employee record (e.g. a suspicious
            person trying to talk to Sylvia). This adds a blocklist entry that Sylvia checks. Enter at least one of name or email.
          </DialogDescription>
        </DialogHeader>
        <div className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="uh-name">Full name</Label>
            <Input id="uh-name" value={name} onChange={(ev) => setName(ev.target.value)} placeholder="Jane Doe" className="min-h-[44px] sm:min-h-0" disabled={busy} />
          </div>
          <div className="space-y-2">
            <Label htmlFor="uh-email">Email</Label>
            <Input id="uh-email" type="email" value={email} onChange={(ev) => setEmail(ev.target.value)} placeholder="jane@example.com" className="min-h-[44px] sm:min-h-0" disabled={busy} />
          </div>
          <div className="space-y-2">
            <Label htmlFor="uh-reason">Reason (optional)</Label>
            <Textarea id="uh-reason" value={reason} onChange={(ev) => setReason(ev.target.value)} placeholder="Why this identity is on hold" disabled={busy} />
          </div>

          <label htmlFor="uh-email-on" className="flex items-start gap-2 cursor-pointer rounded-md border bg-muted/30 p-3">
            <Checkbox id="uh-email-on" checked={emailOn} onCheckedChange={(v) => setEmailOn(!!v)} disabled={busy} className="mt-0.5" />
            <div className="flex-1 min-w-0">
              <div className="text-sm font-medium text-foreground leading-snug">Email this identity an On Hold notice</div>
              <div className="text-xs text-muted-foreground mt-0.5">On by default. Uncheck to add the block silently with no email.</div>
            </div>
          </label>

          {emailOn && (
            <div className="space-y-4">
              <p className="text-xs text-muted-foreground">A copy is always sent to the internal Outlook backup inbox.</p>
              <HrCopyCheckbox value={hrCopy} onChange={setHrCopy} disabled={busy} label="Also send a copy to" idPrefix="uh-hrcopy" />
              <SendScheduleControl onChange={setSchedule} />
            </div>
          )}
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={onClose} disabled={busy} className="min-h-[44px] sm:min-h-0">Cancel</Button>
          <Button onClick={submit} disabled={busy} className="min-h-[44px] sm:min-h-0 text-white" style={{ backgroundColor: "#b91c1c" }}>
            {busy ? <><Loader2 className="h-4 w-4 mr-1.5 animate-spin" /> Working…</> : <><PauseCircle className="h-4 w-4 mr-1.5" /> Confirm On Hold</>}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

function RemoveOnHoldAnyoneModal({ onClose }: { onClose: () => void }) {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [emailOn, setEmailOn] = useState(true);
  const [hrCopy, setHrCopy] = useState<HrCopyState>(defaultHrCopyState);
  const [schedule, setSchedule] = useState<SendScheduleValue>({ mode: "now" });
  const [busy, setBusy] = useState(false);

  const submit = async () => {
    const n = name.trim();
    const e = email.trim();
    if (!n && !e) return toast.error("Enter at least a full name or an email to identify the block");
    if (emailOn && (!e || !EMAIL_RE.test(e))) return toast.error("A valid email is required to send the notice (or uncheck the email option)");
    if (emailOn && !n) return toast.error("A name is required to send the notice (or uncheck the email option)");
    setBusy(true);
    try {
      // Find ACTIVE blocks (removed_at null) matching name OR email, case-insensitive.
      const orParts: string[] = [];
      if (n) orParts.push(`full_name.ilike.${n}`);
      if (e) orParts.push(`email.ilike.${e}`);
      const { data: matches, error: findErr } = await supabase
        .from("sylvia_blocklist")
        .select("id")
        .is("removed_at", null)
        .or(orParts.join(","));
      if (findErr) throw findErr;

      if (!matches || matches.length === 0) {
        toast.error("No active block found for that identity.");
        setBusy(false);
        return;
      }

      const ids = matches.map((m) => m.id);
      const { error: updErr } = await supabase
        .from("sylvia_blocklist")
        .update({ removed_at: new Date().toISOString() })
        .in("id", ids);
      if (updErr) throw updErr;
      toast.success(`Removed On Hold for ${n || e} (${ids.length} block${ids.length > 1 ? "s" : ""}).`);

      // Optional reactivation notice (additive). Unchecked => clear silently.
      if (emailOn) {
        try {
          const msg = await sendUniversalHoldNotice({ kind: "reactivation", name: n, email: e, hrCopy, schedule });
          toast.success(msg);
        } catch (mailErr: any) {
          toast.error(`Block removed, but the email failed: ${mailErr?.message || "send_failed"}`);
        }
      }
      onClose();
    } catch (err: any) {
      toast.error(err?.message || "Failed to remove On Hold block");
    } finally {
      setBusy(false);
    }
  };

  return (
    <Dialog open onOpenChange={(o) => !o && !busy && onClose()}>
      <DialogContent className="sm:max-w-[480px] max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <PlayCircle className="h-4 w-4" style={{ color: "#16a34a" }} /> Remove On Hold Anyone
          </DialogTitle>
          <DialogDescription>
            Clear an active On Hold block for any typed name and/or email (case-insensitive). Matching active
            blocklist entries are marked removed. Enter at least one of name or email.
          </DialogDescription>
        </DialogHeader>
        <div className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="ur-name">Full name</Label>
            <Input id="ur-name" value={name} onChange={(ev) => setName(ev.target.value)} placeholder="Jane Doe" className="min-h-[44px] sm:min-h-0" disabled={busy} />
          </div>
          <div className="space-y-2">
            <Label htmlFor="ur-email">Email</Label>
            <Input id="ur-email" type="email" value={email} onChange={(ev) => setEmail(ev.target.value)} placeholder="jane@example.com" className="min-h-[44px] sm:min-h-0" disabled={busy} />
          </div>

          <label htmlFor="ur-email-on" className="flex items-start gap-2 cursor-pointer rounded-md border bg-muted/30 p-3">
            <Checkbox id="ur-email-on" checked={emailOn} onCheckedChange={(v) => setEmailOn(!!v)} disabled={busy} className="mt-0.5" />
            <div className="flex-1 min-w-0">
              <div className="text-sm font-medium text-foreground leading-snug">Email this identity a Welcome Back notice</div>
              <div className="text-xs text-muted-foreground mt-0.5">On by default. Uncheck to clear the block silently with no email.</div>
            </div>
          </label>

          {emailOn && (
            <div className="space-y-4">
              <p className="text-xs text-muted-foreground">A copy is always sent to the internal Outlook backup inbox.</p>
              <HrCopyCheckbox value={hrCopy} onChange={setHrCopy} disabled={busy} label="Also send a copy to" idPrefix="ur-hrcopy" />
              <SendScheduleControl onChange={setSchedule} />
            </div>
          )}
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={onClose} disabled={busy} className="min-h-[44px] sm:min-h-0">Cancel</Button>
          <Button onClick={submit} disabled={busy} className="min-h-[44px] sm:min-h-0 text-white" style={{ backgroundColor: "#16a34a" }}>
            {busy ? <><Loader2 className="h-4 w-4 mr-1.5 animate-spin" /> Working…</> : <><PlayCircle className="h-4 w-4 mr-1.5" /> Confirm Remove On Hold</>}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
