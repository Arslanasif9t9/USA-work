// Manila-timezone aware appointment display + live countdown for HR table.
import { useEffect, useState } from "react";

const MANILA_TZ = "Asia/Manila";

function fmtManila(d: Date): string {
  // e.g., "May 26, 3:30 PM PHT"
  const date = new Intl.DateTimeFormat("en-US", {
    timeZone: MANILA_TZ, month: "short", day: "numeric",
  }).format(d);
  const time = new Intl.DateTimeFormat("en-US", {
    timeZone: MANILA_TZ, hour: "numeric", minute: "2-digit", hour12: true,
  }).format(d);
  return `${date}, ${time} PHT`;
}

function manilaDayKey(d: Date): string {
  return new Intl.DateTimeFormat("en-CA", {
    timeZone: MANILA_TZ, year: "numeric", month: "2-digit", day: "2-digit",
  }).format(d);
}

function relative(target: Date, now: Date): { label: string; tone: "future" | "soon" | "now" | "past" } {
  const diffMs = target.getTime() - now.getTime();
  const absMin = Math.round(Math.abs(diffMs) / 60000);
  if (diffMs <= -60 * 60 * 1000) {
    // > 1h past
    const hrs = Math.round(absMin / 60);
    return { label: hrs >= 24 ? "Expired" : `Started ${hrs}h ago`, tone: "past" };
  }
  if (diffMs < 0) {
    return { label: `Started ${absMin} min ago`, tone: "now" };
  }
  if (diffMs < 15 * 60 * 1000) {
    return { label: absMin <= 1 ? "Starting now" : `in ${absMin} min`, tone: "now" };
  }
  if (diffMs < 60 * 60 * 1000) {
    return { label: `in ${absMin} min`, tone: "soon" };
  }
  if (diffMs < 24 * 60 * 60 * 1000) {
    const hrs = Math.round(diffMs / (60 * 60 * 1000));
    return { label: `in ${hrs} hour${hrs === 1 ? "" : "s"}`, tone: "soon" };
  }
  // Tomorrow / N days
  const todayKey = manilaDayKey(now);
  const targetKey = manilaDayKey(target);
  const tomorrow = new Date(now.getTime() + 24 * 60 * 60 * 1000);
  const tomorrowKey = manilaDayKey(tomorrow);
  const time = new Intl.DateTimeFormat("en-US", {
    timeZone: MANILA_TZ, hour: "numeric", minute: "2-digit", hour12: true,
  }).format(target);
  if (targetKey === tomorrowKey) return { label: `tomorrow ${time}`, tone: "future" };
  const days = Math.round(diffMs / (24 * 60 * 60 * 1000));
  return { label: `in ${days} day${days === 1 ? "" : "s"}`, tone: "future" };
}

export const AppointmentCountdown = ({ startIso }: { startIso: string | null }) => {
  const [now, setNow] = useState(() => new Date());
  useEffect(() => {
    const t = setInterval(() => setNow(new Date()), 30000);
    return () => clearInterval(t);
  }, []);
  if (!startIso) return <span className="text-xs text-muted-foreground italic">No booking</span>;
  const d = new Date(startIso);
  if (isNaN(d.getTime())) return <span className="text-xs text-muted-foreground italic">—</span>;
  const rel = relative(d, now);
  const toneCls =
    rel.tone === "now" ? "text-emerald-700 bg-emerald-50 border-emerald-200"
    : rel.tone === "soon" ? "text-amber-700 bg-amber-50 border-amber-200"
    : rel.tone === "past" ? "text-muted-foreground bg-muted border-border"
    : "text-blue-700 bg-blue-50 border-blue-200";
  return (
    <div className="flex flex-col gap-1 min-w-[140px]">
      <span className="text-base font-semibold leading-tight">{fmtManila(d)}</span>
      <span className={`inline-flex w-fit text-sm font-semibold px-1.5 py-0.5 rounded border ${toneCls}`}>
        {rel.label}
      </span>
    </div>
  );
};

export default AppointmentCountdown;
