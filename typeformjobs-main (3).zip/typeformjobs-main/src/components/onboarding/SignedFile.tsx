import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { ImageIcon, ExternalLink } from "lucide-react";

// Stored values look like "candidate-files/responses/.../file.ext".
// Resolve a short-lived signed URL for the private bucket.
export function useSignedUrl(filePath?: string | null, expiresIn = 3600) {
  const [url, setUrl] = useState<string | null>(null);
  useEffect(() => {
    let cancelled = false;
    setUrl(null);
    if (!filePath) return;
    (async () => {
      const slash = filePath.indexOf("/");
      if (slash < 0) return;
      const bucket = filePath.slice(0, slash);
      const path = filePath.slice(slash + 1);
      const { data } = await supabase.storage.from(bucket).createSignedUrl(path, expiresIn);
      if (!cancelled && data?.signedUrl) setUrl(data.signedUrl);
    })();
    return () => {
      cancelled = true;
    };
  }, [filePath, expiresIn]);
  return url;
}

// Clickable thumbnail that opens the full image in a new tab.
export function SignedThumb({
  filePath,
  label,
  size = 64,
}: {
  filePath?: string | null;
  label: string;
  size?: number;
}) {
  const url = useSignedUrl(filePath);
  if (!filePath) {
    return <span className="text-xs text-muted-foreground">—</span>;
  }
  return (
    <a
      href={url || undefined}
      target="_blank"
      rel="noopener noreferrer"
      title={`Open ${label} in a new tab`}
      className="inline-flex items-center justify-center rounded border bg-muted/40 overflow-hidden hover:opacity-80 transition-opacity"
      style={{ width: size, height: size }}
      onClick={(e) => {
        if (!url) e.preventDefault();
      }}
    >
      {url ? (
        <img src={url} alt={label} className="w-full h-full object-cover" />
      ) : (
        <ImageIcon className="h-5 w-5 text-muted-foreground" />
      )}
    </a>
  );
}

// Clickable text link that opens the file in a new tab.
export function SignedFileLink({
  filePath,
  label,
}: {
  filePath?: string | null;
  label: string;
}) {
  const url = useSignedUrl(filePath);
  if (!filePath) return <span className="text-muted-foreground">—</span>;
  return (
    <a
      href={url || undefined}
      target="_blank"
      rel="noopener noreferrer"
      className="inline-flex items-center gap-1 text-primary underline underline-offset-2 hover:opacity-80"
      onClick={(e) => {
        if (!url) e.preventDefault();
      }}
    >
      {label} <ExternalLink className="h-3 w-3" />
    </a>
  );
}
