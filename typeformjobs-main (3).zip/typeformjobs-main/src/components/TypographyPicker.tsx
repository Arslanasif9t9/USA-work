import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Type, Bold, Italic, Underline, AlignLeft, AlignCenter, AlignRight, Loader2 } from "lucide-react";
import {
  FONT_FAMILIES, FONT_SIZES, FormTypography, mergeTypography, typographyEqual,
} from "@/lib/typography";
import { cn } from "@/lib/utils";

type Props = {
  draft: FormTypography;
  saved: FormTypography;
  onChange: (next: FormTypography) => void;
  onSave: () => void;
  onReset: () => void;
  saving?: boolean;
};

const TypographyPicker = ({ draft, saved, onChange, onSave, onReset, saving }: Props) => {
  const t = mergeTypography(draft);
  const dirty = !typographyEqual(draft, saved);
  const set = (patch: Partial<FormTypography>) => onChange({ ...t, ...patch });

  const ToggleBtn = ({ active, onClick, label, children }: any) => (
    <button
      type="button"
      onClick={onClick}
      aria-pressed={active}
      aria-label={label}
      className={cn(
        "h-8 w-8 inline-flex items-center justify-center rounded-md border border-border",
        active ? "bg-foreground text-background" : "bg-background text-foreground hover:bg-secondary"
      )}
    >
      {children}
    </button>
  );

  return (
    <Popover>
      <PopoverTrigger asChild>
        <Button variant="outline" size="sm" className="h-7 gap-1.5" aria-label="Form typography">
          <Type className="h-3.5 w-3.5" />
          <span className="text-xs">Typography</span>
          {dirty && <span className="ml-1 h-1.5 w-1.5 rounded-full bg-amber-500" aria-label="Unsaved" />}
        </Button>
      </PopoverTrigger>
      <PopoverContent align="end" className="w-72 p-3 space-y-3">
        <p className="text-xs font-medium text-muted-foreground">Form typography</p>

        <div>
          <Label className="text-[11px]">Font family</Label>
          <Select value={t.fontFamily} onValueChange={(v: any) => set({ fontFamily: v })}>
            <SelectTrigger className="h-8"><SelectValue /></SelectTrigger>
            <SelectContent>
              {FONT_FAMILIES.map((f) => (
                <SelectItem key={f.id} value={f.id}>
                  <span style={{ fontFamily: f.stack }}>{f.name}</span>
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <div>
          <Label className="text-[11px]">Font size</Label>
          <Select value={t.fontSize} onValueChange={(v: any) => set({ fontSize: v })}>
            <SelectTrigger className="h-8"><SelectValue /></SelectTrigger>
            <SelectContent>
              {FONT_SIZES.map((s) => <SelectItem key={s.id} value={s.id}>{s.name}</SelectItem>)}
            </SelectContent>
          </Select>
        </div>

        <div>
          <Label className="text-[11px] block mb-1">Style</Label>
          <div className="flex gap-1">
            <ToggleBtn active={t.bold}      onClick={() => set({ bold: !t.bold })}           label="Bold"><Bold className="h-3.5 w-3.5" /></ToggleBtn>
            <ToggleBtn active={t.italic}    onClick={() => set({ italic: !t.italic })}       label="Italic"><Italic className="h-3.5 w-3.5" /></ToggleBtn>
            <ToggleBtn active={t.underline} onClick={() => set({ underline: !t.underline })} label="Underline"><Underline className="h-3.5 w-3.5" /></ToggleBtn>
          </div>
        </div>

        <div>
          <Label className="text-[11px] block mb-1">Alignment</Label>
          <div className="flex gap-1">
            <ToggleBtn active={t.align === "left"}   onClick={() => set({ align: "left" })}   label="Align left"><AlignLeft className="h-3.5 w-3.5" /></ToggleBtn>
            <ToggleBtn active={t.align === "center"} onClick={() => set({ align: "center" })} label="Align center"><AlignCenter className="h-3.5 w-3.5" /></ToggleBtn>
            <ToggleBtn active={t.align === "right"}  onClick={() => set({ align: "right" })}  label="Align right"><AlignRight className="h-3.5 w-3.5" /></ToggleBtn>
          </div>
        </div>

        <div>
          <Label className="text-[11px] block mb-1">Text color</Label>
          <div className="flex items-center gap-2">
            <input
              type="color"
              value={t.color || "#000000"}
              onChange={(e) => set({ color: e.target.value })}
              className="h-8 w-10 rounded-md border border-border bg-background cursor-pointer"
              aria-label="Text color"
            />
            <Button
              variant="ghost"
              size="sm"
              className="h-7 text-xs"
              onClick={() => set({ color: null })}
              disabled={!t.color}
            >
              Use theme default
            </Button>
          </div>
        </div>

        <div className="flex items-center gap-2 pt-2 border-t border-border">
          <Button size="sm" variant="ghost" className="flex-1 h-7 text-xs" onClick={onReset} disabled={!dirty || saving}>
            Cancel
          </Button>
          <Button size="sm" className="flex-1 h-7 text-xs" onClick={onSave} disabled={!dirty || saving}>
            {saving ? <Loader2 className="h-3 w-3 animate-spin" /> : "Save"}
          </Button>
        </div>
        <p className="text-[10px] text-muted-foreground">
          {dirty ? "Preview only — Save to make it live for candidates." : "Live typography. Adjust to preview."}
        </p>
      </PopoverContent>
    </Popover>
  );
};

export default TypographyPicker;
