import { useNavigate, useParams, useLocation } from "react-router-dom";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { ArrowLeft, MoreHorizontal, Settings, Loader2 } from "lucide-react";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { generateUniqueSlug } from "@/lib/slug";
import { duplicateForm } from "@/lib/duplicateForm";
import { useAuth } from "@/hooks/useAuth";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label as UILabel } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";



const SLUG_REGEX = /^[a-z0-9-]+$/;

type FormRow = {
  id: string;
  title: string;
  slug: string;
  description: string | null;
  status: string;
  theme: string;
  typography: any;
};

export const useFormHeader = (formId: string) => {
  const [form, setForm] = useState<FormRow | null>(null);
  const refresh = async () => {
    const { data } = await supabase
      .from("forms")
      .select("id, title, slug, description, status, theme, typography")
      .eq("id", formId)
      .maybeSingle();
    if (data) setForm(data as FormRow);
  };
  useEffect(() => {
    refresh();
  }, [formId]);
  return { form, setForm, refresh };
};

type Props = {
  form: FormRow;
  onChange: () => void;
  active: "build" | "share" | "results" | "bookings";
};

const FormTopBar = ({ form, onChange, active }: Props) => {
  const navigate = useNavigate();
  const { user } = useAuth();
  const [deleteOpen, setDeleteOpen] = useState(false);
  const [renameOpen, setRenameOpen] = useState(false);
  const [renameValue, setRenameValue] = useState(form.title);
  const [dupOpen, setDupOpen] = useState(false);
  const [duplicating, setDuplicating] = useState(false);
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [deletingForm, setDeletingForm] = useState(false);
  const [statusBusy, setStatusBusy] = useState(false);
  const [sTitle, setSTitle] = useState(form.title);
  const [sSlug, setSSlug] = useState(form.slug);
  const [sDesc, setSDesc] = useState(form.description || "");
  const [sErrors, setSErrors] = useState<{ title?: string; slug?: string }>({});
  const [sSaving, setSSaving] = useState(false);



  const sDirty = sTitle !== form.title || sSlug !== form.slug || (sDesc || "") !== (form.description || "");

  const openSettings = () => {
    setSTitle(form.title); setSSlug(form.slug); setSDesc(form.description || ""); setSErrors({});
    setSettingsOpen(true);
  };

  const trySetSettingsOpen = (o: boolean) => {
    if (!o && sDirty) {
      if (!window.confirm("Discard unsaved changes?")) return;
    }
    setSettingsOpen(o);
  };

  const handleSaveSettings = async () => {
    const errs: typeof sErrors = {};
    const title = sTitle.trim(); const slug = sSlug.trim();
    if (!title) errs.title = "Title cannot be empty.";
    if (!slug) errs.slug = "Slug cannot be empty.";
    else if (!SLUG_REGEX.test(slug)) errs.slug = "Only lowercase letters, numbers, hyphens";
    if (Object.keys(errs).length) { setSErrors(errs); return; }
    setSSaving(true);
    if (slug !== form.slug) {
      const { data: exists } = await supabase.from("forms").select("id").eq("slug", slug).maybeSingle();
      if (exists && exists.id !== form.id) {
        setSErrors({ slug: "This slug is already taken." });
        setSSaving(false);
        return;
      }
    }
    const { error } = await supabase.from("forms").update({ title, slug, description: sDesc || null }).eq("id", form.id);
    setSSaving(false);
    if (error) return toast.error(error.message);
    toast.success("Settings saved");
    setSettingsOpen(false);
    onChange();
  };

  const toggleStatus = async (checked: boolean) => {
    const newStatus = checked ? "live" : "draft";
    setStatusBusy(true);
    const { error } = await supabase
      .from("forms")
      .update({ status: newStatus })
      .eq("id", form.id);
    setStatusBusy(false);
    if (error) return toast.error(error.message);
    if (newStatus === "live") toast.success("Form is now live.");
    else toast.success("Form is now in draft. Public link is disabled.");
    onChange();
  };



  const handleDelete = async () => {
    setDeletingForm(true);
    const { error } = await supabase.from("forms").delete().eq("id", form.id);
    setDeletingForm(false);
    if (error) return toast.error(error.message);
    toast.success("Form deleted");
    navigate("/dashboard");
  };

  const handleRename = async () => {
    const title = renameValue.trim() || "Untitled Form";
    const slug = await generateUniqueSlug(title, form.id);
    const { error } = await supabase
      .from("forms")
      .update({ title, slug })
      .eq("id", form.id);
    if (error) return toast.error(error.message);
    setRenameOpen(false);
    onChange();
  };

  const handleDuplicate = async () => {
    if (!user) return;
    setDuplicating(true);
    try {
      const newForm = await duplicateForm(form.id, user.id);
      toast.success("Editing duplicated form");
      setDupOpen(false);
      navigate(`/forms/${newForm.id}`, { replace: true });
    } catch {
      toast.error("Could not duplicate form. Please try again.");
    } finally {
      setDuplicating(false);
    }
  };

  // Cmd/Ctrl+D shortcut in builder
  useEffect(() => {
    if (active !== "build") return;
    const onKey = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === "d") {
        e.preventDefault();
        setDupOpen(true);
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [active]);

  const tabBtn = (key: string, label: string, path: string) => (
    <button
      key={key}
      onClick={() => navigate(path)}
      className={`px-4 py-1.5 text-sm rounded-md transition-colors ${
        active === key ? "bg-secondary text-foreground font-medium" : "text-muted-foreground hover:text-foreground"
      }`}
    >
      {label}
    </button>
  );

  return (
    <header className="border-b border-border bg-background">
      <div className="px-4 md:px-6 h-14 flex items-center justify-between gap-2">
        <div className="flex items-center gap-2 min-w-0 flex-1">
          <Button variant="ghost" size="icon" onClick={() => navigate("/dashboard")}>
            <ArrowLeft className="h-4 w-4" />
          </Button>
          <h1
            className="px-2 cursor-pointer shrink-0"
            style={{
              fontFamily: "'Cormorant Garamond', serif",
              fontWeight: 600,
              fontSize: "18px",
              color: "#1a2547",
              letterSpacing: "1px",
            }}
            onClick={() => navigate("/dashboard")}
          >
            EIA Talent Recruiting System
          </h1>

          <div className="text-sm text-muted-foreground truncate hidden sm:block">
            / <span className="text-foreground font-medium">{form.title}</span>
          </div>
        </div>

        <div className="hidden md:flex items-center gap-1">
          {tabBtn("build", "Build", `/forms/${form.id}`)}
          {tabBtn("share", "Share", `/forms/${form.id}/share`)}
          {tabBtn("results", "Results", `/forms/${form.id}/results`)}
        </div>

        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2">
            <Label htmlFor="status" className="text-sm hidden sm:inline">
              {form.status === "live" ? "Live" : "Draft"}
            </Label>
            {statusBusy && <Loader2 className="h-3 w-3 animate-spin text-muted-foreground" aria-label="Updating status" />}
            <Switch
              id="status"
              checked={form.status === "live"}
              onCheckedChange={toggleStatus}
              disabled={statusBusy}
            />
          </div>
          {active === "build" && (
            <Button variant="ghost" size="icon" onClick={openSettings} aria-label="Form settings">
              <Settings className="h-4 w-4" />
            </Button>
          )}
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" size="icon">
                <MoreHorizontal className="h-4 w-4" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuItem onClick={() => { setRenameValue(form.title); setRenameOpen(true); }}>
                Rename
              </DropdownMenuItem>
              <DropdownMenuItem onClick={() => setDupOpen(true)}>Duplicate</DropdownMenuItem>
              <DropdownMenuItem onClick={() => setDeleteOpen(true)}>Delete</DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>

      <div className="md:hidden flex items-center gap-1 px-4 pb-2 border-t border-border pt-2 overflow-x-auto">
        {tabBtn("build", "Build", `/forms/${form.id}`)}
        {tabBtn("share", "Share", `/forms/${form.id}/share`)}
        {tabBtn("results", "Results", `/forms/${form.id}/results`)}
      </div>

      <AlertDialog open={dupOpen} onOpenChange={(o) => !duplicating && setDupOpen(o)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Duplicate this form?</AlertDialogTitle>
            <AlertDialogDescription>
              A copy of "{form.title}" will be created with all its questions. The copy starts as a draft.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={duplicating}>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={(e) => { e.preventDefault(); handleDuplicate(); }} disabled={duplicating}>
              {duplicating ? (<><Loader2 className="h-4 w-4 mr-2 animate-spin" /> Duplicating...</>) : "Duplicate"}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      <AlertDialog open={deleteOpen} onOpenChange={setDeleteOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete this form?</AlertDialogTitle>
            <AlertDialogDescription>
              This will permanently delete all responses.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={deletingForm}>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={(e) => { e.preventDefault(); handleDelete(); }} disabled={deletingForm}>
              {deletingForm ? (<><Loader2 className="h-4 w-4 mr-2 animate-spin" /> Deleting...</>) : "Delete"}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      <Dialog open={renameOpen} onOpenChange={setRenameOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Rename form</DialogTitle>
          </DialogHeader>
          <Input value={renameValue} onChange={(e) => setRenameValue(e.target.value)} autoFocus />
          <DialogFooter>
            <Button variant="ghost" onClick={() => setRenameOpen(false)}>Cancel</Button>
            <Button onClick={handleRename}>Save</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>




      <Dialog open={settingsOpen} onOpenChange={trySetSettingsOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Form Settings</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <UILabel className="text-xs">Title</UILabel>
              <Input value={sTitle} onChange={(e) => setSTitle(e.target.value)} />
              {sErrors.title && <p className="text-xs text-destructive mt-1">{sErrors.title}</p>}
            </div>
            <div>
              <UILabel className="text-xs">Slug</UILabel>
              <Input value={sSlug} onChange={(e) => setSSlug(e.target.value)} />
              <p className="text-[11px] text-muted-foreground mt-1">Only lowercase letters, numbers, hyphens</p>
              {sErrors.slug && <p className="text-xs text-destructive mt-1">{sErrors.slug}</p>}
            </div>
            <div>
              <UILabel className="text-xs">Description</UILabel>
              <Textarea value={sDesc} onChange={(e) => setSDesc(e.target.value)} rows={3} />
            </div>
          </div>
          <DialogFooter>
            <Button variant="ghost" onClick={() => trySetSettingsOpen(false)}>Cancel</Button>
            <Button onClick={handleSaveSettings} disabled={!sDirty || sSaving}>
              {sSaving ? (<><Loader2 className="h-4 w-4 mr-2 animate-spin" /> Saving...</>) : "Save Changes"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </header>
  );
};

export default FormTopBar;
