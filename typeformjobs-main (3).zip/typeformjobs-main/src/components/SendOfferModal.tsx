import { useEffect, useMemo, useRef, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Dialog, DialogContent } from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { toast } from "sonner";
import {
  ArrowDown,
  ArrowUp,
  CheckCircle2,
  GripVertical,
  Library,
  Loader2,
  Plus,
  Sparkles,
  X,
} from "lucide-react";
import { ModalShell, ModalSection, EditableContactField } from "@/components/action-dialogs/ModalShell";
import { HrCopyCheckbox, defaultHrCopyState, type HrCopyState } from "@/components/HrCopyCheckbox";
import { updateResponseAnswer } from "@/lib/candidateActions";
import { useHrIdentity } from "@/hooks/useHrIdentity";
import {
  SCOPE_CATEGORIES,
  CATEGORY_COLORS,
  categoryColor,
  normalizeCategory,
} from "@/lib/categoryColors";
import {
  DEFAULT_SCHEDULE_PRESET,
  LOCKED_SCHEDULE_PRESETS,
  type ScheduleKey,
} from "@/lib/schedulePresets";
import SendScheduleControl, { type SendScheduleValue } from "@/components/SendScheduleControl";
import { insertScheduledSend, formatScheduledFor } from "@/lib/scheduledSends";

type Currency = "PHP" | "USD";
const PRESETS = LOCKED_SCHEDULE_PRESETS;

const tomorrowISO = () => {
  const d = new Date();
  d.setDate(d.getDate() + 1);
  return d.toISOString().slice(0, 10);
};

const fmtTime = (t: string) => {
  if (!t) return "—";
  const [h, m] = t.split(":").map(Number);
  const period = h >= 12 ? "PM" : "AM";
  const h12 = h % 12 || 12;
  return `${h12}:${String(m).padStart(2, "0")} ${period}`;
};

const fmtDate = (iso: string) => {
  if (!iso) return "—";
  const d = new Date(iso + "T00:00:00");
  return d.toLocaleDateString(undefined, {
    weekday: "long",
    year: "numeric",
    month: "long",
    day: "numeric",
  });
};

const randomToken = (len = 32) => {
  const chars =
    "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
  const arr = new Uint32Array(len);
  crypto.getRandomValues(arr);
  let out = "";
  for (let i = 0; i < len; i++) out += chars[arr[i] % chars.length];
  return out;
};

type LibraryItem = {
  id: string;
  text: string;
  category: string;
  usage_count: number;
};

export type SourceOffer = {
  id: string;
  position_title: string;
  trial_weeks: number;
  trial_weekly_salary: number;
  post_trial_weekly_salary: number;
  monthly_range_min: number | null;
  monthly_range_max: number | null;
  raise_applied: boolean;
  currency: Currency;
  schedule_preset_used: string | null;
  weekday_start: string | null;
  weekday_end: string | null;
  saturday_start: string | null;
  saturday_end: string | null;
  sunday_off: boolean;
  scope_items: string[];
  internal_notes: string | null;
  remarks: string | null;
  parallel_group_id: string | null;
};

export type SendOfferModalProps = {
  open: boolean;
  onClose: () => void;
  formId: string;
  candidateName?: string;
  candidateEmail?: string;
  responseId?: string;
  nameQid?: string;
  emailQid?: string;
  onSaved?: (offerRef: string, jobOfferId?: string) => void;
  onContactUpdated?: (vals: { name?: string; email?: string }) => void;
  sourceOffer?: SourceOffer | null;
  isResend?: boolean;
  existingOfferId?: string | null;
};

type SendPhase = "idle" | "saving" | "pdf" | "signflow" | "email" | "done";
type SendError = {
  phase: "save" | "pdf" | "signflow" | "email" | "finalize";
  message: string;
  jobOfferId?: string;
  offerRef?: string;
  pdfUrl?: string;
  signingUrl?: string;
};

const buildOfferSenderA = (
  candName: string,
  position: string,
  signingUrl: string,
  comp?: {
    currency: string;
    baseMonthly: number;
    bonusEnabled: boolean;
    bonusAmount: number;
  },
) => {
  const sym = comp?.currency === "USD" ? "$" : "₱";
  const fmt = (n: number) => `${sym}${Math.round(n).toLocaleString("en-US")}`;
  const compTextLines: string[] = [];
  const compHtmlLines: string[] = [];
  if (comp) {
    compTextLines.push("Compensation:");
    compTextLines.push(`Base salary: ${fmt(comp.baseMonthly)}/month`);
    compHtmlLines.push("<p><strong>Compensation:</strong><br/>");
    compHtmlLines.push(`Base salary: ${fmt(comp.baseMonthly)}/month`);
    if (comp.bonusEnabled && comp.bonusAmount > 0) {
      compTextLines.push(
        `Performance bonus: up to ${fmt(comp.bonusAmount)} per pay period (discretionary, based on performance — see attached offer letter for full details)`,
      );
      compHtmlLines.push(
        `<br/>Performance bonus: up to ${fmt(comp.bonusAmount)} per pay period <em>(discretionary, based on performance — see attached offer letter for full details)</em>`,
      );
    }
    compHtmlLines.push("</p>");
  }
  const compTextBlock = compTextLines.length ? `\n${compTextLines.join("\n")}\n` : "";
  const compHtmlBlock = compHtmlLines.length ? compHtmlLines.join("") : "";

  const text = `Hi ${candName},

I'm pleased to formally extend you a job offer for the ${position} position at Expert Intuitive Advisor Inc.
${compTextBlock}
Your offer letter includes:
- Compensation details
- Trial period terms
- Job scope and responsibilities
- Work schedule
- Acceptance conditions

You can review and sign your offer using the secure link below:
${signingUrl}

There's no rush — please take your time to read through everything. The offer will remain open for the next 7 days, and you can sign whenever you're ready.

If you have any questions before signing, just reply to this email and I'll connect you with the right person.

Welcome to EIA — we're excited about what you'll build with us.

Cathy Anderson
Hiring Director
Expert Intuitive Advisor Inc.`;
  const html = `<div style="font-family:Arial,sans-serif;font-size:14px;color:#1a2236;line-height:1.6;max-width:600px">
<p>Hi ${candName},</p>
<p>I'm pleased to formally extend you a job offer for the <strong>${position}</strong> position at Expert Intuitive Advisor Inc.</p>
${compHtmlBlock}
<p>Your offer letter includes:</p>
<ul>
  <li>Compensation details</li>
  <li>Trial period terms</li>
  <li>Job scope and responsibilities</li>
  <li>Work schedule</li>
  <li>Acceptance conditions</li>
</ul>
<p style="margin:24px 0"><a href="${signingUrl}" style="display:inline-block;background:#1a2547;color:#ffffff;text-decoration:none;padding:12px 24px;border-radius:6px;font-weight:bold">Review &amp; sign your offer</a></p>
<p>There's no rush — please take your time to read through everything. The offer will remain open for the next 7 days, and you can sign whenever you're ready.</p>
<p>If you have any questions before signing, just reply to this email and I'll connect you with the right person.</p>
<p>Welcome to EIA — we're excited about what you'll build with us.</p>
<p>Cathy Anderson<br/>Hiring Director<br/>Expert Intuitive Advisor Inc.</p>
</div>`;
  return {
    from_name: "Angela Stein / HR – Talent Manager",
    from_address: "talent@expertintuitiveadvisor.com",
    subject: `Job Offer — ${position} at Expert Intuitive Advisor`,
    html_body: html,
    text_body: text,
  };
};


const buildOfferSenderB = (candName: string, position: string, signingUrl: string) => {
  const text = `Hi ${candName},

Just a personal heads up — Cathy sent over your formal offer letter for the ${position} role.

The signing link is in her email. Here it is again so you don't have to dig:

${signingUrl}

A few things to know:
- Take your time reading it, especially the compensation and schedule sections
- The offer will stay open for the next 7 days, so there's no rush
- If anything's unclear or you want to discuss before signing, reply to me and we'll talk

Congrats — looking forward to having you on the team.

— Angela Stein`;
  const html = `<div style="font-family:Arial,sans-serif;font-size:14px;color:#1a2236;line-height:1.6;max-width:600px">
<p>Hi ${candName},</p>
<p>Just a personal heads up — Cathy sent over your formal offer letter for the <strong>${position}</strong> role.</p>
<p>The signing link is in her email. Here it is again so you don't have to dig:</p>
<p style="margin:24px 0"><a href="${signingUrl}" style="display:inline-block;background:#1a2547;color:#ffffff;text-decoration:none;padding:12px 24px;border-radius:6px;font-weight:bold">Review &amp; sign your offer</a></p>
<p>A few things to know:</p>
<ul>
  <li>Take your time reading it, especially the compensation and schedule sections</li>
  <li>The offer will stay open for the next 7 days, so there's no rush</li>
  <li>If anything's unclear or you want to discuss before signing, reply to me and we'll talk</li>
</ul>
<p>Congrats — looking forward to having you on the team.</p>
<p>— Angela Stein</p>
</div>`;
  return {
    from_name: "Angela Stein",
    from_address: "expertintuitiveadvisor@gmail.com",
    subject: "Your EIA offer is ready to sign",
    html_body: html,
    text_body: text,
  };
};

export default function SendOfferModal(props: SendOfferModalProps) {
  const { open, onClose, formId, candidateName, candidateEmail, responseId, nameQid, emailQid, onSaved, onContactUpdated, sourceOffer, isResend, existingOfferId } = props;
  const { hrId } = useHrIdentity();
  const [activeSource, setActiveSource] = useState<SourceOffer | null>(sourceOffer ?? null);
  const [resetKey, setResetKey] = useState(0);
  const [savedOffer, setSavedOffer] = useState<{ id: string; ref: string } | null>(null);
  const nameInputRef = useRef<HTMLInputElement | null>(null);
  // The response row that downstream tracking writes should target. For a normal
  // send this is the source response; for a duplicate-to-another-candidate send it
  // is the NEW response created for that candidate (set inside performSend).
  const effectiveResponseIdRef = useRef<string | null>(null);

  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [positionTitle, setPositionTitle] = useState("");
  const [startDate, setStartDate] = useState(tomorrowISO());
  const [trialWeeks, setTrialWeeks] = useState(4);
  const [currency, setCurrency] = useState<Currency>("PHP");
  const [trialWeekly, setTrialWeekly] = useState<number>(4000);
  const [applyRaise, setApplyRaise] = useState(true);
  const [postTrialWeekly, setPostTrialWeekly] = useState<number>(4500);
  // String drafts that drive the numeric inputs' displayed value while typing.
  // Numeric state above stays the source of truth for math + send (UNCHANGED).
  const [trialWeeksStr, setTrialWeeksStr] = useState("4");
  const [trialWeeklyStr, setTrialWeeklyStr] = useState("4000");
  const [postTrialWeeklyStr, setPostTrialWeeklyStr] = useState("4500");
  const [preset, setPreset] = useState<ScheduleKey>(DEFAULT_SCHEDULE_PRESET);
  const [weekdayStart, setWeekdayStart] = useState(PRESETS[DEFAULT_SCHEDULE_PRESET].weekday_start);
  const [weekdayEnd, setWeekdayEnd] = useState(PRESETS[DEFAULT_SCHEDULE_PRESET].weekday_end);
  const [saturdayStart, setSaturdayStart] = useState(PRESETS[DEFAULT_SCHEDULE_PRESET].saturday_start);
  const [saturdayEnd, setSaturdayEnd] = useState(PRESETS[DEFAULT_SCHEDULE_PRESET].saturday_end);
  const [scope, setScope] = useState<string[]>([]);
  const [scopeInput, setScopeInput] = useState("");
  const [libraryOpen, setLibraryOpen] = useState(false);
  const [aiOpen, setAiOpen] = useState(false);
  const [aiMode, setAiMode] = useState<"suggest" | "override">("suggest");
  const [aiOverrideConfirmOpen, setAiOverrideConfirmOpen] = useState(false);
  const [aiOverrideLoading, setAiOverrideLoading] = useState(false);
  const [scopeCatMap, setScopeCatMap] = useState<Record<string, string>>({});
  const [notes, setNotes] = useState("");
  const [remarks, setRemarks] = useState("");
  const [pwOpen, setPwOpen] = useState(false);
  const [pwValue, setPwValue] = useState("");
  const [pwChecking, setPwChecking] = useState(false);
  const [confirmOpen, setConfirmOpen] = useState(false);
  const [saving, setSaving] = useState(false);
  const [overwriteOpen, setOverwriteOpen] = useState(false);
  const [savingDefault, setSavingDefault] = useState(false);
  const [sendPhase, setSendPhase] = useState<SendPhase>("idle");
  const [sendError, setSendError] = useState<SendError | null>(null);
  const [bonusEnabled, setBonusEnabled] = useState(false);
  const [bonusAmount, setBonusAmount] = useState<number>(500);
  const [bonusAmountStr, setBonusAmountStr] = useState("500");
  const [includeAdaptability, setIncludeAdaptability] = useState(true);
  const dragIndex = useRef<number | null>(null);
  const skipCurrencyResetRef = useRef(false);
  const [hrCopy, setHrCopy] = useState<HrCopyState>(defaultHrCopyState);
  const [schedule, setSchedule] = useState<SendScheduleValue>({ mode: "now" });

  useEffect(() => {
    if (!open) return;
    // Sync activeSource from prop when modal (re)opens
    setActiveSource(sourceOffer ?? null);
    setSavedOffer(null);
    setSendPhase("idle");
    setSendError(null);
    setSchedule({ mode: "now" });
    // Load override_email for this response and prefer it
    if (responseId) {
      (async () => {
        const { data } = await supabase
          .from("responses")
          .select("override_email")
          .eq("id", responseId)
          .maybeSingle();
        const ov = (data as any)?.override_email;
        if (ov && typeof ov === "string" && ov.trim()) setEmail(ov.trim());
      })();
    }
  }, [open, sourceOffer, responseId]);

  // Pre-fill from existing offer when in resend mode
  useEffect(() => {
    if (!open || !isResend || !existingOfferId) return;
    (async () => {
      const { data } = await supabase
        .from("job_offers")
        .select("*")
        .eq("id", existingOfferId)
        .maybeSingle();
      if (!data) return;
      skipCurrencyResetRef.current = true;
      setName(data.candidate_name || "");
      setEmail(data.candidate_email || "");
      setPositionTitle(data.position_title || "");
      setStartDate(data.start_date || tomorrowISO());
      setTrialWeeks(data.trial_weeks ?? 4);
      setCurrency((data.currency as Currency) || "PHP");
      setTrialWeekly(Number(data.trial_weekly_salary) || 0);
      setPostTrialWeekly(Number(data.post_trial_weekly_salary) || 0);
      setApplyRaise(!!data.raise_applied);
      const p = (data.schedule_preset_used as ScheduleKey) || "custom";
      setPreset(PRESETS[p as ScheduleKey] ? p : "custom");
      setWeekdayStart(data.weekday_start || PRESETS[DEFAULT_SCHEDULE_PRESET].weekday_start);
      setWeekdayEnd(data.weekday_end || PRESETS[DEFAULT_SCHEDULE_PRESET].weekday_end);
      setSaturdayStart(data.saturday_start || PRESETS[DEFAULT_SCHEDULE_PRESET].saturday_start);
      setSaturdayEnd(data.saturday_end || PRESETS[DEFAULT_SCHEDULE_PRESET].saturday_end);
      setScope(Array.isArray(data.scope_items) ? (data.scope_items as string[]) : []);
      setNotes(data.internal_notes || "");
      setRemarks((data as any).remarks || "");
      setBonusEnabled(!!(data as any).performance_bonus_enabled);
      setBonusAmount(Number((data as any).performance_bonus_amount) || 500);
      setIncludeAdaptability((data as any).include_adaptability_clause !== false);
    })();
  }, [open, isResend, existingOfferId]);

  useEffect(() => {
    if (!open) return;
    const src = activeSource;
    if (src) {
      // Duplicate mode: copy everything except candidate + start_date
      setName("");
      setEmail("");
      setStartDate(tomorrowISO());
      setPositionTitle(src.position_title || "");
      setTrialWeeks(src.trial_weeks ?? 4);
      skipCurrencyResetRef.current = true;
      setCurrency((src.currency as Currency) || "PHP");
      setTrialWeekly(Number(src.trial_weekly_salary) || 0);
      setPostTrialWeekly(Number(src.post_trial_weekly_salary) || 0);
      setApplyRaise(!!src.raise_applied);
      const p = (src.schedule_preset_used as ScheduleKey) || "custom";
      setPreset(PRESETS[p as ScheduleKey] ? p : "custom");
      setWeekdayStart(src.weekday_start || PRESETS[DEFAULT_SCHEDULE_PRESET].weekday_start);
      setWeekdayEnd(src.weekday_end || PRESETS[DEFAULT_SCHEDULE_PRESET].weekday_end);
      setSaturdayStart(src.saturday_start || PRESETS[DEFAULT_SCHEDULE_PRESET].saturday_start);
      setSaturdayEnd(src.saturday_end || PRESETS[DEFAULT_SCHEDULE_PRESET].saturday_end);
      setScope(Array.isArray(src.scope_items) ? src.scope_items : []);
      setScopeInput("");
      setNotes(src.internal_notes || "");
      setRemarks(src.remarks || "");
      setBonusEnabled(false);
      setBonusAmount(500);
      setIncludeAdaptability(true);
      setPwValue("");
      // Focus candidate name shortly after render
      setTimeout(() => nameInputRef.current?.focus(), 60);
      return;
    }
    // Fresh mode
    setName(candidateName || "");
    setEmail(candidateEmail || "");
    setStartDate(tomorrowISO());
    setTrialWeeks(4);
    setCurrency("PHP");
    setTrialWeekly(4000);
    setApplyRaise(true);
    setPostTrialWeekly(4500);
    setPreset(DEFAULT_SCHEDULE_PRESET);
    setWeekdayStart(PRESETS[DEFAULT_SCHEDULE_PRESET].weekday_start);
    setWeekdayEnd(PRESETS[DEFAULT_SCHEDULE_PRESET].weekday_end);
    setSaturdayStart(PRESETS[DEFAULT_SCHEDULE_PRESET].saturday_start);
    setSaturdayEnd(PRESETS[DEFAULT_SCHEDULE_PRESET].saturday_end);
    setScope([]);
    setScopeInput("");
    setNotes("");
    setRemarks("");
    setBonusEnabled(false);
    setBonusAmount(500);
    setIncludeAdaptability(true);
    setPwValue("");


    (async () => {
      const { data } = await supabase
        .from("form_metadata")
        .select("position_title, default_job_scope_item_ids")
        .eq("form_id", formId)
        .maybeSingle();
      if (data?.position_title) setPositionTitle(data.position_title);
      else setPositionTitle("");
      const ids = (data?.default_job_scope_item_ids || []) as string[];
      if (ids.length) {
        const { data: items } = await supabase
          .from("job_scope_library")
          .select("id, text")
          .in("id", ids);
        const byId: Record<string, string> = {};
        (items || []).forEach((i: any) => (byId[i.id] = i.text));
        setScope(ids.map((id) => byId[id]).filter(Boolean));
      }
    })();
  }, [open, formId, candidateName, candidateEmail, activeSource, resetKey]);

  useEffect(() => {
    if (skipCurrencyResetRef.current) {
      skipCurrencyResetRef.current = false;
      return;
    }
    if (currency === "PHP") {
      setTrialWeekly(4000);
      setPostTrialWeekly(applyRaise ? 4500 : 4000);
    } else {
      setTrialWeekly(100);
      setPostTrialWeekly(applyRaise ? 115 : 100);
    }
  }, [currency]);

  useEffect(() => {
    if (!applyRaise) setPostTrialWeekly(trialWeekly);
  }, [applyRaise, trialWeekly]);

  // Keep the string drafts in sync whenever numeric state changes PROGRAMMATICALLY
  // (resend prefill, duplicate, fresh reset, apply-raise). User typing updates the
  // draft directly in onChange, so a no-op numeric setState can't strand a raw
  // "0500"/"010" string in the input. Blank-at-zero matches prior behavior.
  useEffect(() => { setTrialWeeksStr(trialWeeks ? String(trialWeeks) : ""); }, [trialWeeks]);
  useEffect(() => { setTrialWeeklyStr(trialWeekly ? String(trialWeekly) : ""); }, [trialWeekly]);
  useEffect(() => { setPostTrialWeeklyStr(postTrialWeekly ? String(postTrialWeekly) : ""); }, [postTrialWeekly]);
  useEffect(() => { setBonusAmountStr(bonusAmount ? String(bonusAmount) : ""); }, [bonusAmount]);

  // Look up categories for current scope items (case-insensitive against library).
  useEffect(() => {
    let cancelled = false;
    if (scope.length === 0) {
      setScopeCatMap({});
      return;
    }
    (async () => {
      const lowered = Array.from(new Set(scope.map((s) => s.toLowerCase())));
      const { data } = await supabase
        .from("job_scope_library")
        .select("text, category")
        .in("text", scope);
      const map: Record<string, string> = {};
      // Case-insensitive: build by lowercased key, also fetch ilike matches if any missed.
      (data || []).forEach((row: { text: string; category: string }) => {
        map[row.text.toLowerCase()] = row.category;
      });
      const missing = lowered.filter((k) => !(k in map));
      if (missing.length > 0) {
        // Fallback for case-mismatch: query each missing one with ilike.
        await Promise.all(
          missing.map(async (k) => {
            const { data: row } = await supabase
              .from("job_scope_library")
              .select("text, category")
              .ilike("text", k)
              .maybeSingle();
            if (row) map[k] = (row as any).category;
          }),
        );
      }
      if (!cancelled) setScopeCatMap(map);
    })();
    return () => {
      cancelled = true;
    };
  }, [scope]);

  const monthlyMin = Math.round(postTrialWeekly * 4);
  const monthlyMax = Math.round(postTrialWeekly * 4.33);

  const applyPreset = (k: ScheduleKey) => {
    setPreset(k);
    if (k !== "custom") {
      const p = PRESETS[k];
      setWeekdayStart(p.weekday_start);
      setWeekdayEnd(p.weekday_end);
      setSaturdayStart(p.saturday_start);
      setSaturdayEnd(p.saturday_end);
    }
  };

  const emailValid = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim());
  const startDateValid = useMemo(() => {
    if (!startDate) return false;
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    return new Date(startDate + "T00:00:00") >= today;
  }, [startDate]);

  const errors = {
    name: !name.trim() ? "Required" : "",
    email: !email.trim()
      ? "Required"
      : !emailValid
        ? "Invalid email"
        : "",
    positionTitle: !positionTitle.trim() ? "Required" : "",
    startDate: !startDate
      ? "Required"
      : !startDateValid
        ? "Start date cannot be in the past"
        : "",
    trialWeeks:
      trialWeeks < 1 || trialWeeks > 12 ? "Must be 1–12" : "",
    trialWeekly: trialWeekly > 0 ? "" : "Must be > 0",
    postTrialWeekly: postTrialWeekly > 0 ? "" : "Must be > 0",
    weekdayStart: weekdayStart ? "" : "Required",
    weekdayEnd: weekdayEnd ? "" : "Required",
    saturdayStart: saturdayStart ? "" : "Required",
    saturdayEnd: saturdayEnd ? "" : "Required",
    scope: scope.length < 3 ? "Need at least 3 scope items" : "",
  };
  const canSave = Object.values(errors).every((v) => !v);

  const onClickUSD = () => {
    if (currency === "USD") return;
    setPwValue("");
    setPwOpen(true);
  };
  const confirmPw = async () => {
    setPwChecking(true);
    try {
      const { data, error } = await supabase.functions.invoke(
        "verify-currency-override",
        { body: { password: pwValue } },
      );
      if (error) throw error;
      if (data?.valid) {
        setCurrency("USD");
        setPwOpen(false);
        setPwValue("");
        toast.success("Currency switched to USD");
      } else {
        toast.error("Incorrect password");
        setPwValue("");
      }
    } catch (e: any) {
      toast.error(e.message || "Verification failed");
    } finally {
      setPwChecking(false);
    }
  };

  const scopeExistsCI = (s: string) =>
    scope.some((x) => x.toLowerCase() === s.toLowerCase());

  const addScopeItem = async (raw: string) => {
    const text = raw.trim();
    if (!text) return;
    if (scopeExistsCI(text)) {
      toast.message("Already in offer");
      return;
    }
    const { data: userRes } = await supabase.auth.getUser();
    const uid = userRes.user?.id || null;
    await supabase
      .from("job_scope_library")
      .insert({ text, category: "General", created_by: uid });
    setScope((s) => [...s, text]);
    setScopeInput("");
  };

  const moveItem = (idx: number, dir: -1 | 1) => {
    setScope((s) => {
      const next = [...s];
      const swap = idx + dir;
      if (swap < 0 || swap >= next.length) return s;
      [next[idx], next[swap]] = [next[swap], next[idx]];
      return next;
    });
  };

  const removeItem = (idx: number) => {
    setScope((s) => s.filter((_, i) => i !== idx));
  };

  const onDragStart = (idx: number) => (e: React.DragEvent) => {
    dragIndex.current = idx;
    e.dataTransfer.effectAllowed = "move";
  };
  const onDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    e.dataTransfer.dropEffect = "move";
  };
  const onDrop = (idx: number) => (e: React.DragEvent) => {
    e.preventDefault();
    const from = dragIndex.current;
    dragIndex.current = null;
    if (from === null || from === idx) return;
    setScope((s) => {
      const next = [...s];
      const [moved] = next.splice(from, 1);
      next.splice(idx, 0, moved);
      return next;
    });
  };

  const onSaveDefault = async () => {
    if (!scope.length) return;
    const { data: existing } = await supabase
      .from("form_metadata")
      .select("default_job_scope_item_ids")
      .eq("form_id", formId)
      .maybeSingle();
    const hasExisting =
      (existing?.default_job_scope_item_ids || []).length > 0;
    if (hasExisting) {
      setOverwriteOpen(true);
    } else {
      await performSaveDefault();
    }
  };

  const performSaveDefault = async () => {
    setSavingDefault(true);
    try {
      const ids: string[] = [];
      const { data: userRes } = await supabase.auth.getUser();
      const uid = userRes.user?.id || null;
      for (const text of scope) {
        await supabase
          .from("job_scope_library")
          .insert({ text, category: "General", created_by: uid });
        const { data: found } = await supabase
          .from("job_scope_library")
          .select("id")
          .ilike("text", text)
          .limit(1)
          .maybeSingle();
        if (found?.id) ids.push(found.id);
      }
      const { error } = await supabase
        .from("form_metadata")
        .update({ default_job_scope_item_ids: ids })
        .eq("form_id", formId);
      if (error) throw error;
      toast.success("Preset saved for this position");
      setOverwriteOpen(false);
    } catch (e: any) {
      toast.error(e.message || "Failed to save preset");
    } finally {
      setSavingDefault(false);
    }
  };

  // Steps 4-7: PDF → SignFlow → emails → finalize. Reusable for retry.
  const runFromPdf = async (jobOfferId: string, offerRef: string): Promise<boolean> => {
    // Step 4: PDF
    setSendPhase("pdf");
    const pdfRes = await supabase.functions.invoke("generate-offer-pdf", {
      body: { job_offer_id: jobOfferId },
    });
    const pdfUrl: string | undefined = (pdfRes.data as any)?.pdf_url;
    if (pdfRes.error || !(pdfRes.data as any)?.success || !pdfUrl) {
      setSendError({
        phase: "pdf",
        message:
          pdfRes.error?.message ||
          (pdfRes.data as any)?.error ||
          "PDF generation failed",
        jobOfferId,
        offerRef,
      });
      return false;
    }
    return runFromSignflow(jobOfferId, offerRef, pdfUrl);
  };

  const runFromSignflow = async (
    jobOfferId: string,
    offerRef: string,
    pdfUrl: string,
  ): Promise<boolean> => {
    setSendPhase("signflow");
    const sfRes = await supabase.functions.invoke("signflow-create-document", {
      body: {
        external_offer_reference: offerRef,
        signer_name: name.trim(),
        signer_email: email.trim(),
        document_title: `Job Offer - ${name.trim()}`,
        pdf_url: pdfUrl,
        signature_field_position: { page: includeAdaptability ? 5 : 4, x: 100, y: 350, width: 200, height: 60 },
      },
    });
    const signingUrl: string | undefined = (sfRes.data as any)?.signing_url;
    const sfToken: string | undefined = (sfRes.data as any)?.signing_token;
    const validSigningUrl = typeof signingUrl === "string" && /^https:\/\/\S+$/i.test(signingUrl);
    if (sfRes.error || !validSigningUrl) {
      setSendError({
        phase: "signflow",
        message:
          sfRes.error?.message ||
          (sfRes.data as any)?.error ||
          (signingUrl ? "SignFlow returned an invalid signing link" : "Couldn't create signing document"),
        jobOfferId,
        offerRef,
        pdfUrl,
      });
      return false;
    }
    // Persist SignFlow's signing_token on the offer row so HR's in-app link
    // matches. The candidate email link uses `signingUrl` directly from
    // SignFlow's response, so a local persist failure does NOT produce a
    // broken email link — we just log a warning.
    if (sfToken) {
      const { error: tokUpdErr } = await supabase
        .from("job_offers")
        .update({ signing_token: sfToken })
        .eq("id", jobOfferId);
      if (tokUpdErr) {
        console.warn("signing_token persist failed (email link still valid)", tokUpdErr);
      }
    }
    return runFromEmail(jobOfferId, offerRef, pdfUrl, signingUrl!);
  };

  const runFromEmail = async (
    jobOfferId: string,
    offerRef: string,
    pdfUrl: string,
    signingUrl: string,
  ): Promise<boolean> => {
    setSendPhase("email");
    const candName = name.trim();
    const position = positionTitle.trim();
    const emailRes = await supabase.functions.invoke("send-dual-email", {
      body: {
        to: email.trim(),
        job_offer_id: jobOfferId,
        stage: "stage_3_offer",
        sender_a: buildOfferSenderA(candName, position, signingUrl, {
          currency,
          baseMonthly: Math.round(postTrialWeekly * 4),
          bonusEnabled,
          bonusAmount,
        }),
        sender_b: buildOfferSenderB(candName, position, signingUrl),
      },
    });
    if (emailRes.error) {
      setSendError({
        phase: "email",
        message: emailRes.error.message || "Email send failed",
        jobOfferId,
        offerRef,
        pdfUrl,
        signingUrl,
      });
      return false;
    }
    // Step 7: finalize
    const { error: upErr } = await supabase
      .from("job_offers")
      .update({ status: "sent", sent_at: new Date().toISOString() })
      .eq("id", jobOfferId);
    if (upErr) {
      setSendError({
        phase: "finalize",
        message: `Email sent but couldn't update status: ${upErr.message}`,
        jobOfferId,
        offerRef,
        pdfUrl,
        signingUrl,
      });
      return false;
    }
    // Tracking: mark this response as offer_sent + record sending HR (single-row, by exact id).
    // Targets the effective response (the new candidate's row when duplicating).
    const trackResponseId = effectiveResponseIdRef.current;
    if (trackResponseId) {
      try {
        const patch: Record<string, any> = {
          round_stage: "offer_sent",
          offer_sent_at: new Date().toISOString(),
        };
        if (hrId) patch.handled_by_hr_id = hrId;
        await supabase.from("responses").update(patch as any).eq("id", trackResponseId);
      } catch (e) {
        console.warn("offer round_stage tracking failed (non-fatal)", e);
      }
    }
    setSendPhase("done");
    setConfirmOpen(false);
    setSavedOffer({ id: jobOfferId, ref: offerRef });
    onSaved?.(offerRef, jobOfferId);
    toast.success(`Offer sent to ${candName}`);
    return true;
  };

  const performSend = async () => {
    setSaving(true);
    setSendError(null);
    setSendPhase("saving");
    // When duplicating an offer to ANOTHER candidate, the new offer must get its
    // OWN distinct candidate identity — never reuse the source candidate's
    // response/candidate_id (that bug bound two offers to one candidate record).
    const isDuplicate = !!activeSource && !isResend;
    // For a normal (non-duplicate) send, persist override_email on THIS response.
    if (!isDuplicate && responseId && email.trim()) {
      try {
        await supabase
          .from("responses")
          .update({ override_email: email.trim() })
          .eq("id", responseId);
      } catch (e) {
        console.warn("override_email persist failed (non-fatal)", e);
      }
    }
    try {
      let jobOfferId: string;
      let offerRef: string;
      let candidateIdForOffer: string | null = null;
      let dupResponseId: string | null = null;
      if (isDuplicate) {
        // Create a brand-new candidate record (distinct applicant_id + response)
        // so name/email/role/team writes never cross into the source candidate.
        const newCandidateId =
          (globalThis.crypto as any)?.randomUUID?.() ||
          `${Date.now()}-${Math.random().toString(36).slice(2)}`;
        const { data: newResp, error: newRespErr } = await supabase
          .from("responses")
          .insert({
            form_id: formId,
            applicant_id: newCandidateId,
            status: "completed",
            override_name: name.trim(),
            override_email: email.trim(),
            round_stage: "offer_sent",
            offer_sent_at: new Date().toISOString(),
          })
          .select("id, applicant_id")
          .single();
        if (newRespErr) throw newRespErr;
        dupResponseId = newResp.id;
        candidateIdForOffer = (newResp as any).applicant_id;
      } else if (responseId) {
        const { data: respRow } = await supabase
          .from("responses")
          .select("applicant_id")
          .eq("id", responseId)
          .maybeSingle();
        candidateIdForOffer = (respRow as any)?.applicant_id || null;
      }
      // Resolve which response downstream tracking writes should target.
      effectiveResponseIdRef.current = isDuplicate ? dupResponseId : (responseId ?? null);

      if (isResend && existingOfferId) {
        // Option B: update existing row with fresh data + new signing_token
        const token = randomToken(32);
        const updatePayload: any = {
          candidate_name: name.trim(),
          candidate_email: email.trim(),
          position_title: positionTitle.trim(),
          start_date: startDate,
          trial_weeks: trialWeeks,
          currency,
          trial_weekly_salary: trialWeekly,
          post_trial_weekly_salary: postTrialWeekly,
          monthly_range_min: monthlyMin,
          monthly_range_max: monthlyMax,
          raise_applied: applyRaise,
          weekday_start: weekdayStart,
          weekday_end: weekdayEnd,
          saturday_start: saturdayStart,
          saturday_end: saturdayEnd,
          sunday_off: true,
          schedule_preset_used: preset,
          scope_items: scope,
          internal_notes: notes.trim() || null,
          remarks: remarks.trim() || null,
          performance_bonus_enabled: bonusEnabled,
          performance_bonus_amount: bonusEnabled ? bonusAmount : null,
          include_adaptability_clause: includeAdaptability,
          candidate_id: candidateIdForOffer,
          signing_token: token,
          status: "draft",
        };
        const { data, error } = await supabase
          .from("job_offers")
          .update(updatePayload)
          .eq("id", existingOfferId)
          .select("id, offer_reference_id")
          .single();
        if (error) throw error;
        jobOfferId = data.id;
        offerRef = data.offer_reference_id;
      } else {
        // Fresh insert. Handle parallel group when duplicating.
        let parallelGroupId: string | null = null;
        let duplicatedFromOfferId: string | null = null;
        if (activeSource) {
          duplicatedFromOfferId = activeSource.id;
          if (activeSource.parallel_group_id) {
            parallelGroupId = activeSource.parallel_group_id;
          } else {
            parallelGroupId =
              (globalThis.crypto as any)?.randomUUID?.() ||
              `${Date.now()}-${Math.random().toString(36).slice(2)}`;
            const upd = await supabase
              .from("job_offers")
              .update({ parallel_group_id: parallelGroupId })
              .eq("id", activeSource.id);
            if (upd.error) {
              const retry = await supabase
                .from("job_offers")
                .update({ parallel_group_id: parallelGroupId })
                .eq("id", activeSource.id);
              if (retry.error) throw retry.error;
            }
            setActiveSource({ ...activeSource, parallel_group_id: parallelGroupId });
          }
        }

        const token = randomToken(32);
        const insertPayload: any = {
          form_id: formId,
          candidate_name: name.trim(),
          candidate_email: email.trim(),
          position_title: positionTitle.trim(),
          start_date: startDate,
          trial_weeks: trialWeeks,
          currency,
          trial_weekly_salary: trialWeekly,
          post_trial_weekly_salary: postTrialWeekly,
          monthly_range_min: monthlyMin,
          monthly_range_max: monthlyMax,
          raise_applied: applyRaise,
          weekday_start: weekdayStart,
          weekday_end: weekdayEnd,
          saturday_start: saturdayStart,
          saturday_end: saturdayEnd,
          sunday_off: true,
          schedule_preset_used: preset,
          scope_items: scope,
          internal_notes: notes.trim() || null,
          remarks: remarks.trim() || null,
          performance_bonus_enabled: bonusEnabled,
          performance_bonus_amount: bonusEnabled ? bonusAmount : null,
          include_adaptability_clause: includeAdaptability,
          candidate_id: candidateIdForOffer,
          signing_token: token,
          status: "draft",
          parallel_group_id: parallelGroupId,
          duplicated_from_offer_id: duplicatedFromOfferId,
          hr_copy_requested: hrCopy.requested === true,
          hr_copy_email_override: hrCopy.requested && hrCopy.override ? hrCopy.override : null,
        };
        const { data, error } = await supabase
          .from("job_offers")
          .insert(insertPayload)
          .select("id, offer_reference_id")
          .single();
        if (error) throw error;
        jobOfferId = data.id;
        offerRef = data.offer_reference_id;

        // For a duplicated offer, give the new candidate its OWN candidate_actions
        // row (distinct response_id + candidate_id) so pipeline/role/team writes
        // stay isolated from the source candidate.
        if (isDuplicate && dupResponseId && candidateIdForOffer) {
          const { error: caErr } = await supabase
            .from("candidate_actions")
            .insert({
              candidate_id: candidateIdForOffer,
              form_id: formId,
              response_id: dupResponseId,
              job_offer_id: jobOfferId,
            });
          if (caErr) console.warn("candidate_actions create for duplicate failed (non-fatal)", caErr);
        }

        for (const t of scope) {
          const { data: row } = await supabase
            .from("job_scope_library")
            .select("id, usage_count")
            .ilike("text", t)
            .limit(1)
            .maybeSingle();
          if (row?.id) {
            await supabase
              .from("job_scope_library")
              .update({ usage_count: (row.usage_count || 0) + 1 })
              .eq("id", row.id);
          }
        }
      }

      // Scheduled branch: the offer row is saved (status draft); instead of
      // running the live PDF→SignFlow→email composite now, persist a pending
      // scheduled_sends row that the fire engine replays via replay-offer-send
      // with the EXACT { job_offer_id, to } payload.
      if (schedule.mode === "schedule") {
        await insertScheduledSend({
          send_type: "offer",
          target_function: "replay-offer-send",
          payload: { job_offer_id: jobOfferId, to: email.trim() },
          response_id: effectiveResponseIdRef.current ?? null,
          scheduled_for_utc: schedule.scheduled_for_utc,
          timezone: schedule.timezone,
        });
        setSendPhase("idle");
        setConfirmOpen(false);
        setSavedOffer({ id: jobOfferId, ref: offerRef });
        onSaved?.(offerRef, jobOfferId);
        toast.success(
          `Offer scheduled for ${formatScheduledFor(schedule.scheduled_for_utc, schedule.timezone)}`,
        );
        return;
      }

      await runFromPdf(jobOfferId, offerRef);
    } catch (e: any) {
      setSendError({ phase: "save", message: e.message || "Failed to save offer" });
      toast.error(e.message || "Failed to save offer");
    } finally {
      setSaving(false);
    }
  };

  const retrySend = async () => {
    if (!sendError) return;
    setSaving(true);
    const err = sendError;
    setSendError(null);
    try {
      if (err.phase === "pdf" && err.jobOfferId && err.offerRef) {
        await runFromPdf(err.jobOfferId, err.offerRef);
      } else if (err.phase === "signflow" && err.jobOfferId && err.offerRef && err.pdfUrl) {
        await runFromSignflow(err.jobOfferId, err.offerRef, err.pdfUrl);
      } else if (err.phase === "email" && err.jobOfferId && err.offerRef && err.pdfUrl && err.signingUrl) {
        await runFromEmail(err.jobOfferId, err.offerRef, err.pdfUrl, err.signingUrl);
      } else {
        // save phase or insufficient context — restart
        await performSend();
      }
    } finally {
      setSaving(false);
    }
  };

  const copyToClipboard = async (txt: string) => {
    try {
      await navigator.clipboard.writeText(txt);
      toast.success("Copied to clipboard");
    } catch {
      toast.error("Copy failed");
    }
  };

  // Build a SourceOffer snapshot of the just-saved form for duplicate-from-here
  const buildSourceFromCurrent = (id: string): SourceOffer => ({
    id,
    position_title: positionTitle.trim(),
    trial_weeks: trialWeeks,
    trial_weekly_salary: trialWeekly,
    post_trial_weekly_salary: postTrialWeekly,
    monthly_range_min: monthlyMin,
    monthly_range_max: monthlyMax,
    raise_applied: applyRaise,
    currency,
    schedule_preset_used: preset,
    weekday_start: weekdayStart,
    weekday_end: weekdayEnd,
    saturday_start: saturdayStart,
    saturday_end: saturdayEnd,
    sunday_off: true,
    scope_items: scope,
    internal_notes: notes.trim() || null,
    remarks: remarks.trim() || null,
    // If we just saved a duplicate, reuse the group; else null (will be created on next dup save)
    parallel_group_id: activeSource?.parallel_group_id ?? null,
  });

  const startDuplicateFromSaved = () => {
    if (!savedOffer) return;
    const src = buildSourceFromCurrent(savedOffer.id);
    setSavedOffer(null);
    setActiveSource(src);
    setResetKey((k) => k + 1);
  };


  const footerEl = (
    <>
      <Button variant="ghost" onClick={onClose} className="text-[#6b7280] hover:text-[#1a2236]">
        Cancel
      </Button>
      <button
        type="button"
        disabled={!canSave}
        onClick={() => setConfirmOpen(true)}
        className={`action-btn action-btn--lg ${canSave ? "action-btn--primary" : "action-btn--disabled"}`}
        style={{ width: "auto", paddingLeft: 24, paddingRight: 24 }}
      >
        {isResend ? `Re-send Offer (${currency})` : `Send Offer (${currency})`}
      </button>
    </>
  );

  return (
    <>
      {savedOffer ? (
        <ModalShell
          open={open}
          onClose={() => { setSavedOffer(null); onClose(); }}
          title="Offer sent"
          subtitle={`Reference: ${savedOffer.ref}`}
          footer={
            <>
              <Button variant="ghost" onClick={() => { setSavedOffer(null); onClose(); }} className="text-[#6b7280]">
                Done
              </Button>
              <button
                type="button"
                onClick={startDuplicateFromSaved}
                className="action-btn action-btn--lg action-btn--primary"
                style={{ width: "auto", paddingLeft: 24, paddingRight: 24 }}
              >
                Send same offer to another candidate
              </button>
            </>
          }
        >
          <div className="flex flex-col items-center justify-center text-center gap-3 py-10">
            <CheckCircle2 className="h-14 w-14 text-green-600" />
            <h3 className="text-xl font-semibold text-[#1a2236]">Offer sent successfully</h3>
            <p className="text-sm text-[#6b7280]">
              Reference: <span className="font-mono font-medium text-[#1a2236]">{savedOffer.ref}</span>
            </p>
            <p className="text-sm text-[#1a2236]">Need to send the same offer to another candidate?</p>
            <p className="text-xs text-[#9ca3af] italic">
              If they accept, you'll need to manually withdraw the other offers.
            </p>
          </div>
        </ModalShell>
      ) : (
        <ModalShell
          open={open}
          onClose={onClose}
          title="Send Job Offer"
          subtitle={`Review details, then send to ${name || "candidate"}`}
          footer={footerEl}
        >
          <Section title="Candidate">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <EditableContactField
                label="Candidate name"
                value={name}
                onChange={setName}
                onSave={async (v) => {
                  if (responseId && nameQid) await updateResponseAnswer(responseId, nameQid, v);
                  onContactUpdated?.({ name: v });
                }}
              />
              <div>
                <label className="block text-[12px] font-medium text-[#6b7280] mb-1.5">Send to (email)</label>
                <Input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="candidate@example.com"
                  className="h-10 text-sm"
                />
                <p className="mt-1 text-[11px] text-[#6b7280]">
                  Edit if missing or incorrect. Saved as the override for all future sends to this candidate.
                </p>
              </div>
            </div>
            {(errors.name || errors.email) && (
              <p className="text-xs text-destructive mt-2">{errors.name || errors.email}</p>
            )}
          </Section>

            <Section title="Position & Dates">
              <Field label="Position title" error={errors.positionTitle}>
                <Input
                  className="h-10"
                  value={positionTitle}
                  onChange={(e) => setPositionTitle(e.target.value)}
                  maxLength={80}
                />
              </Field>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <Field label="Start date" error={errors.startDate}>
                  <Input
                    className="h-10"
                    type="date"
                    value={startDate}
                    onChange={(e) => setStartDate(e.target.value)}
                  />
                </Field>
                <Field label="Trial weeks" error={errors.trialWeeks}>
                  <Input
                    className="h-10"
                    type="number"
                    inputMode="numeric"
                    min={1}
                    max={12}
                    value={trialWeeksStr}
                    onChange={(e) => {
                      const cleaned = e.target.value.replace(/^0+(?=\d)/, "");
                      if (cleaned !== e.target.value) e.target.value = cleaned;
                      setTrialWeeksStr(cleaned);
                      setTrialWeeks(Number(cleaned) || 0);
                    }}
                  />
                </Field>
              </div>
            </Section>

            <Section title="Salary">
              <div className="flex gap-2">
                <button
                  type="button"
                  className={`action-btn action-btn--lg ${currency === "PHP" ? "action-btn--primary" : "action-btn--disabled"}`}
                  style={{ flex: 1 }}
                  onClick={() => setCurrency("PHP")}
                >
                  PHP
                </button>
                <button
                  type="button"
                  className={`action-btn action-btn--lg ${currency === "USD" ? "action-btn--primary" : "action-btn--disabled"}`}
                  style={{ flex: 1 }}
                  onClick={onClickUSD}
                >
                  USD
                </button>
              </div>

              <Field
                label={`Trial weekly salary`}
                error={errors.trialWeekly}
              >
                <div className="flex items-center gap-2">
                  <Input
                    className="h-10"
                    type="number"
                    inputMode="numeric"
                    value={trialWeeklyStr}
                    onChange={(e) => {
                      const cleaned = e.target.value.replace(/^0+(?=\d)/, "");
                      if (cleaned !== e.target.value) e.target.value = cleaned;
                      setTrialWeeklyStr(cleaned);
                      setTrialWeekly(Number(cleaned) || 0);
                    }}
                  />
                  <span className="text-sm text-[#6b7280] whitespace-nowrap">
                    {currency} / week
                  </span>
                </div>
              </Field>

              <label className="flex items-center gap-2 text-sm text-[#1a2236]">
                <Checkbox
                  checked={applyRaise}
                  onCheckedChange={(v) => setApplyRaise(!!v)}
                />
                Apply standard raise
              </label>

              <Field
                label={`Post-trial weekly salary`}
                error={errors.postTrialWeekly}
              >
                <div className="flex items-center gap-2">
                  <Input
                    className="h-10"
                    type="number"
                    inputMode="numeric"
                    disabled={!applyRaise}
                    value={postTrialWeeklyStr}
                    onChange={(e) => {
                      const cleaned = e.target.value.replace(/^0+(?=\d)/, "");
                      if (cleaned !== e.target.value) e.target.value = cleaned;
                      setPostTrialWeeklyStr(cleaned);
                      setPostTrialWeekly(Number(cleaned) || 0);
                    }}
                  />
                  <span className="text-sm text-[#6b7280] whitespace-nowrap">
                    {currency} / week
                  </span>
                </div>
              </Field>

              <div className="text-sm text-[#1a2236]">
                Monthly range:{" "}
                <span className={currency === "USD" ? "text-amber-600 font-medium" : "font-medium"}>
                  {currency} {monthlyMin.toLocaleString()} –{" "}
                  {monthlyMax.toLocaleString()}
                </span>
              </div>

              <p className="text-xs italic text-[#9ca3af]">
                {applyRaise
                  ? "Performance Review Clause will apply: post-trial salary subject to management approval based on demonstrated performance and value delivered during the trial period."
                  : "Compensation Review Clause will apply: salary remains fixed through the trial period."}
              </p>

              {/* Performance Bonus */}
              <div className="pt-2 border-t border-[#e1e4ec]">
                <label className="flex items-center gap-2 text-sm text-[#1a2236] cursor-pointer">
                  <Checkbox
                    checked={bonusEnabled}
                    onCheckedChange={(v) => setBonusEnabled(!!v)}
                  />
                  Performance Bonus (discretionary, per pay period)
                </label>
                {bonusEnabled && (
                  <>
                    <div className="mt-2 flex items-center gap-2 max-w-xs">
                      <span className="text-sm text-[#6b7280]">{currency === "PHP" ? "₱" : "$"}</span>
                      <Input
                        className="h-10"
                        type="number"
                        inputMode="numeric"
                        min={0}
                        value={bonusAmountStr}
                        onChange={(e) => {
                          const cleaned = e.target.value.replace(/^0+(?=\d)/, "");
                          if (cleaned !== e.target.value) e.target.value = cleaned;
                          setBonusAmountStr(cleaned);
                          setBonusAmount(Number(cleaned) || 0);
                        }}
                      />
                      <span className="text-sm text-[#6b7280] whitespace-nowrap">/ period</span>
                    </div>
                    <div
                      className="mt-2 text-[12px] leading-[1.55]"
                      style={{
                        fontFamily: "'Inter', sans-serif",
                        color: "#1a2236",
                        background: "#fafaf7",
                        borderLeft: "3px solid #b08d57",
                        padding: "12px",
                      }}
                    >
                      This performance bonus of up to {currency === "PHP" ? "₱" : "$"}
                      {bonusAmount.toLocaleString()} per pay period is discretionary and based on
                      individual performance metrics including productivity, accuracy, punctuality,
                      and overall contribution. The bonus is reviewed regularly and may be adjusted,
                      reduced, or withheld entirely at the company's discretion based on performance
                      assessment. Continued eligibility requires sustained performance standards as
                      determined by management. This bonus is not part of guaranteed compensation.
                    </div>
                  </>
                )}
              </div>
            </Section>


            <Section title="Schedule">
              <Field label="Preset">
                <Select
                  value={preset}
                  onValueChange={(v) => applyPreset(v as ScheduleKey)}
                >
                  <SelectTrigger className="h-10">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {Object.entries(PRESETS).map(([k, p]) => (
                      <SelectItem key={k} value={k}>
                        {p.label}
                      </SelectItem>
                    ))}
                    <SelectItem value="custom">Custom…</SelectItem>
                  </SelectContent>
                </Select>
              </Field>

              <div className="grid grid-cols-2 gap-3">
                <Field label="Mon-Fri start" error={errors.weekdayStart}>
                  <Input
                    className="h-10"
                    type="time"
                    disabled={preset !== "custom"}
                    value={weekdayStart}
                    onChange={(e) => setWeekdayStart(e.target.value)}
                  />
                </Field>
                <Field label="Mon-Fri end" error={errors.weekdayEnd}>
                  <Input
                    className="h-10"
                    type="time"
                    disabled={preset !== "custom"}
                    value={weekdayEnd}
                    onChange={(e) => setWeekdayEnd(e.target.value)}
                  />
                </Field>
                <Field label="Saturday start" error={errors.saturdayStart}>
                  <Input
                    className="h-10"
                    type="time"
                    disabled={preset !== "custom"}
                    value={saturdayStart}
                    onChange={(e) => setSaturdayStart(e.target.value)}
                  />
                </Field>
                <Field label="Saturday end" error={errors.saturdayEnd}>
                  <Input
                    className="h-10"
                    type="time"
                    disabled={preset !== "custom"}
                    value={saturdayEnd}
                    onChange={(e) => setSaturdayEnd(e.target.value)}
                  />
                </Field>
              </div>

              <div className="text-sm text-[#6b7280] space-y-0.5">
                <div>
                  Mon-Fri: {fmtTime(weekdayStart)} – {fmtTime(weekdayEnd)}
                </div>
                <div>
                  Saturday: {fmtTime(saturdayStart)} – {fmtTime(saturdayEnd)}
                </div>
                <div>Sunday: Off</div>
              </div>
            </Section>

            <Section title="Job Scope">
              <p className="text-xs italic text-[#9ca3af]">
                List of tasks this candidate will be responsible for. Minimum 3
                items required.
              </p>

              {scope.length === 0 ? (
                <div className="rounded-md border border-dashed border-[#e1e4ec] bg-white p-6 text-center text-sm text-[#9ca3af] italic">
                  No scope items selected yet. Add some below.
                </div>
              ) : (
                <ul className="space-y-2">
                  {scope.map((text, i) => {
                    const cat = scopeCatMap[text.toLowerCase()];
                    const color = categoryColor(cat);
                    return (
                      <li
                        key={`${i}-${text}`}
                        draggable
                        onDragStart={onDragStart(i)}
                        onDragOver={onDragOver}
                        onDrop={onDrop(i)}
                        className="flex items-start gap-2 p-3 bg-white border border-[#e1e4ec] rounded-md shadow-sm"
                        style={{ borderLeft: `4px solid ${color}` }}
                      >
                        <span className="cursor-grab touch-none p-1 text-[#9aa1ad] mt-0.5">
                          <GripVertical className="h-4 w-4" />
                        </span>
                        <button
                          className="h-9 w-9 inline-flex items-center justify-center rounded text-[#9aa1ad] hover:text-[#1a2547] hover:bg-[#f4f5f8]"
                          onClick={() => moveItem(i, -1)}
                          aria-label="Move up"
                        >
                          <ArrowUp className="h-4 w-4" />
                        </button>
                        <button
                          className="h-9 w-9 inline-flex items-center justify-center rounded text-[#9aa1ad] hover:text-[#1a2547] hover:bg-[#f4f5f8]"
                          onClick={() => moveItem(i, 1)}
                          aria-label="Move down"
                        >
                          <ArrowDown className="h-4 w-4" />
                        </button>
                        <div className="flex-1 min-w-0">
                          <div className="text-sm text-[#1a2236]">{text}</div>
                          {cat && (
                            <div
                              className="text-[11px] mt-0.5 flex items-center gap-1.5"
                              style={{ color: "#6b7280" }}
                            >
                              <span
                                className="inline-block h-2 w-2 rounded-full"
                                style={{ background: color }}
                              />
                              {normalizeCategory(cat)}
                            </div>
                          )}
                        </div>
                        <button
                          className="h-9 w-9 inline-flex items-center justify-center rounded text-[#9aa1ad] hover:text-[#dc2626] hover:bg-red-50"
                          onClick={() => removeItem(i)}
                          aria-label="Remove"
                        >
                          <X className="h-4 w-4" />
                        </button>
                      </li>
                    );
                  })}
                </ul>
              )}

              <div className="flex flex-wrap gap-2">
                <Button
                  type="button"
                  variant="outline"
                  className="h-10 border-[#1a2547] text-[#1a2547] hover:bg-[#1a2547] hover:text-white"
                  onClick={() => setLibraryOpen(true)}
                >
                  <Library className="h-4 w-4 mr-2" />
                  Browse Library
                </Button>
                <Button
                  type="button"
                  variant="outline"
                  className="h-10 border-[#b08d57] text-[#b08d57] hover:bg-[#b08d57] hover:text-white"
                  disabled={!positionTitle.trim()}
                  onClick={() => {
                    setAiMode("suggest");
                    setAiOpen(true);
                  }}
                  title={
                    !positionTitle.trim()
                      ? "Enter a position title to use AI Suggest"
                      : "Generate scope items with AI"
                  }
                >
                  <Sparkles className="h-4 w-4 mr-2" />
                  AI Suggest
                </Button>
                <Button
                  type="button"
                  variant="outline"
                  className="h-10 border-[#d97706] text-[#d97706] hover:bg-[#fef3c7] active:scale-[0.98] transition-transform"
                  disabled={!positionTitle.trim() || aiOverrideLoading}
                  onClick={() => setAiOverrideConfirmOpen(true)}
                  title={
                    !positionTitle.trim()
                      ? "Enter a position title to use AI Override"
                      : "Replace all scope items with AI suggestions"
                  }
                >
                  {aiOverrideLoading ? (
                    <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                  ) : (
                    <Sparkles className="h-4 w-4 mr-2" />
                  )}
                  AI Override
                </Button>
                <Button
                  type="button"
                  variant="ghost"
                  className="h-10 text-[#6b7280] hover:text-[#1a2236]"
                  disabled={scope.length === 0 || savingDefault}
                  onClick={onSaveDefault}
                >
                  {savingDefault && (
                    <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                  )}
                  Save as default
                </Button>
              </div>

              <div className="flex gap-2">
                <Input
                  className="h-10"
                  placeholder="+ Add scope item..."
                  value={scopeInput}
                  onChange={(e) => setScopeInput(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === "Enter") {
                      e.preventDefault();
                      addScopeItem(scopeInput);
                    }
                  }}
                />
                <Button
                  type="button"
                  variant="outline"
                  className="h-10"
                  onClick={() => addScopeItem(scopeInput)}
                >
                  <Plus className="h-4 w-4" />
                </Button>
              </div>

              {errors.scope && (
                <p className="text-xs text-destructive">{errors.scope}</p>
              )}
            </Section>

            <Section title="Offer Letter Clauses">
              <label
                className="flex items-start gap-2 text-sm text-[#1a2236] cursor-pointer"
                title="Includes a clause stating employee will perform reasonable additional tasks within their 8-hour workday"
              >
                <Checkbox
                  className="mt-0.5"
                  checked={includeAdaptability}
                  onCheckedChange={(v) => setIncludeAdaptability(!!v)}
                />
                <span>
                  Include "Scope of Work and Adaptability" clause
                  <span className="block text-xs text-[#9ca3af] mt-0.5">
                    Covers tasks not explicitly listed in job scope. Recommended for all offers.
                  </span>
                </span>
              </label>
            </Section>


            <Section title="Internal Notes">
              <p className="text-xs italic text-[#9ca3af]">Not shown to candidate.</p>
              <Textarea
                rows={5}
                placeholder="e.g. Candidate referred by John, has 2 yrs experience in real estate, prefers async work"
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
              />
            </Section>

            <Section title="Remarks">
              <p className="text-xs italic text-[#b45309]">
                Prints on the candidate's contract (last page). Unlike Internal Notes, the candidate sees this.
              </p>
              <Textarea
                rows={3}
                placeholder="e.g. Contract on condition… (optional). Leave blank for 'No Remarks'."
                value={remarks}
                onChange={(e) => setRemarks(e.target.value)}
              />
            </Section>
        </ModalShell>
      )}

      <LibraryBrowser
        open={libraryOpen}
        onClose={() => setLibraryOpen(false)}
        selectedTexts={scope}
        onAdd={(texts) => {
          setScope((s) => [
            ...s,
            ...texts.filter(
              (t) => !s.some((x) => x.toLowerCase() === t.toLowerCase()),
            ),
          ]);
          setLibraryOpen(false);
        }}
      />

      <AiSuggestDialog
        open={aiOpen}
        onClose={() => setAiOpen(false)}
        positionTitle={positionTitle}
        existingItems={aiMode === "override" ? [] : scope}
        mode={aiMode}
        onAdd={async (texts) => {
          const toAdd = texts.filter(
            (t) => !scope.some((x) => x.toLowerCase() === t.toLowerCase()),
          );
          if (toAdd.length === 0) {
            setAiOpen(false);
            return;
          }
          const { data: userRes } = await supabase.auth.getUser();
          const uid = userRes.user?.id || null;
          for (const text of toAdd) {
            const { data: existing } = await supabase
              .from("job_scope_library")
              .select("id")
              .ilike("text", text)
              .maybeSingle();
            if (!existing) {
              await supabase
                .from("job_scope_library")
                .insert({ text, category: "General", created_by: uid });
            }
          }
          setScope((s) => [...s, ...toAdd]);
          toast.success(`Added ${toAdd.length} item${toAdd.length === 1 ? "" : "s"}`);
          setAiOpen(false);
        }}
      />

      <AlertDialog
        open={aiOverrideConfirmOpen}
        onOpenChange={(o) => !aiOverrideLoading && setAiOverrideConfirmOpen(o)}
      >
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Replace all scope items?</AlertDialogTitle>
            <AlertDialogDescription>
              This will REPLACE all current scope items with new AI suggestions. Continue?
              <span className="block mt-2 text-xs text-muted-foreground">
                Your current items will be removed from this offer but stay in the library.
              </span>
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={aiOverrideLoading}>Cancel</AlertDialogCancel>
            <AlertDialogAction
              className="bg-[#d97706] hover:bg-[#b45309] text-white"
              disabled={aiOverrideLoading}
              onClick={(e) => {
                e.preventDefault();
                if (aiOverrideLoading) return;
                const prevScope = scope;
                setAiOverrideLoading(true);
                // Optimistically clear scope, then open AI dialog in override mode.
                // If the AI dialog encounters an error, the user sees it inline and can cancel;
                // we restore prevScope if they close without adding.
                setScope([]);
                setAiMode("override");
                setAiOverrideConfirmOpen(false);
                setAiOpen(true);
                setAiOverrideLoading(false);
                // Stash prev scope on window so we could restore — but simpler: rely on Cancel
                // to leave scope empty. Per spec, items stay in library so this is acceptable.
                void prevScope;
              }}
            >
              Yes, replace all
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
      <AlertDialog open={pwOpen} onOpenChange={setPwOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Currency Override</AlertDialogTitle>
            <AlertDialogDescription>
              USD is non-standard. Enter override password to switch.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <Input
            type="password"
            value={pwValue}
            onChange={(e) => setPwValue(e.target.value)}
            autoFocus
            onKeyDown={(e) => {
              if (e.key === "Enter") confirmPw();
            }}
          />
          <AlertDialogFooter>
            <AlertDialogCancel onClick={() => setPwValue("")}>
              Cancel
            </AlertDialogCancel>
            <AlertDialogAction
              onClick={(e) => {
                e.preventDefault();
                confirmPw();
              }}
              disabled={pwChecking}
            >
              {pwChecking && (
                <Loader2 className="h-4 w-4 mr-2 animate-spin" />
              )}
              Confirm
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      <AlertDialog open={overwriteOpen} onOpenChange={setOverwriteOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Overwrite preset?</AlertDialogTitle>
            <AlertDialogDescription>
              This form already has a preset. Overwrite?
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={(e) => {
                e.preventDefault();
                performSaveDefault();
              }}
            >
              Yes, overwrite
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      <Dialog open={confirmOpen} onOpenChange={setConfirmOpen}>
        <DialogContent className="max-w-[560px] p-0 flex flex-col max-h-[85vh]">
          <div className="px-6 pt-6 pb-2 shrink-0">
            <h3 className="text-lg font-semibold mb-2">Confirm Offer Details</h3>
          </div>
          <div className="flex-1 overflow-y-auto px-6">
            <div className="text-sm space-y-1">
              <div>
                <strong>Candidate:</strong> {name} ({email})
              </div>
              <div>
                <strong>Position:</strong> {positionTitle}
              </div>
              <div>
                <strong>Start date:</strong> {fmtDate(startDate)}
              </div>
              <div>
                <strong>Currency:</strong>{" "}
                <span className={currency === "USD" ? "text-amber-400" : ""}>
                  {currency}
                </span>
              </div>
              <div>
                <strong>Trial:</strong> {currency}{" "}
                {trialWeekly.toLocaleString()} × {trialWeeks} weeks ={" "}
                {currency} {(trialWeekly * trialWeeks).toLocaleString()}
              </div>
              <div>
                <strong>Post-trial:</strong> {currency}{" "}
                {postTrialWeekly.toLocaleString()}/week ({currency}{" "}
                {monthlyMin.toLocaleString()}–{monthlyMax.toLocaleString()}/month)
              </div>
              <div>
                <strong>Raise:</strong>{" "}
                {applyRaise
                  ? "Yes — Performance Review Clause"
                  : "No — Compensation Review Clause"}
              </div>
              <div>
                <strong>Schedule:</strong>
                <div className="ml-4">
                  <div>
                    Mon-Fri: {fmtTime(weekdayStart)}–{fmtTime(weekdayEnd)}
                  </div>
                  <div>
                    Saturday: {fmtTime(saturdayStart)}–{fmtTime(saturdayEnd)}
                  </div>
                  <div>Sunday: Off</div>
                </div>
              </div>
              <div>
                <strong>Job scope:</strong> {scope.length} items
              </div>
              <div>
                <strong>Internal notes:</strong>{" "}
                {notes.trim() ? notes.trim().slice(0, 100) : "None"}
              </div>
            </div>

            <div className="mt-3">
              <HrCopyCheckbox
                value={hrCopy}
                onChange={setHrCopy}
                disabled={saving || (sendPhase !== "idle" && sendPhase !== "done")}
                label="If signed, send copy to internal backup inbox"
                idPrefix="offer-hrcopy"
              />
            </div>

            <div className="mt-3">
              <SendScheduleControl onChange={setSchedule} />
            </div>

            {sendPhase !== "idle" && sendPhase !== "done" && !sendError && (
              <div className="mt-3 rounded-md border border-[#e1e4ec] bg-[#f9fafb] p-3 text-sm text-[#1a2236] flex items-center gap-2">
                <Loader2 className="h-4 w-4 animate-spin" />
                {sendPhase === "saving" && "Saving offer..."}
                {sendPhase === "pdf" && "Generating offer letter..."}
                {sendPhase === "signflow" && "Creating signing document..."}
                {sendPhase === "email" && "Sending email..."}
              </div>
            )}

            {sendError && (
              <div className="mt-3 rounded-md border border-amber-300 bg-amber-50 p-3 text-sm">
                <div className="font-semibold text-amber-900 mb-1">
                  {sendError.phase === "pdf" && "PDF generation failed"}
                  {sendError.phase === "signflow" && "Couldn't create signing document"}
                  {sendError.phase === "email" && "Email send failed"}
                  {sendError.phase === "finalize" && "Status update failed"}
                  {sendError.phase === "save" && "Couldn't save offer"}
                </div>
                <div className="text-amber-900 mb-2">{sendError.message}</div>
                {sendError.pdfUrl && (
                  <div className="text-xs text-amber-900 break-all mb-1">
                    PDF: <a href={sendError.pdfUrl} target="_blank" rel="noreferrer" className="underline">{sendError.pdfUrl}</a>
                    <button type="button" onClick={() => copyToClipboard(sendError.pdfUrl!)} className="ml-2 underline">Copy</button>
                  </div>
                )}
                {sendError.signingUrl && (
                  <div className="text-xs text-amber-900 break-all">
                    Signing link: <a href={sendError.signingUrl} target="_blank" rel="noreferrer" className="underline">{sendError.signingUrl}</a>
                    <button type="button" onClick={() => copyToClipboard(sendError.signingUrl!)} className="ml-2 underline">Copy</button>
                  </div>
                )}
              </div>
            )}
          </div>

          <div className="shrink-0 border-t px-6 py-4 flex justify-end gap-2">
            <Button variant="ghost" onClick={() => setConfirmOpen(false)} disabled={saving}>
              {sendError ? "Close" : "Back to edit"}
            </Button>
            {sendError ? (
              <Button onClick={retrySend} disabled={saving}>
                {saving && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
                Retry
              </Button>
            ) : (
              <Button onClick={performSend} disabled={saving}>
                {saving && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
                {schedule.mode === "schedule" ? "Confirm & Schedule" : "Confirm & Send"}
              </Button>
            )}
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
}


function Section({
  title,
  children,
}: {
  title: string;
  children: React.ReactNode;
}) {
  return <ModalSection title={title}>{children}</ModalSection>;
}

function Field({
  label,
  error,
  children,
}: {
  label: string;
  error?: string;
  children: React.ReactNode;
}) {
  return (
    <div>
      <Label className="block text-[12px] font-medium text-[#6b7280] mb-1.5">{label}</Label>
      {children}
      {error && <p className="text-xs text-destructive mt-1">{error}</p>}
    </div>
  );
}

function LibraryBrowser({
  open,
  onClose,
  selectedTexts,
  onAdd,
}: {
  open: boolean;
  onClose: () => void;
  selectedTexts: string[];
  onAdd: (texts: string[]) => void;
}) {
  const [items, setItems] = useState<LibraryItem[]>([]);
  const [loading, setLoading] = useState(false);
  const [search, setSearch] = useState("");
  const [category, setCategory] = useState<string>("all");
  const [picked, setPicked] = useState<Record<string, boolean>>({});
  const [newText, setNewText] = useState("");
  const [newCat, setNewCat] = useState("General");
  const [grouped, setGrouped] = useState(true);

  const selectedLower = useMemo(
    () => new Set(selectedTexts.map((s) => s.toLowerCase())),
    [selectedTexts],
  );

  const load = async () => {
    setLoading(true);
    let q = supabase
      .from("job_scope_library")
      .select("id, text, category, usage_count")
      .order("text");
    if (search.trim()) q = q.ilike("text", `%${search.trim()}%`);
    if (category !== "all") q = q.eq("category", category);
    const { data } = await q;
    setItems((data || []) as LibraryItem[]);
    setLoading(false);
  };

  useEffect(() => {
    if (!open) return;
    setPicked({});
    setSearch("");
    setCategory("all");
    setNewText("");
    setNewCat("General");
    setGrouped(true);
    load();
  }, [open]);

  useEffect(() => {
    if (!open) return;
    const t = setTimeout(load, 200);
    return () => clearTimeout(t);
  }, [search, category]);

  const addNew = async () => {
    const text = newText.trim();
    if (!text) return;
    const { data: userRes } = await supabase.auth.getUser();
    const uid = userRes.user?.id || null;
    const { data, error } = await supabase
      .from("job_scope_library")
      .insert({ text, category: newCat, created_by: uid })
      .select("id, text, category, usage_count")
      .maybeSingle();
    if (error) {
      toast.error(error.message);
      return;
    }
    setNewText("");
    if (data) {
      setItems((arr) => [data as LibraryItem, ...arr]);
      setPicked((p) => ({ ...p, [data.id]: true }));
    }
  };

  const pickedCount = Object.values(picked).filter(Boolean).length;

  const submit = () => {
    const texts = items
      .filter((it) => picked[it.id] && !selectedLower.has(it.text.toLowerCase()))
      .map((it) => it.text);
    onAdd(texts);
  };

  return (
    <Dialog open={open} onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="max-w-[640px] w-screen h-screen sm:w-auto sm:h-auto sm:max-h-[85vh] p-0 flex flex-col gap-0">
        <div className="px-5 py-4 border-b border-border flex items-center justify-between">
          <h3 className="text-lg font-semibold">Job Scope Library</h3>
          <button
            onClick={onClose}
            className="p-2 rounded hover:bg-secondary"
            aria-label="Close"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        <div className="px-5 py-3 space-y-3 border-b border-border">
          <div className="flex flex-col sm:flex-row gap-2">
            <Input
              className="h-11"
              placeholder="Search..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
            />
            <Select value={category} onValueChange={setCategory}>
              <SelectTrigger className="h-11 sm:w-[200px]">
                <span className="flex items-center gap-2 text-sm">
                  {category !== "all" && (
                    <span
                      className="inline-block h-2 w-2 rounded-full"
                      style={{ background: categoryColor(category) }}
                    />
                  )}
                  {category === "all" ? "All categories" : category}
                </span>
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All categories</SelectItem>
                {SCOPE_CATEGORIES.map((c) => (
                  <SelectItem key={c} value={c}>
                    <span className="flex items-center gap-2">
                      <span
                        className="inline-block h-2 w-2 rounded-full"
                        style={{ background: CATEGORY_COLORS[c] }}
                      />
                      {c}
                    </span>
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="flex flex-col sm:flex-row gap-2">
            <Input
              className="h-11"
              placeholder="Add new item..."
              value={newText}
              onChange={(e) => setNewText(e.target.value)}
            />
            <Select value={newCat} onValueChange={setNewCat}>
              <SelectTrigger className="h-11 sm:w-[160px]">
                <span className="flex items-center gap-2 text-sm">
                  <span
                    className="inline-block h-2 w-2 rounded-full"
                    style={{ background: categoryColor(newCat) }}
                  />
                  {newCat}
                </span>
              </SelectTrigger>
              <SelectContent>
                {SCOPE_CATEGORIES.map((c) => (
                  <SelectItem key={c} value={c}>
                    <span className="flex items-center gap-2">
                      <span
                        className="inline-block h-2 w-2 rounded-full"
                        style={{ background: CATEGORY_COLORS[c] }}
                      />
                      {c}
                    </span>
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Button onClick={addNew} className="h-11">
              Add
            </Button>
          </div>
          <label className="flex items-center gap-2 text-xs text-muted-foreground cursor-pointer select-none">
            <input
              type="checkbox"
              checked={grouped}
              onChange={(e) => setGrouped(e.target.checked)}
              className="h-3.5 w-3.5"
            />
            Group by category
          </label>
        </div>

        <div className="overflow-y-auto flex-1 px-5 py-3">
          {loading ? (
            <div className="flex items-center gap-2 text-sm text-muted-foreground">
              <Loader2 className="h-4 w-4 animate-spin" /> Loading…
            </div>
          ) : items.length === 0 ? (
            <p className="text-sm text-muted-foreground">No items.</p>
          ) : (() => {
            const renderItem = (it: LibraryItem) => {
              const alreadyInOffer = selectedLower.has(it.text.toLowerCase());
              const checked = alreadyInOffer || !!picked[it.id];
              const cat = normalizeCategory(it.category);
              const color = CATEGORY_COLORS[cat];
              return (
                <li
                  key={it.id}
                  className="flex items-center gap-3 p-2 bg-white border border-border rounded"
                  style={{ borderLeft: `4px solid ${color}` }}
                >
                  <Checkbox
                    checked={checked}
                    disabled={alreadyInOffer}
                    onCheckedChange={(v) =>
                      setPicked((p) => ({ ...p, [it.id]: !!v }))
                    }
                  />
                  <div className="flex-1 min-w-0">
                    <div className="text-sm">{it.text}</div>
                    <div className="text-[11px] text-muted-foreground mt-0.5">
                      used {it.usage_count}×
                    </div>
                  </div>
                  <span
                    className="text-[11px] font-medium px-2 py-0.5 rounded-full whitespace-nowrap"
                    style={{
                      color,
                      backgroundColor: `${color}1a`,
                      border: `1px solid ${color}80`,
                    }}
                  >
                    {cat}
                  </span>
                </li>
              );
            };

            if (!grouped) {
              return <ul className="space-y-1">{items.map(renderItem)}</ul>;
            }

            const groups = new Map<string, LibraryItem[]>();
            for (const it of items) {
              const k = normalizeCategory(it.category);
              if (!groups.has(k)) groups.set(k, []);
              groups.get(k)!.push(it);
            }
            const orderedKeys = SCOPE_CATEGORIES.filter((c) => groups.has(c));
            return (
              <div className="space-y-4">
                {orderedKeys.map((c) => (
                  <div key={c}>
                    <div
                      className="flex items-center justify-between px-3 py-1.5 mb-1.5 rounded"
                      style={{ background: "#fdf6e3" }}
                    >
                      <span className="text-xs font-bold uppercase tracking-wider text-[#1a2547] flex items-center gap-2">
                        <span
                          className="inline-block h-2 w-2 rounded-full"
                          style={{ background: CATEGORY_COLORS[c] }}
                        />
                        {c}
                      </span>
                      <span className="text-[11px] text-[#6b7280]">
                        {groups.get(c)!.length} item
                        {groups.get(c)!.length === 1 ? "" : "s"}
                      </span>
                    </div>
                    <ul className="space-y-1">{groups.get(c)!.map(renderItem)}</ul>
                  </div>
                ))}
              </div>
            );
          })()}
        </div>

        <div className="border-t border-border px-5 py-3 flex justify-end gap-2">
          <Button variant="ghost" onClick={onClose} className="h-11">
            Cancel
          </Button>
          <Button onClick={submit} disabled={pickedCount === 0} className="h-11">
            Add Selected ({pickedCount})
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}

function AiSuggestDialog(props: {
  open: boolean;
  onClose: () => void;
  positionTitle: string;
  existingItems: string[];
  mode?: "suggest" | "override";
  onAdd: (texts: string[]) => void | Promise<void>;
}) {
  const { open, onClose, positionTitle, existingItems, onAdd } = props;
  const mode = props.mode ?? "suggest";
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [suggestions, setSuggestions] = useState<string[]>([]);
  const [seen, setSeen] = useState<string[]>([]);
  const [picked, setPicked] = useState<Record<string, boolean>>({});
  const [adding, setAdding] = useState(false);

  const fetchSuggestions = async (more = false) => {
    setLoading(true);
    setError(null);
    try {
      const { data, error: invokeErr } = await supabase.functions.invoke(
        "gemini-scope-suggest",
        {
          body: {
            position_title: positionTitle,
            existing_items: existingItems,
            excluded_items: more ? seen : [],
          },
        },
      );
      if (invokeErr) throw new Error(invokeErr.message);
      if ((data as any)?.error) throw new Error((data as any).error);
      const items: string[] = (data as any)?.suggestions ?? [];
      if (more) {
        setSuggestions((prev) => [...prev, ...items]);
        setSeen((prev) => [...prev, ...items]);
      } else {
        setSuggestions(items);
        setSeen(items);
        setPicked({});
      }
    } catch (e) {
      const msg = e instanceof Error ? e.message : "Failed to get suggestions";
      setError(msg);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (open) {
      setSuggestions([]);
      setSeen([]);
      setPicked({});
      setError(null);
      fetchSuggestions(false);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open]);

  const pickedTexts = suggestions.filter((s) => picked[s]);
  const pickedCount = pickedTexts.length;

  const submit = async () => {
    if (pickedCount === 0) return;
    setAdding(true);
    try {
      await onAdd(pickedTexts);
    } finally {
      setAdding(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="max-w-lg p-0 gap-0 sm:max-h-[85vh] flex flex-col">
        <div className="px-5 py-4 border-b border-border">
          <h3 className="text-lg font-semibold flex items-center gap-2">
            <Sparkles
              className="h-5 w-5"
              style={{ color: mode === "override" ? "#d97706" : "#b08d57" }}
            />
            {mode === "override" ? "AI Override Suggestions" : "AI Scope Suggestions"}
          </h3>
          <p className="text-xs text-muted-foreground mt-1">
            {mode === "override"
              ? "Pick which to add. Your previous items have been cleared."
              : <>Based on position: <strong>{positionTitle || "—"}</strong></>}
          </p>
        </div>

        <div className="flex-1 overflow-y-auto p-5 space-y-2">
          {loading && suggestions.length === 0 ? (
            <div className="flex items-center justify-center py-12 text-sm text-muted-foreground gap-2">
              <Loader2 className="h-4 w-4 animate-spin" />
              Generating suggestions…
            </div>
          ) : error ? (
            <div className="text-sm text-destructive py-4">
              {error}
              <div className="mt-3">
                <Button
                  variant="outline"
                  className="h-10"
                  onClick={() => fetchSuggestions(false)}
                >
                  Try again
                </Button>
              </div>
            </div>
          ) : suggestions.length === 0 ? (
            <p className="text-sm text-muted-foreground italic">
              No new suggestions. Try adjusting the position title.
            </p>
          ) : (
            <ul className="space-y-2">
              {suggestions.map((text) => (
                <li
                  key={text}
                  className="flex items-start gap-3 p-2 border border-border rounded"
                >
                  <Checkbox
                    checked={!!picked[text]}
                    onCheckedChange={(v) =>
                      setPicked((p) => ({ ...p, [text]: !!v }))
                    }
                    className="mt-1"
                  />
                  <span className="text-sm flex-1">{text}</span>
                </li>
              ))}
            </ul>
          )}
        </div>

        <div className="border-t border-border px-5 py-3 flex flex-wrap justify-between gap-2">
          <Button
            variant="outline"
            className="h-11"
            onClick={() => fetchSuggestions(true)}
            disabled={loading || adding || !!error}
          >
            {loading && suggestions.length > 0 && (
              <Loader2 className="h-4 w-4 mr-2 animate-spin" />
            )}
            More suggestions
          </Button>
          <div className="flex gap-2">
            <Button variant="ghost" onClick={onClose} className="h-11">
              Cancel
            </Button>
            <Button
              onClick={submit}
              disabled={pickedCount === 0 || adding}
              className="h-11"
            >
              {adding && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
              Add Selected ({pickedCount})
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
