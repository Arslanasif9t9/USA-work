import { Star, Heart, ThumbsDown, OctagonAlert, type LucideIcon } from "lucide-react";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";

/**
 * Manual HR badge per candidate (shortlisted / favorite / bad / very_bad).
 * Stored on hr_candidate_extras.hr_badge, follows the person by email (same
 * identity model as photo/nickname). Editable only from Scout Report; display
 * everywhere else. Each badge = small rounded pill with icon + text + color.
 */
export type HrBadgeKey = "shortlisted" | "favorite" | "bad" | "very_bad";

export const HR_BADGES: Record<HrBadgeKey, { label: string; Icon: LucideIcon; className: string }> = {
  shortlisted: { label: "Short Listed", Icon: Star, className: "bg-amber-500 text-white border-0" },
  favorite: { label: "Favorite", Icon: Heart, className: "bg-rose-600 text-white border-0" },
  bad: { label: "Bad", Icon: ThumbsDown, className: "bg-orange-500 text-white border-0" },
  very_bad: { label: "Very Bad", Icon: OctagonAlert, className: "bg-red-600 text-white border-0" },
};

export function HrBadgePill({ value }: { value: string | null | undefined }) {
  const cfg = value ? HR_BADGES[value as HrBadgeKey] : undefined;
  if (!cfg) return null;
  const { Icon, label, className } = cfg;
  return (
    <span className={`inline-flex items-center gap-1 rounded-full px-2.5 py-0.5 text-xs font-bold shadow-sm ${className}`}>
      <Icon className="h-3 w-3 shrink-0" />
      {label}
    </span>
  );
}

export function HrBadgeSelect({
  value,
  onChange,
}: {
  value: string | null | undefined;
  onChange: (next: string) => void;
}) {
  return (
    <Select value={value || "none"} onValueChange={(v) => onChange(v === "none" ? "" : v)}>
      <SelectTrigger className="h-7 w-[140px] text-xs">
        <SelectValue placeholder="Set badge" />
      </SelectTrigger>
      <SelectContent>
        <SelectItem value="none">No Remarks</SelectItem>
        <SelectItem value="shortlisted">Short Listed</SelectItem>
        <SelectItem value="favorite">Favorite</SelectItem>
        <SelectItem value="bad">Bad</SelectItem>
        <SelectItem value="very_bad">Very Bad</SelectItem>
      </SelectContent>
    </Select>
  );
}
