import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Check, X, Loader2 } from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import type { CandidateAction } from "@/lib/candidateActions";

type Props = {
  action: CandidateAction | null;
  round: 1 | 2;
  /** Whether the appointment time has already passed (PHT). */
  appointmentPassed: boolean;
  onChanged?: (a: CandidateAction) => void;
};

/**
 * Compact "Mark Attended / No-Show" control for a booked candidate row.
 * - Only renders once the appointment time has passed.
 * - If attendance already marked, shows a badge instead.
 */
export const MarkAttendanceButton = ({ action, round, appointmentPassed, onChanged }: Props) => {
  const [busy, setBusy] = useState<null | "attended" | "no_show">(null);

  if (!action || !appointmentPassed) return null;

  const statusField = round === 1 ? "round1_attendance_status" : "round2_attendance_status";
  const markedAtField = round === 1 ? "round1_attendance_marked_at" : "round2_attendance_marked_at";
  const current = (action as any)[statusField] as "attended" | "no_show" | null | undefined;

  if (current === "attended") {
    return (
      <Badge className="bg-emerald-100 text-emerald-800 hover:bg-emerald-100 border-0">
        <Check className="h-3 w-3 mr-1" /> R{round} Attended
      </Badge>
    );
  }
  if (current === "no_show") {
    return (
      <Badge className="bg-amber-100 text-amber-900 hover:bg-amber-100 border-0">
        <X className="h-3 w-3 mr-1" /> R{round} No-Show
      </Badge>
    );
  }

  const mark = async (value: "attended" | "no_show") => {
    setBusy(value);
    try {
      const patch: Record<string, any> = {
        [statusField]: value,
        [markedAtField]: new Date().toISOString(),
      };
      const { data, error } = await (supabase
        .from("candidate_actions") as any)
        .update(patch)
        .eq("id", action.id)
        .select("*")
        .single();
      if (error) throw error;
      onChanged?.(data as CandidateAction);
      toast.success(value === "attended" ? `Round ${round} marked as attended` : `Round ${round} marked as no-show`);
    } catch (e: any) {
      toast.error(e?.message || "Could not update attendance");
    } finally {
      setBusy(null);
    }
  };

  return (
    <div className="flex gap-1.5">
      <Button
        type="button"
        size="sm"
        variant="outline"
        className="h-7 px-2 text-xs border-emerald-300 text-emerald-700 hover:bg-emerald-50"
        onClick={() => mark("attended")}
        disabled={!!busy}
      >
        {busy === "attended" ? <Loader2 className="h-3 w-3 mr-1 animate-spin" /> : <Check className="h-3 w-3 mr-1" />}
        Attended
      </Button>
      <Button
        type="button"
        size="sm"
        variant="outline"
        className="h-7 px-2 text-xs border-amber-300 text-amber-800 hover:bg-amber-50"
        onClick={() => mark("no_show")}
        disabled={!!busy}
      >
        {busy === "no_show" ? <Loader2 className="h-3 w-3 mr-1 animate-spin" /> : <X className="h-3 w-3 mr-1" />}
        No-Show
      </Button>
    </div>
  );
};
