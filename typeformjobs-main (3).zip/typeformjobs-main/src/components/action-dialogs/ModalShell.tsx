import { ReactNode, useState } from "react";
import * as DialogPrimitive from "@radix-ui/react-dialog";
import { Dialog, DialogOverlay, DialogPortal } from "@/components/ui/dialog";
import { cn } from "@/lib/utils";
import { Pencil, X, Check, Loader2 } from "lucide-react";
import { Input } from "@/components/ui/input";
import { PasswordPromptDialog } from "./PasswordPromptDialog";

/* ============================================================
   ModalShell — premium 960px modal with sticky header + footer
   and a SINGLE close X (no duplicate from Radix DialogContent).
============================================================ */

export const ModalShell = ({
  open,
  onClose,
  title,
  subtitle,
  footer,
  children,
  disableCloseOnOverlay,
}: {
  open: boolean;
  onClose: () => void;
  title: string;
  subtitle?: ReactNode;
  footer: ReactNode;
  children: ReactNode;
  disableCloseOnOverlay?: boolean;
}) => {
  return (
    <Dialog
      open={open}
      onOpenChange={(o) => {
        if (!o && !disableCloseOnOverlay) onClose();
      }}
    >
      <DialogPortal>
        <DialogOverlay />
        <DialogPrimitive.Content
          onEscapeKeyDown={(e) => {
            if (disableCloseOnOverlay) e.preventDefault();
          }}
          onPointerDownOutside={(e) => {
            if (disableCloseOnOverlay) e.preventDefault();
          }}
          className={cn(
            "fixed left-1/2 top-1/2 z-50 -translate-x-1/2 -translate-y-1/2",
            "w-screen h-screen sm:h-auto sm:max-h-[85vh] sm:w-[min(960px,calc(100vw-32px))]",
            "bg-background flex flex-col gap-0 p-0 shadow-xl",
            "sm:rounded-lg border border-[#e1e4ec]",
            "data-[state=open]:animate-in data-[state=closed]:animate-out",
            "data-[state=open]:fade-in-0 data-[state=closed]:fade-out-0",
            "duration-200",
          )}
        >
          {/* Fixed header — flex child, never scrolls */}
          <header className="bg-white border-b border-[#e1e4ec] px-6 py-5 flex items-start justify-between gap-4 shrink-0">
            <div className="min-w-0">
              <DialogPrimitive.Title
                style={{ fontFamily: '"Cormorant Garamond", serif' }}
                className="text-[24px] leading-tight font-semibold text-[#1a2547] truncate"
              >
                {title}
              </DialogPrimitive.Title>
              {subtitle && (
                <DialogPrimitive.Description className="text-sm text-[#6b7280] mt-1 truncate">
                  {subtitle}
                </DialogPrimitive.Description>
              )}
            </div>
            <button
              type="button"
              onClick={onClose}
              aria-label="Close"
              className="shrink-0 h-9 w-9 inline-flex items-center justify-center rounded-md text-[#6b7280] hover:text-[#1a2547] hover:bg-[#f4f5f8] transition-colors"
            >
              <X className="h-5 w-5" />
            </button>
          </header>

          {/* Body — the ONLY scrollable area. min-h-0 lets the flex child
              shrink so scrolling happens here, keeping header/footer pinned. */}
          <div className="flex-1 min-h-0 overflow-y-auto px-6 pt-5 pb-8 bg-[#fbfbfd]">
            {children}
          </div>

          {/* Fixed footer — flex child, pinned at bottom, never scrolls */}
          <footer className="bg-white border-t border-[#e1e4ec] px-6 py-4 flex items-center justify-between gap-3 shrink-0">
            {footer}
          </footer>
        </DialogPrimitive.Content>
      </DialogPortal>
    </Dialog>
  );
};

/* ============================================================
   ModalSection — uppercase gold strip + hairline rule
============================================================ */

export const ModalSection = ({
  title,
  children,
  className,
}: {
  title: string;
  children: ReactNode;
  className?: string;
}) => (
  <section className={cn("py-6 first:pt-2", className)}>
    <div className="mb-3">
      <div className="text-[11px] font-semibold tracking-[2px] uppercase text-[#b08d57]">
        {title}
      </div>
      <div className="h-px bg-[#e1e4ec] mt-2" />
    </div>
    <div className="space-y-4">{children}</div>
  </section>
);

/* ============================================================
   FieldLabel + helpers
============================================================ */

export const FieldLabel = ({ children }: { children: ReactNode }) => (
  <label className="block text-[12px] font-medium text-[#6b7280] mb-1.5">
    {children}
  </label>
);

/* ============================================================
   EditableContactField — read-only by default with pencil edit
   that triggers password prompt then unlocks editing.
============================================================ */

export const EditableContactField = ({
  label,
  value,
  onChange,
  onSave,
  type = "text",
  disabled,
}: {
  label: string;
  value: string;
  onChange: (v: string) => void;
  /** Called when admin commits a non-empty change. Should persist. */
  onSave: (v: string) => Promise<void> | void;
  type?: "text" | "email";
  disabled?: boolean;
}) => {
  const [editable, setEditable] = useState(false);
  const [pwOpen, setPwOpen] = useState(false);
  const [saving, setSaving] = useState(false);
  const [draft, setDraft] = useState(value);

  const commit = async () => {
    const v = draft.trim();
    if (!v) return; // disallow empty
    if (v === value) {
      setEditable(false);
      return;
    }
    setSaving(true);
    try {
      await onSave(v);
      onChange(v);
      setEditable(false);
    } finally {
      setSaving(false);
    }
  };

  return (
    <div>
      <FieldLabel>{label}</FieldLabel>
      <div className="relative">
        <Input
          type={type}
          value={editable ? draft : value}
          onChange={(e) => setDraft(e.target.value)}
          readOnly={!editable}
          disabled={disabled || saving}
          autoFocus={editable}
          onKeyDown={(e) => {
            if (e.key === "Enter" && editable) { e.preventDefault(); commit(); }
            if (e.key === "Escape" && editable) { setEditable(false); setDraft(value); }
          }}
          onBlur={() => { if (editable) commit(); }}
          className={cn(
            "h-10 pr-10 text-sm text-[#1a2236] border-[#e1e4ec] rounded-md",
            "focus-visible:ring-2 focus-visible:ring-[#1a2547]/15 focus-visible:border-[#1a2547]",
            !editable && "bg-[#f4f5f8] cursor-default",
          )}
        />
        <button
          type="button"
          disabled={disabled || saving}
          onClick={() => {
            if (editable) { commit(); return; }
            setDraft(value);
            setPwOpen(true);
          }}
          aria-label={editable ? "Save" : `Edit ${label}`}
          className={cn(
            "absolute inset-y-0 right-2 my-auto h-7 w-7 inline-flex items-center justify-center rounded-md",
            "text-[#b08d57] hover:text-[#1a2547] hover:bg-white transition-colors",
            saving && "opacity-60 cursor-wait",
          )}
        >
          {saving ? (
            <Loader2 className="h-4 w-4 animate-spin" />
          ) : editable ? (
            <Check className="h-4 w-4 text-[#1a2547]" />
          ) : (
            <Pencil className="h-4 w-4" />
          )}
        </button>
      </div>

      <PasswordPromptDialog
        open={pwOpen}
        onOpenChange={setPwOpen}
        title="Authorization required"
        description={`Enter override password to edit ${label.toLowerCase()}.`}
        onConfirmed={() => { setPwOpen(false); setEditable(true); }}
      />
    </div>
  );
};
