import { useEffect, useState } from "react";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Loader2, Mail, CalendarClock, Sparkles, User, Wallet, Clock, AlertTriangle, Briefcase } from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import EditSlotsDialog from "@/components/EditSlotsDialog";
import { HrCopyCheckbox, defaultHrCopyState, type HrCopyState } from "@/components/HrCopyCheckbox";
import SendScheduleControl, { type SendScheduleValue } from "@/components/SendScheduleControl";
import { insertScheduledSend, formatScheduledFor } from "@/lib/scheduledSends";

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

// --- Round 2 (Marissa) pre-fill formatting helpers (best-effort, display only) ---
const formatTime12h = (t?: string | null): string | null => {
  if (!t) return null;
  const m = String(t).match(/^(\d{1,2}):(\d{2})/);
  if (!m) return null;
  let h = parseInt(m[1], 10);
  const min = parseInt(m[2], 10);
  const ampm = h >= 12 ? "PM" : "AM";
  h = h % 12;
  if (h === 0) h = 12;
  return min === 0 ? `${h} ${ampm}` : `${h}:${m[2]} ${ampm}`;
};

const formatOfferSalary = (offer: any): string => {
  const weekly = Number(offer?.post_trial_weekly_salary) || Number(offer?.trial_weekly_salary) || 0;
  if (!weekly) return "";
  const currency = (offer?.currency || "PHP") === "PHP" ? "pesos" : String(offer?.currency);
  const amount = weekly.toLocaleString("en-US");
  return `${amount} ${currency} per week, paid every Saturday`;
};

const formatOfferSchedule = (offer: any): string => {
  const ws = formatTime12h(offer?.weekday_start);
  const we = formatTime12h(offer?.weekday_end);
  const ss = formatTime12h(offer?.saturday_start);
  const se = formatTime12h(offer?.saturday_end);
  const parts: string[] = [];
  if (ws && we) parts.push(`Monday to Friday ${ws} to ${we}`);
  if (ss && se) parts.push(`Saturday ${ss} to ${se}`);
  if (offer?.sunday_off) parts.push("Sunday off");
  return parts.join(", ");
};

type Props = {
  open: boolean;
  onOpenChange: (o: boolean) => void;
  responseId: string;
  round: 1 | 2;
  candidateName: string;
  initialEmail: string;
  isResend: boolean;
  resendCount?: number;
  /** Round 1 only: force the DIRECT Christine /ai-interview link regardless of
   *  the global scheduling mode (passes force_direct=true to send-round-invite). */
  forceDirect?: boolean;
  onSent: (vals: { email: string }) => void;
};

export const InviteRoundDialog = ({
  open, onOpenChange, responseId, round, candidateName,
  initialEmail, isResend, resendCount = 0, forceDirect = false, onSent,
}: Props) => {
  const [email, setEmail] = useState(initialEmail || "");
  const [busy, setBusy] = useState(false);
  const [curatedIds, setCuratedIds] = useState<string[]>([]);
  const [editOpen, setEditOpen] = useState(false);
  const [nameInput, setNameInput] = useState(candidateName || "");
  const [salaryInput, setSalaryInput] = useState("");
  const [scheduleInput, setScheduleInput] = useState("");
  // Read-only display of the position Marissa will state (Round 2). Resolved from
  // the SAME source create-ai-web-call uses: responses.form_id → form_metadata.
  // Never editable, never sent — position is resolved fresh at call time.
  const [positionTitle, setPositionTitle] = useState("");
  const [hrCopy, setHrCopy] = useState<HrCopyState>(defaultHrCopyState);
  const [interviewMode, setInterviewMode] = useState<"ai_direct" | "ai_scheduled">("ai_direct");
  const [schedule, setSchedule] = useState<SendScheduleValue>({ mode: "now" });

  useEffect(() => {
    if (open) {
      setEmail(initialEmail || "");
      setBusy(false);
      setCuratedIds([]);
      setNameInput(candidateName || "");
      setSalaryInput("");
      setScheduleInput("");
      setPositionTitle("");
      setHrCopy(defaultHrCopyState);
      setSchedule({ mode: "now" });
    }
  }, [open, initialEmail, candidateName, responseId]);

  useEffect(() => {
    if (!open || round !== 1) return;
    let cancelled = false;
    (async () => {
      try {
        const { data: cfg } = await supabase
          .from("scheduling_config")
          .select("interview_mode")
          .eq("id", 1)
          .maybeSingle();
        if (!cancelled) {
          setInterviewMode((cfg as any)?.interview_mode === "ai_scheduled" ? "ai_scheduled" : "ai_direct");
        }
      } catch { /* keep default */ }
    })();
    return () => { cancelled = true; };
  }, [open, round]);

  // Round 2 only: best-effort pre-fill salary/schedule from this candidate's
  // signed offer (if one exists). Never blocks sending if lookup fails.
  useEffect(() => {
    if (!open || round !== 2) return;
    let cancelled = false;
    (async () => {
      try {
        const { data: action } = await supabase
          .from("candidate_actions")
          .select("job_offer_id")
          .eq("response_id", responseId)
          .maybeSingle();
        const offerId = (action as any)?.job_offer_id;
        if (!offerId) return;
        const { data: offer } = await supabase
          .from("job_offers")
          .select("trial_weekly_salary, post_trial_weekly_salary, currency, weekday_start, weekday_end, saturday_start, saturday_end, sunday_off")
          .eq("id", offerId)
          .maybeSingle();
        if (cancelled || !offer) return;
        const sal = formatOfferSalary(offer);
        const sch = formatOfferSchedule(offer);
        if (sal) setSalaryInput((prev) => (prev.trim() ? prev : sal));
        if (sch) setScheduleInput((prev) => (prev.trim() ? prev : sch));
      } catch { /* best-effort, never block */ }
    })();
    return () => { cancelled = true; };
  }, [open, round, responseId]);

  // Round 2 only: best-effort read of the position Marissa will state, from the
  // SAME source create-ai-web-call uses (responses.form_id → form_metadata).
  // Display-only — never sent. Failure just leaves the line on its fallback.
  useEffect(() => {
    if (!open || round !== 2) return;
    let cancelled = false;
    (async () => {
      try {
        const { data: resp } = await supabase
          .from("responses")
          .select("form_id")
          .eq("id", responseId)
          .maybeSingle();
        const formId = (resp as any)?.form_id;
        if (!formId) return;
        const { data: meta } = await supabase
          .from("form_metadata")
          .select("position_title")
          .eq("form_id", formId)
          .maybeSingle();
        if (cancelled) return;
        setPositionTitle(((meta as any)?.position_title || "").trim());
      } catch { /* best-effort, never block */ }
    })();
    return () => { cancelled = true; };
  }, [open, round, responseId]);



  const submit = async () => {
    const cleaned = email.trim();
    if (!EMAIL_RE.test(cleaned)) {
      toast.error("Enter a valid candidate email");
      return;
    }
    setBusy(true);
    try {
      const trimmedName = nameInput.trim();
      try {
        // Single source of truth: write override_email (and override_name when
        // provided) onto the response row, single-row by id.
        const patch: Record<string, unknown> = { override_email: cleaned };
        if (trimmedName) patch.override_name = trimmedName;
        await supabase
          .from("responses")
          .update(patch as any)
          .eq("id", responseId);
      } catch (e) {
        console.warn("override persist failed (non-fatal)", e);
      }
      const body: Record<string, unknown> = {
        response_id: responseId,
        round,
        override_email: cleaned,
        hr_copy_requested: hrCopy.requested === true,
        hr_copy_email_override: hrCopy.requested && hrCopy.override ? hrCopy.override : null,
      };
      if (trimmedName) body.candidate_name = trimmedName;
      if (round === 2) {
        const trimmedSalary = salaryInput.trim();
        const trimmedSchedule = scheduleInput.trim();
        if (trimmedSalary) body.marissa_salary = trimmedSalary;
        if (trimmedSchedule) body.marissa_schedule = trimmedSchedule;
      } else if (curatedIds.length > 0) {
        body.curated_slot_ids = curatedIds;
      }
      // Round 1 only: force the DIRECT Christine link when requested by caller.
      if (round === 1 && forceDirect) body.force_direct = true;

      // Scheduled branch: persist a pending row with the EXACT Send-Now payload
      // and do NOT call the send function now.
      if (schedule.mode === "schedule") {
        await insertScheduledSend({
          send_type: round === 1 ? "round1" : "round2",
          target_function: "send-round-invite",
          payload: body,
          response_id: responseId,
          scheduled_for_utc: schedule.scheduled_for_utc,
          timezone: schedule.timezone,
        });
        toast.success(
          `Round ${round} invite scheduled for ${formatScheduledFor(schedule.scheduled_for_utc, schedule.timezone)}`,
        );
        onOpenChange(false);
        return;
      }

      const { data, error } = await supabase.functions.invoke("send-round-invite", { body });

      // Special-case the deliberate 409 safety-stop: when a candidate already has
      // an active booking, send-round-invite returns { error: "active_booking_exists",
      // message } with a non-2xx status. supabase.functions.invoke surfaces that as a
      // FunctionsHttpError whose context (the raw Response) holds the JSON body.
      // Read that body so we can show the friendly `message` as an info/warning toast
      // instead of the generic "Edge Function returned a non-2xx status code" string.
      let blockBody: any = (data && typeof data === "object") ? data : null;
      if (!blockBody?.error && (error as any)?.context && typeof (error as any).context.json === "function") {
        try { blockBody = await (error as any).context.json(); } catch { /* unparseable body */ }
      }
      if (blockBody?.error === "active_booking_exists") {
        toast.warning(
          blockBody.message ||
            "Candidate already has an active booking — cancel or reschedule first.",
        );
        return;
      }

      const errMsg = (data as any)?.error || error?.message;
      if (errMsg) {
        if (errMsg === "missing_email") toast.error("Add an email for this candidate first");
        else toast.error(errMsg);
        return;
      }
      const curatedNote = round === 1 && curatedIds.length > 0 ? ` with ${curatedIds.length} curated slot${curatedIds.length === 1 ? "" : "s"}` : "";
      toast.success(
        isResend
          ? `Round ${round} invite re-sent to ${cleaned}${curatedNote}`
          : `Round ${round} invite sent to ${cleaned}${curatedNote}`,
      );
      onSent({ email: cleaned });
      onOpenChange(false);
    } catch (e: any) {
      toast.error(e?.message || "Could not send invite");
    } finally {
      setBusy(false);
    }
  };

  const description = round === 2
    ? `${candidateName || "The candidate"} will receive a branded email with a 3-day link to their AI interview with Marissa, our Round 2 AI interviewer. No Zoom booking is created.`
    : `${candidateName || "The candidate"} will receive a branded email with a 3-day link to their AI interview (or, in AI-scheduled mode, to pick their own slot first).`;

  return (
    <>
      <Dialog open={open} onOpenChange={(o) => !busy && onOpenChange(o)}>
        <DialogContent className="max-w-md max-h-[85vh] flex flex-col gap-0">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <CalendarClock className="h-4 w-4" />
              {isResend ? `Re-send Round ${round} invite` : `Send Round ${round} invite`}
              {isResend && resendCount > 0 ? ` (${resendCount})` : ""}
            </DialogTitle>
            <DialogDescription>{description}</DialogDescription>
          </DialogHeader>
          <form onSubmit={(e) => { e.preventDefault(); submit(); }} className="flex flex-col min-h-0 flex-1">
            <div className="flex-1 min-h-0 overflow-y-auto space-y-3 pr-1 pt-3">

            {round === 2 && (
              <div className="rounded-md border border-primary/30 bg-primary/5 p-3 space-y-3">
                <div className="space-y-1">
                  <Label className="flex items-center gap-1.5 font-semibold">
                    <Briefcase className="h-3.5 w-3.5" /> Position Marissa will state
                  </Label>
                  <p className="text-sm font-medium">
                    {positionTitle || "the role they applied for"}
                  </p>
                  <p className="text-xs text-muted-foreground">
                    Read-only — resolved automatically when the interview starts.
                    {positionTitle ? "" : " No position set on this form, so Marissa uses this fallback."}
                  </p>
                </div>

                <div className="space-y-1.5">
                  <Label className="flex items-center gap-1.5 font-semibold">
                    <Wallet className="h-3.5 w-3.5" /> Salary Marissa will state
                  </Label>
                  <Input
                    type="text"
                    value={salaryInput}
                    onChange={(e) => setSalaryInput(e.target.value)}
                    placeholder="e.g. 4,500 pesos per week, paid every Saturday"
                  />
                  <p className="text-xs text-muted-foreground">
                    If left blank, Marissa says: 4,000 pesos per week, paid every Saturday
                  </p>
                </div>

                <div className="space-y-1.5">
                  <Label className="flex items-center gap-1.5 font-semibold">
                    <Clock className="h-3.5 w-3.5" /> Schedule Marissa will state
                  </Label>
                  <Input
                    type="text"
                    value={scheduleInput}
                    onChange={(e) => setScheduleInput(e.target.value)}
                    placeholder="e.g. Monday to Friday 10 AM to 6 PM, Saturday 10 AM to 2 PM, Sunday off"
                  />
                  <p className="text-xs text-muted-foreground">
                    If left blank, Marissa says: Mon–Fri 10 AM–6 PM, Sat 10 AM–2 PM, Sun off
                  </p>
                </div>

                {!salaryInput.trim() && !scheduleInput.trim() && (
                  <div className="flex items-start gap-2 rounded-md border border-amber-300 bg-amber-50 p-2 text-xs text-amber-800 dark:border-amber-700/60 dark:bg-amber-950/40 dark:text-amber-200">
                    <AlertTriangle className="h-3.5 w-3.5 mt-0.5 shrink-0" />
                    <span>
                      Marissa will use the default 4,000/week and Mon–Fri 10–6. Fill these in to set this candidate's real pay.
                    </span>
                  </div>
                )}
              </div>
            )}

            <div className="space-y-1.5">
              <Label className="flex items-center gap-1.5">
                <Mail className="h-3.5 w-3.5" /> Send to
              </Label>
              <Input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="name@example.com"
                autoFocus={!initialEmail}
              />
              <p className="text-xs text-muted-foreground">
                Edits here save as the override email for this candidate.
              </p>
            </div>

            <div className="space-y-1.5">
              <Label className="flex items-center gap-1.5">
                <User className="h-3.5 w-3.5" /> Candidate name (optional)
              </Label>
              <Input
                type="text"
                value={nameInput}
                onChange={(e) => setNameInput(e.target.value)}
                placeholder="e.g. Maria Santos"
              />
              <p className="text-xs text-muted-foreground">
                If set, the AI interviewer greets them by name. Leave blank to skip.
              </p>
            </div>



            {round === 1 && interviewMode === "ai_scheduled" && (
              <div className="rounded-md border bg-muted/30 p-3 flex items-start gap-3">
                <Sparkles className="h-4 w-4 mt-0.5 text-primary shrink-0" />
                <div className="flex-1 space-y-1">
                  <div className="text-sm font-medium">
                    {curatedIds.length === 0 ? "Default availability (3-day window)" : `Curated: ${curatedIds.length} slot${curatedIds.length === 1 ? "" : "s"}`}
                  </div>
                  <p className="text-xs text-muted-foreground">
                    {curatedIds.length === 0
                      ? "Candidate sees all available slots automatically (AI-scheduled mode only)."
                      : "Candidate sees only the slots you picked."}
                  </p>
                </div>
                <Button type="button" variant="outline" size="sm" onClick={() => setEditOpen(true)} disabled={busy}>
                  Edit Slots
                </Button>
              </div>
            )}

            <HrCopyCheckbox
              value={hrCopy}
              onChange={setHrCopy}
              disabled={busy}
              label={`If interview is completed, send Round ${round} video link copy to internal backup inbox`}
              idPrefix={`r${round}-hrcopy`}
              compact
            />

            <SendScheduleControl onChange={setSchedule} />
            </div>

            <DialogFooter className="shrink-0 border-t mt-3 pt-3 bg-background">
              <Button type="button" variant="outline" onClick={() => onOpenChange(false)} disabled={busy}>
                Cancel
              </Button>
              <Button type="submit" disabled={busy || !EMAIL_RE.test(email.trim())}>
                {busy ? <Loader2 className="h-4 w-4 animate-spin" /> : (schedule.mode === "schedule" ? "Schedule invite" : (isResend ? "Re-send invite" : "Send invite"))}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      <EditSlotsDialog
        open={editOpen}
        onOpenChange={setEditOpen}
        initialSelected={curatedIds}
        onSave={(ids) => setCuratedIds(ids)}
      />
    </>
  );
};

export default InviteRoundDialog;
