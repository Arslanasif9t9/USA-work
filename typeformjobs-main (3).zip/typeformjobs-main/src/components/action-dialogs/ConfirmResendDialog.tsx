import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog";

export const ConfirmResendDialog = ({
  open,
  onOpenChange,
  stageLabel,
  resendCount,
  onConfirm,
}: {
  open: boolean;
  onOpenChange: (o: boolean) => void;
  stageLabel: string;
  resendCount: number;
  onConfirm: () => void;
}) => {
  const sentTimes = resendCount + 1;
  return (
    <AlertDialog open={open} onOpenChange={onOpenChange}>
      <AlertDialogContent className="max-w-sm">
        <AlertDialogHeader>
          <AlertDialogTitle>Already sent. Re-send?</AlertDialogTitle>
          <AlertDialogDescription>
            This {stageLabel} has been sent {sentTimes} time{sentTimes === 1 ? "" : "s"}.
            Sending again will increment the counter.
          </AlertDialogDescription>
        </AlertDialogHeader>
        <AlertDialogFooter>
          <AlertDialogCancel>Cancel</AlertDialogCancel>
          <AlertDialogAction onClick={onConfirm}>Yes, re-send</AlertDialogAction>
        </AlertDialogFooter>
      </AlertDialogContent>
    </AlertDialog>
  );
};
