import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { CalendarPlus, Send, Check, Lock, MapPin, Loader2 } from "lucide-react";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog";
import { computePipelineStage } from "@/lib/pipelineStage";
import { toast } from "sonner";
import {
  type CandidateAction,
  type Stage,
  ensureCandidateAction,
  markStageSent,
} from "@/lib/candidateActions";
import { ConfirmResendDialog } from "./ConfirmResendDialog";
import { PasswordPromptDialog } from "./PasswordPromptDialog";
import { MissingCandidateDataDialog } from "./MissingCandidateDataDialog";
import { InviteRoundDialog } from "./InviteRoundDialog";
import SendOfferModal from "@/components/SendOfferModal";
import { DisqualifyButton } from "@/components/DisqualifyButton";
import { InvalidateRoundsButton } from "@/components/InvalidateRoundsButton";
import { RescheduleButton } from "@/components/RescheduleButton";
import { ReleaseSlotButton } from "@/components/ReleaseSlotButton";
import { RegenerateZoomButton } from "@/components/RegenerateZoomButton";
import { RecoverInterviewButton } from "@/components/RecoverInterviewButton";
import { InvolveHumanButton } from "@/components/InvolveHumanButton";


type Props = {
  formId: string;
  responseId: string;
  applicantId: string;
  candidateName: string;
  candidateEmail: string;
  nameQid?: string;
  emailQid?: string;
  action: CandidateAction | null;
  signedPdfUrl?: string;
  size?: "sm" | "lg";
  onChanged: (a: CandidateAction) => void;
  onContactUpdated?: (vals: { name?: string; email?: string }) => void;
  /** Cancelled tab rows should expose only Re-Send Round 1 + Disqualify. */
  cancelledOnly?: boolean;
  /**
   * Page context. "results" renders ONLY the Send Round 1 button (no Round 2,
   * Offer, Disqualify, or Invalidate). "bookings" (default) renders the full
   * set and labels the Round 1 button "Re-Send Round 1".
   */
  context?: "results" | "bookings";
  /** Results-only: responses.round_stage (for pill/lock stage detection). */
  roundStage?: string | null;
  /** Results-only: responses.disqualified_at_stage. */
  disqualifiedAtStage?: string | null;
  /** Called after a cancelled candidate is re-sent Round 1 and returns active. */
  onRound1Sent?: () => void;
  /** Optimistically remove this candidate row from the parent list (no refetch). */
  onCandidateRemoved?: () => void;
  /** Restore the row if the background disqualify fails. */
  onCandidateRestored?: () => void;
};

// Same Boss password the standalone Send buttons use. The attendance gate is
// UI-only — the send backend accepts the request regardless.
const BOSS_PASSWORD = "Boss2828";

const buttonClass = (variant: "primary" | "disabled" | "success" | "signed" | "info", size: "sm" | "lg") =>
  `action-btn ${size === "lg" ? "action-btn--lg" : ""} action-btn--${variant}`;


export const ActionsCell = (props: Props) => {
  const {
    formId, responseId, applicantId, candidateName, candidateEmail,
    nameQid, emailQid, action, signedPdfUrl, size = "sm", onChanged, onContactUpdated,
    cancelledOnly = false, onRound1Sent, onCandidateRemoved, onCandidateRestored,
    context = "bookings", roundStage, disqualifiedAtStage,
  } = props;

  const navigate = useNavigate();



  const [pendingStage, setPendingStage] = useState<null | Stage>(null);
  const [pendingIsResend, setPendingIsResend] = useState(false);
  const [confirmStage, setConfirmStage] = useState<null | Stage>(null);
  const [pwOpenStage, setPwOpenStage] = useState<null | Stage>(null);
  const [missingOpen, setMissingOpen] = useState(false);
  const [pendingAfterMissing, setPendingAfterMissing] = useState<null | { stage: Stage; resend: boolean }>(null);
  const [localName, setLocalName] = useState(candidateName);
  const [localEmail, setLocalEmail] = useState(candidateEmail);
  const [scheduledSlotId, setScheduledSlotId] = useState<string | null>(null);

  // Boss-password override for the grayed (attendance-gated) Round 2 / Offer
  // inline buttons. Mirrors SendRound2Button/SendOfferButton. The attendance
  // gate is UI-only, so unlocking client-side + opening the existing dialog
  // sends normally — this is an HR speed-bump, not a security boundary.
  const [overridePwStage, setOverridePwStage] = useState<null | Stage>(null);
  const [overridePwValue, setOverridePwValue] = useState("");
  const [overridePwBusy, setOverridePwBusy] = useState(false);
  const [overrideConfirmStage, setOverrideConfirmStage] = useState<null | Stage>(null);

  const submitOverridePassword = () => {
    if (!overridePwValue) return;
    setOverridePwBusy(true);
    const ok = overridePwValue === BOSS_PASSWORD;
    setOverridePwBusy(false);
    if (!ok) {
      toast.error("Incorrect password");
      setOverridePwValue("");
      return;
    }
    const stage = overridePwStage;
    setOverridePwStage(null);
    setOverridePwValue("");
    setOverrideConfirmStage(stage);
  };

  // Prefer responses.override_email when present (single-row lookup by id).
  // Also fetch scheduled_slot_id to know if candidate has booked.
  useEffect(() => {
    let cancelled = false;
    (async () => {
      const { supabase } = await import("@/integrations/supabase/client");
      const { data } = await supabase
        .from("responses")
        .select("override_email, override_name, scheduled_slot_id")
        .eq("id", responseId)
        .maybeSingle();
      if (cancelled || !data) return;
      const ov = (data as any).override_email;
      if (ov && typeof ov === "string" && ov.trim()) setLocalEmail(ov.trim());
      const on = (data as any).override_name;
      if (on && typeof on === "string" && on.trim()) setLocalName(on.trim());
      setScheduledSlotId((data as any).scheduled_slot_id || null);
    })();
    return () => { cancelled = true; };
  }, [responseId]);

  const ico = size === "lg" ? "h-4 w-4 mr-2" : "h-3.5 w-3.5 mr-1.5";

  const round1Sent = action?.round1_status === "sent";
  const round2Sent = action?.round2_status === "sent";
  const offerStatus = action?.offer_status || "not_sent";

  const openStage = async (stage: Stage, isResend: boolean) => {
    const missingName = !localName;
    // Email is allowed to be missing — the modal has an editable
    // "Send to" field that validates before send and persists to
    // responses.override_email. Only block on missing name.
    if (missingName) {
      setPendingAfterMissing({ stage, resend: isResend });
      setMissingOpen(true);
      return;
    }
    // Ensure row exists
    let act = action;
    if (!act) {
      try {
        act = await ensureCandidateAction(responseId, formId, applicantId);
        onChanged(act);
      } catch (e: any) {
        toast.error("Could not initialize action: " + (e?.message || ""));
        return;
      }
    }
    setPendingStage(stage);
    setPendingIsResend(isResend);
  };

  const handleClick = (stage: Stage) => {
    const sent = stage === "round1" ? round1Sent : stage === "round2" ? round2Sent : offerStatus !== "not_sent";
    // Round 1/2 use the invite flow — no password gate on re-send (HR-only action).
    if (sent && stage === "offer") {
      setConfirmStage(stage);
    } else {
      openStage(stage, sent);
    }
  };

  const stageLabel = (s: Stage) => s === "round1" ? "Round 1" : s === "round2" ? "Round 2" : "offer";
  const stageLabelShort = (s: Stage) => s === "round1" ? "Round 1" : s === "round2" ? "Round 2" : "Offer";

  // Button renderers
  const Round1Btn = () => {
    if (cancelledOnly) {
      return (
        <button type="button" className={buttonClass("success", size)} onClick={() => handleClick("round1")}>
          <CalendarPlus className={ico} /> Re-Send Round 1
        </button>
      );
    }
    if (!round1Sent) {
      // Results: first send → "Send Round 1". Bookings: candidate was typically
      // already invited → "Re-Send Round 1". Same underlying send-round-invite call.
      const label = context === "results" ? "Send Round 1" : "Re-Send Round 1";
      return (
        <button type="button" className={buttonClass("primary", size)} onClick={() => handleClick("round1")}>
          <CalendarPlus className={ico} /> {label}
        </button>
      );
    }
    // Booked → show Reschedule instead of Resend
    if (scheduledSlotId) {
      return (
        <RescheduleButton
          slotId={scheduledSlotId}
          candidateName={localName}
          candidateEmail={localEmail}
          variant="outline"
          size="sm"
          label="Reschedule"
        />
      );
    }
    const n = action!.round1_resend_count || 0;
    return (
      <button type="button" className={buttonClass("success", size)} onClick={() => handleClick("round1")}>
        <CalendarPlus className={ico} /> Re-Send R1 +{n + 1}
      </button>
    );
  };

  const Round2Btn = () => {
    if (!round1Sent) {
      return (
        <button type="button" disabled className={buttonClass("disabled", size)}>
          <CalendarPlus className={ico} /> Send Round 2
        </button>
      );
    }
    if (!round2Sent) {
      const attended = action?.round1_attendance_status === "attended";
      if (!attended) {
        const hint = action?.round1_attendance_status === "no_show"
          ? "Round 1 was a no-show — rebook or disqualify (or override)"
          : "Mark Round 1 attended first (or override)";
        // Grayed but CLICKABLE: HR can override with the Boss password when the
        // candidate completed Round 1 outside the normal flow (e.g. Universal Zoom).
        return (
          <TooltipProvider delayDuration={150}>
            <Tooltip>
              <TooltipTrigger asChild>
                <button
                  type="button"
                  className={`${buttonClass("disabled", size)} cursor-pointer`}
                  onClick={() => { setOverridePwValue(""); setOverridePwStage("round2"); }}
                >
                  <CalendarPlus className={ico} /> Send Round 2
                </button>
              </TooltipTrigger>
              <TooltipContent>{hint}</TooltipContent>
            </Tooltip>
          </TooltipProvider>
        );
      }
      return (
        <button type="button" className={buttonClass("primary", size)} onClick={() => handleClick("round2")}>
          <CalendarPlus className={ico} /> Send Round 2
        </button>
      );
    }
    if (scheduledSlotId) {
      return (
        <RescheduleButton
          slotId={scheduledSlotId}
          candidateName={localName}
          candidateEmail={localEmail}
          variant="outline"
          size="sm"
          label="Reschedule R2"
        />
      );
    }
    const n = action!.round2_resend_count || 0;
    return (
      <button type="button" className={buttonClass("info", size)} onClick={() => handleClick("round2")}>
        <CalendarPlus className={ico} /> Re-Send R2 +{n + 1}
      </button>
    );
  };

  const OfferBtn = () => {
    if (offerStatus === "signed") {
      if (signedPdfUrl) {
        return (
          <TooltipProvider delayDuration={150}>
            <Tooltip>
              <TooltipTrigger asChild>
                <a
                  href={signedPdfUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className={`${buttonClass("signed", size)} cursor-pointer`}
                  onClick={(e) => e.stopPropagation()}
                >
                  <Check className={ico} /> Signed — View Document
                </a>
              </TooltipTrigger>
              <TooltipContent>Click to view signed offer letter</TooltipContent>
            </Tooltip>
          </TooltipProvider>
        );
      }
      return (
        <TooltipProvider delayDuration={150}>
          <Tooltip>
            <TooltipTrigger asChild>
              <button type="button" disabled className={buttonClass("signed", size)}>
                <Check className={ico} /> Signed
              </button>
            </TooltipTrigger>
            <TooltipContent>PDF link not yet available — refresh in a few seconds</TooltipContent>
          </Tooltip>
        </TooltipProvider>
      );
    }
    if (!round2Sent) {
      return (
        <button type="button" disabled className={buttonClass("disabled", size)}>
          <Send className={ico} /> Send Offer
        </button>
      );
    }
    if (offerStatus === "not_sent") {
      const r2Attended = action?.round2_attendance_status === "attended";
      if (!r2Attended) {
        const hint = action?.round2_attendance_status === "no_show"
          ? "Round 2 was a no-show — rebook or disqualify (or override)"
          : "Mark Round 2 attended first (or override)";
        // Grayed but CLICKABLE: HR can override with the Boss password when the
        // candidate completed Round 2 outside the normal flow (e.g. Universal Zoom).
        return (
          <TooltipProvider delayDuration={150}>
            <Tooltip>
              <TooltipTrigger asChild>
                <button
                  type="button"
                  className={`${buttonClass("disabled", size)} cursor-pointer`}
                  onClick={() => { setOverridePwValue(""); setOverridePwStage("offer"); }}
                >
                  <Send className={ico} /> Send Offer
                </button>
              </TooltipTrigger>
              <TooltipContent>{hint}</TooltipContent>
            </Tooltip>
          </TooltipProvider>
        );
      }
    }
    if (offerStatus === "not_sent") {
      return (
        <button type="button" className={buttonClass("primary", size)} onClick={() => handleClick("offer")}>
          <Send className={ico} /> Send Offer
        </button>
      );
    }
    const n = action!.offer_resend_count;
    return (
      <button type="button" className={buttonClass("success", size)} onClick={() => handleClick("offer")}>
        <Send className={ico} /> Re-send Offer{n > 0 ? ` (${n})` : ""}
      </button>
    );
  };

  const wrapperClass = size === "lg" ? "grid gap-2" : "flex flex-row flex-wrap items-center gap-2 [&_.action-btn]:w-auto";

  const resultsOnly = context === "results";

  // Results page: compute the candidate's current pipeline stage. When in the
  // pipeline we lock the Send Round 1 button and surface a "Locate Me" jump.
  const resultsStage = resultsOnly
    ? computePipelineStage({
        roundStage,
        disqualifiedAtStage,
        round1Status: action?.round1_status,
        round2Status: action?.round2_status,
        offerStatus: action?.offer_status,
      })
    : null;
  const resultsLocked = resultsOnly && resultsStage !== null;

  const ResultsLockedButtons = () => (
    <>
      <TooltipProvider delayDuration={150}>
        <Tooltip>
          <TooltipTrigger asChild>
            <button
              type="button"
              disabled
              className={buttonClass("disabled", size)}
              style={{ opacity: 0.5, cursor: "not-allowed" }}
            >
              <Lock className={ico} /> {resultsStage!.lockLabel}
            </button>
          </TooltipTrigger>
          <TooltipContent>
            Already in the pipeline. Use Locate Me to jump to this candidate.
          </TooltipContent>
        </Tooltip>
      </TooltipProvider>
      <button
        type="button"
        onClick={() => {
          // Stage-aware destination: disqualified/terminated candidates do not
          // live on My Bookings, so route to the page that actually loads them.
          const key = resultsStage?.key;
          const dest =
            key === "disqualified" ? "disqualified"
            : key === "terminated" ? "quarantine"
            : "my-bookings";
          navigate(`/dashboard/${dest}?locate=${responseId}`);
        }}
        className={`inline-flex items-center justify-center rounded-md border border-navy/30 bg-transparent text-navy font-medium hover:bg-navy/5 transition-colors ${
          size === "lg" ? "px-3 py-2 text-sm" : "px-2 py-1.5 text-xs"
        }`}
      >
        <MapPin className={ico} /> Locate Me
      </button>
    </>
  );

  return (
    <div className={wrapperClass}>
      {resultsLocked ? <ResultsLockedButtons /> : <Round1Btn />}
      {!resultsOnly && !cancelledOnly && <Round2Btn />}
      {!resultsOnly && !cancelledOnly && <OfferBtn />}
      {/* Recover — Not Completed and Involve Human buttons removed from the
          My Bookings rows (UI only). Their handlers/components remain intact
          (RecoverInterviewButton / InvolveHumanButton) and can be re-rendered. */}

      {!resultsOnly && !cancelledOnly && scheduledSlotId && (
        <>
          <RegenerateZoomButton
            slotId={scheduledSlotId}
            candidateName={localName}
            size={size}
          />
          <ReleaseSlotButton
            slotId={scheduledSlotId}
            candidateName={localName}
            size={size}
            onReleased={() => {
              setScheduledSlotId(null);
              onContactUpdated?.({});
            }}
          />
        </>
      )}
      {!resultsOnly && (
        <DisqualifyButton
          responseId={responseId}
          candidateName={localName}
          size={size}
          onOptimisticRemove={onCandidateRemoved}
          onRevert={onCandidateRestored}
        />
      )}
      {!resultsOnly && (
        <InvalidateRoundsButton
          responseId={responseId}
          candidateName={localName}
          size={size}
        />
      )}


      {/* Boss-password override for the grayed Round 2 / Offer inline buttons */}
      <Dialog
        open={!!overridePwStage}
        onOpenChange={(o) => { if (!overridePwBusy && !o) { setOverridePwStage(null); setOverridePwValue(""); } }}
      >
        <DialogContent className="max-w-sm">
          <DialogHeader>
            <DialogTitle>Override required</DialogTitle>
            <DialogDescription>
              {overridePwStage === "offer"
                ? "Round 2 isn't marked attended. Enter the Boss password to send the offer anyway."
                : "Round 1 isn't marked attended. Enter the Boss password to send Round 2 anyway."}
            </DialogDescription>
          </DialogHeader>
          <form onSubmit={(e) => { e.preventDefault(); submitOverridePassword(); }} className="space-y-3">
            <Input
              type="password"
              value={overridePwValue}
              onChange={(e) => setOverridePwValue(e.target.value)}
              autoFocus
              placeholder="Boss password"
            />
            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => { setOverridePwStage(null); setOverridePwValue(""); }}>Cancel</Button>
              <Button type="submit" disabled={overridePwBusy || !overridePwValue}>
                {overridePwBusy ? <Loader2 className="h-4 w-4 animate-spin" /> : "Unlock"}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      {/* Confirm AlertDialog after a correct Boss password */}
      <AlertDialog open={!!overrideConfirmStage} onOpenChange={(o) => { if (!o) setOverrideConfirmStage(null); }}>
        <AlertDialogContent className="max-w-sm">
          <AlertDialogHeader>
            <AlertDialogTitle>
              {overrideConfirmStage === "offer" ? "Override offer send?" : "Override Round 2 send?"}
            </AlertDialogTitle>
            <AlertDialogDescription>
              {overrideConfirmStage === "offer"
                ? "Are you sure this candidate completed Round 2? You're about to send the offer."
                : "Are you sure this candidate completed Round 1? You're about to send the Round 2 invite."}
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={() => {
              const s = overrideConfirmStage!;
              setOverrideConfirmStage(null);
              // Same action the enabled inline button triggers when attended.
              openStage(s, false);
            }}>
              {overrideConfirmStage === "offer" ? "Yes, send offer" : "Yes, send Round 2"}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>


      {/* Confirm + Password gate for re-sends */}
      <ConfirmResendDialog
        open={!!confirmStage}
        onOpenChange={(o) => !o && setConfirmStage(null)}
        stageLabel={confirmStage ? stageLabel(confirmStage) : ""}
        resendCount={
          confirmStage === "round1" ? (action?.round1_resend_count ?? 0)
          : confirmStage === "round2" ? (action?.round2_resend_count ?? 0)
          : (action?.offer_resend_count ?? 0)
        }
        onConfirm={() => {
          const s = confirmStage!;
          setConfirmStage(null);
          setPwOpenStage(s);
        }}
      />

      <PasswordPromptDialog
        open={!!pwOpenStage}
        onOpenChange={(o) => !o && setPwOpenStage(null)}
        title="Authorization required"
        description="Enter override password to re-send."
        onConfirmed={() => {
          const s = pwOpenStage!;
          setPwOpenStage(null);
          openStage(s, true);
        }}
      />

      {/* Missing data gate */}
      <MissingCandidateDataDialog
        open={missingOpen}
        onOpenChange={(o) => { setMissingOpen(o); if (!o) setPendingAfterMissing(null); }}
        missing={{ name: !localName, email: !localEmail }}
        onResolved={async (vals) => {
          const { updateResponseAnswer } = await import("@/lib/candidateActions");
          const { supabase } = await import("@/integrations/supabase/client");
          // Persist new name/email to the underlying response answer AND to the
          // authoritative override_* fields (single row by id) so both edit
          // paths land in the same field that sends read first.
          const overridePatch: Record<string, unknown> = {};
          if (vals.name && nameQid) {
            await updateResponseAnswer(responseId, nameQid, vals.name);
            overridePatch.override_name = vals.name;
            setLocalName(vals.name);
          }
          if (vals.email && emailQid) {
            await updateResponseAnswer(responseId, emailQid, vals.email);
            overridePatch.override_email = vals.email;
            setLocalEmail(vals.email);
          }
          if (Object.keys(overridePatch).length > 0) {
            try {
              await supabase.from("responses").update(overridePatch as any).eq("id", responseId);
            } catch (e) {
              console.warn("override persist failed (non-fatal)", e);
            }
          }
          onContactUpdated?.(vals);
          // Re-trigger original action
          const after = pendingAfterMissing;
          setPendingAfterMissing(null);
          if (after) {
            // small delay to let state update propagate
            setTimeout(() => openStage(after.stage, after.resend), 0);
          }
        }}
      />

      {/* Round 1/2 invite dialog */}
      {pendingStage && pendingStage !== "offer" && action && (
        <InviteRoundDialog
          open={true}
          onOpenChange={(o) => { if (!o) setPendingStage(null); }}
          responseId={responseId}
          round={pendingStage === "round1" ? 1 : 2}
          candidateName={localName}
          initialEmail={localEmail}
          isResend={pendingIsResend}
          resendCount={pendingStage === "round1" ? (action.round1_resend_count || 0) : (action.round2_resend_count || 0)}
          onSent={async ({ email }) => {
            if (email) setLocalEmail(email);
            onContactUpdated?.({ email });
            // Refetch the action row to pick up status / counts.
            const { supabase } = await import("@/integrations/supabase/client");
            const { data } = await supabase.from("candidate_actions").select("*").eq("id", action.id).maybeSingle();
            if (data) onChanged(data as any);
            if (pendingStage === "round1" || cancelledOnly) onRound1Sent?.();
          }}
        />
      )}

      {/* Offer modal */}
      {pendingStage === "offer" && action && (
        <SendOfferModal
          open={true}
          onClose={() => setPendingStage(null)}
          formId={formId}
          candidateName={localName}
          candidateEmail={localEmail}
          responseId={responseId}
          nameQid={nameQid}
          emailQid={emailQid}
          isResend={pendingIsResend}
          existingOfferId={pendingIsResend ? action.job_offer_id : null}
          onContactUpdated={(vals) => {
            if (vals.name) setLocalName(vals.name);
            if (vals.email) setLocalEmail(vals.email);
            onContactUpdated?.(vals);
          }}
          onSaved={async (_offerRef, savedOfferId) => {
            const { supabase } = await import("@/integrations/supabase/client");
            let jobOfferId = savedOfferId || null;
            if (!jobOfferId) {
              const { data: latest } = await supabase
                .from("job_offers")
                .select("id")
                .eq("form_id", formId)
                .eq("candidate_email", localEmail)
                .order("created_at", { ascending: false })
                .limit(1)
                .maybeSingle();
              jobOfferId = (latest as any)?.id || null;
            }
            try {
              if (pendingIsResend && action.job_offer_id) {
                const { markStageResent } = await import("@/lib/candidateActions");
                await markStageResent(action.id, "offer", action.offer_resend_count);
              } else {
                await markStageSent(action.id, "offer", { jobOfferId: jobOfferId || undefined });
              }
              const { data } = await supabase.from("candidate_actions").select("*").eq("id", action.id).maybeSingle();
              if (data) onChanged(data as any);
            } catch (e: any) {
              toast.error(e?.message || "Could not update status");
            }
          }}
        />
      )}
    </div>
  );
};
