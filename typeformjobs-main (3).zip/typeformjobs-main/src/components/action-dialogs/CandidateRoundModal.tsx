import { useEffect, useMemo, useState } from "react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Loader2, Info, CheckCircle2, ExternalLink, AlertTriangle } from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import {
  type CandidateAction,
  type Stage,
  markStageSent,
  markStageResent,
  updateResponseAnswer,
} from "@/lib/candidateActions";
import { buildRoundEmails } from "@/lib/roundEmailTemplates";
import { ModalShell, ModalSection, FieldLabel, EditableContactField } from "./ModalShell";
import { useHrIdentity } from "@/hooks/useHrIdentity";

type Props = {
  open: boolean;
  onClose: () => void;
  stage: Extract<Stage, "round1" | "round2">;
  action: CandidateAction;
  initialName: string;
  initialEmail: string;
  nameQid?: string;
  emailQid?: string;
  responseId: string;
  isResend: boolean;
  initialAppointment?: string | null;
  onSaved: (updated: { name: string; email: string }) => void;
};

const MANILA_TZ = "Asia/Manila";
const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

const pad = (n: number) => String(n).padStart(2, "0");

const tomorrowDateStr = () => {
  // Tomorrow's date in Manila wall-clock
  const now = new Date();
  const parts = new Intl.DateTimeFormat("en-CA", {
    timeZone: MANILA_TZ,
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
  }).formatToParts(new Date(now.getTime() + 24 * 60 * 60 * 1000));
  const y = parts.find((p) => p.type === "year")!.value;
  const m = parts.find((p) => p.type === "month")!.value;
  const d = parts.find((p) => p.type === "day")!.value;
  return `${y}-${m}-${d}`;
};

const todayDateStr = () => {
  const parts = new Intl.DateTimeFormat("en-CA", {
    timeZone: MANILA_TZ,
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
  }).formatToParts(new Date());
  return `${parts.find((p) => p.type === "year")!.value}-${parts.find((p) => p.type === "month")!.value}-${parts.find((p) => p.type === "day")!.value}`;
};

const parseInitial = (iso?: string | null) => {
  if (!iso) return null;
  const d = new Date(iso);
  if (isNaN(d.getTime())) return null;
  const parts = new Intl.DateTimeFormat("en-CA", {
    timeZone: MANILA_TZ,
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
    hour12: false,
  }).formatToParts(d);
  const get = (t: string) => parts.find((p) => p.type === t)!.value;
  return { date: `${get("year")}-${get("month")}-${get("day")}`, time: `${get("hour")}:${get("minute")}` };
};

const formatFullDate = (date: string) => {
  // "Tuesday, May 20, 2026" in Manila
  const [y, m, d] = date.split("-").map(Number);
  // Build at noon Manila → safe across DST (none in PHT)
  const dt = new Date(Date.UTC(y, m - 1, d, 12, 0, 0));
  return new Intl.DateTimeFormat("en-US", {
    timeZone: MANILA_TZ,
    weekday: "long",
    month: "long",
    day: "numeric",
    year: "numeric",
  }).format(dt);
};

const formatTime12 = (time: string) => {
  const [h, m] = time.split(":").map(Number);
  const period = h >= 12 ? "PM" : "AM";
  const h12 = h === 0 ? 12 : h > 12 ? h - 12 : h;
  return `${h12}:${pad(m)} ${period}`;
};

/** Combine Manila wall-clock date+time into a true UTC ISO. PHT is UTC+8 (no DST). */
const manilaToUtcIso = (date: string, time: string) => {
  return new Date(`${date}T${time}:00+08:00`).toISOString();
};

/** Local naive ISO for Zoom (no offset). */
const manilaLocalIso = (date: string, time: string) => `${date}T${time}:00`;

type ProgressStep = "idle" | "zoom" | "ics" | "email" | "db" | "done";

export const CandidateRoundModal = ({
  open, onClose, stage, action, initialName, initialEmail,
  nameQid, emailQid, responseId, isResend, initialAppointment, onSaved,
}: Props) => {
  const round: 1 | 2 = stage === "round1" ? 1 : 2;
  const stageLabel = `Round ${round}`;
  const emailStage = stage === "round1" ? "stage_2_round_1" : "stage_2_round_2";
  const defaultDuration = round === 1 ? 15 : 30;
  const { hrId } = useHrIdentity();

  const initial = useMemo(() => parseInitial(initialAppointment), [initialAppointment]);

  const [name, setName] = useState(initialName);
  const [email, setEmail] = useState(initialEmail);
  const [date, setDate] = useState(initial?.date || tomorrowDateStr());
  const [time, setTime] = useState(initial?.time || "10:00");
  const [duration, setDuration] = useState(defaultDuration);
  const [positionTitle, setPositionTitle] = useState("the role");

  const [progress, setProgress] = useState<ProgressStep>("idle");
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [partialState, setPartialState] = useState<null | {
    join_url: string;
    password: string | null;
    meeting_id: string;
    db_record_id: string;
  }>(null);
  const [successInfo, setSuccessInfo] = useState<null | {
    join_url: string;
    password: string | null;
    meeting_id: string;
  }>(null);

  useEffect(() => {
    if (open) {
      setName(initialName);
      setEmail(initialEmail);
      const init = parseInitial(initialAppointment);
      setDate(init?.date || tomorrowDateStr());
      setTime(init?.time || "10:00");
      setDuration(defaultDuration);
      setProgress("idle");
      setErrorMsg(null);
      setPartialState(null);
      setSuccessInfo(null);
      // Load override_email for this response and prefer it
      (async () => {
        const { data } = await supabase
          .from("responses")
          .select("override_email")
          .eq("id", responseId)
          .maybeSingle();
        const ov = (data as any)?.override_email;
        if (ov && typeof ov === "string" && ov.trim()) setEmail(ov.trim());
      })();
    }
  }, [open, initialName, initialEmail, initialAppointment, defaultDuration, responseId]);

  // Fetch position_title for the form
  useEffect(() => {
    if (!open) return;
    let cancelled = false;
    (async () => {
      const { data } = await supabase
        .from("form_metadata")
        .select("position_title")
        .eq("form_id", action.form_id)
        .maybeSingle();
      if (!cancelled && data?.position_title) setPositionTitle(data.position_title);
    })();
    return () => { cancelled = true; };
  }, [open, action.form_id]);

  const busy = progress !== "idle" && progress !== "done";

  const validate = (): string | null => {
    if (!name.trim()) return "Candidate name required";
    if (!EMAIL_RE.test(email.trim())) return "Valid candidate email required";
    if (!date) return "Pick a date";
    if (!time) return "Pick a time";
    const today = todayDateStr();
    if (date < today) return "Date cannot be in the past";
    if (date === today) {
      // also check time is in future (Manila wall clock)
      const nowManila = new Intl.DateTimeFormat("en-GB", {
        timeZone: MANILA_TZ, hour: "2-digit", minute: "2-digit", hour12: false,
      }).format(new Date());
      if (time <= nowManila) return "Time must be in the future";
    }
    if (![15, 30, 45, 60].includes(duration)) return "Invalid duration";
    return null;
  };

  const doSend = async () => {
    const v = validate();
    if (v) { toast.error(v); return; }
    setErrorMsg(null);
    setPartialState(null);

    let zoomMeetingDbId = "";
    let zoomMeetingId = "";
    let zoomJoinUrl = "";
    let zoomPassword: string | null = null;

    // Persist the resolved/edited email as the override for this response.
    // Single-row, by exact id, never touches answers or other rows.
    try {
      await supabase
        .from("responses")
        .update({ override_email: email.trim() })
        .eq("id", responseId);
    } catch (e) {
      console.warn("override_email persist failed (non-fatal)", e);
    }

    // OPTION B: If re-sending and there's a prior zoom meeting, cancel it first.
    const priorZoomId = round === 1
      ? action.round1_zoom_meeting_id
      : action.round2_zoom_meeting_id;
    if (isResend && priorZoomId) {
      try {
        await supabase.functions.invoke("delete-zoom-meeting", {
          body: { db_record_id: priorZoomId },
        });
      } catch {/* best-effort */}
    }

    // STEP 3: Create Zoom meeting
    setProgress("zoom");
    try {
      const { data, error } = await supabase.functions.invoke("create-zoom-meeting", {
        body: {
          topic: `Round ${round} Interview - ${name.trim()}`,
          start_time: manilaLocalIso(date, time),
          duration_minutes: duration,
          candidate_actions_id: action.id,
          candidate_id: action.candidate_id,
          round,
        },
      });
      if (error || !data?.success) {
        setProgress("idle");
        setErrorMsg(`Couldn't create Zoom meeting: ${error?.message || data?.error || "unknown"}`);
        toast.error("Couldn't create Zoom meeting. Try again.");
        return;
      }
      zoomMeetingDbId = data.db_record_id;
      zoomMeetingId = data.meeting_id;
      zoomJoinUrl = data.join_url;
      zoomPassword = data.password ?? null;
    } catch (e: any) {
      setProgress("idle");
      setErrorMsg(`Zoom error: ${e?.message || String(e)}`);
      toast.error("Couldn't create Zoom meeting. Try again.");
      return;
    }

    // STEP 4: Generate .ics (non-fatal)
    setProgress("ics");
    let icsContent: string | null = null;
    let icsFilename = `EIA-Interview-${date}.ics`;
    try {
      const { data, error } = await supabase.functions.invoke("generate-ics-from-zoom", {
        body: {
          zoom_meeting_db_id: zoomMeetingDbId,
          candidate_name: name.trim(),
          candidate_email: email.trim(),
        },
      });
      if (!error && data?.ok && data?.ics_content) {
        icsContent = data.ics_content;
        if (data.filename) icsFilename = data.filename;
      } else {
        console.warn("ics generation failed", error, data);
        toast.warning("Calendar invite couldn't be generated — email will send without it.");
      }
    } catch (e) {
      console.warn("ics exception", e);
    }

    // STEP 5: Send dual emails
    setProgress("email");
    const templates = buildRoundEmails({
      round,
      candidate_name: name.trim(),
      position_title: positionTitle,
      formatted_date: formatFullDate(date),
      formatted_time: formatTime12(time),
      duration_minutes: duration,
      zoom_join_url: zoomJoinUrl,
      zoom_password: zoomPassword,
    });

    const attachments = icsContent
      ? [{
          filename: icsFilename,
          content: btoa(unescape(encodeURIComponent(icsContent))),
          content_type: "text/calendar; method=REQUEST; charset=utf-8",
        }]
      : undefined;

    let emailOk = false;
    try {
      const { data, error } = await supabase.functions.invoke("send-dual-email", {
        body: {
          to: email.trim(),
          candidate_id: action.candidate_id,
          stage: emailStage,
          sender_a: templates.sender_a,
          sender_b: templates.sender_b,
          attachments,
        },
      });
      // 207/multi-status comes through as a non-error here typically; accept if at least one succeeded
      const resendOk = !!(data as any)?.resend?.success;
      const gmailOk = !!(data as any)?.gmail?.success;
      emailOk = resendOk || gmailOk;
      if (!emailOk) {
        setProgress("idle");
        setPartialState({
          join_url: zoomJoinUrl,
          password: zoomPassword,
          meeting_id: zoomMeetingId,
          db_record_id: zoomMeetingDbId,
        });
        setErrorMsg(
          `Zoom meeting created but email failed to send. Meeting details below — share manually with candidate.${
            error ? ` (${error.message})` : ""
          }`,
        );
        toast.error("Email send failed — see details below.");
        return;
      }
      if (!resendOk || !gmailOk) {
        toast.warning(
          `Only one of two emails sent (Resend ${resendOk ? "✓" : "✗"}, Gmail ${gmailOk ? "✓" : "✗"}).`,
        );
      }
    } catch (e: any) {
      setProgress("idle");
      setPartialState({
        join_url: zoomJoinUrl,
        password: zoomPassword,
        meeting_id: zoomMeetingId,
        db_record_id: zoomMeetingDbId,
      });
      setErrorMsg(`Email send exception: ${e?.message || String(e)}`);
      toast.error("Email send failed — see details below.");
      return;
    }

    // STEP 6: Update candidate_actions
    setProgress("db");
    try {
      const apptIsoUtc = manilaToUtcIso(date, time);
      const patch: Record<string, any> = {
        [`${stage}_appointment_date`]: apptIsoUtc,
        [`${stage}_zoom_meeting_id`]: zoomMeetingDbId,
        [`${stage}_zoom_join_url`]: zoomJoinUrl,
      };
      const now = new Date().toISOString();
      if (isResend) {
        patch[`${stage}_last_sent_at`] = now;
        patch[`${stage}_resend_count`] =
          (round === 1 ? action.round1_resend_count : action.round2_resend_count) + 1;
      } else {
        patch[`${stage}_status`] = "sent";
        patch[`${stage}_sent_at`] = now;
        patch[`${stage}_last_sent_at`] = now;
      }
      const { error } = await supabase.from("candidate_actions").update(patch as any).eq("id", action.id);
      if (error) throw error;

      // Tracking: write round stage + HR identity to responses (single-row, by exact id).
      // Nullable columns only; never touches answers table.
      try {
        const respPatch: Record<string, any> = {
          round_stage: round === 1 ? "round_1_sent" : "round_2_sent",
          [`round_${round}_sent_at`]: now,
        };
        if (hrId) respPatch.handled_by_hr_id = hrId;
        await supabase.from("responses").update(respPatch as any).eq("id", responseId);
      } catch (e) {
        console.warn("round_stage tracking update failed (non-fatal)", e);
      }

      // Auto-claim linked interview slot for current HR on Round 1 send
      if (round === 1 && hrId) {
        try {
          const { data: resp } = await supabase
            .from("responses")
            .select("scheduled_slot_id")
            .eq("id", responseId)
            .maybeSingle();
          const slotId = (resp as any)?.scheduled_slot_id;
          if (slotId) {
            await supabase
              .from("interview_slots")
              .update({ claimed_by_hr_id: hrId, claimed_at: new Date().toISOString() })
              .eq("id", slotId)
              .is("claimed_by_hr_id", null);
          }
        } catch (e) {
          console.warn("auto-claim failed", e);
        }
      }
    } catch (e: any) {
      // Critical inconsistency — email sent but DB failed
      setProgress("idle");
      setErrorMsg(`Email sent but couldn't update status: ${e?.message || String(e)}. Refresh and verify.`);
      toast.error("Email sent but status update failed. Refresh to verify.");
      // fall through; user must refresh
      onSaved({ name: name.trim(), email: email.trim() });
      return;
    }

    setProgress("done");
    setSuccessInfo({ join_url: zoomJoinUrl, password: zoomPassword, meeting_id: zoomMeetingId });
    toast.success(`${stageLabel} sent to ${name.trim()}`);
    onSaved({ name: name.trim(), email: email.trim() });
  };

  // Retry email only (when partial failure)
  const retryEmail = async () => {
    if (!partialState) return;
    setErrorMsg(null);
    setProgress("ics");
    let icsContent: string | null = null;
    let icsFilename = `EIA-Interview-${date}.ics`;
    try {
      const { data } = await supabase.functions.invoke("generate-ics-from-zoom", {
        body: {
          zoom_meeting_db_id: partialState.db_record_id,
          candidate_name: name.trim(),
          candidate_email: email.trim(),
        },
      });
      if (data?.ok && data?.ics_content) {
        icsContent = data.ics_content;
        if (data.filename) icsFilename = data.filename;
      }
    } catch {/* ignore */}

    setProgress("email");
    const templates = buildRoundEmails({
      round,
      candidate_name: name.trim(),
      position_title: positionTitle,
      formatted_date: formatFullDate(date),
      formatted_time: formatTime12(time),
      duration_minutes: duration,
      zoom_join_url: partialState.join_url,
      zoom_password: partialState.password,
    });
    const attachments = icsContent
      ? [{
          filename: icsFilename,
          content: btoa(unescape(encodeURIComponent(icsContent))),
          content_type: "text/calendar; method=REQUEST; charset=utf-8",
        }]
      : undefined;
    try {
      const { data, error } = await supabase.functions.invoke("send-dual-email", {
        body: {
          to: email.trim(),
          candidate_id: action.candidate_id,
          stage: emailStage,
          sender_a: templates.sender_a,
          sender_b: templates.sender_b,
          attachments,
        },
      });
      const ok = !!(data as any)?.resend?.success || !!(data as any)?.gmail?.success;
      if (!ok) {
        setProgress("idle");
        setErrorMsg(`Email retry failed${error ? `: ${error.message}` : ""}.`);
        toast.error("Retry failed.");
        return;
      }
    } catch (e: any) {
      setProgress("idle");
      setErrorMsg(`Retry exception: ${e?.message || String(e)}`);
      return;
    }

    // DB update
    setProgress("db");
    try {
      const apptIsoUtc = manilaToUtcIso(date, time);
      const patch: Record<string, any> = {
        [`${stage}_appointment_date`]: apptIsoUtc,
        [`${stage}_zoom_meeting_id`]: partialState.db_record_id,
        [`${stage}_zoom_join_url`]: partialState.join_url,
      };
      const now = new Date().toISOString();
      if (isResend) {
        patch[`${stage}_last_sent_at`] = now;
        patch[`${stage}_resend_count`] =
          (round === 1 ? action.round1_resend_count : action.round2_resend_count) + 1;
      } else {
        patch[`${stage}_status`] = "sent";
        patch[`${stage}_sent_at`] = now;
        patch[`${stage}_last_sent_at`] = now;
      }
      await supabase.from("candidate_actions").update(patch as any).eq("id", action.id);
    } catch (e: any) {
      setErrorMsg(`Email sent but couldn't update status: ${e?.message || String(e)}.`);
    }
    setProgress("done");
    setSuccessInfo({
      join_url: partialState.join_url,
      password: partialState.password,
      meeting_id: partialState.meeting_id,
    });
    setPartialState(null);
    toast.success(`${stageLabel} sent to ${name.trim()}`);
    onSaved({ name: name.trim(), email: email.trim() });
  };

  const progressLabel = () => {
    switch (progress) {
      case "zoom": return "Creating Zoom meeting...";
      case "ics": return "Generating calendar invite...";
      case "email": return "Sending email...";
      case "db": return "Updating status...";
      case "done": return "Sent successfully";
      default: return "";
    }
  };

  return (
    <ModalShell
      open={open}
      onClose={busy ? () => {} : onClose}
      title={`Send ${stageLabel} Interview`}
      subtitle={
        progress === "done"
          ? `Sent to ${name}`
          : `Schedule interview with ${name || "candidate"}`
      }
      disableCloseOnOverlay={busy}
      footer={
        progress === "done" ? (
          <Button onClick={onClose} className="bg-[#1a2547] text-white hover:bg-[#1a2547]/90">
            Done
          </Button>
        ) : partialState ? (
          <>
            <Button variant="ghost" onClick={onClose} className="text-[#6b7280] hover:text-[#1a2236]">
              Close
            </Button>
            <button
              type="button"
              onClick={retryEmail}
              disabled={busy}
              className="action-btn action-btn--lg action-btn--primary"
              style={{ width: "auto", paddingLeft: 24, paddingRight: 24 }}
            >
              {busy ? <Loader2 className="h-4 w-4 animate-spin" /> : "Retry email"}
            </button>
          </>
        ) : (
          <>
            <Button variant="ghost" onClick={onClose} disabled={busy} className="text-[#6b7280] hover:text-[#1a2236]">
              Cancel
            </Button>
            <button
              type="button"
              disabled={busy}
              onClick={doSend}
              className="action-btn action-btn--lg action-btn--primary"
              style={{ width: "auto", paddingLeft: 24, paddingRight: 24 }}
            >
              {busy ? (
                <span className="inline-flex items-center gap-2">
                  <Loader2 className="h-4 w-4 animate-spin" /> {progressLabel()}
                </span>
              ) : (
                `Send ${stageLabel}`
              )}
            </button>
          </>
        )
      }
    >
      {progress === "done" && successInfo ? (
        <ModalSection title="Sent">
          <div className="flex items-start gap-3 rounded-md bg-[#ecfdf5] border border-[#a7f3d0] p-4">
            <CheckCircle2 className="h-5 w-5 text-[#059669] mt-0.5 shrink-0" />
            <div className="space-y-2 text-sm text-[#1a2236]">
              <p className="font-medium">Round {round} sent successfully to {name}.</p>
              <p>Meeting ID: <span className="font-mono">{successInfo.meeting_id}</span></p>
              <p>
                Join URL:{" "}
                <a href={successInfo.join_url} target="_blank" rel="noreferrer"
                   className="text-[#1a2547] underline inline-flex items-center gap-1">
                  {successInfo.join_url} <ExternalLink className="h-3 w-3" />
                </a>
              </p>
              {successInfo.password && <p>Password: <span className="font-mono">{successInfo.password}</span></p>}
            </div>
          </div>
        </ModalSection>
      ) : (
        <>
          <ModalSection title="Candidate">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <EditableContactField
                label="Candidate name"
                value={name}
                onChange={setName}
                onSave={async (v) => {
                  if (nameQid) await updateResponseAnswer(responseId, nameQid, v);
                }}
              />
              <div>
                <FieldLabel>Send to (email)</FieldLabel>
                <Input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="candidate@example.com"
                  disabled={busy}
                  className="h-10 text-sm"
                />
                <p className="mt-1 text-[11px] text-[#6b7280]">
                  Edit if missing or incorrect. Saved as the override for all future sends to this candidate.
                </p>
              </div>
            </div>
          </ModalSection>

          <ModalSection title="Interview Details">
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div>
                <FieldLabel>Date</FieldLabel>
                <Input
                  type="date"
                  min={todayDateStr()}
                  value={date}
                  onChange={(e) => setDate(e.target.value)}
                  disabled={busy}
                  className="h-10 text-sm"
                />
              </div>
              <div>
                <FieldLabel>Time</FieldLabel>
                <Input
                  type="time"
                  step={900}
                  value={time}
                  onChange={(e) => setTime(e.target.value)}
                  disabled={busy}
                  className="h-10 text-sm"
                />
              </div>
              <div>
                <FieldLabel>Duration</FieldLabel>
                <select
                  value={duration}
                  onChange={(e) => setDuration(Number(e.target.value))}
                  disabled={busy}
                  className="h-10 w-full rounded-md border border-[#e1e4ec] bg-white px-3 text-sm text-[#1a2236] focus:outline-none focus:ring-2 focus:ring-[#1a2547]/15"
                >
                  <option value={15}>15 minutes</option>
                  <option value={30}>30 minutes</option>
                  <option value={45}>45 minutes</option>
                  <option value={60}>60 minutes</option>
                </select>
              </div>
            </div>
            <div className="text-xs text-[#6b7280]">
              Timezone: Asia/Manila (PHT) · Candidate's local time. Make sure this matches their availability.
            </div>
            {isResend && (
              <p className="text-xs italic text-[#9ca3af]">
                Re-sending creates a fresh Zoom meeting and cancels the previous one.
              </p>
            )}
          </ModalSection>

          <ModalSection title="Zoom Meeting">
            {partialState ? (
              <div className="flex items-start gap-3 rounded-md bg-[#fff7ed] border border-[#fed7aa] p-4">
                <AlertTriangle className="h-5 w-5 text-[#d97706] mt-0.5 shrink-0" />
                <div className="space-y-2 text-sm text-[#1a2236]">
                  <p className="font-medium">{errorMsg}</p>
                  <p>Meeting ID: <span className="font-mono">{partialState.meeting_id}</span></p>
                  <p>
                    Join URL:{" "}
                    <a href={partialState.join_url} target="_blank" rel="noreferrer"
                       className="text-[#1a2547] underline inline-flex items-center gap-1">
                      {partialState.join_url} <ExternalLink className="h-3 w-3" />
                    </a>
                  </p>
                  {partialState.password && <p>Password: <span className="font-mono">{partialState.password}</span></p>}
                </div>
              </div>
            ) : busy && (progress === "zoom" || progress === "ics" || progress === "email" || progress === "db") ? (
              <div className="flex items-center gap-2 rounded-md bg-[#f4f6fb] border border-[#e1e4ec] p-3 text-sm text-[#1a2236]">
                <Loader2 className="h-4 w-4 animate-spin text-[#1a2547]" /> {progressLabel()}
              </div>
            ) : (
              <div className="flex items-start gap-2 rounded-md bg-[#faf7f1] border border-[#f5ecda] p-3 text-xs italic text-[#6b7280]">
                <Info className="h-3.5 w-3.5 mt-0.5 shrink-0 text-[#b08d57]" />
                <span>Zoom meeting will be created automatically when you click Send.</span>
              </div>
            )}
            {errorMsg && !partialState && (
              <div className="text-xs text-[#b91c1c]">{errorMsg}</div>
            )}
          </ModalSection>
        </>
      )}
    </ModalShell>
  );
};
