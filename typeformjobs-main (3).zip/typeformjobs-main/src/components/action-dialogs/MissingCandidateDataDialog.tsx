import { useEffect, useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Loader2 } from "lucide-react";
import { toast } from "sonner";
import { verifyOverridePassword } from "@/lib/candidateActions";

/**
 * Blocking dialog for missing candidate name/email.
 * Asks for the missing field(s) AND the override password (2828).
 */
export const MissingCandidateDataDialog = ({
  open,
  onOpenChange,
  missing,
  onResolved,
}: {
  open: boolean;
  onOpenChange: (o: boolean) => void;
  missing: { name: boolean; email: boolean };
  onResolved: (vals: { name?: string; email?: string }) => void;
}) => {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [pw, setPw] = useState("");
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    if (!open) {
      setName(""); setEmail(""); setPw(""); setBusy(false);
    }
  }, [open]);

  const titleParts: string[] = [];
  if (missing.name) titleParts.push("name");
  if (missing.email) titleParts.push("email");
  const title = `No ${titleParts.join(" or ")} found`;

  const submit = async () => {
    if (missing.name && !name.trim()) return;
    if (missing.email && !email.trim()) return;
    if (!pw) return;
    setBusy(true);
    const ok = await verifyOverridePassword(pw);
    setBusy(false);
    if (!ok) {
      toast.error("Incorrect password");
      setPw("");
      return;
    }
    onOpenChange(false);
    onResolved({
      name: missing.name ? name.trim() : undefined,
      email: missing.email ? email.trim() : undefined,
    });
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-sm">
        <DialogHeader>
          <DialogTitle>{title}</DialogTitle>
          <DialogDescription>
            Enter the missing candidate details and the override password to continue.
          </DialogDescription>
        </DialogHeader>
        <form onSubmit={(e) => { e.preventDefault(); submit(); }} className="space-y-3">
          {missing.name && (
            <div className="space-y-1.5">
              <Label>Candidate name</Label>
              <Input value={name} onChange={(e) => setName(e.target.value)} autoFocus />
            </div>
          )}
          {missing.email && (
            <div className="space-y-1.5">
              <Label>Candidate email</Label>
              <Input type="email" value={email} onChange={(e) => setEmail(e.target.value)} />
            </div>
          )}
          <div className="space-y-1.5">
            <Label>Override password</Label>
            <Input type="password" value={pw} onChange={(e) => setPw(e.target.value)} />
          </div>
          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>Cancel</Button>
            <Button type="submit" disabled={busy}>
              {busy ? <Loader2 className="h-4 w-4 animate-spin" /> : "Confirm"}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
};
