import { useState } from "react";
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Button } from "@/components/ui/button";
import { Loader2, Trash2 } from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";

type Props = {
  slotId?: string | null;
  responseId?: string;
  candidateName?: string;
  onCancelled?: () => void;
};

export const CancelAppointmentButton = ({ slotId, responseId, candidateName, onCancelled }: Props) => {
  const [open, setOpen] = useState(false);
  const [busy, setBusy] = useState(false);

  const submit = async () => {
    setBusy(true);
    try {
      const body: Record<string, unknown> = { reason: "admin_cancel_appointment" };
      if (slotId) body.slot_id = slotId;
      if (responseId) body.response_id = responseId;
      if (!slotId && !responseId) throw new Error("Missing candidate reference");
      const { data, error } = await supabase.functions.invoke("release-slot", { body });
      const errMsg = (data as any)?.error || error?.message;
      if (errMsg) throw new Error(errMsg);
      toast.success("Appointment cancelled");
      setOpen(false);
      onCancelled?.();
    } catch (e: any) {
      toast.error(e?.message || "Could not cancel appointment");
    } finally {
      setBusy(false);
    }
  };

  return (
    <>
      <Button
        type="button"
        size="sm"
        variant="outline"
        className="min-h-[36px] text-red-600 hover:text-red-700 border-red-200 hover:bg-red-50"
        onClick={() => setOpen(true)}
        title="Delete appointment — frees the slot, no re-invite sent"
        aria-label="Delete appointment"
      >
        <Trash2 className="h-4 w-4" />
      </Button>

      <AlertDialog open={open} onOpenChange={(o) => !busy && setOpen(o)}>
        <AlertDialogContent onClick={(e) => e.stopPropagation()}>
          <AlertDialogHeader>
            <AlertDialogTitle>
              Delete {candidateName || "this candidate"}'s appointment?
            </AlertDialogTitle>
            <AlertDialogDescription>
              This frees their slot (instantly bookable by others) and cancels the Zoom meeting
              (skipped gracefully if already gone). The candidate{" "}
              <span className="font-semibold">stays in My Bookings</span> with an amber
              "Cancelled — Awaiting Rebooking" badge so you can Re-Send or Reschedule them.
              No email is sent to the candidate.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={busy}>Keep appointment</AlertDialogCancel>
            <AlertDialogAction
              onClick={(e) => { e.preventDefault(); submit(); }}
              disabled={busy}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              {busy ? (<><Loader2 className="h-4 w-4 mr-2 animate-spin" /> Deleting…</>) : "Delete appointment"}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
};


export default CancelAppointmentButton;
