import { useEffect, useRef } from "react";

// Loads the official Vimeo Player JS API and attaches it to the embedded
// iframe so we can (a) detect genuine completion ('ended') and (b) block
// forward-skipping past unwatched content. Pausing/resuming and re-watching
// already-seen parts is allowed; jumping ahead snaps back.

declare global {
  interface Window {
    // The Vimeo SDK attaches itself here once loaded.
    Vimeo?: { Player: new (el: HTMLIFrameElement | HTMLElement, opts?: unknown) => VimeoPlayer };
  }
}

type VimeoPlayer = {
  on: (event: string, cb: (data: { seconds: number; duration?: number }) => void) => void;
  off: (event: string) => void;
  setCurrentTime: (seconds: number) => Promise<number>;
  play?: () => Promise<void>;
  unload?: () => Promise<void>;
  destroy?: () => Promise<void>;
};

const SDK_SRC = "https://player.vimeo.com/api/player.js";
// Allow this much forward drift before treating a jump as "skipping ahead".
const SEEK_TOLERANCE = 1.0;

let sdkPromise: Promise<void> | null = null;
function loadVimeoSdk(): Promise<void> {
  if (typeof window !== "undefined" && window.Vimeo) return Promise.resolve();
  if (sdkPromise) return sdkPromise;
  sdkPromise = new Promise<void>((resolve, reject) => {
    const existing = document.querySelector(`script[src="${SDK_SRC}"]`) as HTMLScriptElement | null;
    if (existing) {
      if (window.Vimeo) return resolve();
      existing.addEventListener("load", () => resolve());
      existing.addEventListener("error", () => reject(new Error("vimeo_sdk_failed")));
      return;
    }
    const s = document.createElement("script");
    s.src = SDK_SRC;
    s.async = true;
    s.onload = () => resolve();
    s.onerror = () => reject(new Error("vimeo_sdk_failed"));
    document.head.appendChild(s);
  });
  return sdkPromise;
}

export default function VimeoWatchGate({ src, onEnded }: { src: string; onEnded: () => void }) {
  const iframeRef = useRef<HTMLIFrameElement | null>(null);
  const furthestRef = useRef(0);
  const onEndedRef = useRef(onEnded);
  onEndedRef.current = onEnded;

  useEffect(() => {
    let cancelled = false;
    let player: VimeoPlayer | null = null;
    furthestRef.current = 0;

    loadVimeoSdk()
      .then(() => {
        if (cancelled || !iframeRef.current || !window.Vimeo) return;
        player = new window.Vimeo.Player(iframeRef.current);

        // Track the furthest point genuinely watched.
        player.on("timeupdate", (data) => {
          if (data.seconds > furthestRef.current) furthestRef.current = data.seconds;
        });

        // Block forward-skipping: if the viewer scrubs past what they've
        // watched, snap back to the furthest watched point.
        player.on("seeked", (data) => {
          if (data.seconds > furthestRef.current + SEEK_TOLERANCE) {
            player?.setCurrentTime(furthestRef.current).catch(() => {});
          }
        });

        player.on("ended", () => onEndedRef.current());

        // One-tap play: kick playback off immediately so the candidate
        // doesn't have to press Vimeo's own play button as well.
        player.play?.().catch(() => {});
      })
      .catch(() => {
        // If the SDK fails to load, the gate stays locked (fail-safe).
      });

    return () => {
      cancelled = true;
      if (player) {
        try {
          player.off("timeupdate");
          player.off("seeked");
          player.off("ended");
          player.destroy?.();
        } catch {
          /* no-op */
        }
      }
    };
  }, [src]);

  return (
    <div style={{ position: "relative", width: "100%", paddingTop: "56.25%" }}>
      <iframe
        ref={iframeRef}
        src={src}
        title="Orientation video"
        allow="autoplay; fullscreen; picture-in-picture"
        allowFullScreen
        style={{ position: "absolute", top: 0, left: 0, width: "100%", height: "100%", border: 0 }}
      />
    </div>
  );
}
