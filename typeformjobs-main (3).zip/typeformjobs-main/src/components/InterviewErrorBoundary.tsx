import React from "react";

interface State {
  hasError: boolean;
}

export default class InterviewErrorBoundary extends React.Component<
  { children: React.ReactNode },
  State
> {
  state: State = { hasError: false };

  static getDerivedStateFromError(): State {
    return { hasError: true };
  }

  componentDidCatch(error: Error, info: React.ErrorInfo) {
    // eslint-disable-next-line no-console
    console.error("[ai-interview] ErrorBoundary caught:", error, info);
  }

  render() {
    if (this.state.hasError) {
      return (
        <div
          style={{
            minHeight: "var(--app-vh, 100vh)",
            background: "#faf8f3",
            color: "#0f1730",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            padding: "24px",
            fontFamily: "'Inter', system-ui, sans-serif",
            textAlign: "center",
          }}
        >
          <div style={{ maxWidth: 480 }}>
            <div
              style={{
                fontFamily: "'Cormorant Garamond', serif",
                fontSize: 28,
                fontWeight: 500,
                marginBottom: 12,
              }}
            >
              Something interrupted the interview.
            </div>
            <p style={{ fontSize: 15, lineHeight: 1.6, color: "rgba(15,23,48,0.75)" }}>
              Please refresh and try again, or contact{" "}
              <a
                href="mailto:careers@expertintuitiveadvisor.com"
                style={{ color: "#0f1730", textDecoration: "underline" }}
              >
                careers@expertintuitiveadvisor.com
              </a>
              .
            </p>
            <button
              onClick={() => window.location.reload()}
              style={{
                marginTop: 24,
                padding: "10px 24px",
                borderRadius: 999,
                background: "#0f1730",
                color: "#faf8f3",
                fontSize: 12,
                letterSpacing: "0.22em",
                textTransform: "uppercase",
                border: 0,
                cursor: "pointer",
              }}
            >
              Refresh
            </button>
          </div>
        </div>
      );
    }
    return this.props.children;
  }
}
