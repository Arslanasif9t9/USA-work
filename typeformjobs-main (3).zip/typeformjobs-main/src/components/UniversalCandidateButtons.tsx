import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { AiAssistButton } from "@/components/AiAssistButton";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import { Loader2, Video, Bot, Copy, Check, Lock, CalendarClock } from "lucide-react";
import { toast } from "sonner";
import { cleanPositionTitle } from "@/lib/positionTitle";
import SendScheduleControl, { type SendScheduleValue } from "@/components/SendScheduleControl";
import { insertScheduledSend, formatScheduledFor } from "@/lib/scheduledSends";
import EditSlotsDialog from "@/components/EditSlotsDialog";

type LiveForm = { id: string; title: string; position_title: string | null };

const AI_PASSWORD = "Money";

export function UniversalCandidateButtons({ onCreated }: { onCreated?: () => void }) {
  const [zoomOpen, setZoomOpen] = useState(false);
  const [aiGateOpen, setAiGateOpen] = useState(false);
  const [aiFormOpen, setAiFormOpen] = useState(false);

  return (
    <>
      <Button
        size="sm"
        onClick={() => setZoomOpen(true)}
        className="bg-blue-600 hover:bg-blue-700 text-white min-h-[44px] sm:min-h-0"
        title="Create an on-the-spot Zoom candidate"
      >
        <Video className="h-4 w-4 mr-1.5" /> Universal Zoom
      </Button>
      <Button
        size="sm"
        onClick={() => setAiGateOpen(true)}
        className="bg-purple-600 hover:bg-purple-700 text-white min-h-[44px] sm:min-h-0"
        title="Create an on-the-spot AI interview candidate"
      >
        <Bot className="h-4 w-4 mr-1.5" /> Universal AI Interview
      </Button>


      {zoomOpen && (
        <UniversalCandidateModal
          type="zoom"
          onClose={() => setZoomOpen(false)}
          onCreated={onCreated}
        />
      )}
      {aiGateOpen && (
        <PasswordGate
          onClose={() => setAiGateOpen(false)}
          onPass={() => { setAiGateOpen(false); setAiFormOpen(true); }}
        />
      )}
      {aiFormOpen && (
        <UniversalCandidateModal
          type="ai"
          onClose={() => setAiFormOpen(false)}
          onCreated={onCreated}
        />
      )}
      
    </>
  );
}

function PasswordGate({ onClose, onPass }: { onClose: () => void; onPass: () => void }) {
  const [pw, setPw] = useState("");
  const [err, setErr] = useState<string | null>(null);
  const submit = () => {
    if (pw === AI_PASSWORD) { setErr(null); onPass(); }
    else setErr("Incorrect password.");
  };
  return (
    <Dialog open onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="sm:max-w-[400px]">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2"><Lock className="h-4 w-4" /> Password Required</DialogTitle>
          <DialogDescription>Enter the password to create a universal AI interview link.</DialogDescription>
        </DialogHeader>
        <div className="space-y-2">
          <Label htmlFor="uc-pw">Password</Label>
          <Input
            id="uc-pw"
            type="password"
            value={pw}
            onChange={(e) => { setPw(e.target.value); setErr(null); }}
            onKeyDown={(e) => { if (e.key === "Enter") submit(); }}
            autoFocus
            className="min-h-[44px] sm:min-h-0"
          />
          {err && <p className="text-sm text-destructive">{err}</p>}
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={onClose} className="min-h-[44px] sm:min-h-0">Cancel</Button>
          <Button onClick={submit} className="min-h-[44px] sm:min-h-0">Continue</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

export function UniversalCandidateModal({
  type, onClose, onCreated, initialName, initialEmail,
}: { type: "zoom" | "ai"; onClose: () => void; onCreated?: () => void; initialName?: string; initialEmail?: string }) {
  const [forms, setForms] = useState<LiveForm[]>([]);
  const [formId, setFormId] = useState("");
  const [positionMode, setPositionMode] = useState<"existing" | "custom">("existing");
  const [customPosition, setCustomPosition] = useState("");
  const [name, setName] = useState(initialName ?? "");
  const [email, setEmail] = useState(initialEmail ?? "");
  const [loading, setLoading] = useState(false);
  const [link, setLink] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);
  const [createdLabel, setCreatedLabel] = useState<string>("");
  const [schedule, setSchedule] = useState<SendScheduleValue>({ mode: "now" });
  // Zoom-only per-recipient slot curation (picker mode, mirrors Round 1).
  const [curatedIds, setCuratedIds] = useState<string[]>([]);
  const [editOpen, setEditOpen] = useState(false);
  // Zoom-only optional personal note injected into the invite email body.
  const [hrMessage, setHrMessage] = useState("");

  useEffect(() => {
    (async () => {
      const { data: f } = await supabase
        .from("forms")
        .select("id, title")
        .eq("status", "live")
        .order("title", { ascending: true });
      const ids = (f || []).map((x) => x.id);
      let meta: Record<string, string | null> = {};
      if (ids.length) {
        const { data: m } = await supabase
          .from("form_metadata")
          .select("form_id, position_title")
          .in("form_id", ids);
        meta = Object.fromEntries((m || []).map((r: any) => [r.form_id, r.position_title]));
      }
      setForms((f || []).map((x: any) => ({ id: x.id, title: x.title, position_title: meta[x.id] ?? null })));
    })();
  }, []);

  const positionLabel = (f: LiveForm) => cleanPositionTitle(f.position_title) || f.title || "Untitled";

  const submit = async () => {
    if (!name.trim()) return toast.error("Name is required");
    if (!email.trim() || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim())) return toast.error("Valid email is required");
    const useCustom = positionMode === "custom";
    if (useCustom) {
      if (!customPosition.trim()) return toast.error("Custom position is required");
    } else if (!formId) {
      return toast.error("Position is required");
    }
    setLoading(true);
    try {
      // Build the EXACT Send-Now body once so a scheduled replay is identical.
      const sendBody: Record<string, unknown> = useCustom
        ? { type, name: name.trim(), email: email.trim(), custom_position: customPosition.trim() }
        : { type, name: name.trim(), email: email.trim(), form_id: formId };
      // Zoom path only: per-recipient curated slots (mirror send-round-invite).
      if (type === "zoom" && curatedIds.length > 0) {
        sendBody.curated_slot_ids = curatedIds;
      }
      // Zoom path only: optional personal note for the invite email body.
      if (type === "zoom" && hrMessage.trim()) {
        sendBody.hr_message = hrMessage.trim();
      }

      // Scheduled branch: persist a pending row and do NOT create the candidate now.
      if (schedule.mode === "schedule") {
        await insertScheduledSend({
          send_type: type === "zoom" ? "universal_zoom" : "universal_ai",
          target_function: "create-universal-candidate",
          payload: sendBody,
          response_id: null,
          scheduled_for_utc: schedule.scheduled_for_utc,
          timezone: schedule.timezone,
        });
        toast.success(
          `${type === "zoom" ? "Universal Zoom" : "Universal AI"} candidate scheduled for ${formatScheduledFor(schedule.scheduled_for_utc, schedule.timezone)}`,
        );
        onClose();
        return;
      }

      const { data, error } = await supabase.functions.invoke("create-universal-candidate", {
        body: sendBody,
      });
      if (error) {
        const msg = (data as any)?.error || error.message || "Failed to create candidate";
        toast.error(String(msg));
        return;
      }
      if ((data as any)?.error) {
        toast.error(String((data as any).error));
        return;
      }
      const raw = (data as any)?.link as string;
      const absolute = raw?.startsWith("/") ? `${window.location.origin}${raw}` : raw;
      setLink(absolute);
      const f = forms.find((x) => x.id === formId);
      const posLabel = useCustom ? customPosition.trim() : (f ? positionLabel(f) : "");
      setCreatedLabel(`${name.trim()} — ${posLabel}`);
      if (type === "zoom") {
        toast.success((data as any)?.email_sent ? "Candidate created — Zoom link emailed" : "Candidate created (email failed to send)");
      } else {
        toast.success((data as any)?.email_sent ? "Candidate created — Christine interview link emailed to candidate" : "Candidate created (email failed to send)");
      }

      onCreated?.();
    } catch (e: any) {
      toast.error(e?.message || "Network error — please retry");
    } finally {
      setLoading(false);
    }
  };

  const copy = async () => {
    if (!link) return;
    try { await navigator.clipboard.writeText(link); setCopied(true); setTimeout(() => setCopied(false), 1800); }
    catch { toast.error("Copy failed"); }
  };

  const title = type === "zoom" ? "Universal Zoom Candidate" : "Universal AI Interview Candidate";

  return (
    <Dialog open onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="sm:max-w-[480px]">
        <DialogHeader>
          <DialogTitle>{title}</DialogTitle>
          <DialogDescription>
            Creates a candidate on the spot and returns a shareable link. They will appear in My Bookings as Round 1 Sent.
          </DialogDescription>
        </DialogHeader>

        {!link ? (
          <div className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="uc-name">Name</Label>
              <Input id="uc-name" value={name} onChange={(e) => setName(e.target.value)} placeholder="Candidate full name" className="min-h-[44px] sm:min-h-0" />
            </div>
            <div className="space-y-2">
              <Label htmlFor="uc-email">Email</Label>
              <Input id="uc-email" type="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="candidate@example.com" className="min-h-[44px] sm:min-h-0" />
            </div>
            <div className="space-y-2">
              <Label>Position</Label>
              <div className="inline-flex rounded-md border border-input p-0.5">
                <button
                  type="button"
                  onClick={() => setPositionMode("existing")}
                  className={`px-3 py-1.5 text-xs font-medium rounded ${positionMode === "existing" ? "bg-primary text-primary-foreground" : "text-muted-foreground"}`}
                >
                  Choose existing
                </button>
                <button
                  type="button"
                  onClick={() => setPositionMode("custom")}
                  className={`px-3 py-1.5 text-xs font-medium rounded ${positionMode === "custom" ? "bg-primary text-primary-foreground" : "text-muted-foreground"}`}
                >
                  Custom position
                </button>
              </div>
              {positionMode === "existing" ? (
                <Select value={formId} onValueChange={setFormId}>
                  <SelectTrigger className="min-h-[44px] sm:min-h-0"><SelectValue placeholder="Choose a position" /></SelectTrigger>
                  <SelectContent>
                    {forms.map((f) => (
                      <SelectItem key={f.id} value={f.id}>{positionLabel(f)}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              ) : (
                <Input
                  value={customPosition}
                  onChange={(e) => setCustomPosition(e.target.value)}
                  placeholder="e.g. Not Applicable, CEO, any title"
                  className="min-h-[44px] sm:min-h-0"
                />
              )}
            </div>
            {type === "zoom" && (
              <div className="rounded-md border bg-muted/30 p-3 flex items-start gap-3">
                <CalendarClock className="h-4 w-4 mt-0.5 text-primary shrink-0" />
                <div className="flex-1 space-y-1">
                  <div className="text-sm font-medium">
                    {curatedIds.length === 0 ? "Default availability (3-day window)" : `Curated: ${curatedIds.length} slot${curatedIds.length === 1 ? "" : "s"} shown`}
                  </div>
                  <p className="text-xs text-muted-foreground">
                    {curatedIds.length === 0
                      ? "Recipient sees all available slots and books their own time."
                      : "Recipient sees only the slots you picked."}
                  </p>
                </div>
                <Button type="button" variant="outline" size="sm" onClick={() => setEditOpen(true)} disabled={loading}>
                  Edit Slots
                </Button>
              </div>
            )}
            {type === "zoom" && (
              <div className="space-y-2">
                <div className="flex items-center justify-between gap-2">
                  <Label htmlFor="uc-message">Message to recipient (optional)</Label>
                  <AiAssistButton
                    context="Personal note from HR inviting a candidate to schedule a Zoom interview"
                    onAccept={(text) => setHrMessage(text)}
                  />
                </div>
                <Textarea
                  id="uc-message"
                  value={hrMessage}
                  onChange={(e) => setHrMessage(e.target.value)}
                  rows={4}
                  placeholder="Add a short personal note to include in the invite email…"
                />
              </div>
            )}
            <div className="space-y-2">
              <Label>When to send</Label>
              <SendScheduleControl onChange={setSchedule} />
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={onClose} disabled={loading} className="min-h-[44px] sm:min-h-0">Cancel</Button>
              <Button onClick={submit} disabled={loading} className="min-h-[44px] sm:min-h-0">
                {loading
                  ? <><Loader2 className="h-4 w-4 mr-1.5 animate-spin" /> {schedule.mode === "schedule" ? "Scheduling…" : "Creating…"}</>
                  : (schedule.mode === "schedule" ? "Schedule Candidate" : "Create Candidate")}
              </Button>
            </DialogFooter>
          </div>
        ) : (
          <div className="space-y-3">
            <p className="text-sm text-muted-foreground">Link for <span className="font-medium text-foreground">{createdLabel}</span></p>
            <div className="flex items-center gap-2">
              <Input readOnly value={link} className="flex-1 font-mono text-xs" onFocus={(e) => e.currentTarget.select()} />
              <Button onClick={copy} variant={copied ? "default" : "outline"} className="min-h-[44px] sm:min-h-0">
                {copied ? <><Check className="h-4 w-4 mr-1.5" /> Copied!</> : <><Copy className="h-4 w-4 mr-1.5" /> Copy Link</>}
              </Button>
            </div>
            <DialogFooter>
              <Button onClick={onClose} className="min-h-[44px] sm:min-h-0">Done</Button>
            </DialogFooter>
          </div>
        )}
      </DialogContent>

      {type === "zoom" && (
        <EditSlotsDialog
          open={editOpen}
          onOpenChange={setEditOpen}
          initialSelected={curatedIds}
          onSave={(ids) => setCuratedIds(ids)}
        />
      )}
    </Dialog>
  );
}
