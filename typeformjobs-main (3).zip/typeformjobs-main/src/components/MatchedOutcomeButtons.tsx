import { useState } from "react";
import { Button } from "@/components/ui/button";
import { CheckCircle2, XCircle, Loader2 } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useHrIdentity } from "@/hooks/useHrIdentity";
import { toast } from "sonner";
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
} from "@/components/ui/alert-dialog";

type Props = {
  responseId: string;
  candidateName?: string;
  /** Called optimistically to remove the row from the current list. */
  onOptimisticRemove?: () => void;
  /** Called if the underlying mutation fails. */
  onRevert?: () => void;
};

/**
 * Matched / Not Matched outcome buttons for an Offer-Signed candidate.
 * - Matched → final_outcome='matched'; candidate appears in /dashboard/employees.
 * - Not Matched → round_stage='disqualified', final_outcome='not_matched',
 *   disqualified_at_stage='Offer Signed'; candidate appears in Disqualified.
 */
export const MatchedOutcomeButtons = ({
  responseId, candidateName, onOptimisticRemove, onRevert,
}: Props) => {
  const { hrId } = useHrIdentity();
  const [confirm, setConfirm] = useState<null | "matched" | "not_matched">(null);
  const [busy, setBusy] = useState(false);

  const submit = async (kind: "matched" | "not_matched") => {
    setBusy(true);
    setConfirm(null);
    onOptimisticRemove?.();
    try {
      const patch: Record<string, any> =
        kind === "matched"
          ? { final_outcome: "matched" }
          : {
              final_outcome: "not_matched",
              round_stage: "disqualified",
              disqualified_at: new Date().toISOString(),
              disqualified_by_hr_id: hrId || null,
              disqualified_at_stage: "Offer Signed",
            };
      const { error } = await (supabase
        .from("responses") as any)
        .update(patch)
        .eq("id", responseId);
      if (error) throw error;
      toast.success(kind === "matched" ? "Marked as Hire — moved to Employees" : "Marked as Not Hire — moved to Disqualified");
    } catch (e: any) {
      onRevert?.();
      toast.error(e?.message || "Could not update — reverted");
    } finally {
      setBusy(false);
    }
  };

  return (
    <>
      <Button
        type="button"
        size="sm"
        className="bg-emerald-600 hover:bg-emerald-700 text-white"
        onClick={() => setConfirm("matched")}
        disabled={busy}
      >
        {busy ? <Loader2 className="h-3.5 w-3.5 mr-1.5 animate-spin" /> : <CheckCircle2 className="h-3.5 w-3.5 mr-1.5" />}
        Hire
      </Button>
      <Button
        type="button"
        size="sm"
        variant="outline"
        className="text-destructive border-destructive/40 hover:bg-destructive/10 hover:text-destructive"
        onClick={() => setConfirm("not_matched")}
        disabled={busy}
      >
        <XCircle className="h-3.5 w-3.5 mr-1.5" /> Not Hire
      </Button>

      <AlertDialog open={!!confirm} onOpenChange={(o) => !o && !busy && setConfirm(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>
              {confirm === "matched"
                ? `Mark ${candidateName || "this candidate"} as Hire?`
                : `Mark ${candidateName || "this candidate"} as Not Hire?`}
            </AlertDialogTitle>
            <AlertDialogDescription>
              {confirm === "matched"
                ? "They will move to the Employees section. The signed offer stays intact."
                : "They will move to the Disqualified section with stage recorded as “Offer Signed”. The signed offer stays intact."}
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={busy}>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={(e) => { e.preventDefault(); if (confirm) submit(confirm); }}
              disabled={busy}
              className={confirm === "matched" ? "bg-emerald-600 hover:bg-emerald-700" : "bg-destructive text-destructive-foreground hover:bg-destructive/90"}
            >
              {busy ? <Loader2 className="h-4 w-4 mr-2 animate-spin" /> : null}
              {confirm === "matched" ? "Confirm Hire" : "Confirm Not Hire"}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
};

export default MatchedOutcomeButtons;
