interface Props {
  /** "TALENT APPLICATION" (default) or custom subtitle in caps */
  subtitle?: string;
  className?: string;
  align?: "left" | "center" | "right";
}

/**
 * Pure-typography EIA brand mark. No image, no box, no icon.
 * Used at the top of forms, the form editor canvas, and other branded surfaces.
 */
const EiaWordmark = ({ subtitle = "TALENT APPLICATION", className = "", align = "left" }: Props) => {
  const textAlign = align === "center" ? "center" : align === "right" ? "right" : "left";
  const dividerMargin =
    align === "center" ? "6px auto" : align === "right" ? "6px 0 6px auto" : "6px 0";

  return (
    <div className={className} style={{ textAlign }}>
      <div
        style={{
          fontFamily: "'Cormorant Garamond', serif",
          fontWeight: 600,
          fontSize: "28px",
          color: "#1a2547",
          letterSpacing: "4px",
          lineHeight: 1,
        }}
      >
        EIA
      </div>
      <div
        style={{
          fontFamily: "'Cormorant Garamond', serif",
          fontWeight: 400,
          fontStyle: "italic",
          fontSize: "11px",
          color: "#1a2547",
          letterSpacing: "0.5px",
          marginTop: "4px",
        }}
      >
        Expert Intuitive Advisor Inc.
      </div>
      <div
        style={{
          width: "60px",
          height: "1px",
          backgroundColor: "#b08d57",
          margin: dividerMargin,
        }}
      />
      <div
        style={{
          fontFamily: "'Inter', sans-serif",
          fontWeight: 400,
          fontSize: "8px",
          color: "#6b7280",
          textTransform: "uppercase",
          letterSpacing: "2px",
        }}
      >
        {subtitle}
      </div>
    </div>
  );
};

export default EiaWordmark;
