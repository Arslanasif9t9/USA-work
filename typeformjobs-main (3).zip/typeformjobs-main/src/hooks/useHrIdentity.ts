import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";

export type HrIdentity = {
  hrId: string | null;
  displayName: string | null;
  role: "hr" | "master_admin" | null;
  email: string | null;
  loading: boolean;
};

export function useHrIdentity(): HrIdentity {
  const { user, loading: authLoading } = useAuth();
  const [state, setState] = useState<HrIdentity>({
    hrId: null, displayName: null, role: null, email: null, loading: true,
  });

  useEffect(() => {
    if (authLoading) return;
    if (!user?.email) {
      setState({ hrId: null, displayName: null, role: null, email: null, loading: false });
      return;
    }
    (async () => {
      const { data } = await supabase
        .from("hr_users")
        .select("id, display_name, role")
        .ilike("email", user.email!)
        .maybeSingle();
      setState({
        hrId: data?.id ?? null,
        displayName: data?.display_name ?? null,
        role: (data?.role as any) ?? null,
        email: user.email!,
        loading: false,
      });
    })();
  }, [user?.email, authLoading]);

  return state;
}
