import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";

const FALLBACK = "talent.expertadvisor@outlook.com";

/**
 * Read-only live fetch of the Internal Backup Copy Email from app_settings.
 * Used by the HrCopyCheckbox to display the destination next to the checkbox.
 * Falls back to a sensible default if the table is unreachable.
 */
export function useHrCopyEmail() {
  const [email, setEmail] = useState<string>(FALLBACK);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const { data } = await supabase
          .from("app_settings" as any)
          .select("hr_copy_email")
          .eq("id", 1)
          .maybeSingle();
        if (!cancelled) {
          const v = (data as any)?.hr_copy_email;
          if (v && typeof v === "string" && v.trim()) setEmail(v.trim());
        }
      } finally {
        if (!cancelled) setLoading(false);
      }
    })();
    return () => { cancelled = true; };
  }, []);

  return { email, loading };
}
