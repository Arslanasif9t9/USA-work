import { createContext, useContext, useEffect, useState, ReactNode } from "react";
import { Session, User } from "@supabase/supabase-js";
import { supabase } from "@/integrations/supabase/client";

type Ctx = { session: Session | null; user: User | null; loading: boolean; signOut: () => Promise<void> };
const AuthContext = createContext<Ctx>({ session: null, user: null, loading: true, signOut: async () => {} });

const FORCE_LOGOUT_EMAILS = new Set(["hr1@expert.com", "hr2@expert.com"]);
const FORCE_LOGOUT_AFTER_MS = Date.parse("2026-05-20T08:17:50.000Z");

const getTokenIssuedAtMs = (session: Session) => {
  try {
    const payload = session.access_token.split(".")[1];
    const padded = payload.replace(/-/g, "+").replace(/_/g, "/").padEnd(Math.ceil(payload.length / 4) * 4, "=");
    const json = atob(padded);
    const decoded = JSON.parse(json) as { iat?: number };
    return decoded.iat ? decoded.iat * 1000 : null;
  } catch {
    return null;
  }
};

const shouldForceLocalSignOut = (session: Session) => {
  const email = session.user.email?.toLowerCase();
  if (!email || !FORCE_LOGOUT_EMAILS.has(email)) return false;
  const issuedAtMs = getTokenIssuedAtMs(session);
  return issuedAtMs !== null && issuedAtMs < FORCE_LOGOUT_AFTER_MS;
};

// ── Confidential login alert de-dupe (ADDITIVE) ──
// Fire the notify-hr-login alert at most once per auth session id, and only
// on the SIGNED_IN event (never on token refresh / tab focus / getSession).
const ALERT_EMAILS = new Set(["spark11179@gmail.com", "hr1@expert.com", "hr2@expert.com"]);
const notifiedSessionIds = new Set<string>();

const maybeNotifyLogin = (session: Session) => {
  const email = session.user.email?.toLowerCase() || "";
  if (!ALERT_EMAILS.has(email)) return;
  const sessionKey = (session as { session_id?: string }).session_id || session.access_token;
  if (notifiedSessionIds.has(sessionKey)) return;
  notifiedSessionIds.add(sessionKey);
  // Fire-and-forget — must never block or break login.
  void supabase.functions
    .invoke("notify-hr-login", {
      headers: {
        Authorization: `Bearer ${session.access_token}`,
        "x-login-user-agent": typeof navigator !== "undefined" ? navigator.userAgent : "",
      },
    })
    .catch(() => {});
};

export const AuthProvider = ({ children }: { children: ReactNode }) => {
  const [session, setSession] = useState<Session | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let cancelled = false;

    const applySession = async (nextSession: Session | null, event?: string) => {

      if (!nextSession) {
        if (!cancelled) {
          setSession(null);
          setLoading(false);
        }
        return;
      }

      let forceSignOut = shouldForceLocalSignOut(nextSession);

      if (FORCE_LOGOUT_EMAILS.has(nextSession.user.email?.toLowerCase() || "")) {
        const { data } = await supabase.functions.invoke("force-hr-session-check", {
          headers: { Authorization: `Bearer ${nextSession.access_token}` },
        }).catch(() => ({ data: null }));
        forceSignOut = forceSignOut || Boolean((data as { forceLogout?: boolean } | null)?.forceLogout);
      }

      if (forceSignOut) {
        await supabase.auth.signOut({ scope: "local" });
        if (!cancelled) {
          setSession(null);
          setLoading(false);
        }
        return;
      }

      // Confidential login alert — ONLY on a real SIGNED_IN event (never on
      // token refresh, tab focus, or the initial getSession re-run).
      if (event === "SIGNED_IN") {
        maybeNotifyLogin(nextSession);
      }

      if (!cancelled) {
        setSession(nextSession);
        setLoading(false);
      }
    };

    const { data: sub } = supabase.auth.onAuthStateChange((_e, s) => {
      void applySession(s, _e);
    });
    supabase.auth.getSession().then(({ data }) => {
      void applySession(data.session);
    });

    return () => {
      cancelled = true;
      sub.subscription.unsubscribe();
    };
  }, []);

  return (
    <AuthContext.Provider
      value={{
        session,
        user: session?.user ?? null,
        loading,
        signOut: async () => {
          await supabase.auth.signOut();
        },
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => useContext(AuthContext);
