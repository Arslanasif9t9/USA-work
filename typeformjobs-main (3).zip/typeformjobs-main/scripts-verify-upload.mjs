import { createClient } from "@supabase/supabase-js";
const url = process.env.VITE_SUPABASE_URL;
const key = process.env.VITE_SUPABASE_PUBLISHABLE_KEY;
const sb = createClient(url, key);

async function test(bucket, name, type, sizeBytes) {
  const buf = new Uint8Array(sizeBytes);
  crypto.getRandomValues(buf);
  const file = new File([buf], name, { type });
  const path = `verify-anon/${Date.now()}-${name.replace(/[^a-zA-Z0-9._-]/g,"_")}`;
  const { data, error } = await sb.storage.from(bucket).upload(path, file, {
    upsert: false, contentType: type || "application/octet-stream"
  });
  console.log(bucket, name, type, sizeBytes,
    error ? `FAIL status=${error.statusCode || error.status} msg=${error.message}` : `OK ${data?.path}`);
}

await test("selfies", "iphone.heic", "image/heic", 800_000);
await test("selfies", "android.jpg", "image/jpeg", 1_200_000);
await test("selfies", "weird name (1).png", "image/png", 200_000);
await test("resumes", "cv.pdf", "application/pdf", 500_000);
await test("resumes", "huge.pdf", "application/pdf", 90 * 1024 * 1024);
