# Employee Onboarding — Video + Quiz (Build Plan)

READ-ONLY investigation done. No code changed. This is for your approval.

## DATA OWNERSHIP MODEL (applies to everything below)
- All data belongs to the workspace/project, never to a user account.
- Every FK to a user table uses ON DELETE SET NULL — never CASCADE, never RESTRICT.
- Single-row writes by `id`. The `answers` table is never touched.
- EIA Lovable has no real DB FKs in practice — linkage is by id/token convention; we keep that convention and apply SET NULL semantics where a real FK is added.

## KEY FINDING — naming collision (needs your call)
`/onboarding/:token` is ALREADY LIVE. It is the equipment/details form: page `src/pages/Onboarding.tsx`, table `onboarding_tokens`, functions `mint-onboarding-token` / `validate-onboarding-token` / `submit-onboarding`, plus a green "Onboarding" badge and `OnboardingSubmissionsSection` in HR Approval.
To avoid breaking that, the new video+quiz feature gets its OWN route, tables, and functions:
- Proposed route: `/onboarding-test/:token` (mirrors `/ai-interview/:token` exactly: public, no login, token-gated).
- If you insist on the literal `/onboarding/:token` path, we'd have to fold both flows behind one token type-switch, which risks the live form. Recommendation: keep them separate. Confirm the route name.

## EXISTING PATTERNS WE REUSE (verified)
- Public token route: registered in `App.tsx` (e.g. `/ai-interview/:token`, `/rebook/:token`), lazy-loaded page calls a public `validate-*-token` edge function (service-role client, returns `{valid, reason}`), CORS-enabled.
- Mint pattern: HR-only function (`requireHr` from `_shared/hr-auth.ts`), service-role insert, read-after-write guard (re-select the row and compare token) — exactly like `mint-onboarding-token`.
- Team list: `list-team-groups` (HR-only proxy to PMS bridge, never exposes the key) → `{id,name}[]`; assignment persisted on `responses.assigned_group_id`.
- HR Approval dashboard: `src/pages/SickLeavesDashboard.tsx` (route `/dashboard/sick-leaves`, labeled "H.R Approval"). Pending rows get Approve/Decline; `OnboardingSubmissionsSection` is already embedded as a section there.
- Sylvia dashboard: `src/pages/SylviaDashboard.tsx`.
- Email: Resend via `https://api.resend.com/emails` directly, sender read from a constant (we will read the sender from config, not hardcode it inline), branded navy `#1a2547` / gold `#b08d57`, Cormorant + Inter, logged to `email_log`.

---

## NEW DATABASE TABLES

### 1. `onboarding_quiz_tokens` (the single-use, identity-gated link)
- `id` uuid PK
- `token` text unique not null
- `candidate_name` text not null
- `candidate_email` text not null
- `assigned_group_id` text null (target PMS team)
- `after_pass_mode` text not null default `'manual'` (`'manual'` = HR approves first; `'auto'` = auto-send next step)
- `video_url` text null (per-link override; falls back to app config default)
- `attempts_used` int not null default 0
- `status` text not null default `'active'` (`active` | `passed_pending` | `passed_approved` | `passed_declined` | `failed_out` | `invalidated`)
- `passed` boolean not null default false
- `invalidated_at` timestamptz null
- `passed_at` timestamptz null
- `expires_at` timestamptz not null default now()+30 days
- `created_by` uuid null (HR user, ON DELETE SET NULL)
- `created_at` / `updated_at` timestamptz (updated_at trigger)
- GRANTs: `service_role` ALL (functions only); `authenticated` SELECT/UPDATE for HR dashboards; no `anon` (public access goes through edge functions). RLS enabled.

### 2. `onboarding_quiz_attempts` (one row per attempt)
- `id` uuid PK
- `token_id` uuid null (link to token; ON DELETE SET NULL)
- `attempt_number` int not null
- `score` int not null, `total` int not null default 11
- `passed` boolean not null
- `answers` jsonb null (selected indexes only — never the correct key)
- `created_at` timestamptz
- GRANTs: `service_role` ALL; `authenticated` SELECT. RLS enabled.

### 3. `onboarding_quiz_questions` (editable question bank)
- `id` uuid PK, `order_index` int, `question` text, `options` jsonb (array, 2–4 items), `correct_index` int, `active` boolean default true, timestamps.
- `correct_index` is NEVER sent to the browser; scoring is server-side only.
- GRANTs: `service_role` ALL; `authenticated` SELECT (for an HR editor later). No `anon`.
- You paste the final 11 questions during the build step; we seed them then.

---

## NEW EDGE FUNCTIONS
1. `mint-onboarding-quiz-token` — HR-only. Inserts a token locked to name+email+team+after_pass_mode (+optional video_url), read-after-write guard, returns token. Reuses an existing live token if one already exists for that identity.
2. `send-onboarding-test-invite` — HR-only. Sends the branded invite carrying `/onboarding-test/:token`; logs to `email_log`. (Mirrors `send-onboarding-invite`.)
3. `validate-onboarding-quiz-token` — PUBLIC. Returns `{valid, reason}` + `candidate_name/email` presence flag + resolved `video_url`. Returns quiz questions WITHOUT `correct_index` only AFTER identity is confirmed (see below). Honors `status`/`expires_at`/`invalidated_at`.
4. `submit-onboarding-quiz-attempt` — PUBLIC, token-gated + identity-gated. Verifies entered name+email match the token (case-insensitive, trimmed). Scores server-side, writes an `onboarding_quiz_attempts` row, increments `attempts_used`. Logic: pass (>=9/11) → set `passed`, `status='passed_pending'`, invalidate link; if `after_pass_mode='auto'` immediately fire next-step invite and log it as already-approved (`status='passed_approved'`); fail and `attempts_used>=3` → `status='failed_out'`, invalidate; otherwise allow retry.
5. `decide-onboarding-quiz` — HR-only Approve/Decline for `passed_pending` rows. Approve → issue PMS team invite (reuse `assigned_group_id` wiring / bridge) and set `passed_approved`. Decline → send nothing, set `passed_declined`.
6. (Optional) `issue-next-project-invite` — shared helper used by both auto-pass and manual-approve to invite the candidate into the chosen PMS team via the existing bridge.

Identity-gate note: to prevent a typo from killing a legit link, the plan is — wrong identity on submit returns an error and does NOT invalidate on the first mismatch; repeated/clearly-different identity handling is configurable. The handover says "wrong name/email → link dead"; confirm whether you want hard-kill on the very first mismatch or a small tolerance. (Risk item below.)

---

## NEW / MODIFIED FRONTEND FILES
- ADD `src/pages/OnboardingTest.tsx` — public page. Step 1 video (HTML5 player, quiz locked until `ended` fires), Step 2 quiz (one question per premium card, "Question X of 11", variable option counts), calm PASS / RETRY / FINAL-FAIL screens. Navy/gold, Cormorant+Inter, no emoji.
- MODIFY `src/App.tsx` — register the new public route.
- MODIFY `src/pages/SylviaDashboard.tsx` — add "Onboarding Test Results" tab (name, email, score, pass/fail, attempts, date) reading `onboarding_quiz_tokens` + latest `onboarding_quiz_attempts`.
- ADD `src/components/OnboardingTestApprovalsSection.tsx` and embed in `SickLeavesDashboard.tsx` (H.R Approval) — lists `passed_pending` rows with Approve/Decline calling `decide-onboarding-quiz`.
- ADD a send popup (extend the existing onboarding send UI in `EmployeeUniversalDocButtons.tsx` / Employees dashboard, or a new dialog): collects name+email, target team (from `list-team-groups`), after-pass toggle (DEFAULT = HR approves first), then calls mint + send-invite.

---

## BUILD ORDER (small, independently testable phases)
1. DB migration: 3 tables + GRANTs + RLS + updated_at triggers. (Questions seeded later.)
2. Edge fn `mint-onboarding-quiz-token` + read-after-write guard. Test via direct invoke.
3. Edge fn `validate-onboarding-quiz-token`. Test with a minted token.
4. Public page `OnboardingTest.tsx` + route — video gating + identity entry, no quiz yet. Visual QA in preview.
5. Seed the 11 questions (you paste them) into `onboarding_quiz_questions`.
6. Edge fn `submit-onboarding-quiz-attempt` (scoring, attempts, invalidation) + wire quiz UI + calm result screens. Test pass/fail/3-fail/identity paths.
7. Sylvia "Onboarding Test Results" tab.
8. HR Approval "Onboarding Test Approvals" section + `decide-onboarding-quiz`.
9. Send popup (mint + invite + team + after-pass toggle).
10. `send-onboarding-test-invite` email + `issue-next-project-invite` (auto + manual approve paths).
11. End-to-end test; then optional subdomain step.

## DOMAIN (optional, later)
Stays ONE project/one deployment. The page already works at `/onboarding-test/:token`. To add `onboarding.expertintuitiveadvisor.com`: add it as a Custom Domain in Lovable, create the Namecheap CNAME Lovable provides, wait for SSL — no data split, no second backend. The invite email base URL becomes configurable so it can emit either domain.

## RISKS / CONFIRM BEFORE BUILDING
1. Route name: `/onboarding-test/:token` (recommended) vs forcing literal `/onboarding/:token` (risks the live equipment form). Your call.
2. Identity hard-kill: invalidate on the FIRST name/email mismatch (typo = dead link, more support load) vs tolerate mismatches and only count quiz attempts. Confirm.
3. Questions storage: editable DB table (recommended, server-side scoring) vs hardcoded constant. Confirm.
4. "Next-step invite" on auto/approve: confirm exactly what gets sent (which email/template + which PMS bridge endpoint) so the invite is correct.
5. Sender config: confirm the exact from-address to use (`talent@careers.expertintuitiveadvisor.com` per handover vs the currently-used `talent@expertintuitiveadvisor.com`) and that it is verified in Resend.
6. Video host: confirm Cloudflare MP4 direct URL (HTML5 `<video>`), and whether a single stitched file or per-segment playlist.

Waiting for your approval (and answers to the 6 items) before writing any code.