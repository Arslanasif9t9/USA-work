UPDATE candidate_actions
SET round1_status='not_sent', round1_sent_at=NULL, round1_last_sent_at=NULL, round1_resend_count=0, round1_appointment_date=NULL,
    round2_status='not_sent', round2_sent_at=NULL, round2_last_sent_at=NULL, round2_resend_count=0, round2_appointment_date=NULL,
    offer_status='not_sent', offer_sent_at=NULL, offer_last_sent_at=NULL, offer_resend_count=0, offer_signed_at=NULL
WHERE id IN ('2850cf07-ee6b-46f6-8e53-20112062a981','5d2b6fb5-8866-4c5c-9329-7fd5272ed88a','d924b6d4-a449-4655-82a4-0839062e8a85');