ALTER TABLE public.rebook_tokens DROP CONSTRAINT IF EXISTS rebook_tokens_stage_check;

ALTER TABLE public.rebook_tokens ADD CONSTRAINT rebook_tokens_stage_check
  CHECK (stage = ANY (ARRAY['reschedule'::text, 'round1'::text, 'round2'::text, 'ai_scheduled'::text]));