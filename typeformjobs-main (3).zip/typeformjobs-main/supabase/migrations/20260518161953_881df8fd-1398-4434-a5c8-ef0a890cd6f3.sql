DELETE FROM answers WHERE response_id IN ('1ce5ca74-4ade-4757-a29e-0a7fc5e41d67','01b2d3e3-fc97-4add-ba0d-7a2aa709006e');
DELETE FROM candidate_actions WHERE response_id IN ('1ce5ca74-4ade-4757-a29e-0a7fc5e41d67','01b2d3e3-fc97-4add-ba0d-7a2aa709006e');
DELETE FROM responses WHERE id IN ('1ce5ca74-4ade-4757-a29e-0a7fc5e41d67','01b2d3e3-fc97-4add-ba0d-7a2aa709006e');