DROP POLICY IF EXISTS "answers_anon_insert_live" ON public.answers;
CREATE POLICY "answers_anon_insert_live"
ON public.answers FOR INSERT TO anon, authenticated
WITH CHECK (
  EXISTS (
    SELECT 1 FROM public.responses r
    JOIN public.forms f ON f.id = r.form_id
    WHERE r.id = answers.response_id AND f.status = 'live'
  )
);

DROP FUNCTION IF EXISTS public.whoami();