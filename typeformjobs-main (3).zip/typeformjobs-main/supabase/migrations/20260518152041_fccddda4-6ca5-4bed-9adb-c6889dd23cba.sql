
REVOKE EXECUTE ON FUNCTION public.create_candidate_actions_for_response() FROM PUBLIC, anon, authenticated;
