ALTER TABLE public.rebook_tokens
  ADD COLUMN IF NOT EXISTS stage TEXT NOT NULL DEFAULT 'reschedule',
  ADD COLUMN IF NOT EXISTS form_id UUID,
  ADD COLUMN IF NOT EXISTS assigned_hr_id UUID;

ALTER TABLE public.rebook_tokens
  ADD CONSTRAINT rebook_tokens_stage_check
  CHECK (stage IN ('reschedule','round1','round2'));

ALTER TABLE public.rebook_tokens
  ADD CONSTRAINT rebook_tokens_assigned_hr_fk
  FOREIGN KEY (assigned_hr_id) REFERENCES public.hr_users(id) ON DELETE SET NULL;

CREATE INDEX IF NOT EXISTS rebook_tokens_response_stage_idx
  ON public.rebook_tokens (response_id, stage) WHERE used_at IS NULL;