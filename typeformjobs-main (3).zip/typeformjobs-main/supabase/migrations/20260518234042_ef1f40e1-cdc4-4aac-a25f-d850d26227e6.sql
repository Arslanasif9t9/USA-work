-- Create assets bucket (public read, for fonts and shared static files)
INSERT INTO storage.buckets (id, name, public)
VALUES ('assets', 'assets', true)
ON CONFLICT (id) DO NOTHING;

-- Create offer-letters bucket (public read, for generated PDFs)
INSERT INTO storage.buckets (id, name, public)
VALUES ('offer-letters', 'offer-letters', true)
ON CONFLICT (id) DO NOTHING;

-- Public can read both buckets
CREATE POLICY "public read assets"
ON storage.objects FOR SELECT
USING (bucket_id = 'assets');

CREATE POLICY "public read offer-letters"
ON storage.objects FOR SELECT
USING (bucket_id = 'offer-letters');

-- Admins (authenticated users with role=admin) can manage both buckets
CREATE POLICY "admins insert assets"
ON storage.objects FOR INSERT TO authenticated
WITH CHECK (bucket_id IN ('assets','offer-letters') AND public.is_admin(auth.uid()));

CREATE POLICY "admins update assets"
ON storage.objects FOR UPDATE TO authenticated
USING (bucket_id IN ('assets','offer-letters') AND public.is_admin(auth.uid()))
WITH CHECK (bucket_id IN ('assets','offer-letters') AND public.is_admin(auth.uid()));

CREATE POLICY "admins delete assets"
ON storage.objects FOR DELETE TO authenticated
USING (bucket_id IN ('assets','offer-letters') AND public.is_admin(auth.uid()));