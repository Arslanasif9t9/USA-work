-- zoom_meetings
CREATE TABLE public.zoom_meetings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  candidate_id uuid,
  candidate_actions_id uuid REFERENCES public.candidate_actions(id) ON DELETE SET NULL,
  round int CHECK (round IN (1, 2)),
  zoom_meeting_id text NOT NULL UNIQUE,
  zoom_meeting_uuid text,
  topic text NOT NULL,
  start_time timestamptz NOT NULL,
  duration_minutes int NOT NULL DEFAULT 15,
  timezone text DEFAULT 'Asia/Manila',
  join_url text NOT NULL,
  password text,
  start_url text,
  status text NOT NULL DEFAULT 'scheduled' CHECK (status IN ('scheduled','started','finished','cancelled')),
  created_at timestamptz NOT NULL DEFAULT now(),
  last_synced_at timestamptz
);

CREATE INDEX idx_zoom_meetings_actions_round ON public.zoom_meetings(candidate_actions_id, round);
CREATE INDEX idx_zoom_meetings_meeting_id ON public.zoom_meetings(zoom_meeting_id);

ALTER TABLE public.zoom_meetings ENABLE ROW LEVEL SECURITY;

CREATE POLICY "admins select zoom_meetings" ON public.zoom_meetings
  FOR SELECT TO authenticated USING (auth.uid() IS NOT NULL);
CREATE POLICY "deny insert zoom_meetings" ON public.zoom_meetings
  FOR INSERT TO anon, authenticated WITH CHECK (false);
CREATE POLICY "deny update zoom_meetings" ON public.zoom_meetings
  FOR UPDATE TO anon, authenticated USING (false) WITH CHECK (false);
CREATE POLICY "deny delete zoom_meetings" ON public.zoom_meetings
  FOR DELETE TO anon, authenticated USING (false);

-- zoom_token_cache (single row)
CREATE TABLE public.zoom_token_cache (
  id int PRIMARY KEY DEFAULT 1 CHECK (id = 1),
  access_token text NOT NULL,
  expires_at timestamptz NOT NULL,
  updated_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.zoom_token_cache ENABLE ROW LEVEL SECURITY;

-- No policies for anon/authenticated = no access. Service role bypasses RLS.
CREATE POLICY "deny all zoom_token_cache" ON public.zoom_token_cache
  FOR ALL TO anon, authenticated USING (false) WITH CHECK (false);