
DROP POLICY IF EXISTS "admins select questions" ON public.questions;
DROP POLICY IF EXISTS "admins insert questions" ON public.questions;
DROP POLICY IF EXISTS "admins update questions" ON public.questions;
DROP POLICY IF EXISTS "admins delete questions" ON public.questions;

CREATE POLICY "admins select questions"
ON public.questions FOR SELECT
TO authenticated
USING (auth.uid() IS NOT NULL);

CREATE POLICY "admins insert questions"
ON public.questions FOR INSERT
TO authenticated
WITH CHECK (auth.uid() IS NOT NULL);

CREATE POLICY "admins update questions"
ON public.questions FOR UPDATE
TO authenticated
USING (auth.uid() IS NOT NULL)
WITH CHECK (auth.uid() IS NOT NULL);

CREATE POLICY "admins delete questions"
ON public.questions FOR DELETE
TO authenticated
USING (auth.uid() IS NOT NULL);
