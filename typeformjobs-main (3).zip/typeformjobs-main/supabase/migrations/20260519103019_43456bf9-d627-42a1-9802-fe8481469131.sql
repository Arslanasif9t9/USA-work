DROP POLICY IF EXISTS "Users can view their own form metadata" ON public.form_metadata;
DROP POLICY IF EXISTS "Users can insert their own form metadata" ON public.form_metadata;
DROP POLICY IF EXISTS "Users can update their own form metadata" ON public.form_metadata;
DROP POLICY IF EXISTS "Users can delete their own form metadata" ON public.form_metadata;

CREATE POLICY "admins select form metadata"
ON public.form_metadata
FOR SELECT
TO authenticated
USING (auth.uid() IS NOT NULL);

CREATE POLICY "admins insert form metadata"
ON public.form_metadata
FOR INSERT
TO authenticated
WITH CHECK (auth.uid() IS NOT NULL);

CREATE POLICY "admins update form metadata"
ON public.form_metadata
FOR UPDATE
TO authenticated
USING (auth.uid() IS NOT NULL)
WITH CHECK (auth.uid() IS NOT NULL);

CREATE POLICY "admins delete form metadata"
ON public.form_metadata
FOR DELETE
TO authenticated
USING (auth.uid() IS NOT NULL);