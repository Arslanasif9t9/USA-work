
-- =====================================================
-- TABLE: scheduling_config (singleton)
-- =====================================================
CREATE TABLE public.scheduling_config (
  id int PRIMARY KEY DEFAULT 1 CHECK (id = 1),
  working_days int[] NOT NULL DEFAULT '{1,2,3,4,5,6}',
  working_hours_start time NOT NULL DEFAULT '10:00',
  working_hours_end time NOT NULL DEFAULT '18:00',
  saturday_hours_start time NOT NULL DEFAULT '10:00',
  saturday_hours_end time NOT NULL DEFAULT '14:00',
  lock_days_ahead int NOT NULL DEFAULT 3,
  min_advance_hours int NOT NULL DEFAULT 1,
  slot_duration_minutes int NOT NULL DEFAULT 30,
  reservation_timer_minutes int NOT NULL DEFAULT 10,
  timezone text NOT NULL DEFAULT 'Asia/Manila',
  is_out_of_office boolean NOT NULL DEFAULT false,
  out_of_office_start date NULL,
  out_of_office_end date NULL,
  updated_at timestamptz NOT NULL DEFAULT now()
);

INSERT INTO public.scheduling_config (id) VALUES (1) ON CONFLICT DO NOTHING;

ALTER TABLE public.scheduling_config ENABLE ROW LEVEL SECURITY;

CREATE POLICY "admins read scheduling_config" ON public.scheduling_config
  FOR SELECT TO authenticated USING (auth.uid() IS NOT NULL);
CREATE POLICY "admins update scheduling_config" ON public.scheduling_config
  FOR UPDATE TO authenticated USING (auth.uid() IS NOT NULL) WITH CHECK (auth.uid() IS NOT NULL);

CREATE TRIGGER scheduling_config_set_updated_at
  BEFORE UPDATE ON public.scheduling_config
  FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

-- =====================================================
-- TABLE: hr_users
-- =====================================================
CREATE TABLE public.hr_users (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  email text UNIQUE NOT NULL,
  display_name text NOT NULL,
  role text NOT NULL DEFAULT 'hr' CHECK (role IN ('hr', 'master_admin')),
  is_active boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.hr_users ENABLE ROW LEVEL SECURITY;

CREATE POLICY "admins read hr_users" ON public.hr_users
  FOR SELECT TO authenticated USING (auth.uid() IS NOT NULL);

CREATE POLICY "master admin manage hr_users" ON public.hr_users
  FOR ALL TO authenticated
  USING (EXISTS (SELECT 1 FROM public.users u WHERE u.id = auth.uid() AND u.email = 'spark11179@gmail.com'))
  WITH CHECK (EXISTS (SELECT 1 FROM public.users u WHERE u.id = auth.uid() AND u.email = 'spark11179@gmail.com'));

INSERT INTO public.hr_users (email, display_name, role) VALUES
  ('hr1@expertintuitiveadvisor.com', 'HR1', 'hr'),
  ('hr2@expertintuitiveadvisor.com', 'HR2', 'hr'),
  ('spark11179@gmail.com', 'Master Admin', 'master_admin')
ON CONFLICT (email) DO NOTHING;

-- =====================================================
-- TABLE: interview_slots
-- =====================================================
CREATE TABLE public.interview_slots (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  slot_start timestamptz NOT NULL UNIQUE,
  slot_end timestamptz NOT NULL,
  slot_date date NOT NULL,
  slot_time time NOT NULL,
  status text NOT NULL DEFAULT 'available'
    CHECK (status IN ('available', 'reserved', 'booked', 'blocked', 'cancelled')),
  reserved_until timestamptz NULL,
  response_id uuid NULL,
  zoom_meeting_id uuid NULL,
  claimed_by_hr_id uuid NULL REFERENCES public.hr_users(id),
  claimed_at timestamptz NULL,
  completed_at timestamptz NULL,
  completion_method text NULL CHECK (completion_method IN ('manual', 'boss_override', 'no_show')),
  blocked_reason text NULL,
  created_by_admin boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX idx_interview_slots_date_status ON public.interview_slots (slot_date, status);
CREATE INDEX idx_interview_slots_status_reserved ON public.interview_slots (status, reserved_until);

ALTER TABLE public.interview_slots ENABLE ROW LEVEL SECURITY;

-- Public: only future available slots within 3 days (relaxed - filtering also done in edge functions)
CREATE POLICY "anon read available slots" ON public.interview_slots
  FOR SELECT TO anon
  USING (status = 'available' AND slot_start > now() + interval '1 hour' AND slot_start < now() + interval '4 days');

CREATE POLICY "admins read all slots" ON public.interview_slots
  FOR SELECT TO authenticated USING (auth.uid() IS NOT NULL);

CREATE POLICY "admins update slots" ON public.interview_slots
  FOR UPDATE TO authenticated USING (auth.uid() IS NOT NULL) WITH CHECK (auth.uid() IS NOT NULL);

-- No anon insert/update; only service role via edge functions

CREATE TRIGGER interview_slots_set_updated_at
  BEFORE UPDATE ON public.interview_slots
  FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

-- =====================================================
-- TABLE: password_audit_log
-- =====================================================
CREATE TABLE public.password_audit_log (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  password_used text NOT NULL,
  hr_user_id uuid NULL REFERENCES public.hr_users(id),
  action_taken text NOT NULL,
  target_resource_id uuid NULL,
  timestamp timestamptz NOT NULL DEFAULT now(),
  ip_address text NULL
);

CREATE INDEX idx_password_audit_timestamp ON public.password_audit_log (timestamp);
CREATE INDEX idx_password_audit_password ON public.password_audit_log (password_used);

ALTER TABLE public.password_audit_log ENABLE ROW LEVEL SECURITY;

CREATE POLICY "admins read password_audit_log" ON public.password_audit_log
  FOR SELECT TO authenticated USING (auth.uid() IS NOT NULL);
-- writes via service role only

-- =====================================================
-- TABLE: notification_log
-- =====================================================
CREATE TABLE public.notification_log (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  event_type text NOT NULL,
  recipient_email text NOT NULL,
  sent_at timestamptz NOT NULL DEFAULT now(),
  related_resource_id uuid NULL,
  status text NOT NULL DEFAULT 'sent' CHECK (status IN ('sent', 'failed'))
);

ALTER TABLE public.notification_log ENABLE ROW LEVEL SECURITY;

CREATE POLICY "admins read notification_log" ON public.notification_log
  FOR SELECT TO authenticated USING (auth.uid() IS NOT NULL);

-- =====================================================
-- responses table modifications
-- =====================================================
ALTER TABLE public.responses
  ADD COLUMN IF NOT EXISTS scheduled_slot_id uuid NULL,
  ADD COLUMN IF NOT EXISTS scheduled_at timestamptz NULL;

-- =====================================================
-- email_log stage CHECK update
-- =====================================================
ALTER TABLE public.email_log DROP CONSTRAINT IF EXISTS email_log_stage_check;
ALTER TABLE public.email_log ADD CONSTRAINT email_log_stage_check
  CHECK (stage = ANY (ARRAY[
    'stage_1_thank_you', 'stage_2_interview', 'stage_2_round_1', 'stage_2_round_2',
    'stage_3_offer', 'test', 'manual_resend', 'other',
    'stage_1_interview_confirmed', 'stage_recovery_email'
  ]));
