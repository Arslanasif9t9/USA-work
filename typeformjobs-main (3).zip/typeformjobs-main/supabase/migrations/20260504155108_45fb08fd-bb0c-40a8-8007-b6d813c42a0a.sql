
-- USERS
CREATE TABLE public.users (
  id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  email text UNIQUE NOT NULL,
  role text NOT NULL DEFAULT 'admin',
  created_at timestamptz NOT NULL DEFAULT now()
);

-- FORMS
CREATE TABLE public.forms (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL DEFAULT 'Untitled Form',
  slug text UNIQUE NOT NULL,
  description text,
  status text NOT NULL DEFAULT 'draft' CHECK (status IN ('draft','live')),
  created_by uuid NOT NULL REFERENCES public.users(id) ON DELETE CASCADE,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE OR REPLACE FUNCTION public.set_updated_at()
RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN NEW.updated_at = now(); RETURN NEW; END; $$;

CREATE TRIGGER forms_updated_at BEFORE UPDATE ON public.forms
FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

-- QUESTIONS
CREATE TABLE public.questions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  form_id uuid NOT NULL REFERENCES public.forms(id) ON DELETE CASCADE,
  type text NOT NULL CHECK (type IN ('welcome','short_text','long_text','email','phone','date','file_upload','yes_no','multiple_choice','dropdown','rating','legal_checkbox','thank_you')),
  label text NOT NULL,
  placeholder text,
  description text,
  required boolean NOT NULL DEFAULT false,
  options jsonb NOT NULL DEFAULT '[]'::jsonb,
  order_index integer NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX questions_form_order_idx ON public.questions(form_id, order_index);

-- RESPONSES
CREATE TABLE public.responses (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  form_id uuid NOT NULL REFERENCES public.forms(id) ON DELETE CASCADE,
  applicant_id uuid NOT NULL DEFAULT gen_random_uuid(),
  submitted_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX responses_form_idx ON public.responses(form_id);
CREATE INDEX responses_submitted_idx ON public.responses(submitted_at DESC);

-- ANSWERS
CREATE TABLE public.answers (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  response_id uuid NOT NULL REFERENCES public.responses(id) ON DELETE CASCADE,
  question_id uuid NOT NULL REFERENCES public.questions(id) ON DELETE CASCADE,
  answer_text text,
  file_url text
);
CREATE INDEX answers_response_idx ON public.answers(response_id);

-- ENABLE RLS
ALTER TABLE public.users ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.forms ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.questions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.responses ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.answers ENABLE ROW LEVEL SECURITY;

-- USERS policies
CREATE POLICY "users_select_own" ON public.users FOR SELECT TO authenticated USING (auth.uid() = id);

-- FORMS policies
CREATE POLICY "forms_auth_all" ON public.forms FOR ALL TO authenticated USING (true) WITH CHECK (true);
CREATE POLICY "forms_anon_select_live" ON public.forms FOR SELECT TO anon USING (status = 'live');

-- QUESTIONS policies
CREATE POLICY "questions_auth_all" ON public.questions FOR ALL TO authenticated USING (true) WITH CHECK (true);
CREATE POLICY "questions_anon_select_live" ON public.questions FOR SELECT TO anon
USING (EXISTS (SELECT 1 FROM public.forms f WHERE f.id = questions.form_id AND f.status = 'live'));

-- RESPONSES policies
CREATE POLICY "responses_auth_select" ON public.responses FOR SELECT TO authenticated USING (true);
CREATE POLICY "responses_auth_delete" ON public.responses FOR DELETE TO authenticated USING (true);
CREATE POLICY "responses_anon_insert_live" ON public.responses FOR INSERT TO anon
WITH CHECK (EXISTS (SELECT 1 FROM public.forms f WHERE f.id = responses.form_id AND f.status = 'live'));

-- ANSWERS policies
CREATE POLICY "answers_auth_select" ON public.answers FOR SELECT TO authenticated USING (true);
CREATE POLICY "answers_auth_delete" ON public.answers FOR DELETE TO authenticated USING (true);
CREATE POLICY "answers_anon_insert_live" ON public.answers FOR INSERT TO anon
WITH CHECK (EXISTS (
  SELECT 1 FROM public.responses r JOIN public.forms f ON f.id = r.form_id
  WHERE r.id = answers.response_id AND f.status = 'live'
));

-- STORAGE BUCKETS
INSERT INTO storage.buckets (id, name, public) VALUES ('resumes','resumes', false), ('selfies','selfies', false);

-- Storage policies
CREATE POLICY "buckets_auth_select" ON storage.objects FOR SELECT TO authenticated
USING (bucket_id IN ('resumes','selfies'));
CREATE POLICY "buckets_auth_delete" ON storage.objects FOR DELETE TO authenticated
USING (bucket_id IN ('resumes','selfies'));
CREATE POLICY "buckets_anon_insert" ON storage.objects FOR INSERT TO anon
WITH CHECK (bucket_id IN ('resumes','selfies'));
