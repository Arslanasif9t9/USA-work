CREATE TABLE public.employee_boards (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  response_id uuid,
  board_id text,
  board_name text,
  onboarding_notes text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX idx_employee_boards_response_id ON public.employee_boards(response_id);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.employee_boards TO authenticated;
GRANT ALL ON public.employee_boards TO service_role;

ALTER TABLE public.employee_boards ENABLE ROW LEVEL SECURITY;

CREATE POLICY "admins select employee_boards"
  ON public.employee_boards FOR SELECT TO authenticated
  USING (auth.uid() IS NOT NULL);

CREATE POLICY "admins insert employee_boards"
  ON public.employee_boards FOR INSERT TO authenticated
  WITH CHECK (auth.uid() IS NOT NULL);

CREATE POLICY "admins update employee_boards"
  ON public.employee_boards FOR UPDATE TO authenticated
  USING (auth.uid() IS NOT NULL)
  WITH CHECK (auth.uid() IS NOT NULL);

CREATE POLICY "service_role full access employee_boards"
  ON public.employee_boards FOR ALL TO service_role
  USING (true) WITH CHECK (true);

CREATE TRIGGER set_employee_boards_updated_at
  BEFORE UPDATE ON public.employee_boards
  FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();