
CREATE TABLE IF NOT EXISTS public.ai_interview_failures (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  response_id uuid,
  token text,
  device_type text,
  user_agent text,
  failure_stage text,
  audio_context_state text,
  retell_error text,
  created_at timestamp with time zone NOT NULL DEFAULT now()
);

ALTER TABLE public.ai_interview_failures ENABLE ROW LEVEL SECURITY;

CREATE POLICY "service_role full access ai_interview_failures"
ON public.ai_interview_failures
FOR ALL
TO service_role
USING (true)
WITH CHECK (true);

CREATE POLICY "admins read ai_interview_failures"
ON public.ai_interview_failures
FOR SELECT
TO authenticated
USING (auth.uid() IS NOT NULL);
