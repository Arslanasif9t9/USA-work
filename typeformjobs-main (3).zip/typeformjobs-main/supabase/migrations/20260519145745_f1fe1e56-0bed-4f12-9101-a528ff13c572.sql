
DROP POLICY IF EXISTS "anon update unused rebook token" ON public.rebook_tokens;

CREATE POLICY "anon mark rebook token used" ON public.rebook_tokens
  FOR UPDATE TO anon
  USING (used_at IS NULL AND expires_at > now())
  WITH CHECK (used_at IS NOT NULL);
