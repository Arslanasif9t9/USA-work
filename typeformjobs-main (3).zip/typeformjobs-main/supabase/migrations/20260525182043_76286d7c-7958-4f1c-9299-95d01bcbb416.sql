ALTER TABLE public.scheduling_config ADD COLUMN IF NOT EXISTS interview_mode text DEFAULT 'ai_direct';
UPDATE public.scheduling_config SET interview_mode = 'ai_direct' WHERE id = 1 AND interview_mode IS NULL;
ALTER TABLE public.candidate_actions ADD COLUMN IF NOT EXISTS round1_mode text;