-- Create leave_requests table
CREATE TABLE public.leave_requests (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  response_id uuid NULL,
  external_reference text NOT NULL UNIQUE,
  signer_name text,
  signer_email text,
  token text UNIQUE,
  token_expires_at timestamptz NOT NULL DEFAULT (now() + interval '14 days'),
  token_used_at timestamptz NULL,
  reason text,
  start_date text,
  num_days text,
  hours_missed text,
  makeup_plan text,
  makeup_choice text,
  coverer_name text,
  agreed_with_coverer boolean,
  trained_coverer boolean,
  typed_name text,
  signature_data text,
  signature_date text,
  signed_pdf_url text NULL,
  status text NOT NULL DEFAULT 'invited' CHECK (status IN ('invited','pending_approval','approved','declined')),
  hr_decision_note text NULL,
  decided_by_hr_id uuid NULL,
  decided_at timestamptz NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

-- Grants — auth-only (no anon)
GRANT SELECT ON public.leave_requests TO authenticated;
GRANT ALL ON public.leave_requests TO service_role;

-- RLS
ALTER TABLE public.leave_requests ENABLE ROW LEVEL SECURITY;

CREATE POLICY "authenticated read leave_requests"
  ON public.leave_requests FOR SELECT
  TO authenticated
  USING (auth.uid() IS NOT NULL);

CREATE POLICY "service_role full access leave_requests"
  ON public.leave_requests FOR ALL
  TO service_role
  USING (true) WITH CHECK (true);

-- Indexes
CREATE INDEX idx_leave_requests_token ON public.leave_requests(token);
CREATE INDEX idx_leave_requests_response_id ON public.leave_requests(response_id);
CREATE INDEX idx_leave_requests_status ON public.leave_requests(status);

-- updated_at trigger (reuse existing set_updated_at)
CREATE TRIGGER trg_leave_requests_updated_at
  BEFORE UPDATE ON public.leave_requests
  FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

-- Additively extend email_log stage check to include the three new leave stages
ALTER TABLE public.email_log DROP CONSTRAINT IF EXISTS email_log_stage_check;
ALTER TABLE public.email_log ADD CONSTRAINT email_log_stage_check CHECK (stage = ANY (ARRAY[
  'stage_1_thank_you'::text,
  'stage_2_interview'::text,
  'stage_2_round_1'::text,
  'stage_2_round_2'::text,
  'stage_2_round_1_invite'::text,
  'stage_2_round_2_invite'::text,
  'stage_3_offer'::text,
  'test'::text,
  'manual_resend'::text,
  'other'::text,
  'stage_1_interview_confirmed'::text,
  'stage_recovery_email'::text,
  'migration_test'::text,
  'onboarding_nda_sent'::text,
  'onboarding_equipment_instructions'::text,
  'stage_termination_evaluation'::text,
  'stage_termination_regular'::text,
  'settlement_sent'::text,
  'leave_form_sent'::text,
  'leave_approved'::text,
  'leave_declined'::text
]));