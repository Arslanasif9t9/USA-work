
CREATE TABLE public.onboarding_tokens (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  token text NOT NULL UNIQUE,
  response_id uuid NOT NULL,
  candidate_email text,
  candidate_name text,
  position_title text,
  created_at timestamptz NOT NULL DEFAULT now(),
  expires_at timestamptz NOT NULL DEFAULT (now() + interval '30 days'),
  used_at timestamptz,
  closed_at timestamptz
);

GRANT SELECT ON public.onboarding_tokens TO anon;
GRANT SELECT ON public.onboarding_tokens TO authenticated;
GRANT ALL ON public.onboarding_tokens TO service_role;

ALTER TABLE public.onboarding_tokens ENABLE ROW LEVEL SECURITY;

CREATE POLICY "anon read onboarding token by value"
  ON public.onboarding_tokens FOR SELECT TO anon USING (true);

CREATE POLICY "admins read onboarding_tokens"
  ON public.onboarding_tokens FOR SELECT TO authenticated USING (auth.uid() IS NOT NULL);

CREATE INDEX idx_onboarding_tokens_response_id ON public.onboarding_tokens(response_id);

CREATE TABLE public.onboarding_submissions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  response_id uuid NOT NULL UNIQUE,
  full_name text,
  email text,
  position_title text,
  phone text,
  profile_photo_url text,
  speedtest_screenshot_url text,
  typing_screenshot_url text,
  submitted_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

GRANT SELECT ON public.onboarding_submissions TO authenticated;
GRANT ALL ON public.onboarding_submissions TO service_role;

ALTER TABLE public.onboarding_submissions ENABLE ROW LEVEL SECURITY;

CREATE POLICY "admins read onboarding_submissions"
  ON public.onboarding_submissions FOR SELECT TO authenticated USING (auth.uid() IS NOT NULL);

CREATE INDEX idx_onboarding_submissions_response_id ON public.onboarding_submissions(response_id);

CREATE TRIGGER trg_onboarding_submissions_updated_at
  BEFORE UPDATE ON public.onboarding_submissions
  FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();
