
ALTER TABLE public.responses
  ADD COLUMN IF NOT EXISTS disqualified_at timestamptz NULL,
  ADD COLUMN IF NOT EXISTS disqualified_by_hr_id uuid NULL REFERENCES public.hr_users(id) ON DELETE SET NULL;

CREATE INDEX IF NOT EXISTS responses_round_stage_idx ON public.responses(round_stage);
