
REVOKE EXECUTE ON FUNCTION public.validate_scheduling_config() FROM PUBLIC, anon, authenticated;
