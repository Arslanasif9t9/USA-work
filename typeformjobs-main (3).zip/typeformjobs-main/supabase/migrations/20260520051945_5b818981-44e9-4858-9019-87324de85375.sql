ALTER TABLE public.hr_users ADD COLUMN IF NOT EXISTS nickname text;
UPDATE public.hr_users SET nickname = 'Cherry' WHERE display_name = 'HR1';
UPDATE public.hr_users SET nickname = 'Angel'  WHERE display_name = 'HR2';