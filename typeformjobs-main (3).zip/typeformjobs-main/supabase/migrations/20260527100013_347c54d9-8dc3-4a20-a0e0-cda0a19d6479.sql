
ALTER TABLE public.scheduling_config ADD COLUMN IF NOT EXISTS sylvia_daily_brief text;
ALTER TABLE public.employee_boards ADD COLUMN IF NOT EXISTS assigned_agent text;
