
CREATE TABLE IF NOT EXISTS public.candidate_actions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  candidate_id uuid NOT NULL,
  form_id uuid NOT NULL,
  response_id uuid UNIQUE,
  round1_status text NOT NULL DEFAULT 'not_sent' CHECK (round1_status IN ('not_sent','sent')),
  round1_sent_at timestamptz,
  round1_last_sent_at timestamptz,
  round1_resend_count int NOT NULL DEFAULT 0,
  round1_appointment_date timestamptz,
  round1_zoom_meeting_id text,
  round1_zoom_join_url text,
  round2_status text NOT NULL DEFAULT 'not_sent' CHECK (round2_status IN ('not_sent','sent')),
  round2_sent_at timestamptz,
  round2_last_sent_at timestamptz,
  round2_resend_count int NOT NULL DEFAULT 0,
  round2_appointment_date timestamptz,
  round2_zoom_meeting_id text,
  round2_zoom_join_url text,
  offer_status text NOT NULL DEFAULT 'not_sent' CHECK (offer_status IN ('not_sent','sent','signed')),
  offer_sent_at timestamptz,
  offer_last_sent_at timestamptz,
  offer_resend_count int NOT NULL DEFAULT 0,
  offer_signed_at timestamptz,
  job_offer_id uuid,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (candidate_id, form_id)
);

CREATE INDEX IF NOT EXISTS candidate_actions_form_id_idx ON public.candidate_actions(form_id);
CREATE INDEX IF NOT EXISTS candidate_actions_status_idx ON public.candidate_actions(round1_status, round2_status, offer_status);

ALTER TABLE public.candidate_actions ENABLE ROW LEVEL SECURITY;

CREATE POLICY "admins select candidate_actions" ON public.candidate_actions
  FOR SELECT TO authenticated USING (auth.uid() IS NOT NULL);
CREATE POLICY "admins insert candidate_actions" ON public.candidate_actions
  FOR INSERT TO authenticated WITH CHECK (auth.uid() IS NOT NULL);
CREATE POLICY "admins update candidate_actions" ON public.candidate_actions
  FOR UPDATE TO authenticated USING (auth.uid() IS NOT NULL) WITH CHECK (auth.uid() IS NOT NULL);
CREATE POLICY "deny delete candidate_actions" ON public.candidate_actions
  FOR DELETE TO authenticated, anon USING (false);

CREATE TRIGGER candidate_actions_updated_at
  BEFORE UPDATE ON public.candidate_actions
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE OR REPLACE FUNCTION public.create_candidate_actions_for_response()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  INSERT INTO public.candidate_actions (candidate_id, form_id, response_id)
  VALUES (NEW.applicant_id, NEW.form_id, NEW.id)
  ON CONFLICT (response_id) DO NOTHING;
  RETURN NEW;
END;
$$;

CREATE TRIGGER responses_create_candidate_actions
  AFTER INSERT ON public.responses
  FOR EACH ROW EXECUTE FUNCTION public.create_candidate_actions_for_response();

INSERT INTO public.candidate_actions (candidate_id, form_id, response_id)
SELECT r.applicant_id, r.form_id, r.id
FROM public.responses r
LEFT JOIN public.candidate_actions ca ON ca.response_id = r.id
WHERE ca.id IS NULL;
