
-- ============ FORMS ============
DROP POLICY IF EXISTS "forms_admin_all" ON public.forms;
CREATE POLICY "admins select forms" ON public.forms FOR SELECT TO authenticated USING (auth.uid() IS NOT NULL);
CREATE POLICY "admins insert forms" ON public.forms FOR INSERT TO authenticated WITH CHECK (auth.uid() IS NOT NULL AND created_by = auth.uid());
CREATE POLICY "admins update forms" ON public.forms FOR UPDATE TO authenticated USING (auth.uid() IS NOT NULL) WITH CHECK (auth.uid() IS NOT NULL);
CREATE POLICY "admins delete forms" ON public.forms FOR DELETE TO authenticated USING (auth.uid() IS NOT NULL);

-- ============ QUESTIONS ============
DROP POLICY IF EXISTS "questions_admin_all" ON public.questions;
CREATE POLICY "admins select questions" ON public.questions FOR SELECT TO authenticated
USING (auth.uid() IS NOT NULL AND EXISTS (SELECT 1 FROM public.forms f WHERE f.id = questions.form_id AND f.created_by = auth.uid()));
CREATE POLICY "admins insert questions" ON public.questions FOR INSERT TO authenticated
WITH CHECK (auth.uid() IS NOT NULL AND EXISTS (SELECT 1 FROM public.forms f WHERE f.id = questions.form_id AND f.created_by = auth.uid()));
CREATE POLICY "admins update questions" ON public.questions FOR UPDATE TO authenticated
USING (auth.uid() IS NOT NULL AND EXISTS (SELECT 1 FROM public.forms f WHERE f.id = questions.form_id AND f.created_by = auth.uid()))
WITH CHECK (auth.uid() IS NOT NULL AND EXISTS (SELECT 1 FROM public.forms f WHERE f.id = questions.form_id AND f.created_by = auth.uid()));
CREATE POLICY "admins delete questions" ON public.questions FOR DELETE TO authenticated
USING (auth.uid() IS NOT NULL AND EXISTS (SELECT 1 FROM public.forms f WHERE f.id = questions.form_id AND f.created_by = auth.uid()));

-- ============ RESPONSES ============
DROP POLICY IF EXISTS "responses_auth_select" ON public.responses;
DROP POLICY IF EXISTS "responses_admin_delete" ON public.responses;
CREATE POLICY "admins select responses" ON public.responses FOR SELECT TO authenticated USING (auth.uid() IS NOT NULL);
CREATE POLICY "admins delete responses" ON public.responses FOR DELETE TO authenticated USING (auth.uid() IS NOT NULL);

-- ============ ANSWERS ============
DROP POLICY IF EXISTS "answers_auth_select" ON public.answers;
DROP POLICY IF EXISTS "answers_admin_delete" ON public.answers;
CREATE POLICY "admins select answers" ON public.answers FOR SELECT TO authenticated USING (auth.uid() IS NOT NULL);
CREATE POLICY "admins delete answers" ON public.answers FOR DELETE TO authenticated USING (auth.uid() IS NOT NULL);

-- ============ USERS ============ (deny client writes)
CREATE POLICY "users deny insert" ON public.users FOR INSERT TO authenticated, anon WITH CHECK (false);
CREATE POLICY "users deny update" ON public.users FOR UPDATE TO authenticated, anon USING (false) WITH CHECK (false);
CREATE POLICY "users deny delete" ON public.users FOR DELETE TO authenticated, anon USING (false);

-- ============ FUNCTIONS (search_path) ============
CREATE OR REPLACE FUNCTION public.set_updated_at()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN NEW.updated_at = now(); RETURN NEW; END; $$;

CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  INSERT INTO public.users (id, email, role)
  VALUES (NEW.id, NEW.email, 'admin')
  ON CONFLICT (id) DO NOTHING;
  RETURN NEW;
END; $$;

DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- ============ STORAGE ============
DROP POLICY IF EXISTS "buckets_auth_select" ON storage.objects;
DROP POLICY IF EXISTS "buckets_auth_delete" ON storage.objects;
DROP POLICY IF EXISTS "buckets_anon_insert" ON storage.objects;

-- resumes
CREATE POLICY "anon can upload resumes" ON storage.objects FOR INSERT TO anon WITH CHECK (bucket_id = 'resumes');
CREATE POLICY "admin can read resumes" ON storage.objects FOR SELECT TO authenticated USING (bucket_id = 'resumes' AND auth.uid() IS NOT NULL);
CREATE POLICY "admin can delete resumes" ON storage.objects FOR DELETE TO authenticated USING (bucket_id = 'resumes' AND auth.uid() IS NOT NULL);

-- selfies
CREATE POLICY "anon can upload selfies" ON storage.objects FOR INSERT TO anon WITH CHECK (bucket_id = 'selfies');
CREATE POLICY "admin can read selfies" ON storage.objects FOR SELECT TO authenticated USING (bucket_id = 'selfies' AND auth.uid() IS NOT NULL);
CREATE POLICY "admin can delete selfies" ON storage.objects FOR DELETE TO authenticated USING (bucket_id = 'selfies' AND auth.uid() IS NOT NULL);

-- Ensure buckets are private
UPDATE storage.buckets SET public = false WHERE id IN ('resumes','selfies');
