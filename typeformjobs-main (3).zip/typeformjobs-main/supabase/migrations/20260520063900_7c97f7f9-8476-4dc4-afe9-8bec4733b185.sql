ALTER TABLE public.candidate_actions
  ADD COLUMN IF NOT EXISTS round1_reminder_sent_at timestamptz,
  ADD COLUMN IF NOT EXISTS round2_reminder_sent_at timestamptz;

CREATE INDEX IF NOT EXISTS idx_candidate_actions_round1_reminder
  ON public.candidate_actions (round1_appointment_date)
  WHERE round1_appointment_date IS NOT NULL AND round1_reminder_sent_at IS NULL;

CREATE INDEX IF NOT EXISTS idx_candidate_actions_round2_reminder
  ON public.candidate_actions (round2_appointment_date)
  WHERE round2_appointment_date IS NOT NULL AND round2_reminder_sent_at IS NULL;