-- Unified bucket for all candidate uploads (photos, resumes, docs, etc.)
INSERT INTO storage.buckets (id, name, public, file_size_limit)
VALUES ('candidate-files', 'candidate-files', false, 26214400)
ON CONFLICT (id) DO NOTHING;

-- Anyone filling a live form can upload to candidate-files
DROP POLICY IF EXISTS "candidate_files_anon_insert" ON storage.objects;
CREATE POLICY "candidate_files_anon_insert"
ON storage.objects
FOR INSERT
TO anon, authenticated
WITH CHECK (bucket_id = 'candidate-files');

-- Admins (any authenticated user in this app) can read/manage uploaded files
DROP POLICY IF EXISTS "candidate_files_auth_select" ON storage.objects;
CREATE POLICY "candidate_files_auth_select"
ON storage.objects
FOR SELECT
TO authenticated
USING (bucket_id = 'candidate-files');

DROP POLICY IF EXISTS "candidate_files_auth_update" ON storage.objects;
CREATE POLICY "candidate_files_auth_update"
ON storage.objects
FOR UPDATE
TO authenticated
USING (bucket_id = 'candidate-files')
WITH CHECK (bucket_id = 'candidate-files');

DROP POLICY IF EXISTS "candidate_files_auth_delete" ON storage.objects;
CREATE POLICY "candidate_files_auth_delete"
ON storage.objects
FOR DELETE
TO authenticated
USING (bucket_id = 'candidate-files');