ALTER TABLE public.ai_interview_sessions ALTER COLUMN response_id DROP NOT NULL;
ALTER TABLE public.ai_interview_evaluations ALTER COLUMN response_id DROP NOT NULL;