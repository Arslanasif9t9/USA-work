-- 1. forms.created_by: CASCADE -> SET NULL (and make column nullable)
ALTER TABLE public.forms ALTER COLUMN created_by DROP NOT NULL;
ALTER TABLE public.forms DROP CONSTRAINT forms_created_by_fkey;
ALTER TABLE public.forms
  ADD CONSTRAINT forms_created_by_fkey
  FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;

-- 2. public.users.id: CASCADE -> NO ACTION (id is PK, cannot be SET NULL)
ALTER TABLE public.users DROP CONSTRAINT users_id_fkey;
ALTER TABLE public.users
  ADD CONSTRAINT users_id_fkey
  FOREIGN KEY (id) REFERENCES auth.users(id) ON DELETE NO ACTION;