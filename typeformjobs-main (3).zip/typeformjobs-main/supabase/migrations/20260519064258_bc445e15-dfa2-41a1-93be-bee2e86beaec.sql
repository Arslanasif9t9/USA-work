DROP POLICY IF EXISTS "anon update rebook_tokens used" ON public.rebook_tokens;
DROP POLICY IF EXISTS "anon select rebook_tokens by token" ON public.rebook_tokens;
-- Edge functions use service role; anon never needs direct access.