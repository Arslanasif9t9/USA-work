CREATE POLICY "responses_anon_select_live"
ON public.responses FOR SELECT TO anon
USING (
  EXISTS (SELECT 1 FROM public.forms f WHERE f.id = responses.form_id AND f.status = 'live')
);