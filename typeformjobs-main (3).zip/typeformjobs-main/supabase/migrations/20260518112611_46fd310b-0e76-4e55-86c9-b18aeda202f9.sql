
-- 1) job_scope_library
CREATE TABLE public.job_scope_library (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  text text NOT NULL,
  category text NOT NULL DEFAULT 'General',
  created_by uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  usage_count int NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE UNIQUE INDEX job_scope_library_lower_text_uniq ON public.job_scope_library (LOWER(text));
CREATE INDEX job_scope_library_category_idx ON public.job_scope_library (category);

ALTER TABLE public.job_scope_library ENABLE ROW LEVEL SECURITY;

CREATE POLICY "auth select scope library" ON public.job_scope_library
  FOR SELECT TO authenticated USING (auth.uid() IS NOT NULL);
CREATE POLICY "auth insert scope library" ON public.job_scope_library
  FOR INSERT TO authenticated WITH CHECK (auth.uid() IS NOT NULL);
CREATE POLICY "auth update scope library" ON public.job_scope_library
  FOR UPDATE TO authenticated USING (auth.uid() IS NOT NULL) WITH CHECK (auth.uid() IS NOT NULL);
CREATE POLICY "auth delete scope library" ON public.job_scope_library
  FOR DELETE TO authenticated USING (auth.uid() IS NOT NULL);

-- 2) job_offers
CREATE SEQUENCE IF NOT EXISTS public.offer_ref_seq START 1;

CREATE OR REPLACE FUNCTION public.generate_offer_reference_id()
RETURNS text
LANGUAGE sql
VOLATILE
SET search_path = public
AS $$
  SELECT 'EIA-' || to_char(now(), 'YYYY') || '-' || lpad(nextval('public.offer_ref_seq')::text, 4, '0');
$$;

CREATE TABLE public.job_offers (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  candidate_id uuid,
  form_id uuid NOT NULL,
  position_title text NOT NULL,
  candidate_name text NOT NULL,
  candidate_email text NOT NULL,
  start_date date,
  trial_weeks int NOT NULL DEFAULT 4,
  trial_weekly_salary numeric NOT NULL,
  post_trial_weekly_salary numeric NOT NULL,
  monthly_range_min numeric,
  monthly_range_max numeric,
  raise_applied boolean NOT NULL DEFAULT true,
  currency text NOT NULL DEFAULT 'PHP' CHECK (currency IN ('PHP', 'USD')),
  schedule_preset_used text,
  weekday_start time,
  weekday_end time,
  saturday_start time,
  saturday_end time,
  sunday_off boolean NOT NULL DEFAULT true,
  scope_items jsonb NOT NULL DEFAULT '[]'::jsonb,
  internal_notes text,
  offer_reference_id text NOT NULL UNIQUE DEFAULT public.generate_offer_reference_id(),
  duplicated_from_offer_id uuid REFERENCES public.job_offers(id) ON DELETE SET NULL,
  parallel_group_id uuid,
  signing_token text UNIQUE,
  status text NOT NULL DEFAULT 'draft' CHECK (status IN ('draft','sent','viewed','signed','withdrawn')),
  created_at timestamptz NOT NULL DEFAULT now(),
  sent_at timestamptz,
  signed_at timestamptz
);

CREATE INDEX job_offers_form_status_idx ON public.job_offers (form_id, status);
CREATE INDEX job_offers_parallel_group_idx ON public.job_offers (parallel_group_id);
CREATE INDEX job_offers_reference_idx ON public.job_offers (offer_reference_id);
CREATE INDEX job_offers_candidate_email_idx ON public.job_offers (candidate_email);

ALTER TABLE public.job_offers ENABLE ROW LEVEL SECURITY;

CREATE POLICY "owners select offers" ON public.job_offers
  FOR SELECT TO authenticated
  USING (EXISTS (SELECT 1 FROM public.forms f WHERE f.id = job_offers.form_id AND f.created_by = auth.uid()));

CREATE POLICY "owners insert offers" ON public.job_offers
  FOR INSERT TO authenticated
  WITH CHECK (EXISTS (SELECT 1 FROM public.forms f WHERE f.id = job_offers.form_id AND f.created_by = auth.uid()));

CREATE POLICY "owners update offers" ON public.job_offers
  FOR UPDATE TO authenticated
  USING (EXISTS (SELECT 1 FROM public.forms f WHERE f.id = job_offers.form_id AND f.created_by = auth.uid()))
  WITH CHECK (EXISTS (SELECT 1 FROM public.forms f WHERE f.id = job_offers.form_id AND f.created_by = auth.uid()));

CREATE POLICY "owners delete offers" ON public.job_offers
  FOR DELETE TO authenticated
  USING (EXISTS (SELECT 1 FROM public.forms f WHERE f.id = job_offers.form_id AND f.created_by = auth.uid()));

-- 3) Prevent deleting a scope library item still referenced in any offer.scope_items snapshot
CREATE OR REPLACE FUNCTION public.prevent_used_scope_library_delete()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  used_count int;
BEGIN
  SELECT count(*) INTO used_count
  FROM public.job_offers o
  WHERE EXISTS (
    SELECT 1 FROM jsonb_array_elements_text(o.scope_items) AS s(val)
    WHERE LOWER(s.val) = LOWER(OLD.text)
  );
  IF used_count > 0 THEN
    RAISE EXCEPTION 'Cannot delete — used in % past offer(s)', used_count
      USING ERRCODE = 'P0001';
  END IF;
  RETURN OLD;
END;
$$;

CREATE TRIGGER trg_prevent_used_scope_library_delete
BEFORE DELETE ON public.job_scope_library
FOR EACH ROW EXECUTE FUNCTION public.prevent_used_scope_library_delete();

-- 4) form_metadata default scope ids
ALTER TABLE public.form_metadata
  ADD COLUMN default_job_scope_item_ids uuid[] NOT NULL DEFAULT '{}'::uuid[];

-- 5) Seed library (case-insensitive dedup via unique index)
INSERT INTO public.job_scope_library (text, category) VALUES
  ('Manage real estate lead pipeline in CRM', 'Real Estate'),
  ('Qualify inbound leads using MMASP framework', 'Real Estate'),
  ('Schedule property showings and follow-ups', 'Real Estate'),
  ('Update property listings and MLS data', 'Real Estate'),
  ('Coordinate with title companies and inspectors', 'Real Estate'),
  ('Send follow-up SMS and email sequences', 'Real Estate'),
  ('Manage Shopify product listings and inventory', 'E-commerce'),
  ('Process customer support tickets via email and chat', 'E-commerce'),
  ('Handle order fulfillment and shipping coordination', 'E-commerce'),
  ('Run product research and competitor analysis', 'E-commerce'),
  ('Update product descriptions and images', 'E-commerce'),
  ('Schedule and post content across social media platforms', 'Marketing'),
  ('Manage cold email campaigns in Instantly or Smartlead', 'Marketing'),
  ('Build and maintain lead lists in Apollo or Clay', 'Marketing'),
  ('Track campaign performance and report weekly KPIs', 'Marketing'),
  ('Create marketing copy variations for A/B testing', 'Marketing'),
  ('Conduct market research and competitor analysis', 'Research'),
  ('Build prospect lists with enriched contact data', 'Research'),
  ('Research industry trends and create briefings', 'Research'),
  ('Extract data from PDFs and web sources', 'Research'),
  ('Manage executive calendar and meeting scheduling', 'Admin Support'),
  ('Process inbox management and email triage', 'Admin Support'),
  ('Prepare meeting agendas and follow-up notes', 'Admin Support'),
  ('Maintain CRM hygiene and data quality', 'Admin Support'),
  ('Generate weekly reports and dashboards', 'Admin Support'),
  ('Build and refine AI workflows using Claude.ai', 'AI & Tools'),
  ('Create and manage prompts for repetitive tasks', 'AI & Tools'),
  ('Use AI tools for content generation and editing', 'AI & Tools'),
  ('Automate data entry using AI agents', 'AI & Tools'),
  ('Attend daily standup meetings', 'General'),
  ('Document processes in company knowledge base', 'General'),
  ('Coordinate with team members via Slack and email', 'General')
ON CONFLICT (LOWER(text)) DO NOTHING;
