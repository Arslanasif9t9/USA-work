
-- 1. New out_of_office_periods table
CREATE TABLE public.out_of_office_periods (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  start_date date NOT NULL,
  end_date date NOT NULL,
  reason text,
  enabled_by_hr_id uuid REFERENCES public.hr_users(id) ON DELETE SET NULL,
  enabled_at timestamptz NOT NULL DEFAULT now(),
  disabled_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT ooo_date_range_valid CHECK (end_date >= start_date)
);

CREATE INDEX idx_ooo_active ON public.out_of_office_periods (disabled_at, start_date, end_date);

ALTER TABLE public.out_of_office_periods ENABLE ROW LEVEL SECURITY;

CREATE POLICY "admins all ooo" ON public.out_of_office_periods
  FOR ALL TO authenticated
  USING (auth.uid() IS NOT NULL)
  WITH CHECK (auth.uid() IS NOT NULL);

CREATE POLICY "anon read active ooo" ON public.out_of_office_periods
  FOR SELECT TO anon
  USING (disabled_at IS NULL AND end_date >= CURRENT_DATE);

CREATE TRIGGER ooo_set_updated_at
  BEFORE UPDATE ON public.out_of_office_periods
  FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

-- 2. interview_slots: add OOO flags
ALTER TABLE public.interview_slots
  ADD COLUMN IF NOT EXISTS cancelled_due_to_ooo boolean NOT NULL DEFAULT false,
  ADD COLUMN IF NOT EXISTS ooo_period_id uuid REFERENCES public.out_of_office_periods(id) ON DELETE SET NULL;

-- 3. scheduling_config: pointer to current OOO period
ALTER TABLE public.scheduling_config
  ADD COLUMN IF NOT EXISTS ooo_active_period_id uuid REFERENCES public.out_of_office_periods(id) ON DELETE SET NULL;

-- 4. rebook_tokens: extend existing table
ALTER TABLE public.rebook_tokens
  ADD COLUMN IF NOT EXISTS candidate_email text,
  ADD COLUMN IF NOT EXISTS candidate_name text,
  ADD COLUMN IF NOT EXISTS new_slot_id uuid REFERENCES public.interview_slots(id) ON DELETE SET NULL;

CREATE UNIQUE INDEX IF NOT EXISTS rebook_tokens_token_uidx ON public.rebook_tokens (token);

-- Allow anonymous candidates to read their token by exact match (used by /rebook/:token page)
CREATE POLICY "anon read rebook token by value" ON public.rebook_tokens
  FOR SELECT TO anon
  USING (true);

-- Allow anonymous candidates to mark token as used (set used_at + new_slot_id) only if currently unused
CREATE POLICY "anon update unused rebook token" ON public.rebook_tokens
  FOR UPDATE TO anon
  USING (used_at IS NULL AND expires_at > now())
  WITH CHECK (true);
