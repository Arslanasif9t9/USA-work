ALTER TABLE public.candidate_actions REPLICA IDENTITY FULL;
DO $$ BEGIN
  BEGIN
    ALTER PUBLICATION supabase_realtime ADD TABLE public.candidate_actions;
  EXCEPTION WHEN duplicate_object THEN NULL;
  END;
END $$;