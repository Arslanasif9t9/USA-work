ALTER TABLE public.email_log DROP CONSTRAINT IF EXISTS email_log_stage_check;
ALTER TABLE public.email_log ADD CONSTRAINT email_log_stage_check
  CHECK (stage = ANY (ARRAY[
    'stage_1_thank_you'::text,
    'stage_2_interview'::text,
    'stage_2_round_1'::text,
    'stage_2_round_2'::text,
    'stage_3_offer'::text,
    'test'::text,
    'manual_resend'::text,
    'other'::text
  ]));