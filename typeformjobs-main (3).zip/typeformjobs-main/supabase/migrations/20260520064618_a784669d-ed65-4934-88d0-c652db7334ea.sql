ALTER TABLE public.candidate_actions
  ADD COLUMN IF NOT EXISTS round1_reminder_30_sent_at timestamptz,
  ADD COLUMN IF NOT EXISTS round1_reminder_15_sent_at timestamptz,
  ADD COLUMN IF NOT EXISTS round2_reminder_30_sent_at timestamptz,
  ADD COLUMN IF NOT EXISTS round2_reminder_15_sent_at timestamptz;