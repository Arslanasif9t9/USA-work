
-- Raise bucket-level size limit to 60MB (>= app max of 50MB)
UPDATE storage.buckets SET file_size_limit = 62914560
WHERE id IN ('resumes','selfies','candidate-selfies');

-- Make sure anon INSERT policies exist (idempotent)
DROP POLICY IF EXISTS "anon can upload resumes" ON storage.objects;
CREATE POLICY "anon can upload resumes"
  ON storage.objects FOR INSERT TO anon, authenticated
  WITH CHECK (bucket_id = 'resumes');

DROP POLICY IF EXISTS "anon can upload selfies" ON storage.objects;
CREATE POLICY "anon can upload selfies"
  ON storage.objects FOR INSERT TO anon, authenticated
  WITH CHECK (bucket_id = 'selfies');

DROP POLICY IF EXISTS "candidate_selfies_anon_insert" ON storage.objects;
CREATE POLICY "candidate_selfies_anon_insert"
  ON storage.objects FOR INSERT TO anon, authenticated
  WITH CHECK (bucket_id = 'candidate-selfies');
