ALTER TABLE public.hr_users
  ADD COLUMN IF NOT EXISTS personal_meeting_url text,
  ADD COLUMN IF NOT EXISTS personal_meeting_password text,
  ADD COLUMN IF NOT EXISTS zoom_pmi text,
  ADD COLUMN IF NOT EXISTS zoom_user_id text,
  ADD COLUMN IF NOT EXISTS zoom_user_email text;