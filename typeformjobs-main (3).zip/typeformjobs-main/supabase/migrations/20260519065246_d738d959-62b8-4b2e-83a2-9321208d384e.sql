-- Fix regression: anon answer inserts failing despite policy looking correct.
-- Recreate policy with explicit form_id propagation that's easier for the planner.

DROP POLICY IF EXISTS "answers_anon_insert_live" ON public.answers;

CREATE POLICY "answers_anon_insert_live"
ON public.answers
FOR INSERT
TO anon, authenticated
WITH CHECK (
  EXISTS (
    SELECT 1
    FROM public.responses r
    WHERE r.id = answers.response_id
      AND EXISTS (
        SELECT 1 FROM public.forms f
        WHERE f.id = r.form_id AND f.status = 'live'
      )
  )
);