
CREATE OR REPLACE FUNCTION public.update_updated_at_column()
RETURNS TRIGGER LANGUAGE plpgsql SET search_path = public AS $$
BEGIN NEW.updated_at = now(); RETURN NEW; END;
$$;

CREATE TABLE public.form_metadata (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  form_id UUID NOT NULL REFERENCES public.forms(id) ON DELETE CASCADE,
  position_title TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  CONSTRAINT form_metadata_form_id_unique UNIQUE (form_id),
  CONSTRAINT form_metadata_position_title_length CHECK (position_title IS NULL OR char_length(position_title) <= 80)
);

CREATE INDEX idx_form_metadata_form_id ON public.form_metadata(form_id);

ALTER TABLE public.form_metadata ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view their own form metadata" ON public.form_metadata FOR SELECT
USING (EXISTS (SELECT 1 FROM public.forms f WHERE f.id = form_metadata.form_id AND f.created_by = auth.uid()));
CREATE POLICY "Users can insert their own form metadata" ON public.form_metadata FOR INSERT
WITH CHECK (EXISTS (SELECT 1 FROM public.forms f WHERE f.id = form_metadata.form_id AND f.created_by = auth.uid()));
CREATE POLICY "Users can update their own form metadata" ON public.form_metadata FOR UPDATE
USING (EXISTS (SELECT 1 FROM public.forms f WHERE f.id = form_metadata.form_id AND f.created_by = auth.uid()));
CREATE POLICY "Users can delete their own form metadata" ON public.form_metadata FOR DELETE
USING (EXISTS (SELECT 1 FROM public.forms f WHERE f.id = form_metadata.form_id AND f.created_by = auth.uid()));

CREATE TRIGGER update_form_metadata_updated_at
BEFORE UPDATE ON public.form_metadata
FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE OR REPLACE FUNCTION public.create_form_metadata_for_new_form()
RETURNS TRIGGER LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  INSERT INTO public.form_metadata (form_id) VALUES (NEW.id) ON CONFLICT (form_id) DO NOTHING;
  RETURN NEW;
END;
$$;

CREATE TRIGGER trg_create_form_metadata_on_new_form
AFTER INSERT ON public.forms
FOR EACH ROW EXECUTE FUNCTION public.create_form_metadata_for_new_form();

INSERT INTO public.form_metadata (form_id)
SELECT f.id FROM public.forms f
LEFT JOIN public.form_metadata fm ON fm.form_id = f.id
WHERE fm.id IS NULL;
