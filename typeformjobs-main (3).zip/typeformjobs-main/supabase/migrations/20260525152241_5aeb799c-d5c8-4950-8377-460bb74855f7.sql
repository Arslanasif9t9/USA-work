-- Phase 3.1: candidate tracking page backend foundation (additive only)
CREATE TABLE public.tracking_tokens (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  token text NOT NULL UNIQUE,
  response_id uuid NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  expires_at timestamptz NULL,
  revoked_at timestamptz NULL
);

CREATE INDEX idx_tracking_tokens_token ON public.tracking_tokens(token);
CREATE INDEX idx_tracking_tokens_response_id ON public.tracking_tokens(response_id);

ALTER TABLE public.tracking_tokens ENABLE ROW LEVEL SECURITY;

-- Mirror "anon read rebook token by value" — anon may SELECT by token (lookup-by-value).
-- The token itself is the secret; without knowing it you cannot find a row.
CREATE POLICY "anon read tracking token by value"
ON public.tracking_tokens FOR SELECT TO anon
USING (true);

-- Admins (authenticated) read for HR tooling.
CREATE POLICY "admins read tracking_tokens"
ON public.tracking_tokens FOR SELECT TO authenticated
USING (auth.uid() IS NOT NULL);

-- No anon INSERT/UPDATE/DELETE policies = denied. Only service role bypasses RLS.