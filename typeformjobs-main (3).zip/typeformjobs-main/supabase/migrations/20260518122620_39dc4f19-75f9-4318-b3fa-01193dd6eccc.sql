
GRANT EXECUTE ON FUNCTION public.generate_offer_reference_id() TO authenticated;
GRANT USAGE, SELECT ON SEQUENCE public.offer_ref_seq TO authenticated;
