
CREATE POLICY "anon attach response live" ON public.scheduling_bookings
  FOR UPDATE TO anon
  USING (
    response_id IS NULL
    AND EXISTS (
      SELECT 1 FROM public.scheduling_configs c
      JOIN public.forms f ON f.id = c.form_id
      WHERE c.id = scheduling_bookings.config_id AND f.status = 'live'
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM public.scheduling_configs c
      JOIN public.forms f ON f.id = c.form_id
      WHERE c.id = scheduling_bookings.config_id AND f.status = 'live'
    )
  );
