DROP POLICY IF EXISTS "public candidate uploads to private buckets" ON storage.objects;

CREATE POLICY "public candidate uploads to private buckets"
ON storage.objects
FOR INSERT
TO public
WITH CHECK (
  bucket_id IN ('resumes', 'selfies', 'candidate-selfies')
);