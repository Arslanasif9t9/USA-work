
REVOKE ALL ON FUNCTION public.generate_offer_reference_id() FROM PUBLIC, anon, authenticated;
REVOKE ALL ON FUNCTION public.prevent_used_scope_library_delete() FROM PUBLIC, anon, authenticated;
