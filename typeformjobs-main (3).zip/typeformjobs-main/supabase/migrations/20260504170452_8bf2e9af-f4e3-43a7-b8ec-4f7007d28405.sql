GRANT SELECT ON public.forms TO anon;
GRANT SELECT ON public.questions TO anon;
GRANT INSERT ON public.responses TO anon;
GRANT INSERT ON public.answers TO anon;