ALTER TABLE public.responses DROP CONSTRAINT IF EXISTS responses_round_stage_check;
ALTER TABLE public.responses ADD CONSTRAINT responses_round_stage_check
  CHECK (round_stage IS NULL OR round_stage IN ('round_1_sent','round_2_sent','offer_sent','offer_signed','disqualified'));