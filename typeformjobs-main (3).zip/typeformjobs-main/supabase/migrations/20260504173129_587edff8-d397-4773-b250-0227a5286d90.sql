ALTER TABLE public.responses ADD COLUMN IF NOT EXISTS viewed_at timestamptz;

-- Allow admins to update responses (mark as viewed)
DROP POLICY IF EXISTS "admins update responses" ON public.responses;
CREATE POLICY "admins update responses" ON public.responses
  FOR UPDATE TO authenticated
  USING (auth.uid() IS NOT NULL)
  WITH CHECK (auth.uid() IS NOT NULL);