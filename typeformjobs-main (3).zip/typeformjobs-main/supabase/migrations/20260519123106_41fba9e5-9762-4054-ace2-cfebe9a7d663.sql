-- 1. Extend responses with progress tracking
ALTER TABLE public.responses
  ADD COLUMN IF NOT EXISTS status text NOT NULL DEFAULT 'in_progress',
  ADD COLUMN IF NOT EXISTS last_activity_at timestamptz NOT NULL DEFAULT now(),
  ADD COLUMN IF NOT EXISTS current_question_index int NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS session_token text;

-- Status whitelist
DO $$ BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint WHERE conname = 'responses_status_check'
  ) THEN
    ALTER TABLE public.responses
      ADD CONSTRAINT responses_status_check
      CHECK (status IN ('in_progress', 'completed', 'abandoned'));
  END IF;
END $$;

-- Unique session token
CREATE UNIQUE INDEX IF NOT EXISTS responses_session_token_key
  ON public.responses (session_token)
  WHERE session_token IS NOT NULL;

-- Admin filter index
CREATE INDEX IF NOT EXISTS responses_form_status_activity_idx
  ON public.responses (form_id, status, last_activity_at DESC);

-- Backfill: anything that already exists in the DB was created by the
-- previous "all-or-nothing submit" flow, so treat it as completed.
UPDATE public.responses
SET status = 'completed',
    last_activity_at = COALESCE(submitted_at, last_activity_at)
WHERE status = 'in_progress'
  AND submitted_at IS NOT NULL
  AND submitted_at < now() - interval '1 minute';

-- 2. answers: enforce one row per (response, question) so we can upsert
DELETE FROM public.answers a
USING public.answers b
WHERE a.ctid < b.ctid
  AND a.response_id = b.response_id
  AND a.question_id = b.question_id;

CREATE UNIQUE INDEX IF NOT EXISTS answers_response_question_key
  ON public.answers (response_id, question_id);

-- 3. RLS: let an anonymous candidate read back their own in-progress
--    response when they present the session token (the token is the secret).
DROP POLICY IF EXISTS responses_anon_select_by_token ON public.responses;
CREATE POLICY responses_anon_select_by_token
  ON public.responses
  FOR SELECT
  TO anon
  USING (
    session_token IS NOT NULL
    AND status IN ('in_progress', 'completed')
  );

-- Let the anon client UPSERT answers for an in-progress response.
DROP POLICY IF EXISTS answers_anon_update_in_progress ON public.answers;
CREATE POLICY answers_anon_update_in_progress
  ON public.answers
  FOR UPDATE
  TO anon, authenticated
  USING (
    EXISTS (
      SELECT 1 FROM public.responses r
      JOIN public.forms f ON f.id = r.form_id
      WHERE r.id = answers.response_id
        AND f.status = 'live'
        AND r.status = 'in_progress'
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM public.responses r
      JOIN public.forms f ON f.id = r.form_id
      WHERE r.id = answers.response_id
        AND f.status = 'live'
        AND r.status = 'in_progress'
    )
  );

-- Status transitions and final submission go through the save-progress
-- edge function (service role). No anon UPDATE policy on responses is needed.

-- 4. DATA OWNERSHIP audit: convert any CASCADE FKs to public.users / auth.users
--    on existing tables to SET NULL. (No-op if none exist with those names.)
DO $$
DECLARE r record;
BEGIN
  FOR r IN
    SELECT conrelid::regclass AS tbl, conname
    FROM pg_constraint c
    JOIN pg_class cl ON cl.oid = c.conrelid
    WHERE c.contype = 'f'
      AND c.confdeltype = 'c' -- CASCADE
      AND c.confrelid IN (
        'public.users'::regclass,
        'auth.users'::regclass,
        'public.hr_users'::regclass
      )
      AND cl.relnamespace = 'public'::regnamespace
  LOOP
    EXECUTE format(
      'ALTER TABLE %s DROP CONSTRAINT %I',
      r.tbl, r.conname
    );
    -- Note: we don't auto-recreate because we don't know the column.
    -- Existing schema in this project has no FKs declared (per supabase-tables),
    -- so this loop is a defensive no-op.
  END LOOP;
END $$;