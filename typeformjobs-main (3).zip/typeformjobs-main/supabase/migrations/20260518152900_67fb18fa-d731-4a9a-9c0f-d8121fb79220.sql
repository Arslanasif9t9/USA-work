UPDATE candidate_actions 
SET round1_status='sent', round1_sent_at=now(), round1_last_sent_at=now(), round1_appointment_date=now() + interval '7 days'
WHERE id='2850cf07-ee6b-46f6-8e53-20112062a981';

UPDATE candidate_actions 
SET round1_status='sent', round1_sent_at=now() - interval '2 days', round1_last_sent_at=now() - interval '1 day', round1_resend_count=2, round1_appointment_date=now() + interval '5 days',
    round2_status='sent', round2_sent_at=now(), round2_last_sent_at=now(), round2_appointment_date=now() + interval '10 days'
WHERE id='5d2b6fb5-8866-4c5c-9329-7fd5272ed88a';

UPDATE candidate_actions 
SET round1_status='sent', round1_sent_at=now() - interval '5 days', round1_last_sent_at=now() - interval '5 days', round1_appointment_date=now() - interval '2 days',
    round2_status='sent', round2_sent_at=now() - interval '1 day', round2_last_sent_at=now() - interval '1 day', round2_resend_count=1, round2_appointment_date=now() + interval '3 days',
    offer_status='sent', offer_sent_at=now(), offer_last_sent_at=now()
WHERE id='d924b6d4-a449-4655-82a4-0839062e8a85';