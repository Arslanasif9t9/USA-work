UPDATE public.candidate_actions SET
  round2_status = 'sent',
  round2_sent_at = now(),
  round2_last_sent_at = now(),
  round2_appointment_date = '2026-05-21T03:00:00Z',
  round2_zoom_meeting_id = '00dec03d-545b-4109-88ef-a9d036d3d54f',
  round2_zoom_join_url = 'https://us05web.zoom.us/j/82561092050?pwd=5PF8JCeoaEfSyzYCq4RUHaLxGgaKxE.1',
  round1_last_sent_at = now(),
  round1_resend_count = round1_resend_count + 1,
  round1_appointment_date = '2026-05-22T06:00:00Z',
  round1_zoom_meeting_id = '1fb41455-91d5-4a0e-9615-f7a5679f1226',
  round1_zoom_join_url = 'https://us05web.zoom.us/j/83745935571?pwd=q3n1LPEhumbZMcZXp6AHVQjbDkLL0B.1'
WHERE id = '5d2b6fb5-8866-4c5c-9329-7fd5272ed88a';