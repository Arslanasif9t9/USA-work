ALTER TABLE public.candidate_actions
  ADD COLUMN IF NOT EXISTS round1_attendance_status text,
  ADD COLUMN IF NOT EXISTS round1_attendance_marked_at timestamptz,
  ADD COLUMN IF NOT EXISTS round1_attendance_marked_by_hr_id uuid,
  ADD COLUMN IF NOT EXISTS round2_attendance_status text,
  ADD COLUMN IF NOT EXISTS round2_attendance_marked_at timestamptz,
  ADD COLUMN IF NOT EXISTS round2_attendance_marked_by_hr_id uuid;

ALTER TABLE public.candidate_actions
  DROP CONSTRAINT IF EXISTS candidate_actions_round1_attendance_status_check,
  DROP CONSTRAINT IF EXISTS candidate_actions_round2_attendance_status_check;

ALTER TABLE public.candidate_actions
  ADD CONSTRAINT candidate_actions_round1_attendance_status_check
    CHECK (round1_attendance_status IS NULL OR round1_attendance_status IN ('attended','no_show')),
  ADD CONSTRAINT candidate_actions_round2_attendance_status_check
    CHECK (round2_attendance_status IS NULL OR round2_attendance_status IN ('attended','no_show'));