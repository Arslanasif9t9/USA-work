
ALTER TABLE public.job_offers
  ADD COLUMN IF NOT EXISTS employment_status text NOT NULL DEFAULT 'active',
  ADD COLUMN IF NOT EXISTS terminated_at timestamptz NULL,
  ADD COLUMN IF NOT EXISTS termination_reason text NULL,
  ADD COLUMN IF NOT EXISTS terminated_by_hr_id uuid NULL REFERENCES public.hr_users(id) ON DELETE SET NULL,
  ADD COLUMN IF NOT EXISTS internal_notes text NULL;

DO $$ BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname = 'job_offers_employment_status_chk') THEN
    ALTER TABLE public.job_offers
      ADD CONSTRAINT job_offers_employment_status_chk
      CHECK (employment_status IN ('active','terminated_evaluation','terminated_regular'));
  END IF;
END $$;

CREATE INDEX IF NOT EXISTS idx_job_offers_employment_status ON public.job_offers(employment_status);

CREATE TABLE IF NOT EXISTS public.termination_log (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  job_offer_id uuid NULL REFERENCES public.job_offers(id) ON DELETE SET NULL,
  termination_type text NOT NULL CHECK (termination_type IN ('evaluation','regular')),
  terminated_by_hr_id uuid NULL REFERENCES public.hr_users(id) ON DELETE SET NULL,
  email_sent_at timestamptz NULL,
  email_log_id uuid NULL REFERENCES public.email_log(id) ON DELETE SET NULL,
  notes text NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.termination_log ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "admins select termination_log" ON public.termination_log;
CREATE POLICY "admins select termination_log" ON public.termination_log
  FOR SELECT TO authenticated USING (auth.uid() IS NOT NULL);

DROP POLICY IF EXISTS "admins insert termination_log" ON public.termination_log;
CREATE POLICY "admins insert termination_log" ON public.termination_log
  FOR INSERT TO authenticated WITH CHECK (auth.uid() IS NOT NULL);

DROP POLICY IF EXISTS "deny update termination_log" ON public.termination_log;
CREATE POLICY "deny update termination_log" ON public.termination_log
  FOR UPDATE TO anon, authenticated USING (false) WITH CHECK (false);

DROP POLICY IF EXISTS "deny delete termination_log" ON public.termination_log;
CREATE POLICY "deny delete termination_log" ON public.termination_log
  FOR DELETE TO anon, authenticated USING (false);
