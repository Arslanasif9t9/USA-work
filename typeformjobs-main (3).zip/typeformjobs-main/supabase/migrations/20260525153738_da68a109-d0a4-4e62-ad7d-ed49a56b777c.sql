ALTER TABLE public.responses DROP CONSTRAINT IF EXISTS responses_round_stage_check;
ALTER TABLE public.responses ADD CONSTRAINT responses_round_stage_check
  CHECK ((round_stage IS NULL) OR (round_stage = ANY (ARRAY['round_1_sent'::text, 'round_2_sent'::text, 'offer_sent'::text, 'offer_signed'::text, 'disqualified'::text, 'terminated'::text])));