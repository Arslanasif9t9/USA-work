-- Add nullable tracking columns to responses for HR-driven round stage tracking
ALTER TABLE public.responses
  ADD COLUMN IF NOT EXISTS round_stage text NULL,
  ADD COLUMN IF NOT EXISTS handled_by_hr_id uuid NULL,
  ADD COLUMN IF NOT EXISTS round_1_sent_at timestamptz NULL,
  ADD COLUMN IF NOT EXISTS round_2_sent_at timestamptz NULL,
  ADD COLUMN IF NOT EXISTS offer_sent_at timestamptz NULL;

-- Validation: only known stage values
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint WHERE conname = 'responses_round_stage_check'
  ) THEN
    ALTER TABLE public.responses
      ADD CONSTRAINT responses_round_stage_check
      CHECK (round_stage IS NULL OR round_stage IN ('round_1_sent','round_2_sent','offer_sent','offer_signed'));
  END IF;
END $$;

-- FK to hr_users with ON DELETE SET NULL (never CASCADE)
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint WHERE conname = 'responses_handled_by_hr_id_fkey'
  ) THEN
    ALTER TABLE public.responses
      ADD CONSTRAINT responses_handled_by_hr_id_fkey
      FOREIGN KEY (handled_by_hr_id) REFERENCES public.hr_users(id) ON DELETE SET NULL;
  END IF;
END $$;

CREATE INDEX IF NOT EXISTS idx_responses_round_stage ON public.responses(round_stage);
CREATE INDEX IF NOT EXISTS idx_responses_handled_by_hr_id ON public.responses(handled_by_hr_id);