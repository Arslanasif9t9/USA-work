ALTER TABLE public.rebook_tokens
  ADD COLUMN IF NOT EXISTS curated_slot_ids uuid[] NULL;