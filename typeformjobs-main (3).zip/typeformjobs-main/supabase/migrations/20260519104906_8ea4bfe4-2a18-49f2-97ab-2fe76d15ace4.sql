ALTER TABLE public.questions DROP CONSTRAINT questions_type_check;
ALTER TABLE public.questions ADD CONSTRAINT questions_type_check
  CHECK (type = ANY (ARRAY[
    'welcome','thank_you',
    'short_text','long_text','email','phone',
    'date','time','file_upload','yes_no','multiple_choice','dropdown',
    'rating','legal_checkbox','selfie','schedule_call'
  ]));