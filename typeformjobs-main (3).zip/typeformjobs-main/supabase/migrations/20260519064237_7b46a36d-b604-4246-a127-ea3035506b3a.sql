
-- Phase H3: HR Booking Dashboard
ALTER TABLE public.interview_slots ADD COLUMN IF NOT EXISTS notes text;
ALTER TABLE public.interview_slots ADD COLUMN IF NOT EXISTS taken_over_from_hr_id uuid;

-- Update hr_users allow master_admin role
-- (role is text, no enum needed)

-- Rebook tokens for recovery emails
CREATE TABLE IF NOT EXISTS public.rebook_tokens (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  token text NOT NULL UNIQUE,
  response_id uuid NOT NULL,
  original_slot_id uuid,
  expires_at timestamptz NOT NULL DEFAULT (now() + interval '3 days'),
  used_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE public.rebook_tokens ENABLE ROW LEVEL SECURITY;
CREATE POLICY "admins read rebook_tokens" ON public.rebook_tokens
  FOR SELECT TO authenticated USING (auth.uid() IS NOT NULL);
CREATE POLICY "anon select rebook_tokens by token" ON public.rebook_tokens
  FOR SELECT TO anon USING (true);

-- Allow INSERT into password_audit_log from authenticated users
DROP POLICY IF EXISTS "admins insert password_audit_log" ON public.password_audit_log;
CREATE POLICY "admins insert password_audit_log" ON public.password_audit_log
  FOR INSERT TO authenticated WITH CHECK (auth.uid() IS NOT NULL);

-- Allow INSERT into notification_log from authenticated users (some flows need)
DROP POLICY IF EXISTS "admins insert notification_log" ON public.notification_log;
CREATE POLICY "admins insert notification_log" ON public.notification_log
  FOR INSERT TO authenticated WITH CHECK (auth.uid() IS NOT NULL);

-- Realtime
ALTER PUBLICATION supabase_realtime ADD TABLE public.interview_slots;
ALTER TABLE public.interview_slots REPLICA IDENTITY FULL;

-- Allow anon to UPDATE rebook_tokens (mark used) when claiming via public rebook flow
CREATE POLICY "anon update rebook_tokens used" ON public.rebook_tokens
  FOR UPDATE TO anon USING (used_at IS NULL AND expires_at > now())
  WITH CHECK (true);
