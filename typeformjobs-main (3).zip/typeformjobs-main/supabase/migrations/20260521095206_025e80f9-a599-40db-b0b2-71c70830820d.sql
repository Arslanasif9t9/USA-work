ALTER TABLE public.email_log DROP CONSTRAINT IF EXISTS email_log_stage_check;
ALTER TABLE public.email_log ADD CONSTRAINT email_log_stage_check CHECK (stage = ANY (ARRAY[
  'stage_1_thank_you','stage_2_interview','stage_2_round_1','stage_2_round_2',
  'stage_2_round_1_invite','stage_2_round_2_invite',
  'stage_3_offer','test','manual_resend','other',
  'stage_1_interview_confirmed','stage_recovery_email','migration_test'
]));