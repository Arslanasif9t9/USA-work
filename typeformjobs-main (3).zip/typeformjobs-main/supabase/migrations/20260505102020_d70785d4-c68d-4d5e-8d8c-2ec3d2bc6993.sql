
INSERT INTO storage.buckets (id, name, public)
VALUES ('candidate-selfies', 'candidate-selfies', false)
ON CONFLICT (id) DO NOTHING;

-- Allow anon (candidate) uploads
CREATE POLICY "candidate_selfies_anon_insert"
ON storage.objects FOR INSERT TO anon
WITH CHECK (bucket_id = 'candidate-selfies');

-- Allow authenticated (admin) uploads too (preview/edit)
CREATE POLICY "candidate_selfies_auth_insert"
ON storage.objects FOR INSERT TO authenticated
WITH CHECK (bucket_id = 'candidate-selfies');

-- Only authenticated users (admins) can read
CREATE POLICY "candidate_selfies_auth_select"
ON storage.objects FOR SELECT TO authenticated
USING (bucket_id = 'candidate-selfies');

-- Admins can delete
CREATE POLICY "candidate_selfies_auth_delete"
ON storage.objects FOR DELETE TO authenticated
USING (bucket_id = 'candidate-selfies');
