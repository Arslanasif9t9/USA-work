ALTER TABLE public.responses
  ADD COLUMN IF NOT EXISTS final_outcome text,
  ADD COLUMN IF NOT EXISTS disqualified_at_stage text;

CREATE INDEX IF NOT EXISTS idx_responses_final_outcome
  ON public.responses(final_outcome)
  WHERE final_outcome IS NOT NULL;