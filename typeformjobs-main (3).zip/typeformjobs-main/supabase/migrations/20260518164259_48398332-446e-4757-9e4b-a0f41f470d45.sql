UPDATE public.candidate_actions SET
  round1_status = 'sent',
  round1_sent_at = now(),
  round1_last_sent_at = now(),
  round1_appointment_date = '2026-05-20T02:00:00Z',
  round1_zoom_meeting_id = '249269f7-bf6c-48e6-ae22-db0fc0896990',
  round1_zoom_join_url = 'https://us05web.zoom.us/j/81912636290?pwd=W0OYGydHCALDoyFgvQ3XTpEah2Z6ai.1'
WHERE id = '5d2b6fb5-8866-4c5c-9329-7fd5272ed88a';