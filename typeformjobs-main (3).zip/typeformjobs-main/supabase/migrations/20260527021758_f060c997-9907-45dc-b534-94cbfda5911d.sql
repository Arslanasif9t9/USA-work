
CREATE TABLE public.nda_signatures (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  response_id uuid,
  external_reference text NOT NULL UNIQUE,
  signer_name text,
  signer_email text,
  signing_token text,
  signing_url text,
  status text NOT NULL DEFAULT 'sent',
  signed_at timestamptz,
  signed_pdf_url text,
  created_at timestamptz NOT NULL DEFAULT now()
);

GRANT SELECT ON public.nda_signatures TO authenticated;
GRANT ALL ON public.nda_signatures TO service_role;

ALTER TABLE public.nda_signatures ENABLE ROW LEVEL SECURITY;

CREATE POLICY "authenticated read nda_signatures"
  ON public.nda_signatures FOR SELECT
  TO authenticated
  USING (auth.uid() IS NOT NULL);

CREATE POLICY "service_role full access nda_signatures"
  ON public.nda_signatures FOR ALL
  TO service_role
  USING (true)
  WITH CHECK (true);

CREATE INDEX nda_signatures_response_id_idx ON public.nda_signatures(response_id);
CREATE INDEX nda_signatures_external_reference_idx ON public.nda_signatures(external_reference);
