CREATE TABLE public.hr_candidate_extras (
  response_id UUID PRIMARY KEY,
  photo_file_url TEXT,
  notes TEXT,
  phone TEXT,
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_by_hr_id UUID,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

ALTER TABLE public.hr_candidate_extras ENABLE ROW LEVEL SECURITY;

CREATE POLICY "admins select hr_candidate_extras"
ON public.hr_candidate_extras FOR SELECT TO authenticated
USING (auth.uid() IS NOT NULL);

CREATE POLICY "admins insert hr_candidate_extras"
ON public.hr_candidate_extras FOR INSERT TO authenticated
WITH CHECK (auth.uid() IS NOT NULL);

CREATE POLICY "admins update hr_candidate_extras"
ON public.hr_candidate_extras FOR UPDATE TO authenticated
USING (auth.uid() IS NOT NULL)
WITH CHECK (auth.uid() IS NOT NULL);

CREATE POLICY "admins delete hr_candidate_extras"
ON public.hr_candidate_extras FOR DELETE TO authenticated
USING (auth.uid() IS NOT NULL);

CREATE TRIGGER trg_hr_candidate_extras_updated_at
BEFORE UPDATE ON public.hr_candidate_extras
FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();