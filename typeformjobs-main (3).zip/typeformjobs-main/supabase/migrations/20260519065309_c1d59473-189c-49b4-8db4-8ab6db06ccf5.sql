DROP POLICY IF EXISTS "answers_anon_insert_live" ON public.answers;
CREATE POLICY "answers_anon_insert_live"
ON public.answers FOR INSERT TO anon, authenticated
WITH CHECK (true);