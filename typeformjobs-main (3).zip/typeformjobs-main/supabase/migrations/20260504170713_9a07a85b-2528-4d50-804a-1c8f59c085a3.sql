CREATE OR REPLACE FUNCTION public.is_response_for_live_form(_response_id uuid)
RETURNS boolean
LANGUAGE sql
STABLE SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.responses r
    JOIN public.forms f ON f.id = r.form_id
    WHERE r.id = _response_id AND f.status = 'live'
  );
$$;

DROP POLICY IF EXISTS "answers_anon_insert_live" ON public.answers;
CREATE POLICY "answers_anon_insert_live"
ON public.answers FOR INSERT TO anon
WITH CHECK (public.is_response_for_live_form(response_id));