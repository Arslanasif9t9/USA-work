UPDATE storage.buckets SET file_size_limit = 115343360 WHERE id = 'resumes';
UPDATE storage.buckets SET file_size_limit = 62914560 WHERE id IN ('selfies','candidate-selfies');
UPDATE storage.buckets SET allowed_mime_types = NULL WHERE id IN ('resumes','selfies','candidate-selfies');