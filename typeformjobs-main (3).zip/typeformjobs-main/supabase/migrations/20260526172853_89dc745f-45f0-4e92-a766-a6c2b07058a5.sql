
-- GLITCH 4: allow HR (authenticated) to read AI interview sessions & evaluations.
GRANT SELECT ON public.ai_interview_sessions TO authenticated;
GRANT SELECT ON public.ai_interview_evaluations TO authenticated;

CREATE POLICY "authenticated read ai_interview_sessions"
ON public.ai_interview_sessions
FOR SELECT
TO authenticated
USING (auth.uid() IS NOT NULL);

CREATE POLICY "authenticated read ai_interview_evaluations"
ON public.ai_interview_evaluations
FOR SELECT
TO authenticated
USING (auth.uid() IS NOT NULL);

-- GLITCH 5: widen responses.round_stage CHECK to include the new ai_interview_completed stage.
ALTER TABLE public.responses DROP CONSTRAINT IF EXISTS responses_round_stage_check;
ALTER TABLE public.responses ADD CONSTRAINT responses_round_stage_check
  CHECK (
    round_stage IS NULL OR round_stage = ANY (ARRAY[
      'round_1_sent'::text,
      'round_2_sent'::text,
      'offer_sent'::text,
      'offer_signed'::text,
      'disqualified'::text,
      'terminated'::text,
      'ai_interview_completed'::text
    ])
  );
