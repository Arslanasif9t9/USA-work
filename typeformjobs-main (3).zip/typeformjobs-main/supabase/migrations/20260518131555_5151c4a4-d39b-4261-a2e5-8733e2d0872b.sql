
CREATE TABLE public.email_log (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  candidate_id uuid,
  job_offer_id uuid,
  stage text NOT NULL CHECK (stage IN ('stage_1_thank_you','stage_2_interview','stage_3_offer','test','manual_resend','other')),
  sender text NOT NULL CHECK (sender IN ('resend','gmail_smtp')),
  from_address text NOT NULL,
  from_name text NOT NULL,
  to_address text NOT NULL,
  subject text NOT NULL,
  status text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','sent','failed','bounced')),
  error_message text,
  resend_message_id text,
  sent_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX idx_email_log_candidate_stage ON public.email_log(candidate_id, stage);
CREATE INDEX idx_email_log_offer_stage ON public.email_log(job_offer_id, stage);
CREATE INDEX idx_email_log_status ON public.email_log(status);
CREATE INDEX idx_email_log_resend_message_id ON public.email_log(resend_message_id);

ALTER TABLE public.email_log ENABLE ROW LEVEL SECURITY;

CREATE POLICY "admins select email_log"
  ON public.email_log FOR SELECT
  TO authenticated
  USING (auth.uid() IS NOT NULL);
