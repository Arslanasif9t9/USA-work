
-- 1. scheduling_configs
CREATE TABLE public.scheduling_configs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  question_id uuid NOT NULL UNIQUE,
  form_id uuid NOT NULL,
  calendar_source text NOT NULL DEFAULT 'internal',
  timezone text NOT NULL DEFAULT 'UTC',
  slot_duration_minutes int NOT NULL DEFAULT 30,
  buffer_minutes int NOT NULL DEFAULT 0,
  working_hours jsonb NOT NULL DEFAULT '{"mon":["09:00","17:00"],"tue":["09:00","17:00"],"wed":["09:00","17:00"],"thu":["09:00","17:00"],"fri":["09:00","17:00"],"sat":null,"sun":null}'::jsonb,
  advance_notice_hours int NOT NULL DEFAULT 24,
  booking_window_days int NOT NULL DEFAULT 30,
  disclaimer_text text NOT NULL DEFAULT 'Please note: Booking a time slot does not guarantee an interview. Your selection is provisional and remains subject to review by our hiring team. You will receive formal confirmation via email only if your application advances to the interview stage.',
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX idx_scheduling_configs_form ON public.scheduling_configs(form_id);

-- 2. scheduling_blocked_slots
CREATE TABLE public.scheduling_blocked_slots (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  config_id uuid NOT NULL REFERENCES public.scheduling_configs(id) ON DELETE CASCADE,
  start_at timestamptz NOT NULL,
  end_at timestamptz NOT NULL,
  reason text,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX idx_blocked_slots_config ON public.scheduling_blocked_slots(config_id, start_at);

-- 3. scheduling_bookings
CREATE TABLE public.scheduling_bookings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  config_id uuid NOT NULL REFERENCES public.scheduling_configs(id) ON DELETE CASCADE,
  response_id uuid,
  candidate_name text,
  candidate_email text,
  candidate_timezone text,
  slot_start timestamptz NOT NULL,
  slot_end timestamptz NOT NULL,
  status text NOT NULL DEFAULT 'pending_approval',
  admin_note text,
  created_at timestamptz NOT NULL DEFAULT now(),
  decided_at timestamptz
);

CREATE INDEX idx_bookings_config ON public.scheduling_bookings(config_id, slot_start);
CREATE UNIQUE INDEX uq_active_booking_slot
  ON public.scheduling_bookings(config_id, slot_start)
  WHERE status IN ('pending_approval','approved');

-- updated_at trigger
CREATE TRIGGER set_scheduling_configs_updated_at
  BEFORE UPDATE ON public.scheduling_configs
  FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

-- non-empty disclaimer validation trigger
CREATE OR REPLACE FUNCTION public.validate_scheduling_config()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF NEW.disclaimer_text IS NULL OR length(btrim(NEW.disclaimer_text)) = 0 THEN
    RAISE EXCEPTION 'disclaimer_text cannot be empty';
  END IF;
  RETURN NEW;
END; $$;

CREATE TRIGGER validate_scheduling_configs_before_write
  BEFORE INSERT OR UPDATE ON public.scheduling_configs
  FOR EACH ROW EXECUTE FUNCTION public.validate_scheduling_config();

-- RLS
ALTER TABLE public.scheduling_configs ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.scheduling_blocked_slots ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.scheduling_bookings ENABLE ROW LEVEL SECURITY;

-- scheduling_configs: admins full, anon select for live forms
CREATE POLICY "admins all configs" ON public.scheduling_configs
  FOR ALL TO authenticated
  USING (auth.uid() IS NOT NULL)
  WITH CHECK (auth.uid() IS NOT NULL);

CREATE POLICY "anon select configs live" ON public.scheduling_configs
  FOR SELECT TO anon
  USING (EXISTS (SELECT 1 FROM public.forms f WHERE f.id = scheduling_configs.form_id AND f.status = 'live'));

-- scheduling_blocked_slots: admins full, anon select for live
CREATE POLICY "admins all blocked" ON public.scheduling_blocked_slots
  FOR ALL TO authenticated
  USING (auth.uid() IS NOT NULL)
  WITH CHECK (auth.uid() IS NOT NULL);

CREATE POLICY "anon select blocked live" ON public.scheduling_blocked_slots
  FOR SELECT TO anon
  USING (EXISTS (
    SELECT 1 FROM public.scheduling_configs c
    JOIN public.forms f ON f.id = c.form_id
    WHERE c.id = scheduling_blocked_slots.config_id AND f.status = 'live'
  ));

-- scheduling_bookings: admins full, anon select+insert for live
CREATE POLICY "admins all bookings" ON public.scheduling_bookings
  FOR ALL TO authenticated
  USING (auth.uid() IS NOT NULL)
  WITH CHECK (auth.uid() IS NOT NULL);

CREATE POLICY "anon select bookings live" ON public.scheduling_bookings
  FOR SELECT TO anon
  USING (EXISTS (
    SELECT 1 FROM public.scheduling_configs c
    JOIN public.forms f ON f.id = c.form_id
    WHERE c.id = scheduling_bookings.config_id AND f.status = 'live'
  ));

CREATE POLICY "anon insert bookings live" ON public.scheduling_bookings
  FOR INSERT TO anon
  WITH CHECK (EXISTS (
    SELECT 1 FROM public.scheduling_configs c
    JOIN public.forms f ON f.id = c.form_id
    WHERE c.id = scheduling_bookings.config_id AND f.status = 'live'
  ));
