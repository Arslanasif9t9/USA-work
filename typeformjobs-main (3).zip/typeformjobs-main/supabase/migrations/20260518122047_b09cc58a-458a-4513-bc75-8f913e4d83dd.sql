
DROP POLICY IF EXISTS "owners select offers" ON public.job_offers;
DROP POLICY IF EXISTS "owners insert offers" ON public.job_offers;
DROP POLICY IF EXISTS "owners update offers" ON public.job_offers;
DROP POLICY IF EXISTS "owners delete offers" ON public.job_offers;
CREATE POLICY "admins select offers" ON public.job_offers FOR SELECT TO authenticated USING (auth.uid() IS NOT NULL);
CREATE POLICY "admins insert offers" ON public.job_offers FOR INSERT TO authenticated WITH CHECK (auth.uid() IS NOT NULL);
CREATE POLICY "admins update offers" ON public.job_offers FOR UPDATE TO authenticated USING (auth.uid() IS NOT NULL) WITH CHECK (auth.uid() IS NOT NULL);
CREATE POLICY "admins delete offers" ON public.job_offers FOR DELETE TO authenticated USING (auth.uid() IS NOT NULL);
