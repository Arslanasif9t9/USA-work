ALTER TABLE public.interview_slots
ADD COLUMN IF NOT EXISTS appointment_resend_count integer NOT NULL DEFAULT 0;