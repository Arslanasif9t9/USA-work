ALTER TABLE public.job_offers
  ADD COLUMN IF NOT EXISTS performance_bonus_enabled boolean NOT NULL DEFAULT false,
  ADD COLUMN IF NOT EXISTS performance_bonus_amount numeric,
  ADD COLUMN IF NOT EXISTS include_adaptability_clause boolean NOT NULL DEFAULT true;