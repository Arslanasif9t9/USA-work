
CREATE TABLE public.ai_interview_sessions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  response_id uuid NOT NULL,
  retell_call_id text,
  started_at timestamptz,
  ended_at timestamptz,
  duration_seconds int,
  transcript jsonb,
  recording_url text,
  video_url text,
  termination_reason text,
  cost_usd numeric,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX idx_ai_interview_sessions_response_id ON public.ai_interview_sessions(response_id);

ALTER TABLE public.ai_interview_sessions ENABLE ROW LEVEL SECURITY;

CREATE POLICY "service_role full access ai_interview_sessions"
ON public.ai_interview_sessions
FOR ALL
TO service_role
USING (true)
WITH CHECK (true);

CREATE TABLE public.ai_interview_evaluations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  session_id uuid NOT NULL,
  response_id uuid NOT NULL,
  tier text,
  ai_recommended boolean,
  red_flags text,
  verdict text,
  availability text,
  hunger text,
  summary text,
  sentiment text,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX idx_ai_interview_evaluations_response_id ON public.ai_interview_evaluations(response_id);

ALTER TABLE public.ai_interview_evaluations ENABLE ROW LEVEL SECURITY;

CREATE POLICY "service_role full access ai_interview_evaluations"
ON public.ai_interview_evaluations
FOR ALL
TO service_role
USING (true)
WITH CHECK (true);
