
CREATE OR REPLACE FUNCTION public.is_admin(_uid uuid)
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT EXISTS (SELECT 1 FROM public.users WHERE id = _uid AND role = 'admin');
$$;

DROP POLICY "forms_auth_all" ON public.forms;
CREATE POLICY "forms_admin_all" ON public.forms FOR ALL TO authenticated
USING (public.is_admin(auth.uid())) WITH CHECK (public.is_admin(auth.uid()));

DROP POLICY "questions_auth_all" ON public.questions;
CREATE POLICY "questions_admin_all" ON public.questions FOR ALL TO authenticated
USING (public.is_admin(auth.uid())) WITH CHECK (public.is_admin(auth.uid()));

DROP POLICY "responses_auth_delete" ON public.responses;
CREATE POLICY "responses_admin_delete" ON public.responses FOR DELETE TO authenticated
USING (public.is_admin(auth.uid()));

DROP POLICY "answers_auth_delete" ON public.answers;
CREATE POLICY "answers_admin_delete" ON public.answers FOR DELETE TO authenticated
USING (public.is_admin(auth.uid()));
