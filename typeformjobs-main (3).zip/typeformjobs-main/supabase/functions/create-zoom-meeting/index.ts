// create-zoom-meeting: admin-only. Creates a Zoom meeting + inserts row in zoom_meetings.
import {
  adminClient,
  corsHeaders,
  jsonResponse,
  requireAdmin,
  zoomFetch,
} from "../_shared/zoom.ts";

interface Input {
  topic: string;
  start_time: string; // ISO 8601 (Manila local time, no offset)
  duration_minutes?: number;
  candidate_actions_id?: string | null;
  candidate_id?: string | null;
  round?: 1 | 2 | null;
  host_email?: string | null;
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });
  const guard = await requireAdmin(req);
  if (guard instanceof Response) return guard;

  let body: Input;
  try {
    body = await req.json();
  } catch {
    return jsonResponse({ error: "invalid_json" }, 400);
  }

  // Validate
  const topic = (body.topic || "").trim();
  if (!topic || topic.length > 200) {
    return jsonResponse({ error: "invalid_topic" }, 400);
  }
  const startTime = body.start_time;
  const startMs = Date.parse(startTime);
  if (isNaN(startMs)) return jsonResponse({ error: "invalid_start_time" }, 400);
  if (startMs < Date.now() - 5 * 60 * 1000) {
    return jsonResponse({ error: "start_time_in_past" }, 400);
  }
  const duration = body.duration_minutes ?? 15;
  if (duration < 5 || duration > 120) {
    return jsonResponse({ error: "invalid_duration" }, 400);
  }
  if (body.round != null && body.round !== 1 && body.round !== 2) {
    return jsonResponse({ error: "invalid_round" }, 400);
  }

  const admin = adminClient();

  // Bug C — idempotency: if this candidate_actions row already has a meeting for this round, reuse it.
  if (body.candidate_actions_id && body.round) {
    const col = body.round === 1 ? "round1_zoom_meeting_id" : "round2_zoom_meeting_id";
    const joinCol = body.round === 1 ? "round1_zoom_join_url" : "round2_zoom_join_url";
    const { data: ca } = await admin
      .from("candidate_actions")
      .select(`id, ${col}, ${joinCol}`)
      .eq("id", body.candidate_actions_id)
      .maybeSingle();
    const existingZoomId = (ca as any)?.[col];
    if (existingZoomId) {
      const { data: zm } = await admin
        .from("zoom_meetings")
        .select("id, zoom_meeting_id, join_url, password, start_url, start_time, duration_minutes")
        .eq("zoom_meeting_id", String(existingZoomId))
        .maybeSingle();
      if (zm) {
        return jsonResponse({
          success: true, reused: true,
          meeting_id: zm.zoom_meeting_id,
          join_url: zm.join_url, password: zm.password ?? null,
          start_url: zm.start_url ?? null,
          start_time: zm.start_time, duration_minutes: zm.duration_minutes,
          db_record_id: zm.id,
        });
      }
    }
  }

  // Bug B — if candidate already has an active scheduled meeting via interview_slots, reuse it.
  if (body.candidate_id) {
    const { data: respRows } = await admin
      .from("responses")
      .select("id, scheduled_slot_id")
      .eq("applicant_id", body.candidate_id)
      .not("scheduled_slot_id", "is", null)
      .limit(5);
    const slotIds = (respRows || []).map((r: any) => r.scheduled_slot_id).filter(Boolean);
    if (slotIds.length) {
      const { data: slots } = await admin
        .from("interview_slots")
        .select("id, zoom_meeting_id, status")
        .in("id", slotIds)
        .eq("status", "booked");
      const zmId = slots?.find((s: any) => s.zoom_meeting_id)?.zoom_meeting_id;
      if (zmId) {
        const { data: zm } = await admin
          .from("zoom_meetings")
          .select("id, zoom_meeting_id, join_url, password, start_url, start_time, duration_minutes, status")
          .eq("id", zmId)
          .maybeSingle();
        if (zm && zm.status !== "cancelled") {
          return jsonResponse({
            success: true, reused: true,
            meeting_id: zm.zoom_meeting_id,
            join_url: zm.join_url, password: zm.password ?? null,
            start_url: zm.start_url ?? null,
            start_time: zm.start_time, duration_minutes: zm.duration_minutes,
            db_record_id: zm.id,
          });
        }
      }
    }
  }

  // Create Zoom meeting
  let zoomRes: Response;
  try {
    zoomRes = await zoomFetch("/users/me/meetings", {
      method: "POST",
      jsonBody: {
        topic,
        type: 2,
        start_time: startTime,
        duration,
        timezone: "Asia/Manila",
        password: "",
        settings: {
          host_video: true,
          participant_video: true,
          join_before_host: false,
          mute_upon_entry: false,
          waiting_room: true,
          auto_recording: "none",
          approval_type: 2,
          audio: "both",
          meeting_invitees: [],
          meeting_authentication: false,
        },
      },
    });
  } catch (e) {
    console.error("zoom_network_error", e);
    return jsonResponse({ error: "zoom_unreachable" }, 503);
  }

  const zoomJson = await zoomRes.json().catch(() => ({}));
  if (!zoomRes.ok) {
    console.error("zoom_create_failed", zoomRes.status, zoomJson);
    return jsonResponse(
      { error: "zoom_api_error", status: zoomRes.status, details: zoomJson },
      zoomRes.status === 401 ? 500 : 502,
    );
  }

  const meetingId = String(zoomJson.id);
  const insertRow = {
    candidate_id: body.candidate_id ?? null,
    candidate_actions_id: body.candidate_actions_id ?? null,
    round: body.round ?? null,
    zoom_meeting_id: meetingId,
    zoom_meeting_uuid: zoomJson.uuid ?? null,
    topic,
    start_time: zoomJson.start_time || new Date(startMs).toISOString(),
    duration_minutes: zoomJson.duration ?? duration,
    timezone: zoomJson.timezone || "Asia/Manila",
    join_url: zoomJson.join_url,
    password: zoomJson.password ?? null,
    start_url: zoomJson.start_url ?? null,
    status: "scheduled",
    last_synced_at: new Date().toISOString(),
  };



  const { data: inserted, error: insErr } = await admin
    .from("zoom_meetings")
    .insert(insertRow)
    .select("id")
    .maybeSingle();

  if (insErr) {
    console.error("zoom_db_insert_failed", insErr, { meetingId });
    return jsonResponse({
      success: true,
      warning: "db_insert_failed",
      meeting_id: meetingId,
      join_url: zoomJson.join_url,
      password: zoomJson.password ?? null,
      start_url: zoomJson.start_url ?? null,
      start_time: insertRow.start_time,
      duration_minutes: insertRow.duration_minutes,
      db_record_id: null,
      db_error: insErr.message,
    });
  }

  return jsonResponse({
    success: true,
    meeting_id: meetingId,
    join_url: zoomJson.join_url,
    password: zoomJson.password ?? null,
    start_url: zoomJson.start_url ?? null,
    start_time: insertRow.start_time,
    duration_minutes: insertRow.duration_minutes,
    db_record_id: inserted?.id ?? null,
  });
});
