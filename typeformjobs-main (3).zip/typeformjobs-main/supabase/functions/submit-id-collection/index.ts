// submit-id-collection: PUBLIC, token-gated. Clone of submit-cash-advance for
// ID-collection rows (doc_type='id_collection') in the same leave_requests table.
// Two actions:
//   - { token, action: "load" }  -> read-only: returns id_hr_message + signer_name
//   - { token, id_photo_1_url, id_photo_2_url, id_body_note, typed_name, signature_* }
//       -> single-row UPDATE, flips status invited -> pending_approval, marks token used.
// Best-effort notifies HR. Never touches the leave / cash-advance flows or SignFlow.
import { createClient } from "npm:@supabase/supabase-js@2";
import { matchLeaveToResponse } from "../_shared/match-leave.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};
const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
const SERVICE = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
const RESEND_API_KEY = Deno.env.get("RESEND_API_KEY") || "";

const HR_NOTIFY = "talent.expertadvisor@outlook.com";
const FROM = "EIA HR <talent@expertintuitiveadvisor.com>";
const FROM_ADDR = "talent@expertintuitiveadvisor.com";
const FROM_NAME = "EIA HR";

const json = (b: unknown, s = 200) =>
  new Response(JSON.stringify(b), { status: s, headers: { ...corsHeaders, "Content-Type": "application/json" } });

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });
  try {
    const body = await req.json();
    const {
      token,
      action,
      id_photo_1_url,
      id_photo_2_url,
      id_body_note,
      typed_name,
      signature_data,
      signature_date,
    } = body || {};

    if (!token || typeof token !== "string") return json({ ok: false, reason: "missing_token" }, 400);

    const admin = createClient(SUPABASE_URL, SERVICE);

    // Re-validate token server-side
    const { data: row } = await admin
      .from("leave_requests")
      .select("id, doc_type, status, token_used_at, token_expires_at, signer_name, id_hr_message")
      .eq("token", token)
      .maybeSingle();

    if (!row) return json({ ok: false, reason: "not_found" }, 404);

    // Read-only load branch for the public page (HR note + name).
    if (action === "load") {
      return json({
        ok: true,
        id_hr_message: (row as any).id_hr_message ?? null,
        signer_name: (row as any).signer_name ?? null,
      });
    }

    if (row.token_used_at) return json({ ok: false, reason: "used" }, 410);
    if (new Date(row.token_expires_at as string) < new Date()) return json({ ok: false, reason: "expired" }, 410);
    if (row.status !== "invited") return json({ ok: false, reason: "used" }, 410);

    const now = new Date().toISOString();

    // Single-row UPDATE by id
    const { error: upErr } = await admin
      .from("leave_requests")
      .update({
        id_photo_1_url: (id_photo_1_url || "").toString().trim() || null,
        id_photo_2_url: (id_photo_2_url || "").toString().trim() || null,
        id_body_note: (id_body_note || "").toString().trim() || null,
        typed_name: (typed_name || "").toString().trim() || null,
        signature_data: signature_data || null,
        signature_date: (signature_date || "").toString().trim() || null,
        status: "pending_approval",
        token_used_at: now,
        updated_at: now,
      })
      .eq("id", row.id);

    if (upErr) return json({ ok: false, reason: "persist_failed", detail: upErr.message }, 500);

    // Read-after-write guard
    const { data: verify } = await admin
      .from("leave_requests")
      .select("status, token_used_at, signer_email, matched_response_id")
      .eq("id", row.id)
      .maybeSingle();
    if (!verify || verify.status !== "pending_approval" || !verify.token_used_at) {
      return json({ ok: false, reason: "persist_failed" }, 500);
    }

    // Idempotent auto-match by email (never throws, never blocks submit)
    if (!verify.matched_response_id && verify.signer_email) {
      await matchLeaveToResponse(admin, row.id, verify.signer_email);
    }

    // Best-effort HR notification — DISABLED: the "New ID Collection Submission"
    // inbox notification is intentionally turned off. Record write + candidate-facing
    // confirmation are unchanged.
    try {
      if (false && RESEND_API_KEY) {
        const subject = `New ID Collection Submission — ${typed_name || "Employee"}`;
        const text =
          `${typed_name || "An employee"} submitted their ID collection form.\n\n` +
          `Notes: ${id_body_note || "(none)"}\n\n` +
          `Review in the EIA Quarantine dashboard.`;
        const html = `<div style="font-family:Inter,Arial,sans-serif;color:#1a2547">
          <h2 style="font-family:'Cormorant Garamond',Georgia,serif;color:#1a2547">New ID Collection Submission</h2>
          <p><strong>${typed_name || "An employee"}</strong> submitted their ID collection form.</p>
          <p><strong>Notes:</strong> ${id_body_note || "(none)"}</p>
          <p style="color:#6b7280;font-size:13px">Review in the EIA Quarantine dashboard.</p>
        </div>`;

        const sendRes = await fetch("https://api.resend.com/emails", {
          method: "POST",
          headers: { "Content-Type": "application/json", Authorization: `Bearer ${RESEND_API_KEY}` },
          body: JSON.stringify({ from: FROM, to: [HR_NOTIFY], subject, html, text }),
        });
        const sendJson = await sendRes.json().catch(() => ({}));
        await admin.from("email_log").insert({
          candidate_id: null,
          stage: "other",
          sender: "resend",
          from_address: FROM_ADDR,
          from_name: FROM_NAME,
          to_address: HR_NOTIFY,
          subject,
          status: sendRes.ok ? "sent" : "failed",
          sent_at: sendRes.ok ? now : null,
          resend_message_id: sendJson?.id ?? null,
          error_message: sendRes.ok ? null : JSON.stringify(sendJson),
        });
      }
    } catch (_e) {
      // swallow — notify must not fail submit
    }

    return json({ ok: true });
  } catch (e: any) {
    return json({ ok: false, reason: "internal", detail: String(e?.message || e) }, 500);
  }
});
