// send-cash-advance-form: HR/admin orchestrator. Mints token + public link,
// inserts a leave_requests row with doc_type='cash_advance', and sends the
// invite email via send-dual-email.
// CLONE of send-leave-form (Option B: same leave_requests table, two doc types).
// Differences only: CASH- reference prefix, doc_type='cash_advance', the
// /cash-advance/{token} public route, and cash-advance wording.
// NOTE: model (a) — in-page signature, NO SignFlow round-trip.
import { createClient } from "npm:@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
const ANON = Deno.env.get("SUPABASE_ANON_KEY")!;
const SVC = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
const PUBLIC_BASE = "https://jobs.expertintuitiveadvisor.com";

const json = (b: unknown, status = 200) =>
  new Response(JSON.stringify(b), {
    status,
    headers: { ...corsHeaders, "content-type": "application/json" },
  });

function shortHex(n: number) {
  const bytes = new Uint8Array(n / 2);
  crypto.getRandomValues(bytes);
  return Array.from(bytes).map((b) => b.toString(16).padStart(2, "0")).join("");
}

function buildCashSenderA(firstName: string, link: string) {
  const text = `Hi ${firstName},

Please complete your cash advance request using the secure link below. Fill in all details, sign, and submit — your request will then be reviewed for approval.

OPEN YOUR CASH ADVANCE REQUEST FORM:
${link}

If you have any questions, simply reply to this email.

Angela Stein
HR — Talent Manager
Expert Intuitive Advisor Inc.`;
  const html = `<div style="font-family:Arial,sans-serif;font-size:14px;color:#1a2236;line-height:1.6;max-width:600px">
<p>Hi ${firstName},</p>
<p>Please complete your cash advance request using the secure link below. Fill in all details, sign, and submit — your request will then be reviewed for approval.</p>
<p><a href="${link}" style="display:inline-block;background:#1a2547;color:#ffffff;padding:12px 22px;border-radius:6px;text-decoration:none;font-weight:600">Open your cash advance request form</a></p>
<p style="font-size:12px;color:#666">Or paste this link into your browser:<br/><a href="${link}" style="color:#1a2547">${link}</a></p>
<p>If you have any questions, simply reply to this email.</p>
<p>Angela Stein<br/>HR — Talent Manager<br/>Expert Intuitive Advisor Inc.</p>
</div>`;
  return {
    from_name: "Angela Stein / HR — Talent Manager",
    from_address: "talent@expertintuitiveadvisor.com",
    subject: "Cash Advance Request Form — please complete and submit (Expert Intuitive Advisor Inc.)",
    html_body: html,
    text_body: text,
  };
}

function buildCashSenderB(firstName: string, link: string) {
  const text = `Hi ${firstName},

Quick personal note — here's your cash advance request form link again so you don't have to dig:

${link}

Fill it in, sign, and submit when you can. If anything's unclear, just reply.

— Angela Stein`;
  const html = `<div style="font-family:Arial,sans-serif;font-size:14px;color:#1a2236;line-height:1.6;max-width:600px">
<p>Hi ${firstName},</p>
<p>Quick personal note — here's your cash advance request form link again so you don't have to dig:</p>
<p><a href="${link}" style="color:#1a2547">${link}</a></p>
<p>Fill it in, sign, and submit when you can. If anything's unclear, just reply.</p>
<p>— Angela Stein</p>
</div>`;
  return {
    from_name: "Angela Stein",
    from_address: "expertintuitiveadvisor@gmail.com",
    subject: "Your EIA cash advance request form",
    html_body: html,
    text_body: text,
  };
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });
  if (req.method !== "POST") return json({ ok: false, reason: "method_not_allowed" }, 405);

  // Admin gate (mirrors send-leave-form)
  const auth = req.headers.get("Authorization") || "";
  if (!auth.startsWith("Bearer ")) return json({ ok: false, reason: "missing_auth" }, 401);
  const userClient = createClient(SUPABASE_URL, ANON, { global: { headers: { Authorization: auth } } });
  const { data: u } = await userClient.auth.getUser();
  if (!u?.user) return json({ ok: false, reason: "invalid_jwt" }, 401);
  const admin = createClient(SUPABASE_URL, SVC);
  const { data: urow } = await admin.from("users").select("role").eq("id", u.user.id).maybeSingle();
  if (!urow || urow.role !== "admin") return json({ ok: false, reason: "forbidden" }, 403);

  let body: { response_id?: string; override_email?: string; name?: string; email?: string; hr_copy_requested?: boolean; hr_copy_email_override?: string };
  try { body = await req.json(); } catch { return json({ ok: false, reason: "invalid_json" }, 400); }
  const { response_id, override_email, name: directName, email: directEmail } = body || {};
  const hrCopyRequested = !!(body as any)?.hr_copy_requested;
  const hrCopyEmailOverrideRaw = typeof (body as any)?.hr_copy_email_override === "string" ? (body as any).hr_copy_email_override.trim() : "";
  const hrCopyEmailOverride = hrCopyEmailOverrideRaw && /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(hrCopyEmailOverrideRaw) ? hrCopyEmailOverrideRaw : null;

  let signerEmail = "";
  let signerName = "";
  let resolvedResponseId: string | null = null;

  if (response_id) {
    const { data: resp, error: respErr } = await admin
      .from("responses")
      .select("id, applicant_id, form_id, override_email, override_name")
      .eq("id", response_id)
      .maybeSingle();
    if (respErr) return json({ ok: false, reason: "response_lookup_failed", detail: respErr.message }, 500);
    if (!resp) return json({ ok: false, reason: "response_not_found" }, 404);
    resolvedResponseId = response_id;

    if (override_email && typeof override_email === "string" && /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(override_email.trim())) {
      const ov = override_email.trim();
      if (ov !== (resp as any).override_email) {
        await admin.from("responses").update({ override_email: ov }).eq("id", response_id);
        (resp as any).override_email = ov;
      }
    }

    signerEmail = ((resp as any).override_email || "").trim();
    if ((resp as any).applicant_id) {
      const { data: off } = await admin
        .from("job_offers")
        .select("candidate_name, candidate_email")
        .eq("candidate_id", (resp as any).applicant_id)
        .order("created_at", { ascending: false })
        .limit(1)
        .maybeSingle();
      if (off?.candidate_name) signerName = off.candidate_name;
      if (!signerEmail && off?.candidate_email) signerEmail = off.candidate_email.trim();
    }
    if (!signerName) {
      const { data: ob } = await admin
        .from("onboarding_submissions").select("full_name, email")
        .eq("response_id", response_id).maybeSingle();
      if (ob?.full_name) signerName = ob.full_name;
      if (!signerEmail && ob?.email) signerEmail = String(ob.email).trim();
    }
    if (!signerName) {
      signerName = ((resp as any).override_name || "").trim();
    }
    if (!signerName) {
      // last fallback to answers
      const { data: qs } = await admin.from("questions").select("id, type, label").eq("form_id", (resp as any).form_id);
      const { data: ans } = await admin.from("answers").select("question_id, answer_text").eq("response_id", response_id);
      const q = qs?.find((q: any) => /name/i.test(q.label));
      if (q) signerName = (ans?.find((a: any) => a.question_id === q.id)?.answer_text || "").trim();
    }
  } else if (directName && directEmail) {
    signerName = String(directName).trim();
    signerEmail = String(directEmail).trim();
  } else {
    return json({ ok: false, reason: "missing_input" }, 400);
  }

  if (!signerEmail || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(signerEmail)) {
    return json({ ok: false, reason: "no_email" }, 400);
  }
  if (!signerName) return json({ ok: false, reason: "no_name" }, 400);

  // Mint reference + token (token is independent of reference)
  const reference = `CASH-${shortHex(8).toUpperCase()}`;
  const token = shortHex(48); // 48 hex chars

  // Insert leave_requests row as a cash advance (ca_* filled when recipient submits)
  const { error: insErr } = await admin.from("leave_requests").insert({
    response_id: resolvedResponseId,
    external_reference: reference,
    signer_name: signerName,
    signer_email: signerEmail,
    token,
    status: "invited",
    doc_type: "cash_advance",
    hr_copy_requested: hrCopyRequested,
    hr_copy_email_override: hrCopyEmailOverride,
  });
  if (insErr) return json({ ok: false, reason: "persist_failed", detail: insErr.message }, 500);

  // Read-after-write guard
  const { data: verifyRow } = await admin
    .from("leave_requests").select("id, token").eq("external_reference", reference).maybeSingle();
  if (!verifyRow) return json({ ok: false, reason: "persist_failed", detail: "row not found after insert" }, 500);

  // Send invite via send-dual-email
  const link = `${PUBLIC_BASE}/cash-advance/${token}`;
  const firstName = signerName.trim().split(/\s+/)[0] || signerName;

  const emailResp = await fetch(`${SUPABASE_URL}/functions/v1/send-dual-email`, {
    method: "POST",
    headers: { Authorization: `Bearer ${SVC}`, "Content-Type": "application/json" },
    body: JSON.stringify({
      to: signerEmail,
      stage: "cash_advance_form_sent",
      sender_a: buildCashSenderA(firstName, link),
      sender_b: buildCashSenderB(firstName, link),
    }),
  });
  const emailJson = await emailResp.json().catch(() => ({}));
  if (!emailResp.ok) {
    return json({
      ok: false, reason: "email_failed", detail: emailJson,
      token, external_reference: reference,
    }, 502);
  }

  return json({ ok: true, token, external_reference: reference, link });
});
