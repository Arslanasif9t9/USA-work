// generate-custom-document-pdf: admin/HR-only. Builds a custom one-page (auto-
// paginating) signable PDF and uploads it to the public `offer-letters` bucket
// under custom-document/. CLONED from generate-nda-pdf.
import { createClient } from "npm:@supabase/supabase-js@2";
import { buildCustomDocumentPdf, type Branding } from "../_shared/custom-document-pdf.ts";
import { uploadPdf } from "../_shared/offer-pdf.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

const json = (b: unknown, status = 200) =>
  new Response(JSON.stringify(b), {
    status,
    headers: { ...corsHeaders, "content-type": "application/json" },
  });

async function requireAdmin(req: Request): Promise<Response | null> {
  const auth = req.headers.get("Authorization") || "";
  if (!auth.startsWith("Bearer ")) return json({ error: "missing_auth" }, 401);
  const userClient = createClient(
    Deno.env.get("SUPABASE_URL")!,
    Deno.env.get("SUPABASE_ANON_KEY")!,
    { global: { headers: { Authorization: auth } } },
  );
  const { data: u } = await userClient.auth.getUser();
  if (!u?.user) return json({ error: "invalid_jwt" }, 401);
  const admin = createClient(
    Deno.env.get("SUPABASE_URL")!,
    Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!,
  );
  const { data: row } = await admin
    .from("users").select("role").eq("id", u.user.id).maybeSingle();
  if (!row || row.role !== "admin") return json({ error: "forbidden" }, 403);
  return null;
}

function sanitizeBranding(raw: unknown): Branding | null {
  if (!raw || typeof raw !== "object") return null;
  const b = raw as Record<string, unknown>;
  const companyName = String(b.companyName ?? "").trim();
  if (!companyName) return null;
  return {
    companyName,
    email: String(b.email ?? "").trim(),
    website: String(b.website ?? "").trim(),
  };
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });
  const guard = await requireAdmin(req);
  if (guard) return guard;

  let body: {
    title?: string; body_text?: string; reference?: string;
    signer_name?: string; manager_name?: string; branding?: unknown;
  };
  try { body = await req.json(); } catch { return json({ error: "invalid_json" }, 400); }
  const title = String(body?.title ?? "").trim();
  const bodyText = String(body?.body_text ?? "").trim();
  const reference = String(body?.reference ?? "").trim();
  const signerName = String(body?.signer_name ?? "").trim();
  const managerName = String(body?.manager_name ?? "").trim() || "Cathy Anderson";
  const branding = sanitizeBranding(body?.branding);
  if (!title || !bodyText || !reference || !signerName) {
    return json({ error: "missing_fields" }, 400);
  }

  let pdfBytes: Uint8Array;
  let warning: string | null = null;
  let pageCount = 0;
  let signatureRect: unknown = null;
  try {
    const out = await buildCustomDocumentPdf({
      title, body_text: bodyText, reference, signer_name: signerName, manager_name: managerName, branding,
    });
    pdfBytes = out.bytes;
    warning = out.warning;
    pageCount = out.pageCount;
    signatureRect = out.signatureRect;
  } catch (e) {
    return json({ error: "pdf_build_failed", detail: (e as Error).message }, 500);
  }

  const lastName = signerName.trim().split(/\s+/).slice(-1)[0]?.replace(/[^A-Za-z0-9_-]/g, "_") || "Signer";
  const filename = `custom-document/${reference}-${lastName}.pdf`;
  const up = await uploadPdf(pdfBytes, filename);
  if (!up.url) {
    return json({ error: "upload_failed", detail: up.error }, 500);
  }
  return json({
    success: true,
    pdf_url: up.url,
    filename,
    page_count: pageCount,
    signature_rect: signatureRect,
    font_warning: warning,
  });
});
