// Shared email-matcher for leave_requests rows. Used by submit-leave (auto on
// signing) and rematch-leave (manual HR retry). Idempotent, race-safe, and
// never throws. Resolves matched_response_id by trying:
//   1) responses.override_email (case-insensitive)
//   2) job_offers.candidate_email (signed) -> candidate_id -> responses.applicant_id
//   3) onboarding_submissions.email
import type { SupabaseClient } from "npm:@supabase/supabase-js@2";

export async function matchLeaveToResponse(
  admin: SupabaseClient,
  leaveId: string,
  signerEmail: string,
): Promise<{ matched: boolean; response_id?: string; reason?: string }> {
  try {
    if (!signerEmail) return { matched: false, reason: "no_email" };

    const { data: cur } = await admin
      .from("leave_requests")
      .select("matched_response_id")
      .eq("id", leaveId)
      .maybeSingle();
    if (!cur) return { matched: false, reason: "leave_not_found" };
    if (cur.matched_response_id) {
      return { matched: false, response_id: cur.matched_response_id, reason: "already_matched" };
    }

    const email = signerEmail.trim();
    let foundResponseId: string | null = null;

    // 1) responses.override_email
    const { data: r1 } = await admin
      .from("responses")
      .select("id, submitted_at")
      .ilike("override_email", email)
      .order("submitted_at", { ascending: false })
      .limit(1)
      .maybeSingle();
    if (r1?.id) foundResponseId = r1.id;

    // 2) job_offers.candidate_email (signed) -> responses
    if (!foundResponseId) {
      const { data: off } = await admin
        .from("job_offers")
        .select("candidate_id, signed_at, created_at")
        .ilike("candidate_email", email)
        .eq("status", "signed")
        .order("signed_at", { ascending: false, nullsFirst: false })
        .limit(1)
        .maybeSingle();
      if (off?.candidate_id) {
        const { data: r2 } = await admin
          .from("responses")
          .select("id, submitted_at")
          .eq("applicant_id", off.candidate_id)
          .order("submitted_at", { ascending: false })
          .limit(1)
          .maybeSingle();
        if (r2?.id) foundResponseId = r2.id;
      }
    }

    // 3) onboarding_submissions.email
    if (!foundResponseId) {
      const { data: ob } = await admin
        .from("onboarding_submissions")
        .select("response_id, created_at")
        .ilike("email", email)
        .order("created_at", { ascending: false })
        .limit(1)
        .maybeSingle();
      if (ob?.response_id) foundResponseId = ob.response_id;
    }

    if (!foundResponseId) return { matched: false, reason: "no_match" };

    const { error: upErr } = await admin
      .from("leave_requests")
      .update({ matched_response_id: foundResponseId, matched_at: new Date().toISOString() })
      .eq("id", leaveId)
      .is("matched_response_id", null); // race-safe
    if (upErr) {
      console.log("[match-leave] update failed:", upErr.message);
      return { matched: false, reason: "update_failed" };
    }
    console.log(`[match-leave] matched leave ${leaveId} -> response ${foundResponseId}`);
    return { matched: true, response_id: foundResponseId };
  } catch (e: any) {
    console.log("[match-leave] threw:", String(e?.message || e));
    return { matched: false, reason: "exception" };
  }
}
