export type ScheduleKey =
  | "day_bird"
  | "midday"
  | "afternoon"
  | "evening"
  | "night_owl"
  | "custom";

export type LockedSchedulePreset = {
  label: string;
  weekday_start: string;
  weekday_end: string;
  saturday_start: string;
  saturday_end: string;
};

export const LOCKED_SCHEDULE_PRESETS: Record<Exclude<ScheduleKey, "custom">, LockedSchedulePreset> = {
  day_bird: {
    label: "Day bird — Mon-Fri 7:00 AM – 2:00 PM, Sat 7:00 AM – 10:30 AM",
    weekday_start: "07:00",
    weekday_end: "14:00",
    saturday_start: "07:00",
    saturday_end: "10:30",
  },
  midday: {
    label: "Midday — Mon-Fri 10:00 AM – 6:00 PM, Sat 10:00 AM – 2:00 PM",
    weekday_start: "10:00",
    weekday_end: "18:00",
    saturday_start: "10:00",
    saturday_end: "14:00",
  },
  afternoon: {
    label: "Afternoon — Mon-Fri 3:00 PM – 11:00 PM, Sat 3:00 PM – 7:00 PM",
    weekday_start: "15:00",
    weekday_end: "23:00",
    saturday_start: "15:00",
    saturday_end: "19:00",
  },
  evening: {
    label: "Evening — Mon-Fri 6:00 PM – 2:00 AM, Sat 6:00 PM – 10:00 PM",
    weekday_start: "18:00",
    weekday_end: "02:00",
    saturday_start: "18:00",
    saturday_end: "22:00",
  },
  night_owl: {
    label: "Night owl — Mon-Fri 12:00 AM – 8:00 AM, Sat 12:00 AM – 4:00 AM",
    weekday_start: "00:00",
    weekday_end: "08:00",
    saturday_start: "00:00",
    saturday_end: "04:00",
  },
};

export const DEFAULT_SCHEDULE_PRESET: Exclude<ScheduleKey, "custom"> = "midday";

export const getLockedSchedulePreset = (key?: string | null): LockedSchedulePreset | null => {
  if (!key || key === "custom") return null;
  return LOCKED_SCHEDULE_PRESETS[key as Exclude<ScheduleKey, "custom">] ?? null;
};
