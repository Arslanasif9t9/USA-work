// Shared R2 part-finalization core. Lists the live per-call part objects
//   interviews/{response_id}/{call_id}/partNNN.webm
// byte-concatenates them IN ORDER into the final object
//   interviews/{response_id}/{call_id}.webm
// then deletes the parts and returns the final public_url.
//
// WebM timeslice chunks byte-concatenate into a replayable file; the Render merge
// re-encodes anyway. If NO parts exist, returns { ok:false, parts_found:0 } so the
// caller can fall back to a single-blob whole-object PUT (no regression).
//
// This is the single source of truth for the concat logic — shared by
// finalize-interview-parts (token-gated, live client) and
// reap-orphaned-interview-videos (server-side cron/on-demand recovery).

const R2_ACCESS_KEY_ID = Deno.env.get("R2_ACCESS_KEY_ID")!;
const R2_SECRET_ACCESS_KEY = Deno.env.get("R2_SECRET_ACCESS_KEY")!;
const R2_ENDPOINT = Deno.env.get("R2_ENDPOINT")!; // https://<acct>.r2.cloudflarestorage.com
const R2_BUCKET = Deno.env.get("R2_BUCKET")!;

const enc = new TextEncoder();

async function sha256Hex(data: Uint8Array | string): Promise<string> {
  const bytes = typeof data === "string" ? enc.encode(data) : data;
  const buf = await crypto.subtle.digest("SHA-256", bytes as BufferSource);
  return [...new Uint8Array(buf)].map((b) => b.toString(16).padStart(2, "0")).join("");
}

async function hmac(key: ArrayBuffer | Uint8Array, data: string): Promise<ArrayBuffer> {
  const cryptoKey = await crypto.subtle.importKey(
    "raw", key as BufferSource, { name: "HMAC", hash: "SHA-256" }, false, ["sign"],
  );
  return crypto.subtle.sign("HMAC", cryptoKey, enc.encode(data));
}

function encodeKey(objectKey: string): string {
  return objectKey.split("/").map(encodeURIComponent).join("/");
}

// SigV4 authorization-header signed request against the R2 S3 API (path-style).
async function signedFetch(
  method: string,
  canonicalUri: string,
  query: Record<string, string>,
  body: Uint8Array | null,
): Promise<Response> {
  const url = new URL(R2_ENDPOINT);
  const host = url.host;
  const region = "auto";
  const service = "s3";
  const now = new Date();
  const amzDate = now.toISOString().replace(/[:-]|\.\d{3}/g, "");
  const dateStamp = amzDate.slice(0, 8);
  const credentialScope = `${dateStamp}/${region}/${service}/aws4_request`;

  const payloadHash = await sha256Hex(body ?? new Uint8Array());
  const canonicalQueryString = Object.keys(query)
    .sort()
    .map((k) => `${encodeURIComponent(k)}=${encodeURIComponent(query[k])}`)
    .join("&");

  const canonicalHeaders =
    `host:${host}\n` +
    `x-amz-content-sha256:${payloadHash}\n` +
    `x-amz-date:${amzDate}\n`;
  const signedHeaders = "host;x-amz-content-sha256;x-amz-date";

  const canonicalRequest =
    `${method}\n${canonicalUri}\n${canonicalQueryString}\n${canonicalHeaders}\n${signedHeaders}\n${payloadHash}`;

  const stringToSign =
    `AWS4-HMAC-SHA256\n${amzDate}\n${credentialScope}\n${await sha256Hex(canonicalRequest)}`;

  const kDate = await hmac(enc.encode("AWS4" + R2_SECRET_ACCESS_KEY), dateStamp);
  const kRegion = await hmac(kDate, region);
  const kService = await hmac(kRegion, service);
  const kSigning = await hmac(kService, "aws4_request");
  const sigBuf = await hmac(kSigning, stringToSign);
  const signature = [...new Uint8Array(sigBuf)].map((b) => b.toString(16).padStart(2, "0")).join("");

  const authorization =
    `AWS4-HMAC-SHA256 Credential=${R2_ACCESS_KEY_ID}/${credentialScope}, ` +
    `SignedHeaders=${signedHeaders}, Signature=${signature}`;

  const qs = canonicalQueryString ? `?${canonicalQueryString}` : "";
  return fetch(`${url.protocol}//${host}${canonicalUri}${qs}`, {
    method,
    headers: {
      "x-amz-date": amzDate,
      "x-amz-content-sha256": payloadHash,
      Authorization: authorization,
      ...(body ? { "Content-Type": "video/webm" } : {}),
    },
    body: body ?? undefined,
  });
}

export type FinalizeResult = {
  ok: boolean;
  parts_found: number;
  deleted?: number;
  bytes?: number;
  object_key?: string;
  public_base?: string;
  public_url?: string;
  error?: string;
  message?: string;
};

export type FinalObjectResult = {
  exists: boolean;
  bytes: number;
  object_key: string;
  public_url: string;
};

// HEAD the already-finalized single object interviews/{response_id}/{call_id}.webm.
// Used when NO partNNN parts exist (single-blob upload, or parts already
// concatenated+deleted) so callers can still recover video_url from a healthy
// final object. Read-only: never writes or deletes anything in R2.
export async function headFinalObject(
  responseId: string,
  retellCallId: string,
): Promise<FinalObjectResult> {
  const safeCallId = String(retellCallId).replace(/[^a-zA-Z0-9_-]/g, "_");
  const finalKey = `interviews/${responseId}/${safeCallId}.webm`;
  const endpoint = R2_ENDPOINT.replace(/\/+$/, "");
  const public_url = `${endpoint}/${R2_BUCKET}/${finalKey}`;
  const res = await signedFetch("HEAD", `/${encodeURIComponent(R2_BUCKET)}/${encodeKey(finalKey)}`, {}, null);
  await res.text().catch(() => "");
  if (!res.ok) return { exists: false, bytes: 0, object_key: finalKey, public_url };
  const len = Number(res.headers.get("content-length") || "0");
  return { exists: true, bytes: len, object_key: finalKey, public_url };
}

// Concatenate the live part objects for one interview call into the final object.
// Keyed by response_id + retell_call_id (no token) so both the live client path
// and the server reaper can call it.
export async function finalizePartsForCall(
  responseId: string,
  retellCallId: string,
): Promise<FinalizeResult> {
  const safeCallId = String(retellCallId).replace(/[^a-zA-Z0-9_-]/g, "_");
  const prefix = `interviews/${responseId}/${safeCallId}/`;
  const finalKey = `interviews/${responseId}/${safeCallId}.webm`;
  const endpoint = R2_ENDPOINT.replace(/\/+$/, "");
  const public_base = `${endpoint}/${R2_BUCKET}`;
  const public_url = `${public_base}/${finalKey}`;

  // 1) LIST part objects under the per-call folder.
  const listRes = await signedFetch(
    "GET",
    `/${encodeURIComponent(R2_BUCKET)}`,
    { "list-type": "2", prefix },
    null,
  );
  const listXml = await listRes.text();
  if (!listRes.ok) {
    console.error("[r2-finalize] list failed:", listRes.status, listXml.slice(0, 300));
    return { ok: false, error: `list_failed_${listRes.status}`, parts_found: 0 };
  }
  const keys = [...listXml.matchAll(/<Key>([^<]+)<\/Key>/g)]
    .map((m) => m[1])
    .filter((k) => k.startsWith(prefix) && /\/part\d+\.webm$/.test(k))
    .sort(); // zero-padded => lexicographic == numeric order

  if (keys.length === 0) {
    return { ok: false, parts_found: 0, message: "no_parts" };
  }

  // 2) Download each part in order and byte-concatenate.
  const buffers: Uint8Array[] = [];
  let total = 0;
  for (const key of keys) {
    const getRes = await signedFetch("GET", `/${encodeURIComponent(R2_BUCKET)}/${encodeKey(key)}`, {}, null);
    if (!getRes.ok) {
      const t = await getRes.text().catch(() => "");
      console.error("[r2-finalize] get part failed:", key, getRes.status, t.slice(0, 200));
      return { ok: false, error: `get_part_failed_${getRes.status}`, parts_found: keys.length };
    }
    const buf = new Uint8Array(await getRes.arrayBuffer());
    buffers.push(buf);
    total += buf.byteLength;
  }
  const merged = new Uint8Array(total);
  let off = 0;
  for (const b of buffers) { merged.set(b, off); off += b.byteLength; }

  // 3) PUT the concatenated final object.
  const putRes = await signedFetch("PUT", `/${encodeURIComponent(R2_BUCKET)}/${encodeKey(finalKey)}`, {}, merged);
  if (!putRes.ok) {
    const t = await putRes.text().catch(() => "");
    console.error("[r2-finalize] put final failed:", putRes.status, t.slice(0, 200));
    return { ok: false, error: `put_final_failed_${putRes.status}`, parts_found: keys.length };
  }

  // 4) Delete the parts (best-effort; failures don't block — final object is written).
  let deleted = 0;
  for (const key of keys) {
    try {
      const delRes = await signedFetch("DELETE", `/${encodeURIComponent(R2_BUCKET)}/${encodeKey(key)}`, {}, null);
      await delRes.text().catch(() => "");
      if (delRes.ok || delRes.status === 204) deleted++;
    } catch (delErr) {
      console.warn("[r2-finalize] delete part failed (non-fatal):", key, String(delErr));
    }
  }

  return {
    ok: true,
    parts_found: keys.length,
    deleted,
    bytes: total,
    object_key: finalKey,
    public_base,
    public_url,
  };
}
