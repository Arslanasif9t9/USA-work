// Shared HR auth helpers
import { createClient } from "npm:@supabase/supabase-js@2";

export const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

export const json = (body: unknown, status = 200) =>
  new Response(JSON.stringify(body), {
    status,
    headers: { ...corsHeaders, "Content-Type": "application/json" },
  });

export type HrIdentity = {
  authUserId: string;
  email: string;
  hrId: string | null;
  displayName: string | null;
  role: string | null;
};

const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
const ANON_KEY = Deno.env.get("SUPABASE_ANON_KEY")!;
const SERVICE_KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;

export const adminClient = () => createClient(SUPABASE_URL, SERVICE_KEY);

export async function requireHr(req: Request): Promise<HrIdentity | Response> {
  const authHeader = req.headers.get("Authorization");
  if (!authHeader?.startsWith("Bearer ")) return json({ error: "unauthorized" }, 401);
  const token = authHeader.slice(7).trim();

  // ── Service-role bypass (ADDITIVE — for the internal scheduler only) ──
  // When the caller presents the project's SERVICE_ROLE key (used by
  // fire-scheduled-sends / replay wrappers running server-side), accept it as
  // an authorized HR call. This does NOT change behavior for real HR user
  // tokens below — Send Now stays exactly as today. An optional
  // `x-acting-hr-email` header lets the scheduler attribute the action to the
  // HR who created the scheduled send; otherwise we fall back to the first
  // active HR profile so downstream `hrId` checks pass.
  if (SERVICE_KEY && token === SERVICE_KEY) {
    const admin = adminClient();
    const actingEmail = (req.headers.get("x-acting-hr-email") || "").toLowerCase().trim();
    let hr: any = null;
    if (actingEmail) {
      const { data } = await admin
        .from("hr_users")
        .select("id, email, display_name, role, is_active")
        .ilike("email", actingEmail)
        .maybeSingle();
      hr = data;
    }
    if (!hr) {
      const { data } = await admin
        .from("hr_users")
        .select("id, email, display_name, role, is_active")
        .eq("is_active", true)
        .order("created_at", { ascending: true })
        .limit(1)
        .maybeSingle();
      hr = data;
    }
    return {
      authUserId: "service-role",
      email: hr?.email ?? "scheduler@service",
      hrId: hr?.id ?? null,
      displayName: hr?.display_name ?? "Scheduler",
      role: hr?.role ?? "hr",
    };
  }

  // Validate JWT via admin client. Using getUser(token) avoids relying on the
  // legacy ANON apikey (which no longer authenticates ES256 user JWTs under
  // the new signing-keys system and was causing spurious 401s).
  const admin = adminClient();
  let userResp = await admin.auth.getUser(token);
  if (userResp.error || !userResp.data?.user) {
    // Fallback to the legacy user-client path for older HS256 tokens.
    const userClient = createClient(SUPABASE_URL, ANON_KEY, {
      global: { headers: { Authorization: authHeader } },
    });
    const fallback = await userClient.auth.getUser();
    if (fallback.error || !fallback.data?.user) return json({ error: "unauthorized" }, 401);
    userResp = fallback as any;
  }
  const user = userResp.data!.user!;
  const email = (user.email || "").toLowerCase();
  const { data: hr } = await admin
    .from("hr_users")
    .select("id, display_name, role, is_active")
    .ilike("email", email)
    .maybeSingle();
  return {
    authUserId: user.id,
    email,
    hrId: hr?.id ?? null,
    displayName: hr?.display_name ?? null,
    role: hr?.role ?? null,
  };
}

