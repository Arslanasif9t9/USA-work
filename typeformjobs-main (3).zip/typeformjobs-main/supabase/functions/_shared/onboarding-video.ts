// Single source of truth for the default EIA onboarding training video.
// Every minted onboarding-quiz token must carry a playable video_url; if the
// caller doesn't provide one, fall back to this default so a candidate never
// hits a dead player.
export const DEFAULT_ONBOARDING_VIDEO_URL = "https://player.vimeo.com/video/1199893890";
