// Shared PDF generation for the General Leave Request form.
// Mirrors nda-pdf/settlement-pdf branding (navy + gold, Cormorant + Inter,
// per-page letterhead).
import { PDFDocument, PDFFont, PDFPage, rgb, StandardFonts } from "npm:pdf-lib@1.17.1";
import fontkit from "npm:@pdf-lib/fontkit@1.1.1";

const ASSETS_BASE =
  Deno.env.get("SUPABASE_URL")! + "/storage/v1/object/public/assets/fonts";

const FONT_URLS = {
  cgRegular: `${ASSETS_BASE}/CormorantGaramond-Regular.ttf`,
  cgSemi: `${ASSETS_BASE}/CormorantGaramond-SemiBold.ttf`,
  cgItalic: `${ASSETS_BASE}/CormorantGaramond-Italic.ttf`,
  interReg: `${ASSETS_BASE}/Inter-Regular.ttf`,
  interSemi: `${ASSETS_BASE}/Inter-SemiBold.ttf`,
  allura: `${ASSETS_BASE}/Allura-Regular.ttf`,
};

let FONT_BYTES: Record<string, Uint8Array> | null = null;
let FONT_ERR: string | null = null;

async function loadFonts(): Promise<{ bytes: Record<string, Uint8Array> | null; error: string | null }> {
  if (FONT_BYTES) return { bytes: FONT_BYTES, error: null };
  if (FONT_ERR) return { bytes: null, error: FONT_ERR };
  try {
    const entries = await Promise.all(
      Object.entries(FONT_URLS).map(async ([k, url]) => {
        const r = await fetch(url);
        if (!r.ok) throw new Error(`font ${k} ${r.status}`);
        return [k, new Uint8Array(await r.arrayBuffer())] as const;
      }),
    );
    FONT_BYTES = Object.fromEntries(entries);
    return { bytes: FONT_BYTES, error: null };
  } catch (e) {
    FONT_ERR = (e as Error).message;
    return { bytes: null, error: FONT_ERR };
  }
}

const NAVY = rgb(0.102, 0.145, 0.278);
const GOLD = rgb(0.69, 0.553, 0.341);
const INK = rgb(0.102, 0.133, 0.212);
const MUTED = rgb(0.42, 0.447, 0.502);
const HAIRLINE = rgb(0.882, 0.894, 0.925);
const GREEN = rgb(0.086, 0.392, 0.204);
const RED = rgb(0.69, 0.118, 0.149);

const PAGE_W = 612;
const PAGE_H = 792;
const M_TOP = 40;
const M_BOT = 40;
const M_SIDE = 61;
const CONTENT_W = PAGE_W - 2 * M_SIDE;

type Fonts = {
  cgReg: PDFFont; cgSemi: PDFFont; cgItalic: PDFFont;
  interReg: PDFFont; interSemi: PDFFont;
  allura: PDFFont;
};

const wrap = (text: string, font: PDFFont, size: number, maxW: number): string[] => {
  const out: string[] = [];
  for (const para of (text || "").split("\n")) {
    if (!para) { out.push(""); continue; }
    const words = para.split(/\s+/);
    let cur = "";
    for (const w of words) {
      const test = cur ? `${cur} ${w}` : w;
      if (font.widthOfTextAtSize(test, size) <= maxW || !cur) cur = test;
      else { out.push(cur); cur = w; }
    }
    if (cur) out.push(cur);
  }
  return out;
};

const drawLetterhead = (page: PDFPage, f: Fonts): number => {
  const top = PAGE_H - M_TOP;
  page.drawText("EIA", { x: M_SIDE, y: top - 20, font: f.cgSemi, size: 24, color: NAVY });
  page.drawText("Expert Intuitive Advisor Inc.", { x: M_SIDE, y: top - 33, font: f.cgItalic, size: 9, color: MUTED });
  page.drawText("The intelligence layer between humans and AI.", { x: M_SIDE, y: top - 44, font: f.cgItalic, size: 8, color: MUTED });
  const right = "EXPERTINTUITIVEADVISOR.COM";
  const rW = f.interSemi.widthOfTextAtSize(right, 8) + 1 * (right.length - 1);
  page.drawText(right, { x: PAGE_W - M_SIDE - rW, y: top - 20, font: f.interSemi, size: 8, color: NAVY, characterSpacing: 1 });
  const right2 = "HR@EXPERTINTUITIVEADVISOR.COM";
  const r2W = f.interReg.widthOfTextAtSize(right2, 8) + 1 * (right2.length - 1);
  page.drawText(right2, { x: PAGE_W - M_SIDE - r2W, y: top - 33, font: f.interReg, size: 8, color: MUTED, characterSpacing: 1 });
  const lineY = top - 56;
  page.drawLine({ start: { x: M_SIDE, y: lineY }, end: { x: M_SIDE + CONTENT_W, y: lineY }, thickness: 1.5, color: NAVY });
  return lineY - 24;
};

const drawFooter = (page: PDFPage, f: Fonts, pageNum: number, total: number) => {
  page.drawText("Expert Intuitive Advisor Inc. — Confidential", {
    x: M_SIDE, y: M_BOT - 6, font: f.cgItalic, size: 7, color: MUTED,
  });
  const txt = `Page ${pageNum} of ${total}`;
  const w = f.cgItalic.widthOfTextAtSize(txt, 7);
  page.drawText(txt, { x: PAGE_W - M_SIDE - w, y: M_BOT - 6, font: f.cgItalic, size: 7, color: MUTED });
};

export type LeaveData = {
  signer_name: string;
  reference: string;
  reason: string | null;
  start_date: string | null;
  num_days: string | null;
  hours_missed: string | null;
  makeup_choice: string | null;
  makeup_plan: string | null;
  coverer_name: string | null;
  agreed_with_coverer: boolean | null;
  trained_coverer: boolean | null;
  typed_name: string | null;
  signature_data: string | null;
  signature_date: string | null;
  status: string; // 'pending_approval' | 'approved' | 'declined'
  hr_decision_note: string | null;
  decided_at: string | null;
};

export type LeaveBuildResult = { bytes: Uint8Array; pageCount: number; warning: string | null };

function fmtBool(v: boolean | null): string {
  if (v === true) return "Yes";
  if (v === false) return "No";
  return "—";
}

function fmtChoice(v: string | null): string {
  if (!v) return "—";
  if (v === "make_up") return "Make up the hours";
  if (v === "deduct") return "Deduct from pay";
  if (v === "other") return "Other";
  return v;
}

export async function buildLeavePdf(data: LeaveData): Promise<LeaveBuildResult> {
  const pdf = await PDFDocument.create();
  pdf.registerFontkit(fontkit);

  const { bytes: fb, error: fontErr } = await loadFonts();
  let f: Fonts;
  let warning: string | null = null;
  if (!fb) {
    warning = `font_load_failed: ${fontErr}`;
    const hel = await pdf.embedFont(StandardFonts.Helvetica);
    const helBold = await pdf.embedFont(StandardFonts.HelveticaBold);
    const helItalic = await pdf.embedFont(StandardFonts.HelveticaOblique);
    f = { cgReg: hel, cgSemi: helBold, cgItalic: helItalic, interReg: hel, interSemi: helBold, allura: helItalic };
  } else {
    f = {
      cgReg: await pdf.embedFont(fb.cgRegular, { subset: true }),
      cgSemi: await pdf.embedFont(fb.cgSemi, { subset: true }),
      cgItalic: await pdf.embedFont(fb.cgItalic, { subset: true }),
      interReg: await pdf.embedFont(fb.interReg, { subset: true }),
      interSemi: await pdf.embedFont(fb.interSemi, { subset: true }),
      allura: await pdf.embedFont(fb.allura, { subset: false }),
    };
  }

  const pages: PDFPage[] = [];
  let page = pdf.addPage([PAGE_W, PAGE_H]);
  pages.push(page);
  let y = drawLetterhead(page, f);

  const newPage = () => {
    page = pdf.addPage([PAGE_W, PAGE_H]);
    pages.push(page);
    y = drawLetterhead(page, f);
  };
  const ensure = (need: number) => { if (y - need < M_BOT + 20) newPage(); };

  // Title
  ensure(60);
  page.drawText("LEAVE REQUEST", { x: M_SIDE, y: y - 18, font: f.cgSemi, size: 18, color: NAVY });
  y -= 26;
  page.drawText("Expert Intuitive Advisor Inc.", { x: M_SIDE, y: y - 12, font: f.cgItalic, size: 12, color: GOLD });
  y -= 28;

  // Reference + signer
  page.drawText(`Reference: ${data.reference}`, { x: M_SIDE, y, font: f.interReg, size: 9, color: MUTED });
  const sn = `Employee: ${data.signer_name}`;
  const snW = f.interReg.widthOfTextAtSize(sn, 9);
  page.drawText(sn, { x: PAGE_W - M_SIDE - snW, y, font: f.interReg, size: 9, color: MUTED });
  y -= 14;
  page.drawLine({ start: { x: M_SIDE, y }, end: { x: M_SIDE + CONTENT_W, y }, thickness: 1, color: HAIRLINE });
  y -= 18;

  // Field renderer
  const drawField = (label: string, value: string) => {
    const labelLines = [label];
    const valueLines = wrap(value || "—", f.interReg, 10.5, CONTENT_W);
    const need = 14 + valueLines.length * 14 + 8;
    ensure(need);
    page.drawText(label, { x: M_SIDE, y, font: f.interSemi, size: 9, color: NAVY, characterSpacing: 1 });
    y -= 14;
    for (const ln of valueLines) {
      page.drawText(ln, { x: M_SIDE, y, font: f.interReg, size: 10.5, color: INK });
      y -= 14;
    }
    y -= 6;
  };

  drawField("REASON FOR LEAVE", data.reason || "—");
  drawField("START DATE", data.start_date || "—");
  drawField("NUMBER OF DAYS", data.num_days || "—");
  drawField("WORKING HOURS MISSED", data.hours_missed || "—");
  drawField("PLAN TO RENDER HOURS", `${fmtChoice(data.makeup_choice)}${data.makeup_plan ? ` — ${data.makeup_plan}` : ""}`);
  drawField("WHO WILL COVER THE SHIFT", data.coverer_name || "—");
  drawField("AGREED WITH THAT PERSON", fmtBool(data.agreed_with_coverer));
  drawField("TRAINED THAT PERSON", fmtBool(data.trained_coverer));

  y -= 6;

  // Signature block
  const SIG_HEIGHT = 140;
  if (y - SIG_HEIGHT < M_BOT + 60) newPage();

  page.drawLine({ start: { x: M_SIDE, y }, end: { x: M_SIDE + CONTENT_W, y }, thickness: 1, color: HAIRLINE });
  y -= 14;
  page.drawText("SIGNATURE", { x: M_SIDE, y, font: f.interSemi, size: 9, color: NAVY, characterSpacing: 2 });
  y -= 18;

  // Render typed name in Allura script (matches offer-letter signature style)
  const sigBoxX = M_SIDE;
  const sigBoxY = y - 60;
  const sigBoxW = 240;
  const sigBoxH = 60;
  page.drawRectangle({
    x: sigBoxX, y: sigBoxY, width: sigBoxW, height: sigBoxH,
    borderColor: HAIRLINE, borderWidth: 0.5,
  });

  const typed = (data.typed_name || data.signer_name || "").trim();
  if (typed) {
    // Fit Allura signature inside the box, max 32pt
    let sigSize = 32;
    const maxW = sigBoxW - 16;
    while (sigSize > 12 && f.allura.widthOfTextAtSize(typed, sigSize) > maxW) {
      sigSize -= 1;
    }
    const tW = f.allura.widthOfTextAtSize(typed, sigSize);
    const tH = f.allura.heightAtSize(sigSize);
    page.drawText(typed, {
      x: sigBoxX + (sigBoxW - tW) / 2,
      y: sigBoxY + (sigBoxH - tH) / 2 + 4,
      font: f.allura, size: sigSize, color: NAVY,
    });
  }
  page.drawText("Signature", { x: sigBoxX, y: sigBoxY - 10, font: f.interReg, size: 8, color: MUTED });

  const col2x = M_SIDE + 270;
  page.drawText("Name", { x: col2x, y, font: f.interSemi, size: 9, color: NAVY, characterSpacing: 1 });
  page.drawText(data.typed_name || data.signer_name, { x: col2x, y: y - 16, font: f.interReg, size: 11, color: INK });
  page.drawLine({ start: { x: col2x, y: y - 22 }, end: { x: col2x + 180, y: y - 22 }, thickness: 0.5, color: HAIRLINE });

  page.drawText("Date", { x: col2x, y: y - 40, font: f.interSemi, size: 9, color: NAVY, characterSpacing: 1 });
  page.drawText(data.signature_date || "—", { x: col2x, y: y - 56, font: f.interReg, size: 11, color: INK });
  page.drawLine({ start: { x: col2x, y: y - 62 }, end: { x: col2x + 180, y: y - 62 }, thickness: 0.5, color: HAIRLINE });

  y = sigBoxY - 24;

  // Decision footer
  if (data.status === "approved" || data.status === "declined") {
    ensure(60);
    page.drawLine({ start: { x: M_SIDE, y }, end: { x: M_SIDE + CONTENT_W, y }, thickness: 1, color: HAIRLINE });
    y -= 16;
    const isApproved = data.status === "approved";
    const decidedAt = data.decided_at
      ? new Date(data.decided_at).toLocaleString("en-US", {
          year: "numeric", month: "short", day: "numeric",
          hour: "numeric", minute: "2-digit", hour12: true,
        })
      : "—";
    const headline = isApproved
      ? `APPROVED by HR on ${decidedAt}`
      : `NOT APPROVED — decision on ${decidedAt}`;
    page.drawText(headline, {
      x: M_SIDE, y, font: f.interSemi, size: 11,
      color: isApproved ? GREEN : RED, characterSpacing: 1,
    });
    y -= 18;
    if (data.hr_decision_note && data.hr_decision_note.trim()) {
      const noteLines = wrap(`Note from HR: ${data.hr_decision_note.trim()}`, f.interReg, 10, CONTENT_W);
      for (const ln of noteLines) {
        ensure(14);
        page.drawText(ln, { x: M_SIDE, y, font: f.interReg, size: 10, color: INK });
        y -= 14;
      }
    }
  }

  const total = pages.length;
  pages.forEach((p, i) => drawFooter(p, f, i + 1, total));

  const bytes = await pdf.save();
  return { bytes, pageCount: total, warning };
}
