// Shared PDF generator for the Exit Settlement & Confidentiality Agreement (NDA 2).
// Signed when an employee leaves. Mirrors _shared/joining-nda-pdf.ts structure +
// EIA branding (navy + gold, Cormorant + Inter). Content is VERBATIM per spec.
import { PDFDocument, PDFFont, PDFPage, rgb, StandardFonts } from "npm:pdf-lib@1.17.1";
import fontkit from "npm:@pdf-lib/fontkit@1.1.1";

const ASSETS_BASE =
  Deno.env.get("SUPABASE_URL")! + "/storage/v1/object/public/assets/fonts";

const FONT_URLS = {
  cgRegular: `${ASSETS_BASE}/CormorantGaramond-Regular.ttf`,
  cgSemi: `${ASSETS_BASE}/CormorantGaramond-SemiBold.ttf`,
  cgItalic: `${ASSETS_BASE}/CormorantGaramond-Italic.ttf`,
  interReg: `${ASSETS_BASE}/Inter-Regular.ttf`,
  interSemi: `${ASSETS_BASE}/Inter-SemiBold.ttf`,
};

let FONT_BYTES: Record<string, Uint8Array> | null = null;
let FONT_ERR: string | null = null;

async function loadFonts(): Promise<{ bytes: Record<string, Uint8Array> | null; error: string | null }> {
  if (FONT_BYTES) return { bytes: FONT_BYTES, error: null };
  if (FONT_ERR) return { bytes: null, error: FONT_ERR };
  try {
    const entries = await Promise.all(
      Object.entries(FONT_URLS).map(async ([k, url]) => {
        const r = await fetch(url);
        if (!r.ok) throw new Error(`font ${k} ${r.status}`);
        return [k, new Uint8Array(await r.arrayBuffer())] as const;
      }),
    );
    FONT_BYTES = Object.fromEntries(entries);
    return { bytes: FONT_BYTES, error: null };
  } catch (e) {
    FONT_ERR = (e as Error).message;
    return { bytes: null, error: FONT_ERR };
  }
}

const NAVY = rgb(0.102, 0.145, 0.278);
const GOLD = rgb(0.69, 0.553, 0.341);
const INK = rgb(0.102, 0.133, 0.212);
const MUTED = rgb(0.42, 0.447, 0.502);
const HAIRLINE = rgb(0.882, 0.894, 0.925);

const PAGE_W = 612;
const PAGE_H = 792;
const M_TOP = 40;
const M_BOT = 40;
const M_SIDE = 61;
const CONTENT_W = PAGE_W - 2 * M_SIDE;

type Fonts = {
  cgReg: PDFFont; cgSemi: PDFFont; cgItalic: PDFFont;
  interReg: PDFFont; interSemi: PDFFont;
};

const wrap = (text: string, font: PDFFont, size: number, maxW: number): string[] => {
  const out: string[] = [];
  for (const para of text.split("\n")) {
    if (!para) { out.push(""); continue; }
    const words = para.split(/\s+/);
    let cur = "";
    for (const w of words) {
      const test = cur ? `${cur} ${w}` : w;
      if (font.widthOfTextAtSize(test, size) <= maxW || !cur) cur = test;
      else { out.push(cur); cur = w; }
    }
    if (cur) out.push(cur);
  }
  return out;
};

const drawLetterhead = (page: PDFPage, f: Fonts): number => {
  const top = PAGE_H - M_TOP;
  page.drawText("EIA", { x: M_SIDE, y: top - 20, font: f.cgSemi, size: 24, color: NAVY });
  page.drawText("Expert Intuitive Advisor Inc.", { x: M_SIDE, y: top - 33, font: f.cgItalic, size: 9, color: MUTED });
  page.drawText("57 West 57 Street, New York, NY 10001", { x: M_SIDE, y: top - 44, font: f.cgItalic, size: 8, color: MUTED });
  const right = "EXPERTINTUITIVEADVISOR.COM";
  const rW = f.interSemi.widthOfTextAtSize(right, 8) + 1 * (right.length - 1);
  page.drawText(right, { x: PAGE_W - M_SIDE - rW, y: top - 20, font: f.interSemi, size: 8, color: NAVY, characterSpacing: 1 });
  const right2 = "HR@EXPERTINTUITIVEADVISOR.COM";
  const r2W = f.interReg.widthOfTextAtSize(right2, 8) + 1 * (right2.length - 1);
  page.drawText(right2, { x: PAGE_W - M_SIDE - r2W, y: top - 33, font: f.interReg, size: 8, color: MUTED, characterSpacing: 1 });
  const lineY = top - 56;
  page.drawLine({ start: { x: M_SIDE, y: lineY }, end: { x: M_SIDE + CONTENT_W, y: lineY }, thickness: 1.5, color: NAVY });
  return lineY - 24;
};

const drawFooter = (page: PDFPage, f: Fonts, pageNum: number, total: number) => {
  const year = new Date().getFullYear();
  page.drawText(`© ${year} Expert Intuitive Advisor Inc.`, {
    x: M_SIDE, y: M_BOT - 6, font: f.cgItalic, size: 7, color: MUTED,
  });
  const txt = `Page ${pageNum} of ${total}`;
  const w = f.cgItalic.widthOfTextAtSize(txt, 7);
  page.drawText(txt, { x: PAGE_W - M_SIDE - w, y: M_BOT - 6, font: f.cgItalic, size: 7, color: MUTED });
};

type Bullet = { label?: string; text: string };
type Section = { num: string; title: string; lead?: string; bullets?: Bullet[]; trail?: string; body?: string };

const TITLE = "Exit Settlement & Confidentiality Agreement";
const INTRO =
  "This document is signed at the conclusion of your engagement with Expert Intuitive Advisor Inc. By signing below, you confirm the following:";
const CLOSING =
  "By signing below, I confirm that I fully understand and agree to all terms stated above, and that the obligations from my previously signed Non-Disclosure Agreement remain in full effect.";

const SECTIONS: Section[] = [
  {
    num: "1",
    title: "Final Payment & Full Settlement",
    bullets: [
      { text: "I confirm that I have received full and final payment for all services, work, or obligations provided to the Company." },
      { text: "I confirm that my total outstanding balance is now ZERO, and no further payments are due to me." },
      { text: "I agree that I will not request, demand, or claim any additional payment, compensation, or benefit from the Company after signing this document." },
      { text: "I acknowledge that I am not relying on any verbal statements, informal communications, or alleged promises (including but not limited to statements such as \"John said this\" or \"John said that\")." },
      { text: "I confirm that only this written agreement represents the final and complete understanding between myself and the Company regarding payment." },
      { text: "I release and discharge the Company, its owners, and representatives from any and all claims, demands, or liabilities related to my work or payments." },
    ],
  },
  {
    num: "2",
    title: "Reminder — Your Joining NDA Remains in Effect",
    lead: "You have already signed our Non-Disclosure Agreement (NDA 1) at the start of your engagement. The following key terms from that agreement remain in full effect after your departure:",
    bullets: [
      { label: "Non-Compete", text: "You can never compete with the Company or open, operate, or work for a competing business during your employment and for five (5) years after leaving the Company. This includes giving Company strategies to someone, opening an account for someone, or opening an account under someone. This is a strict policy." },
      { label: "Prohibition on Solicitation", text: "Do not solicit Company clients, partners, or employees for five (5) years after your association ends." },
      { label: "Platform Ban", text: "You agree not to join, register, or work on the same platform(s) currently used by the Company, either directly or indirectly, for five (5) years following the end of your engagement." },
      { label: "No Social Media / No Sharing", text: "You are strictly prohibited from posting, sharing, uploading, or distributing any work-related materials on any platform, including but not limited to Facebook, TikTok, Instagram, Twitter (X), YouTube, any other social media, or any website or internet platform. This includes documents, screenshots, videos, photos, text content, and internal conversations." },
      { label: "Confidentiality", text: "You will not disclose, share, copy, or retain any of the Company's confidential information — including trade secrets, strategies, client data, login credentials, business processes, brand assets, photos, recordings, or internal communications." },
    ],
  },
  {
    num: "3",
    title: "Mandatory Data Deletion",
    lead: "I agree to permanently delete all Company-related materials in my possession, including but not limited to:",
    bullets: [
      { text: "Video files" },
      { text: "Photos" },
      { text: "Documents" },
      { text: "Text files" },
      { text: "Screenshots" },
      { text: "Client information" },
      { text: "Login credentials and passwords" },
    ],
    trail: "No copies (digital or physical) shall be retained.",
  },
  {
    num: "4",
    title: "Account Access Termination",
    bullets: [
      { text: "Log out from all work-related accounts." },
      { text: "Sign out from any browser used for Company work." },
      { text: "Remove all saved passwords." },
      { text: "Delete any Google or email accounts provided by the Company." },
      { text: "Remove Company access from all devices." },
    ],
  },
  {
    num: "5",
    title: "No Future Access or Claims",
    bullets: [
      { text: "I will not attempt to access any Company accounts or systems again." },
      { text: "I will not attempt to recover any deleted data." },
      { text: "I will not claim ownership or rights over any Company materials." },
    ],
  },
  {
    num: "6",
    title: "Legal Enforcement",
    body: "This Agreement is legally binding. Any violation may result in legal action and financial damages.",
  },
];

export type ExitNdaData = { signer_name: string; reference: string };
// Real signature rectangle in PDF bottom-origin coords (fieldTop = top edge of the field box).
export type SignatureRect = { page: number; x: number; fieldTop: number; width: number; height: number };
export type ExitNdaBuildResult = { bytes: Uint8Array; pageCount: number; warning: string | null; signatureRect: SignatureRect };

export async function buildExitNdaPdf(data: ExitNdaData): Promise<ExitNdaBuildResult> {
  const pdf = await PDFDocument.create();
  pdf.registerFontkit(fontkit);

  const { bytes: fb, error: fontErr } = await loadFonts();
  let f: Fonts;
  let warning: string | null = null;
  if (!fb) {
    warning = `font_load_failed: ${fontErr}`;
    const hel = await pdf.embedFont(StandardFonts.Helvetica);
    const helBold = await pdf.embedFont(StandardFonts.HelveticaBold);
    const helItalic = await pdf.embedFont(StandardFonts.HelveticaOblique);
    f = { cgReg: hel, cgSemi: helBold, cgItalic: helItalic, interReg: hel, interSemi: helBold };
  } else {
    f = {
      cgReg: await pdf.embedFont(fb.cgRegular, { subset: true }),
      cgSemi: await pdf.embedFont(fb.cgSemi, { subset: true }),
      cgItalic: await pdf.embedFont(fb.cgItalic, { subset: true }),
      interReg: await pdf.embedFont(fb.interReg, { subset: true }),
      interSemi: await pdf.embedFont(fb.interSemi, { subset: true }),
    };
  }

  const pages: PDFPage[] = [];
  let page = pdf.addPage([PAGE_W, PAGE_H]);
  pages.push(page);
  let y = drawLetterhead(page, f);

  const newPage = () => {
    page = pdf.addPage([PAGE_W, PAGE_H]);
    pages.push(page);
    y = drawLetterhead(page, f);
  };

  const ensure = (need: number) => {
    if (y - need < M_BOT + 20) newPage();
  };

  // Title block
  ensure(60);
  const titleLines = wrap(TITLE, f.cgSemi, 18, CONTENT_W);
  let ty = y;
  for (const line of titleLines) {
    page.drawText(line, { x: M_SIDE, y: ty - 20, font: f.cgSemi, size: 18, color: NAVY });
    ty -= 24;
  }
  y = ty - 10;

  // Reference + signer
  page.drawText(`Reference: ${data.reference}`, { x: M_SIDE, y, font: f.interReg, size: 9, color: MUTED });
  const sn = `Signer: ${data.signer_name}`;
  const snW = f.interReg.widthOfTextAtSize(sn, 9);
  page.drawText(sn, { x: PAGE_W - M_SIDE - snW, y, font: f.interReg, size: 9, color: MUTED });
  y -= 18;
  page.drawLine({ start: { x: M_SIDE, y }, end: { x: M_SIDE + CONTENT_W, y }, thickness: 1, color: HAIRLINE });
  y -= 18;

  // Intro
  const introLines = wrap(INTRO, f.interReg, 10.5, CONTENT_W);
  for (const line of introLines) {
    ensure(16);
    page.drawText(line, { x: M_SIDE, y, font: f.interReg, size: 10.5, color: INK });
    y -= 15;
  }
  y -= 8;

  const drawBullet = (b: Bullet) => {
    const indent = 14;
    if (b.label) {
      const labelText = `${b.label}: `;
      const labelW = f.interSemi.widthOfTextAtSize(labelText, 10);
      const firstLineMaxW = CONTENT_W - indent - labelW;
      const words = b.text.split(/\s+/);
      let cur = "";
      for (const w of words) {
        const test = cur ? `${cur} ${w}` : w;
        if (f.interReg.widthOfTextAtSize(test, 10) <= firstLineMaxW) cur = test;
        else break;
      }
      const firstLine = cur;
      const remainder = b.text.slice(firstLine.length).trim();
      const wrappedRemainder = remainder ? wrap(remainder, f.interReg, 10, CONTENT_W - indent) : [];
      const totalLines = 1 + wrappedRemainder.length;
      ensure(totalLines * 14 + 4);
      page.drawText("•", { x: M_SIDE, y, font: f.interReg, size: 10, color: GOLD });
      page.drawText(labelText, { x: M_SIDE + indent, y, font: f.interSemi, size: 10, color: NAVY });
      page.drawText(firstLine, { x: M_SIDE + indent + labelW, y, font: f.interReg, size: 10, color: INK });
      let by = y - 14;
      for (const ln of wrappedRemainder) {
        page.drawText(ln, { x: M_SIDE + indent, y: by, font: f.interReg, size: 10, color: INK });
        by -= 14;
      }
      y = by - 2;
    } else {
      const lines = wrap(b.text, f.interReg, 10, CONTENT_W - indent);
      ensure(lines.length * 14 + 4);
      page.drawText("•", { x: M_SIDE, y, font: f.interReg, size: 10, color: GOLD });
      let by = y;
      for (const ln of lines) {
        page.drawText(ln, { x: M_SIDE + indent, y: by, font: f.interReg, size: 10, color: INK });
        by -= 14;
      }
      y = by - 2;
    }
  };

  // Sections
  for (const s of SECTIONS) {
    ensure(40);
    page.drawText(s.num, { x: M_SIDE, y, font: f.cgItalic, size: 14, color: GOLD });
    const nw = f.cgItalic.widthOfTextAtSize(s.num, 14);
    page.drawText(s.title.toUpperCase(), {
      x: M_SIDE + nw + 8, y: y + 1, font: f.interSemi, size: 11, color: NAVY, characterSpacing: 2,
    });
    y -= 10;
    page.drawLine({ start: { x: M_SIDE, y }, end: { x: M_SIDE + CONTENT_W, y }, thickness: 1, color: HAIRLINE });
    y -= 14;

    if (s.lead) {
      const lines = wrap(s.lead, f.interReg, 10, CONTENT_W);
      for (const ln of lines) {
        ensure(14);
        page.drawText(ln, { x: M_SIDE, y, font: f.interReg, size: 10, color: INK });
        y -= 14;
      }
      y -= 4;
    }

    if (s.bullets) for (const b of s.bullets) drawBullet(b);

    if (s.trail) {
      y -= 2;
      const lines = wrap(s.trail, f.interReg, 10, CONTENT_W);
      for (const ln of lines) {
        ensure(14);
        page.drawText(ln, { x: M_SIDE, y, font: f.interReg, size: 10, color: INK });
        y -= 14;
      }
    }

    if (s.body) {
      const lines = wrap(s.body, f.interReg, 10, CONTENT_W);
      for (const ln of lines) {
        ensure(14);
        page.drawText(ln, { x: M_SIDE, y, font: f.interReg, size: 10, color: INK });
        y -= 14;
      }
    }

    y -= 10;
  }

  // Closing
  const closingLines = wrap(CLOSING, f.cgItalic, 11, CONTENT_W);
  ensure(closingLines.length * 16 + 8);
  y -= 6;
  for (const ln of closingLines) {
    page.drawText(ln, { x: M_SIDE, y, font: f.cgItalic, size: 11, color: NAVY });
    y -= 16;
  }
  y -= 14;

  // Signature block — reserve ~160pt; SignFlow field on Employee Signature line.
  const SIG_HEIGHT = 160;
  if (y - SIG_HEIGHT < M_BOT + 20) newPage();

  const sigTop = y;
  page.drawLine({ start: { x: M_SIDE, y: sigTop }, end: { x: M_SIDE + CONTENT_W, y: sigTop }, thickness: 1, color: HAIRLINE });
  page.drawText("SIGNATURE", { x: M_SIDE, y: sigTop - 14, font: f.interSemi, size: 9, color: NAVY, characterSpacing: 2 });

  const fieldTop = sigTop - 28;
  const fieldH = 60;
  page.drawRectangle({
    x: M_SIDE, y: fieldTop - fieldH, width: 240, height: fieldH,
    borderColor: HAIRLINE, borderWidth: 0.5,
  });
  page.drawText("Employee Signature", { x: M_SIDE, y: fieldTop - fieldH - 12, font: f.interReg, size: 8, color: MUTED });

  const col2x = M_SIDE + 270;
  page.drawText("Employee Name", { x: col2x, y: sigTop - 14, font: f.interSemi, size: 9, color: NAVY, characterSpacing: 1 });
  page.drawText(data.signer_name || "", { x: col2x, y: sigTop - 32, font: f.interReg, size: 11, color: INK });
  page.drawLine({ start: { x: col2x, y: sigTop - 38 }, end: { x: col2x + 180, y: sigTop - 38 }, thickness: 0.5, color: HAIRLINE });

  page.drawText("Passport / Govt ID Number", { x: col2x, y: sigTop - 56, font: f.interSemi, size: 9, color: NAVY, characterSpacing: 1 });
  page.drawLine({ start: { x: col2x, y: sigTop - 80 }, end: { x: col2x + 180, y: sigTop - 80 }, thickness: 0.5, color: HAIRLINE });
  page.drawText("(If you don't have an ID, write N/A or NA. HR will verify it manually.)", { x: col2x, y: sigTop - 94, font: f.cgItalic, size: 7, color: MUTED });

  page.drawText("Date", { x: col2x, y: sigTop - 112, font: f.interSemi, size: 9, color: NAVY, characterSpacing: 1 });
  page.drawLine({ start: { x: col2x, y: sigTop - 136 }, end: { x: col2x + 180, y: sigTop - 136 }, thickness: 0.5, color: HAIRLINE });

  const total = pages.length;
  pages.forEach((p, i) => drawFooter(p, f, i + 1, total));

  const bytes = await pdf.save();
  return { bytes, pageCount: total, warning, signatureRect: { page: total, x: M_SIDE, fieldTop, width: 240, height: fieldH } };
}
