// Shared PDF generation logic for offer letters.
// Builds a 4-page PDF using pdf-lib + custom TTF fonts loaded from
// the public 'assets' bucket.
import {
  PDFDocument,
  PDFFont,
  PDFPage,
  rgb,
  StandardFonts,
} from "npm:pdf-lib@1.17.1";
import fontkit from "npm:@pdf-lib/fontkit@1.1.1";
import { createClient } from "npm:@supabase/supabase-js@2";
import { getLockedSchedulePreset, type ScheduleKey } from "./schedule-presets.ts";

const ASSETS_BASE =
  Deno.env.get("SUPABASE_URL")! +
  "/storage/v1/object/public/assets/fonts";

const FONT_URLS = {
  cgRegular: `${ASSETS_BASE}/CormorantGaramond-Regular.ttf`,
  cgSemi: `${ASSETS_BASE}/CormorantGaramond-SemiBold.ttf`,
  cgItalic: `${ASSETS_BASE}/CormorantGaramond-Italic.ttf`,
  interReg: `${ASSETS_BASE}/Inter-Regular.ttf`,
  interSemi: `${ASSETS_BASE}/Inter-SemiBold.ttf`,
  allura: `${ASSETS_BASE}/Allura-Regular.ttf`,
};

// Module-level font byte cache (warm across invocations within a worker).
let FONT_BYTES: Record<string, Uint8Array> | null = null;
let FONT_LOAD_ERROR: string | null = null;

async function loadFontBytes(): Promise<{
  bytes: Record<string, Uint8Array> | null;
  error: string | null;
}> {
  if (FONT_BYTES) return { bytes: FONT_BYTES, error: null };
  if (FONT_LOAD_ERROR) return { bytes: null, error: FONT_LOAD_ERROR };
  try {
    const entries = await Promise.all(
      Object.entries(FONT_URLS).map(async ([k, url]) => {
        const r = await fetch(url);
        if (!r.ok) throw new Error(`font ${k} ${r.status}`);
        return [k, new Uint8Array(await r.arrayBuffer())] as const;
      }),
    );
    FONT_BYTES = Object.fromEntries(entries);
    return { bytes: FONT_BYTES, error: null };
  } catch (e) {
    FONT_LOAD_ERROR = (e as Error).message;
    return { bytes: null, error: FONT_LOAD_ERROR };
  }
}

// ---------------- Colors ----------------
const NAVY = rgb(0.102, 0.145, 0.278);
const GOLD = rgb(0.69, 0.553, 0.341);
const INK = rgb(0.102, 0.133, 0.212);
const MUTED = rgb(0.42, 0.447, 0.502);
const HAIRLINE = rgb(0.882, 0.894, 0.925);

// ---------------- Geometry ----------------
const PAGE_W = 612;
const PAGE_H = 792;
const M_TOP = 40;
const M_BOT = 36;
const M_SIDE = 61;
const CONTENT_W = PAGE_W - 2 * M_SIDE; // 490

// ---------------- Types ----------------
export type OfferData = {
  candidate_name: string;
  position_title: string;
  offer_reference_id: string;
  date_issued: Date;
  start_date: Date | null;
  trial_weeks: number;
  trial_weekly_salary: number;
  post_trial_weekly_salary: number;
  monthly_range_min: number | null;
  monthly_range_max: number | null;
  raise_applied: boolean;
  currency: string;
  weekday_start: string | null; // "09:00"
  weekday_end: string | null;
  saturday_start: string | null;
  saturday_end: string | null;
  schedule_preset_used?: ScheduleKey | string | null;
  scope_items: string[];
  performance_bonus_enabled?: boolean;
  performance_bonus_amount?: number | null;
  include_adaptability_clause?: boolean;
  remarks?: string | null;
};

type Fonts = {
  cgReg: PDFFont;
  cgSemi: PDFFont;
  cgItalic: PDFFont;
  interReg: PDFFont;
  interSemi: PDFFont;
  allura: PDFFont;
  fontWarning?: string;
};

// ---------------- Formatting helpers ----------------
const MONTHS = [
  "January", "February", "March", "April", "May", "June",
  "July", "August", "September", "October", "November", "December",
];

const formatLongDate = (d: Date): string => {
  try {
    if (isNaN(d.getTime())) throw new Error("bad");
    const wd = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"][d.getUTCDay()];
    return `${wd}, ${MONTHS[d.getUTCMonth()]} ${d.getUTCDate()}, ${d.getUTCFullYear()}`;
  } catch {
    return d.toISOString().slice(0, 10);
  }
};

const formatShortDate = (d: Date): string => {
  try {
    return `${MONTHS[d.getUTCMonth()]} ${d.getUTCDate()}, ${d.getUTCFullYear()}`;
  } catch {
    return d.toISOString().slice(0, 10);
  }
};

const addDaysUTC = (d: Date, days: number): Date => {
  const x = new Date(d.getTime());
  x.setUTCDate(x.getUTCDate() + days);
  return x;
};

const formatMoney = (cur: string, amount: number): string => {
  const n = Math.round(amount);
  return `${cur} ${n.toLocaleString("en-US")}`;
};

const formatTime12 = (t: string | null): string => {
  if (!t) return "—";
  const [hStr, mStr] = t.split(":");
  const h = parseInt(hStr, 10);
  const m = parseInt(mStr, 10);
  if (isNaN(h) || isNaN(m)) return t;
  const period = h >= 12 ? "PM" : "AM";
  const h12 = h === 0 ? 12 : h > 12 ? h - 12 : h;
  return `${h12}:${String(m).padStart(2, "0")} ${period}`;
};

const truncate = (s: string, max: number): string =>
  s.length > max ? s.slice(0, max - 1).trimEnd() + "…" : s;

// ---------------- Text drawing helpers ----------------
type DrawCtx = {
  page: PDFPage;
  fonts: Fonts;
};

const drawText = (
  ctx: DrawCtx,
  text: string,
  x: number,
  y: number,
  opts: {
    font: PDFFont;
    size: number;
    color?: ReturnType<typeof rgb>;
    characterSpacing?: number;
  },
) => {
  ctx.page.drawText(text, {
    x,
    y,
    font: opts.font,
    size: opts.size,
    color: opts.color || INK,
    ...(opts.characterSpacing ? { characterSpacing: opts.characterSpacing } : {}),
  });
};

// Word-wrap text into lines that fit width
const wrapLines = (
  text: string,
  font: PDFFont,
  size: number,
  maxWidth: number,
  charSpacing = 0,
): string[] => {
  const lines: string[] = [];
  for (const para of text.split("\n")) {
    if (para === "") { lines.push(""); continue; }
    const words = para.split(/\s+/);
    let cur = "";
    for (const w of words) {
      const test = cur ? `${cur} ${w}` : w;
      const width = font.widthOfTextAtSize(test, size) + charSpacing * (test.length - 1);
      if (width <= maxWidth || cur === "") {
        cur = test;
      } else {
        lines.push(cur);
        cur = w;
      }
    }
    if (cur) lines.push(cur);
  }
  return lines;
};

const drawWrapped = (
  ctx: DrawCtx,
  text: string,
  x: number,
  y: number,
  opts: {
    font: PDFFont;
    size: number;
    color?: ReturnType<typeof rgb>;
    maxWidth: number;
    lineHeight: number;
  },
): number => {
  const lines = wrapLines(text, opts.font, opts.size, opts.maxWidth);
  let cy = y;
  for (const line of lines) {
    if (line.length) {
      ctx.page.drawText(line, {
        x, y: cy, font: opts.font, size: opts.size,
        color: opts.color || INK,
      });
    }
    cy -= opts.lineHeight;
  }
  return cy;
};

const drawRightAligned = (
  ctx: DrawCtx,
  text: string,
  rightX: number,
  y: number,
  opts: {
    font: PDFFont;
    size: number;
    color?: ReturnType<typeof rgb>;
    characterSpacing?: number;
  },
) => {
  const width = opts.font.widthOfTextAtSize(text, opts.size) +
    (opts.characterSpacing || 0) * Math.max(0, text.length - 1);
  drawText(ctx, text, rightX - width, y, opts);
};

const drawCenteredText = (
  ctx: DrawCtx,
  text: string,
  centerX: number,
  y: number,
  opts: { font: PDFFont; size: number; color?: ReturnType<typeof rgb>; characterSpacing?: number },
) => {
  const width = opts.font.widthOfTextAtSize(text, opts.size) +
    (opts.characterSpacing || 0) * Math.max(0, text.length - 1);
  drawText(ctx, text, centerX - width / 2, y, opts);
};

const drawHairline = (page: PDFPage, x: number, y: number, w: number, color = HAIRLINE, thickness = 1) => {
  page.drawLine({
    start: { x, y },
    end: { x: x + w, y },
    thickness,
    color,
  });
};

// ---------------- Letterhead + Footer ----------------
const drawLetterhead = (ctx: DrawCtx) => {
  const topY = PAGE_H - M_TOP; // baseline area
  // Left: EIA logo
  drawText(ctx, "EIA", M_SIDE, topY - 20, {
    font: ctx.fonts.cgSemi, size: 24, color: NAVY,
  });
  drawText(ctx, "Expert Intuitive Advisor Inc.", M_SIDE, topY - 33, {
    font: ctx.fonts.cgItalic, size: 9, color: MUTED,
  });
  drawText(ctx, "The intelligence layer between humans and AI.", M_SIDE, topY - 44, {
    font: ctx.fonts.cgItalic, size: 8, color: MUTED,
  });
  // Right
  const rightX = PAGE_W - M_SIDE;
  drawRightAligned(ctx, "EXPERTINTUITIVEADVISOR.COM", rightX, topY - 20, {
    font: ctx.fonts.interSemi, size: 8, color: NAVY, characterSpacing: 1,
  });
  drawRightAligned(ctx, "HR@EXPERTINTUITIVEADVISOR.COM", rightX, topY - 33, {
    font: ctx.fonts.interReg, size: 8, color: MUTED, characterSpacing: 1,
  });
  // Navy hairline below
  const lineY = topY - 56;
  drawHairline(ctx.page, M_SIDE, lineY, CONTENT_W, NAVY, 1.5);
  return lineY - 24; // content start Y (cursor)
};

const drawFooter = (ctx: DrawCtx, pageNum: number, total: number) => {
  const y = M_BOT;
  drawText(ctx, "Expert Intuitive Advisor Inc. — Confidential", M_SIDE, y, {
    font: ctx.fonts.cgItalic, size: 7, color: MUTED,
  });
  drawRightAligned(ctx, `Page ${pageNum} of ${total}`, PAGE_W - M_SIDE, y, {
    font: ctx.fonts.cgItalic, size: 7, color: MUTED,
  });
};

// ---------------- Section header ----------------
const drawSectionHeader = (ctx: DrawCtx, num: string, title: string, yStart: number): number => {
  // Number left, title to right of number
  drawText(ctx, num, M_SIDE, yStart - 12, {
    font: ctx.fonts.cgItalic, size: 14, color: GOLD,
  });
  const numWidth = ctx.fonts.cgItalic.widthOfTextAtSize(num, 14);
  drawText(ctx, title.toUpperCase(), M_SIDE + numWidth + 8, yStart - 11, {
    font: ctx.fonts.interSemi, size: 11, color: NAVY, characterSpacing: 2,
  });
  // Hairline below
  const lineY = yStart - 22;
  drawHairline(ctx.page, M_SIDE, lineY, CONTENT_W, HAIRLINE, 1);
  return lineY - 12; // content start
};

// ---------------- Sections ----------------
const sec01 = (ctx: DrawCtx, y: number, d: OfferData): number => {
  let cy = drawSectionHeader(ctx, "01", "Introduction", y);
  cy = drawWrapped(ctx,
    `Dear ${d.candidate_name},`,
    M_SIDE, cy,
    { font: ctx.fonts.interReg, size: 10.5, color: INK, maxWidth: CONTENT_W, lineHeight: 15 },
  );
  cy -= 6;
  cy = drawWrapped(ctx,
    `Congratulations. We are pleased to formally extend an offer of employment to you at Expert Intuitive Advisor Inc. ("EIA") for the position of ${d.position_title}.`,
    M_SIDE, cy,
    { font: ctx.fonts.interReg, size: 10.5, color: INK, maxWidth: CONTENT_W, lineHeight: 15 },
  );
  cy -= 6;
  cy = drawWrapped(ctx,
    "This letter outlines the terms of your engagement. Please review each section carefully. Your acceptance of this offer is confirmed through your signature on Page 4.",
    M_SIDE, cy,
    { font: ctx.fonts.interReg, size: 10.5, color: INK, maxWidth: CONTENT_W, lineHeight: 15 },
  );
  return cy;
};

const drawKeyValue = (ctx: DrawCtx, key: string, val: string, y: number): number => {
  drawText(ctx, key, M_SIDE, y, { font: ctx.fonts.interSemi, size: 10, color: NAVY });
  const keyW = ctx.fonts.interSemi.widthOfTextAtSize(key, 10);
  drawWrapped(ctx, val, M_SIDE + keyW + 6, y, {
    font: ctx.fonts.interReg, size: 10, color: INK,
    maxWidth: CONTENT_W - keyW - 6, lineHeight: 14,
  });
  return y - 16;
};

const sec02 = (ctx: DrawCtx, y: number, d: OfferData): number => {
  let cy = drawSectionHeader(ctx, "02", "Position & Reporting", y);
  cy = drawKeyValue(ctx, "Position:", d.position_title, cy);
  cy = drawKeyValue(ctx, "Engagement Type:", "Independent Contractor", cy);
  cy = drawKeyValue(ctx, "Reporting To:", "Hiring Director — Cathy Anderson", cy);
  cy = drawKeyValue(ctx, "Workplace:", "Remote", cy);
  cy -= 4;
  cy = drawWrapped(ctx,
    "You will operate as part of EIA's global remote team, supporting US-based operations with AI-assisted execution.",
    M_SIDE, cy,
    { font: ctx.fonts.interReg, size: 10.5, color: INK, maxWidth: CONTENT_W, lineHeight: 15 });
  return cy;
};

const sec03 = (ctx: DrawCtx, y: number, d: OfferData): number => {
  let cy = drawSectionHeader(ctx, "03", "Start Date & Trial Period", y);
  const startStr = d.start_date ? formatLongDate(d.start_date) : "To be confirmed";
  const trialEnd = d.start_date ? formatLongDate(addDaysUTC(d.start_date, d.trial_weeks * 7)) : "—";
  cy = drawKeyValue(ctx, "Start Date:", startStr, cy);
  cy = drawKeyValue(ctx, "Trial Duration:", `${d.trial_weeks} weeks from start date`, cy);
  cy = drawKeyValue(ctx, "Trial End Date:", trialEnd, cy);
  cy -= 4;
  cy = drawWrapped(ctx,
    "The trial period allows both parties to evaluate fit, performance, and working dynamics. Either party may end the engagement at any point during this period without cause.",
    M_SIDE, cy,
    { font: ctx.fonts.interReg, size: 10.5, color: INK, maxWidth: CONTENT_W, lineHeight: 15 });
  return cy;
};

const sec04 = (ctx: DrawCtx, y: number, d: OfferData): number => {
  let cy = drawSectionHeader(ctx, "04", "Trial Period Terms", y);
  cy = drawWrapped(ctx, "During the trial period:", M_SIDE, cy,
    { font: ctx.fonts.interReg, size: 10.5, color: INK, maxWidth: CONTENT_W, lineHeight: 15 });
  cy -= 6;
  const trialMonthly = d.trial_weekly_salary * 4;
  const items = [
    `Compensation: ${formatMoney(d.currency, d.trial_weekly_salary)} per week (${formatMoney(d.currency, trialMonthly)} per month, paid every Saturday)`,
    "Schedule: As outlined in Section 09",
    "Tools: As outlined in Section 08",
    "Expected output: Daily tasks delivered with documented progress",
  ];
  for (const it of items) {
    drawText(ctx, "•", M_SIDE, cy, { font: ctx.fonts.interReg, size: 10, color: GOLD });
    const after = drawWrapped(ctx, it, M_SIDE + 14, cy, {
      font: ctx.fonts.interReg, size: 10, color: INK,
      maxWidth: CONTENT_W - 14, lineHeight: 14,
    });
    cy = after - 4;
  }
  cy -= 2;
  cy = drawWrapped(ctx,
    "Your engagement is confirmed weekly via deliverables and check-ins. Payment is processed on the Friday following each completed work week.",
    M_SIDE, cy,
    { font: ctx.fonts.interReg, size: 10.5, color: INK, maxWidth: CONTENT_W, lineHeight: 15 });
  return cy;
};

const monthlyRangeStr = (d: OfferData): string => {
  if (d.monthly_range_min == null || d.monthly_range_max == null) {
    return formatMoney(d.currency, d.trial_weekly_salary * 4);
  }
  if (Math.round(d.monthly_range_min) === Math.round(d.monthly_range_max)) {
    return formatMoney(d.currency, d.monthly_range_min);
  }
  return `${formatMoney(d.currency, d.monthly_range_min)}–${Math.round(d.monthly_range_max).toLocaleString("en-US")}`;
};

const postTrialMonthlyRangeStr = (d: OfferData): string => {
  // If raise_applied, we display the higher tier; if no explicit field, compute weekly*4.
  const min = d.post_trial_weekly_salary * 4;
  const max = d.monthly_range_max ?? min;
  if (Math.round(min) === Math.round(max)) return formatMoney(d.currency, min);
  return `${formatMoney(d.currency, min)}–${Math.round(max).toLocaleString("en-US")}`;
};

const sec05 = (ctx: DrawCtx, y: number, d: OfferData): number => {
  let cy = drawSectionHeader(ctx, "05", "Compensation", y);
  cy = drawWrapped(ctx,
    `Trial Period: ${formatMoney(d.currency, d.trial_weekly_salary)}/week (${monthlyRangeStr(d)}/month)`,
    M_SIDE, cy,
    { font: ctx.fonts.interReg, size: 10.5, color: INK, maxWidth: CONTENT_W, lineHeight: 15 });
  cy -= 4;
  if (d.raise_applied) {
    cy = drawWrapped(ctx,
      `Post-Trial Period: ${formatMoney(d.currency, d.post_trial_weekly_salary)}/week (${postTrialMonthlyRangeStr(d)}/month)`,
      M_SIDE, cy,
      { font: ctx.fonts.interReg, size: 10.5, color: INK, maxWidth: CONTENT_W, lineHeight: 15 });
  } else {
    cy = drawWrapped(ctx,
      `Post-Trial Period: ${formatMoney(d.currency, d.trial_weekly_salary)}/week (${monthlyRangeStr(d)}/month) — same rate continues post-trial.`,
      M_SIDE, cy,
      { font: ctx.fonts.interReg, size: 10.5, color: INK, maxWidth: CONTENT_W, lineHeight: 15 });
  }
  cy -= 4;
  cy = drawWrapped(ctx,
    "Payment Schedule: Weekly, every Saturday via your preferred remittance method (Wise, GCash, or bank transfer).",
    M_SIDE, cy,
    { font: ctx.fonts.interReg, size: 10.5, color: INK, maxWidth: CONTENT_W, lineHeight: 15 });
  cy -= 8;
  // Clause heading
  const clauseTitle = d.raise_applied ? "PERFORMANCE REVIEW CLAUSE" : "COMPENSATION REVIEW CLAUSE";
  drawText(ctx, clauseTitle, M_SIDE, cy, { font: ctx.fonts.interSemi, size: 9, color: NAVY, characterSpacing: 1 });
  cy -= 14;
  if (d.raise_applied) {
    const maxMonthly = d.monthly_range_max != null
      ? formatMoney(d.currency, d.monthly_range_max)
      : formatMoney(d.currency, d.post_trial_weekly_salary * 4);
    cy = drawWrapped(ctx,
      `The post-trial weekly salary of ${formatMoney(d.currency, d.post_trial_weekly_salary)} (${maxMonthly}/month) is subject to management approval based on demonstrated performance and value delivered during the trial period.`,
      M_SIDE, cy,
      { font: ctx.fonts.interReg, size: 10, color: INK, maxWidth: CONTENT_W, lineHeight: 14 });
  } else {
    cy = drawWrapped(ctx,
      "Salary will be reviewed periodically and adjusted based on performance, scope expansion, and business needs. Any adjustment will be communicated in writing.",
      M_SIDE, cy,
      { font: ctx.fonts.interReg, size: 10, color: INK, maxWidth: CONTENT_W, lineHeight: 14 });
  }
  // Performance bonus disclaimer
  if (d.performance_bonus_enabled && (d.performance_bonus_amount ?? 0) > 0) {
    cy -= 10;
    drawText(ctx, `Performance Bonus: up to ${formatMoney(d.currency, d.performance_bonus_amount!)}/period`,
      M_SIDE, cy, { font: ctx.fonts.interSemi, size: 9.5, color: NAVY, characterSpacing: 0.5 });
    cy -= 12;
    drawText(ctx, "PERFORMANCE BONUS DISCLAIMER", M_SIDE, cy,
      { font: ctx.fonts.interSemi, size: 8.5, color: GOLD, characterSpacing: 1 });
    cy -= 11;
    cy = drawWrapped(ctx,
      `This performance bonus of up to ${formatMoney(d.currency, d.performance_bonus_amount!)} per pay period is discretionary and based on individual performance metrics including productivity, accuracy, punctuality, and overall contribution. The bonus is reviewed regularly and may be adjusted, reduced, or withheld entirely at the company's discretion based on performance assessment. Continued eligibility requires sustained performance standards as determined by management. This bonus is not part of guaranteed compensation.`,
      M_SIDE, cy,
      { font: ctx.fonts.cgItalic, size: 9, color: MUTED, maxWidth: CONTENT_W, lineHeight: 12 });
  }
  return cy;
};

const sec06 = (ctx: DrawCtx, y: number, d: OfferData): number => {
  let cy = drawSectionHeader(ctx, "06", "Job Scope", y);
  cy = drawWrapped(ctx,
    "Your role includes (but is not limited to) the following responsibilities:",
    M_SIDE, cy,
    { font: ctx.fonts.interReg, size: 10.5, color: INK, maxWidth: CONTENT_W, lineHeight: 15 });
  cy -= 8;
  if (!d.scope_items || d.scope_items.length === 0) {
    cy = drawWrapped(ctx, "Scope to be defined during onboarding.", M_SIDE, cy,
      { font: ctx.fonts.cgItalic, size: 10, color: MUTED, maxWidth: CONTENT_W, lineHeight: 14 });
  } else {
    for (const item of d.scope_items) {
      drawText(ctx, "•", M_SIDE, cy, { font: ctx.fonts.interReg, size: 10, color: GOLD });
      const after = drawWrapped(ctx, String(item), M_SIDE + 14, cy, {
        font: ctx.fonts.interReg, size: 10, color: INK,
        maxWidth: CONTENT_W - 14, lineHeight: 14,
      });
      cy = after - 2;
    }
  }
  cy -= 6;
  cy = drawWrapped(ctx,
    "Additional responsibilities may be assigned as the role evolves. Significant scope changes will be discussed and documented before implementation.",
    M_SIDE, cy,
    { font: ctx.fonts.interReg, size: 10.5, color: INK, maxWidth: CONTENT_W, lineHeight: 15 });

  if (d.include_adaptability_clause !== false) {
    cy -= 12;
    drawText(ctx, "SCOPE OF WORK AND ADAPTABILITY", M_SIDE, cy,
      { font: ctx.fonts.interSemi, size: 9.5, color: NAVY, characterSpacing: 1.5 });
    cy -= 13;
    cy = drawWrapped(ctx,
      "Your responsibilities above represent the core duties of this position. During your 8-hour daily work schedule, you may be assigned additional tasks not specifically listed in this offer letter. These will fall within reasonable scope and may include tasks related to your role that emerge from business needs, cross-functional support, skill development, administrative duties supporting team operations, and special projects assigned by management. You agree to perform such assignments with diligence and professionalism. Reasonable adaptability is considered an essential quality of this role. Where the company determines that additional tasks fall outside your current skill set, training and development support will be provided. Refusal to perform reasonable assigned tasks may be considered a performance issue and may affect your standing within the company.",
      M_SIDE, cy,
      { font: ctx.fonts.interReg, size: 9.5, color: INK, maxWidth: CONTENT_W, lineHeight: 12.5 });
  }
  return cy;
};

const drawBulletList = (ctx: DrawCtx, items: string[], y: number): number => {
  let cy = y;
  for (const it of items) {
    drawText(ctx, "•", M_SIDE, cy, { font: ctx.fonts.interReg, size: 10, color: GOLD });
    const after = drawWrapped(ctx, it, M_SIDE + 14, cy, {
      font: ctx.fonts.interReg, size: 10, color: INK,
      maxWidth: CONTENT_W - 14, lineHeight: 14,
    });
    cy = after - 2;
  }
  return cy;
};

const sec07 = (ctx: DrawCtx, y: number): number => {
  let cy = drawSectionHeader(ctx, "07", "Acceptance Conditions", y);
  cy = drawWrapped(ctx, "By accepting this offer, you confirm:", M_SIDE, cy,
    { font: ctx.fonts.interReg, size: 10.5, color: INK, maxWidth: CONTENT_W, lineHeight: 15 });
  cy -= 6;
  cy = drawBulletList(ctx, [
    "You are legally able to work as an independent contractor in the Philippines",
    "You are not under any non-compete or exclusivity agreement that would prevent this engagement",
    "Information shared during your role (client data, internal systems, strategy) is confidential and remains EIA property",
    "Work product (deliverables, documentation, AI workflows) created during your engagement is owned by EIA",
  ], cy);
  cy -= 4;
  cy = drawWrapped(ctx, "Confidentiality and IP terms remain in effect after engagement ends.",
    M_SIDE, cy,
    { font: ctx.fonts.interReg, size: 10.5, color: INK, maxWidth: CONTENT_W, lineHeight: 15 });
  return cy;
};

const sec08 = (ctx: DrawCtx, y: number): number => {
  let cy = drawSectionHeader(ctx, "08", "Required Tools & Setup", y);
  cy = drawWrapped(ctx, "You are responsible for providing:", M_SIDE, cy,
    { font: ctx.fonts.interReg, size: 10.5, color: INK, maxWidth: CONTENT_W, lineHeight: 15 });
  cy -= 6;
  cy = drawBulletList(ctx, [
    "Personal computer (Windows or Mac, less than 4 years old)",
    "Stable internet connection (minimum 20 Mbps, ideally fiber)",
    "Power backup (UPS or generator) for outage continuity",
    "Working camera, microphone, and headset for video calls",
    "Quiet, dedicated workspace",
  ], cy);
  cy -= 6;
  cy = drawWrapped(ctx, "EIA will provide:", M_SIDE, cy,
    { font: ctx.fonts.interReg, size: 10.5, color: INK, maxWidth: CONTENT_W, lineHeight: 15 });
  cy -= 6;
  cy = drawBulletList(ctx, [
    "Access to Claude.ai workspace",
    "Required SaaS tool subscriptions (CRM, project management, etc.)",
    "Training materials and onboarding documentation",
  ], cy);
  return cy;
};

const sec09 = (ctx: DrawCtx, y: number, d: OfferData): number => {
  let cy = drawSectionHeader(ctx, "09", "Attendance & Schedule", y);
  cy = drawWrapped(ctx, "Your working schedule (all times in Philippine Standard Time):",
    M_SIDE, cy,
    { font: ctx.fonts.interReg, size: 10.5, color: INK, maxWidth: CONTENT_W, lineHeight: 15 });
  cy -= 8;
  const schedule = getLockedSchedulePreset(d.schedule_preset_used) ?? d;
  const wkRange = schedule.weekday_start && schedule.weekday_end
    ? `${formatTime12(schedule.weekday_start)} – ${formatTime12(schedule.weekday_end)}`
    : "To be confirmed";
  const satRange = schedule.saturday_start && schedule.saturday_end
    ? `${formatTime12(schedule.saturday_start)} – ${formatTime12(schedule.saturday_end)}`
    : "Off";
  cy = drawKeyValue(ctx, "Monday–Friday:", wkRange, cy);
  cy = drawKeyValue(ctx, "Saturday:", satRange, cy);
  cy = drawKeyValue(ctx, "Sunday:", "Off", cy);
  cy -= 4;
  cy = drawWrapped(ctx, "Attendance Expectations:", M_SIDE, cy,
    { font: ctx.fonts.interSemi, size: 10, color: NAVY, maxWidth: CONTENT_W, lineHeight: 14 });
  cy -= 6;
  cy = drawBulletList(ctx, [
    "Be online and available during scheduled hours",
    "Daily standup at the start of your shift",
    "Notify Angela Stein at least 24 hours in advance for planned time off",
    "Sick days are unpaid but accepted with same-day notice",
  ], cy);
  cy -= 4;
  cy = drawWrapped(ctx,
    "We respect your time off — please respect the team's reliance on your availability during scheduled hours.",
    M_SIDE, cy,
    { font: ctx.fonts.interReg, size: 10.5, color: INK, maxWidth: CONTENT_W, lineHeight: 15 });
  return cy;
};

const sec10 = (ctx: DrawCtx, y: number, d: OfferData): number => {
  let cy = drawSectionHeader(ctx, "10", "Acceptance & Signature", y);
  cy = drawWrapped(ctx,
    "By signing below, you formally accept this offer of employment with Expert Intuitive Advisor Inc. on the terms outlined above.",
    M_SIDE, cy,
    { font: ctx.fonts.interReg, size: 10.5, color: INK, maxWidth: CONTENT_W, lineHeight: 15 });
  cy -= 6;
  cy = drawWrapped(ctx,
    `This offer is valid for 7 days from the issue date (${formatShortDate(d.date_issued)}). After this period, it expires and must be re-issued by EIA.`,
    M_SIDE, cy,
    { font: ctx.fonts.interReg, size: 10.5, color: INK, maxWidth: CONTENT_W, lineHeight: 15 });
  cy -= 6;
  cy = drawWrapped(ctx, "We look forward to working with you.", M_SIDE, cy,
    { font: ctx.fonts.interReg, size: 10.5, color: INK, maxWidth: CONTENT_W, lineHeight: 15 });
  cy -= 4;
  cy = drawWrapped(ctx, "Sincerely,", M_SIDE, cy,
    { font: ctx.fonts.interReg, size: 10.5, color: INK, maxWidth: CONTENT_W, lineHeight: 15 });
  cy -= 18;

  // Cathy Anderson signature (Allura)
  drawText(ctx, "Cathy Anderson", M_SIDE, cy - 22, {
    font: ctx.fonts.allura, size: 28, color: NAVY,
  });
  cy -= 30;
  drawHairline(ctx.page, M_SIDE, cy, 200, NAVY, 1);
  cy -= 12;
  drawText(ctx, "Cathy Anderson", M_SIDE, cy, { font: ctx.fonts.interSemi, size: 10, color: INK });
  cy -= 12;
  drawText(ctx, "Hiring Director, Expert Intuitive Advisor Inc.", M_SIDE, cy, {
    font: ctx.fonts.interReg, size: 9, color: MUTED,
  });
  cy -= 11;
  drawText(ctx, `Date Issued: ${formatShortDate(d.date_issued)}`, M_SIDE, cy, {
    font: ctx.fonts.interReg, size: 9, color: MUTED,
  });
  cy -= 48;

  // Candidate signature block — leave 60pt for SignFlow
  cy -= 60;
  drawHairline(ctx.page, M_SIDE, cy, 200, INK, 1);
  cy -= 12;
  drawText(ctx, "Candidate Signature", M_SIDE, cy, { font: ctx.fonts.interSemi, size: 10, color: INK });
  cy -= 12;
  drawText(ctx, d.candidate_name, M_SIDE, cy, { font: ctx.fonts.interReg, size: 9, color: MUTED });
  cy -= 11;
  drawText(ctx, "Date Signed: ___________", M_SIDE, cy, {
    font: ctx.fonts.interReg, size: 9, color: MUTED,
  });

  // Remarks block — additive, placed below the candidate signature block.
  // Stays well under y≈290 so it never collides with the SignFlow field band
  // (y≈350-410) or the Allura signature above.
  cy -= 34;
  drawText(ctx, "REMARKS", M_SIDE, cy, {
    font: ctx.fonts.interSemi, size: 9, color: NAVY, characterSpacing: 1,
  });
  cy -= 14;
  const remarksText = (d.remarks && d.remarks.trim()) ? d.remarks.trim() : "No Remarks";
  cy = drawWrapped(ctx, remarksText, M_SIDE, cy, {
    font: ctx.fonts.interReg, size: 9, color: MUTED, maxWidth: CONTENT_W, lineHeight: 13,
  });
  return cy;
};

// ---------------- Page 1 special: confidential strip + info bar + title ----------------
const drawConfidentialStrip = (ctx: DrawCtx, y: number): number => {
  drawCenteredText(ctx, "CONFIDENTIAL — OFFICIAL OFFER LETTER", PAGE_W / 2, y - 9, {
    font: ctx.fonts.interSemi, size: 9, color: GOLD, characterSpacing: 3,
  });
  return y - 9 - 16;
};

const drawInfoBar = (ctx: DrawCtx, y: number, d: OfferData): number => {
  const colW = CONTENT_W / 4;
  const cols = [
    { label: "ISSUED TO", value: truncate(d.candidate_name, 40) },
    { label: "POSITION", value: truncate(d.position_title, 40) },
    { label: "DATE ISSUED", value: formatShortDate(d.date_issued) },
    { label: "REFERENCE", value: d.offer_reference_id },
  ];
  const labelY = y - 9;
  const valueY = labelY - 16;
  cols.forEach((c, i) => {
    const x = M_SIDE + i * colW;
    drawText(ctx, c.label, x, labelY, {
      font: ctx.fonts.interSemi, size: 8, color: NAVY, characterSpacing: 1,
    });
    // Auto-fit: shrink font size until value fits on a single line within column
    const maxW = colW - 6;
    let valSize = 12;
    while (
      valSize > 8 &&
      ctx.fonts.cgSemi.widthOfTextAtSize(c.value, valSize) > maxW
    ) {
      valSize -= 0.5;
    }
    drawText(ctx, c.value, x, valueY, {
      font: ctx.fonts.cgSemi, size: valSize, color: INK,
    });
  });
  let cy = valueY - 28;
  drawHairline(ctx.page, M_SIDE, cy, CONTENT_W, HAIRLINE, 1);
  return cy - 24;
};

const drawTitle = (ctx: DrawCtx, y: number): number => {
  drawCenteredText(ctx, "Official Job Offer", PAGE_W / 2, y - 18, {
    font: ctx.fonts.cgSemi, size: 22, color: NAVY,
  });
  let cy = y - 18 - 8;
  drawCenteredText(ctx, "Effective upon signed acceptance", PAGE_W / 2, cy - 12, {
    font: ctx.fonts.cgItalic, size: 10, color: MUTED,
  });
  return cy - 12 - 24;
};

// ---------------- Main builder ----------------
export async function buildOfferPdf(data: OfferData): Promise<{
  bytes: Uint8Array;
  warning: string | null;
  pageCount: number;
}> {
  const pdf = await PDFDocument.create();
  pdf.registerFontkit(fontkit);

  // Try to load custom fonts; fallback to Standard Helvetica
  const { bytes: fb, error: fontErr } = await loadFontBytes();
  let fonts: Fonts;
  let warning: string | null = null;

  if (fb) {
    try {
      const allura = await pdf.embedFont(fb.allura, { subset: false });
      const signatureWidth = allura.widthOfTextAtSize("Cathy Anderson", 28);
      console.log(JSON.stringify({
        event: "offer_pdf_allura_embedded",
        alluraBytes: fb.allura.length,
        signatureWidth,
      }));
      fonts = {
        cgReg: await pdf.embedFont(fb.cgRegular, { subset: true }),
        cgSemi: await pdf.embedFont(fb.cgSemi, { subset: true }),
        cgItalic: await pdf.embedFont(fb.cgItalic, { subset: true }),
        interReg: await pdf.embedFont(fb.interReg, { subset: true }),
        interSemi: await pdf.embedFont(fb.interSemi, { subset: true }),
        allura,
      };
    } catch (e) {
      console.error("offer_pdf_allura_embed_failed", (e as Error).message);
      throw e;
    }
  } else {
    const h = await pdf.embedFont(StandardFonts.Helvetica);
    const hb = await pdf.embedFont(StandardFonts.HelveticaBold);
    const hi = await pdf.embedFont(StandardFonts.HelveticaOblique);
    const ti = await pdf.embedFont(StandardFonts.TimesRomanItalic);
    fonts = {
      cgReg: h, cgSemi: hb, cgItalic: ti,
      interReg: h, interSemi: hb, allura: ti,
    };
    warning = `font_load_failed: ${fontErr || "unknown"}`;
  }

  // If adaptability clause is enabled, sec06 needs its own page (5-page layout).
  // Otherwise compact 4-page layout.
  const useFivePages = data.include_adaptability_clause !== false;
  const totalPages = useFivePages ? 5 : 4;

  const pages: PDFPage[] = [];
  for (let i = 0; i < totalPages; i++) pages.push(pdf.addPage([PAGE_W, PAGE_H]));

  // ===== PAGE 1 (same in both layouts) =====
  {
    const ctx: DrawCtx = { page: pages[0], fonts };
    let y = drawLetterhead(ctx);
    y = drawConfidentialStrip(ctx, y);
    y = drawInfoBar(ctx, y, data);
    y = drawTitle(ctx, y);
    y = sec01(ctx, y, data);
    y -= 16;
    y = sec02(ctx, y, data);
    y -= 16;
    y = sec03(ctx, y, data);
    drawFooter(ctx, 1, totalPages);
  }

  if (useFivePages) {
    // Page 2: sec04 + sec05
    {
      const ctx: DrawCtx = { page: pages[1], fonts };
      let y = drawLetterhead(ctx);
      y = sec04(ctx, y, data);
      y -= 16;
      y = sec05(ctx, y, data);
      drawFooter(ctx, 2, totalPages);
    }
    // Page 3: sec06 (with adaptability clause)
    {
      const ctx: DrawCtx = { page: pages[2], fonts };
      let y = drawLetterhead(ctx);
      y = sec06(ctx, y, data);
      drawFooter(ctx, 3, totalPages);
    }
    // Page 4: sec07 + sec08 + sec09
    {
      const ctx: DrawCtx = { page: pages[3], fonts };
      let y = drawLetterhead(ctx);
      y = sec07(ctx, y);
      y -= 16;
      y = sec08(ctx, y);
      y -= 16;
      y = sec09(ctx, y, data);
      drawFooter(ctx, 4, totalPages);
    }
    // Page 5: sec10
    {
      const ctx: DrawCtx = { page: pages[4], fonts };
      let y = drawLetterhead(ctx);
      sec10(ctx, y, data);
      drawFooter(ctx, 5, totalPages);
    }
  } else {
    // 4-page compact layout (no adaptability clause)
    {
      const ctx: DrawCtx = { page: pages[1], fonts };
      let y = drawLetterhead(ctx);
      y = sec04(ctx, y, data);
      y -= 16;
      y = sec05(ctx, y, data);
      y -= 16;
      y = sec06(ctx, y, data);
      drawFooter(ctx, 2, totalPages);
    }
    {
      const ctx: DrawCtx = { page: pages[2], fonts };
      let y = drawLetterhead(ctx);
      y = sec07(ctx, y);
      y -= 16;
      y = sec08(ctx, y);
      y -= 16;
      y = sec09(ctx, y, data);
      drawFooter(ctx, 3, totalPages);
    }
    {
      const ctx: DrawCtx = { page: pages[3], fonts };
      let y = drawLetterhead(ctx);
      sec10(ctx, y, data);
      drawFooter(ctx, 4, totalPages);
    }
  }

  const bytes = await pdf.save();
  return { bytes, warning, pageCount: totalPages };
}


export async function buildAlluraDebugPdf(): Promise<{
  bytes: Uint8Array;
  warning: string | null;
}> {
  const pdf = await PDFDocument.create();
  pdf.registerFontkit(fontkit);
  const { bytes: fb, error: fontErr } = await loadFontBytes();
  if (!fb) {
    const h = await pdf.embedFont(StandardFonts.Helvetica);
    const page = pdf.addPage([PAGE_W, PAGE_H]);
    page.drawText(`Allura font failed to load: ${fontErr || "unknown"}`, {
      x: M_SIDE,
      y: PAGE_H - 120,
      font: h,
      size: 14,
      color: INK,
    });
    return { bytes: await pdf.save(), warning: `font_load_failed: ${fontErr || "unknown"}` };
  }

  let allura: PDFFont;
  try {
    allura = await pdf.embedFont(fb.allura, { subset: false });
    console.log(JSON.stringify({
      event: "offer_pdf_allura_debug_embedded",
      alluraBytes: fb.allura.length,
      testWidth28: allura.widthOfTextAtSize("Test 123", 28),
      signatureWidth28: allura.widthOfTextAtSize("Cathy Anderson", 28),
    }));
  } catch (e) {
    console.error("offer_pdf_allura_debug_embed_failed", (e as Error).message);
    throw e;
  }

  const inter = await pdf.embedFont(fb.interReg, { subset: true });
  const page = pdf.addPage([PAGE_W, PAGE_H]);
  page.drawText("Allura signature render diagnostic", {
    x: M_SIDE,
    y: PAGE_H - 90,
    font: inter,
    size: 12,
    color: MUTED,
  });
  let y = PAGE_H - 160;
  for (const size of [18, 28, 36, 48]) {
    page.drawText(`Allura ${size}pt`, { x: M_SIDE, y: y + 10, font: inter, size: 9, color: MUTED });
    page.drawText("Test 123", { x: M_SIDE + 90, y, font: allura, size, color: NAVY });
    page.drawText("Cathy Anderson", { x: M_SIDE + 230, y, font: allura, size, color: NAVY });
    y -= 78;
  }
  return { bytes: await pdf.save(), warning: null };
}

// ---------------- Build OfferData from DB row ----------------
export function offerRowToData(row: Record<string, any>): {
  data: OfferData | null;
  missing: string[];
} {
  const missing: string[] = [];
  const need = (k: string) => {
    if (row[k] === null || row[k] === undefined || row[k] === "") missing.push(k);
  };
  need("candidate_name");
  need("position_title");
  need("offer_reference_id");
  need("trial_weekly_salary");
  need("post_trial_weekly_salary");
  need("currency");

  if (missing.length) return { data: null, missing };

  const startDate = row.start_date ? new Date(`${row.start_date}T00:00:00Z`) : null;
  const scope = Array.isArray(row.scope_items)
    ? row.scope_items.map((s: any) => typeof s === "string" ? s : (s?.text ?? String(s)))
    : [];

  return {
    data: {
      candidate_name: truncate(String(row.candidate_name), 80),
      position_title: truncate(String(row.position_title), 80),
      offer_reference_id: String(row.offer_reference_id),
      date_issued: new Date(),
      start_date: startDate && !isNaN(startDate.getTime()) ? startDate : null,
      trial_weeks: Number(row.trial_weeks ?? 4),
      trial_weekly_salary: Number(row.trial_weekly_salary),
      post_trial_weekly_salary: Number(row.post_trial_weekly_salary),
      monthly_range_min: row.monthly_range_min != null ? Number(row.monthly_range_min) : null,
      monthly_range_max: row.monthly_range_max != null ? Number(row.monthly_range_max) : null,
      raise_applied: row.raise_applied !== false,
      currency: String(row.currency || "PHP"),
      weekday_start: row.weekday_start ? String(row.weekday_start).slice(0, 5) : null,
      weekday_end: row.weekday_end ? String(row.weekday_end).slice(0, 5) : null,
      saturday_start: row.saturday_start ? String(row.saturday_start).slice(0, 5) : null,
      saturday_end: row.saturday_end ? String(row.saturday_end).slice(0, 5) : null,
      schedule_preset_used: row.schedule_preset_used ? String(row.schedule_preset_used) : null,
      scope_items: scope,
      performance_bonus_enabled: row.performance_bonus_enabled === true,
      performance_bonus_amount: row.performance_bonus_amount != null ? Number(row.performance_bonus_amount) : null,
      include_adaptability_clause: row.include_adaptability_clause !== false,
      remarks: row.remarks != null && String(row.remarks).trim() !== "" ? String(row.remarks) : null,
    },
    missing: [],
  };
}

// ---------------- Storage upload ----------------
export async function uploadPdf(
  bytes: Uint8Array,
  filename: string,
): Promise<{ url: string | null; error: string | null }> {
  try {
    const admin = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!,
    );
    const { error } = await admin.storage
      .from("offer-letters")
      .upload(filename, bytes, {
        contentType: "application/pdf",
        upsert: true,
      });
    if (error) return { url: null, error: error.message };
    const { data } = admin.storage.from("offer-letters").getPublicUrl(filename);
    return { url: data.publicUrl, error: null };
  } catch (e) {
    return { url: null, error: (e as Error).message };
  }
}

export function buildFilename(refId: string, candidateName: string): string {
  const lastPart = candidateName.trim().split(/\s+/).slice(-1)[0] || "Candidate";
  const safe = lastPart.replace(/[^A-Za-z0-9_-]/g, "_");
  return `${refId}-${safe}.pdf`;
}
