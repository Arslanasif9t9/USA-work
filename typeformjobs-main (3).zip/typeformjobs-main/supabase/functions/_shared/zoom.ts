// Shared Zoom helpers used by create/get/delete/test edge functions.
import { createClient, SupabaseClient } from "npm:@supabase/supabase-js@2";

const ZOOM_ACCOUNT_ID = Deno.env.get("ZOOM_ACCOUNT_ID")!;
const ZOOM_CLIENT_ID = Deno.env.get("ZOOM_CLIENT_ID")!;
const ZOOM_CLIENT_SECRET = Deno.env.get("ZOOM_CLIENT_SECRET")!;

export const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

export function jsonResponse(body: unknown, status = 200) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { ...corsHeaders, "Content-Type": "application/json" },
  });
}

export function adminClient(): SupabaseClient {
  return createClient(
    Deno.env.get("SUPABASE_URL")!,
    Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!,
  );
}

/** Verify caller is an authenticated admin (has a row in public.users) OR a service-role server-to-server call. */
export async function requireAdmin(req: Request): Promise<{ ok: true } | Response> {
  const auth = req.headers.get("Authorization") || "";
  if (!auth.startsWith("Bearer ")) {
    return jsonResponse({ error: "missing_auth" }, 401);
  }
  const token = auth.slice(7).trim();
  const serviceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") || "";
  // Service-role server-to-server bypass (used by other edge functions).
  if (serviceKey && token === serviceKey) {
    return { ok: true };
  }
  // Also accept any rotated service key from SUPABASE_SECRET_KEYS (JSON array of jwts).
  try {
    const raw = Deno.env.get("SUPABASE_SECRET_KEYS") || "";
    if (raw) {
      const parsed = JSON.parse(raw);
      const keys: string[] = Array.isArray(parsed)
        ? parsed.map((k: any) => (typeof k === "string" ? k : k?.key)).filter(Boolean)
        : [];
      if (keys.includes(token)) return { ok: true };
    }
  } catch (_) { /* ignore */ }
  const userClient = createClient(
    Deno.env.get("SUPABASE_URL")!,
    Deno.env.get("SUPABASE_ANON_KEY")!,
    { global: { headers: { Authorization: auth } } },
  );
  const { data: u, error } = await userClient.auth.getUser();
  if (error || !u?.user) return jsonResponse({ error: "invalid_jwt" }, 401);
  const admin = adminClient();
  const { data: row } = await admin
    .from("users")
    .select("id, role")
    .eq("id", u.user.id)
    .maybeSingle();
  if (!row || row.role !== "admin") {
    return jsonResponse({ error: "forbidden" }, 403);
  }
  return { ok: true };
}

/** Fetch a Zoom OAuth access token, using DB cache when fresh (>5 min remaining). */
export async function getZoomToken(forceRefresh = false): Promise<string> {
  const admin = adminClient();
  if (!forceRefresh) {
    const { data: cached } = await admin
      .from("zoom_token_cache")
      .select("access_token, expires_at")
      .eq("id", 1)
      .maybeSingle();
    if (cached?.access_token && cached.expires_at) {
      const remainingMs = new Date(cached.expires_at).getTime() - Date.now();
      if (remainingMs > 5 * 60 * 1000) return cached.access_token;
    }
  }

  const basic = btoa(`${ZOOM_CLIENT_ID}:${ZOOM_CLIENT_SECRET}`);
  const res = await fetch("https://zoom.us/oauth/token", {
    method: "POST",
    headers: {
      Authorization: `Basic ${basic}`,
      "Content-Type": "application/x-www-form-urlencoded",
    },
    body: `grant_type=account_credentials&account_id=${encodeURIComponent(ZOOM_ACCOUNT_ID)}`,
  });
  const json = await res.json().catch(() => ({}));
  if (!res.ok || !json.access_token) {
    throw new Error(`zoom_token_failed: ${res.status} ${JSON.stringify(json)}`);
  }
  const expiresAt = new Date(Date.now() + (json.expires_in ?? 3600) * 1000);
  await admin.from("zoom_token_cache").upsert({
    id: 1,
    access_token: json.access_token,
    expires_at: expiresAt.toISOString(),
    updated_at: new Date().toISOString(),
  });
  return json.access_token as string;
}

/** Call Zoom API with one auto-retry on 401 (token refresh) and 429 (rate limit). */
export async function zoomFetch(
  path: string,
  init: RequestInit & { jsonBody?: unknown } = {},
): Promise<Response> {
  const doCall = async (token: string) => {
    const headers: Record<string, string> = {
      Authorization: `Bearer ${token}`,
      ...(init.headers as Record<string, string> | undefined),
    };
    let body = init.body;
    if (init.jsonBody !== undefined) {
      headers["Content-Type"] = "application/json";
      body = JSON.stringify(init.jsonBody);
    }
    return fetch(`https://api.zoom.us/v2${path}`, {
      ...init,
      headers,
      body,
    });
  };

  let token = await getZoomToken();
  let res = await doCall(token);

  if (res.status === 401) {
    token = await getZoomToken(true);
    res = await doCall(token);
  }
  if (res.status === 429) {
    await new Promise((r) => setTimeout(r, 2000));
    res = await doCall(token);
  }
  return res;
}
