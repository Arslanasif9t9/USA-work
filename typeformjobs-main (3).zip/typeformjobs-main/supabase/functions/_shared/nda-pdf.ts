// Shared PDF generation for the NDA. Mirrors offer-pdf branding (EIA letterhead,
// navy + gold, Cormorant + Inter fonts) but with fixed NDA content.
import { PDFDocument, PDFFont, PDFPage, rgb, StandardFonts } from "npm:pdf-lib@1.17.1";
import fontkit from "npm:@pdf-lib/fontkit@1.1.1";

const ASSETS_BASE =
  Deno.env.get("SUPABASE_URL")! + "/storage/v1/object/public/assets/fonts";

const FONT_URLS = {
  cgRegular: `${ASSETS_BASE}/CormorantGaramond-Regular.ttf`,
  cgSemi: `${ASSETS_BASE}/CormorantGaramond-SemiBold.ttf`,
  cgItalic: `${ASSETS_BASE}/CormorantGaramond-Italic.ttf`,
  interReg: `${ASSETS_BASE}/Inter-Regular.ttf`,
  interSemi: `${ASSETS_BASE}/Inter-SemiBold.ttf`,
};

let FONT_BYTES: Record<string, Uint8Array> | null = null;
let FONT_ERR: string | null = null;

async function loadFonts(): Promise<{ bytes: Record<string, Uint8Array> | null; error: string | null }> {
  if (FONT_BYTES) return { bytes: FONT_BYTES, error: null };
  if (FONT_ERR) return { bytes: null, error: FONT_ERR };
  try {
    const entries = await Promise.all(
      Object.entries(FONT_URLS).map(async ([k, url]) => {
        const r = await fetch(url);
        if (!r.ok) throw new Error(`font ${k} ${r.status}`);
        return [k, new Uint8Array(await r.arrayBuffer())] as const;
      }),
    );
    FONT_BYTES = Object.fromEntries(entries);
    return { bytes: FONT_BYTES, error: null };
  } catch (e) {
    FONT_ERR = (e as Error).message;
    return { bytes: null, error: FONT_ERR };
  }
}

const NAVY = rgb(0.102, 0.145, 0.278);
const GOLD = rgb(0.69, 0.553, 0.341);
const INK = rgb(0.102, 0.133, 0.212);
const MUTED = rgb(0.42, 0.447, 0.502);
const HAIRLINE = rgb(0.882, 0.894, 0.925);

const PAGE_W = 612;
const PAGE_H = 792;
const M_TOP = 40;
const M_BOT = 40;
const M_SIDE = 61;
const CONTENT_W = PAGE_W - 2 * M_SIDE;

type Fonts = {
  cgReg: PDFFont; cgSemi: PDFFont; cgItalic: PDFFont;
  interReg: PDFFont; interSemi: PDFFont;
};

const wrap = (text: string, font: PDFFont, size: number, maxW: number): string[] => {
  const out: string[] = [];
  for (const para of text.split("\n")) {
    if (!para) { out.push(""); continue; }
    const words = para.split(/\s+/);
    let cur = "";
    for (const w of words) {
      const test = cur ? `${cur} ${w}` : w;
      if (font.widthOfTextAtSize(test, size) <= maxW || !cur) cur = test;
      else { out.push(cur); cur = w; }
    }
    if (cur) out.push(cur);
  }
  return out;
};

const drawLetterhead = (page: PDFPage, f: Fonts): number => {
  const top = PAGE_H - M_TOP;
  page.drawText("EIA", { x: M_SIDE, y: top - 20, font: f.cgSemi, size: 24, color: NAVY });
  page.drawText("Expert Intuitive Advisor Inc.", { x: M_SIDE, y: top - 33, font: f.cgItalic, size: 9, color: MUTED });
  page.drawText("The intelligence layer between humans and AI.", { x: M_SIDE, y: top - 44, font: f.cgItalic, size: 8, color: MUTED });
  const right = "EXPERTINTUITIVEADVISOR.COM";
  const rW = f.interSemi.widthOfTextAtSize(right, 8) + 1 * (right.length - 1);
  page.drawText(right, { x: PAGE_W - M_SIDE - rW, y: top - 20, font: f.interSemi, size: 8, color: NAVY, characterSpacing: 1 });
  const right2 = "HR@EXPERTINTUITIVEADVISOR.COM";
  const r2W = f.interReg.widthOfTextAtSize(right2, 8) + 1 * (right2.length - 1);
  page.drawText(right2, { x: PAGE_W - M_SIDE - r2W, y: top - 33, font: f.interReg, size: 8, color: MUTED, characterSpacing: 1 });
  const lineY = top - 56;
  page.drawLine({ start: { x: M_SIDE, y: lineY }, end: { x: M_SIDE + CONTENT_W, y: lineY }, thickness: 1.5, color: NAVY });
  return lineY - 24;
};

const drawFooter = (page: PDFPage, f: Fonts, pageNum: number, total: number) => {
  page.drawText("Expert Intuitive Advisor Inc. — Confidential", {
    x: M_SIDE, y: M_BOT - 6, font: f.cgItalic, size: 7, color: MUTED,
  });
  const txt = `Page ${pageNum} of ${total}`;
  const w = f.cgItalic.widthOfTextAtSize(txt, 7);
  page.drawText(txt, { x: PAGE_W - M_SIDE - w, y: M_BOT - 6, font: f.cgItalic, size: 7, color: MUTED });
};

// Section / bullet types and content
type Section = { num: string; title: string; intro?: string; bullets: string[] };

const NDA_TITLE = "NON-DISCLOSURE, CONFIDENTIALITY, AND COMPANY OWNERSHIP AGREEMENT";
const NDA_SUBTITLE = "Expert Intuitive Advisor Inc.";
const NDA_INTRO =
  'By signing below, I confirm that I am entering this Agreement with Expert Intuitive Advisor Inc. (the "Company") voluntarily, and I agree to all of the following — both during and after my engagement:';
const NDA_CLOSING =
  "By signing below, I confirm that I have read, understood, and voluntarily agreed to all terms above, and that I will fulfill my duties in a professional and responsible manner.";

const SECTIONS: Section[] = [
  { num: "1", title: "Confidentiality", bullets: [
    "I agree never to disclose, use, share, copy, or keep the Company's confidential information",
    "This includes: trade secrets, strategies, client data, login credentials, business processes, brand assets, photos, recordings, internal communications, and proprietary tools",
    "I agree to return all Company materials when my employment or contract ends",
  ] },
  { num: "2", title: "Non-Compete", bullets: [
    "I agree never to compete with the Company, or open, operate, or work for a competing business — during my engagement and permanently after it ends",
    "I agree never to share Company strategies with anyone",
    "I agree never to open an account for someone else, or under someone else",
    "I agree never to solicit the Company's clients, partners, or employees",
    "I understand this is a strict, permanent commitment with no expiration",
  ] },
  { num: "3", title: "Platform Restriction & Monitoring", bullets: [
    "I agree never to join, register, or work on the same platform(s) the Company uses — directly or indirectly, during or after my engagement",
    "I understand the Company may monitor unusual or suspicious activity that may signal a breach",
    "I understand any violation is treated as a serious infraction and pursued legally",
  ] },
  { num: "4", title: "No Posting or Sharing on Any Platform", bullets: [
    "I agree never to post, share, upload, or distribute any work-related materials",
    "This includes: documents, screenshots, videos, photos, text content, internal conversations",
    "On any platform, including: Facebook, TikTok, Instagram, Twitter (X), YouTube, any social media, or any website or internet platform",
  ] },
  { num: "5", title: "Company Account Ownership", bullets: [
    "I agree that all accounts, profiles, emails, platforms, phone numbers, photos, content, and materials created, used, or accessed during my engagement belong solely to the Company",
    "I agree I hold no ownership, claim, or right — now or in the future",
    "I agree never to represent myself as the owner or controller of any Company account, asset, or brand",
    "I agree never to question, challenge, request access to, or claim ownership of any Company asset, or contact platforms, clients, or third parties about Company ownership",
  ] },
  { num: "6", title: "Data Deletion & Access Termination Upon Exit", intro: "When my engagement ends, I agree to:", bullets: [
    "Permanently delete all work-related materials — videos, photos, documents, text files, screenshots, client information, login credentials and passwords",
    "Keep no copies, digital or physical",
    "Log out of all work-related accounts and sign out of all browsers",
    "Remove all saved passwords and delete any Company-provided email or accounts",
    "Remove all access from my devices",
    "Never attempt to access or recover any Company accounts, systems, or data afterward",
  ] },
  { num: "7", title: "Legal Enforcement & Governing Law", bullets: [
    "I understand this Agreement is legally binding",
    "I agree that any breach causes irreparable harm to the Company",
    "I understand that if I violate any term of this Agreement, the Company may pursue severe legal action against me — including, but not limited to, filing complaints with the National Bureau of Investigation (NBI) and any applicable government, law enforcement, or legal authority in my jurisdiction — and may seek damages, injunctions, and immediate legal remedies",
    "I understand such action may affect my legal standing and records, including my NBI clearance and similar government clearances",
    "This Agreement is governed by the laws of the jurisdiction in which I reside",
  ] },
];

export type NdaData = { signer_name: string; reference: string };

// Real signature rectangle in PDF bottom-origin coords (fieldTop = top edge of the field box).
export type SignatureRect = { page: number; x: number; fieldTop: number; width: number; height: number };
export type NdaBuildResult = { bytes: Uint8Array; pageCount: number; warning: string | null; signatureRect: SignatureRect };

// Layout engine: stream sections, paginate, reserve last-page space for signature block.
export async function buildNdaPdf(data: NdaData): Promise<NdaBuildResult> {
  const pdf = await PDFDocument.create();
  pdf.registerFontkit(fontkit);

  const { bytes: fb, error: fontErr } = await loadFonts();
  let f: Fonts;
  let warning: string | null = null;
  if (!fb) {
    warning = `font_load_failed: ${fontErr}`;
    const hel = await pdf.embedFont(StandardFonts.Helvetica);
    const helBold = await pdf.embedFont(StandardFonts.HelveticaBold);
    const helItalic = await pdf.embedFont(StandardFonts.HelveticaOblique);
    f = { cgReg: hel, cgSemi: helBold, cgItalic: helItalic, interReg: hel, interSemi: helBold };
  } else {
    f = {
      cgReg: await pdf.embedFont(fb.cgRegular, { subset: true }),
      cgSemi: await pdf.embedFont(fb.cgSemi, { subset: true }),
      cgItalic: await pdf.embedFont(fb.cgItalic, { subset: true }),
      interReg: await pdf.embedFont(fb.interReg, { subset: true }),
      interSemi: await pdf.embedFont(fb.interSemi, { subset: true }),
    };
  }

  // Streaming page allocator
  const pages: PDFPage[] = [];
  let page = pdf.addPage([PAGE_W, PAGE_H]);
  pages.push(page);
  let y = drawLetterhead(page, f);

  const newPage = () => {
    page = pdf.addPage([PAGE_W, PAGE_H]);
    pages.push(page);
    y = drawLetterhead(page, f);
  };

  const ensure = (need: number) => {
    if (y - need < M_BOT + 20) newPage();
  };

  // Page 1: Title block
  ensure(80);
  page.drawText(NDA_TITLE, {
    x: M_SIDE, y: y - 18, font: f.cgSemi, size: 16, color: NAVY,
    maxWidth: CONTENT_W,
  });
  // Wrap title manually if too wide
  const titleLines = wrap(NDA_TITLE, f.cgSemi, 16, CONTENT_W);
  let ty = y;
  for (const line of titleLines) {
    page.drawText(line, { x: M_SIDE, y: ty - 18, font: f.cgSemi, size: 16, color: NAVY });
    ty -= 22;
  }
  y = ty - 4;
  page.drawText(NDA_SUBTITLE, { x: M_SIDE, y: y - 14, font: f.cgItalic, size: 12, color: GOLD });
  y -= 30;

  // Reference + signer
  page.drawText(`Reference: ${data.reference}`, { x: M_SIDE, y, font: f.interReg, size: 9, color: MUTED });
  const sn = `Signer: ${data.signer_name}`;
  const snW = f.interReg.widthOfTextAtSize(sn, 9);
  page.drawText(sn, { x: PAGE_W - M_SIDE - snW, y, font: f.interReg, size: 9, color: MUTED });
  y -= 18;
  page.drawLine({ start: { x: M_SIDE, y }, end: { x: M_SIDE + CONTENT_W, y }, thickness: 1, color: HAIRLINE });
  y -= 18;

  // Intro paragraph
  const introLines = wrap(NDA_INTRO, f.interReg, 10.5, CONTENT_W);
  for (const line of introLines) {
    ensure(16);
    page.drawText(line, { x: M_SIDE, y, font: f.interReg, size: 10.5, color: INK });
    y -= 15;
  }
  y -= 8;

  // Sections
  for (const s of SECTIONS) {
    ensure(40);
    // Header
    page.drawText(s.num, { x: M_SIDE, y, font: f.cgItalic, size: 14, color: GOLD });
    const nw = f.cgItalic.widthOfTextAtSize(s.num, 14);
    page.drawText(s.title.toUpperCase(), {
      x: M_SIDE + nw + 8, y: y + 1, font: f.interSemi, size: 11, color: NAVY, characterSpacing: 2,
    });
    y -= 10;
    page.drawLine({ start: { x: M_SIDE, y }, end: { x: M_SIDE + CONTENT_W, y }, thickness: 1, color: HAIRLINE });
    y -= 14;

    if (s.intro) {
      const lines = wrap(s.intro, f.interReg, 10.5, CONTENT_W);
      for (const ln of lines) {
        ensure(16);
        page.drawText(ln, { x: M_SIDE, y, font: f.interReg, size: 10.5, color: INK });
        y -= 15;
      }
      y -= 4;
    }

    for (const b of s.bullets) {
      const lines = wrap(b, f.interReg, 10, CONTENT_W - 14);
      ensure(lines.length * 14 + 4);
      page.drawText("•", { x: M_SIDE, y, font: f.interReg, size: 10, color: GOLD });
      let by = y;
      for (let i = 0; i < lines.length; i++) {
        page.drawText(lines[i], { x: M_SIDE + 14, y: by, font: f.interReg, size: 10, color: INK });
        by -= 14;
      }
      y = by - 2;
    }
    y -= 8;
  }

  // Closing italic
  const closingLines = wrap(NDA_CLOSING, f.cgItalic, 11, CONTENT_W);
  ensure(closingLines.length * 16 + 8);
  y -= 6;
  for (const ln of closingLines) {
    page.drawText(ln, { x: M_SIDE, y, font: f.cgItalic, size: 11, color: NAVY });
    y -= 16;
  }
  y -= 14;

  // Reserve signature block (~120pt). If not enough room, start a new page.
  const SIG_HEIGHT = 130;
  if (y - SIG_HEIGHT < M_BOT + 20) newPage();

  // Signature block on the last (current) page
  const sigTop = y;
  page.drawLine({ start: { x: M_SIDE, y: sigTop }, end: { x: M_SIDE + CONTENT_W, y: sigTop }, thickness: 1, color: HAIRLINE });
  page.drawText("SIGNATURE", { x: M_SIDE, y: sigTop - 14, font: f.interSemi, size: 9, color: NAVY, characterSpacing: 2 });

  // Empty signature canvas area (SignFlow injects the field here)
  const fieldTop = sigTop - 28;
  const fieldH = 60;
  page.drawRectangle({
    x: M_SIDE, y: fieldTop - fieldH, width: 240, height: fieldH,
    borderColor: HAIRLINE, borderWidth: 0.5,
  });
  page.drawText("Employee Signature", { x: M_SIDE, y: fieldTop - fieldH - 12, font: f.interReg, size: 8, color: MUTED });

  // Name + Date columns
  const col2x = M_SIDE + 270;
  page.drawText("Employee Name", { x: col2x, y: sigTop - 14, font: f.interSemi, size: 9, color: NAVY, characterSpacing: 1 });
  page.drawText(data.signer_name, { x: col2x, y: sigTop - 32, font: f.interReg, size: 11, color: INK });
  page.drawLine({ start: { x: col2x, y: sigTop - 38 }, end: { x: col2x + 180, y: sigTop - 38 }, thickness: 0.5, color: HAIRLINE });

  page.drawText("Date", { x: col2x, y: sigTop - 56, font: f.interSemi, size: 9, color: NAVY, characterSpacing: 1 });
  page.drawLine({ start: { x: col2x, y: sigTop - 80 }, end: { x: col2x + 180, y: sigTop - 80 }, thickness: 0.5, color: HAIRLINE });

  // Footers on every page
  const total = pages.length;
  pages.forEach((p, i) => drawFooter(p, f, i + 1, total));

  const bytes = await pdf.save();
  return { bytes, pageCount: total, warning, signatureRect: { page: total, x: M_SIDE, fieldTop, width: 240, height: fieldH } };
}
