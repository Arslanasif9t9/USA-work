// Plain-body PDF builder for Circular Notices.
// Reuses the wrap()/newPage()/footer/page-break engine from nda-pdf.ts but with
// NO letterhead and a fully dynamic body (HR-typed). A simple bold title line is
// drawn at the top, then the body flows across as many pages as needed. A
// signature block is placed on the LAST page and signature_rect is returned so
// the orchestrator can convert to top-origin (y = 792 - fieldTop) exactly like
// the NDA builder.
import { PDFDocument, PDFFont, PDFPage, rgb, StandardFonts } from "npm:pdf-lib@1.17.1";
import fontkit from "npm:@pdf-lib/fontkit@1.1.1";

const ASSETS_BASE =
  Deno.env.get("SUPABASE_URL")! + "/storage/v1/object/public/assets/fonts";

const FONT_URLS = {
  cgSemi: `${ASSETS_BASE}/CormorantGaramond-SemiBold.ttf`,
  cgItalic: `${ASSETS_BASE}/CormorantGaramond-Italic.ttf`,
  interReg: `${ASSETS_BASE}/Inter-Regular.ttf`,
  interSemi: `${ASSETS_BASE}/Inter-SemiBold.ttf`,
};

let FONT_BYTES: Record<string, Uint8Array> | null = null;
let FONT_ERR: string | null = null;

async function loadFonts(): Promise<{ bytes: Record<string, Uint8Array> | null; error: string | null }> {
  if (FONT_BYTES) return { bytes: FONT_BYTES, error: null };
  if (FONT_ERR) return { bytes: null, error: FONT_ERR };
  try {
    const entries = await Promise.all(
      Object.entries(FONT_URLS).map(async ([k, url]) => {
        const r = await fetch(url);
        if (!r.ok) throw new Error(`font ${k} ${r.status}`);
        return [k, new Uint8Array(await r.arrayBuffer())] as const;
      }),
    );
    FONT_BYTES = Object.fromEntries(entries);
    return { bytes: FONT_BYTES, error: null };
  } catch (e) {
    FONT_ERR = (e as Error).message;
    return { bytes: null, error: FONT_ERR };
  }
}

const NAVY = rgb(0.102, 0.145, 0.278);
const INK = rgb(0.102, 0.133, 0.212);
const MUTED = rgb(0.42, 0.447, 0.502);
const HAIRLINE = rgb(0.882, 0.894, 0.925);

const PAGE_W = 612;
const PAGE_H = 792;
const M_TOP = 56;
const M_BOT = 40;
const M_SIDE = 61;
const CONTENT_W = PAGE_W - 2 * M_SIDE;

type Fonts = { cgSemi: PDFFont; cgItalic: PDFFont; interReg: PDFFont; interSemi: PDFFont };

const wrap = (text: string, font: PDFFont, size: number, maxW: number): string[] => {
  const out: string[] = [];
  for (const para of text.split("\n")) {
    if (!para) { out.push(""); continue; }
    const words = para.split(/\s+/);
    let cur = "";
    for (const w of words) {
      const test = cur ? `${cur} ${w}` : w;
      if (font.widthOfTextAtSize(test, size) <= maxW || !cur) cur = test;
      else { out.push(cur); cur = w; }
    }
    if (cur) out.push(cur);
  }
  return out;
};

const drawFooter = (page: PDFPage, f: Fonts, pageNum: number, total: number) => {
  page.drawText("Expert Intuitive Advisor Inc. — Internal Circular", {
    x: M_SIDE, y: M_BOT - 6, font: f.cgItalic, size: 7, color: MUTED,
  });
  const txt = `Page ${pageNum} of ${total}`;
  const w = f.cgItalic.widthOfTextAtSize(txt, 7);
  page.drawText(txt, { x: PAGE_W - M_SIDE - w, y: M_BOT - 6, font: f.cgItalic, size: 7, color: MUTED });
};

export type CircularData = { title: string; body: string; reference: string; signer_name?: string; branded?: boolean };

// Optional branded letterhead — drawn at the top of EVERY page when branded=true.
// This intentionally mirrors the offer letter's drawLetterhead (EIA logo, company
// name, tagline, website + email, navy hairline separator) so a branded circular
// matches the official EIA letter look. Returns the content-start Y (cursor).
const LH_TOP = 40; // matches offer-pdf M_TOP so the letterhead sits identically
const drawLetterhead = (page: PDFPage, f: Fonts): number => {
  const topY = PAGE_H - LH_TOP;
  // Left: EIA logo + company name + tagline.
  page.drawText("EIA", { x: M_SIDE, y: topY - 20, font: f.cgSemi, size: 24, color: NAVY });
  page.drawText("Expert Intuitive Advisor Inc.", { x: M_SIDE, y: topY - 33, font: f.cgItalic, size: 9, color: MUTED });
  page.drawText("The intelligence layer between humans and AI.", { x: M_SIDE, y: topY - 44, font: f.cgItalic, size: 8, color: MUTED });
  // Right: website + email (right-aligned, with the same character spacing).
  const rightX = PAGE_W - M_SIDE;
  const web = "EXPERTINTUITIVEADVISOR.COM";
  const webW = f.interSemi.widthOfTextAtSize(web, 8) + 1 * Math.max(0, web.length - 1);
  page.drawText(web, { x: rightX - webW, y: topY - 20, font: f.interSemi, size: 8, color: NAVY, characterSpacing: 1 });
  const mail = "HR@EXPERTINTUITIVEADVISOR.COM";
  const mailW = f.interReg.widthOfTextAtSize(mail, 8) + 1 * Math.max(0, mail.length - 1);
  page.drawText(mail, { x: rightX - mailW, y: topY - 33, font: f.interReg, size: 8, color: MUTED, characterSpacing: 1 });
  // Navy hairline below.
  const lineY = topY - 56;
  page.drawLine({ start: { x: M_SIDE, y: lineY }, end: { x: M_SIDE + CONTENT_W, y: lineY }, thickness: 1.5, color: NAVY });
  return lineY - 24; // content start Y
};

// Real signature rectangle in PDF bottom-origin coords (fieldTop = top edge of the field box).
export type SignatureRect = { page: number; x: number; fieldTop: number; width: number; height: number };
export type CircularBuildResult = { bytes: Uint8Array; pageCount: number; warning: string | null; signatureRect: SignatureRect };

export async function buildCircularPdf(data: CircularData): Promise<CircularBuildResult> {
  const pdf = await PDFDocument.create();
  pdf.registerFontkit(fontkit);

  const { bytes: fb, error: fontErr } = await loadFonts();
  let f: Fonts;
  let warning: string | null = null;
  if (!fb) {
    warning = `font_load_failed: ${fontErr}`;
    const hel = await pdf.embedFont(StandardFonts.Helvetica);
    const helBold = await pdf.embedFont(StandardFonts.HelveticaBold);
    const helItalic = await pdf.embedFont(StandardFonts.HelveticaOblique);
    f = { cgSemi: helBold, cgItalic: helItalic, interReg: hel, interSemi: helBold };
  } else {
    f = {
      cgSemi: await pdf.embedFont(fb.cgSemi, { subset: true }),
      cgItalic: await pdf.embedFont(fb.cgItalic, { subset: true }),
      interReg: await pdf.embedFont(fb.interReg, { subset: true }),
      interSemi: await pdf.embedFont(fb.interSemi, { subset: true }),
    };
  }

  // Streaming page allocator. Plain by default (current behavior); when
  // branded=true, draw the EIA letterhead at the top of every page and start
  // the body below it.
  const branded = data.branded === true;
  const pages: PDFPage[] = [];
  let page = pdf.addPage([PAGE_W, PAGE_H]);
  pages.push(page);
  let y = branded ? drawLetterhead(page, f) : PAGE_H - M_TOP;

  const newPage = () => {
    page = pdf.addPage([PAGE_W, PAGE_H]);
    pages.push(page);
    y = branded ? drawLetterhead(page, f) : PAGE_H - M_TOP;
  };

  const ensure = (need: number) => {
    if (y - need < M_BOT + 20) newPage();
  };

  // Optional bold title line at top (only on the first page).
  const title = (data.title || "").trim();
  if (title) {
    const titleLines = wrap(title, f.cgSemi, 18, CONTENT_W);
    for (const line of titleLines) {
      ensure(26);
      page.drawText(line, { x: M_SIDE, y: y - 18, font: f.cgSemi, size: 18, color: NAVY });
      y -= 24;
    }
    y -= 6;
    page.drawText(`Reference: ${data.reference}`, { x: M_SIDE, y, font: f.interReg, size: 9, color: MUTED });
    y -= 14;
    page.drawLine({ start: { x: M_SIDE, y }, end: { x: M_SIDE + CONTENT_W, y }, thickness: 1, color: HAIRLINE });
    y -= 18;
  }

  // Body — dynamic, flows across pages.
  const bodyLines = wrap(data.body || "", f.interReg, 11, CONTENT_W);
  for (const line of bodyLines) {
    ensure(17);
    if (line) page.drawText(line, { x: M_SIDE, y, font: f.interReg, size: 11, color: INK });
    y -= 16;
  }
  y -= 16;

  // Reserve signature block (~130pt). If not enough room, start a new page.
  const SIG_HEIGHT = 130;
  if (y - SIG_HEIGHT < M_BOT + 20) newPage();

  const sigTop = y;
  page.drawLine({ start: { x: M_SIDE, y: sigTop }, end: { x: M_SIDE + CONTENT_W, y: sigTop }, thickness: 1, color: HAIRLINE });
  page.drawText("SIGNATURE", { x: M_SIDE, y: sigTop - 14, font: f.interSemi, size: 9, color: NAVY, characterSpacing: 2 });

  const fieldTop = sigTop - 28;
  const fieldH = 60;
  page.drawRectangle({
    x: M_SIDE, y: fieldTop - fieldH, width: 240, height: fieldH,
    borderColor: HAIRLINE, borderWidth: 0.5,
  });
  page.drawText("Recipient Signature", { x: M_SIDE, y: fieldTop - fieldH - 12, font: f.interReg, size: 8, color: MUTED });

  const col2x = M_SIDE + 270;
  page.drawText("Recipient Name", { x: col2x, y: sigTop - 14, font: f.interSemi, size: 9, color: NAVY, characterSpacing: 1 });
  if (data.signer_name) page.drawText(data.signer_name, { x: col2x, y: sigTop - 32, font: f.interReg, size: 11, color: INK });
  page.drawLine({ start: { x: col2x, y: sigTop - 38 }, end: { x: col2x + 180, y: sigTop - 38 }, thickness: 0.5, color: HAIRLINE });

  page.drawText("Date", { x: col2x, y: sigTop - 56, font: f.interSemi, size: 9, color: NAVY, characterSpacing: 1 });
  page.drawLine({ start: { x: col2x, y: sigTop - 80 }, end: { x: col2x + 180, y: sigTop - 80 }, thickness: 0.5, color: HAIRLINE });

  const total = pages.length;
  pages.forEach((p, i) => drawFooter(p, f, i + 1, total));

  const bytes = await pdf.save();
  return { bytes, pageCount: total, warning, signatureRect: { page: total, x: M_SIDE, fieldTop, width: 240, height: fieldH } };
}
