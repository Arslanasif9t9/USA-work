// Shared helper for Piece 6 Part A:
//   1) PERMANENT ARCHIVE — pull a signed PDF from a (short-lived) source URL
//      and upload it to the private `signed-archive` bucket in the main EIA
//      project, organized by doc type + reference id. Returns the storage
//      path which callers should persist on the record's `archived_pdf_url`
//      column. This must complete BEFORE SignFlow's 7-day purge runs.
//   2) ALWAYS-ON OUTLOOK BACKUP — emails a completion notification with the
//      signed PDF attached to `app_settings.main_backup_email` (read LIVE at
//      send time). Never throws — best-effort, logged to `email_log`.
//   3) OPTIONAL GMAIL COPY — if the caller passes hr_copy_requested=true,
//      also emails the same payload to `app_settings.hr_copy_email`
//      (read LIVE) with optional inline override. Logged to `email_log`.
//
// All sends use the existing Resend sender talent@careers.expertintuitiveadvisor.com.
// Callers should pass best-effort: failures in this helper never roll back
// the primary completion.

import { createClient } from "npm:@supabase/supabase-js@2";

type Admin = ReturnType<typeof createClient>;

const RESEND_API_KEY = Deno.env.get("RESEND_API_KEY") || "";
const FROM_ADDRESS = "talent@expertintuitiveadvisor.com";
const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

export type DocType =
  | "offer"
  | "nda"
  | "joining-nda"
  | "exit-nda"
  | "settlement"
  | "leave"
  | "cash-advance"
  | "id-collection"
  | "pre-consultation"
  | "termination"
  | "circular"
  | "custom-document";

const STAGE_PREFIX: Record<DocType, string> = {
  "offer": "offer",
  "nda": "nda",
  "joining-nda": "joining_nda",
  "exit-nda": "exit_nda",
  "settlement": "settlement",
  "leave": "leave",
  "cash-advance": "cash_advance",
  "id-collection": "id_collection",
  "pre-consultation": "pre_consultation",
  "termination": "termination",
  "circular": "circular",
  "custom-document": "custom_document",
};

const DOC_LABEL: Record<DocType, string> = {
  "offer": "Signed Offer",
  "nda": "Signed NDA",
  "joining-nda": "Signed Joining NDA",
  "exit-nda": "Signed Exit NDA",
  "settlement": "Signed Settlement",
  "leave": "Completed Leave Request",
  "cash-advance": "Completed Cash Advance Request",
  "id-collection": "Completed ID Collection",
  "pre-consultation": "Pre-Consultation",
  "termination": "Termination Notice",
  "circular": "Signed Circular Notice",
  "custom-document": "Signed Custom Document",
};

function esc(s: string): string {
  return String(s ?? "").replace(/[&<>"']/g, (c) =>
    ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]!),
  );
}

async function readSetting(admin: Admin, key: "main_backup_email" | "hr_copy_email"): Promise<string | null> {
  try {
    const { data } = await admin.from("app_settings").select(key).eq("id", 1).maybeSingle();
    const v = (data as any)?.[key]?.trim();
    if (v && EMAIL_RE.test(v)) return v;
  } catch (_) { /* swallow */ }
  return null;
}

// --- 1) Permanent archive --------------------------------------------------

export type ArchiveResult = {
  ok: boolean;
  storage_path?: string;   // signed-archive/<type>/<reference>.pdf
  bytes?: Uint8Array | null;
  reason?: string;
};

export async function archiveSignedPdf(args: {
  admin: Admin;
  doc_type: DocType;
  external_reference: string;
  source_pdf_url: string;
}): Promise<ArchiveResult> {
  try {
    if (!args.source_pdf_url) return { ok: false, reason: "no_source_url" };
    const r = await fetch(args.source_pdf_url);
    if (!r.ok) return { ok: false, reason: `fetch_${r.status}` };
    const buf = new Uint8Array(await r.arrayBuffer());
    if (!buf.byteLength) return { ok: false, reason: "empty_pdf" };

    const safeRef = args.external_reference.replace(/[^a-zA-Z0-9._-]/g, "_");
    const path = `${args.doc_type}/${safeRef}.pdf`;

    const { error } = await args.admin.storage
      .from("signed-archive")
      .upload(path, buf, {
        contentType: "application/pdf",
        upsert: true,
      });
    if (error) return { ok: false, reason: `upload_failed:${error.message}`, bytes: buf };
    return { ok: true, storage_path: `signed-archive/${path}`, bytes: buf };
  } catch (e) {
    return { ok: false, reason: String((e as Error)?.message || e) };
  }
}

// --- 2 & 3) Backup emails (Outlook always + optional Gmail) ---------------

type BackupEmailArgs = {
  admin: Admin;
  doc_type: DocType;
  recipient_name: string;        // the original signer/employee name (for context only)
  external_reference: string;
  // If the PDF is already in memory (returned by archiveSignedPdf), attach it.
  // Otherwise we just include the source URL in the body.
  pdf_bytes?: Uint8Array | null;
  source_pdf_url?: string | null;
  // Optional contextual extras shown in the email body
  extras?: Array<[string, string]>;
  // Gmail / hr_copy
  hr_copy_requested?: boolean;
  hr_copy_email_override?: string | null;
  // For email_log traceability
  job_offer_id?: string | null;
  candidate_id?: string | null;
};

export type BackupResult = {
  main_backup_sent: boolean;
  main_backup_to?: string | null;
  main_backup_reason?: string;
  hr_copy_sent: boolean;
  hr_copy_to?: string | null;
  hr_copy_reason?: string;
};

async function sendOneBackup(opts: {
  admin: Admin;
  to: string;
  fromName: string;
  subject: string;
  html: string;
  text: string;
  attachment?: { filename: string; content: Uint8Array } | null;
  stage: string;
  job_offer_id?: string | null;
  candidate_id?: string | null;
}): Promise<{ ok: boolean; reason?: string; id?: string | null }> {
  if (!RESEND_API_KEY) return { ok: false, reason: "no_resend_key" };
  const payload: Record<string, unknown> = {
    from: `${opts.fromName} <${FROM_ADDRESS}>`,
    to: [opts.to],
    subject: opts.subject,
    html: opts.html,
    text: opts.text,
  };
  if (opts.attachment && opts.attachment.content && opts.attachment.content.byteLength) {
    // Resend expects base64 in `content` (string)
    const bytes = opts.attachment.content;
    // Chunked base64 encoding to keep peak memory low for photo-heavy PDFs.
    const CHUNK = 0x8000; // 32KB slices
    let bin = "";
    for (let i = 0; i < bytes.length; i += CHUNK) {
      bin += String.fromCharCode.apply(null, bytes.subarray(i, i + CHUNK) as unknown as number[]);
    }
    const b64 = btoa(bin);
    payload.attachments = [{ filename: opts.attachment.filename, content: b64 }];
  }
  let ok = false; let id: string | null = null; let err: string | null = null;
  try {
    const r = await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: { "Content-Type": "application/json", Authorization: `Bearer ${RESEND_API_KEY}` },
      body: JSON.stringify(payload),
    });
    const j = await r.json().catch(() => ({}));
    ok = r.ok;
    id = (j as any)?.id ?? null;
    if (!ok) err = JSON.stringify(j).slice(0, 500);
  } catch (e) {
    err = String((e as Error)?.message || e);
  }

  try {
    await opts.admin.from("email_log").insert({
      to_address: opts.to,
      from_address: FROM_ADDRESS,
      from_name: opts.fromName,
      sender: "resend",
      subject: opts.subject,
      stage: opts.stage,
      status: ok ? "sent" : "failed",
      sent_at: ok ? new Date().toISOString() : null,
      resend_message_id: id,
      error_message: ok ? null : err,
      candidate_id: opts.candidate_id ?? null,
      job_offer_id: opts.job_offer_id ?? null,
    });
  } catch (_) { /* never fail caller on log issues */ }

  return { ok, reason: ok ? undefined : (err || "send_failed"), id };
}

export async function sendCompletionBackups(args: BackupEmailArgs): Promise<BackupResult> {
  const out: BackupResult = { main_backup_sent: false, hr_copy_sent: false };
  const label = DOC_LABEL[args.doc_type];
  const stageBase = STAGE_PREFIX[args.doc_type];
  const subject = `${label} — ${args.recipient_name} (${args.external_reference})`;

  const extras = args.extras || [];
  const extrasHtml = extras.map(([k, v]) => `<li><strong>${esc(k)}:</strong> ${esc(v)}</li>`).join("");
  const extrasText = extras.map(([k, v]) => `${k}: ${v}`).join("\n");
  const pdfLine = args.source_pdf_url
    ? `\n\nOriginal source link (may expire): ${args.source_pdf_url}`
    : "";
  const pdfHtml = args.source_pdf_url
    ? `<p style="font-size:12px;color:#6b7280">Original source link (may expire after 7 days): <a href="${args.source_pdf_url}">${esc(args.source_pdf_url)}</a></p>`
    : "";
  const archivedNote = args.pdf_bytes ? " (PDF attached, permanent copy archived in EIA storage)" : "";

  const text = `${label}${archivedNote}\n\nRecipient: ${args.recipient_name}\nReference: ${args.external_reference}\n${extrasText}${pdfLine}\n\nThis is an automated completion notice. Do not reply.`;

  const html = `<div style="font-family:Arial,sans-serif;font-size:14px;color:#1a2236;line-height:1.6;max-width:600px">
<p><strong>${esc(label)}</strong>${archivedNote ? ` <span style="font-size:12px;color:#6b7280">${esc(archivedNote.trim())}</span>` : ""}</p>
<ul>
<li><strong>Recipient:</strong> ${esc(args.recipient_name)}</li>
<li><strong>Reference:</strong> ${esc(args.external_reference)}</li>
${extrasHtml}
</ul>
${pdfHtml}
<p style="font-size:12px;color:#6b7280">This is an automated completion notice. Do not reply.</p>
</div>`;

  const attachment = args.pdf_bytes && args.pdf_bytes.byteLength
    ? { filename: `${args.external_reference}.pdf`, content: args.pdf_bytes }
    : null;

  // --- Outlook (always) ---
  const mainTo = await readSetting(args.admin, "main_backup_email");
  out.main_backup_to = mainTo;
  if (mainTo) {
    const r = await sendOneBackup({
      admin: args.admin,
      to: mainTo,
      fromName: "EIA Archive (Main Backup)",
      subject,
      html,
      text,
      attachment,
      stage: `main_backup_${stageBase}`,
      job_offer_id: args.job_offer_id ?? null,
      candidate_id: args.candidate_id ?? null,
    });
    out.main_backup_sent = r.ok;
    if (!r.ok) out.main_backup_reason = r.reason;
  } else {
    out.main_backup_reason = "no_destination";
  }

  // --- Gmail (only if checkbox flag) ---
  if (args.hr_copy_requested) {
    const ov = (args.hr_copy_email_override || "").trim();
    const hrTo = (ov && EMAIL_RE.test(ov)) ? ov : await readSetting(args.admin, "hr_copy_email");
    out.hr_copy_to = hrTo;
    if (hrTo) {
      const r = await sendOneBackup({
        admin: args.admin,
        to: hrTo,
        fromName: "EIA HR (Internal Copy)",
        subject,
        html,
        text,
        attachment,
        stage: `hr_copy_${stageBase}`,
        job_offer_id: args.job_offer_id ?? null,
        candidate_id: args.candidate_id ?? null,
      });
      out.hr_copy_sent = r.ok;
      if (!r.ok) out.hr_copy_reason = r.reason;
    } else {
      out.hr_copy_reason = "no_destination";
    }
  }

  return out;
}
