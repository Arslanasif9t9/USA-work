// Shared .ics builder used by generate-ics, generate-ics-from-zoom, test-ics-generate.

export interface IcsInput {
  summary: string;
  description?: string;
  start_time: string; // ISO 8601
  duration_minutes: number;
  timezone?: string;
  location?: string;
  url?: string;
  candidate_name?: string;
  candidate_email?: string;
  organizer_name?: string;
  organizer_email?: string;
  uid?: string;
}

export interface IcsResult {
  ok: true;
  ics_content: string;
  filename: string;
  warnings: string[];
}

export interface IcsError {
  ok: false;
  error: string;
  details?: string;
}

const VALID_TZ = (tz: string) => {
  try {
    new Intl.DateTimeFormat("en-US", { timeZone: tz });
    return true;
  } catch {
    return false;
  }
};

/** RFC 5545 text escaping for SUMMARY/DESCRIPTION/LOCATION values. */
export function escapeIcsText(s: string): string {
  return s
    .replace(/\\/g, "\\\\")
    .replace(/\r\n|\r|\n/g, "\\n")
    .replace(/,/g, "\\,")
    .replace(/;/g, "\\;");
}

/** RFC 5545 line folding: max 75 octets per line; continuations begin with single space. */
export function foldLine(line: string): string {
  const encoder = new TextEncoder();
  const bytes = encoder.encode(line);
  if (bytes.length <= 75) return line;
  const out: string[] = [];
  let i = 0;
  const decoder = new TextDecoder();
  // First chunk: 75 bytes. Subsequent: 74 bytes (leading space counts).
  let limit = 75;
  while (i < bytes.length) {
    let end = Math.min(i + limit, bytes.length);
    // Avoid splitting multi-byte UTF-8 char: walk back if mid-codepoint.
    while (end > i && end < bytes.length && (bytes[end] & 0xc0) === 0x80) end--;
    out.push(decoder.decode(bytes.slice(i, end)));
    i = end;
    limit = 74;
  }
  return out.join("\r\n ");
}

function toIcsUtc(iso: string): string {
  // YYYYMMDDTHHMMSSZ
  const d = new Date(iso);
  const pad = (n: number) => String(n).padStart(2, "0");
  return (
    d.getUTCFullYear().toString() +
    pad(d.getUTCMonth() + 1) +
    pad(d.getUTCDate()) +
    "T" +
    pad(d.getUTCHours()) +
    pad(d.getUTCMinutes()) +
    pad(d.getUTCSeconds()) +
    "Z"
  );
}

export function buildIcs(input: IcsInput): IcsResult | IcsError {
  const summary = (input.summary || "").trim();
  if (!summary) return { ok: false, error: "empty_summary" };
  if (summary.length > 250) {
    return { ok: false, error: "summary_too_long" };
  }
  const startMs = Date.parse(input.start_time);
  if (isNaN(startMs)) return { ok: false, error: "invalid_start_time" };
  const duration = input.duration_minutes;
  if (!Number.isFinite(duration) || duration < 5 || duration > 480) {
    return { ok: false, error: "invalid_duration" };
  }

  const warnings: string[] = [];
  let tz = input.timezone || "Asia/Manila";
  if (!VALID_TZ(tz)) {
    warnings.push(`invalid_timezone_fallback:${tz}`);
    tz = "Asia/Manila";
  }

  // Truncate description if very long.
  let description = input.description || "";
  if (description.length > 1000) {
    description = description.slice(0, 997) + "...";
    warnings.push("description_truncated");
  }

  const startUtc = toIcsUtc(new Date(startMs).toISOString());
  const endUtc = toIcsUtc(new Date(startMs + duration * 60 * 1000).toISOString());
  const stamp = toIcsUtc(new Date().toISOString());
  const uid =
    input.uid ||
    `${crypto.randomUUID()}@expertintuitiveadvisor.com`;

  const lines: string[] = [];
  lines.push("BEGIN:VCALENDAR");
  lines.push("VERSION:2.0");
  lines.push("PRODID:-//Expert Intuitive Advisor//EIA Hiring//EN");
  lines.push("CALSCALE:GREGORIAN");
  lines.push("METHOD:REQUEST");
  lines.push("BEGIN:VEVENT");
  lines.push(`UID:${uid}`);
  lines.push(`DTSTAMP:${stamp}`);
  lines.push(`DTSTART:${startUtc}`);
  lines.push(`DTEND:${endUtc}`);
  lines.push(foldLine(`SUMMARY:${escapeIcsText(summary)}`));
  if (description) {
    lines.push(foldLine(`DESCRIPTION:${escapeIcsText(description)}`));
  }
  if (input.location) {
    lines.push(foldLine(`LOCATION:${escapeIcsText(input.location)}`));
  }
  if (input.url) {
    // URLs are not escaped (no commas/semicolons expected in well-formed URLs).
    lines.push(foldLine(`URL:${input.url}`));
  }
  if (input.candidate_email) {
    const cn = input.candidate_name
      ? `;CN=${escapeIcsText(input.candidate_name)}`
      : "";
    lines.push(
      foldLine(
        `ATTENDEE${cn};RSVP=TRUE;ROLE=REQ-PARTICIPANT;PARTSTAT=NEEDS-ACTION:mailto:${input.candidate_email}`,
      ),
    );
  }
  if (input.organizer_email) {
    const cn = input.organizer_name
      ? `;CN=${escapeIcsText(input.organizer_name)}`
      : "";
    lines.push(
      foldLine(`ORGANIZER${cn}:mailto:${input.organizer_email}`),
    );
  }
  lines.push("STATUS:CONFIRMED");
  lines.push("SEQUENCE:0");
  lines.push("END:VEVENT");
  lines.push("END:VCALENDAR");

  return {
    ok: true,
    ics_content: lines.join("\r\n") + "\r\n",
    filename: "interview.ics",
    warnings,
  };
}
