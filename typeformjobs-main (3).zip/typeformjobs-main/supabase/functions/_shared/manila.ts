// Manila timezone helpers. PHT = UTC+8 with no DST.
// We compute UTC instants from Manila wall-clock by subtracting 8h.

export const MANILA_TZ = "Asia/Manila";
export const MANILA_OFFSET_MIN = 8 * 60; // +08:00

/** Build a UTC Date for a Manila wall-clock (YYYY-MM-DD HH:MM). */
export function manilaWallToUtc(dateStr: string, timeStr: string): Date {
  // dateStr: YYYY-MM-DD, timeStr: HH:MM[:SS]
  const [y, m, d] = dateStr.split("-").map((x) => parseInt(x, 10));
  const [hh, mm, ss = 0] = timeStr.split(":").map((x) => parseInt(x, 10));
  // Pretend it's UTC, then subtract +8h offset.
  const asIfUtc = Date.UTC(y, m - 1, d, hh, mm, ss);
  return new Date(asIfUtc - MANILA_OFFSET_MIN * 60 * 1000);
}

/** Get Manila date components from a UTC Date. */
export function manilaParts(date: Date): {
  year: number;
  month: number;
  day: number;
  hour: number;
  minute: number;
  weekday: number; // 1=Mon ... 7=Sun
  dateStr: string; // YYYY-MM-DD
  timeStr: string; // HH:MM:SS
} {
  const fmt = new Intl.DateTimeFormat("en-GB", {
    timeZone: MANILA_TZ,
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
    weekday: "short",
    hour12: false,
  });
  const parts = fmt.formatToParts(date);
  const get = (t: string) => parts.find((p) => p.type === t)?.value || "";
  const year = parseInt(get("year"), 10);
  const month = parseInt(get("month"), 10);
  const day = parseInt(get("day"), 10);
  let hour = parseInt(get("hour"), 10);
  if (hour === 24) hour = 0;
  const minute = parseInt(get("minute"), 10);
  const second = parseInt(get("second"), 10);
  const wdMap: Record<string, number> = { Mon: 1, Tue: 2, Wed: 3, Thu: 4, Fri: 5, Sat: 6, Sun: 7 };
  const weekday = wdMap[get("weekday")] || 1;
  const pad = (n: number) => String(n).padStart(2, "0");
  return {
    year, month, day, hour, minute, weekday,
    dateStr: `${year}-${pad(month)}-${pad(day)}`,
    timeStr: `${pad(hour)}:${pad(minute)}:${pad(second)}`,
  };
}

export function formatManilaDate(date: Date): string {
  return new Intl.DateTimeFormat("en-US", {
    timeZone: MANILA_TZ,
    weekday: "long", year: "numeric", month: "long", day: "numeric",
  }).format(date);
}

export function formatManilaTime(date: Date): string {
  return new Intl.DateTimeFormat("en-US", {
    timeZone: MANILA_TZ, hour: "numeric", minute: "2-digit", hour12: true,
  }).format(date);
}
