// Shared PDF generation for the "Pre-Consultation Acknowledgment & Service
// Agreement" form. SEPARATE clone of cash-advance-pdf.ts so no existing layout
// is at risk. Branding = "Psychic John" ONLY — NO EIA logo, NO navy/gold
// letterhead, NO address/phone/domain/email footer. Purple accent.
// ONE PAGE: heading, intro, the agreed clauses (each a tick line), the
// arbitration clause, preferred-time line, Allura typed signature, name, date,
// and APPROVED / DECLINED footer state.
import { PDFDocument, PDFFont, PDFPage, rgb, StandardFonts } from "npm:pdf-lib@1.17.1";
import fontkit from "npm:@pdf-lib/fontkit@1.1.1";

const ASSETS_BASE =
  Deno.env.get("SUPABASE_URL")! + "/storage/v1/object/public/assets/fonts";

const FONT_URLS = {
  cgRegular: `${ASSETS_BASE}/CormorantGaramond-Regular.ttf`,
  cgSemi: `${ASSETS_BASE}/CormorantGaramond-SemiBold.ttf`,
  cgItalic: `${ASSETS_BASE}/CormorantGaramond-Italic.ttf`,
  interReg: `${ASSETS_BASE}/Inter-Regular.ttf`,
  interSemi: `${ASSETS_BASE}/Inter-SemiBold.ttf`,
  allura: `${ASSETS_BASE}/Allura-Regular.ttf`,
};

let FONT_BYTES: Record<string, Uint8Array> | null = null;
let FONT_ERR: string | null = null;

async function loadFonts(): Promise<{ bytes: Record<string, Uint8Array> | null; error: string | null }> {
  if (FONT_BYTES) return { bytes: FONT_BYTES, error: null };
  if (FONT_ERR) return { bytes: null, error: FONT_ERR };
  try {
    const entries = await Promise.all(
      Object.entries(FONT_URLS).map(async ([k, url]) => {
        const r = await fetch(url);
        if (!r.ok) throw new Error(`font ${k} ${r.status}`);
        return [k, new Uint8Array(await r.arrayBuffer())] as const;
      }),
    );
    FONT_BYTES = Object.fromEntries(entries);
    return { bytes: FONT_BYTES, error: null };
  } catch (e) {
    FONT_ERR = (e as Error).message;
    return { bytes: null, error: FONT_ERR };
  }
}

// Purple-accent palette (Psychic John). No EIA navy/gold anywhere.
const PURPLE = rgb(0.486, 0.227, 0.929); // #7c3aed
const PURPLE_DK = rgb(0.357, 0.094, 0.682); // #5b18ae
const INK = rgb(0.12, 0.12, 0.16);
const MUTED = rgb(0.42, 0.42, 0.47);
const HAIRLINE = rgb(0.86, 0.84, 0.92);
const GREEN = rgb(0.086, 0.392, 0.204);
const RED = rgb(0.69, 0.118, 0.149);

const PAGE_W = 612;
const PAGE_H = 792;
const M_TOP = 38;
const M_BOT = 34;
const M_SIDE = 50;
const CONTENT_W = PAGE_W - 2 * M_SIDE;

type Fonts = {
  cgReg: PDFFont; cgSemi: PDFFont; cgItalic: PDFFont;
  interReg: PDFFont; interSemi: PDFFont;
  allura: PDFFont;
};

const wrap = (text: string, font: PDFFont, size: number, maxW: number): string[] => {
  const out: string[] = [];
  for (const para of (text || "").split("\n")) {
    if (!para) { out.push(""); continue; }
    const words = para.split(/\s+/);
    let cur = "";
    for (const w of words) {
      const test = cur ? `${cur} ${w}` : w;
      if (font.widthOfTextAtSize(test, size) <= maxW || !cur) cur = test;
      else { out.push(cur); cur = w; }
    }
    if (cur) out.push(cur);
  }
  return out;
};

export type PreConsultationData = {
  signer_name: string;
  reference: string;
  pc_amount: string | null;
  pc_duration: string | null;
  pc_preferred_time: string | null;
  typed_name: string | null;
  signature_data: string | null;
  signature_date: string | null;
  status: string; // 'pending_approval' | 'approved' | 'declined'
  hr_decision_note: string | null;
  decided_at: string | null;
};

export type PreConsultationBuildResult = { bytes: Uint8Array; pageCount: number; warning: string | null };

function amountDisplay(raw: string | null): string {
  const v = (raw || "").trim();
  if (!v) return "$___";
  return v.startsWith("$") ? v : `$${v}`;
}

function buildClauses(amount: string | null, duration: string | null): string[] {
  const dur = (duration || "").trim() || "the agreed time";
  const amt = amountDisplay(amount);
  return [
    "I understand this reading/consultation is for guidance and entertainment purposes only.",
    `I understand my session is ${dur} and cannot go beyond that time.`,
    "It is my responsibility to ask all my questions during the session, in a timely manner — not at the last minute. If I forget to ask something, that is on me, and I will need to book and pay for a new session for new questions.",
    `I will not use confusion as a tactic (for example "I didn't understand," "I'm confused," "please repeat") to get free follow-ups after the session has ended.`,
    `I understand the ${amt} I paid covers this ${dur} session only. Psychic John's rate is $599 per hour, so this is not a full hour of time.`,
    "I understand predictions are not guaranteed. My own actions, choices, and karma shape my life. Psychic John only guides and reads my chart, and is not responsible for outcomes.",
    "I understand Psychic John is not a financial advisor and does not guarantee any financial result, that any specific person will contact me, or any specific outcome.",
    "I understand that if someone does not contact me, that is their own free will — not Psychic John's fault, and not something he can guarantee.",
    "I agree that no outcome or result can be blamed on Psychic John later.",
  ];
}

const ARBITRATION_CLAUSE =
  "I agree that any dispute will be resolved through binding arbitration, and I waive any right to file a lawsuit or court case regarding this reading or consultation.";

export async function buildPreConsultationPdf(data: PreConsultationData): Promise<PreConsultationBuildResult> {
  const pdf = await PDFDocument.create();
  pdf.registerFontkit(fontkit);

  const { bytes: fb, error: fontErr } = await loadFonts();
  let f: Fonts;
  let warning: string | null = null;
  if (!fb) {
    warning = `font_load_failed: ${fontErr}`;
    const hel = await pdf.embedFont(StandardFonts.Helvetica);
    const helBold = await pdf.embedFont(StandardFonts.HelveticaBold);
    const helItalic = await pdf.embedFont(StandardFonts.HelveticaOblique);
    f = { cgReg: hel, cgSemi: helBold, cgItalic: helItalic, interReg: hel, interSemi: helBold, allura: helItalic };
  } else {
    f = {
      cgReg: await pdf.embedFont(fb.cgRegular, { subset: true }),
      cgSemi: await pdf.embedFont(fb.cgSemi, { subset: true }),
      cgItalic: await pdf.embedFont(fb.cgItalic, { subset: true }),
      interReg: await pdf.embedFont(fb.interReg, { subset: true }),
      interSemi: await pdf.embedFont(fb.interSemi, { subset: true }),
      allura: await pdf.embedFont(fb.allura, { subset: false }),
    };
  }

  const page = pdf.addPage([PAGE_W, PAGE_H]);
  let y = PAGE_H - M_TOP;

  // Draw a purple tick (manual check mark) at the left margin baseline `ty`.
  const drawTick = (ty: number) => {
    const s = 8; // box size
    const bx = M_SIDE;
    const by = ty - s + 2;
    page.drawRectangle({ x: bx, y: by, width: s, height: s, borderColor: PURPLE, borderWidth: 0.8, color: rgb(0.95, 0.92, 1) });
    // check mark
    page.drawLine({ start: { x: bx + 1.6, y: by + s * 0.5 }, end: { x: bx + s * 0.4, y: by + 1.8 }, thickness: 1.1, color: PURPLE_DK });
    page.drawLine({ start: { x: bx + s * 0.4, y: by + 1.8 }, end: { x: bx + s - 1.2, y: by + s - 1.2 }, thickness: 1.1, color: PURPLE_DK });
  };

  // Heading top-left: "Psychic John" (purple)
  page.drawText("Psychic John", { x: M_SIDE, y: y - 18, font: f.cgSemi, size: 22, color: PURPLE });
  y -= 28;
  page.drawLine({ start: { x: M_SIDE, y }, end: { x: M_SIDE + CONTENT_W, y }, thickness: 1.5, color: PURPLE });
  y -= 18;

  // Title
  page.drawText("Pre-Consultation Acknowledgment & Service Agreement", {
    x: M_SIDE, y: y - 12, font: f.cgSemi, size: 15, color: PURPLE_DK,
  });
  y -= 24;

  // Reference + signer line
  page.drawText(`Reference: ${data.reference}`, { x: M_SIDE, y, font: f.interReg, size: 8.5, color: MUTED });
  const sn = `Client: ${data.signer_name}`;
  const snW = f.interReg.widthOfTextAtSize(sn, 8.5);
  page.drawText(sn, { x: PAGE_W - M_SIDE - snW, y, font: f.interReg, size: 8.5, color: MUTED });
  y -= 16;

  // Intro line
  const introLines = wrap("Please read and agree before your reading with Psychic John.", f.interSemi, 10, CONTENT_W);
  for (const ln of introLines) {
    page.drawText(ln, { x: M_SIDE, y, font: f.interSemi, size: 10, color: INK });
    y -= 14;
  }
  y -= 4;

  const clauses = buildClauses(data.pc_amount, data.pc_duration);
  const TEXT_X = M_SIDE + 16;
  const TEXT_W = CONTENT_W - 16;
  const FS = 9;
  const LH = 11;

  const drawClause = (text: string) => {
    const lines = wrap(text, f.interReg, FS, TEXT_W);
    drawTick(y);
    for (let i = 0; i < lines.length; i++) {
      page.drawText(lines[i], { x: TEXT_X, y, font: f.interReg, size: FS, color: INK });
      y -= LH;
    }
    y -= 4; // gap between clauses
  };

  for (const c of clauses) drawClause(c);

  // Arbitration section
  y -= 2;
  page.drawText("Arbutration Agreement", { x: M_SIDE, y, font: f.interSemi, size: 9.5, color: PURPLE_DK, characterSpacing: 0.5 });
  y -= 14;
  drawClause(ARBITRATION_CLAUSE);

  // Preferred-time line
  y -= 2;
  page.drawText("Preferred session time:", { x: M_SIDE, y, font: f.interSemi, size: 9, color: PURPLE_DK });
  const ptW = f.interSemi.widthOfTextAtSize("Preferred session time:", 9);
  page.drawText(data.pc_preferred_time || "—", { x: M_SIDE + ptW + 6, y, font: f.interReg, size: 9, color: INK });
  y -= 12;
  const noteLines = wrap("This time is only a suggestion, not a guarantee that Psychic John will call you at this time.", f.cgItalic, 8, CONTENT_W);
  for (const ln of noteLines) {
    page.drawText(ln, { x: M_SIDE, y, font: f.cgItalic, size: 8, color: MUTED });
    y -= 10;
  }
  y -= 8;

  // Signature block
  page.drawLine({ start: { x: M_SIDE, y }, end: { x: M_SIDE + CONTENT_W, y }, thickness: 0.8, color: HAIRLINE });
  y -= 14;
  page.drawText("SIGNATURE", { x: M_SIDE, y, font: f.interSemi, size: 9, color: PURPLE_DK, characterSpacing: 2 });
  y -= 16;

  const sigBoxX = M_SIDE;
  const sigBoxY = y - 52;
  const sigBoxW = 240;
  const sigBoxH = 52;
  page.drawRectangle({ x: sigBoxX, y: sigBoxY, width: sigBoxW, height: sigBoxH, borderColor: HAIRLINE, borderWidth: 0.5 });

  const typed = (data.typed_name || data.signer_name || "").trim();
  if (typed) {
    let sigSize = 30;
    const maxW = sigBoxW - 16;
    while (sigSize > 12 && f.allura.widthOfTextAtSize(typed, sigSize) > maxW) sigSize -= 1;
    const tW = f.allura.widthOfTextAtSize(typed, sigSize);
    const tH = f.allura.heightAtSize(sigSize);
    page.drawText(typed, {
      x: sigBoxX + (sigBoxW - tW) / 2,
      y: sigBoxY + (sigBoxH - tH) / 2 + 4,
      font: f.allura, size: sigSize, color: PURPLE_DK,
    });
  }
  page.drawText("Signature", { x: sigBoxX, y: sigBoxY - 10, font: f.interReg, size: 8, color: MUTED });

  const col2x = M_SIDE + 270;
  page.drawText("Name", { x: col2x, y, font: f.interSemi, size: 9, color: PURPLE_DK, characterSpacing: 1 });
  page.drawText(data.typed_name || data.signer_name, { x: col2x, y: y - 15, font: f.interReg, size: 11, color: INK });
  page.drawLine({ start: { x: col2x, y: y - 20 }, end: { x: col2x + 180, y: y - 20 }, thickness: 0.5, color: HAIRLINE });
  page.drawText("Date", { x: col2x, y: y - 36, font: f.interSemi, size: 9, color: PURPLE_DK, characterSpacing: 1 });
  page.drawText(data.signature_date || "—", { x: col2x, y: y - 51, font: f.interReg, size: 11, color: INK });
  page.drawLine({ start: { x: col2x, y: y - 56 }, end: { x: col2x + 180, y: y - 56 }, thickness: 0.5, color: HAIRLINE });

  y = sigBoxY - 22;

  // Decision footer
  if (data.status === "approved" || data.status === "declined") {
    page.drawLine({ start: { x: M_SIDE, y }, end: { x: M_SIDE + CONTENT_W, y }, thickness: 0.8, color: HAIRLINE });
    y -= 14;
    const isApproved = data.status === "approved";
    const decidedAt = data.decided_at
      ? new Date(data.decided_at).toLocaleString("en-US", {
          year: "numeric", month: "short", day: "numeric", hour: "numeric", minute: "2-digit", hour12: true,
        })
      : "—";
    const headline = isApproved ? `APPROVED on ${decidedAt}` : `DECLINED — decision on ${decidedAt}`;
    page.drawText(headline, { x: M_SIDE, y, font: f.interSemi, size: 11, color: isApproved ? GREEN : RED, characterSpacing: 1 });
    y -= 16;
    if (data.hr_decision_note && data.hr_decision_note.trim()) {
      const nl = wrap(`Note: ${data.hr_decision_note.trim()}`, f.interReg, 9.5, CONTENT_W);
      for (const ln of nl) { page.drawText(ln, { x: M_SIDE, y, font: f.interReg, size: 9.5, color: INK }); y -= 12; }
    }
  }

  // Footer — Psychic John only, no EIA, no contact details.
  page.drawText("Psychic John — Confidential", { x: M_SIDE, y: M_BOT - 6, font: f.cgItalic, size: 7, color: MUTED });

  const bytes = await pdf.save();
  return { bytes, pageCount: pdf.getPageCount(), warning };
}
