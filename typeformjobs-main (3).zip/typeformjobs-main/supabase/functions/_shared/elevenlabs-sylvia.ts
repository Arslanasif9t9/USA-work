// Shared ElevenLabs WhatsApp outbound send helper. Used by both
// launch-sylvia (HR-invoked) and launch-sylvia-cron (scheduler).
//
// Endpoint (from ElevenLabs docs):
//   POST https://api.elevenlabs.io/v1/convai/whatsapp/outbound-message
//   Header:  xi-api-key: <ELEVENLABS_API_KEY>          (server-only secret)
//   Body:    {
//     whatsapp_phone_number_id, whatsapp_user_id (digits-only),
//     template_name, template_language_code,
//     template_params: [ { type: "body", parameters: [ { type: "text", text } ] } ],
//     agent_id,
//   }

const ELEVENLABS_API_KEY = Deno.env.get("ELEVENLABS_API_KEY") || "";

export const SYLVIA_AGENT_ID = "agent_4501ksmjapkvf4gbqgwcfnjhjrgt";
export const SYLVIA_PHONE_NUMBER_ID = "1152463884612336";
export const SYLVIA_TEMPLATE_NAME = "eia_general_outreach_sylvia";
export const SYLVIA_TEMPLATE_LANG = "en";
export const EL_OUTBOUND_ENDPOINT =
  "https://api.elevenlabs.io/v1/convai/whatsapp/outbound-message";

export function normalizeWhatsAppDigits(num: string): string | null {
  const digits = (num || "").replace(/[^\d]/g, "");
  if (digits.length < 8 || digits.length > 15) return null;
  return digits;
}

function firstName(full: string | null | undefined): string {
  return ((full || "").trim().split(/\s+/)[0] || "there");
}

export async function sendSylviaWhatsApp(opts: {
  candidate_name: string;
  whatsapp_number: string;
}): Promise<{ ok: boolean; status: number; body: any; error?: string }> {
  if (!ELEVENLABS_API_KEY) {
    return { ok: false, status: 0, body: null, error: "missing_elevenlabs_api_key" };
  }
  const userId = normalizeWhatsAppDigits(opts.whatsapp_number);
  if (!userId) return { ok: false, status: 0, body: null, error: "invalid_whatsapp_number" };

  const payload = {
    whatsapp_phone_number_id: SYLVIA_PHONE_NUMBER_ID,
    whatsapp_user_id: userId,
    template_name: SYLVIA_TEMPLATE_NAME,
    template_language_code: SYLVIA_TEMPLATE_LANG,
    template_params: [{ type: "body", parameters: [{ type: "text", parameter_name: "name", text: firstName(opts.candidate_name) }] }],
    agent_id: SYLVIA_AGENT_ID,
  };

  let res: Response;
  try {
    res = await fetch(EL_OUTBOUND_ENDPOINT, {
      method: "POST",
      headers: {
        "xi-api-key": ELEVENLABS_API_KEY,
        "Content-Type": "application/json",
      },
      body: JSON.stringify(payload),
    });
  } catch (e) {
    return { ok: false, status: 0, body: null, error: String((e as any)?.message || e) };
  }
  const body = await res.json().catch(() => ({}));
  return { ok: res.ok, status: res.status, body };
}
