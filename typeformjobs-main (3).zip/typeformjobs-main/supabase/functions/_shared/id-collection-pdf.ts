// Shared PDF generation for the ID Collection form.
// SEPARATE clone of cash-advance-pdf.ts so the leave & cash-advance layouts are
// never at risk. Same EIA letterhead (navy + gold, Cormorant + Inter + Allura),
// per-page letterhead, "IDENTITY DOCUMENT COLLECTION" title, HR note, body note,
// two EMBEDDED ID photos, Allura signature box, and APPROVED / NOT-APPROVED
// decision footer.
import { PDFDocument, PDFFont, PDFImage, PDFPage, rgb, StandardFonts } from "npm:pdf-lib@1.17.1";
import fontkit from "npm:@pdf-lib/fontkit@1.1.1";

const ASSETS_BASE =
  Deno.env.get("SUPABASE_URL")! + "/storage/v1/object/public/assets/fonts";

const FONT_URLS = {
  cgRegular: `${ASSETS_BASE}/CormorantGaramond-Regular.ttf`,
  cgSemi: `${ASSETS_BASE}/CormorantGaramond-SemiBold.ttf`,
  cgItalic: `${ASSETS_BASE}/CormorantGaramond-Italic.ttf`,
  interReg: `${ASSETS_BASE}/Inter-Regular.ttf`,
  interSemi: `${ASSETS_BASE}/Inter-SemiBold.ttf`,
  allura: `${ASSETS_BASE}/Allura-Regular.ttf`,
};

let FONT_BYTES: Record<string, Uint8Array> | null = null;
let FONT_ERR: string | null = null;

async function loadFonts(): Promise<{ bytes: Record<string, Uint8Array> | null; error: string | null }> {
  if (FONT_BYTES) return { bytes: FONT_BYTES, error: null };
  if (FONT_ERR) return { bytes: null, error: FONT_ERR };
  try {
    const entries = await Promise.all(
      Object.entries(FONT_URLS).map(async ([k, url]) => {
        const r = await fetch(url);
        if (!r.ok) throw new Error(`font ${k} ${r.status}`);
        return [k, new Uint8Array(await r.arrayBuffer())] as const;
      }),
    );
    FONT_BYTES = Object.fromEntries(entries);
    return { bytes: FONT_BYTES, error: null };
  } catch (e) {
    FONT_ERR = (e as Error).message;
    return { bytes: null, error: FONT_ERR };
  }
}

const NAVY = rgb(0.102, 0.145, 0.278);
const GOLD = rgb(0.69, 0.553, 0.341);
const INK = rgb(0.102, 0.133, 0.212);
const MUTED = rgb(0.42, 0.447, 0.502);
const HAIRLINE = rgb(0.882, 0.894, 0.925);
const GREEN = rgb(0.086, 0.392, 0.204);
const RED = rgb(0.69, 0.118, 0.149);

const PAGE_W = 612;
const PAGE_H = 792;
const M_TOP = 40;
const M_BOT = 40;
const M_SIDE = 61;
const CONTENT_W = PAGE_W - 2 * M_SIDE;

type Fonts = {
  cgReg: PDFFont; cgSemi: PDFFont; cgItalic: PDFFont;
  interReg: PDFFont; interSemi: PDFFont;
  allura: PDFFont;
};

const wrap = (text: string, font: PDFFont, size: number, maxW: number): string[] => {
  const out: string[] = [];
  for (const para of (text || "").split("\n")) {
    if (!para) { out.push(""); continue; }
    const words = para.split(/\s+/);
    let cur = "";
    for (const w of words) {
      const test = cur ? `${cur} ${w}` : w;
      if (font.widthOfTextAtSize(test, size) <= maxW || !cur) cur = test;
      else { out.push(cur); cur = w; }
    }
    if (cur) out.push(cur);
  }
  return out;
};

const drawLetterhead = (page: PDFPage, f: Fonts): number => {
  const top = PAGE_H - M_TOP;
  page.drawText("EIA", { x: M_SIDE, y: top - 20, font: f.cgSemi, size: 24, color: NAVY });
  page.drawText("Expert Intuitive Advisor Inc.", { x: M_SIDE, y: top - 33, font: f.cgItalic, size: 9, color: MUTED });
  page.drawText("The intelligence layer between humans and AI.", { x: M_SIDE, y: top - 44, font: f.cgItalic, size: 8, color: MUTED });
  const right = "EXPERTINTUITIVEADVISOR.COM";
  const rW = f.interSemi.widthOfTextAtSize(right, 8) + 1 * (right.length - 1);
  page.drawText(right, { x: PAGE_W - M_SIDE - rW, y: top - 20, font: f.interSemi, size: 8, color: NAVY, characterSpacing: 1 });
  const right2 = "HR@EXPERTINTUITIVEADVISOR.COM";
  const r2W = f.interReg.widthOfTextAtSize(right2, 8) + 1 * (right2.length - 1);
  page.drawText(right2, { x: PAGE_W - M_SIDE - r2W, y: top - 33, font: f.interReg, size: 8, color: MUTED, characterSpacing: 1 });
  const lineY = top - 56;
  page.drawLine({ start: { x: M_SIDE, y: lineY }, end: { x: M_SIDE + CONTENT_W, y: lineY }, thickness: 1.5, color: NAVY });
  return lineY - 24;
};

const drawFooter = (page: PDFPage, f: Fonts, pageNum: number, total: number) => {
  page.drawText("Expert Intuitive Advisor Inc. — Confidential", {
    x: M_SIDE, y: M_BOT - 6, font: f.cgItalic, size: 7, color: MUTED,
  });
  const txt = `Page ${pageNum} of ${total}`;
  const w = f.cgItalic.widthOfTextAtSize(txt, 7);
  page.drawText(txt, { x: PAGE_W - M_SIDE - w, y: M_BOT - 6, font: f.cgItalic, size: 7, color: MUTED });
};

// An ID photo passed in as raw bytes (already downloaded from the private
// candidate-files bucket by the caller). ext is used to pick embed strategy.
export type IdPhotoInput = {
  bytes: Uint8Array | null;
  ext: string | null;   // e.g. "jpg", "jpeg", "png", "webp", "heic"
};

export type IdCollectionData = {
  signer_name: string;
  reference: string;
  id_hr_message: string | null;
  id_text_style: string | null;
  id_body_note: string | null;
  photo1: IdPhotoInput | null;
  photo2: IdPhotoInput | null;
  typed_name: string | null;
  signature_data: string | null;
  signature_date: string | null;
  status: string; // 'pending_approval' | 'approved' | 'declined'
  hr_decision_note: string | null;
  decided_at: string | null;
};

export type IdCollectionBuildResult = { bytes: Uint8Array; pageCount: number; warning: string | null };

// Try to embed an image; pdf-lib only supports JPG + PNG. For other formats
// (webp/heic/avif) return null so the caller can render a graceful placeholder.
async function tryEmbed(pdf: PDFDocument, photo: IdPhotoInput | null): Promise<PDFImage | null> {
  if (!photo || !photo.bytes || !photo.bytes.byteLength) return null;
  const ext = (photo.ext || "").toLowerCase();
  // Sniff magic bytes too (extension can lie).
  const b = photo.bytes;
  const isPng = b.length > 8 && b[0] === 0x89 && b[1] === 0x50 && b[2] === 0x4e && b[3] === 0x47;
  const isJpg = b.length > 3 && b[0] === 0xff && b[1] === 0xd8 && b[2] === 0xff;
  try {
    if (isPng || ext === "png") return await pdf.embedPng(b);
    if (isJpg || ext === "jpg" || ext === "jpeg") return await pdf.embedJpg(b);
    // Unknown — attempt jpg then png as a last resort.
    try { return await pdf.embedJpg(b); } catch { /* fallthrough */ }
    try { return await pdf.embedPng(b); } catch { /* fallthrough */ }
    return null;
  } catch {
    return null;
  }
}

export async function buildIdCollectionPdf(data: IdCollectionData): Promise<IdCollectionBuildResult> {
  const pdf = await PDFDocument.create();
  pdf.registerFontkit(fontkit);

  const { bytes: fb, error: fontErr } = await loadFonts();
  let f: Fonts;
  let warning: string | null = null;
  if (!fb) {
    warning = `font_load_failed: ${fontErr}`;
    const hel = await pdf.embedFont(StandardFonts.Helvetica);
    const helBold = await pdf.embedFont(StandardFonts.HelveticaBold);
    const helItalic = await pdf.embedFont(StandardFonts.HelveticaOblique);
    f = { cgReg: hel, cgSemi: helBold, cgItalic: helItalic, interReg: hel, interSemi: helBold, allura: helItalic };
  } else {
    f = {
      cgReg: await pdf.embedFont(fb.cgRegular, { subset: true }),
      cgSemi: await pdf.embedFont(fb.cgSemi, { subset: true }),
      cgItalic: await pdf.embedFont(fb.cgItalic, { subset: true }),
      interReg: await pdf.embedFont(fb.interReg, { subset: true }),
      interSemi: await pdf.embedFont(fb.interSemi, { subset: true }),
      allura: await pdf.embedFont(fb.allura, { subset: true }),
    };
  }

  // Pre-embed the two ID photos (graceful null if unsupported format).
  const img1 = await tryEmbed(pdf, data.photo1);
  const img2 = await tryEmbed(pdf, data.photo2);

  const pages: PDFPage[] = [];
  let page = pdf.addPage([PAGE_W, PAGE_H]);
  pages.push(page);
  let y = drawLetterhead(page, f);

  const newPage = () => {
    page = pdf.addPage([PAGE_W, PAGE_H]);
    pages.push(page);
    y = drawLetterhead(page, f);
  };
  const ensure = (need: number) => { if (y - need < M_BOT + 20) newPage(); };

  // Title
  ensure(60);
  page.drawText("IDENTITY DOCUMENT COLLECTION", { x: M_SIDE, y: y - 18, font: f.cgSemi, size: 18, color: NAVY });
  y -= 26;
  page.drawText("Expert Intuitive Advisor Inc.", { x: M_SIDE, y: y - 12, font: f.cgItalic, size: 12, color: GOLD });
  y -= 28;

  // Reference + signer
  page.drawText(`Reference: ${data.reference}`, { x: M_SIDE, y, font: f.interReg, size: 9, color: MUTED });
  const sn = `Employee: ${data.signer_name}`;
  const snW = f.interReg.widthOfTextAtSize(sn, 9);
  page.drawText(sn, { x: PAGE_W - M_SIDE - snW, y, font: f.interReg, size: 9, color: MUTED });
  y -= 14;
  page.drawLine({ start: { x: M_SIDE, y }, end: { x: M_SIDE + CONTENT_W, y }, thickness: 1, color: HAIRLINE });
  y -= 18;

  // Optional HR note (shown at top). Paginates cleanly: the cream background box
  // is chunked per page and we page-break BEFORE running off the bottom, so a long
  // HR message never overflows the footer or the signature block below.
  // Text style (data.id_text_style) only ADDS bullets/spacing — it never drops or
  // truncates any source character. We pre-build the styled, wrapped lines as
  // { text, x } and feed them through the SAME per-page chunking loop below.
  if (data.id_hr_message && data.id_hr_message.trim()) {
    const noteSize = 10.5;
    const baseX = M_SIDE + 8;
    const innerW = CONTENT_W - 16;
    const bulletPrefix = "•  ";
    const bulletW = f.interReg.widthOfTextAtSize(bulletPrefix, noteSize);
    const style = data.id_text_style === "spacing" || data.id_text_style === "paragraphs"
      ? data.id_text_style
      : "bullets";

    type RLine = { text: string; x: number };
    const renderLines: RLine[] = [];
    // Split on user-typed newlines. A "source line" = one thing the user typed.
    const src = data.id_hr_message.trim().split("\n");

    if (style === "paragraphs") {
      // Group consecutive non-empty source lines into paragraphs (blank lines split).
      const paras: string[] = [];
      let cur: string[] = [];
      for (const line of src) {
        if (line.trim() === "") { if (cur.length) { paras.push(cur.join(" ")); cur = []; } }
        else cur.push(line.trim());
      }
      if (cur.length) paras.push(cur.join(" "));
      paras.forEach((p, idx) => {
        for (const w of wrap(p, f.interReg, noteSize, innerW)) renderLines.push({ text: w, x: baseX });
        if (idx < paras.length - 1) renderLines.push({ text: "", x: baseX }); // one blank row between paragraphs
      });
    } else if (style === "spacing") {
      for (const line of src) {
        if (line.trim() === "") { renderLines.push({ text: "", x: baseX }); continue; }
        for (const w of wrap(line.trim(), f.interReg, noteSize, innerW)) renderLines.push({ text: w, x: baseX });
        renderLines.push({ text: "", x: baseX }); // one blank row after each source line
      }
    } else {
      // bullets: one bullet per non-empty source line; continuation wraps indent under text.
      for (const line of src) {
        if (line.trim() === "") { renderLines.push({ text: "", x: baseX }); continue; }
        const wrapped = wrap(line.trim(), f.interReg, noteSize, innerW - bulletW);
        wrapped.forEach((w, wi) => {
          if (wi === 0) renderLines.push({ text: bulletPrefix + w, x: baseX });
          else renderLines.push({ text: w, x: baseX + bulletW });
        });
        renderLines.push({ text: "", x: baseX }); // one blank row after each bullet block
      }
    }

    ensure(14 + 14 + 10);
    let first = true;
    let i = 0;
    while (i < renderLines.length) {
      const headerH = first ? 14 : 0;
      const avail = y - (M_BOT + 20) - headerH - 10;
      const fit = Math.max(1, Math.floor(avail / 14));
      const chunk = renderLines.slice(i, i + fit);
      const boxH = headerH + chunk.length * 14 + 10;
      // Background box FIRST, then the text on top (so text is never hidden).
      page.drawRectangle({
        x: M_SIDE, y: y - boxH + 12, width: CONTENT_W, height: boxH,
        color: rgb(0.972, 0.965, 0.945), borderColor: GOLD, borderWidth: 0.5,
      });
      if (first) {
        page.drawText("MESSAGE FROM HR", { x: M_SIDE + 8, y, font: f.interSemi, size: 8, color: GOLD, characterSpacing: 1 });
        y -= 14;
        first = false;
      }
      for (const ln of chunk) {
        if (ln.text) page.drawText(ln.text, { x: ln.x, y, font: f.interReg, size: noteSize, color: INK });
        y -= 14;
      }
      y -= 10;
      i += chunk.length;
      if (i < renderLines.length) newPage();
    }
    y -= 4;
  }

  // Field renderer (labeled section)
  const drawField = (label: string, value: string) => {
    const valueLines = wrap(value || "—", f.interReg, 10.5, CONTENT_W);
    const need = 14 + valueLines.length * 14 + 8;
    ensure(need);
    page.drawText(label, { x: M_SIDE, y, font: f.interSemi, size: 9, color: NAVY, characterSpacing: 1 });
    y -= 14;
    for (const ln of valueLines) {
      ensure(14);
      page.drawText(ln, { x: M_SIDE, y, font: f.interReg, size: 10.5, color: INK });
      y -= 14;
    }
    y -= 6;
  };

  drawField("NOTE FROM EMPLOYEE", data.id_body_note || "—");

  y -= 4;

  // ----- ID Photos (embedded) -----
  page.drawText("IDENTITY DOCUMENTS", { x: M_SIDE, y, font: f.interSemi, size: 9, color: NAVY, characterSpacing: 1 });
  y -= 16;

  const BOX_W = (CONTENT_W - 20) / 2; // two columns
  const BOX_H = 170;

  const drawPhotoBox = (boxX: number, boxTopY: number, label: string, img: PDFImage | null, raw: IdPhotoInput | null) => {
    const boxBottom = boxTopY - BOX_H;
    page.drawRectangle({
      x: boxX, y: boxBottom, width: BOX_W, height: BOX_H,
      borderColor: HAIRLINE, borderWidth: 0.75, color: rgb(0.985, 0.987, 0.992),
    });
    // label strip
    page.drawText(label, { x: boxX + 8, y: boxTopY - 14, font: f.interSemi, size: 8, color: NAVY, characterSpacing: 1 });
    const innerTop = boxTopY - 22;
    const innerH = BOX_H - 30;
    const innerW = BOX_W - 16;
    const innerX = boxX + 8;
    const innerBottom = innerTop - innerH;
    if (img) {
      const scale = Math.min(innerW / img.width, innerH / img.height);
      const w = img.width * scale;
      const h = img.height * scale;
      page.drawImage(img, {
        x: innerX + (innerW - w) / 2,
        y: innerBottom + (innerH - h) / 2,
        width: w, height: h,
      });
    } else {
      const msg = raw && raw.bytes && raw.bytes.byteLength
        ? "Photo on file (format not embeddable)"
        : "No photo provided";
      const lines = wrap(msg, f.interReg, 9, innerW);
      let ty = innerBottom + innerH / 2 + (lines.length * 11) / 2 - 8;
      for (const ln of lines) {
        const lw = f.interReg.widthOfTextAtSize(ln, 9);
        page.drawText(ln, { x: innerX + (innerW - lw) / 2, y: ty, font: f.interReg, size: 9, color: MUTED });
        ty -= 11;
      }
    }
  };

  ensure(BOX_H + 20);
  const photoTopY = y;
  drawPhotoBox(M_SIDE, photoTopY, "ID PHOTO 1", img1, data.photo1);
  drawPhotoBox(M_SIDE + BOX_W + 20, photoTopY, "ID PHOTO 2", img2, data.photo2);
  y = photoTopY - BOX_H - 16;

  // Signature block
  const SIG_HEIGHT = 140;
  if (y - SIG_HEIGHT < M_BOT + 60) newPage();

  page.drawLine({ start: { x: M_SIDE, y }, end: { x: M_SIDE + CONTENT_W, y }, thickness: 1, color: HAIRLINE });
  y -= 14;
  page.drawText("SIGNATURE", { x: M_SIDE, y, font: f.interSemi, size: 9, color: NAVY, characterSpacing: 2 });
  y -= 18;

  const sigBoxX = M_SIDE;
  const sigBoxY = y - 60;
  const sigBoxW = 240;
  const sigBoxH = 60;
  page.drawRectangle({
    x: sigBoxX, y: sigBoxY, width: sigBoxW, height: sigBoxH,
    borderColor: HAIRLINE, borderWidth: 0.5,
  });

  const typed = (data.typed_name || data.signer_name || "").trim();
  if (typed) {
    let sigSize = 32;
    const maxW = sigBoxW - 16;
    while (sigSize > 12 && f.allura.widthOfTextAtSize(typed, sigSize) > maxW) {
      sigSize -= 1;
    }
    const tW = f.allura.widthOfTextAtSize(typed, sigSize);
    const tH = f.allura.heightAtSize(sigSize);
    page.drawText(typed, {
      x: sigBoxX + (sigBoxW - tW) / 2,
      y: sigBoxY + (sigBoxH - tH) / 2 + 4,
      font: f.allura, size: sigSize, color: NAVY,
    });
  }
  page.drawText("Signature", { x: sigBoxX, y: sigBoxY - 10, font: f.interReg, size: 8, color: MUTED });

  const col2x = M_SIDE + 270;
  page.drawText("Name", { x: col2x, y, font: f.interSemi, size: 9, color: NAVY, characterSpacing: 1 });
  page.drawText(data.typed_name || data.signer_name, { x: col2x, y: y - 16, font: f.interReg, size: 11, color: INK });
  page.drawLine({ start: { x: col2x, y: y - 22 }, end: { x: col2x + 180, y: y - 22 }, thickness: 0.5, color: HAIRLINE });

  page.drawText("Date", { x: col2x, y: y - 40, font: f.interSemi, size: 9, color: NAVY, characterSpacing: 1 });
  page.drawText(data.signature_date || "—", { x: col2x, y: y - 56, font: f.interReg, size: 11, color: INK });
  page.drawLine({ start: { x: col2x, y: y - 62 }, end: { x: col2x + 180, y: y - 62 }, thickness: 0.5, color: HAIRLINE });

  y = sigBoxY - 24;

  // Decision footer
  if (data.status === "approved" || data.status === "declined") {
    ensure(60);
    page.drawLine({ start: { x: M_SIDE, y }, end: { x: M_SIDE + CONTENT_W, y }, thickness: 1, color: HAIRLINE });
    y -= 16;
    const isApproved = data.status === "approved";
    const decidedAt = data.decided_at
      ? new Date(data.decided_at).toLocaleString("en-US", {
          year: "numeric", month: "short", day: "numeric",
          hour: "numeric", minute: "2-digit", hour12: true,
        })
      : "—";
    const headline = isApproved
      ? `APPROVED by HR on ${decidedAt}`
      : `NOT APPROVED — decision on ${decidedAt}`;
    page.drawText(headline, {
      x: M_SIDE, y, font: f.interSemi, size: 11,
      color: isApproved ? GREEN : RED, characterSpacing: 1,
    });
    y -= 18;
    if (data.hr_decision_note && data.hr_decision_note.trim()) {
      const noteLines = wrap(`Note from HR: ${data.hr_decision_note.trim()}`, f.interReg, 10, CONTENT_W);
      for (const ln of noteLines) {
        ensure(14);
        page.drawText(ln, { x: M_SIDE, y, font: f.interReg, size: 10, color: INK });
        y -= 14;
      }
    }
  }

  const total = pages.length;
  pages.forEach((p, i) => drawFooter(p, f, i + 1, total));

  const bytes = await pdf.save();
  return { bytes, pageCount: total, warning };
}
