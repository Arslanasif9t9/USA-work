// Shared helper: send the optional "copy to internal backup inbox" email.
// Reads app_settings.hr_copy_email LIVE at call time (never a snapshot from
// when the checkbox was set). Sends via Resend using the same sender used by
// the existing flows (talent@careers.expertintuitiveadvisor.com). Logs each
// send to email_log with the supplied stage. NEVER throws — callers can call
// it best-effort right after the primary completion event.
//
// IMPORTANT: do NOT call this with the candidate's private signing/interview
// link. Only call it once a completed artifact exists (signed PDF URL,
// merged video URL, sent termination notice). The recipient is the internal
// HR backup inbox — they get the final result, never the candidate's link.

import { createClient } from "npm:@supabase/supabase-js@2";

type Admin = ReturnType<typeof createClient>;

const RESEND_API_KEY = Deno.env.get("RESEND_API_KEY") || "";
const FROM_NAME = "EIA HR (Internal Copy)";
const FROM_ADDRESS = "talent@expertintuitiveadvisor.com";

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

export type HrCopyStage =
  | "hr_copy_offer"
  | "hr_copy_nda"
  | "hr_copy_joining_nda"
  | "hr_copy_exit_nda"
  | "hr_copy_settlement"
  | "hr_copy_leave"
  | "hr_copy_termination"
  | "hr_copy_interview_video";

export type HrCopyArgs = {
  admin: Admin;
  stage: HrCopyStage;
  subject: string;
  html: string;
  text: string;
  // Optional one-off override email (set at send time by HR via inline edit).
  // If invalid/empty, falls back to app_settings.hr_copy_email.
  override_email?: string | null;
  // Identifiers for traceability in email_log
  job_offer_id?: string | null;
  candidate_id?: string | null;
};

async function resolveDestination(admin: Admin, override?: string | null): Promise<string | null> {
  const ov = (override || "").trim();
  if (ov && EMAIL_RE.test(ov)) return ov;
  try {
    const { data } = await admin
      .from("app_settings")
      .select("hr_copy_email")
      .eq("id", 1)
      .maybeSingle();
    const v = (data as any)?.hr_copy_email?.trim();
    if (v && EMAIL_RE.test(v)) return v;
  } catch (_) { /* swallow */ }
  return null;
}

export async function sendHrCopy(args: HrCopyArgs): Promise<{ sent: boolean; reason?: string; to?: string; resend_id?: string | null }> {
  try {
    if (!RESEND_API_KEY) return { sent: false, reason: "no_resend_key" };
    const to = await resolveDestination(args.admin, args.override_email);
    if (!to) return { sent: false, reason: "no_destination" };

    const r = await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${RESEND_API_KEY}`,
      },
      body: JSON.stringify({
        from: `${FROM_NAME} <${FROM_ADDRESS}>`,
        to: [to],
        subject: args.subject,
        html: args.html,
        text: args.text,
      }),
    });
    const j = await r.json().catch(() => ({}));
    const ok = r.ok;
    const resendId = (j as any)?.id ?? null;

    // Log to email_log
    try {
      await args.admin.from("email_log").insert({
        to_address: to,
        from_address: FROM_ADDRESS,
        from_name: FROM_NAME,
        sender: "resend",
        subject: args.subject,
        stage: args.stage,
        status: ok ? "sent" : "failed",
        sent_at: ok ? new Date().toISOString() : null,
        resend_message_id: resendId,
        error_message: ok ? null : JSON.stringify(j).slice(0, 500),
        candidate_id: args.candidate_id ?? null,
        job_offer_id: args.job_offer_id ?? null,
      });
    } catch (_) { /* log failure must not break copy result */ }

    return { sent: ok, to, resend_id: resendId, reason: ok ? undefined : "send_failed" };
  } catch (e) {
    return { sent: false, reason: String((e as Error)?.message || e) };
  }
}

// Pretty HTML/text builders used by callers
export function buildLinkBody(kind: string, recipientName: string, link: string, extras: Array<[string, string]> = []) {
  const extrasHtml = extras.map(([k, v]) => `<li><strong>${k}:</strong> ${escapeHtml(v)}</li>`).join("");
  const extrasText = extras.map(([k, v]) => `${k}: ${v}`).join("\n");
  const text = `Internal copy — ${kind}

Recipient: ${recipientName}
${extrasText ? extrasText + "\n" : ""}
Link: ${link}

This is an automated copy of a completed record sent to the internal HR backup inbox. The original record was delivered to the recipient directly. Do not forward this link to the recipient — they already received their own copy.`;
  const html = `<div style="font-family:Arial,sans-serif;font-size:14px;color:#1a2236;line-height:1.6;max-width:600px">
<p><strong>Internal copy — ${escapeHtml(kind)}</strong></p>
<p><strong>Recipient:</strong> ${escapeHtml(recipientName)}</p>
${extras.length ? `<ul>${extrasHtml}</ul>` : ""}
<p><a href="${link}" style="color:#1a2547">${escapeHtml(link)}</a></p>
<p style="font-size:12px;color:#6b7280">This is an automated copy of a completed record sent to the internal HR backup inbox. The original record was delivered to the recipient directly. Do not forward this link to the recipient — they already received their own copy.</p>
</div>`;
  return { html, text };
}

function escapeHtml(s: string): string {
  return String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]!));
}
