// Shared PDF generation for the Universal Custom Document.
// CLONED from nda-pdf.ts (same page geometry, margins, navy + gold, Cormorant +
// Inter fonts, streaming wrap() + ensure() body engine that auto-paginates and
// never overlaps the signature). Differences vs nda-pdf:
//   - title + body are fully custom (passed in by HR)
//   - optional `branding` arg swaps letterhead/footer to a custom company;
//     when null/absent the EIA letterhead/footer render BYTE-IDENTICAL to NDA.
//   - a manager signature block (Allura) is drawn above the SignFlow signer block.
import { PDFDocument, PDFFont, PDFPage, rgb, StandardFonts } from "npm:pdf-lib@1.17.1";
import fontkit from "npm:@pdf-lib/fontkit@1.1.1";

const ASSETS_BASE =
  Deno.env.get("SUPABASE_URL")! + "/storage/v1/object/public/assets/fonts";

const FONT_URLS = {
  cgRegular: `${ASSETS_BASE}/CormorantGaramond-Regular.ttf`,
  cgSemi: `${ASSETS_BASE}/CormorantGaramond-SemiBold.ttf`,
  cgItalic: `${ASSETS_BASE}/CormorantGaramond-Italic.ttf`,
  interReg: `${ASSETS_BASE}/Inter-Regular.ttf`,
  interSemi: `${ASSETS_BASE}/Inter-SemiBold.ttf`,
  allura: `${ASSETS_BASE}/Allura-Regular.ttf`,
};

let FONT_BYTES: Record<string, Uint8Array> | null = null;
let FONT_ERR: string | null = null;

async function loadFonts(): Promise<{ bytes: Record<string, Uint8Array> | null; error: string | null }> {
  if (FONT_BYTES) return { bytes: FONT_BYTES, error: null };
  if (FONT_ERR) return { bytes: null, error: FONT_ERR };
  try {
    const entries = await Promise.all(
      Object.entries(FONT_URLS).map(async ([k, url]) => {
        const r = await fetch(url);
        if (!r.ok) throw new Error(`font ${k} ${r.status}`);
        return [k, new Uint8Array(await r.arrayBuffer())] as const;
      }),
    );
    FONT_BYTES = Object.fromEntries(entries);
    return { bytes: FONT_BYTES, error: null };
  } catch (e) {
    FONT_ERR = (e as Error).message;
    return { bytes: null, error: FONT_ERR };
  }
}

const NAVY = rgb(0.102, 0.145, 0.278);
const GOLD = rgb(0.69, 0.553, 0.341);
const INK = rgb(0.102, 0.133, 0.212);
const MUTED = rgb(0.42, 0.447, 0.502);
const HAIRLINE = rgb(0.882, 0.894, 0.925);

const PAGE_W = 612;
const PAGE_H = 792;
const M_TOP = 40;
const M_BOT = 40;
const M_SIDE = 61;
const CONTENT_W = PAGE_W - 2 * M_SIDE;

export type Branding = { companyName: string; email: string; website: string };

type Fonts = {
  cgReg: PDFFont; cgSemi: PDFFont; cgItalic: PDFFont;
  interReg: PDFFont; interSemi: PDFFont; allura: PDFFont;
};

const wrap = (text: string, font: PDFFont, size: number, maxW: number): string[] => {
  const out: string[] = [];
  for (const para of text.split("\n")) {
    if (!para) { out.push(""); continue; }
    const words = para.split(/\s+/);
    let cur = "";
    for (const w of words) {
      const test = cur ? `${cur} ${w}` : w;
      if (font.widthOfTextAtSize(test, size) <= maxW || !cur) cur = test;
      else { out.push(cur); cur = w; }
    }
    if (cur) out.push(cur);
  }
  return out;
};

// Letterhead — defaults to EXACT EIA values; swaps to custom company when branding present.
const drawLetterhead = (page: PDFPage, f: Fonts, branding: Branding | null): number => {
  const top = PAGE_H - M_TOP;
  if (!branding) {
    page.drawText("EIA", { x: M_SIDE, y: top - 20, font: f.cgSemi, size: 24, color: NAVY });
    page.drawText("Expert Intuitive Advisor Inc.", { x: M_SIDE, y: top - 33, font: f.cgItalic, size: 9, color: MUTED });
    page.drawText("The intelligence layer between humans and AI.", { x: M_SIDE, y: top - 44, font: f.cgItalic, size: 8, color: MUTED });
    const right = "EXPERTINTUITIVEADVISOR.COM";
    const rW = f.interSemi.widthOfTextAtSize(right, 8) + 1 * (right.length - 1);
    page.drawText(right, { x: PAGE_W - M_SIDE - rW, y: top - 20, font: f.interSemi, size: 8, color: NAVY, characterSpacing: 1 });
    const right2 = "HR@EXPERTINTUITIVEADVISOR.COM";
    const r2W = f.interReg.widthOfTextAtSize(right2, 8) + 1 * (right2.length - 1);
    page.drawText(right2, { x: PAGE_W - M_SIDE - r2W, y: top - 33, font: f.interReg, size: 8, color: MUTED, characterSpacing: 1 });
  } else {
    // Custom company mode: render company NAME as the wordmark (text, no logo).
    const name = branding.companyName.trim() || "Company";
    page.drawText(name, { x: M_SIDE, y: top - 20, font: f.cgSemi, size: 22, color: NAVY });
    const website = (branding.website || "").trim().toUpperCase();
    const email = (branding.email || "").trim().toUpperCase();
    if (website) {
      const rW = f.interSemi.widthOfTextAtSize(website, 8) + 1 * (website.length - 1);
      page.drawText(website, { x: PAGE_W - M_SIDE - rW, y: top - 20, font: f.interSemi, size: 8, color: NAVY, characterSpacing: 1 });
    }
    if (email) {
      const r2W = f.interReg.widthOfTextAtSize(email, 8) + 1 * (email.length - 1);
      page.drawText(email, { x: PAGE_W - M_SIDE - r2W, y: top - 33, font: f.interReg, size: 8, color: MUTED, characterSpacing: 1 });
    }
  }
  const lineY = top - 56;
  page.drawLine({ start: { x: M_SIDE, y: lineY }, end: { x: M_SIDE + CONTENT_W, y: lineY }, thickness: 1.5, color: NAVY });
  return lineY - 24;
};

const drawFooter = (page: PDFPage, f: Fonts, pageNum: number, total: number, branding: Branding | null) => {
  const companyName = branding ? (branding.companyName.trim() || "Company") : "Expert Intuitive Advisor Inc.";
  page.drawText(`${companyName} — Confidential`, {
    x: M_SIDE, y: M_BOT - 6, font: f.cgItalic, size: 7, color: MUTED,
  });
  const txt = `Page ${pageNum} of ${total}`;
  const w = f.cgItalic.widthOfTextAtSize(txt, 7);
  page.drawText(txt, { x: PAGE_W - M_SIDE - w, y: M_BOT - 6, font: f.cgItalic, size: 7, color: MUTED });
};

// Real signature rectangle in PDF bottom-origin coords (fieldTop = top edge of the field box).
export type SignatureRect = { page: number; x: number; fieldTop: number; width: number; height: number };
export type CustomDocBuildResult = { bytes: Uint8Array; pageCount: number; warning: string | null; signatureRect: SignatureRect };

export type CustomDocData = {
  title: string;
  body_text: string;
  reference: string;
  signer_name: string;
  manager_name: string;
  branding?: Branding | null;
};

const formatShortDate = (d: Date): string => {
  const MONTHS = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
  try {
    if (isNaN(d.getTime())) throw new Error("bad");
    return `${MONTHS[d.getUTCMonth()]} ${d.getUTCDate()}, ${d.getUTCFullYear()}`;
  } catch {
    return new Date().toISOString().slice(0, 10);
  }
};

export async function buildCustomDocumentPdf(data: CustomDocData): Promise<CustomDocBuildResult> {
  const branding = data.branding ?? null;
  const pdf = await PDFDocument.create();
  pdf.registerFontkit(fontkit);

  const { bytes: fb, error: fontErr } = await loadFonts();
  let f: Fonts;
  let warning: string | null = null;
  if (!fb) {
    warning = `font_load_failed: ${fontErr}`;
    const hel = await pdf.embedFont(StandardFonts.Helvetica);
    const helBold = await pdf.embedFont(StandardFonts.HelveticaBold);
    const helItalic = await pdf.embedFont(StandardFonts.HelveticaOblique);
    f = { cgReg: hel, cgSemi: helBold, cgItalic: helItalic, interReg: hel, interSemi: helBold, allura: helItalic };
  } else {
    f = {
      cgReg: await pdf.embedFont(fb.cgRegular, { subset: true }),
      cgSemi: await pdf.embedFont(fb.cgSemi, { subset: true }),
      cgItalic: await pdf.embedFont(fb.cgItalic, { subset: true }),
      interReg: await pdf.embedFont(fb.interReg, { subset: true }),
      interSemi: await pdf.embedFont(fb.interSemi, { subset: true }),
      allura: await pdf.embedFont(fb.allura, { subset: false }),
    };
  }

  const pages: PDFPage[] = [];
  let page = pdf.addPage([PAGE_W, PAGE_H]);
  pages.push(page);
  let y = drawLetterhead(page, f, branding);

  const newPage = () => {
    page = pdf.addPage([PAGE_W, PAGE_H]);
    pages.push(page);
    y = drawLetterhead(page, f, branding);
  };

  const ensure = (need: number) => {
    if (y - need < M_BOT + 20) newPage();
  };

  // Title block
  ensure(80);
  const titleLines = wrap(data.title, f.cgSemi, 16, CONTENT_W);
  let ty = y;
  for (const line of titleLines) {
    page.drawText(line, { x: M_SIDE, y: ty - 18, font: f.cgSemi, size: 16, color: NAVY });
    ty -= 22;
  }
  y = ty - 8;

  // Reference + signer
  page.drawText(`Reference: ${data.reference}`, { x: M_SIDE, y, font: f.interReg, size: 9, color: MUTED });
  const sn = `Signer: ${data.signer_name}`;
  const snW = f.interReg.widthOfTextAtSize(sn, 9);
  page.drawText(sn, { x: PAGE_W - M_SIDE - snW, y, font: f.interReg, size: 9, color: MUTED });
  y -= 18;
  page.drawLine({ start: { x: M_SIDE, y }, end: { x: M_SIDE + CONTENT_W, y }, thickness: 1, color: HAIRLINE });
  y -= 18;

  // Body — streaming wrap() + ensure() (auto-paginates; never overlaps signature)
  const bodyLines = wrap(data.body_text, f.interReg, 10.5, CONTENT_W);
  for (const line of bodyLines) {
    ensure(16);
    page.drawText(line, { x: M_SIDE, y, font: f.interReg, size: 10.5, color: INK });
    y -= 15;
  }
  y -= 14;

  // Manager signature block (Allura) — reserve room so it stays with signer block.
  const MGR_HEIGHT = 90;
  const SIG_HEIGHT = 130;
  if (y - (MGR_HEIGHT + SIG_HEIGHT) < M_BOT + 20) newPage();

  const managerName = (data.manager_name || "").trim() || "Cathy Anderson";
  page.drawText(managerName, { x: M_SIDE, y: y - 22, font: f.allura, size: 28, color: NAVY });
  y -= 30;
  page.drawLine({ start: { x: M_SIDE, y }, end: { x: M_SIDE + 200, y }, thickness: 1, color: NAVY });
  y -= 12;
  page.drawText(managerName, { x: M_SIDE, y, font: f.interSemi, size: 10, color: INK });
  y -= 12;
  const mgrTitle = branding
    ? `Authorized Signatory, ${branding.companyName.trim() || "Company"}`
    : "Hiring Director, Expert Intuitive Advisor Inc.";
  page.drawText(mgrTitle, { x: M_SIDE, y, font: f.interReg, size: 9, color: MUTED });
  y -= 11;
  page.drawText(`Date Issued: ${formatShortDate(new Date())}`, { x: M_SIDE, y, font: f.interReg, size: 9, color: MUTED });
  y -= 28;

  // SignFlow signer block (kept from nda-pdf). Ensure it fits on this page.
  if (y - SIG_HEIGHT < M_BOT + 20) newPage();

  const sigTop = y;
  page.drawLine({ start: { x: M_SIDE, y: sigTop }, end: { x: M_SIDE + CONTENT_W, y: sigTop }, thickness: 1, color: HAIRLINE });
  page.drawText("SIGNATURE", { x: M_SIDE, y: sigTop - 14, font: f.interSemi, size: 9, color: NAVY, characterSpacing: 2 });

  const fieldTop = sigTop - 28;
  const fieldH = 60;
  page.drawRectangle({
    x: M_SIDE, y: fieldTop - fieldH, width: 240, height: fieldH,
    borderColor: HAIRLINE, borderWidth: 0.5,
  });
  page.drawText("Signer Signature", { x: M_SIDE, y: fieldTop - fieldH - 12, font: f.interReg, size: 8, color: MUTED });

  const col2x = M_SIDE + 270;
  page.drawText("Signer Name", { x: col2x, y: sigTop - 14, font: f.interSemi, size: 9, color: NAVY, characterSpacing: 1 });
  page.drawText(data.signer_name, { x: col2x, y: sigTop - 32, font: f.interReg, size: 11, color: INK });
  page.drawLine({ start: { x: col2x, y: sigTop - 38 }, end: { x: col2x + 180, y: sigTop - 38 }, thickness: 0.5, color: HAIRLINE });

  page.drawText("Date", { x: col2x, y: sigTop - 56, font: f.interSemi, size: 9, color: NAVY, characterSpacing: 1 });
  page.drawLine({ start: { x: col2x, y: sigTop - 80 }, end: { x: col2x + 180, y: sigTop - 80 }, thickness: 0.5, color: HAIRLINE });

  const total = pages.length;
  pages.forEach((p, i) => drawFooter(p, f, i + 1, total, branding));

  const bytes = await pdf.save();
  return { bytes, pageCount: total, warning, signatureRect: { page: total, x: M_SIDE, fieldTop, width: 240, height: fieldH } };
}
