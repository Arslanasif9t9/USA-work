// set-curated-slots: HR-authenticated. Writes curated_slot_ids to a rebook_token.
// Pass slot_ids: string[] | null. null/empty clears curation (full availability).
import { adminClient, corsHeaders, json, requireHr } from "../_shared/hr-auth.ts";

const UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });
  const ident = await requireHr(req);
  if (ident instanceof Response) return ident;
  if (!ident.hrId) return json({ error: "no_hr_profile" }, 403);

  const { token, slot_ids } = await req.json().catch(() => ({}));
  if (!token || typeof token !== "string") return json({ error: "missing_token" }, 400);

  let curated: string[] | null = null;
  if (Array.isArray(slot_ids) && slot_ids.length > 0) {
    if (!slot_ids.every((s: unknown) => typeof s === "string" && UUID_RE.test(s as string))) {
      return json({ error: "invalid_slot_ids" }, 400);
    }
    curated = Array.from(new Set(slot_ids as string[]));
  }

  const admin = adminClient();
  const { data, error } = await admin
    .from("rebook_tokens")
    .update({ curated_slot_ids: curated })
    .eq("token", token)
    .select("id")
    .maybeSingle();
  if (error) return json({ error: error.message }, 500);
  if (!data) return json({ error: "token_not_found" }, 404);

  return json({ success: true, count: curated?.length ?? 0 });
});
