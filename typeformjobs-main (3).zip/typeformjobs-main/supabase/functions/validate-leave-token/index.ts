// validate-leave-token: PUBLIC (no JWT). Mirrors validate-onboarding-token style.
// Looks up leave_requests by token. Does NOT mark used (only submit does).
import { createClient } from "npm:@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
const SERVICE = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;

const json = (b: unknown, s = 200) =>
  new Response(JSON.stringify(b), { status: s, headers: { ...corsHeaders, "Content-Type": "application/json" } });

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });
  try {
    const { token } = await req.json();
    if (!token || typeof token !== "string") return json({ valid: false, reason: "missing_token" }, 400);

    const admin = createClient(SUPABASE_URL, SERVICE);

    const { data: row } = await admin
      .from("leave_requests")
      .select("id, external_reference, signer_name, signer_email, response_id, status, token_used_at, token_expires_at")
      .eq("token", token)
      .maybeSingle();

    if (!row) return json({ valid: false, reason: "not_found" });
    if (row.token_used_at) return json({ valid: false, reason: "used" });
    if (new Date(row.token_expires_at as string) < new Date()) return json({ valid: false, reason: "expired" });
    if (row.status !== "invited") return json({ valid: false, reason: "used" });

    return json({
      valid: true,
      external_reference: row.external_reference,
      signer_name: row.signer_name,
      signer_email: row.signer_email,
      response_id: row.response_id,
    });
  } catch (e: any) {
    return json({ valid: false, reason: "internal", detail: String(e?.message || e) }, 500);
  }
});
