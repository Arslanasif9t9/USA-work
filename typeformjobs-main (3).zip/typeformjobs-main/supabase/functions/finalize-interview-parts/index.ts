// finalize-interview-parts: PUBLIC. Validates a rebook_token, then concatenates the
// live part objects (interviews/{response_id}/{call_id}/partNNN.webm) into the final
// object interviews/{response_id}/{call_id}.webm via the shared r2-finalize core.
//
// If NO parts exist, returns { ok: false, parts_found: 0 } so the client falls back
// to the single-blob whole-object PUT (no regression). Concat logic is shared with
// reap-orphaned-interview-videos and lives in ../_shared/r2-finalize.ts.
import { createClient } from "npm:@supabase/supabase-js@2";
import { finalizePartsForCall } from "../_shared/r2-finalize.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
const SERVICE = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;

const json = (b: unknown, s = 200) =>
  new Response(JSON.stringify(b), { status: s, headers: { ...corsHeaders, "Content-Type": "application/json" } });

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });
  try {
    const { token, retell_call_id } = await req.json();
    if (!token) return json({ error: "missing_token" }, 400);
    if (!retell_call_id) return json({ error: "missing_retell_call_id" }, 400);

    const admin = createClient(SUPABASE_URL, SERVICE);
    const { data: tok } = await admin.from("rebook_tokens").select("*").eq("token", token).maybeSingle();
    if (!tok) return json({ error: "invalid_token" }, 401);
    if (tok.used_at) return json({ error: "token_used" }, 401);
    if (new Date(tok.expires_at) <= new Date()) return json({ error: "token_expired" }, 401);

    const result = await finalizePartsForCall(tok.response_id, retell_call_id);
    return json(result, 200);
  } catch (e: any) {
    console.error("[finalize-interview-parts] exception:", e);
    return json({ ok: false, error: String(e?.message || e) }, 500);
  }
});
