import { adminClient, corsHeaders, json, requireHr } from "../_shared/hr-auth.ts";

const BOSS_PASSWORD = "Boss2828";
const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
const SERVICE_KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });
  const ident = await requireHr(req);
  if (ident instanceof Response) return ident;
  if (!ident.hrId) return json({ error: "no_hr_profile" }, 403);

  const { slot_id, password, reason } = await req.json().catch(() => ({}));
  if (!slot_id || !password) return json({ error: "missing_input" }, 400);
  if (password !== BOSS_PASSWORD) return json({ error: "invalid_password" }, 403);

  const admin = adminClient();
  const { error } = await admin
    .from("interview_slots")
    .update({
      completed_at: new Date().toISOString(),
      completion_method: "boss_override",
      notes: reason ? String(reason).slice(0, 5000) : null,
    })
    .eq("id", slot_id);
  if (error) return json({ error: error.message }, 500);

  const ip = req.headers.get("x-forwarded-for") || "";
  await admin.from("password_audit_log").insert({
    hr_user_id: ident.hrId,
    password_used: "Boss2828",
    action_taken: `Force-completed slot (reason: ${reason || "n/a"})`,
    target_resource_id: slot_id,
    ip_address: ip,
  });

  fetch(`${SUPABASE_URL}/functions/v1/send-override-audit-email`, {
    method: "POST",
    headers: { Authorization: `Bearer ${SERVICE_KEY}`, "Content-Type": "application/json" },
    body: JSON.stringify({
      action: "force_complete",
      hr_email: ident.email,
      hr_name: ident.displayName,
      slot_id,
      reason,
    }),
  }).catch(() => {});

  return json({ success: true });
});
