// signflow-webhook-receiver: receives signature events from SignFlow.
// Auth: Bearer SIGNFLOW_API_KEY. Updates job_offers + candidate_actions on signed.
//
// Piece 6 Part A — on every "signed" branch we additionally:
//   1) Archive the signed PDF to our private `signed-archive` bucket BEFORE
//      SignFlow's 7-day purge runs, and store the path on archived_pdf_url.
//   2) Send always-on backup to the Outlook main_backup_email.
//   3) If hr_copy_requested on the record is true, also send to Gmail.
// All three steps are best-effort: failures must NOT roll back the signed update.

import { createClient } from "npm:@supabase/supabase-js@2";
import { archiveSignedPdf, sendCompletionBackups, type DocType } from "../_shared/archive-and-backup.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

const json = (b: unknown, status = 200) =>
  new Response(JSON.stringify(b), {
    status,
    headers: { ...corsHeaders, "content-type": "application/json" },
  });

// Best-effort archive + backup wrapper used by every signed branch.
async function archiveAndNotify(opts: {
  admin: ReturnType<typeof createClient>;
  doc_type: DocType;
  table: "job_offers" | "nda_signatures" | "circular_signatures";
  recordId: string;
  external_reference: string;
  signer_name: string;
  signer_email: string | null;
  signed_pdf_url: string | null;
  hr_copy_requested: boolean;
  hr_copy_email_override: string | null;
  job_offer_id?: string | null;
  candidate_id?: string | null;
  extras?: Array<[string, string]>;
}) {
  if (!opts.signed_pdf_url) {
    console.warn("[archiveAndNotify] no signed_pdf_url — skipping archive+backup", {
      doc_type: opts.doc_type, ref: opts.external_reference,
    });
    return;
  }
  // 1) Archive
  const arch = await archiveSignedPdf({
    admin: opts.admin,
    doc_type: opts.doc_type,
    external_reference: opts.external_reference,
    source_pdf_url: opts.signed_pdf_url,
  });
  if (arch.ok && arch.storage_path) {
    try {
      await opts.admin.from(opts.table)
        .update({ archived_pdf_url: arch.storage_path })
        .eq("id", opts.recordId);
    } catch (e) {
      console.warn("[archiveAndNotify] update archived_pdf_url failed", { e: (e as Error).message });
    }
  } else {
    console.warn("[archiveAndNotify] archive failed", { reason: arch.reason });
  }
  // 2 & 3) Backups
  const backup = await sendCompletionBackups({
    admin: opts.admin,
    doc_type: opts.doc_type,
    recipient_name: opts.signer_name || opts.signer_email || "(unknown)",
    external_reference: opts.external_reference,
    pdf_bytes: arch.bytes ?? null,
    source_pdf_url: opts.signed_pdf_url,
    extras: opts.extras,
    hr_copy_requested: !!opts.hr_copy_requested,
    hr_copy_email_override: opts.hr_copy_email_override,
    job_offer_id: opts.job_offer_id ?? null,
    candidate_id: opts.candidate_id ?? null,
  });
  // Stamp timestamps best-effort
  try {
    const patch: Record<string, unknown> = {};
    if (backup.hr_copy_sent) patch.hr_copy_sent_at = new Date().toISOString();
    if (Object.keys(patch).length) {
      await opts.admin.from(opts.table).update(patch).eq("id", opts.recordId);
    }
  } catch (_) { /* swallow */ }
  console.log("[archiveAndNotify]", {
    doc_type: opts.doc_type, ref: opts.external_reference,
    archived: arch.ok, archive_path: arch.storage_path, archive_reason: arch.reason,
    main_backup_sent: backup.main_backup_sent, main_backup_to: backup.main_backup_to,
    hr_copy_sent: backup.hr_copy_sent, hr_copy_to: backup.hr_copy_to,
  });
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });
  if (req.method !== "POST") return json({ error: "method_not_allowed", code: "method_not_allowed" }, 405);

  const auth = req.headers.get("Authorization") || "";
  if (!auth.startsWith("Bearer ")) {
    return json({ error: "Missing authorization", code: "missing_auth" }, 401);
  }
  const apiKey = Deno.env.get("SIGNFLOW_API_KEY");
  if (!apiKey) return json({ error: "server_misconfigured", code: "no_secret" }, 500);
  const provided = auth.slice("Bearer ".length).trim();
  if (provided !== apiKey) {
    return json({ error: "Invalid API key", code: "invalid_api_key" }, 403);
  }

  let body: any;
  try { body = await req.json(); } catch { return json({ error: "invalid_json", code: "invalid_json" }, 400); }

  const { event, sign_request_id, external_offer_reference, status, signed_at, signed_pdf_url } = body || {};
  const errs: string[] = [];
  if (event !== "signature_completed") errs.push("event must be 'signature_completed'");
  if (!sign_request_id) errs.push("sign_request_id required");
  if (!external_offer_reference) errs.push("external_offer_reference required");
  if (!status) errs.push("status required");
  if (errs.length) return json({ error: "invalid_payload", code: "invalid_payload", details: errs }, 400);

  const logBase = {
    ts: new Date().toISOString(),
    event,
    external_offer_reference,
    status,
  };

  if (status !== "signed") {
    console.log(JSON.stringify({ ...logBase, action: "ignored" }));
    return json({ ignored: true, reason: "non-signed status" }, 200);
  }

  const admin = createClient(
    Deno.env.get("SUPABASE_URL")!,
    Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!,
  );

  const computeSignedAt = (): string => {
    if (signed_at) {
      const d = new Date(signed_at);
      if (!isNaN(d.getTime())) return d.toISOString();
    }
    return new Date().toISOString();
  };

  // Map external_reference prefix → nda_signatures doc_type subtree.
  type Subtype = { prefix: string; doc_type: DocType; action: string };
  const ndaSubtypes: Subtype[] = [
    { prefix: "NDA-",  doc_type: "nda",          action: "nda_updated" },
    { prefix: "JNDA-", doc_type: "joining-nda",  action: "joining_nda_updated" },
    { prefix: "ENDA-", doc_type: "exit-nda",     action: "exit_nda_updated" },
    { prefix: "STL-",  doc_type: "settlement",   action: "settlement_updated" },
    { prefix: "DOC-",  doc_type: "custom-document", action: "custom_document_updated" },
  ];

  for (const st of ndaSubtypes) {
    if (typeof external_offer_reference !== "string" || !external_offer_reference.startsWith(st.prefix)) continue;
    const signedAtIso = computeSignedAt();
    const { data: row, error } = await admin
      .from("nda_signatures")
      .select("id, response_id, signer_name, signer_email, status, hr_copy_requested, hr_copy_email_override")
      .eq("external_reference", external_offer_reference)
      .maybeSingle();
    if (error) {
      console.error(JSON.stringify({ ...logBase, action: `${st.doc_type}_db_error`, err: error.message }));
      return json({ error: "db_error", code: "db_error" }, 500);
    }
    if (!row) {
      console.log(JSON.stringify({ ...logBase, action: `${st.doc_type}_not_found` }));
      return json({ error: `${st.doc_type} not found`, code: `${st.doc_type}_not_found` }, 404);
    }
    if ((row as any).status !== "signed") {
      const patch: Record<string, unknown> = { status: "signed", signed_at: signedAtIso };
      if (signed_pdf_url && typeof signed_pdf_url === "string") patch.signed_pdf_url = signed_pdf_url;
      const { error: updErr } = await admin.from("nda_signatures").update(patch).eq("id", (row as any).id);
      if (updErr) {
        console.error(JSON.stringify({ ...logBase, action: `${st.doc_type}_update_failed`, err: updErr.message }));
        return json({ error: `${st.doc_type}_update_failed`, code: `${st.doc_type}_update_failed` }, 500);
      }
    }

    // NDA-only: best-effort equipment instructions email
    if (st.prefix === "NDA-" && (row as any).response_id) {
      try {
        await fetch(
          `${Deno.env.get("SUPABASE_URL")}/functions/v1/send-onboarding-equipment-instructions`,
          {
            method: "POST",
            headers: {
              Authorization: `Bearer ${Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")}`,
              "Content-Type": "application/json",
            },
            body: JSON.stringify({ response_id: (row as any).response_id }),
          },
        );
      } catch (e) {
        console.warn(JSON.stringify({ ...logBase, action: "equipment_email_exception", err: (e as Error).message }));
      }
    }

    // === Archive + backups ===
    try {
      await archiveAndNotify({
        admin,
        doc_type: st.doc_type,
        table: "nda_signatures",
        recordId: (row as any).id,
        external_reference: external_offer_reference,
        signer_name: (row as any).signer_name || "",
        signer_email: (row as any).signer_email || null,
        signed_pdf_url: (signed_pdf_url as string) || null,
        hr_copy_requested: !!(row as any).hr_copy_requested,
        hr_copy_email_override: (row as any).hr_copy_email_override || null,
        extras: [["Signed at", signedAtIso]],
      });
    } catch (e) {
      console.warn(JSON.stringify({ ...logBase, action: "archive_backup_warn", err: (e as Error).message }));
    }

    console.log(JSON.stringify({ ...logBase, action: st.action }));
    return json({ success: true, type: st.doc_type, external_reference: external_offer_reference, signed_at: signedAtIso }, 200);
  }

  // ---------- Circular Notice branch (CIRC-) ----------
  // ADDITIVE: routes circular completions through the SAME archiveAndNotify /
  // sendCompletionBackups path as the other doc types. Never touches NDA/offer logic.
  if (typeof external_offer_reference === "string" && external_offer_reference.startsWith("CIRC-")) {
    const signedAtIso = computeSignedAt();
    const { data: cRow, error: cErr } = await admin
      .from("circular_signatures")
      .select("id, circular_id, signer_name, signer_email, status, understanding_text, hr_copy_requested, hr_copy_email_override")
      .eq("reference", external_offer_reference)
      .maybeSingle();
    if (cErr) {
      console.error(JSON.stringify({ ...logBase, action: "circular_db_error", err: cErr.message }));
      return json({ error: "db_error", code: "db_error" }, 500);
    }
    if (!cRow) {
      console.log(JSON.stringify({ ...logBase, action: "circular_not_found" }));
      return json({ error: "circular not found", code: "circular_not_found" }, 404);
    }

    // Single-row write by id; never wipe understanding_text.
    if ((cRow as any).status !== "signed") {
      const patch: Record<string, unknown> = { status: "signed", signed_at: signedAtIso };
      if (signed_pdf_url && typeof signed_pdf_url === "string") {
        patch.signed_pdf_url = signed_pdf_url;
        patch.archived_pdf_url = signed_pdf_url;
      }
      const { error: updErr } = await admin
        .from("circular_signatures").update(patch).eq("id", (cRow as any).id);
      if (updErr) {
        console.error(JSON.stringify({ ...logBase, action: "circular_update_failed", err: updErr.message }));
        return json({ error: "circular_update_failed", code: "circular_update_failed" }, 500);
      }
    }

    // Read-after-write verify (single row by id).
    const { data: verify } = await admin
      .from("circular_signatures")
      .select("id, status, signed_at, signed_pdf_url, understanding_text")
      .eq("id", (cRow as any).id)
      .maybeSingle();

    // Look up the circular title (best-effort) for the email subject/label.
    let circularTitle = "Circular Notice";
    if ((cRow as any).circular_id) {
      const { data: circ } = await admin
        .from("circulars").select("title").eq("id", (cRow as any).circular_id).maybeSingle();
      if ((circ as any)?.title) circularTitle = (circ as any).title;
    }

    // === Archive + backups: SAME helper as the other doc types ===
    try {
      await archiveAndNotify({
        admin,
        doc_type: "circular",
        table: "circular_signatures",
        recordId: (cRow as any).id,
        external_reference: external_offer_reference,
        signer_name: (cRow as any).signer_name || "",
        signer_email: (cRow as any).signer_email || null,
        signed_pdf_url: (signed_pdf_url as string) || null,
        hr_copy_requested: !!(cRow as any).hr_copy_requested,
        hr_copy_email_override: (cRow as any).hr_copy_email_override || null,
        extras: [["Circular", circularTitle], ["Signed at", signedAtIso]],
      });
    } catch (e) {
      console.warn(JSON.stringify({ ...logBase, action: "archive_backup_warn", err: (e as Error).message }));
    }

    console.log(JSON.stringify({ ...logBase, action: "circular_updated", title: circularTitle }));
    return json({
      success: true,
      type: "circular",
      external_reference: external_offer_reference,
      signed_at: (verify as any)?.signed_at || signedAtIso,
      understanding_preserved: typeof (verify as any)?.understanding_text === "string",
    }, 200);
  }



  // ---------- Offer branch (default) ----------
  const { data: offer, error: offerErr } = await admin
    .from("job_offers")
    .select("id, status, signed_at, candidate_id, candidate_name, form_id, candidate_email, hr_copy_requested, hr_copy_email_override")
    .eq("offer_reference_id", external_offer_reference)
    .maybeSingle();
  if (offerErr) {
    console.error(JSON.stringify({ ...logBase, action: "db_error", err: offerErr.message }));
    return json({ error: "db_error", code: "db_error" }, 500);
  }
  if (!offer) {
    console.log(JSON.stringify({ ...logBase, action: "not_found" }));
    return json({ error: "Offer not found", code: "offer_not_found" }, 404);
  }

  const signedAtIso = (() => {
    if (signed_at) {
      const d = new Date(signed_at);
      if (!isNaN(d.getTime())) return d.toISOString();
    }
    return (offer as any).signed_at || new Date().toISOString();
  })();

  const updatePatch: Record<string, unknown> = { status: "signed", signed_at: signedAtIso };
  if (signed_pdf_url && typeof signed_pdf_url === "string") {
    updatePatch.signed_pdf_url = signed_pdf_url;
  }
  const { error: updErr } = await admin
    .from("job_offers")
    .update(updatePatch)
    .eq("id", (offer as any).id);
  if (updErr) {
    console.error(JSON.stringify({ ...logBase, action: "offer_update_failed", err: updErr.message }));
    return json({ error: "offer_update_failed", code: "offer_update_failed" }, 500);
  }

  let { data: caRows, error: caReadErr } = await admin
    .from("candidate_actions")
    .select("id, response_id")
    .eq("job_offer_id", (offer as any).id);
  if ((!caRows || caRows.length === 0) && (offer as any).candidate_id) {
    const byCandidate = await admin
      .from("candidate_actions")
      .select("id, response_id")
      .eq("candidate_id", (offer as any).candidate_id)
      .eq("form_id", (offer as any).form_id)
      .order("created_at", { ascending: false })
      .limit(1);
    caRows = byCandidate.data || [];
    caReadErr = byCandidate.error;
  }
  if ((!caRows || caRows.length === 0) && (offer as any).candidate_email) {
    const { data: responsesByOverride } = await admin
      .from("responses")
      .select("id")
      .eq("form_id", (offer as any).form_id)
      .ilike("override_email", (offer as any).candidate_email)
      .limit(5);
    let respIds = (responsesByOverride || []).map((r: any) => r.id).filter(Boolean) as string[];
    if (respIds.length === 0) {
      const { data: answerRows } = await admin
        .from("answers")
        .select("response_id")
        .ilike("answer_text", (offer as any).candidate_email)
        .limit(10);
      respIds = (answerRows || []).map((a: any) => a.response_id).filter(Boolean) as string[];
    }
    if (respIds.length) {
      const byResponse = await admin
        .from("candidate_actions")
        .select("id, response_id")
        .in("response_id", respIds)
        .eq("form_id", (offer as any).form_id)
        .order("created_at", { ascending: false })
        .limit(1);
      caRows = byResponse.data || [];
      caReadErr = byResponse.error;
    }
  }

  let caErr = caReadErr;
  let count = caRows?.length ?? 0;
  const caIds = (caRows || []).map((r: any) => r.id).filter(Boolean) as string[];
  if (!caErr && caIds.length) {
    const updated = await admin
      .from("candidate_actions")
      .update({
        job_offer_id: (offer as any).id,
        offer_status: "signed",
        offer_signed_at: signedAtIso,
        updated_at: new Date().toISOString(),
      }, { count: "exact" })
      .in("id", caIds)
      .select("response_id");
    caErr = updated.error;
    count = updated.count ?? caIds.length;
    caRows = updated.data || caRows;
  }

  if (caErr) {
    console.warn(JSON.stringify({ ...logBase, action: "ca_update_warn", err: caErr.message }));
  }

  const respIds = (caRows || []).map((r: any) => r.response_id).filter(Boolean) as string[];
  for (const rid of respIds) {
    const { error: rErr } = await admin
      .from("responses")
      .update({ round_stage: "offer_signed" })
      .eq("id", rid);
    if (rErr) console.warn(JSON.stringify({ ...logBase, action: "resp_stage_update_warn", rid, err: rErr.message }));

    // Offer signing timing: whole hours from offer_sent_at → now. Single-row by id.
    // First-completion wins (never overwrite a non-null value). Skip if offer_sent_at
    // is null or offer_signed_hours already set. Fully wrapped — never breaks the webhook.
    try {
      const { data: oRow } = await admin
        .from("responses")
        .select("id, offer_sent_at, offer_signed_hours")
        .eq("id", rid)
        .maybeSingle();
      const offSentAt = (oRow as any)?.offer_sent_at as string | null | undefined;
      const existingOffHours = (oRow as any)?.offer_signed_hours;
      if (oRow && offSentAt && existingOffHours == null) {
        const elapsedOffMs = Date.parse(signedAtIso) - Date.parse(offSentAt);
        if (Number.isFinite(elapsedOffMs) && elapsedOffMs >= 0) {
          const offHours = Math.floor(elapsedOffMs / (1000 * 60 * 60));
          const { error: ohErr } = await admin
            .from("responses")
            .update({ offer_signed_hours: offHours })
            .eq("id", rid);
          if (ohErr) console.warn(JSON.stringify({ ...logBase, action: "offer_signed_hours_warn", rid, err: ohErr.message }));
          else console.log(JSON.stringify({ ...logBase, action: "offer_signed_hours_set", rid, hours: offHours }));
        }
      }
    } catch (ohCatch) {
      console.warn(JSON.stringify({ ...logBase, action: "offer_signed_hours_threw", rid, err: (ohCatch as Error).message }));
    }
  }

  // === Archive + backups (offer) ===
  try {
    await archiveAndNotify({
      admin,
      doc_type: "offer",
      table: "job_offers",
      recordId: (offer as any).id,
      external_reference: external_offer_reference,
      signer_name: (offer as any).candidate_name || "",
      signer_email: (offer as any).candidate_email || null,
      signed_pdf_url: (signed_pdf_url as string) || null,
      hr_copy_requested: !!(offer as any).hr_copy_requested,
      hr_copy_email_override: (offer as any).hr_copy_email_override || null,
      job_offer_id: (offer as any).id,
      candidate_id: (offer as any).candidate_id || null,
      extras: [["Signed at", signedAtIso]],
    });
  } catch (e) {
    console.warn(JSON.stringify({ ...logBase, action: "archive_backup_warn", err: (e as Error).message }));
  }

  console.log(JSON.stringify({ ...logBase, action: "updated", ca_rows: count ?? 0 }));

  return json({
    success: true,
    offer_reference: external_offer_reference,
    candidate_actions_updated: !caErr,
    signed_at: signedAtIso,
  }, 200);
});
