// One-shot: resets passwords for hr1@expert.com and hr2@expert.com from secrets.
// Delete after use. No auth gate — single invocation, secrets-only inputs.
import { createClient } from "npm:@supabase/supabase-js@2";

const cors = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: cors });
  const admin = createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!);
  const targets = [
    { email: "hr1@expert.com", pw: Deno.env.get("HR1_NEW_PW_ONCE") || "" },
    { email: "hr2@expert.com", pw: Deno.env.get("HR2_NEW_PW_ONCE") || "" },
  ];
  const results: any[] = [];
  const { data: list, error: listErr } = await admin.auth.admin.listUsers({ perPage: 1000 });
  if (listErr) return new Response(JSON.stringify({ error: listErr.message }), { status: 500, headers: { ...cors, "Content-Type": "application/json" } });
  for (const t of targets) {
    if (!t.pw || t.pw.length < 8) { results.push({ email: t.email, ok: false, error: "missing_or_short_password" }); continue; }
    const u = list?.users?.find((x: any) => (x.email || "").toLowerCase() === t.email);
    if (!u) { results.push({ email: t.email, ok: false, error: "user_not_found" }); continue; }
    const { error: updErr } = await admin.auth.admin.updateUserById(u.id, { password: t.pw });
    results.push({ email: t.email, ok: !updErr, error: updErr?.message });
  }
  return new Response(JSON.stringify({ results }), { headers: { ...cors, "Content-Type": "application/json" } });
});
