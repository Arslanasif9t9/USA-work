// rebook-confirm: validates rebook token, books the slot for the candidate's response,
// marks token used, and — for round1/round2 invites — auto-claims the slot to the
// inviting HR and mirrors the Zoom meeting into candidate_actions.
import { createClient } from "npm:@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};
const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
const SERVICE = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
const json = (b: unknown, s = 200) =>
  new Response(JSON.stringify(b), { status: s, headers: { ...corsHeaders, "Content-Type": "application/json" } });

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });
  try {
    const { token, slot_id } = await req.json();
    if (!token || !slot_id) return json({ error: "missing_fields" }, 400);
    const admin = createClient(SUPABASE_URL, SERVICE);

    const { data: tok } = await admin.from("rebook_tokens").select("*").eq("token", token).maybeSingle();
    if (!tok) return json({ error: "invalid_token" }, 404);
    if (tok.used_at) return json({ error: "token_used" }, 410);
    if (new Date(tok.expires_at) < new Date()) return json({ error: "token_expired" }, 410);

    // Book via book-slot
    const bookRes = await fetch(`${SUPABASE_URL}/functions/v1/book-slot`, {
      method: "POST",
      headers: { "Content-Type": "application/json", Authorization: `Bearer ${SERVICE}` },
      body: JSON.stringify({
        slot_id,
        response_id: tok.response_id,
        candidate_name: tok.candidate_name,
        candidate_email: tok.candidate_email,
        assigned_hr_id: tok.assigned_hr_id ?? null,
      }),
    });
    const bookData = await bookRes.json().catch(() => ({}));
    if (!bookRes.ok) return json({ error: "book_failed", details: bookData }, bookRes.status);

    await admin.from("rebook_tokens").update({
      used_at: new Date().toISOString(),
      new_slot_id: slot_id,
    }).eq("id", tok.id);

    const stage = tok.stage || "reschedule";
    if ((stage === "round1" || stage === "round2") && tok.response_id) {
      // Auto-claim the slot to the inviting HR (only if still unclaimed).
      if (tok.assigned_hr_id) {
        await admin.from("interview_slots").update({
          claimed_by_hr_id: tok.assigned_hr_id,
          claimed_at: new Date().toISOString(),
        }).eq("id", slot_id).is("claimed_by_hr_id", null);
      }

      // Mirror Zoom meeting + appointment into candidate_actions for this round.
      const { data: slot } = await admin.from("interview_slots")
        .select("zoom_meeting_id, slot_start").eq("id", slot_id).maybeSingle();
      let joinUrl: string | null = null;
      if (slot?.zoom_meeting_id) {
        const { data: zm } = await admin.from("zoom_meetings")
          .select("join_url").eq("id", slot.zoom_meeting_id).maybeSingle();
        joinUrl = zm?.join_url || null;
      }
      const { data: actRow } = await admin.from("candidate_actions")
        .select("id").eq("response_id", tok.response_id).maybeSingle();
      if (actRow) {
        const round = stage === "round1" ? 1 : 2;
        await admin.from("candidate_actions").update({
          [`round${round}_appointment_date`]: slot?.slot_start ?? null,
          [`round${round}_zoom_meeting_id`]: slot?.zoom_meeting_id ?? null,
          [`round${round}_zoom_join_url`]: joinUrl,
        }).eq("id", actRow.id);
      }
    }

    return json({ success: true, booking: bookData, stage });
  } catch (e: any) {
    return json({ error: "internal", details: String(e?.message || e) }, 500);
  }
});
