// generate-joining-nda-pdf: admin/HR-only. Builds the EIA Joining NDA (NDA 1)
// PDF and uploads it to the public `offer-letters` bucket under joining-nda/.
import { createClient } from "npm:@supabase/supabase-js@2";
import { buildJoiningNdaPdf } from "../_shared/joining-nda-pdf.ts";
import { uploadPdf } from "../_shared/offer-pdf.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

const json = (b: unknown, status = 200) =>
  new Response(JSON.stringify(b), {
    status,
    headers: { ...corsHeaders, "content-type": "application/json" },
  });

async function requireAdmin(req: Request): Promise<Response | null> {
  const auth = req.headers.get("Authorization") || "";
  if (!auth.startsWith("Bearer ")) return json({ error: "missing_auth" }, 401);
  const userClient = createClient(
    Deno.env.get("SUPABASE_URL")!,
    Deno.env.get("SUPABASE_ANON_KEY")!,
    { global: { headers: { Authorization: auth } } },
  );
  const { data: u } = await userClient.auth.getUser();
  if (!u?.user) return json({ error: "invalid_jwt" }, 401);
  const admin = createClient(
    Deno.env.get("SUPABASE_URL")!,
    Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!,
  );
  const { data: row } = await admin
    .from("users").select("role").eq("id", u.user.id).maybeSingle();
  if (!row || row.role !== "admin") return json({ error: "forbidden" }, 403);
  return null;
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });
  const guard = await requireAdmin(req);
  if (guard) return guard;

  let body: { response_id?: string; signer_name?: string; signer_email?: string; reference?: string };
  try { body = await req.json(); } catch { return json({ error: "invalid_json" }, 400); }
  const { signer_name, reference } = body || {};
  if (!signer_name || !reference) {
    return json({ error: "missing_fields" }, 400);
  }

  let pdfBytes: Uint8Array;
  let warning: string | null = null;
  let pageCount = 0;
  let signatureRect: unknown = null;
  try {
    const out = await buildJoiningNdaPdf({ signer_name, reference });
    pdfBytes = out.bytes;
    warning = out.warning;
    pageCount = out.pageCount;
    signatureRect = out.signatureRect;
  } catch (e) {
    return json({ error: "pdf_build_failed", detail: (e as Error).message }, 500);
  }

  const lastName = signer_name.trim().split(/\s+/).slice(-1)[0]?.replace(/[^A-Za-z0-9_-]/g, "_") || "Candidate";
  const filename = `joining-nda/${reference}-${lastName}.pdf`;
  const up = await uploadPdf(pdfBytes, filename);
  if (!up.url) {
    return json({ error: "upload_failed", detail: up.error }, 500);
  }
  return json({
    success: true,
    pdf_url: up.url,
    filename,
    page_count: pageCount,
    signature_rect: signatureRect,
    font_warning: warning,
  });
});
