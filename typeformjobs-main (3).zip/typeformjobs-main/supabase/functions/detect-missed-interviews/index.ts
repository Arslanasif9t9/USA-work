// Cron-invoked (every 5 min): detect both-missed interviews, alert, AND
// auto-release past no-show slots back to 'available' so they don't squat
// availability for real candidates.
import { adminClient, corsHeaders } from "../_shared/hr-auth.ts";

const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
const SERVICE_KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
const RESEND_API_KEY = Deno.env.get("RESEND_API_KEY")!;
const LOVABLE_API_KEY = Deno.env.get("LOVABLE_API_KEY")!;
const GATEWAY_URL = "https://connector-gateway.lovable.dev/resend";
const ALERT_RECIPIENTS = ["talent.expertadvisor@outlook.com", "spark11179@gmail.com"];

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });
  const admin = adminClient();
  const cutoff = new Date(Date.now() - 60 * 60 * 1000).toISOString();

  // Both missed: slot ended >1h ago, never claimed, no completion.
  // AI-safe: only consider slots tied to a real human-Zoom booking
  // (zoom_meeting_id IS NOT NULL). AI-interview candidates have no
  // interview_slots row, but this guard also covers any future drift.
  const { data: missed } = await admin
    .from("interview_slots")
    .select("id, slot_start, zoom_meeting_id")
    .lt("slot_end", cutoff)
    .is("claimed_by_hr_id", null)
    .is("completed_at", null)
    .not("zoom_meeting_id", "is", null)
    .eq("status", "booked");

  let alerted = 0;
  for (const slot of missed || []) {
    // Check if already logged
    const { data: existing } = await admin
      .from("notification_log")
      .select("id")
      .eq("event_type", "both_missed_alert")
      .eq("related_resource_id", slot.id)
      .maybeSingle();
    if (existing) continue;

    const subject = `ALERT: Interview missed by both HRs (slot ${slot.id})`;
    const html = `<p><b>Neither HR claimed or attended this interview.</b></p>
<p>Slot: ${slot.id}<br/>Time: ${slot.slot_start}</p>
<p>Please review in the Booking Dashboard.</p>`;
    for (const to of ALERT_RECIPIENTS) {
      try {
        await fetch(`${GATEWAY_URL}/emails`, {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${LOVABLE_API_KEY}`,
            "X-Connection-Api-Key": RESEND_API_KEY,
          },
          body: JSON.stringify({
            from: "EIA Talent <talent@expertintuitiveadvisor.com>",
            to: [to], subject, html,
          }),
        });
        await admin.from("notification_log").insert({
          event_type: "both_missed_alert", recipient_email: to,
          related_resource_id: slot.id, status: "sent",
        });
      } catch (e) { console.error("alert error", e); }
    }
    alerted++;
  }

  // Auto-release past slots that were booked/reserved but the interview never
  // completed (no-show / squatting). Slot must have started >1h ago and not
  // be completed. Calls release-slot per slot (single-row by exact id).
  const { data: stale } = await admin
    .from("interview_slots")
    .select("id")
    .lt("slot_start", cutoff)
    .is("completed_at", null)
    .not("zoom_meeting_id", "is", null)
    .in("status", ["booked", "reserved"]);

  let released = 0;
  for (const s of stale || []) {
    try {
      const r = await fetch(`${SUPABASE_URL}/functions/v1/release-slot`, {
        method: "POST",
        headers: {
          Authorization: `Bearer ${SERVICE_KEY}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ slot_id: s.id, reason: "auto_released_no_show" }),
      });
      if (r.ok) released++;
    } catch (e) { console.error("release error", e); }
  }

  return new Response(JSON.stringify({ checked: missed?.length || 0, alerted, released }), {
    headers: { ...corsHeaders, "Content-Type": "application/json" },
  });
});
