// whatsapp-webhook-receiver: PUBLIC Meta WhatsApp Cloud API webhook endpoint.
// verify_jwt = false (Meta cannot send a JWT — see config.toml).
//
// GET  -> Meta verification handshake (hub.challenge).
// POST -> inbound messages + status updates, stored in public.whatsapp_messages.
//
// FULLY INDEPENDENT of the ElevenLabs Sylvia path — no imports from
// _shared/elevenlabs-sylvia.ts. Uses the service-role client for all writes.
import { createClient } from "npm:@supabase/supabase-js@2";

const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
const SERVICE_KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
const WHATSAPP_VERIFY_TOKEN = Deno.env.get("WHATSAPP_VERIFY_TOKEN") ?? "";
const WHATSAPP_ACCESS_TOKEN = Deno.env.get("WHATSAPP_ACCESS_TOKEN") ?? "";

const admin = () => createClient(SUPABASE_URL, SERVICE_KEY);

// Fetch the temporary downloadable URL for a media id from the Meta Graph API.
// Best-effort: returns { url, mime } or nulls on any failure (never throws).
async function fetchMediaUrl(
  mediaId: string,
): Promise<{ url: string | null; mime: string | null }> {
  try {
    if (!mediaId || !WHATSAPP_ACCESS_TOKEN) return { url: null, mime: null };
    const res = await fetch(`https://graph.facebook.com/v21.0/${mediaId}`, {
      headers: { Authorization: `Bearer ${WHATSAPP_ACCESS_TOKEN}` },
    });
    if (!res.ok) return { url: null, mime: null };
    const j = await res.json().catch(() => ({}));
    return { url: j?.url ?? null, mime: j?.mime_type ?? null };
  } catch (_e) {
    return { url: null, mime: null };
  }
}

// Map a mime type to a sensible file extension.
function extFromMime(mime: string | null): string {
  switch ((mime ?? "").split(";")[0].trim().toLowerCase()) {
    case "image/jpeg":
    case "image/jpg":
      return ".jpg";
    case "image/png":
      return ".png";
    case "image/webp":
      return ".webp";
    case "image/gif":
      return ".gif";
    case "application/pdf":
      return ".pdf";
    case "audio/ogg":
      return ".ogg";
    case "audio/mpeg":
    case "audio/mp3":
      return ".mp3";
    case "audio/amr":
      return ".amr";
    case "audio/aac":
      return ".aac";
    case "video/mp4":
      return ".mp4";
    case "video/3gpp":
      return ".3gp";
    case "application/msword":
      return ".doc";
    case "application/vnd.openxmlformats-officedocument.wordprocessingml.document":
      return ".docx";
    case "application/vnd.ms-excel":
      return ".xls";
    case "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet":
      return ".xlsx";
    case "text/plain":
      return ".txt";
    default:
      return ".bin";
  }
}

// Download the actual media bytes from Meta's temporary URL (requires the
// WhatsApp access token), upload them into the private candidate-files bucket,
// and return a long-lived (30-day) signed URL plus the resolved mime type.
// Best-effort: returns nulls on any failure (never throws).
async function downloadAndStoreMedia(
  supa: ReturnType<typeof admin>,
  tempUrl: string,
  mime: string | null,
  phone: string,
  mediaId: string,
): Promise<{ url: string | null; mime: string | null }> {
  try {
    if (!tempUrl || !WHATSAPP_ACCESS_TOKEN) return { url: null, mime };
    const res = await fetch(tempUrl, {
      headers: { Authorization: `Bearer ${WHATSAPP_ACCESS_TOKEN}` },
    });
    if (!res.ok) return { url: null, mime };
    const resolvedMime = mime ?? res.headers.get("content-type") ?? null;
    const bytes = new Uint8Array(await res.arrayBuffer());
    if (!bytes.byteLength) return { url: null, mime: resolvedMime };

    const safePhone = (phone || "unknown").replace(/[^0-9]/g, "") || "unknown";
    const ext = extFromMime(resolvedMime);
    const path = `whatsapp-inbound/${safePhone}/${Date.now()}-${mediaId}${ext}`;

    const { error: uploadErr } = await supa.storage
      .from("candidate-files")
      .upload(path, bytes, {
        contentType: resolvedMime ?? "application/octet-stream",
        upsert: true,
      });
    if (uploadErr) {
      console.error("[whatsapp-webhook-receiver] media upload error", uploadErr);
      return { url: null, mime: resolvedMime };
    }

    // 30-day signed URL (private bucket).
    const { data: signed, error: signErr } = await supa.storage
      .from("candidate-files")
      .createSignedUrl(path, 60 * 60 * 24 * 30);
    if (signErr || !signed?.signedUrl) {
      console.error("[whatsapp-webhook-receiver] media sign error", signErr);
      return { url: null, mime: resolvedMime };
    }
    return { url: signed.signedUrl, mime: resolvedMime };
  } catch (e) {
    console.error("[whatsapp-webhook-receiver] media download/store error", e);
    return { url: null, mime };
  }
}

Deno.serve(async (req) => {
  const url = new URL(req.url);

  // ── GET: Meta verification handshake ──
  if (req.method === "GET") {
    const mode = url.searchParams.get("hub.mode");
    const token = url.searchParams.get("hub.verify_token");
    const challenge = url.searchParams.get("hub.challenge") ?? "";
    if (mode === "subscribe" && token === WHATSAPP_VERIFY_TOKEN && WHATSAPP_VERIFY_TOKEN) {
      return new Response(challenge, {
        status: 200,
        headers: { "Content-Type": "text/plain" },
      });
    }
    return new Response("Forbidden", { status: 403 });
  }

  if (req.method !== "POST") {
    return new Response("Method Not Allowed", { status: 405 });
  }

  // ── POST: inbound events. Always ACK 200 quickly; do work defensively. ──
  let payload: any = {};
  try {
    payload = await req.json();
  } catch (_e) {
    return new Response(JSON.stringify({ ok: true }), {
      status: 200,
      headers: { "Content-Type": "application/json" },
    });
  }

  try {
    const supa = admin();
    const entries: any[] = Array.isArray(payload?.entry) ? payload.entry : [];

    for (const entry of entries) {
      const changes: any[] = Array.isArray(entry?.changes) ? entry.changes : [];
      for (const change of changes) {
        const value = change?.value ?? {};

        // Map phone -> contact display name from this change's contacts[].
        const contacts: any[] = Array.isArray(value?.contacts) ? value.contacts : [];
        const nameByWaId: Record<string, string> = {};
        for (const c of contacts) {
          const waId = c?.wa_id ?? "";
          const nm = c?.profile?.name ?? "";
          if (waId && nm) nameByWaId[waId] = nm;
        }
        const fallbackName = contacts[0]?.profile?.name ?? null;

        // ── Inbound messages ──
        const messages: any[] = Array.isArray(value?.messages) ? value.messages : [];
        for (const msg of messages) {
          try {
            const from: string = msg?.from ?? "";
            const waMessageId: string = msg?.id ?? "";
            const type: string = msg?.type ?? "unknown";
            if (!waMessageId) continue;

            let body: string | null = null;
            let mediaUrl: string | null = null;
            let mediaMime: string | null = null;

            if (type === "text") {
              body = msg?.text?.body ?? null;
            } else if (type === "image" || type === "document" || type === "audio" || type === "video") {
              const media = msg?.[type] ?? {};
              body = media?.caption ?? media?.filename ?? null;
              mediaMime = media?.mime_type ?? null;
              const mediaId = media?.id ?? "";
              if (mediaId) {
                // Best-effort: never block/fail the webhook on a slow media fetch.
                const fetched = await fetchMediaUrl(mediaId);
                if (!mediaMime) mediaMime = fetched.mime;
                // Download the bytes from Meta's temporary URL and re-upload to
                // our permanent private bucket, then store a 30-day signed URL.
                // This whole step is best-effort: failures fall back to null
                // media_url and never block the message from being saved.
                if (fetched.url) {
                  const stored = await downloadAndStoreMedia(
                    supa,
                    fetched.url,
                    mediaMime,
                    from,
                    mediaId,
                  );
                  mediaUrl = stored.url;
                  if (!mediaMime) mediaMime = stored.mime;
                }
              }
            } else {
              // interactive/button/location/etc — store raw, no body.
              body = null;
            }

            const contactName = nameByWaId[from] ?? fallbackName;

            // DEDUPE: wa_message_id is unique. on conflict do nothing.
            await supa
              .from("whatsapp_messages")
              .upsert(
                {
                  direction: "inbound",
                  wa_message_id: waMessageId,
                  phone: from,
                  contact_name: contactName,
                  type,
                  body,
                  media_url: mediaUrl,
                  media_mime: mediaMime,
                  status: "received",
                  raw: msg,
                },
                { onConflict: "wa_message_id", ignoreDuplicates: true },
              );
          } catch (e) {
            console.error("[whatsapp-webhook-receiver] message handling error", e);
          }
        }

        // ── Status updates (sent/delivered/read/failed) ──
        const statuses: any[] = Array.isArray(value?.statuses) ? value.statuses : [];
        for (const st of statuses) {
          try {
            const waMessageId: string = st?.id ?? "";
            const status: string = st?.status ?? "";
            if (!waMessageId || !status) continue;
            const stErrors = Array.isArray(st?.errors) ? st.errors : null;
            if (stErrors) {
              console.log(
                "[whatsapp-webhook-receiver] status",
                status,
                "errors",
                JSON.stringify(stErrors),
              );
            } else {
              console.log("[whatsapp-webhook-receiver] status", status, waMessageId);
            }
            if (stErrors) {
              // Persist the failure detail by merging into the existing raw column.
              const { data: existingRow } = await supa
                .from("whatsapp_messages")
                .select("raw")
                .eq("wa_message_id", waMessageId)
                .eq("direction", "outbound")
                .maybeSingle();
              const mergedRaw = {
                ...(existingRow?.raw && typeof existingRow.raw === "object" ? existingRow.raw : {}),
                status_error: stErrors,
              };
              await supa
                .from("whatsapp_messages")
                .update({ status, raw: mergedRaw })
                .eq("wa_message_id", waMessageId)
                .eq("direction", "outbound");
            } else {
              // Patch the matching outbound row; never error if not found.
              await supa
                .from("whatsapp_messages")
                .update({ status })
                .eq("wa_message_id", waMessageId)
                .eq("direction", "outbound");
            }
          } catch (e) {
            console.error("[whatsapp-webhook-receiver] status handling error", e);
          }
        }

      }
    }
  } catch (e) {
    console.error("[whatsapp-webhook-receiver] top-level error", e);
  }

  // Always acknowledge fast so Meta does not retry needlessly.
  return new Response(JSON.stringify({ ok: true }), {
    status: 200,
    headers: { "Content-Type": "application/json" },
  });
});
