// send-custom-message: HR-authenticated. Password-gated. Sends a one-off custom
// branded message (EIA HR) to any recipient. Logs to email_log. Optional
// response_id ties the log to a candidate for their Email & Action History.
import { adminClient, corsHeaders, json, requireHr } from "../_shared/hr-auth.ts";

const RESEND_API_KEY = Deno.env.get("RESEND_API_KEY")!;
const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const ADMIN_PW = "Angel2828";

const FROM_NAME = "Expert Intuitive Advisor — Human Resources";
const FROM_ADDRESS = "talent@expertintuitiveadvisor.com";

const htmlEscape = (s: string) =>
  s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;")
   .replace(/"/g, "&quot;").replace(/'/g, "&#39;");

function buildHtml(recipientName: string, body: string) {
  const year = new Date().getFullYear();
  const greeting = recipientName ? `Hi ${htmlEscape(recipientName)},` : "Hello,";
  const bodyHtml = htmlEscape(body).replace(/\n/g, "<br/>");
  return `<!doctype html><html><body style="margin:0;padding:0;background:#faf8f3;font-family:'Inter',Arial,sans-serif;color:#1a2547;">
  <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background:#faf8f3;padding:40px 16px;">
    <tr><td align="center">
      <table role="presentation" width="600" cellpadding="0" cellspacing="0" style="max-width:600px;background:#ffffff;border:1px solid #e6e0d1;border-radius:6px;overflow:hidden;">
        <tr><td style="padding:36px 48px 24px 48px;text-align:center;">
          <div style="font-family:'Cormorant Garamond',Georgia,serif;font-weight:600;font-size:28px;letter-spacing:6px;color:#1a2547;">EIA</div>
          <div style="font-family:'Inter',Arial,sans-serif;font-size:10px;letter-spacing:2px;text-transform:uppercase;color:#b08d57;margin-top:6px;">Expert Intuitive Advisor Inc.</div>
          <div style="height:1px;background:#b08d57;width:60px;margin:20px auto 0;"></div>
        </td></tr>
        <tr><td style="padding:8px 48px 8px 48px;text-align:center;">
          <div style="font-family:'Cormorant Garamond',Georgia,serif;font-size:18px;color:#1a2547;font-style:italic;">You have a message from Expert Intuitive Advisor — Human Resources Dept.</div>
        </td></tr>
        <tr><td style="padding:28px 48px 8px 48px;font-family:'Inter',Arial,sans-serif;font-size:15px;line-height:1.7;color:#1a2547;">
          <p style="margin:0 0 16px 0;">${greeting}</p>
          <div style="margin:0 0 24px 0;">${bodyHtml}</div>
          <p style="margin:24px 0 4px 0;">Warm regards,</p>
          <p style="margin:0;font-weight:600;">Human Resources</p>
          <p style="margin:0;color:#6b6655;">Expert Intuitive Advisor Inc.</p>
        </td></tr>
        <tr><td style="padding:20px 48px 32px 48px;">
          <div style="height:1px;background:#e6e0d1;margin-bottom:16px;"></div>
          <div style="font-family:'Inter',Arial,sans-serif;font-size:11px;color:#9a9588;text-align:center;">&copy; ${year} Expert Intuitive Advisor Inc.</div>
        </td></tr>
      </table>
    </td></tr>
  </table>
</body></html>`;
}

function buildText(recipientName: string, body: string) {
  const year = new Date().getFullYear();
  const greeting = recipientName ? `Hi ${recipientName},` : "Hello,";
  return `You have a message from Expert Intuitive Advisor — Human Resources Dept.

${greeting}

${body}

Warm regards,
Human Resources
Expert Intuitive Advisor Inc.

© ${year} Expert Intuitive Advisor Inc.`;
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });

  const ident = await requireHr(req);
  if (ident instanceof Response) return ident;

  try {
    const body = await req.json().catch(() => ({}));
    const password: string = typeof body?.password === "string" ? body.password : "";
    if (password !== ADMIN_PW) return json({ error: "wrong password" }, 403);

    const recipientEmail: string = typeof body?.recipient_email === "string" ? body.recipient_email.trim() : "";
    const recipientName: string = typeof body?.recipient_name === "string" ? body.recipient_name.trim() : "";
    let messageBody: string = typeof body?.message_body === "string" ? body.message_body.trim() : "";
    const responseId: string | null = typeof body?.response_id === "string" && body.response_id ? body.response_id : null;

    if (!recipientEmail || !EMAIL_RE.test(recipientEmail)) {
      return json({ error: "invalid recipient email" }, 400);
    }
    if (!messageBody) return json({ error: "message body required" }, 400);
    if (messageBody.length > 4000) messageBody = messageBody.slice(0, 4000);

    const admin = adminClient();

    let candidateId: string | null = null;
    if (responseId) {
      const { data: r } = await admin
        .from("responses").select("applicant_id").eq("id", responseId).maybeSingle();
      candidateId = (r as any)?.applicant_id ?? null;
    }

    const subject = "A message from Expert Intuitive Advisor — Human Resources Dept.";
    const html = buildHtml(recipientName, messageBody);
    const text = buildText(recipientName, messageBody);

    let emailOk = false;
    let resendId: string | null = null;
    let errorMessage: string | null = null;
    try {
      const r = await fetch("https://api.resend.com/emails", {
        method: "POST",
        headers: { "Content-Type": "application/json", Authorization: `Bearer ${RESEND_API_KEY}` },
        body: JSON.stringify({
          from: `${FROM_NAME} <${FROM_ADDRESS}>`,
          to: [recipientEmail],
          subject, html, text,
        }),
      });
      const j = await r.json().catch(() => ({}));
      emailOk = r.ok;
      resendId = j?.id ?? null;
      if (!r.ok) errorMessage = JSON.stringify(j).slice(0, 500);
    } catch (e: any) {
      errorMessage = String(e?.message || e);
    }

    await admin.from("email_log").insert({
      candidate_id: candidateId,
      stage: "custom_hr_message",
      sender: "resend",
      from_address: FROM_ADDRESS,
      from_name: FROM_NAME,
      to_address: recipientEmail,
      subject,
      status: emailOk ? "sent" : "failed",
      sent_at: emailOk ? new Date().toISOString() : null,
      resend_message_id: resendId,
      error_message: emailOk ? null : errorMessage,
    });

    if (!emailOk) return json({ error: "send failed", details: errorMessage }, 500);
    return json({ ok: true, resend_id: resendId });
  } catch (e: any) {
    return json({ error: "unexpected", details: String(e?.message || e) }, 500);
  }
});
