// decide-pre-consultation: HR approve/decline orchestrator for pre_consultation
// rows (leave_requests with doc_type='pre_consultation'). SEPARATE clone of
// decide-cash-advance. Generates the Psychic John PDF after the decision,
// archives it, sends completion backups (Outlook always + optional HR copy with
// PDF attached), and emails the signer a warm decision note with the signed-PDF
// link.
import { createClient } from "npm:@supabase/supabase-js@2";
import { archiveSignedPdf, sendCompletionBackups } from "../_shared/archive-and-backup.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
const ANON = Deno.env.get("SUPABASE_ANON_KEY")!;
const SVC = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;

const json = (b: unknown, status = 200) =>
  new Response(JSON.stringify(b), { status, headers: { ...corsHeaders, "content-type": "application/json" } });

function escapeHtml(s: string): string {
  return s.replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]!));
}

function buildSenders(approved: boolean, firstName: string, note: string | null, pdfUrl: string | null) {
  const noteLine = note && note.trim() ? `Note from Psychic John: ${note.trim()}\n\n` : "";
  const noteHtml = note && note.trim() ? `<p><strong>Note from Psychic John:</strong> ${escapeHtml(note.trim())}</p>` : "";
  const pdfLine = pdfUrl ? `Signed record: ${pdfUrl}\n\n` : "";
  const pdfHtml = pdfUrl ? `<p>You can download your signed record here: <a href="${pdfUrl}" style="color:#7c3aed">${pdfUrl}</a></p>` : "";
  const body = approved
    ? `Your pre-consultation agreement has been confirmed. We're all set for your reading.`
    : `After review, your pre-consultation agreement was not accepted at this time.`;
  const text = `Hi ${firstName},

${body}

${noteLine}${pdfLine}If you have any questions, just reply to this email.

— Psychic John`;
  const html = `<div style="font-family:Arial,sans-serif;font-size:14px;color:#2a1a3a;line-height:1.6;max-width:600px">
<p>Hi ${escapeHtml(firstName)},</p>
<p>${body}</p>
${noteHtml}
${pdfHtml}
<p>If you have any questions, just reply to this email.</p>
<p>— Psychic John</p>
</div>`;
  const senderA = {
    from_name: "Psychic John",
    from_address: "talent@expertintuitiveadvisor.com",
    subject: approved ? "Your pre-consultation is confirmed" : "Update on your pre-consultation",
    html_body: html,
    text_body: text,
  };
  const senderB = {
    from_name: "Psychic John",
    from_address: "expertintuitiveadvisor@gmail.com",
    subject: approved ? "We're set for your reading" : "A quick note about your pre-consultation",
    html_body: html,
    text_body: text,
  };
  return { senderA, senderB };
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });
  if (req.method !== "POST") return json({ ok: false, reason: "method_not_allowed" }, 405);

  // HR/admin gate
  const auth = req.headers.get("Authorization") || "";
  if (!auth.startsWith("Bearer ")) return json({ ok: false, reason: "missing_auth" }, 401);
  const userClient = createClient(SUPABASE_URL, ANON, { global: { headers: { Authorization: auth } } });
  const { data: u } = await userClient.auth.getUser();
  if (!u?.user) return json({ ok: false, reason: "invalid_jwt" }, 401);
  const admin = createClient(SUPABASE_URL, SVC);
  const { data: urow } = await admin.from("users").select("role").eq("id", u.user.id).maybeSingle();
  if (!urow || urow.role !== "admin") return json({ ok: false, reason: "forbidden" }, 403);

  const userEmail = (u.user.email || "").toLowerCase();
  const { data: hrRow } = await admin.from("hr_users").select("id").ilike("email", userEmail).maybeSingle();
  const hrId: string | null = (hrRow as any)?.id ?? null;

  let body: { leave_request_id?: string; decision?: string; note?: string };
  try { body = await req.json(); } catch { return json({ ok: false, reason: "invalid_json" }, 400); }
  const { leave_request_id, decision, note } = body || {};
  if (!leave_request_id) return json({ ok: false, reason: "missing_leave_request_id" }, 400);
  if (decision !== "approved" && decision !== "declined") return json({ ok: false, reason: "invalid_decision" }, 400);
  const cleanNote = typeof note === "string" && note.trim() ? note.trim() : null;

  const { data: row, error: loadErr } = await admin
    .from("leave_requests")
    .select("id, doc_type, status, signer_name, signer_email, response_id, external_reference, hr_copy_requested, hr_copy_email_override")
    .eq("id", leave_request_id)
    .maybeSingle();
  if (loadErr) return json({ ok: false, reason: "lookup_failed", detail: loadErr.message }, 500);
  if (!row) return json({ ok: false, reason: "not_found" }, 404);
  if ((row as any).doc_type !== "pre_consultation") {
    return json({ ok: false, reason: "wrong_doc_type", doc_type: (row as any).doc_type }, 409);
  }
  if ((row as any).status !== "pending_approval") {
    return json({ ok: false, reason: "not_pending", current_status: (row as any).status }, 409);
  }

  const nowIso = new Date().toISOString();
  const { error: updErr } = await admin
    .from("leave_requests")
    .update({ status: decision, hr_decision_note: cleanNote, decided_by_hr_id: hrId, decided_at: nowIso, updated_at: nowIso })
    .eq("id", leave_request_id);
  if (updErr) return json({ ok: false, reason: "update_failed", detail: updErr.message }, 500);

  // Generate PDF — non-fatal
  let pdfUrl: string | null = null;
  let pdfWarning: string | null = null;
  try {
    const pdfResp = await fetch(`${SUPABASE_URL}/functions/v1/generate-pre-consultation-pdf`, {
      method: "POST",
      headers: { Authorization: `Bearer ${SVC}`, "Content-Type": "application/json" },
      body: JSON.stringify({ leave_request_id }),
    });
    const pdfJson = await pdfResp.json().catch(() => ({}));
    if (pdfResp.ok && (pdfJson as any)?.pdf_url) {
      pdfUrl = (pdfJson as any).pdf_url;
      await admin.from("leave_requests").update({ signed_pdf_url: pdfUrl, updated_at: new Date().toISOString() }).eq("id", leave_request_id);
    } else {
      pdfWarning = JSON.stringify(pdfJson);
    }
  } catch (e) {
    pdfWarning = (e as Error).message;
  }

  // Archive + backups — best-effort
  if (pdfUrl) {
    try {
      const arch = await archiveSignedPdf({
        admin,
        doc_type: "pre-consultation" as any,
        external_reference: (row as any).external_reference || leave_request_id,
        source_pdf_url: pdfUrl,
      });
      if (arch.ok && arch.storage_path) {
        await admin.from("leave_requests").update({ archived_pdf_url: arch.storage_path }).eq("id", leave_request_id);
      }
      const backup = await sendCompletionBackups({
        admin,
        doc_type: "pre-consultation" as any,
        recipient_name: (row as any).signer_name || (row as any).signer_email || "(unknown)",
        external_reference: (row as any).external_reference || leave_request_id,
        pdf_bytes: arch.bytes ?? null,
        source_pdf_url: pdfUrl,
        extras: [["Decision", decision], ["Decided at", nowIso]],
        hr_copy_requested: !!(row as any).hr_copy_requested,
        hr_copy_email_override: (row as any).hr_copy_email_override || null,
      });
      if (backup.hr_copy_sent) {
        await admin.from("leave_requests").update({ hr_copy_sent_at: new Date().toISOString() }).eq("id", leave_request_id);
      }
    } catch (e) {
      console.warn("[decide-pre-consultation] archive_backup_warn", (e as Error).message);
    }
  }

  // Decision email — non-fatal
  let emailWarning: string | null = null;
  const signerEmail = (row as any).signer_email as string | null;
  const signerName = (row as any).signer_name as string | null;
  if (signerEmail && /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(signerEmail)) {
    const firstName = (signerName || "").trim().split(/\s+/)[0] || signerName || "there";
    const { senderA, senderB } = buildSenders(decision === "approved", firstName, cleanNote, pdfUrl);
    try {
      const emailResp = await fetch(`${SUPABASE_URL}/functions/v1/send-dual-email`, {
        method: "POST",
        headers: { Authorization: `Bearer ${SVC}`, "Content-Type": "application/json" },
        body: JSON.stringify({
          to: signerEmail,
          stage: decision === "approved" ? "pre_consultation_approved" : "pre_consultation_declined",
          sender_a: senderA,
          sender_b: senderB,
        }),
      });
      if (!emailResp.ok) {
        const ej = await emailResp.json().catch(() => ({}));
        emailWarning = `email_status_${emailResp.status}: ${JSON.stringify(ej)}`;
      }
    } catch (e) {
      emailWarning = (e as Error).message;
    }
  } else {
    emailWarning = "no_signer_email";
  }

  return json({ ok: true, decision, pdf_url: pdfUrl, pdf_warning: pdfWarning, email_warning: emailWarning });
});
