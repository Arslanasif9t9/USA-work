// send-onboarding-approval: sends the candidate a warm, EIA-branded approval
// email AFTER HR approves their onboarding submission. Cloned from the send
// block of decide-onboarding-quiz. Email failures are failure-safe and NEVER
// throw. Input: { submission_id }.
import { createClient } from "npm:@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

const json = (body: unknown, status = 200) =>
  new Response(JSON.stringify(body), {
    status,
    headers: { ...corsHeaders, "Content-Type": "application/json" },
  });

const RESEND_API_KEY = Deno.env.get("RESEND_API_KEY")!;

const FROM_NAME = "Angela Stein / HR – Talent Manager";
const FROM_ADDR = "talent@expertintuitiveadvisor.com";
const FROM = `${FROM_NAME} <${FROM_ADDR}>`;

const NAVY = "#1a2547";
const GOLD = "#b08d57";

const htmlEscape = (s: string) =>
  String(s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;").replace(/'/g, "&#39;");

function shell(innerHtml: string): string {
  const year = new Date().getFullYear();
  return `<!doctype html><html><body style="margin:0;padding:0;background:#faf8f3;font-family:Inter,Arial,sans-serif;color:${NAVY}">
  <table width="100%" cellpadding="0" cellspacing="0" style="background:#faf8f3;padding:32px 0">
    <tr><td align="center">
      <table width="560" cellpadding="0" cellspacing="0" style="background:#ffffff;border-top:4px solid ${GOLD};padding:34px 34px 30px 34px">
        <tr><td style="text-align:center;padding-bottom:6px">
          <div style="font-family:'Cormorant Garamond',Georgia,serif;font-weight:600;font-size:28px;letter-spacing:6px;color:${NAVY}">EIA</div>
          <div style="font-size:10px;letter-spacing:2px;text-transform:uppercase;color:${GOLD};margin-top:6px">Expert Intuitive Advisor Inc.</div>
          <div style="height:1px;background:${GOLD};width:60px;margin:18px auto 22px"></div>
        </td></tr>
        <tr><td>${innerHtml}</td></tr>
        <tr><td style="padding-top:22px">
          <div style="height:1px;background:#e6e0d1;margin-bottom:14px"></div>
          <div style="font-size:11px;color:#9a9588;text-align:center">&copy; ${year} Expert Intuitive Advisor Inc.</div>
        </td></tr>
      </table>
    </td></tr>
  </table>
  </body></html>`;
}

function approvalEmail(firstName: string, positionTitle: string | null) {
  const posLine = positionTitle
    ? `<div style="font-size:11px;letter-spacing:3px;text-transform:uppercase;color:${GOLD};margin-bottom:16px">${htmlEscape(positionTitle)}</div>`
    : `<div style="font-size:11px;letter-spacing:3px;text-transform:uppercase;color:${GOLD};margin-bottom:16px">Onboarding — Approved</div>`;
  const inner = `
    <div style="font-family:'Cormorant Garamond',Georgia,serif;font-size:24px;color:${NAVY};font-weight:600;margin-bottom:4px">Hi ${htmlEscape(firstName)},</div>
    ${posLine}
    <p style="font-size:15px;line-height:1.7;color:${NAVY};margin:0 0 14px 0">Great news — your onboarding submission has been <strong>approved</strong>.</p>
    <p style="font-size:15px;line-height:1.7;color:${NAVY};margin:0 0 14px 0">Please wait for the next steps from our team. In the meantime, stay connected with Sylvia, our onboarding specialist, on WhatsApp at <strong>+1 (917) 735-8220</strong> — she will guide you through what comes next.</p>
    <p style="font-size:15px;line-height:1.7;color:${NAVY};margin:0 0 14px 0">We're glad to have you with us.</p>
    <p style="font-size:14px;line-height:1.6;color:${NAVY};margin:24px 0 0 0">Warm regards,<br/><span style="color:${GOLD}">Angela Stein</span><br/>HR – Talent Manager<br/>Expert Intuitive Advisor Inc.</p>`;
  const text = `Hi ${firstName},

Great news — your onboarding submission has been approved.

Please wait for the next steps from our team. In the meantime, stay connected with Sylvia, our onboarding specialist, on WhatsApp at +1 (917) 735-8220 — she will guide you through what comes next.

We're glad to have you with us.

Angela Stein / HR – Talent Manager / Expert Intuitive Advisor Inc.`;
  return {
    subject: "Your Onboarding Has Been Approved — Expert Intuitive Advisor Inc.",
    html: shell(inner),
    text,
  };
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });
  if (req.method !== "POST") return json({ error: "method_not_allowed" }, 405);

  let body: { submission_id?: unknown };
  try { body = await req.json(); } catch { return json({ error: "bad_request" }, 400); }
  const submissionId = typeof body.submission_id === "string" ? body.submission_id.trim() : "";
  if (!submissionId) return json({ error: "submission_id_required" }, 400);

  const admin = createClient(
    Deno.env.get("SUPABASE_URL")!,
    Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!,
  );

  const { data: sub, error: subErr } = await admin
    .from("onboarding_submissions")
    .select("id, full_name, email, position_title, onboarding_status")
    .eq("id", submissionId)
    .maybeSingle();

  if (subErr) return json({ error: "lookup_failed", detail: subErr.message }, 500);
  if (!sub) return json({ error: "not_found" }, 404);
  if (sub.onboarding_status !== "approved") {
    return json({ error: "not_approved", status: sub.onboarding_status }, 409);
  }

  const toAddr = (sub.email || "").trim();
  const emailRe = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!toAddr || !emailRe.test(toAddr)) {
    return json({ error: "no_recipient_email" }, 422);
  }

  const firstName = ((sub.full_name || "").split(" ")[0] || "there").trim();
  const built = approvalEmail(firstName, sub.position_title || null);

  let sendOk = false;
  let resendId: string | null = null;
  let errMsg: string | null = null;
  try {
    const sendRes = await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: { "Content-Type": "application/json", Authorization: `Bearer ${RESEND_API_KEY}` },
      body: JSON.stringify({ from: FROM, to: [toAddr], subject: built.subject, html: built.html, text: built.text }),
    });
    const sendJson = await sendRes.json().catch(() => ({}));
    sendOk = sendRes.ok;
    resendId = (sendJson as { id?: string })?.id || null;
    if (!sendRes.ok) errMsg = JSON.stringify(sendJson).slice(0, 500);
  } catch (e) {
    errMsg = String((e as Error)?.message || e);
  }

  // Best-effort log — never let logging break the response.
  try {
    await admin.from("email_log").insert({
      candidate_id: null,
      stage: "onboarding_submission_approved",
      sender: "resend",
      from_address: FROM_ADDR,
      from_name: FROM_NAME,
      to_address: toAddr,
      subject: built.subject,
      status: sendOk ? "sent" : "failed",
      sent_at: sendOk ? new Date().toISOString() : null,
      resend_message_id: resendId,
      error_message: sendOk ? null : errMsg,
    });
  } catch (_) { /* swallow */ }

  return json({ ok: sendOk, email_warning: sendOk ? null : errMsg }, 200);
});
