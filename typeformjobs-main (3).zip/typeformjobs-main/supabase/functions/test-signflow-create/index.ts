import { corsHeaders } from 'npm:@supabase/supabase-js@2/cors';

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders });

  const apiKey = Deno.env.get('SIGNFLOW_API_KEY');
  if (!apiKey) {
    return new Response(JSON.stringify({ error: 'SIGNFLOW_API_KEY not set' }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }

  const body = {
    external_offer_reference: 'EIA-2026-TEST',
    signer_name: 'Test Candidate',
    signer_email: 'test@example.com',
    document_title: 'Test Offer Letter',
    pdf_url: 'https://ddfojwkaiinrmqsqmhhi.supabase.co/storage/v1/object/public/offer-letters/TEST-EIA-2026-TEST-PHP-Cruz.pdf',
    signature_field_position: { page: 4, x: 100, y: 350, width: 200, height: 60 },
  };

  const url = 'https://iutnvmotjbuoqrkxzegj.supabase.co/functions/v1/external-create-document-from-template';
  const resp = await fetch(url, {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${apiKey}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(body),
  });

  const text = await resp.text();
  let parsed: unknown = null;
  try { parsed = JSON.parse(text); } catch { /* keep raw */ }

  return new Response(JSON.stringify({
    status: resp.status,
    ok: resp.ok,
    body: parsed ?? text,
  }, null, 2), {
    status: 200,
    headers: { ...corsHeaders, 'Content-Type': 'application/json' },
  });
});
