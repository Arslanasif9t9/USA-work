// mint-onboarding-quiz-token: HR-only. Mints (or reuses) a single-use,
// identity-locked onboarding video+quiz token. Read-after-write guard.
// Locked to ONE candidate name + email. Optional target PMS team and
// after-pass behavior (manual = HR approves first [default] | auto).
import { adminClient, corsHeaders, json, requireHr } from "../_shared/hr-auth.ts";
import { DEFAULT_ONBOARDING_VIDEO_URL } from "../_shared/onboarding-video.ts";

function randomToken(): string {
  const bytes = new Uint8Array(32);
  crypto.getRandomValues(bytes);
  return Array.from(bytes, (b) => b.toString(16).padStart(2, "0")).join("");
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });
  if (req.method !== "POST") return json({ error: "method_not_allowed" }, 405);

  const hr = await requireHr(req);
  if (hr instanceof Response) return hr;

  let body: {
    candidate_name?: unknown;
    candidate_email?: unknown;
    assigned_group_id?: unknown;
    after_pass_mode?: unknown;
    video_url?: unknown;
  };
  try { body = await req.json(); } catch { return json({ error: "bad_request" }, 400); }

  const candidateName = typeof body.candidate_name === "string" ? body.candidate_name.trim() : "";
  const candidateEmail = typeof body.candidate_email === "string" ? body.candidate_email.trim() : "";
  const assignedGroupId = typeof body.assigned_group_id === "string" && body.assigned_group_id.trim()
    ? body.assigned_group_id.trim() : null;
  const afterPassMode = body.after_pass_mode === "auto" ? "auto" : "manual";
  // Always carry a playable video. Use the caller's value only if provided;
  // otherwise fall back to the single shared default so no token is ever minted
  // with a null/empty video_url.
  const videoUrl = typeof body.video_url === "string" && body.video_url.trim()
    ? body.video_url.trim() : DEFAULT_ONBOARDING_VIDEO_URL;

  if (!candidateName) return json({ error: "candidate_name_required" }, 400);
  if (!candidateEmail || !/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(candidateEmail)) {
    return json({ error: "candidate_email_invalid" }, 400);
  }

  const admin = adminClient();

  // Reuse an existing live (active, not expired, not invalidated) token for the
  // same identity so re-sending doesn't create duplicates.
  const { data: existing } = await admin
    .from("onboarding_quiz_tokens")
    .select("id, token, status, expires_at")
    .ilike("candidate_email", candidateEmail)
    .eq("status", "active")
    .gt("expires_at", new Date().toISOString())
    .order("created_at", { ascending: false })
    .limit(1)
    .maybeSingle();

  if (existing?.token) {
    // Update routing prefs on reuse (team / mode / video) without resetting attempts.
    await admin.from("onboarding_quiz_tokens")
      .update({
        candidate_name: candidateName,
        assigned_group_id: assignedGroupId,
        after_pass_mode: afterPassMode,
        video_url: videoUrl,
      })
      .eq("id", existing.id);
    return json({ token: existing.token, reused: true }, 200);
  }

  const newToken = randomToken();
  const { data: inserted, error: insErr } = await admin
    .from("onboarding_quiz_tokens")
    .insert({
      token: newToken,
      candidate_name: candidateName,
      candidate_email: candidateEmail,
      assigned_group_id: assignedGroupId,
      after_pass_mode: afterPassMode,
      video_url: videoUrl,
      created_by: hr.hrId,
    })
    .select("id, token")
    .maybeSingle();
  if (insErr || !inserted?.token) {
    return json({ error: "insert_failed", detail: insErr?.message }, 500);
  }

  // Read-after-write guard.
  const { data: verify } = await admin
    .from("onboarding_quiz_tokens").select("token").eq("id", inserted.id).maybeSingle();
  if (!verify?.token || verify.token !== inserted.token) {
    return json({ error: "verify_failed" }, 500);
  }

  return json({ token: verify.token, reused: false }, 200);
});
