// send-onboarding-form-universal: admin-gated universal sender. Mints a
// response-less onboarding token carrying HR's pre-filled text values
// (prefill_data), then sends the SAME branded onboarding invite email that
// send-onboarding-invite sends, pointing at /onboarding/{token}.
// Additive — does NOT touch the per-hire mint-onboarding-token /
// send-onboarding-invite flow.
import { createClient } from "npm:@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
const ANON = Deno.env.get("SUPABASE_ANON_KEY")!;
const SVC = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
const RESEND_API_KEY = Deno.env.get("RESEND_API_KEY")!;

// Same sender + branding constants as send-onboarding-invite.
const FROM = "Angela Stein / HR – Talent Manager <talent@expertintuitiveadvisor.com>";
const FROM_ADDR = "talent@expertintuitiveadvisor.com";
const FROM_NAME = "Angela Stein / HR – Talent Manager";

const NAVY = "#1a2547";
const GOLD = "#b08d57";
const PUBLIC_BASE = "https://jobs.expertintuitiveadvisor.com";

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

const json = (b: unknown, status = 200) =>
  new Response(JSON.stringify(b), {
    status,
    headers: { ...corsHeaders, "content-type": "application/json" },
  });

function randomToken(): string {
  const bytes = new Uint8Array(32);
  crypto.getRandomValues(bytes);
  return Array.from(bytes, (b) => b.toString(16).padStart(2, "0")).join("");
}

// Identical template to send-onboarding-invite.
function inviteHtml(firstName: string, position: string, link: string) {
  return `<!doctype html><html><body style="margin:0;padding:0;background:#faf8f3;font-family:Inter,Arial,sans-serif;color:${NAVY}">
  <table width="100%" cellpadding="0" cellspacing="0" style="background:#faf8f3;padding:32px 0">
    <tr><td align="center">
      <table width="560" cellpadding="0" cellspacing="0" style="background:#ffffff;border-top:4px solid ${GOLD};padding:32px 32px 28px 32px">
        <tr><td>
          <div style="font-family:'Cormorant Garamond',Georgia,serif;font-size:26px;color:${NAVY};font-weight:600;margin-bottom:6px">
            Welcome aboard, ${firstName}
          </div>
          <div style="font-size:11px;letter-spacing:3px;text-transform:uppercase;color:${GOLD};margin-bottom:16px">
            Your EIA Onboarding Form
          </div>
          <p style="font-size:15px;line-height:1.6;color:${NAVY};margin:0 0 14px 0">
            Congratulations on joining Expert Intuitive Advisor Inc.${position ? ` as <strong>${position}</strong>` : ""}. To get you set up, please complete your onboarding form using the link below.
          </p>
          <p style="text-align:center;margin:26px 0">
            <a href="${link}" style="display:inline-block;background:${NAVY};color:#ffffff;text-decoration:none;padding:14px 28px;border-radius:6px;font-weight:600;font-size:15px">Open Onboarding Form</a>
          </p>
          <p style="font-size:13px;line-height:1.6;color:${NAVY};margin:0 0 8px 0">
            Or copy this link:<br/>
            <span style="color:${NAVY};word-break:break-all;font-size:12px">${link}</span>
          </p>
          <p style="font-size:13px;line-height:1.6;color:#555;margin:18px 0 0 0">
            This link stays active for 30 days. You can revisit it to update your information any time during that window.
          </p>
          <p style="font-size:14px;line-height:1.6;color:${NAVY};margin:24px 0 0 0">
            Warm regards,<br/>
            <span style="color:${GOLD}">Angela Stein</span><br/>
            HR – Talent Manager<br/>
            Expert Intuitive Advisor Inc.
          </p>
        </td></tr>
      </table>
    </td></tr>
  </table>
  </body></html>`;
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });
  if (req.method !== "POST") return json({ ok: false, reason: "method_not_allowed" }, 405);

  // Admin gate (mirrors send-pre-consultation-form / send-cash-advance-form).
  const auth = req.headers.get("Authorization") || "";
  if (!auth.startsWith("Bearer ")) return json({ ok: false, reason: "missing_auth" }, 401);
  const userClient = createClient(SUPABASE_URL, ANON, { global: { headers: { Authorization: auth } } });
  const { data: u } = await userClient.auth.getUser();
  if (!u?.user) return json({ ok: false, reason: "invalid_jwt" }, 401);
  const admin = createClient(SUPABASE_URL, SVC);
  const { data: urow } = await admin.from("users").select("role").eq("id", u.user.id).maybeSingle();
  if (!urow || urow.role !== "admin") return json({ ok: false, reason: "forbidden" }, 403);

  let body: { name?: string; email?: string; position?: string; prefill_data?: Record<string, unknown> };
  try { body = await req.json(); } catch { return json({ ok: false, reason: "invalid_json" }, 400); }

  const name = (body.name || "").trim();
  const email = (body.email || "").trim();
  const position = (body.position || "").trim();
  const prefill = (body.prefill_data && typeof body.prefill_data === "object") ? body.prefill_data : {};

  if (!name) return json({ ok: false, reason: "missing_name" }, 400);
  if (!email || !EMAIL_RE.test(email)) return json({ ok: false, reason: "invalid_email" }, 400);

  // Mint a response-less onboarding token carrying HR's pre-filled values.
  const token = randomToken();
  const { data: inserted, error: insErr } = await admin
    .from("onboarding_tokens")
    .insert({
      token,
      response_id: null,
      candidate_name: name,
      candidate_email: email,
      position_title: position || null,
      prefill_data: prefill,
    })
    .select("id, token")
    .maybeSingle();
  if (insErr || !inserted?.token) return json({ ok: false, reason: "insert_failed", detail: insErr?.message }, 500);

  // Read-after-write guard — never send a broken link.
  const { data: verify } = await admin
    .from("onboarding_tokens").select("token").eq("id", inserted.id).maybeSingle();
  if (!verify?.token || verify.token !== token) return json({ ok: false, reason: "verify_failed" }, 500);

  const firstName = (name.split(" ")[0] || "there").trim();
  const link = `${PUBLIC_BASE}/onboarding/${token}`;
  const subject = "Your EIA Onboarding Form";
  const html = inviteHtml(firstName, position, link);
  const text = `Hi ${firstName},

Congratulations on joining Expert Intuitive Advisor Inc.${position ? ` as ${position}` : ""}.

Please complete your onboarding form using this link:
${link}

This link stays active for 30 days. You can revisit it to update your information any time during that window.

Warm regards,
Angela Stein
HR – Talent Manager
Expert Intuitive Advisor Inc.`;

  let sendRes: Response;
  let sendJson: any = {};
  try {
    sendRes = await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: { "Content-Type": "application/json", Authorization: `Bearer ${RESEND_API_KEY}` },
      body: JSON.stringify({ from: FROM, to: [email], subject, html, text }),
    });
    sendJson = await sendRes.json().catch(() => ({}));
  } catch (e) {
    await admin.from("email_log").insert({
      candidate_id: null,
      stage: "onboarding_invite",
      sender: "resend",
      from_address: FROM_ADDR,
      from_name: FROM_NAME,
      to_address: email,
      subject,
      status: "failed",
      sent_at: null,
      resend_message_id: null,
      error_message: String((e as any)?.message || e),
    });
    // Link is valid even if email failed — return it so HR can share manually.
    return json({ ok: false, reason: "send_failed", token, link });
  }

  const now = new Date().toISOString();
  await admin.from("email_log").insert({
    candidate_id: null,
    stage: "onboarding_invite",
    sender: "resend",
    from_address: FROM_ADDR,
    from_name: FROM_NAME,
    to_address: email,
    subject,
    status: sendRes.ok ? "sent" : "failed",
    sent_at: sendRes.ok ? now : null,
    resend_message_id: sendJson?.id ?? null,
    error_message: sendRes.ok ? null : JSON.stringify(sendJson),
  });

  if (!sendRes.ok) return json({ ok: false, reason: sendJson?.message || "send_failed", token, link });
  return json({ ok: true, token, link, to: email });
});
