// generate-ics: admin-only. Builds a .ics file from explicit fields.
import { corsHeaders, jsonResponse, requireAdmin } from "../_shared/zoom.ts";
import { buildIcs, IcsInput } from "../_shared/ics.ts";

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });
  const guard = await requireAdmin(req);
  if (guard instanceof Response) return guard;

  let body: IcsInput;
  try {
    body = await req.json();
  } catch {
    return jsonResponse({ error: "invalid_json" }, 400);
  }

  const result = buildIcs(body);
  if (!("ok" in result) || !result.ok) {
    return jsonResponse(result, 400);
  }
  return jsonResponse(result);
});
