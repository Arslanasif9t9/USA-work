// ai-write-message: HR-gated AI write-assist for composing short messages.
// Takes HR's plain-English description (+ optional context hint) and returns a
// short, warm, professional message via the Lovable AI Gateway (google/gemini-2.5-flash).
// Modeled on circular-draft-assist: same gateway, same key, same 429/402/timeout handling.
import { corsHeaders } from "npm:@supabase/supabase-js@2/cors";
import { createClient } from "npm:@supabase/supabase-js@2";

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });

  try {
    const authHeader = req.headers.get("Authorization");
    if (!authHeader?.startsWith("Bearer ")) {
      return json({ error: "Unauthorized" }, 401);
    }
    const supabase = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_ANON_KEY")!,
      { global: { headers: { Authorization: authHeader } } },
    );
    const token = authHeader.replace("Bearer ", "");
    const { data: claims, error: claimsErr } = await supabase.auth.getClaims(token);
    if (claimsErr || !claims?.claims) return json({ error: "Unauthorized" }, 401);

    const body = await req.json().catch(() => ({}));
    const description = String(body?.description ?? "").trim();
    const context = String(body?.context ?? "").trim();
    const longMode = body?.long === true || body?.doc_mode === true;
    const descCap = longMode ? 6000 : 2000;

    if (!description || description.length > descCap) {
      return json({ error: `description required (max ${descCap} chars)` }, 400);
    }

    const LOVABLE_API_KEY = Deno.env.get("LOVABLE_API_KEY");
    if (!LOVABLE_API_KEY) return json({ error: "LOVABLE_API_KEY not configured" }, 500);

    const contextLine = context ? `\n\nThis message is for: ${context}.` : "";
    const prompt = `HR's description of what they want to say:
"""
${description}
"""${contextLine}

Write the ${longMode ? "document body" : "message"} now.`;

    const systemInstruction = longMode
      ? "You are an HR talent manager at Expert Intuitive Advisor Inc. Write the FULL BODY of a professional one-page document (contract, NDA, agreement, or letter) based on HR's description. Rules: write clear, professional, well-structured multi-paragraph document language; use short numbered clauses or paragraphs where appropriate; keep it to a single page worth of content; plain English, professional and precise, no corporate clichés, no emojis. Do NOT invent specific names, dates, amounts, or facts not in the description. Do NOT add a signature line, signature block, or letterhead (those are added automatically). Return ONLY the document body text — no preamble, no quotes, no title heading."
      : "You are an HR talent manager at Expert Intuitive Advisor Inc. Write a SHORT, warm, professional message to a candidate/employee based on the HR's description. Rules: keep it concise (2-4 sentences max), warm and courteous, no-blame tone, plain English, no corporate clichés, no emojis. Do NOT invent specifics not in the description. Return ONLY the message text — no preamble, no quotes, no subject line.";

    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), longMode ? 25_000 : 10_000);

    let aiResp: Response;
    try {
      aiResp = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
        method: "POST",
        signal: controller.signal,
        headers: {
          Authorization: `Bearer ${LOVABLE_API_KEY}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          model: "google/gemini-2.5-flash",
          messages: [
            { role: "system", content: systemInstruction },
            { role: "user", content: prompt },
          ],
        }),
      });
    } catch (e) {
      clearTimeout(timeout);
      if ((e as Error).name === "AbortError") {
        return json({ error: "AI write timed out. Please try again." }, 504);
      }
      throw e;
    }
    clearTimeout(timeout);

    if (aiResp.status === 429) return json({ error: "Rate limit exceeded. Try again shortly." }, 429);
    if (aiResp.status === 402) return json({ error: "AI credits exhausted. Add credits in workspace settings." }, 402);
    if (!aiResp.ok) {
      const t = await aiResp.text();
      console.error("AI gateway error:", aiResp.status, t);
      return json({ error: "AI gateway error" }, 500);
    }

    const data = await aiResp.json();
    const message = String(data?.choices?.[0]?.message?.content ?? "")
      .trim()
      .replace(/^["']|["']$/g, "")
      .trim();
    if (!message) return json({ error: "AI returned an empty message. Please try again." }, 502);

    return json({ message });
  } catch (e) {
    console.error("ai-write-message error:", e);
    return json({ error: e instanceof Error ? e.message : "Unknown error" }, 500);
  }
});

function json(b: unknown, status = 200) {
  return new Response(JSON.stringify(b), {
    status,
    headers: { ...corsHeaders, "Content-Type": "application/json" },
  });
}
