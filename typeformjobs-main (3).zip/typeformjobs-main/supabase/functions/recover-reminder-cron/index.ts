// recover-reminder-cron: DAILY gentle reminder to candidates who were INVITED to
// their AI interview but never completed it, until their link expires.
//
// Modeled on interview-reminder-cron's shape: idempotent, single-row writes by id,
// never touches the answers table, never cascades.
//
// Selection ("invited, not completed"):
//   - responses.round_stage IN ('round_1_sent','round_2_sent')
//   - an ACTIVE rebook_token exists (used_at IS NULL AND expires_at > now())
//   - NO completed ai_interview_session (no row, or only failed/short)
//   - NOT disqualified / NOT cancelled
//   - recover_reminder_last_sent_at is null OR older than ~23h (max one per 24h)
//
// It REUSES the candidate's existing active token link — it does NOT mint or
// replace a token. Because the token expires in ~3 days, this naturally fires at
// most ~2-3 times, then the candidate drops out of selection (no reminder after
// the link expires). Logs email_log stage 'recover_reminder'.
import { createClient } from "npm:@supabase/supabase-js@2";

const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
const SERVICE_KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
const RESEND_API_KEY = Deno.env.get("RESEND_API_KEY")!;

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const PUBLIC_BASE_URL = "https://jobs.expertintuitiveadvisor.com";

// One reminder per ~24h. Use 23h so a daily cron that drifts a few minutes
// earlier still fires (never double-sends within the same calendar day).
const MIN_GAP_MS = 23 * 60 * 60 * 1000;
// A session counts as "COMPLETED" (stop reminding) ONLY if it ran a real
// interview of at least 4 minutes AND did not end in an error/abandon.
// Anyone with no session, a session under 4 minutes, or only failed/error
// sessions is STILL INCOMPLETE and keeps getting the daily reminder.
const COMPLETED_MIN_SECONDS = 240; // 4 minutes
const FAILED_REASON_RE = /(error|not_joined|failed|abandon)/i;
// Terminations where the AGENT ended the call = a real, finished interview
// regardless of duration (e.g. Christine hangs up at 3:47). These count as
// COMPLETED even when under 240s.
const AGENT_ENDED_REASONS = new Set(["agent_hangup", "max_duration_reached"]);
// SMART COMPLETION RULE (identical in cron, RecoverInterviewButton, AiInterviews):
//   completed = NOT trueBail AND ( agentEnded OR duration_seconds >= 240 )
const isSessionCompleted = (reason: string | null | undefined, durationSeconds: number | null | undefined) => {
  const trueBail = reason ? FAILED_REASON_RE.test(reason) : false;
  if (trueBail) return false;
  const agentEnded = reason ? AGENT_ENDED_REASONS.has(reason.toLowerCase()) : false;
  return agentEnded || (durationSeconds ?? 0) >= COMPLETED_MIN_SECONDS;
};

// Stages that represent a recover-able AI interview link.
const RECOVER_STAGES = ["round1", "ai_scheduled", "round2_ai"];

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });

  const admin = createClient(SUPABASE_URL, SERVICE_KEY, { auth: { persistSession: false } });
  const nowMs = Date.now();
  const nowIso = new Date(nowMs).toISOString();

  // 1) Active recover tokens (the natural 3-day expiry gate).
  const { data: tokens, error: tokErr } = await admin
    .from("rebook_tokens")
    .select("token, response_id, stage, candidate_name, candidate_email, assigned_hr_id, expires_at, used_at")
    .in("stage", RECOVER_STAGES)
    .is("used_at", null)
    .gt("expires_at", nowIso);

  if (tokErr) {
    console.error("[recover-reminder] token query failed", tokErr);
    return new Response(JSON.stringify({ error: tokErr.message }), {
      status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }

  // Keep the latest active token per response (most recently created wins if duplicates).
  const tokenByResp: Record<string, any> = {};
  for (const t of (tokens || [])) {
    if (!t.response_id) continue;
    const prev = tokenByResp[t.response_id];
    if (!prev || new Date(t.expires_at).getTime() > new Date(prev.expires_at).getTime()) {
      tokenByResp[t.response_id] = t;
    }
  }
  const responseIds = Object.keys(tokenByResp);
  if (responseIds.length === 0) {
    return new Response(JSON.stringify({ ok: true, processed: 0, sent: 0 }), {
      status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }

  // 2) Load responses → gate on round_stage / disqualified / cancelled.
  const { data: responses } = await admin
    .from("responses")
    .select("id, form_id, applicant_id, override_email, override_name, round_stage, appointment_cancelled, disqualified_at")
    .in("id", responseIds);

  const eligibleResp = (responses || []).filter((r: any) => {
    if (r.disqualified_at || r.round_stage === "disqualified") return false;
    if (r.appointment_cancelled) return false;
    // Include ai_interview_completed: the webhook flips this stage on ANY
    // call_ended (even a 6-second bail), so completion is decided by the
    // >=240s + non-error session rule below — NOT by round_stage alone.
    return r.round_stage === "round_1_sent"
      || r.round_stage === "round_2_sent"
      || r.round_stage === "ai_interview_completed";
  });
  if (eligibleResp.length === 0) {
    return new Response(JSON.stringify({ ok: true, processed: 0, sent: 0 }), {
      status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
  const eligibleIds = eligibleResp.map((r: any) => r.id);

  // 3) Sessions → drop any candidate with a COMPLETED session (long + not failed).
  const { data: sessions } = await admin
    .from("ai_interview_sessions")
    .select("response_id, duration_seconds, termination_reason")
    .in("response_id", eligibleIds);

  const completedResp = new Set<string>();
  for (const s of (sessions || [])) {
    if (!s.response_id) continue;
    // SMART COMPLETION RULE: agent-ended OR >=240s, and not a true bail.
    if (isSessionCompleted(s.termination_reason, s.duration_seconds)) {
      completedResp.add(s.response_id);
    }
  }

  // 4) candidate_actions → idempotency (recover_reminder_last_sent_at) + opt-out + write target.
  const { data: actions } = await admin
    .from("candidate_actions")
    .select("id, response_id, recover_reminder_last_sent_at, recover_reminder_opt_out")
    .in("response_id", eligibleIds);
  const actionByResp: Record<string, any> = {};
  for (const a of (actions || [])) if (a.response_id) actionByResp[a.response_id] = a;

  // 5) For email name/email fallback by LABEL (never positional).
  const formIds = [...new Set(eligibleResp.map((r: any) => r.form_id))];
  const [{ data: questions }, { data: answers }, { data: forms }] = await Promise.all([
    admin.from("questions").select("id, form_id, type, label").in("form_id", formIds),
    admin.from("answers").select("response_id, question_id, answer_text").in("response_id", eligibleIds),
    admin.from("form_metadata").select("form_id, position_title").in("form_id", formIds),
  ]);
  const qByForm: Record<string, any[]> = {};
  for (const q of (questions || [])) (qByForm[q.form_id] = qByForm[q.form_id] || []).push(q);
  const ansByResp: Record<string, Record<string, string>> = {};
  for (const a of (answers || [])) {
    ansByResp[a.response_id] = ansByResp[a.response_id] || {};
    ansByResp[a.response_id][a.question_id] = (a.answer_text || "").trim();
  }
  const positionByForm: Record<string, string> = {};
  for (const m of (forms || [])) positionByForm[(m as any).form_id] = (m as any).position_title || "";

  const findByLabel = (qs: any[], re: RegExp) => qs?.find((q) => re.test(q.label || ""));

  let processed = 0;
  let sent = 0;
  let skipped = 0;
  let failed = 0;
  const errors: string[] = [];

  for (const r of eligibleResp) {
    processed++;
    if (completedResp.has(r.id)) { skipped++; continue; }

    const action = actionByResp[r.id];
    // STOP REMINDERS opt-out: HR (or disqualify/delete) flipped this true → skip.
    if (action?.recover_reminder_opt_out === true) { skipped++; continue; }
    const last = action?.recover_reminder_last_sent_at
      ? new Date(action.recover_reminder_last_sent_at).getTime() : 0;
    if (last && (nowMs - last) < MIN_GAP_MS) { skipped++; continue; }

    const tok = tokenByResp[r.id];
    if (!tok) { skipped++; continue; }

    // Resolve name + email: override → token → answer-by-label.
    const qs = qByForm[r.form_id] || [];
    const ans = ansByResp[r.id] || {};
    const emailQ = findByLabel(qs, /e[-\s]?mail/i) || qs.find((q) => q.type === "email");
    const nameQ = findByLabel(qs, /(full\s*name|first\s*name|your\s*name|\bname\b)/i)
      || qs.find((q) => q.type === "short_text");

    const candidateEmail = (r.override_email || "").trim()
      || (tok.candidate_email || "").trim()
      || (emailQ ? (ans[emailQ.id] || "") : "");
    const candidateName = (r.override_name || "").trim()
      || (tok.candidate_name || "").trim()
      || (nameQ ? (ans[nameQ.id] || "") : "")
      || "there";

    if (!candidateEmail || !EMAIL_RE.test(candidateEmail)) { skipped++; continue; }

    // Round is keyed off the token stage (round2_ai → Marissa), since
    // round_stage may be ai_interview_completed after a partial attempt.
    const round = (tok.stage === "round2_ai" || r.round_stage === "round_2_sent") ? 2 : 1;
    const interviewerName = round === 2 ? "Marissa" : "Christine";
    const minutes = round === 2 ? "10" : "7";
    const firstName = candidateName.split(" ")[0];
    const positionTitle = positionByForm[r.form_id] || "the role";

    // REUSE the existing token link — do NOT mint a new one.
    const recoverUrl = tok.stage === "ai_scheduled"
      ? `${PUBLIC_BASE_URL}/rebook/${tok.token}`
      : `${PUBLIC_BASE_URL}/ai-interview/${tok.token}`;

    const subject = `A gentle reminder — your interview is still open`;
    const html = `<div style="font-family: Arial, Helvetica, sans-serif; color:#1a2547; font-size:15px; line-height:1.6; max-width:560px;">
<p>Hi ${firstName},</p>
<p>Just a gentle reminder — your short interview with ${interviewerName} for the <strong>${positionTitle}</strong> position is still open.</p>
<p>It only takes about ${minutes} minutes, right here — no scheduling, no download. Whenever you have a quiet moment, just click below. Our team reviews every interview personally.</p>
<p style="text-align:center; margin:28px 0;">
  <a href="${recoverUrl}" style="display:inline-block; background:#1a2547; color:#ffffff; text-decoration:none; font-weight:600; font-size:16px; padding:14px 28px; border-radius:8px;">Continue your interview</a>
</p>
<p>There are no trick questions — just a friendly conversation. Take your time and answer naturally. You'll only need a quiet spot with a working camera and microphone.</p>
<p style="color:#6b7280; font-size:13px;">If the button doesn't work, copy and paste this link into your browser:<br/>
<a href="${recoverUrl}" style="color:#1a2547;">${recoverUrl}</a></p>
<p style="margin-top:24px;">Warmly,<br/>
<strong>Angela Stein</strong><br/>
HR — Talent Manager<br/>
Expert Intuitive Advisor Inc.</p>
</div>`;
    const text = `Hi ${firstName},

Just a gentle reminder — your short interview with ${interviewerName} for the ${positionTitle} position is still open.

It only takes about ${minutes} minutes, right here — no scheduling, no download. Whenever you have a quiet moment, just click the link below. Our team reviews every interview personally.

Continue your interview:
${recoverUrl}

There are no trick questions — just a friendly conversation. Take your time and answer naturally. You'll only need a quiet spot with a working camera and microphone.

Warmly,
Angela Stein
HR — Talent Manager
Expert Intuitive Advisor Inc.`;

    let emailOk = false;
    let resendId: string | null = null;
    let errorMessage: string | null = null;
    try {
      const res = await fetch("https://api.resend.com/emails", {
        method: "POST",
        headers: { "Content-Type": "application/json", Authorization: `Bearer ${RESEND_API_KEY}` },
        body: JSON.stringify({
          from: "Angela Stein / HR – Talent Manager <talent@expertintuitiveadvisor.com>",
          to: [candidateEmail], subject, html, text,
        }),
      });
      const j = await res.json().catch(() => ({}));
      emailOk = res.ok;
      resendId = j?.id ?? null;
      if (!res.ok) errorMessage = JSON.stringify(j).slice(0, 500);
    } catch (e: any) {
      errorMessage = String(e?.message || e);
    }

    // Log every attempt (single row).
    await admin.from("email_log").insert({
      candidate_id: r.applicant_id ?? null,
      stage: "recover_reminder",
      sender: "resend",
      from_address: "talent@expertintuitiveadvisor.com",
      from_name: "Angela Stein / HR – Talent Manager",
      to_address: candidateEmail,
      subject,
      status: emailOk ? "sent" : "failed",
      sent_at: emailOk ? new Date().toISOString() : null,
      resend_message_id: resendId,
      error_message: emailOk ? null : errorMessage,
    });

    if (emailOk) {
      sent++;
      // Mark idempotency timestamp — single-row write by id.
      if (action?.id) {
        await admin.from("candidate_actions")
          .update({ recover_reminder_last_sent_at: new Date().toISOString() })
          .eq("id", action.id);
      }
    } else {
      failed++;
      if (errorMessage) errors.push(`${candidateEmail}: ${errorMessage}`);
    }
  }

  console.log(`[recover-reminder] processed=${processed} sent=${sent} skipped=${skipped} failed=${failed}`);
  return new Response(JSON.stringify({ ok: true, processed, sent, skipped, failed, errors }), {
    status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" },
  });
});
