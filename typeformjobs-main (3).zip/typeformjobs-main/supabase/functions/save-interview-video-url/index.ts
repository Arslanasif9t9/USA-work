// save-interview-video-url: PUBLIC. Writes video_url to ai_interview_sessions.
// Matches by retell_call_id; falls back to response_id; inserts a stub row if neither exists.
import { createClient } from "npm:@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
const SERVICE = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;

const json = (b: unknown, s = 200) =>
  new Response(JSON.stringify(b), { status: s, headers: { ...corsHeaders, "Content-Type": "application/json" } });

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });
  try {
    const { token, retell_call_id, video_url } = await req.json();
    if (!token || !retell_call_id || !video_url) return json({ error: "missing_fields" }, 400);

    const admin = createClient(SUPABASE_URL, SERVICE);
    const { data: tok } = await admin.from("rebook_tokens").select("response_id,stage,used_at,expires_at").eq("token", token).maybeSingle();
    if (!tok) return json({ error: "invalid_token" }, 401);
    if (tok.used_at) return json({ error: "token_used" }, 401);
    if (new Date(tok.expires_at) <= new Date()) return json({ error: "token_expired" }, 401);

    const response_id = tok.response_id;

    // 1) Try update by retell_call_id
    const upd1 = await admin
      .from("ai_interview_sessions")
      .update({ video_url, stage: tok.stage })
      .eq("retell_call_id", retell_call_id)
      .select("id");
    if ((upd1.data?.length ?? 0) > 0) return json({ ok: true, mode: "updated_by_call_id" });

    // 2) Try update by response_id where retell_call_id is null
    const upd2 = await admin
      .from("ai_interview_sessions")
      .update({ video_url, retell_call_id, stage: tok.stage })
      .eq("response_id", response_id)
      .is("retell_call_id", null)
      .select("id");
    if ((upd2.data?.length ?? 0) > 0) return json({ ok: true, mode: "updated_by_response_id" });

    // 3) Upsert on retell_call_id so a racing webhook insert converges to ONE row.
    //    Only sets video_url/response_id/stage — NEVER overwrites recording_url/transcript
    //    (those columns aren't in the payload). Unique index on retell_call_id makes
    //    this atomic; NULL retell_call_id can't reach here (validated above).
    const ins = await admin
      .from("ai_interview_sessions")
      .upsert({ response_id, retell_call_id, video_url, stage: tok.stage }, { onConflict: "retell_call_id" })
      .select("id")
      .maybeSingle();
    if (ins.error) {
      console.error("[save-interview-video-url] upsert error:", ins.error);
      return json({ error: ins.error.message }, 500);
    }
    return json({ ok: true, mode: "upserted", id: ins.data?.id });
  } catch (e: any) {
    console.error("[save-interview-video-url] exception:", e);
    return json({ error: String(e?.message || e) }, 500);
  }
});
