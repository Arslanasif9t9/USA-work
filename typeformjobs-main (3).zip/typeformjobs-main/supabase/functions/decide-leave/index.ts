// decide-leave: HR approve/decline orchestrator for leave_requests.
// - Requires HR/admin JWT.
// - Guards status === 'pending_approval'.
// - Updates the row's decision fields.
// - Calls generate-leave-pdf AFTER the decision (so footer reflects it),
//   stores signed_pdf_url. PDF/email failures don't roll back the decision.
// - Sends warm decision email via send-dual-email (leave_approved / leave_declined).
import { createClient } from "npm:@supabase/supabase-js@2";
import { archiveSignedPdf, sendCompletionBackups } from "../_shared/archive-and-backup.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
const ANON = Deno.env.get("SUPABASE_ANON_KEY")!;
const SVC = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;

const json = (b: unknown, status = 200) =>
  new Response(JSON.stringify(b), {
    status,
    headers: { ...corsHeaders, "content-type": "application/json" },
  });

function escapeHtml(s: string): string {
  return s.replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]!));
}

function buildApprovedSenders(firstName: string, note: string | null, pdfUrl: string | null) {
  const noteLine = note && note.trim() ? `Note from HR: ${note.trim()}\n\n` : "";
  const noteHtml = note && note.trim() ? `<p><strong>Note from HR:</strong> ${escapeHtml(note.trim())}</p>` : "";
  const pdfLine = pdfUrl ? `Signed record: ${pdfUrl}\n\n` : "";
  const pdfHtml = pdfUrl
    ? `<p>You can download the signed record here: <a href="${pdfUrl}" style="color:#1a2547">${pdfUrl}</a></p>`
    : "";
  const text = `Hi ${firstName},

Your leave request has been approved.

${noteLine}${pdfLine}Thank you for letting us know in advance and arranging coverage.

Warmly,
Angela Stein
HR — Talent Manager
Expert Intuitive Advisor Inc.`;
  const html = `<div style="font-family:Arial,sans-serif;font-size:14px;color:#1a2236;line-height:1.6;max-width:600px">
<p>Hi ${escapeHtml(firstName)},</p>
<p><strong>Your leave request has been approved.</strong></p>
${noteHtml}
${pdfHtml}
<p>Thank you for letting us know in advance and arranging coverage.</p>
<p>Warmly,<br/>Angela Stein<br/>HR — Talent Manager<br/>Expert Intuitive Advisor Inc.</p>
</div>`;
  const senderA = {
    from_name: "Angela Stein / HR — Talent Manager",
    from_address: "talent@expertintuitiveadvisor.com",
    subject: "Your leave request has been approved — Expert Intuitive Advisor Inc.",
    html_body: html,
    text_body: text,
  };
  const senderB = {
    from_name: "Angela Stein",
    from_address: "expertintuitiveadvisor@gmail.com",
    subject: "Quick note — your leave is approved",
    html_body: html,
    text_body: text,
  };
  return { senderA, senderB };
}

function buildDeclinedSenders(firstName: string, note: string | null, pdfUrl: string | null) {
  const noteLine = note && note.trim() ? `Note from HR: ${note.trim()}\n\n` : "";
  const noteHtml = note && note.trim() ? `<p><strong>Note from HR:</strong> ${escapeHtml(note.trim())}</p>` : "";
  const pdfLine = pdfUrl ? `Decision record: ${pdfUrl}\n\n` : "";
  const pdfHtml = pdfUrl
    ? `<p>Decision record: <a href="${pdfUrl}" style="color:#1a2547">${pdfUrl}</a></p>`
    : "";
  const text = `Hi ${firstName},

After review, your leave request has not been approved at this time.

${noteLine}${pdfLine}Please reach out to HR if you have any questions — we're happy to talk it through.

Warmly,
Angela Stein
HR — Talent Manager
Expert Intuitive Advisor Inc.`;
  const html = `<div style="font-family:Arial,sans-serif;font-size:14px;color:#1a2236;line-height:1.6;max-width:600px">
<p>Hi ${escapeHtml(firstName)},</p>
<p>After review, your leave request has not been approved at this time.</p>
${noteHtml}
${pdfHtml}
<p>Please reach out to HR if you have any questions — we're happy to talk it through.</p>
<p>Warmly,<br/>Angela Stein<br/>HR — Talent Manager<br/>Expert Intuitive Advisor Inc.</p>
</div>`;
  const senderA = {
    from_name: "Angela Stein / HR — Talent Manager",
    from_address: "talent@expertintuitiveadvisor.com",
    subject: "Update on your leave request — Expert Intuitive Advisor Inc.",
    html_body: html,
    text_body: text,
  };
  const senderB = {
    from_name: "Angela Stein",
    from_address: "expertintuitiveadvisor@gmail.com",
    subject: "A quick personal note about your leave request",
    html_body: html,
    text_body: text,
  };
  return { senderA, senderB };
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });
  if (req.method !== "POST") return json({ ok: false, reason: "method_not_allowed" }, 405);

  // HR/admin gate
  const auth = req.headers.get("Authorization") || "";
  if (!auth.startsWith("Bearer ")) return json({ ok: false, reason: "missing_auth" }, 401);
  const userClient = createClient(SUPABASE_URL, ANON, { global: { headers: { Authorization: auth } } });
  const { data: u } = await userClient.auth.getUser();
  if (!u?.user) return json({ ok: false, reason: "invalid_jwt" }, 401);
  const admin = createClient(SUPABASE_URL, SVC);
  const { data: urow } = await admin.from("users").select("role").eq("id", u.user.id).maybeSingle();
  if (!urow || urow.role !== "admin") return json({ ok: false, reason: "forbidden" }, 403);

  // Resolve HR id by email (best-effort)
  const userEmail = (u.user.email || "").toLowerCase();
  const { data: hrRow } = await admin
    .from("hr_users").select("id").ilike("email", userEmail).maybeSingle();
  const hrId: string | null = (hrRow as any)?.id ?? null;

  let body: { leave_request_id?: string; decision?: string; note?: string };
  try { body = await req.json(); } catch { return json({ ok: false, reason: "invalid_json" }, 400); }
  const { leave_request_id, decision, note } = body || {};
  if (!leave_request_id) return json({ ok: false, reason: "missing_leave_request_id" }, 400);
  if (decision !== "approved" && decision !== "declined") {
    return json({ ok: false, reason: "invalid_decision" }, 400);
  }
  const cleanNote = typeof note === "string" && note.trim() ? note.trim() : null;

  // Load + guard
  const { data: row, error: loadErr } = await admin
    .from("leave_requests")
    .select("id, doc_type, status, signer_name, signer_email, response_id, external_reference, hr_copy_requested, hr_copy_email_override")
    .eq("id", leave_request_id)
    .maybeSingle();
  if (loadErr) return json({ ok: false, reason: "lookup_failed", detail: loadErr.message }, 500);
  if (!row) return json({ ok: false, reason: "not_found" }, 404);
  // Defense in depth: never process a foreign doc type with leave wording.
  // doc_type may be null for legacy leave rows — treat null/'leave' as leave.
  const docType = (row as any).doc_type;
  if (docType && docType !== "leave") {
    return json({ ok: false, reason: "wrong_doc_type", doc_type: docType }, 409);
  }
  if ((row as any).status !== "pending_approval") {
    return json({ ok: false, reason: "not_pending", current_status: (row as any).status }, 409);
  }

  // Single-row decision UPDATE
  const nowIso = new Date().toISOString();
  const { error: updErr } = await admin
    .from("leave_requests")
    .update({
      status: decision,
      hr_decision_note: cleanNote,
      decided_by_hr_id: hrId,
      decided_at: nowIso,
      updated_at: nowIso,
    })
    .eq("id", leave_request_id);
  if (updErr) return json({ ok: false, reason: "update_failed", detail: updErr.message }, 500);

  // Generate PDF (after the decision so footer reflects it) — non-fatal
  let pdfUrl: string | null = null;
  let pdfWarning: string | null = null;
  try {
    const pdfResp = await fetch(`${SUPABASE_URL}/functions/v1/generate-leave-pdf`, {
      method: "POST",
      headers: { Authorization: `Bearer ${SVC}`, "Content-Type": "application/json" },
      body: JSON.stringify({ leave_request_id }),
    });
    const pdfJson = await pdfResp.json().catch(() => ({}));
    if (pdfResp.ok && (pdfJson as any)?.pdf_url) {
      pdfUrl = (pdfJson as any).pdf_url;
      await admin.from("leave_requests")
        .update({ signed_pdf_url: pdfUrl, updated_at: new Date().toISOString() })
        .eq("id", leave_request_id);
    } else {
      pdfWarning = JSON.stringify(pdfJson);
    }
  } catch (e) {
    pdfWarning = (e as Error).message;
  }

  // === Piece 6 Part A: archive PDF + always-on Outlook backup + optional Gmail copy ===
  // Best-effort: failures must NOT roll back the decision.
  if (pdfUrl) {
    try {
      const arch = await archiveSignedPdf({
        admin,
        doc_type: "leave",
        external_reference: (row as any).external_reference || leave_request_id,
        source_pdf_url: pdfUrl,
      });
      if (arch.ok && arch.storage_path) {
        await admin.from("leave_requests")
          .update({ archived_pdf_url: arch.storage_path })
          .eq("id", leave_request_id);
      }
      const backup = await sendCompletionBackups({
        admin,
        doc_type: "leave",
        recipient_name: (row as any).signer_name || (row as any).signer_email || "(unknown)",
        external_reference: (row as any).external_reference || leave_request_id,
        pdf_bytes: arch.bytes ?? null,
        source_pdf_url: pdfUrl,
        extras: [["Decision", decision], ["Decided at", nowIso]],
        hr_copy_requested: !!(row as any).hr_copy_requested,
        hr_copy_email_override: (row as any).hr_copy_email_override || null,
      });
      if (backup.hr_copy_sent) {
        await admin.from("leave_requests")
          .update({ hr_copy_sent_at: new Date().toISOString() })
          .eq("id", leave_request_id);
      }
      console.log("[decide-leave] archive+backup", {
        archived: arch.ok, archive_path: arch.storage_path,
        main_backup_sent: backup.main_backup_sent, hr_copy_sent: backup.hr_copy_sent,
      });
    } catch (e) {
      console.warn("[decide-leave] archive_backup_warn", (e as Error).message);
    }
  }

  // Send decision email — non-fatal
  let emailWarning: string | null = null;
  const signerEmail = (row as any).signer_email as string | null;
  const signerName = (row as any).signer_name as string | null;
  if (signerEmail && /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(signerEmail)) {
    const firstName = (signerName || "").trim().split(/\s+/)[0] || signerName || "there";
    const { senderA, senderB } = decision === "approved"
      ? buildApprovedSenders(firstName, cleanNote, pdfUrl)
      : buildDeclinedSenders(firstName, cleanNote, pdfUrl);
    try {
      const emailResp = await fetch(`${SUPABASE_URL}/functions/v1/send-dual-email`, {
        method: "POST",
        headers: { Authorization: `Bearer ${SVC}`, "Content-Type": "application/json" },
        body: JSON.stringify({
          to: signerEmail,
          stage: decision === "approved" ? "leave_approved" : "leave_declined",
          sender_a: senderA,
          sender_b: senderB,
        }),
      });
      if (!emailResp.ok) {
        const ej = await emailResp.json().catch(() => ({}));
        emailWarning = `email_status_${emailResp.status}: ${JSON.stringify(ej)}`;
      }
    } catch (e) {
      emailWarning = (e as Error).message;
    }
  } else {
    emailWarning = "no_signer_email";
  }

  return json({
    ok: true,
    decision,
    pdf_url: pdfUrl,
    pdf_warning: pdfWarning,
    email_warning: emailWarning,
  });
});
