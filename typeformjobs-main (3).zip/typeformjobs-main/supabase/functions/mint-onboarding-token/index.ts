// HR-only helper that mints (or returns the existing) onboarding token for a
// response. Long-lived (30 days). Reuses existing live row if present.
// Pre-fills candidate_name / candidate_email / position_title from job_offers
// (fallback to answers / form_metadata). Read-after-write guard.
import { adminClient, corsHeaders, json, requireHr } from "../_shared/hr-auth.ts";

function randomToken(): string {
  const bytes = new Uint8Array(32);
  crypto.getRandomValues(bytes);
  return Array.from(bytes, (b) => b.toString(16).padStart(2, "0")).join("");
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });
  if (req.method !== "POST") return json({ error: "method_not_allowed" }, 405);

  const hr = await requireHr(req);
  if (hr instanceof Response) return hr;

  let body: { response_id?: unknown };
  try { body = await req.json(); } catch { return json({ error: "bad_request" }, 400); }
  const responseId = typeof body?.response_id === "string" ? body.response_id.trim() : "";
  if (!responseId) return json({ error: "response_id_required" }, 400);

  const admin = adminClient();

  const { data: resp, error: respErr } = await admin
    .from("responses")
    .select("id, form_id, applicant_id, override_email, override_name")
    .eq("id", responseId)
    .maybeSingle();
  if (respErr || !resp) return json({ error: "response_not_found" }, 404);

  // Reuse existing live (not closed, not expired) token.
  const { data: existing } = await admin
    .from("onboarding_tokens")
    .select("id, token, expires_at, closed_at")
    .eq("response_id", responseId)
    .is("closed_at", null)
    .gt("expires_at", new Date().toISOString())
    .order("created_at", { ascending: false })
    .limit(1)
    .maybeSingle();

  if (existing?.token) {
    return json({ token: existing.token, reused: true }, 200);
  }

  // Resolve prefill data
  let candidateName: string | null = null;
  let candidateEmail: string | null = null;
  let positionTitle: string | null = null;

  // Prefer the most recent matched job_offer for this candidate
  if (resp.applicant_id) {
    const { data: offer } = await admin
      .from("job_offers")
      .select("candidate_name, candidate_email, position_title")
      .eq("candidate_id", resp.applicant_id)
      .eq("status", "signed")
      .order("signed_at", { ascending: false })
      .limit(1)
      .maybeSingle();
    if (offer) {
      candidateName = (offer.candidate_name || "").trim() || null;
      candidateEmail = (offer.candidate_email || "").trim() || null;
      positionTitle = (offer.position_title || "").trim() || null;
    }
  }

  if (!candidateName) {
    candidateName = ((resp as any).override_name || "").trim() || null;
  }

  if (!candidateEmail) {
    candidateEmail = ((resp as any).override_email || "").trim() || null;
  }

  // Fallback to answers
  if (!candidateName || !candidateEmail) {
    const { data: qs } = await admin
      .from("questions").select("id, type, label").eq("form_id", resp.form_id);
    const { data: ans } = await admin
      .from("answers").select("question_id, answer_text").eq("response_id", responseId);
    const nameQ = qs?.find((q: any) => /name/i.test(q.label));
    const emailQ = qs?.find((q: any) => q.type === "email") || qs?.find((q: any) => /email/i.test(q.label));
    const find = (qid?: string) => qid ? ((ans?.find((a: any) => a.question_id === qid)?.answer_text) || "").trim() : "";
    if (!candidateName) candidateName = find(nameQ?.id) || null;
    if (!candidateEmail) candidateEmail = find(emailQ?.id) || null;
  }

  if (!positionTitle) {
    const { data: meta } = await admin
      .from("form_metadata").select("position_title").eq("form_id", resp.form_id).maybeSingle();
    positionTitle = (meta?.position_title || "").trim() || null;
  }

  const newToken = randomToken();
  const { data: inserted, error: insErr } = await admin
    .from("onboarding_tokens")
    .insert({
      token: newToken,
      response_id: responseId,
      candidate_email: candidateEmail,
      candidate_name: candidateName,
      position_title: positionTitle,
    })
    .select("id, token")
    .maybeSingle();
  if (insErr || !inserted?.token) return json({ error: "insert_failed", detail: insErr?.message }, 500);

  // Read-after-write
  const { data: verify } = await admin
    .from("onboarding_tokens").select("token").eq("id", inserted.id).maybeSingle();
  if (!verify?.token || verify.token !== inserted.token) {
    return json({ error: "verify_failed" }, 500);
  }

  return json({ token: verify.token, reused: false }, 200);
});
