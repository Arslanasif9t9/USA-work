// setup-hr-pmr: admin-only. Fetches each HR's Personal Meeting Room (PMI + join URL + password)
// from Zoom and stores it in hr_users (personal_meeting_url, personal_meeting_password, zoom_pmi,
// zoom_user_id, zoom_user_email). Auto-matches Zoom users to HR rows by nickname / display_name /
// email; an optional `mapping` body lets callers override (e.g. { "<hr_id>": "<zoom_user_id_or_email>" }).
import { adminClient, corsHeaders, jsonResponse, requireAdmin, zoomFetch } from "../_shared/zoom.ts";

function norm(s: string | null | undefined) {
  return (s || "").toString().toLowerCase().replace(/[^a-z]/g, "");
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });
  const guard = await requireAdmin(req);
  if (guard instanceof Response) return guard;

  let body: { mapping?: Record<string, string> } = {};
  try { body = (await req.json()) ?? {}; } catch { body = {}; }
  const mapping = body.mapping || {};

  const admin = adminClient();

  // 1. List Zoom users (active). Light read endpoint — not subject to the create quota.
  const usersRes = await zoomFetch("/users?page_size=100&status=active", { method: "GET" });
  const usersJson: any = await usersRes.json().catch(() => ({}));
  if (!usersRes.ok) {
    return jsonResponse({ error: "zoom_users_failed", status: usersRes.status, details: usersJson }, 502);
  }
  const zoomUsers: any[] = usersJson.users || [];

  // 2. Load HR rows we want to wire up (anyone with role 'hr' or 'master_admin').
  const { data: hrRows, error: hrErr } = await admin
    .from("hr_users")
    .select("id, email, display_name, nickname, role")
    .eq("is_active", true);
  if (hrErr) return jsonResponse({ error: "db_hr_load", details: hrErr.message }, 500);

  const results: any[] = [];

  for (const hr of hrRows || []) {
    // Resolve override (id or email) first.
    const override = mapping[hr.id];
    let zUser: any | null = null;
    if (override) {
      zUser = zoomUsers.find((u) =>
        u.id === override || (u.email || "").toLowerCase() === override.toLowerCase()
      ) || null;
      if (!zUser) {
        // Try as a direct user-id lookup against Zoom in case it's not in the first page.
        const r = await zoomFetch(`/users/${encodeURIComponent(override)}`, { method: "GET" });
        if (r.ok) zUser = await r.json().catch(() => null);
      }
    }
    // Auto-match by email exact, then nickname/display_name fuzzy.
    if (!zUser) {
      zUser = zoomUsers.find((u) => (u.email || "").toLowerCase() === (hr.email || "").toLowerCase()) || null;
    }
    if (!zUser) {
      const wanted = [norm(hr.nickname), norm(hr.display_name)].filter(Boolean);
      zUser = zoomUsers.find((u) => {
        const first = norm(u.first_name);
        const last = norm(u.last_name);
        const display = norm(u.display_name);
        return wanted.some((w) =>
          w && (first.includes(w) || last.includes(w) || display.includes(w) ||
            w.includes(first) || w.includes(last))
        );
      }) || null;
    }

    if (!zUser) {
      results.push({
        hr_id: hr.id, hr_email: hr.email, nickname: hr.nickname,
        matched: false, reason: "no_zoom_user_found",
        candidates: zoomUsers.map((u) => ({ id: u.id, email: u.email, name: `${u.first_name || ""} ${u.last_name || ""}`.trim() })),
      });
      continue;
    }

    // Fetch full user (PMI + personal_meeting_url) and settings (PMI password).
    const fullRes = await zoomFetch(`/users/${encodeURIComponent(zUser.id)}`, { method: "GET" });
    const full: any = await fullRes.json().catch(() => ({}));
    if (!fullRes.ok) {
      results.push({ hr_id: hr.id, matched: false, reason: "user_fetch_failed", status: fullRes.status, details: full });
      continue;
    }

    let pmiPassword: string | null = null;
    const settingsRes = await zoomFetch(`/users/${encodeURIComponent(zUser.id)}/settings`, { method: "GET" });
    if (settingsRes.ok) {
      const settings: any = await settingsRes.json().catch(() => ({}));
      pmiPassword = settings?.schedule_meeting?.pmi_password
        || settings?.schedule_meeting?.default_password_for_scheduled_meetings
        || null;
    }

    const pmi = full.pmi != null ? String(full.pmi) : null;
    let personalMeetingUrl: string | null = full.personal_meeting_url || null;
    if (!personalMeetingUrl && pmi) {
      // Last-resort construct (matches Zoom's standard PMR URL pattern).
      personalMeetingUrl = `https://zoom.us/j/${pmi}`;
    }

    // Single-row update by exact id (DATA OWNERSHIP / SAFETY).
    const { error: upErr } = await admin.from("hr_users").update({
      personal_meeting_url: personalMeetingUrl,
      personal_meeting_password: pmiPassword,
      zoom_pmi: pmi,
      zoom_user_id: full.id || zUser.id,
      zoom_user_email: full.email || zUser.email || null,
    }).eq("id", hr.id);

    if (upErr) {
      results.push({ hr_id: hr.id, matched: true, reason: "db_update_failed", details: upErr.message });
      continue;
    }

    results.push({
      hr_id: hr.id, hr_email: hr.email, nickname: hr.nickname,
      matched: true,
      zoom_user_id: full.id || zUser.id,
      zoom_user_email: full.email || zUser.email,
      pmi, personal_meeting_url: personalMeetingUrl,
      personal_meeting_password: pmiPassword ? "***set***" : null,
    });
  }

  return jsonResponse({ success: true, results });
});
