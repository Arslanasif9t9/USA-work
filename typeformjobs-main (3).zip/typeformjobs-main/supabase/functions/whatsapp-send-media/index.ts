// whatsapp-send-media: HR-authenticated. Sends an IMAGE or DOCUMENT (by public
// URL) via the Meta WhatsApp Cloud API (graph.facebook.com) and logs the
// outbound row to public.whatsapp_messages.
//
// FULLY INDEPENDENT of the ElevenLabs Sylvia path — no shared imports from
// _shared/elevenlabs-sylvia.ts. Uses the same HR auth pattern as launch-sylvia /
// send-round-invite (requireHr from _shared/hr-auth.ts).
import { adminClient, corsHeaders, json, requireHr } from "../_shared/hr-auth.ts";

const WHATSAPP_PHONE_NUMBER_ID = Deno.env.get("WHATSAPP_PHONE_NUMBER_ID")!;
const WHATSAPP_ACCESS_TOKEN = Deno.env.get("WHATSAPP_ACCESS_TOKEN")!;

// LOCAL phone normalizer — do NOT import from _shared/elevenlabs-sylvia.ts.
function normalizePhone(input: string): string | null {
  const digits = (input || "").replace(/\D/g, "");
  if (digits.length < 8 || digits.length > 15) return null;
  return digits;
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });
  if (req.method !== "POST") return json({ error: "method_not_allowed" }, 405);

  const ident = await requireHr(req);
  if (ident instanceof Response) return ident;

  try {
    const body = await req.json().catch(() => ({}));
    const toRaw: string = typeof body?.to === "string" ? body.to : "";
    const mediaUrl: string = typeof body?.media_url === "string" ? body.media_url.trim() : "";
    const type: string = typeof body?.type === "string" ? body.type.trim() : "";
    const caption: string = typeof body?.caption === "string" ? body.caption.trim() : "";
    const filename: string = typeof body?.filename === "string" ? body.filename.trim() : "";

    const to = normalizePhone(toRaw);
    if (!to) return json({ error: "invalid_phone", detail: "Phone must be 8-15 digits" }, 400);
    if (!mediaUrl) return json({ error: "media_url_required" }, 400);
    if (type !== "image" && type !== "document") {
      return json({ error: "invalid_type", detail: "type must be 'image' or 'document'" }, 400);
    }
    if (!WHATSAPP_PHONE_NUMBER_ID || !WHATSAPP_ACCESS_TOKEN) {
      return json({ error: "whatsapp_not_configured" }, 500);
    }

    // Build the media payload. `filename` is only valid for documents.
    const mediaPayload: Record<string, unknown> = { link: mediaUrl };
    if (caption) mediaPayload.caption = caption;
    if (type === "document" && filename) mediaPayload.filename = filename;

    const url = `https://graph.facebook.com/v21.0/${WHATSAPP_PHONE_NUMBER_ID}/messages`;
    const metaRes = await fetch(url, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${WHATSAPP_ACCESS_TOKEN}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        messaging_product: "whatsapp",
        to,
        type,
        [type]: mediaPayload,
      }),
    });

    const metaJson = await metaRes.json().catch(() => ({}));

    // On failure, surface the ACTUAL Meta error JSON — never fake success.
    if (!metaRes.ok) {
      return json({ error: "meta_send_failed", meta: metaJson }, metaRes.status);
    }

    const waMessageId: string | null = metaJson?.messages?.[0]?.id ?? null;

    const admin = adminClient();
    await admin.from("whatsapp_messages").insert({
      direction: "outbound",
      wa_message_id: waMessageId,
      phone: to,
      type,
      body: caption || null,
      media_url: mediaUrl,
      status: "sent",
      raw: metaJson,
    });

    return json({ ok: true, meta: metaJson });
  } catch (e: any) {
    return json({ error: "unexpected", detail: String(e?.message || e) }, 500);
  }
});
