// purge-candidate-completely: the ONLY true destroy. Permanently deletes one OR
// many candidates by response_id — works on ANY candidate (active, booked,
// terminated, disqualified, never-touched). NO round_stage guard.
// Scoped cleanup, no CASCADE: clears interview_slots.response_id, deletes
// email_log (by candidate_id), candidate_actions (by response_id + candidate_id),
// job_offers + nda_signatures for that candidate, answers, then the responses row.
// Removes storage files (resume/selfie/signed PDFs). Single-row writes by id.
import { createClient } from "npm:@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
const ANON = Deno.env.get("SUPABASE_ANON_KEY")!;
const SERVICE = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;

const STORAGE_BUCKETS = ["resumes", "selfies", "candidate-selfies", "candidate-files", "offer-letters", "signed-archive"];

function parseStorageUrl(url: string | null | undefined): { bucket: string; path: string } | null {
  if (!url) return null;
  for (const b of STORAGE_BUCKETS) {
    const idx = url.indexOf(`/object/public/${b}/`);
    if (idx !== -1) return { bucket: b, path: decodeURIComponent(url.slice(idx + `/object/public/${b}/`.length).split("?")[0]) };
    const idx2 = url.indexOf(`/object/sign/${b}/`);
    if (idx2 !== -1) return { bucket: b, path: decodeURIComponent(url.slice(idx2 + `/object/sign/${b}/`.length).split("?")[0]) };
    const idx3 = url.indexOf(`/${b}/`);
    if (idx3 !== -1) return { bucket: b, path: decodeURIComponent(url.slice(idx3 + b.length + 2).split("?")[0]) };
  }
  return null;
}

async function purgeOne(admin: ReturnType<typeof createClient>, responseId: string): Promise<{ ok: boolean; error?: string }> {
  // Load the response by exact id (NO stage guard — any candidate may be purged).
  const { data: resp } = await admin
    .from("responses")
    .select("id, applicant_id, scheduled_slot_id")
    .eq("id", responseId)
    .maybeSingle();
  if (!resp) return { ok: false, error: "not_found" };

  const candId = (resp as any).applicant_id as string | null;
  const files: { bucket: string; path: string }[] = [];

  // Gather files from answers BEFORE deleting.
  const { data: ans } = await admin.from("answers").select("file_url").eq("response_id", responseId);
  for (const a of ans || []) {
    const fp = parseStorageUrl((a as any).file_url);
    if (fp) files.push(fp);
  }

  // Gather job_offers + nda_signatures for this candidate (files + ids).
  let offerIds: string[] = [];
  if (candId) {
    const { data: offers } = await admin
      .from("job_offers")
      .select("id, signed_pdf_url, archived_pdf_url")
      .eq("candidate_id", candId);
    for (const o of offers || []) {
      offerIds.push((o as any).id);
      for (const u of [(o as any).signed_pdf_url, (o as any).archived_pdf_url]) {
        const fp = parseStorageUrl(u);
        if (fp) files.push(fp);
      }
    }
  }
  // nda_signatures by response_id (and gather their PDFs).
  const { data: ndas } = await admin
    .from("nda_signatures")
    .select("id, signed_pdf_url, archived_pdf_url")
    .eq("response_id", responseId);
  for (const n of ndas || []) {
    for (const u of [(n as any).signed_pdf_url, (n as any).archived_pdf_url]) {
      const fp = parseStorageUrl(u);
      if (fp) files.push(fp);
    }
  }

  // 1. Clear interview_slots link(s).
  await admin.from("interview_slots").update({ response_id: null }).eq("response_id", responseId);
  if ((resp as any).scheduled_slot_id) {
    await admin.from("interview_slots").update({ response_id: null }).eq("id", (resp as any).scheduled_slot_id);
  }
  // 2. email_log (scoped to this candidate / their offers).
  if (candId) await admin.from("email_log").delete().eq("candidate_id", candId);
  if (offerIds.length) await admin.from("email_log").delete().in("job_offer_id", offerIds);
  // 3. candidate_actions (by response and candidate).
  // Belt-and-braces: stop the recover-reminder cron from ever picking this
  // candidate up — set the opt-out true before deleting the row.
  await admin.from("candidate_actions").update({ recover_reminder_opt_out: true }).eq("response_id", responseId);
  await admin.from("candidate_actions").delete().eq("response_id", responseId);
  if (candId) await admin.from("candidate_actions").delete().eq("candidate_id", candId);
  // 4. nda_signatures for this candidate.
  await admin.from("nda_signatures").delete().eq("response_id", responseId);
  // 5. job_offers for this candidate.
  if (candId) await admin.from("job_offers").delete().eq("candidate_id", candId);
  // 6. answers (scoped to this response).
  await admin.from("answers").delete().eq("response_id", responseId);
  // 6b. belt-and-braces: explicitly expire any active rebook_tokens (Christine/Marissa
  //     interview links) for this response_id BEFORE deleting the response row, so an
  //     active link can never outlive the candidate. Single scope, no CASCADE.
  {
    const nowIso = new Date().toISOString();
    const expiredIso = new Date(Date.now() - 1000).toISOString();
    await admin
      .from("rebook_tokens")
      .update({ expires_at: expiredIso, used_at: nowIso })
      .eq("response_id", responseId)
      .is("used_at", null)
      .gt("expires_at", nowIso);
  }
  // 7. finally the response row itself — single row by id.
  const { error: delErr } = await admin.from("responses").delete().eq("id", responseId);
  if (delErr) return { ok: false, error: delErr.message };

  // 8. storage cleanup (best-effort).
  const grouped: Record<string, string[]> = {};
  for (const f of files) (grouped[f.bucket] = grouped[f.bucket] || []).push(f.path);
  for (const [bucket, paths] of Object.entries(grouped)) {
    if (paths.length) await admin.storage.from(bucket).remove(paths).catch(() => {});
  }

  return { ok: true };
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });
  try {
    const authHeader = req.headers.get("Authorization");
    if (!authHeader?.startsWith("Bearer ")) {
      return new Response(JSON.stringify({ error: "unauthorized" }), { status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }
    const userClient = createClient(SUPABASE_URL, ANON, { global: { headers: { Authorization: authHeader } } });
    const { data: userData, error: uErr } = await userClient.auth.getUser();
    if (uErr || !userData?.user) {
      return new Response(JSON.stringify({ error: "unauthorized" }), { status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }
    const admin = createClient(SUPABASE_URL, SERVICE);

    const body = await req.json().catch(() => ({}));
    const ids: string[] = [];
    if (typeof body?.response_id === "string") ids.push(body.response_id);
    if (Array.isArray(body?.response_ids)) {
      for (const x of body.response_ids) if (typeof x === "string") ids.push(x);
    }
    const unique = Array.from(new Set(ids));
    if (!unique.length) {
      return new Response(JSON.stringify({ error: "invalid_request" }), { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }

    let ok = 0;
    const failures: { id: string; error: string }[] = [];
    for (const rid of unique) {
      const res = await purgeOne(admin, rid);
      if (res.ok) ok++; else failures.push({ id: rid, error: res.error || "unknown" });
    }

    return new Response(JSON.stringify({ ok: failures.length === 0, deleted: ok, failures }), {
      status: 200,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (e) {
    return new Response(JSON.stringify({ error: (e as Error).message }), { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } });
  }
});
