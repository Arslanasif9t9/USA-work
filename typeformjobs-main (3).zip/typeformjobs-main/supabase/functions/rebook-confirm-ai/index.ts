// rebook-confirm-ai: AI-scheduled booking confirmation wrapper.
// Validates the booking token, books the slot via book-slot-ai (no Zoom),
// mints a SEPARATE ai_scheduled rebook_token for the Christine link,
// marks the original booking token used, and fires the AI confirmation email.
import { createClient } from "npm:@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};
const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
const SERVICE = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
const json = (b: unknown, s = 200) =>
  new Response(JSON.stringify(b), { status: s, headers: { ...corsHeaders, "Content-Type": "application/json" } });

function genToken() {
  const bytes = crypto.getRandomValues(new Uint8Array(24));
  return Array.from(bytes).map((b) => b.toString(16).padStart(2, "0")).join("");
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });
  try {
    const { token, slot_id } = await req.json();
    if (!token || !slot_id) return json({ error: "missing_fields" }, 400);
    const admin = createClient(SUPABASE_URL, SERVICE);

    // 1. Validate booking token (identical to rebook-confirm).
    const { data: tok } = await admin.from("rebook_tokens").select("*").eq("token", token).maybeSingle();
    if (!tok) return json({ error: "invalid_token" }, 404);
    if (tok.used_at) return json({ error: "token_used" }, 410);
    if (new Date(tok.expires_at) < new Date()) return json({ error: "token_expired" }, 410);

    // 2. Book via book-slot-ai (no Zoom).
    const bookRes = await fetch(`${SUPABASE_URL}/functions/v1/book-slot-ai`, {
      method: "POST",
      headers: { "Content-Type": "application/json", Authorization: `Bearer ${SERVICE}` },
      body: JSON.stringify({
        slot_id,
        response_id: tok.response_id,
        candidate_name: tok.candidate_name,
        candidate_email: tok.candidate_email,
        assigned_hr_id: tok.assigned_hr_id ?? null,
      }),
    });
    const bookData = await bookRes.json().catch(() => ({}));
    if (!bookRes.ok || !bookData?.success) {
      return json(bookData?.error ? bookData : { error: "book_failed", details: bookData }, bookRes.status || 500);
    }
    const slot_start: string = bookData.slot_start;

    // 3. Mint a SEPARATE ai_scheduled token for the Christine link.
    const aiToken = genToken();
    const expiresAt = new Date(new Date(slot_start).getTime() + 2 * 60 * 60 * 1000).toISOString();
    const { error: tokInsErr } = await admin.from("rebook_tokens").insert({
      token: aiToken,
      response_id: tok.response_id,
      stage: "ai_scheduled",
      form_id: tok.form_id,
      assigned_hr_id: tok.assigned_hr_id ?? null,
      candidate_name: tok.candidate_name,
      candidate_email: tok.candidate_email,
      expires_at: expiresAt,
    });
    if (tokInsErr) {
      return json({ error: "token_persist_failed", details: tokInsErr.message }, 500);
    }
    const { data: tokCheck } = await admin
      .from("rebook_tokens")
      .select("token")
      .eq("token", aiToken)
      .maybeSingle();
    if (!tokCheck) return json({ error: "token_not_persisted" }, 500);

    // 4. Mark original booking token used.
    await admin.from("rebook_tokens").update({
      used_at: new Date().toISOString(),
      new_slot_id: slot_id,
    }).eq("id", tok.id);

    // 5. Fire-and-forget AI confirmation email.
    // Do not forward Origin — the downstream function builds links on the fixed
    // public domain so links never resolve to a login-gated preview origin.
    fetch(`${SUPABASE_URL}/functions/v1/send-ai-interview-confirmed-email`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${SERVICE}`,
      },
      body: JSON.stringify({
        response_id: tok.response_id,
        token: aiToken,
        slot_start,
      }),
    }).catch(() => { /* fire-and-forget */ });

    return json({ success: true, slot_id, slot_start, ai_token: aiToken });
  } catch (e: any) {
    return json({ error: "internal", details: String(e?.message || e) }, 500);
  }
});
