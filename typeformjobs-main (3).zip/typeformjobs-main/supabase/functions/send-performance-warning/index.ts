// send-performance-warning: HR-authenticated. Password-gated. Sends a polite-but-
// serious performance warning email to ANY recipient (employee or not). Logs to
// email_log. Optional response_id ties the log to a candidate. Optional remarks
// block is appended only when provided.
import { adminClient, corsHeaders, json, requireHr } from "../_shared/hr-auth.ts";

const RESEND_API_KEY = Deno.env.get("RESEND_API_KEY")!;
const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const ADMIN_PW = "Angel2828";

const FROM_NAME = "Expert Intuitive Advisor — Human Resources";
const FROM_ADDRESS = "talent@expertintuitiveadvisor.com";

const htmlEscape = (s: string) =>
  s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;")
   .replace(/"/g, "&quot;").replace(/'/g, "&#39;");

function todayFormatted(): string {
  return new Date().toLocaleDateString("en-US", { year: "numeric", month: "long", day: "numeric" });
}

function buildHtml(name: string, remarks: string) {
  const year = new Date().getFullYear();
  const safeName = htmlEscape(name) || "there";
  const date = todayFormatted();

  const remarksBlock = remarks
    ? `<tr><td style="padding:8px 48px 8px 48px;">
        <div style="background:#faf8f3;border-left:4px solid #b08d57;border-radius:4px;padding:16px 20px;margin:8px 0 8px 0;">
          <div style="font-family:'Inter',Arial,sans-serif;font-weight:600;font-size:14px;color:#1a2547;margin-bottom:8px;">Remarks:</div>
          <div style="font-family:'Inter',Arial,sans-serif;font-size:14px;line-height:1.6;color:#1a2547;">${htmlEscape(remarks).replace(/\n/g, "<br/>")}</div>
        </div>
      </td></tr>`
    : "";

  return `<!doctype html><html><body style="margin:0;padding:0;background:#faf8f3;font-family:'Inter',Arial,sans-serif;color:#1a2547;">
  <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background:#faf8f3;padding:40px 16px;">
    <tr><td align="center">
      <table role="presentation" width="600" cellpadding="0" cellspacing="0" style="max-width:600px;background:#ffffff;border:1px solid #e6e0d1;border-radius:6px;overflow:hidden;">
        <tr><td style="padding:36px 48px 24px 48px;text-align:center;">
          <div style="font-family:'Cormorant Garamond',Georgia,serif;font-weight:600;font-size:28px;letter-spacing:6px;color:#1a2547;">EIA</div>
          <div style="font-family:'Inter',Arial,sans-serif;font-size:10px;letter-spacing:2px;text-transform:uppercase;color:#b08d57;margin-top:6px;">Expert Intuitive Advisor Inc.</div>
          <div style="height:1px;background:#b08d57;width:60px;margin:20px auto 0;"></div>
        </td></tr>
        <tr><td style="padding:8px 48px 8px 48px;text-align:center;">
          <div style="font-family:'Cormorant Garamond',Georgia,serif;font-size:20px;color:#1a2547;font-style:italic;">Important — Please Read Before Your Next Shift</div>
        </td></tr>
        <tr><td style="padding:28px 48px 8px 48px;font-family:'Inter',Arial,sans-serif;font-size:15px;line-height:1.7;color:#1a2547;">
          <p style="margin:0 0 16px 0;">Dear ${safeName},</p>
          <p style="margin:0 0 16px 0;">We hope this message finds you well. Thank you for the work you have been putting into your role at Expert Intuitive Advisor.</p>
          <p style="margin:0 0 16px 0;">We are writing to share that some concerns have come to our attention regarding your recent performance. We take these matters seriously, and we believe in addressing them through open and honest conversation rather than assumptions.</p>
          <p style="margin:0 0 16px 0;">Before your next shift, we ask that you please reach out to your boss directly to discuss this matter. <strong>Please do not log in or begin your next shift until this conversation has taken place.</strong> This is important so we can understand the situation together and find the right way forward.</p>
          <p style="margin:0 0 16px 0;">Failure to discuss this before resuming your shifts may lead to further action, which we would like to avoid. We want to give you every opportunity to address what has come up and continue your journey with us.</p>
          <p style="margin:0 0 16px 0;">Please treat this message with the seriousness it deserves. We value you, and we want this to work out.</p>
        </td></tr>
        ${remarksBlock}
        <tr><td style="padding:8px 48px 8px 48px;font-family:'Inter',Arial,sans-serif;font-size:15px;line-height:1.7;color:#1a2547;">
          <p style="margin:16px 0 4px 0;">Warm regards,</p>
          <p style="margin:0;font-weight:600;">HR — Expert Intuitive Advisor Inc.</p>
          <p style="margin:4px 0 0 0;color:#6b6655;">${date}</p>
        </td></tr>
        <tr><td style="padding:20px 48px 32px 48px;">
          <div style="height:1px;background:#e6e0d1;margin-bottom:16px;"></div>
          <div style="font-family:'Inter',Arial,sans-serif;font-size:11px;color:#9a9588;text-align:center;">&copy; ${year} Expert Intuitive Advisor Inc.</div>
        </td></tr>
      </table>
    </td></tr>
  </table>
</body></html>`;
}

function buildText(name: string, remarks: string) {
  const safeName = name || "there";
  const date = todayFormatted();
  const remarksBlock = remarks ? `\nRemarks:\n${remarks}\n` : "";
  return `Important — Please Read Before Your Next Shift

Dear ${safeName},

We hope this message finds you well. Thank you for the work you have been putting into your role at Expert Intuitive Advisor.

We are writing to share that some concerns have come to our attention regarding your recent performance. We take these matters seriously, and we believe in addressing them through open and honest conversation rather than assumptions.

Before your next shift, we ask that you please reach out to your boss directly to discuss this matter. Please do not log in or begin your next shift until this conversation has taken place. This is important so we can understand the situation together and find the right way forward.

Failure to discuss this before resuming your shifts may lead to further action, which we would like to avoid. We want to give you every opportunity to address what has come up and continue your journey with us.

Please treat this message with the seriousness it deserves. We value you, and we want this to work out.
${remarksBlock}
Warm regards,
HR — Expert Intuitive Advisor Inc.
${date}`;
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });

  const ident = await requireHr(req);
  if (ident instanceof Response) return ident;

  try {
    const body = await req.json().catch(() => ({}));
    const password: string = typeof body?.password === "string" ? body.password : "";
    if (password !== ADMIN_PW) return json({ error: "wrong password" }, 403);

    const recipientEmail: string = typeof body?.recipient_email === "string" ? body.recipient_email.trim() : "";
    const recipientName: string = typeof body?.recipient_name === "string" ? body.recipient_name.trim() : "";
    let remarks: string = typeof body?.remarks === "string" ? body.remarks.trim() : "";
    const responseId: string | null = typeof body?.response_id === "string" && body.response_id ? body.response_id : null;

    if (!recipientEmail || !EMAIL_RE.test(recipientEmail)) {
      return json({ error: "invalid recipient email" }, 400);
    }
    if (!recipientName) return json({ error: "recipient name required" }, 400);
    if (remarks.length > 1000) remarks = remarks.slice(0, 1000);

    const admin = adminClient();

    let candidateId: string | null = null;
    if (responseId) {
      const { data: r } = await admin
        .from("responses").select("applicant_id").eq("id", responseId).maybeSingle();
      candidateId = (r as any)?.applicant_id ?? null;
    }

    const subject = "Important — Please Read Before Your Next Shift";
    const html = buildHtml(recipientName, remarks);
    const text = buildText(recipientName, remarks);

    let emailOk = false;
    let resendId: string | null = null;
    let errorMessage: string | null = null;
    try {
      const r = await fetch("https://api.resend.com/emails", {
        method: "POST",
        headers: { "Content-Type": "application/json", Authorization: `Bearer ${RESEND_API_KEY}` },
        body: JSON.stringify({
          from: `${FROM_NAME} <${FROM_ADDRESS}>`,
          to: [recipientEmail],
          subject, html, text,
        }),
      });
      const j = await r.json().catch(() => ({}));
      emailOk = r.ok;
      resendId = j?.id ?? null;
      if (!r.ok) errorMessage = JSON.stringify(j).slice(0, 500);
    } catch (e: any) {
      errorMessage = String(e?.message || e);
    }

    await admin.from("email_log").insert({
      candidate_id: candidateId,
      stage: "performance_warning",
      sender: "resend",
      from_address: FROM_ADDRESS,
      from_name: FROM_NAME,
      to_address: recipientEmail,
      subject,
      status: emailOk ? "sent" : "failed",
      sent_at: emailOk ? new Date().toISOString() : null,
      resend_message_id: resendId,
      error_message: emailOk ? null : errorMessage,
    });

    if (!emailOk) return json({ ok: false, error: "send failed", details: errorMessage }, 500);
    return json({ ok: true, resend_id: resendId });
  } catch (e: any) {
    return json({ ok: false, error: "unexpected", details: String(e?.message || e) }, 500);
  }
});
