// backfill-pmr-bookings: admin-only. One-shot — rewrites every UPCOMING booked
// interview_slot so its zoom_meetings row points to the assigned HR's PMR (Personal
// Meeting Room) instead of a per-meeting Zoom URL. Then re-sends the candidate
// confirmation email (which embeds the updated link + a fresh .ics).
//
// Safety:
//  - single-row updates by exact zoom_meetings.id
//  - never touches `answers`
//  - skips any booking whose claimed HR has no PMR configured
//  - re-emails are fire-and-forget so one failure doesn't stop the loop
import { adminClient, corsHeaders, jsonResponse, requireAdmin } from "../_shared/zoom.ts";

const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
const SERVICE_KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });
  const guard = await requireAdmin(req);
  if (guard instanceof Response) return guard;

  let body: { dry_run?: boolean; resend_emails?: boolean } = {};
  try { body = (await req.json()) ?? {}; } catch { body = {}; }
  const dryRun = body.dry_run === true;
  const resendEmails = body.resend_emails !== false; // default true

  const admin = adminClient();

  // Load HR PMR map.
  const { data: hrs } = await admin
    .from("hr_users")
    .select("id, personal_meeting_url, personal_meeting_password, zoom_pmi");
  const hrMap = new Map<string, any>();
  for (const h of hrs || []) hrMap.set(h.id, h);

  // Fallback HR (first one with a PMR configured).
  const fallbackHr = (hrs || []).find((h: any) => h.personal_meeting_url) || null;

  // All upcoming booked slots.
  const { data: slots, error } = await admin
    .from("interview_slots")
    .select("id, slot_start, response_id, zoom_meeting_id, claimed_by_hr_id")
    .eq("status", "booked")
    .gt("slot_start", new Date().toISOString())
    .order("slot_start", { ascending: true });
  if (error) return jsonResponse({ error: "load_slots_failed", details: error.message }, 500);

  const results: any[] = [];
  for (const s of slots || []) {
    const row: any = {
      slot_id: s.id,
      slot_start: s.slot_start,
      response_id: s.response_id,
      claimed_by_hr_id: s.claimed_by_hr_id,
      zoom_meeting_row_id: s.zoom_meeting_id,
    };

    if (!s.zoom_meeting_id) { row.action = "skip_no_zoom_row"; results.push(row); continue; }

    let hr = s.claimed_by_hr_id ? hrMap.get(s.claimed_by_hr_id) : null;
    if (!hr || !hr.personal_meeting_url) hr = fallbackHr;
    if (!hr || !hr.personal_meeting_url) {
      row.action = "skip_no_pmr_for_hr";
      results.push(row);
      continue;
    }
    row.using_hr_id = hr.id;
    row.new_join_url = hr.personal_meeting_url;

    if (dryRun) { row.action = "dry_run"; results.push(row); continue; }

    // Single-row update by exact zoom_meetings.id. Use unique synthetic id per row
    // because zoom_meeting_id has a UNIQUE constraint and PMI is shared across all bookings.
    const { error: upErr } = await admin
      .from("zoom_meetings")
      .update({
        zoom_meeting_id: `pmr-${hr.zoom_pmi || hr.id}-${s.id}`,
        join_url: hr.personal_meeting_url,
        password: hr.personal_meeting_password || null,
        start_url: null,
        status: "scheduled",
        last_synced_at: new Date().toISOString(),
      })
      .eq("id", s.zoom_meeting_id);
    if (upErr) {
      row.action = "update_failed";
      row.error = upErr.message;
      results.push(row);
      continue;
    }
    row.action = "updated";

    // Also mirror into candidate_actions if a round1/round2 row exists for this response.
    if (s.response_id) {
      const { data: ca } = await admin
        .from("candidate_actions")
        .select("id, round1_zoom_meeting_id, round2_zoom_meeting_id")
        .eq("response_id", s.response_id)
        .maybeSingle();
      if (ca) {
        const patch: Record<string, any> = {};
        if (ca.round1_zoom_meeting_id) {
          patch.round1_zoom_join_url = hr.personal_meeting_url;
          patch.round1_zoom_meeting_id = hr.zoom_pmi || `pmr-${hr.id}`;
        }
        if (ca.round2_zoom_meeting_id) {
          patch.round2_zoom_join_url = hr.personal_meeting_url;
          patch.round2_zoom_meeting_id = hr.zoom_pmi || `pmr-${hr.id}`;
        }
        if (Object.keys(patch).length) {
          await admin.from("candidate_actions").update(patch).eq("id", ca.id);
        }
      }

      // Re-send confirmation email (fire-and-forget).
      if (resendEmails) {
        // Fire-and-forget so 31 sequential emails don't blow the gateway timeout.
        fetch(`${SUPABASE_URL}/functions/v1/send-interview-confirmed-email`, {
          method: "POST",
          headers: { Authorization: `Bearer ${SERVICE_KEY}`, "Content-Type": "application/json" },
          body: JSON.stringify({ response_id: s.response_id }),
        }).catch(() => {});
        row.email_status = "queued";
      }
    }

    results.push(row);
  }

  const summary = {
    total: results.length,
    updated: results.filter((r) => r.action === "updated").length,
    skipped: results.filter((r) => r.action?.startsWith("skip")).length,
    failed: results.filter((r) => r.action === "update_failed").length,
  };
  return jsonResponse({ success: true, dry_run: dryRun, summary, results });
});
