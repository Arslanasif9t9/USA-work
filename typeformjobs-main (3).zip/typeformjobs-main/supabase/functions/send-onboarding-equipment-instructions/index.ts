// send-onboarding-equipment-instructions: invoked by the SignFlow webhook
// after the NDA is signed. Sends the candidate the equipment + onboarding
// pre-start checklist. Service-role only (called server-to-server).
import { createClient } from "npm:@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
const SVC = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;

const json = (b: unknown, status = 200) =>
  new Response(JSON.stringify(b), {
    status,
    headers: { ...corsHeaders, "content-type": "application/json" },
  });

function buildSenderA(firstName: string) {
  const text = `Hi ${firstName},

Thank you for signing your NDA — that's an important step done!

Now, to get ready for your start date, please make sure you have the following in place:

  • Install WhatsApp on your phone
  • Make sure you have a stable Wi-Fi connection
  • Make sure you have a working laptop or computer
  • Make sure you have good, reliable internet

Our onboarding specialist Sylvia will reach out to guide you through your first steps. Welcome to the team.

Angela Stein
HR — Talent Manager
Expert Intuitive Advisor Inc.`;
  const html = `<div style="font-family:Arial,sans-serif;font-size:14px;color:#1a2236;line-height:1.6;max-width:600px">
<p>Hi ${firstName},</p>
<p>Thank you for signing your NDA — that's an important step done!</p>
<p>Now, to get ready for your start date, please make sure you have the following in place:</p>
<ul>
  <li>Install WhatsApp on your phone</li>
  <li>Make sure you have a stable Wi-Fi connection</li>
  <li>Make sure you have a working laptop or computer</li>
  <li>Make sure you have good, reliable internet</li>
</ul>
<p>Our onboarding specialist <strong>Sylvia</strong> will reach out to guide you through your first steps. Welcome to the team.</p>
<p>Angela Stein<br/>HR — Talent Manager<br/>Expert Intuitive Advisor Inc.</p>
</div>`;
  return {
    from_name: "Angela Stein / HR — Talent Manager",
    from_address: "talent@expertintuitiveadvisor.com",
    subject: "Your NDA is signed — next steps to get set up",
    html_body: html,
    text_body: text,
  };
}
function buildSenderB(firstName: string) {
  const text = `Hi ${firstName},

Welcome aboard 🎉 — just a quick heads up that Sylvia will reach out separately on WhatsApp to walk you through your first days.

Make sure WhatsApp is installed and you're ready with a stable laptop + internet before your start date.

— Angela Stein`;
  const html = `<div style="font-family:Arial,sans-serif;font-size:14px;color:#1a2236;line-height:1.6;max-width:600px">
<p>Hi ${firstName},</p>
<p>Welcome aboard 🎉 — just a quick heads up that Sylvia will reach out separately on WhatsApp to walk you through your first days.</p>
<p>Make sure WhatsApp is installed and you're ready with a stable laptop + internet before your start date.</p>
<p>— Angela Stein</p>
</div>`;
  return {
    from_name: "Angela Stein",
    from_address: "expertintuitiveadvisor@gmail.com",
    subject: "Welcome to EIA — quick onboarding heads up",
    html_body: html,
    text_body: text,
  };
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });
  if (req.method !== "POST") return json({ ok: false, reason: "method_not_allowed" }, 405);

  // Service-role only (called by signflow-webhook-receiver server-to-server)
  const auth = req.headers.get("Authorization") || "";
  const tok = auth.replace("Bearer ", "").trim();
  if (!tok || tok !== SVC) return json({ ok: false, reason: "unauthorized" }, 401);

  let body: { response_id?: string };
  try { body = await req.json(); } catch { return json({ ok: false, reason: "invalid_json" }, 400); }
  const { response_id } = body || {};
  if (!response_id) return json({ ok: false, reason: "missing_response_id" }, 400);

  const admin = createClient(SUPABASE_URL, SVC);

  // Resolve email + name (same priority order as send-nda)
  const { data: resp } = await admin
    .from("responses").select("id, applicant_id, override_email").eq("id", response_id).maybeSingle();
  if (!resp) return json({ ok: false, reason: "response_not_found" }, 404);

  let email = ((resp as any).override_email || "").trim();
  let name = "";
  if ((resp as any).applicant_id) {
    const { data: off } = await admin
      .from("job_offers").select("candidate_name, candidate_email")
      .eq("candidate_id", (resp as any).applicant_id)
      .order("created_at", { ascending: false }).limit(1).maybeSingle();
    if (off?.candidate_name) name = off.candidate_name;
    if (!email && off?.candidate_email) email = off.candidate_email.trim();
  }
  if (!name || !email) {
    const { data: nda } = await admin
      .from("nda_signatures").select("signer_name, signer_email")
      .eq("response_id", response_id)
      .order("created_at", { ascending: false }).limit(1).maybeSingle();
    if (!name && nda?.signer_name) name = nda.signer_name;
    if (!email && nda?.signer_email) email = nda.signer_email;
  }
  if (!email) return json({ ok: false, reason: "no_email" }, 400);

  const firstName = (name || "there").trim().split(/\s+/)[0];

  try {
    const r = await fetch(`${SUPABASE_URL}/functions/v1/send-dual-email`, {
      method: "POST",
      headers: { Authorization: `Bearer ${SVC}`, "Content-Type": "application/json" },
      body: JSON.stringify({
        to: email,
        stage: "onboarding_equipment_instructions",
        sender_a: buildSenderA(firstName),
        sender_b: buildSenderB(firstName),
      }),
    });
    const j = await r.json().catch(() => ({}));
    if (!r.ok) return json({ ok: false, reason: "email_failed", detail: j }, 502);
  } catch (e) {
    return json({ ok: false, reason: "email_exception", detail: (e as Error).message }, 500);
  }

  return json({ ok: true });
});
