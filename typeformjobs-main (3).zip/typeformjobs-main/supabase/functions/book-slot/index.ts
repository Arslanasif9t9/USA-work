// book-slot: PUBLIC. Confirms reservation, creates Zoom meeting, marks slot booked.
import { createClient } from "npm:@supabase/supabase-js@2";
import { formatManilaDate, formatManilaTime } from "../_shared/manila.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
const SERVICE_KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
const UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });
  try {
  const admin = createClient(SUPABASE_URL, SERVICE_KEY);



  let body: any;
  try { body = await req.json(); } catch {
    return new Response(JSON.stringify({ error: "invalid_json" }), {
      status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
  const { slot_id, response_id, candidate_name, candidate_email, assigned_hr_id } = body || {};
  if (!slot_id || !UUID_RE.test(slot_id) || !response_id || !UUID_RE.test(response_id)) {
    return new Response(JSON.stringify({ error: "invalid_input" }), {
      status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }

  // Load slot & verify reservation
  const { data: slot } = await admin
    .from("interview_slots")
    .select("id, slot_start, status, reserved_until")
    .eq("id", slot_id)
    .maybeSingle();
  if (!slot) {
    return new Response(JSON.stringify({ error: "slot_not_found" }), {
      status: 404, headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
  if (slot.status !== "reserved" || !slot.reserved_until || new Date(slot.reserved_until) < new Date()) {
    return new Response(JSON.stringify({ error: "slot_expired", code: "reservation_lost" }), {
      status: 409, headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }

  const name = (candidate_name || "Candidate").toString().slice(0, 100);
  const email = (candidate_email || "").toString();

  // ── Resolve which HR's PMR (Personal Meeting Room) to use ──────────────────
  // Priority: explicit body → most recent rebook_token for this response with
  //   assigned_hr_id set → first active HR row that has a PMR configured.
  let chosenHrId: string | null =
    (typeof assigned_hr_id === "string" && UUID_RE.test(assigned_hr_id)) ? assigned_hr_id : null;
  if (!chosenHrId) {
    const { data: tok } = await admin
      .from("rebook_tokens")
      .select("assigned_hr_id, created_at")
      .eq("response_id", response_id)
      .not("assigned_hr_id", "is", null)
      .order("created_at", { ascending: false })
      .limit(1)
      .maybeSingle();
    if (tok?.assigned_hr_id) chosenHrId = tok.assigned_hr_id as string;
  }

  let hrPmr: {
    id: string; personal_meeting_url: string | null; personal_meeting_password: string | null;
    zoom_pmi: string | null;
  } | null = null;
  if (chosenHrId) {
    const { data: hr } = await admin
      .from("hr_users")
      .select("id, personal_meeting_url, personal_meeting_password, zoom_pmi")
      .eq("id", chosenHrId)
      .maybeSingle();
    if (hr) hrPmr = hr as any;
  }
  if (!hrPmr || !hrPmr.personal_meeting_url) {
    const { data: fallback } = await admin
      .from("hr_users")
      .select("id, personal_meeting_url, personal_meeting_password, zoom_pmi")
      .eq("is_active", true)
      .not("personal_meeting_url", "is", null)
      .order("created_at", { ascending: true })
      .limit(1)
      .maybeSingle();
    if (fallback?.personal_meeting_url) hrPmr = fallback as any;
  }

  let zoomMeetingId: string;
  let zoomJoinUrl: string;
  let zoomPassword: string | null;
  let zoomStartUrl: string | null = null;
  let zoomUuid: string | null = null;
  let zoomStartIso: string = slot.slot_start as unknown as string;
  // Outer-scope join URL valid on BOTH paths (PMR reuse + create-zoom).
  let resolvedZoomJoinUrl: string | null = null;

  if (hrPmr && hrPmr.personal_meeting_url) {
    // ✅ Reuse PMR — no Zoom API create call (no daily-limit consumption).
    zoomMeetingId = hrPmr.zoom_pmi || `pmr-${hrPmr.id}`;
    zoomJoinUrl = hrPmr.personal_meeting_url;
    resolvedZoomJoinUrl = hrPmr.personal_meeting_url;
    zoomPassword = hrPmr.personal_meeting_password || null;
  } else {
    // Fallback: legacy create-a-new-Zoom path (kept so the system still works
    // before setup-hr-pmr has been run, or if the chosen HR has no PMR yet).
    const ZOOM_ACCOUNT_ID = Deno.env.get("ZOOM_ACCOUNT_ID")!;
    const ZOOM_CLIENT_ID = Deno.env.get("ZOOM_CLIENT_ID")!;
    const ZOOM_CLIENT_SECRET = Deno.env.get("ZOOM_CLIENT_SECRET")!;
    const basic = btoa(`${ZOOM_CLIENT_ID}:${ZOOM_CLIENT_SECRET}`);
    const tokRes = await fetch("https://zoom.us/oauth/token", {
      method: "POST",
      headers: { Authorization: `Basic ${basic}`, "Content-Type": "application/x-www-form-urlencoded" },
      body: `grant_type=account_credentials&account_id=${encodeURIComponent(ZOOM_ACCOUNT_ID)}`,
    });
    const tokJson = await tokRes.json().catch(() => ({}));
    if (!tokRes.ok || !tokJson.access_token) {
      return new Response(JSON.stringify({ error: "zoom_token_failed", details: tokJson }), {
        status: 502, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }
    const zoomToken = tokJson.access_token;
    const zoomRes = await fetch("https://api.zoom.us/v2/users/me/meetings", {
      method: "POST",
      headers: { Authorization: `Bearer ${zoomToken}`, "Content-Type": "application/json" },
      body: JSON.stringify({
        topic: `EIA Interview - ${name}`,
        type: 2,
        start_time: new Date(slot.slot_start).toISOString().replace(/\.\d{3}Z$/, "Z"),
        duration: 30,
        timezone: "Asia/Manila",
        settings: {
          host_video: true, participant_video: true, join_before_host: false,
          mute_upon_entry: false, waiting_room: true, auto_recording: "none",
          approval_type: 2, audio: "both", meeting_authentication: false,
        },
      }),
    });
    const zoomJson = await zoomRes.json().catch(() => ({}));
    if (!zoomRes.ok) {
      return new Response(JSON.stringify({ error: "zoom_create_failed", details: zoomJson }), {
        status: 502, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }
    zoomMeetingId = String(zoomJson.id);
    zoomUuid = zoomJson.uuid ?? null;
    zoomJoinUrl = zoomJson.join_url;
    resolvedZoomJoinUrl = zoomJson.join_url ?? null;
    zoomPassword = zoomJson.password ?? null;
    zoomStartUrl = zoomJson.start_url ?? null;
    zoomStartIso = zoomJson.start_time || (slot.slot_start as unknown as string);
  }

  // Insert zoom_meetings row
  const { data: zmRow } = await admin.from("zoom_meetings").insert({
    zoom_meeting_id: zoomMeetingId,
    zoom_meeting_uuid: zoomUuid,
    topic: `EIA Interview - ${name}`,
    start_time: zoomStartIso,
    duration_minutes: 30,
    timezone: "Asia/Manila",
    join_url: zoomJoinUrl,
    password: zoomPassword,
    start_url: zoomStartUrl,
    status: "scheduled",
    last_synced_at: new Date().toISOString(),
  }).select("id").maybeSingle();

  // Atomically transition reserved -> booked
  const { data: bookedRows, error: bookErr } = await admin
    .from("interview_slots")
    .update({
      status: "booked",
      response_id,
      zoom_meeting_id: zmRow?.id ?? null,
      reserved_until: null,
    })
    .eq("id", slot_id)
    .eq("status", "reserved")
    .select("id");

  if (bookErr || !bookedRows || bookedRows.length === 0) {
    return new Response(JSON.stringify({ error: "book_failed", details: bookErr?.message }), {
      status: 409, headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }

  // Update responses (clear any prior cancellation flag on successful booking)
  await admin.from("responses").update({
    scheduled_slot_id: slot_id,
    scheduled_at: new Date().toISOString(),
    appointment_cancelled: false,
  }).eq("id", response_id);

  // Log notifications & fire (best-effort)
  const recipients = ["talent.expertadvisor@outlook.com", "spark11179@gmail.com"];
  for (const r of recipients) {
    await admin.from("notification_log").insert({
      event_type: "new_booking",
      recipient_email: r,
      related_resource_id: slot_id,
      status: "sent",
    });
  }

  // Fire-and-forget HR notification email
  fetch(`${SUPABASE_URL}/functions/v1/send-new-booking-notification`, {
    method: "POST",
    headers: { Authorization: `Bearer ${SERVICE_KEY}`, "Content-Type": "application/json" },
    body: JSON.stringify({ slot_id }),
  }).catch((e) => console.error("notify error", e));

  // Fire-and-forget CANDIDATE confirmation email (Zoom link + .ics)
  fetch(`${SUPABASE_URL}/functions/v1/send-interview-confirmed-email`, {
    method: "POST",
    headers: { Authorization: `Bearer ${SERVICE_KEY}`, "Content-Type": "application/json" },
    body: JSON.stringify({ response_id, fallback_join_url: resolvedZoomJoinUrl }),
  }).catch((e) => console.error("confirmation email error", e));

  const slotDate = new Date(slot.slot_start);
  return new Response(JSON.stringify({
    success: true,
    slot_id,
    zoom_join_url: resolvedZoomJoinUrl,
    slot_start: slot.slot_start,
    display_date: formatManilaDate(slotDate),
    display_time: formatManilaTime(slotDate),
  }), { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } });
  } catch (e: any) {
    return new Response(JSON.stringify({ error: "internal", details: String(e?.message || e) }), {
      status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
