// resend-termination-email: sends (or re-sends) the termination notice email
// for an already-terminated employee. Uses byte-identical wording to
// terminate-employee's evaluationEmail/regularEmail (copied verbatim below) so
// the recipient sees the exact same notice. Does NOT change employment_status.
import { createClient } from "npm:@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
const ANON = Deno.env.get("SUPABASE_ANON_KEY")!;
const SERVICE = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
const RESEND_API_KEY = Deno.env.get("RESEND_API_KEY")!;
const GMAIL_USER = (Deno.env.get("GMAIL_USER") ?? "").trim();
const BOSS_PASSWORD = Deno.env.get("BOSS_TERMINATION_PASSWORD") || "Boss2828";

const FROM_NAME = "Cathy Anderson";
const FROM_ADDRESS = "talent@expertintuitiveadvisor.com";
const HR_INBOX = "talent.expertadvisor@outlook.com";
const BOSS_INBOX = "spark11179@gmail.com";

const formatToday = () =>
  new Date().toLocaleDateString("en-US", { weekday: "long", year: "numeric", month: "long", day: "numeric" });

// === BYTE-IDENTICAL COPIES of terminate-employee's evaluationEmail / regularEmail ===
function evaluationEmail(name: string, title: string, today: string) {
  const subject = "Update on your position with Expert Intuitive Advisor Inc.";
  const text = `Dear ${name},\n\nThank you for the time and effort you've invested with Expert Intuitive Advisor Inc. as a ${title}.\n\nAfter careful review during the trial period, we've decided not to continue the engagement beyond this point. The trial period exists to assess fit on both sides, and at this time the role and your path here aren't quite the right match.\n\nThis decision is not a reflection of your character or potential. Many talented individuals find that a particular role or working arrangement isn't the ideal fit — that's exactly why the trial period exists.\n\nEffective ${today}, your engagement with EIA is concluded. Any compensation owed for verified work completed will be processed accordingly. If no work was completed, there is no balance owed.\n\nWe wish you the very best in your future endeavors.\n\nWith respect,\n\nCathy Anderson\nHiring Director\nExpert Intuitive Advisor Inc.`;
  const html = text.replace(/\n/g, "<br/>");
  return { subject, text, html };
}

function regularEmail(name: string, _title: string, _today: string) {
  const firstName = (name || "").trim().split(/\s+/)[0] || name;
  const subject = "Notice of Termination — Expert Intuitive Advisor Inc.";
  const text = `Dear ${firstName},\n\nWe are writing to formally inform you that you have been terminated from Expert Intuitive Advisor Inc., effective immediately. You will no longer be working with the company in any capacity.\n\nPlease understand that this decision is not a reflection of your character, your potential, or the value of what you have brought to the team. We sincerely appreciate the dedication and effort you have shown during your time with us, and we are grateful for your contributions.\n\nAny outstanding matters concerning final payment or company materials will be addressed separately in due course. We kindly ask that you ensure all company information, files, accounts, and access are properly returned or deleted in accordance with the terms of the agreements you have signed.\n\nWe wish you continued success and every good wish in what comes next.\n\nRespectfully,\nCathy Anderson\nHiring Director\nExpert Intuitive Advisor Inc.`;
  const html = text.replace(/\n/g, "<br/>");
  return { subject, text, html };
}

async function sendResend(to: string, subject: string, html: string, text: string, bcc: string[] = []) {
  const r = await fetch("https://api.resend.com/emails", {
    method: "POST",
    headers: { Authorization: `Bearer ${RESEND_API_KEY}`, "Content-Type": "application/json" },
    body: JSON.stringify({
      from: `${FROM_NAME} <${FROM_ADDRESS}>`,
      to: [to],
      bcc: bcc.length ? bcc : undefined,
      reply_to: GMAIL_USER || undefined,
      subject, html, text,
    }),
  });
  const data = await r.json().catch(() => ({}));
  return { ok: r.ok, id: (data as any)?.id ?? null, error: r.ok ? null : JSON.stringify(data) };
}

const json = (b: unknown, status = 200) =>
  new Response(JSON.stringify(b), { status, headers: { ...corsHeaders, "Content-Type": "application/json" } });

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });

  try {
    const authHeader = req.headers.get("Authorization");
    if (!authHeader?.startsWith("Bearer ")) return json({ error: "unauthorized" }, 401);

    const userClient = createClient(SUPABASE_URL, ANON, { global: { headers: { Authorization: authHeader } } });
    const { data: userData, error: uErr } = await userClient.auth.getUser();
    if (uErr || !userData?.user) return json({ error: "unauthorized" }, 401);

    const adminClient = createClient(SUPABASE_URL, SERVICE);

    const body = await req.json().catch(() => ({}));
    const { job_offer_id, override_email, password } = body || {};
    if (!job_offer_id || typeof password !== "string") return json({ error: "invalid_request" }, 400);

    const overrideEmailClean = typeof override_email === "string" ? override_email.trim() : "";
    if (overrideEmailClean && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(overrideEmailClean)) {
      return json({ error: "invalid_email" }, 400);
    }

    // identify HR
    const email = (userData.user.email || "").toLowerCase();
    const { data: hr } = await adminClient.from("hr_users").select("id, display_name, role").ilike("email", email).maybeSingle();
    const hrId = hr?.id ?? null;

    // verify boss password
    if (password !== BOSS_PASSWORD) {
      await adminClient.from("password_audit_log").insert({
        hr_user_id: hrId, password_used: "***wrong***",
        action_taken: "resend_termination_failed", target_resource_id: job_offer_id,
      });
      return json({ error: "wrong_password" }, 403);
    }

    // fetch offer
    const { data: offer, error: oErr } = await adminClient
      .from("job_offers")
      .select("id, candidate_id, candidate_name, candidate_email, position_title, employment_status, override_email")
      .eq("id", job_offer_id).maybeSingle();
    if (oErr || !offer) return json({ error: "offer_not_found" }, 404);

    // GUARD: only for already-terminated employees
    if (!["terminated_evaluation", "terminated_regular"].includes(offer.employment_status)) {
      return json({ error: "not_terminated" }, 409);
    }

    const termination_type = offer.employment_status === "terminated_evaluation" ? "evaluation" : "regular";

    const recipientEmail = overrideEmailClean || (offer as any).override_email || offer.candidate_email;
    if (!recipientEmail) return json({ error: "no_recipient_email" }, 400);

    // persist override if changed
    if (overrideEmailClean && overrideEmailClean !== (offer as any).override_email) {
      await adminClient.from("job_offers").update({ override_email: overrideEmailClean }).eq("id", job_offer_id);
    }

    const today = formatToday();
    const built = termination_type === "evaluation"
      ? evaluationEmail(offer.candidate_name, offer.position_title, today)
      : regularEmail(offer.candidate_name, offer.position_title, today);

    const stageValue = termination_type === "evaluation" ? "stage_termination_evaluation" : "stage_termination_regular";

    // pre-insert email_log
    const { data: logRow } = await adminClient.from("email_log").insert({
      to_address: recipientEmail,
      from_address: FROM_ADDRESS,
      from_name: FROM_NAME,
      sender: "resend",
      subject: built.subject,
      stage: stageValue,
      status: "pending",
      candidate_id: null,
      job_offer_id,
    }).select("id").single();
    const emailLogId = logRow?.id ?? null;

    const sendRes = await sendResend(recipientEmail, built.subject, built.html, built.text, [HR_INBOX, BOSS_INBOX]);

    if (emailLogId) {
      await adminClient.from("email_log").update({
        status: sendRes.ok ? "sent" : "failed",
        sent_at: sendRes.ok ? new Date().toISOString() : null,
        resend_message_id: sendRes.id,
        error_message: sendRes.ok ? null : sendRes.error,
      }).eq("id", emailLogId);
    }

    // Update latest termination_log row's email_sent_at on success; insert one if none.
    if (sendRes.ok) {
      const sentAt = new Date().toISOString();
      const { data: latestLog } = await adminClient
        .from("termination_log")
        .select("id")
        .eq("job_offer_id", job_offer_id)
        .order("created_at", { ascending: false })
        .limit(1)
        .maybeSingle();
      if (latestLog?.id) {
        await adminClient.from("termination_log")
          .update({ email_sent_at: sentAt, email_log_id: emailLogId })
          .eq("id", latestLog.id);
      } else {
        await adminClient.from("termination_log").insert({
          job_offer_id,
          termination_type,
          terminated_by_hr_id: hrId,
          email_sent_at: sentAt,
          email_log_id: emailLogId,
          notes: "Termination notice sent via resend-termination-email",
        });
      }
    }

    await adminClient.from("password_audit_log").insert({
      hr_user_id: hrId,
      password_used: "***boss***",
      action_taken: `resend_termination_${termination_type}`,
      target_resource_id: job_offer_id,
    });

    await adminClient.from("notification_log").insert({
      event_type: `resend_termination_${termination_type}`,
      recipient_email: `${HR_INBOX},${BOSS_INBOX}`,
      related_resource_id: job_offer_id,
      status: sendRes.ok ? "sent" : "failed",
    });

    if (!sendRes.ok) return json({ ok: false, reason: sendRes.error || "send_failed" }, 502);
    return json({ ok: true, email_sent: true, recipient: recipientEmail, email_log_id: emailLogId });
  } catch (e) {
    return json({ error: (e as Error).message }, 500);
  }
});
