// zoom-probe: tiny admin-only probe — calls a Zoom path and returns raw JSON + status.
import { corsHeaders, jsonResponse, requireAdmin, zoomFetch } from "../_shared/zoom.ts";

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });
  const guard = await requireAdmin(req);
  if (guard instanceof Response) return guard;
  let body: { path?: string } = {};
  try { body = (await req.json()) ?? {}; } catch { /* noop */ }
  const path = body.path || "/users/me";
  const res = await zoomFetch(path, { method: "GET" });
  const j = await res.json().catch(() => ({}));
  return jsonResponse({ status: res.status, path, body: j });
});
