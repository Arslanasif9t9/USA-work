import { adminClient, corsHeaders, json, requireHr } from "../_shared/hr-auth.ts";

const RESEND_API_KEY = Deno.env.get("RESEND_API_KEY")!;

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });
  const ident = await requireHr(req);
  if (ident instanceof Response) return ident;

  const { response_id } = await req.json().catch(() => ({}));
  if (!response_id) return json({ error: "missing_input" }, 400);

  const admin = adminClient();
  const { data: resp } = await admin
    .from("responses")
    .select("form_id, override_email, override_name")
    .eq("id", response_id)
    .maybeSingle();
  if (!resp) return json({ error: "response_not_found" }, 404);

  const { data: qs } = await admin.from("questions").select("id, type, label").eq("form_id", resp.form_id);
  const { data: ans } = await admin.from("answers").select("question_id, answer_text").eq("response_id", response_id);

  const EMAIL_LABEL_RE = /e[\s-]?mail/i;
  const EMAIL_EXCLUDE_RE = /(onlinejob|profile|link|url)/i;
  const emailQ =
    qs?.find((q: any) => EMAIL_LABEL_RE.test(q.label || "") && !EMAIL_EXCLUDE_RE.test(q.label || "")) ||
    qs?.find((q: any) => q.type === "email" && !EMAIL_EXCLUDE_RE.test(q.label || ""));
  const nameQ =
    qs?.find((q: any) => q.type === "short_text" && /name/i.test(q.label || "")) ||
    qs?.find((q: any) => q.type === "short_text");
  const answerEmail = ans?.find((a: any) => a.question_id === emailQ?.id)?.answer_text || "";
  const candidateEmail = ((resp as any).override_email || answerEmail || "").trim();
  const fullName = ((resp as any).override_name || "").trim() || (ans?.find((a: any) => a.question_id === nameQ?.id)?.answer_text || "").trim();
  const firstName = fullName.split(" ")[0] || "there";

  if (!candidateEmail) return json({ error: "no_email" }, 400);

  const subject = "Update on your application";
  const html = `<div style="font-family: Arial, Helvetica, sans-serif; color:#1a2547; font-size:15px; line-height:1.6;">
<p>Hi ${firstName},</p>
<p>Thank you so much for the time and interest you've shown in Expert Intuitive Advisor Inc. We truly appreciate it.</p>
<p>The position you applied for has already been filled, and we are not moving forward with additional candidates at this time. This is not a reflection of your abilities or potential — it's simply a matter of timing and fit for this specific role.</p>
<p>We would love to hear from you again. Please feel free to apply for future openings that match your skills and interests.</p>
<p>Wishing you all the best,</p>
<p style="margin-top:24px;">
<strong>Angela Stein</strong><br/>
HR — Talent Manager<br/>
Expert Intuitive Advisor Inc.</p>
</div>`;

  try {
    const r = await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${RESEND_API_KEY}`,
      },
      body: JSON.stringify({
        from: "Angela Stein <talent@expertintuitiveadvisor.com>",
        to: [candidateEmail],
        subject,
        html,
      }),
    });
    if (!r.ok) {
      const t = await r.text();
      return json({ error: "send_failed", detail: t }, 502);
    }
  } catch (e: any) {
    return json({ error: "send_failed", detail: String(e?.message || e) }, 502);
  }

  return json({ success: true, to: candidateEmail });
});
