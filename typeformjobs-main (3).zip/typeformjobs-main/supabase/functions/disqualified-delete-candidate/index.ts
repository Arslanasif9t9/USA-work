// disqualified-delete-candidate: permanently deletes ONE disqualified candidate.
// Safety: only deletes if responses.round_stage = 'disqualified'.
// Removes email_log (by candidate_id), candidate_actions (by candidate_id),
// answers, response, clears interview_slots.response_id, and removes storage files
// (resume/selfie). Single-row by exact id. No CASCADE — explicit cleanup only.
import { createClient } from "npm:@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
const ANON = Deno.env.get("SUPABASE_ANON_KEY")!;
const SERVICE = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;

const STORAGE_BUCKETS = ["resumes", "selfies", "candidate-selfies", "candidate-files"];

function parseStorageUrl(url: string | null | undefined): { bucket: string; path: string } | null {
  if (!url) return null;
  for (const b of STORAGE_BUCKETS) {
    const idx = url.indexOf(`/object/public/${b}/`);
    if (idx !== -1) return { bucket: b, path: decodeURIComponent(url.slice(idx + `/object/public/${b}/`.length).split("?")[0]) };
    const idx2 = url.indexOf(`/object/sign/${b}/`);
    if (idx2 !== -1) return { bucket: b, path: decodeURIComponent(url.slice(idx2 + `/object/sign/${b}/`.length).split("?")[0]) };
    const idx3 = url.indexOf(`/${b}/`);
    if (idx3 !== -1) return { bucket: b, path: decodeURIComponent(url.slice(idx3 + b.length + 2).split("?")[0]) };
  }
  return null;
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });
  try {
    const authHeader = req.headers.get("Authorization");
    if (!authHeader?.startsWith("Bearer ")) {
      return new Response(JSON.stringify({ error: "unauthorized" }), { status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }
    const userClient = createClient(SUPABASE_URL, ANON, { global: { headers: { Authorization: authHeader } } });
    const { data: userData, error: uErr } = await userClient.auth.getUser();
    if (uErr || !userData?.user) {
      return new Response(JSON.stringify({ error: "unauthorized" }), { status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }
    const admin = createClient(SUPABASE_URL, SERVICE);

    const { response_id } = await req.json().catch(() => ({}));
    if (!response_id || typeof response_id !== "string") {
      return new Response(JSON.stringify({ error: "invalid_request" }), { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }

    // SAFETY: load the response by exact id and confirm it is disqualified.
    const { data: resp } = await admin
      .from("responses")
      .select("id, applicant_id, round_stage, scheduled_slot_id")
      .eq("id", response_id)
      .maybeSingle();
    if (!resp) {
      return new Response(JSON.stringify({ error: "not_found" }), { status: 404, headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }
    if (resp.round_stage !== "disqualified") {
      return new Response(JSON.stringify({ error: "not_disqualified", stage: resp.round_stage }), { status: 409, headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }

    const candId = resp.applicant_id;

    // gather files from answers BEFORE deleting
    const { data: ans } = await admin
      .from("answers").select("file_url").eq("response_id", response_id);
    const files: { bucket: string; path: string }[] = [];
    for (const a of ans || []) {
      const fp = parseStorageUrl((a as any).file_url);
      if (fp) files.push(fp);
    }

    // Clear slot link (defensive — disqualify already released it)
    if (resp.scheduled_slot_id) {
      await admin.from("interview_slots").update({ response_id: null }).eq("id", resp.scheduled_slot_id);
    }

    // email_log (scoped to this candidate only)
    if (candId) await admin.from("email_log").delete().eq("candidate_id", candId);
    // candidate_actions (scoped to this response/candidate)
    // Belt-and-braces: stop the recover-reminder cron from ever picking this
    // candidate up — set the opt-out true before deleting the row.
    await admin.from("candidate_actions").update({ recover_reminder_opt_out: true }).eq("response_id", response_id);
    await admin.from("candidate_actions").delete().eq("response_id", response_id);
    if (candId) await admin.from("candidate_actions").delete().eq("candidate_id", candId);
    // answers (scoped to this response)
    await admin.from("answers").delete().eq("response_id", response_id);
    // belt-and-braces: explicitly expire any active rebook_tokens (Christine/Marissa
    // interview links) for this response_id BEFORE deleting the response row, so an
    // active link can never outlive the candidate. Single scope, no CASCADE.
    {
      const nowIso = new Date().toISOString();
      const expiredIso = new Date(Date.now() - 1000).toISOString();
      await admin
        .from("rebook_tokens")
        .update({ expires_at: expiredIso, used_at: nowIso })
        .eq("response_id", response_id)
        .is("used_at", null)
        .gt("expires_at", nowIso);
    }
    // finally the response itself — single row by id, only if still disqualified
    const { error: delErr } = await admin
      .from("responses").delete().eq("id", response_id).eq("round_stage", "disqualified");
    if (delErr) throw delErr;

    // storage cleanup (best-effort)
    const grouped: Record<string, string[]> = {};
    for (const f of files) (grouped[f.bucket] = grouped[f.bucket] || []).push(f.path);
    for (const [bucket, paths] of Object.entries(grouped)) {
      if (paths.length) await admin.storage.from(bucket).remove(paths).catch(() => {});
    }

    return new Response(JSON.stringify({ ok: true }), { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } });
  } catch (e) {
    return new Response(JSON.stringify({ error: (e as Error).message }), { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } });
  }
});
