// book-slot-ai: PUBLIC. Sibling of book-slot for AI-scheduled interviews.
// Confirms reservation and marks slot booked. NO Zoom meeting is created.
// The AI confirmation email is fired by the wrapper (rebook-confirm-ai), not here.
import { createClient } from "npm:@supabase/supabase-js@2";
import { formatManilaDate, formatManilaTime } from "../_shared/manila.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
const SERVICE_KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
const UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });
  const admin = createClient(SUPABASE_URL, SERVICE_KEY);

  let body: any;
  try { body = await req.json(); } catch {
    return new Response(JSON.stringify({ error: "invalid_json" }), {
      status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
  // assigned_hr_id is accepted (parity with book-slot) but unused — no PMR lookup here.
  const { slot_id, response_id } = body || {};
  if (!slot_id || !UUID_RE.test(slot_id) || !response_id || !UUID_RE.test(response_id)) {
    return new Response(JSON.stringify({ error: "invalid_input" }), {
      status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }

  // Load slot & verify reservation (identical to book-slot)
  const { data: slot } = await admin
    .from("interview_slots")
    .select("id, slot_start, status, reserved_until")
    .eq("id", slot_id)
    .maybeSingle();
  if (!slot) {
    return new Response(JSON.stringify({ error: "slot_not_found" }), {
      status: 404, headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
  if (slot.status !== "reserved" || !slot.reserved_until || new Date(slot.reserved_until) < new Date()) {
    return new Response(JSON.stringify({ error: "slot_expired", code: "reservation_lost" }), {
      status: 409, headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }

  // ── NO ZOOM ──────────────────────────────────────────────────────────────
  // book-slot's PMR lookup + Zoom API + zoom_meetings insert are intentionally
  // omitted for AI-scheduled interviews.

  // Atomically transition reserved -> booked (no zoom_meeting_id column set)
  const { data: bookedRows, error: bookErr } = await admin
    .from("interview_slots")
    .update({
      status: "booked",
      response_id,
      reserved_until: null,
    })
    .eq("id", slot_id)
    .eq("status", "reserved")
    .select("id");

  if (bookErr || !bookedRows || bookedRows.length === 0) {
    return new Response(JSON.stringify({ error: "book_failed", details: bookErr?.message }), {
      status: 409, headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }

  // Update responses (clear any prior cancellation flag on successful booking)
  await admin.from("responses").update({
    scheduled_slot_id: slot_id,
    scheduled_at: new Date().toISOString(),
    appointment_cancelled: false,
  }).eq("id", response_id);

  // Log notifications & fire (best-effort) — mirrors book-slot
  const recipients = ["talent.expertadvisor@outlook.com", "spark11179@gmail.com"];
  for (const r of recipients) {
    await admin.from("notification_log").insert({
      event_type: "new_booking",
      recipient_email: r,
      related_resource_id: slot_id,
      status: "sent",
    });
  }

  // Fire-and-forget HR notification email (no Zoom-link candidate email here)
  fetch(`${SUPABASE_URL}/functions/v1/send-new-booking-notification`, {
    method: "POST",
    headers: { Authorization: `Bearer ${SERVICE_KEY}`, "Content-Type": "application/json" },
    body: JSON.stringify({ slot_id }),
  }).catch((e) => console.error("notify error", e));

  const slotDate = new Date(slot.slot_start);
  return new Response(JSON.stringify({
    success: true,
    slot_id,
    slot_start: slot.slot_start,
    display_date: formatManilaDate(slotDate),
    display_time: formatManilaTime(slotDate),
  }), { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } });
});
