import { createClient } from "https://esm.sh/@supabase/supabase-js@2.45.0";
import postgres from "https://deno.land/x/postgresjs@v3.4.4/mod.js";

const cors = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: cors });

  const admin = createClient(
    Deno.env.get("SUPABASE_URL")!,
    Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!
  );

  const target = "hr2@expert.com";

  // Find user
  let userId: string | null = null;
  let page = 1;
  while (true) {
    const { data, error } = await admin.auth.admin.listUsers({ page, perPage: 200 });
    if (error) return new Response(JSON.stringify({ error: error.message }), { status: 500, headers: { ...cors, "Content-Type": "application/json" } });
    const u = data.users.find((u) => u.email?.toLowerCase() === target);
    if (u) { userId = u.id; break; }
    if (data.users.length < 200) break;
    page++;
  }
  if (!userId) return new Response(JSON.stringify({ error: `not found: ${target}` }), { status: 404, headers: { ...cors, "Content-Type": "application/json" } });

  const dbUrl = Deno.env.get("SUPABASE_DB_URL")!;
  const sql = postgres(dbUrl, { prepare: false });
  try {
    const tokens = await sql`DELETE FROM auth.refresh_tokens WHERE user_id = ${userId}::text RETURNING id`;
    const sessions = await sql`DELETE FROM auth.sessions WHERE user_id = ${userId}::uuid RETURNING id`;
    return new Response(JSON.stringify({
      ok: true, email: target, userId,
      refresh_tokens_deleted: tokens.length,
      sessions_deleted: sessions.length,
    }), { headers: { ...cors, "Content-Type": "application/json" } });
  } catch (e) {
    return new Response(JSON.stringify({ error: String(e), userId }), { status: 500, headers: { ...cors, "Content-Type": "application/json" } });
  } finally {
    await sql.end();
  }
});
