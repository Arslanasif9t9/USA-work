// submit-onboarding: PUBLIC, token-gated. Upserts the onboarding_submissions
// row by response_id, then sends the post-submit thank-you email.
import { createClient } from "npm:@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};
const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
const SERVICE = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
const RESEND_API_KEY = Deno.env.get("RESEND_API_KEY")!;
const json = (b: unknown, s = 200) =>
  new Response(JSON.stringify(b), { status: s, headers: { ...corsHeaders, "Content-Type": "application/json" } });

const FROM = "Angela Stein / HR – Talent Manager <talent@expertintuitiveadvisor.com>";
const FROM_ADDR = "talent@expertintuitiveadvisor.com";
const FROM_NAME = "Angela Stein / HR – Talent Manager";

const NAVY = "#1a2547";
const GOLD = "#b08d57";

function thankYouHtml(name: string) {
  const first = (name || "").split(" ")[0] || "there";
  return `<!doctype html><html><body style="margin:0;padding:0;background:#faf8f3;font-family:Inter,Arial,sans-serif;color:${NAVY}">
  <table width="100%" cellpadding="0" cellspacing="0" style="background:#faf8f3;padding:32px 0">
    <tr><td align="center">
      <table width="560" cellpadding="0" cellspacing="0" style="background:#ffffff;border-top:4px solid ${GOLD};padding:32px 32px 28px 32px">
        <tr><td>
          <div style="font-family:'Cormorant Garamond',Georgia,serif;font-size:26px;color:${NAVY};font-weight:600;margin-bottom:12px">
            Onboarding received — next step
          </div>
          <p style="font-size:15px;line-height:1.6;color:${NAVY};margin:0 0 14px 0">
            Hi ${first},
          </p>
          <p style="font-size:15px;line-height:1.6;color:${NAVY};margin:0 0 14px 0">
            Thank you — we've received your onboarding form. Welcome to Expert Intuitive Advisor Inc.
          </p>
          <p style="font-size:15px;line-height:1.6;color:${NAVY};margin:0 0 8px 0">
            <strong>Please add your onboarding specialist Sylvia on WhatsApp:</strong>
          </p>
          <p style="font-size:18px;line-height:1.4;color:${NAVY};margin:0 0 16px 0;font-weight:600">
            +1 917 735 8220
          </p>
          <p style="font-size:14px;line-height:1.6;color:${NAVY};margin:0 0 14px 0">
            She will guide you through your next steps. Your onboarding link stays active for 30 days if you need to revisit or update anything.
          </p>
          <p style="font-size:14px;line-height:1.6;color:${NAVY};margin:24px 0 0 0">
            Warm regards,<br/>
            <span style="color:${GOLD}">Angela Stein</span><br/>
            HR – Talent Manager<br/>
            Expert Intuitive Advisor Inc.
          </p>
        </td></tr>
      </table>
    </td></tr>
  </table>
  </body></html>`;
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });
  try {
    const body = await req.json();
    const { token, full_name, email, phone, profile_photo_url, speedtest_screenshot_url, typing_screenshot_url, onlinejobs_profile_url, digital_pay_gcash } = body || {};
    if (!token) return json({ error: "missing_token" }, 400);
    if (!profile_photo_url || !speedtest_screenshot_url || !typing_screenshot_url) {
      return json({ error: "missing_required_uploads" }, 400);
    }

    const admin = createClient(SUPABASE_URL, SERVICE);

    const { data: tok } = await admin.from("onboarding_tokens").select("*").eq("token", token).maybeSingle();
    if (!tok) return json({ error: "invalid_token" }, 404);
    if (tok.closed_at) return json({ error: "closed" }, 410);
    if (new Date(tok.expires_at) < new Date()) return json({ error: "expired" }, 410);

    // For universal (response-less) tokens, key the submission by the token's
    // own id so it persists without an attached employee/response.
    const responseId = tok.response_id || tok.id;
    const pf: any = tok.prefill_data || {};
    const now = new Date().toISOString();

    const payload = {
      response_id: responseId,
      full_name: (full_name || tok.candidate_name || pf.full_name || "").toString().trim() || null,
      email: (email || tok.candidate_email || pf.email || "").toString().trim() || null,
      position_title: (tok.position_title || pf.position_title || "").toString().trim() || null,
      phone: (phone || pf.phone || "").toString().trim() || null,
      profile_photo_url,
      speedtest_screenshot_url,
      typing_screenshot_url,
      onlinejobs_profile_url: onlinejobs_profile_url ?? null,
      digital_pay_gcash: (digital_pay_gcash ?? "").toString().trim() || null,
      onboarding_status: "pending",
      submitted_at: now,
      updated_at: now,
    };

    const { data: up, error: upErr } = await admin
      .from("onboarding_submissions")
      .upsert(payload, { onConflict: "response_id" })
      .select("id, submitted_at")
      .maybeSingle();
    if (upErr || !up) return json({ error: "upsert_failed", detail: upErr?.message }, 500);

    // Read-after-write
    const { data: verify } = await admin
      .from("onboarding_submissions").select("id, submitted_at").eq("response_id", responseId).maybeSingle();
    if (!verify?.submitted_at) return json({ error: "verify_failed" }, 500);


    // Send thank-you email (best-effort)
    const toAddr = payload.email;
    let emailOk = false;
    let resendId: string | null = null;
    let errMsg: string | null = null;
    if (toAddr && RESEND_API_KEY) {
      try {
        const subject = "Onboarding Received — Next Step";
        const html = thankYouHtml(payload.full_name || "");
        const text = `Hi ${(payload.full_name || "").split(" ")[0] || "there"},

Thank you — we've received your onboarding form. Welcome to Expert Intuitive Advisor Inc.

Please add your onboarding specialist Sylvia on WhatsApp:
+1 917 735 8220

She will guide you through your next steps. Your onboarding link stays active for 30 days if you need to revisit or update anything.

Warm regards,
Angela Stein
HR – Talent Manager
Expert Intuitive Advisor Inc.`;
        const sendRes = await fetch("https://api.resend.com/emails", {
          method: "POST",
          headers: { "Content-Type": "application/json", Authorization: `Bearer ${RESEND_API_KEY}` },
          body: JSON.stringify({ from: FROM, to: [toAddr], subject, html, text }),
        });
        const sendJson = await sendRes.json().catch(() => ({}));
        emailOk = sendRes.ok;
        resendId = sendJson?.id ?? null;
        if (!emailOk) errMsg = JSON.stringify(sendJson);

        await admin.from("email_log").insert({
          candidate_id: null,
          stage: "onboarding_submitted",
          sender: "resend",
          from_address: FROM_ADDR,
          from_name: FROM_NAME,
          to_address: toAddr,
          subject,
          status: emailOk ? "sent" : "failed",
          sent_at: emailOk ? now : null,
          resend_message_id: resendId,
          error_message: errMsg,
        });
      } catch (e: any) {
        errMsg = String(e?.message || e);
      }
    }

    return json({ success: true, submission_id: verify.id, email_sent: emailOk });
  } catch (e: any) {
    return json({ error: "internal", details: String(e?.message || e) }, 500);
  }
});
