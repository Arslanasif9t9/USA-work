// signflow-create-document: admin-only proxy that calls SignFlow's
// external-create-document-from-template using SIGNFLOW_API_KEY.
import { createClient } from "npm:@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type",
};

const SIGNFLOW_URL =
  "https://iutnvmotjbuoqrkxzegj.supabase.co/functions/v1/external-create-document-from-template";

const json = (b: unknown, status = 200) =>
  new Response(JSON.stringify(b), {
    status,
    headers: { ...corsHeaders, "content-type": "application/json" },
  });

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });

  const auth = req.headers.get("Authorization") || "";
  if (!auth.startsWith("Bearer ")) return json({ error: "missing_auth" }, 401);

  const userClient = createClient(
    Deno.env.get("SUPABASE_URL")!,
    Deno.env.get("SUPABASE_ANON_KEY")!,
    { global: { headers: { Authorization: auth } } },
  );
  const { data: u } = await userClient.auth.getUser();
  if (!u?.user) return json({ error: "invalid_jwt" }, 401);

  const admin = createClient(
    Deno.env.get("SUPABASE_URL")!,
    Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!,
  );
  const { data: row } = await admin
    .from("users").select("role").eq("id", u.user.id).maybeSingle();
  if (!row || row.role !== "admin") return json({ error: "forbidden" }, 403);

  const apiKey = Deno.env.get("SIGNFLOW_API_KEY");
  if (!apiKey) return json({ error: "signflow_api_key_not_set" }, 500);

  let body: any;
  try { body = await req.json(); } catch { return json({ error: "invalid_json" }, 400); }

  const {
    external_offer_reference,
    signer_name,
    signer_email,
    document_title,
    pdf_url,
    signature_field_position,
  } = body || {};

  if (!external_offer_reference || !signer_name || !signer_email || !document_title || !pdf_url) {
    return json({ error: "missing_fields" }, 400);
  }

  const payload = {
    external_offer_reference,
    signer_name,
    signer_email,
    document_title,
    pdf_url,
    signature_field_position: signature_field_position || {
      page: 4, x: 100, y: 350, width: 200, height: 60,
    },
  };

  let resp: Response;
  try {
    resp = await fetch(SIGNFLOW_URL, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${apiKey}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify(payload),
    });
  } catch (e) {
    return json({ error: "signflow_fetch_failed", detail: (e as Error).message }, 502);
  }

  const text = await resp.text();
  let parsed: any = null;
  try { parsed = JSON.parse(text); } catch { parsed = { raw: text }; }

  return new Response(JSON.stringify(parsed), {
    status: resp.status,
    headers: { ...corsHeaders, "Content-Type": "application/json" },
  });
});
