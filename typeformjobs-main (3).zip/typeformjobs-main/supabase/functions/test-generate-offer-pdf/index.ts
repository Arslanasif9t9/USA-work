// test-generate-offer-pdf: admin-only. Generates a sample PDF with optional overrides.
import { createClient } from "npm:@supabase/supabase-js@2";
import {
  buildFilename,
  buildAlluraDebugPdf,
  buildOfferPdf,
  type OfferData,
  uploadPdf,
} from "../_shared/offer-pdf.ts";
import { DEFAULT_SCHEDULE_PRESET, getLockedSchedulePreset } from "../_shared/schedule-presets.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type",
};

const json = (b: unknown, status = 200) =>
  new Response(JSON.stringify(b), {
    status,
    headers: { ...corsHeaders, "content-type": "application/json" },
  });

async function requireAdmin(req: Request): Promise<Response | null> {
  const auth = req.headers.get("Authorization") || "";
  if (!auth.startsWith("Bearer ")) return json({ error: "missing_auth" }, 401);
  const userClient = createClient(
    Deno.env.get("SUPABASE_URL")!,
    Deno.env.get("SUPABASE_ANON_KEY")!,
    { global: { headers: { Authorization: auth } } },
  );
  const { data: u } = await userClient.auth.getUser();
  if (!u?.user) return json({ error: "invalid_jwt" }, 401);
  const admin = createClient(
    Deno.env.get("SUPABASE_URL")!,
    Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!,
  );
  const { data: row } = await admin
    .from("users").select("role").eq("id", u.user.id).maybeSingle();
  if (!row || row.role !== "admin") return json({ error: "forbidden" }, 403);
  return null;
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });
  const guard = await requireAdmin(req);
  if (guard) return guard;

  let input: Record<string, any> = {};
  try { input = await req.json(); } catch { input = {}; }

  const today = new Date();
  const start = new Date(today.getTime() + 7 * 24 * 60 * 60 * 1000);
  const raise = input.raise_applied !== false;
  const currency = input.currency || "PHP";
  const schedulePreset = input.schedule_preset_used || input.schedule_preset || DEFAULT_SCHEDULE_PRESET;
  const schedule = getLockedSchedulePreset(schedulePreset) ?? getLockedSchedulePreset(DEFAULT_SCHEDULE_PRESET)!;

  if (input.debug_allura === true) {
    const out = await buildAlluraDebugPdf();
    const filename = `DEBUG-Allura-${today.getUTCFullYear()}-${Date.now()}.pdf`;
    const up = await uploadPdf(out.bytes, filename);
    return json({ success: true, pdf_url: up.url, filename, upload_error: up.error, font_warning: out.warning });
  }

  // Locked defaults differ by currency
  const isUSD = currency.toUpperCase() === "USD";
  const trialWeekly = input.trial_weekly_salary ?? (isUSD ? 100 : 4000);
  const postTrialWeekly = input.post_trial_weekly_salary ??
    (raise ? (isUSD ? 115 : 4500) : trialWeekly);
  const monthlyMin = input.monthly_range_min ?? trialWeekly * 4;
  const monthlyMax = input.monthly_range_max ??
    (raise ? postTrialWeekly * 4 : trialWeekly * 4);

  const data: OfferData = {
    candidate_name: input.candidate_name || "Test Candidate Dela Cruz",
    position_title: input.position_title || "AI Operations Associate",
    offer_reference_id: input.offer_reference_id || `EIA-${today.getUTCFullYear()}-TEST`,
    date_issued: today,
    start_date: start,
    trial_weeks: 4,
    trial_weekly_salary: trialWeekly,
    post_trial_weekly_salary: postTrialWeekly,
    monthly_range_min: monthlyMin,
    monthly_range_max: monthlyMax,
    raise_applied: raise,
    currency,
    schedule_preset_used: schedulePreset,
    weekday_start: input.weekday_start || schedule.weekday_start,
    weekday_end: input.weekday_end || schedule.weekday_end,
    saturday_start: input.saturday_start || schedule.saturday_start,
    saturday_end: input.saturday_end || schedule.saturday_end,
    scope_items: input.scope_items || [
      "Draft and refine prompts for client-facing AI workflows",
      "Maintain CRM data hygiene and weekly pipeline updates",
      "Coordinate with the US team on deliverable handoffs across timezones",
      "Document standard operating procedures in Notion",
      "Run QA on AI-generated outputs before release to clients",
    ],
    performance_bonus_enabled: input.performance_bonus_enabled === true,
    performance_bonus_amount: input.performance_bonus_amount != null ? Number(input.performance_bonus_amount) : null,
    include_adaptability_clause: input.include_adaptability_clause !== false,
  } as OfferData;


  let pdfBytes: Uint8Array;
  let buildWarning: string | null = null;
  try {
    const out = await buildOfferPdf(data);
    pdfBytes = out.bytes;
    buildWarning = out.warning;
  } catch (e) {
    return json({ error: "pdf_build_failed", detail: (e as Error).message }, 500);
  }

  const filename = `TEST-${buildFilename(data.offer_reference_id, data.candidate_name)}`;
  const up = await uploadPdf(pdfBytes, filename);
  if (!up.url) {
    const b64 = btoa(String.fromCharCode(...pdfBytes));
    return json({
      success: true,
      pdf_url: null,
      pdf_base64: b64,
      filename,
      upload_error: up.error,
      font_warning: buildWarning,
    });
  }
  return json({
    success: true,
    pdf_url: up.url,
    filename,
    font_warning: buildWarning,
    raise_applied: data.raise_applied,
  });
});
