// send-pre-consultation-form: HR/admin orchestrator. Mints token + public link,
// inserts a leave_requests row with doc_type='pre_consultation', and (when
// send_mode='email') sends the invite email via send-dual-email.
// CLONE of send-cash-advance-form (Option B: same leave_requests table).
// Differences: PC- reference prefix, doc_type='pre_consultation', the
// /pre-consultation/{token} public route, pc_* fields, and send_mode handling.
//   - send_mode='email' AND email present -> send warm/casual invite email.
//   - send_mode='link' -> do NOT send email; return { token, link } for HR to copy.
import { createClient } from "npm:@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
const ANON = Deno.env.get("SUPABASE_ANON_KEY")!;
const SVC = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
const PUBLIC_BASE = "https://jobs.expertintuitiveadvisor.com";

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

const json = (b: unknown, status = 200) =>
  new Response(JSON.stringify(b), {
    status,
    headers: { ...corsHeaders, "content-type": "application/json" },
  });

function shortHex(n: number) {
  const bytes = new Uint8Array(n / 2);
  crypto.getRandomValues(bytes);
  return Array.from(bytes).map((b) => b.toString(16).padStart(2, "0")).join("");
}

function buildSenderA(firstName: string, link: string) {
  const text = `Hi ${firstName},

Before your reading with Psychic John, please take a moment to read and agree to the quick pre-consultation form using the secure link below. It only takes a minute — read it, agree, sign, and you're all set.

OPEN YOUR PRE-CONSULTATION FORM:
${link}

If you have any questions, simply reply to this email.

Talk soon,
Psychic John`;
  const html = `<div style="font-family:Arial,sans-serif;font-size:14px;color:#2a1a3a;line-height:1.6;max-width:600px">
<p>Hi ${firstName},</p>
<p>Before your reading with Psychic John, please take a moment to read and agree to the quick pre-consultation form using the secure link below. It only takes a minute — read it, agree, sign, and you're all set.</p>
<p><a href="${link}" style="display:inline-block;background:#7c3aed;color:#ffffff;padding:12px 22px;border-radius:6px;text-decoration:none;font-weight:600">Open your pre-consultation form</a></p>
<p style="font-size:12px;color:#666">Or paste this link into your browser:<br/><a href="${link}" style="color:#7c3aed">${link}</a></p>
<p>If you have any questions, simply reply to this email.</p>
<p>Talk soon,<br/>Psychic John</p>
</div>`;
  return {
    from_name: "Psychic John",
    from_address: "talent@expertintuitiveadvisor.com",
    subject: "Quick form before your reading with Psychic John",
    html_body: html,
    text_body: text,
  };
}

function buildSenderB(firstName: string, link: string) {
  const text = `Hi ${firstName},

Quick note — here's your pre-consultation form link again so it's easy to find:

${link}

Just read it, agree, and sign when you can. See you at your session!

— Psychic John`;
  const html = `<div style="font-family:Arial,sans-serif;font-size:14px;color:#2a1a3a;line-height:1.6;max-width:600px">
<p>Hi ${firstName},</p>
<p>Quick note — here's your pre-consultation form link again so it's easy to find:</p>
<p><a href="${link}" style="color:#7c3aed">${link}</a></p>
<p>Just read it, agree, and sign when you can. See you at your session!</p>
<p>— Psychic John</p>
</div>`;
  return {
    from_name: "Psychic John",
    from_address: "expertintuitiveadvisor@gmail.com",
    subject: "Your pre-consultation form",
    html_body: html,
    text_body: text,
  };
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });
  if (req.method !== "POST") return json({ ok: false, reason: "method_not_allowed" }, 405);

  // Admin gate (mirrors send-cash-advance-form)
  const auth = req.headers.get("Authorization") || "";
  if (!auth.startsWith("Bearer ")) return json({ ok: false, reason: "missing_auth" }, 401);
  const userClient = createClient(SUPABASE_URL, ANON, { global: { headers: { Authorization: auth } } });
  const { data: u } = await userClient.auth.getUser();
  if (!u?.user) return json({ ok: false, reason: "invalid_jwt" }, 401);
  const admin = createClient(SUPABASE_URL, SVC);
  const { data: urow } = await admin.from("users").select("role").eq("id", u.user.id).maybeSingle();
  if (!urow || urow.role !== "admin") return json({ ok: false, reason: "forbidden" }, 403);

  let body: {
    name?: string; email?: string;
    pc_amount?: string; pc_duration?: string; pc_preferred_time?: string; pc_hr_message?: string;
    send_mode?: string;
    hr_copy_requested?: boolean; hr_copy_email_override?: string;
  };
  try { body = await req.json(); } catch { return json({ ok: false, reason: "invalid_json" }, 400); }

  const signerName = String(body?.name || "").trim();
  const signerEmailRaw = String(body?.email || "").trim();
  const sendMode = body?.send_mode === "link" ? "link" : "email";
  const pcAmount = String(body?.pc_amount || "").trim();
  const pcDuration = String(body?.pc_duration || "").trim();
  const pcPreferredTime = String(body?.pc_preferred_time || "").trim();
  const pcHrMessage = String(body?.pc_hr_message || "").trim();

  const hrCopyRequested = !!body?.hr_copy_requested;
  const hrCopyEmailOverrideRaw = typeof body?.hr_copy_email_override === "string" ? body.hr_copy_email_override.trim() : "";
  const hrCopyEmailOverride = hrCopyEmailOverrideRaw && EMAIL_RE.test(hrCopyEmailOverrideRaw) ? hrCopyEmailOverrideRaw : null;

  if (!signerName) return json({ ok: false, reason: "no_name" }, 400);
  if (!pcAmount) return json({ ok: false, reason: "no_amount" }, 400);
  if (!pcDuration) return json({ ok: false, reason: "no_duration" }, 400);

  // In email mode a valid email is required. In link mode email may be blank.
  const validEmail = signerEmailRaw && EMAIL_RE.test(signerEmailRaw) ? signerEmailRaw : "";
  if (sendMode === "email" && !validEmail) return json({ ok: false, reason: "no_email" }, 400);

  // Mint reference + token
  const reference = `PC-${shortHex(8).toUpperCase()}`;
  const token = shortHex(48);

  const { error: insErr } = await admin.from("leave_requests").insert({
    external_reference: reference,
    signer_name: signerName,
    signer_email: validEmail || null,
    token,
    status: "invited",
    doc_type: "pre_consultation",
    pc_amount: pcAmount,
    pc_duration: pcDuration,
    pc_preferred_time: pcPreferredTime || null,
    pc_hr_message: pcHrMessage || null,
    hr_copy_requested: hrCopyRequested,
    hr_copy_email_override: hrCopyEmailOverride,
  });
  if (insErr) return json({ ok: false, reason: "persist_failed", detail: insErr.message }, 500);

  // Read-after-write guard — never return a broken link
  const { data: verifyRow } = await admin
    .from("leave_requests").select("id, token").eq("external_reference", reference).maybeSingle();
  if (!verifyRow?.token) return json({ ok: false, reason: "persist_failed", detail: "row not found after insert" }, 500);

  const link = `${PUBLIC_BASE}/pre-consultation/${verifyRow.token}`;

  // Link mode: do NOT send email, just return the link to copy.
  if (sendMode === "link") {
    return json({ ok: true, mode: "link", token: verifyRow.token, external_reference: reference, link });
  }

  // Email mode: send invite via send-dual-email
  const firstName = signerName.split(/\s+/)[0] || signerName;
  const emailResp = await fetch(`${SUPABASE_URL}/functions/v1/send-dual-email`, {
    method: "POST",
    headers: { Authorization: `Bearer ${SVC}`, "Content-Type": "application/json" },
    body: JSON.stringify({
      to: validEmail,
      stage: "pre_consultation_form_sent",
      sender_a: buildSenderA(firstName, link),
      sender_b: buildSenderB(firstName, link),
    }),
  });
  const emailJson = await emailResp.json().catch(() => ({}));
  if (!emailResp.ok) {
    return json({
      ok: false, reason: "email_failed", detail: emailJson,
      token: verifyRow.token, external_reference: reference, link,
    }, 502);
  }

  return json({ ok: true, mode: "email", token: verifyRow.token, external_reference: reference, link });
});
