// Master-admin-only: update an HR user's auth password. No other data touched.
import { adminClient, corsHeaders, json, requireHr } from "../_shared/hr-auth.ts";

const MASTER_EMAIL = "spark11179@gmail.com";
const ALLOWED_EMAILS = new Set([
  "hr1@expert.com",
  "hr2@expert.com",
]);

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });

  const ident = await requireHr(req);
  if (ident instanceof Response) return ident;
  if (ident.email !== MASTER_EMAIL) return json({ error: "master_admin_only" }, 403);

  let body: any = {};
  try { body = await req.json(); } catch { return json({ ok: false, error: "invalid_json" }); }

  // Accept both {target_email,new_password} (current UI contract) and legacy {email}.
  const email = String(body?.target_email ?? body?.email ?? "").trim().toLowerCase();
  const newPassword = String(body?.new_password ?? "");

  if (!email) return json({ ok: false, error: "missing_target_email" });
  if (!ALLOWED_EMAILS.has(email)) {
    return json({ ok: false, error: `not_allowed: ${email} is not an allowed HR account` });
  }
  if (!newPassword || newPassword.length < 8) {
    return json({ ok: false, error: "password_too_short: minimum 8 characters" });
  }

  const admin = adminClient();

  // Find target auth user by email.
  const { data: list, error: listErr } = await admin.auth.admin.listUsers();
  if (listErr) return json({ ok: false, error: listErr.message });
  const match = list?.users?.find((u: any) => (u.email || "").toLowerCase() === email);
  if (!match) return json({ ok: false, error: "user_not_found" });

  const { error: updErr } = await admin.auth.admin.updateUserById(match.id, { password: newPassword });
  if (updErr) return json({ ok: false, error: updErr.message });

  // Best-effort audit log (never store the real password).
  try {
    const { data: targetHr } = await admin
      .from("hr_users").select("id").ilike("email", email).maybeSingle();
    await admin.from("password_audit_log").insert({
      password_used: "[REDACTED: hr password reset]",
      action_taken: "hr_password_reset",
      hr_user_id: ident.hrId,
      target_resource_id: targetHr?.id ?? null,
    });
  } catch (_e) {
    // Audit failures must not break the reset.
  }

  return json({ ok: true, email });
});
