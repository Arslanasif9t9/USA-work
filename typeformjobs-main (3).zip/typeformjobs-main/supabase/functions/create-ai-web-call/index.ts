// create-ai-web-call: PUBLIC. Validates a rebook_token and creates a Retell web call.
// Picks the Retell agent based on the token's stage:
//   - round2_ai  → Marissa
//   - everything else (round1, ai_scheduled, permanent-test) → Christine
// Passes retell_llm_dynamic_variables (candidate_name, position, candidate_timezone,
// salary, schedule). All DB lookups for these are best-effort — failures fall back
// to "" and NEVER block the call. metadata: { response_id } is preserved as-is.
import { createClient } from "npm:@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
const SERVICE = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
const RETELL_API_KEY = Deno.env.get("RETELL_API_KEY")!;
const CHRISTINE_AGENT_ID = "agent_ebfc0e0483aae37dd6e1a20d3f";
const MARISSA_AGENT_ID = "agent_9cbbf25c5a0d27cad1a61a3daa";

const json = (b: unknown, s = 200) =>
  new Response(JSON.stringify(b), { status: s, headers: { ...corsHeaders, "Content-Type": "application/json" } });

const interviewRoundForStage = (stage: unknown) =>
  stage === "round2_ai" ? "round2" : "round1";

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });
  try {
    const { token } = await req.json();
    if (!token) return json({ error: "missing_token" }, 400);

    // Permanent, non-consuming test token. Always valid, never expires, never marked used.
    // Used by the fixed test URL /ai-interview/permanent-test for live-domain QA.
    const PERMANENT_TEST_TOKEN = "permanent-test";
    const PERMANENT_TEST_RESPONSE_ID = "75783256-14bd-4d0f-846e-99a96ab74ad2";

    let response_id: string | null = null;
    let tok: any = null;

    const admin = createClient(SUPABASE_URL, SERVICE);

    if (token === PERMANENT_TEST_TOKEN) {
      response_id = PERMANENT_TEST_RESPONSE_ID;
    } else {
      const { data } = await admin.from("rebook_tokens").select("*").eq("token", token).maybeSingle();
      if (!data) return json({ error: "invalid_token" }, 401);
      if (data.used_at) return json({ error: "token_used" }, 401);
      if (new Date(data.expires_at) <= new Date()) return json({ error: "token_expired" }, 401);
      tok = data;
      response_id = data.response_id || null;

      // ----- GLITCH 8: block reuse after a real completion -----
      // Wrapped: a transient query error must NOT hard-block a legit candidate.
      // Failed/silent sessions (duration<=20 or error_*/not_joined/failed/abandon)
      // do NOT count, so the GLITCH 1 retry-after-failure path stays intact.
      // Round-aware: Round 1 completions must not burn or block fresh Round 2
      // links, and Round 2 completions must not block Round 1 retry/reschedule
      // links. Pre-migration null session stages are treated as Round 1 only.
      if (response_id) {
        try {
          const currentRound = interviewRoundForStage(tok?.stage);
          const { data: priorSessions } = await admin
            .from("ai_interview_sessions")
            .select("id, duration_seconds, termination_reason, stage")
            .eq("response_id", response_id);
          const hasRealCompletion = (priorSessions || []).some((s: any) => {
            if (interviewRoundForStage(s.stage) !== currentRound) return false;
            const dur = typeof s.duration_seconds === "number" ? s.duration_seconds : 0;
            const reason = typeof s.termination_reason === "string" ? s.termination_reason : "";
            const isError = /error|not_joined|failed|abandon/i.test(reason);
            return dur > 20 && !isError;
          });
          if (hasRealCompletion) {
            // Stamp the token used so subsequent reopens fail fast at the cheaper
            // token_used check instead of re-querying sessions. Single-row by id.
            try {
              await admin
                .from("rebook_tokens")
                .update({ used_at: new Date().toISOString() })
                .eq("id", tok.id);
            } catch (stampErr) {
              console.error("[create-ai-web-call] used_at stamp on block failed (non-fatal)", stampErr);
            }
            console.log("[create-ai-web-call] blocked already_completed", { response_id, token: tok.id, stage: tok?.stage, round: currentRound });
            return json({ error: "already_completed" }, 409);
          }
        } catch (lookupErr) {
          // Safety valve: don't punish a legit candidate for a transient lookup failure.
          console.error("[create-ai-web-call] prior-session lookup threw (non-fatal, allowing call)", lookupErr);
        }
      }
      // ----- end GLITCH 8 -----
    }

    // ----- REPEAT-MINT CAP -----
    // create-web-call bills Retell but does NOT mark the token used, so a
    // determined visitor could tap Begin repeatedly to mint many paid calls on
    // ONE link. Cap real tokens at MINT_CAP successful mints; after that return
    // 429. permanent-test (tok === null) is fully exempt — never capped.
    const MINT_CAP = 3;
    if (tok && typeof tok.mint_count === "number" && tok.mint_count >= MINT_CAP) {
      console.log("[create-ai-web-call] blocked too_many_attempts", { token: tok.id, mint_count: tok.mint_count });
      return json({ error: "too_many_attempts" }, 429);
    }
    // ----- end REPEAT-MINT CAP -----

    // Agent branch: round2_ai → Marissa; everything else (including permanent-test) → Christine.
    const currentStage = tok?.stage || "permanent-test";
    const agentId = currentStage === "round2_ai" ? MARISSA_AGENT_ID : CHRISTINE_AGENT_ID;

    // Best-effort dynamic variables. Any failure → "" and we still start the call.
    let candidateName = "";
    let position = "";
    const candidateTimezone = "Philippine time";
    const salary = (tok?.marissa_salary && String(tok.marissa_salary).trim()) || "";
    const schedule = (tok?.marissa_schedule && String(tok.marissa_schedule).trim()) || "";

    try {
      if (tok?.candidate_name && String(tok.candidate_name).trim()) {
        candidateName = String(tok.candidate_name).trim();
      } else if (response_id) {
        const { data: resp } = await admin
          .from("responses").select("form_id, override_name").eq("id", response_id).maybeSingle();
        candidateName = ((resp as any)?.override_name || "").trim();
        if (!candidateName && resp?.form_id) {
          const { data: qs } = await admin
            .from("questions").select("id, label").eq("form_id", resp.form_id);
          const nameQ = qs?.find((q: any) => /name/i.test(q.label || ""));
          if (nameQ?.id) {
            const { data: ans } = await admin
              .from("answers").select("answer_text")
              .eq("response_id", response_id).eq("question_id", nameQ.id).maybeSingle();
            candidateName = (ans?.answer_text || "").trim();
          }
        }
      }
    } catch (_) { /* fallback "" */ }

    try {
      if (response_id) {
        const { data: resp } = await admin
          .from("responses").select("form_id").eq("id", response_id).maybeSingle();
        if (resp?.form_id) {
          const { data: meta } = await admin
            .from("form_metadata").select("position_title").eq("form_id", resp.form_id).maybeSingle();
          position = (meta?.position_title || "").trim();
        }
      }
    } catch (_) { /* fallback "" */ }

    // Safe fallback: Marissa should never receive an empty position. When
    // form_metadata.position_title is null/missing, pass a graceful default.
    // A non-empty position is fine for round1 (Christine) too.
    if (!position) position = "the role you applied for";

    const retell_llm_dynamic_variables: Record<string, string> = {
      candidate_name: candidateName,
      position,
      candidate_timezone: candidateTimezone,
      salary,
      schedule,
    };

    const retellRes = await fetch("https://api.retellai.com/v2/create-web-call", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${RETELL_API_KEY}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        agent_id: agentId,
        metadata: { response_id, stage: currentStage },
        retell_llm_dynamic_variables,
      }),
    });

    const retellData = await retellRes.json();
    if (!retellRes.ok) {
      console.error("[create-ai-web-call] retell error:", retellData);
      return json({ error: retellData?.message || retellData?.error || "retell_failed", details: retellData }, 500);
    }

    // A real paid call was just minted — stamp the cap counter for real tokens.
    // Single-row by id. Best-effort: a counter-write failure must NEVER drop a
    // call we already paid for. permanent-test (tok === null) is never counted.
    if (tok?.id) {
      try {
        await admin
          .from("rebook_tokens")
          .update({ mint_count: (tok.mint_count || 0) + 1, last_minted_at: new Date().toISOString() })
          .eq("id", tok.id);
      } catch (mintErr) {
        console.error("[create-ai-web-call] mint_count stamp failed (non-fatal)", mintErr);
      }
    }

    return json({ access_token: retellData.access_token, call_id: retellData.call_id, stage: currentStage });
  } catch (e: any) {
    console.error("[create-ai-web-call] exception:", e);
    return json({ error: String(e?.message || e) }, 500);
  }
});
