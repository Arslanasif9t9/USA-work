// generate-offer-pdf: admin-only. Builds a 4-page PDF offer letter from a job_offers row.
import { createClient } from "npm:@supabase/supabase-js@2";
import {
  buildFilename,
  buildOfferPdf,
  offerRowToData,
  uploadPdf,
} from "../_shared/offer-pdf.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type",
};

const json = (b: unknown, status = 200) =>
  new Response(JSON.stringify(b), {
    status,
    headers: { ...corsHeaders, "content-type": "application/json" },
  });

async function requireAdmin(req: Request): Promise<Response | null> {
  const auth = req.headers.get("Authorization") || "";
  if (!auth.startsWith("Bearer ")) return json({ error: "missing_auth" }, 401);
  const userClient = createClient(
    Deno.env.get("SUPABASE_URL")!,
    Deno.env.get("SUPABASE_ANON_KEY")!,
    { global: { headers: { Authorization: auth } } },
  );
  const { data: u } = await userClient.auth.getUser();
  if (!u?.user) return json({ error: "invalid_jwt" }, 401);
  const admin = createClient(
    Deno.env.get("SUPABASE_URL")!,
    Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!,
  );
  const { data: row } = await admin
    .from("users").select("role").eq("id", u.user.id).maybeSingle();
  if (!row || row.role !== "admin") return json({ error: "forbidden" }, 403);
  return null;
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });
  const guard = await requireAdmin(req);
  if (guard) return guard;

  let body: { job_offer_id?: string };
  try { body = await req.json(); } catch { return json({ error: "invalid_json" }, 400); }
  const id = body.job_offer_id;
  if (!id || typeof id !== "string") return json({ error: "missing_job_offer_id" }, 400);

  const admin = createClient(
    Deno.env.get("SUPABASE_URL")!,
    Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!,
  );
  const { data: row, error } = await admin
    .from("job_offers").select("*").eq("id", id).maybeSingle();
  if (error) return json({ error: "db_error", detail: error.message }, 500);
  if (!row) return json({ error: "job_offer_not_found" }, 404);

  const parsed = offerRowToData(row as any);
  if (!parsed.data) {
    return json({ error: "missing_required_fields", missing: parsed.missing }, 400);
  }

  let pdfBytes: Uint8Array;
  let buildWarning: string | null = null;
  try {
    const out = await buildOfferPdf(parsed.data);
    pdfBytes = out.bytes;
    buildWarning = out.warning;
  } catch (e) {
    return json({ error: "pdf_build_failed", detail: (e as Error).message }, 500);
  }

  const filename = buildFilename(parsed.data.offer_reference_id, parsed.data.candidate_name);
  const up = await uploadPdf(pdfBytes, filename);
  if (!up.url) {
    // Fall back to returning base64
    const b64 = btoa(String.fromCharCode(...pdfBytes));
    return json({
      success: true,
      pdf_url: null,
      pdf_base64: b64,
      filename,
      upload_error: up.error,
      font_warning: buildWarning,
    });
  }

  return json({
    success: true,
    pdf_url: up.url,
    filename,
    font_warning: buildWarning,
  });
});
