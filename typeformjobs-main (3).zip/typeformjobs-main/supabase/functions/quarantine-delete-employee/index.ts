// quarantine-delete-employee: VIEW-ONLY removal from the Quarantine dashboard.
// Re-verifies Quarantine password, then flags the job_offer with
// quarantine_removed = true so it drops out of the Quarantine list.
// Does NOT destroy responses/answers/job_offers/storage — the candidate's
// Results record survives. (The ONLY true destroy is purge-candidate-completely
// on the Results page.) Keeps the audit log + boss notification email.
import { createClient } from "npm:@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
const ANON = Deno.env.get("SUPABASE_ANON_KEY")!;
const SERVICE = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
const RESEND_API_KEY = Deno.env.get("RESEND_API_KEY")!;
const QUARANTINE_PASSWORD = Deno.env.get("QUARANTINE_PASSWORD") || "Terminator123!";
const BOSS_INBOX = "spark11179@gmail.com";

async function sendAuditEmail(actor: string, msg: string) {
  if (!RESEND_API_KEY) return;
  try {
    await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: { Authorization: `Bearer ${RESEND_API_KEY}`, "Content-Type": "application/json" },
      body: JSON.stringify({
        from: "EIA Security <talent@expertintuitiveadvisor.com>",
        to: [BOSS_INBOX],
        subject: "[Quarantine] Removed from view",
        text: `${msg} by ${actor} at ${new Date().toISOString()}`,
      }),
    });
  } catch (_) { /* swallow */ }
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });
  try {
    const authHeader = req.headers.get("Authorization");
    if (!authHeader?.startsWith("Bearer ")) {
      return new Response(JSON.stringify({ error: "unauthorized" }), { status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }
    const userClient = createClient(SUPABASE_URL, ANON, { global: { headers: { Authorization: authHeader } } });
    const { data: userData, error: uErr } = await userClient.auth.getUser();
    if (uErr || !userData?.user) {
      return new Response(JSON.stringify({ error: "unauthorized" }), { status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }
    const admin = createClient(SUPABASE_URL, SERVICE);
    const email = (userData.user.email || "").toLowerCase();
    const { data: hr } = await admin.from("hr_users").select("id, display_name").ilike("email", email).maybeSingle();
    const hrId = hr?.id ?? null;
    const actor = hr?.display_name || email;

    const body = await req.json().catch(() => ({}));
    const { job_offer_id, password } = body || {};
    if (!job_offer_id || typeof password !== "string") {
      return new Response(JSON.stringify({ error: "invalid_request" }), { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }
    if (password !== QUARANTINE_PASSWORD) {
      await admin.from("password_audit_log").insert({
        hr_user_id: hrId, password_used: "***wrong***", action_taken: "quarantine_delete_failed", target_resource_id: job_offer_id,
      });
      return new Response(JSON.stringify({ error: "wrong_password" }), { status: 403, headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }

    const { data: offer } = await admin
      .from("job_offers")
      .select("id, candidate_name, employment_status")
      .eq("id", job_offer_id).maybeSingle();
    if (!offer) {
      return new Response(JSON.stringify({ error: "not_found" }), { status: 404, headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }
    if (!["terminated_evaluation", "terminated_regular"].includes(offer.employment_status)) {
      return new Response(JSON.stringify({ error: "not_terminated" }), { status: 409, headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }

    // VIEW-ONLY: flag the offer so it leaves the Quarantine list. Nothing destroyed.
    const { error: updErr } = await admin
      .from("job_offers")
      .update({ quarantine_removed: true })
      .eq("id", job_offer_id);
    if (updErr) throw updErr;

    await admin.from("password_audit_log").insert({
      hr_user_id: hrId, password_used: "***quarantine***",
      action_taken: `quarantine_view_remove:${offer.candidate_name}`,
      target_resource_id: job_offer_id,
    });
    await sendAuditEmail(actor, `Removed ${offer.candidate_name} from Quarantine view (Results record preserved)`);

    return new Response(JSON.stringify({ ok: true }), { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } });
  } catch (e) {
    return new Response(JSON.stringify({ error: (e as Error).message }), { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } });
  }
});
