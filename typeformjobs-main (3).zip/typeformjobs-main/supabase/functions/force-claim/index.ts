import { adminClient, corsHeaders, json, requireHr } from "../_shared/hr-auth.ts";

const CLAIM_PASSWORD = "Claim2828";
const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
const SERVICE_KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });
  const ident = await requireHr(req);
  if (ident instanceof Response) return ident;
  if (!ident.hrId) return json({ error: "no_hr_profile" }, 403);

  const { slot_id, password } = await req.json().catch(() => ({}));
  if (!slot_id || !password) return json({ error: "missing_input" }, 400);
  if (password !== CLAIM_PASSWORD) return json({ error: "invalid_password" }, 403);

  const admin = adminClient();
  const { data: slot } = await admin
    .from("interview_slots")
    .select("id, claimed_by_hr_id")
    .eq("id", slot_id)
    .maybeSingle();
  if (!slot) return json({ error: "slot_not_found" }, 404);
  const previousHr = slot.claimed_by_hr_id;

  const { error } = await admin
    .from("interview_slots")
    .update({
      claimed_by_hr_id: ident.hrId,
      claimed_at: new Date().toISOString(),
      taken_over_from_hr_id: previousHr,
    })
    .eq("id", slot_id);
  if (error) return json({ error: error.message }, 500);

  const ip = req.headers.get("x-forwarded-for") || "";
  await admin.from("password_audit_log").insert({
    hr_user_id: ident.hrId,
    password_used: "Claim2828",
    action_taken: `Force-claimed slot (from HR ${previousHr || "unclaimed"})`,
    target_resource_id: slot_id,
    ip_address: ip,
  });

  fetch(`${SUPABASE_URL}/functions/v1/send-override-audit-email`, {
    method: "POST",
    headers: { Authorization: `Bearer ${SERVICE_KEY}`, "Content-Type": "application/json" },
    body: JSON.stringify({
      action: "force_claim",
      hr_email: ident.email,
      hr_name: ident.displayName,
      slot_id,
      previous_hr_id: previousHr,
    }),
  }).catch(() => {});

  return json({ success: true });
});
