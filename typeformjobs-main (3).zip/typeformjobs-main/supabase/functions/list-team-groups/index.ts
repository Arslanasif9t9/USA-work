// list-team-groups: HR-only. Returns the 5 canonical PMS teams from the shared
// team list (_shared/teams.ts). No external bridge call — the old
// projects.expertintuitiveadvisor.com endpoint is dead. Always returns HTTP 200
// with { ok, groups } so dropdowns keep working.
import { corsHeaders, json, requireHr } from "../_shared/hr-auth.ts";
import { TEAM_OPTIONS } from "../_shared/teams.ts";

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });

  const hr = await requireHr(req);
  if (hr instanceof Response) return hr;

  // Same response shape as before: { ok, groups: [{ id, name }] }.
  const groups = TEAM_OPTIONS.map((t) => ({ id: t.id, name: t.name }));
  return json({ ok: true, groups }, 200);
});
