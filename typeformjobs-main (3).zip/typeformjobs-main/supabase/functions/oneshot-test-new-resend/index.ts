import { createClient } from "npm:@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

Deno.serve(async (_req) => {
  const RESEND_API_KEY = Deno.env.get("RESEND_API_KEY")!;
  const admin = createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!);
  const to = "spark11179@gmail.com";
  const from = "Angela Stein <talent@careers.expertintuitiveadvisor.com>";
  const subject = "Resend migration test — new key + careers sender";

  const r = await fetch("https://api.resend.com/emails", {
    method: "POST",
    headers: { "Content-Type": "application/json", Authorization: `Bearer ${RESEND_API_KEY}` },
    body: JSON.stringify({ from, to: [to], subject, html: "<p>Test ✅ new Resend account, careers domain.</p>" }),
  });
  const j = await r.json().catch(() => ({}));

  await admin.from("email_log").insert({
    stage: "migration_test",
    sender: "resend",
    from_address: "talent@expertintuitiveadvisor.com",
    from_name: "Angela Stein",
    to_address: to,
    subject,
    status: r.ok ? "sent" : "failed",
    sent_at: r.ok ? new Date().toISOString() : null,
    resend_message_id: j?.id ?? null,
    error_message: r.ok ? null : JSON.stringify(j),
  });

  return new Response(JSON.stringify({ ok: r.ok, resend: j }), {
    status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" },
  });
});
