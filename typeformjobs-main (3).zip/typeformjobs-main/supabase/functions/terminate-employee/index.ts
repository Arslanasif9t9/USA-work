// terminate-employee: verifies BOSS termination password, sends termination email
// via Resend (with Gmail BCC), updates job_offers, writes termination_log + audit log,
// and notifies HR + boss inboxes.
import { createClient } from "npm:@supabase/supabase-js@2";
import { sendCompletionBackups } from "../_shared/archive-and-backup.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
const ANON = Deno.env.get("SUPABASE_ANON_KEY")!;
const SERVICE = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
const RESEND_API_KEY = Deno.env.get("RESEND_API_KEY")!;
const GMAIL_USER = (Deno.env.get("GMAIL_USER") ?? "").trim();
const BOSS_PASSWORD = Deno.env.get("BOSS_TERMINATION_PASSWORD") || "Boss2828";

const FROM_NAME = "Cathy Anderson";
const FROM_ADDRESS = "talent@expertintuitiveadvisor.com";
const HR_INBOX = "talent.expertadvisor@outlook.com";
const BOSS_INBOX = "spark11179@gmail.com";

const formatToday = () =>
  new Date().toLocaleDateString("en-US", { weekday: "long", year: "numeric", month: "long", day: "numeric" });

function evaluationEmail(name: string, title: string, today: string) {
  const subject = "Update on your position with Expert Intuitive Advisor Inc.";
  const text = `Dear ${name},\n\nThank you for the time and effort you've invested with Expert Intuitive Advisor Inc. as a ${title}.\n\nAfter careful review during the trial period, we've decided not to continue the engagement beyond this point. The trial period exists to assess fit on both sides, and at this time the role and your path here aren't quite the right match.\n\nThis decision is not a reflection of your character or potential. Many talented individuals find that a particular role or working arrangement isn't the ideal fit — that's exactly why the trial period exists.\n\nEffective ${today}, your engagement with EIA is concluded. Any compensation owed for verified work completed will be processed accordingly. If no work was completed, there is no balance owed.\n\nWe wish you the very best in your future endeavors.\n\nWith respect,\n\nCathy Anderson\nHiring Director\nExpert Intuitive Advisor Inc.`;
  const html = text.replace(/\n/g, "<br/>");
  return { subject, text, html };
}

function regularEmail(name: string, _title: string, _today: string) {
  const firstName = (name || "").trim().split(/\s+/)[0] || name;
  const subject = "Notice of Termination — Expert Intuitive Advisor Inc.";
  const text = `Dear ${firstName},\n\nWe are writing to formally inform you that you have been terminated from Expert Intuitive Advisor Inc., effective immediately. You will no longer be working with the company in any capacity.\n\nPlease understand that this decision is not a reflection of your character, your potential, or the value of what you have brought to the team. We sincerely appreciate the dedication and effort you have shown during your time with us, and we are grateful for your contributions.\n\nAny outstanding matters concerning final payment or company materials will be addressed separately in due course. We kindly ask that you ensure all company information, files, accounts, and access are properly returned or deleted in accordance with the terms of the agreements you have signed.\n\nWe wish you continued success and every good wish in what comes next.\n\nRespectfully,\nCathy Anderson\nHiring Director\nExpert Intuitive Advisor Inc.`;
  const html = text.replace(/\n/g, "<br/>");
  return { subject, text, html };
}

async function sendResend(to: string, subject: string, html: string, text: string, bcc: string[] = []) {
  const r = await fetch("https://api.resend.com/emails", {
    method: "POST",
    headers: { Authorization: `Bearer ${RESEND_API_KEY}`, "Content-Type": "application/json" },
    body: JSON.stringify({
      from: `${FROM_NAME} <${FROM_ADDRESS}>`,
      to: [to],
      bcc: bcc.length ? bcc : undefined,
      reply_to: GMAIL_USER || undefined,
      subject, html, text,
    }),
  });
  const data = await r.json().catch(() => ({}));
  return { ok: r.ok, id: (data as any)?.id ?? null, error: r.ok ? null : JSON.stringify(data) };
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });

  try {
    const authHeader = req.headers.get("Authorization");
    if (!authHeader?.startsWith("Bearer ")) {
      return new Response(JSON.stringify({ error: "unauthorized" }), { status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }
    const userClient = createClient(SUPABASE_URL, ANON, { global: { headers: { Authorization: authHeader } } });
    const { data: userData, error: uErr } = await userClient.auth.getUser();
    if (uErr || !userData?.user) {
      return new Response(JSON.stringify({ error: "unauthorized" }), { status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }
    const adminClient = createClient(SUPABASE_URL, SERVICE);

    const body = await req.json().catch(() => ({}));
    const { job_offer_id, termination_type, password, internal_notes, override_email, skip_email, hr_copy_requested, hr_copy_email_override } = body || {};
    if (!job_offer_id || !["evaluation", "regular"].includes(termination_type) || typeof password !== "string") {
      return new Response(JSON.stringify({ error: "invalid_request" }), { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }
    const skipEmail = skip_email === true;
    const overrideEmailClean = typeof override_email === "string" ? override_email.trim() : "";
    if (overrideEmailClean && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(overrideEmailClean)) {
      return new Response(JSON.stringify({ error: "invalid_email" }), { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }

    // identify HR
    const email = (userData.user.email || "").toLowerCase();
    const { data: hr } = await adminClient.from("hr_users").select("id, display_name, role").ilike("email", email).maybeSingle();
    const hrId = hr?.id ?? null;

    // verify password
    if (password !== BOSS_PASSWORD) {
      await adminClient.from("password_audit_log").insert({
        hr_user_id: hrId, password_used: "***wrong***", action_taken: `terminate_${termination_type}_failed`, target_resource_id: job_offer_id,
      });
      return new Response(JSON.stringify({ error: "wrong_password" }), { status: 403, headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }

    // fetch offer
    const { data: offer, error: oErr } = await adminClient
      .from("job_offers")
      .select("id, candidate_id, candidate_name, candidate_email, position_title, employment_status, override_email")
      .eq("id", job_offer_id).maybeSingle();
    if (oErr || !offer) {
      return new Response(JSON.stringify({ error: "offer_not_found" }), { status: 404, headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }
    if (offer.employment_status !== "active") {
      return new Response(JSON.stringify({ error: "already_terminated" }), { status: 409, headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }

    const recipientEmail = overrideEmailClean || (offer as any).override_email || offer.candidate_email;
    if (!skipEmail && !recipientEmail) {
      return new Response(JSON.stringify({ error: "no_recipient_email" }), { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }

    // persist override (single-row update by exact id) when changed
    if (overrideEmailClean && overrideEmailClean !== (offer as any).override_email) {
      await adminClient.from("job_offers").update({ override_email: overrideEmailClean }).eq("id", job_offer_id);
    }

    const today = formatToday();
    const emailBuilt = termination_type === "evaluation"
      ? evaluationEmail(offer.candidate_name, offer.position_title, today)
      : regularEmail(offer.candidate_name, offer.position_title, today);

    const stageValue = termination_type === "evaluation" ? "stage_termination_evaluation" : "stage_termination_regular";

    let emailLogId: string | null = null;
    let sendRes: { ok: boolean; id: string | null; error: string | null } = { ok: false, id: null, error: null };

    if (skipEmail) {
      // Audit-only: record that the termination email was intentionally not sent.
      const { data: skippedRow } = await adminClient.from("email_log").insert({
        to_address: recipientEmail || "(none)",
        from_address: FROM_ADDRESS,
        from_name: FROM_NAME,
        sender: "resend",
        subject: emailBuilt.subject,
        stage: stageValue,
        status: "skipped",
        candidate_id: null,
        job_offer_id,
      }).select("id").single();
      emailLogId = skippedRow?.id ?? null;
    } else {
      // pre-insert email_log row
      const { data: logRow } = await adminClient.from("email_log").insert({
        to_address: recipientEmail,
        from_address: FROM_ADDRESS,
        from_name: FROM_NAME,
        sender: "resend",
        subject: emailBuilt.subject,
        stage: stageValue,
        status: "pending",
        candidate_id: null,
        job_offer_id,
      }).select("id").single();
      emailLogId = logRow?.id ?? null;

      // send to employee + BCC HR & boss
      sendRes = await sendResend(recipientEmail, emailBuilt.subject, emailBuilt.html, emailBuilt.text, [HR_INBOX, BOSS_INBOX]);

      if (emailLogId) {
        await adminClient.from("email_log").update({
          status: sendRes.ok ? "sent" : "failed",
          sent_at: sendRes.ok ? new Date().toISOString() : null,
          resend_message_id: sendRes.id,
          error_message: sendRes.ok ? null : sendRes.error,
        }).eq("id", emailLogId);
      }
    }

    const newStatus = termination_type === "evaluation" ? "terminated_evaluation" : "terminated_regular";

    await adminClient.from("job_offers").update({
      employment_status: newStatus,
      terminated_at: new Date().toISOString(),
      termination_reason: termination_type,
      terminated_by_hr_id: hrId,
      internal_notes: internal_notes || null,
    }).eq("id", job_offer_id);

    // Additive: mark the candidate's response as terminated so the /track page
    // reflects it (shows the warm "position has already been filled" message
    // instead of the stale "Welcome aboard" / offer_signed state). Fire-and-
    // forget — any failure here must NOT roll back the termination above.
    try {
      const candidateId = (offer as any).candidate_id;
      if (candidateId) {
        const { data: respRow } = await adminClient
          .from("responses")
          .select("id")
          .eq("applicant_id", candidateId)
          .order("submitted_at", { ascending: false })
          .limit(1)
          .maybeSingle();
        const responseId = respRow?.id;
        if (responseId) {
          const { error: stageErr } = await adminClient
            .from("responses")
            .update({ round_stage: "terminated" })
            .eq("id", responseId);
          if (stageErr) {
            console.error("terminate-employee: round_stage update failed", stageErr);
          }
        } else {
          console.warn("terminate-employee: no response found for candidate_id", candidateId);
        }
      }
    } catch (e) {
      console.error("terminate-employee: round_stage write threw", e);
    }

    const { data: termRow } = await adminClient.from("termination_log").insert({
      job_offer_id,
      termination_type,
      terminated_by_hr_id: hrId,
      email_sent_at: skipEmail ? null : (sendRes.ok ? new Date().toISOString() : null),
      email_log_id: emailLogId,
      notes: internal_notes || null,
      hr_copy_requested: !!hr_copy_requested,
      hr_copy_email_override: typeof hr_copy_email_override === "string" ? hr_copy_email_override.trim() || null : null,
    }).select("id").single();

    // === Piece 6 Part A: always-on Outlook backup + optional Gmail copy ===
    // Fire ONLY if primary termination email was accepted by Resend.
    if (!skipEmail && sendRes.ok) {
      try {
        const backup = await sendCompletionBackups({
          admin: adminClient,
          doc_type: "termination",
          recipient_name: offer.candidate_name || recipientEmail || "(unknown)",
          external_reference: `TERM-${job_offer_id}`,
          pdf_bytes: null,
          source_pdf_url: null,
          extras: [
            ["Type", termination_type],
            ["Position", offer.position_title || ""],
            ["Recipient email", recipientEmail || ""],
            ["Termination subject", emailBuilt.subject],
          ],
          hr_copy_requested: !!hr_copy_requested,
          hr_copy_email_override: typeof hr_copy_email_override === "string" ? hr_copy_email_override.trim() || null : null,
          job_offer_id,
          candidate_id: (offer as any).candidate_id || null,
        });
        const patch: Record<string, unknown> = {};
        if (backup.hr_copy_sent) patch.hr_copy_sent_at = new Date().toISOString();
        if (termRow?.id && Object.keys(patch).length) {
          await adminClient.from("termination_log").update(patch).eq("id", termRow.id);
        }
        console.log("[terminate-employee] backups", {
          main_backup_sent: backup.main_backup_sent, hr_copy_sent: backup.hr_copy_sent,
        });
      } catch (e) {
        console.warn("[terminate-employee] backup_warn", (e as Error).message);
      }
    }

    await adminClient.from("password_audit_log").insert({
      hr_user_id: hrId,
      password_used: "***boss***",
      action_taken: `terminate_${termination_type}${skipEmail ? "_no_email" : ""}`,
      target_resource_id: job_offer_id,
    });

    // fire notification log entry (does not send another email; BCC above already covers HR/boss)
    await adminClient.from("notification_log").insert({
      event_type: `termination_${termination_type}${skipEmail ? "_no_email" : ""}`,
      recipient_email: `${HR_INBOX},${BOSS_INBOX}`,
      related_resource_id: job_offer_id,
      status: skipEmail ? "skipped" : (sendRes.ok ? "sent" : "failed"),
    });

    return new Response(JSON.stringify({ ok: true, email_sent: skipEmail ? false : sendRes.ok, email_log_id: emailLogId }), {
      status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (e) {
    return new Response(JSON.stringify({ error: (e as Error).message }), { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } });
  }
});
