// One-shot: ensures hr1@, hr2@, and master admin exist in auth + hr_users.
// Idempotent. Only callable by an authenticated user matching the master email.
import { adminClient, corsHeaders, json, requireHr } from "../_shared/hr-auth.ts";

const MASTER_EMAIL = "spark11179@gmail.com";

const ACCOUNTS = [
  { email: "hr1@expertintuitiveadvisor.com", display_name: "HR1", role: "hr", password: Deno.env.get("HR_ADMIN_NEW_PASSWORD") || "ChangeMeHR1!" },
  { email: "hr2@expertintuitiveadvisor.com", display_name: "HR2", role: "hr", password: Deno.env.get("HR_ADMIN_NEW_PASSWORD") || "ChangeMeHR2!" },
];

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });
  const ident = await requireHr(req);
  if (ident instanceof Response) return ident;
  if (ident.email !== MASTER_EMAIL) return json({ error: "master_admin_only" }, 403);

  const admin = adminClient();
  const results: any[] = [];

  for (const acct of ACCOUNTS) {
    // Try to find existing auth user
    let userId: string | null = null;
    const { data: existing } = await admin.auth.admin.listUsers();
    const match = existing?.users?.find((u: any) => (u.email || "").toLowerCase() === acct.email);
    if (match) {
      userId = match.id;
    } else {
      const { data: created, error } = await admin.auth.admin.createUser({
        email: acct.email, password: acct.password, email_confirm: true,
      });
      if (error) { results.push({ email: acct.email, error: error.message }); continue; }
      userId = created.user?.id || null;
    }

    // Upsert hr_users
    const { data: hrRow } = await admin
      .from("hr_users")
      .select("id")
      .ilike("email", acct.email)
      .maybeSingle();
    if (!hrRow) {
      await admin.from("hr_users").insert({
        email: acct.email, display_name: acct.display_name, role: acct.role, is_active: true,
      });
    }

    // Also ensure a row in public.users with admin role so they pass ProtectedRoute
    if (userId) {
      await admin.from("users").upsert({ id: userId, email: acct.email, role: "admin" }, { onConflict: "id" });
    }

    results.push({ email: acct.email, ok: true, user_id: userId });
  }

  // Ensure master admin has hr_users row with master_admin role
  const { data: masterHr } = await admin
    .from("hr_users").select("id").ilike("email", MASTER_EMAIL).maybeSingle();
  if (!masterHr) {
    await admin.from("hr_users").insert({
      email: MASTER_EMAIL, display_name: "Master Admin", role: "master_admin", is_active: true,
    });
  } else {
    await admin.from("hr_users").update({ role: "master_admin" }).eq("id", masterHr.id);
  }

  return json({ success: true, results });
});
