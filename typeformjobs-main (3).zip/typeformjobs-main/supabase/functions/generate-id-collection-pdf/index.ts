// generate-id-collection-pdf: builds an EIA-branded ID Collection PDF (with the
// two embedded ID photos) for a row, uploads to the public `offer-letters`
// bucket under id-collection/, returns the URL. Auth: accepts the service-role
// token (so decide-id-collection can call it) OR an admin user JWT.
// SEPARATE clone of generate-cash-advance-pdf — leave/cash-advance untouched.
import { createClient } from "npm:@supabase/supabase-js@2";
import { buildIdCollectionPdf, type IdCollectionData, type IdPhotoInput } from "../_shared/id-collection-pdf.ts";
import { uploadPdf } from "../_shared/offer-pdf.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
const ANON = Deno.env.get("SUPABASE_ANON_KEY")!;
const SVC = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;

const json = (b: unknown, status = 200) =>
  new Response(JSON.stringify(b), {
    status,
    headers: { ...corsHeaders, "content-type": "application/json" },
  });

async function authorize(req: Request): Promise<Response | null> {
  const auth = req.headers.get("Authorization") || "";
  if (!auth.startsWith("Bearer ")) return json({ error: "missing_auth" }, 401);
  const token = auth.slice(7).trim();
  if (token === SVC) return null;
  const userClient = createClient(SUPABASE_URL, ANON, { global: { headers: { Authorization: auth } } });
  const { data: u } = await userClient.auth.getUser();
  if (!u?.user) return json({ error: "invalid_jwt" }, 401);
  const admin = createClient(SUPABASE_URL, SVC);
  const { data: row } = await admin.from("users").select("role").eq("id", u.user.id).maybeSingle();
  if (!row || row.role !== "admin") return json({ error: "forbidden" }, 403);
  return null;
}

// Stored URL is "<bucket>/<path>" e.g. "candidate-files/idcollection/<tok>/photo1-<ts>.jpg".
// Download the bytes via the storage REST object endpoint (service-role auth) and
// return raw bytes + ext. Uses fetch rather than the SDK .download() helper for
// reliability against private buckets.
async function loadPhoto(_admin: ReturnType<typeof createClient>, stored: string | null): Promise<IdPhotoInput | null> {
  if (!stored || !stored.trim()) return null;
  try {
    let bucket = "candidate-files";
    let path = stored.trim();
    const slash = path.indexOf("/");
    if (slash > 0) {
      bucket = path.slice(0, slash);
      path = path.slice(slash + 1);
    }
    const ext = (path.split(".").pop() || "").toLowerCase().replace(/[^a-z0-9]/g, "");
    const encodedPath = path.split("/").map(encodeURIComponent).join("/");
    const r = await fetch(`${SUPABASE_URL}/storage/v1/object/${bucket}/${encodedPath}`, {
      headers: { Authorization: `Bearer ${SVC}`, apikey: SVC },
    });
    if (!r.ok) return { bytes: null, ext };
    const bytes = new Uint8Array(await r.arrayBuffer());
    return { bytes: bytes.byteLength ? bytes : null, ext };
  } catch {
    return { bytes: null, ext: null };
  }
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });
  const guard = await authorize(req);
  if (guard) return guard;

  let body: { leave_request_id?: string };
  try { body = await req.json(); } catch { return json({ error: "invalid_json" }, 400); }
  const { leave_request_id } = body || {};
  if (!leave_request_id) return json({ error: "missing_leave_request_id" }, 400);

  const admin = createClient(SUPABASE_URL, SVC);
  const { data: row, error } = await admin
    .from("leave_requests")
    .select("*")
    .eq("id", leave_request_id)
    .maybeSingle();
  if (error) return json({ error: "lookup_failed", detail: error.message }, 500);
  if (!row) return json({ error: "not_found" }, 404);

  const r = row as any;

  const [photo1, photo2] = await Promise.all([
    loadPhoto(admin, r.id_photo_1_url),
    loadPhoto(admin, r.id_photo_2_url),
  ]);

  const data: IdCollectionData = {
    signer_name: r.signer_name || r.typed_name || "Employee",
    reference: r.external_reference,
    id_hr_message: r.id_hr_message,
    id_text_style: r.id_text_style,
    id_body_note: r.id_body_note,
    photo1,
    photo2,
    typed_name: r.typed_name,
    signature_data: r.signature_data,
    signature_date: r.signature_date,
    status: r.status,
    hr_decision_note: r.hr_decision_note,
    decided_at: r.decided_at,
  };

  let out;
  try {
    out = await buildIdCollectionPdf(data);
  } catch (e) {
    return json({ error: "pdf_build_failed", detail: (e as Error).message }, 500);
  }

  const lastName = (data.signer_name || "Employee").trim().split(/\s+/).slice(-1)[0]?.replace(/[^A-Za-z0-9_-]/g, "_") || "Employee";
  const filename = `id-collection/${data.reference}-${lastName}.pdf`;
  const up = await uploadPdf(out.bytes, filename);
  if (!up.url) return json({ error: "upload_failed", detail: up.error }, 500);

  return json({
    success: true,
    pdf_url: up.url,
    filename,
    page_count: out.pageCount,
    font_warning: out.warning,
  });
});
