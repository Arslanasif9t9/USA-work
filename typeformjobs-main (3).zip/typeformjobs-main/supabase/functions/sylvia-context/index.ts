import { createClient } from "npm:@supabase/supabase-js@2";
import { teamNameById } from "../_shared/teams.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type, x-sylvia-key",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

const json = (body: unknown, status = 200) =>
  new Response(JSON.stringify(body), {
    status,
    headers: { ...corsHeaders, "Content-Type": "application/json" },
  });

const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
const SERVICE_KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
const PMS_URL = Deno.env.get("PMS_SUPABASE_URL")!;
const PMS_KEY = Deno.env.get("PMS_SERVICE_ROLE_KEY")!;
const BRIDGE_KEY = Deno.env.get("SYLVIA_BRIDGE_KEY")!;

async function fetchBoardTasks(boardId: string) {
  const pms = createClient(PMS_URL, PMS_KEY);
  const { data: items } = await pms
    .from("items")
    .select("id, task_code, name, group_id, sort_order")
    .eq("board_id", boardId)
    .is("deleted_at", null)
    .is("parent_item_id", null);

  const { data: groups } = await pms
    .from("groups")
    .select("id, name, sort_order")
    .eq("board_id", boardId);
  const groupMap = new Map<string, { name: string; sort_order: number }>();
  for (const g of groups ?? [])
    groupMap.set(g.id, { name: g.name, sort_order: g.sort_order ?? 0 });

  const { data: cols } = await pms
    .from("columns")
    .select("id, column_type")
    .eq("board_id", boardId)
    .is("archived_at", null)
    .in("column_type", ["status", "priority"]);
  const statusCol = cols?.find((c) => c.column_type === "status") ?? null;
  const priorityCol = cols?.find((c) => c.column_type === "priority") ?? null;

  const colIds = [statusCol?.id, priorityCol?.id].filter(Boolean) as string[];
  const labelMap = new Map<string, { name: string; color: string | null }>();
  if (colIds.length > 0) {
    const { data: labels } = await pms
      .from("column_labels")
      .select("id, name, color")
      .in("column_id", colIds);
    for (const l of labels ?? []) labelMap.set(l.id, { name: l.name, color: l.color });
  }

  const itemIds = (items ?? []).map((i) => i.id);
  const statusByItem = new Map<string, string | null>();
  const priorityByItem = new Map<string, string | null>();
  if (itemIds.length > 0 && colIds.length > 0) {
    const { data: vals } = await pms
      .from("item_column_values")
      .select("item_id, column_id, value")
      .in("column_id", colIds)
      .in("item_id", itemIds);
    for (const v of vals ?? []) {
      const labelId = (v.value as any)?.label_id ?? null;
      if (statusCol && v.column_id === statusCol.id) statusByItem.set(v.item_id, labelId);
      else if (priorityCol && v.column_id === priorityCol.id)
        priorityByItem.set(v.item_id, labelId);
    }
  }

  const tasks = (items ?? []).map((it) => {
    const g = it.group_id ? groupMap.get(it.group_id) : null;
    const sLabelId = statusByItem.get(it.id) ?? null;
    const pLabelId = priorityByItem.get(it.id) ?? null;
    return {
      task_code: it.task_code,
      name: it.name,
      group_name: g?.name ?? null,
      status: sLabelId ? labelMap.get(sLabelId)?.name ?? null : null,
      priority: pLabelId ? labelMap.get(pLabelId)?.name ?? null : null,
      _gsort: g?.sort_order ?? 999999,
      _isort: it.sort_order ?? 0,
    };
  });
  tasks.sort((a, b) => a._gsort - b._gsort || a._isort - b._isort);
  return tasks.map(({ _gsort, _isort, ...rest }) => rest);
}

// Active On-Hold blocklist match (case-insensitive on full_name OR email).
// Fails CLOSED: any query error is treated as a block so a non-active identity
// can never leak data through a transient failure.
async function hasActiveBlock(
  admin: any,
  names: (string | null | undefined)[],
  emails: (string | null | undefined)[],
): Promise<boolean> {
  const orParts: string[] = [];
  const seen = new Set<string>();
  for (const n of names) {
    const v = (n ?? "").trim();
    if (v && !seen.has("n:" + v.toLowerCase())) { seen.add("n:" + v.toLowerCase()); orParts.push(`full_name.ilike.${v}`); }
  }
  for (const e of emails) {
    const v = (e ?? "").trim();
    if (v && !seen.has("e:" + v.toLowerCase())) { seen.add("e:" + v.toLowerCase()); orParts.push(`email.ilike.${v}`); }
  }
  if (orParts.length === 0) return false;
  const { data, error } = await admin
    .from("sylvia_blocklist")
    .select("id")
    .is("removed_at", null)
    .or(orParts.join(","))
    .limit(1);
  if (error) { console.error("sylvia_blocklist check failed", error); return true; }
  return !!(data && data.length > 0);
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });
  try {
    const sylviaKey = req.headers.get("x-sylvia-key");
    if (!sylviaKey || sylviaKey !== BRIDGE_KEY) return json({ error: "unauthorized" }, 401);

    const { response_id } = await req.json().catch(() => ({}));
    if (!response_id) return json({ error: "missing response_id" }, 400);

    const admin = createClient(SUPABASE_URL, SERVICE_KEY);

    // 1. employee_boards row
    const { data: eb } = await admin
      .from("employee_boards")
      .select(
        "board_id, board_name, assigned_agent, onboarding_notes, onboarding_credentials",
      )
      .eq("response_id", response_id)
      .maybeSingle();

    // 2. global daily brief
    const { data: cfg } = await admin
      .from("scheduling_config")
      .select("sylvia_daily_brief")
      .eq("id", 1)
      .maybeSingle();

    // 4. candidate identity + status gate
    let candidate_name: string | null = null;
    let candidate_email: string | null = null;
    let position_title: string | null = null;
    let offerRow: any = null;
    const { data: resp } = await admin
      .from("responses")
      .select("applicant_id, round_stage, disqualified_at, final_outcome")
      .eq("id", response_id)
      .maybeSingle();
    if (resp?.applicant_id) {
      const { data: offer } = await admin
        .from("job_offers")
        .select("candidate_name, candidate_email, override_email, position_title, signed_at, employment_status, quarantine_removed, hold_status")
        .eq("candidate_id", resp.applicant_id)
        .order("signed_at", { ascending: false, nullsFirst: false })
        .limit(1)
        .maybeSingle();
      if (offer) {
        offerRow = offer;
        candidate_name = offer.candidate_name ?? null;
        candidate_email = offer.candidate_email ?? offer.override_email ?? null;
        position_title = offer.position_title ?? null;
      }
    }

    // ── SECURITY GATE: terminated / disqualified / on-hold / quarantined / blocklisted → NO data ──
    const blockedByIdentity = await hasActiveBlock(
      admin,
      [candidate_name],
      [candidate_email, offerRow?.override_email],
    );
    const inactive =
      (offerRow?.employment_status != null && offerRow.employment_status !== "active") ||
      offerRow?.hold_status === "on_hold" ||
      offerRow?.quarantine_removed === true ||
      (resp?.round_stage === "disqualified" || resp?.round_stage === "terminated") ||
      resp?.disqualified_at != null ||
      resp?.final_outcome === "disqualified_after_matched" ||
      blockedByIdentity;

    if (inactive) {
      return json({
        found: true,
        blocked: true,
        candidate_name,
      });
    }


    // 3. board tasks (only if board_id present)
    let tasks: any[] = [];
    if (eb?.board_id) {
      try {
        tasks = await fetchBoardTasks(eb.board_id);
      } catch (e) {
        console.error("fetchBoardTasks failed", e);
        tasks = [];
      }
    }

    // ── ADDITIVE: queued team assignment + instruction (does NOT touch the
    // employee_boards resolution above). team_name comes from the shared map
    // with passthrough for manual free-text assignments. ──
    const { data: asg } = await admin
      .from("responses")
      .select("assigned_group_id, sylvia_instruction")
      .eq("id", response_id)
      .maybeSingle();
    const team_name = teamNameById(asg?.assigned_group_id);
    const instruction = (asg?.sylvia_instruction ?? null) || null;

    return json({
      candidate_name,
      position_title,
      assigned_agent: eb?.assigned_agent ?? null,
      board_name: eb?.board_name ?? null,
      team_name,
      instruction,
      daily_brief: (cfg as any)?.sylvia_daily_brief ?? null,
      onboarding_notes: eb?.onboarding_notes ?? null,
      onboarding_credentials: eb?.onboarding_credentials ?? null,
      tasks,
    });
  } catch (e: any) {
    return json({ error: String(e?.message || e) }, 500);
  }
});
