// validate-rebook-token: PUBLIC. Returns token info if valid (used by /rebook page).
import { createClient } from "npm:@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};
const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
const SERVICE = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
const json = (b: unknown, s = 200) =>
  new Response(JSON.stringify(b), { status: s, headers: { ...corsHeaders, "Content-Type": "application/json" } });

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });
  try {
    const { token } = await req.json();
    if (!token) return json({ error: "missing_token" }, 400);
    const admin = createClient(SUPABASE_URL, SERVICE);
    const { data: tok } = await admin.from("rebook_tokens").select("*").eq("token", token).maybeSingle();
    if (!tok) return json({ valid: false, reason: "not_found" });
    if (tok.used_at) return json({ valid: false, reason: "used" });
    if (new Date(tok.expires_at) < new Date()) return json({ valid: false, reason: "expired" });

    // Best-effort position_title via form_metadata
    let position_title: string | null = null;
    const formId = tok.form_id || null;
    if (formId) {
      const { data: meta } = await admin.from("form_metadata").select("position_title").eq("form_id", formId).maybeSingle();
      position_title = meta?.position_title || null;
      if (!position_title) {
        const { data: form } = await admin.from("forms").select("title").eq("id", formId).maybeSingle();
        position_title = form?.title || null;
      }
    } else if (tok.response_id) {
      const { data: resp } = await admin.from("responses").select("form_id").eq("id", tok.response_id).maybeSingle();
      if (resp?.form_id) {
        const { data: meta } = await admin.from("form_metadata").select("position_title").eq("form_id", resp.form_id).maybeSingle();
        position_title = meta?.position_title || null;
        if (!position_title) {
          const { data: form } = await admin.from("forms").select("title").eq("id", resp.form_id).maybeSingle();
          position_title = form?.title || null;
        }
      }
    }

    return json({
      valid: true,
      stage: tok.stage || "reschedule",
      candidate_name: tok.candidate_name,
      candidate_email: tok.candidate_email,
      expires_at: tok.expires_at,
      position_title,
      has_curated: Array.isArray(tok.curated_slot_ids) && tok.curated_slot_ids.length > 0,
    });
  } catch (e: any) {
    return json({ error: "internal", details: String(e?.message || e) }, 500);
  }
});
