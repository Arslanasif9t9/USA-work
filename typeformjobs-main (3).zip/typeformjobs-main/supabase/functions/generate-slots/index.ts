// generate-slots: seeds interview_slots for next N days according to scheduling_config.
// Public (verify_jwt=false). Idempotent via UNIQUE(slot_start).
import { createClient } from "npm:@supabase/supabase-js@2";
import { manilaParts, manilaWallToUtc } from "../_shared/manila.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, GET, OPTIONS",
};

const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
const SERVICE_KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;

function addMinutes(t: string, n: number): string {
  const [hh, mm] = t.split(":").map((x) => parseInt(x, 10));
  const total = hh * 60 + mm + n;
  const H = Math.floor(total / 60);
  const M = total % 60;
  return `${String(H).padStart(2, "0")}:${String(M).padStart(2, "0")}`;
}

function timeToMin(t: string): number {
  const [hh, mm] = t.split(":").map((x) => parseInt(x, 10));
  return hh * 60 + mm;
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });
  const admin = createClient(SUPABASE_URL, SERVICE_KEY);

  try {
    const { data: cfg } = await admin.from("scheduling_config").select("*").eq("id", 1).maybeSingle();
    if (!cfg) {
      return new Response(JSON.stringify({ error: "no_config" }), {
        status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const days = 14;
    const workingDays: number[] = cfg.working_days || [1, 2, 3, 4, 5, 6];
    const duration = cfg.slot_duration_minutes || 30;
    const oooActive = cfg.is_out_of_office === true;
    const oooStart = cfg.out_of_office_start ? new Date(cfg.out_of_office_start) : null;
    const oooEnd = cfg.out_of_office_end ? new Date(cfg.out_of_office_end) : null;

    const now = new Date();
    const today = manilaParts(now);
    const rows: Array<Record<string, unknown>> = [];

    for (let offset = 0; offset < days; offset++) {
      // Compute target Manila date by adding offset days to today's manila date.
      const base = new Date(Date.UTC(today.year, today.month - 1, today.day) + offset * 86400000);
      const y = base.getUTCFullYear();
      const m = base.getUTCMonth() + 1;
      const d = base.getUTCDate();
      const pad = (n: number) => String(n).padStart(2, "0");
      const dateStr = `${y}-${pad(m)}-${pad(d)}`;

      // Determine weekday for that date in Manila by constructing noon UTC and asking manilaParts
      const noonUtc = manilaWallToUtc(dateStr, "12:00");
      const wd = manilaParts(noonUtc).weekday;

      if (!workingDays.includes(wd)) continue;

      // OOO check
      if (oooActive && oooStart && oooEnd) {
        const dCheck = new Date(`${dateStr}T00:00:00Z`);
        if (dCheck >= oooStart && dCheck <= oooEnd) continue;
      }

      // Hours: Sat uses saturday_hours_*, else weekday
      const isSat = wd === 6;
      const startT: string = isSat
        ? (cfg.saturday_hours_start || "10:00:00").slice(0, 5)
        : (cfg.working_hours_start || "10:00:00").slice(0, 5);
      const endT: string = isSat
        ? (cfg.saturday_hours_end || "14:00:00").slice(0, 5)
        : (cfg.working_hours_end || "18:00:00").slice(0, 5);

      const endMin = timeToMin(endT);
      for (let cur = startT; timeToMin(cur) <= endMin; cur = addMinutes(cur, duration)) {
        const slotStart = manilaWallToUtc(dateStr, cur);
        if (slotStart.getTime() < now.getTime()) continue;
        const slotEnd = new Date(slotStart.getTime() + duration * 60000);
        rows.push({
          slot_start: slotStart.toISOString(),
          slot_end: slotEnd.toISOString(),
          slot_date: dateStr,
          slot_time: `${cur}:00`,
          status: "available",
          created_by_admin: false,
        });
      }
    }

    let inserted = 0;
    if (rows.length > 0) {
      // Use upsert with ignoreDuplicates to skip existing slots
      const { data, error } = await admin
        .from("interview_slots")
        .upsert(rows, { onConflict: "slot_start", ignoreDuplicates: true })
        .select("id");
      if (error) {
        console.error("insert error", error);
        return new Response(JSON.stringify({ error: error.message }), {
          status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
      inserted = data?.length || 0;
    }

    return new Response(JSON.stringify({
      success: true,
      candidate_rows: rows.length,
      inserted,
    }), { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } });
  } catch (e) {
    console.error("generate-slots error", e);
    return new Response(JSON.stringify({ error: String(e) }), {
      status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
