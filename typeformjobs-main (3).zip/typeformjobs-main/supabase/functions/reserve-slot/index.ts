// reserve-slot: PUBLIC. Atomic reservation for 10 minutes.
import { createClient } from "npm:@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

const UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });
  const admin = createClient(
    Deno.env.get("SUPABASE_URL")!,
    Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!,
  );

  let body: { slot_id?: string };
  try { body = await req.json(); } catch {
    return new Response(JSON.stringify({ error: "invalid_json" }), {
      status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
  const slotId = body.slot_id;
  if (!slotId || !UUID_RE.test(slotId)) {
    return new Response(JSON.stringify({ error: "invalid_slot_id" }), {
      status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }

  const { data: cfg } = await admin.from("scheduling_config").select("reservation_timer_minutes").eq("id", 1).maybeSingle();
  const minutes = cfg?.reservation_timer_minutes || 10;
  const reservedUntil = new Date(Date.now() + minutes * 60 * 1000).toISOString();
  const nowIso = new Date().toISOString();

  // Atomic update: only succeed if available OR expired-reserved.
  const { data, error } = await admin
    .from("interview_slots")
    .update({ status: "reserved", reserved_until: reservedUntil })
    .eq("id", slotId)
    .or(`status.eq.available,and(status.eq.reserved,reserved_until.lt.${nowIso})`)
    .select("id, reserved_until");

  if (error) {
    return new Response(JSON.stringify({ error: error.message }), {
      status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
  if (!data || data.length === 0) {
    return new Response(JSON.stringify({ error: "slot_unavailable", code: "taken" }), {
      status: 409, headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }

  return new Response(JSON.stringify({
    success: true,
    slot_id: slotId,
    reserved_until: reservedUntil,
    reservation_seconds: minutes * 60,
  }), { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } });
});
