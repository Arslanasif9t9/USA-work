// decide-onboarding-quiz: HR-only. Approve / Decline a candidate who PASSED
// the onboarding quiz and is waiting in the HR Approval queue (status
// 'passed_pending'). Approve -> 'passed_approved' (and the next-step PMS invite
// can be issued). Decline -> 'passed_declined'.
//
// ADDITIVE: after the decision write succeeds we send the candidate a warm,
// EIA-branded decision email (Resend, direct api.resend.com) carrying their
// result report, and log both sends to email_log. Email failures are
// failure-safe — they NEVER block or roll back the HR decision.
import { adminClient, corsHeaders, json, requireHr } from "../_shared/hr-auth.ts";

const RESEND_API_KEY = Deno.env.get("RESEND_API_KEY")!;

// Sender read from config (single place to change). Verified domain — matches
// the rest of the onboarding flow (send-onboarding-test-invite).
const FROM_NAME = "Angela Stein / HR – Talent Manager";
const FROM_ADDR = "talent@expertintuitiveadvisor.com";
const FROM = `${FROM_NAME} <${FROM_ADDR}>`;

const NAVY = "#1a2547";
const GOLD = "#b08d57";

const htmlEscape = (s: string) =>
  String(s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;").replace(/'/g, "&#39;");

function fmtDate(iso: string | null): string {
  const d = iso ? new Date(iso) : new Date();
  return d.toLocaleDateString("en-US", { year: "numeric", month: "long", day: "numeric" });
}

function shell(innerHtml: string): string {
  const year = new Date().getFullYear();
  return `<!doctype html><html><body style="margin:0;padding:0;background:#faf8f3;font-family:Inter,Arial,sans-serif;color:${NAVY}">
  <table width="100%" cellpadding="0" cellspacing="0" style="background:#faf8f3;padding:32px 0">
    <tr><td align="center">
      <table width="560" cellpadding="0" cellspacing="0" style="background:#ffffff;border-top:4px solid ${GOLD};padding:34px 34px 30px 34px">
        <tr><td style="text-align:center;padding-bottom:6px">
          <div style="font-family:'Cormorant Garamond',Georgia,serif;font-weight:600;font-size:28px;letter-spacing:6px;color:${NAVY}">EIA</div>
          <div style="font-size:10px;letter-spacing:2px;text-transform:uppercase;color:${GOLD};margin-top:6px">Expert Intuitive Advisor Inc.</div>
          <div style="height:1px;background:${GOLD};width:60px;margin:18px auto 22px"></div>
        </td></tr>
        <tr><td>${innerHtml}</td></tr>
        <tr><td style="padding-top:22px">
          <div style="height:1px;background:#e6e0d1;margin-bottom:14px"></div>
          <div style="font-size:11px;color:#9a9588;text-align:center">&copy; ${year} Expert Intuitive Advisor Inc.</div>
        </td></tr>
      </table>
    </td></tr>
  </table>
  </body></html>`;
}

function resultCard(rows: Array<[string, string]>): string {
  const cells = rows.map(([k, v]) =>
    `<tr>
       <td style="padding:6px 0;font-size:13px;color:#6b6655;font-family:Inter,Arial,sans-serif">${htmlEscape(k)}</td>
       <td style="padding:6px 0;font-size:14px;font-weight:600;color:${NAVY};text-align:right;font-family:Inter,Arial,sans-serif">${htmlEscape(v)}</td>
     </tr>`).join("");
  return `<div style="background:#faf8f3;border-left:4px solid ${GOLD};border-radius:4px;padding:14px 20px;margin:18px 0">
    <div style="font-family:Inter,Arial,sans-serif;font-weight:600;font-size:12px;letter-spacing:2px;text-transform:uppercase;color:${GOLD};margin-bottom:6px">Result Report</div>
    <table width="100%" cellpadding="0" cellspacing="0">${cells}</table>
  </div>`;
}

function approvedEmail(firstName: string, rows: Array<[string, string]>) {
  const inner = `
    <div style="font-family:'Cormorant Garamond',Georgia,serif;font-size:24px;color:${NAVY};font-weight:600;margin-bottom:4px">Congratulations, ${htmlEscape(firstName)}</div>
    <div style="font-size:11px;letter-spacing:3px;text-transform:uppercase;color:${GOLD};margin-bottom:16px">Onboarding Certification — Passed</div>
    <p style="font-size:15px;line-height:1.7;color:${NAVY};margin:0 0 14px 0">We're delighted to let you know that you have <strong>passed your onboarding certification</strong>. Thank you for the care and attention you brought to the orientation and the check — it truly shows.</p>
    ${resultCard(rows)}
    <p style="font-size:15px;line-height:1.7;color:${NAVY};margin:14px 0 0 0">This is an exciting step, and we're glad to have you with us. Your team will contact you with next steps.</p>
    <p style="font-size:14px;line-height:1.6;color:${NAVY};margin:24px 0 0 0">Warm regards,<br/><span style="color:${GOLD}">Angela Stein</span><br/>HR – Talent Manager<br/>Expert Intuitive Advisor Inc.</p>`;
  const text = `Congratulations, ${firstName}

We're delighted to let you know that you have passed your onboarding certification. Thank you for the care and attention you brought to the orientation and the check.

Result Report
${rows.map(([k, v]) => `- ${k}: ${v}`).join("\n")}

This is an exciting step, and we're glad to have you with us. Your team will contact you with next steps.

Warm regards,
Angela Stein
HR – Talent Manager
Expert Intuitive Advisor Inc.`;
  return { subject: "Onboarding Certification — Passed", html: shell(inner), text };
}

function declinedEmail(firstName: string, rows: Array<[string, string]>) {
  const inner = `
    <div style="font-family:'Cormorant Garamond',Georgia,serif;font-size:24px;color:${NAVY};font-weight:600;margin-bottom:4px">Thank you, ${htmlEscape(firstName)}</div>
    <div style="font-size:11px;letter-spacing:3px;text-transform:uppercase;color:${GOLD};margin-bottom:16px">Onboarding Certification — Result</div>
    <p style="font-size:15px;line-height:1.7;color:${NAVY};margin:0 0 14px 0">Thank you for completing your EIA onboarding. We genuinely appreciate the time and effort you put into the orientation and the certification check.</p>
    <p style="font-size:15px;line-height:1.7;color:${NAVY};margin:0 0 14px 0">After review, you did not pass the certification this time. Please know this reflects only this particular check — not your potential.</p>
    ${resultCard(rows)}
    <p style="font-size:15px;line-height:1.7;color:${NAVY};margin:14px 0 0 0">The door remains open, and we'd warmly welcome the chance to connect again in the future. Thank you once more for your interest in Expert Intuitive Advisor.</p>
    <p style="font-size:14px;line-height:1.6;color:${NAVY};margin:24px 0 0 0">Warm regards,<br/><span style="color:${GOLD}">Angela Stein</span><br/>HR – Talent Manager<br/>Expert Intuitive Advisor Inc.</p>`;
  const text = `Thank you, ${firstName}

Thank you for completing your EIA onboarding. We genuinely appreciate the time and effort you put into the orientation and the certification check.

After review, you did not pass the certification this time. Please know this reflects only this particular check — not your potential.

Result Report
${rows.map(([k, v]) => `- ${k}: ${v}`).join("\n")}

The door remains open, and we'd warmly welcome the chance to connect again in the future. Thank you once more for your interest in Expert Intuitive Advisor.

Warm regards,
Angela Stein
HR – Talent Manager
Expert Intuitive Advisor Inc.`;
  return { subject: "Onboarding Certification — Result", html: shell(inner), text };
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });
  if (req.method !== "POST") return json({ error: "method_not_allowed" }, 405);

  const hr = await requireHr(req);
  if (hr instanceof Response) return hr;

  let body: { token_id?: unknown; decision?: unknown };
  try { body = await req.json(); } catch { return json({ error: "bad_request" }, 400); }
  const tokenId = typeof body.token_id === "string" ? body.token_id.trim() : "";
  const decision = body.decision === "approved" ? "approved"
    : body.decision === "declined" ? "declined" : "";
  if (!tokenId) return json({ error: "token_id_required" }, 400);
  if (!decision) return json({ error: "decision_invalid" }, 400);

  const admin = adminClient();
  const { data: tok } = await admin
    .from("onboarding_quiz_tokens").select("*").eq("id", tokenId).maybeSingle();
  if (!tok) return json({ error: "not_found" }, 404);
  if (tok.status !== "passed_pending") {
    return json({ error: "not_pending", status: tok.status }, 409);
  }

  const newStatus = decision === "approved" ? "passed_approved" : "passed_declined";
  await admin.from("onboarding_quiz_tokens")
    .update({ status: newStatus })
    .eq("id", tokenId);

  // NOTE: On approve, the next-step PMS team invite is issued here once the
  // exact bridge endpoint/template is confirmed. assigned_group_id is on the
  // token row (tok.assigned_group_id).

  // ── ADDITIVE: warm candidate decision email (failure-safe) ──
  let emailWarning: string | null = null;
  try {
    const toAddr = (tok.candidate_email || "").trim();
    const emailRe = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (toAddr && emailRe.test(toAddr)) {
      const firstName = ((tok.candidate_name || "").split(" ")[0] || "there").trim();

      // Pull the relevant attempt for the result report.
      // Approve -> the passing attempt; Decline -> the most recent attempt.
      let attemptQ = admin
        .from("onboarding_quiz_attempts")
        .select("attempt_number, score, total, passed, created_at")
        .eq("token_id", tokenId);
      if (decision === "approved") attemptQ = attemptQ.eq("passed", true);
      const { data: attempts } = await attemptQ
        .order("attempt_number", { ascending: false })
        .limit(1);
      const att = (attempts && attempts[0]) || null;

      const score = att?.score ?? null;
      const total = att?.total ?? null;
      const scoreStr = score != null && total != null ? `${score}/${total}` : "—";
      const attemptsUsed = tok.attempts_used ?? att?.attempt_number ?? null;
      const completedDate = fmtDate(tok.passed_at || att?.created_at || null);

      const built = decision === "approved"
        ? approvedEmail(firstName, [
            ["Score", scoreStr],
            ["Passed on attempt", String(att?.attempt_number ?? attemptsUsed ?? "—")],
            ["Date completed", completedDate],
          ])
        : declinedEmail(firstName, [
            ["Score", scoreStr],
            ["Attempts used", String(attemptsUsed ?? "—")],
            ["Date completed", completedDate],
          ]);

      const stage = decision === "approved" ? "onboarding_quiz_approved" : "onboarding_quiz_declined";

      let sendOk = false;
      let resendId: string | null = null;
      let errMsg: string | null = null;
      try {
        const sendRes = await fetch("https://api.resend.com/emails", {
          method: "POST",
          headers: { "Content-Type": "application/json", Authorization: `Bearer ${RESEND_API_KEY}` },
          body: JSON.stringify({ from: FROM, to: [toAddr], subject: built.subject, html: built.html, text: built.text }),
        });
        const sendJson = await sendRes.json().catch(() => ({}));
        sendOk = sendRes.ok;
        resendId = (sendJson as { id?: string })?.id || null;
        if (!sendRes.ok) errMsg = JSON.stringify(sendJson).slice(0, 500);
      } catch (e) {
        errMsg = String((e as Error)?.message || e);
      }
      if (!sendOk) emailWarning = errMsg;

      await admin.from("email_log").insert({
        candidate_id: null,
        stage,
        sender: "resend",
        from_address: FROM_ADDR,
        from_name: FROM_NAME,
        to_address: toAddr,
        subject: built.subject,
        status: sendOk ? "sent" : "failed",
        sent_at: sendOk ? new Date().toISOString() : null,
        resend_message_id: resendId,
        error_message: sendOk ? null : errMsg,
      }).catch(() => {});
    } else {
      emailWarning = "no_recipient_email";
    }
  } catch (e) {
    // Never let email problems break the decision.
    emailWarning = String((e as Error)?.message || e);
    console.warn("[decide-onboarding-quiz] email_warn", emailWarning);
  }

  return json({ ok: true, status: newStatus, email_warning: emailWarning }, 200);
});
