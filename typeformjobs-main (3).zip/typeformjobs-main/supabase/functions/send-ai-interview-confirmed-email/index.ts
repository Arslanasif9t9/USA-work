// send-ai-interview-confirmed-email: sends the AI-scheduled confirmation email
// with the /ai-interview/{token} link and an .ics for the booked time.
// Sibling of send-interview-confirmed-email (the Zoom email) — do NOT modify that one.
import { createClient } from "npm:@supabase/supabase-js@2";
import { formatManilaDate, formatManilaTime } from "../_shared/manila.ts";
import { buildIcs } from "../_shared/ics.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
const SERVICE_KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
const RESEND_API_KEY = Deno.env.get("RESEND_API_KEY")!;

const NAVY = "#1a2547";

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });
  const admin = createClient(SUPABASE_URL, SERVICE_KEY);

  const body = await req.json().catch(() => ({}));
  const responseId: string | undefined = body?.response_id;
  const token: string | undefined = body?.token;
  const slotStart: string | undefined = body?.slot_start;
  if (!responseId || !token || !slotStart) {
    return new Response(JSON.stringify({ error: "missing_fields" }), {
      status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }

  // Resolve candidate details (same lookup pattern as send-interview-confirmed-email)
  const { data: resp } = await admin
    .from("responses")
    .select("id, form_id, applicant_id, override_email, override_name")
    .eq("id", responseId)
    .maybeSingle();
  if (!resp) {
    return new Response(JSON.stringify({ error: "response_not_found" }), {
      status: 404, headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }

  const { data: meta } = await admin.from("form_metadata")
    .select("position_title").eq("form_id", resp.form_id).maybeSingle();
  const positionTitle = (meta?.position_title || "").trim() || "the role you applied for";

  const { data: qs } = await admin.from("questions").select("id, type, label").eq("form_id", resp.form_id);
  const { data: ans } = await admin.from("answers").select("question_id, answer_text").eq("response_id", responseId);
  const emailQ = qs?.find((q: any) => q.type === "email");
  const nameQ = qs?.find((q: any) => q.type === "short_text" && /name/i.test(q.label))
    || qs?.find((q: any) => q.type === "short_text");
  const find = (qid?: string) =>
    qid ? (ans?.find((a: any) => a.question_id === qid)?.answer_text || "").trim() : "";
  const answerEmail = find(emailQ?.id);
  const candidateEmail = (resp.override_email || "").trim() || answerEmail;
  const fullName = ((resp as any).override_name || "").trim() || find(nameQ?.id);
  const firstName = (fullName.split(/\s+/)[0] || "there").trim() || "there";

  if (!candidateEmail) {
    return new Response(JSON.stringify({ error: "no_email" }), {
      status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }

  // Build the AI interview link on the fixed public domain so emails sent from
  // the editor preview never produce login-gated dead links. (Do not use Origin.)
  const PUBLIC_BASE_URL = "https://jobs.expertintuitiveadvisor.com";
  const aiInterviewUrl = `${PUBLIC_BASE_URL}/ai-interview/${token}`;

  const slotDate = new Date(slotStart);
  const dateStr = formatManilaDate(slotDate);
  const timeStr = formatManilaTime(slotDate);

  // Build .ics (non-blocking on failure)
  const ics = buildIcs({
    summary: `EIA AI Interview - ${firstName}`,
    description:
      `Your AI interview with Christine.\n\nAt your scheduled time, click the link below to begin:\n${aiInterviewUrl}\n\nPlease be in a quiet place with a working camera and microphone.`,
    start_time: slotStart,
    duration_minutes: 30,
    timezone: "Asia/Manila",
    url: aiInterviewUrl,
    location: aiInterviewUrl,
    candidate_name: fullName || firstName,
    candidate_email: candidateEmail,
    organizer_name: "Angela Stein",
    organizer_email: "talent@careers.expertintuitiveadvisor.com",
    uid: `ai-${responseId}@expertintuitiveadvisor.com`,
  });
  const attachments: any[] = [];
  if ("ok" in ics && ics.ok) {
    attachments.push({
      filename: ics.filename || "eia-ai-interview.ics",
      content: btoa(unescape(encodeURIComponent(ics.ics_content))),
    });
  }

  // Compose email
  const subject = "Your interview is scheduled — Expert Intuitive Advisor";
  const text = `Hi ${firstName},

Your interview for the ${positionTitle} position is scheduled for:

${dateStr} at ${timeStr} (Philippine Standard Time)

Your interview is conducted online and takes about 5 minutes. At your scheduled time, click the link below to begin. Please make sure you're in a quiet place with a working camera and microphone.

${aiInterviewUrl}

We look forward to meeting you!

Angela Stein / HR — Talent Manager
Expert Intuitive Advisor Inc.`;

  const html = `<!doctype html>
<html><body style="margin:0;padding:0;background:#f5f5f5;font-family:-apple-system,Segoe UI,Roboto,Helvetica,Arial,sans-serif;color:${NAVY};">
  <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background:#f5f5f5;padding:24px 0;">
    <tr><td align="center">
      <table role="presentation" width="600" cellpadding="0" cellspacing="0" style="max-width:600px;background:#ffffff;border-radius:8px;overflow:hidden;">
        <tr><td style="background:${NAVY};padding:20px 28px;color:#ffffff;font-size:18px;font-weight:600;letter-spacing:0.3px;">
          Expert Intuitive Advisor Inc.
        </td></tr>
        <tr><td style="padding:28px;font-size:15px;line-height:1.6;color:${NAVY};">
          <p style="margin:0 0 14px 0;">Hi ${firstName},</p>
          <p style="margin:0 0 14px 0;">Your interview for the <strong>${positionTitle}</strong> position is scheduled for:</p>
          <p style="margin:0 0 18px 0;padding:12px 16px;background:#f7f5ef;border-left:3px solid ${NAVY};font-weight:600;">
            ${dateStr} at ${timeStr} <span style="font-weight:400;color:#666;">(Philippine Standard Time)</span>
          </p>
          <p style="margin:0 0 18px 0;">Your interview is conducted online and takes about 5 minutes. At your scheduled time, click the link below to begin. Please make sure you're in a quiet place with a working camera and microphone.</p>
          <p style="margin:0 0 22px 0;text-align:center;">
            <a href="${aiInterviewUrl}" style="display:inline-block;background:${NAVY};color:#ffffff;text-decoration:none;padding:12px 24px;border-radius:6px;font-weight:600;">Begin Interview</a>
          </p>
          <p style="margin:0 0 18px 0;font-size:13px;color:#666;word-break:break-all;">${aiInterviewUrl}</p>
          <p style="margin:0 0 6px 0;">We look forward to meeting you!</p>
          <p style="margin:18px 0 0 0;font-size:14px;color:#555;">
            Angela Stein / HR — Talent Manager<br/>
            Expert Intuitive Advisor Inc.
          </p>
        </td></tr>
      </table>
    </td></tr>
  </table>
</body></html>`;

  // Send via Resend
  let sendRes: Response;
  let sendJson: any = {};
  try {
    sendRes = await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${RESEND_API_KEY}`,
      },
      body: JSON.stringify({
        from: "Angela Stein / HR – Talent Manager <talent@expertintuitiveadvisor.com>",
        to: [candidateEmail], subject, html, text,
        attachments,
      }),
    });
    sendJson = await sendRes.json().catch(() => ({}));
  } catch (e: any) {
    await admin.from("email_log").insert({
      candidate_id: resp.applicant_id ?? null,
      stage: "stage_1_ai_interview_confirmed",
      sender: "resend",
      from_address: "talent@expertintuitiveadvisor.com",
      from_name: "Angela Stein / HR – Talent Manager",
      to_address: candidateEmail,
      subject,
      status: "failed",
      sent_at: null,
      resend_message_id: null,
      error_message: String(e?.message || e),
    });
    return new Response(JSON.stringify({ error: "send_failed", details: String(e?.message || e) }), {
      status: 502, headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }

  await admin.from("email_log").insert({
    candidate_id: resp.applicant_id ?? null,
    stage: "stage_1_ai_interview_confirmed",
    sender: "resend",
    from_address: "talent@expertintuitiveadvisor.com",
    from_name: "Angela Stein / HR – Talent Manager",
    to_address: candidateEmail,
    subject,
    status: sendRes.ok ? "sent" : "failed",
    sent_at: sendRes.ok ? new Date().toISOString() : null,
    resend_message_id: sendJson?.id ?? null,
    error_message: sendRes.ok ? null : JSON.stringify(sendJson),
  });

  if (!sendRes.ok) {
    return new Response(JSON.stringify({ error: "send_failed", details: sendJson }), {
      status: 502, headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }

  return new Response(JSON.stringify({ success: true, resend: sendJson }), {
    status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" },
  });
});
