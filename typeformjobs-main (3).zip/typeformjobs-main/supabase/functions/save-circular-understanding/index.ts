// save-circular-understanding: PUBLIC (verify_jwt=false). Writes the recipient's
// "what I understood in my own words" text to their circular_signatures row,
// matched by the unguessable access_token. Single-row write. Read-after-write.
// Refuses to overwrite once the row is already signed.
import { createClient } from "npm:@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};
const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
const SERVICE = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
const json = (b: unknown, s = 200) =>
  new Response(JSON.stringify(b), { status: s, headers: { ...corsHeaders, "Content-Type": "application/json" } });

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });
  if (req.method !== "POST") return json({ ok: false, reason: "method_not_allowed" }, 405);
  try {
    const { token, understanding_text } = await req.json().catch(() => ({}));
    if (!token || typeof token !== "string") return json({ ok: false, reason: "missing_token" }, 400);
    const text = String(understanding_text || "").trim();
    if (text.length < 80) return json({ ok: false, reason: "too_short" }, 400);

    const admin = createClient(SUPABASE_URL, SERVICE);
    const { data: row } = await admin
      .from("circular_signatures")
      .select("id, status, signed_at, signing_url")
      .eq("access_token", token)
      .maybeSingle();

    if (!row) return json({ ok: false, reason: "not_found" }, 404);
    if (row.status === "signed" || row.signed_at) return json({ ok: false, reason: "already_signed" }, 409);

    const { error: updErr } = await admin
      .from("circular_signatures")
      .update({ understanding_text: text })
      .eq("id", row.id);
    if (updErr) return json({ ok: false, reason: "update_failed", details: updErr.message }, 500);

    // Read-after-write verify.
    const { data: verify } = await admin
      .from("circular_signatures")
      .select("understanding_text, signing_url")
      .eq("id", row.id)
      .maybeSingle();
    if (!verify || (verify.understanding_text || "").trim().length < 80) {
      return json({ ok: false, reason: "verify_failed" }, 500);
    }

    return json({ ok: true, signing_url: verify.signing_url || row.signing_url });
  } catch (e: any) {
    return json({ ok: false, reason: "internal", details: String(e?.message || e) }, 500);
  }
});
