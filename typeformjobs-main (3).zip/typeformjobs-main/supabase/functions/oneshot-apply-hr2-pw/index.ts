// One-shot: applies HR2_PASSWORD_INPUT to hr2@expert.com auth user.
import { createClient } from "npm:@supabase/supabase-js@2";

const cors = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: cors });
  const admin = createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!);
  const pw = Deno.env.get("HR2_PASSWORD_INPUT") || "";
  if (pw.length < 8) {
    return new Response(JSON.stringify({ ok: false, error: "password_missing_or_short" }), { status: 400, headers: { ...cors, "Content-Type": "application/json" } });
  }
  const { data: list, error: listErr } = await admin.auth.admin.listUsers({ perPage: 1000 });
  if (listErr) return new Response(JSON.stringify({ error: listErr.message }), { status: 500, headers: { ...cors, "Content-Type": "application/json" } });
  const u = list?.users?.find((x: any) => (x.email || "").toLowerCase() === "hr2@expert.com");
  if (!u) return new Response(JSON.stringify({ ok: false, error: "user_not_found" }), { status: 404, headers: { ...cors, "Content-Type": "application/json" } });
  const { error: updErr } = await admin.auth.admin.updateUserById(u.id, { password: pw });
  // Force sign-out of all existing sessions
  const { error: signOutErr } = await admin.auth.admin.signOut(u.id, "global" as any);
  return new Response(JSON.stringify({ ok: !updErr, email: "hr2@expert.com", error: updErr?.message, signOutError: signOutErr?.message }), { headers: { ...cors, "Content-Type": "application/json" } });
});
