// invalidate-candidate-tokens: HR-gated. Expires every active rebook_tokens row
// for a candidate (response_id) so any previously-sent AI interview link bounces
// with "link no longer valid". Fully reversible — re-sending Round 1 mints a new
// token. Reuses rebook_tokens (expire only, never delete) + email_log (audit).
import { adminClient, corsHeaders, json, requireHr } from "../_shared/hr-auth.ts";

const UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });

  const ident = await requireHr(req);
  if (ident instanceof Response) return ident;
  if (!ident.hrId) return json({ error: "no_hr_profile" }, 403);

  const body = await req.json().catch(() => ({}));
  const responseId: string | undefined = typeof body?.response_id === "string" ? body.response_id.trim() : undefined;
  // When invoked from the Disqualify flow we tag the audit row differently.
  const onDisqualify = !!body?.on_disqualify;

  if (!responseId || !UUID_RE.test(responseId)) {
    return json({ error: "response_id required" }, 400);
  }

  const admin = adminClient();
  const nowIso = new Date().toISOString();
  const expiredIso = new Date(Date.now() - 1000).toISOString();

  try {
    // Expire every active (unused + not-yet-expired) token for this candidate.
    // Single-table update scoped to one candidate; never touches answers.
    const { data: rows, error: updErr } = await admin
      .from("rebook_tokens")
      .update({ expires_at: expiredIso, used_at: nowIso })
      .eq("response_id", responseId)
      .is("used_at", null)
      .gt("expires_at", nowIso)
      .select("id, stage");

    if (updErr) {
      return json({ ok: false, error: updErr.message }, 500);
    }

    const invalidated = rows || [];
    const count = invalidated.length;
    const stages = Array.from(new Set(invalidated.map((r: any) => r.stage || "reschedule")));

    // Audit row in email_log (service_role bypasses RLS). Map to existing columns.
    const auditStage = onDisqualify ? "tokens_invalidated_on_disqualify" : "tokens_invalidated";
    const subject = onDisqualify
      ? `Auto-invalidated ${count} token(s) on disqualify`
      : `HR invalidated ${count} active token(s)`;
    await admin.from("email_log").insert({
      candidate_id: responseId,
      stage: auditStage,
      status: "sent",
      subject,
      to_address: "internal-audit",
      from_address: "internal-audit",
      from_name: ident.email || "system",
      sender: "resend",
      sent_at: nowIso,
    });

    return json({ ok: true, count_invalidated: count, stages });
  } catch (e: any) {
    return json({ ok: false, error: String(e?.message || e) }, 500);
  }
});
