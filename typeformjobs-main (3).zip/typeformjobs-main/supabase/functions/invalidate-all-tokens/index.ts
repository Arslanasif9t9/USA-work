// invalidate-all-tokens: HR-gated + password-gated EMERGENCY flush.
// Expires EVERY currently-active rebook_tokens row for one agent's stages at
// once (Christine = Round-1 path, Marissa = Round-2 path). Fully reversible —
// sending a fresh invite mints a brand-new token that works normally.
//
// SAFETY: only touches rebook_tokens. Never touches the Retell agents,
// create-ai-web-call, scheduling_config, or the permanent-test token (which is
// a hardcoded constant, not a rebook_tokens row — explicitly excluded anyway).
import { adminClient, corsHeaders, json, requireHr } from "../_shared/hr-auth.ts";

// Christine handles Round 1 + reschedule + ai_scheduled links.
const CHRISTINE_STAGES = ["round1", "reschedule", "ai_scheduled"];
// Marissa handles Round 2 (current "round2_ai" + legacy "round2").
const MARISSA_STAGES = ["round2_ai", "round2"];
// Hardcoded emergency password (owner-only) — keep this off the client.
const FLUSH_PASSWORD = "flush";

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });

  // 1) Must be an authenticated HR user.
  const ident = await requireHr(req);
  if (ident instanceof Response) return ident;
  if (!ident.hrId) return json({ error: "no_hr_profile" }, 403);

  const body = await req.json().catch(() => ({}));
  const agent = typeof body?.agent === "string" ? body.agent.toLowerCase().trim() : "";
  const password = typeof body?.password === "string" ? body.password : "";

  // 2) Emergency password gate (403 → "wrong password", parsed cleanly client-side).
  if (password !== FLUSH_PASSWORD) return json({ error: "wrong password" }, 403);

  // 3) Resolve which stage set to flush.
  if (agent !== "christine" && agent !== "marissa") {
    return json({ error: "invalid_agent" }, 400);
  }
  const stages = agent === "christine" ? CHRISTINE_STAGES : MARISSA_STAGES;

  const admin = adminClient();
  const nowIso = new Date().toISOString();
  const expiredIso = new Date(Date.now() - 1000).toISOString();

  try {
    // Expire every ACTIVE (unused + not-yet-expired) token for these stages.
    // Excludes the permanent-test token defensively. Read-after-write via select.
    const { data: rows, error: updErr } = await admin
      .from("rebook_tokens")
      .update({ expires_at: expiredIso, used_at: nowIso })
      .in("stage", stages)
      .is("used_at", null)
      .gt("expires_at", nowIso)
      .neq("token", "permanent-test")
      .select("id, stage");

    if (updErr) return json({ ok: false, error: updErr.message }, 500);

    const invalidated = rows || [];
    return json({ ok: true, agent, count_invalidated: invalidated.length });
  } catch (e: any) {
    return json({ ok: false, error: String(e?.message || e) }, 500);
  }
});
