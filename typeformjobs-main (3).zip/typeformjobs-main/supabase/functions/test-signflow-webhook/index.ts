// Internal: forwards a test payload to signflow-webhook-receiver using SIGNFLOW_API_KEY.
const cors = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};
Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: cors });
  const key = Deno.env.get("SIGNFLOW_API_KEY")!;
  const url = `${Deno.env.get("SUPABASE_URL")}/functions/v1/signflow-webhook-receiver`;
  const body = await req.text();
  const r = await fetch(url, {
    method: "POST",
    headers: { Authorization: `Bearer ${key}`, "Content-Type": "application/json" },
    body,
  });
  const text = await r.text();
  return new Response(JSON.stringify({ status: r.status, body: text }), {
    headers: { ...cors, "Content-Type": "application/json" },
  });
});
