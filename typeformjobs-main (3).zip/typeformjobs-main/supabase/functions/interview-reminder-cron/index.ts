// Interview reminder cron — sends three classes of reminders, each at-most-once
// per interview:
//   * 30 minutes before → CANDIDATE (override_email → answer email; skip if none)
//   * 15 minutes before → CANDIDATE
//   * 10 minutes before → backup heads-up to two fixed HR inboxes
// Triggered by pg_cron every minute. Idempotent via per-phase sent-at columns.

import { createClient } from "npm:@supabase/supabase-js@2";

const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
const SERVICE_KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

const REMINDER_INBOXES = [
  "talent.expertadvisor@gmail.com",
  "talent.expertadvisor@outlook.com",
];

const MANILA_TZ = "Asia/Manila";
const fmtFullManila = (d: Date) =>
  new Intl.DateTimeFormat("en-US", {
    timeZone: MANILA_TZ, weekday: "short", year: "numeric", month: "short", day: "numeric",
    hour: "numeric", minute: "2-digit", hour12: true,
  }).format(d);
const fmtTimeManila = (d: Date) =>
  new Intl.DateTimeFormat("en-US", {
    timeZone: MANILA_TZ, hour: "numeric", minute: "2-digit", hour12: true,
  }).format(d);

const EMAIL_LABEL_RE = /e[\s-]?mail/i;
const EMAIL_EXCLUDE_RE = /(onlinejob|online\s*jobs?|profile|link|url)/i;
function detectQids(qs: { id: string; type: string; label: string | null }[]) {
  const emailQ =
    qs.find((q) => EMAIL_LABEL_RE.test(q.label || "") && !EMAIL_EXCLUDE_RE.test(q.label || "")) ||
    qs.find((q) => q.type === "email" && !EMAIL_EXCLUDE_RE.test(q.label || ""));
  const nameQ =
    qs.find((q) => q.type === "short_text" && /name/i.test(q.label || "")) ||
    qs.find((q) => q.type === "short_text");
  return { nameQid: nameQ?.id, emailQid: emailQ?.id };
}

type Phase = "30" | "15" | "10";
type Round = 1 | 2;
type Due = {
  actionId: string;
  candidateId: string;
  formId: string;
  responseId: string | null;
  round: Round;
  phase: Phase;
  apptDate: Date;
  zoomUrl: string | null;
};

const phaseConfig = {
  "30": { minutes: 30, window: 31 * 60_000 + 30_000 },
  "15": { minutes: 15, window: 16 * 60_000 + 30_000 },
  "10": { minutes: 10, window: 11 * 60_000 + 30_000 },
};

const sentAtCol = (round: Round, phase: Phase) =>
  round === 1
    ? phase === "30" ? "round1_reminder_30_sent_at"
    : phase === "15" ? "round1_reminder_15_sent_at"
    : "round1_reminder_sent_at"
    : phase === "30" ? "round2_reminder_30_sent_at"
    : phase === "15" ? "round2_reminder_15_sent_at"
    : "round2_reminder_sent_at";

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });
  const admin = createClient(SUPABASE_URL, SERVICE_KEY);
  const nowMs = Date.now();
  const graceStartMs = nowMs - 2 * 60_000;
  const windowEndIso = new Date(nowMs + 31 * 60_000 + 30_000).toISOString(); // outer window = 30min phase
  const graceStartIso = new Date(graceStartMs).toISOString();

  // Pull rows for both rounds with any unsent reminder column where appt falls in window.
  const cols = "id, candidate_id, form_id, response_id, job_offer_id, "
    + "round1_appointment_date, round1_zoom_join_url, round1_reminder_30_sent_at, round1_reminder_15_sent_at, round1_reminder_sent_at, "
    + "round2_appointment_date, round2_zoom_join_url, round2_reminder_30_sent_at, round2_reminder_15_sent_at, round2_reminder_sent_at";

  const [r1, r2] = await Promise.all([
    admin.from("candidate_actions").select(cols)
      .gte("round1_appointment_date", graceStartIso)
      .lte("round1_appointment_date", windowEndIso)
      .not("round1_appointment_date", "is", null),
    admin.from("candidate_actions").select(cols)
      .gte("round2_appointment_date", graceStartIso)
      .lte("round2_appointment_date", windowEndIso)
      .not("round2_appointment_date", "is", null),
  ]);

  const rows = [...(r1.data || []), ...(r2.data || [])];
  // Dedupe by id (a row may appear in both queries if both rounds happen to fit)
  const byId: Record<string, any> = {};
  for (const r of rows) byId[r.id] = r;

  const due: Due[] = [];
  for (const r of Object.values(byId)) {
    for (const round of [1, 2] as Round[]) {
      const appt = round === 1 ? r.round1_appointment_date : r.round2_appointment_date;
      const zoom = round === 1 ? r.round1_zoom_join_url : r.round2_zoom_join_url;
      if (!appt) continue;
      // AI-interview candidates have no Zoom join URL — skip silently so they
      // never receive a human-Zoom reminder for an interview that has no Zoom link.
      if (!zoom) continue;
      const apptDate = new Date(appt);
      const diff = apptDate.getTime() - nowMs;
      for (const phase of ["30", "15", "10"] as Phase[]) {
        const cfg = phaseConfig[phase];
        const alreadySent = r[sentAtCol(round, phase)];
        if (alreadySent) continue;
        // Window: phase target minutes (e.g. 30) >= remaining >= 0, plus small grace either side
        const upperMs = cfg.minutes * 60_000 + 60_000;
        const lowerMs = phase === "30" ? 15 * 60_000 + 30_000 // 30-min phase only valid until 15.5min remaining
          : phase === "15" ? 10 * 60_000 + 30_000             // 15-min phase only until 10.5min
          : -2 * 60_000;                                       // 10-min phase down to -2min
        if (diff <= upperMs && diff >= lowerMs) {
          due.push({
            actionId: r.id, candidateId: r.candidate_id, formId: r.form_id, responseId: r.response_id,
            round, phase, apptDate, zoomUrl: zoom,
          });
        }
      }
    }
  }

  if (due.length === 0) {
    return new Response(JSON.stringify({ ok: true, processed: 0 }), {
      status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }

  const formIds = [...new Set(due.map((d) => d.formId))];
  const responseIds = [...new Set(due.map((d) => d.responseId).filter(Boolean) as string[])];
  const actionIds = [...new Set(due.map((d) => d.actionId))];

  const [{ data: questions }, { data: answers }, { data: responses }, { data: forms }, { data: actions }] = await Promise.all([
    admin.from("questions").select("id, form_id, type, label").in("form_id", formIds),
    responseIds.length
      ? admin.from("answers").select("response_id, question_id, answer_text").in("response_id", responseIds)
      : Promise.resolve({ data: [] as any[] }),
    responseIds.length
      ? admin.from("responses").select("id, override_email, override_name, handled_by_hr_id").in("id", responseIds)
      : Promise.resolve({ data: [] as any[] }),
    admin.from("forms").select("id, title").in("id", formIds),
    admin.from("candidate_actions").select("id, job_offer_id").in("id", actionIds),
  ]);

  const formTitle: Record<string, string> = {};
  for (const f of (forms || [])) formTitle[f.id] = (f as any).title || "";

  const jobOfferIds = [...new Set((actions || []).map((a: any) => a.job_offer_id).filter(Boolean))];
  let offersById: Record<string, string> = {};
  if (jobOfferIds.length) {
    const { data: offers } = await admin.from("job_offers").select("id, position_title").in("id", jobOfferIds);
    for (const o of (offers || [])) offersById[(o as any).id] = (o as any).position_title || "";
  }
  const offerByAction: Record<string, string> = {};
  for (const a of (actions || [])) {
    if ((a as any).job_offer_id && offersById[(a as any).job_offer_id]) offerByAction[a.id] = offersById[(a as any).job_offer_id];
  }

  const qidsByForm: Record<string, { nameQid?: string; emailQid?: string }> = {};
  const qByForm: Record<string, any[]> = {};
  for (const q of (questions || [])) (qByForm[q.form_id] = qByForm[q.form_id] || []).push(q);
  for (const fid of Object.keys(qByForm)) qidsByForm[fid] = detectQids(qByForm[fid]);

  const ansByResp: Record<string, Record<string, string>> = {};
  for (const a of (answers || [])) {
    ansByResp[a.response_id] = ansByResp[a.response_id] || {};
    ansByResp[a.response_id][a.question_id] = a.answer_text || "";
  }
  const respMap: Record<string, any> = {};
  for (const r of (responses || [])) respMap[r.id] = r;

  const hrIds = [...new Set((responses || []).map((r: any) => r.handled_by_hr_id).filter(Boolean))];
  let hrById: Record<string, string> = {};
  if (hrIds.length) {
    const { data: hrs } = await admin.from("hr_users").select("id, display_name, nickname").in("id", hrIds);
    for (const h of (hrs || [])) {
      hrById[(h as any).id] = (h as any).nickname ? `${(h as any).display_name} / ${(h as any).nickname}` : (h as any).display_name;
    }
  }

  const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  let sent = 0; let failed = 0; let skipped = 0;
  const errors: string[] = [];

  for (const d of due) {
    const qids = qidsByForm[d.formId] || {};
    const ans = (d.responseId && ansByResp[d.responseId]) || {};
    const resp = d.responseId ? respMap[d.responseId] : null;
    const candidateName = ((resp?.override_name as string) || "").trim() || (qids.nameQid && ans[qids.nameQid]) || "there";
    const candidateEmail =
      ((resp?.override_email as string) || (qids.emailQid && ans[qids.emailQid]) || "").trim();
    const positionTitle = offerByAction[d.actionId] || formTitle[d.formId] || "the role";
    const assignedHr = resp?.handled_by_hr_id ? (hrById[resp.handled_by_hr_id] || "—") : "—";

    let allOk = true;

    if (d.phase === "10") {
      // DISABLED: the HR "Interview in 10 minutes" heads-up to the backup inboxes
      // is intentionally turned off. We mark it sent (allOk stays true) so the cron
      // does not keep reprocessing this phase. The candidate-facing 30/15-minute
      // reminders below are unchanged. (The BCC copy of the candidate reminder is
      // also gone because app_settings.hr_copy_email is cleared, so send-dual-email
      // adds no internal BCC.)
    } else {
      // Candidate reminder (30 or 15)
      if (!candidateEmail || !EMAIL_RE.test(candidateEmail)) {
        skipped++;
        continue; // do NOT mark sent — leave it so HR can backfill email and the next cron picks it up
      }
      const mins = d.phase;
      const subject = `Reminder: Your interview is in ${mins} minutes`;
      const text =
        `Hi ${candidateName},\n\n` +
        `This is a friendly reminder that your interview for the ${positionTitle} position is coming up in ${mins} minutes, at ${fmtTimeManila(d.apptDate)} (Philippine Standard Time).\n\n` +
        `Please join using your Zoom link below:\n${d.zoomUrl || "(link unavailable — please reply to this email)"}\n\n` +
        `Make sure you're in a quiet place with a stable internet connection. We look forward to speaking with you!\n\n` +
        `Angela Stein\nHR – Talent Manager\nExpert Intuitive Advisor Inc.`;
      const html =
        `<div style="font-family:Arial,sans-serif;font-size:14px;line-height:1.6;color:#1a2236">
          <p>Hi ${candidateName},</p>
          <p>This is a friendly reminder that your interview for the <b>${positionTitle}</b> position is coming up in <b>${mins} minutes</b>, at <b>${fmtTimeManila(d.apptDate)}</b> (Philippine Standard Time).</p>
          <p>Please join using your Zoom link below:<br/>
            ${d.zoomUrl ? `<a href="${d.zoomUrl}">${d.zoomUrl}</a>` : "(link unavailable — please reply to this email)"}
          </p>
          <p>Make sure you're in a quiet place with a stable internet connection. We look forward to speaking with you!</p>
          <p style="margin-top:20px">Angela Stein<br/>HR – Talent Manager<br/>Expert Intuitive Advisor Inc.</p>
        </div>`;
      const { error: invErr } = await admin.functions.invoke("send-dual-email", {
        body: {
          to: candidateEmail, candidate_id: d.candidateId ?? null, stage: "other",
          sender_a: { from_name: "Angela Stein / HR – Talent Manager", from_address: "talent@expertintuitiveadvisor.com", subject, text_body: text, html_body: html },
          sender_b: { from_name: "Angela Stein", from_address: "talent@expertintuitiveadvisor.com", subject, text_body: text, html_body: html },
        },
      });
      if (invErr) { allOk = false; errors.push(`cand-${d.phase} a=${d.actionId} r=${d.round}: ${invErr.message}`); }
    }

    if (allOk) {
      const col = sentAtCol(d.round, d.phase);
      const { error: upErr } = await admin
        .from("candidate_actions")
        .update({ [col]: new Date().toISOString() })
        .eq("id", d.actionId);
      if (upErr) { failed++; errors.push(`mark-sent a=${d.actionId} ${col}: ${upErr.message}`); } else { sent++; }
    } else {
      failed++;
    }
  }

  return new Response(
    JSON.stringify({ ok: true, processed: due.length, sent, failed, skipped, errors }),
    { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } },
  );
});
