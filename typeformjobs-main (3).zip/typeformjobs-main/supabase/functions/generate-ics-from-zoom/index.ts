// generate-ics-from-zoom: admin-only. Looks up a zoom_meetings row, builds .ics.
import {
  adminClient,
  corsHeaders,
  jsonResponse,
  requireAdmin,
} from "../_shared/zoom.ts";
import { buildIcs } from "../_shared/ics.ts";

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });
  const guard = await requireAdmin(req);
  if (guard instanceof Response) return guard;

  let body: {
    zoom_meeting_db_id?: string;
    candidate_name?: string;
    candidate_email?: string;
  };
  try {
    body = await req.json();
  } catch {
    return jsonResponse({ error: "invalid_json" }, 400);
  }

  if (!body.zoom_meeting_db_id) {
    return jsonResponse({ error: "missing_zoom_meeting_db_id" }, 400);
  }

  const admin = adminClient();
  const { data: zm, error } = await admin
    .from("zoom_meetings")
    .select(
      "id, round, topic, start_time, duration_minutes, timezone, join_url, password",
    )
    .eq("id", body.zoom_meeting_db_id)
    .maybeSingle();
  if (error || !zm) return jsonResponse({ error: "zoom_meeting_not_found" }, 404);

  const roundLabel = zm.round ? `Round ${zm.round} ` : "";
  const summary = `${roundLabel}Interview - EIA`;
  const pwLine = zm.password ? `\nPassword: ${zm.password}` : "";
  const description = `Zoom interview with Angela Stein.\n\nJoin: ${zm.join_url}${pwLine}`;

  const result = buildIcs({
    summary,
    description,
    start_time: zm.start_time,
    duration_minutes: zm.duration_minutes,
    timezone: zm.timezone || "Asia/Manila",
    url: zm.join_url,
    location: zm.join_url,
    candidate_name: body.candidate_name,
    candidate_email: body.candidate_email,
    organizer_name: "Angela Stein",
    organizer_email: "talent@careers.expertintuitiveadvisor.com",
    uid: `zoom-${zm.id}@expertintuitiveadvisor.com`,
  });

  if (!("ok" in result) || !result.ok) {
    return jsonResponse(result, 400);
  }
  return jsonResponse({
    ...result,
    filename: zm.round ? `eia-round-${zm.round}-interview.ics` : "eia-interview.ics",
  });
});
