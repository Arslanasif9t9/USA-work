// validate-onboarding-token: PUBLIC. Returns token info + pre-fill data + any
// existing submission. Mirrors validate-rebook-token.
import { createClient } from "npm:@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};
const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
const SERVICE = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
const json = (b: unknown, s = 200) =>
  new Response(JSON.stringify(b), { status: s, headers: { ...corsHeaders, "Content-Type": "application/json" } });

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });
  try {
    const { token } = await req.json();
    if (!token) return json({ error: "missing_token" }, 400);
    const admin = createClient(SUPABASE_URL, SERVICE);

    const { data: tok } = await admin.from("onboarding_tokens").select("*").eq("token", token).maybeSingle();
    if (!tok) return json({ valid: false, reason: "not_found" });
    if (tok.closed_at) return json({ valid: false, reason: "closed" });
    if (new Date(tok.expires_at) < new Date()) return json({ valid: false, reason: "expired" });

    const responseId = tok.response_id;

    // ── Universal (response-less) onboarding token ──────────────────────────
    // No job_offers/responses/answers prefill chain — load HR's stored text
    // values from prefill_data. Submissions are keyed by the token's own id.
    if (!responseId) {
      const pf: any = tok.prefill_data || {};
      const { data: uniSub } = await admin
        .from("onboarding_submissions").select("*").eq("response_id", tok.id).maybeSingle();
      return json({
        valid: true,
        response_id: null,
        expires_at: tok.expires_at,
        prefill: {
          full_name: (pf.full_name || tok.candidate_name || "").toString().trim(),
          email: (pf.email || tok.candidate_email || "").toString().trim(),
          position_title: (pf.position_title || tok.position_title || "").toString().trim(),
          phone: (pf.phone || "").toString().trim(),
        },
        hr_extras: {
          bank_account_details: (pf.bank_account_details || "").toString().trim(),
          digital_pay_gcash: (pf.digital_pay_gcash || "").toString().trim(),
          other_notes: (pf.other_notes || "").toString().trim(),
        },
        submission: uniSub || null,
      });
    }

    // Pre-fill: job_offers > responses.override_email > answers / hr_candidate_extras / form_metadata
    let full_name = tok.candidate_name || "";
    let email = tok.candidate_email || "";
    let position_title = tok.position_title || "";
    let phone = "";

    const { data: resp } = await admin
      .from("responses").select("form_id, applicant_id, override_email, override_name").eq("id", responseId).maybeSingle();


    if (resp?.applicant_id) {
      const { data: offer } = await admin
        .from("job_offers")
        .select("candidate_name, candidate_email, position_title")
        .eq("candidate_id", resp.applicant_id)
        .eq("status", "signed")
        .order("signed_at", { ascending: false }).limit(1).maybeSingle();
      if (offer) {
        if (!full_name) full_name = (offer.candidate_name || "").trim();
        if (!email) email = (offer.candidate_email || "").trim();
        if (!position_title) position_title = (offer.position_title || "").trim();
      }
    }

    if (!full_name && (resp as any)?.override_name) full_name = ((resp as any).override_name || "").trim();
    if (!email && resp?.override_email) email = (resp.override_email || "").trim();

    // hr_candidate_extras for phone + HR-only fields
    const { data: extras } = await admin
      .from("hr_candidate_extras").select("phone, bank_account_details, digital_pay_gcash, other_notes").eq("response_id", responseId).maybeSingle();
    if (extras?.phone) phone = (extras.phone || "").trim();

    // answers fallback
    if (!full_name || !email || !phone) {
      const { data: qs } = await admin.from("questions").select("id, type, label").eq("form_id", resp?.form_id);
      const { data: ans } = await admin.from("answers").select("question_id, answer_text").eq("response_id", responseId);
      const find = (pred: (q: any) => boolean) => {
        const q = qs?.find(pred);
        if (!q) return "";
        return (ans?.find((a: any) => a.question_id === q.id)?.answer_text || "").trim();
      };
      if (!full_name) full_name = find((q) => /name/i.test(q.label));
      if (!email) email = find((q) => q.type === "email" || /email/i.test(q.label));
      if (!phone) phone = find((q) => /phone|mobile|contact/i.test(q.label));
    }

    if (!position_title && resp?.form_id) {
      const { data: meta } = await admin.from("form_metadata").select("position_title").eq("form_id", resp.form_id).maybeSingle();
      position_title = (meta?.position_title || "").trim();
    }

    const { data: sub } = await admin
      .from("onboarding_submissions").select("*").eq("response_id", responseId).maybeSingle();

    // Existing profile photo from the application answers — the SAME stored
    // value the form Results page renders. Returned as a storage path plus a
    // freshly signed display URL so the onboarding form can pre-fill + lock it.
    let existing_photo_path: string | null = null;
    let existing_photo_url: string | null = null;
    try {
      if (resp?.form_id) {
        const { data: photoQs } = await admin
          .from("questions").select("id, type, label").eq("form_id", resp.form_id);
        const photoRe = /photo|selfie|picture|headshot|portrait|image/i;
        const photoQ = (photoQs || []).find((q: any) =>
          q.type === "selfie" || (q.type === "file_upload" && photoRe.test(q.label || ""))
        );
        if (photoQ) {
          const { data: pa } = await admin
            .from("answers").select("file_url")
            .eq("response_id", responseId).eq("question_id", photoQ.id)
            .not("file_url", "is", null)
            .limit(1);
          const fileUrl = (pa && pa[0]?.file_url) || null;
          if (fileUrl) {
            existing_photo_path = fileUrl;
            const slash = fileUrl.indexOf("/");
            const bucket = fileUrl.slice(0, slash);
            const path = fileUrl.slice(slash + 1);
            const { data: signed } = await admin.storage.from(bucket)
              .createSignedUrl(path, 60 * 60 * 24 * 7);
            if (signed?.signedUrl) existing_photo_url = signed.signedUrl;
          }
        }
      }
    } catch (_e) {
      // best-effort only; never block validation on photo lookup
    }

    return json({
      valid: true,
      response_id: responseId,
      expires_at: tok.expires_at,
      prefill: { full_name, email, position_title, phone },
      hr_extras: {
        bank_account_details: extras?.bank_account_details || "",
        digital_pay_gcash: extras?.digital_pay_gcash || "",
        other_notes: extras?.other_notes || "",
      },
      existing_photo_path,
      existing_photo_url,
      submission: sub || null,
    });
  } catch (e: any) {
    return json({ error: "internal", details: String(e?.message || e) }, 500);
  }
});
