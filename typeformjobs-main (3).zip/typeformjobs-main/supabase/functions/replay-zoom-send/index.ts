// replay-zoom-send: server-side replay of the CandidateRoundModal composite,
// used ONLY by the scheduler (fire-scheduled-sends) to fire a scheduled
// universal/round Zoom send. Mirrors the live flow:
// create-zoom-meeting -> generate-ics-from-zoom -> send-dual-email -> DB update.
// Runs as service role (guarded). Does NOT alter the live Send-Now path.

import { createClient } from "npm:@supabase/supabase-js@2";

const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
const SERVICE_KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
const MANILA_TZ = "Asia/Manila";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, x-acting-hr-email",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};
const json = (b: unknown, s = 200) =>
  new Response(JSON.stringify(b), { status: s, headers: { ...corsHeaders, "Content-Type": "application/json" } });

const pad = (n: number) => String(n).padStart(2, "0");
const formatFullDate = (date: string) => {
  const [y, m, d] = date.split("-").map(Number);
  const dt = new Date(Date.UTC(y, m - 1, d, 12, 0, 0));
  return new Intl.DateTimeFormat("en-US", { timeZone: MANILA_TZ, weekday: "long", month: "long", day: "numeric", year: "numeric" }).format(dt);
};
const formatTime12 = (time: string) => {
  const [h, m] = time.split(":").map(Number);
  const period = h >= 12 ? "PM" : "AM";
  const h12 = h === 0 ? 12 : h > 12 ? h - 12 : h;
  return `${h12}:${pad(m)} ${period}`;
};
const manilaToUtcIso = (date: string, time: string) => new Date(`${date}T${time}:00+08:00`).toISOString();

const htmlEscape = (s: string) => s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
const toHtml = (text: string, joinUrl: string) => {
  const escaped = htmlEscape(text)
    .replace(new RegExp(htmlEscape(joinUrl).replace(/[.*+?^${}()|[\]\\]/g, "\\$&"), "g"), `<a href="${joinUrl}">${joinUrl}</a>`)
    .replace(/\n/g, "<br/>");
  return `<div style="font-family:Arial,sans-serif;font-size:14px;line-height:1.55;color:#1a2236">${escaped}</div>`;
};

function buildRoundEmails(v: { round: 1 | 2; candidate_name: string; position_title: string; formatted_date: string; formatted_time: string; duration_minutes: number; zoom_join_url: string; }) {
  if (v.round === 1) {
    const aText = `Hi ${v.candidate_name},

For the better experience, we recommend joining on a desktop or laptop computer with camera and mic.

Congratulations — you've been shortlisted for our Round 1 Interview for the ${v.position_title} position at Expert Intuitive Advisor Inc.

INTERVIEW DETAILS:
Date: ${v.formatted_date}
Time: ${v.formatted_time} (Asia/Manila time)
Duration: ${v.duration_minutes} minutes
Format: Zoom video call

JOIN MEETING:
${v.zoom_join_url}

The calendar invite is attached — please add it to your calendar so you don't miss it.

Please make sure:
- You have a stable internet connection
- You're in a quiet, well-lit space
- Your camera and microphone are working
- You're available 5 minutes before the scheduled time

This is a brief evaluation interview. We'll discuss your background and assess fit for the role.

If you need to reschedule, reply to this email and we'll work with you.

Looking forward to speaking with you.

Angela Stein
HR – Talent Manager
Expert Intuitive Advisor Inc.`;
    const bText = `Hi ${v.candidate_name},

For the better experience, we recommend joining on a desktop or laptop computer with camera and mic.

Just sending a personal reminder about your Round 1 interview.

When: ${v.formatted_date} at ${v.formatted_time} (Manila time)
Where: Zoom — ${v.zoom_join_url}

The calendar invite should be attached. If you can't open it, just save the date and time above.

A few quick tips:
- Test your Zoom audio/video beforehand
- Have your resume nearby in case we want to discuss it
- Be ready a couple minutes early

If anything changes on your end, just reply and we'll figure it out.

— Angela Stein`;
    return {
      sender_a: { from_name: "Angela Stein / HR – Talent Manager", from_address: "talent@expertintuitiveadvisor.com", subject: `Round 1 Interview Scheduled — ${v.position_title}`, text_body: aText, html_body: toHtml(aText, v.zoom_join_url) },
      sender_b: { from_name: "Angela Stein", from_address: "expertintuitiveadvisor@gmail.com", subject: "Quick reminder — your Round 1 interview is set", text_body: bText, html_body: toHtml(bText, v.zoom_join_url) },
    };
  }
  const aText = `Hi ${v.candidate_name},

For the better experience, we recommend joining on a desktop or laptop computer with camera and mic.

Thank you for completing Round 1. We're moving forward with you to Round 2 of our interview process for the ${v.position_title} position.

INTERVIEW DETAILS:
Date: ${v.formatted_date}
Time: ${v.formatted_time} (Asia/Manila time)
Duration: ${v.duration_minutes} minutes
Format: Zoom video call

JOIN MEETING:
${v.zoom_join_url}

The calendar invite is attached.

In this interview, we'll discuss your application in more detail and go over the role responsibilities, work schedule, compensation, and other important details.

Please be prepared to:
- Discuss your relevant experience and approach
- Ask any questions you have about the role
- Demonstrate basic technical setup (internet speed, audio, video)

Please make sure you have a stable internet connection and a quiet environment.

If you need to reschedule, reply to this email.

Angela Stein
HR – Talent Manager
Expert Intuitive Advisor Inc.`;
  const bText = `Hi ${v.candidate_name},

For the better experience, we recommend joining on a desktop or laptop computer with camera and mic.

Excited to chat again — here are the details for Round 2:

When: ${v.formatted_date} at ${v.formatted_time} (Manila time)
Where: Zoom — ${v.zoom_join_url}

This is the discussion where we go over the role in more depth. Come prepared with questions.

We'll also do a quick technical check (internet, audio, video) during the call, so make sure your setup is ready.

If you need to reschedule, just reply.

— Angela Stein`;
  return {
    sender_a: { from_name: "Angela Stein / HR – Talent Manager", from_address: "talent@expertintuitiveadvisor.com", subject: `Round 2 Interview Scheduled — ${v.position_title}`, text_body: aText, html_body: toHtml(aText, v.zoom_join_url) },
    sender_b: { from_name: "Angela Stein", from_address: "expertintuitiveadvisor@gmail.com", subject: "Quick reminder — Round 2 interview details", text_body: bText, html_body: toHtml(bText, v.zoom_join_url) },
  };
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });

  // Guard: service role only.
  const auth = req.headers.get("Authorization") || "";
  if (auth.slice(7).trim() !== SERVICE_KEY) return json({ error: "forbidden" }, 403);

  const body = await req.json().catch(() => ({}));
  const round: 1 | 2 = body?.round === 2 ? 2 : 1;
  const responseId: string | undefined = body?.response_id;
  const candidateActionsId: string | undefined = body?.candidate_actions_id;
  const candidateId: string | undefined = body?.candidate_id;
  const name: string = (body?.name || "").trim();
  const email: string = (body?.email || "").trim();
  const positionTitle: string = (body?.position_title || "the role").trim();
  const date: string = body?.date;
  const time: string = body?.time;
  const duration: number = Number(body?.duration) || (round === 1 ? 15 : 30);
  if (!candidateActionsId || !name || !email || !date || !time) {
    return json({ error: "missing_fields" }, 400);
  }

  const admin = createClient(SUPABASE_URL, SERVICE_KEY);
  const stage = round === 1 ? "round1" : "round2";
  const emailStage = round === 1 ? "stage_2_round_1" : "stage_2_round_2";

  // Step 1: Zoom
  const zoomRes = await admin.functions.invoke("create-zoom-meeting", {
    body: {
      topic: `Round ${round} Interview - ${name}`,
      start_time: `${date}T${time}:00`,
      duration_minutes: duration,
      candidate_actions_id: candidateActionsId,
      candidate_id: candidateId,
      round,
    },
  });
  if (zoomRes.error || !(zoomRes.data as any)?.success) {
    return json({ error: `zoom: ${zoomRes.error?.message || (zoomRes.data as any)?.error || "zoom failed"}` }, 500);
  }
  const zoomMeetingDbId = (zoomRes.data as any).db_record_id;
  const zoomJoinUrl = (zoomRes.data as any).join_url;
  const zoomPassword = (zoomRes.data as any).password ?? null;

  // Step 2: ICS (non-fatal)
  let icsContent: string | null = null;
  let icsFilename = `EIA-Interview-${date}.ics`;
  try {
    const icsRes = await admin.functions.invoke("generate-ics-from-zoom", {
      body: { zoom_meeting_db_id: zoomMeetingDbId, candidate_name: name, candidate_email: email },
    });
    if (!icsRes.error && (icsRes.data as any)?.ok && (icsRes.data as any)?.ics_content) {
      icsContent = (icsRes.data as any).ics_content;
      if ((icsRes.data as any).filename) icsFilename = (icsRes.data as any).filename;
    }
  } catch (_) { /* non-fatal */ }

  // Step 3: dual email
  const templates = buildRoundEmails({
    round, candidate_name: name, position_title: positionTitle,
    formatted_date: formatFullDate(date), formatted_time: formatTime12(time),
    duration_minutes: duration, zoom_join_url: zoomJoinUrl,
  });
  void zoomPassword;
  const attachments = icsContent
    ? [{ filename: icsFilename, content: btoa(unescape(encodeURIComponent(icsContent))), content_type: "text/calendar; method=REQUEST; charset=utf-8" }]
    : undefined;

  const emailRes = await admin.functions.invoke("send-dual-email", {
    body: { to: email, candidate_id: candidateId ?? null, stage: emailStage, sender_a: templates.sender_a, sender_b: templates.sender_b, attachments },
  });
  const resendOk = !!(emailRes.data as any)?.resend?.success;
  const gmailOk = !!(emailRes.data as any)?.gmail?.success;
  if (emailRes.error || !(resendOk || gmailOk)) {
    return json({ error: `email: ${emailRes.error?.message || "email failed"}`, zoom_join_url: zoomJoinUrl }, 500);
  }

  // Step 4: DB update (single-row by id)
  const now = new Date().toISOString();
  const apptIsoUtc = manilaToUtcIso(date, time);
  await admin.from("candidate_actions").update({
    [`${stage}_appointment_date`]: apptIsoUtc,
    [`${stage}_zoom_meeting_id`]: zoomMeetingDbId,
    [`${stage}_zoom_join_url`]: zoomJoinUrl,
    [`${stage}_status`]: "sent",
    [`${stage}_sent_at`]: now,
    [`${stage}_last_sent_at`]: now,
  } as any).eq("id", candidateActionsId);

  if (responseId) {
    try {
      await admin.from("responses").update({
        round_stage: round === 1 ? "round_1_sent" : "round_2_sent",
        [`round_${round}_sent_at`]: now,
      } as any).eq("id", responseId);
    } catch (_) { /* non-fatal */ }
  }

  return json({ ok: true, zoom_join_url: zoomJoinUrl });
});
