// quarantine-access: verifies Quarantine password and returns ALL terminated employee data.
// Logs every access attempt; on success, fires audit email to boss inbox.
import { createClient } from "npm:@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
const ANON = Deno.env.get("SUPABASE_ANON_KEY")!;
const SERVICE = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
const RESEND_API_KEY = Deno.env.get("RESEND_API_KEY")!;
const QUARANTINE_PASSWORD = Deno.env.get("QUARANTINE_PASSWORD") || "Terminator123!";
const BOSS_INBOX = "spark11179@gmail.com";

async function sendAuditEmail(actor: string, action: string) {
  if (!RESEND_API_KEY) return;
  try {
    await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: { Authorization: `Bearer ${RESEND_API_KEY}`, "Content-Type": "application/json" },
      body: JSON.stringify({
        from: "EIA Security <talent@expertintuitiveadvisor.com>",
        to: [BOSS_INBOX],
        subject: `[Quarantine] ${action}`,
        text: `${action} by ${actor} at ${new Date().toISOString()}`,
      }),
    });
  } catch (_) { /* swallow */ }
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });
  try {
    const authHeader = req.headers.get("Authorization");
    if (!authHeader?.startsWith("Bearer ")) {
      return new Response(JSON.stringify({ error: "unauthorized" }), { status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }
    const userClient = createClient(SUPABASE_URL, ANON, { global: { headers: { Authorization: authHeader } } });
    const { data: userData, error: uErr } = await userClient.auth.getUser();
    if (uErr || !userData?.user) {
      return new Response(JSON.stringify({ error: "unauthorized" }), { status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }
    const admin = createClient(SUPABASE_URL, SERVICE);
    const email = (userData.user.email || "").toLowerCase();
    const { data: hr } = await admin.from("hr_users").select("id, display_name, role").ilike("email", email).maybeSingle();
    const hrId = hr?.id ?? null;
    const actor = hr?.display_name || email;

    const body = await req.json().catch(() => ({}));
    const password = typeof body?.password === "string" ? body.password : "";

    if (password !== QUARANTINE_PASSWORD) {
      await admin.from("password_audit_log").insert({
        hr_user_id: hrId, password_used: "***wrong***", action_taken: "quarantine_access_failed",
      });
      return new Response(JSON.stringify({ error: "wrong_password" }), { status: 403, headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }

    // Pull terminated employees with everything we'll need.
    const { data: offers } = await admin
      .from("job_offers")
      .select("id, candidate_id, candidate_name, candidate_email, position_title, start_date, signed_at, signed_pdf_url, employment_status, terminated_at, termination_reason, terminated_by_hr_id, internal_notes")
      .in("employment_status", ["terminated_evaluation", "terminated_regular"])
      .eq("quarantine_removed", false)
      .order("terminated_at", { ascending: false });

    const hrIds = Array.from(new Set((offers || []).map(o => o.terminated_by_hr_id).filter(Boolean))) as string[];
    const { data: hrs } = hrIds.length
      ? await admin.from("hr_users").select("id, display_name, role, email").in("id", hrIds)
      : { data: [] as any[] };

    const offerIds = (offers || []).map(o => o.id);
    const { data: termLogs } = offerIds.length
      ? await admin.from("termination_log").select("*").in("job_offer_id", offerIds)
      : { data: [] as any[] };

    const candIds = Array.from(new Set((offers || []).map(o => o.candidate_id).filter(Boolean))) as string[];
    const { data: responses } = candIds.length
      ? await admin.from("responses").select("id, applicant_id, form_id, submitted_at").in("applicant_id", candIds)
      : { data: [] as any[] };

    const respIds = (responses || []).map(r => r.id);
    const { data: answers } = respIds.length
      ? await admin.from("answers").select("id, response_id, question_id, answer_text, file_url").in("response_id", respIds)
      : { data: [] as any[] };

    const formIds = Array.from(new Set((responses || []).map(r => r.form_id)));
    const { data: questions } = formIds.length
      ? await admin.from("questions").select("id, form_id, label, type, order_index").in("form_id", formIds)
      : { data: [] as any[] };

    const { data: emailLogs } = offerIds.length
      ? await admin.from("email_log").select("id, job_offer_id, candidate_id, stage, subject, status, sent_at, to_address, created_at").in("job_offer_id", offerIds).order("created_at", { ascending: false })
      : { data: [] as any[] };

    // Settlement signatures for these terminated employees (resolve by response_id when present, else by signer_email).
    const emails = Array.from(new Set((offers || []).map(o => (o.candidate_email || "").toLowerCase()).filter(Boolean)));
    const respIdsForSig = respIds;
    let settlementSigs: any[] = [];
    if (respIdsForSig.length || emails.length) {
      const { data: sigs } = await admin
        .from("nda_signatures")
        .select("id, response_id, signer_email, external_reference, status, signed_at, signing_url, signed_pdf_url, doc_type, created_at")
        .eq("doc_type", "settlement")
        .or([
          respIdsForSig.length ? `response_id.in.(${respIdsForSig.join(",")})` : null,
          emails.length ? `signer_email.in.(${emails.map(e => `"${e}"`).join(",")})` : null,
        ].filter(Boolean).join(","));
      settlementSigs = sigs || [];
    }

    // Deleted Appointments (booking graveyard) — responses moved here via the
    // "Permanently Delete" action in My Bookings → Deleted Appointments. This is a
    // VIEW-MOVE only (a flag); the responses/answers record is never destroyed.
    // SEPARATE from terminated employees (responses vs job_offers) — never mixed.
    const { data: delResps } = await admin
      .from("responses")
      .select("id, applicant_id, form_id, submitted_at, override_email, override_name, custom_position, quarantine_moved_at")
      .eq("appointment_permanently_deleted", true)
      .order("quarantine_moved_at", { ascending: false });

    const delRespIds = (delResps || []).map((r: any) => r.id);
    const delFormIds = Array.from(new Set((delResps || []).map((r: any) => r.form_id)));
    const { data: delAnswers } = delRespIds.length
      ? await admin.from("answers").select("response_id, question_id, answer_text").in("response_id", delRespIds)
      : { data: [] as any[] };
    const { data: delQuestions } = delFormIds.length
      ? await admin.from("questions").select("id, form_id, label, type").in("form_id", delFormIds)
      : { data: [] as any[] };
    const { data: delMetas } = delFormIds.length
      ? await admin.from("form_metadata").select("form_id, position_title").in("form_id", delFormIds)
      : { data: [] as any[] };
    const { data: delForms } = delFormIds.length
      ? await admin.from("forms").select("id, title").in("id", delFormIds)
      : { data: [] as any[] };

    const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    const deleted_appointments = (delResps || []).map((r: any) => {
      const qs = (delQuestions || []).filter((q: any) => q.form_id === r.form_id);
      const ans = (delAnswers || []).filter((a: any) => a.response_id === r.id);
      const getText = (qid: string) => ans.find((a: any) => a.question_id === qid)?.answer_text || "";
      const nameQ = qs.find((q: any) => /name/i.test(q.label || "") && !/user|company|file|business/i.test(q.label || ""));
      const emailQ = qs.find((q: any) => /e-?mail/i.test(q.label || ""));
      let email = (r.override_email || (emailQ ? getText(emailQ.id) : "") || "").trim();
      if (!email) {
        const found = ans.find((a: any) => a.answer_text && EMAIL_RE.test((a.answer_text || "").trim()));
        email = found ? found.answer_text.trim() : "";
      }
      const name = ((r.override_name || "").trim()) || (nameQ ? getText(nameQ.id) : "").trim();
      const meta = (delMetas || []).find((m: any) => m.form_id === r.form_id);
      const form = (delForms || []).find((f: any) => f.id === r.form_id);
      const position = (r.custom_position || meta?.position_title || form?.title || "").trim();
      return {
        id: r.id,
        name,
        email,
        position,
        moved_at: r.quarantine_moved_at || null,
        submitted_at: r.submitted_at || null,
      };
    });

    await admin.from("password_audit_log").insert({
      hr_user_id: hrId, password_used: "***quarantine***", action_taken: "quarantine_access_granted",
    });
    await sendAuditEmail(actor, "Quarantine accessed");

    return new Response(JSON.stringify({
      ok: true,
      offers: offers || [],
      hr_users: hrs || [],
      termination_logs: termLogs || [],
      responses: responses || [],
      answers: answers || [],
      questions: questions || [],
      email_logs: emailLogs || [],
      settlement_signatures: settlementSigs,
      deleted_appointments,
    }), { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } });
  } catch (e) {
    return new Response(JSON.stringify({ error: (e as Error).message }), { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } });
  }
});
