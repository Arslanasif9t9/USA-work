// list-active-employees
// READ-ONLY bridge for a sister app to fetch the active employee roster.
// - GET only, verify_jwt = false (validated in code via x-academy-key)
// - Requires header "x-academy-key" === secret ACADEMY_BRIDGE_KEY, else 401
// - Resolves name + email EXACTLY like the Employees dashboard:
//     active = job_offers.status='signed' AND employment_status='active'
//              AND the candidate has a responses row with final_outcome='matched'
//     name   = job_offers.candidate_name
//     email  = job_offers.override_email || job_offers.candidate_email
//   (de-duplicated by email)
// - SELECT only. Never writes. Never exposes any key in the response.
// - All errors return HTTP 200 with { ok:false, error } so the caller never
//   hits an unhandled non-2xx (the 401 auth gate is the only intentional non-2xx).

import { createClient } from "npm:@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type, x-academy-key",
  "Access-Control-Allow-Methods": "GET, OPTIONS",
};

const json = (body: unknown, status = 200) =>
  new Response(JSON.stringify(body), {
    status,
    headers: { ...corsHeaders, "Content-Type": "application/json" },
  });

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });

  try {
    // Only GET is allowed for this read-only endpoint.
    if (req.method !== "GET") {
      return json({ ok: false, error: "method_not_allowed" });
    }

    // ── Auth gate: shared bridge key. Wrong/missing => 401 (the only non-2xx). ──
    const ACADEMY_BRIDGE_KEY = Deno.env.get("ACADEMY_BRIDGE_KEY");
    const provided = req.headers.get("x-academy-key");
    if (!ACADEMY_BRIDGE_KEY || !provided || provided !== ACADEMY_BRIDGE_KEY) {
      return json({ ok: false, error: "unauthorized" }, 401);
    }

    const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
    const SERVICE_KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const admin = createClient(SUPABASE_URL, SERVICE_KEY);

    // 1) Active signed offers (SELECT only — mirrors the dashboard filters).
    const { data: offers, error: offersErr } = await admin
      .from("job_offers")
      .select("candidate_id, candidate_name, candidate_email, override_email, signed_at")
      .eq("status", "signed")
      .eq("employment_status", "active")
      .order("signed_at", { ascending: false });
    if (offersErr) return json({ ok: false, error: offersErr.message });

    const rows = (offers as any[]) || [];
    const candIds = Array.from(
      new Set(rows.map((o) => o.candidate_id).filter(Boolean) as string[]),
    );

    // 2) Keep only candidates HR explicitly Matched (responses.final_outcome='matched').
    const matched = new Set<string>();
    if (candIds.length) {
      const { data: resps, error: respsErr } = await admin
        .from("responses")
        .select("applicant_id, final_outcome")
        .in("applicant_id", candIds)
        .eq("final_outcome", "matched");
      if (respsErr) return json({ ok: false, error: respsErr.message });
      for (const r of ((resps as any[]) || [])) matched.add(r.applicant_id);
    }

    // 3) Resolve name + email, de-duplicate by email (case-insensitive).
    const byEmail = new Map<string, { name: string; email: string }>();
    for (const o of rows) {
      if (!o.candidate_id || !matched.has(o.candidate_id)) continue;
      const name = (o.candidate_name ?? "").trim();
      const email = ((o.override_email ?? o.candidate_email) ?? "").trim();
      if (!email) continue;
      const key = email.toLowerCase();
      // Offers are ordered by most-recently-signed first; keep the first seen.
      if (!byEmail.has(key)) byEmail.set(key, { name, email });
    }

    const employees = Array.from(byEmail.values());
    return json({ ok: true, employees });
  } catch (e: any) {
    // Safe shape — never throw a raw non-2xx at the caller.
    return json({ ok: false, error: String(e?.message || e) });
  }
});
