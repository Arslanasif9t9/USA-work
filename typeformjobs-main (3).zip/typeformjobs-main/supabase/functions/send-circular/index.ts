// send-circular: HR-gated multi-send orchestrator for Circular Notices.
// - Inserts ONE circulars row.
// - Generates the plain-body PDF ONCE (same notice for everyone).
// - Loops per recipient IN ISOLATION: own CIRC- reference, own SignFlow doc + link,
//   own circular_signatures row, auto-saves into circular_recipients (last_sent_at),
//   sends ONE email (single sender, single recipient — no CC/BCC), logs email_log.
// - A failed recipient is recorded as failed and the loop continues (batch never aborts).
// Does NOT use send-dual-email (one email per person, not two).
import { createClient } from "npm:@supabase/supabase-js@2";
import { requireHr, corsHeaders, json } from "../_shared/hr-auth.ts";

const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
const SVC = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
const RESEND_API_KEY = Deno.env.get("RESEND_API_KEY")!;

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const FROM_NAME = "Angela Stein / HR – Talent Manager";
const FROM_ADDRESS = "talent@expertintuitiveadvisor.com";
const PUBLIC_BASE = Deno.env.get("PUBLIC_BASE_URL") || "https://jobs.expertintuitiveadvisor.com";
const PAGE_H = 792;

function shortId() {
  return crypto.randomUUID().replace(/-/g, "").slice(0, 8).toUpperCase();
}

// Unguessable token for the public /circular/:token understanding page.
function accessToken() {
  const bytes = new Uint8Array(32);
  crypto.getRandomValues(bytes);
  return Array.from(bytes, (b) => b.toString(16).padStart(2, "0")).join("");
}

function escapeHtml(s: string) {
  return s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
}

function buildEmail(firstName: string, title: string, signingUrl: string) {
  const safeTitle = escapeHtml(title || "Circular Notice");
  const subject = `Action required: ${title || "Circular Notice"} — Expert Intuitive Advisor Inc.`;
  const text = `Hi ${firstName},

You have received a circular notice from Expert Intuitive Advisor Inc.:

"${title || "Circular Notice"}"

Please open the secure link below to read it, confirm your understanding in your own words, and sign:

${signingUrl}

If you have any questions, simply reply to this email.

Angela Stein
HR – Talent Manager
Expert Intuitive Advisor Inc.`;
  const html = `<div style="font-family:Arial,sans-serif;font-size:14px;color:#1a2236;line-height:1.6;max-width:600px">
<p>Hi ${escapeHtml(firstName)},</p>
<p>You have received a circular notice from <strong>Expert Intuitive Advisor Inc.</strong>:</p>
<p style="font-weight:600;color:#1a2547">${safeTitle}</p>
<p>Please open the secure link below to read it, confirm your understanding in your own words, and sign.</p>
<p><a href="${signingUrl}" style="display:inline-block;background:#1a2547;color:#ffffff;padding:12px 22px;border-radius:6px;text-decoration:none;font-weight:600">Read &amp; sign the circular</a></p>
<p style="font-size:12px;color:#666">Or paste this link into your browser:<br/><a href="${signingUrl}" style="color:#1a2547">${signingUrl}</a></p>
<p>If you have any questions, simply reply to this email.</p>
<p>Angela Stein<br/>HR – Talent Manager<br/>Expert Intuitive Advisor Inc.</p>
</div>`;
  return { subject, text, html };
}

async function sendOneEmail(to: string, subject: string, html: string, text: string): Promise<{ ok: boolean; id?: string; error?: string }> {
  try {
    const ctrl = new AbortController();
    const t = setTimeout(() => ctrl.abort(), 15000);
    const res = await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: { Authorization: `Bearer ${RESEND_API_KEY}`, "Content-Type": "application/json" },
      signal: ctrl.signal,
      // Single recipient only. NEVER add cc/bcc — recipients must not see each other.
      body: JSON.stringify({ from: `${FROM_NAME} <${FROM_ADDRESS}>`, to: [to], subject, html, text }),
    });
    clearTimeout(t);
    const data = await res.json().catch(() => ({}));
    if (!res.ok) return { ok: false, error: `Resend ${res.status}: ${JSON.stringify(data)}` };
    return { ok: true, id: (data as any)?.id };
  } catch (e) {
    return { ok: false, error: `Resend exception: ${(e as Error).message}` };
  }
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });
  if (req.method !== "POST") return json({ ok: false, reason: "method_not_allowed" }, 405);

  const auth = req.headers.get("Authorization") || "";
  const hr = await requireHr(req);
  if (hr instanceof Response) return hr;

  let body: { title?: string; body?: string; explanation?: string | null; recipients?: Array<{ name?: string; email?: string }>; branded_letterhead?: boolean };
  try { body = await req.json(); } catch { return json({ ok: false, reason: "invalid_json" }, 400); }

  const title = String(body?.title || "").trim();
  const notice = String(body?.body || "");
  const explanation = body?.explanation == null ? null : String(body.explanation).trim() || null;
  const branded = body?.branded_letterhead === true;
  const rawRecipients = Array.isArray(body?.recipients) ? body!.recipients! : [];
  if (!notice.trim()) return json({ ok: false, reason: "missing_body" }, 400);

  // De-dupe recipients by lower(email), validate.
  const seen = new Set<string>();
  const recipients: Array<{ name: string; email: string }> = [];
  for (const r of rawRecipients) {
    const email = String(r?.email || "").trim();
    const name = String(r?.name || "").trim();
    if (!EMAIL_RE.test(email)) continue;
    const key = email.toLowerCase();
    if (seen.has(key)) continue;
    seen.add(key);
    recipients.push({ name, email });
  }
  if (recipients.length === 0) return json({ ok: false, reason: "no_valid_recipients" }, 400);

  const admin = createClient(SUPABASE_URL, SVC);

  // 1) ONE circulars row.
  const { data: circ, error: circErr } = await admin
    .from("circulars")
    .insert({ title: title || null, body: notice, explanation, created_by: hr.hrId, recipient_count: recipients.length, branded_letterhead: branded })
    .select("id")
    .maybeSingle();
  if (circErr || !circ) return json({ ok: false, reason: "circular_insert_failed", detail: circErr?.message }, 500);
  const circularId = (circ as any).id as string;

  // 2) Generate the plain-body PDF ONCE (same notice content for everyone).
  const pdfResp = await fetch(`${SUPABASE_URL}/functions/v1/generate-circular-pdf`, {
    method: "POST",
    headers: { Authorization: auth, "Content-Type": "application/json" },
    body: JSON.stringify({ title, body: notice, reference: `CIRC-${circularId.slice(0, 8).toUpperCase()}`, branded_letterhead: branded }),
  });
  const pdfJson = await pdfResp.json().catch(() => ({}));
  const pdfUrl: string | undefined = (pdfJson as any)?.pdf_url;
  const pageCount: number | undefined = (pdfJson as any)?.page_count;
  if (!pdfResp.ok || !pdfUrl) {
    return json({ ok: false, reason: "pdf_failed", detail: pdfJson, circular_id: circularId }, 500);
  }

  // Convert signature rect from bottom-origin (fieldTop) to top-origin (y = PAGE_H - fieldTop).
  const sigRect = (pdfJson as any)?.signature_rect as
    | { page?: number; x?: number; fieldTop?: number; width?: number; height?: number }
    | null | undefined;
  const sigPage = Math.max(1, Number(sigRect?.page ?? pageCount ?? 1));
  const sigFieldPosition = sigRect && typeof sigRect.fieldTop === "number"
    ? { page: sigPage, x: Number(sigRect.x ?? 61), y: PAGE_H - Number(sigRect.fieldTop), width: Number(sigRect.width ?? 240), height: Number(sigRect.height ?? 60) }
    : { page: sigPage, x: 100, y: 350, width: 200, height: 60 };

  // 3) Loop per recipient — each in isolation.
  const results: Array<{ email: string; ok: boolean; reference?: string; signing_url?: string; reason?: string }> = [];

  for (const r of recipients) {
    const reference = `CIRC-${shortId()}`;
    const token = accessToken();
    const firstName = r.name.trim().split(/\s+/)[0] || r.name || r.email.split("@")[0];
    try {
      // a/b) Own SignFlow doc + signing link.
      const sfResp = await fetch(`${SUPABASE_URL}/functions/v1/signflow-create-document`, {
        method: "POST",
        headers: { Authorization: auth, "Content-Type": "application/json" },
        body: JSON.stringify({
          external_offer_reference: reference,
          signer_name: r.name || r.email,
          signer_email: r.email,
          document_title: title || "Circular Notice",
          pdf_url: pdfUrl,
          signature_field_position: sigFieldPosition,
        }),
      });
      const sfJson = await sfResp.json().catch(() => ({}));
      const signingUrl: string | undefined = (sfJson as any)?.signing_url;
      if (!sfResp.ok || !signingUrl || !/^https:\/\/\S+$/i.test(signingUrl)) {
        await admin.from("circular_signatures").insert({
          circular_id: circularId, reference, signer_name: r.name || null, signer_email: r.email,
          signing_url: null, status: "failed",
        });
        results.push({ email: r.email, ok: false, reference, reason: "signflow_failed" });
        continue;
      }

      // c) Insert circular_signatures row (status sent) + read-after-write verify.
      // Mint the unguessable access_token here so the recipient's /circular/:token works.
      const { error: insErr } = await admin.from("circular_signatures").insert({
        circular_id: circularId, reference, signer_name: r.name || null, signer_email: r.email,
        signing_url: signingUrl, access_token: token, status: "sent", sent_at: new Date().toISOString(),
      });
      if (insErr) {
        results.push({ email: r.email, ok: false, reference, reason: "persist_failed" });
        continue;
      }
      const { data: verifyRow } = await admin
        .from("circular_signatures").select("id").eq("reference", reference).maybeSingle();
      if (!verifyRow) {
        results.push({ email: r.email, ok: false, reference, reason: "persist_verify_failed" });
        continue;
      }

      // d) Auto-save into circular_recipients (upsert on lower(email)), set last_sent_at.
      const { data: existing } = await admin
        .from("circular_recipients").select("id").ilike("email", r.email).maybeSingle();
      if (existing) {
        await admin.from("circular_recipients")
          .update({ name: r.name || null, last_sent_at: new Date().toISOString() })
          .eq("id", (existing as any).id);
      } else {
        await admin.from("circular_recipients")
          .insert({ name: r.name || null, email: r.email, last_sent_at: new Date().toISOString() });
      }

      // e) ONE email to this recipient only (single sender, no CC/BCC).
      // Point the email at the EIA understanding page, NOT the raw SignFlow link.
      const circularUrl = `${PUBLIC_BASE}/circular/${token}`;
      const { subject, html, text } = buildEmail(firstName, title, circularUrl);
      const sent = await sendOneEmail(r.email, subject, html, text);

      // f) Log to email_log with stage 'circular_sent'.
      await admin.from("email_log").insert({
        stage: "circular_sent",
        sender: "resend",
        from_address: FROM_ADDRESS,
        from_name: FROM_NAME,
        to_address: r.email,
        subject,
        status: sent.ok ? "sent" : "failed",
        resend_message_id: sent.ok ? (sent.id ?? null) : null,
        error_message: sent.ok ? null : (sent.error ?? "unknown"),
        sent_at: sent.ok ? new Date().toISOString() : null,
      });

      if (!sent.ok) {
        results.push({ email: r.email, ok: false, reference, signing_url: signingUrl, reason: "email_failed" });
        continue;
      }
      results.push({ email: r.email, ok: true, reference, signing_url: signingUrl });
    } catch (e) {
      results.push({ email: r.email, ok: false, reference, reason: `exception: ${(e as Error).message}` });
    }
  }

  const sentCount = results.filter((x) => x.ok).length;
  return json({
    ok: true,
    circular_id: circularId,
    pdf_url: pdfUrl,
    total: recipients.length,
    sent: sentCount,
    failed: recipients.length - sentCount,
    results,
  });
});
