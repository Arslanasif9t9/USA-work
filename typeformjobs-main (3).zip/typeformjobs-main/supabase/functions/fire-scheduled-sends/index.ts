// fire-scheduled-sends: cron-driven scheduler engine (Piece 1).
// Every minute, finds pending scheduled_sends whose scheduled_for <= now(),
// atomically claims each (pending -> in_flight) to guard against double-fire,
// then replays the stored payload to the target edge function using the
// SERVICE_ROLE key (which satisfies the shared requireHr service-role bypass).
// On success -> sent; on error -> failed (no auto-retry in v1).
//
// Runs as service role. Invoked by pg_cron with the anon apikey header; it does
// not require a user JWT.

import { createClient } from "npm:@supabase/supabase-js@2";

const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
const SERVICE_KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

const BATCH = 25;

/**
 * TEST-SAFETY GUARDRAIL (additive — does NOT affect the live Send-Now path).
 * A scheduled row may only fire if its payload names an EXPLICIT recipient.
 * Recognized explicit-recipient fields across all target functions:
 *   - override_email (send-round-invite, etc.)
 *   - to            (replay-offer-send)
 *   - email         (create-universal-candidate, employee doc functions)
 *   - recipients[]  (send-circular — at least one entry with an email)
 * If none is present we REFUSE to send and mark the row failed, so the engine
 * can never silently fall back to a candidate's stored address.
 */
function hasExplicitRecipient(payload: any): boolean {
  if (!payload || typeof payload !== "object") return false;
  const nonEmpty = (v: unknown) => typeof v === "string" && v.trim().length > 0;
  if (nonEmpty(payload.override_email)) return true;
  if (nonEmpty(payload.to)) return true;
  if (nonEmpty(payload.email)) return true;
  if (nonEmpty(payload.recipient_email)) return true;
  if (Array.isArray(payload.recipients)) {
    return payload.recipients.some((r: any) =>
      nonEmpty(r) || (r && typeof r === "object" && (nonEmpty(r.email) || nonEmpty(r.to)))
    );
  }
  return false;
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });

  const admin = createClient(SUPABASE_URL, SERVICE_KEY);
  const nowIso = new Date().toISOString();

  // 1) Find due pending rows.
  const { data: dueRows, error: selErr } = await admin
    .from("scheduled_sends")
    .select("id, send_type, target_function, payload, response_id, scheduled_for, attempts, created_by")
    .eq("status", "pending")
    .lte("scheduled_for", nowIso)
    .order("scheduled_for", { ascending: true })
    .limit(BATCH);

  if (selErr) {
    return new Response(JSON.stringify({ ok: false, error: selErr.message }), {
      status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }

  if (!dueRows || dueRows.length === 0) {
    return new Response(JSON.stringify({ ok: true, processed: 0 }), {
      status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }

  // Resolve acting-HR emails for created_by (best-effort attribution).
  // created_by is an auth.users id; HR functions resolve HR by email, so we map
  // through users.email when available.
  const creatorIds = [...new Set(dueRows.map((r: any) => r.created_by).filter(Boolean))] as string[];
  const emailByUser: Record<string, string> = {};
  if (creatorIds.length) {
    const { data: users } = await admin.from("users").select("id, email").in("id", creatorIds);
    for (const u of (users || [])) emailByUser[(u as any).id] = (u as any).email || "";
  }

  let sent = 0; let failed = 0; let claimed = 0;
  const results: any[] = [];

  for (const row of dueRows) {
    // 1b) GUARDRAIL: refuse rows without an explicit recipient. Flip
    // pending -> failed atomically (never claimed, never invoked, never falls
    // back to a stored candidate address).
    if (!hasExplicitRecipient((row as any).payload)) {
      const { data: failedRows } = await admin
        .from("scheduled_sends")
        .update({ status: "failed", error: "no explicit recipient", attempts: (row.attempts ?? 0) + 1 })
        .eq("id", row.id)
        .eq("status", "pending")
        .select("id");
      if (failedRows && failedRows.length > 0) {
        failed++;
        results.push({ id: row.id, ok: false, error: "no explicit recipient" });
      } else {
        results.push({ id: row.id, ok: true, skipped: "already_claimed" });
      }
      continue;
    }

    // 2) Atomic claim: only proceed if THIS call flips pending -> in_flight.
    const { data: claimedRows, error: claimErr } = await admin
      .from("scheduled_sends")
      .update({ status: "in_flight" })
      .eq("id", row.id)
      .eq("status", "pending")
      .select("id");

    if (claimErr) {
      failed++;
      results.push({ id: row.id, ok: false, error: `claim: ${claimErr.message}` });
      continue;
    }
    if (!claimedRows || claimedRows.length === 0) {
      // Another overlapping run already claimed it — skip silently.
      results.push({ id: row.id, ok: true, skipped: "already_claimed" });
      continue;
    }
    claimed++;

    // 3) Replay payload to the target function as service role.
    const headers: Record<string, string> = {};
    const actingEmail = row.created_by ? emailByUser[row.created_by] : "";
    if (actingEmail) headers["x-acting-hr-email"] = actingEmail;

    let ok = false;
    let errMsg = "";
    try {
      const { data, error } = await admin.functions.invoke(row.target_function, {
        body: row.payload ?? {},
        headers,
      });
      if (error) {
        errMsg = error.message || "invoke_error";
      } else if (data && (data as any).error) {
        errMsg = typeof (data as any).error === "string" ? (data as any).error : JSON.stringify((data as any).error);
      } else {
        ok = true;
      }
    } catch (e: any) {
      errMsg = e?.message || String(e);
    }

    // 4) Finalize status.
    if (ok) {
      const { error: upErr } = await admin
        .from("scheduled_sends")
        .update({ status: "sent", sent_at: new Date().toISOString(), error: null })
        .eq("id", row.id);
      if (upErr) {
        failed++;
        results.push({ id: row.id, ok: false, error: `mark-sent: ${upErr.message}` });
      } else {
        sent++;
        results.push({ id: row.id, ok: true });
      }
    } else {
      await admin
        .from("scheduled_sends")
        .update({ status: "failed", error: errMsg.slice(0, 2000), attempts: (row.attempts ?? 0) + 1 })
        .eq("id", row.id);
      failed++;
      results.push({ id: row.id, ok: false, error: errMsg });
    }
  }

  return new Response(
    JSON.stringify({ ok: true, processed: dueRows.length, claimed, sent, failed, results }),
    { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } },
  );
});
