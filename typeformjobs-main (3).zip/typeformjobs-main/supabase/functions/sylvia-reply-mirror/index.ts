import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

Deno.serve(async (req) => {
  if (req.method !== "POST") {
    return new Response(JSON.stringify({ ok: true, note: "alive" }), {
      status: 200, headers: { "Content-Type": "application/json" },
    });
  }
  try {
    const SUPABASE_URL = Deno.env.get("SUPABASE_URL") ?? "";
    const SERVICE_ROLE = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? "";
    const admin = () => createClient(SUPABASE_URL, SERVICE_ROLE);

    const payload = await req.json().catch(() => ({}));
    console.log("ELEVENLABS_WEBHOOK_RAW", JSON.stringify(payload));

    const data = payload?.data ?? payload ?? {};
    const conversationId =
      data?.conversation_id ?? data?.conversationId ?? payload?.conversation_id ?? "unknown";

    const rawPhone =
      data?.conversation_initiation_client_data?.dynamic_variables?.system__caller_id ??
      data?.metadata?.phone_call?.external_number ??
      data?.metadata?.caller_id ??
      data?.customer?.phone ??
      "";
    const phone = String(rawPhone).replace(/\D/g, "");

    const transcript = Array.isArray(data?.transcript) ? data.transcript : [];

    if (!phone || transcript.length === 0) {
      return new Response(JSON.stringify({ ok: true, note: "no phone or transcript; raw logged", phone, turns: transcript.length }), {
        status: 200, headers: { "Content-Type": "application/json" },
      });
    }

    const rows = [];
    transcript.forEach((turn, i) => {
      const role = turn?.role ?? turn?.speaker ?? "";
      const text = turn?.message ?? turn?.text ?? turn?.content ?? "";
      if (role === "agent" && text && String(text).trim()) {
        rows.push({
          direction: "outbound",
          phone,
          type: "text",
          body: String(text),
          status: "sent",
          wa_message_id: `el-${conversationId}-${i}`,
        });
      }
    });

    if (rows.length === 0) {
      return new Response(JSON.stringify({ ok: true, note: "no agent turns", phone }), {
        status: 200, headers: { "Content-Type": "application/json" },
      });
    }

    const { error } = await admin()
      .from("whatsapp_messages")
      .upsert(rows, { onConflict: "wa_message_id", ignoreDuplicates: true });

    if (error) {
      console.log("INSERT_ERROR", error.message);
      return new Response(JSON.stringify({ ok: false, error: error.message }), {
        status: 200, headers: { "Content-Type": "application/json" },
      });
    }

    return new Response(JSON.stringify({ ok: true, inserted: rows.length, phone }), {
      status: 200, headers: { "Content-Type": "application/json" },
    });
  } catch (e) {
    console.log("HANDLER_ERROR", String(e));
    return new Response(JSON.stringify({ ok: false, error: String(e) }), {
      status: 200, headers: { "Content-Type": "application/json" },
    });
  }
});
