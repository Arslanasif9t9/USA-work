// Public lookup: given the candidate's AI-interview rebook token (their proof
// of identity for /ai-interview/:token), return the existing tracking_tokens
// row for their response. Read-only; never mints. Used by the Thank-You
// screen to show a /track/:token link without exposing HR auth.
import { adminClient, corsHeaders, json } from "../_shared/hr-auth.ts";

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });

  let body: { interview_token?: unknown };
  try { body = await req.json(); } catch { return json({ token: null }, 200); }
  const itok = typeof body?.interview_token === "string" ? body.interview_token.trim() : "";
  if (!itok) return json({ token: null }, 200);

  const admin = adminClient();

  // Validate the candidate's rebook token (their auth proof for this flow).
  const { data: rb } = await admin
    .from("rebook_tokens")
    .select("response_id, expires_at")
    .eq("token", itok)
    .maybeSingle();
  if (!rb?.response_id) return json({ token: null }, 200);

  // Look up existing tracking token (live, non-revoked). DO NOT mint here —
  // the webhook handler does that after the interview is recorded.
  const { data: tt } = await admin
    .from("tracking_tokens")
    .select("token")
    .eq("response_id", rb.response_id)
    .is("revoked_at", null)
    .order("created_at", { ascending: false })
    .limit(1)
    .maybeSingle();

  return json({ token: tt?.token ?? null }, 200);
});
