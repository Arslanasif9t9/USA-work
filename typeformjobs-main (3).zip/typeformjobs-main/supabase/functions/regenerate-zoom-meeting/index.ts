// regenerate-zoom-meeting: admin-only.
// Recreates Zoom meetings on the active Zoom account for upcoming booked slots
// whose existing Zoom links live on a now-dead account.
//
// Body:
//   { slot_id: uuid }                  → single slot
//   { batch_all_upcoming: true }       → every booked/reserved slot with slot_start > now()
//
// For each slot:
//   1) Resolve candidate name + email from response answers
//   2) Create a new Zoom meeting (Server-to-Server OAuth, current credentials)
//   3) Insert a new zoom_meetings row, repoint interview_slots.zoom_meeting_id
//   4) Mirror new zoom id/url onto candidate_actions (round1/round2) where the old id was referenced
//   5) Mark the old zoom_meetings row as 'cancelled'
//   6) Fire send-interview-confirmed-email (Zoom link + .ics) — best-effort
//
// Safety: single-row updates by exact id; never touches `answers`; never re-creates
// for past slots; if a slot is missing email/response it is skipped (not failed).
import { adminClient, corsHeaders, jsonResponse, requireAdmin, zoomFetch } from "../_shared/zoom.ts";

const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
const SERVICE_KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
const UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

type SlotRow = {
  id: string;
  slot_start: string;
  status: string;
  response_id: string | null;
  zoom_meeting_id: string | null;
};

async function resolveCandidate(
  admin: ReturnType<typeof adminClient>,
  responseId: string,
): Promise<{ name: string; email: string; formId: string | null }> {
  const { data: resp } = await admin
    .from("responses")
    .select("id, form_id, override_email, override_name")
    .eq("id", responseId)
    .maybeSingle();
  if (!resp) return { name: "Candidate", email: "", formId: null };

  const { data: qs } = await admin.from("questions").select("id, type, label").eq("form_id", resp.form_id);
  const { data: ans } = await admin.from("answers").select("question_id, answer_text").eq("response_id", responseId);
  const emailQ = qs?.find((q: any) => q.type === "email");
  const nameQ =
    qs?.find((q: any) => q.type === "short_text" && /name/i.test(q.label)) ||
    qs?.find((q: any) => q.type === "short_text");
  const find = (qid?: string) =>
    qid ? ((ans?.find((a: any) => a.question_id === qid)?.answer_text) || "").trim() : "";
  const override = (resp as any).override_email?.toString().trim() || "";
  return {
    name: ((resp as any).override_name || "").trim() || find(nameQ?.id) || "Candidate",
    email: override || find(emailQ?.id),
    formId: resp.form_id,
  };
}

async function regenerateOne(
  admin: ReturnType<typeof adminClient>,
  slot: SlotRow,
): Promise<{ slot_id: string; ok: boolean; reason?: string; new_join_url?: string }> {
  if (!slot.response_id) {
    return { slot_id: slot.id, ok: false, reason: "no_response" };
  }
  if (new Date(slot.slot_start).getTime() <= Date.now()) {
    return { slot_id: slot.id, ok: false, reason: "in_past" };
  }

  const { name, email } = await resolveCandidate(admin, slot.response_id);
  if (!email) return { slot_id: slot.id, ok: false, reason: "no_email" };

  // Load old zoom row (for cancellation + candidate_actions mirror lookup)
  let oldZoomDbId: string | null = slot.zoom_meeting_id;
  let oldZoomMeetingId: string | null = null;
  if (oldZoomDbId) {
    const { data: oldZm } = await admin
      .from("zoom_meetings")
      .select("zoom_meeting_id")
      .eq("id", oldZoomDbId)
      .maybeSingle();
    oldZoomMeetingId = oldZm?.zoom_meeting_id ?? null;
  }

  // Create new Zoom meeting (Manila local string, no offset)
  const startManila = new Date(new Date(slot.slot_start).getTime() + 8 * 60 * 60 * 1000)
    .toISOString()
    .replace(/\.\d{3}Z$/, "");
  let zoomRes: Response;
  try {
    zoomRes = await zoomFetch("/users/me/meetings", {
      method: "POST",
      jsonBody: {
        topic: `EIA Interview - ${name}`,
        type: 2,
        start_time: startManila,
        duration: 30,
        timezone: "Asia/Manila",
        settings: {
          host_video: true, participant_video: true, join_before_host: false,
          mute_upon_entry: false, waiting_room: true, auto_recording: "none",
          approval_type: 2, audio: "both", meeting_authentication: false,
        },
      },
    });
  } catch (e) {
    return { slot_id: slot.id, ok: false, reason: `zoom_unreachable:${(e as Error).message}` };
  }
  const zoomJson = await zoomRes.json().catch(() => ({}));
  if (!zoomRes.ok) {
    return { slot_id: slot.id, ok: false, reason: `zoom_${zoomRes.status}:${JSON.stringify(zoomJson).slice(0, 200)}` };
  }

  const newMeetingId = String(zoomJson.id);
  const { data: newZm, error: insErr } = await admin
    .from("zoom_meetings")
    .insert({
      zoom_meeting_id: newMeetingId,
      zoom_meeting_uuid: zoomJson.uuid ?? null,
      topic: `EIA Interview - ${name}`,
      start_time: zoomJson.start_time || slot.slot_start,
      duration_minutes: zoomJson.duration ?? 30,
      timezone: "Asia/Manila",
      join_url: zoomJson.join_url,
      password: zoomJson.password ?? null,
      start_url: zoomJson.start_url ?? null,
      status: "scheduled",
      last_synced_at: new Date().toISOString(),
    })
    .select("id")
    .maybeSingle();
  if (insErr || !newZm) {
    return { slot_id: slot.id, ok: false, reason: `db_insert:${insErr?.message || "unknown"}` };
  }

  // Repoint slot → new meeting row (single-row update by exact id)
  const { error: updErr } = await admin
    .from("interview_slots")
    .update({ zoom_meeting_id: newZm.id })
    .eq("id", slot.id);
  if (updErr) {
    return { slot_id: slot.id, ok: false, reason: `slot_update:${updErr.message}` };
  }

  // Mirror new meeting onto candidate_actions where the old zoom_meeting_id was referenced
  if (oldZoomMeetingId) {
    await admin
      .from("candidate_actions")
      .update({ round1_zoom_meeting_id: newMeetingId, round1_zoom_join_url: zoomJson.join_url })
      .eq("response_id", slot.response_id)
      .eq("round1_zoom_meeting_id", oldZoomMeetingId);
    await admin
      .from("candidate_actions")
      .update({ round2_zoom_meeting_id: newMeetingId, round2_zoom_join_url: zoomJson.join_url })
      .eq("response_id", slot.response_id)
      .eq("round2_zoom_meeting_id", oldZoomMeetingId);
  }

  // Mark old zoom row cancelled (the old account is dead anyway; this clears UI/state)
  if (oldZoomDbId) {
    await admin.from("zoom_meetings").update({ status: "cancelled" }).eq("id", oldZoomDbId);
  }

  // Fire-and-forget confirmation email with NEW Zoom link + .ics
  fetch(`${SUPABASE_URL}/functions/v1/send-interview-confirmed-email`, {
    method: "POST",
    headers: { Authorization: `Bearer ${SERVICE_KEY}`, "Content-Type": "application/json" },
    body: JSON.stringify({ response_id: slot.response_id }),
  }).catch((e) => console.error("confirmation email error", slot.id, e));

  return { slot_id: slot.id, ok: true, new_join_url: zoomJson.join_url };
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });
  const guard = await requireAdmin(req);
  if (guard instanceof Response) return guard;

  const body = await req.json().catch(() => ({}));
  const admin = adminClient();

  let slots: SlotRow[] = [];

  if (body?.slot_id) {
    if (!UUID_RE.test(body.slot_id)) return jsonResponse({ error: "invalid_slot_id" }, 400);
    const { data } = await admin
      .from("interview_slots")
      .select("id, slot_start, status, response_id, zoom_meeting_id")
      .eq("id", body.slot_id)
      .maybeSingle();
    if (!data) return jsonResponse({ error: "slot_not_found" }, 404);
    if (!["booked", "reserved"].includes(data.status)) {
      return jsonResponse({ error: "slot_not_booked", status: data.status }, 409);
    }
    slots = [data as SlotRow];
  } else if (Array.isArray(body?.slot_ids) && body.slot_ids.length > 0) {
    const ids: string[] = body.slot_ids.filter((s: unknown) => typeof s === "string" && UUID_RE.test(s as string));
    if (ids.length === 0) return jsonResponse({ error: "invalid_slot_ids" }, 400);
    const { data, error } = await admin
      .from("interview_slots")
      .select("id, slot_start, status, response_id, zoom_meeting_id")
      .in("id", ids)
      .order("slot_start", { ascending: true });
    if (error) return jsonResponse({ error: "load_failed", details: error.message }, 500);
    slots = (data || []) as SlotRow[];
  } else if (body?.batch_all_upcoming === true) {
    const { data, error } = await admin
      .from("interview_slots")
      .select("id, slot_start, status, response_id, zoom_meeting_id")
      .in("status", ["booked", "reserved"])
      .gt("slot_start", new Date().toISOString())
      .order("slot_start", { ascending: true });
    if (error) return jsonResponse({ error: "load_failed", details: error.message }, 500);
    slots = (data || []) as SlotRow[];
  } else {
    return jsonResponse({ error: "missing_slot_id_or_batch" }, 400);
  }

  const results: any[] = [];
  // Sequential to be gentle on Zoom (avoid bursting > rate limit)
  for (const s of slots) {
    try {
      const r = await regenerateOne(admin, s);
      results.push(r);
    } catch (e) {
      results.push({ slot_id: s.id, ok: false, reason: `exception:${(e as Error).message}` });
    }
  }

  const ok = results.filter((r) => r.ok).length;
  const failed = results.length - ok;
  return jsonResponse({ success: true, total: results.length, ok, failed, results });
});
