// send-id-collection-form: HR/admin orchestrator. Mints token + public link,
// inserts a leave_requests row with doc_type='id_collection', stores the optional
// HR message, and sends the invite email via send-dual-email.
// CLONE of send-cash-advance-form (Option B: same leave_requests table, multiple doc types).
// Differences only: ID- reference prefix, doc_type='id_collection', id_hr_message
// stored at invite time, the /id-collection/{token} public route, and ID-collection wording.
// NOTE: model (a) — in-page upload + signature, NO SignFlow round-trip.
import { createClient } from "npm:@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
const ANON = Deno.env.get("SUPABASE_ANON_KEY")!;
const SVC = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
const PUBLIC_BASE = "https://jobs.expertintuitiveadvisor.com";

const json = (b: unknown, status = 200) =>
  new Response(JSON.stringify(b), {
    status,
    headers: { ...corsHeaders, "content-type": "application/json" },
  });

function shortHex(n: number) {
  const bytes = new Uint8Array(n / 2);
  crypto.getRandomValues(bytes);
  return Array.from(bytes).map((b) => b.toString(16).padStart(2, "0")).join("");
}

function esc(s: string): string {
  return String(s ?? "").replace(/[&<>"']/g, (c) =>
    ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]!),
  );
}

function buildIdSenderA(firstName: string, link: string) {
  const text = `Hi ${firstName},

Please complete your ID collection request using the secure link below. Upload clear photos of your valid ID(s), add any notes requested, sign, and submit.

OPEN YOUR ID COLLECTION FORM:
${link}

Please review and complete your identity document form using the secure link above.

If you have any questions, simply reply to this email.

Angela Stein
HR — Talent Manager
Expert Intuitive Advisor Inc.`;
  const html = `<div style="font-family:Arial,sans-serif;font-size:14px;color:#1a2236;line-height:1.6;max-width:600px">
<p>Hi ${firstName},</p>
<p>Please complete your ID collection request using the secure link below. Upload clear photos of your valid ID(s), add any notes requested, sign, and submit.</p>
<p><a href="${link}" style="display:inline-block;background:#1a2547;color:#ffffff;padding:12px 22px;border-radius:6px;text-decoration:none;font-weight:600">Open your ID collection form</a></p>
<p style="font-size:12px;color:#666">Or paste this link into your browser:<br/><a href="${link}" style="color:#1a2547">${link}</a></p>
<p>Please review and complete your identity document form using the secure link above.</p>
<p>If you have any questions, simply reply to this email.</p>
<p>Angela Stein<br/>HR — Talent Manager<br/>Expert Intuitive Advisor Inc.</p>
</div>`;
  return {
    from_name: "Angela Stein / HR — Talent Manager",
    from_address: "talent@expertintuitiveadvisor.com",
    subject: "ID Collection Form — please upload your ID and submit (Expert Intuitive Advisor Inc.)",
    html_body: html,
    text_body: text,
  };
}

function buildIdSenderB(firstName: string, link: string) {
  const text = `Hi ${firstName},

Quick personal note — here's your ID collection form link again so you don't have to dig:

${link}

Upload your ID, add any details, sign, and submit when you can. If anything's unclear, just reply.

— Angela Stein`;
  const html = `<div style="font-family:Arial,sans-serif;font-size:14px;color:#1a2236;line-height:1.6;max-width:600px">
<p>Hi ${firstName},</p>
<p>Quick personal note — here's your ID collection form link again so you don't have to dig:</p>
<p><a href="${link}" style="color:#1a2547">${link}</a></p>
<p>Upload your ID, add any details, sign, and submit when you can. If anything's unclear, just reply.</p>
<p>— Angela Stein</p>
</div>`;
  return {
    from_name: "Angela Stein",
    from_address: "expertintuitiveadvisor@gmail.com",
    subject: "Your EIA ID collection form",
    html_body: html,
    text_body: text,
  };
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });
  if (req.method !== "POST") return json({ ok: false, reason: "method_not_allowed" }, 405);

  // Admin gate (mirrors send-cash-advance-form)
  const auth = req.headers.get("Authorization") || "";
  if (!auth.startsWith("Bearer ")) return json({ ok: false, reason: "missing_auth" }, 401);
  const userClient = createClient(SUPABASE_URL, ANON, { global: { headers: { Authorization: auth } } });
  const { data: u } = await userClient.auth.getUser();
  if (!u?.user) return json({ ok: false, reason: "invalid_jwt" }, 401);
  const admin = createClient(SUPABASE_URL, SVC);
  const { data: urow } = await admin.from("users").select("role").eq("id", u.user.id).maybeSingle();
  if (!urow || urow.role !== "admin") return json({ ok: false, reason: "forbidden" }, 403);

  let body: { name?: string; email?: string; id_hr_message?: string; hr_copy_requested?: boolean; hr_copy_email_override?: string };
  try { body = await req.json(); } catch { return json({ ok: false, reason: "invalid_json" }, 400); }
  const { name: directName, email: directEmail } = body || {};
  const hrCopyRequested = !!(body as any)?.hr_copy_requested;
  const hrCopyEmailOverrideRaw = typeof (body as any)?.hr_copy_email_override === "string" ? (body as any).hr_copy_email_override.trim() : "";
  const hrCopyEmailOverride = hrCopyEmailOverrideRaw && /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(hrCopyEmailOverrideRaw) ? hrCopyEmailOverrideRaw : null;
  const idHrMessageRaw = typeof (body as any)?.id_hr_message === "string" ? (body as any).id_hr_message.trim() : "";
  const idHrMessage = idHrMessageRaw ? idHrMessageRaw.slice(0, 20000) : null;
  const idTextStyleRaw = typeof (body as any)?.id_text_style === "string" ? (body as any).id_text_style.trim() : "";
  const idTextStyle = ["bullets", "spacing", "paragraphs"].includes(idTextStyleRaw) ? idTextStyleRaw : "bullets";

  let signerEmail = "";
  let signerName = "";

  if (directName && directEmail) {
    signerName = String(directName).trim();
    signerEmail = String(directEmail).trim();
  } else {
    return json({ ok: false, reason: "missing_input" }, 400);
  }

  if (!signerEmail || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(signerEmail)) {
    return json({ ok: false, reason: "no_email" }, 400);
  }
  if (!signerName) return json({ ok: false, reason: "no_name" }, 400);

  // Mint reference + token (token is independent of reference)
  const reference = `ID-${shortHex(8).toUpperCase()}`;
  const token = shortHex(48); // 48 hex chars

  // Insert leave_requests row as an ID collection (id_photo_*_url and id_body_note
  // filled when recipient submits; id_hr_message stored now if provided).
  const { error: insErr } = await admin.from("leave_requests").insert({
    response_id: null,
    external_reference: reference,
    signer_name: signerName,
    signer_email: signerEmail,
    token,
    status: "invited",
    doc_type: "id_collection",
    id_hr_message: idHrMessage,
    id_text_style: idTextStyle,
    hr_copy_requested: hrCopyRequested,
    hr_copy_email_override: hrCopyEmailOverride,
  });
  if (insErr) return json({ ok: false, reason: "persist_failed", detail: insErr.message }, 500);

  // Read-after-write guard
  const { data: verifyRow } = await admin
    .from("leave_requests").select("id, token").eq("external_reference", reference).maybeSingle();
  if (!verifyRow) return json({ ok: false, reason: "persist_failed", detail: "row not found after insert" }, 500);

  // Send invite via send-dual-email
  const link = `${PUBLIC_BASE}/id-collection/${token}`;
  const firstName = signerName.trim().split(/\s+/)[0] || signerName;

  const emailResp = await fetch(`${SUPABASE_URL}/functions/v1/send-dual-email`, {
    method: "POST",
    headers: { Authorization: `Bearer ${SVC}`, "Content-Type": "application/json" },
    body: JSON.stringify({
      to: signerEmail,
      stage: "id_collection_form_sent",
      sender_a: buildIdSenderA(firstName, link),
      sender_b: buildIdSenderB(firstName, link),
    }),
  });
  const emailJson = await emailResp.json().catch(() => ({}));
  if (!emailResp.ok) {
    return json({
      ok: false, reason: "email_failed", detail: emailJson,
      token, external_reference: reference,
    }, 502);
  }

  return json({ ok: true, token, external_reference: reference, link });
});
