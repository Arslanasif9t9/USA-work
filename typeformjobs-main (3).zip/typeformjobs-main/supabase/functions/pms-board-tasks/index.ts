import { createClient } from "npm:@supabase/supabase-js@2";
import { corsHeaders, json, requireHr } from "../_shared/hr-auth.ts";

const PMS_URL = Deno.env.get("PMS_SUPABASE_URL")!;
const PMS_KEY = Deno.env.get("PMS_SERVICE_ROLE_KEY")!;
const BRIDGE_KEY = Deno.env.get("SYLVIA_BRIDGE_KEY")!;

Deno.serve(async (req) => {
  if (req.method === "OPTIONS")
    return new Response(null, {
      headers: {
        ...corsHeaders,
        "Access-Control-Allow-Headers":
          "authorization, x-client-info, apikey, content-type, x-sylvia-key",
      },
    });
  try {
    // Auth: Sylvia bridge key OR HR JWT
    const sylviaKey = req.headers.get("x-sylvia-key");
    if (!sylviaKey || sylviaKey !== BRIDGE_KEY) {
      const ident = await requireHr(req);
      if (ident instanceof Response) return ident;
    }

    const { board_id } = await req.json().catch(() => ({}));
    if (!board_id) return json({ error: "missing board_id" }, 400);

    const pms = createClient(PMS_URL, PMS_KEY);

    // 1. Board name
    const { data: board, error: boardErr } = await pms
      .from("boards")
      .select("id, name")
      .eq("id", board_id)
      .maybeSingle();
    if (boardErr) return json({ error: boardErr.message }, 500);
    if (!board) return json({ error: "board_not_found" }, 404);

    // 2. Top-level items
    const { data: items, error: itemsErr } = await pms
      .from("items")
      .select("id, task_code, name, group_id, sort_order")
      .eq("board_id", board_id)
      .is("deleted_at", null)
      .is("parent_item_id", null);
    if (itemsErr) return json({ error: itemsErr.message }, 500);

    // 3. Groups
    const { data: groups, error: groupsErr } = await pms
      .from("groups")
      .select("id, name, sort_order")
      .eq("board_id", board_id);
    if (groupsErr) return json({ error: groupsErr.message }, 500);
    const groupMap = new Map<string, { name: string; sort_order: number }>();
    for (const g of groups ?? []) groupMap.set(g.id, { name: g.name, sort_order: g.sort_order ?? 0 });

    // 4. Status + priority columns
    const { data: cols, error: colsErr } = await pms
      .from("columns")
      .select("id, column_type")
      .eq("board_id", board_id)
      .is("archived_at", null)
      .in("column_type", ["status", "priority"]);
    if (colsErr) return json({ error: colsErr.message }, 500);
    const statusCol = cols?.find((c) => c.column_type === "status") ?? null;
    const priorityCol = cols?.find((c) => c.column_type === "priority") ?? null;

    // 5. Labels
    const colIds = [statusCol?.id, priorityCol?.id].filter(Boolean) as string[];
    const labelMap = new Map<string, { name: string; color: string | null }>();
    if (colIds.length > 0) {
      const { data: labels, error: labelsErr } = await pms
        .from("column_labels")
        .select("id, column_id, name, color")
        .in("column_id", colIds);
      if (labelsErr) return json({ error: labelsErr.message }, 500);
      for (const l of labels ?? []) labelMap.set(l.id, { name: l.name, color: l.color });
    }

    // 6. Item column values
    const itemIds = (items ?? []).map((i) => i.id);
    const statusByItem = new Map<string, string | null>();
    const priorityByItem = new Map<string, string | null>();
    if (itemIds.length > 0 && colIds.length > 0) {
      const { data: vals, error: valsErr } = await pms
        .from("item_column_values")
        .select("item_id, column_id, value")
        .in("column_id", colIds)
        .in("item_id", itemIds);
      if (valsErr) return json({ error: valsErr.message }, 500);
      for (const v of vals ?? []) {
        const labelId = (v.value as any)?.label_id ?? null;
        if (statusCol && v.column_id === statusCol.id) statusByItem.set(v.item_id, labelId);
        else if (priorityCol && v.column_id === priorityCol.id) priorityByItem.set(v.item_id, labelId);
      }
    }

    // 7. Build tasks array
    const tasks = (items ?? []).map((it) => {
      const g = it.group_id ? groupMap.get(it.group_id) : null;
      const sLabelId = statusByItem.get(it.id) ?? null;
      const pLabelId = priorityByItem.get(it.id) ?? null;
      const sLab = sLabelId ? labelMap.get(sLabelId) : null;
      const pLab = pLabelId ? labelMap.get(pLabelId) : null;
      return {
        task_id: it.id,
        task_code: it.task_code,
        name: it.name,
        group_name: g?.name ?? null,
        _group_sort: g?.sort_order ?? 999999,
        _item_sort: it.sort_order ?? 0,
        status: sLab?.name ?? null,
        status_color: sLab?.color ?? null,
        priority: pLab?.name ?? null,
        priority_color: pLab?.color ?? null,
      };
    });
    tasks.sort((a, b) => a._group_sort - b._group_sort || a._item_sort - b._item_sort);
    const cleaned = tasks.map(({ _group_sort, _item_sort, ...rest }) => rest);

    return json({ board_name: board.name, tasks: cleaned });
  } catch (e: any) {
    return json({ error: String(e?.message || e) }, 500);
  }
});
