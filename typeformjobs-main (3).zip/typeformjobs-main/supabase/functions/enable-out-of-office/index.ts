// enable-out-of-office: Boss2929 gated. Creates OOO period, cancels affected bookings,
// generates rebook tokens, sends cancellation emails, notifies boss inboxes.
import { createClient } from "npm:@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
const ANON = Deno.env.get("SUPABASE_ANON_KEY")!;
const SERVICE = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
const BOSS2929 = Deno.env.get("BOSS2929_PASSWORD") || "Boss2929";
const RESEND_API_KEY = Deno.env.get("RESEND_API_KEY")!;
const BOSS_INBOXES = ["talent.expertadvisor@outlook.com", "spark11179@gmail.com"];
const PUBLIC_BASE = Deno.env.get("PUBLIC_BASE_URL") || "https://jobs.expertintuitiveadvisor.com";

const json = (b: unknown, s = 200) =>
  new Response(JSON.stringify(b), { status: s, headers: { ...corsHeaders, "Content-Type": "application/json" } });

function randomToken() {
  const a = new Uint8Array(24);
  crypto.getRandomValues(a);
  return Array.from(a).map((b) => b.toString(16).padStart(2, "0")).join("");
}

async function deleteZoom(zoomMeetingId: string) {
  try {
    const ZOOM_ACCOUNT_ID = Deno.env.get("ZOOM_ACCOUNT_ID");
    const ZOOM_CLIENT_ID = Deno.env.get("ZOOM_CLIENT_ID");
    const ZOOM_CLIENT_SECRET = Deno.env.get("ZOOM_CLIENT_SECRET");
    if (!ZOOM_ACCOUNT_ID || !ZOOM_CLIENT_ID || !ZOOM_CLIENT_SECRET) return;
    const basic = btoa(`${ZOOM_CLIENT_ID}:${ZOOM_CLIENT_SECRET}`);
    const tokRes = await fetch("https://zoom.us/oauth/token", {
      method: "POST",
      headers: { Authorization: `Basic ${basic}`, "Content-Type": "application/x-www-form-urlencoded" },
      body: `grant_type=account_credentials&account_id=${encodeURIComponent(ZOOM_ACCOUNT_ID)}`,
    });
    const tok = await tokRes.json().catch(() => ({}));
    if (!tok.access_token) return;
    await fetch(`https://api.zoom.us/v2/meetings/${zoomMeetingId}`, {
      method: "DELETE",
      headers: { Authorization: `Bearer ${tok.access_token}` },
    });
  } catch (_) { /* swallow */ }
}

async function sendEmail(to: string, subject: string, html: string) {
  if (!RESEND_API_KEY) return { ok: false };
  const res = await fetch("https://api.resend.com/emails", {
    method: "POST",
    headers: { Authorization: `Bearer ${RESEND_API_KEY}`, "Content-Type": "application/json" },
    body: JSON.stringify({
      from: "EIA Talent <talent@expertintuitiveadvisor.com>",
      to: [to], subject, html,
    }),
  });
  return { ok: res.ok };
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });
  try {
    const authHeader = req.headers.get("Authorization");
    if (!authHeader?.startsWith("Bearer ")) return json({ error: "unauthorized" }, 401);
    const userClient = createClient(SUPABASE_URL, ANON, { global: { headers: { Authorization: authHeader } } });
    const { data: userData, error: uErr } = await userClient.auth.getUser();
    if (uErr || !userData?.user) return json({ error: "unauthorized" }, 401);
    const admin = createClient(SUPABASE_URL, SERVICE);
    const email = (userData.user.email || "").toLowerCase();
    const { data: hr } = await admin.from("hr_users").select("id, display_name, role").ilike("email", email).maybeSingle();

    const body = await req.json().catch(() => ({}));
    const { password, start_date, end_date, reason } = body || {};
    if (!password || !start_date || !end_date) return json({ error: "missing_fields" }, 400);
    if (password !== BOSS2929) {
      await admin.from("password_audit_log").insert({
        hr_user_id: hr?.id ?? null, password_used: "***wrong***", action_taken: "ooo_enable_failed",
      });
      return json({ error: "wrong_password" }, 403);
    }
    if (end_date < start_date) return json({ error: "invalid_range" }, 400);

    // Create OOO period
    const { data: period, error: pErr } = await admin
      .from("out_of_office_periods")
      .insert({ start_date, end_date, reason: reason || null, enabled_by_hr_id: hr?.id ?? null })
      .select("id")
      .single();
    if (pErr || !period) return json({ error: "period_insert_failed", details: pErr?.message }, 500);

    // Update scheduling_config
    await admin.from("scheduling_config").update({
      is_out_of_office: true,
      out_of_office_start: start_date,
      out_of_office_end: end_date,
      ooo_active_period_id: period.id,
    }).eq("id", 1);

    // Find affected booked slots in range
    const { data: affected } = await admin
      .from("interview_slots")
      .select("id, slot_start, slot_date, response_id, zoom_meeting_id")
      .eq("status", "booked")
      .gte("slot_date", start_date)
      .lte("slot_date", end_date);

    const affectedList = affected || [];
    let emailsSent = 0;

    for (const slot of affectedList) {
      // Look up zoom meeting + candidate info
      let zoomMeetingExternalId: string | null = null;
      if (slot.zoom_meeting_id) {
        const { data: zm } = await admin
          .from("zoom_meetings")
          .select("zoom_meeting_id")
          .eq("id", slot.zoom_meeting_id)
          .maybeSingle();
        zoomMeetingExternalId = zm?.zoom_meeting_id ?? null;
      }

      // Candidate info via response → answers (best effort)
      let candEmail = ""; let candName = "Candidate";
      if (slot.response_id) {
        const { data: ans } = await admin
          .from("answers")
          .select("answer_text, question_id, questions:question_id(type, label)")
          .eq("response_id", slot.response_id);
        for (const a of ans || []) {
          const q: any = (a as any).questions;
          if (!q) continue;
          const t = (q.type || "").toLowerCase();
          const lbl = (q.label || "").toLowerCase();
          if (!candEmail && (t === "email" || lbl.includes("email"))) candEmail = a.answer_text || "";
          if (candName === "Candidate" && (lbl.includes("name") || t === "name" || t === "short_text")) {
            if (a.answer_text) candName = a.answer_text;
          }
        }
      }

      // Cancel zoom
      if (zoomMeetingExternalId) await deleteZoom(zoomMeetingExternalId);
      if (slot.zoom_meeting_id) {
        await admin.from("zoom_meetings")
          .update({ status: "cancelled", last_synced_at: new Date().toISOString() })
          .eq("id", slot.zoom_meeting_id);
      }

      // Generate rebook token (only if we have a response_id)
      let token: string | null = null;
      if (slot.response_id && candEmail) {
        token = randomToken();
        await admin.from("rebook_tokens").insert({
          token,
          response_id: slot.response_id,
          original_slot_id: slot.id,
          candidate_email: candEmail,
          candidate_name: candName,
        });
      }

      // Free up the slot
      await admin.from("interview_slots").update({
        status: "available",
        response_id: null,
        zoom_meeting_id: null,
        cancelled_due_to_ooo: true,
        ooo_period_id: period.id,
      }).eq("id", slot.id);

      // Send cancellation email
      if (candEmail && token) {
        try {
          await admin.functions.invoke("send-ooo-cancellation-email", {
            body: {
              to: candEmail,
              candidate_name: candName,
              original_slot_start: slot.slot_start,
              rebook_url: `${PUBLIC_BASE}/rebook/${token}`,
              ooo_start: start_date,
              ooo_end: end_date,
            },
          });
          emailsSent++;
        } catch (e) {
          console.error("cancellation_email_failed", e);
        }
      }
    }

    // DISABLED: the "Out of Office enabled" alert email to the boss/Outlook inboxes
    // is intentionally turned off (button removed/unused). All OOO logic above
    // (period creation, slot cancellation, rebook tokens, candidate cancellation
    // emails) is unchanged — only this internal alert send is skipped.
    const summary = `Out of Office enabled: ${start_date} to ${end_date} — affected ${affectedList.length}, cancellations ${emailsSent}`;
    void summary;

    await admin.from("password_audit_log").insert({
      hr_user_id: hr?.id ?? null, password_used: "***correct***", action_taken: "ooo_enabled",
      target_resource_id: period.id,
    });

    return json({ success: true, period_id: period.id, affected: affectedList.length, emails_sent: emailsSent });
  } catch (e: any) {
    console.error("enable-out-of-office error", e);
    return json({ error: "internal", details: String(e?.message || e) }, 500);
  }
});
