// send-onboarding-test-invite: HR-only. Sends the branded invite carrying the
// /onboarding-test/:token link (video + quiz). Mints separately first.
import { adminClient, corsHeaders, json, requireHr } from "../_shared/hr-auth.ts";

const RESEND_API_KEY = Deno.env.get("RESEND_API_KEY")!;
// Sender read from config (single place to change). Verified domain.
const FROM = "Angela Stein / HR – Talent Manager <talent@expertintuitiveadvisor.com>";
const FROM_ADDR = "talent@expertintuitiveadvisor.com";
const FROM_NAME = "Angela Stein / HR – Talent Manager";
const PUBLIC_BASE = "https://jobs.expertintuitiveadvisor.com";

const NAVY = "#1a2547";
const GOLD = "#b08d57";

function inviteHtml(firstName: string, link: string) {
  return `<!doctype html><html><body style="margin:0;padding:0;background:#faf8f3;font-family:Inter,Arial,sans-serif;color:${NAVY}">
  <table width="100%" cellpadding="0" cellspacing="0" style="background:#faf8f3;padding:32px 0">
    <tr><td align="center">
      <table width="560" cellpadding="0" cellspacing="0" style="background:#ffffff;border-top:4px solid ${GOLD};padding:32px 32px 28px 32px">
        <tr><td>
          <div style="font-family:'Cormorant Garamond',Georgia,serif;font-size:26px;color:${NAVY};font-weight:600;margin-bottom:6px">
            Welcome aboard, ${firstName}
          </div>
          <div style="font-size:11px;letter-spacing:3px;text-transform:uppercase;color:${GOLD};margin-bottom:16px">
            Your EIA Onboarding
          </div>
          <p style="font-size:15px;line-height:1.6;color:${NAVY};margin:0 0 14px 0">
            Welcome to Expert Intuitive Advisor Inc. Your onboarding has two short steps: watch a brief orientation video, then complete an 11-question check. The check unlocks once the video finishes.
          </p>
          <p style="text-align:center;margin:26px 0">
            <a href="${link}" style="display:inline-block;background:${NAVY};color:#ffffff;text-decoration:none;padding:14px 28px;border-radius:6px;font-weight:600;font-size:15px">Begin Onboarding</a>
          </p>
          <p style="font-size:13px;line-height:1.6;color:${NAVY};margin:0 0 8px 0">
            Or copy this link:<br/>
            <span style="color:${NAVY};word-break:break-all;font-size:12px">${link}</span>
          </p>
          <p style="font-size:13px;line-height:1.6;color:#555;margin:18px 0 0 0">
            This is a private, single-use link issued just for you. Please use the exact name and email it was sent to.
          </p>
          <p style="font-size:14px;line-height:1.6;color:${NAVY};margin:24px 0 0 0">
            Warm regards,<br/>
            <span style="color:${GOLD}">Angela Stein</span><br/>
            HR – Talent Manager<br/>
            Expert Intuitive Advisor Inc.
          </p>
        </td></tr>
      </table>
    </td></tr>
  </table>
  </body></html>`;
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });
  if (req.method !== "POST") return json({ error: "method_not_allowed" }, 405);

  const hr = await requireHr(req);
  if (hr instanceof Response) return hr;

  let body: { token?: string };
  try { body = await req.json(); } catch { return json({ error: "bad_request" }, 400); }
  const token = (body.token || "").trim();
  if (!token) return json({ error: "missing_token" }, 400);

  const admin = adminClient();
  const { data: tok } = await admin
    .from("onboarding_quiz_tokens")
    .select("token, candidate_name, candidate_email")
    .eq("token", token).maybeSingle();
  if (!tok) return json({ error: "token_not_found" }, 404);

  const toAddr = (tok.candidate_email || "").trim();
  if (!toAddr) return json({ error: "no_recipient" }, 400);

  const firstName = ((tok.candidate_name || "").split(" ")[0] || "there").trim();
  const link = `${PUBLIC_BASE}/onboarding-test/${token}`;
  const subject = "Your EIA Onboarding — Video & Check";
  const html = inviteHtml(firstName, link);
  const text = `Hi ${firstName},

Welcome to Expert Intuitive Advisor Inc. Your onboarding has two short steps: watch a brief orientation video, then complete an 11-question check. The check unlocks once the video finishes.

Begin here:
${link}

This is a private, single-use link issued just for you. Please use the exact name and email it was sent to.

Warm regards,
Angela Stein
HR – Talent Manager
Expert Intuitive Advisor Inc.`;

  const sendRes = await fetch("https://api.resend.com/emails", {
    method: "POST",
    headers: { "Content-Type": "application/json", Authorization: `Bearer ${RESEND_API_KEY}` },
    body: JSON.stringify({ from: FROM, to: [toAddr], subject, html, text }),
  });
  const sendJson = await sendRes.json().catch(() => ({}));

  // Failure-safe logging: the Supabase query builder is thenable but has no
  // .catch() method — calling .catch() on it throws a TypeError and crashes the
  // function AFTER the email already sent. Wrap in try/catch so a logging hiccup
  // never makes a successful send look failed.
  try {
    await admin.from("email_log").insert({
      candidate_id: null,
      stage: "onboarding_quiz_sent",
      sender: "resend",
      from_address: FROM_ADDR,
      from_name: FROM_NAME,
      to_address: toAddr,
      subject,
      status: sendRes.ok ? "sent" : "failed",
      resend_message_id: (sendJson as any)?.id || null,
      error_message: sendRes.ok ? null : JSON.stringify(sendJson),
    });
  } catch (_logErr) {
    // ignore logging failures
  }

  if (!sendRes.ok) return json({ error: "send_failed", detail: sendJson }, 502);
  return json({ ok: true }, 200);
});
