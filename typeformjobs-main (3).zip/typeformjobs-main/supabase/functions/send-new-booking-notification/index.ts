// send-new-booking-notification: sends booking alert to HR shared + master admin via Resend.
import { createClient } from "npm:@supabase/supabase-js@2";
import { formatManilaDate, formatManilaTime } from "../_shared/manila.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
const SERVICE_KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
const RESEND_API_KEY = Deno.env.get("RESEND_API_KEY")!;

const RECIPIENTS = ["talent.expertadvisor@outlook.com"];

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });
  const admin = createClient(SUPABASE_URL, SERVICE_KEY);
  const body = await req.json().catch(() => ({}));
  const slotId = body?.slot_id;
  if (!slotId) {
    return new Response(JSON.stringify({ error: "missing slot_id" }), {
      status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }

  const { data: slot } = await admin
    .from("interview_slots")
    .select("id, slot_start, response_id, zoom_meeting_id")
    .eq("id", slotId)
    .maybeSingle();
  if (!slot) {
    return new Response(JSON.stringify({ error: "slot_not_found" }), {
      status: 404, headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }

  // Load response → form, plus answers for candidate name/email
  let candidateName = "Candidate";
  let candidateEmail = "";
  let positionTitle = "the role";
  if (slot.response_id) {
    const { data: resp } = await admin.from("responses").select("id, form_id, override_name").eq("id", slot.response_id).maybeSingle();
    if (resp) {
      const { data: meta } = await admin.from("form_metadata").select("position_title").eq("form_id", resp.form_id).maybeSingle();
      positionTitle = (meta?.position_title || "").trim() || "the role";

      const { data: qs } = await admin.from("questions").select("id, type, label").eq("form_id", resp.form_id);
      const { data: ans } = await admin.from("answers").select("question_id, answer_text").eq("response_id", slot.response_id);
      const emailQ = qs?.find((q: any) => q.type === "email");
      const nameQ = qs?.find((q: any) => q.type === "short_text" && /name/i.test(q.label)) || qs?.find((q: any) => q.type === "short_text");
      const find = (qid?: string) => qid ? (ans?.find((a: any) => a.question_id === qid)?.answer_text || "").trim() : "";
      candidateEmail = find(emailQ?.id);
      candidateName = ((resp as any).override_name || "").trim() || find(nameQ?.id) || "Candidate";
    }
  }

  let zoomUrl = "";
  if (slot.zoom_meeting_id) {
    const { data: zm } = await admin.from("zoom_meetings").select("join_url").eq("id", slot.zoom_meeting_id).maybeSingle();
    zoomUrl = zm?.join_url || "";
  }

  const slotDate = new Date(slot.slot_start);
  const dateStr = formatManilaDate(slotDate);
  const timeStr = formatManilaTime(slotDate);

  const subject = `New interview booked — ${dateStr} at ${timeStr} (${positionTitle})`;
  const text = `A new candidate just booked an interview through the form.

CANDIDATE: ${candidateName}
EMAIL: ${candidateEmail}
POSITION: ${positionTitle}

INTERVIEW DETAILS:
Date: ${dateStr}
Time: ${timeStr} (Philippine Standard Time)
Duration: 30 minutes
Zoom: ${zoomUrl}

This appointment is now in the Booking Dashboard awaiting claim.

— EIA Talent Recruiting System`;

  const html = text.replace(/\n/g, "<br/>");

  // DISABLED: the per-booking "New interview booked" notification email to the
  // Outlook inbox is intentionally turned off. No copy/notification is sent here.
  // (Document backups and critical alerts are unaffected — they live elsewhere.)
  void subject; void html; void text;


  return new Response(JSON.stringify({ success: true }), {
    status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" },
  });
});
