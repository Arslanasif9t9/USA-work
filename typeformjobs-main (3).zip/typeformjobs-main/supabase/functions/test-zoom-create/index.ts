// test-zoom-create: admin-only smoke test. Creates a meeting starting in 1 hour.
import {
  adminClient,
  corsHeaders,
  jsonResponse,
  requireAdmin,
  zoomFetch,
} from "../_shared/zoom.ts";

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });
  const guard = await requireAdmin(req);
  if (guard instanceof Response) return guard;

  let body: { topic?: string; duration_minutes?: number } = {};
  try {
    body = (await req.json()) ?? {};
  } catch {
    body = {};
  }

  const topic = (body.topic || "EIA Test Meeting").slice(0, 200);
  const duration = body.duration_minutes ?? 15;

  // Manila time = UTC+8. Convert "1 hour from now" UTC into Manila local string (no offset).
  const startUtc = new Date(Date.now() + 60 * 60 * 1000);
  const startManila = new Date(startUtc.getTime() + 8 * 60 * 60 * 1000);
  const startStr = startManila.toISOString().replace(/\.\d{3}Z$/, ""); // YYYY-MM-DDTHH:mm:ss

  const res = await zoomFetch("/users/me/meetings", {
    method: "POST",
    jsonBody: {
      topic,
      type: 2,
      start_time: startStr,
      duration,
      timezone: "Asia/Manila",
      password: "",
      settings: {
        host_video: true,
        participant_video: true,
        join_before_host: false,
        mute_upon_entry: false,
        waiting_room: true,
        auto_recording: "none",
        approval_type: 2,
        audio: "both",
      },
    },
  });
  const zj = await res.json().catch(() => ({}));
  const rateHeaders: Record<string, string> = {};
  res.headers.forEach((v, k) => {
    const lk = k.toLowerCase();
    if (lk.startsWith("x-ratelimit") || lk === "retry-after") rateHeaders[k] = v;
  });
  if (!res.ok) {
    return jsonResponse(
      { success: false, status: res.status, details: zj, rate_limit_headers: rateHeaders },
      502,
    );
  }

  const meetingId = String(zj.id);
  const admin = adminClient();
  const { data: inserted, error: insErr } = await admin
    .from("zoom_meetings")
    .insert({
      zoom_meeting_id: meetingId,
      zoom_meeting_uuid: zj.uuid ?? null,
      topic,
      start_time: zj.start_time || new Date(startUtc).toISOString(),
      duration_minutes: zj.duration ?? duration,
      timezone: zj.timezone || "Asia/Manila",
      join_url: zj.join_url,
      password: zj.password ?? null,
      start_url: zj.start_url ?? null,
      status: "scheduled",
      last_synced_at: new Date().toISOString(),
    })
    .select("id")
    .maybeSingle();

  return jsonResponse({
    success: true,
    meeting_id: meetingId,
    join_url: zj.join_url,
    password: zj.password ?? null,
    start_url: zj.start_url ?? null,
    start_time: zj.start_time,
    duration_minutes: zj.duration ?? duration,
    db_record_id: inserted?.id ?? null,
    db_error: insErr?.message ?? null,
  });
});
