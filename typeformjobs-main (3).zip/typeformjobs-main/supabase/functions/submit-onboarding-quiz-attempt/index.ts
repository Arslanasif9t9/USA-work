// submit-onboarding-quiz-attempt: PUBLIC, token-gated + identity-gated.
// Scores the quiz SERVER-SIDE (correct_index never leaves the server),
// records the attempt, enforces the 3-attempt limit, and invalidates the link
// on PASS or on the 3rd fail (single-use either way).
import { createClient } from "npm:@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};
const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
const SERVICE = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
const json = (b: unknown, s = 200) =>
  new Response(JSON.stringify(b), { status: s, headers: { ...corsHeaders, "Content-Type": "application/json" } });

const MAX_ATTEMPTS = 3;
const PASS_MARK = 9;
// Reusable preview link: this single literal token is exempt from the
// single-use kill (never invalidated, attempt counter resets). No other
// token is ever affected.
const TEST_TOKEN = "permanent-test";
const norm = (s: unknown) => (typeof s === "string" ? s.trim().toLowerCase() : "");

// ─── ADDITIVE: auto-approve pass email ───────────────────────────────────────
// Mirrors decide-onboarding-quiz's APPROVE email (same template, same Resend
// pattern, same email_log stage 'onboarding_quiz_approved'). Used only when a
// pass lands on a token whose after_pass_mode = "auto". Fully failure-safe.
const RESEND_API_KEY = Deno.env.get("RESEND_API_KEY") || "";
const FROM_NAME = "Angela Stein / HR – Talent Manager";
const FROM_ADDR = "talent@expertintuitiveadvisor.com";
const FROM = `${FROM_NAME} <${FROM_ADDR}>`;
const NAVY = "#1a2547";
const GOLD = "#b08d57";

const htmlEscape = (s: string) =>
  String(s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;").replace(/'/g, "&#39;");

const fmtDate = (iso: string | null) =>
  (iso ? new Date(iso) : new Date()).toLocaleDateString("en-US", { year: "numeric", month: "long", day: "numeric" });

function shell(innerHtml: string): string {
  const year = new Date().getFullYear();
  return `<!doctype html><html><body style="margin:0;padding:0;background:#faf8f3;font-family:Inter,Arial,sans-serif;color:${NAVY}">
  <table width="100%" cellpadding="0" cellspacing="0" style="background:#faf8f3;padding:32px 0">
    <tr><td align="center">
      <table width="560" cellpadding="0" cellspacing="0" style="background:#ffffff;border-top:4px solid ${GOLD};padding:34px 34px 30px 34px">
        <tr><td style="text-align:center;padding-bottom:6px">
          <div style="font-family:'Cormorant Garamond',Georgia,serif;font-weight:600;font-size:28px;letter-spacing:6px;color:${NAVY}">EIA</div>
          <div style="font-size:10px;letter-spacing:2px;text-transform:uppercase;color:${GOLD};margin-top:6px">Expert Intuitive Advisor Inc.</div>
          <div style="height:1px;background:${GOLD};width:60px;margin:18px auto 22px"></div>
        </td></tr>
        <tr><td>${innerHtml}</td></tr>
        <tr><td style="padding-top:22px">
          <div style="height:1px;background:#e6e0d1;margin-bottom:14px"></div>
          <div style="font-size:11px;color:#9a9588;text-align:center">&copy; ${year} Expert Intuitive Advisor Inc.</div>
        </td></tr>
      </table>
    </td></tr>
  </table>
  </body></html>`;
}

function resultCard(rows: Array<[string, string]>): string {
  const cells = rows.map(([k, v]) =>
    `<tr>
       <td style="padding:6px 0;font-size:13px;color:#6b6655;font-family:Inter,Arial,sans-serif">${htmlEscape(k)}</td>
       <td style="padding:6px 0;font-size:14px;font-weight:600;color:${NAVY};text-align:right;font-family:Inter,Arial,sans-serif">${htmlEscape(v)}</td>
     </tr>`).join("");
  return `<div style="background:#faf8f3;border-left:4px solid ${GOLD};border-radius:4px;padding:14px 20px;margin:18px 0">
    <div style="font-family:Inter,Arial,sans-serif;font-weight:600;font-size:12px;letter-spacing:2px;text-transform:uppercase;color:${GOLD};margin-bottom:6px">Result Report</div>
    <table width="100%" cellpadding="0" cellspacing="0">${cells}</table>
  </div>`;
}

function approvedEmail(firstName: string, rows: Array<[string, string]>) {
  const inner = `
    <div style="font-family:'Cormorant Garamond',Georgia,serif;font-size:24px;color:${NAVY};font-weight:600;margin-bottom:4px">Congratulations, ${htmlEscape(firstName)}</div>
    <div style="font-size:11px;letter-spacing:3px;text-transform:uppercase;color:${GOLD};margin-bottom:16px">Onboarding Certification — Passed</div>
    <p style="font-size:15px;line-height:1.7;color:${NAVY};margin:0 0 14px 0">We're delighted to let you know that you have <strong>passed your onboarding certification</strong>. Thank you for the care and attention you brought to the orientation and the check — it truly shows.</p>
    ${resultCard(rows)}
    <p style="font-size:15px;line-height:1.7;color:${NAVY};margin:14px 0 0 0">This is an exciting step, and we're glad to have you with us. Your team will contact you with next steps.</p>
    <p style="font-size:14px;line-height:1.6;color:${NAVY};margin:24px 0 0 0">Warm regards,<br/><span style="color:${GOLD}">Angela Stein</span><br/>HR – Talent Manager<br/>Expert Intuitive Advisor Inc.</p>`;
  const text = `Congratulations, ${firstName}

We're delighted to let you know that you have passed your onboarding certification. Thank you for the care and attention you brought to the orientation and the check.

Result Report
${rows.map(([k, v]) => `- ${k}: ${v}`).join("\n")}

This is an exciting step, and we're glad to have you with us. Your team will contact you with next steps.

Warm regards,
Angela Stein
HR – Talent Manager
Expert Intuitive Advisor Inc.`;
  return { subject: "Onboarding Certification — Passed", html: shell(inner), text };
}

// deno-lint-ignore no-explicit-any
async function sendAutoApproveEmail(admin: any, tok: any, score: number, total: number, attemptNumber: number, passedAtIso: string) {
  try {
    const toAddr = (tok.candidate_email || "").trim();
    if (!toAddr || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(toAddr)) return;
    const firstName = ((tok.candidate_name || "").split(" ")[0] || "there").trim();
    const built = approvedEmail(firstName, [
      ["Score", `${score}/${total}`],
      ["Passed on attempt", String(attemptNumber)],
      ["Date completed", fmtDate(passedAtIso)],
    ]);

    let sendOk = false;
    let resendId: string | null = null;
    let errMsg: string | null = null;
    try {
      const sendRes = await fetch("https://api.resend.com/emails", {
        method: "POST",
        headers: { "Content-Type": "application/json", Authorization: `Bearer ${RESEND_API_KEY}` },
        body: JSON.stringify({ from: FROM, to: [toAddr], subject: built.subject, html: built.html, text: built.text }),
      });
      const sendJson = await sendRes.json().catch(() => ({}));
      sendOk = sendRes.ok;
      resendId = (sendJson as { id?: string })?.id || null;
      if (!sendRes.ok) errMsg = JSON.stringify(sendJson).slice(0, 500);
    } catch (e) {
      errMsg = String((e as Error)?.message || e);
    }

    await admin.from("email_log").insert({
      candidate_id: null,
      stage: "onboarding_quiz_approved",
      sender: "resend",
      from_address: FROM_ADDR,
      from_name: FROM_NAME,
      to_address: toAddr,
      subject: built.subject,
      status: sendOk ? "sent" : "failed",
      sent_at: sendOk ? new Date().toISOString() : null,
      resend_message_id: resendId,
      error_message: sendOk ? null : errMsg,
    }).catch(() => {});
  } catch (e) {
    // Never let email problems affect the result save.
    console.warn("[submit-onboarding-quiz-attempt] auto_approve_email_warn", String((e as Error)?.message || e));
  }
}



Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });
  try {
    const body = await req.json().catch(() => ({}));
    const token = typeof body?.token === "string" ? body.token.trim() : "";
    const name = typeof body?.name === "string" ? body.name : "";
    const email = typeof body?.email === "string" ? body.email : "";
    const answers = Array.isArray(body?.answers) ? body.answers : [];
    if (!token) return json({ error: "missing_token" }, 400);

    const admin = createClient(SUPABASE_URL, SERVICE);
    const { data: tok } = await admin
      .from("onboarding_quiz_tokens").select("*").eq("token", token).maybeSingle();

    if (!tok) return json({ error: "not_found", valid: false }, 404);
    const isTest = tok.token === TEST_TOKEN;
    if (!isTest) {
      if (tok.passed) return json({ valid: false, reason: "passed" });
      if (tok.status === "failed_out" || tok.status === "invalidated" || tok.invalidated_at) {
        return json({ valid: false, reason: "invalidated" });
      }
      if (new Date(tok.expires_at) < new Date()) return json({ valid: false, reason: "expired" });
    }

    // No identity gate: name/email are kept only as light record-keeping and
    // are saved alongside the attempt below. They never block or kill the link.

    if (!isTest && (tok.attempts_used || 0) >= MAX_ATTEMPTS) {
      return json({ valid: false, reason: "no_attempts_left" });
    }

    // Score server-side.
    const { data: qs } = await admin
      .from("onboarding_quiz_questions")
      .select("id, correct_index")
      .eq("active", true);
    const correctById = new Map<string, number>();
    (qs || []).forEach((q: any) => correctById.set(q.id, q.correct_index));
    const total = correctById.size;

    let score = 0;
    const recorded: Record<string, number> = {};
    for (const a of answers) {
      const qid = typeof a?.question_id === "string" ? a.question_id : "";
      const sel = Number.isInteger(a?.selected_index) ? a.selected_index : -1;
      if (!qid || !correctById.has(qid)) continue;
      recorded[qid] = sel;
      if (correctById.get(qid) === sel) score += 1;
    }

    const passed = score >= PASS_MARK;
    const attemptNumber = (tok.attempts_used || 0) + 1;
    const attemptsLeft = MAX_ATTEMPTS - attemptNumber;

    // Record the attempt.
    await admin.from("onboarding_quiz_attempts").insert({
      token_id: tok.id,
      attempt_number: attemptNumber,
      score,
      total,
      passed,
      answers: recorded,
      candidate_name: name || tok.candidate_name || null,
      candidate_email: email || tok.candidate_email || null,
    });

    const nowIso = new Date().toISOString();
    const update: Record<string, unknown> = { attempts_used: attemptNumber };

    let finished = false;
    if (isTest) {
      // Reusable preview link: never dies, attempt counter resets so it can be
      // re-taken endlessly. Real result fields are left untouched.
      update.attempts_used = 0;
      finished = false;
    } else if (passed) {
      finished = true;
      update.passed = true;
      update.passed_at = nowIso;
      update.invalidated_at = nowIso; // link dies on pass
      // Manual = HR approves first (default). Auto = treated as already approved.
      update.status = tok.after_pass_mode === "auto" ? "passed_approved" : "passed_pending";
    } else if (attemptNumber >= MAX_ATTEMPTS) {
      finished = true;
      update.status = "failed_out";
      update.invalidated_at = nowIso; // link dies on 3rd fail
    }

    await admin.from("onboarding_quiz_tokens").update(update).eq("id", tok.id);

    // ── ADDITIVE: auto-approve pass email (failure-safe, never blocks) ──
    // Only on a real (non-test) PASS where the token is set to auto-approve.
    if (!isTest && passed && tok.after_pass_mode === "auto") {
      await sendAutoApproveEmail(admin, tok, score, total, attemptNumber, nowIso);
    }



    return json({
      valid: true,
      identity_ok: true,
      passed,
      score,
      total,
      pass_mark: PASS_MARK,
      attempt_number: attemptNumber,
      attempts_left: attemptsLeft < 0 ? 0 : attemptsLeft,
      finished,
      after_pass_mode: tok.after_pass_mode,
    });
  } catch (e: any) {
    return json({ error: "internal", details: String(e?.message || e) }, 500);
  }
});
