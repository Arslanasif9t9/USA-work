// get-zoom-meeting: admin-only read/sync of a Zoom meeting.
import {
  adminClient,
  corsHeaders,
  jsonResponse,
  requireAdmin,
  zoomFetch,
} from "../_shared/zoom.ts";

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });
  const guard = await requireAdmin(req);
  if (guard instanceof Response) return guard;

  let body: { zoom_meeting_id?: string; db_record_id?: string };
  try {
    body = await req.json();
  } catch {
    return jsonResponse({ error: "invalid_json" }, 400);
  }

  const admin = adminClient();
  let zoomMeetingId = body.zoom_meeting_id?.toString();

  if (!zoomMeetingId && body.db_record_id) {
    const { data } = await admin
      .from("zoom_meetings")
      .select("zoom_meeting_id")
      .eq("id", body.db_record_id)
      .maybeSingle();
    zoomMeetingId = data?.zoom_meeting_id;
  }
  if (!zoomMeetingId) {
    return jsonResponse({ error: "missing_meeting_id" }, 400);
  }

  const res = await zoomFetch(`/meetings/${zoomMeetingId}`, { method: "GET" });
  const json = await res.json().catch(() => ({}));
  if (!res.ok) {
    return jsonResponse(
      { error: "zoom_api_error", status: res.status, details: json },
      res.status,
    );
  }

  await admin
    .from("zoom_meetings")
    .update({ last_synced_at: new Date().toISOString() })
    .eq("zoom_meeting_id", zoomMeetingId);

  return jsonResponse({ success: true, meeting: json });
});
