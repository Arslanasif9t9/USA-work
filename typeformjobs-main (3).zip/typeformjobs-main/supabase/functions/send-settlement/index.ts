// send-settlement: admin/HR-only orchestrator. Mirrors send-nda but for the
// Final Settlement Acknowledgment. Reuses signflow-create-document and the
// nda_signatures table (with doc_type='settlement').
import { createClient } from "npm:@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
const ANON = Deno.env.get("SUPABASE_ANON_KEY")!;
const SVC = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;

const json = (b: unknown, status = 200) =>
  new Response(JSON.stringify(b), {
    status,
    headers: { ...corsHeaders, "content-type": "application/json" },
  });

function shortId() {
  return crypto.randomUUID().replace(/-/g, "").slice(0, 8).toUpperCase();
}

function buildSenderA(firstName: string, signingUrl: string) {
  const text = `Hi ${firstName},

Please review and sign your final settlement acknowledgment using the secure link below.

REVIEW & SIGN:
${signingUrl}

If you have any questions, simply reply to this email.

Cathy Anderson
Hiring Director
Expert Intuitive Advisor Inc.`;
  const html = `<div style="font-family:Arial,sans-serif;font-size:14px;color:#1a2236;line-height:1.6;max-width:600px">
<p>Hi ${firstName},</p>
<p>Please review and sign your final settlement acknowledgment using the secure link below.</p>
<p><a href="${signingUrl}" style="display:inline-block;background:#1a2547;color:#ffffff;padding:12px 22px;border-radius:6px;text-decoration:none;font-weight:600">Review &amp; sign your final settlement</a></p>
<p style="font-size:12px;color:#666">Or paste this link into your browser:<br/><a href="${signingUrl}" style="color:#1a2547">${signingUrl}</a></p>
<p>If you have any questions, simply reply to this email.</p>
<p>Cathy Anderson<br/>Hiring Director<br/>Expert Intuitive Advisor Inc.</p>
</div>`;
  return {
    from_name: "Cathy Anderson / Hiring Director",
    from_address: "talent@expertintuitiveadvisor.com",
    subject: "Please sign your Final Settlement Acknowledgment — Expert Intuitive Advisor Inc.",
    html_body: html,
    text_body: text,
  };
}

function buildSenderB(firstName: string, signingUrl: string) {
  const text = `Hi ${firstName},

Quick note — your final settlement acknowledgment is ready for signing:

${signingUrl}

If anything's unclear, just reply.

— Cathy Anderson`;
  const html = `<div style="font-family:Arial,sans-serif;font-size:14px;color:#1a2236;line-height:1.6;max-width:600px">
<p>Hi ${firstName},</p>
<p>Quick note — your final settlement acknowledgment is ready for signing:</p>
<p><a href="${signingUrl}" style="color:#1a2547">${signingUrl}</a></p>
<p>If anything's unclear, just reply.</p>
<p>— Cathy Anderson</p>
</div>`;
  return {
    from_name: "Cathy Anderson",
    from_address: "expertintuitiveadvisor@gmail.com",
    subject: "Your EIA Final Settlement is ready to sign",
    html_body: html,
    text_body: text,
  };
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });
  if (req.method !== "POST") return json({ ok: false, reason: "method_not_allowed" }, 405);

  // Admin gate
  const auth = req.headers.get("Authorization") || "";
  if (!auth.startsWith("Bearer ")) return json({ ok: false, reason: "missing_auth" }, 401);
  const userClient = createClient(SUPABASE_URL, ANON, { global: { headers: { Authorization: auth } } });
  const { data: u } = await userClient.auth.getUser();
  if (!u?.user) return json({ ok: false, reason: "invalid_jwt" }, 401);
  const admin = createClient(SUPABASE_URL, SVC);
  const { data: urow } = await admin.from("users").select("role").eq("id", u.user.id).maybeSingle();
  if (!urow || urow.role !== "admin") return json({ ok: false, reason: "forbidden" }, 403);

  let body: { response_id?: string; override_email?: string; name?: string; email?: string; hr_copy_requested?: boolean; hr_copy_email_override?: string };
  try { body = await req.json(); } catch { return json({ ok: false, reason: "invalid_json" }, 400); }
  const { response_id, override_email, name: directName, email: directEmail } = body || {};
  const hrCopyRequested = !!(body as any)?.hr_copy_requested;
  const hrCopyEmailOverrideRaw = typeof (body as any)?.hr_copy_email_override === "string" ? (body as any).hr_copy_email_override.trim() : "";
  const hrCopyEmailOverride = hrCopyEmailOverrideRaw && /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(hrCopyEmailOverrideRaw) ? hrCopyEmailOverrideRaw : null;

  let signerEmail = "";
  let signerName = "";
  let resolvedResponseId: string | null = null;

  if (response_id) {
    const { data: resp, error: respErr } = await admin
      .from("responses")
      .select("id, applicant_id, form_id, override_email")
      .eq("id", response_id)
      .maybeSingle();
    if (respErr) return json({ ok: false, reason: "response_lookup_failed", detail: respErr.message }, 500);
    if (!resp) return json({ ok: false, reason: "response_not_found" }, 404);
    resolvedResponseId = response_id;

    if (override_email && typeof override_email === "string" && /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(override_email.trim())) {
      const ov = override_email.trim();
      if (ov !== (resp as any).override_email) {
        await admin.from("responses").update({ override_email: ov }).eq("id", response_id);
        (resp as any).override_email = ov;
      }
    }

    signerEmail = ((resp as any).override_email || "").trim();
    if ((resp as any).applicant_id) {
      const { data: off } = await admin
        .from("job_offers")
        .select("candidate_name, candidate_email")
        .eq("candidate_id", (resp as any).applicant_id)
        .order("created_at", { ascending: false })
        .limit(1)
        .maybeSingle();
      if (off?.candidate_name) signerName = off.candidate_name;
      if (!signerEmail && off?.candidate_email) signerEmail = off.candidate_email.trim();
    }
    if (!signerName) {
      const { data: ob } = await admin
        .from("onboarding_submissions").select("full_name, email")
        .eq("response_id", response_id).maybeSingle();
      if (ob?.full_name) signerName = ob.full_name;
      if (!signerEmail && ob?.email) signerEmail = String(ob.email).trim();
    }
  } else if (directName && directEmail) {
    signerName = String(directName).trim();
    signerEmail = String(directEmail).trim();
  } else {
    return json({ ok: false, reason: "missing_input" }, 400);
  }

  if (!signerEmail || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(signerEmail)) {
    return json({ ok: false, reason: "no_email" }, 400);
  }
  if (!signerName) return json({ ok: false, reason: "no_name" }, 400);

  const reference = `STL-${shortId()}`;

  // Generate PDF
  const pdfResp = await fetch(`${SUPABASE_URL}/functions/v1/generate-settlement-pdf`, {
    method: "POST",
    headers: { Authorization: auth, "Content-Type": "application/json" },
    body: JSON.stringify({ response_id: resolvedResponseId, signer_name: signerName, signer_email: signerEmail, reference }),
  });
  const pdfJson = await pdfResp.json().catch(() => ({}));
  const pdfUrl: string | undefined = (pdfJson as any)?.pdf_url;
  const pageCount: number | undefined = (pdfJson as any)?.page_count;
  if (!pdfResp.ok || !pdfUrl) {
    return json({ ok: false, reason: "pdf_failed", detail: pdfJson }, 500);
  }

  // SignFlow document. Use the REAL signature-block rectangle from the PDF
  // builder, converted from PDF bottom-origin (fieldTop) to the top-origin space
  // the signer page renders in (y_top = PAGE_H - fieldTop, PAGE_H = 792).
  const PAGE_H = 792;
  const sigRect = (pdfJson as any)?.signature_rect as
    | { page?: number; x?: number; fieldTop?: number; width?: number; height?: number }
    | null | undefined;
  const sigPage = Math.max(1, Number(sigRect?.page ?? pageCount ?? 1));
  const sigFieldPosition = sigRect && typeof sigRect.fieldTop === "number"
    ? { page: sigPage, x: Number(sigRect.x ?? 61), y: PAGE_H - Number(sigRect.fieldTop), width: Number(sigRect.width ?? 240), height: Number(sigRect.height ?? 60) }
    : { page: sigPage, x: 100, y: 350, width: 200, height: 60 };
  const sfResp = await fetch(`${SUPABASE_URL}/functions/v1/signflow-create-document`, {
    method: "POST",
    headers: { Authorization: auth, "Content-Type": "application/json" },
    body: JSON.stringify({
      external_offer_reference: reference,
      signer_name: signerName,
      signer_email: signerEmail,
      document_title: `Final Settlement - ${signerName}`,
      pdf_url: pdfUrl,
      signature_field_position: sigFieldPosition,
    }),
  });
  const sfJson = await sfResp.json().catch(() => ({}));
  const signingUrl: string | undefined = (sfJson as any)?.signing_url;
  const signingToken: string | undefined = (sfJson as any)?.signing_token;
  if (!sfResp.ok || !signingUrl || !/^https:\/\/\S+$/i.test(signingUrl)) {
    return json({ ok: false, reason: "signflow_failed", detail: sfJson }, 502);
  }

  // Persist nda_signatures row (doc_type='settlement'), read-after-write
  const { error: insErr } = await admin.from("nda_signatures").insert({
    response_id: resolvedResponseId,
    external_reference: reference,
    signer_name: signerName,
    signer_email: signerEmail,
    signing_token: signingToken || null,
    signing_url: signingUrl,
    status: "sent",
    doc_type: "settlement",
    hr_copy_requested: hrCopyRequested,
    hr_copy_email_override: hrCopyEmailOverride,
  });
  if (insErr) return json({ ok: false, reason: "persist_failed", detail: insErr.message }, 500);
  const { data: verifyRow } = await admin
    .from("nda_signatures").select("id").eq("external_reference", reference).maybeSingle();
  if (!verifyRow) return json({ ok: false, reason: "persist_failed", detail: "row not found after insert" }, 500);

  // Email
  const firstName = signerName.trim().split(/\s+/)[0] || signerName;
  const emailResp = await fetch(`${SUPABASE_URL}/functions/v1/send-dual-email`, {
    method: "POST",
    headers: { Authorization: `Bearer ${SVC}`, "Content-Type": "application/json" },
    body: JSON.stringify({
      to: signerEmail,
      stage: "settlement_sent",
      sender_a: buildSenderA(firstName, signingUrl),
      sender_b: buildSenderB(firstName, signingUrl),
    }),
  });
  const emailJson = await emailResp.json().catch(() => ({}));
  if (!emailResp.ok) {
    return json({
      ok: false, reason: "email_failed", detail: emailJson,
      signing_url: signingUrl, external_reference: reference,
    }, 502);
  }

  return json({ ok: true, signing_url: signingUrl, external_reference: reference, recipient: signerEmail });
});
