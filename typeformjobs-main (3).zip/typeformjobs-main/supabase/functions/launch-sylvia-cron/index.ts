// launch-sylvia-cron: invoked every 5 minutes by pg_cron. Picks up due
// scheduled launches and fires them via the shared ElevenLabs send helper.
// Idempotent: each row is claimed via UPDATE ... WHERE status='pending' so
// two overlapping runs cannot double-send.
import { createClient } from "npm:@supabase/supabase-js@2";
import { sendSylviaWhatsApp } from "../_shared/elevenlabs-sylvia.ts";

const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
const SERVICE_KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;

const cors = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: cors });

  const admin = createClient(SUPABASE_URL, SERVICE_KEY);
  const nowIso = new Date().toISOString();
  // Immediate (mode='now') launches whose browser invoke failed get orphaned at
  // 'pending'. Recover any that have been pending for >2 minutes so a failed
  // immediate send is not stuck forever.
  const staleIso = new Date(Date.now() - 2 * 60 * 1000).toISOString();

  const { data: due, error } = await admin
    .from("launches")
    .select("id")
    .eq("status", "pending")
    .or(`and(mode.eq.scheduled,scheduled_for.lte.${nowIso}),and(mode.eq.now,created_at.lte.${staleIso})`)
    .order("created_at", { ascending: true })
    .limit(50);

  if (error) {
    return new Response(JSON.stringify({ ok: false, error: error.message }), {
      status: 200, headers: { ...cors, "Content-Type": "application/json" },
    });
  }

  const results: any[] = [];
  for (const row of (due || [])) {
    const { data: claimed } = await admin
      .from("launches")
      .update({ status: "sending" as any })
      .eq("id", row.id)
      .eq("status", "pending")
      .select("id, candidate_name, whatsapp_number")
      .maybeSingle();
    if (!claimed) { results.push({ id: row.id, skipped: true }); continue; }

    const send = await sendSylviaWhatsApp({
      candidate_name: claimed.candidate_name || "",
      whatsapp_number: claimed.whatsapp_number,
    });
    if (send.ok) {
      await admin.from("launches").update({
        status: "sent", sent_at: new Date().toISOString(), error_message: null,
      }).eq("id", row.id);
      results.push({ id: row.id, ok: true });
    } else {
      const errMsg = send.error || (send.body ? JSON.stringify(send.body) : `http_${send.status}`);
      await admin.from("launches").update({
        status: "failed", error_message: errMsg.slice(0, 2000),
      }).eq("id", row.id);
      results.push({ id: row.id, ok: false, error: errMsg });
    }
  }

  return new Response(JSON.stringify({ ok: true, processed: results.length, results }), {
    status: 200, headers: { ...cors, "Content-Type": "application/json" },
  });
});
