// get-available-slots: PUBLIC. Returns slots grouped by Manila date.
// Optional { token } → if token has curated_slot_ids, returns ONLY those slots
// (still filtering to status='available' / expired-reservation) grouped by date,
// with no window/fallback logic. Otherwise uses default 3→14d fallback window.
import { createClient } from "npm:@supabase/supabase-js@2";
import { manilaParts, formatManilaTime } from "../_shared/manila.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, GET, OPTIONS",
};

const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
const SERVICE_KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;

function candidateWindowDates(now: Date, workingDays: number[], dayCount: number): Set<string> {
  const allowedDates = new Set<string>();
  let counted = 0;
  for (let i = 0; counted < dayCount && i < 21; i++) {
    const todayParts = manilaParts(now);
    const base = new Date(Date.UTC(todayParts.year, todayParts.month - 1, todayParts.day) + i * 86400000);
    const pad = (n: number) => String(n).padStart(2, "0");
    const dateStr = `${base.getUTCFullYear()}-${pad(base.getUTCMonth() + 1)}-${pad(base.getUTCDate())}`;
    const noon = new Date(base.getTime() + 12 * 3600 * 1000);
    const wd = manilaParts(noon).weekday;
    if (workingDays.includes(wd)) {
      allowedDates.add(dateStr);
      counted++;
    }
  }
  return allowedDates;
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });
  const admin = createClient(SUPABASE_URL, SERVICE_KEY);

  const body = await req.json().catch(() => ({}));
  const token = typeof body?.token === "string" ? body.token : null;

  const { data: cfg } = await admin.from("scheduling_config").select("*").eq("id", 1).maybeSingle();
  if (!cfg) {
    return new Response(JSON.stringify({ error: "no_config" }), {
      status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }

  const now = new Date();

  // OOO check
  if (cfg.is_out_of_office && cfg.out_of_office_start && cfg.out_of_office_end) {
    const today = manilaParts(now).dateStr;
    if (today >= cfg.out_of_office_start && today <= cfg.out_of_office_end) {
      return new Response(JSON.stringify({
        ooo_active: true,
        ooo_end: cfg.out_of_office_end,
        timezone: cfg.timezone,
        slots_by_date: {},
      }), { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }
  }

  // Curated path: token with curated_slot_ids overrides window logic
  let curatedIds: string[] | null = null;
  if (token) {
    const { data: tok } = await admin
      .from("rebook_tokens")
      .select("curated_slot_ids, used_at, expires_at")
      .eq("token", token)
      .maybeSingle();
    if (tok && !tok.used_at && new Date(tok.expires_at) > now
        && Array.isArray(tok.curated_slot_ids) && tok.curated_slot_ids.length > 0) {
      curatedIds = tok.curated_slot_ids as string[];
    }
  }

  if (curatedIds) {
    const minAdvanceHours = cfg.min_advance_hours || 1;
    const cutoff = new Date(now.getTime() + minAdvanceHours * 3600 * 1000);
    const { data: slots, error } = await admin
      .from("interview_slots")
      .select("id, slot_start, slot_date, status, reserved_until")
      .in("id", curatedIds)
      .in("status", ["available", "reserved"])
      .gte("slot_start", cutoff.toISOString())
      .order("slot_start", { ascending: true });
    if (error) {
      return new Response(JSON.stringify({ error: error.message }), {
        status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }
    const byDate: Record<string, Array<{ id: string; slot_start: string; display_time: string; available: boolean }>> = {};
    for (const s of slots || []) {
      if (s.status === "reserved" && s.reserved_until && new Date(s.reserved_until) > now) continue;
      const d = s.slot_date;
      if (!byDate[d]) byDate[d] = [];
      byDate[d].push({
        id: s.id, slot_start: s.slot_start,
        display_time: formatManilaTime(new Date(s.slot_start)), available: true,
      });
    }
    return new Response(JSON.stringify({
      ooo_active: false,
      timezone: cfg.timezone,
      curated: true,
      extended_window: false,
      visible_days: Object.keys(byDate).length,
      slots_by_date: byDate,
    }), { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } });
  }

  // Default (non-curated) path
  const minAdvanceHours = cfg.min_advance_hours || 1;
  const lockDays = cfg.lock_days_ahead || 3;
  const maxWindowDays = Math.max(lockDays, 14);
  const cutoff = new Date(now.getTime() + minAdvanceHours * 3600 * 1000);
  const windowEnd = new Date(now.getTime() + (maxWindowDays + 8) * 86400 * 1000);

  const { data: slots, error } = await admin
    .from("interview_slots")
    .select("id, slot_start, slot_end, slot_date, slot_time, status, reserved_until")
    .gte("slot_start", cutoff.toISOString())
    .lt("slot_start", windowEnd.toISOString())
    .in("status", ["available", "reserved"])
    .order("slot_start", { ascending: true });

  if (error) {
    return new Response(JSON.stringify({ error: error.message }), {
      status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }

  const workingDays: number[] = cfg.working_days || [1, 2, 3, 4, 5, 6];
  let visibleDays = lockDays;
  for (let days = lockDays; days <= maxWindowDays; days++) {
    const testDates = candidateWindowDates(now, workingDays, days);
    const availableCount = (slots || []).filter((s) => {
      if (!testDates.has(s.slot_date)) return false;
      if (s.status === "reserved" && s.reserved_until && new Date(s.reserved_until) > now) return false;
      return true;
    }).length;
    visibleDays = days;
    if (availableCount > 0) break;
  }

  const allowedDates = candidateWindowDates(now, workingDays, visibleDays);
  const slotsByDate: Record<string, Array<{ id: string; slot_start: string; display_time: string; available: boolean }>> = {};
  for (const d of allowedDates) slotsByDate[d] = [];
  for (const s of slots || []) {
    if (!allowedDates.has(s.slot_date)) continue;
    if (s.status === "reserved" && s.reserved_until && new Date(s.reserved_until) > now) continue;
    const date = s.slot_date;
    if (!slotsByDate[date]) slotsByDate[date] = [];
    slotsByDate[date].push({
      id: s.id, slot_start: s.slot_start,
      display_time: formatManilaTime(new Date(s.slot_start)), available: true,
    });
  }

  return new Response(JSON.stringify({
    ooo_active: false,
    timezone: cfg.timezone,
    config: {
      lock_days_ahead: visibleDays,
      min_advance_hours: minAdvanceHours,
      slot_duration_minutes: cfg.slot_duration_minutes,
    },
    extended_window: visibleDays > lockDays,
    visible_days: visibleDays,
    slots_by_date: slotsByDate,
  }), { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } });
});
