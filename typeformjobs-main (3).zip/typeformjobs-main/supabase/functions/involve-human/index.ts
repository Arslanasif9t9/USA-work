// involve-human: HR-authenticated manual signal. Flags a candidate as needing a
// human touch (HR will reach out manually, e.g. Zoom) WITHOUT changing the
// candidate's pipeline. It:
//   1. Sets responses.needs_human = true + needs_human_at = now() (single-row by id).
//   2. Inserts a notification_log row (event_type='involve_human').
//   3. Emails the fixed HR inbox via Resend (pattern from send-new-booking-notification).
//
// CRITICAL: this is purely an HR signal. It NEVER changes round_stage, NEVER
// invalidates/burns rebook_tokens, NEVER touches answers, and NEVER cascades.
// The candidate's existing interview link stays fully active.
import { adminClient, corsHeaders, json, requireHr } from "../_shared/hr-auth.ts";

const RESEND_API_KEY = Deno.env.get("RESEND_API_KEY")!;

// Fixed HR inbox fallback (same address send-new-booking-notification targets).
const FALLBACK_HR_INBOX = "talent.expertadvisor@outlook.com";

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });

  const ident = await requireHr(req);
  if (ident instanceof Response) return ident;

  const body = await req.json().catch(() => ({}));
  const responseId: string | undefined = body?.response_id;
  if (!responseId) return json({ error: "missing_response_id" }, 400);

  const admin = adminClient();

  // Load response (read-only gate; we do NOT touch round_stage / tokens).
  const { data: resp } = await admin
    .from("responses")
    .select("id, form_id, applicant_id, override_name, round_stage")
    .eq("id", responseId)
    .maybeSingle();
  if (!resp) return json({ error: "response_not_found" }, 404);

  // 1) Flip the flag — single-row write by id. Nothing else changes.
  const { error: flagErr } = await admin
    .from("responses")
    .update({ needs_human: true, needs_human_at: new Date().toISOString() })
    .eq("id", responseId);
  if (flagErr) {
    console.error("[involve-human] flag update failed", flagErr);
    return json({ error: "flag_failed", details: flagErr.message }, 500);
  }

  // Resolve candidate name + position for the notification body.
  let positionTitle = "the role";
  const { data: meta } = await admin.from("form_metadata")
    .select("position_title").eq("form_id", resp.form_id).maybeSingle();
  if (meta?.position_title) positionTitle = meta.position_title;

  const { data: qs } = await admin.from("questions")
    .select("id, type, label").eq("form_id", resp.form_id);
  const { data: ans } = await admin.from("answers")
    .select("question_id, answer_text").eq("response_id", responseId);
  const nameQ = qs?.find((q: any) => q.type === "short_text" && /name/i.test(q.label || ""))
    || qs?.find((q: any) => q.type === "short_text");
  const answerFor = (qid?: string) =>
    qid ? (ans?.find((a: any) => a.question_id === qid)?.answer_text || "").trim() : "";
  const candidateName = (resp.override_name || "").trim() || answerFor(nameQ?.id) || "Candidate";

  const interviewerName = resp.round_stage === "round_2_sent" ? "Marissa" : "Christine";

  // Resolve the HR inbox live (with the fixed fallback) — same pattern as bookings.
  let hrInbox = FALLBACK_HR_INBOX;
  try {
    const { data: settings } = await admin
      .from("app_settings").select("main_backup_email").eq("id", 1).maybeSingle();
    const v = (settings as any)?.main_backup_email?.trim();
    if (v) hrInbox = v;
  } catch (_) { /* keep fallback */ }

  const flaggedBy = ident.displayName || ident.email || "an HR teammate";
  const subject = `Involve Human — ${candidateName} (${positionTitle})`;
  const text = `${flaggedBy} flagged a candidate as needing a human touch.

CANDIDATE: ${candidateName}
POSITION: ${positionTitle}

ACTION NEEDED:
Please reach out to this candidate manually (e.g. a Zoom call) to help them along.

IMPORTANT: This is a manual assist only. The candidate STILL needs to complete
their AI interview with ${interviewerName} — their existing interview link is
still active and has NOT been changed or invalidated.

— EIA Talent Recruiting System`;
  const html = text.replace(/\n/g, "<br/>");

  // 3) DISABLED: the involve-human alert email to the HR inbox is intentionally
  // turned off (button removed/unused). The flag flip above + notification_log
  // record below are kept. No email is sent.
  const emailOk = false;
  const errorMessage: string | null = "disabled";
  void subject; void html; void text;

  // 2) Log the notification (single row).
  await admin.from("notification_log").insert({
    event_type: "involve_human",
    recipient_email: hrInbox,
    related_resource_id: responseId,
    status: "skipped",
  });

  return json({ success: true, email_sent: emailOk, recipient: hrInbox, candidate_name: candidateName, email_error: errorMessage });
});
