import { adminClient, corsHeaders, json, requireHr } from "../_shared/hr-auth.ts";

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });
  const ident = await requireHr(req);
  if (ident instanceof Response) return ident;
  if (!ident.hrId) return json({ error: "no_hr_profile" }, 403);

  const { slot_id } = await req.json().catch(() => ({}));
  if (!slot_id) return json({ error: "missing slot_id" }, 400);

  const admin = adminClient();
  const { data, error } = await admin
    .from("interview_slots")
    .update({ claimed_by_hr_id: ident.hrId, claimed_at: new Date().toISOString() })
    .eq("id", slot_id)
    .is("claimed_by_hr_id", null)
    .select("id");
  if (error) return json({ error: error.message }, 500);
  if (!data || data.length === 0) return json({ error: "already_claimed" }, 409);
  return json({ success: true });
});
