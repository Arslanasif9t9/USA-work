// validate-circular-token: PUBLIC (verify_jwt=false). Returns circular notice info
// for a recipient's unguessable access_token so the /circular/:token page can render
// the notice + understanding box. NEVER leaks data for an invalid/used token.
import { createClient } from "npm:@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};
const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
const SERVICE = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
const json = (b: unknown, s = 200) =>
  new Response(JSON.stringify(b), { status: s, headers: { ...corsHeaders, "Content-Type": "application/json" } });

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });
  try {
    const { token } = await req.json().catch(() => ({}));
    if (!token || typeof token !== "string") return json({ valid: false, reason: "missing_token" }, 400);

    const admin = createClient(SUPABASE_URL, SERVICE);
    const { data: row } = await admin
      .from("circular_signatures")
      .select("id, circular_id, signer_name, signing_url, status, signed_at")
      .eq("access_token", token)
      .maybeSingle();

    if (!row) return json({ valid: false, reason: "not_found" });
    if (row.status === "signed" || row.signed_at) return json({ valid: false, reason: "completed" });
    if (!row.signing_url) return json({ valid: false, reason: "no_signing_url" });

    const { data: circ } = await admin
      .from("circulars")
      .select("title, body, explanation")
      .eq("id", row.circular_id)
      .maybeSingle();

    if (!circ) return json({ valid: false, reason: "not_found" });

    return json({
      valid: true,
      title: circ.title || "Circular Notice",
      body: circ.body || "",
      explanation: circ.explanation || "",
      signer_name: row.signer_name || "",
      signing_url: row.signing_url,
    });
  } catch (e: any) {
    return json({ valid: false, reason: "internal", details: String(e?.message || e) }, 500);
  }
});
