// release-slot: Frees a booked/cancelled slot back to 'available' so other
// candidates can take it. Cancels the associated Zoom meeting (best-effort)
// and clears responses.scheduled_slot_id for the booked candidate.
//
// Auth: HR session OR service-role bearer (so cron + internal callers like
// disqualify can invoke it without an HR user).
//
// Single-row writes by exact id. Never touches the answers table.
import { adminClient, corsHeaders, json, requireHr } from "../_shared/hr-auth.ts";

const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
const SERVICE_KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;

async function authorize(req: Request): Promise<true | Response> {
  const auth = req.headers.get("Authorization") || "";
  const token = auth.replace(/^Bearer\s+/i, "").trim();
  if (token && token === SERVICE_KEY) return true;
  const ident = await requireHr(req);
  if (ident instanceof Response) return ident;
  if (!ident.hrId) return json({ error: "no_hr_profile" }, 403);
  return true;
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });

  const ok = await authorize(req);
  if (ok !== true) return ok;

  const body = await req.json().catch(() => ({} as any));
  const slotId: string | undefined = body?.slot_id;
  const responseId: string | undefined = body?.response_id;
  const reason: string = typeof body?.reason === "string" ? body.reason : "manual_release";
  // Opt-in: when true, ONLY free the interview_slots row back to available and
  // skip ALL response/candidate_actions/token mutations. Used by the "Send Round 1
  // (AI)" booked-row flow, where send-round-invite has ALREADY reset the response
  // and minted a fresh token — running the default response/token wipe here would
  // cancel the row and invalidate that brand-new token. Defaults false → byte-for-byte
  // unchanged for every existing caller.
  const slotOnly: boolean = body?.slot_only === true;
  if (!slotId && !responseId) return json({ error: "missing_slot_or_response_id" }, 400);

  const admin = adminClient();

  const slotIdToRelease = slotId || null;

  // Load slot when present (single row by id). A response-only cancel is also valid
  // for pending candidates with no appointment yet.
  const { data: slot, error: loadErr } = slotIdToRelease ? await admin
    .from("interview_slots")
    .select("id, status, response_id, zoom_meeting_id, completed_at, slot_start")
    .eq("id", slotId)
    .maybeSingle() : { data: null, error: null } as any;
  if (loadErr) return json({ error: "load_failed", details: loadErr.message }, 500);
  if (slotIdToRelease && !slot) return json({ error: "slot_not_found" }, 404);

  // HR has full control: any slot can be deleted/released, including
  // ones already marked attended/no-show/completed. Frees the slot and
  // un-books the candidate (they stay in My Bookings to rebook).

  // Cancel Zoom meeting (best-effort, fire-and-forget).
  // interview_slots.zoom_meeting_id stores the zoom_meetings.id UUID.
  if (slot?.zoom_meeting_id) {
    fetch(`${SUPABASE_URL}/functions/v1/delete-zoom-meeting`, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${SERVICE_KEY}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ db_record_id: slot.zoom_meeting_id }),
    }).catch(() => {});
  }

  // Detach the candidate from the slot (single-row update by id).
  // Some legacy/past rows still have responses.scheduled_slot_id pointing at a
  // slot whose interview_slots.response_id is already null, so fall back to the
  // response id supplied by the UI, then to a reverse lookup by scheduled_slot_id.
  let targetResponseId = slot?.response_id || responseId || null;
  if (!targetResponseId && slot?.id) {
    const { data: linkedResp } = await admin
      .from("responses")
      .select("id")
      .eq("scheduled_slot_id", slot.id)
      .maybeSingle();
    targetResponseId = linkedResp?.id || null;
  }
  // Mark appointment_cancelled = true so HR can see/filter cancelled candidates
  // who need re-booking. Cleared on next successful booking (book-slot).
  //
  // AI-flow isolation: releasing a (manual Zoom) slot must NEVER erase where the
  // candidate is in the AI flow. We clear ONLY the slot fields and flag the row
  // cancelled. round_stage, round1/round2 attendance, attendance_marked_at and
  // offer_sent_at are deliberately left intact.
  if (targetResponseId && !slotOnly) {
    await admin
      .from("responses")
      .update({
        scheduled_slot_id: null,
        scheduled_at: null,
        appointment_cancelled: true,
      })
      .eq("id", targetResponseId);

    // Invalidate ALL active AI interview tokens for this candidate (stage-agnostic).
    // Catches round1, ai_scheduled, reschedule, round2, round2_ai in one shot.
    const nowIso = new Date().toISOString();
    const expiredIso = new Date(Date.now() - 1000).toISOString();
    await admin
      .from("rebook_tokens")
      .update({ expires_at: expiredIso, used_at: nowIso })
      .eq("response_id", targetResponseId)
      .is("used_at", null)
      .gt("expires_at", nowIso);
  }

  // Reset slot itself to available.
  if (slot) {
    const { error: updErr } = await admin
      .from("interview_slots")
      .update({
        status: "available",
        response_id: null,
        claimed_by_hr_id: null,
        zoom_meeting_id: null,
        reserved_until: null,
        notes: reason,
      })
      .eq("id", slot.id);
    if (updErr) return json({ error: "update_failed", details: updErr.message }, 500);
  }

  return json({ success: true, slot_id: slot?.id || null, response_id: targetResponseId, reason });
});
