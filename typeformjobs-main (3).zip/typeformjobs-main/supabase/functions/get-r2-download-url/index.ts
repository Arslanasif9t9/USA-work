// get-r2-download-url: HR-authenticated. Returns a presigned GET URL for a
// private R2 object (interview video). Mirrors get-r2-upload-url's SigV4 path
// signer (PUT → GET). Additive only; does not touch upload pipeline.
import { corsHeaders, json, requireHr } from "../_shared/hr-auth.ts";

const R2_ACCESS_KEY_ID = Deno.env.get("R2_ACCESS_KEY_ID")!;
const R2_SECRET_ACCESS_KEY = Deno.env.get("R2_SECRET_ACCESS_KEY")!;
const R2_ENDPOINT = Deno.env.get("R2_ENDPOINT")!;
const R2_BUCKET = Deno.env.get("R2_BUCKET")!;

async function sha256Hex(data: string): Promise<string> {
  const buf = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(data));
  return [...new Uint8Array(buf)].map((b) => b.toString(16).padStart(2, "0")).join("");
}
async function hmac(key: ArrayBuffer | Uint8Array, data: string): Promise<ArrayBuffer> {
  const ck = await crypto.subtle.importKey("raw", key as BufferSource, { name: "HMAC", hash: "SHA-256" }, false, ["sign"]);
  return crypto.subtle.sign("HMAC", ck, new TextEncoder().encode(data));
}

async function presignGet(objectKey: string, expiresSec = 3600): Promise<string> {
  const url = new URL(R2_ENDPOINT);
  const host = url.host;
  const region = "auto";
  const service = "s3";
  const now = new Date();
  const amzDate = now.toISOString().replace(/[:-]|\.\d{3}/g, "");
  const dateStamp = amzDate.slice(0, 8);
  const credentialScope = `${dateStamp}/${region}/${service}/aws4_request`;
  const credential = `${R2_ACCESS_KEY_ID}/${credentialScope}`;
  const signedHeaders = "host";
  const encodedKey = objectKey.split("/").map(encodeURIComponent).join("/");
  const canonicalUri = `/${encodeURIComponent(R2_BUCKET)}/${encodedKey}`;

  const qsParams: Record<string, string> = {
    "X-Amz-Algorithm": "AWS4-HMAC-SHA256",
    "X-Amz-Credential": credential,
    "X-Amz-Date": amzDate,
    "X-Amz-Expires": String(expiresSec),
    "X-Amz-SignedHeaders": signedHeaders,
  };
  const canonicalQueryString = Object.keys(qsParams).sort()
    .map((k) => `${encodeURIComponent(k)}=${encodeURIComponent(qsParams[k])}`).join("&");

  const canonicalHeaders = `host:${host}\n`;
  const canonicalRequest = `GET\n${canonicalUri}\n${canonicalQueryString}\n${canonicalHeaders}\n${signedHeaders}\nUNSIGNED-PAYLOAD`;
  const stringToSign = `AWS4-HMAC-SHA256\n${amzDate}\n${credentialScope}\n${await sha256Hex(canonicalRequest)}`;

  const kDate = await hmac(new TextEncoder().encode("AWS4" + R2_SECRET_ACCESS_KEY), dateStamp);
  const kRegion = await hmac(kDate, region);
  const kService = await hmac(kRegion, service);
  const kSigning = await hmac(kService, "aws4_request");
  const sigBuf = await hmac(kSigning, stringToSign);
  const signature = [...new Uint8Array(sigBuf)].map((b) => b.toString(16).padStart(2, "0")).join("");

  return `${url.protocol}//${host}${canonicalUri}?${canonicalQueryString}&X-Amz-Signature=${signature}`;
}

function extractKey(input: string): string | null {
  if (!input) return null;
  let s = input.trim();
  if (!s) return null;
  // Full URL form → strip scheme/host, then bucket prefix.
  if (s.startsWith("http://") || s.startsWith("https://")) {
    try {
      const u = new URL(s);
      s = u.pathname.replace(/^\/+/, "");
    } catch { return null; }
  } else {
    s = s.replace(/^\/+/, "");
  }
  const bucketPrefix = `${R2_BUCKET}/`;
  if (s.startsWith(bucketPrefix)) s = s.slice(bucketPrefix.length);
  return s || null;
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });
  const ident = await requireHr(req);
  if (ident instanceof Response) return ident;

  try {
    const body = await req.json().catch(() => ({}));
    const raw: string = (typeof body?.key === "string" && body.key)
      || (typeof body?.video_url === "string" && body.video_url)
      || "";
    const key = extractKey(raw);
    if (!key) return json({ error: "missing_key_or_video_url" }, 400);

    const url = await presignGet(key, 3600);
    return json({ url, key });
  } catch (e: any) {
    console.error("[get-r2-download-url] exception:", e);
    return json({ error: String(e?.message || e) }, 500);
  }
});
