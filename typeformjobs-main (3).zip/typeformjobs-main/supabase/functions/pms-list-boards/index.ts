import { createClient } from "npm:@supabase/supabase-js@2";
import { corsHeaders, json, requireHr } from "../_shared/hr-auth.ts";

const PMS_URL = Deno.env.get("PMS_SUPABASE_URL")!;
const PMS_KEY = Deno.env.get("PMS_SERVICE_ROLE_KEY")!;

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });
  try {
    const ident = await requireHr(req);
    if (ident instanceof Response) return ident;

    const pms = createClient(PMS_URL, PMS_KEY);
    const { data, error } = await pms
      .from("boards")
      .select("id, name, workspace_id, icon_emoji")
      .is("deleted_at", null)
      .is("archived_at", null)
      .order("name", { ascending: true });
    if (error) return json({ error: error.message }, 500);
    return json({ boards: data ?? [] });
  } catch (e: any) {
    return json({ error: String(e?.message || e) }, 500);
  }
});
