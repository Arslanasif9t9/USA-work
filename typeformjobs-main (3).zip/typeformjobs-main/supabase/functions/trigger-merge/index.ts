// trigger-merge: PUBLIC (verify_jwt=false). Invoked server-side by the
// fire_interview_merge DB trigger when an ai_interview_sessions row has both
// recording_url (audio) and video_url (video) but no merged_video_url yet.
//
// Flow: presign the private R2 video → call the Render merge service with the
// presigned video URL + the public Retell audio URL → on success, write the
// merged R2 object URL onto ai_interview_sessions.merged_video_url. Single-row
// UPDATE by id. Never touches other columns or other tables.
//
// Storage rule: we store ONLY the link, never a file.

import { createClient } from "npm:@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
const SERVICE = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;

// R2 credentials — same envs used by get-r2-download-url / get-r2-upload-url.
const R2_ACCESS_KEY_ID = Deno.env.get("R2_ACCESS_KEY_ID")!;
const R2_SECRET_ACCESS_KEY = Deno.env.get("R2_SECRET_ACCESS_KEY")!;
const R2_ENDPOINT = Deno.env.get("R2_ENDPOINT")!;
const R2_BUCKET = Deno.env.get("R2_BUCKET")!;

// Render merge service — both read from secrets, never hardcoded.
const MERGE_SERVICE_URL = Deno.env.get("MERGE_SERVICE_URL")!;
const MERGE_SECRET = Deno.env.get("MERGE_SECRET")!;

const json = (b: unknown, s = 200) =>
  new Response(JSON.stringify(b), {
    status: s,
    headers: { ...corsHeaders, "Content-Type": "application/json" },
  });

// ---------- R2 SigV4 presigner (mirrors get-r2-download-url) ----------
async function sha256Hex(data: string): Promise<string> {
  const buf = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(data));
  return [...new Uint8Array(buf)].map((b) => b.toString(16).padStart(2, "0")).join("");
}
async function hmac(key: ArrayBuffer | Uint8Array, data: string): Promise<ArrayBuffer> {
  const ck = await crypto.subtle.importKey(
    "raw",
    key as BufferSource,
    { name: "HMAC", hash: "SHA-256" },
    false,
    ["sign"],
  );
  return crypto.subtle.sign("HMAC", ck, new TextEncoder().encode(data));
}

async function presignGet(objectKey: string, expiresSec = 3600): Promise<string> {
  const url = new URL(R2_ENDPOINT);
  const host = url.host;
  const region = "auto";
  const service = "s3";
  const now = new Date();
  const amzDate = now.toISOString().replace(/[:-]|\.\d{3}/g, "");
  const dateStamp = amzDate.slice(0, 8);
  const credentialScope = `${dateStamp}/${region}/${service}/aws4_request`;
  const credential = `${R2_ACCESS_KEY_ID}/${credentialScope}`;
  const signedHeaders = "host";
  const encodedKey = objectKey.split("/").map(encodeURIComponent).join("/");
  const canonicalUri = `/${encodeURIComponent(R2_BUCKET)}/${encodedKey}`;

  const qsParams: Record<string, string> = {
    "X-Amz-Algorithm": "AWS4-HMAC-SHA256",
    "X-Amz-Credential": credential,
    "X-Amz-Date": amzDate,
    "X-Amz-Expires": String(expiresSec),
    "X-Amz-SignedHeaders": signedHeaders,
  };
  const canonicalQueryString = Object.keys(qsParams).sort()
    .map((k) => `${encodeURIComponent(k)}=${encodeURIComponent(qsParams[k])}`)
    .join("&");

  const canonicalHeaders = `host:${host}\n`;
  const canonicalRequest =
    `GET\n${canonicalUri}\n${canonicalQueryString}\n${canonicalHeaders}\n${signedHeaders}\nUNSIGNED-PAYLOAD`;
  const stringToSign =
    `AWS4-HMAC-SHA256\n${amzDate}\n${credentialScope}\n${await sha256Hex(canonicalRequest)}`;

  const kDate = await hmac(new TextEncoder().encode("AWS4" + R2_SECRET_ACCESS_KEY), dateStamp);
  const kRegion = await hmac(kDate, region);
  const kService = await hmac(kRegion, service);
  const kSigning = await hmac(kService, "aws4_request");
  const sigBuf = await hmac(kSigning, stringToSign);
  const signature = [...new Uint8Array(sigBuf)]
    .map((b) => b.toString(16).padStart(2, "0")).join("");

  return `${url.protocol}//${host}${canonicalUri}?${canonicalQueryString}&X-Amz-Signature=${signature}`;
}

// Extracts the R2 object key from any of the stored forms:
//   - "key/path.webm"
//   - "/bucket/key/path.webm"
//   - "bucket/key/path.webm"
//   - "https://<account>.r2.cloudflarestorage.com/<bucket>/key/path.webm"
// (Same shape that get-r2-download-url.extractKey handles.)
function extractKey(input: string): string | null {
  if (!input) return null;
  let s = input.trim();
  if (!s) return null;
  if (s.startsWith("http://") || s.startsWith("https://")) {
    try {
      const u = new URL(s);
      s = u.pathname.replace(/^\/+/, "");
    } catch {
      return null;
    }
  } else {
    s = s.replace(/^\/+/, "");
  }
  const bucketPrefix = `${R2_BUCKET}/`;
  if (s.startsWith(bucketPrefix)) s = s.slice(bucketPrefix.length);
  return s || null;
}

// Build the canonical "stored" R2 URL for an object key. Matches the shape of
// video_url already stored on existing rows, so the Scout Report's existing
// get-r2-download-url presign step works identically for merged videos.
function storedR2Url(objectKey: string): string {
  const url = new URL(R2_ENDPOINT);
  const encodedKey = objectKey.split("/").map(encodeURIComponent).join("/");
  return `${url.protocol}//${url.host}/${encodeURIComponent(R2_BUCKET)}/${encodedKey}`;
}

// ---------- handler ----------
Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });

  let session_id: string | null = null;
  let output_key: string | null = null;

  try {
    const body = await req.json().catch(() => ({}));
    session_id = body?.session_id ?? null;
    const response_id: string | null = body?.response_id ?? null;
    const retell_call_id: string | null = body?.retell_call_id ?? null;
    const video_url: string | null = body?.video_url ?? null;
    const audio_url: string | null = body?.audio_url ?? null;

    if (!session_id || !video_url || !audio_url) {
      console.error("[trigger-merge] missing fields", { session_id, video_url, audio_url });
      return json({ ok: false, error: "missing_fields" }, 400);
    }

    // Step 2 — turn the stored (private) R2 video_url into a presigned GET URL.
    const videoKey = extractKey(video_url);
    if (!videoKey) {
      console.error("[trigger-merge] could not extract R2 key from video_url", { video_url });
      return json({ ok: false, error: "invalid_video_url" }, 200);
    }
    console.log("[trigger-merge] extracted video key", { session_id, videoKey });
    const presignedVideoUrl = await presignGet(videoKey, 3600);

    // Step 3 — output_key. Prefer retell_call_id; fall back to session_id.
    const idPart = retell_call_id || session_id;
    const respPart = response_id || "unknown-response";
    output_key = `merged/${respPart}/${idPart}.mp4`;

    // Step 4 — call Render. Generous timeout: Render free tier cold-start ~60s.
    console.log("[trigger-merge] calling render", {
      session_id,
      output_key,
      service: MERGE_SERVICE_URL,
    });

    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 120_000); // 120s
    let renderResp: Response;
    try {
      renderResp = await fetch(`${MERGE_SERVICE_URL}/merge`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "x-merge-secret": MERGE_SECRET,
        },
        body: JSON.stringify({
          video_url: presignedVideoUrl,
          audio_url,
          output_key,
        }),
        signal: controller.signal,
      });
    } finally {
      clearTimeout(timeout);
    }

    const renderText = await renderResp.text();
    let renderJson: any = null;
    try { renderJson = JSON.parse(renderText); } catch { /* ignore */ }
    console.log("[trigger-merge] render response", {
      session_id,
      output_key,
      status: renderResp.status,
      ok: renderResp.ok,
      body: renderJson ?? renderText?.slice(0, 500),
    });

    if (!renderResp.ok || !renderJson?.ok) {
      // Step 6 — leave merged_video_url NULL so a future update can retry,
      // and return 200 so pg_net doesn't error-loop.
      return json({
        ok: false,
        error: "render_failed",
        status: renderResp.status,
        detail: renderJson ?? renderText?.slice(0, 500),
      }, 200);
    }

    // Render confirms which key it wrote. Trust the server's reported key when
    // present; otherwise use the one we asked for.
    const finalKey: string = renderJson?.output_key || output_key;
    const merged_video_url = storedR2Url(finalKey);

    // Step 5 — single-row UPDATE by id. Touches ONLY merged_video_url.
    const admin = createClient(SUPABASE_URL, SERVICE);
    const { error: updErr } = await admin
      .from("ai_interview_sessions")
      .update({ merged_video_url })
      .eq("id", session_id);

    if (updErr) {
      console.error("[trigger-merge] db update failed", { session_id, updErr });
      return json({ ok: false, error: "db_update_failed", detail: updErr.message }, 200);
    }

    // === Piece 6 Part A: backup interview video link ===
    // Outlook always; Gmail only if per-candidate checkbox flag was set on the round.
    try {
      const respId = response_id;
      let ca: any = null;
      if (respId) {
        const { data } = await admin
          .from("candidate_actions")
          .select("round1_hr_copy_requested, round1_hr_copy_email_override, round2_hr_copy_requested, round2_hr_copy_email_override, candidate_id")
          .eq("response_id", respId)
          .maybeSingle();
        ca = data;
      }
      const hrFlag = !!(ca?.round1_hr_copy_requested || ca?.round2_hr_copy_requested);
      const hrOverride = ca?.round2_hr_copy_email_override || ca?.round1_hr_copy_email_override || null;
      const { sendCompletionBackups } = await import("../_shared/archive-and-backup.ts");
      await sendCompletionBackups({
        admin,
        doc_type: "termination", // unused label; we override extras to clarify
        recipient_name: "(interview candidate)",
        external_reference: `VIDEO-${session_id}`,
        pdf_bytes: null,
        source_pdf_url: merged_video_url,
        extras: [["Type", "Completed AI Interview Video"], ["Video link", merged_video_url], ["Response ID", respId || ""]],
        hr_copy_requested: hrFlag,
        hr_copy_email_override: hrOverride,
        candidate_id: ca?.candidate_id ?? null,
      });
    } catch (e) {
      console.warn("[trigger-merge] backup_warn", (e as Error).message);
    }

    console.log("[trigger-merge] SUCCESS", { session_id, output_key: finalKey, merged_video_url });
    return json({ ok: true, session_id, output_key: finalKey, merged_video_url });
  } catch (e: any) {
    // Step 6 — never error-loop the trigger.
    const msg = e?.name === "AbortError" ? "render_timeout_120s" : String(e?.message || e);
    console.error("[trigger-merge] FAILURE", { session_id, output_key, error: msg });
    return json({ ok: false, error: msg }, 200);
  }
});
