// send-round-invite: HR-authenticated. Creates a /rebook scheduling token for
// Round 1 or Round 2 and emails the candidate a branded invite (Angela Stein).
// NO Zoom meeting is created here — that happens only when the candidate
// books a slot via /rebook → rebook-confirm → book-slot.
import { adminClient, corsHeaders, json, requireHr } from "../_shared/hr-auth.ts";

const RESEND_API_KEY = Deno.env.get("RESEND_API_KEY")!;
const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

function genToken() {
  const bytes = crypto.getRandomValues(new Uint8Array(24));
  return Array.from(bytes).map((b) => b.toString(16).padStart(2, "0")).join("");
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });
  const ident = await requireHr(req);
  if (ident instanceof Response) return ident;
  if (!ident.hrId) return json({ error: "no_hr_profile" }, 403);

  const body = await req.json().catch(() => ({}));
  const responseId: string | undefined = body?.response_id;
  const round: number | undefined = body?.round;
  const overrideEmailRaw: string = typeof body?.override_email === "string" ? body.override_email.trim() : "";
  const curatedSlotIdsRaw: unknown = body?.curated_slot_ids;
  const UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
  let curatedSlotIds: string[] | null = null;
  if (Array.isArray(curatedSlotIdsRaw) && curatedSlotIdsRaw.length > 0) {
    if (!curatedSlotIdsRaw.every((s: unknown) => typeof s === "string" && UUID_RE.test(s as string))) {
      return json({ error: "invalid_curated_slot_ids" }, 400);
    }
    curatedSlotIds = Array.from(new Set(curatedSlotIdsRaw as string[]));
  }
  // Optional Round 2 (Marissa) context — all nullable.
  const marissaSalary: string | null =
    typeof body?.marissa_salary === "string" && body.marissa_salary.trim() ? body.marissa_salary.trim() : null;
  const marissaSchedule: string | null =
    typeof body?.marissa_schedule === "string" && body.marissa_schedule.trim() ? body.marissa_schedule.trim() : null;
  const candidateNameOverride: string | null =
    typeof body?.candidate_name === "string" && body.candidate_name.trim() ? body.candidate_name.trim() : null;
  if (!responseId) return json({ error: "missing_response_id" }, 400);
  if (round !== 1 && round !== 2) return json({ error: "invalid_round" }, 400);
  if (overrideEmailRaw && !EMAIL_RE.test(overrideEmailRaw)) return json({ error: "invalid_email" }, 400);
  const hrCopyRequested = !!(body as any)?.hr_copy_requested;
  // Optional per-call override: force the DIRECT Christine /ai-interview link for
  // Round 1, regardless of the global scheduling_config.interview_mode. Defaults
  // to false → every existing caller behaves byte-for-byte as before.
  const forceDirect = round === 1 && (body as any)?.force_direct === true;
  const hrCopyEmailOverrideRaw: string = typeof (body as any)?.hr_copy_email_override === "string" ? (body as any).hr_copy_email_override.trim() : "";
  const hrCopyEmailOverride = hrCopyEmailOverrideRaw && EMAIL_RE.test(hrCopyEmailOverrideRaw) ? hrCopyEmailOverrideRaw : null;

  const stage = round === 1 ? "round1" : "round2_ai";
  const admin = adminClient();

  // Global interview mode (single-row scheduling_config). Defaults to 'ai_direct'
  // on any read failure so we never block a send.
  let interviewMode: string = "ai_direct";
  try {
    const { data: cfg } = await admin
      .from("scheduling_config")
      .select("interview_mode")
      .eq("id", 1)
      .maybeSingle();
    if (cfg?.interview_mode === "ai_direct" || cfg?.interview_mode === "ai_scheduled") {
      interviewMode = cfg.interview_mode;
    }
  } catch (_) { /* default 'ai_direct' */ }

  // Load response → form_id, override_email, override_name
  const { data: resp } = await admin
    .from("responses")
    .select("id, form_id, applicant_id, override_email, override_name")
    .eq("id", responseId)
    .maybeSingle();
  if (!resp) return json({ error: "response_not_found" }, 404);

  // GUARD — protect a LIVE booking from the Round-1 reset.
  // Round 1 doubles as a universal reset that nulls scheduled_slot_id /
  // scheduled_at / appointment_cancelled (see respPatch below). That is correct
  // for re-inviting a cancelled/expired/never-booked candidate, but DESTRUCTIVE
  // when the candidate has ALREADY booked a valid upcoming slot — a second
  // "Send Round 1" would silently erase their confirmed booking (the Andrea Paz
  // Orpilla case). Block the resend with a clear message so HR consciously
  // cancels/reschedules first. Runs BEFORE any side effects (token, email, reset).
  if (round === 1) {
    const { data: bookingResp } = await admin
      .from("responses")
      .select("scheduled_slot_id, appointment_cancelled")
      .eq("id", responseId)
      .maybeSingle();
    if (bookingResp?.scheduled_slot_id && bookingResp.appointment_cancelled !== true) {
      const { data: slot } = await admin
        .from("interview_slots")
        .select("slot_start, status")
        .eq("id", bookingResp.scheduled_slot_id)
        .maybeSingle();
      const startMs = slot?.slot_start ? new Date(slot.slot_start).getTime() : null;
      const isFuture = startMs !== null && startMs > Date.now();
      const isCompleted = (slot?.status || "").toLowerCase() === "completed";
      if (slot && isFuture && !isCompleted) {
        const dateStr = new Date(slot.slot_start).toLocaleString("en-US", {
          timeZone: "Asia/Manila",
          month: "short", day: "numeric", year: "numeric",
          hour: "numeric", minute: "2-digit",
        });
        return json({
          error: "active_booking_exists",
          message: `Candidate already has an active booking on ${dateStr} (PST) — cancel or reschedule first.`,
        }, 409);
      }
    }
  }

  // Persist override email if HR supplied one (single-row update by id)
  if (overrideEmailRaw) {
    await admin.from("responses").update({ override_email: overrideEmailRaw }).eq("id", responseId);
  }
  // Persist override name if HR supplied one (single-row update by id).
  if (candidateNameOverride) {
    await admin.from("responses").update({ override_name: candidateNameOverride }).eq("id", responseId);
  }

  // Resolve candidate name + email by LABEL match (never positional).
  const { data: qs } = await admin.from("questions")
    .select("id, type, label").eq("form_id", resp.form_id);
  const { data: ans } = await admin.from("answers")
    .select("question_id, answer_text").eq("response_id", responseId);

  const findByLabel = (re: RegExp) =>
    qs?.find((q: any) => re.test(q.label || ""));
  const emailQ = findByLabel(/e[-\s]?mail/i)
    || qs?.find((q: any) => q.type === "email");
  const nameQ = findByLabel(/(full\s*name|first\s*name|your\s*name|\bname\b)/i)
    || qs?.find((q: any) => q.type === "short_text");

  const answerFor = (qid?: string) =>
    qid ? (ans?.find((a: any) => a.question_id === qid)?.answer_text || "").trim() : "";

  const candidateEmail = overrideEmailRaw
    || (resp.override_email || "").trim()
    || answerFor(emailQ?.id);
  // override_name is the single source of truth, then the form answer.
  const candidateName = candidateNameOverride
    || (resp.override_name || "").trim()
    || answerFor(nameQ?.id)
    || "there";

  if (!candidateEmail || !EMAIL_RE.test(candidateEmail)) {
    return json({ error: "missing_email", message: "Add an email for this candidate first." }, 400);
  }

  // Idempotency: invalidate any prior unused invite tokens for this response+stage
  // (single-table update by exact filter; never touches answers).
  await admin.from("rebook_tokens").update({
    expires_at: new Date(Date.now() - 1000).toISOString(),
  })
    .eq("response_id", responseId)
    .eq("stage", stage)
    .is("used_at", null);

  // Mint fresh token (3-day expiry default from column default).
  // CRITICAL: verify the insert actually persisted BEFORE sending the email —
  // otherwise the candidate gets a link whose token doesn't exist in the DB
  // and lands on "Link Unavailable".
  const token = genToken();
  // Round 1 token stage depends on global interview mode:
  //   ai_direct    → "round1"        (/ai-interview/:token, Christine direct)
  //   ai_scheduled → "ai_scheduled"  (/rebook/:token → rebook-confirm-ai)
  // Round 2 is now AI-only (Marissa) → "round2_ai" (/ai-interview/:token).
  // force_direct (Round 1 only) overrides the global mode to the DIRECT path.
  const round1Mode = forceDirect ? "ai_direct" : interviewMode;
  const round1Stage = round1Mode === "ai_scheduled" ? "ai_scheduled" : "round1";
  const tokenStage = round === 1 ? round1Stage : "round2_ai";
  // candidateName already resolves override_name first for BOTH rounds.
  const effectiveCandidateName = candidateName;
  const insertPayload: Record<string, unknown> = {
    token,
    response_id: responseId,
    stage: tokenStage,
    form_id: resp.form_id,
    assigned_hr_id: ident.hrId,
    candidate_name: effectiveCandidateName,
    candidate_email: candidateEmail,
    curated_slot_ids: curatedSlotIds,
  };
  if (round === 2) {
    if (marissaSalary) insertPayload.marissa_salary = marissaSalary;
    if (marissaSchedule) insertPayload.marissa_schedule = marissaSchedule;
  }
  const { error: tokInsErr } = await admin.from("rebook_tokens").insert(insertPayload);
  if (tokInsErr) {
    console.error("rebook_tokens insert failed", tokInsErr);
    return json({ error: "token_persist_failed", details: tokInsErr.message }, 500);
  }
  // Read-after-write sanity check.
  const { data: tokCheck } = await admin
    .from("rebook_tokens").select("token").eq("token", token).maybeSingle();
  if (!tokCheck) {
    console.error("rebook_tokens read-after-write missing", { token });
    return json({ error: "token_not_persisted" }, 500);
  }

  // Always build candidate links on the fixed public domain so emails sent from
  // the editor preview never produce login-gated dead links. (Do not use Origin.)
  const PUBLIC_BASE_URL = "https://jobs.expertintuitiveadvisor.com";
  const bookingUrl = `${PUBLIC_BASE_URL}/rebook/${token}`;
  const aiInterviewUrl = `${PUBLIC_BASE_URL}/ai-interview/${token}`;
  // Round 1: ai_direct → Christine link; ai_scheduled → booking link.
  // Round 2: AI interview link (Marissa) — no booking, no Zoom.
  const round1Url = round1Mode === "ai_scheduled" ? bookingUrl : aiInterviewUrl;
  const inviteUrl = round === 1 ? round1Url : aiInterviewUrl;

  // Position title (for the email body)
  let positionTitle = "the role";
  const { data: meta } = await admin.from("form_metadata")
    .select("position_title").eq("form_id", resp.form_id).maybeSingle();
  if (meta?.position_title) positionTitle = meta.position_title;

  const firstName = (effectiveCandidateName || "there").split(" ")[0];

  let subject: string;
  let html: string;
  let text: string;

  if (round === 1) {
    if (round1Mode === "ai_scheduled") {
      // AI SCHEDULED: candidate picks a slot first; Christine link comes later.
      subject = "Schedule your interview — Expert Intuitive Advisor";
      html = `<div style="font-family: Arial, Helvetica, sans-serif; color:#1a2547; font-size:15px; line-height:1.6;">
<p>Hi ${firstName},</p>
<p>Congratulations! We'd like to invite you to interview for the <strong>${positionTitle}</strong> position.</p>
<p>Please choose a time that works for you using the link below. Your interview is conducted online and takes about 5 minutes.</p>
<p><a href="${inviteUrl}" style="color:#1a2547; font-weight:600;">${inviteUrl}</a></p>
<p style="color:#6b7280; font-size:13px;">This link expires in 3 days. All times are in Philippine Standard Time.</p>
<p>We look forward to meeting you!</p>
<p style="margin-top:24px;">Warmly,<br/>
<strong>Angela Stein</strong><br/>
HR — Talent Manager<br/>
Expert Intuitive Advisor Inc.</p>
</div>`;
      text = `Hi ${firstName},

Congratulations! We'd like to invite you to interview for the ${positionTitle} position.

Please choose a time that works for you using the link below. Your interview is conducted online and takes about 5 minutes.

${inviteUrl}

This link expires in 3 days. All times are in Philippine Standard Time.

We look forward to meeting you!

Angela Stein
HR — Talent Manager
Expert Intuitive Advisor Inc.`;
    } else {
      // AI DIRECT (unchanged from P4.1): Christine link, click to begin.
      subject = "Your interview with Expert Intuitive Advisor";
      html = `<div style="font-family: Arial, Helvetica, sans-serif; color:#1a2547; font-size:15px; line-height:1.6;">
<p>Hi ${firstName},</p>
<p>Congratulations! We'd like to invite you to your interview for the <strong>${positionTitle}</strong> position.</p>
<p>Your interview is conducted online and takes about 5 minutes. When you're ready, click the link below to begin. Please make sure you're in a quiet place with a working camera and microphone.</p>
<p>In order to qualify for this role, please complete your interview within 72 hours of receiving this message.</p>
<p><a href="${inviteUrl}" style="color:#1a2547; font-weight:600;">${inviteUrl}</a></p>
<p style="color:#6b7280; font-size:13px;">This link expires in 3 days. All times are in Philippine Standard Time.</p>
<p>We look forward to meeting you!</p>
<p style="margin-top:24px;">Warmly,<br/>
<strong>Angela Stein</strong><br/>
HR — Talent Manager<br/>
Expert Intuitive Advisor Inc.</p>
</div>`;
      text = `Hi ${firstName},

Congratulations! We'd like to invite you to your interview for the ${positionTitle} position.

Your interview is conducted online and takes about 5 minutes. When you're ready, click the link below to begin. Please make sure you're in a quiet place with a working camera and microphone.

In order to qualify for this role, please complete your interview within 72 hours of receiving this message.

${inviteUrl}

This link expires in 3 days. All times are in Philippine Standard Time.

We look forward to meeting you!

Angela Stein
HR — Talent Manager
Expert Intuitive Advisor Inc.`;
    }

  } else {
    // Round 2 — AI interview with Marissa. Click link to begin (no booking, no Zoom).
    subject = "Your Round 2 interview with Expert Intuitive Advisor";
    html = `<div style="font-family: Arial, Helvetica, sans-serif; color:#1a2547; font-size:15px; line-height:1.6;">
<p>Hi ${firstName},</p>
<p>Congratulations on making it to Round 2 for the <strong>${positionTitle}</strong> position!</p>
<p>Your Round 2 interview is conducted online with our AI interviewer, Marissa. It takes about 10 minutes. When you're ready, click the link below to begin. Please make sure you're in a quiet place with a working camera and microphone.</p>
<p><a href="${inviteUrl}" style="color:#1a2547; font-weight:600;">${inviteUrl}</a></p>
<p style="color:#6b7280; font-size:13px;">This link expires in 3 days. All times are in Philippine Standard Time.</p>
<p>We look forward to speaking with you!</p>
<p style="margin-top:24px;">Warmly,<br/>
<strong>Angela Stein</strong><br/>
HR — Talent Manager<br/>
Expert Intuitive Advisor Inc.</p>
</div>`;
    text = `Hi ${firstName},

Congratulations on making it to Round 2 for the ${positionTitle} position!

Your Round 2 interview is conducted online with our AI interviewer, Marissa. It takes about 10 minutes. When you're ready, click the link below to begin. Please make sure you're in a quiet place with a working camera and microphone.

${inviteUrl}

This link expires in 3 days. All times are in Philippine Standard Time.

We look forward to speaking with you!

Angela Stein
HR — Talent Manager
Expert Intuitive Advisor Inc.`;
  }

  let emailOk = false;
  let resendId: string | null = null;
  let errorMessage: string | null = null;
  try {
    const r = await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: { "Content-Type": "application/json", Authorization: `Bearer ${RESEND_API_KEY}` },
      body: JSON.stringify({
        from: "Angela Stein / HR – Talent Manager <talent@expertintuitiveadvisor.com>",
        to: [candidateEmail], subject, html, text,
      }),
    });
    const j = await r.json().catch(() => ({}));
    emailOk = r.ok;
    resendId = j?.id ?? null;
    if (!r.ok) errorMessage = JSON.stringify(j).slice(0, 500);
  } catch (e: any) {
    errorMessage = String(e?.message || e);
  }

  await admin.from("email_log").insert({
    candidate_id: resp.applicant_id ?? null,
    stage: round === 1 ? "stage_2_round_1_invite" : "stage_2_round_2_invite",
    sender: "resend",
    from_address: "talent@expertintuitiveadvisor.com",
    from_name: "Angela Stein / HR – Talent Manager",
    to_address: candidateEmail,
    subject,
    status: emailOk ? "sent" : "failed",
    sent_at: emailOk ? new Date().toISOString() : null,
    resend_message_id: resendId,
    error_message: emailOk ? null : errorMessage,
  });

  if (!emailOk) {
    return json({ error: "email_failed", details: errorMessage }, 502);
  }

  // Update candidate_actions: ensure row exists, then mark stage sent.
  // Single-row by exact id; never touches answers.
  const { data: existing } = await admin.from("candidate_actions")
    .select("*").eq("response_id", responseId).maybeSingle();
  let actionRow = existing;
  if (!actionRow) {
    const { data: created } = await admin.from("candidate_actions").insert({
      candidate_id: resp.applicant_id,
      form_id: resp.form_id,
      response_id: responseId,
    }).select("*").maybeSingle();
    actionRow = created;
  }
  if (actionRow) {
    const now = new Date().toISOString();
    const alreadySent = (round === 1 ? actionRow.round1_status : actionRow.round2_status) === "sent";
    const patch: Record<string, any> = {
      [`round${round}_last_sent_at`]: now,
      [`round${round}_hr_copy_requested`]: hrCopyRequested,
      [`round${round}_hr_copy_email_override`]: hrCopyEmailOverride,
    };
    if (round === 1) {
      patch.round1_mode = interviewMode;
      Object.assign(patch, {
        round1_attendance_status: null,
        round1_attendance_marked_at: null,
        round1_attendance_marked_by_hr_id: null,
        round2_status: "not_sent",
        round2_sent_at: null,
        round2_last_sent_at: null,
        round2_resend_count: 0,
        round2_appointment_date: null,
        round2_zoom_meeting_id: null,
        round2_zoom_join_url: null,
        round2_attendance_status: null,
        round2_attendance_marked_at: null,
        round2_attendance_marked_by_hr_id: null,
        offer_status: "not_sent",
        offer_sent_at: null,
        offer_last_sent_at: null,
        offer_resend_count: 0,
      });
    }
    if (alreadySent) {
      patch[`round${round}_resend_count`] =
        (round === 1 ? actionRow.round1_resend_count : actionRow.round2_resend_count || 0) + 1;
    } else {
      patch[`round${round}_status`] = "sent";
      patch[`round${round}_sent_at`] = now;
    }
    await admin.from("candidate_actions").update(patch).eq("id", actionRow.id);
  }

  // Tracking on responses.
  // Round 1 doubles as a universal RESET: clear appointment_cancelled so a
  // previously-cancelled / expired / legacy candidate restarts cleanly.
  const respPatch: Record<string, unknown> = {
    round_stage: round === 1 ? "round_1_sent" : "round_2_sent",
    [`round_${round}_sent_at`]: new Date().toISOString(),
    handled_by_hr_id: ident.hrId,
  };
  if (round === 1) {
    respPatch.appointment_cancelled = false;
    respPatch.scheduled_slot_id = null;
    respPatch.scheduled_at = null;
    respPatch.round_2_sent_at = null;
    respPatch.offer_sent_at = null;
  }
  await admin.from("responses").update(respPatch).eq("id", responseId);

  return json({ success: true, rebook_url: inviteUrl, candidate_email: candidateEmail });
});
