import { adminClient, corsHeaders, json, requireHr } from "../_shared/hr-auth.ts";

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });
  const ident = await requireHr(req);
  if (ident instanceof Response) return ident;
  if (!ident.hrId) return json({ error: "no_hr_profile" }, 403);

  const { slot_id, notes } = await req.json().catch(() => ({}));
  if (!slot_id) return json({ error: "missing slot_id" }, 400);

  const admin = adminClient();
  const update: Record<string, unknown> = {
    completed_at: new Date().toISOString(),
    completion_method: "manual",
  };
  if (typeof notes === "string" && notes.trim()) update.notes = notes.trim().slice(0, 5000);

  const { data, error } = await admin
    .from("interview_slots")
    .update(update)
    .eq("id", slot_id)
    .eq("claimed_by_hr_id", ident.hrId)
    .select("id");
  if (error) return json({ error: error.message }, 500);
  if (!data || data.length === 0) return json({ error: "not_your_claim" }, 403);
  return json({ success: true });
});
