// auto-send-stage-1: fires Stage 1 acknowledgment dual-email when a candidate submits a form.
// Public (verify_jwt=false). Trusts only response_id from client; derives all other data server-side.
import { createClient } from "npm:@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
const SERVICE_KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

const TALENT_FROM_NAME = "Angela Stein / HR – Talent Manager";
const TALENT_FROM_ADDRESS = "talent@expertintuitiveadvisor.com";
const PERSONAL_FROM_NAME = "Angela Stein";

const esc = (s: string) =>
  s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");

function buildResendTemplate(name: string, position: string) {
  const text = `Hi ${name},

We've received your application for ${position} at Expert Intuitive Advisor Inc.

Please do not reply to this email — this inbox is not monitored.

If your profile matches what we're looking for, our team will reach out within 7 business days to schedule an initial interview.

If you don't hear from us within that window, it means we're not moving forward at this time. We keep all applications on file and may reach out for future openings that fit your skills.

Thanks for your interest in EIA.

Angela Stein
HR – Talent Manager
Expert Intuitive Advisor Inc.`;

  const html = `<!doctype html><html><body style="font-family:Arial,Helvetica,sans-serif;color:#222;font-size:15px;line-height:1.55;margin:0;padding:24px;background:#ffffff;">
<div style="max-width:560px;margin:0 auto;">
<p>Hi ${esc(name)},</p>
<p>We've received your application for <strong>${esc(position)}</strong> at Expert Intuitive Advisor Inc.</p>
<p><strong>Please do not reply to this email — this inbox is not monitored.</strong></p>
<p>If your profile matches what we're looking for, our team will reach out within 7 business days to schedule an initial interview.</p>
<p>If you don't hear from us within that window, it means we're not moving forward at this time. We keep all applications on file and may reach out for future openings that fit your skills.</p>
<p>Thanks for your interest in EIA.</p>
<p style="margin-top:28px;">Angela Stein<br/>HR – Talent Manager<br/>Expert Intuitive Advisor Inc.</p>
</div></body></html>`;

  return {
    from_name: TALENT_FROM_NAME,
    from_address: TALENT_FROM_ADDRESS,
    subject: `Application received — ${position}`,
    html_body: html,
    text_body: text,
  };
}

function buildPersonalTemplate(name: string, position: string) {
  const text = `Hi ${name},

Just a quick personal note — your application for ${position} landed in our system.

Heads up: please don't reply to the formal email you also got from talent@careers.expertintuitiveadvisor.com. That inbox is automated.

If your profile matches what we're looking for, you'll hear back from us within 7 business days. Either way, we truly appreciate the time you took to apply.

Appreciate you taking the time to apply.

Angela Stein
HR – Talent Manager
Expert Intuitive Advisor Inc.`;

  const html = `<!doctype html><html><body style="font-family:Arial,Helvetica,sans-serif;color:#222;font-size:15px;line-height:1.55;margin:0;padding:24px;background:#ffffff;">
<div style="max-width:560px;margin:0 auto;">
<p>Hi ${esc(name)},</p>
<p>Just a quick personal note — your application for <strong>${esc(position)}</strong> landed in our system.</p>
<p>Heads up: please don't reply to the formal email you also got from <em>talent@careers.expertintuitiveadvisor.com</em>. That inbox is automated.</p>
<p>If your profile matches what we're looking for, you'll hear back from us within 7 business days. Either way, we truly appreciate the time you took to apply.</p>
<p>Appreciate you taking the time to apply.</p>
<p style="margin-top:24px;">Angela Stein<br/>HR – Talent Manager<br/>Expert Intuitive Advisor Inc.</p>
</div></body></html>`;

  return {
    from_name: PERSONAL_FROM_NAME,
    from_address: TALENT_FROM_ADDRESS,
    subject: "Quick note — your EIA application",
    html_body: html,
    text_body: text,
  };
}

async function logFailure(
  admin: ReturnType<typeof createClient>,
  candidateId: string | null,
  toAddress: string,
  reason: string,
) {
  await admin.from("email_log").insert([
    {
      candidate_id: candidateId,
      stage: "stage_1_thank_you",
      sender: "resend",
      from_address: TALENT_FROM_ADDRESS,
      from_name: TALENT_FROM_NAME,
      to_address: toAddress || "unknown",
      subject: "Application received (not sent)",
      status: "failed",
      error_message: reason,
    },
    {
      candidate_id: candidateId,
      stage: "stage_1_thank_you",
      sender: "resend",
      from_address: TALENT_FROM_ADDRESS,
      from_name: PERSONAL_FROM_NAME,
      to_address: toAddress || "unknown",
      subject: "Quick note (not sent)",
      status: "failed",
      error_message: reason,
    },
  ]);
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });
  const admin = createClient(SUPABASE_URL, SERVICE_KEY);

  try {
    const body = await req.json().catch(() => null);
    const responseId = body?.response_id;
    if (!responseId || typeof responseId !== "string") {
      return new Response(JSON.stringify({ sent: false, reason: "missing response_id" }), {
        status: 200,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // Load response → form
    const { data: response, error: rErr } = await admin
      .from("responses")
      .select("id, form_id, applicant_id, scheduled_slot_id, override_name")
      .eq("id", responseId)
      .maybeSingle();
    if (rErr || !response) {
      return new Response(JSON.stringify({ sent: false, reason: "response_not_found" }), {
        status: 200,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // If candidate scheduled an interview, send the confirmed email instead of Stage 1 ack.
    if (response.scheduled_slot_id) {
      const r = await fetch(`${SUPABASE_URL}/functions/v1/send-interview-confirmed-email`, {
        method: "POST",
        headers: { Authorization: `Bearer ${SERVICE_KEY}`, "Content-Type": "application/json" },
        body: JSON.stringify({ response_id: responseId }),
      });
      const j = await r.json().catch(() => ({}));
      return new Response(
        JSON.stringify({ sent: true, branch: "interview_confirmed", status: r.status, ...j }),
        { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } },
      );
    }

    // Load questions + answers
    const { data: questions } = await admin
      .from("questions")
      .select("id, type, label")
      .eq("form_id", response.form_id);
    const { data: answers } = await admin
      .from("answers")
      .select("question_id, answer_text")
      .eq("response_id", responseId);

    const qs = questions || [];
    const ans = answers || [];
    const emailQ = qs.find((q: any) => q.type === "email");
    const nameQ =
      qs.find((q: any) => q.type === "short_text" && /name/i.test(q.label)) ||
      qs.find((q: any) => q.type === "short_text");

    const findAnswer = (qid?: string) =>
      qid ? (ans.find((a: any) => a.question_id === qid)?.answer_text || "").trim() : "";

    const candidateEmail = findAnswer(emailQ?.id);
    const candidateNameRaw = ((response as any).override_name || "").trim() || findAnswer(nameQ?.id);
    const candidateName = candidateNameRaw || "there";

    // Load position_title
    const { data: meta } = await admin
      .from("form_metadata")
      .select("position_title")
      .eq("form_id", response.form_id)
      .maybeSingle();
    const positionTitle =
      (meta?.position_title || "").trim() || "the role you applied for";

    // Validate email
    if (!candidateEmail || !EMAIL_RE.test(candidateEmail)) {
      await logFailure(admin, response.applicant_id ?? null, candidateEmail, "invalid_email");
      return new Response(JSON.stringify({ sent: false, reason: "invalid_email" }), {
        status: 200,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // Ensure candidate_actions row (trigger should auto-create; this is belt-and-suspenders)
    await admin
      .from("candidate_actions")
      .upsert(
        {
          response_id: responseId,
          form_id: response.form_id,
          candidate_id: response.applicant_id,
        },
        { onConflict: "response_id", ignoreDuplicates: true },
      );

    const sender_a = buildResendTemplate(candidateName, positionTitle);
    const sender_b = buildPersonalTemplate(candidateName, positionTitle);

    // Invoke send-dual-email using service role key
    const dualRes = await fetch(`${SUPABASE_URL}/functions/v1/send-dual-email`, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${SERVICE_KEY}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        to: candidateEmail,
        candidate_id: response.applicant_id,
        stage: "stage_1_thank_you",
        sender_a,
        sender_b,
        // Route the warm "personal touch" copy via the verified Resend domain
        // (sender_b.from_address = talent@careers.expertintuitiveadvisor.com),
        // not Gmail SMTP.
        second_via_resend: true,
      }),
    });
    const dualJson = await dualRes.json().catch(() => ({}));

    return new Response(
      JSON.stringify({ sent: true, dual_status: dualRes.status, ...dualJson }),
      { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } },
    );
  } catch (e: any) {
    console.error("auto-send-stage-1 error", e);
    return new Response(
      JSON.stringify({ sent: false, reason: "exception", error: e?.message || String(e) }),
      { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } },
    );
  }
});
