import { createClient } from "npm:@supabase/supabase-js@2";
import { teamNameById } from "../_shared/teams.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type, x-sylvia-key",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

const json = (body: unknown, status = 200) =>
  new Response(JSON.stringify(body), {
    status,
    headers: { ...corsHeaders, "Content-Type": "application/json" },
  });

const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
const SERVICE_KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
const BRIDGE_KEY = Deno.env.get("SYLVIA_BRIDGE_KEY")!;

// ── NEW EIA Projects (PMS) bridge ──
// The old PMS Supabase project is dead. The PMS now lives on a separate
// Supabase project exposing two read endpoints secured by the shared
// EIA_BRIDGE_KEY (header x-eia-key). We resolve board_name + tasks straight
// from the candidate's responses.assigned_group_id. Any bridge failure
// degrades gracefully (board_name → local teams map, tasks → []).
const PMS_BRIDGE_BASE = "https://kevtjqxsmzjquoonqfbh.supabase.co/functions/v1";
const EIA_BRIDGE_KEY = Deno.env.get("EIA_BRIDGE_KEY")!;

// GET /list-groups → resolve the group name for an assigned_group_id.
// Returns null on any failure so the caller can fall back to the local map.
async function fetchBridgeGroupName(groupId: string): Promise<string | null> {
  try {
    const res = await fetch(`${PMS_BRIDGE_BASE}/list-groups`, {
      headers: { "x-eia-key": EIA_BRIDGE_KEY },
    });
    if (!res.ok) {
      console.error("bridge /list-groups non-200", res.status);
      return null;
    }
    const data = await res.json().catch(() => null);
    const groups = Array.isArray(data?.groups) ? data.groups : [];
    const g = groups.find((x: any) => x?.id === groupId);
    return (g?.name ?? null) || null;
  } catch (e) {
    console.error("bridge /list-groups failed", e);
    return null;
  }
}

// GET /list-tasks?group_id=<uuid> → tasks for the assigned group.
// Maps to the shape Sylvia expects (task_code, name, details, status).
// Returns [] on any failure so Sylvia degrades gracefully.
async function fetchBridgeTasks(groupId: string): Promise<any[]> {
  try {
    const res = await fetch(
      `${PMS_BRIDGE_BASE}/list-tasks?group_id=${encodeURIComponent(groupId)}`,
      { headers: { "x-eia-key": EIA_BRIDGE_KEY } },
    );
    if (!res.ok) {
      console.error("bridge /list-tasks non-200", res.status);
      return [];
    }
    const data = await res.json().catch(() => null);
    const tasks = Array.isArray(data?.tasks) ? data.tasks : [];
    return tasks.map((t: any) => ({
      task_code: t?.task_code ?? null,
      name: t?.name ?? null,
      details: t?.details ?? null,
      status: t?.status ?? null,
    }));
  } catch (e) {
    console.error("bridge /list-tasks failed", e);
    return [];
  }
}

// Active On-Hold blocklist match (case-insensitive on full_name OR email).
// Fails CLOSED: any query error is treated as a block so a non-active identity
// can never leak data through a transient failure.
async function hasActiveBlock(
  admin: any,
  names: (string | null | undefined)[],
  emails: (string | null | undefined)[],
): Promise<boolean> {
  const orParts: string[] = [];
  const seen = new Set<string>();
  for (const n of names) {
    const v = (n ?? "").trim();
    if (v && !seen.has("n:" + v.toLowerCase())) { seen.add("n:" + v.toLowerCase()); orParts.push(`full_name.ilike.${v}`); }
  }
  for (const e of emails) {
    const v = (e ?? "").trim();
    if (v && !seen.has("e:" + v.toLowerCase())) { seen.add("e:" + v.toLowerCase()); orParts.push(`email.ilike.${v}`); }
  }
  if (orParts.length === 0) return false;
  const { data, error } = await admin
    .from("sylvia_blocklist")
    .select("id")
    .is("removed_at", null)
    .or(orParts.join(","))
    .limit(1);
  if (error) { console.error("sylvia_blocklist check failed", error); return true; }
  return !!(data && data.length > 0);
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });
  try {
    const sylviaKey = req.headers.get("x-sylvia-key");
    if (!sylviaKey || sylviaKey !== BRIDGE_KEY) return json({ error: "unauthorized" }, 401);

    const body = await req.json().catch(() => ({}));
    let queryRaw = typeof body?.query === "string" ? body.query.trim() : "";
    const phoneRaw = typeof body?.phone === "string" ? body.phone.trim() : "";

    const admin = createClient(SUPABASE_URL, SERVICE_KEY);

    // ── ADDITIVE: phone-number identification ──
    // The ElevenLabs agent may pass { phone } = the WhatsApp number the candidate
    // is messaging from. When present, resolve the candidate by phone BEFORE the
    // existing name/email path so Sylvia does not have to re-ask for name/email.
    // We resolve phone → a candidate identity (email preferred, else name) and
    // then feed that identity into the UNCHANGED query flow below, so the
    // response shape sylvia-context/the agent expects is identical to today.
    // Read-only: matching + single-row reads by id only. Never fabricates rows.
    if (phoneRaw && !queryRaw) {
      // a. Normalize incoming phone: strip "+", spaces, dashes → digits only.
      //    "+639162770516" and "639162770516" both become "639162770516".
      const normPhone = phoneRaw.replace(/[^\d]/g, "");
      if (normPhone) {
        // b. Match against launches.whatsapp_number in BOTH stored formats
        //    ("+639162770516" and "639162770516"). ILIKE substring pre-filters,
        //    then we confirm an EXACT normalized digit-for-digit match in JS so a
        //    partial/substring number can never resolve the wrong person.
        const { data: launchRows } = await admin
          .from("launches")
          .select("candidate_name, whatsapp_number, response_id, created_at")
          .ilike("whatsapp_number", `%${normPhone}%`)
          .order("created_at", { ascending: false })
          .limit(20);
        const exact = (launchRows ?? []).filter(
          (l) => (l.whatsapp_number ?? "").replace(/[^\d]/g, "") === normPhone,
        );
        // Prefer a launch that carries a pipeline response_id (richest identity),
        // else the most recent exact match.
        const best = exact.find((l) => l.response_id) ?? exact[0] ?? null;

        if (best) {
          // c. Derive a candidate identity. If the launch has a response_id, read
          //    the linked candidate's most-recent job_offers row and prefer email
          //    (most precise) → name. Otherwise use the launch candidate_name.
          let identity: string | null = null;
          if (best.response_id) {
            const { data: resp0 } = await admin
              .from("responses")
              .select("applicant_id")
              .eq("id", best.response_id)
              .maybeSingle();
            if (resp0?.applicant_id) {
              const { data: off0 } = await admin
                .from("job_offers")
                .select("candidate_email, override_email, candidate_name")
                .eq("candidate_id", resp0.applicant_id)
                .order("signed_at", { ascending: false, nullsFirst: false })
                .limit(1)
                .maybeSingle();
              identity =
                (off0?.candidate_email ?? off0?.override_email ?? off0?.candidate_name) ||
                null;
            }
          }
          if (!identity) identity = (best.candidate_name ?? "").trim() || null;
          // Feed the resolved identity into the existing query flow unchanged.
          if (identity) queryRaw = identity;
        }
      }
    }

    // d. If phone was missing OR did not resolve, fall back to the EXISTING
    //    name/email { query } behavior exactly as before.
    if (!queryRaw) return json({ error: "missing query" }, 400);

    const isEmail = queryRaw.includes("@");

    // ── NAME normalization (FIX 2): trim, lowercase, collapse internal spaces,
    // split into words. Forgiving match = every typed word must appear somewhere
    // in the stored name (AND of ILIKE %word%), so middle-name / word-order
    // differences still match. ILIKE escaping preserved per word. ──
    const escapeLike = (s: string) => s.replace(/[%_]/g, (m) => `\\${m}`);
    const nameWords = queryRaw
      .trim()
      .toLowerCase()
      .replace(/\s+/g, " ")
      .split(" ")
      .filter(Boolean);

    let offerQ = admin
      .from("job_offers")
      .select("candidate_id, candidate_name, candidate_email, position_title, signed_at, override_email, employment_status, quarantine_removed, hold_status");

    if (isEmail) {
      const q = queryRaw.toLowerCase();
      offerQ = offerQ.or(`candidate_email.ilike.${q},override_email.ilike.${q}`);
    } else {
      // FIX 2: AND a %word% ILIKE for each typed word (any order, subset of full name)
      for (const w of nameWords) {
        offerQ = offerQ.ilike("candidate_name", `%${escapeLike(w)}%`);
      }
    }

    const { data: offers, error: offerErr } = await offerQ
      .order("signed_at", { ascending: false, nullsFirst: false })
      .limit(5);
    if (offerErr) throw offerErr;

    // Early blocklist gate: a suspicious person may have NO employee record at all.
    const blockedByQuery = await hasActiveBlock(
      admin,
      [isEmail ? null : queryRaw],
      [isEmail ? queryRaw : null],
    );

    if (!offers || offers.length === 0) {
      if (blockedByQuery) {
        return json({ found: true, blocked: true, candidate_name: isEmail ? null : queryRaw });
      }

      // ── FIX 1: Universal-Launch fallback (NAME branch only) ──
      // People launched via Universal Launch live ONLY in `launches` (name +
      // whatsapp), with NO job_offers row. Read-only resolution: if a launch row
      // matches the typed name (same forgiving word matching as FIX 2), greet
      // them as a launched person with NO pipeline record. Never fabricate a
      // job_offers row, never touch the context chain.
      if (!isEmail && nameWords.length > 0) {
        let launchQ = admin
          .from("launches")
          .select("candidate_name, whatsapp_number, contact_timezone, sylvia_instruction, mode, status");
        for (const w of nameWords) {
          launchQ = launchQ.ilike("candidate_name", `%${escapeLike(w)}%`);
        }
        const { data: launchRows } = await launchQ
          .order("created_at", { ascending: false })
          .limit(5);

        if (launchRows && launchRows.length > 0) {
          const distinctNames = Array.from(
            new Set(
              launchRows
                .map((l) => (l.candidate_name ?? "").trim().toLowerCase())
                .filter(Boolean),
            ),
          );
          if (distinctNames.length > 1) {
            return json({
              found: false,
              ambiguous: true,
              matches: launchRows.map((l) => ({ candidate_name: l.candidate_name })),
            });
          }
          const lr = launchRows[0];
          return json({
            found: true,
            source: "launch",
            candidate_name: lr.candidate_name ?? null,
            whatsapp_number: lr.whatsapp_number ?? null,
            contact_timezone: lr.contact_timezone ?? null,
            instruction: (lr.sylvia_instruction ?? null) || null,
            mode: lr.mode ?? null,
          });
        }
      }

      return json({ found: false, matches: [] });
    }

    const distinctIds = Array.from(
      new Set(offers.map((o) => o.candidate_id).filter(Boolean) as string[]),
    );
    if (distinctIds.length > 1) {
      return json({
        found: false,
        ambiguous: true,
        matches: offers.map((o) => ({
          candidate_name: o.candidate_name,
          position_title: o.position_title,
        })),
      });
    }

    // exactly one distinct candidate — pick most-recent offer row (already ordered)
    const chosen = offers[0];
    const candidateId = chosen.candidate_id;

    let response_id: string | null = null;
    let respRow: any = null;
    if (candidateId) {
      const { data: resp } = await admin
        .from("responses")
        .select("id, round_stage, disqualified_at, final_outcome")
        .eq("applicant_id", candidateId)
        .order("submitted_at", { ascending: false })
        .limit(1)
        .maybeSingle();
      response_id = resp?.id ?? null;
      respRow = resp ?? null;
    }

    // ── SECURITY GATE: terminated / disqualified / on-hold / quarantined / blocklisted → NO data ──
    const blockedByCandidate = await hasActiveBlock(
      admin,
      [chosen.candidate_name, isEmail ? null : queryRaw],
      [chosen.candidate_email, chosen.override_email, isEmail ? queryRaw : null],
    );
    const inactive =
      (chosen.employment_status != null && chosen.employment_status !== "active") ||
      chosen.hold_status === "on_hold" ||
      chosen.quarantine_removed === true ||
      (respRow?.round_stage === "disqualified" || respRow?.round_stage === "terminated") ||
      respRow?.disqualified_at != null ||
      respRow?.final_outcome === "disqualified_after_matched" ||
      blockedByQuery ||
      blockedByCandidate;

    if (inactive) {
      return json({
        found: true,
        blocked: true,
        candidate_name: chosen.candidate_name ?? null,
      });
    }

    let eb: any = null;
    if (response_id) {
      const { data } = await admin
        .from("employee_boards")
        .select("board_id, board_name, assigned_agent, onboarding_notes, onboarding_credentials")
        .eq("response_id", response_id)
        .maybeSingle();
      eb = data;
    }

    const { data: cfg } = await admin
      .from("scheduling_config")
      .select("sylvia_daily_brief")
      .eq("id", 1)
      .maybeSingle();

    // ── Queued team assignment + instruction. assigned_group_id drives both the
    // team_name (local shared map, passthrough for free-text) AND the new PMS
    // bridge resolution for board_name + tasks below. ──
    let assigned_group_id: string | null = null;
    let team_name: string | null = null;
    let instruction: string | null = null;
    if (response_id) {
      const { data: asg } = await admin
        .from("responses")
        .select("assigned_group_id, sylvia_instruction")
        .eq("id", response_id)
        .maybeSingle();
      assigned_group_id = (asg?.assigned_group_id ?? null) || null;
      team_name = teamNameById(assigned_group_id);
      instruction = (asg?.sylvia_instruction ?? null) || null;
    }

    // ── board_name + tasks now come from the EIA Projects (PMS) bridge, keyed
    // on assigned_group_id. Bridge failure degrades gracefully: board_name
    // falls back to the local teams map, tasks fall back to []. ──
    let board_name: string | null = eb?.board_name ?? null;
    let tasks: any[] = [];
    if (assigned_group_id) {
      const bridgeName = await fetchBridgeGroupName(assigned_group_id);
      board_name = bridgeName ?? teamNameById(assigned_group_id) ?? board_name;
      tasks = await fetchBridgeTasks(assigned_group_id);
    }

    return json({
      found: true,
      response_id,
      candidate_name: chosen.candidate_name ?? null,
      candidate_email: chosen.candidate_email ?? null,
      position_title: chosen.position_title ?? null,
      assigned_agent: eb?.assigned_agent ?? null,
      board_name,
      team_name,
      instruction,
      daily_brief: (cfg as any)?.sylvia_daily_brief ?? null,
      onboarding_notes: eb?.onboarding_notes ?? null,
      onboarding_credentials: eb?.onboarding_credentials ?? null,
      tasks,
    });
  } catch (e: any) {
    return json({ error: String(e?.message || e) }, 500);
  }
});
