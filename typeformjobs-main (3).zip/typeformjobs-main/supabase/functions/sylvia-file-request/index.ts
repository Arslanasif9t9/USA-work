// sylvia-file-request: PUBLIC bridge for Sylvia (ElevenLabs WhatsApp agent).
// Auth: header x-sylvia-key compared to SYLVIA_BRIDGE_KEY (cloned from
// sylvia-lookup).
//
// REWORKED: instead of inserting a filed pending_approval request directly,
// this now mirrors the normal HR flow — it mints the SAME "invited"
// leave_requests row + token that send-leave-form / send-cash-advance-form
// create, and sends the SAME form-link email (via send-dual-email, reusing the
// identical sender templates). The employee then fills + signs the form
// themselves at /leave/:token or /cash-advance/:token.
//
// Returns { ok:true, form_link } so Sylvia can also hand the link over in chat.
//
// DO NOT TOUCH: send-leave-form, send-cash-advance-form, submit-leave,
// decide-* — this clones their internal logic, never modifies them.
import { createClient } from "npm:@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type, x-sylvia-key",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

const json = (body: unknown, status = 200) =>
  new Response(JSON.stringify(body), {
    status,
    headers: { ...corsHeaders, "Content-Type": "application/json" },
  });

const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
const SERVICE_KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
const BRIDGE_KEY = Deno.env.get("SYLVIA_BRIDGE_KEY")!;
const PUBLIC_BASE = "https://jobs.expertintuitiveadvisor.com";

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const escapeLike = (s: string) => s.replace(/[%_]/g, (m) => `\\${m}`);

function shortHex(n: number) {
  const bytes = new Uint8Array(n / 2);
  crypto.getRandomValues(bytes);
  return Array.from(bytes).map((b) => b.toString(16).padStart(2, "0")).join("");
}

// ── Email senders cloned verbatim from send-leave-form / send-cash-advance-form ──
function buildLeaveSenderA(firstName: string, link: string) {
  const text = `Hi ${firstName},

Please complete your leave request using the secure link below. Fill in all details, sign, and submit — your request will then be reviewed for approval.

OPEN YOUR LEAVE REQUEST FORM:
${link}

If you have any questions, simply reply to this email.

Angela Stein
HR — Talent Manager
Expert Intuitive Advisor Inc.`;
  const html = `<div style="font-family:Arial,sans-serif;font-size:14px;color:#1a2236;line-height:1.6;max-width:600px">
<p>Hi ${firstName},</p>
<p>Please complete your leave request using the secure link below. Fill in all details, sign, and submit — your request will then be reviewed for approval.</p>
<p><a href="${link}" style="display:inline-block;background:#1a2547;color:#ffffff;padding:12px 22px;border-radius:6px;text-decoration:none;font-weight:600">Open your leave request form</a></p>
<p style="font-size:12px;color:#666">Or paste this link into your browser:<br/><a href="${link}" style="color:#1a2547">${link}</a></p>
<p>If you have any questions, simply reply to this email.</p>
<p>Angela Stein<br/>HR — Talent Manager<br/>Expert Intuitive Advisor Inc.</p>
</div>`;
  return {
    from_name: "Angela Stein / HR — Talent Manager",
    from_address: "talent@expertintuitiveadvisor.com",
    subject: "Leave Request Form — please complete and submit (Expert Intuitive Advisor Inc.)",
    html_body: html,
    text_body: text,
  };
}

function buildLeaveSenderB(firstName: string, link: string) {
  const text = `Hi ${firstName},

Quick personal note — here's your leave request form link again so you don't have to dig:

${link}

Fill it in, sign, and submit when you can. If anything's unclear, just reply.

— Angela Stein`;
  const html = `<div style="font-family:Arial,sans-serif;font-size:14px;color:#1a2236;line-height:1.6;max-width:600px">
<p>Hi ${firstName},</p>
<p>Quick personal note — here's your leave request form link again so you don't have to dig:</p>
<p><a href="${link}" style="color:#1a2547">${link}</a></p>
<p>Fill it in, sign, and submit when you can. If anything's unclear, just reply.</p>
<p>— Angela Stein</p>
</div>`;
  return {
    from_name: "Angela Stein",
    from_address: "expertintuitiveadvisor@gmail.com",
    subject: "Your EIA leave request form",
    html_body: html,
    text_body: text,
  };
}

function buildCashSenderA(firstName: string, link: string) {
  const text = `Hi ${firstName},

Please complete your cash advance request using the secure link below. Fill in all details, sign, and submit — your request will then be reviewed for approval.

OPEN YOUR CASH ADVANCE REQUEST FORM:
${link}

If you have any questions, simply reply to this email.

Angela Stein
HR — Talent Manager
Expert Intuitive Advisor Inc.`;
  const html = `<div style="font-family:Arial,sans-serif;font-size:14px;color:#1a2236;line-height:1.6;max-width:600px">
<p>Hi ${firstName},</p>
<p>Please complete your cash advance request using the secure link below. Fill in all details, sign, and submit — your request will then be reviewed for approval.</p>
<p><a href="${link}" style="display:inline-block;background:#1a2547;color:#ffffff;padding:12px 22px;border-radius:6px;text-decoration:none;font-weight:600">Open your cash advance request form</a></p>
<p style="font-size:12px;color:#666">Or paste this link into your browser:<br/><a href="${link}" style="color:#1a2547">${link}</a></p>
<p>If you have any questions, simply reply to this email.</p>
<p>Angela Stein<br/>HR — Talent Manager<br/>Expert Intuitive Advisor Inc.</p>
</div>`;
  return {
    from_name: "Angela Stein / HR — Talent Manager",
    from_address: "talent@expertintuitiveadvisor.com",
    subject: "Cash Advance Request Form — please complete and submit (Expert Intuitive Advisor Inc.)",
    html_body: html,
    text_body: text,
  };
}

function buildCashSenderB(firstName: string, link: string) {
  const text = `Hi ${firstName},

Quick personal note — here's your cash advance request form link again so you don't have to dig:

${link}

Fill it in, sign, and submit when you can. If anything's unclear, just reply.

— Angela Stein`;
  const html = `<div style="font-family:Arial,sans-serif;font-size:14px;color:#1a2236;line-height:1.6;max-width:600px">
<p>Hi ${firstName},</p>
<p>Quick personal note — here's your cash advance request form link again so you don't have to dig:</p>
<p><a href="${link}" style="color:#1a2547">${link}</a></p>
<p>Fill it in, sign, and submit when you can. If anything's unclear, just reply.</p>
<p>— Angela Stein</p>
</div>`;
  return {
    from_name: "Angela Stein",
    from_address: "expertintuitiveadvisor@gmail.com",
    subject: "Your EIA cash advance request form",
    html_body: html,
    text_body: text,
  };
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });
  if (req.method !== "POST") return json({ ok: false, error: "method_not_allowed" }, 405);

  try {
    const sylviaKey = req.headers.get("x-sylvia-key");
    if (!sylviaKey || sylviaKey !== BRIDGE_KEY) return json({ ok: false, error: "unauthorized" }, 401);

    const body = await req.json().catch(() => ({}));
    const candidateEmail = typeof body?.candidate_email === "string" ? body.candidate_email.trim() : "";
    const candidateName = typeof body?.candidate_name === "string" ? body.candidate_name.trim() : "";
    const requestType = body?.request_type === "cash_advance" ? "cash_advance" : "leave";

    if (!candidateEmail && !candidateName) {
      return json({ ok: false, error: "missing_candidate", detail: "Provide candidate_email or candidate_name." }, 400);
    }

    const admin = createClient(SUPABASE_URL, SERVICE_KEY);

    // ── Resolve the employee (job_offers → responses), like sylvia-lookup. ──
    let offerQ = admin
      .from("job_offers")
      .select("candidate_id, candidate_name, candidate_email, override_email");
    if (candidateEmail) {
      const q = candidateEmail.toLowerCase();
      offerQ = offerQ.or(`candidate_email.ilike.${q},override_email.ilike.${q}`);
    } else {
      const nameWords = candidateName.toLowerCase().replace(/\s+/g, " ").split(" ").filter(Boolean);
      for (const w of nameWords) offerQ = offerQ.ilike("candidate_name", `%${escapeLike(w)}%`);
    }
    const { data: offers } = await offerQ
      .order("signed_at", { ascending: false, nullsFirst: false })
      .limit(5);

    let resolvedResponseId: string | null = null;
    let matchedResponseId: string | null = null;
    let signerName: string | null = candidateName || null;
    let signerEmail: string | null = candidateEmail && EMAIL_RE.test(candidateEmail) ? candidateEmail : null;

    const chosen = offers && offers.length ? offers[0] : null;
    if (chosen?.candidate_id) {
      signerName = chosen.candidate_name || signerName;
      signerEmail = signerEmail || chosen.candidate_email || chosen.override_email || null;
      const { data: resp } = await admin
        .from("responses")
        .select("id")
        .eq("applicant_id", chosen.candidate_id)
        .order("submitted_at", { ascending: false })
        .limit(1)
        .maybeSingle();
      resolvedResponseId = resp?.id ?? null;
      matchedResponseId = resp?.id ?? null;
    }

    if (!signerName) {
      return json({ ok: false, error: "no_name", detail: "Could not determine the employee's name." }, 400);
    }
    if (!signerEmail || !EMAIL_RE.test(signerEmail)) {
      return json({ ok: false, error: "no_email", detail: "Could not determine the employee's email to send the form link." }, 400);
    }

    // ── Mint the SAME invited row + token send-leave-form / send-cash-advance-form create. ──
    const reference = `${requestType === "cash_advance" ? "CASH" : "LEAVE"}-${shortHex(8).toUpperCase()}`;
    const token = shortHex(48);

    const insertRow: Record<string, unknown> = {
      response_id: resolvedResponseId,
      external_reference: reference,
      signer_name: signerName,
      signer_email: signerEmail,
      token,
      status: "invited",
      doc_type: requestType,
    };
    if (requestType === "cash_advance") {
      // send-cash-advance-form does not set leave_type
    } else {
      insertRow.leave_type = "general";
    }
    if (matchedResponseId) {
      insertRow.matched_response_id = matchedResponseId;
      insertRow.matched_at = new Date().toISOString();
    }

    const { error: insErr } = await admin.from("leave_requests").insert(insertRow);
    if (insErr) return json({ ok: false, error: "persist_failed", detail: insErr.message }, 500);

    // Read-after-write guard.
    const { data: verifyRow } = await admin
      .from("leave_requests")
      .select("id, token, doc_type, status, signer_name, signer_email, matched_response_id")
      .eq("external_reference", reference)
      .maybeSingle();
    if (!verifyRow) return json({ ok: false, error: "persist_failed", detail: "row not found after insert" }, 500);

    // ── Send the SAME form-link email via send-dual-email (identical templates). ──
    const routeBase = requestType === "cash_advance" ? "cash-advance" : "leave";
    const formLink = `${PUBLIC_BASE}/${routeBase}/${token}`;
    const firstName = signerName.trim().split(/\s+/)[0] || signerName;

    const stage = requestType === "cash_advance" ? "cash_advance_form_sent" : "leave_form_sent";
    const sender_a = requestType === "cash_advance"
      ? buildCashSenderA(firstName, formLink)
      : buildLeaveSenderA(firstName, formLink);
    const sender_b = requestType === "cash_advance"
      ? buildCashSenderB(firstName, formLink)
      : buildLeaveSenderB(firstName, formLink);

    const emailResp = await fetch(`${SUPABASE_URL}/functions/v1/send-dual-email`, {
      method: "POST",
      headers: { Authorization: `Bearer ${SERVICE_KEY}`, "Content-Type": "application/json" },
      body: JSON.stringify({ to: signerEmail, stage, sender_a, sender_b }),
    });
    const emailJson = await emailResp.json().catch(() => ({}));
    if (!emailResp.ok) {
      return json({
        ok: false,
        error: "email_failed",
        detail: emailJson,
        form_link: formLink,
        external_reference: reference,
      }, 502);
    }

    return json({
      ok: true,
      form_link: formLink,
      external_reference: reference,
      doc_type: verifyRow.doc_type,
      status: verifyRow.status,
      matched: !!verifyRow.matched_response_id,
    });
  } catch (e: any) {
    return json({ ok: false, error: "internal", detail: String(e?.message || e) }, 500);
  }
});
