// circular-draft-assist: HR-gated AI write-assist for the Circular Notice composer.
// Takes HR's rough idea (+ optional title) and returns a polished circular body in
// EIA's professional tone via the Lovable AI Gateway (model google/gemini-2.5-flash).
// Modeled on gemini-scope-suggest: same gateway, same key, same 429/402/timeout handling.
import { corsHeaders } from "npm:@supabase/supabase-js@2/cors";
import { createClient } from "npm:@supabase/supabase-js@2";

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });

  try {
    const authHeader = req.headers.get("Authorization");
    if (!authHeader?.startsWith("Bearer ")) {
      return json({ error: "Unauthorized" }, 401);
    }
    const supabase = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_ANON_KEY")!,
      { global: { headers: { Authorization: authHeader } } },
    );
    const token = authHeader.replace("Bearer ", "");
    const { data: claims, error: claimsErr } = await supabase.auth.getClaims(token);
    if (claimsErr || !claims?.claims) return json({ error: "Unauthorized" }, 401);

    const body = await req.json().catch(() => ({}));
    const idea = String(body?.idea ?? "").trim();
    const title = String(body?.title ?? "").trim();

    if (!idea || idea.length > 2000) {
      return json({ error: "idea required (max 2000 chars)" }, 400);
    }

    const LOVABLE_API_KEY = Deno.env.get("LOVABLE_API_KEY");
    if (!LOVABLE_API_KEY) return json({ error: "LOVABLE_API_KEY not configured" }, 500);

    const titleLine = title ? `\n\nThe notice title is: "${title}".` : "";
    const prompt = `You are an HR communications specialist at Expert Intuitive Advisor Inc. (EIA). Write the full body of a circular notice that will be sent to employees and signed by them.${titleLine}

HR's rough idea / instructions:
"""
${idea}
"""

Write a clear, professional circular notice body in EIA's corporate tone:
- Polished, courteous, and unambiguous; suitable for a formal company notice.
- Plain text only (no markdown, no headings with #, no bullet symbols unless natural). Use short paragraphs.
- Do NOT invent specific dates, names, figures, or policies that were not in HR's idea.
- Do NOT include a subject line or title (that is handled separately).
- Do NOT include a signature block or sign-off like "Angela Stein / HR" (that is added elsewhere).
- Return ONLY the notice body text.`;

    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 20_000);

    let aiResp: Response;
    try {
      aiResp = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
        method: "POST",
        signal: controller.signal,
        headers: {
          Authorization: `Bearer ${LOVABLE_API_KEY}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          model: "google/gemini-2.5-flash",
          messages: [
            { role: "system", content: "You write professional HR circular notices in plain text." },
            { role: "user", content: prompt },
          ],
        }),
      });
    } catch (e) {
      clearTimeout(timeout);
      if ((e as Error).name === "AbortError") {
        return json({ error: "AI draft timed out. Please try again." }, 504);
      }
      throw e;
    }
    clearTimeout(timeout);

    if (aiResp.status === 429) return json({ error: "Rate limit exceeded. Try again shortly." }, 429);
    if (aiResp.status === 402) return json({ error: "AI credits exhausted. Add credits in workspace settings." }, 402);
    if (!aiResp.ok) {
      const t = await aiResp.text();
      console.error("AI gateway error:", aiResp.status, t);
      return json({ error: "AI gateway error" }, 500);
    }

    const data = await aiResp.json();
    const draft = String(data?.choices?.[0]?.message?.content ?? "").trim();
    if (!draft) return json({ error: "AI returned an empty draft. Please try again." }, 502);

    return json({ draft });
  } catch (e) {
    console.error("circular-draft-assist error:", e);
    return json({ error: e instanceof Error ? e.message : "Unknown error" }, 500);
  }
});

function json(b: unknown, status = 200) {
  return new Response(JSON.stringify(b), {
    status,
    headers: { ...corsHeaders, "Content-Type": "application/json" },
  });
}
