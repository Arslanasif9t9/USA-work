// rematch-leave: admin-gated. Re-runs the shared matchLeaveToResponse helper
// against a single leave_requests row. Idempotent — if already matched, returns
// { ok:true, already:true } without touching the row.
import { createClient } from "npm:@supabase/supabase-js@2";
import { matchLeaveToResponse } from "../_shared/match-leave.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
const ANON = Deno.env.get("SUPABASE_ANON_KEY")!;
const SVC = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;

const json = (b: unknown, s = 200) =>
  new Response(JSON.stringify(b), { status: s, headers: { ...corsHeaders, "Content-Type": "application/json" } });

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });
  if (req.method !== "POST") return json({ ok: false, reason: "method_not_allowed" }, 405);

  const auth = req.headers.get("Authorization") || "";
  if (!auth.startsWith("Bearer ")) return json({ ok: false, reason: "missing_auth" }, 401);
  const userClient = createClient(SUPABASE_URL, ANON, { global: { headers: { Authorization: auth } } });
  const { data: u } = await userClient.auth.getUser();
  if (!u?.user) return json({ ok: false, reason: "invalid_jwt" }, 401);
  const admin = createClient(SUPABASE_URL, SVC);
  const { data: urow } = await admin.from("users").select("role").eq("id", u.user.id).maybeSingle();
  if (!urow || urow.role !== "admin") return json({ ok: false, reason: "forbidden" }, 403);

  let body: { leave_id?: string };
  try { body = await req.json(); } catch { return json({ ok: false, reason: "invalid_json" }, 400); }
  const leaveId = (body?.leave_id || "").trim();
  if (!leaveId) return json({ ok: false, reason: "missing_leave_id" }, 400);

  const { data: row, error } = await admin
    .from("leave_requests")
    .select("id, signer_email, matched_response_id")
    .eq("id", leaveId)
    .maybeSingle();
  if (error) return json({ ok: false, reason: "lookup_failed", detail: error.message }, 500);
  if (!row) return json({ ok: false, reason: "not_found" }, 404);

  if (row.matched_response_id) {
    return json({ ok: true, already: true, matched: true, response_id: row.matched_response_id });
  }

  const res = await matchLeaveToResponse(admin, row.id, row.signer_email || "");
  return json({ ok: true, already: false, matched: res.matched, response_id: res.response_id || null, reason: res.reason || null });
});
