import { createClient } from "npm:@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
const SUPABASE_ANON_KEY = Deno.env.get("SUPABASE_ANON_KEY")!;
const GMAIL_USER = (Deno.env.get("GMAIL_USER") ?? "").trim();
const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });

  const authHeader = req.headers.get("Authorization") || "";
  const token = authHeader.replace("Bearer ", "");
  if (!token) return new Response(JSON.stringify({ error: "Unauthorized" }), { status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" } });
  const sb = createClient(SUPABASE_URL, SUPABASE_ANON_KEY, { global: { headers: { Authorization: authHeader } } });
  const { data: claims, error: cErr } = await sb.auth.getClaims(token);
  if (cErr || !claims?.claims) return new Response(JSON.stringify({ error: "Unauthorized" }), { status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" } });

  const body = await req.json().catch(() => ({}));
  const to = body?.to;
  const breakResend = body?.break_resend === true;
  if (!EMAIL_RE.test(to || "")) return new Response(JSON.stringify({ error: "invalid 'to'" }), { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } });

  const payload = {
    to,
    stage: "test",
    _test_break_resend: breakResend,
    sender_a: {
      from_name: "Angela Stein / HR – Talent Manager",
      from_address: "talent@expertintuitiveadvisor.com",
      subject: "Application received — EIA Hiring Test",
      text_body: "This is a test email from the EIA Hiring System. Sender A: Resend via talent@.",
      html_body: "<p>This is a test email from the EIA Hiring System.</p><p><strong>Sender A: Resend via talent@</strong></p>",
    },
    sender_b: {
      from_name: "Angela Stein",
      from_address: GMAIL_USER,
      subject: "Quick note — EIA application",
      text_body: "Hey, just sending a quick note. This is a test from the EIA Hiring System. Sender B: Gmail SMTP.",
      html_body: "<p>Hey, just sending a quick note.</p><p>This is a test from the EIA Hiring System.</p><p><strong>Sender B: Gmail SMTP</strong></p>",
    },
  };

  const { data, error } = await sb.functions.invoke("send-dual-email", { body: payload });
  if (error) return new Response(JSON.stringify({ error: error.message, data }), { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } });
  return new Response(JSON.stringify(data), { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } });
});
