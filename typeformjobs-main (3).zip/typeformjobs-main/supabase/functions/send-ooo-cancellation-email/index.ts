// send-ooo-cancellation-email: warm apology + rebook link. Internal use.
const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};
const RESEND_API_KEY = Deno.env.get("RESEND_API_KEY")!;

const json = (b: unknown, s = 200) =>
  new Response(JSON.stringify(b), { status: s, headers: { ...corsHeaders, "Content-Type": "application/json" } });

function fmtManila(iso: string, opts: Intl.DateTimeFormatOptions) {
  return new Intl.DateTimeFormat("en-US", { timeZone: "Asia/Manila", ...opts }).format(new Date(iso));
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });
  try {
    const { to, candidate_name, original_slot_start, rebook_url, ooo_start, ooo_end } = await req.json();
    if (!to || !rebook_url) return json({ error: "missing_fields" }, 400);

    const origDate = original_slot_start ? fmtManila(original_slot_start, { weekday: "long", month: "long", day: "numeric", year: "numeric" }) : "";
    const origTime = original_slot_start ? fmtManila(original_slot_start, { hour: "numeric", minute: "2-digit", hour12: true }) : "";
    const name = candidate_name || "there";

    const html = `
      <div style="font-family:-apple-system,Segoe UI,Roboto,sans-serif;max-width:560px;margin:0 auto;color:#1a1a1a;line-height:1.55;">
        <p>Hi ${name},</p>
        <p>I'm Angela Stein from Expert Intuitive Advisor — and I'm so sorry for the inconvenience.</p>
        <p>Unfortunately, our team is unexpectedly out of office from <strong>${ooo_start}</strong> to <strong>${ooo_end}</strong>, which means we have to cancel your scheduled interview${origDate ? ` on <strong>${origDate}</strong> at <strong>${origTime}</strong>` : ""}. I know how disruptive this can be, and I truly appreciate your patience.</p>
        <p>The good news: you can rebook a new time slot right now using your private link below. It's valid for the next 3 days.</p>
        <p style="text-align:center;margin:28px 0;">
          <a href="${rebook_url}" style="background:#1e3a5f;color:#fff;text-decoration:none;padding:14px 28px;border-radius:8px;font-weight:600;display:inline-block;">Rebook My Interview</a>
        </p>
        <p style="color:#666;font-size:13px;">If the button doesn't work, copy & paste this link: <br/><a href="${rebook_url}">${rebook_url}</a></p>
        <p>Thank you so much for your understanding — we genuinely look forward to meeting you.</p>
        <p>Warmly,<br/><strong>Angela Stein</strong><br/>Expert Intuitive Advisor</p>
      </div>`;

    const res = await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: { Authorization: `Bearer ${RESEND_API_KEY}`, "Content-Type": "application/json" },
      body: JSON.stringify({
        from: "Angela Stein <talent@expertintuitiveadvisor.com>",
        to: [to],
        subject: "Important: We need to reschedule your interview",
        html,
      }),
    });
    const data = await res.json().catch(() => ({}));
    if (!res.ok) return json({ error: "send_failed", details: data }, 502);
    return json({ success: true, id: data?.id });
  } catch (e: any) {
    return json({ error: "internal", details: String(e?.message || e) }, 500);
  }
});
