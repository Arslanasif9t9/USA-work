// whatsapp-register-number: HR-authenticated, ADDITIVE one-shot admin tool to
// re-register the WhatsApp number with Meta's Graph API after two-step
// verification was turned OFF (composer fails with code 200 / "API access
// blocked.").
//
// FULLY INDEPENDENT — does NOT touch whatsapp-send-message / whatsapp-send-media /
// whatsapp-webhook-receiver. Reuses the same HR auth helpers as those functions.
//
// Reads secrets WHATSAPP_ACCESS_TOKEN + WHATSAPP_PHONE_NUMBER_ID (never hardcoded).
//
// Supported actions (body.action, or inferred):
//   "register"        (DEFAULT) → POST .../{PNID}/register { messaging_product, pin }
//   "request_code"               → POST .../{PNID}/request_code { code_method, language }
//   "verify_register" (when body.code present) → POST .../{PNID}/verify_code { code }
//                                                then POST .../{PNID}/register { messaging_product, pin }
//
// Every Meta call is console.log'd verbatim (status + body) and returned raw.
import { corsHeaders, json, requireHr } from "../_shared/hr-auth.ts";

const WHATSAPP_PHONE_NUMBER_ID = Deno.env.get("WHATSAPP_PHONE_NUMBER_ID")!;
const WHATSAPP_ACCESS_TOKEN = Deno.env.get("WHATSAPP_ACCESS_TOKEN")!;

const GRAPH = "https://graph.facebook.com/v21.0";

async function metaPost(endpoint: string, payload: Record<string, unknown>) {
  const url = `${GRAPH}/${WHATSAPP_PHONE_NUMBER_ID}/${endpoint}`;
  const res = await fetch(url, {
    method: "POST",
    headers: {
      Authorization: `Bearer ${WHATSAPP_ACCESS_TOKEN}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify(payload),
  });
  const body = await res.json().catch(() => ({}));
  const result = { endpoint, status: res.status, ok: res.ok, body };
  // Verbatim raw Meta response into the function logs.
  console.log("WA_REGISTER_RESPONSE", JSON.stringify(result));
  return result;
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });
  if (req.method !== "POST") return json({ error: "method_not_allowed" }, 405);

  const ident = await requireHr(req);
  if (ident instanceof Response) return ident;

  if (!WHATSAPP_PHONE_NUMBER_ID || !WHATSAPP_ACCESS_TOKEN) {
    return json({ error: "whatsapp_not_configured" }, 500);
  }

  try {
    const body = await req.json().catch(() => ({}));

    // PIN for registration. Two-step is OFF, but Meta's /register still requires
    // a 6-digit pin field — pass one in the body, else default to "000000".
    const pin: string =
      typeof body?.pin === "string" && /^\d{6}$/.test(body.pin) ? body.pin : "000000";

    const code: string | null =
      typeof body?.code === "string" && body.code.trim() ? body.code.trim() : null;

    const codeMethod: string =
      typeof body?.code_method === "string" && body.code_method.trim()
        ? body.code_method.trim()
        : "SMS";
    const language: string =
      typeof body?.language === "string" && body.language.trim()
        ? body.language.trim()
        : "en_US";

    // Infer the action: explicit body.action wins; otherwise a code => verify_register,
    // no code => register (Mode A default).
    const action: string =
      typeof body?.action === "string" && body.action.trim()
        ? body.action.trim()
        : code
        ? "verify_register"
        : "register";

    const phone_number_id = WHATSAPP_PHONE_NUMBER_ID;

    if (action === "request_code") {
      // MODE B step 1 — ask Meta to send a verification code.
      const requestCode = await metaPost("request_code", {
        code_method: codeMethod,
        language,
      });
      return json({ action, phone_number_id, pin_used: pin, request_code: requestCode });
    }

    if (action === "verify_register") {
      // MODE B step 2 — verify the code Meta sent, then register with the pin.
      if (!code) return json({ error: "code_required_for_verify_register" }, 400);
      const verify = await metaPost("verify_code", { code });
      const register = await metaPost("register", {
        messaging_product: "whatsapp",
        pin,
      });
      const success = register.ok && register.body?.success === true;
      return json({ action, phone_number_id, pin_used: pin, success, verify_code: verify, register });
    }

    // DEFAULT — MODE A: direct register with pin.
    const register = await metaPost("register", {
      messaging_product: "whatsapp",
      pin,
    });
    const success = register.ok && register.body?.success === true;
    return json({ action: "register", phone_number_id, pin_used: pin, success, register });
  } catch (e: any) {
    return json({ error: "unexpected", detail: String(e?.message || e) }, 500);
  }
});
