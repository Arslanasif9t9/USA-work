// save-progress: per-question autosave + final submission for the candidate form.
// Anon-callable. All writes go through service role so RLS stays tight.

import { createClient } from "https://esm.sh/@supabase/supabase-js@2.45.0";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

const json = (body: unknown, status = 200) =>
  new Response(JSON.stringify(body), {
    status,
    headers: { ...corsHeaders, "Content-Type": "application/json" },
  });

const sb = createClient(
  Deno.env.get("SUPABASE_URL")!,
  Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!,
  { auth: { persistSession: false } }
);

type Body = {
  session_token?: string;
  response_id?: string;
  form_id?: string;
  question_id?: string | null;
  answer_text?: string | null;
  file_url?: string | null;
  current_question_index?: number;
  complete?: boolean;
  abandon?: boolean;
  // metadata used only when completing
  candidate_name?: string | null;
  candidate_email?: string | null;
  slot_id?: string | null;
};

const newToken = () =>
  crypto.randomUUID() + "-" + crypto.randomUUID().slice(0, 8);

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });
  if (req.method !== "POST") return json({ error: "method_not_allowed" }, 405);

  let body: Body;
  try { body = await req.json(); } catch { return json({ error: "bad_json" }, 400); }

  // ── 1. Resolve or create the response row ────────────────────────────────
  let responseId = body.response_id;
  let sessionToken = body.session_token;

  if (!responseId) {
    if (!body.form_id) return json({ error: "form_id_required" }, 400);
    // Verify form is live
    const { data: form, error: fErr } = await sb
      .from("forms").select("id, status").eq("id", body.form_id).maybeSingle();
    if (fErr || !form || form.status !== "live") {
      return json({ error: "form_not_live" }, 400);
    }
    sessionToken = newToken();
    const newId = crypto.randomUUID();
    const { error: iErr } = await sb.from("responses").insert({
      id: newId,
      form_id: body.form_id,
      status: "in_progress",
      session_token: sessionToken,
      last_activity_at: new Date().toISOString(),
      current_question_index: 0,
    });
    if (iErr) {
      console.error("[save-progress] create response failed", iErr);
      return json({ error: "create_failed", detail: iErr.message }, 500);
    }
    responseId = newId;
  } else {
    // Validate session token matches
    if (!sessionToken) return json({ error: "session_token_required" }, 400);
    const { data: row, error } = await sb
      .from("responses")
      .select("id, session_token, status, form_id")
      .eq("id", responseId)
      .maybeSingle();
    if (error || !row) return json({ error: "response_not_found" }, 404);
    if (row.session_token !== sessionToken) {
      return json({ error: "session_token_mismatch" }, 403);
    }
    if (body.abandon) {
      await sb.from("responses").update({ status: "abandoned", last_activity_at: new Date().toISOString() }).eq("id", responseId);
      return json({ ok: true, response_id: responseId, session_token: sessionToken });
    }
    if (row.status === "completed") {
      return json({ error: "already_completed" }, 409);
    }
  }

  // ── 2. Upsert answer if provided ─────────────────────────────────────────
  if (body.question_id && (body.answer_text !== undefined || body.file_url !== undefined)) {
    const { error: aErr } = await sb.from("answers").upsert(
      {
        response_id: responseId,
        question_id: body.question_id,
        answer_text: body.answer_text ?? null,
        file_url: body.file_url ?? null,
      },
      { onConflict: "response_id,question_id" }
    );
    if (aErr) {
      console.error("[save-progress] upsert answer failed", { responseId, question_id: body.question_id, aErr });
      return json({ error: "answer_save_failed", detail: aErr.message }, 500);
    }
  }

  // ── 3. Update activity / index / completion ──────────────────────────────
  const patch: Record<string, any> = { last_activity_at: new Date().toISOString() };
  if (typeof body.current_question_index === "number") {
    patch.current_question_index = body.current_question_index;
  }
  if (body.complete) {
    patch.status = "completed";
    patch.submitted_at = new Date().toISOString();
  }
  const { error: uErr } = await sb.from("responses").update(patch).eq("id", responseId);
  if (uErr) {
    console.error("[save-progress] update response failed", { responseId, uErr });
    return json({ error: "update_failed", detail: uErr.message }, 500);
  }

  // ── 4. On completion: book slot if requested, fire stage-1 email ─────────
  let booking: { display_date: string; display_time: string } | null = null;
  if (body.complete && body.slot_id) {
    try {
      const { data: bk, error: bkErr } = await sb.functions.invoke<{
        success: boolean; display_date: string; display_time: string;
      }>("book-slot", {
        body: {
          slot_id: body.slot_id,
          response_id: responseId,
          candidate_name: body.candidate_name || body.candidate_email || "Candidate",
          candidate_email: body.candidate_email || null,
        },
      });
      if (bkErr || !bk?.success) {
        console.error("[save-progress] book-slot failed", { responseId, slot_id: body.slot_id, bkErr, bk });
        // Roll status back so candidate can retry
        await sb.from("responses").update({ status: "in_progress" }).eq("id", responseId);
        return json({ error: "booking_failed" }, 409);
      }
      booking = { display_date: bk.display_date, display_time: bk.display_time };
    } catch (err: any) {
      console.error("[save-progress] book-slot threw", { responseId, err: String(err) });
      await sb.from("responses").update({ status: "in_progress" }).eq("id", responseId);
      return json({ error: "booking_unavailable" }, 503);
    }
  }

  if (body.complete) {
    // Fire-and-forget stage-1 email
    sb.functions.invoke("auto-send-stage-1", { body: { response_id: responseId } })
      .catch((e) => console.warn("auto-send-stage-1 failed", e));
  }

  return json({
    ok: true,
    response_id: responseId,
    session_token: sessionToken,
    booking,
  });
});
