// Marks in_progress responses as abandoned after 24h. Invoked by pg_cron daily.

import { createClient } from "https://esm.sh/@supabase/supabase-js@2.45.0";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

const sb = createClient(
  Deno.env.get("SUPABASE_URL")!,
  Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!,
  { auth: { persistSession: false } }
);

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });

  const cutoff = new Date(Date.now() - 24 * 3600 * 1000).toISOString();
  const { data, error } = await sb
    .from("responses")
    .update({ status: "abandoned" })
    .eq("status", "in_progress")
    .lt("last_activity_at", cutoff)
    .select("id");

  if (error) {
    console.error("[mark-abandoned] failed", error);
    return new Response(JSON.stringify({ error: error.message }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
  console.log(`[mark-abandoned] flipped ${data?.length || 0} responses to abandoned`);
  return new Response(JSON.stringify({ count: data?.length || 0 }), {
    headers: { ...corsHeaders, "Content-Type": "application/json" },
  });
});
