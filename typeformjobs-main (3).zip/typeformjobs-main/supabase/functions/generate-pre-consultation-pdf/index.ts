// generate-pre-consultation-pdf: builds a "Psychic John"-branded Pre-Consultation
// Acknowledgment & Service Agreement PDF for a leave_requests row
// (doc_type='pre_consultation'), uploads to the public `offer-letters` bucket
// under pre-consultation/, returns the URL. Auth: accepts the service-role token
// (so decide-pre-consultation can call it) OR an admin user JWT.
// SEPARATE clone of generate-cash-advance-pdf.
import { createClient } from "npm:@supabase/supabase-js@2";
import { buildPreConsultationPdf, type PreConsultationData } from "../_shared/pre-consultation-pdf.ts";
import { uploadPdf } from "../_shared/offer-pdf.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
const ANON = Deno.env.get("SUPABASE_ANON_KEY")!;
const SVC = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;

const json = (b: unknown, status = 200) =>
  new Response(JSON.stringify(b), {
    status,
    headers: { ...corsHeaders, "content-type": "application/json" },
  });

async function authorize(req: Request): Promise<Response | null> {
  const auth = req.headers.get("Authorization") || "";
  if (!auth.startsWith("Bearer ")) return json({ error: "missing_auth" }, 401);
  const token = auth.slice(7).trim();
  if (token === SVC) return null;
  const userClient = createClient(SUPABASE_URL, ANON, { global: { headers: { Authorization: auth } } });
  const { data: u } = await userClient.auth.getUser();
  if (!u?.user) return json({ error: "invalid_jwt" }, 401);
  const admin = createClient(SUPABASE_URL, SVC);
  const { data: row } = await admin.from("users").select("role").eq("id", u.user.id).maybeSingle();
  if (!row || row.role !== "admin") return json({ error: "forbidden" }, 403);
  return null;
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });
  const guard = await authorize(req);
  if (guard) return guard;

  let body: { leave_request_id?: string };
  try { body = await req.json(); } catch { return json({ error: "invalid_json" }, 400); }
  const { leave_request_id } = body || {};
  if (!leave_request_id) return json({ error: "missing_leave_request_id" }, 400);

  const admin = createClient(SUPABASE_URL, SVC);
  const { data: row, error } = await admin
    .from("leave_requests")
    .select("*")
    .eq("id", leave_request_id)
    .maybeSingle();
  if (error) return json({ error: "lookup_failed", detail: error.message }, 500);
  if (!row) return json({ error: "not_found" }, 404);

  const r = row as any;
  const data: PreConsultationData = {
    signer_name: r.signer_name || r.typed_name || "Client",
    reference: r.external_reference,
    pc_amount: r.pc_amount,
    pc_duration: r.pc_duration,
    pc_preferred_time: r.pc_preferred_time,
    typed_name: r.typed_name,
    signature_data: r.signature_data,
    signature_date: r.signature_date,
    status: r.status,
    hr_decision_note: r.hr_decision_note,
    decided_at: r.decided_at,
  };

  let out;
  try {
    out = await buildPreConsultationPdf(data);
  } catch (e) {
    return json({ error: "pdf_build_failed", detail: (e as Error).message }, 500);
  }

  const lastName = (data.signer_name || "Client").trim().split(/\s+/).slice(-1)[0]?.replace(/[^A-Za-z0-9_-]/g, "_") || "Client";
  const filename = `pre-consultation/${data.reference}-${lastName}.pdf`;
  const up = await uploadPdf(out.bytes, filename);
  if (!up.url) return json({ error: "upload_failed", detail: up.error }, 500);

  return json({
    success: true,
    pdf_url: up.url,
    filename,
    page_count: out.pageCount,
    font_warning: out.warning,
  });
});
