// send-welcome-email-universal: admin-gated universal sender. Sends the SAME
// branded EIA welcome email that send-sylvia-welcome sends (NAVY/GOLD/Cormorant
// card, Angela Stein / HR signature, Sylvia WhatsApp line) to ANY name + email,
// plus a Position line. No system lookup — uses what HR enters verbatim.
// Additive — does NOT replace or touch the per-row send-sylvia-welcome flow.
import { createClient } from "npm:@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
const ANON = Deno.env.get("SUPABASE_ANON_KEY")!;
const SVC = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
const RESEND_API_KEY = Deno.env.get("RESEND_API_KEY")!;

// Same sender constants as send-sylvia-welcome.
const FROM = "Angela Stein / HR – Talent Manager <talent@expertintuitiveadvisor.com>";
const FROM_ADDR = "talent@expertintuitiveadvisor.com";
const FROM_NAME = "Angela Stein / HR – Talent Manager";

const NAVY = "#1a2547";
const GOLD = "#b08d57";
const SYLVIA_WA = "+1 917 735 8220";

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

const json = (b: unknown, status = 200) =>
  new Response(JSON.stringify(b), {
    status,
    headers: { ...corsHeaders, "content-type": "application/json" },
  });

function welcomeHtml(firstName: string, position: string) {
  const positionRow = position
    ? `<p style="font-size:15px;line-height:1.6;color:${NAVY};margin:0 0 14px 0"><strong>Position:</strong> ${position}</p>`
    : "";
  return `<!doctype html><html><body style="margin:0;padding:0;background:#faf8f3;font-family:Inter,Arial,sans-serif;color:${NAVY}">
  <table width="100%" cellpadding="0" cellspacing="0" style="background:#faf8f3;padding:32px 0">
    <tr><td align="center">
      <table width="560" cellpadding="0" cellspacing="0" style="background:#ffffff;border-top:4px solid ${GOLD};padding:32px 32px 28px 32px">
        <tr><td>
          <div style="font-family:'Cormorant Garamond',Georgia,serif;font-size:26px;color:${NAVY};font-weight:600;margin-bottom:6px">
            Welcome to Expert Intuitive Advisor, ${firstName}
          </div>
          <div style="font-size:11px;letter-spacing:3px;text-transform:uppercase;color:${GOLD};margin-bottom:16px">
            Your Onboarding Starts Now
          </div>
          ${positionRow}
          <p style="font-size:15px;line-height:1.6;color:${NAVY};margin:0 0 14px 0">
            Congratulations and welcome to the team. We are glad to have you with us.
          </p>
          <p style="font-size:15px;line-height:1.6;color:${NAVY};margin:0 0 14px 0">
            Your onboarding will be guided by <strong>Sylvia</strong>, our onboarding specialist. She will reach out to you personally on WhatsApp to walk you through your first steps, answer your questions, and get you set up.
          </p>
          <p style="font-size:15px;line-height:1.6;color:${NAVY};margin:0 0 14px 0">
            We use WhatsApp for all professional communication. If you do not already have it, please download WhatsApp on your phone — our onboarding specialist will personally guide you there.
          </p>
          <p style="font-size:15px;line-height:1.6;color:${NAVY};margin:18px 0 10px 0;font-weight:600">
            Please do this now so she can reach you:
          </p>
          <ol style="font-size:15px;line-height:1.7;color:${NAVY};margin:0 0 14px 22px;padding:0">
            <li>Save this WhatsApp number to your contacts: <strong style="color:${NAVY}">${SYLVIA_WA}</strong> (Sylvia — Expert Intuitive Advisor)</li>
            <li>Make sure WhatsApp is installed on your phone.</li>
            <li>Watch for her message — she will contact you shortly.</li>
          </ol>
          <p style="font-size:14px;line-height:1.6;color:${NAVY};margin:16px 0 0 0">
            If you do not hear from her, message that number on WhatsApp and say you are a new hire starting onboarding.
          </p>
          <p style="font-size:15px;line-height:1.6;color:${NAVY};margin:18px 0 0 0">
            We are looking forward to working with you.
          </p>
          <p style="font-size:14px;line-height:1.6;color:${NAVY};margin:24px 0 0 0">
            Warm regards,<br/>
            <span style="color:${GOLD}">The Expert Intuitive Advisor Team</span>
          </p>
        </td></tr>
      </table>
    </td></tr>
  </table>
  </body></html>`;
}

function welcomeText(firstName: string, position: string) {
  const positionLine = position ? `Position: ${position}\n\n` : "";
  return `Hi ${firstName},

${positionLine}Congratulations and welcome to the team. We are glad to have you with us.

Your onboarding will be guided by Sylvia, our onboarding specialist. She will reach out to you personally on WhatsApp to walk you through your first steps, answer your questions, and get you set up.

We use WhatsApp for all professional communication. If you do not already have it, please download WhatsApp on your phone — our onboarding specialist will personally guide you there.

Please do this now so she can reach you:
1. Save this WhatsApp number to your contacts: ${SYLVIA_WA} (Sylvia — Expert Intuitive Advisor)
2. Make sure WhatsApp is installed on your phone.
3. Watch for her message — she will contact you shortly.

If you do not hear from her, message that number on WhatsApp and say you are a new hire starting onboarding.

We are looking forward to working with you.

Warm regards,
The Expert Intuitive Advisor Team`;
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });
  if (req.method !== "POST") return json({ ok: false, reason: "method_not_allowed" }, 405);

  // Admin gate (mirrors send-pre-consultation-form / send-cash-advance-form).
  const auth = req.headers.get("Authorization") || "";
  if (!auth.startsWith("Bearer ")) return json({ ok: false, reason: "missing_auth" }, 401);
  const userClient = createClient(SUPABASE_URL, ANON, { global: { headers: { Authorization: auth } } });
  const { data: u } = await userClient.auth.getUser();
  if (!u?.user) return json({ ok: false, reason: "invalid_jwt" }, 401);
  const admin = createClient(SUPABASE_URL, SVC);
  const { data: urow } = await admin.from("users").select("role").eq("id", u.user.id).maybeSingle();
  if (!urow || urow.role !== "admin") return json({ ok: false, reason: "forbidden" }, 403);

  let body: { name?: string; email?: string; position?: string };
  try { body = await req.json(); } catch { return json({ ok: false, reason: "invalid_json" }, 400); }

  const name = (body.name || "").trim();
  const email = (body.email || "").trim();
  const position = (body.position || "").trim();

  if (!name) return json({ ok: false, reason: "missing_name" }, 400);
  if (!email || !EMAIL_RE.test(email)) return json({ ok: false, reason: "invalid_email" }, 400);

  const firstName = (name.split(" ")[0] || "there").trim();
  const subject = "Welcome to Expert Intuitive Advisor — Your Onboarding Starts Now";
  const html = welcomeHtml(firstName, position);
  const text = welcomeText(firstName, position);

  let sendRes: Response;
  let sendJson: any = {};
  try {
    sendRes = await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: { "Content-Type": "application/json", Authorization: `Bearer ${RESEND_API_KEY}` },
      body: JSON.stringify({ from: FROM, to: [email], subject, html, text }),
    });
    sendJson = await sendRes.json().catch(() => ({}));
  } catch (e) {
    await admin.from("email_log").insert({
      candidate_id: null,
      stage: "welcome_email",
      sender: "resend",
      from_address: FROM_ADDR,
      from_name: FROM_NAME,
      to_address: email,
      subject,
      status: "failed",
      sent_at: null,
      resend_message_id: null,
      error_message: String((e as any)?.message || e),
    });
    return json({ ok: false, reason: "send_failed" });
  }

  const now = new Date().toISOString();
  await admin.from("email_log").insert({
    candidate_id: null,
    stage: "welcome_email",
    sender: "resend",
    from_address: FROM_ADDR,
    from_name: FROM_NAME,
    to_address: email,
    subject,
    status: sendRes.ok ? "sent" : "failed",
    sent_at: sendRes.ok ? now : null,
    resend_message_id: sendJson?.id ?? null,
    error_message: sendRes.ok ? null : JSON.stringify(sendJson),
  });

  if (!sendRes.ok) return json({ ok: false, reason: sendJson?.message || "send_failed" });
  return json({ ok: true, to: email });
});
