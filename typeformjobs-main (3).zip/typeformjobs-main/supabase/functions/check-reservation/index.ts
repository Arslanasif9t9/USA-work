// check-reservation: PUBLIC. Confirms whether a slot's reservation is still active.
import { createClient } from "npm:@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

const UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });
  const admin = createClient(
    Deno.env.get("SUPABASE_URL")!,
    Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!,
  );

  let body: { slot_id?: string };
  try { body = await req.json(); } catch {
    return new Response(JSON.stringify({ error: "invalid_json" }), {
      status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
  const slotId = body.slot_id;
  if (!slotId || !UUID_RE.test(slotId)) {
    return new Response(JSON.stringify({ error: "invalid_slot_id" }), {
      status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }

  const { data: slot, error } = await admin
    .from("interview_slots")
    .select("id, status, reserved_until")
    .eq("id", slotId)
    .maybeSingle();
  if (error || !slot) {
    return new Response(JSON.stringify({ valid: false, reason: "not_found" }), {
      status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }

  const now = Date.now();
  const ru = slot.reserved_until ? new Date(slot.reserved_until).getTime() : 0;
  const valid = slot.status === "reserved" && ru > now;
  const seconds_remaining = valid ? Math.max(0, Math.floor((ru - now) / 1000)) : 0;

  return new Response(JSON.stringify({
    valid,
    status: slot.status,
    reserved_until: slot.reserved_until,
    seconds_remaining,
  }), { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } });
});
