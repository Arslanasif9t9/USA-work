// rescue-interview-email: HR-authenticated SECOND-CHANCE re-engagement. Cloned
// verbatim from recover-interview-email's mechanics — it re-mints a FRESH
// rebook_token for the candidate's current round (round_1_sent → Christine;
// round_2_sent → Marissa) with a read-after-write guard, then emails a WARM,
// genuine second-chance reminder via Resend (verified sender Angela Stein / HR).
// Logs to email_log with stage 'rescue_interview'. Reads override_email first.
//
// Differences from recover-interview-email (the only additions):
//   - body param interview_duration_label (the early-exit duration to reference)
//   - body param hr_remark (optional free-text note shown in a labeled block)
//   - distinct warm "second chance" copy + email_log stage 'rescue_interview'.
//
// This function does NOT touch the answers table, never cascades, and writes
// single rows by id.
import { adminClient, corsHeaders, json, requireHr } from "../_shared/hr-auth.ts";

const RESEND_API_KEY = Deno.env.get("RESEND_API_KEY")!;
const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

const DURATION_LABELS = new Set([
  "under 1 minute", "1 minute", "2 minutes", "3 minutes",
  "4 minutes", "5 minutes", "6 minutes",
]);

function genToken() {
  const bytes = crypto.getRandomValues(new Uint8Array(24));
  return Array.from(bytes).map((b) => b.toString(16).padStart(2, "0")).join("");
}

// Minimal HTML escape for the optional free-text HR remark.
function esc(s: string) {
  return s
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });

  const ident = await requireHr(req);
  if (ident instanceof Response) return ident;
  if (!ident.hrId) return json({ error: "no_hr_profile" }, 403);

  const body = await req.json().catch(() => ({}));
  const responseId: string | undefined = body?.response_id;
  const overrideEmailRaw: string = typeof body?.override_email === "string" ? body.override_email.trim() : "";
  const durationLabelRaw: string = typeof body?.interview_duration_label === "string"
    ? body.interview_duration_label.trim()
    : "";
  const hrRemarkRaw: string = typeof body?.hr_remark === "string" ? body.hr_remark.trim() : "";
  // Additive: HR can force which round to rescue (matches the visible Scout tab).
  // 1 → Christine R1 link; 2 → Marissa Round 2 link. Falls back to derivation.
  const forceRound: 1 | 2 | null = body?.force_round === 1 || body?.force_round === 2 ? body.force_round : null;

  if (!responseId) return json({ error: "missing_response_id" }, 400);
  if (overrideEmailRaw && !EMAIL_RE.test(overrideEmailRaw)) return json({ error: "invalid_email" }, 400);
  if (durationLabelRaw && !DURATION_LABELS.has(durationLabelRaw)) {
    return json({ error: "invalid_duration_label" }, 400);
  }
  const durationLabel = durationLabelRaw || "a short time";
  const hrRemark = hrRemarkRaw.slice(0, 1000);

  const admin = adminClient();

  // Global interview mode (for round 1 link shape). Default 'ai_direct'.
  let interviewMode: string = "ai_direct";
  try {
    const { data: cfg } = await admin
      .from("scheduling_config")
      .select("interview_mode")
      .eq("id", 1)
      .maybeSingle();
    if (cfg?.interview_mode === "ai_direct" || cfg?.interview_mode === "ai_scheduled") {
      interviewMode = cfg.interview_mode;
    }
  } catch (_) { /* default */ }

  // Load response → round_stage decides which round to re-invite.
  const { data: resp } = await admin
    .from("responses")
    .select("id, form_id, applicant_id, override_email, override_name, round_stage, appointment_cancelled, disqualified_at")
    .eq("id", responseId)
    .maybeSingle();
  if (!resp) return json({ error: "response_not_found" }, 404);

  // Guard: never rescue a disqualified candidate (kept exactly as-is).
  if (resp.disqualified_at || resp.round_stage === "disqualified") {
    return json({ error: "not_recoverable", reason: "disqualified" }, 409);
  }

  // Round derivation (WIDENED): direct stages map first; otherwise derive from
  // which round was actually sent (candidate_actions.round2_sent_at / round1_sent_at).
  // This lets HR rescue candidates whose interview already completed
  // (round_stage === 'ai_interview_completed') and any other non-disqualified
  // stage that has a recorded round send.
  let round: 1 | 2 | null =
    forceRound ??
    (resp.round_stage === "round_2_sent" ? 2 :
     resp.round_stage === "round_1_sent" ? 1 : null);

  if (!round) {
    const { data: actions } = await admin
      .from("candidate_actions")
      .select("round1_sent_at, round2_sent_at, round1_status, round2_status")
      .eq("response_id", responseId)
      .maybeSingle();

    const round2Sent = !!(actions?.round2_sent_at) || actions?.round2_status === "sent";
    const round1Sent = !!(actions?.round1_sent_at) || actions?.round1_status === "sent";

    if (round2Sent) round = 2;
    else if (round1Sent) round = 1;
  }

  if (!round) {
    return json({ error: "not_recoverable", reason: "not_invited", stage: resp.round_stage }, 409);
  }

  // Persist override email if HR supplied one (single-row update by id).
  if (overrideEmailRaw) {
    await admin.from("responses").update({ override_email: overrideEmailRaw }).eq("id", responseId);
  }

  // Resolve candidate name + email by LABEL match (never positional).
  const { data: qs } = await admin.from("questions")
    .select("id, type, label").eq("form_id", resp.form_id);
  const { data: ans } = await admin.from("answers")
    .select("question_id, answer_text").eq("response_id", responseId);

  const findByLabel = (re: RegExp) => qs?.find((q: any) => re.test(q.label || ""));
  const emailQ = findByLabel(/e[-\s]?mail/i) || qs?.find((q: any) => q.type === "email");
  const nameQ = findByLabel(/(full\s*name|first\s*name|your\s*name|\bname\b)/i)
    || qs?.find((q: any) => q.type === "short_text");
  const answerFor = (qid?: string) =>
    qid ? (ans?.find((a: any) => a.question_id === qid)?.answer_text || "").trim() : "";

  const candidateEmail = overrideEmailRaw
    || (resp.override_email || "").trim()
    || answerFor(emailQ?.id);
  const candidateName = (resp.override_name || "").trim()
    || answerFor(nameQ?.id)
    || "there";

  if (!candidateEmail || !EMAIL_RE.test(candidateEmail)) {
    return json({ error: "missing_email", message: "Add an email for this candidate first." }, 400);
  }

  // Round 1 token stage depends on global interview mode (matches send-round-invite):
  //   ai_direct    → "round1"        (/ai-interview/:token, Christine direct)
  //   ai_scheduled → "ai_scheduled"  (/rebook/:token → rebook-confirm-ai)
  // Round 2 is AI-only (Marissa) → "round2_ai" (/ai-interview/:token).
  const round1Stage = interviewMode === "ai_scheduled" ? "ai_scheduled" : "round1";
  const tokenStage = round === 1 ? round1Stage : "round2_ai";

  // For Round 2 (Marissa), carry over the same dynamic data the Round 2 invite
  // used (salary + schedule) so Marissa greets the candidate correctly. Read it
  // from the most recent round2_ai token BEFORE we invalidate it below.
  let marissaSalary: string | null = null;
  let marissaSchedule: string | null = null;
  if (round === 2) {
    const { data: prevTok } = await admin
      .from("rebook_tokens")
      .select("marissa_salary, marissa_schedule")
      .eq("response_id", responseId)
      .eq("stage", "round2_ai")
      .order("created_at", { ascending: false })
      .limit(1)
      .maybeSingle();
    marissaSalary = prevTok?.marissa_salary ?? null;
    marissaSchedule = prevTok?.marissa_schedule ?? null;
  }

  // Idempotency: invalidate any prior unused token for this response+stage.
  await admin.from("rebook_tokens").update({
    expires_at: new Date(Date.now() - 1000).toISOString(),
  })
    .eq("response_id", responseId)
    .eq("stage", tokenStage)
    .is("used_at", null);

  // Mint fresh token, then VERIFY persistence BEFORE sending the email.
  const token = genToken();
  const insertPayload: Record<string, unknown> = {
    token,
    response_id: responseId,
    stage: tokenStage,
    form_id: resp.form_id,
    assigned_hr_id: ident.hrId,
    candidate_name: candidateName,
    candidate_email: candidateEmail,
  };
  if (round === 2) {
    if (marissaSalary) insertPayload.marissa_salary = marissaSalary;
    if (marissaSchedule) insertPayload.marissa_schedule = marissaSchedule;
  }
  const { error: tokInsErr } = await admin.from("rebook_tokens").insert(insertPayload);
  if (tokInsErr) {
    console.error("rebook_tokens insert failed", tokInsErr);
    return json({ error: "token_persist_failed", details: tokInsErr.message }, 500);
  }
  // Read-after-write sanity check.
  const { data: tokCheck } = await admin
    .from("rebook_tokens").select("token").eq("token", token).maybeSingle();
  if (!tokCheck) {
    console.error("rebook_tokens read-after-write missing", { token });
    return json({ error: "token_not_persisted" }, 500);
  }

  // Always build candidate links on the fixed public domain.
  const PUBLIC_BASE_URL = "https://jobs.expertintuitiveadvisor.com";
  const bookingUrl = `${PUBLIC_BASE_URL}/rebook/${token}`;
  const aiInterviewUrl = `${PUBLIC_BASE_URL}/ai-interview/${token}`;
  const round1Url = interviewMode === "ai_scheduled" ? bookingUrl : aiInterviewUrl;
  const rescueUrl = round === 1 ? round1Url : aiInterviewUrl;

  // Position title (for the email body)
  let positionTitle = "the role";
  const { data: meta } = await admin.from("form_metadata")
    .select("position_title").eq("form_id", resp.form_id).maybeSingle();
  if (meta?.position_title) positionTitle = meta.position_title;

  const firstName = (candidateName || "there").split(" ")[0];
  const interviewerName = round === 2 ? "Marissa" : "Christine";

  const subject = `One more chance to finish your interview — Expert Intuitive Advisor`;

  const remarkBlockHtml = hrRemark
    ? `<div style="margin:20px 0; padding:14px 16px; background:#faf8f3; border-left:3px solid #b08d57; border-radius:6px;">
  <p style="margin:0 0 6px; font-weight:600; color:#1a2547; font-size:14px;">A note from our team:</p>
  <p style="margin:0; color:#4b5563; font-size:14px;">${esc(hrRemark)}</p>
</div>`
    : "";

  const html = `<div style="font-family: Arial, Helvetica, sans-serif; color:#1a2547; font-size:15px; line-height:1.6; max-width:560px;">
<p>Hi ${firstName},</p>
<p>We noticed that your interview with ${interviewerName} for the <strong>${positionTitle}</strong> position ended after about <strong>${durationLabel}</strong>.</p>
<p>No problem at all — these things happen, and we'd genuinely like to give you another chance to complete it. It only takes about 7 minutes, right here in your browser — no scheduling, no download. Our team reviews every interview personally.</p>
${remarkBlockHtml}
<p style="text-align:center; margin:28px 0;">
  <a href="${rescueUrl}" style="display:inline-block; background:#1a2547; color:#ffffff; text-decoration:none; font-weight:600; font-size:16px; padding:14px 28px; border-radius:8px;">Continue your interview</a>
</p>
<p>There are no trick questions — just a friendly conversation. Take your time and answer naturally. You'll only need a quiet spot with a working camera and microphone.</p>
<p style="color:#6b7280; font-size:13px;">If the button doesn't work, copy and paste this link into your browser:<br/>
<a href="${rescueUrl}" style="color:#1a2547;">${rescueUrl}</a></p>
<p style="color:#6b7280; font-size:13px;">This link expires in 3 days.</p>
<p style="margin-top:24px;">Warmly,<br/>
<strong>Angela Stein</strong><br/>
HR — Talent Manager<br/>
Expert Intuitive Advisor Inc.</p>
</div>`;

  const remarkBlockText = hrRemark ? `\nA note from our team:\n${hrRemark}\n` : "";

  const text = `Hi ${firstName},

We noticed that your interview with ${interviewerName} for the ${positionTitle} position ended after about ${durationLabel}.

No problem at all — these things happen, and we'd genuinely like to give you another chance to complete it. It only takes about 7 minutes, right here in your browser — no scheduling, no download. Our team reviews every interview personally.
${remarkBlockText}
Continue your interview:
${rescueUrl}

There are no trick questions — just a friendly conversation. Take your time and answer naturally. You'll only need a quiet spot with a working camera and microphone.

This link expires in 3 days.

Warmly,
Angela Stein
HR — Talent Manager
Expert Intuitive Advisor Inc.`;

  let emailOk = false;
  let resendId: string | null = null;
  let errorMessage: string | null = null;
  try {
    const r = await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: { "Content-Type": "application/json", Authorization: `Bearer ${RESEND_API_KEY}` },
      body: JSON.stringify({
        from: "Angela Stein / HR – Talent Manager <talent@expertintuitiveadvisor.com>",
        to: [candidateEmail], subject, html, text,
      }),
    });
    const j = await r.json().catch(() => ({}));
    emailOk = r.ok;
    resendId = j?.id ?? null;
    if (!r.ok) errorMessage = JSON.stringify(j).slice(0, 500);
  } catch (e: any) {
    errorMessage = String(e?.message || e);
  }

  await admin.from("email_log").insert({
    candidate_id: resp.applicant_id ?? null,
    stage: "rescue_interview",
    sender: "resend",
    from_address: "talent@expertintuitiveadvisor.com",
    from_name: "Angela Stein / HR – Talent Manager",
    to_address: candidateEmail,
    subject,
    status: emailOk ? "sent" : "failed",
    sent_at: emailOk ? new Date().toISOString() : null,
    resend_message_id: resendId,
    error_message: emailOk ? null : errorMessage,
  });

  if (!emailOk) {
    return json({ error: "email_failed", details: errorMessage }, 502);
  }

  return json({ success: true, rescue_url: rescueUrl, candidate_email: candidateEmail, round });
});
