import { corsHeaders } from "npm:@supabase/supabase-js@2/cors";
import { createClient } from "npm:@supabase/supabase-js@2";

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });

  try {
    const authHeader = req.headers.get("Authorization");
    if (!authHeader?.startsWith("Bearer ")) {
      return json({ error: "Unauthorized" }, 401);
    }
    const supabase = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_ANON_KEY")!,
      { global: { headers: { Authorization: authHeader } } },
    );
    const token = authHeader.replace("Bearer ", "");
    const { data: claims, error: claimsErr } = await supabase.auth.getClaims(token);
    if (claimsErr || !claims?.claims) return json({ error: "Unauthorized" }, 401);

    const body = await req.json().catch(() => ({}));
    const position_title = String(body?.position_title ?? "").trim();
    const existing_items: string[] = Array.isArray(body?.existing_items)
      ? body.existing_items.filter((x: unknown) => typeof x === "string")
      : [];
    const excluded_items: string[] = Array.isArray(body?.excluded_items)
      ? body.excluded_items.filter((x: unknown) => typeof x === "string")
      : [];

    if (!position_title || position_title.length > 200) {
      return json({ error: "position_title required (max 200 chars)" }, 400);
    }

    const LOVABLE_API_KEY = Deno.env.get("LOVABLE_API_KEY");
    if (!LOVABLE_API_KEY) return json({ error: "LOVABLE_API_KEY not configured" }, 500);

    const excludedAll = [...existing_items, ...excluded_items];
    const excludedList = excludedAll.length
      ? `\n\nDo NOT suggest any of these (already covered or shown):\n${excludedAll.map((s) => `- ${s}`).join("\n")}`
      : "";

    const prompt = `You are an HR specialist writing job scope items for a position titled "${position_title}".

Generate exactly 8 concise, action-oriented job scope items (each 4-12 words, starting with a verb in present tense). Items should be specific responsibilities a candidate would own day-to-day. Avoid vague items like "Be a team player".${excludedList}`;

    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 10_000);

    let aiResp: Response;
    try {
      aiResp = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
        method: "POST",
        signal: controller.signal,
        headers: {
          Authorization: `Bearer ${LOVABLE_API_KEY}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          model: "google/gemini-2.5-flash",
          messages: [
            { role: "system", content: "You generate job scope item lists." },
            { role: "user", content: prompt },
          ],
          tools: [
            {
              type: "function",
              function: {
                name: "return_scope_items",
                description: "Return the 8 scope items.",
                parameters: {
                  type: "object",
                  properties: {
                    items: {
                      type: "array",
                      items: { type: "string" },
                      minItems: 8,
                      maxItems: 8,
                    },
                  },
                  required: ["items"],
                  additionalProperties: false,
                },
              },
            },
          ],
          tool_choice: { type: "function", function: { name: "return_scope_items" } },
        }),
      });
    } catch (e) {
      clearTimeout(timeout);
      if ((e as Error).name === "AbortError") {
        return json({ error: "AI suggestion timed out. Please try again." }, 504);
      }
      throw e;
    }
    clearTimeout(timeout);

    if (aiResp.status === 429) return json({ error: "Rate limit exceeded. Try again shortly." }, 429);
    if (aiResp.status === 402) return json({ error: "AI credits exhausted. Add credits in workspace settings." }, 402);
    if (!aiResp.ok) {
      const t = await aiResp.text();
      console.error("AI gateway error:", aiResp.status, t);
      return json({ error: "AI gateway error" }, 500);
    }

    const data = await aiResp.json();
    const toolCall = data?.choices?.[0]?.message?.tool_calls?.[0];
    let items: string[] = [];
    try {
      const parsed = JSON.parse(toolCall?.function?.arguments ?? "{}");
      items = Array.isArray(parsed?.items) ? parsed.items.filter((s: unknown) => typeof s === "string") : [];
    } catch {
      items = [];
    }

    // Pre-filter case-insensitively against existing + excluded
    const excludedLower = new Set(excludedAll.map((s) => s.toLowerCase().trim()));
    const filtered = items
      .map((s) => s.trim())
      .filter((s) => s.length > 0 && !excludedLower.has(s.toLowerCase()));

    // Dedup within batch
    const seen = new Set<string>();
    const unique = filtered.filter((s) => {
      const k = s.toLowerCase();
      if (seen.has(k)) return false;
      seen.add(k);
      return true;
    });

    return json({ suggestions: unique });
  } catch (e) {
    console.error("gemini-scope-suggest error:", e);
    return json({ error: e instanceof Error ? e.message : "Unknown error" }, 500);
  }
});

function json(b: unknown, status = 200) {
  return new Response(JSON.stringify(b), {
    status,
    headers: { ...corsHeaders, "Content-Type": "application/json" },
  });
}
