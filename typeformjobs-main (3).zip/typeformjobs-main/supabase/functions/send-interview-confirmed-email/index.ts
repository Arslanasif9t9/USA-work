// send-interview-confirmed-email: sends Stage 1 alternate email with .ics for scheduled candidates.
import { createClient } from "npm:@supabase/supabase-js@2";
import { formatManilaDate, formatManilaTime } from "../_shared/manila.ts";
import { buildIcs } from "../_shared/ics.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
const SERVICE_KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
const RESEND_API_KEY = Deno.env.get("RESEND_API_KEY")!;

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });
  const admin = createClient(SUPABASE_URL, SERVICE_KEY);

  const body = await req.json().catch(() => ({}));
  const responseId = body?.response_id;
  const fallbackJoinUrl = (typeof body?.fallback_join_url === "string" ? body.fallback_join_url : "").trim();
  if (!responseId) {
    return new Response(JSON.stringify({ error: "missing response_id" }), {
      status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }

  const { data: resp } = await admin
    .from("responses")
    .select("id, form_id, applicant_id, scheduled_slot_id, override_email, override_name")
    .eq("id", responseId)
    .maybeSingle();
  if (!resp || !resp.scheduled_slot_id) {
    return new Response(JSON.stringify({ error: "no_scheduled_slot" }), {
      status: 404, headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }

  const { data: slot } = await admin
    .from("interview_slots")
    .select("slot_start, zoom_meeting_id")
    .eq("id", resp.scheduled_slot_id)
    .maybeSingle();
  if (!slot) {
    return new Response(JSON.stringify({ error: "slot_missing" }), {
      status: 404, headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }

  let zoomUrl = "", zoomPw = "";
  if (slot.zoom_meeting_id) {
    const { data: zm } = await admin.from("zoom_meetings")
      .select("join_url, password").eq("id", slot.zoom_meeting_id).maybeSingle();
    zoomUrl = zm?.join_url || "";
    zoomPw = zm?.password || "";
  }
  // Universal-zoom / PMR bookings have no zoom_meetings row → use forwarded join URL.
  if (!zoomUrl && fallbackJoinUrl) {
    zoomUrl = fallbackJoinUrl;
  }

  const { data: meta } = await admin.from("form_metadata")
    .select("position_title").eq("form_id", resp.form_id).maybeSingle();
  const positionTitle = (meta?.position_title || "").trim() || "the role you applied for";

  const { data: qs } = await admin.from("questions").select("id, type, label").eq("form_id", resp.form_id);
  const { data: ans } = await admin.from("answers").select("question_id, answer_text").eq("response_id", responseId);
  const emailQ = qs?.find((q: any) => q.type === "email");
  const nameQ = qs?.find((q: any) => q.type === "short_text" && /name/i.test(q.label)) || qs?.find((q: any) => q.type === "short_text");
  const find = (qid?: string) => qid ? (ans?.find((a: any) => a.question_id === qid)?.answer_text || "").trim() : "";
  const answerEmail = find(emailQ?.id);
  const candidateEmail = (resp.override_email || "").trim() || answerEmail;
  const candidateName = ((resp as any).override_name || "").trim() || find(nameQ?.id) || "there";

  if (!candidateEmail) {
    return new Response(JSON.stringify({ error: "no_candidate_email" }), {
      status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }

  const slotDate = new Date(slot.slot_start);
  const dateStr = formatManilaDate(slotDate);
  const timeStr = formatManilaTime(slotDate);

  const subject = `Interview confirmed — ${dateStr} at ${timeStr} (${positionTitle})`;
  const text = `Hi ${candidateName},

Thank you for applying to the ${positionTitle} position at Expert Intuitive Advisor Inc.

Your interview is confirmed:

INTERVIEW DETAILS:
Date: ${dateStr}
Time: ${timeStr} (Philippine Standard Time)
Duration: 30 minutes
Format: Zoom video call

JOIN MEETING:
${zoomUrl}${zoomPw ? `\nPassword: ${zoomPw}` : ""}

The calendar invite is attached.

PLEASE NOTE:
This is an initial evaluation conversation. Following this call, our Talent Team will review and contact you with next steps if your profile matches the role. If we do not move forward at this stage, we will retain your application for future opportunities.

PREPARATION:
- Stable internet connection
- Quiet, well-lit space
- Working camera and microphone
- Be available 5 minutes early

If you need to reschedule, reply to this email at least 6 hours before the scheduled time.

Angela Stein
HR – Talent Manager
Expert Intuitive Advisor Inc.`;

  const html = text.replace(/\n/g, "<br/>");

  // Build .ics
  const ics = buildIcs({
    summary: `EIA Interview - ${candidateName}`,
    description: `Zoom interview with Angela Stein.\n\nJoin: ${zoomUrl}${zoomPw ? `\nPassword: ${zoomPw}` : ""}`,
    start_time: slot.slot_start,
    duration_minutes: 30,
    timezone: "Asia/Manila",
    url: zoomUrl, location: zoomUrl,
    candidate_name: candidateName, candidate_email: candidateEmail,
    organizer_name: "Angela Stein",
    organizer_email: "talent@careers.expertintuitiveadvisor.com",
    uid: `slot-${resp.scheduled_slot_id}@expertintuitiveadvisor.com`,
  });
  const attachments: any[] = [];
  if ("ok" in ics && ics.ok) {
    attachments.push({
      filename: "eia-interview.ics",
      content: btoa(unescape(encodeURIComponent(ics.ics_content))),
    });
  }

  const sendRes = await fetch("https://api.resend.com/emails", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${RESEND_API_KEY}`,
    },
    body: JSON.stringify({
      from: "Angela Stein / HR – Talent Manager <talent@expertintuitiveadvisor.com>",
      to: [candidateEmail], subject, html, text,
      attachments,
    }),
  });
  const sendJson = await sendRes.json().catch(() => ({}));

  await admin.from("email_log").insert({
    candidate_id: resp.applicant_id ?? null,
    stage: "stage_1_interview_confirmed",
    sender: "resend",
    from_address: "talent@expertintuitiveadvisor.com",
    from_name: "Angela Stein / HR – Talent Manager",
    to_address: candidateEmail,
    subject,
    status: sendRes.ok ? "sent" : "failed",
    sent_at: sendRes.ok ? new Date().toISOString() : null,
    resend_message_id: sendJson?.id ?? null,
    error_message: sendRes.ok ? null : JSON.stringify(sendJson),
  });

  return new Response(JSON.stringify({ success: sendRes.ok, resend: sendJson }), {
    status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" },
  });
});
