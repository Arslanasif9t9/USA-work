// send-sylvia-welcome: HR-only. Sends a warm welcome email to a newly active
// employee letting them know Sylvia will reach out on WhatsApp for onboarding.
// Additive — does NOT replace the existing send-onboarding-invite flow.
import { adminClient, corsHeaders, json, requireHr } from "../_shared/hr-auth.ts";

const RESEND_API_KEY = Deno.env.get("RESEND_API_KEY")!;
const FROM = "Angela Stein / HR – Talent Manager <talent@expertintuitiveadvisor.com>";
const FROM_ADDR = "talent@expertintuitiveadvisor.com";
const FROM_NAME = "Angela Stein / HR – Talent Manager";

const NAVY = "#1a2547";
const GOLD = "#b08d57";
const SYLVIA_WA = "+1 917 735 8220";

function welcomeHtml(firstName: string) {
  return `<!doctype html><html><body style="margin:0;padding:0;background:#faf8f3;font-family:Inter,Arial,sans-serif;color:${NAVY}">
  <table width="100%" cellpadding="0" cellspacing="0" style="background:#faf8f3;padding:32px 0">
    <tr><td align="center">
      <table width="560" cellpadding="0" cellspacing="0" style="background:#ffffff;border-top:4px solid ${GOLD};padding:32px 32px 28px 32px">
        <tr><td>
          <div style="font-family:'Cormorant Garamond',Georgia,serif;font-size:26px;color:${NAVY};font-weight:600;margin-bottom:6px">
            Welcome to Expert Intuitive Advisor, ${firstName}
          </div>
          <div style="font-size:11px;letter-spacing:3px;text-transform:uppercase;color:${GOLD};margin-bottom:16px">
            Your Onboarding Starts Now
          </div>
          <p style="font-size:15px;line-height:1.6;color:${NAVY};margin:0 0 14px 0">
            Congratulations and welcome to the team. We are glad to have you with us.
          </p>
          <p style="font-size:15px;line-height:1.6;color:${NAVY};margin:0 0 14px 0">
            Your onboarding will be guided by <strong>Sylvia</strong>, our onboarding specialist. She will reach out to you personally on WhatsApp to walk you through your first steps, answer your questions, and get you set up.
          </p>
          <p style="font-size:15px;line-height:1.6;color:${NAVY};margin:0 0 14px 0">
            We use WhatsApp for all professional communication. If you do not already have it, please download WhatsApp on your phone — our onboarding specialist will personally guide you there.
          </p>
          <p style="font-size:15px;line-height:1.6;color:${NAVY};margin:18px 0 10px 0;font-weight:600">
            Please do this now so she can reach you:
          </p>
          <ol style="font-size:15px;line-height:1.7;color:${NAVY};margin:0 0 14px 22px;padding:0">
            <li>Save this WhatsApp number to your contacts: <strong style="color:${NAVY}">${SYLVIA_WA}</strong> (Sylvia — Expert Intuitive Advisor)</li>
            <li>Make sure WhatsApp is installed on your phone.</li>
            <li>Watch for her message — she will contact you shortly.</li>
          </ol>
          <p style="font-size:14px;line-height:1.6;color:${NAVY};margin:16px 0 0 0">
            If you do not hear from her, message that number on WhatsApp and say you are a new hire starting onboarding.
          </p>
          <p style="font-size:15px;line-height:1.6;color:${NAVY};margin:18px 0 0 0">
            We are looking forward to working with you.
          </p>
          <p style="font-size:14px;line-height:1.6;color:${NAVY};margin:24px 0 0 0">
            Warm regards,<br/>
            <span style="color:${GOLD}">The Expert Intuitive Advisor Team</span>
          </p>
        </td></tr>
      </table>
    </td></tr>
  </table>
  </body></html>`;
}

function welcomeText(firstName: string) {
  return `Hi ${firstName},

Congratulations and welcome to the team. We are glad to have you with us.

Your onboarding will be guided by Sylvia, our onboarding specialist. She will reach out to you personally on WhatsApp to walk you through your first steps, answer your questions, and get you set up.

We use WhatsApp for all professional communication. If you do not already have it, please download WhatsApp on your phone — our onboarding specialist will personally guide you there.

Please do this now so she can reach you:
1. Save this WhatsApp number to your contacts: ${SYLVIA_WA} (Sylvia — Expert Intuitive Advisor)
2. Make sure WhatsApp is installed on your phone.
3. Watch for her message — she will contact you shortly.

If you do not hear from her, message that number on WhatsApp and say you are a new hire starting onboarding.

We are looking forward to working with you.

Warm regards,
The Expert Intuitive Advisor Team`;
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });
  if (req.method !== "POST") return json({ error: "method_not_allowed" }, 405);

  const hr = await requireHr(req);
  if (hr instanceof Response) return hr;

  let body: { candidate_id?: string; override_email?: string };
  try { body = await req.json(); } catch { return json({ ok: false, error: "bad_request" }); }
  const candidateId = (body.candidate_id || "").trim();
  if (!candidateId) return json({ ok: false, error: "missing_candidate_id" });

  const admin = adminClient();

  // Resolve the most recent active offer for this candidate
  const { data: offer } = await admin
    .from("job_offers")
    .select("id, candidate_name, candidate_email, override_email")
    .eq("candidate_id", candidateId)
    .order("created_at", { ascending: false })
    .limit(1)
    .maybeSingle();

  if (!offer) return json({ ok: false, error: "no_offer" });

  const toAddr =
    ((body.override_email || "").trim()) ||
    ((offer as any).override_email || "").trim() ||
    (offer.candidate_email || "").trim();

  if (!toAddr) return json({ ok: false, error: "no_email" });

  const firstName = ((offer.candidate_name || "").split(" ")[0] || "there").trim();
  const subject = "Welcome to Expert Intuitive Advisor — Your Onboarding Starts Now";
  const html = welcomeHtml(firstName);
  const text = welcomeText(firstName);

  let sendRes: Response;
  let sendJson: any = {};
  try {
    sendRes = await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: { "Content-Type": "application/json", Authorization: `Bearer ${RESEND_API_KEY}` },
      body: JSON.stringify({ from: FROM, to: [toAddr], subject, html, text }),
    });
    sendJson = await sendRes.json().catch(() => ({}));
  } catch (e) {
    await admin.from("email_log").insert({
      candidate_id: candidateId,
      stage: "stage_onboarding_invite",
      sender: "resend",
      from_address: FROM_ADDR,
      from_name: FROM_NAME,
      to_address: toAddr,
      subject,
      status: "failed",
      sent_at: null,
      resend_message_id: null,
      error_message: String((e as any)?.message || e),
    });
    return json({ ok: false, error: "send_failed" });
  }

  const now = new Date().toISOString();
  await admin.from("email_log").insert({
    candidate_id: candidateId,
    stage: "stage_onboarding_invite",
    sender: "resend",
    from_address: FROM_ADDR,
    from_name: FROM_NAME,
    to_address: toAddr,
    subject,
    status: sendRes.ok ? "sent" : "failed",
    sent_at: sendRes.ok ? now : null,
    resend_message_id: sendJson?.id ?? null,
    error_message: sendRes.ok ? null : JSON.stringify(sendJson),
  });

  if (!sendRes.ok) return json({ ok: false, error: sendJson?.message || "send_failed" });
  return json({ ok: true, to: toAddr });
});
