// replay-offer-send: server-side replay of the SendOfferModal composite, used
// ONLY by the scheduler (fire-scheduled-sends) to fire a scheduled Send Offer.
// Mirrors the live 3-step flow: generate-offer-pdf -> signflow-create-document
// -> send-dual-email (stage_3_offer) -> finalize offer status.
// Runs as service role (guarded). Does NOT alter the live Send-Now path.

import { createClient } from "npm:@supabase/supabase-js@2";

const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
const SERVICE_KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, x-acting-hr-email",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

const json = (b: unknown, s = 200) =>
  new Response(JSON.stringify(b), { status: s, headers: { ...corsHeaders, "Content-Type": "application/json" } });

const buildOfferSenderA = (
  candName: string, position: string, signingUrl: string,
  comp?: { currency: string; baseMonthly: number; bonusEnabled: boolean; bonusAmount: number },
) => {
  const sym = comp?.currency === "USD" ? "$" : "₱";
  const fmt = (n: number) => `${sym}${Math.round(n).toLocaleString("en-US")}`;
  const compTextLines: string[] = [];
  const compHtmlLines: string[] = [];
  if (comp) {
    compTextLines.push("Compensation:");
    compTextLines.push(`Base salary: ${fmt(comp.baseMonthly)}/month`);
    compHtmlLines.push("<p><strong>Compensation:</strong><br/>");
    compHtmlLines.push(`Base salary: ${fmt(comp.baseMonthly)}/month`);
    if (comp.bonusEnabled && comp.bonusAmount > 0) {
      compTextLines.push(`Performance bonus: up to ${fmt(comp.bonusAmount)} per pay period (discretionary, based on performance — see attached offer letter for full details)`);
      compHtmlLines.push(`<br/>Performance bonus: up to ${fmt(comp.bonusAmount)} per pay period <em>(discretionary, based on performance — see attached offer letter for full details)</em>`);
    }
    compHtmlLines.push("</p>");
  }
  const compTextBlock = compTextLines.length ? `\n${compTextLines.join("\n")}\n` : "";
  const compHtmlBlock = compHtmlLines.length ? compHtmlLines.join("") : "";
  const text = `Hi ${candName},

I'm pleased to formally extend you a job offer for the ${position} position at Expert Intuitive Advisor Inc.
${compTextBlock}
Your offer letter includes:
- Compensation details
- Trial period terms
- Job scope and responsibilities
- Work schedule
- Acceptance conditions

REVIEW AND SIGN YOUR OFFER:
${signingUrl}

The offer is valid for 7 days from today's date. Please review carefully and sign electronically to confirm your acceptance.

If you have questions before signing, reply to this email and I'll connect you with the right person.

Welcome to EIA — we're excited about what you'll build with us.

Cathy Anderson
Hiring Director
Expert Intuitive Advisor Inc.`;
  const html = `<div style="font-family:Arial,sans-serif;font-size:14px;color:#1a2236;line-height:1.6;max-width:600px">
<p>Hi ${candName},</p>
<p>I'm pleased to formally extend you a job offer for the <strong>${position}</strong> position at Expert Intuitive Advisor Inc.</p>
${compHtmlBlock}
<p>Your offer letter includes:</p>
<ul><li>Compensation details</li><li>Trial period terms</li><li>Job scope and responsibilities</li><li>Work schedule</li><li>Acceptance conditions</li></ul>
<p><strong>Review and sign your offer:</strong><br/><a href="${signingUrl}" style="color:#1a2547">${signingUrl}</a></p>
<p>The offer is valid for 7 days from today's date. Please review carefully and sign electronically to confirm your acceptance.</p>
<p>If you have questions before signing, reply to this email and I'll connect you with the right person.</p>
<p>Welcome to EIA — we're excited about what you'll build with us.</p>
<p>Cathy Anderson<br/>Hiring Director<br/>Expert Intuitive Advisor Inc.</p></div>`;
  return {
    from_name: "Cathy Anderson / Hiring Director",
    from_address: "talent@expertintuitiveadvisor.com",
    subject: `Job Offer — ${position} at Expert Intuitive Advisor`,
    html_body: html, text_body: text,
  };
};

const buildOfferSenderB = (candName: string, position: string, signingUrl: string) => {
  const text = `Hi ${candName},

Just a personal heads up — Cathy sent over your formal offer letter for the ${position} role.

The signing link is in her email. Here it is again so you don't have to dig:

${signingUrl}

A few things to know:
- Take your time reading it, especially the compensation and schedule sections
- The offer is valid for 7 days
- If anything's unclear or you want to discuss before signing, reply to me and we'll talk

Congrats — looking forward to having you on the team.

— Angela Stein`;
  const html = `<div style="font-family:Arial,sans-serif;font-size:14px;color:#1a2236;line-height:1.6;max-width:600px">
<p>Hi ${candName},</p>
<p>Just a personal heads up — Cathy sent over your formal offer letter for the <strong>${position}</strong> role.</p>
<p>The signing link is in her email. Here it is again so you don't have to dig:</p>
<p><a href="${signingUrl}" style="color:#1a2547">${signingUrl}</a></p>
<p>A few things to know:</p>
<ul><li>Take your time reading it, especially the compensation and schedule sections</li><li>The offer is valid for 7 days</li><li>If anything's unclear or you want to discuss before signing, reply to me and we'll talk</li></ul>
<p>Congrats — looking forward to having you on the team.</p>
<p>— Angela Stein</p></div>`;
  return {
    from_name: "Angela Stein", from_address: "expertintuitiveadvisor@gmail.com",
    subject: "Your EIA offer is ready to sign", html_body: html, text_body: text,
  };
};

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });

  // Guard: service role only.
  const auth = req.headers.get("Authorization") || "";
  if (auth.slice(7).trim() !== SERVICE_KEY) return json({ error: "forbidden" }, 403);

  const body = await req.json().catch(() => ({}));
  const jobOfferId: string | undefined = body?.job_offer_id;
  const toOverride: string | undefined = typeof body?.to === "string" ? body.to.trim() : undefined;
  if (!jobOfferId) return json({ error: "missing_job_offer_id" }, 400);

  const admin = createClient(SUPABASE_URL, SERVICE_KEY);

  const { data: offer, error: offErr } = await admin
    .from("job_offers")
    .select("id, candidate_name, candidate_email, position_title, currency, post_trial_weekly_salary, performance_bonus_enabled, performance_bonus_amount, include_adaptability_clause, offer_reference_id, candidate_id")
    .eq("id", jobOfferId)
    .maybeSingle();
  if (offErr || !offer) return json({ error: "offer_not_found" }, 404);

  const candName = (offer.candidate_name || "").trim();
  const position = (offer.position_title || "").trim();
  const toEmail = (toOverride || offer.candidate_email || "").trim();

  // Step 1: PDF
  const pdfRes = await admin.functions.invoke("generate-offer-pdf", { body: { job_offer_id: jobOfferId } });
  const pdfUrl = (pdfRes.data as any)?.pdf_url;
  if (pdfRes.error || !(pdfRes.data as any)?.success || !pdfUrl) {
    return json({ error: `pdf: ${pdfRes.error?.message || (pdfRes.data as any)?.error || "PDF generation failed"}` }, 500);
  }

  // Step 2: SignFlow
  const sfRes = await admin.functions.invoke("signflow-create-document", {
    body: {
      external_offer_reference: offer.offer_reference_id,
      signer_name: candName, signer_email: toEmail,
      document_title: `Job Offer - ${candName}`, pdf_url: pdfUrl,
      signature_field_position: { page: offer.include_adaptability_clause !== false ? 5 : 4, x: 100, y: 350, width: 200, height: 60 },
    },
  });
  const signingUrl = (sfRes.data as any)?.signing_url;
  const sfToken = (sfRes.data as any)?.signing_token;
  if (sfRes.error || !(typeof signingUrl === "string" && /^https:\/\/\S+$/i.test(signingUrl))) {
    return json({ error: `signflow: ${sfRes.error?.message || (sfRes.data as any)?.error || "signing link failed"}` }, 500);
  }
  if (sfToken) {
    await admin.from("job_offers").update({ signing_token: sfToken }).eq("id", jobOfferId);
  }

  // Step 3: dual email
  const emailRes = await admin.functions.invoke("send-dual-email", {
    body: {
      to: toEmail, job_offer_id: jobOfferId, stage: "stage_3_offer",
      sender_a: buildOfferSenderA(candName, position, signingUrl, {
        currency: offer.currency || "PHP",
        baseMonthly: Math.round(Number(offer.post_trial_weekly_salary || 0) * 4),
        bonusEnabled: !!offer.performance_bonus_enabled,
        bonusAmount: Number(offer.performance_bonus_amount || 0),
      }),
      sender_b: buildOfferSenderB(candName, position, signingUrl),
    },
  });
  if (emailRes.error) return json({ error: `email: ${emailRes.error.message}` }, 500);

  // Step 4: finalize
  await admin.from("job_offers").update({ status: "sent", sent_at: new Date().toISOString() }).eq("id", jobOfferId);

  return json({ ok: true, job_offer_id: jobOfferId, signing_url: signingUrl });
});
