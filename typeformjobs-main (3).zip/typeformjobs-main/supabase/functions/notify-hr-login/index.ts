import { createClient } from "npm:@supabase/supabase-js@2";

// ── Confidential login alert (ADDITIVE) ──────────────────────────────────────
// On a successful login by one of the 3 real EIA HR accounts, send a private
// plain-text email to the master admin ONLY. HR users never see this.
// This function is fully self-contained: it does NOT touch auth flow, the
// force-hr-session-check guard, RLS, the seed function, or any account.

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, x-login-user-agent",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

// Sole recipient — hardcoded. Never cc/bcc, never HR, never candidates.
const ALERT_RECIPIENT = "spark11179@gmail.com";
const RESEND_FROM = "Angela Stein <talent@expertintuitiveadvisor.com>";

// Only these 3 real accounts trigger an alert.
const ALERT_EMAILS = new Set([
  "spark11179@gmail.com",
  "hr1@expert.com",
  "hr2@expert.com",
]);

const json = (body: unknown, status = 200) =>
  new Response(JSON.stringify(body), {
    status,
    headers: { ...corsHeaders, "Content-Type": "application/json" },
  });

function clientIp(req: Request): string | null {
  const xff = req.headers.get("x-forwarded-for");
  if (xff) {
    const first = xff.split(",")[0]?.trim();
    if (first) return first;
  }
  return (
    req.headers.get("cf-connecting-ip") ||
    req.headers.get("x-real-ip") ||
    null
  );
}

function parseDevice(ua: string | null): string {
  if (!ua) return "Unknown device";
  let os = "Unknown OS";
  if (/Windows NT 10/.test(ua)) os = "Windows 10/11";
  else if (/Windows NT/.test(ua)) os = "Windows";
  else if (/iPhone|iPad|iPod/.test(ua)) os = "iOS";
  else if (/Mac OS X/.test(ua)) os = "macOS";
  else if (/Android/.test(ua)) os = "Android";
  else if (/Linux/.test(ua)) os = "Linux";

  let browser = "Unknown browser";
  if (/Edg\//.test(ua)) browser = "Edge";
  else if (/OPR\/|Opera/.test(ua)) browser = "Opera";
  else if (/Chrome\//.test(ua) && !/Edg\//.test(ua)) browser = "Chrome";
  else if (/Firefox\//.test(ua)) browser = "Firefox";
  else if (/Safari\//.test(ua) && /Version\//.test(ua)) browser = "Safari";

  return `${browser} on ${os}`;
}

async function lookupLocation(ip: string | null): Promise<string> {
  if (!ip) return "Unknown location";
  // Skip private / loopback ranges
  if (/^(10\.|127\.|192\.168\.|172\.(1[6-9]|2\d|3[01])\.|::1|fe80:)/.test(ip)) {
    return "Unknown location";
  }
  try {
    const r = await fetch(`https://ipapi.co/${encodeURIComponent(ip)}/json/`, {
      headers: { "User-Agent": "eia-login-alert/1.0" },
    });
    if (r.ok) {
      const j = await r.json().catch(() => null) as
        | { city?: string; country_name?: string; error?: boolean }
        | null;
      if (j && !j.error) {
        const parts = [j.city, j.country_name].filter(Boolean);
        if (parts.length) return parts.join(", ");
      }
    }
  } catch (_) {
    // fall through to graceful fallback
  }
  try {
    const r2 = await fetch(`http://ip-api.com/json/${encodeURIComponent(ip)}?fields=status,city,country`);
    if (r2.ok) {
      const j2 = await r2.json().catch(() => null) as
        | { status?: string; city?: string; country?: string }
        | null;
      if (j2 && j2.status === "success") {
        const parts = [j2.city, j2.country].filter(Boolean);
        if (parts.length) return parts.join(", ");
      }
    }
  } catch (_) {
    // omit location gracefully
  }
  return "Unknown location";
}

function manilaTime(d: Date): string {
  return new Intl.DateTimeFormat("en-US", {
    timeZone: "Asia/Manila",
    weekday: "short",
    year: "numeric",
    month: "short",
    day: "numeric",
    hour: "numeric",
    minute: "2-digit",
    second: "2-digit",
    hour12: true,
  }).format(d) + " (Manila)";
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });

  try {
    // ── Validate the user from the bearer token (does NOT modify auth) ──
    const authHeader = req.headers.get("Authorization") || "";
    const token = authHeader.replace(/^Bearer\s+/i, "").trim();
    if (!token) return json({ ok: false, reason: "no_token" }, 200);

    const admin = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!,
    );

    const { data: userData, error: userErr } = await admin.auth.getUser(token);
    const email = userData.user?.email?.toLowerCase() || "";
    if (userErr || !userData.user || !ALERT_EMAILS.has(email)) {
      // Not a tracked account (or invalid token) — silently no-op.
      return json({ ok: true, sent: false });
    }

    // Role lookup from hr_users (read-only).
    const { data: hr } = await admin
      .from("hr_users")
      .select("role")
      .ilike("email", email)
      .maybeSingle();
    const role = hr?.role || "unknown";

    // Request metadata.
    const ip = clientIp(req);
    const ua =
      req.headers.get("x-login-user-agent") ||
      req.headers.get("user-agent") ||
      null;
    const device = parseDevice(ua);
    const location = await lookupLocation(ip);
    const time = manilaTime(new Date());

    // ── New-vs-known device+location gate ──────────────────────────────────
    // Fingerprint = parsed browser + OS (the `device` string).
    // Only alert when this account_email has NOT been seen with this SAME
    // device_fingerprint AND SAME location before.
    const deviceFingerprint = device;
    const { data: known } = await admin
      .from("known_logins")
      .select("id")
      .eq("account_email", email)
      .eq("device_fingerprint", deviceFingerprint)
      .eq("location", location)
      .maybeSingle();

    if (known?.id) {
      // Known device + location → refresh last_seen, send NO email (silent).
      await admin
        .from("known_logins")
        .update({ last_seen: new Date().toISOString() })
        .eq("id", known.id);
      return json({ ok: true, sent: false, reason: "known_device_location" });
    }

    // New device OR new location → record it, then send the alert.
    await admin.from("known_logins").insert({
      account_email: email,
      device_fingerprint: deviceFingerprint,
      location,
    });

    const text =
      `New device or location detected for this account.\n\n` +
      `EIA HR system login detected.\n` +
      `Account: ${email} (${role})\n` +
      `Time: ${time}\n` +
      `Location: ${location}\n` +
      `IP: ${ip || "Unknown"}\n` +
      `Device: ${device}\n\n` +
      `If this was not you, change that account's password immediately.`;

    const RESEND_API_KEY = Deno.env.get("RESEND_API_KEY")!;
    const r = await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${RESEND_API_KEY}`,
      },
      body: JSON.stringify({
        from: RESEND_FROM,
        to: [ALERT_RECIPIENT], // sole recipient — no cc/bcc
        subject: "EIA HR login alert",
        text,
      }),
    });
    const j = await r.json().catch(() => ({}));

    return json({ ok: r.ok, sent: r.ok, id: (j as { id?: string })?.id ?? null });
  } catch (e) {
    // Never throw back to the client — alerting must never break login.
    return json({ ok: false, error: String(e) }, 200);
  }
});
