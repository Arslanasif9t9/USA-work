// delete-zoom-meeting: admin-only cancellation. Keeps DB row, marks status=cancelled.
import {
  adminClient,
  corsHeaders,
  jsonResponse,
  requireAdmin,
  zoomFetch,
} from "../_shared/zoom.ts";

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });
  const guard = await requireAdmin(req);
  if (guard instanceof Response) return guard;

  let body: { db_record_id?: string; zoom_meeting_id?: string };
  try {
    body = await req.json();
  } catch {
    return jsonResponse({ error: "invalid_json" }, 400);
  }

  const admin = adminClient();
  let zoomMeetingId = body.zoom_meeting_id?.toString();
  let dbId = body.db_record_id;

  if (!zoomMeetingId && dbId) {
    const { data } = await admin
      .from("zoom_meetings")
      .select("zoom_meeting_id")
      .eq("id", dbId)
      .maybeSingle();
    zoomMeetingId = data?.zoom_meeting_id;
  }
  if (!zoomMeetingId) return jsonResponse({ error: "missing_meeting_id" }, 400);

  const res = await zoomFetch(`/meetings/${zoomMeetingId}`, { method: "DELETE" });
  // Zoom returns 204 on success. 404 = already gone (treat as success).
  if (!res.ok && res.status !== 404) {
    const detail = await res.text().catch(() => "");
    return jsonResponse(
      { error: "zoom_api_error", status: res.status, details: detail },
      502,
    );
  }

  const { error: updErr } = await admin
    .from("zoom_meetings")
    .update({ status: "cancelled", last_synced_at: new Date().toISOString() })
    .eq("zoom_meeting_id", zoomMeetingId);
  if (updErr) console.error("zoom_db_update_failed", updErr);

  return jsonResponse({ success: true, zoom_status: res.status });
});
