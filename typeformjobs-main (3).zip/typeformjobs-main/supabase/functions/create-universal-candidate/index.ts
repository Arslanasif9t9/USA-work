// create-universal-candidate: HR-authenticated. ADDITIVE ONLY.
// Creates an on-the-spot candidate (responses row) and returns either:
//   - type "zoom": the shared HR PMR url (Cherry's hr_users.personal_meeting_url) — no Zoom API call, no rebook_token.
//                  ALSO emails the candidate Cherry's PMR Zoom link (talent@careers..., via Resend).
//   - type "ai":   a fresh /ai-interview/{token} link backed by a rebook_tokens row (stage 'reschedule')
// Position can come from EITHER a real live form (form_id) OR a typed-in custom_position string.
// When custom_position is used, a carrier form_id is chosen (any live form, else any form) to satisfy
// the NOT NULL responses.form_id constraint, and the typed text is stored on responses.custom_position
// so My Bookings displays it verbatim.
// Inserts ONE answers row for the new response so the dashboard name-lookup resolves
// (single insert by new response_id only — never updates/overwrites any other row).
import { adminClient, corsHeaders, json, requireHr } from "../_shared/hr-auth.ts";

const RESEND_API_KEY = Deno.env.get("RESEND_API_KEY")!;
const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

// Escape user-supplied text for safe HTML rendering; line breaks -> <br>.
function escapeHtml(s: string) {
  return s
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#39;");
}
function htmlNote(s: string) {
  return escapeHtml(s).replace(/\r\n|\r|\n/g, "<br>");
}

function genToken() {
  const bytes = crypto.getRandomValues(new Uint8Array(24));
  return Array.from(bytes).map((b) => b.toString(16).padStart(2, "0")).join("");
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });

  const ident = await requireHr(req);
  if (ident instanceof Response) return ident;
  if (!ident.hrId) return json({ error: "no_hr_profile" }, 403);

  const body = await req.json().catch(() => ({}));
  const type: string = body?.type;
  const name: string = typeof body?.name === "string" ? body.name.trim() : "";
  const email: string = typeof body?.email === "string" ? body.email.trim() : "";
  const form_id: string = typeof body?.form_id === "string" ? body.form_id.trim() : "";
  const custom_position: string =
    typeof body?.custom_position === "string" ? body.custom_position.trim() : "";

  if (type !== "zoom" && type !== "ai") return json({ error: "invalid_type" }, 400);
  if (!email || !EMAIL_RE.test(email)) return json({ error: "invalid_email" }, 400);
  // Require EITHER a valid form_id OR a non-empty custom_position.
  if (form_id && !UUID_RE.test(form_id)) return json({ error: "invalid_form_id" }, 400);
  if (!form_id && !custom_position) return json({ error: "missing_position" }, 400);

  const admin = adminClient();

  // Resolve the form_id actually written to the response.
  //  - Existing path: HR picked a real live form → use it as-is (custom_position null).
  //  - Custom path: no form_id → pick a carrier form (any live form, else any form) and
  //    store the typed text on responses.custom_position for display.
  let effectiveFormId = form_id;
  const usingCustom = !form_id && !!custom_position;

  if (form_id) {
    const { data: form } = await admin.from("forms").select("id").eq("id", form_id).maybeSingle();
    if (!form) return json({ error: "form_not_found" }, 404);
  } else {
    // Carrier form for custom positions.
    let { data: carrier } = await admin
      .from("forms")
      .select("id")
      .eq("status", "live")
      .order("created_at", { ascending: true })
      .limit(1)
      .maybeSingle();
    if (!carrier?.id) {
      const { data: anyForm } = await admin
        .from("forms")
        .select("id")
        .order("created_at", { ascending: true })
        .limit(1)
        .maybeSingle();
      carrier = anyForm ?? null;
    }
    if (!carrier?.id) return json({ error: "no_carrier_form" }, 500);
    effectiveFormId = carrier.id;
  }

  // 1) Insert response (trigger auto-creates candidate_actions row).
  // round_stage matches send-round-invite Round 1 so the candidate appears in My Bookings as invited.
  const { data: resp, error: respErr } = await admin
    .from("responses")
    .insert({
      form_id: effectiveFormId,
      override_email: email,
      round_stage: "round_1_sent",
      round_1_sent_at: new Date().toISOString(),
      handled_by_hr_id: ident.hrId,
      ...(usingCustom ? { custom_position } : {}),
    })
    .select("id")
    .maybeSingle();
  if (respErr || !resp) {
    return json({ error: "response_insert_failed", details: respErr?.message }, 500);
  }
  const response_id = resp.id;

  // 2) NAME — additive single insert into answers for THIS new response_id only.
  //    Find the form's NAME question: label regex match, else first short_text question.
  //    Fallback name = "Direct Link Candidate" so the row is never nameless.
  let name_persisted = false;
  let name_skipped_reason: string | null = null;
  try {
    const { data: qs } = await admin
      .from("questions")
      .select("id, label, type, order_index")
      .eq("form_id", effectiveFormId)
      .order("order_index", { ascending: true });
    const nameRe = /(full\s*name|first\s*name|your\s*name|\bname\b)/i;
    let nameQ = (qs || []).find((q: any) => typeof q.label === "string" && nameRe.test(q.label));
    if (!nameQ) nameQ = (qs || []).find((q: any) => q.type === "short_text");
    if (!nameQ) {
      name_skipped_reason = "no_name_question";
    } else {
      const answer_text = name && name.length > 0 ? name : "Direct Link Candidate";
      const { error: ansErr } = await admin
        .from("answers")
        .insert({ response_id, question_id: nameQ.id, answer_text });
      if (ansErr) {
        name_skipped_reason = `answers_insert_failed:${ansErr.message}`;
      } else {
        name_persisted = true;
      }
    }
  } catch (e) {
    name_skipped_reason = `answers_insert_threw:${(e as Error).message}`;
  }

  // Position label used in emails / context.
  let positionTitle = custom_position || "the role";
  if (!usingCustom) {
    const { data: meta } = await admin
      .from("form_metadata")
      .select("position_title")
      .eq("form_id", effectiveFormId)
      .maybeSingle();
    if (meta?.position_title) positionTitle = meta.position_title;
  }

  if (type === "zoom") {
    // ── Universal Zoom = candidate SELF-BOOKING (mirrors the proven Round-1 pattern) ──
    // Instead of emailing a static Zoom link, we mint a /rebook booking token (stage
    // "reschedule") with HR-curated slots. The candidate picks a slot in the 3-day
    // window; on confirm, the existing rebook-confirm → book-slot machinery REUSES
    // the shared HR PMR (no Zoom API call) and send-interview-confirmed-email hands
    // out that PMR Zoom link + .ics. We resolve the shared PMR HR (Cherry, else any
    // HR with a PMR) and pin it on the token as assigned_hr_id so book-slot reuses
    // the SAME PMR (us05web.zoom.us/j/86246183040) deterministically.
    let { data: hr } = await admin
      .from("hr_users")
      .select("id, personal_meeting_url")
      .ilike("nickname", "Cherry")
      .not("personal_meeting_url", "is", null)
      .maybeSingle();
    if (!hr?.personal_meeting_url) {
      const { data: anyHr } = await admin
        .from("hr_users")
        .select("id, personal_meeting_url")
        .eq("is_active", true)
        .not("personal_meeting_url", "is", null)
        .order("created_at", { ascending: true })
        .limit(1)
        .maybeSingle();
      hr = anyHr ?? null;
    }
    if (!hr?.personal_meeting_url) {
      return json({ error: "pmr_url_missing", response_id }, 500);
    }
    const pmrHrId = hr.id as string;

    // Optional per-candidate curated slots (validated exactly like send-round-invite).
    const curatedRaw: unknown = body?.curated_slot_ids;
    let curatedSlotIds: string[] | null = null;
    if (Array.isArray(curatedRaw) && curatedRaw.length > 0) {
      if (!curatedRaw.every((s: unknown) => typeof s === "string" && UUID_RE.test(s as string))) {
        return json({ error: "invalid_curated_slot_ids", response_id }, 400);
      }
      curatedSlotIds = Array.from(new Set(curatedRaw as string[]));
    }

    // Optional personal note from HR, injected into the invite email body only.
    const hrMessage: string =
      typeof body?.hr_message === "string" ? body.hr_message.trim() : "";

    // Mint the booking token. stage "reschedule" routes /rebook → rebook-confirm →
    // book-slot (Zoom PMR reuse + Zoom confirmation email) — NEVER the AI path.
    // is_universal_zoom flags this token as a Universal Zoom self-booking link.
    const token = genToken();
    const { error: tokInsErr } = await admin.from("rebook_tokens").insert({
      token,
      response_id,
      stage: "reschedule",
      form_id: effectiveFormId,
      assigned_hr_id: pmrHrId,
      candidate_name: name || null,
      candidate_email: email,
      curated_slot_ids: curatedSlotIds,
      is_universal_zoom: true,
    });
    if (tokInsErr) {
      return json({ error: "token_persist_failed", details: tokInsErr.message, response_id }, 500);
    }
    // READ-AFTER-WRITE GUARD — never return a broken link (same as send-round-invite).
    const { data: tokCheck } = await admin
      .from("rebook_tokens")
      .select("token")
      .eq("token", token)
      .maybeSingle();
    if (!tokCheck) {
      return json({ error: "token_not_persisted", response_id }, 500);
    }

    // EMAIL the BOOKING link (NOT the Zoom link). The Zoom PMR link is delivered
    // later, in the post-booking confirmation email. Absolute URL on the fixed
    // public domain so the link never resolves to a login-gated preview origin.
    const bookingUrl = `https://jobs.expertintuitiveadvisor.com/rebook/${token}`;
    const firstName = (name || "there").split(" ")[0];
    const subject = "Schedule your interview — Expert Intuitive Advisor";
    // Optional personal note block — rendered ABOVE the booking link, only when present.
    const noteHtml = hrMessage
      ? `<p style="margin:16px 0; padding:12px 14px; background:#f3f6fb; border-left:3px solid #1a2547; border-radius:4px;">${htmlNote(hrMessage)}</p>\n`
      : "";
    const html = `<div style="font-family: Arial, Helvetica, sans-serif; color:#1a2547; font-size:15px; line-height:1.6;">
<p>Hi ${firstName},</p>
<p>Congratulations! We'd like to invite you to interview for the <strong>${positionTitle}</strong> position.</p>
${noteHtml}<p>Please choose a time that works for you using the link below. Your interview is conducted online over Zoom — once you pick a slot, we'll email you the Zoom link and a calendar invite.</p>
<p><a href="${bookingUrl}" style="color:#1a2547; font-weight:600;">${bookingUrl}</a></p>
<p style="color:#6b7280; font-size:13px;">This link expires in 3 days. All times are in Philippine Standard Time. If it doesn't open, copy and paste it into your browser.</p>
<p>We look forward to meeting you!</p>
<p style="margin-top:24px;">Warmly,<br/>
<strong>Angela Stein</strong><br/>
HR — Talent Manager<br/>
Expert Intuitive Advisor Inc.</p>
</div>`;
    const text = `Hi ${firstName},

Congratulations! We'd like to invite you to interview for the ${positionTitle} position.
${hrMessage ? `\n${hrMessage}\n` : ""}
Please choose a time that works for you using the link below. Your interview is conducted online over Zoom — once you pick a slot, we'll email you the Zoom link and a calendar invite.

${bookingUrl}

This link expires in 3 days. All times are in Philippine Standard Time. If it doesn't open, copy and paste it into your browser.

We look forward to meeting you!

Angela Stein
HR — Talent Manager
Expert Intuitive Advisor Inc.`;

    let emailOk = false;
    let resendId: string | null = null;
    let errorMessage: string | null = null;
    try {
      const r = await fetch("https://api.resend.com/emails", {
        method: "POST",
        headers: { "Content-Type": "application/json", Authorization: `Bearer ${RESEND_API_KEY}` },
        body: JSON.stringify({
          from: "Angela Stein / HR – Talent Manager <talent@expertintuitiveadvisor.com>",
          to: [email], subject, html, text,
        }),
      });
      const j = await r.json().catch(() => ({}));
      emailOk = r.ok;
      resendId = j?.id ?? null;
      if (!r.ok) errorMessage = JSON.stringify(j).slice(0, 500);
    } catch (e: any) {
      errorMessage = String(e?.message || e);
    }

    await admin.from("email_log").insert({
      candidate_id: response_id,
      stage: "universal_zoom_sent",
      sender: "resend",
      from_address: "talent@expertintuitiveadvisor.com",
      from_name: "Angela Stein / HR – Talent Manager",
      to_address: email,
      subject,
      status: emailOk ? "sent" : "failed",
      sent_at: emailOk ? new Date().toISOString() : null,
      resend_message_id: resendId,
      error_message: emailOk ? null : errorMessage,
    });

    return json({
      response_id,
      token,
      link: `/rebook/${token}`,
      round_stage: "round_1_sent",
      email_sent: emailOk,
      email_error: emailOk ? null : errorMessage,
      name_persisted,
      name_skipped_reason,
    });
  }

  // type === "ai" — mint a rebook_token (stage 'reschedule' satisfies CHECK constraint)
  const token = genToken();
  const { error: tokInsErr } = await admin.from("rebook_tokens").insert({
    token,
    response_id,
    stage: "reschedule",
    form_id: effectiveFormId,
    assigned_hr_id: ident.hrId,
    candidate_name: name || null,
    candidate_email: email,
  });
  if (tokInsErr) {
    return json({ error: "token_persist_failed", details: tokInsErr.message, response_id }, 500);
  }

  // READ-AFTER-WRITE GUARD — never return a broken link.
  const { data: tokCheck } = await admin
    .from("rebook_tokens")
    .select("token")
    .eq("token", token)
    .maybeSingle();
  if (!tokCheck) {
    return json({ error: "token_not_persisted", response_id }, 500);
  }



  // EMAIL the Christine AI interview link to the candidate — same Resend
  // pattern + verified sender as the zoom path. Absolute URL on the fixed
  // public domain so the link never resolves to a login-gated preview origin.
  const aiLink = `https://jobs.expertintuitiveadvisor.com/ai-interview/${token}`;
  const firstName = (name || "there").split(" ")[0];
  const subject = "Your AI interview with Expert Intuitive Advisor";
  const html = `<div style="font-family: Arial, Helvetica, sans-serif; color:#1a2547; font-size:15px; line-height:1.6;">
<p>Hi ${firstName},</p>
<p>Congratulations! We'd like to invite you to interview for the <strong>${positionTitle}</strong> position.</p>
<p>Your interview is conducted online with <strong>Christine</strong>, our AI interviewer. It takes about <strong>10 minutes</strong>. When you're ready, click the link below to begin. Please make sure you're in a quiet place with a working camera and microphone.</p>
<p><a href="${aiLink}" style="color:#1a2547; font-weight:600;">${aiLink}</a></p>
<p style="color:#6b7280; font-size:13px;">This link expires in 3 days. If it doesn't open, copy and paste it into your browser.</p>
<p>We look forward to meeting you!</p>
<p style="margin-top:24px;">Warmly,<br/>
<strong>Angela Stein</strong><br/>
HR — Talent Manager<br/>
Expert Intuitive Advisor Inc.</p>
</div>`;
  const text = `Hi ${firstName},

Congratulations! We'd like to invite you to interview for the ${positionTitle} position.

Your interview is conducted online with Christine, our AI interviewer. It takes about 10 minutes. When you're ready, click the link below to begin. Please make sure you're in a quiet place with a working camera and microphone.

${aiLink}

This link expires in 3 days. If it doesn't open, copy and paste it into your browser.

We look forward to meeting you!

Angela Stein
HR — Talent Manager
Expert Intuitive Advisor Inc.`;

  let emailOk = false;
  let resendId: string | null = null;
  let errorMessage: string | null = null;
  try {
    const r = await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: { "Content-Type": "application/json", Authorization: `Bearer ${RESEND_API_KEY}` },
      body: JSON.stringify({
        from: "Angela Stein / HR – Talent Manager <talent@expertintuitiveadvisor.com>",
        to: [email], subject, html, text,
      }),
    });
    const j = await r.json().catch(() => ({}));
    emailOk = r.ok;
    resendId = j?.id ?? null;
    if (!r.ok) errorMessage = JSON.stringify(j).slice(0, 500);
  } catch (e: any) {
    errorMessage = String(e?.message || e);
  }

  await admin.from("email_log").insert({
    candidate_id: response_id,
    stage: "universal_ai_sent",
    sender: "resend",
    from_address: "talent@expertintuitiveadvisor.com",
    from_name: "Angela Stein / HR – Talent Manager",
    to_address: email,
    subject,
    status: emailOk ? "sent" : "failed",
    sent_at: emailOk ? new Date().toISOString() : null,
    resend_message_id: resendId,
    error_message: emailOk ? null : errorMessage,
  });

  return json({
    response_id,
    token,
    link: `/ai-interview/${token}`,
    round_stage: "round_1_sent",
    email_sent: emailOk,
    email_error: emailOk ? null : errorMessage,
    name_persisted,
    name_skipped_reason,
  });
});

