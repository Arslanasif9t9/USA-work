// send-joining-nda: admin/HR-only orchestrator for the Joining NDA (NDA 1).
// Mirrors send-nda exactly. Supports both modes: response_id (system lookup) AND
// direct {name,email} (verbatim, no lookup). Logs via send-dual-email with stage
// "joining_nda_sent". Inserts nda_signatures with doc_type='joining_nda'.
import { createClient } from "npm:@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
const ANON = Deno.env.get("SUPABASE_ANON_KEY")!;
const SVC = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;

const json = (b: unknown, status = 200) =>
  new Response(JSON.stringify(b), {
    status,
    headers: { ...corsHeaders, "content-type": "application/json" },
  });

function shortId() {
  return crypto.randomUUID().replace(/-/g, "").slice(0, 8).toUpperCase();
}

function buildSenderA(firstName: string, signingUrl: string) {
  const text = `Hi ${firstName},

As part of joining Expert Intuitive Advisor Inc., please review and sign your Non-Disclosure Agreement (NDA) — covering confidentiality, non-compete, and platform restrictions — using the secure link below.

REVIEW & SIGN YOUR JOINING NDA:
${signingUrl}

If you have any questions, simply reply to this email.

Angela Stein
HR — Talent Manager
Expert Intuitive Advisor Inc.`;
  const html = `<div style="font-family:Arial,sans-serif;font-size:14px;color:#1a2236;line-height:1.6;max-width:600px">
<p>Hi ${firstName},</p>
<p>As part of joining <strong>Expert Intuitive Advisor Inc.</strong>, please review and sign your Non-Disclosure Agreement (NDA) — covering confidentiality, non-compete, and platform restrictions — using the secure link below.</p>
<p><a href="${signingUrl}" style="display:inline-block;background:#1a2547;color:#ffffff;padding:12px 22px;border-radius:6px;text-decoration:none;font-weight:600">Review &amp; sign your Joining NDA</a></p>
<p style="font-size:12px;color:#666">Or paste this link into your browser:<br/><a href="${signingUrl}" style="color:#1a2547">${signingUrl}</a></p>
<p>If you have any questions, simply reply to this email.</p>
<p>Angela Stein<br/>HR — Talent Manager<br/>Expert Intuitive Advisor Inc.</p>
</div>`;
  return {
    from_name: "Angela Stein / HR — Talent Manager",
    from_address: "talent@expertintuitiveadvisor.com",
    subject: "Please sign your Joining NDA — Expert Intuitive Advisor Inc.",
    html_body: html,
    text_body: text,
  };
}

function buildSenderB(firstName: string, signingUrl: string) {
  const text = `Hi ${firstName},

Quick personal note — your Joining NDA is ready for signing. Here's the link again so you don't have to dig:

${signingUrl}

Take a few minutes to read through it carefully. If anything's unclear, just reply.

— Angela Stein`;
  const html = `<div style="font-family:Arial,sans-serif;font-size:14px;color:#1a2236;line-height:1.6;max-width:600px">
<p>Hi ${firstName},</p>
<p>Quick personal note — your Joining NDA is ready for signing. Here's the link again so you don't have to dig:</p>
<p><a href="${signingUrl}" style="color:#1a2547">${signingUrl}</a></p>
<p>Take a few minutes to read through it carefully. If anything's unclear, just reply.</p>
<p>— Angela Stein</p>
</div>`;
  return {
    from_name: "Angela Stein",
    from_address: "expertintuitiveadvisor@gmail.com",
    subject: "Your EIA Joining NDA is ready to sign",
    html_body: html,
    text_body: text,
  };
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });
  if (req.method !== "POST") return json({ ok: false, reason: "method_not_allowed" }, 405);

  // Admin gate
  const auth = req.headers.get("Authorization") || "";
  if (!auth.startsWith("Bearer ")) return json({ ok: false, reason: "missing_auth" }, 401);
  const userClient = createClient(SUPABASE_URL, ANON, { global: { headers: { Authorization: auth } } });
  const { data: u } = await userClient.auth.getUser();
  if (!u?.user) return json({ ok: false, reason: "invalid_jwt" }, 401);
  const admin = createClient(SUPABASE_URL, SVC);
  const { data: urow } = await admin.from("users").select("role").eq("id", u.user.id).maybeSingle();
  if (!urow || urow.role !== "admin") return json({ ok: false, reason: "forbidden" }, 403);

  let body: { response_id?: string; override_email?: string; name?: string; email?: string; hr_copy_requested?: boolean; hr_copy_email_override?: string };
  try { body = await req.json(); } catch { return json({ ok: false, reason: "invalid_json" }, 400); }
  const { response_id, override_email, name: directName, email: directEmail } = body || {};
  const hrCopyRequested = !!(body as any)?.hr_copy_requested;
  const hrCopyEmailOverrideRaw = typeof (body as any)?.hr_copy_email_override === "string" ? (body as any).hr_copy_email_override.trim() : "";
  const hrCopyEmailOverride = hrCopyEmailOverrideRaw && /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(hrCopyEmailOverrideRaw) ? hrCopyEmailOverrideRaw : null;

  let signerEmail = "";
  let signerName = "";
  let resolvedResponseId: string | null = null;

  if (response_id) {
    const { data: resp, error: respErr } = await admin
      .from("responses")
      .select("id, applicant_id, form_id, override_email")
      .eq("id", response_id)
      .maybeSingle();
    if (respErr) return json({ ok: false, reason: "response_lookup_failed", detail: respErr.message }, 500);
    if (!resp) return json({ ok: false, reason: "response_not_found" }, 404);
    resolvedResponseId = response_id;

    if (override_email && typeof override_email === "string" && /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(override_email.trim())) {
      const ov = override_email.trim();
      if (ov !== (resp as any).override_email) {
        await admin.from("responses").update({ override_email: ov }).eq("id", response_id);
        (resp as any).override_email = ov;
      }
    }

    signerEmail = ((resp as any).override_email || "").trim();
    if ((resp as any).applicant_id) {
      const { data: off } = await admin
        .from("job_offers")
        .select("candidate_name, candidate_email")
        .eq("candidate_id", (resp as any).applicant_id)
        .order("created_at", { ascending: false })
        .limit(1)
        .maybeSingle();
      if (off?.candidate_name) signerName = off.candidate_name;
      if (!signerEmail && off?.candidate_email) signerEmail = off.candidate_email.trim();
    }
    if (!signerName) {
      const { data: ob } = await admin
        .from("onboarding_submissions").select("full_name, email")
        .eq("response_id", response_id).maybeSingle();
      if (ob?.full_name) signerName = ob.full_name;
      if (!signerEmail && ob?.email) signerEmail = String(ob.email).trim();
    }
  } else if (directName && directEmail) {
    signerName = String(directName).trim();
    signerEmail = String(directEmail).trim();
  } else {
    return json({ ok: false, reason: "missing_input" }, 400);
  }

  if (!signerEmail || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(signerEmail)) {
    return json({ ok: false, reason: "no_email" }, 400);
  }
  if (!signerName) return json({ ok: false, reason: "no_name" }, 400);

  const reference = `JNDA-${shortId()}`;

  const pdfResp = await fetch(`${SUPABASE_URL}/functions/v1/generate-joining-nda-pdf`, {
    method: "POST",
    headers: { Authorization: auth, "Content-Type": "application/json" },
    body: JSON.stringify({ response_id: resolvedResponseId, signer_name: signerName, signer_email: signerEmail, reference }),
  });
  const pdfJson = await pdfResp.json().catch(() => ({}));
  const pdfUrl: string | undefined = (pdfJson as any)?.pdf_url;
  const pageCount: number | undefined = (pdfJson as any)?.page_count;
  if (!pdfResp.ok || !pdfUrl) {
    return json({ ok: false, reason: "pdf_failed", detail: pdfJson }, 500);
  }

  // Use the REAL signature-block rectangle from the PDF builder, converted from
  // PDF bottom-origin (fieldTop) to the top-origin space the signer page renders
  // in (y_top = PAGE_H - fieldTop, PAGE_H = 792).
  const PAGE_H = 792;
  const sigRect = (pdfJson as any)?.signature_rect as
    | { page?: number; x?: number; fieldTop?: number; width?: number; height?: number }
    | null | undefined;
  const sigPage = Math.max(1, Number(sigRect?.page ?? pageCount ?? 2));
  const sigFieldPosition = sigRect && typeof sigRect.fieldTop === "number"
    ? { page: sigPage, x: Number(sigRect.x ?? 61), y: PAGE_H - Number(sigRect.fieldTop), width: Number(sigRect.width ?? 240), height: Number(sigRect.height ?? 60) }
    : { page: sigPage, x: 100, y: 350, width: 200, height: 60 };
  const sfResp = await fetch(`${SUPABASE_URL}/functions/v1/signflow-create-document`, {
    method: "POST",
    headers: { Authorization: auth, "Content-Type": "application/json" },
    body: JSON.stringify({
      external_offer_reference: reference,
      signer_name: signerName,
      signer_email: signerEmail,
      document_title: "Non-Disclosure Agreement (NDA)",
      pdf_url: pdfUrl,
      signature_field_position: sigFieldPosition,
    }),
  });
  const sfJson = await sfResp.json().catch(() => ({}));
  const signingUrl: string | undefined = (sfJson as any)?.signing_url;
  const signingToken: string | undefined = (sfJson as any)?.signing_token;
  if (!sfResp.ok || !signingUrl || !/^https:\/\/\S+$/i.test(signingUrl)) {
    return json({ ok: false, reason: "signflow_failed", detail: sfJson }, 502);
  }

  const { error: insErr } = await admin.from("nda_signatures").insert({
    response_id: resolvedResponseId,
    external_reference: reference,
    signer_name: signerName,
    signer_email: signerEmail,
    signing_token: signingToken || null,
    signing_url: signingUrl,
    status: "sent",
    doc_type: "joining_nda",
    hr_copy_requested: hrCopyRequested,
    hr_copy_email_override: hrCopyEmailOverride,
  });
  if (insErr) return json({ ok: false, reason: "persist_failed", detail: insErr.message }, 500);
  const { data: verifyRow } = await admin
    .from("nda_signatures").select("id").eq("external_reference", reference).maybeSingle();
  if (!verifyRow) return json({ ok: false, reason: "persist_failed", detail: "row not found after insert" }, 500);

  const firstName = signerName.trim().split(/\s+/)[0] || signerName;
  const emailResp = await fetch(`${SUPABASE_URL}/functions/v1/send-dual-email`, {
    method: "POST",
    headers: { Authorization: `Bearer ${SVC}`, "Content-Type": "application/json" },
    body: JSON.stringify({
      to: signerEmail,
      stage: "joining_nda_sent",
      sender_a: buildSenderA(firstName, signingUrl),
      sender_b: buildSenderB(firstName, signingUrl),
    }),
  });
  const emailJson = await emailResp.json().catch(() => ({}));
  if (!emailResp.ok) {
    return json({
      ok: false, reason: "email_failed", detail: emailJson,
      signing_url: signingUrl, external_reference: reference,
    }, 502);
  }

  return json({ ok: true, signing_url: signingUrl, external_reference: reference });
});
