// submit-cash-advance: PUBLIC, token-gated. Clone of submit-leave for cash advance
// rows (doc_type='cash_advance') living in the same leave_requests table. Updates the
// row with the employee's cash-advance fields, flips status invited -> pending_approval,
// marks token used. Best-effort notifies HR. Never touches the leave flow / SignFlow.
import { createClient } from "npm:@supabase/supabase-js@2";
import { matchLeaveToResponse } from "../_shared/match-leave.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};
const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
const SERVICE = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
const RESEND_API_KEY = Deno.env.get("RESEND_API_KEY") || "";

const HR_NOTIFY = "talent.expertadvisor@outlook.com";
const FROM = "EIA HR <talent@expertintuitiveadvisor.com>";
const FROM_ADDR = "talent@expertintuitiveadvisor.com";
const FROM_NAME = "EIA HR";

const json = (b: unknown, s = 200) =>
  new Response(JSON.stringify(b), { status: s, headers: { ...corsHeaders, "Content-Type": "application/json" } });

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });
  try {
    const body = await req.json();
    const {
      token,
      ca_amount,
      ca_reason,
      ca_repayment_method,
      typed_name,
      signature_data,
      signature_date,
    } = body || {};

    if (!token || typeof token !== "string") return json({ ok: false, reason: "missing_token" }, 400);

    const admin = createClient(SUPABASE_URL, SERVICE);

    // Re-validate token server-side
    const { data: row } = await admin
      .from("leave_requests")
      .select("id, status, token_used_at, token_expires_at")
      .eq("token", token)
      .maybeSingle();

    if (!row) return json({ ok: false, reason: "not_found" }, 404);
    if (row.token_used_at) return json({ ok: false, reason: "used" }, 410);
    if (new Date(row.token_expires_at as string) < new Date()) return json({ ok: false, reason: "expired" }, 410);
    if (row.status !== "invited") return json({ ok: false, reason: "used" }, 410);

    const now = new Date().toISOString();

    // Single-row UPDATE by id
    const { error: upErr } = await admin
      .from("leave_requests")
      .update({
        ca_amount: (ca_amount || "").toString().trim() || null,
        ca_reason: (ca_reason || "").toString().trim() || null,
        ca_repayment_method: (ca_repayment_method || "").toString().trim() || null,
        typed_name: (typed_name || "").toString().trim() || null,
        signature_data: signature_data || null,
        signature_date: (signature_date || "").toString().trim() || null,
        status: "pending_approval",
        token_used_at: now,
        updated_at: now,
      })
      .eq("id", row.id);

    if (upErr) return json({ ok: false, reason: "persist_failed", detail: upErr.message }, 500);

    // Read-after-write guard
    const { data: verify } = await admin
      .from("leave_requests")
      .select("status, token_used_at, signer_email, matched_response_id")
      .eq("id", row.id)
      .maybeSingle();
    if (!verify || verify.status !== "pending_approval" || !verify.token_used_at) {
      return json({ ok: false, reason: "persist_failed" }, 500);
    }

    // Idempotent auto-match by email (never throws, never blocks submit)
    if (!verify.matched_response_id && verify.signer_email) {
      await matchLeaveToResponse(admin, row.id, verify.signer_email);
    }

    // Best-effort HR notification — DISABLED: the "New Cash Advance Request" inbox
    // notification is intentionally turned off. Record write + candidate-facing
    // confirmation are unchanged.
    try {
      if (false && RESEND_API_KEY) {
        const subject = `New Cash Advance Request — ${typed_name || "Employee"}`;
        const text =
          `${typed_name || "An employee"} submitted a cash advance request.\n\n` +
          `Amount: ${ca_amount || "(not provided)"}\n` +
          `Reason: ${ca_reason || "(not provided)"}\n` +
          `Repayment method: ${ca_repayment_method || "(not provided)"}\n\n` +
          `Review and approve/decline in the EIA Quarantine dashboard.`;
        const html = `<div style="font-family:Inter,Arial,sans-serif;color:#1a2547">
          <h2 style="font-family:'Cormorant Garamond',Georgia,serif;color:#1a2547">New Cash Advance Request</h2>
          <p><strong>${typed_name || "An employee"}</strong> submitted a cash advance request.</p>
          <ul>
            <li><strong>Amount:</strong> ${ca_amount || "(not provided)"}</li>
            <li><strong>Reason:</strong> ${ca_reason || "(not provided)"}</li>
            <li><strong>Repayment method:</strong> ${ca_repayment_method || "(not provided)"}</li>
          </ul>
          <p style="color:#6b7280;font-size:13px">Review and approve/decline in the EIA Quarantine dashboard.</p>
        </div>`;

        const sendRes = await fetch("https://api.resend.com/emails", {
          method: "POST",
          headers: { "Content-Type": "application/json", Authorization: `Bearer ${RESEND_API_KEY}` },
          body: JSON.stringify({ from: FROM, to: [HR_NOTIFY], subject, html, text }),
        });
        const sendJson = await sendRes.json().catch(() => ({}));
        await admin.from("email_log").insert({
          candidate_id: null,
          stage: "other",
          sender: "resend",
          from_address: FROM_ADDR,
          from_name: FROM_NAME,
          to_address: HR_NOTIFY,
          subject,
          status: sendRes.ok ? "sent" : "failed",
          sent_at: sendRes.ok ? now : null,
          resend_message_id: sendJson?.id ?? null,
          error_message: sendRes.ok ? null : JSON.stringify(sendJson),
        });
      }
    } catch (_e) {
      // swallow — notify must not fail submit
    }

    return json({ ok: true });
  } catch (e: any) {
    return json({ ok: false, reason: "internal", detail: String(e?.message || e) }, 500);
  }
});
