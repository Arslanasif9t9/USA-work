// HR-only helper that mints (or returns the existing) tracking token for a
// response. Long-lived (no expires_at). Reuses existing row if present —
// never duplicates. Read-after-write guard.
import { adminClient, corsHeaders, json, requireHr } from "../_shared/hr-auth.ts";

function randomToken(): string {
  // 32 url-safe bytes
  const bytes = new Uint8Array(32);
  crypto.getRandomValues(bytes);
  return Array.from(bytes, (b) => b.toString(16).padStart(2, "0")).join("");
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });
  if (req.method !== "POST") return json({ error: "method_not_allowed" }, 405);

  const hr = await requireHr(req);
  if (hr instanceof Response) return hr;

  let body: { response_id?: unknown };
  try { body = await req.json(); } catch { return json({ error: "bad_request" }, 400); }
  const responseId = typeof body?.response_id === "string" ? body.response_id.trim() : "";
  if (!responseId) return json({ error: "response_id_required" }, 400);

  const admin = adminClient();

  // Verify response exists (avoid minting tokens for garbage ids).
  const { data: resp, error: respErr } = await admin
    .from("responses").select("id").eq("id", responseId).maybeSingle();
  if (respErr || !resp) return json({ error: "response_not_found" }, 404);

  // Reuse existing live (non-revoked) token if present.
  const { data: existing } = await admin
    .from("tracking_tokens")
    .select("id, token, response_id, created_at, expires_at, revoked_at")
    .eq("response_id", responseId)
    .is("revoked_at", null)
    .order("created_at", { ascending: false })
    .limit(1)
    .maybeSingle();

  if (existing?.token) {
    return json({ token: existing.token, reused: true }, 200);
  }

  const newToken = randomToken();
  const { data: inserted, error: insErr } = await admin
    .from("tracking_tokens")
    .insert({ token: newToken, response_id: responseId })
    .select("id, token")
    .maybeSingle();
  if (insErr || !inserted?.token) return json({ error: "insert_failed", detail: insErr?.message }, 500);

  // Read-after-write guard.
  const { data: verify } = await admin
    .from("tracking_tokens")
    .select("token")
    .eq("id", inserted.id)
    .maybeSingle();
  if (!verify?.token || verify.token !== inserted.token) {
    return json({ error: "verify_failed" }, 500);
  }

  return json({ token: verify.token, reused: false }, 200);
});
