// send-custom-document: admin/HR-only orchestrator for the Universal Custom
// Document. CLONED from send-nda. Direct {signer_name, signer_email} mode only.
//   generate-custom-document-pdf -> signflow-create-document
//   -> insert nda_signatures (doc_type='custom_document', read-after-write)
//   -> send-dual-email.
import { createClient } from "npm:@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
const ANON = Deno.env.get("SUPABASE_ANON_KEY")!;
const SVC = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;

const json = (b: unknown, status = 200) =>
  new Response(JSON.stringify(b), {
    status,
    headers: { ...corsHeaders, "content-type": "application/json" },
  });

function shortId() {
  return crypto.randomUUID().replace(/-/g, "").slice(0, 8).toUpperCase();
}

function buildDocSenderA(firstName: string, documentTitle: string, signingUrl: string) {
  const text = `Hi ${firstName},

You have a document to review and sign: "${documentTitle}".

Please use the secure link below to review and sign it:

${signingUrl}

If you have any questions, simply reply to this email.

Angela Stein
HR — Talent Manager`;
  const html = `<div style="font-family:Arial,sans-serif;font-size:14px;color:#1a2236;line-height:1.6;max-width:600px">
<p>Hi ${firstName},</p>
<p>You have a document to review and sign: <strong>${documentTitle}</strong>.</p>
<p><a href="${signingUrl}" style="display:inline-block;background:#1a2547;color:#ffffff;padding:12px 22px;border-radius:6px;text-decoration:none;font-weight:600">Review &amp; sign your document</a></p>
<p style="font-size:12px;color:#666">Or paste this link into your browser:<br/><a href="${signingUrl}" style="color:#1a2547">${signingUrl}</a></p>
<p>If you have any questions, simply reply to this email.</p>
<p>Angela Stein<br/>HR — Talent Manager</p>
</div>`;
  return {
    from_name: "Angela Stein / HR — Talent Manager",
    from_address: "talent@expertintuitiveadvisor.com",
    subject: `You have a document to review and sign — ${documentTitle}`,
    html_body: html,
    text_body: text,
  };
}

function buildDocSenderB(firstName: string, documentTitle: string, signingUrl: string) {
  const text = `Hi ${firstName},

Quick personal note — your document "${documentTitle}" is ready for signing. Here's the link again so you don't have to dig:

${signingUrl}

Take a few minutes to read through it carefully. If anything's unclear, just reply.

— Angela Stein`;
  const html = `<div style="font-family:Arial,sans-serif;font-size:14px;color:#1a2236;line-height:1.6;max-width:600px">
<p>Hi ${firstName},</p>
<p>Quick personal note — your document <strong>${documentTitle}</strong> is ready for signing. Here's the link again so you don't have to dig:</p>
<p><a href="${signingUrl}" style="color:#1a2547">${signingUrl}</a></p>
<p>Take a few minutes to read through it carefully. If anything's unclear, just reply.</p>
<p>— Angela Stein</p>
</div>`;
  return {
    from_name: "Angela Stein",
    from_address: "expertintuitiveadvisor@gmail.com",
    subject: `Your document is ready to sign — ${documentTitle}`,
    html_body: html,
    text_body: text,
  };
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });
  if (req.method !== "POST") return json({ ok: false, reason: "method_not_allowed" }, 405);

  // Admin gate
  const auth = req.headers.get("Authorization") || "";
  if (!auth.startsWith("Bearer ")) return json({ ok: false, reason: "missing_auth" }, 401);
  const userClient = createClient(SUPABASE_URL, ANON, { global: { headers: { Authorization: auth } } });
  const { data: u } = await userClient.auth.getUser();
  if (!u?.user) return json({ ok: false, reason: "invalid_jwt" }, 401);
  const admin = createClient(SUPABASE_URL, SVC);
  const { data: urow } = await admin.from("users").select("role").eq("id", u.user.id).maybeSingle();
  if (!urow || urow.role !== "admin") return json({ ok: false, reason: "forbidden" }, 403);

  let body: {
    signer_name?: string; signer_email?: string;
    document_title?: string; body_text?: string; manager_name?: string;
    branding?: { companyName?: string; email?: string; website?: string } | null;
    hr_copy_requested?: boolean; hr_copy_email_override?: string;
  };
  try { body = await req.json(); } catch { return json({ ok: false, reason: "invalid_json" }, 400); }

  const signerName = String(body?.signer_name ?? "").trim();
  const signerEmail = String(body?.signer_email ?? "").trim();
  const documentTitle = String(body?.document_title ?? "").trim();
  const bodyText = String(body?.body_text ?? "").trim();
  const managerName = String(body?.manager_name ?? "").trim() || "Cathy Anderson";

  // Branding: null = EIA default. Only honored when a company name is supplied.
  let branding: { companyName: string; email: string; website: string } | null = null;
  if (body?.branding && typeof body.branding === "object") {
    const companyName = String(body.branding.companyName ?? "").trim();
    if (companyName) {
      branding = {
        companyName,
        email: String(body.branding.email ?? "").trim(),
        website: String(body.branding.website ?? "").trim(),
      };
    }
  }

  const hrCopyRequested = !!body?.hr_copy_requested;
  const hrCopyEmailOverrideRaw = typeof body?.hr_copy_email_override === "string" ? body.hr_copy_email_override.trim() : "";
  const hrCopyEmailOverride = hrCopyEmailOverrideRaw && /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(hrCopyEmailOverrideRaw) ? hrCopyEmailOverrideRaw : null;

  if (!signerName) return json({ ok: false, reason: "no_name" }, 400);
  if (!signerEmail || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(signerEmail)) {
    return json({ ok: false, reason: "no_email" }, 400);
  }
  if (!documentTitle) return json({ ok: false, reason: "no_title" }, 400);
  if (!bodyText) return json({ ok: false, reason: "no_body" }, 400);

  // external_reference (unique)
  const reference = `DOC-${shortId()}`;

  // Generate the custom document PDF (admin-gated internal fn)
  const pdfResp = await fetch(`${SUPABASE_URL}/functions/v1/generate-custom-document-pdf`, {
    method: "POST",
    headers: { Authorization: auth, "Content-Type": "application/json" },
    body: JSON.stringify({
      title: documentTitle,
      body_text: bodyText,
      reference,
      signer_name: signerName,
      manager_name: managerName,
      branding,
    }),
  });
  const pdfJson = await pdfResp.json().catch(() => ({}));
  const pdfUrl: string | undefined = (pdfJson as any)?.pdf_url;
  const pageCount: number | undefined = (pdfJson as any)?.page_count;
  if (!pdfResp.ok || !pdfUrl) {
    return json({ ok: false, reason: "pdf_failed", detail: pdfJson }, 500);
  }

  // signflow-create-document — signature field on LAST page (computed exactly as send-nda)
  const PAGE_H = 792;
  const sigRect = (pdfJson as any)?.signature_rect as
    | { page?: number; x?: number; fieldTop?: number; width?: number; height?: number }
    | null | undefined;
  const sigPage = Math.max(1, Number(sigRect?.page ?? pageCount ?? 1));
  const sigFieldPosition = sigRect && typeof sigRect.fieldTop === "number"
    ? { page: sigPage, x: Number(sigRect.x ?? 61), y: PAGE_H - Number(sigRect.fieldTop), width: Number(sigRect.width ?? 240), height: Number(sigRect.height ?? 60) }
    : { page: sigPage, x: 100, y: 350, width: 200, height: 60 };
  const sfResp = await fetch(`${SUPABASE_URL}/functions/v1/signflow-create-document`, {
    method: "POST",
    headers: { Authorization: auth, "Content-Type": "application/json" },
    body: JSON.stringify({
      external_offer_reference: reference,
      signer_name: signerName,
      signer_email: signerEmail,
      document_title: documentTitle,
      pdf_url: pdfUrl,
      signature_field_position: sigFieldPosition,
    }),
  });
  const sfJson = await sfResp.json().catch(() => ({}));
  const signingUrl: string | undefined = (sfJson as any)?.signing_url;
  const signingToken: string | undefined = (sfJson as any)?.signing_token;
  if (!sfResp.ok || !signingUrl || !/^https:\/\/\S+$/i.test(signingUrl)) {
    return json({ ok: false, reason: "signflow_failed", detail: sfJson }, 502);
  }

  // Insert nda_signatures row (read-after-write guard)
  const { error: insErr } = await admin.from("nda_signatures").insert({
    response_id: null,
    doc_type: "custom_document",
    external_reference: reference,
    signer_name: signerName,
    signer_email: signerEmail,
    signing_token: signingToken || null,
    signing_url: signingUrl,
    status: "sent",
    hr_copy_requested: hrCopyRequested,
    hr_copy_email_override: hrCopyEmailOverride,
  });
  if (insErr) return json({ ok: false, reason: "persist_failed", detail: insErr.message }, 500);
  const { data: verifyRow } = await admin
    .from("nda_signatures").select("id").eq("external_reference", reference).maybeSingle();
  if (!verifyRow) return json({ ok: false, reason: "persist_failed", detail: "row not found after insert" }, 500);

  // Email via send-dual-email
  const firstName = signerName.trim().split(/\s+/)[0] || signerName;
  const emailResp = await fetch(`${SUPABASE_URL}/functions/v1/send-dual-email`, {
    method: "POST",
    headers: { Authorization: `Bearer ${SVC}`, "Content-Type": "application/json" },
    body: JSON.stringify({
      to: signerEmail,
      stage: "custom_document_sent",
      sender_a: buildDocSenderA(firstName, documentTitle, signingUrl),
      sender_b: buildDocSenderB(firstName, documentTitle, signingUrl),
    }),
  });
  const emailJson = await emailResp.json().catch(() => ({}));
  if (!emailResp.ok) {
    return json({
      ok: false, reason: "email_failed", detail: emailJson,
      signing_url: signingUrl, external_reference: reference,
    }, 502);
  }

  return json({ ok: true, signing_url: signingUrl, external_reference: reference });
});
