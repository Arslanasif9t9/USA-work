// Resume token loader: GET an in-progress response by session token.
// Used by the candidate client to restore state (cross-device via ?resume=).

import { createClient } from "https://esm.sh/@supabase/supabase-js@2.45.0";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};
const json = (b: unknown, status = 200) =>
  new Response(JSON.stringify(b), { status, headers: { ...corsHeaders, "Content-Type": "application/json" } });

const sb = createClient(
  Deno.env.get("SUPABASE_URL")!,
  Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!,
  { auth: { persistSession: false } }
);

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });
  if (req.method !== "POST") return json({ error: "method_not_allowed" }, 405);

  let body: { session_token?: string; form_id?: string };
  try { body = await req.json(); } catch { return json({ error: "bad_json" }, 400); }
  if (!body.session_token) return json({ error: "session_token_required" }, 400);

  const { data: row, error } = await sb
    .from("responses")
    .select("id, form_id, status, current_question_index, last_activity_at, submitted_at")
    .eq("session_token", body.session_token)
    .maybeSingle();
  if (error) return json({ error: "lookup_failed", detail: error.message }, 500);
  if (!row) return json({ found: false });
  if (body.form_id && row.form_id !== body.form_id) return json({ found: false });

  // Only offer resume for in-progress, within 24h
  const ageMs = Date.now() - new Date(row.last_activity_at).getTime();
  if (row.status !== "in_progress" || ageMs > 24 * 3600 * 1000) {
    return json({ found: false, status: row.status });
  }

  const { data: answers } = await sb
    .from("answers")
    .select("question_id, answer_text, file_url")
    .eq("response_id", row.id);

  return json({
    found: true,
    response_id: row.id,
    form_id: row.form_id,
    current_question_index: row.current_question_index,
    last_activity_at: row.last_activity_at,
    answers: answers || [],
  });
});
