// cron-ooo-cleanup: runs daily at Manila midnight. Auto-disables expired OOO periods,
// then triggers slot regeneration.
import { createClient } from "npm:@supabase/supabase-js@2";
import { manilaParts } from "../_shared/manila.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};
const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
const SERVICE = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;

Deno.serve(async (_req) => {
  const admin = createClient(SUPABASE_URL, SERVICE);
  const today = manilaParts(new Date()).dateStr;

  const { data: cfg } = await admin.from("scheduling_config").select("*").eq("id", 1).maybeSingle();
  let disabled = false;
  if (cfg?.is_out_of_office && cfg.out_of_office_end && cfg.out_of_office_end < today) {
    await admin.from("scheduling_config").update({
      is_out_of_office: false,
      out_of_office_start: null,
      out_of_office_end: null,
      ooo_active_period_id: null,
    }).eq("id", 1);
    if (cfg.ooo_active_period_id) {
      await admin.from("out_of_office_periods")
        .update({ disabled_at: new Date().toISOString() })
        .eq("id", cfg.ooo_active_period_id);
    }
    disabled = true;
  }

  // Regenerate slots
  try {
    await admin.functions.invoke("generate-slots", { body: {} });
  } catch (_) { /* swallow */ }

  return new Response(JSON.stringify({ success: true, disabled, today }), {
    status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" },
  });
});
