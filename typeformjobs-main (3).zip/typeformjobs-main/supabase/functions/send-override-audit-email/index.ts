// Notifies master admin when an override password is used.
import { corsHeaders } from "../_shared/hr-auth.ts";

const RESEND_API_KEY = Deno.env.get("RESEND_API_KEY")!;
const ADMIN_EMAIL = "spark11179@gmail.com";

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });
  const body = await req.json().catch(() => ({}));
  const { action, hr_email, hr_name, slot_id, reason, candidate_email, previous_hr_id } = body || {};
  const subject = `[Override Used] ${action} by ${hr_name || hr_email}`;
  const html = `<p><b>Override password used.</b></p>
<ul>
  <li>Action: ${action}</li>
  <li>HR: ${hr_name || ""} (${hr_email})</li>
  <li>Slot: ${slot_id}</li>
  ${reason ? `<li>Reason: ${reason}</li>` : ""}
  ${candidate_email ? `<li>Candidate: ${candidate_email}</li>` : ""}
  ${previous_hr_id ? `<li>Previous claimer: ${previous_hr_id}</li>` : ""}
  <li>When: ${new Date().toISOString()}</li>
</ul>`;
  try {
    await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${RESEND_API_KEY}`,
      },
      body: JSON.stringify({
        from: "EIA Talent <talent@expertintuitiveadvisor.com>",
        to: [ADMIN_EMAIL], subject, html,
      }),
    });
  } catch (e) { console.error("audit email error", e); }
  return new Response(JSON.stringify({ ok: true }), {
    headers: { ...corsHeaders, "Content-Type": "application/json" },
  });
});
