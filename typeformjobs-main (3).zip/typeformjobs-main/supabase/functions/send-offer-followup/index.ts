// send-offer-followup: HR-triggered reminder OR cron-triggered expiry.
// Modes:
//   { response_id, mode: "followup" }  → manual reminder
//   { response_id, mode: "expiry" }    → expiry email, marks status expired
//   { mode: "cron_expiry" }            → daily cron sweep
import { adminClient, corsHeaders, json, requireHr } from "../_shared/hr-auth.ts";

const RESEND_API_KEY = Deno.env.get("RESEND_API_KEY")!;
const FROM = "Angela Stein / HR – Talent Manager <talent@expertintuitiveadvisor.com>";

const followupHtml = (name: string, position: string, expiresAt: Date) => `
<div style="font-family:Arial,Helvetica,sans-serif;color:#1a2547;font-size:15px;line-height:1.6;">
<p>Hi ${name},</p>
<p>We're following up on the offer letter we recently sent you for the <strong>${position}</strong> position.</p>
<p>We haven't received your signed copy yet. To complete the process:</p>
<ol>
  <li>Open the offer email we previously sent</li>
  <li>Click the secure signing link</li>
  <li>Review the offer details and sign electronically</li>
</ol>
<p><strong>Please note:</strong> This offer expires on
<strong>${expiresAt.toLocaleDateString("en-US",{ timeZone:"Asia/Manila", weekday:"long", month:"long", day:"numeric", year:"numeric" })}</strong>
(7 days from the issue date) and you have not signed it yet.</p>
<p>If you have any questions or didn't receive the original email, please reach out to
<a href="mailto:talent@expertintuitiveadvisor.com" style="color:#1a2547;font-weight:600;">talent@expertintuitiveadvisor.com</a>.</p>
<p style="margin-top:24px;">Warmly,<br/>
<strong>Angela Stein</strong><br/>HR — Talent Manager<br/>Expert Intuitive Advisor Inc.</p>
</div>`;

const expiryHtml = (name: string, position: string) => `
<div style="font-family:Arial,Helvetica,sans-serif;color:#1a2547;font-size:15px;line-height:1.6;">
<p>Hi ${name},</p>
<p>Your offer letter for the <strong>${position}</strong> position has expired, as it was not signed within 7 days of issue.</p>
<p>We understand circumstances vary. If you'd like to discuss your application or have any questions,
please reach out to <a href="mailto:talent@expertintuitiveadvisor.com" style="color:#1a2547;font-weight:600;">talent@expertintuitiveadvisor.com</a>.</p>
<p>Thank you for your interest in Expert Intuitive Advisor Inc.</p>
<p style="margin-top:24px;">Warmly,<br/>
<strong>Angela Stein</strong><br/>HR — Talent Manager<br/>Expert Intuitive Advisor Inc.</p>
</div>`;

async function sendEmail(to: string, subject: string, html: string) {
  const r = await fetch("https://api.resend.com/emails", {
    method: "POST",
    headers: { "Content-Type": "application/json", Authorization: `Bearer ${RESEND_API_KEY}` },
    body: JSON.stringify({ from: FROM, to: [to], subject, html }),
  });
  const j = await r.json().catch(() => ({}));
  return { ok: r.ok, id: j?.id ?? null, err: r.ok ? null : JSON.stringify(j).slice(0, 500) };
}

async function processOne(admin: any, responseId: string, mode: "followup" | "expiry") {
  const { data: act } = await admin.from("candidate_actions")
    .select("id, job_offer_id, offer_sent_at, offer_status, response_id, candidate_id")
    .eq("response_id", responseId).maybeSingle();
  if (!act) return { ok: false, error: "action_not_found" };
  if (act.offer_status === "signed") return { ok: false, error: "already_signed" };
  if (!act.job_offer_id) return { ok: false, error: "no_offer" };

  const { data: offer } = await admin.from("job_offers")
    .select("id, candidate_name, candidate_email, position_title, sent_at, override_email")
    .eq("id", act.job_offer_id).maybeSingle();
  if (!offer) return { ok: false, error: "offer_not_found" };

  const { data: resp } = await admin.from("responses").select("override_email").eq("id", responseId).maybeSingle();
  const to = (resp as any)?.override_email || offer.override_email || offer.candidate_email;
  if (!to) return { ok: false, error: "no_email" };
  const name = (offer.candidate_name || "there").split(" ")[0];
  const position = offer.position_title || "the role";
  const sentAt = act.offer_sent_at ? new Date(act.offer_sent_at) : new Date();
  const expiresAt = new Date(sentAt.getTime() + 7 * 24 * 60 * 60 * 1000);

  const subject = mode === "followup"
    ? `Reminder: please sign your offer for ${position}`
    : `Your offer for ${position} has expired`;
  const html = mode === "followup" ? followupHtml(name, position, expiresAt) : expiryHtml(name, position);

  const sent = await sendEmail(to, subject, html);

  await admin.from("email_log").insert({
    candidate_id: act.candidate_id ?? null,
    job_offer_id: offer.id,
    stage: mode === "followup" ? "offer_followup" : "offer_expired",
    sender: "resend",
    from_address: "talent@expertintuitiveadvisor.com",
    from_name: "Angela Stein / HR – Talent Manager",
    to_address: to,
    subject,
    status: sent.ok ? "sent" : "failed",
    sent_at: sent.ok ? new Date().toISOString() : null,
    resend_message_id: sent.id,
    error_message: sent.err,
  });

  if (mode === "expiry" && sent.ok) {
    await admin.from("candidate_actions").update({ offer_status: "expired" }).eq("id", act.id);
    await admin.from("responses").update({ round_stage: "offer_expired" }).eq("id", responseId);
  }

  return { ok: sent.ok, error: sent.err, to };
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });
  const body = await req.json().catch(() => ({}));
  const mode = body?.mode as string | undefined;

  const admin = adminClient();

  if (mode === "cron_expiry") {
    // Find candidates with offer sent >=7 days ago and not signed.
    const cutoff = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString();
    const { data: rows } = await admin.from("candidate_actions")
      .select("response_id, offer_sent_at, offer_status")
      .eq("offer_status", "sent")
      .lte("offer_sent_at", cutoff)
      .limit(200);
    const results: any[] = [];
    for (const row of (rows || []) as any[]) {
      if (!row.response_id) continue;
      const res = await processOne(admin, row.response_id, "expiry");
      results.push({ response_id: row.response_id, ...res });
    }
    return json({ success: true, processed: results.length, results });
  }

  // Manual modes require HR auth.
  const ident = await requireHr(req);
  if (ident instanceof Response) return ident;
  if (!ident.hrId) return json({ error: "no_hr_profile" }, 403);

  const responseId = body?.response_id as string | undefined;
  if (!responseId) return json({ error: "missing_response_id" }, 400);
  const m: "followup" | "expiry" = mode === "expiry" ? "expiry" : "followup";
  const r = await processOne(admin, responseId, m);
  return json(r, r.ok ? 200 : 400);
});
