// launch-sylvia: HR-only. Sends a Sylvia outbound WhatsApp template message via
// ElevenLabs and records the result on the launches row. ADDITIVE — does not
// touch any existing flow.
import { adminClient, corsHeaders, json, requireHr } from "../_shared/hr-auth.ts";
import { sendSylviaWhatsApp, normalizeWhatsAppDigits } from "../_shared/elevenlabs-sylvia.ts";

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });
  if (req.method !== "POST") return json({ error: "method_not_allowed" }, 405);

  const hr = await requireHr(req);
  if (hr instanceof Response) return hr;

  let body: { launch_id?: string };
  try { body = await req.json(); } catch { return json({ ok: false, error: "bad_request" }); }
  const launchId = (body.launch_id || "").trim();
  if (!launchId) return json({ ok: false, error: "missing_launch_id" });

  const admin = adminClient();

  // Atomically claim: only fire if still 'pending'.
  const { data: claimed, error: claimErr } = await admin
    .from("launches")
    .update({ status: "sending" as any })
    .eq("id", launchId)
    .eq("status", "pending")
    .select("id, candidate_name, whatsapp_number")
    .maybeSingle();
  if (claimErr) return json({ ok: false, error: claimErr.message });
  if (!claimed) {
    const { data: existing } = await admin
      .from("launches").select("status").eq("id", launchId).maybeSingle();
    return json({ ok: false, error: existing ? `not_pending:${existing.status}` : "not_found" });
  }

  const send = await sendSylviaWhatsApp({
    candidate_name: claimed.candidate_name || "",
    whatsapp_number: claimed.whatsapp_number,
  });

  if (send.ok) {
    await admin.from("launches").update({
      status: "sent",
      sent_at: new Date().toISOString(),
      error_message: null,
    }).eq("id", launchId);

    // ADDITIVE, fire-and-forget: mirror the launch message into whatsapp_messages
    // so it shows in /dashboard/whatsapp-chat. Never blocks/fails the launch.
    try {
      const phoneDigits = normalizeWhatsAppDigits(claimed.whatsapp_number || "");
      if (phoneDigits) {
        const fullName = (claimed.candidate_name || "").trim();
        const first = fullName.split(/\s+/)[0] || "";
        const greeting = first ? `Hi ${first}` : "Hello";
        const displayBody =
          `${greeting}, this is Sylvia from Expert Intuitive Advisor. I am reaching out from the EIA team to assist you. ` +
          `Whenever you are ready, just reply here and tell me how I can help, and we will take it from there.`;
        await admin.from("whatsapp_messages").insert({
          direction: "outbound",
          phone: phoneDigits,
          contact_name: fullName || null,
          type: "text",
          body: displayBody,
          status: "sent",
        });
      }
    } catch (e) {
      console.error("[launch-sylvia] whatsapp_messages mirror insert failed:", (e as any)?.message || e);
    }

    return json({ ok: true });
  } else {
    const errMsg = send.error || (send.body ? JSON.stringify(send.body) : `http_${send.status}`);
    await admin.from("launches").update({
      status: "failed",
      error_message: errMsg.slice(0, 2000),
    }).eq("id", launchId);
    return json({ ok: false, error: errMsg });
  }
});
