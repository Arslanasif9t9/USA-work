// reap-orphaned-interview-videos: PUBLIC (cron + on-demand). Recovers interview
// videos stranded when the candidate force-closed the browser mid-interview.
//
// Progressive per-part upload already lands chunks on R2 every ~6s at
//   interviews/{response_id}/{call_id}/partNNN.webm
// but if the client exits before finalizeRecordingAndUpload runs, the parts survive
// while finalize-interview-parts + save-interview-video-url never run, so
// ai_interview_sessions.video_url stays NULL ("Video not available") even though
// footage exists. This reaper finds those sessions and finalizes the stranded parts.
//
// Reuses the shared concat core (../_shared/r2-finalize.ts) — no duplicated logic.
// Best-effort per session: one failure never stops the batch. Never overwrites an
// existing video_url. Respects the ~7-day R2 lifecycle window.
import { createClient } from "npm:@supabase/supabase-js@2";
import { finalizePartsForCall, headFinalObject } from "../_shared/r2-finalize.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
const SERVICE = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;

const json = (b: unknown, s = 200) =>
  new Response(JSON.stringify(b), { status: s, headers: { ...corsHeaders, "Content-Type": "application/json" } });

// R2 lifecycle window: parts older than this are auto-deleted, so don't bother.
const WINDOW_DAYS = 7;
const MAX_BATCH = 8;
// Minimum byte size for a final object to be considered a healthy, playable video.
// Guards against surfacing truncated finals/concats (e.g. Efril's ~308KB stub).
const MIN_FINAL_BYTES = 1_000_000;

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });
  try {
    const body = await req.json().catch(() => ({} as any));
    // Optional single-session targeting for on-demand / manual triggers.
    const onlySessionId: string | undefined =
      typeof body?.session_id === "string" && body.session_id ? body.session_id : undefined;

    const admin = createClient(SUPABASE_URL, SERVICE);
    const sinceIso = new Date(Date.now() - WINDOW_DAYS * 24 * 60 * 60 * 1000).toISOString();

    // Candidate sessions: no video yet, recoverable identifiers present, inside window.
    let query = admin
      .from("ai_interview_sessions")
      .select("id, response_id, retell_call_id, created_at")
      .is("video_url", null)
      .is("merged_video_url", null)
      .not("retell_call_id", "is", null)
      .not("response_id", "is", null)
      .gte("created_at", sinceIso)
      .order("created_at", { ascending: false })
      .limit(MAX_BATCH);
    if (onlySessionId) query = query.eq("id", onlySessionId);

    const { data: sessions, error: qErr } = await query;
    if (qErr) {
      console.error("[reap] query failed:", qErr);
      return json({ error: qErr.message }, 500);
    }

    let reaped = 0;
    let skipped_no_parts = 0;
    let failed = 0;
    const details: Array<Record<string, unknown>> = [];

    for (const s of sessions ?? []) {
      const sid = (s as any).id as string;
      const responseId = (s as any).response_id as string;
      const callId = (s as any).retell_call_id as string;
      try {
        // STEP 1: if a healthy FINAL object already exists (single-blob upload,
        // or parts already concatenated+deleted) recover video_url straight from
        // it. This is the fix for "video in R2 but video_url NULL" and it must run
        // BEFORE finalizePartsForCall so a stray leftover part can never overwrite
        // a healthy final object.
        const fin = await headFinalObject(responseId, callId);
        if (fin.exists && fin.bytes >= MIN_FINAL_BYTES) {
          const { data: updF, error: updFErr } = await admin
            .from("ai_interview_sessions")
            .update({ video_url: fin.public_url })
            .eq("id", sid)
            .is("video_url", null)
            .select("id");
          if (updFErr) {
            failed++;
            details.push({ id: sid, status: "db_update_failed", error: updFErr.message });
          } else if ((updF?.length ?? 0) > 0) {
            reaped++;
            details.push({ id: sid, status: "reaped_final_object", bytes: fin.bytes });
          } else {
            skipped_no_parts++;
            details.push({ id: sid, status: "already_set_by_other" });
          }
          continue;
        }

        // STEP 2: no healthy final object → concat live parts (original path).
        const result = await finalizePartsForCall(responseId, callId);
        if (!result.ok || !result.public_url) {
          if (result.parts_found === 0) {
            skipped_no_parts++;
            details.push({ id: sid, status: "skipped_no_parts", final_bytes: fin.bytes });
          } else {
            failed++;
            details.push({ id: sid, status: "finalize_failed", error: result.error });
          }
          continue;
        }
        // Guard: never surface a truncated concat as a playable video.
        if ((result.bytes ?? 0) < MIN_FINAL_BYTES) {
          skipped_no_parts++;
          details.push({ id: sid, status: "skipped_truncated", bytes: result.bytes });
          continue;
        }
        // Persist the recovered URL — single row by id, and ONLY if still NULL so a
        // concurrent client save is never overwritten. Setting video_url also fires
        // the existing fire_interview_merge trigger (same as the normal save path).
        const { data: updated, error: updErr } = await admin
          .from("ai_interview_sessions")
          .update({ video_url: result.public_url })
          .eq("id", sid)
          .is("video_url", null)
          .select("id");
        if (updErr) {
          failed++;
          details.push({ id: sid, status: "db_update_failed", error: updErr.message });
          continue;
        }
        if ((updated?.length ?? 0) > 0) {
          reaped++;
          details.push({ id: sid, status: "reaped", parts: result.parts_found, bytes: result.bytes });
        } else {
          // Row was filled by a racing client save between our read and write — fine.
          skipped_no_parts++;
          details.push({ id: sid, status: "already_set_by_other" });
        }
      } catch (e) {
        failed++;
        console.error("[reap] session failed (non-fatal):", sid, String(e));
        details.push({ id: sid, status: "exception", error: String(e) });
      }
    }

    const summary = {
      ok: true,
      scanned: sessions?.length ?? 0,
      reaped,
      skipped_no_parts,
      failed,
      window_days: WINDOW_DAYS,
    };
    console.log("[reap] done:", JSON.stringify(summary));
    return json({ ...summary, details });
  } catch (e: any) {
    console.error("[reap] exception:", e);
    return json({ error: String(e?.message || e) }, 500);
  }
});
