// send-onboarding-invite: HR-only. Sends the branded invite email carrying the
// /onboarding/:token link. Mint the token first (separate call), then call this.
import { adminClient, corsHeaders, json, requireHr } from "../_shared/hr-auth.ts";

const RESEND_API_KEY = Deno.env.get("RESEND_API_KEY")!;
const FROM = "Angela Stein / HR – Talent Manager <talent@expertintuitiveadvisor.com>";
const FROM_ADDR = "talent@expertintuitiveadvisor.com";
const FROM_NAME = "Angela Stein / HR – Talent Manager";

const NAVY = "#1a2547";
const GOLD = "#b08d57";

const PUBLIC_BASE = "https://jobs.expertintuitiveadvisor.com";

function inviteHtml(firstName: string, position: string, link: string) {
  return `<!doctype html><html><body style="margin:0;padding:0;background:#faf8f3;font-family:Inter,Arial,sans-serif;color:${NAVY}">
  <table width="100%" cellpadding="0" cellspacing="0" style="background:#faf8f3;padding:32px 0">
    <tr><td align="center">
      <table width="560" cellpadding="0" cellspacing="0" style="background:#ffffff;border-top:4px solid ${GOLD};padding:32px 32px 28px 32px">
        <tr><td>
          <div style="font-family:'Cormorant Garamond',Georgia,serif;font-size:26px;color:${NAVY};font-weight:600;margin-bottom:6px">
            Welcome aboard, ${firstName}
          </div>
          <div style="font-size:11px;letter-spacing:3px;text-transform:uppercase;color:${GOLD};margin-bottom:16px">
            Your EIA Onboarding Form
          </div>
          <p style="font-size:15px;line-height:1.6;color:${NAVY};margin:0 0 14px 0">
            Congratulations on joining Expert Intuitive Advisor Inc.${position ? ` as <strong>${position}</strong>` : ""}. To get you set up, please complete your onboarding form using the link below.
          </p>
          <p style="text-align:center;margin:26px 0">
            <a href="${link}" style="display:inline-block;background:${NAVY};color:#ffffff;text-decoration:none;padding:14px 28px;border-radius:6px;font-weight:600;font-size:15px">Open Onboarding Form</a>
          </p>
          <p style="font-size:13px;line-height:1.6;color:${NAVY};margin:0 0 8px 0">
            Or copy this link:<br/>
            <span style="color:${NAVY};word-break:break-all;font-size:12px">${link}</span>
          </p>
          <p style="font-size:13px;line-height:1.6;color:#555;margin:18px 0 0 0">
            This link stays active for 30 days. You can revisit it to update your information any time during that window.
          </p>
          <p style="font-size:14px;line-height:1.6;color:${NAVY};margin:24px 0 0 0">
            Warm regards,<br/>
            <span style="color:${GOLD}">Angela Stein</span><br/>
            HR – Talent Manager<br/>
            Expert Intuitive Advisor Inc.
          </p>
        </td></tr>
      </table>
    </td></tr>
  </table>
  </body></html>`;
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });
  if (req.method !== "POST") return json({ error: "method_not_allowed" }, 405);

  const hr = await requireHr(req);
  if (hr instanceof Response) return hr;

  let body: { response_id?: string; token?: string; override_email?: string };
  try { body = await req.json(); } catch { return json({ error: "bad_request" }, 400); }
  const responseId = (body.response_id || "").trim();
  const token = (body.token || "").trim();
  if (!responseId || !token) return json({ error: "missing_params" }, 400);

  const admin = adminClient();

  const { data: tok } = await admin
    .from("onboarding_tokens").select("token, candidate_name, candidate_email, position_title, response_id")
    .eq("token", token).maybeSingle();
  if (!tok || tok.response_id !== responseId) return json({ error: "token_mismatch" }, 400);

  // Persist override email on responses if HR edited it.
  let toAddr = (body.override_email || "").trim();
  if (toAddr) {
    await admin.from("responses").update({ override_email: toAddr }).eq("id", responseId);
  } else {
    toAddr = (tok.candidate_email || "").trim();
    if (!toAddr) {
      const { data: resp } = await admin.from("responses").select("override_email").eq("id", responseId).maybeSingle();
      toAddr = (resp?.override_email || "").trim();
    }
  }
  if (!toAddr) return json({ error: "no_recipient" }, 400);

  const firstName = ((tok.candidate_name || "").split(" ")[0] || "there").trim();
  const position = (tok.position_title || "").trim();
  const link = `${PUBLIC_BASE}/onboarding/${token}`;

  const subject = "Your EIA Onboarding Form";
  const html = inviteHtml(firstName, position, link);
  const text = `Hi ${firstName},

Congratulations on joining Expert Intuitive Advisor Inc.${position ? ` as ${position}` : ""}.

Please complete your onboarding form using this link:
${link}

This link stays active for 30 days. You can revisit it to update your information any time during that window.

Warm regards,
Angela Stein
HR – Talent Manager
Expert Intuitive Advisor Inc.`;

  const sendRes = await fetch("https://api.resend.com/emails", {
    method: "POST",
    headers: { "Content-Type": "application/json", Authorization: `Bearer ${RESEND_API_KEY}` },
    body: JSON.stringify({ from: FROM, to: [toAddr], subject, html, text }),
  });
  const sendJson = await sendRes.json().catch(() => ({}));
  const now = new Date().toISOString();

  await admin.from("email_log").insert({
    candidate_id: null,
    stage: "onboarding_invite",
    sender: "resend",
    from_address: FROM_ADDR,
    from_name: FROM_NAME,
    to_address: toAddr,
    subject,
    status: sendRes.ok ? "sent" : "failed",
    sent_at: sendRes.ok ? now : null,
    resend_message_id: sendJson?.id ?? null,
    error_message: sendRes.ok ? null : JSON.stringify(sendJson),
  });

  return json({ success: sendRes.ok, link, to: toAddr });
});
