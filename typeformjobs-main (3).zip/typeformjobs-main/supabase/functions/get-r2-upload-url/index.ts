// get-r2-upload-url: PUBLIC. Validates a rebook_token and returns a presigned R2 PUT URL.
import { createClient } from "npm:@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
const SERVICE = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
const R2_ACCESS_KEY_ID = Deno.env.get("R2_ACCESS_KEY_ID")!;
const R2_SECRET_ACCESS_KEY = Deno.env.get("R2_SECRET_ACCESS_KEY")!;
const R2_ENDPOINT = Deno.env.get("R2_ENDPOINT")!; // https://<acct>.r2.cloudflarestorage.com
const R2_BUCKET = Deno.env.get("R2_BUCKET")!;

const json = (b: unknown, s = 200) =>
  new Response(JSON.stringify(b), { status: s, headers: { ...corsHeaders, "Content-Type": "application/json" } });

async function sha256Hex(data: string): Promise<string> {
  const buf = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(data));
  return [...new Uint8Array(buf)].map((b) => b.toString(16).padStart(2, "0")).join("");
}

async function hmac(key: ArrayBuffer | Uint8Array, data: string): Promise<ArrayBuffer> {
  const cryptoKey = await crypto.subtle.importKey(
    "raw",
    key as BufferSource,
    { name: "HMAC", hash: "SHA-256" },
    false,
    ["sign"],
  );
  return crypto.subtle.sign("HMAC", cryptoKey, new TextEncoder().encode(data));
}

async function presignPut(objectKey: string, expiresSec = 900): Promise<string> {
  const url = new URL(R2_ENDPOINT);
  const host = url.host;
  const region = "auto";
  const service = "s3";
  const now = new Date();
  const amzDate = now.toISOString().replace(/[:-]|\.\d{3}/g, "");
  const dateStamp = amzDate.slice(0, 8);
  const credentialScope = `${dateStamp}/${region}/${service}/aws4_request`;
  const credential = `${R2_ACCESS_KEY_ID}/${credentialScope}`;
  const signedHeaders = "host";
  const encodedKey = objectKey.split("/").map(encodeURIComponent).join("/");
  const canonicalUri = `/${encodeURIComponent(R2_BUCKET)}/${encodedKey}`;

  const qsParams: Record<string, string> = {
    "X-Amz-Algorithm": "AWS4-HMAC-SHA256",
    "X-Amz-Credential": credential,
    "X-Amz-Date": amzDate,
    "X-Amz-Expires": String(expiresSec),
    "X-Amz-SignedHeaders": signedHeaders,
  };
  const canonicalQueryString = Object.keys(qsParams)
    .sort()
    .map((k) => `${encodeURIComponent(k)}=${encodeURIComponent(qsParams[k])}`)
    .join("&");

  const canonicalHeaders = `host:${host}\n`;
  const payloadHash = "UNSIGNED-PAYLOAD";
  const canonicalRequest = `PUT\n${canonicalUri}\n${canonicalQueryString}\n${canonicalHeaders}\n${signedHeaders}\n${payloadHash}`;

  const stringToSign = `AWS4-HMAC-SHA256\n${amzDate}\n${credentialScope}\n${await sha256Hex(canonicalRequest)}`;

  const kDate = await hmac(new TextEncoder().encode("AWS4" + R2_SECRET_ACCESS_KEY), dateStamp);
  const kRegion = await hmac(kDate, region);
  const kService = await hmac(kRegion, service);
  const kSigning = await hmac(kService, "aws4_request");
  const sigBuf = await hmac(kSigning, stringToSign);
  const signature = [...new Uint8Array(sigBuf)].map((b) => b.toString(16).padStart(2, "0")).join("");

  return `${url.protocol}//${host}${canonicalUri}?${canonicalQueryString}&X-Amz-Signature=${signature}`;
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });
  try {
    const { token, retell_call_id, part } = await req.json();
    if (!token) return json({ error: "missing_token" }, 400);
    if (!retell_call_id) return json({ error: "missing_retell_call_id" }, 400);

    const admin = createClient(SUPABASE_URL, SERVICE);
    const { data: tok } = await admin.from("rebook_tokens").select("*").eq("token", token).maybeSingle();
    if (!tok) return json({ error: "invalid_token" }, 401);
    if (tok.used_at) return json({ error: "token_used" }, 401);
    if (new Date(tok.expires_at) <= new Date()) return json({ error: "token_expired" }, 401);

    const response_id = tok.response_id;
    const safeCallId = String(retell_call_id).replace(/[^a-zA-Z0-9_-]/g, "_");

    // OPTIONAL part upload (Pattern A live streaming). When `part` is a valid
    // non-negative integer, presign a PART object inside a per-call folder:
    //   interviews/{response_id}/{call_id}/partNNN.webm
    // When `part` is omitted, behave EXACTLY as before (single whole-object key)
    // so existing single-PUT callers are unaffected.
    const hasPart =
      part !== undefined && part !== null && Number.isInteger(Number(part)) && Number(part) >= 0;
    const object_key = hasPart
      ? `interviews/${response_id}/${safeCallId}/part${String(Number(part)).padStart(3, "0")}.webm`
      : `interviews/${response_id}/${safeCallId}.webm`;

    const upload_url = await presignPut(object_key, 900);
    const endpoint = R2_ENDPOINT.replace(/\/+$/, "");
    const public_base = `${endpoint}/${R2_BUCKET}`;
    const public_url = `${public_base}/${object_key}`;

    return json({ upload_url, object_key, public_base, public_url });
  } catch (e: any) {
    console.error("[get-r2-upload-url] exception:", e);
    return json({ error: String(e?.message || e) }, 500);
  }
});
