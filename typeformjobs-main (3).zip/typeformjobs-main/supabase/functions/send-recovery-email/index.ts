import { adminClient, corsHeaders, json, requireHr } from "../_shared/hr-auth.ts";

const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
const SERVICE_KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
const RESEND_API_KEY = Deno.env.get("RESEND_API_KEY")!;

function genToken() {
  const bytes = crypto.getRandomValues(new Uint8Array(24));
  return Array.from(bytes).map((b) => b.toString(16).padStart(2, "0")).join("");
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });
  const ident = await requireHr(req);
  if (ident instanceof Response) return ident;
  if (!ident.hrId) return json({ error: "no_hr_profile" }, 403);

  const { slot_id, override_email, curated_slot_ids, response_id: responseIdFromBody } = await req.json().catch(() => ({}));
  if (!slot_id) return json({ error: "missing_slot_id" }, 400);
  const overrideEmailClean = typeof override_email === "string" ? override_email.trim() : "";
  if (overrideEmailClean && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(overrideEmailClean)) {
    return json({ error: "invalid_email" }, 400);
  }
  const UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
  let curatedSlotIds: string[] | null = null;
  if (Array.isArray(curated_slot_ids) && curated_slot_ids.length > 0) {
    if (!curated_slot_ids.every((s: unknown) => typeof s === "string" && UUID_RE.test(s as string))) {
      return json({ error: "invalid_curated_slot_ids" }, 400);
    }
    curatedSlotIds = Array.from(new Set(curated_slot_ids as string[]));
  }
  const responseIdFromBodyClean = typeof responseIdFromBody === "string" && UUID_RE.test(responseIdFromBody)
    ? responseIdFromBody : null;

  const admin = adminClient();
  const { data: slot } = await admin
    .from("interview_slots")
    .select("id, response_id, zoom_meeting_id")
    .eq("id", slot_id)
    .maybeSingle();
  if (!slot) return json({ error: "slot_not_found" }, 404);

  // Resolve the authoritative response_id. Slot.response_id may be NULL if the
  // candidate was previously cancelled/detached. Fall back to: (1) body, then
  // (2) responses.scheduled_slot_id, then (3) most recent rebook_token for this slot.
  let resolvedResponseId: string | null = slot.response_id || responseIdFromBodyClean;
  if (!resolvedResponseId) {
    const { data: respRow } = await admin
      .from("responses").select("id")
      .eq("scheduled_slot_id", slot_id).limit(1).maybeSingle();
    resolvedResponseId = (respRow as any)?.id || null;
  }
  if (!resolvedResponseId) {
    const { data: priorTok } = await admin
      .from("rebook_tokens").select("response_id")
      .or(`original_slot_id.eq.${slot_id},new_slot_id.eq.${slot_id}`)
      .not("response_id", "is", null)
      .order("created_at", { ascending: false }).limit(1).maybeSingle();
    resolvedResponseId = (priorTok as any)?.response_id || null;
  }
  if (!resolvedResponseId) {
    return json({ error: "response_not_resolvable", message: "Could not find the candidate's response for this slot. Use Send Round 1 instead." }, 400);
  }
  // Use the resolved id for the rest of the flow.
  (slot as any).response_id = resolvedResponseId;

  // Resolve candidate email/name BEFORE mutating anything so we can fail
  // cleanly when no email is available.
  let candidateEmail = "";
  let candidateName = "there";
  if (slot.response_id) {
    if (overrideEmailClean) {
      await admin.from("responses").update({ override_email: overrideEmailClean }).eq("id", slot.response_id);
    }
    const { data: resp } = await admin.from("responses").select("form_id, override_email, override_name").eq("id", slot.response_id).maybeSingle();
    if (resp) {
      const { data: qs } = await admin.from("questions").select("id, type, label").eq("form_id", resp.form_id);
      const { data: ans } = await admin.from("answers").select("question_id, answer_text").eq("response_id", slot.response_id);
      const emailQ = qs?.find((q: any) => q.type === "email");
      const nameQ = qs?.find((q: any) => q.type === "short_text" && /name/i.test(q.label)) || qs?.find((q: any) => q.type === "short_text");
      const answerEmail = ans?.find((a: any) => a.question_id === emailQ?.id)?.answer_text || "";
      candidateEmail = overrideEmailClean || (resp as any).override_email || answerEmail || "";
      const resolvedName = ((resp as any).override_name || "").trim() || (ans?.find((a: any) => a.question_id === nameQ?.id)?.answer_text || "there");
      candidateName = resolvedName.split(" ")[0] || "there";
    }
  } else if (overrideEmailClean) {
    candidateEmail = overrideEmailClean;
  }

  if (!candidateEmail) {
    return json({ error: "missing_email", message: "Add an email for this candidate first." }, 400);
  }

  // Cancel old zoom (best-effort, no crash if it fails or doesn't exist)
  if (slot.zoom_meeting_id) {
    fetch(`${SUPABASE_URL}/functions/v1/delete-zoom-meeting`, {
      method: "POST",
      headers: { Authorization: `Bearer ${SERVICE_KEY}`, "Content-Type": "application/json" },
      body: JSON.stringify({ zoom_meeting_id: slot.zoom_meeting_id }),
    }).catch(() => {});
  }

  // Mark slot cancelled
  await admin.from("interview_slots").update({ status: "cancelled" }).eq("id", slot_id);

  // Detach the candidate from the slot so My Bookings shows
  // "Cancelled — Awaiting Rebooking" until they pick a new time.
  // Cleared automatically when book-slot fires on successful rebook.
  if (slot.response_id) {
    await admin
      .from("responses")
      .update({
        scheduled_slot_id: null,
        scheduled_at: null,
        appointment_cancelled: true,
      })
      .eq("id", slot.response_id);
  }

  const token = genToken();
  const { error: tokInsErr } = await admin.from("rebook_tokens").insert({
    token, response_id: slot.response_id, original_slot_id: slot_id,
    candidate_email: candidateEmail,
    curated_slot_ids: curatedSlotIds,
  });
  if (tokInsErr) {
    console.error("rebook_tokens insert failed", tokInsErr);
    return json({ error: "token_persist_failed", details: tokInsErr.message }, 500);
  }
  const { data: tokCheck } = await admin
    .from("rebook_tokens").select("token").eq("token", token).maybeSingle();
  if (!tokCheck) {
    console.error("rebook_tokens read-after-write missing", { token });
    return json({ error: "token_not_persisted" }, 500);
  }

  // Always build the rebook link on the fixed public domain so emails sent from
  // the editor preview never produce login-gated dead links. (Do not use Origin.)
  const PUBLIC_BASE_URL = "https://jobs.expertintuitiveadvisor.com";
  const rebookUrl = `${PUBLIC_BASE_URL}/rebook/${token}`;

  const subject = "Let's reschedule your interview";
  const html = `<div style="font-family: Arial, Helvetica, sans-serif; color:#1a2547; font-size:15px; line-height:1.6;">
<p>Hi ${candidateName},</p>
<p>We'd like to reschedule your interview. Please use the link below to choose a new time that works for you:</p>
<p><a href="${rebookUrl}" style="color:#1a2547; font-weight:600;">${rebookUrl}</a></p>
<p style="color:#6b7280; font-size:13px;">This link expires in 3 days.</p>
<p>We look forward to speaking with you.</p>
<p style="margin-top:24px;">Warmly,<br/>
<strong>Angela Stein</strong><br/>
HR — Talent Manager<br/>
Expert Intuitive Advisor Inc.</p>
</div>`;
  try {
    await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${RESEND_API_KEY}`,
      },
      body: JSON.stringify({
        from: "Angela Stein <talent@expertintuitiveadvisor.com>",
        to: [candidateEmail], subject, html,
      }),
    });
  } catch (e) { console.error("recovery email error", e); }

  const ip = req.headers.get("x-forwarded-for") || "";
  await admin.from("password_audit_log").insert({
    hr_user_id: ident.hrId,
    password_used: "n/a",
    action_taken: `Sent reschedule link (${candidateEmail})`,
    target_resource_id: slot_id,
    ip_address: ip,
  });

  fetch(`${SUPABASE_URL}/functions/v1/send-override-audit-email`, {
    method: "POST",
    headers: { Authorization: `Bearer ${SERVICE_KEY}`, "Content-Type": "application/json" },
    body: JSON.stringify({
      action: "send_recovery", hr_email: ident.email, hr_name: ident.displayName,
      slot_id, candidate_email: candidateEmail,
    }),
  }).catch(() => {});

  return json({ success: true, rebook_url: rebookUrl });
});
