import { createClient } from "npm:@supabase/supabase-js@2";
import nodemailer from "npm:nodemailer@6.9.14";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
const SUPABASE_ANON_KEY = Deno.env.get("SUPABASE_ANON_KEY")!;
const SERVICE_KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
const RESEND_API_KEY = Deno.env.get("RESEND_API_KEY")!;
const GMAIL_USER = (Deno.env.get("GMAIL_USER") ?? "").trim();
// Strip all whitespace from app password (Google displays it with spaces but they must be removed)
const GMAIL_APP_PASSWORD = (Deno.env.get("GMAIL_APP_PASSWORD") ?? "").replace(/\s+/g, "");

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const VALID_STAGES = ["stage_1_thank_you", "stage_2_interview", "stage_2_round_1", "stage_2_round_2", "stage_3_offer", "onboarding_nda_sent", "joining_nda_sent", "exit_nda_sent", "onboarding_equipment_instructions", "settlement_sent", "leave_form_sent", "leave_approved", "leave_declined", "cash_advance_form_sent", "cash_advance_approved", "cash_advance_declined", "id_collection_form_sent", "id_collection_approved", "id_collection_declined", "pre_consultation_form_sent", "pre_consultation_approved", "pre_consultation_declined", "custom_document_sent", "test", "manual_resend", "other"];

// Feature flag: temporarily disable Gmail SMTP (sender_b). When false, only Resend (sender_a) sends.
const GMAIL_SMTP_ENABLED = false;

interface Attachment {
  filename: string;
  content: string; // base64
  content_type?: string;
}
const MAX_HTML_BYTES = 500_000;

interface SenderPayload {
  from_name: string;
  from_address: string;
  subject: string;
  html_body: string;
  text_body: string;
}

function validateSender(s: any): string | null {
  if (!s || typeof s !== "object") return "missing sender block";
  for (const k of ["from_name", "from_address", "subject", "html_body", "text_body"]) {
    if (typeof s[k] !== "string" || !s[k]) return `sender.${k} required`;
  }
  if (!EMAIL_RE.test(s.from_address)) return "sender.from_address invalid";
  if (new TextEncoder().encode(s.html_body).length > MAX_HTML_BYTES) return "html_body exceeds 500KB";
  return null;
}

const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));

// Verified sending-domain reply address. NEVER reply_to the internal Gmail.
const REPLY_TO = "talent@careers.expertintuitiveadvisor.com";

// Reads the editable HR-copy recipient LIVE from app_settings.hr_copy_email
// (same source used by _shared/hr-copy.ts). Returns null when cleared/invalid,
// in which case NO bcc copy is sent. Never throws.
async function resolveHrCopyBcc(admin: ReturnType<typeof createClient>): Promise<string | null> {
  try {
    const { data } = await admin
      .from("app_settings")
      .select("hr_copy_email")
      .eq("id", 1)
      .maybeSingle();
    const v = (data as any)?.hr_copy_email?.trim();
    if (v && EMAIL_RE.test(v)) return v;
  } catch (_) { /* swallow — absence of copy must not break the primary send */ }
  return null;
}

async function sendViaResend(to: string, refId: string, s: SenderPayload, attachments: Attachment[] | undefined, bccCopy: string | null, attempt = 1): Promise<{ ok: boolean; id?: string; error?: string }> {
  try {
    const ctrl = new AbortController();
    const t = setTimeout(() => ctrl.abort(), 15000);
    const payload: Record<string, any> = {
      from: `${s.from_name} <${s.from_address}>`,
      to: [to],
      // Optional internal copy — only when HR has set app_settings.hr_copy_email.
      // When cleared/disabled, no bcc is added so no copy fires.
      ...(bccCopy ? { bcc: [bccCopy] } : {}),
      reply_to: REPLY_TO,
      subject: s.subject,
      html: s.html_body,
      text: s.text_body,
      headers: { "X-Entity-Ref-ID": refId },
    };
    if (attachments && attachments.length) {
      payload.attachments = attachments.map((a) => ({
        filename: a.filename,
        content: a.content,
        ...(a.content_type ? { content_type: a.content_type } : {}),
      }));
    }
    const res = await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${RESEND_API_KEY}`,
        "Content-Type": "application/json",
      },
      signal: ctrl.signal,
      body: JSON.stringify(payload),
    });
    clearTimeout(t);
    const data = await res.json().catch(() => ({}));
    if (res.status === 429 && attempt === 1) {
      await sleep(5000);
      return sendViaResend(to, refId, s, attachments, bccCopy, 2);
    }
    if (!res.ok) return { ok: false, error: `Resend ${res.status}: ${JSON.stringify(data)}` };
    return { ok: true, id: data.id };
  } catch (e: any) {
    return { ok: false, error: `Resend exception: ${e?.message || String(e)}` };
  }
}

async function sendViaGmail(to: string, s: SenderPayload, attachments: Attachment[] | undefined, attempt = 1): Promise<{ ok: boolean; error?: string }> {
  try {
    const transporter = nodemailer.createTransport({
      host: "smtp.gmail.com",
      port: 587,
      secure: false,
      auth: { user: GMAIL_USER, pass: GMAIL_APP_PASSWORD },
      connectionTimeout: 15000,
      greetingTimeout: 15000,
      socketTimeout: 15000,
    });
    const mail: Record<string, any> = {
      from: `${s.from_name} <${GMAIL_USER}>`,
      to,
      subject: s.subject,
      html: s.html_body,
      text: s.text_body,
    };
    if (attachments && attachments.length) {
      mail.attachments = attachments.map((a) => ({
        filename: a.filename,
        content: a.content,
        encoding: "base64",
        contentType: a.content_type || "application/octet-stream",
      }));
    }
    await transporter.sendMail(mail);
    return { ok: true };
  } catch (e: any) {
    const msg = e?.message || String(e);
    const code = e?.code || "";
    const isConn = code === "ECONNREFUSED" || code === "ETIMEDOUT" || code === "ESOCKET";
    if (isConn && attempt === 1) {
      await sleep(3000);
      return sendViaGmail(to, s, attachments, 2);
    }
    return { ok: false, error: `Gmail ${code}: ${msg}` };
  }
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });

  try {
    // Auth: either valid user JWT OR service role key
    const authHeader = req.headers.get("Authorization") || "";
    const token = authHeader.replace("Bearer ", "");
    let authed = false;
    if (token === SERVICE_KEY) {
      authed = true;
    } else if (token) {
      const sb = createClient(SUPABASE_URL, SUPABASE_ANON_KEY, { global: { headers: { Authorization: authHeader } } });
      const { data, error } = await sb.auth.getClaims(token);
      if (!error && data?.claims) authed = true;
    }
    if (!authed) {
      return new Response(JSON.stringify({ error: "Unauthorized" }), { status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }

    const body = await req.json().catch(() => null);
    if (!body) return new Response(JSON.stringify({ error: "invalid JSON" }), { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } });

    const { to, candidate_id, job_offer_id, stage, sender_a, sender_b, attachments, _test_break_resend, second_via_resend } = body;
    // Opt-in flag: when true and Gmail SMTP is disabled, sender_b is sent via Resend
    // (from its own verified from_address) instead of being skipped. Defaults off so
    // existing callers are unaffected.
    const sendSecondViaResend = second_via_resend === true && !GMAIL_SMTP_ENABLED;
    const attachList: Attachment[] | undefined = Array.isArray(attachments)
      ? attachments.filter((a: any) => a && typeof a.filename === "string" && typeof a.content === "string")
      : undefined;
    if (!EMAIL_RE.test(to || "")) return new Response(JSON.stringify({ error: "invalid 'to'" }), { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } });
    if (!VALID_STAGES.includes(stage)) return new Response(JSON.stringify({ error: "invalid stage" }), { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } });
    const eA = validateSender(sender_a);
    const eB = validateSender(sender_b);
    if (eA) return new Response(JSON.stringify({ error: `sender_a: ${eA}` }), { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } });
    if (eB) return new Response(JSON.stringify({ error: `sender_b: ${eB}` }), { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } });

    const admin = createClient(SUPABASE_URL, SERVICE_KEY);

    // Insert pending rows (Gmail row only inserted when feature flag is enabled)
    const rows: any[] = [
      {
        candidate_id: candidate_id ?? null,
        job_offer_id: job_offer_id ?? null,
        stage,
        sender: "resend",
        from_address: sender_a.from_address,
        from_name: sender_a.from_name,
        to_address: to,
        subject: sender_a.subject,
        status: "pending",
      },
    ];
    if (GMAIL_SMTP_ENABLED) {
      rows.push({
        candidate_id: candidate_id ?? null,
        job_offer_id: job_offer_id ?? null,
        stage,
        sender: "gmail_smtp",
        from_address: GMAIL_USER,
        from_name: sender_b.from_name,
        to_address: to,
        subject: sender_b.subject,
        status: "pending",
      });
    } else if (sendSecondViaResend) {
      rows.push({
        candidate_id: candidate_id ?? null,
        job_offer_id: job_offer_id ?? null,
        stage,
        sender: "resend",
        from_address: sender_b.from_address,
        from_name: sender_b.from_name,
        to_address: to,
        subject: sender_b.subject,
        status: "pending",
      });
    }
    const { data: inserted, error: insErr } = await admin.from("email_log").insert(rows).select("id");
    if (insErr || !inserted) {
      return new Response(JSON.stringify({ error: "log insert failed", details: insErr?.message }), { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }
    const logAId = inserted[0].id;
    const logBId = inserted[1]?.id ?? null;
    const refId = candidate_id || job_offer_id || "n/a";

    // Resolve the optional internal copy recipient LIVE from app_settings.
    // null => no bcc copy is sent (HR cleared/disabled it).
    const hrCopyBcc = await resolveHrCopyBcc(admin);

    const [rRes, gRes] = await Promise.allSettled([
      _test_break_resend
        ? Promise.resolve({ ok: false, error: "TEST: forced Resend failure" })
        : sendViaResend(to, refId, sender_a, attachList, hrCopyBcc),
      GMAIL_SMTP_ENABLED
        ? sendViaGmail(to, sender_b, attachList)
        : sendSecondViaResend
          ? sendViaResend(to, refId, sender_b, attachList, hrCopyBcc)
          : Promise.resolve({ ok: true, skipped: true as const }),
    ]);

    const aOut = rRes.status === "fulfilled" ? rRes.value : { ok: false, error: String(rRes.reason) };
    const bOut = gRes.status === "fulfilled" ? gRes.value : { ok: false, error: String(gRes.reason) };

    await admin.from("email_log").update(
      aOut.ok
        ? { status: "sent", resend_message_id: (aOut as any).id ?? null, sent_at: new Date().toISOString() }
        : { status: "failed", error_message: aOut.error ?? "unknown" }
    ).eq("id", logAId);

    if (logBId) {
      await admin.from("email_log").update(
        bOut.ok
          ? { status: "sent", resend_message_id: (bOut as any).id ?? null, sent_at: new Date().toISOString() }
          : { status: "failed", error_message: bOut.error ?? "unknown" }
      ).eq("id", logBId);
    }

    const status = aOut.ok && bOut.ok ? 200 : 207;
    return new Response(
      JSON.stringify({
        resend_a: { success: aOut.ok, message_id: (aOut as any).id ?? null, error: aOut.error ?? null },
        resend_b: { success: bOut.ok, message_id: (bOut as any).id ?? null, error: bOut.error ?? null },
        log_ids: [logAId, logBId],
      }),
      { status, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (e: any) {
    return new Response(JSON.stringify({ error: "server error", details: e?.message || String(e) }), { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } });
  }
});
