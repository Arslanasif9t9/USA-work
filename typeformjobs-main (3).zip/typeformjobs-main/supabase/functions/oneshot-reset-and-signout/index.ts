// One-shot: reset password + revoke sessions for hr1 & hr2. Delete after use.
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.45.0";
import postgres from "https://deno.land/x/postgresjs@v3.4.4/mod.js";

const cors = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: cors });
  const body = await req.json().catch(() => ({}));
  const targets: { email: string; pw: string }[] = body.targets || [];
  if (!targets.length) return new Response(JSON.stringify({ error: "no_targets" }), { status: 400, headers: { ...cors, "Content-Type": "application/json" } });

  const admin = createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!);
  const sql = postgres(Deno.env.get("SUPABASE_DB_URL")!, { prepare: false });
  const results: any[] = [];

  const { data: list, error: listErr } = await admin.auth.admin.listUsers({ perPage: 1000 });
  if (listErr) { await sql.end(); return new Response(JSON.stringify({ error: listErr.message }), { status: 500, headers: { ...cors, "Content-Type": "application/json" } }); }

  for (const t of targets) {
    const email = t.email.toLowerCase();
    const u = list.users.find((x: any) => (x.email || "").toLowerCase() === email);
    if (!u) { results.push({ email, ok: false, error: "user_not_found" }); continue; }
    const { error: updErr } = await admin.auth.admin.updateUserById(u.id, { password: t.pw });
    if (updErr) { results.push({ email, ok: false, error: updErr.message }); continue; }
    const tokens = await sql`DELETE FROM auth.refresh_tokens WHERE user_id = ${u.id}::text RETURNING id`;
    const sessions = await sql`DELETE FROM auth.sessions WHERE user_id = ${u.id}::uuid RETURNING id`;
    results.push({ email, ok: true, password_updated: true, refresh_tokens_deleted: tokens.length, sessions_deleted: sessions.length });
  }
  await sql.end();
  return new Response(JSON.stringify({ results }), { headers: { ...cors, "Content-Type": "application/json" } });
});
