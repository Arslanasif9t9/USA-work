// validate-onboarding-quiz-token: PUBLIC. Token-gated + identity-gated.
// Two actions:
//   (default)        -> returns link validity, status, video_url, attempts info.
//                       Does NOT leak the candidate's identity.
//   action="verify"  -> body { token, name, email }. Verifies the entered
//                       identity matches the token (case-insensitive, trimmed).
//                       On match returns the quiz questions WITHOUT correct_index.
import { createClient } from "npm:@supabase/supabase-js@2";
import { DEFAULT_ONBOARDING_VIDEO_URL } from "../_shared/onboarding-video.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};
const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
const SERVICE = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
const json = (b: unknown, s = 200) =>
  new Response(JSON.stringify(b), { status: s, headers: { ...corsHeaders, "Content-Type": "application/json" } });

// Fallback video used when a token has no per-link video_url, so a candidate
// never hits a dead player. Single shared default.
const DEFAULT_VIDEO_URL = DEFAULT_ONBOARDING_VIDEO_URL;
const MAX_ATTEMPTS = 3;
const norm = (s: unknown) => (typeof s === "string" ? s.trim().toLowerCase() : "");

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });
  try {
    const body = await req.json().catch(() => ({}));
    const token = typeof body?.token === "string" ? body.token.trim() : "";
    const action = typeof body?.action === "string" ? body.action : "";
    if (!token) return json({ error: "missing_token" }, 400);

    const admin = createClient(SUPABASE_URL, SERVICE);
    const { data: tok } = await admin
      .from("onboarding_quiz_tokens").select("*").eq("token", token).maybeSingle();

    if (!tok) return json({ valid: false, reason: "not_found" });
    if (tok.status === "invalidated") return json({ valid: false, reason: "invalidated" });
    if (tok.status === "failed_out") return json({ valid: false, reason: "failed_out" });
    if (tok.passed) return json({ valid: false, reason: "passed" });
    if (tok.invalidated_at) return json({ valid: false, reason: "invalidated" });
    if (new Date(tok.expires_at) < new Date()) return json({ valid: false, reason: "expired" });

    const videoUrl = (tok.video_url || DEFAULT_VIDEO_URL) || null;

    // ── Identity (light record-keeping only) + quiz fetch ───────────────────
    // No hard match: any entered name/email is accepted. We just return the
    // quiz so the candidate can proceed straight to the video + check.
    if (action === "verify") {
      const { data: qs } = await admin
        .from("onboarding_quiz_questions")
        .select("id, order_index, question, options")
        .eq("active", true)
        .order("order_index", { ascending: true });

      const questions = (qs || []).map((q: any) => ({
        id: q.id,
        question: q.question,
        options: Array.isArray(q.options) ? q.options : [],
      }));

      return json({
        valid: true,
        identity_ok: true,
        candidate_name: tok.candidate_name || "",
        candidate_email: tok.candidate_email || "",
        video_url: videoUrl,
        attempts_used: tok.attempts_used || 0,
        max_attempts: MAX_ATTEMPTS,
        total_questions: questions.length,
        pass_mark: 9,
        questions,
      });
    }

    // ── Default: public-safe status + pre-fill identity ─────────────────────
    return json({
      valid: true,
      status: tok.status,
      candidate_name: tok.candidate_name || "",
      candidate_email: tok.candidate_email || "",
      video_url: videoUrl,
      attempts_used: tok.attempts_used || 0,
      max_attempts: MAX_ATTEMPTS,
      expires_at: tok.expires_at,
    });
  } catch (e: any) {
    return json({ error: "internal", details: String(e?.message || e) }, 500);
  }
});
