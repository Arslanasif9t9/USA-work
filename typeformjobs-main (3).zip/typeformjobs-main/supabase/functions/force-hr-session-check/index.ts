import { createClient } from "https://esm.sh/@supabase/supabase-js@2.45.0";
import postgres from "https://deno.land/x/postgresjs@v3.4.4/mod.js";

const cors = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

const FORCE_LOGOUT_EMAILS = new Set(["hr1@expert.com", "hr2@expert.com"]);
const FORCE_LOGOUT_AFTER_MS = Date.parse("2026-05-20T08:17:50.000Z");

const getTokenIssuedAtMs = (token: string) => {
  try {
    const payload = token.split(".")[1];
    const padded = payload.replace(/-/g, "+").replace(/_/g, "/").padEnd(Math.ceil(payload.length / 4) * 4, "=");
    const decoded = JSON.parse(atob(padded)) as { iat?: number };
    return decoded.iat ? decoded.iat * 1000 : null;
  } catch {
    return null;
  }
};

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: cors });

  const authHeader = req.headers.get("Authorization") || "";
  const token = authHeader.replace(/^Bearer\s+/i, "").trim();

  if (!token) {
    return new Response(JSON.stringify({ forceLogout: false }), {
      status: 200,
      headers: { ...cors, "Content-Type": "application/json" },
    });
  }

  const admin = createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!);
  const { data, error } = await admin.auth.getUser(token);
  const email = data.user?.email?.toLowerCase() || "";

  if (error || !data.user || !FORCE_LOGOUT_EMAILS.has(email)) {
    return new Response(JSON.stringify({ forceLogout: false }), {
      status: 200,
      headers: { ...cors, "Content-Type": "application/json" },
    });
  }

  const issuedAtMs = getTokenIssuedAtMs(token);
  if (issuedAtMs !== null && issuedAtMs >= FORCE_LOGOUT_AFTER_MS) {
    return new Response(JSON.stringify({ forceLogout: false, email }), {
      status: 200,
      headers: { ...cors, "Content-Type": "application/json" },
    });
  }

  const sql = postgres(Deno.env.get("SUPABASE_DB_URL")!, { prepare: false });
  try {
    const tokens = await sql`DELETE FROM auth.refresh_tokens WHERE user_id = ${data.user.id}::text RETURNING id`;
    const sessions = await sql`DELETE FROM auth.sessions WHERE user_id = ${data.user.id}::uuid RETURNING id`;

    return new Response(
      JSON.stringify({
        forceLogout: true,
        email,
        refresh_tokens_deleted: tokens.length,
        sessions_deleted: sessions.length,
      }),
      { status: 200, headers: { ...cors, "Content-Type": "application/json" } },
    );
  } finally {
    await sql.end();
  }
});