// log-ai-interview-failure: PUBLIC. Records why an AI interview failed to connect.
import { createClient } from "npm:@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
const SERVICE = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });
  try {
    const body = await req.json().catch(() => ({}));
    const {
      token = null,
      device_type = null,
      user_agent = null,
      failure_stage = null,
      audio_context_state = null,
      retell_error = null,
    } = body || {};

    const admin = createClient(SUPABASE_URL, SERVICE);

    let response_id: string | null = null;
    if (token) {
      const { data: tok } = await admin
        .from("rebook_tokens")
        .select("response_id")
        .eq("token", token)
        .maybeSingle();
      response_id = tok?.response_id ?? null;
    }

    const { error } = await admin.from("ai_interview_failures").insert({
      response_id,
      token,
      device_type,
      user_agent,
      failure_stage,
      audio_context_state,
      retell_error: typeof retell_error === "string" ? retell_error : JSON.stringify(retell_error),
    });
    if (error) {
      console.error("[log-ai-interview-failure] insert error:", error);
      return new Response(JSON.stringify({ error: error.message }), {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }
    return new Response(JSON.stringify({ ok: true }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (e: any) {
    console.error("[log-ai-interview-failure] exception:", e);
    return new Response(JSON.stringify({ error: String(e?.message || e) }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
