// Public, token-gated endpoint that returns a candidate's live pipeline status.
// Mirrors the /rebook/:token security pattern. NEVER leaks data for an invalid
// or revoked token. Read-only — never writes.
import { adminClient, corsHeaders, json } from "../_shared/hr-auth.ts";

const NOT_FOUND = { valid: false, reason: "not_found" as const };

const EMAIL_LABEL_RE = /e[\s-]?mail/i;
const EMAIL_EXCLUDE_RE = /(onlinejob|online\s*jobs?|profile|link|url)/i;

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });

  let body: { token?: unknown };
  try { body = await req.json(); } catch { return json(NOT_FOUND, 200); }
  const token = typeof body?.token === "string" ? body.token.trim() : "";
  if (!token) return json(NOT_FOUND, 200);

  const admin = adminClient();

  // Single-row lookup by token.
  const { data: tok, error: tokErr } = await admin
    .from("tracking_tokens")
    .select("id, token, response_id, expires_at, revoked_at")
    .eq("token", token)
    .maybeSingle();

  if (tokErr || !tok) return json(NOT_FOUND, 200);
  if (tok.revoked_at) return json(NOT_FOUND, 200);
  if (tok.expires_at && new Date(tok.expires_at).getTime() < Date.now()) {
    return json({ valid: false, reason: "expired" }, 200);
  }

  // Load LIVE status from responses (single authoritative signal).
  const { data: resp, error: respErr } = await admin
    .from("responses")
    .select("id, form_id, round_stage, override_name")
    .eq("id", tok.response_id)
    .maybeSingle();
  if (respErr || !resp) return json(NOT_FOUND, 200);

  // Position title: form_metadata.position_title → fallback to forms.title.
  let positionTitle: string | null = null;
  const { data: meta } = await admin
    .from("form_metadata")
    .select("position_title")
    .eq("form_id", resp.form_id)
    .maybeSingle();
  positionTitle = meta?.position_title || null;
  if (!positionTitle) {
    const { data: form } = await admin
      .from("forms").select("title").eq("id", resp.form_id).maybeSingle();
    positionTitle = form?.title || null;
  }

  // Candidate first name (best-effort, safe). Prefer override_name, then detect the name question.
  let firstName: string | null = null;
  const overrideFull = ((resp as any).override_name || "").trim();
  if (overrideFull) {
    firstName = overrideFull.split(/\s+/)[0] || null;
  } else {
    try {
      const { data: qs } = await admin
        .from("questions").select("id, type, label").eq("form_id", resp.form_id);
      const nameQ =
        (qs || []).find((q: any) => q.type === "short_text" && /name/i.test(q.label || "")) ||
        (qs || []).find((q: any) => q.type === "short_text");
      if (nameQ) {
        const { data: ans } = await admin
          .from("answers")
          .select("answer_text")
          .eq("response_id", resp.id)
          .eq("question_id", nameQ.id)
          .maybeSingle();
        const full = (ans?.answer_text || "").trim();
        if (full) firstName = full.split(/\s+/)[0] || null;
      }
    } catch { /* non-fatal */ }
  }

  // Read-only completion fallback: older completions may still have
  // round_stage = 'round_1_sent' (pre-webhook-writeback). If a real completed
  // AI interview session exists for this response, surface that to the page
  // as 'ai_interview_completed'. No DB write.
  let effectiveStage: string | null = resp.round_stage ?? null;
  const ADVANCED = new Set([
    "ai_interview_completed",
    "round_2_sent",
    "offer_sent",
    "offer_signed",
    "offer_expired",
    "disqualified",
    "terminated",
  ]);
  if (!effectiveStage || !ADVANCED.has(effectiveStage)) {
    try {
      const { data: sessions } = await admin
        .from("ai_interview_sessions")
        .select("duration_seconds, termination_reason")
        .eq("response_id", resp.id);
      const realCompletion = (sessions || []).some((s: any) => {
        const dur = Number(s?.duration_seconds || 0);
        const term = String(s?.termination_reason || "");
        if (dur <= 20) return false;
        if (/error|not_joined|failed|abandon/i.test(term)) return false;
        return true;
      });
      if (realCompletion) effectiveStage = "ai_interview_completed";
    } catch { /* non-fatal — keep original stage */ }
  }

  // SANITIZED payload only. No internal ids, no email, no HR id, no notes,
  // no other candidates' data. round_stage stays as the raw signal so the
  // page (3.2) can map it to a candidate-safe label.
  return json({
    valid: true,
    round_stage: effectiveStage,
    position_title: positionTitle,
    first_name: firstName,
  }, 200);
});
