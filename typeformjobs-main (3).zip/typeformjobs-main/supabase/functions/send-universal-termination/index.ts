// send-universal-termination: admin-gated one-off "Notice of Termination" email
// to any name + email. Boss password gated. Does NOT touch job_offers / responses
// / termination_log / candidate_actions — universal recipients have no employee
// record. Logs only to email_log + notification_log + password_audit_log.
import { createClient } from "npm:@supabase/supabase-js@2";
import { sendCompletionBackups } from "../_shared/archive-and-backup.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
const ANON = Deno.env.get("SUPABASE_ANON_KEY")!;
const SERVICE = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
const RESEND_API_KEY = Deno.env.get("RESEND_API_KEY")!;
const GMAIL_USER = (Deno.env.get("GMAIL_USER") ?? "").trim();
const BOSS_PASSWORD = Deno.env.get("BOSS_TERMINATION_PASSWORD") || "Boss2828";

const FROM_NAME = "Cathy Anderson";
const FROM_ADDRESS = "talent@expertintuitiveadvisor.com";
const HR_INBOX = "talent.expertadvisor@outlook.com";
const BOSS_INBOX = "spark11179@gmail.com";

const json = (b: unknown, status = 200) =>
  new Response(JSON.stringify(b), { status, headers: { ...corsHeaders, "Content-Type": "application/json" } });

function buildEmail(firstName: string) {
  const subject = "Notice of Termination — Expert Intuitive Advisor Inc.";
  const text = `Dear ${firstName},\n\nWe are writing to formally inform you that you have been terminated from Expert Intuitive Advisor Inc., effective immediately. You will no longer be working with the company in any capacity.\n\nPlease understand that this decision is not a reflection of your character, your abilities, or your potential. We sincerely thank you for the time, effort, and consideration you have given us, and we appreciate everything you have contributed during your time with the company.\n\nAny outstanding matters concerning final payment or company materials will be addressed separately in due course. We kindly ask that you ensure all company information, files, accounts, and access are properly returned or deleted in accordance with the terms of the agreements you have signed.\n\nWe wish you continued success and every good wish in your future endeavors.\n\nRespectfully,\nCathy Anderson\nHiring Director\nExpert Intuitive Advisor Inc.`;
  const html = text.replace(/\n/g, "<br/>");
  return { subject, text, html };
}

async function sendResend(to: string, subject: string, html: string, text: string, bcc: string[]) {
  const r = await fetch("https://api.resend.com/emails", {
    method: "POST",
    headers: { Authorization: `Bearer ${RESEND_API_KEY}`, "Content-Type": "application/json" },
    body: JSON.stringify({
      from: `${FROM_NAME} <${FROM_ADDRESS}>`,
      to: [to],
      bcc: bcc.length ? bcc : undefined,
      reply_to: GMAIL_USER || undefined,
      subject, html, text,
    }),
  });
  const data = await r.json().catch(() => ({}));
  return { ok: r.ok, id: (data as any)?.id ?? null, error: r.ok ? null : JSON.stringify(data) };
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });

  try {
    const authHeader = req.headers.get("Authorization");
    if (!authHeader?.startsWith("Bearer ")) return json({ error: "unauthorized" }, 401);

    const userClient = createClient(SUPABASE_URL, ANON, { global: { headers: { Authorization: authHeader } } });
    const { data: userData, error: uErr } = await userClient.auth.getUser();
    if (uErr || !userData?.user) return json({ error: "unauthorized" }, 401);

    const adminClient = createClient(SUPABASE_URL, SERVICE);

    const body = await req.json().catch(() => ({}));
    const { name, email, termination_type, password } = body || {};
    const nameClean = typeof name === "string" ? name.trim() : "";
    const emailClean = typeof email === "string" ? email.trim() : "";
    if (!nameClean) return json({ error: "invalid_name" }, 400);
    if (!emailClean || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(emailClean)) return json({ error: "invalid_email" }, 400);
    if (!["evaluation", "regular"].includes(termination_type)) return json({ error: "invalid_termination_type" }, 400);
    if (typeof password !== "string") return json({ error: "invalid_request" }, 400);

    // identify HR
    const hrEmail = (userData.user.email || "").toLowerCase();
    const { data: hr } = await adminClient.from("hr_users").select("id").ilike("email", hrEmail).maybeSingle();
    const hrId = hr?.id ?? null;

    if (password !== BOSS_PASSWORD) {
      await adminClient.from("password_audit_log").insert({
        hr_user_id: hrId, password_used: "***wrong***",
        action_taken: `universal_termination_${termination_type}_failed`, target_resource_id: null,
      });
      return json({ error: "wrong_password" }, 401);
    }

    const firstName = nameClean.split(/\s+/)[0] || nameClean;
    const built = buildEmail(firstName);

    const { data: logRow } = await adminClient.from("email_log").insert({
      to_address: emailClean,
      from_address: FROM_ADDRESS,
      from_name: FROM_NAME,
      sender: "resend",
      subject: built.subject,
      stage: "universal_termination_sent",
      status: "pending",
      candidate_id: null,
      job_offer_id: null,
      error_message: `universal_termination_type:${termination_type}`,
    }).select("id").single();
    const emailLogId = logRow?.id ?? null;

    const sendRes = await sendResend(emailClean, built.subject, built.html, built.text, [HR_INBOX, BOSS_INBOX]);

    if (emailLogId) {
      await adminClient.from("email_log").update({
        status: sendRes.ok ? "sent" : "failed",
        sent_at: sendRes.ok ? new Date().toISOString() : null,
        resend_message_id: sendRes.id,
        error_message: sendRes.ok
          ? `universal_termination_type:${termination_type}`
          : `universal_termination_type:${termination_type} | ${sendRes.error}`,
      }).eq("id", emailLogId);
    }

    await adminClient.from("password_audit_log").insert({
      hr_user_id: hrId,
      password_used: "***boss-universal-termination***",
      action_taken: `universal_termination_${termination_type}`,
      target_resource_id: null,
    });

    await adminClient.from("notification_log").insert({
      event_type: "universal_termination_sent",
      recipient_email: emailClean,
      related_resource_id: null,
      status: sendRes.ok ? "sent" : "failed",
    });

    if (!sendRes.ok) return json({ ok: false, reason: sendRes.error || "send_failed" }, 502);

    // === Piece 6 Part A: always-on Outlook backup + optional Gmail copy ===
    // Universal termination has no persisted record, so checkbox flags come from the request body.
    const hrCopyRequested = !!(body as any)?.hr_copy_requested;
    const hrCopyOverride = typeof (body as any)?.hr_copy_email_override === "string"
      ? (body as any).hr_copy_email_override.trim() || null
      : null;
    try {
      const backup = await sendCompletionBackups({
        admin: adminClient,
        doc_type: "termination",
        recipient_name: nameClean,
        external_reference: `UTERM-${emailLogId || crypto.randomUUID()}`,
        pdf_bytes: null,
        source_pdf_url: null,
        extras: [["Type", termination_type], ["Recipient email", emailClean]],
        hr_copy_requested: hrCopyRequested,
        hr_copy_email_override: hrCopyOverride,
      });
      console.log("[send-universal-termination] backups", {
        main_backup_sent: backup.main_backup_sent, hr_copy_sent: backup.hr_copy_sent,
      });
    } catch (e) {
      console.warn("[send-universal-termination] backup_warn", (e as Error).message);
    }

    return json({ ok: true, email_sent: true, recipient: emailClean, email_log_id: emailLogId });
  } catch (e) {
    return json({ error: (e as Error).message }, 500);
  }
});
