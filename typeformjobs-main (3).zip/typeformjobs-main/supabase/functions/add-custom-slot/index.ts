// add-custom-slot: admin-only. Adds a slot outside default working hours.
import { createClient } from "npm:@supabase/supabase-js@2";
import { manilaWallToUtc } from "../_shared/manila.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

async function requireAdmin(req: Request) {
  const auth = req.headers.get("Authorization") || "";
  if (!auth.startsWith("Bearer ")) return { error: "missing_auth", status: 401 };
  const userClient = createClient(
    Deno.env.get("SUPABASE_URL")!,
    Deno.env.get("SUPABASE_ANON_KEY")!,
    { global: { headers: { Authorization: auth } } },
  );
  const { data, error } = await userClient.auth.getUser();
  if (error || !data?.user) return { error: "invalid_jwt", status: 401 };
  return { user: data.user };
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });
  const guard = await requireAdmin(req);
  if ("error" in guard) {
    return new Response(JSON.stringify({ error: guard.error }), {
      status: guard.status, headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }

  const admin = createClient(
    Deno.env.get("SUPABASE_URL")!,
    Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!,
  );

  let body: any;
  try { body = await req.json(); } catch {
    return new Response(JSON.stringify({ error: "invalid_json" }), {
      status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
  const { slot_date, slot_time, notes } = body || {};
  if (!slot_date || !slot_time || !/^\d{4}-\d{2}-\d{2}$/.test(slot_date) || !/^\d{2}:\d{2}$/.test(slot_time)) {
    return new Response(JSON.stringify({ error: "invalid_input" }), {
      status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }

  const slotStart = manilaWallToUtc(slot_date, slot_time);
  if (slotStart.getTime() < Date.now()) {
    return new Response(JSON.stringify({ error: "slot_in_past" }), {
      status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
  const slotEnd = new Date(slotStart.getTime() + 30 * 60000);

  const { data, error } = await admin.from("interview_slots").insert({
    slot_start: slotStart.toISOString(),
    slot_end: slotEnd.toISOString(),
    slot_date,
    slot_time: `${slot_time}:00`,
    status: "available",
    created_by_admin: true,
    blocked_reason: notes || null,
  }).select("id").maybeSingle();

  if (error) {
    if (error.code === "23505") {
      return new Response(JSON.stringify({ error: "slot_exists" }), {
        status: 409, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }
    return new Response(JSON.stringify({ error: error.message }), {
      status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }

  return new Response(JSON.stringify({ success: true, slot_id: data?.id }), {
    status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" },
  });
});
