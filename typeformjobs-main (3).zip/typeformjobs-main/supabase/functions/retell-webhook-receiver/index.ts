import { createClient } from "npm:@supabase/supabase-js@2";
import { corsHeaders } from "npm:@supabase/supabase-js@2/cors";

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response("ok", { headers: corsHeaders });
  }

  try {
    const payload = await req.json().catch(() => ({}));
    console.log("[retell-webhook] incoming payload:", JSON.stringify(payload));

    const event = payload?.event;
    if (event !== "call_analyzed") {
      console.log(`[retell-webhook] ignoring event: ${event}`);
      return new Response(JSON.stringify({ ok: true, ignored: event }), {
        status: 200,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // Retell payload shape: { event, call: { call_id, transcript, recording_url, metadata, call_analysis: { ... }, ... } }
    const call = payload?.call ?? payload?.data ?? {};
    const analysis = call?.call_analysis ?? {};
    const custom = analysis?.custom_analysis_data ?? {};
    const metadata = call?.metadata ?? {};

    const retell_call_id = call?.call_id ?? call?.id ?? null;
    const transcript = call?.transcript_object ?? call?.transcript ?? null;
    const recording_url = call?.recording_url ?? null;

    // Duration
    let duration_seconds: number | null = null;
    if (typeof call?.duration_ms === "number") {
      duration_seconds = Math.round(call.duration_ms / 1000);
    } else if (typeof call?.duration_seconds === "number") {
      duration_seconds = call.duration_seconds;
    } else if (call?.start_timestamp && call?.end_timestamp) {
      duration_seconds = Math.round((call.end_timestamp - call.start_timestamp) / 1000);
    }

    // Cost
    let cost_usd: number | null = null;
    const cost = call?.call_cost ?? call?.cost ?? null;
    if (cost) {
      if (typeof cost === "number") cost_usd = cost;
      else if (typeof cost?.combined_cost === "number") cost_usd = cost.combined_cost / 100; // cents → usd if applicable
      else if (typeof cost?.total_cost === "number") cost_usd = cost.total_cost;
    }

    const termination_reason =
      call?.disconnection_reason ?? call?.termination_reason ?? analysis?.call_completion_rating ?? null;

    const response_id = metadata?.response_id ?? null;
    const stage = metadata?.stage ?? ((call as any)?.agent_id === "agent_9cbbf25c5a0d27cad1a61a3daa" ? "round2_ai" : null);
    if (!response_id) {
      console.warn("[retell-webhook] metadata.response_id missing on call", retell_call_id);
    }

    // Custom analysis fields (6)
    const tier = custom?.tier ?? null;
    const ai_recommended =
      typeof custom?.ai_recommended === "boolean"
        ? custom.ai_recommended
        : typeof custom?.ai_recommended === "string"
        ? /^(true|yes|1)$/i.test(custom.ai_recommended)
        : null;
    const red_flags = custom?.red_flags ?? null;
    const verdict = custom?.verdict ?? null;
    const availability = custom?.availability ?? null;
    const hunger = custom?.hunger ?? custom?.commitment ?? null;

    // Retell defaults
    const summary = analysis?.call_summary ?? analysis?.summary ?? null;
    const sentiment = analysis?.user_sentiment ?? null;

    const supabase = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!,
    );

    // ----- UPSERT: converge on the SAME row that save-interview-video-url touches -----
    // Order: (1) match by retell_call_id, (2) match by response_id where retell_call_id IS NULL,
    // (3) insert new. Never overwrites a non-null video_url.
    const webhookFields = {
      transcript,
      recording_url,
      duration_seconds,
      cost_usd,
      ended_at: new Date().toISOString(),
      termination_reason,
      stage,
    };

    let sessionRow: { id: string } | null = null;

    // (1) Existing row by retell_call_id (typical when save-video stub landed first)
    if (retell_call_id) {
      const { data: existing } = await supabase
        .from("ai_interview_sessions")
        .select("id, response_id")
        .eq("retell_call_id", retell_call_id)
        .maybeSingle();
      if (existing) {
        const patch: Record<string, unknown> = { ...webhookFields };
        if (!stage) delete patch.stage;
        // Backfill response_id if the stub didn't have it
        if (response_id && !existing.response_id) patch.response_id = response_id;
        const { data: upd, error: updErr } = await supabase
          .from("ai_interview_sessions")
          .update(patch)
          .eq("id", existing.id)
          .select("id")
          .single();
        if (updErr) throw updErr;
        sessionRow = upd;
        console.log("[retell-webhook] updated existing session by retell_call_id", sessionRow.id);
      }
    }

    // (2) Existing row by response_id with no retell_call_id yet — backfill it
    if (!sessionRow && response_id) {
      const { data: byResp } = await supabase
        .from("ai_interview_sessions")
        .select("id")
        .eq("response_id", response_id)
        .is("retell_call_id", null)
        .order("created_at", { ascending: false })
        .limit(1)
        .maybeSingle();
      if (byResp) {
        const patch: Record<string, unknown> = { ...webhookFields, retell_call_id };
        if (!stage) delete patch.stage;
        const { data: upd, error: updErr } = await supabase
          .from("ai_interview_sessions")
          .update(patch)
          .eq("id", byResp.id)
          .select("id")
          .single();
        if (updErr) throw updErr;
        sessionRow = upd;
        console.log("[retell-webhook] updated existing session by response_id (backfilled retell_call_id)", sessionRow.id);
      }
    }

    // (3) No existing row — upsert on retell_call_id so a racing save-video insert
    //     converges to ONE row. webhookFields has no video_url, so an existing
    //     non-null video_url is never overwritten. Unique index makes it atomic;
    //     a NULL retell_call_id simply inserts (NULLs are distinct).
    if (!sessionRow) {
      const { data: ins, error: insErr } = await supabase
        .from("ai_interview_sessions")
        .upsert({ response_id, retell_call_id, ...webhookFields }, { onConflict: "retell_call_id" })
        .select("id")
        .single();
      if (insErr) throw insErr;
      sessionRow = ins;
      console.log("[retell-webhook] upserted session", sessionRow.id);
    }
    // ----- end UPSERT -----

    const { error: evalErr } = await supabase.from("ai_interview_evaluations").insert({
      session_id: sessionRow.id,
      response_id,
      tier,
      ai_recommended,
      red_flags: red_flags == null ? null : String(red_flags),
      verdict,
      availability,
      hunger,
      summary,
      sentiment,
    });

    if (evalErr) throw evalErr;
    console.log("[retell-webhook] inserted evaluation for session", sessionRow.id);

    // ----- GLITCH 5: status writeback (additive, idempotent, single-row by response_id) -----
    // Only on real completions: must have response_id, real duration, and a non-error termination.
    // Wrapped so any failure here NEVER breaks the session/eval insert or webhook response.
    const isErrorTermination =
      typeof termination_reason === "string" &&
      /error|not_joined|failed|abandon/i.test(termination_reason);
    const isRealCompletion =
      !!response_id &&
      typeof duration_seconds === "number" &&
      duration_seconds > 20 &&
      !isErrorTermination;

    if (isRealCompletion) {
      // 1) candidate_actions.round1_attendance_status = 'attended' (idempotent)
      try {
        const { data: existingAction } = await supabase
          .from("candidate_actions")
          .select("id, round1_attendance_status")
          .eq("response_id", response_id)
          .maybeSingle();
        if (existingAction && (existingAction as any).round1_attendance_status !== "attended") {
          const { error: caErr } = await supabase
            .from("candidate_actions")
            .update({
              round1_attendance_status: "attended",
              round1_attendance_marked_at: new Date().toISOString(),
            })
            .eq("id", (existingAction as any).id);
          if (caErr) console.error("[retell-webhook] candidate_actions writeback failed (non-fatal)", caErr);
          else console.log("[retell-webhook] marked R1 attended for response", response_id);
        } else if (!existingAction) {
          console.log("[retell-webhook] no candidate_actions row for response (skipping R1 mark)", response_id);
        }
      } catch (caCatch) {
        console.error("[retell-webhook] candidate_actions writeback threw (non-fatal)", caCatch);
      }

      // 2) responses.round_stage = 'ai_interview_completed' (idempotent; do not overwrite later stages)
      try {
        const { data: respRow } = await supabase
          .from("responses")
          .select("id, round_stage")
          .eq("id", response_id)
          .maybeSingle();
        const cur = (respRow as any)?.round_stage as string | null | undefined;
        const advancedStages = new Set([
          "ai_interview_completed",
          "round_2_sent",
          "offer_sent",
          "offer_signed",
          "disqualified",
          "terminated",
        ]);
        if (respRow && !advancedStages.has(cur || "")) {
          const { error: rErr } = await supabase
            .from("responses")
            .update({ round_stage: "ai_interview_completed" })
            .eq("id", response_id);
          if (rErr) console.error("[retell-webhook] responses.round_stage writeback failed (non-fatal)", rErr);
          else console.log("[retell-webhook] set round_stage=ai_interview_completed for", response_id);
        }
      } catch (rCatch) {
        console.error("[retell-webhook] responses writeback threw (non-fatal)", rCatch);
      }

      // 3) responses.r1_completed_hours = whole hours from round_1_sent_at → now
      //    (72-hour completion timing). Single-row by id. First completion wins:
      //    never overwrite an existing non-null value. If round_1_sent_at is null,
      //    leave r1_completed_hours null. Fully wrapped — never breaks the webhook.
      try {
        const { data: tRow } = await supabase
          .from("responses")
          .select("id, round_1_sent_at, r1_completed_hours")
          .eq("id", response_id)
          .maybeSingle();
        const sentAt = (tRow as any)?.round_1_sent_at as string | null | undefined;
        const existingHours = (tRow as any)?.r1_completed_hours;
        if (tRow && sentAt && existingHours == null) {
          const elapsedMs = Date.now() - Date.parse(sentAt);
          if (Number.isFinite(elapsedMs) && elapsedMs >= 0) {
            const hours = Math.floor(elapsedMs / (1000 * 60 * 60));
            const { error: thErr } = await supabase
              .from("responses")
              .update({ r1_completed_hours: hours })
              .eq("id", response_id);
            if (thErr) console.error("[retell-webhook] r1_completed_hours writeback failed (non-fatal)", thErr);
            else console.log("[retell-webhook] set r1_completed_hours", { response_id, hours });
          }
        }
      } catch (thCatch) {
        console.error("[retell-webhook] r1_completed_hours writeback threw (non-fatal)", thCatch);
      }

      // 4) responses.r2_completed_hours = whole hours from round_2_sent_at → now,
      //    ONLY on a real Round-2 (Marissa) completion. Single-row by id. First
      //    completion wins: never overwrite an existing non-null value. If
      //    round_2_sent_at is null, leave r2_completed_hours null. The round is
      //    detected via the Retell agent id (Marissa = round 2). Fully wrapped —
      //    never breaks the webhook.
      try {
        const MARISSA_AGENT_ID = "agent_9cbbf25c5a0d27cad1a61a3daa";
        const callAgentId = (call as any)?.agent_id ?? null;
        const isRound2 = callAgentId === MARISSA_AGENT_ID;
        if (isRound2) {
          const { data: t2Row } = await supabase
            .from("responses")
            .select("id, round_2_sent_at, r2_completed_hours")
            .eq("id", response_id)
            .maybeSingle();
          const sent2At = (t2Row as any)?.round_2_sent_at as string | null | undefined;
          const existing2Hours = (t2Row as any)?.r2_completed_hours;
          if (t2Row && sent2At && existing2Hours == null) {
            const elapsed2Ms = Date.now() - Date.parse(sent2At);
            if (Number.isFinite(elapsed2Ms) && elapsed2Ms >= 0) {
              const hours2 = Math.floor(elapsed2Ms / (1000 * 60 * 60));
              const { error: th2Err } = await supabase
                .from("responses")
                .update({ r2_completed_hours: hours2 })
                .eq("id", response_id);
              if (th2Err) console.error("[retell-webhook] r2_completed_hours writeback failed (non-fatal)", th2Err);
              else console.log("[retell-webhook] set r2_completed_hours", { response_id, hours: hours2 });
            }
          }

          // 4b) candidate_actions.round2_attendance_status = 'attended' (idempotent).
          //     Mirrors the Round-1 auto-mark above; fires ONLY inside this real
          //     Round-2 (Marissa) completion branch so the offer gate
          //     (round2_attendance_status === 'attended') unlocks automatically.
          //     Single-row by response_id. Never overwrites an existing 'attended'.
          //     Fully wrapped — never breaks the webhook.
          try {
            const { data: existingR2Action } = await supabase
              .from("candidate_actions")
              .select("id, round2_attendance_status")
              .eq("response_id", response_id)
              .maybeSingle();
            if (existingR2Action && (existingR2Action as any).round2_attendance_status !== "attended") {
              const { error: ca2Err } = await supabase
                .from("candidate_actions")
                .update({
                  round2_attendance_status: "attended",
                  round2_attendance_marked_at: new Date().toISOString(),
                })
                .eq("id", (existingR2Action as any).id);
              if (ca2Err) console.error("[retell-webhook] round2_attendance writeback failed (non-fatal)", ca2Err);
              else console.log("[retell-webhook] marked R2 attended for response", response_id);
            } else if (!existingR2Action) {
              console.log("[retell-webhook] no candidate_actions row for response (skipping R2 mark)", response_id);
            }
          } catch (ca2Catch) {
            console.error("[retell-webhook] round2_attendance writeback threw (non-fatal)", ca2Catch);
          }
        } else {
          console.log("[retell-webhook] not a Round-2 (Marissa) call — skipping r2_completed_hours", { response_id });
        }
      } catch (th2Catch) {
        console.error("[retell-webhook] r2_completed_hours writeback threw (non-fatal)", th2Catch);
      }
    } else {
      console.log("[retell-webhook] skipping status writeback", {
        response_id, duration_seconds, termination_reason, isErrorTermination,
      });
    }
    // ----- end GLITCH 5 -----



    // ----- PHASE 3.3: auto-mint tracking token + email tracking link -----
    // Fire-and-forget. NEVER throw / block the webhook response on failure.
    if (response_id) {
      try {
        const PROJECT_URL = Deno.env.get("SUPABASE_URL")!;
        const SERVICE = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
        // mint-tracking-token is HR-auth gated, so we hit the table directly
        // here with the service role (additive, mirrors mint's reuse logic).
        const { data: existingTok } = await supabase
          .from("tracking_tokens")
          .select("token")
          .eq("response_id", response_id)
          .is("revoked_at", null)
          .order("created_at", { ascending: false })
          .limit(1)
          .maybeSingle();

        let trackingToken: string | null = existingTok?.token ?? null;
        let isNew = false;
        if (!trackingToken) {
          const bytes = new Uint8Array(32);
          crypto.getRandomValues(bytes);
          const newTok = Array.from(bytes, (b) => b.toString(16).padStart(2, "0")).join("");
          const { data: inserted } = await supabase
            .from("tracking_tokens")
            .insert({ token: newTok, response_id })
            .select("token")
            .maybeSingle();
          if (inserted?.token) { trackingToken = inserted.token; isNew = true; }
        }
        console.log("[retell-webhook] tracking token", { isNew, response_id });

        // Only email on first mint (prevents repeat sends on duplicate webhooks).
        if (isNew && trackingToken) {
          // Resolve candidate name + email via answers/responses (mirrors
          // interview-reminder-cron pattern).
          const { data: resp } = await supabase
            .from("responses")
            .select("id, form_id, override_email, override_name")
            .eq("id", response_id)
            .maybeSingle();
          if (resp) {
            const { data: qs } = await supabase
              .from("questions").select("id, type, label").eq("form_id", resp.form_id);
            const EMAIL_LABEL_RE = /e[\s-]?mail/i;
            const EMAIL_EXCLUDE_RE = /(onlinejob|online\s*jobs?|profile|link|url)/i;
            const emailQ = (qs || []).find((q: any) => EMAIL_LABEL_RE.test(q.label || "") && !EMAIL_EXCLUDE_RE.test(q.label || ""))
              || (qs || []).find((q: any) => q.type === "email" && !EMAIL_EXCLUDE_RE.test(q.label || ""));
            const nameQ = (qs || []).find((q: any) => q.type === "short_text" && /name/i.test(q.label || ""))
              || (qs || []).find((q: any) => q.type === "short_text");

            const qIds = [emailQ?.id, nameQ?.id].filter(Boolean);
            const { data: ans } = qIds.length
              ? await supabase.from("answers").select("question_id, answer_text").eq("response_id", response_id).in("question_id", qIds)
              : { data: [] as any[] };
            const ansMap: Record<string, string> = {};
            for (const a of (ans || [])) ansMap[(a as any).question_id] = (a as any).answer_text || "";

            const candidateEmail = ((resp.override_email as string) || (emailQ?.id && ansMap[emailQ.id]) || "").trim();
            const fullName = ((resp as any).override_name || "").trim() || (nameQ?.id && ansMap[nameQ.id] || "").trim();
            const firstName = fullName.split(/\s+/)[0] || "there";
            const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

            if (candidateEmail && EMAIL_RE.test(candidateEmail)) {
              // Build candidate-safe origin for the tracking URL. Prefer the
              // published custom domain; fall back to lovable.app preview.
              const trackUrl = `https://jobs.expertintuitiveadvisor.com/track/${trackingToken}`;
              const subject = "Track your application — Expert Intuitive Advisor";
              const text =
                `Hi ${firstName},\n\n` +
                `Thank you for completing your interview with us. You can now follow your application status anytime using your private tracking link below:\n\n` +
                `${trackUrl}\n\n` +
                `We'll update this page as your application progresses. Please save this link for your records.\n\n` +
                `Warmly,\nAngela Stein\nHR – Talent Manager\nExpert Intuitive Advisor Inc.`;
              const html =
                `<div style="font-family:Arial,sans-serif;font-size:14px;line-height:1.65;color:#1a2547">
                  <p>Hi ${firstName},</p>
                  <p>Thank you for completing your interview with us. You can now follow your application status anytime using your private tracking link below:</p>
                  <p style="margin:18px 0"><a href="${trackUrl}" style="color:#b08d57;text-decoration:none;font-weight:600">${trackUrl}</a></p>
                  <p>We'll update this page as your application progresses. Please save this link for your records.</p>
                  <p style="margin-top:22px">Warmly,<br/>Angela Stein<br/>HR – Talent Manager<br/>Expert Intuitive Advisor Inc.</p>
                </div>`;

              try {
                const r = await fetch(`${PROJECT_URL}/functions/v1/send-dual-email`, {
                  method: "POST",
                  headers: {
                    "Content-Type": "application/json",
                    Authorization: `Bearer ${SERVICE}`,
                  },
                  body: JSON.stringify({
                    to: candidateEmail,
                    candidate_id: null,
                    stage: "other", // logged via email_log; marks tracking-link send
                    sender_a: {
                      from_name: "Angela Stein / HR – Talent Manager",
                      from_address: "talent@expertintuitiveadvisor.com",
                      subject, text_body: text, html_body: html,
                    },
                    sender_b: {
                      from_name: "Angela Stein",
                      from_address: "talent@expertintuitiveadvisor.com",
                      subject, text_body: text, html_body: html,
                    },
                  }),
                });
                console.log("[retell-webhook] tracking email send status", r.status);
              } catch (mailErr) {
                console.error("[retell-webhook] tracking email failed (non-fatal)", mailErr);
              }
            } else {
              console.log("[retell-webhook] no candidate email — skipping tracking-link email");
            }
          }
        }
      } catch (trackErr) {
        // Never fail the webhook for tracking issues.
        console.error("[retell-webhook] tracking-token mint/email failed (non-fatal)", trackErr);
      }
    }
    // ----- end PHASE 3.3 -----

    return new Response(JSON.stringify({ ok: true, session_id: sessionRow.id }), {
      status: 200,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (err) {
    console.error("[retell-webhook] error:", err);
    return new Response(
      JSON.stringify({ ok: false, error: err instanceof Error ? err.message : String(err) }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } },
    );
  }
});
