// send-hold-notice (On Hold — Piece 2): sends one of two INFO-ONLY notices —
//   kind="on_hold"      -> "position placed on hold" notice
//   kind="reactivation" -> "position resumed / welcome back" notice
// No signature, no PDF, no link. Reuses the existing Resend sender
// (talent@careers.expertintuitiveadvisor.com), the always-on Outlook backup
// (app_settings.main_backup_email) and the optional Gmail copy
// (app_settings.hr_copy_email / per-send override). Logs to email_log.
//
// Auth: requireHr — accepts a real HR user token AND the service-role bypass
// used by fire-scheduled-sends (so the Now/Later scheduler can replay it).
// This function does NOT touch job_offers / employment_status / Piece-1 hold
// columns — the dashboard owns the status write; this only emails.
import { adminClient, corsHeaders, json, requireHr } from "../_shared/hr-auth.ts";

const RESEND_API_KEY = Deno.env.get("RESEND_API_KEY")!;
const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

const FROM_NAME = "Angela Stein — Expert Intuitive Advisor";
const FROM_ADDRESS = "talent@expertintuitiveadvisor.com";
const FALLBACK_OUTLOOK_BACKUP = "talent.expertadvisor@outlook.com";
const FALLBACK_GMAIL_COPY = "talent.expertadvisor@outlook.com";

const htmlEscape = (s: string) =>
  s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;")
   .replace(/"/g, "&quot;").replace(/'/g, "&#39;");

// Format an ISO date for display, or return "immediately" when absent.
function fmtDateOrImmediate(iso: string | null): string {
  if (!iso) return "immediately";
  const d = new Date(iso);
  if (isNaN(d.getTime())) return "immediately";
  return d.toLocaleDateString("en-US", { year: "numeric", month: "long", day: "numeric" });
}

function buildBody(kind: "on_hold" | "reactivation", name: string, dateLabel: string) {
  const firstName = (name.split(/\s+/)[0] || name) || "there";
  if (kind === "on_hold") {
    const subject = "Important update regarding your position — Expert Intuitive Advisor";
    const text = `Dear ${firstName},

We are writing to inform you that your position with Expert Intuitive Advisor has been placed on hold, effective ${dateLabel}. During this period your working hours and compensation are paused and will not accrue.

This is not a termination. Your position is being held pending further discussion. To resume, or to understand the next steps, please contact your HR representative or your manager as soon as possible.

We look forward to hearing from you.

Warm regards,
Angela Stein
HR — Talent Manager
Expert Intuitive Advisor Inc.`;
    return { subject, text };
  }
  const subject = "Welcome back — your position has resumed — Expert Intuitive Advisor";
  const text = `Dear ${firstName},

Good news — the hold on your position with Expert Intuitive Advisor has been lifted. You are cleared to resume work effective ${dateLabel}. Your working hours and compensation resume from that date.

Please reconnect with your manager for your current schedule and tasks. We're glad to have you back.

Warm regards,
Angela Stein
HR — Talent Manager
Expert Intuitive Advisor Inc.`;
  return { subject, text };
}

function buildHtml(kind: "on_hold" | "reactivation", name: string, dateLabel: string) {
  const { subject, text } = buildBody(kind, name, dateLabel);
  const year = new Date().getFullYear();
  const heading = kind === "on_hold"
    ? "Important Update Regarding Your Position"
    : "Welcome Back — Your Position Has Resumed";
  const accent = kind === "on_hold" ? "#b08d57" : "#16a34a";
  const paras = text
    .split("\n\n")
    .map((p) => `<p style="margin:0 0 16px 0;">${htmlEscape(p).replace(/\n/g, "<br/>")}</p>`)
    .join("");
  return `<!doctype html><html><body style="margin:0;padding:0;background:#faf8f3;font-family:'Inter',Arial,sans-serif;color:#1a2547;">
  <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background:#faf8f3;padding:40px 16px;">
    <tr><td align="center">
      <table role="presentation" width="600" cellpadding="0" cellspacing="0" style="max-width:600px;background:#ffffff;border:1px solid #e6e0d1;border-radius:6px;overflow:hidden;">
        <tr><td style="padding:36px 48px 24px 48px;text-align:center;">
          <div style="font-family:'Cormorant Garamond',Georgia,serif;font-weight:600;font-size:28px;letter-spacing:6px;color:#1a2547;">EIA</div>
          <div style="font-family:'Inter',Arial,sans-serif;font-size:10px;letter-spacing:2px;text-transform:uppercase;color:#b08d57;margin-top:6px;">Expert Intuitive Advisor Inc.</div>
          <div style="height:1px;background:${accent};width:60px;margin:20px auto 0;"></div>
        </td></tr>
        <tr><td style="padding:8px 48px 8px 48px;text-align:center;">
          <div style="font-family:'Cormorant Garamond',Georgia,serif;font-size:20px;color:#1a2547;font-style:italic;">${htmlEscape(heading)}</div>
        </td></tr>
        <tr><td style="padding:28px 48px 8px 48px;font-family:'Inter',Arial,sans-serif;font-size:15px;line-height:1.7;color:#1a2547;">
          ${paras}
        </td></tr>
        <tr><td style="padding:20px 48px 32px 48px;">
          <div style="height:1px;background:#e6e0d1;margin-bottom:16px;"></div>
          <div style="font-family:'Inter',Arial,sans-serif;font-size:11px;color:#9a9588;text-align:center;">&copy; ${year} Expert Intuitive Advisor Inc.</div>
        </td></tr>
      </table>
    </td></tr>
  </table>
</body></html>`;
}

async function readSetting(admin: any, key: "main_backup_email" | "hr_copy_email"): Promise<string | null> {
  try {
    const { data } = await admin.from("app_settings").select(key).eq("id", 1).maybeSingle();
    const v = (data as any)?.[key];
    return typeof v === "string" && v.trim() ? v.trim() : null;
  } catch {
    return null;
  }
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });

  const ident = await requireHr(req);
  if (ident instanceof Response) return ident;

  try {
    const body = await req.json().catch(() => ({}));
    const kind: string = body?.kind;
    if (kind !== "on_hold" && kind !== "reactivation") return json({ error: "invalid kind" }, 400);

    const name: string = typeof body?.name === "string" ? body.name.trim() : "";
    const email: string = typeof body?.email === "string" ? body.email.trim() : "";
    if (!name) return json({ error: "recipient name required" }, 400);
    if (!email || !EMAIL_RE.test(email)) return json({ error: "invalid recipient email" }, 400);

    const effectiveDate: string | null = typeof body?.effective_date === "string" && body.effective_date ? body.effective_date : null;
    const rejoinDate: string | null = typeof body?.rejoin_date === "string" && body.rejoin_date ? body.rejoin_date : null;
    const responseId: string | null = typeof body?.response_id === "string" && body.response_id ? body.response_id : null;
    const hrCopyRequested = body?.hr_copy_requested === true;
    const hrCopyOverride: string | null = typeof body?.hr_copy_email_override === "string" && body.hr_copy_email_override.trim()
      ? body.hr_copy_email_override.trim() : null;

    const dateLabel = fmtDateOrImmediate(kind === "on_hold" ? effectiveDate : rejoinDate);
    const { subject } = buildBody(kind, name, dateLabel);
    const text = buildBody(kind, name, dateLabel).text;
    const html = buildHtml(kind, name, dateLabel);

    const admin = adminClient();

    // resolve candidate_id for traceability (best-effort).
    let candidateId: string | null = null;
    if (responseId) {
      const { data: r } = await admin.from("responses").select("applicant_id").eq("id", responseId).maybeSingle();
      candidateId = (r as any)?.applicant_id ?? null;
    }

    // Build BCC list: always-on Outlook backup + optional editable Gmail copy.
    const outlookBackup = (await readSetting(admin, "main_backup_email")) || FALLBACK_OUTLOOK_BACKUP;
    const bcc: string[] = [];
    if (outlookBackup && EMAIL_RE.test(outlookBackup)) bcc.push(outlookBackup);
    if (hrCopyRequested) {
      const gmailCopy = hrCopyOverride && EMAIL_RE.test(hrCopyOverride)
        ? hrCopyOverride
        : ((await readSetting(admin, "hr_copy_email")) || FALLBACK_GMAIL_COPY);
      if (gmailCopy && EMAIL_RE.test(gmailCopy) && !bcc.includes(gmailCopy)) bcc.push(gmailCopy);
    }

    const stage = kind === "on_hold" ? "hold_notice_sent" : "reactivation_notice_sent";

    let emailOk = false;
    let resendId: string | null = null;
    let errorMessage: string | null = null;
    try {
      const r = await fetch("https://api.resend.com/emails", {
        method: "POST",
        headers: { "Content-Type": "application/json", Authorization: `Bearer ${RESEND_API_KEY}` },
        body: JSON.stringify({
          from: `${FROM_NAME} <${FROM_ADDRESS}>`,
          to: [email],
          bcc: bcc.length ? bcc : undefined,
          subject, html, text,
        }),
      });
      const j = await r.json().catch(() => ({}));
      emailOk = r.ok;
      resendId = (j as any)?.id ?? null;
      if (!r.ok) errorMessage = JSON.stringify(j).slice(0, 500);
    } catch (e: any) {
      errorMessage = String(e?.message || e);
    }

    await admin.from("email_log").insert({
      candidate_id: candidateId,
      stage,
      sender: "resend",
      from_address: FROM_ADDRESS,
      from_name: FROM_NAME,
      to_address: email,
      subject,
      status: emailOk ? "sent" : "failed",
      sent_at: emailOk ? new Date().toISOString() : null,
      resend_message_id: resendId,
      error_message: emailOk ? null : errorMessage,
    });

    if (!emailOk) return json({ ok: false, error: "send failed", details: errorMessage }, 500);
    return json({ ok: true, resend_id: resendId, copies: bcc });
  } catch (e: any) {
    return json({ ok: false, error: "unexpected", details: String(e?.message || e) }, 500);
  }
});
