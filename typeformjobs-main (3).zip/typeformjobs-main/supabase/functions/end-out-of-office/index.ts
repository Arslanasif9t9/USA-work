// end-out-of-office: Boss2929 gated. Ends an active OOO period early.
import { createClient } from "npm:@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
const ANON = Deno.env.get("SUPABASE_ANON_KEY")!;
const SERVICE = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
const BOSS2929 = Deno.env.get("BOSS2929_PASSWORD") || "Boss2929";

const json = (b: unknown, s = 200) =>
  new Response(JSON.stringify(b), { status: s, headers: { ...corsHeaders, "Content-Type": "application/json" } });

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });
  try {
    const authHeader = req.headers.get("Authorization");
    if (!authHeader?.startsWith("Bearer ")) return json({ error: "unauthorized" }, 401);
    const userClient = createClient(SUPABASE_URL, ANON, { global: { headers: { Authorization: authHeader } } });
    const { data: userData, error: uErr } = await userClient.auth.getUser();
    if (uErr || !userData?.user) return json({ error: "unauthorized" }, 401);
    const admin = createClient(SUPABASE_URL, SERVICE);
    const email = (userData.user.email || "").toLowerCase();
    const { data: hr } = await admin.from("hr_users").select("id").ilike("email", email).maybeSingle();

    const body = await req.json().catch(() => ({}));
    const password = body?.password;
    if (password !== BOSS2929) {
      await admin.from("password_audit_log").insert({
        hr_user_id: hr?.id ?? null, password_used: "***wrong***", action_taken: "ooo_end_failed",
      });
      return json({ error: "wrong_password" }, 403);
    }

    const { data: cfg } = await admin.from("scheduling_config").select("ooo_active_period_id").eq("id", 1).maybeSingle();
    const periodId = cfg?.ooo_active_period_id;

    await admin.from("scheduling_config").update({
      is_out_of_office: false,
      out_of_office_start: null,
      out_of_office_end: null,
      ooo_active_period_id: null,
    }).eq("id", 1);

    if (periodId) {
      await admin.from("out_of_office_periods")
        .update({ disabled_at: new Date().toISOString() })
        .eq("id", periodId);
    }

    await admin.from("password_audit_log").insert({
      hr_user_id: hr?.id ?? null, password_used: "***correct***", action_taken: "ooo_ended_early",
      target_resource_id: periodId ?? null,
    });

    return json({ success: true });
  } catch (e: any) {
    return json({ error: "internal", details: String(e?.message || e) }, 500);
  }
});
