// Vercel adapter for /api/mcp (MCP JSON-RPC connector).
//
// Vercel's standard Node serverless runtime invokes a DEFAULT export with Node's
// (req, res) objects. The shared logic in ./_lib/handlers.js speaks the Web
// Request -> Web Response contract, so this adapter bridges Node (req,res) <->
// Web Request/Response and delegates to the shared `mcp` handler.
import { mcp } from './_lib/handlers.js'

// --- Node req -> Web Request -------------------------------------------------

// Collect the raw request body as a string. Vercel may have already parsed the
// body into req.body; if so, re-serialize it. Otherwise drain the raw stream.
async function readBody(req) {
  if (req.body !== undefined && req.body !== null) {
    if (typeof req.body === 'string') return req.body
    if (req.body instanceof Uint8Array) return new TextDecoder().decode(req.body)
    return JSON.stringify(req.body)
  }
  const decoder = new TextDecoder()
  let data = ''
  for await (const chunk of req) {
    data += typeof chunk === 'string' ? chunk : decoder.decode(chunk, { stream: true })
  }
  data += decoder.decode()
  return data.length ? data : undefined
}

async function toWebRequest(req) {
  const host = req.headers.host || 'localhost'
  const url = `https://${host}${req.url}`

  const headers = new Headers()
  for (const [key, value] of Object.entries(req.headers)) {
    if (Array.isArray(value)) value.forEach((v) => headers.append(key, v))
    else if (value != null) headers.set(key, value)
  }

  const method = req.method || 'GET'
  const hasBody = method !== 'GET' && method !== 'HEAD'
  const body = hasBody ? await readBody(req) : undefined

  return new Request(url, { method, headers, body })
}

// --- Web Response -> Node res ------------------------------------------------

async function sendWebResponse(res, response) {
  res.statusCode = response.status
  response.headers.forEach((value, key) => {
    // Let Node compute Content-Length from the body we actually write.
    if (key.toLowerCase() === 'content-length') return
    res.setHeader(key, value)
  })
  res.end(await response.text())
}

// --- Vercel Node serverless handler (DEFAULT export) -------------------------

export default async function handler(req, res) {
  try {
    const request = await toWebRequest(req)
    const response = await mcp(request)
    await sendWebResponse(res, response)
  } catch (err) {
    res.statusCode = 500
    res.setHeader('Content-Type', 'application/json')
    res.end(JSON.stringify({ error: 'Internal error', detail: String(err?.message || err) }))
  }
}
