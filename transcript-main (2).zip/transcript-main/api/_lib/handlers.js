// Platform-agnostic backend logic.
//
// Every handler here is a standard Web "fetch handler": it receives a Web
// `Request` and returns a Web `Response`. This is the common denominator that
// works on Vercel, Netlify, and our local Vite dev server, so the logic in this
// file never has to change when you switch hosting platforms — only the thin
// per-platform adapter files (api/*.js for Vercel, netlify/functions/*.js for
// Netlify) wire these into each platform.

// Captions are fetched via a third-party transcript API (Supadata), NOT directly
// from YouTube: from a datacenter IP (e.g. Vercel) YouTube soft-blocks direct
// caption requests and client libraries mislabel that as "captions disabled".
// Supadata fetches through its own residential/proxy infrastructure, so normal
// videos resolve correctly in production. See fetchCaptionViaService below.

/** @param {Request} request */
export async function health(request) {
  return Response.json({
    status: 'ok',
    message: 'Transcript API is running',
    // Example of reading a secret/config from the environment. Never hardcode
    // keys — set them in .env locally and in the hosting platform's dashboard.
    environment: process.env.NODE_ENV ?? 'development',
    timestamp: new Date().toISOString(),
  })
}

// Extracts the 11-character video ID from common YouTube URL formats:
//   https://www.youtube.com/watch?v=ID (with any extra query params)
//   https://youtu.be/ID
//   https://www.youtube.com/shorts/ID
//   https://www.youtube.com/embed/ID
//   https://www.youtube.com/live/ID
// Returns the ID string, or null if none can be found.
export function extractVideoId(rawUrl) {
  if (!rawUrl || typeof rawUrl !== 'string') return null

  const input = rawUrl.trim()
  const ID = /^[a-zA-Z0-9_-]{11}$/

  // Bare 11-char ID pasted directly.
  if (ID.test(input)) return input

  let url
  try {
    url = new URL(input.includes('://') ? input : `https://${input}`)
  } catch {
    return null
  }

  const host = url.hostname.replace(/^www\./, '').toLowerCase()

  // youtu.be/ID
  if (host === 'youtu.be') {
    const id = url.pathname.split('/').filter(Boolean)[0]
    return id && ID.test(id) ? id : null
  }

  // Any youtube.com host (www, m, music, ...)
  if (host === 'youtube.com' || host.endsWith('.youtube.com')) {
    // watch?v=ID
    const v = url.searchParams.get('v')
    if (v && ID.test(v)) return v

    // /shorts/ID, /embed/ID, /live/ID, /v/ID
    const parts = url.pathname.split('/').filter(Boolean)
    if (parts.length >= 2 && ['shorts', 'embed', 'live', 'v'].includes(parts[0])) {
      return ID.test(parts[1]) ? parts[1] : null
    }
  }

  return null
}

// Lightweight decode of the few HTML entities YouTube captions commonly contain,
// so the raw transcript reads cleanly.
function decodeEntities(text) {
  return text
    .replace(/&amp;/g, '&')
    .replace(/&#39;/g, "'")
    .replace(/&#34;/g, '"')
    .replace(/&quot;/g, '"')
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/&nbsp;/g, ' ')
}

// Reads the YouTube URL from a request, whether sent as a JSON body { url }
// (POST) or as a ?url= query param (handy for quick GET testing).
async function readUrl(request) {
  if (request.method === 'POST') {
    try {
      const body = await request.json()
      return body?.url ?? ''
    } catch {
      return ''
    }
  }
  return new URL(request.url).searchParams.get('url') ?? ''
}

// ---------------------------------------------------------------------------
// AI structuring (Gemini primary -> Groq backup fallback chain)
// ---------------------------------------------------------------------------

// Adaptive instruction: let the content decide the structure, don't force a
// rigid template. Used for short videos and for the final combine pass.
const AI_INSTRUCTION =
  'You are given the raw transcript of a YouTube video. Produce complete, ' +
  'faithful written notes that let someone fully understand the video WITHOUT ' +
  'watching it. Capture all the important explanations, key points, and any ' +
  'steps or instructions given. Structure the notes in whatever way best fits ' +
  "this specific video's content — use headings, sub-points, ordered steps, or " +
  'flowing paragraphs as appropriate. Do not force a rigid template. Do not omit ' +
  'important detail. Be thorough but clear. Output in clean markdown.'

// Per-section instruction for long videos (one transcript chunk at a time).
const chunkInstruction = (part, total) =>
  `You are given part ${part} of ${total} of the raw transcript of a YouTube ` +
  'video. Produce complete, faithful written notes for THIS PART only. Capture ' +
  'all the important explanations, key points, and any steps or instructions ' +
  'given. Use clean markdown, structured in whatever way best fits the content ' +
  '(headings, sub-points, ordered steps, or paragraphs). Do NOT write an overall ' +
  'introduction or conclusion for the whole video — this is only one section. Do ' +
  'not omit important detail.'

// Final combine pass: merge sequential section notes into one coherent document.
const COMBINE_INSTRUCTION =
  'Below are notes from sequential sections of a single YouTube video, in order. ' +
  'Combine them into one coherent, well-structured set of notes for the whole ' +
  'video. Preserve all the detail, key points, and steps. Remove duplicated or ' +
  'redundant headings, smooth the transitions between sections, and ensure a ' +
  'logical flow from start to finish. Do not omit important detail. Output in ' +
  'clean markdown.'

// Very large transcripts are capped so a pathological input can't run forever.
// A ~1-hour video is well under this; chunking (below) handles the length.
const MAX_TRANSCRIPT_CHARS = 250_000
// Above this, the transcript is split and processed in sequential chunks so we
// stay within free-tier model limits.
const CHUNK_CHARS = 12_000
// If the concatenated section notes fit under this, run one smoothing pass.
const FINAL_PASS_CHARS = 30_000

// Model ids are overridable via env so a deprecated free model can be swapped
// without touching code.
const GEMINI_MODEL = () => process.env.GEMINI_MODEL || 'gemini-2.0-flash'
const GROQ_MODEL = () => process.env.GROQ_MODEL || 'llama-3.3-70b-versatile'

// Google Gemini (free tier). The API key is passed in so the same function can
// be reused with multiple keys in the fallback chain. Throws on any failure so
// the chain falls through to the next provider.
async function callGemini(instruction, content, key) {
  if (!key) throw new Error('Gemini API key is not set')

  const model = GEMINI_MODEL()
  const res = await fetch(
    `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${key}`,
    {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        system_instruction: { parts: [{ text: instruction }] },
        contents: [{ role: 'user', parts: [{ text: content }] }],
      }),
    },
  )

  if (!res.ok) {
    const detail = await res.text().catch(() => '')
    throw new Error(`Gemini request failed (${res.status}): ${detail.slice(0, 200)}`)
  }

  const data = await res.json()
  const text =
    data?.candidates?.[0]?.content?.parts?.map((p) => p.text).join('') ?? ''
  if (!text.trim()) throw new Error('Gemini returned no content')
  return text.trim()
}

// Groq (free tier, OpenAI-compatible API). The API key is passed in so the same
// function can be reused with multiple keys. Throws on any failure.
async function callGroq(instruction, content, key) {
  if (!key) throw new Error('Groq API key is not set')

  const model = GROQ_MODEL()
  const res = await fetch('https://api.groq.com/openai/v1/chat/completions', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${key}`,
    },
    body: JSON.stringify({
      model,
      messages: [
        { role: 'system', content: instruction },
        { role: 'user', content },
      ],
    }),
  })

  if (!res.ok) {
    const detail = await res.text().catch(() => '')
    throw new Error(`Groq request failed (${res.status}): ${detail.slice(0, 200)}`)
  }

  const data = await res.json()
  const text = data?.choices?.[0]?.message?.content ?? ''
  if (!text.trim()) throw new Error('Groq returned no content')
  return text.trim()
}

// Runs one AI request through a 4-key fallback chain, in this exact order:
//   1. Gemini key 1  ->  2. Groq key 1  ->  3. Gemini key 2  ->  4. Groq key 2
// Each step uses its own key; if a provider throws or rate-limits (e.g. 429) the
// chain falls through to the next. Returns the text, or null if all four failed
// (so the caller's friendly ai_failed error fires). Keys are read from env and
// never logged.
async function runAI(instruction, content) {
  const chain = [
    { label: 'gemini key1', fn: callGemini, key: process.env.GEMINI_API_KEY_1 },
    { label: 'groq key1', fn: callGroq, key: process.env.GROQ_API_KEY_1 },
    { label: 'gemini key2', fn: callGemini, key: process.env.GEMINI_API_KEY_2 },
    { label: 'groq key2', fn: callGroq, key: process.env.GROQ_API_KEY_2 },
  ]

  for (const step of chain) {
    // Skip an empty/missing key gracefully — log and move to the next slot,
    // never throw out of the loop.
    if (!step.key) {
      console.warn(`[notes] skipping ${step.label}: key not set`)
      continue
    }
    try {
      console.log(`[notes] trying ${step.label}`)
      const text = await step.fn(instruction, content, step.key)
      console.log(`[notes] ${step.label} succeeded`)
      return text
    } catch (err) {
      // ANY failure (throw, network, 429, bad key) is caught here and the chain
      // continues to the next key. Server-side log only — never the key value.
      console.warn(`[notes] ${step.label} failed: ${err?.message || String(err)}`)
    }
  }

  // Every provider failed — return null so the caller's ai_failed (502) fires.
  console.warn('[notes] all 4 providers failed — giving up (ai_failed)')
  return null
}

// Splits long text into chunks of roughly `size` characters, breaking on word
// boundaries so no word is cut in half.
function splitIntoChunks(text, size) {
  const words = text.split(/\s+/)
  const chunks = []
  let current = ''
  for (const word of words) {
    if (current && current.length + word.length + 1 > size) {
      chunks.push(current)
      current = ''
    }
    current += (current ? ' ' : '') + word
  }
  if (current) chunks.push(current)
  return chunks
}

// Turns a transcript into structured notes. Short transcripts go in one request;
// long ones (e.g. ~1-hour videos) are chunked, each chunk structured via the
// fallback chain, then combined — optionally with a final smoothing pass.
// Returns the markdown notes, or null if processing failed.
async function structureNotes(transcriptText) {
  const text =
    transcriptText.length > MAX_TRANSCRIPT_CHARS
      ? transcriptText.slice(0, MAX_TRANSCRIPT_CHARS)
      : transcriptText

  // Short enough to do in a single pass.
  if (text.length <= CHUNK_CHARS) {
    return runAI(AI_INSTRUCTION, text)
  }

  // Long video: process each section, then combine.
  const chunks = splitIntoChunks(text, CHUNK_CHARS)
  const sections = []
  for (let i = 0; i < chunks.length; i++) {
    const note = await runAI(chunkInstruction(i + 1, chunks.length), chunks[i])
    if (!note) return null // a section failed on both providers — fail cleanly
    sections.push(note)
  }

  let combined = sections.join('\n\n')

  // Optional final pass to smooth transitions, if it fits in limits.
  if (combined.length <= FINAL_PASS_CHARS) {
    const smoothed = await runAI(COMBINE_INSTRUCTION, combined)
    if (smoothed) combined = smoothed
  }

  return combined
}

// ---------------------------------------------------------------------------
// Caption fetching ("Way 1") via Supadata's transcript API.
//
// GET https://api.supadata.ai/v1/transcript?url=<youtube url>&text=true
//   header: x-api-key: <TRANSCRIPT_API_KEY>
//   200 -> { content: string, lang, availableLangs }      (synchronous)
//   202 -> { jobId }   for long videos (>20 min) — poll the job below
//   206 -> transcript-unavailable  (video genuinely has no captions)
//   401/400/other -> failure
// Docs: https://docs.supadata.ai/
// ---------------------------------------------------------------------------

const SUPADATA_BASE = 'https://api.supadata.ai/v1'
const SUPADATA_POLL_INTERVAL_MS = 1000
const SUPADATA_MAX_POLLS = 55 // ~55s ceiling, within the function's maxDuration

const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms))

// Pull plain text out of a Supadata result body. With text=true `content` is a
// string; we also defensively handle the timestamped-array form.
function extractSupadataText(data) {
  const content = data?.content
  if (typeof content === 'string') return content
  if (Array.isArray(content)) return content.map((c) => c?.text ?? '').join(' ')
  return ''
}

// Poll an async transcript job (returned for long videos) until it finishes.
async function pollSupadataJob(jobId, key) {
  const url = `${SUPADATA_BASE}/transcript/${encodeURIComponent(jobId)}`
  for (let i = 0; i < SUPADATA_MAX_POLLS; i++) {
    await sleep(SUPADATA_POLL_INTERVAL_MS)

    let res
    try {
      res = await fetch(url, { headers: { 'x-api-key': key } })
    } catch (err) {
      return { status: 'failed', detail: `job network error: ${err?.message || err}` }
    }

    if (!res.ok) {
      const detail = await res.text().catch(() => '')
      return { status: 'failed', detail: `job ${res.status}: ${detail.slice(0, 200)}` }
    }

    const data = await res.json().catch(() => null)
    const jobStatus = data?.status

    if (jobStatus === 'completed') {
      const text = extractSupadataText(data).trim()
      return text ? { status: 'ok', text } : { status: 'no_caption' }
    }
    if (jobStatus === 'failed') {
      const e = data?.error
      const eStr = typeof e === 'string' ? e : JSON.stringify(e ?? {})
      // A job that fails specifically because the video has no transcript maps
      // to the "no caption" branch, not a generic fetch failure.
      if (/transcript-unavailable|no.?transcript|unavailable/i.test(eStr)) {
        return { status: 'no_caption' }
      }
      return { status: 'failed', detail: `job failed: ${eStr.slice(0, 200)}` }
    }
    // 'queued' | 'active' -> keep polling
  }
  return { status: 'failed', detail: 'transcript job timed out' }
}

// Fetch a video's caption text via Supadata. Returns one of:
//   { status: 'ok', text }      caption text retrieved
//   { status: 'no_caption' }    video genuinely has no captions
//   { status: 'failed', detail} service/network/config failure
async function fetchCaptionViaService(videoId) {
  const key = process.env.TRANSCRIPT_API_KEY
  if (!key) return { status: 'failed', detail: 'TRANSCRIPT_API_KEY is not set' }

  const videoUrl = `https://www.youtube.com/watch?v=${videoId}`
  const endpoint = `${SUPADATA_BASE}/transcript?url=${encodeURIComponent(videoUrl)}&text=true`

  let res
  try {
    res = await fetch(endpoint, { headers: { 'x-api-key': key } })
  } catch (err) {
    return { status: 'failed', detail: `network error: ${err?.message || err}` }
  }

  // Genuine "this video has no transcript/captions".
  if (res.status === 206) return { status: 'no_caption' }

  // Long videos: async job we must poll.
  if (res.status === 202) {
    const body = await res.json().catch(() => null)
    const jobId = body?.jobId
    if (!jobId) return { status: 'failed', detail: 'async job missing jobId' }
    return pollSupadataJob(jobId, key)
  }

  if (!res.ok) {
    const detail = await res.text().catch(() => '')
    return { status: 'failed', detail: `service ${res.status}: ${detail.slice(0, 200)}` }
  }

  const data = await res.json().catch(() => null)
  if (!data) return { status: 'failed', detail: 'invalid JSON from transcript service' }

  const text = extractSupadataText(data).trim()
  return text ? { status: 'ok', text } : { status: 'no_caption' }
}

/**
 * Shared core used by BOTH the REST endpoint and the MCP tool — single source of
 * truth. Validates the URL, fetches the caption via Supadata, then structures it
 * into notes via the 4-key AI fallback chain. Returns one of:
 *   { ok:true,  videoId, notes, transcript }                              // notes generated
 *   { ok:true,  videoId, notes:null, transcript, notesUnavailable:true }  // AI exhausted
 *   { ok:false, code:'invalid_url' }                                      // bad/empty URL
 *   { ok:false, code:'no_caption',   videoId }                           // video has no captions
 *   { ok:false, code:'fetch_failed', videoId, detail }                   // caption service failed
 * An AI failure alone never blocks returning a caption we already have.
 */
export async function fetchAndStructureNotes(url) {
  const videoId = extractVideoId(url)
  if (!videoId) return { ok: false, code: 'invalid_url' }

  // Fetch the caption text via Supadata (replaces direct youtube-transcript,
  // which YouTube soft-blocks from datacenter IPs).
  const fetched = await fetchCaptionViaService(videoId)

  // "No caption" branch (isolated). Way 2 (audio + Whisper) plugs in HERE later.
  if (fetched.status === 'no_caption') {
    return { ok: false, code: 'no_caption', videoId }
  }
  // Service/network failures (auth, rate limit, video unavailable, etc.).
  if (fetched.status !== 'ok') {
    console.error('[transcript] caption service failed', { videoId, detail: fetched.detail })
    return { ok: false, code: 'fetch_failed', videoId, detail: fetched.detail }
  }

  const rawTranscript = decodeEntities(fetched.text).trim()

  // Structure the transcript into notes via the 4-key AI fallback chain.
  const notes = await structureNotes(rawTranscript)

  // Graceful degradation: captions fetched but AI chain exhausted -> still a
  // success with the caption, flagged notesUnavailable so callers can react.
  if (!notes) {
    console.warn('[transcript] notes unavailable (AI chain exhausted) — returning caption only', { videoId })
    return { ok: true, videoId, notes: null, transcript: rawTranscript, notesUnavailable: true }
  }

  return { ok: true, videoId, notes, transcript: rawTranscript }
}

/**
 * POST /api/transcript  { url }
 * Thin REST wrapper over fetchAndStructureNotes that maps the result to the JSON
 * shapes the frontend expects. Returns both the notes and the raw transcript so
 * the frontend can toggle between them without re-calling the backend.
 * @param {Request} request
 */
export async function transcript(request) {
  try {
    const url = await readUrl(request)
    const result = await fetchAndStructureNotes(url)

    if (!result.ok) {
      if (result.code === 'invalid_url') {
        return Response.json(
          { error: 'Please enter a valid YouTube link.' },
          { status: 400 },
        )
      }
      if (result.code === 'no_caption') {
        return Response.json(
          { error: 'no_caption', message: 'No caption is available for this video.' },
          { status: 404 },
        )
      }
      // fetch_failed
      return Response.json(
        {
          error: 'fetch_failed',
          message:
            'Could not fetch the transcript for this video. Please try again.',
        },
        { status: 502 },
      )
    }

    if (result.notesUnavailable) {
      return Response.json({
        videoId: result.videoId,
        notes: null,
        transcript: result.transcript,
        notesUnavailable: true,
      })
    }

    return Response.json({
      videoId: result.videoId,
      notes: result.notes,
      transcript: result.transcript,
    })
  } catch (err) {
    // Last-resort safety net — never crash. Log the real error server-side so
    // unexpected throws are debuggable (never sent to the browser).
    console.error('[transcript] unexpected error:', err?.stack || err?.message || err)
    return Response.json(
      { error: 'server_error', message: 'Something went wrong. Please try again.' },
      { status: 500 },
    )
  }
}

// ---------------------------------------------------------------------------
// MCP server (/api/mcp)
//
// Exposes the YouTube notes capability to Claude chat as a connector, speaking
// JSON-RPC 2.0 over HTTP (the "Streamable HTTP" transport: client POSTs a
// JSON-RPC request, server replies with a single JSON response). Reuses the
// shared fetchAndStructureNotes core, so the tool always returns the original
// caption plus AI notes when available.
// ---------------------------------------------------------------------------

const MCP_DEFAULT_PROTOCOL_VERSION = '2024-11-05'
const MCP_SERVER_INFO = { name: 'youtube-notes-mcp', version: '1.0.0' }

// CORS so the connector can be reached from the Claude chat client.
const MCP_CORS_HEADERS = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'POST, GET, OPTIONS',
  'Access-Control-Allow-Headers':
    'Content-Type, Authorization, mcp-session-id, mcp-protocol-version',
  'Access-Control-Max-Age': '86400',
}

const GET_YOUTUBE_NOTES_TOOL = {
  name: 'get_youtube_notes',
  description:
    "Fetches a YouTube video's original caption and AI-structured notes. Always " +
    'returns the original caption when available. If structured notes are included, ' +
    'present those notes to the user. If notes are unavailable (notesAvailable: ' +
    'false), generate clear, well-structured notes yourself from the provided ' +
    'original caption, then present those notes. Always show the user readable notes.',
  inputSchema: {
    type: 'object',
    properties: {
      url: {
        type: 'string',
        description: 'Full YouTube URL (any format) or an 11-character YouTube video ID.',
      },
      include_caption: {
        type: 'boolean',
        description:
          'Whether to include the original caption in the response. The caption is ' +
          'included by default so the assistant can always produce notes.',
        default: true,
      },
    },
    required: ['url'],
  },
}

// Build the labeled, machine-parsable text block the calling model reads.
function buildNotesToolText(result, includeCaption) {
  const notesAvailable = !!result.notes
  return [
    '## NOTES',
    notesAvailable ? result.notes : 'NOTES_UNAVAILABLE',
    '',
    '## ORIGINAL CAPTION',
    includeCaption ? result.transcript : '(caption omitted by request)',
    '',
    '## STATUS',
    `notesAvailable: ${notesAvailable}`,
    `videoId: ${result.videoId}`,
  ].join('\n')
}

// Executes the get_youtube_notes tool. Returns an MCP tool-result object
// ({ content, isError }). Caption failures are reported as isError tool results
// (not protocol errors); AI exhaustion is a normal success with notesAvailable:false.
async function runGetYoutubeNotes(args) {
  const url = typeof args?.url === 'string' ? args.url : ''
  const includeCaption = args?.include_caption !== false // default true

  const result = await fetchAndStructureNotes(url)

  if (!result.ok) {
    const messages = {
      invalid_url:
        'Invalid YouTube URL or video ID. Please provide a valid YouTube link.',
      no_caption:
        'This video has no captions available, so notes cannot be generated for it.',
      fetch_failed:
        'Could not fetch the caption for this video right now. Please try again later.',
    }
    return {
      content: [{ type: 'text', text: messages[result.code] || 'Could not process this video.' }],
      isError: true,
    }
  }

  return {
    content: [{ type: 'text', text: buildNotesToolText(result, includeCaption) }],
    isError: false,
  }
}

const jsonRpcResult = (id, result) => ({ jsonrpc: '2.0', id, result })
const jsonRpcError = (id, code, message) => ({ jsonrpc: '2.0', id, error: { code, message } })
const mcpJson = (payload, status = 200) =>
  Response.json(payload, { status, headers: MCP_CORS_HEADERS })

/**
 * POST /api/mcp — MCP JSON-RPC 2.0 endpoint (Claude chat connector).
 * @param {Request} request
 */
export async function mcp(request) {
  // CORS preflight.
  if (request.method === 'OPTIONS') {
    return new Response(null, { status: 204, headers: MCP_CORS_HEADERS })
  }

  // Lightweight discovery/health for GET.
  if (request.method === 'GET') {
    return mcpJson({ ...MCP_SERVER_INFO, protocol: 'mcp', transport: 'http' })
  }

  let body
  try {
    body = await request.json()
  } catch {
    return mcpJson(jsonRpcError(null, -32700, 'Parse error'))
  }

  const { id = null, method, params } = body || {}

  try {
    switch (method) {
      case 'initialize':
        // Echo the client's requested protocol version when present.
        return mcpJson(
          jsonRpcResult(id, {
            protocolVersion: params?.protocolVersion || MCP_DEFAULT_PROTOCOL_VERSION,
            capabilities: { tools: {} },
            serverInfo: MCP_SERVER_INFO,
          }),
        )

      // Notifications carry no id and expect no JSON-RPC response body.
      case 'notifications/initialized':
      case 'initialized':
        return new Response(null, { status: 202, headers: MCP_CORS_HEADERS })

      case 'ping':
        return mcpJson(jsonRpcResult(id, {}))

      case 'tools/list':
        return mcpJson(jsonRpcResult(id, { tools: [GET_YOUTUBE_NOTES_TOOL] }))

      case 'tools/call': {
        if (params?.name !== 'get_youtube_notes') {
          return mcpJson(jsonRpcError(id, -32602, `Unknown tool: ${params?.name}`))
        }
        const toolResult = await runGetYoutubeNotes(params?.arguments)
        return mcpJson(jsonRpcResult(id, toolResult))
      }

      default:
        return mcpJson(jsonRpcError(id, -32601, `Method not found: ${method}`))
    }
  } catch (err) {
    console.error('[mcp] unexpected error:', err?.stack || err?.message || err)
    return mcpJson(jsonRpcError(id, -32603, 'Internal error'))
  }
}

// Route registry: maps a URL path segment to its handler. The local dev server
// (see vite.config.js) uses this to serve `/api/<name>` during development.
export const routes = {
  health,
  transcript,
  mcp,
}
