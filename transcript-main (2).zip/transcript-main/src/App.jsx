import { useState } from 'react'
import ReactMarkdown from 'react-markdown'
import './App.css'

// Simple, elegant brand mark: a gradient badge with an abstract "ascending
// insight" motif. Pairs with the EIA wordmark in the header.
function Logo() {
  return (
    <svg
      className="brand-logo"
      width="40"
      height="40"
      viewBox="0 0 40 40"
      role="img"
      aria-label="EIA logo"
    >
      <defs>
        <linearGradient id="eiaGrad" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0" stopColor="#6366f1" />
          <stop offset="1" stopColor="#a855f7" />
        </linearGradient>
      </defs>
      <rect width="40" height="40" rx="11" fill="url(#eiaGrad)" />
      <rect x="10" y="22" width="4.5" height="8" rx="2.25" fill="#fff" opacity="0.92" />
      <rect x="17.75" y="16.5" width="4.5" height="13.5" rx="2.25" fill="#fff" opacity="0.92" />
      <rect x="25.5" y="10" width="4.5" height="20" rx="2.25" fill="#fff" opacity="0.92" />
    </svg>
  )
}

// Client-side plausibility check for common YouTube URL forms. The backend still
// validates strictly — this just avoids a pointless round trip on bad input.
function looksLikeYouTubeUrl(value) {
  return /^(https?:\/\/)?(www\.|m\.|music\.)?(youtube\.com\/(watch|shorts|embed|live|v)\b|youtu\.be\/)/i.test(
    value,
  )
}

// Maps any backend response to a friendly, user-facing message — never a raw
// code or technical detail.
function friendlyMessage(status, data) {
  const code = (data && data.error) || ''
  if (code === 'no_caption') {
    return "This video doesn't have captions available. (Audio transcription is coming soon.)"
  }
  if (status === 400) {
    return 'Please paste a valid YouTube link.'
  }
  if (/generate notes/i.test(code)) {
    return "Couldn't generate notes right now. Please try again in a moment."
  }
  return 'Something went wrong. Please try again.'
}

function App() {
  const [url, setUrl] = useState('')
  const [loading, setLoading] = useState(false)
  const [notes, setNotes] = useState('')
  const [transcript, setTranscript] = useState('')
  const [error, setError] = useState('')
  const [inputError, setInputError] = useState('')
  const [view, setView] = useState('notes') // 'notes' | 'caption'
  const [copied, setCopied] = useState(false)
  // True when captions were fetched but the AI chain was exhausted, so we show
  // the caption with a friendly notice instead of a hard error.
  const [notesUnavailable, setNotesUnavailable] = useState(false)

  async function handleSubmit(event) {
    event.preventDefault()

    const trimmed = url.trim()
    if (!looksLikeYouTubeUrl(trimmed)) {
      setInputError('Please paste a valid YouTube link.')
      return
    }

    setInputError('')
    setLoading(true)
    setNotes('')
    setTranscript('')
    setError('')
    setView('notes')
    setCopied(false)
    setNotesUnavailable(false)

    try {
      const res = await fetch('/api/transcript', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ url: trimmed }),
      })
      const data = await res.json().catch(() => ({}))

      if (!res.ok || data.error) {
        setError(friendlyMessage(res.status, data))
      } else {
        setNotes(data.notes || '')
        setTranscript(data.transcript || '')
        // Captions came back but AI notes are unavailable: don't error — show the
        // caption and surface a friendly notice in the Notes tab.
        if (data.notesUnavailable || (!data.notes && data.transcript)) {
          setNotesUnavailable(true)
          setView('caption') // jump to the usable caption immediately
        }
      }
    } catch {
      setError('Something went wrong. Please try again.')
    } finally {
      setLoading(false)
    }
  }

  // When notes are unavailable, the Notes tab has no copyable markdown, so fall
  // back to the caption for Copy/Download.
  const currentContent = view === 'notes' ? notes || transcript : transcript

  async function handleCopy() {
    try {
      await navigator.clipboard.writeText(currentContent)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    } catch {
      // Clipboard unavailable — silently ignore; Download remains as a fallback.
    }
  }

  function handleDownload() {
    const blob = new Blob([currentContent], { type: 'text/plain;charset=utf-8' })
    const href = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = href
    a.download = view === 'notes' ? 'eia-notes.txt' : 'eia-caption.txt'
    document.body.appendChild(a)
    a.click()
    a.remove()
    URL.revokeObjectURL(href)
  }

  const hasResult = (notes || transcript) && !error

  return (
    <div className="page">
      <header className="brandbar">
        <div className="brand">
          <Logo />
          <span className="brand-name">
            EIA <span className="brand-sep">—</span>{' '}
            <span className="brand-full">Expert Intuitive Advisor Inc.</span>
          </span>
        </div>
      </header>

      <main className="app">
        <section className="hero">
          <h1>Transcript</h1>
          <p className="subtitle">
            Paste a YouTube link and get readable notes of what the video teaches.
          </p>
        </section>

        <form className="input-card" onSubmit={handleSubmit}>
          <input
            type="text"
            className="url-input"
            value={url}
            onChange={(e) => {
              setUrl(e.target.value)
              if (inputError) setInputError('')
            }}
            placeholder="Paste YouTube video link here..."
            aria-label="YouTube video link"
            disabled={loading}
          />
          <button type="submit" className="submit-btn" disabled={loading}>
            {loading ? 'Generating…' : 'Get Notes'}
          </button>
        </form>

        {inputError && <p className="field-error">{inputError}</p>}

        {loading && (
          <div className="results-card">
            <div className="loading">
              <span className="spinner" aria-hidden="true" />
              <span>
                Generating notes… this can take a little longer for long videos.
              </span>
            </div>
          </div>
        )}

        {!loading && error && (
          <div className="error-box" role="alert">
            <svg width="20" height="20" viewBox="0 0 24 24" aria-hidden="true">
              <circle cx="12" cy="12" r="10" fill="none" stroke="currentColor" strokeWidth="2" />
              <path d="M12 7v6M12 16.5v.5" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
            </svg>
            <span>{error}</span>
          </div>
        )}

        {!loading && hasResult && (
          <div className="results-card">
            <div className="results-head">
              <div className="toggle" role="tablist" aria-label="View">
                <button
                  role="tab"
                  aria-selected={view === 'notes'}
                  className={view === 'notes' ? 'toggle-btn active' : 'toggle-btn'}
                  onClick={() => setView('notes')}
                >
                  Notes
                </button>
                <button
                  role="tab"
                  aria-selected={view === 'caption'}
                  className={view === 'caption' ? 'toggle-btn active' : 'toggle-btn'}
                  onClick={() => setView('caption')}
                >
                  Original Caption
                </button>
              </div>

              <div className="actions">
                <button type="button" className="action-btn" onClick={handleCopy}>
                  {copied ? 'Copied!' : 'Copy'}
                </button>
                <button type="button" className="action-btn" onClick={handleDownload}>
                  Download .txt
                </button>
              </div>
            </div>

            {view === 'notes' ? (
              notesUnavailable || !notes ? (
                <div className="notes-notice" role="status">
                  AI notes are temporarily unavailable (API limit reached). The
                  original caption is shown below — you can still read, copy, and
                  download it.
                </div>
              ) : (
                <article className="notes">
                  <ReactMarkdown>{notes}</ReactMarkdown>
                </article>
              )
            ) : (
              <pre className="caption">{transcript}</pre>
            )}
          </div>
        )}

        {!loading && !hasResult && !error && (
          <div className="results-card empty">
            <p className="placeholder">Your notes will appear here.</p>
          </div>
        )}
      </main>
    </div>
  )
}

export default App
