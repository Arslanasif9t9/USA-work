import { defineConfig, loadEnv } from 'vite'
import react from '@vitejs/plugin-react'

// Local dev server for the serverless functions.
//
// In production, Vercel/Netlify host the functions in api/ and netlify/. During
// `npm run dev` there's no platform runtime, so this small plugin serves the
// SAME shared handlers (api/_lib/handlers.js) at /api/<name>. That means the
// frontend talks to one identical URL — /api/health — locally and in production.
function devApiServer() {
  return {
    name: 'dev-api-server',
    configureServer(server) {
      server.middlewares.use('/api', async (req, res, next) => {
        try {
          // Re-import on each request so edits to handlers are picked up (HMR).
          const { routes } = await server.ssrLoadModule('/api/_lib/handlers.js')

          const url = new URL(req.url ?? '/', 'http://localhost')
          const name = url.pathname.replace(/^\/+/, '').split('/')[0]
          const handler = routes[name]

          if (!handler) return next()

          // Convert the Node request into a Web Request.
          const chunks = []
          for await (const chunk of req) chunks.push(chunk)
          const body = chunks.length ? Buffer.concat(chunks) : undefined
          const request = new Request(`http://localhost/api/${name}`, {
            method: req.method,
            headers: req.headers,
            body: req.method === 'GET' || req.method === 'HEAD' ? undefined : body,
          })

          // Run the shared handler and stream its Web Response back.
          const response = await handler(request)
          res.statusCode = response.status
          response.headers.forEach((value, key) => res.setHeader(key, value))
          res.end(Buffer.from(await response.arrayBuffer()))
        } catch (err) {
          next(err)
        }
      })
    },
  }
}

// https://vite.dev/config/
export default defineConfig(({ mode }) => {
  // Load all of .env (the '' prefix means "every var", not just VITE_ ones) and
  // expose them to the local API handlers via process.env. This mirrors how
  // Vercel/Netlify inject env vars in production, so the backend reads its keys
  // (TRANSCRIPT_API_KEY, the four GEMINI/GROQ keys, etc.) identically everywhere.
  const env = loadEnv(mode, process.cwd(), '')
  for (const [key, value] of Object.entries(env)) {
    if (process.env[key] === undefined) process.env[key] = value
  }

  return {
    plugins: [react(), devApiServer()],
  }
})
