# Transcript — Project Plan & Standing Context

This file is the standing plan for the project. Follow it for every step. **Build only the phase explicitly requested — never build ahead.**

## What it does

User pastes a YouTube video link and submits it. The app returns clean, structured written notes of what the video teaches — a short summary at the top, then chapters/headings, and under each heading the key points as ordered steps. The goal: someone can **read** the notes instead of watching the video.

## How it works (the flow)

1. User pastes a YouTube URL into an input box and clicks Submit.
2. Backend extracts the video ID from the URL.
3. Backend fetches that video's caption/transcript from YouTube using the **`youtube-transcript`** package (this is **"Way 1"** — caption-based).
4. If no caption is found, show a clean **"no caption available for this video"** message. This branch is a **reserved slot** — later we add **"Way 2"**: download audio and run Whisper speech-to-text. **Do NOT build Way 2 now** — keep the branch clean and isolated so it can be added later without rewriting anything.
5. Backend sends the raw transcript to an AI to structure it, using a **fallback chain**: try **Gemini first** (primary, free key); if it fails or hits a rate limit, automatically try **Groq** (backup, free key); if all fail, return a friendly error. All API keys come from **environment variables** — never hardcoded, never sent to the browser.
6. The AI is instructed to: break the transcript into chapters and clear headings, list what is taught under each heading as concise **ordered steps**, and begin with a **short summary** of the whole video.
7. Frontend displays the structured notes cleanly: summary at top, headings in bold, steps as lists, with a **loading state** while processing.

## Key decisions (locked in)

- **Frontend:** React + Vite (already built).
- **Backend:** platform-agnostic serverless functions (already built) — must keep working on **both** localhost and when deployed to **Netlify or Vercel with no rewrites**.
- **AI:** Gemini primary → Groq backup fallback chain (free tiers). Keys in `.env`.
- **Database:** none. Nothing is stored.
- **Deploy:** code pushed to GitHub, then connected to Netlify or Vercel. Keep everything deploy-ready.

## Build order (phases — do ONE at a time, only when asked)

- **Phase 0:** clean base project. ✅ **DONE**
- **Phase 1:** homepage with a YouTube URL input box, Submit button, loading state, and a results area.
- **Phase 2:** backend function to extract video ID and fetch the caption via `youtube-transcript`; return raw transcript, or a clean "no caption" status.
- **Phase 3:** backend AI structuring with the Gemini → Groq fallback chain (keys provided at this phase).
- **Phase 4:** wire frontend to backend and display the structured notes.
- **Phase 5:** polish — input validation (reject non-YouTube links), copy-to-clipboard button, friendly error messages.
- **Phase 6:** push to GitHub, then deploy to the chosen platform and set env vars in its dashboard.
- **Phase 7:** test with real videos and refine the AI instruction.
- **LATER:** Way 2 (Whisper fallback) slots into the "no caption" branch from step 4.

## Rules

- Build only the phase asked for, nothing ahead.
- Keep the backend platform-agnostic and working on localhost at every step.
- Never hardcode or expose API keys.
- After each phase, explain how to verify it on localhost.

## Current architecture (Phase 0, for reference)

- `api/_lib/handlers.js` — all backend logic, written as Web `Request`→`Response` handlers (single source of truth). Register routes in the `routes` map.
- `api/<name>.js` — thin Vercel adapter (Vercel auto-detects `/api`).
- `netlify/functions/<name>.js` — thin Netlify adapter (routed via `config.path`).
- `vite.config.js` — dev plugin serves the same handlers at `/api/*` on localhost.
- Frontend always calls `/api/<name>` — identical URL locally, on Vercel, and on Netlify.
- Secrets: `.env` (git-ignored) read via `process.env`; never exposed to the browser unless `VITE_`-prefixed (public).
