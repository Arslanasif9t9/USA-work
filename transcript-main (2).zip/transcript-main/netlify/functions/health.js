// Netlify adapter (Functions v2).
//
// Netlify v2 functions are also Web fetch handlers: `export default` receives a
// Web `Request` and returns a Web `Response`. The `config.path` makes Netlify
// serve this at `/api/health` directly, matching the Vercel and local-dev URLs
// so the frontend uses one identical path everywhere. We delegate to the same
// shared handler used by every platform.
import { health } from '../../api/_lib/handlers.js'

export default async (request) => health(request)

export const config = {
  path: '/api/health',
}
