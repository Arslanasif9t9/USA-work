// Netlify adapter (Functions v2) for /api/mcp — delegates to the shared MCP
// handler. config.path serves it at /api/mcp, matching every platform.
import { mcp } from '../../api/_lib/handlers.js'

export default async (request) => mcp(request)

export const config = {
  path: '/api/mcp',
}
