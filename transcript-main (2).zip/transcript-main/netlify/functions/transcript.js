// Netlify adapter (Functions v2) for /api/transcript — delegates to the shared
// handler. config.path serves it at /api/transcript, matching every platform.
import { transcript } from '../../api/_lib/handlers.js'

export default async (request) => transcript(request)

export const config = {
  path: '/api/transcript',
}
