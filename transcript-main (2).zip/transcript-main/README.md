# Transcript

A clean base project: **Vite + React** frontend with a **platform-agnostic serverless backend** that deploys to either **Vercel** or **Netlify** with no code changes.

## Quick start

```bash
npm install
npm run dev
```

Open the URL Vite prints (default http://localhost:5173). The page calls
`/api/health` and displays the backend's JSON response to confirm the full
frontend ↔ backend wiring works locally.

## Scripts

| Command           | Description                                  |
| ----------------- | -------------------------------------------- |
| `npm run dev`     | Start the dev server (frontend + `/api/*`).  |
| `npm run build`   | Production build into `dist/`.               |
| `npm run preview` | Preview the production build locally.         |
| `npm run lint`    | Run ESLint.                                   |

## Backend architecture (platform-agnostic)

All backend logic lives **once** in [`api/_lib/handlers.js`](api/_lib/handlers.js)
as standard Web *fetch handlers* — each takes a Web `Request` and returns a Web
`Response`. This is the common API supported by Vercel, Netlify, and the local
dev server, so the logic never changes when you switch platforms.

```
api/
  _lib/handlers.js      # all backend logic (the single source of truth)
  health.js             # Vercel adapter (auto-detected from /api)
netlify/
  functions/health.js   # Netlify adapter (routed to /api/health via config.path)
vite.config.js          # local dev server for /api/* (uses the same handlers)
```

Adding an endpoint:
1. Add a handler to `api/_lib/handlers.js` and register it in the `routes` map.
2. Add a one-line Vercel adapter in `api/<name>.js`.
3. Add a one-line Netlify adapter in `netlify/functions/<name>.js`.

The frontend always calls `/api/<name>` — the same URL locally, on Vercel, and on
Netlify.

## Deployment

No backend rewrite is needed for either platform; both adapter sets are already
in the repo.

- **Vercel** — import the repo. Vite is auto-detected; functions in `/api` are
  picked up automatically. Config: [`vercel.json`](vercel.json).
- **Netlify** — import the repo. Config: [`netlify.toml`](netlify.toml)
  (build command `npm run build`, publish `dist`, functions in
  `netlify/functions`).

## Secrets / environment variables

- Copy [`.env.example`](.env.example) to `.env` and add keys there. `.env` is
  **git-ignored** — never commit it.
- Server-side secrets are read in handlers via `process.env.MY_KEY` and are **not**
  exposed to the browser.
- Anything exposed to the frontend must be prefixed `VITE_` and is **public**
  (bundled into client code) — never put real secrets there.
- For deployment, set the same variables in the Vercel/Netlify dashboard.
