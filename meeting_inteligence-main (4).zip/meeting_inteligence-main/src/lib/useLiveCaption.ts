import { useCallback, useEffect, useRef, useState } from 'react'

/**
 * Live on-screen caption via the browser's Web Speech API — DISPLAY ONLY.
 *
 * This is deliberately separate from the audio recording. Its text is ephemeral
 * and must NEVER be saved, summarized, or treated as the real transcript: the
 * source of truth stays the full-audio → Groq result. Web Speech alone drops
 * words on long sessions, which is exactly why it is not the saved transcript.
 *
 * The hook never touches the recorder, the audio Blob, ai.ts, the transcribe
 * function, transcript state, or createMeeting.
 */

type SpeechRecognitionLike = {
  continuous: boolean
  interimResults: boolean
  lang: string
  onresult: ((e: any) => void) | null
  onerror: ((e: any) => void) | null
  onend: (() => void) | null
  start: () => void
  stop: () => void
  abort: () => void
}

function getCtor(): (new () => SpeechRecognitionLike) | null {
  if (typeof window === 'undefined') return null
  const w = window as unknown as {
    SpeechRecognition?: new () => SpeechRecognitionLike
    webkitSpeechRecognition?: new () => SpeechRecognitionLike
  }
  return w.SpeechRecognition ?? w.webkitSpeechRecognition ?? null
}

export function useLiveCaption() {
  const supported = useRef(getCtor() != null).current
  const [liveText, setLiveText] = useState('')
  const recRef = useRef<SpeechRecognitionLike | null>(null)
  const activeRef = useRef(false) // true while we want it listening
  const finalRef = useRef('') // accumulated finalized text
  const interimRef = useRef('') // current (not-yet-final) text

  const render = () =>
    setLiveText(`${finalRef.current} ${interimRef.current}`.trim())

  // Creates a fresh recognition instance and starts it. Web Speech ends itself
  // periodically (silence/timeouts), so onend relaunches while still active.
  const launch = useCallback(() => {
    const Ctor = getCtor()
    if (!Ctor) return
    let rec: SpeechRecognitionLike
    try {
      rec = new Ctor()
    } catch {
      return
    }
    rec.continuous = true
    rec.interimResults = true
    rec.onresult = (e: any) => {
      let interim = ''
      for (let i = e.resultIndex; i < e.results.length; i++) {
        const seg = e.results[i]
        const text = seg?.[0]?.transcript ?? ''
        // Append finalized segments (with a separating space) so words don't run
        // together; keep the live interim separate so it can be flushed on restart.
        if (seg?.isFinal) finalRef.current = `${finalRef.current} ${text}`.trim()
        else interim += text
      }
      interimRef.current = interim
      render()
    }
    rec.onerror = (e: any) => {
      // Stop retrying on fatal/permission errors so we don't loop forever.
      if (e?.error === 'not-allowed' || e?.error === 'service-not-allowed') {
        activeRef.current = false
      }
    }
    rec.onend = () => {
      recRef.current = null
      // Preserve any pending interim across the restart so it never vanishes.
      if (interimRef.current) {
        finalRef.current = `${finalRef.current} ${interimRef.current}`.trim()
        interimRef.current = ''
        render()
      }
      if (activeRef.current) launch() // keep captions flowing on long sessions
    }
    recRef.current = rec
    try {
      rec.start()
    } catch {
      /* start() can throw if a previous instance is still ending; ignore */
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  const start = useCallback(() => {
    if (!getCtor()) return
    activeRef.current = true
    if (!recRef.current) launch()
  }, [launch])

  const stop = useCallback(() => {
    activeRef.current = false
    const rec = recRef.current
    recRef.current = null
    if (rec) {
      try {
        rec.stop()
      } catch {
        /* ignore */
      }
    }
  }, [])

  const reset = useCallback(() => {
    finalRef.current = ''
    interimRef.current = ''
    setLiveText('')
  }, [])

  // Tear down on unmount.
  useEffect(() => {
    return () => {
      activeRef.current = false
      const rec = recRef.current
      recRef.current = null
      if (rec) {
        try {
          rec.abort()
        } catch {
          /* ignore */
        }
      }
    }
  }, [])

  return { liveText, supported, start, stop, reset }
}
