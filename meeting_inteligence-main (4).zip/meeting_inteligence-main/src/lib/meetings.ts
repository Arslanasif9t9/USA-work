import { supabase } from './supabase'

export interface MeetingInput {
  title: string
  summary: string
  transcript: string
  durationSec: number
  wordCount: number
  /** Retention window in days; used to compute expires_at on insert. */
  retentionDays?: number
}

/**
 * Inserts a meeting row (PLAN.md §6) and returns its id. Audio is never stored
 * — only the transcript + summary. expires_at is set from the retention window
 * so the 3-day (configurable) auto-delete applies.
 */
export async function createMeeting(
  userId: string,
  m: MeetingInput,
): Promise<string> {
  const expiresAt =
    m.retentionDays && m.retentionDays > 0
      ? new Date(Date.now() + m.retentionDays * 86400000).toISOString()
      : undefined

  const { data, error } = await supabase
    .from('meetings')
    .insert({
      user_id: userId,
      title: m.title,
      summary: m.summary,
      transcript: m.transcript,
      duration_sec: m.durationSec,
      word_count: m.wordCount,
      ...(expiresAt ? { expires_at: expiresAt } : {}),
    })
    .select('id')
    .single()

  if (error) throw new Error(error.message)
  return data.id as string
}

/** Updates an existing meeting's editable fields (title / summary). */
export async function updateMeeting(
  id: string,
  fields: { title?: string; summary?: string },
): Promise<void> {
  const { error } = await supabase.from('meetings').update(fields).eq('id', id)
  if (error) throw new Error(error.message)
}

export interface MeetingRow {
  id: string
  title: string
  summary: string
  duration_sec: number
  word_count: number
  created_at: string
  expires_at: string
}

/**
 * Lists the user's non-expired meetings, newest first (PLAN.md §4/§6).
 * RLS already scopes to the current user; the expires_at filter ensures
 * nothing expired is shown between hourly pg_cron purges.
 */
export async function listMeetings(userId: string): Promise<MeetingRow[]> {
  const { data, error } = await supabase
    .from('meetings')
    .select('id, title, summary, duration_sec, word_count, created_at, expires_at')
    .eq('user_id', userId)
    .gt('expires_at', new Date().toISOString())
    .order('created_at', { ascending: false })

  if (error) throw new Error(error.message)
  return (data ?? []) as MeetingRow[]
}

/** Hard-deletes a meeting row (RLS restricts this to the owner). */
export async function deleteMeeting(id: string): Promise<void> {
  const { error } = await supabase.from('meetings').delete().eq('id', id)
  if (error) throw new Error(error.message)
}
