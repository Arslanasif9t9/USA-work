import { useEffect, useState } from 'react'
import { createPortal } from 'react-dom'
import type { MeetingRow } from '../lib/meetings'
import { deleteMeeting } from '../lib/meetings'
import {
  copyText,
  downloadPdf,
  downloadTxt,
  mailtoUrl,
  whatsappUrl,
} from '../lib/exports'
import { formatDate, formatDuration } from '../lib/format'

interface Props {
  meeting: MeetingRow
  onClose: () => void
  onDeleted: (id: string) => void
}

/** Read-only viewer for a saved meeting: full summary + actions + delete. */
export default function MeetingModal({ meeting, onClose, onDeleted }: Props) {
  const [copied, setCopied] = useState(false)
  const [confirmDelete, setConfirmDelete] = useState(false)
  const [deleting, setDeleting] = useState(false)
  const [error, setError] = useState<string | null>(null)

  // Close on Esc and lock background scroll while the dialog is open.
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose()
    }
    window.addEventListener('keydown', onKey)
    const prevOverflow = document.body.style.overflow
    document.body.style.overflow = 'hidden'
    return () => {
      window.removeEventListener('keydown', onKey)
      document.body.style.overflow = prevOverflow
    }
  }, [onClose])

  const handleCopy = async () => {
    if (await copyText(meeting.summary)) {
      setCopied(true)
      window.setTimeout(() => setCopied(false), 1800)
    }
  }

  const handleDelete = async () => {
    setError(null)
    setDeleting(true)
    try {
      await deleteMeeting(meeting.id)
      onDeleted(meeting.id)
    } catch {
      setError('Could not delete this meeting. Please try again.')
      setDeleting(false)
    }
  }

  return createPortal(
    <div
      role="dialog"
      aria-modal="true"
      className="fixed inset-0 z-50 flex items-center justify-center bg-ink/50 p-4 backdrop-blur-sm"
      onClick={onClose}
    >
      <div
        className="relative flex max-h-[90vh] w-full max-w-2xl flex-col overflow-hidden rounded-card border border-line bg-surface shadow-lift"
        onClick={(e) => e.stopPropagation()}
      >
        <button
          onClick={onClose}
          aria-label="Close"
          className="absolute right-4 top-4 z-10 grid h-9 w-9 place-items-center rounded-full bg-surface/80 text-muted transition-colors hover:bg-line/50 hover:text-ink"
        >
          ✕
        </button>

        {/* Header — fixed, does not scroll */}
        <div className="shrink-0 border-b border-line px-7 pb-4 pt-7">
          <h2 className="pr-10 font-display text-2xl font-600 tracking-tight text-ink">
            {meeting.title || 'Untitled summary'}
          </h2>
          <div className="mt-1 flex flex-wrap items-center gap-3 font-mono text-xs text-muted">
            <span>{formatDate(meeting.created_at)}</span>
            <span aria-hidden>·</span>
            <span>{formatDuration(meeting.duration_sec)}</span>
            <span aria-hidden>·</span>
            <span>{meeting.word_count} words</span>
          </div>
        </div>

        {/* Body — scrolls inside the dialog */}
        <div className="min-h-0 flex-1 overflow-y-auto px-7 py-5">
        <div className="whitespace-pre-wrap rounded-xl border border-line bg-paper/40 px-4 py-3 text-sm leading-relaxed text-ink-2">
          {meeting.summary}
        </div>

        {/* Actions — Copy is the most prominent (§4) */}
        <div className="mt-4 flex flex-wrap items-center gap-2">
          <button
            onClick={handleCopy}
            className="rounded-full bg-accent px-7 py-3 text-base font-600 text-white shadow-lift transition-transform hover:-translate-y-0.5"
          >
            {copied ? 'Copied!' : 'Copy'}
          </button>
          <a
            href={mailtoUrl(meeting.title, meeting.summary)}
            className="rounded-full border border-line bg-surface px-5 py-3 text-sm font-600 text-ink-2 transition-transform hover:-translate-y-0.5"
          >
            Email
          </a>
          <a
            href={whatsappUrl(meeting.title, meeting.summary)}
            target="_blank"
            rel="noopener noreferrer"
            className="rounded-full border border-line bg-surface px-5 py-3 text-sm font-600 text-ink-2 transition-transform hover:-translate-y-0.5"
          >
            WhatsApp
          </a>
          <button
            onClick={() => void downloadPdf(meeting.title, meeting.summary)}
            className="rounded-full border border-line bg-surface px-5 py-3 text-sm font-600 text-ink-2 transition-transform hover:-translate-y-0.5"
          >
            Download PDF
          </button>
          <button
            onClick={() => downloadTxt(meeting.title, meeting.summary)}
            className="rounded-full border border-line bg-surface px-5 py-3 text-sm font-600 text-ink-2 transition-transform hover:-translate-y-0.5"
          >
            Download .txt
          </button>
        </div>

        {error && (
          <p className="mt-4 rounded-xl bg-rec/10 px-4 py-2.5 text-sm font-500 text-rec">
            {error}
          </p>
        )}

        {/* Delete */}
        <div className="mt-6 border-t border-line pt-4">
          {!confirmDelete ? (
            <button
              onClick={() => setConfirmDelete(true)}
              className="text-sm font-600 text-rec transition-colors hover:underline"
            >
              Delete this meeting
            </button>
          ) : (
            <div className="flex items-center gap-3">
              <span className="text-sm text-ink-2">Delete permanently?</span>
              <button
                onClick={handleDelete}
                disabled={deleting}
                className="rounded-full bg-rec px-5 py-2 text-sm font-600 text-white transition-transform hover:-translate-y-0.5 disabled:opacity-60"
              >
                {deleting ? 'Deleting…' : 'Yes, delete'}
              </button>
              <button
                onClick={() => setConfirmDelete(false)}
                disabled={deleting}
                className="rounded-full px-4 py-2 text-sm font-600 text-muted transition-colors hover:text-ink"
              >
                Cancel
              </button>
            </div>
          )}
        </div>
        </div>
      </div>
    </div>,
    document.body,
  )
}
