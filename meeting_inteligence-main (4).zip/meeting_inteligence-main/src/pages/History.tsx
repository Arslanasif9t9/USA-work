import { useEffect, useMemo, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import AppShell from '../components/AppShell'
import MeetingModal from '../components/MeetingModal'
import { useAuth } from '../context/AuthContext'
import { listMeetings, type MeetingRow } from '../lib/meetings'
import { formatDate, formatDuration } from '../lib/format'

/** History page (§7): all saved meetings as a responsive card grid. */
export default function History() {
  const { user } = useAuth()
  const navigate = useNavigate()
  const [items, setItems] = useState<MeetingRow[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [query, setQuery] = useState('')
  const [selected, setSelected] = useState<MeetingRow | null>(null)

  useEffect(() => {
    if (!user) return
    let cancelled = false
    setLoading(true)
    listMeetings(user.id)
      .then((rows) => {
        if (!cancelled) {
          setItems(rows)
          setError(null)
        }
      })
      .catch(() => {
        if (!cancelled) setError('Could not load your saved meetings.')
      })
      .finally(() => {
        if (!cancelled) setLoading(false)
      })
    return () => {
      cancelled = true
    }
  }, [user])

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase()
    if (!q) return items
    return items.filter(
      (m) =>
        m.title.toLowerCase().includes(q) ||
        m.summary.toLowerCase().includes(q),
    )
  }, [items, query])

  const handleDeleted = (id: string) => {
    setItems((prev) => prev.filter((m) => m.id !== id))
    setSelected(null)
  }

  return (
    <AppShell>
      <div className="reveal mx-auto max-w-5xl">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <h1 className="font-display text-3xl font-600 tracking-tight text-ink">
            History
          </h1>
          <input
            type="search"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search by title or text…"
            className="w-full max-w-xs rounded-full border border-line bg-surface px-4 py-2 text-sm text-ink placeholder:text-muted/70"
          />
        </div>

        <div className="mt-6">
          {loading ? (
            <p className="rounded-card border border-line bg-surface px-5 py-12 text-center text-sm text-muted">
              Loading…
            </p>
          ) : error ? (
            <p className="rounded-card border border-line bg-rec/10 px-5 py-12 text-center text-sm font-500 text-rec">
              {error}
            </p>
          ) : items.length === 0 ? (
            <div className="rounded-card border border-dashed border-line bg-surface/60 px-5 py-16 text-center">
              <p className="text-sm text-muted">
                No saved meetings yet. Record a briefing and your summaries will
                appear here.
              </p>
              <button
                onClick={() => navigate('/record')}
                className="mt-4 rounded-full bg-accent px-6 py-2.5 text-sm font-600 text-white transition-transform hover:-translate-y-0.5"
              >
                Start recording
              </button>
            </div>
          ) : filtered.length === 0 ? (
            <p className="rounded-card border border-dashed border-line bg-surface/60 px-5 py-16 text-center text-sm text-muted">
              No meetings match “{query}”.
            </p>
          ) : (
            <ul className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
              {filtered.map((m) => (
                <li key={m.id}>
                  <button
                    onClick={() => setSelected(m)}
                    className="flex h-full w-full flex-col rounded-card border border-line bg-surface p-5 text-left shadow-card transition-transform hover:-translate-y-0.5"
                  >
                    <span className="font-display text-lg font-600 leading-snug tracking-tight text-ink line-clamp-2">
                      {m.title || 'Untitled summary'}
                    </span>
                    <span className="mt-2 line-clamp-3 flex-1 text-sm text-muted">
                      {m.summary}
                    </span>
                    <span className="mt-3 font-mono text-xs text-muted">
                      {formatDate(m.created_at)} · {formatDuration(m.duration_sec)}{' '}
                      · {m.word_count} words
                    </span>
                  </button>
                </li>
              ))}
            </ul>
          )}
        </div>
      </div>

      {selected && (
        <MeetingModal
          meeting={selected}
          onClose={() => setSelected(null)}
          onDeleted={handleDeleted}
        />
      )}
    </AppShell>
  )
}
