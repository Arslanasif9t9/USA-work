import { useCallback, useEffect, useRef, useState } from 'react'
import AppShell from '../components/AppShell'
import ProgressRing from '../components/ProgressRing'
import RecordButton, { type RecordState } from '../components/RecordButton'
import { AudioRecorder, MicPermissionError } from '../lib/recorder'
import { transcribeAudio, summarizeTranscript } from '../lib/ai'
import { createMeeting, updateMeeting } from '../lib/meetings'
import SummaryCard, { type SaveState } from '../components/SummaryCard'
import RegenerateBox from '../components/RegenerateBox'
import TranscriptPanel from '../components/TranscriptPanel'
import CopyButton from '../components/CopyButton'
import { transcriptWithPrompt } from '../lib/exports'
import { useLiveCaption } from '../lib/useLiveCaption'
import { useAuth } from '../context/AuthContext'
import { supabase } from '../lib/supabase'

const DEFAULT_MAX_MINUTES = 30

function formatTime(totalSeconds: number): string {
  const s = Math.max(0, Math.floor(totalSeconds))
  const mm = String(Math.floor(s / 60)).padStart(2, '0')
  const ss = String(s % 60).padStart(2, '0')
  return `${mm}:${ss}`
}

function countWords(text: string): number {
  return text.trim().split(/\s+/).filter(Boolean).length
}

export default function Recorder() {
  const { user } = useAuth()

  // Live on-screen caption (Web Speech, display-only — NOT the saved transcript).
  const live = useLiveCaption()
  const liveBoxRef = useRef<HTMLDivElement>(null)
  useEffect(() => {
    const el = liveBoxRef.current
    if (el) el.scrollTop = el.scrollHeight
  }, [live.liveText])

  const [maxMinutes, setMaxMinutes] = useState(DEFAULT_MAX_MINUTES)
  const [state, setState] = useState<RecordState>('idle')
  const [elapsed, setElapsed] = useState(0) // seconds
  const [level, setLevel] = useState(0)
  const [error, setError] = useState<string | null>(null)
  const [audioBlob, setAudioBlob] = useState<Blob | null>(null)
  const [audioUrl, setAudioUrl] = useState<string | null>(null)
  const [transcribing, setTranscribing] = useState(false)
  const [transcript, setTranscript] = useState<string | null>(null)
  const [transcribeError, setTranscribeError] = useState<string | null>(null)
  const [summarizing, setSummarizing] = useState(false)
  const [regenerating, setRegenerating] = useState(false)
  const [summary, setSummary] = useState<string | null>(null)
  const [summaryTitle, setSummaryTitle] = useState<string | null>(null)
  const [summaryError, setSummaryError] = useState<string | null>(null)
  const [retentionDays, setRetentionDays] = useState(3)
  const [saveState, setSaveState] = useState<SaveState>('idle')

  // Persistence: the meeting row id, plus refs holding the latest editable
  // values for the debounced auto-save.
  const meetingIdRef = useRef<string | null>(null)
  const titleRef = useRef('')
  const summaryRef = useRef('')
  const transcriptRef = useRef('')
  const durationRef = useRef(0)
  const saveTimerRef = useRef<number | null>(null)
  // Default summary instruction from Settings (empty = standard bullets).
  const defaultPromptRef = useRef('')
  // AI model preference from Settings (sent to the Edge Functions).
  const modelRef = useRef<string | undefined>(undefined)

  const recorderRef = useRef<AudioRecorder | null>(null)
  const elapsedMsRef = useRef(0)
  const lastTickRef = useRef(0)
  const tickRef = useRef<number | null>(null)
  const stateRef = useRef<RecordState>('idle')
  stateRef.current = state

  const capSeconds = maxMinutes * 60

  // Load the recording cap from the profile (Settings page persists it later).
  useEffect(() => {
    if (!user) return
    supabase
      .from('profiles')
      .select('max_minutes, retention_days, default_prompt, ai_model')
      .eq('id', user.id)
      .single()
      .then(({ data }) => {
        if (data?.max_minutes) setMaxMinutes(data.max_minutes)
        if (data?.retention_days) setRetentionDays(data.retention_days)
        defaultPromptRef.current = data?.default_prompt ?? ''
        modelRef.current = data?.ai_model ?? undefined
      })
  }, [user])

  const stopTicking = useCallback(() => {
    if (tickRef.current !== null) {
      cancelAnimationFrame(tickRef.current)
      tickRef.current = null
    }
  }, [])

  // Persist after a (re)generation: insert the meeting row on the first
  // summary, update it thereafter (PLAN.md §6 — audio is never stored).
  const persistSummary = useCallback(
    async (title: string, summaryText: string) => {
      if (!user) return
      try {
        setSaveState('saving')
        if (meetingIdRef.current) {
          await updateMeeting(meetingIdRef.current, { title, summary: summaryText })
        } else {
          meetingIdRef.current = await createMeeting(user.id, {
            title,
            summary: summaryText,
            transcript: transcriptRef.current,
            durationSec: durationRef.current,
            wordCount: countWords(transcriptRef.current),
            retentionDays,
          })
        }
        setSaveState('saved')
      } catch {
        setSaveState('error')
      }
    },
    [user, retentionDays],
  )

  // Generate the worker-facing summary (§3). `regenerate` keeps the card
  // visible (in-place rewrite); the initial call shows the loading state.
  const generateSummary = useCallback(
    async (transcriptText: string, instruction = '', regenerate = false) => {
      setSummaryError(null)
      if (regenerate) {
        setRegenerating(true)
      } else {
        setSummary(null)
        setSummaryTitle(null)
        setSummarizing(true)
      }
      try {
        const { title, summary } = await summarizeTranscript(
          transcriptText,
          instruction,
          modelRef.current,
        )
        setSummaryTitle(title)
        setSummary(summary)
        titleRef.current = title
        summaryRef.current = summary
        await persistSummary(title, summary)
      } catch (e) {
        setSummaryError(
          e instanceof Error ? e.message : 'Could not generate the summary.',
        )
      } finally {
        setSummarizing(false)
        setRegenerating(false)
      }
    },
    [persistSummary],
  )

  // Debounced auto-save of in-place edits to the summary/title.
  const scheduleSave = useCallback(() => {
    if (saveTimerRef.current) window.clearTimeout(saveTimerRef.current)
    setSaveState('saving')
    saveTimerRef.current = window.setTimeout(async () => {
      if (!meetingIdRef.current) {
        setSaveState('idle')
        return
      }
      try {
        await updateMeeting(meetingIdRef.current, {
          title: titleRef.current,
          summary: summaryRef.current,
        })
        setSaveState('saved')
      } catch {
        setSaveState('error')
      }
    }, 800)
  }, [])

  // Clears persistence state so the next recording starts a fresh meeting row.
  const resetPersistence = () => {
    if (saveTimerRef.current) window.clearTimeout(saveTimerRef.current)
    meetingIdRef.current = null
    titleRef.current = ''
    summaryRef.current = ''
    transcriptRef.current = ''
    durationRef.current = 0
    setSaveState('idle')
  }

  const handleEditTitle = (t: string) => {
    setSummaryTitle(t)
    titleRef.current = t
    scheduleSave()
  }
  const handleEditSummary = (s: string) => {
    setSummary(s)
    summaryRef.current = s
    scheduleSave()
  }

  // Send the recorded audio to the transcribe Edge Function (Gemini, §2),
  // then automatically summarize the returned transcript.
  const runTranscription = useCallback(
    async (blob: Blob) => {
      setTranscribeError(null)
      setTranscript(null)
      setTranscribing(true)
      try {
        const text = await transcribeAudio(blob, modelRef.current)
        setTranscript(text)
        transcriptRef.current = text
        durationRef.current = Math.round(elapsedMsRef.current / 1000)
        // Apply the user's default summary instruction, if any (§7).
        void generateSummary(text, defaultPromptRef.current)
      } catch (e) {
        setTranscribeError(
          e instanceof Error
            ? e.message
            : 'Transcription failed. Please try again.',
        )
      } finally {
        setTranscribing(false)
      }
    },
    [generateSummary],
  )

  const handleStop = useCallback(async () => {
    stopTicking()
    live.stop()
    const recorder = recorderRef.current
    if (!recorder) return
    try {
      const blob = await recorder.stop()
      setAudioBlob(blob)
      setAudioUrl((prev) => {
        if (prev) URL.revokeObjectURL(prev)
        return URL.createObjectURL(blob)
      })
      void runTranscription(blob)
    } catch {
      setError('Something went wrong while finishing the recording.')
    } finally {
      recorderRef.current = null
      setState('idle')
      stateRef.current = 'idle'
      setLevel(0)
    }
  }, [stopTicking, runTranscription])

  // Single animation-frame loop. Accumulates elapsed time only while actively
  // recording, so Pause/Resume keeps the clock correct (acceptance §13).
  const tick = useCallback(() => {
    const now = performance.now()
    const delta = now - lastTickRef.current
    lastTickRef.current = now

    if (stateRef.current === 'recording') {
      elapsedMsRef.current += delta
      const secs = elapsedMsRef.current / 1000
      setElapsed(secs)
      setLevel(recorderRef.current?.getLevel() ?? 0)

      if (secs >= capSeconds) {
        void handleStop() // auto-stop at the cap
        return
      }
    }
    tickRef.current = requestAnimationFrame(tick)
  }, [capSeconds, handleStop])

  const handleStart = async () => {
    setError(null)
    const recorder = new AudioRecorder()
    try {
      await recorder.start()
    } catch (err) {
      if (err instanceof MicPermissionError) setError(err.message)
      else setError('Could not start recording. Please try again.')
      recorder.dispose()
      return
    }
    recorderRef.current = recorder
    elapsedMsRef.current = 0
    lastTickRef.current = performance.now()
    setElapsed(0)
    setAudioBlob(null)
    setTranscript(null)
    setTranscribeError(null)
    setSummary(null)
    setSummaryTitle(null)
    setSummaryError(null)
    resetPersistence()
    live.reset()
    live.start() // ephemeral on-screen captions only
    setState('recording')
    stateRef.current = 'recording'
    tickRef.current = requestAnimationFrame(tick)
  }

  const handlePause = () => {
    recorderRef.current?.pause()
    live.stop()
    setState('paused')
    stateRef.current = 'paused'
    setLevel(0)
  }

  const handleResume = () => {
    recorderRef.current?.resume()
    live.start()
    lastTickRef.current = performance.now()
    setState('recording')
    stateRef.current = 'recording'
  }

  const handleReset = () => {
    setAudioBlob(null)
    setAudioUrl((prev) => {
      if (prev) URL.revokeObjectURL(prev)
      return null
    })
    setElapsed(0)
    elapsedMsRef.current = 0
    setError(null)
    setTranscript(null)
    setTranscribeError(null)
    setSummary(null)
    setSummaryTitle(null)
    setSummaryError(null)
    resetPersistence()
    live.reset()
  }

  const handleMainButton = () => {
    if (state === 'idle') void handleStart()
    else void handleStop()
  }

  // Spacebar starts/stops recording (§4), unless the user is typing in a
  // field or focused on a button. A ref keeps the listener bound once.
  const mainButtonRef = useRef(handleMainButton)
  mainButtonRef.current = handleMainButton
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.code !== 'Space') return
      const el = document.activeElement as HTMLElement | null
      const tag = el?.tagName
      if (
        tag === 'INPUT' ||
        tag === 'TEXTAREA' ||
        tag === 'SELECT' ||
        tag === 'BUTTON' ||
        el?.isContentEditable
      ) {
        return
      }
      e.preventDefault()
      mainButtonRef.current()
    }
    window.addEventListener('keydown', onKey)
    return () => window.removeEventListener('keydown', onKey)
  }, [])

  // Cleanup on unmount: stop ticking and release the mic.
  useEffect(() => {
    return () => {
      stopTicking()
      recorderRef.current?.dispose()
      if (audioUrl) URL.revokeObjectURL(audioUrl)
      if (saveTimerRef.current) window.clearTimeout(saveTimerRef.current)
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  const inSession = state !== 'idle'
  const progress = capSeconds > 0 ? elapsed / capSeconds : 0
  const ringColor =
    state === 'recording'
      ? 'var(--color-rec)'
      : state === 'paused'
        ? 'var(--color-amber)'
        : 'var(--color-accent)'

  return (
    <AppShell>
      <div className="reveal mx-auto flex max-w-xl flex-col items-center text-center">
        <h1 className="font-display text-3xl font-600 tracking-tight text-ink">
          {inSession ? 'Recording your briefing' : 'New recording'}
        </h1>
        <p className="mt-2 max-w-md text-sm text-muted">
          {inSession
            ? 'Speak naturally — every word is being captured. Press the button to finish.'
            : 'Press the button and talk through the task. The full audio is recorded so nothing is missed.'}
        </p>

        {/* Mic-permission / recording error */}
        {error && (
          <p className="mt-4 w-full rounded-xl bg-rec/10 px-4 py-3 text-sm font-500 text-rec">
            {error}
          </p>
        )}

        {/* Record button + countdown ring */}
        <div className="mt-6">
          <ProgressRing progress={progress} color={ringColor} size={224}>
            <RecordButton
              state={state}
              level={level}
              onClick={handleMainButton}
            />
          </ProgressRing>
        </div>

        {/* Mono timer MM:SS / max */}
        <p className="mt-5 font-mono text-lg font-500 text-ink-2">
          {formatTime(elapsed)}{' '}
          <span className="text-muted">/ {formatTime(capSeconds)}</span>
        </p>

        {/* Spacebar hint (§4) */}
        <p className="mt-2 text-xs text-muted">
          Tip: press{' '}
          <kbd className="rounded border border-line bg-paper px-1.5 py-0.5 font-mono text-[0.7rem] text-ink-2">
            Space
          </kbd>{' '}
          to {inSession ? 'stop' : 'start'}.
        </p>

        {/* Pause / Resume pill — only during a session */}
        {inSession && (
          <div className="mt-6">
            {state === 'recording' ? (
              <button
                onClick={handlePause}
                className="rounded-full border border-line bg-surface px-6 py-2.5 text-sm font-600 text-ink-2 shadow-card transition-transform hover:-translate-y-0.5"
              >
                Pause
              </button>
            ) : (
              <button
                onClick={handleResume}
                className="rounded-full border border-amber/40 bg-amber/10 px-6 py-2.5 text-sm font-600 text-amber shadow-card transition-transform hover:-translate-y-0.5"
              >
                Resume
              </button>
            )}
          </div>
        )}

        {/* Live preview — Web Speech, on-screen only. NOT saved; the final
            transcript is the full-audio → Groq result generated after Stop. */}
        {inSession &&
          (live.supported ? (
            <div className="mt-6 w-full">
              <div className="mb-1 text-xs font-600 text-muted">
                Live preview — the final transcript is generated after you stop.
              </div>
              <div
                ref={liveBoxRef}
                className="max-h-32 w-full overflow-y-auto rounded-xl border border-line bg-paper/40 px-4 py-3 text-left text-sm leading-relaxed text-ink-2"
              >
                {live.liveText || (
                  <span className="text-muted">Listening…</span>
                )}
              </div>
            </div>
          ) : (
            <p className="mt-4 text-xs text-muted">
              Live preview isn't supported in this browser.
            </p>
          ))}
      </div>

      {/* After stop: two columns (transcript | summary) with a full-width
          Regenerate row below. Cards size to their content (no fixed height /
          scrollbars); stacks to one column on mobile in order
          transcript → summary → regenerate. */}
      {!inSession && audioBlob && (
        <section className="reveal mt-8">
          <div className="mb-4 flex items-center justify-end">
            <button
              onClick={handleReset}
              className="rounded-full bg-accent px-6 py-2.5 text-sm font-600 text-white transition-transform hover:-translate-y-0.5"
            >
              Record again
            </button>
          </div>

          <div className="grid grid-cols-1 gap-4 lg:grid-cols-[1fr_1.4fr] lg:items-start">
            {/* LEFT — transcript ("Recording captured") */}
            <div className="rounded-card border border-line bg-surface p-5 text-left shadow-card">
              <div className="flex items-center gap-2">
                <span className="h-2.5 w-2.5 rounded-full bg-good" />
                <h2 className="font-display text-lg font-600 text-ink">
                  Recording captured
                </h2>
              </div>
              <p className="mt-1 text-sm text-muted">
                {formatTime(elapsed)} of audio captured.
              </p>

              {audioUrl && (
                <audio controls src={audioUrl} className="mt-4 w-full">
                  Your browser does not support audio playback.
                </audio>
              )}

              {transcribing && (
                <div className="mt-4 flex items-center gap-3 rounded-xl bg-accent-soft/60 px-4 py-3 text-sm font-500 text-accent">
                  <span className="h-4 w-4 animate-spin rounded-full border-2 border-accent/30 border-t-accent" />
                  Transcribing the full recording…
                </div>
              )}

              {transcribeError && !transcribing && (
                <div className="mt-4 rounded-xl bg-rec/10 px-4 py-3 text-sm font-500 text-rec">
                  {transcribeError}
                  <button
                    onClick={() => void runTranscription(audioBlob)}
                    className="ml-2 underline underline-offset-2 hover:no-underline"
                  >
                    Try again
                  </button>
                </div>
              )}

              {transcript !== null && !transcribing && (
                <div className="mt-4">
                  <TranscriptPanel transcript={transcript} />
                </div>
              )}
            </div>

            {/* RIGHT — summary card (wider) */}
            <div className="rounded-card border border-line bg-surface p-5 text-left shadow-card">
              {transcript === null ? (
                <p className="text-sm text-muted">
                  Your summary will appear here once the transcript is ready.
                </p>
              ) : summarizing ? (
                <div className="flex items-center gap-3 rounded-xl bg-accent-soft/60 px-4 py-3 text-sm font-500 text-accent">
                  <span className="h-4 w-4 animate-spin rounded-full border-2 border-accent/30 border-t-accent" />
                  Writing the summary…
                </div>
              ) : summaryError ? (
                <div className="rounded-xl border border-rec/30 bg-rec/10 px-4 py-4">
                  <p className="text-sm font-500 text-rec">{summaryError}</p>
                  <p className="mt-2 text-sm text-ink-2">
                    No problem — your full transcript is safe on the left. You
                    can retry, or copy the transcript into any other AI to get
                    the summary yourself.
                  </p>
                  <div className="mt-3 flex flex-wrap gap-2">
                    <button
                      onClick={() => void generateSummary(transcript)}
                      className="rounded-full bg-accent px-5 py-2.5 text-sm font-600 text-white transition-transform hover:-translate-y-0.5"
                    >
                      Try again
                    </button>
                    <CopyButton
                      text={transcript}
                      label="Copy full transcript"
                      className="rounded-full border border-line bg-surface px-5 py-2.5 text-sm font-600 text-ink-2 transition-transform hover:-translate-y-0.5"
                    />
                    <CopyButton
                      text={() => transcriptWithPrompt(transcript)}
                      label="Copy transcript + summary prompt"
                      className="rounded-full border border-line bg-surface px-5 py-2.5 text-sm font-600 text-ink-2 transition-transform hover:-translate-y-0.5"
                    />
                  </div>
                </div>
              ) : summary !== null ? (
                <SummaryCard
                  title={summaryTitle ?? ''}
                  summary={summary}
                  durationSec={durationRef.current}
                  wordCount={countWords(transcript)}
                  saveState={saveState}
                  onChangeTitle={handleEditTitle}
                  onChangeSummary={handleEditSummary}
                />
              ) : (
                <p className="text-sm text-muted">Preparing the summary…</p>
              )}
            </div>
          </div>

          {/* Regenerate with AI — full-width row below the two columns */}
          <div className="mt-4 rounded-card border border-line bg-surface p-5 text-left shadow-card">
            <RegenerateBox
              regenerating={regenerating}
              disabled={transcript === null}
              onRegenerate={(instruction) =>
                void generateSummary(transcript ?? '', instruction, true)
              }
            />
          </div>
        </section>
      )}
    </AppShell>
  )
}
