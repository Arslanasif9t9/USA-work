import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useState,
  type ReactNode,
} from 'react'
import type { Session, User } from '@supabase/supabase-js'
import { supabase } from '../lib/supabase'
import { COMPANY_DEFAULT } from '../lib/profile'

type AuthResult = { error: string | null }

interface AuthContextValue {
  session: Session | null
  user: User | null
  loading: boolean
  /** Configured company name, shown in the header (PLAN.md §7/§8). */
  company: string
  /** Re-reads the profile (e.g. after Settings are saved). */
  refreshProfile: () => Promise<void>
  signIn: (email: string, password: string) => Promise<AuthResult>
  signOut: () => Promise<void>
}

const AuthContext = createContext<AuthContextValue | undefined>(undefined)

/**
 * Ensures a profiles row exists for the signed-in user (PLAN.md §6).
 * Uses upsert so it is safe to call on every sign-in — idempotent whether
 * the row already existed or not. With a single fixed admin user this simply
 * guarantees the admin's profile row is present after the first login.
 */
async function ensureProfile(user: User) {
  const { error } = await supabase
    .from('profiles')
    .upsert({ id: user.id }, { onConflict: 'id', ignoreDuplicates: true })
  if (error) console.error('Failed to ensure profile row:', error.message)
}

export function AuthProvider({ children }: { children: ReactNode }) {
  const [session, setSession] = useState<Session | null>(null)
  const [loading, setLoading] = useState(true)
  const [company, setCompany] = useState(COMPANY_DEFAULT)

  // Reads the current user's company for the header. Falls back to the
  // default when signed out or if the field is empty.
  const refreshProfile = useCallback(async () => {
    const {
      data: { user },
    } = await supabase.auth.getUser()
    if (!user) {
      setCompany(COMPANY_DEFAULT)
      return
    }
    const { data } = await supabase
      .from('profiles')
      .select('company')
      .eq('id', user.id)
      .single()
    setCompany(data?.company || COMPANY_DEFAULT)
  }, [])

  useEffect(() => {
    supabase.auth.getSession().then(({ data }) => {
      setSession(data.session)
      setLoading(false)
      if (data.session?.user) void refreshProfile()
    })

    const { data: sub } = supabase.auth.onAuthStateChange((_event, next) => {
      setSession(next)
      if (next?.user) {
        void ensureProfile(next.user).then(() => refreshProfile())
      } else {
        setCompany(COMPANY_DEFAULT)
      }
    })

    return () => sub.subscription.unsubscribe()
  }, [refreshProfile])

  const signIn: AuthContextValue['signIn'] = async (email, password) => {
    const { error } = await supabase.auth.signInWithPassword({ email, password })
    return { error: error ? error.message : null }
  }

  const signOut = async () => {
    await supabase.auth.signOut()
  }

  const value: AuthContextValue = {
    session,
    user: session?.user ?? null,
    loading,
    company,
    refreshProfile,
    signIn,
    signOut,
  }

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>
}

// eslint-disable-next-line react-refresh/only-export-components
export function useAuth() {
  const ctx = useContext(AuthContext)
  if (!ctx) throw new Error('useAuth must be used within an AuthProvider')
  return ctx
}
