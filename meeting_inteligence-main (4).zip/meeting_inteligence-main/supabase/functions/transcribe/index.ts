// EIA Recap — `transcribe` Edge Function (Path A: Groq primary, Gemini fallback)
//
// Returns { transcript } for the full recorded audio.
// - PRIMARY: Groq Whisper "whisper-large-v3-turbo" (OpenAI-compatible).
// - FALLBACK: existing Gemini path, used automatically when Groq hits a
//   rate-limit/quota (429) or any other failure, and for audio larger than
//   Groq's file-size limit (Gemini handles big files via its Files API).
// - Verifies the Supabase JWT, sends CORS headers, returns clear 429/errors.
// - The transcript is the COMPLETE provider output, always returned in LATIN
//   script: English stays English; Urdu/Arabic and Hindi/Devanagari are
//   transliterated to Roman (same words, every word) via a STRICT, word-count-
//   guarded pass that falls back to the complete native-script text if it would
//   ever shorten the transcript. This is transliteration, not translation.
// - Audio is never stored; it lives only for this request.
//
// Transcription is kept separate from summarization (its own function/module)
// and the provider is swappable via the `transcribe()` orchestrator below.

import { createClient } from 'jsr:@supabase/supabase-js@2'
import { encodeBase64 } from 'jsr:@std/encoding@1/base64'

const GROQ_API_KEY = Deno.env.get('GROQ_API_KEY') ?? ''
const GEMINI_API_KEY = Deno.env.get('GEMINI_API_KEY') ?? ''
const GEMINI_MODEL = Deno.env.get('GEMINI_MODEL') ?? 'gemini-2.5-flash'

const GROQ_BASE = 'https://api.groq.com/openai/v1'
const GEMINI_BASE = 'https://generativelanguage.googleapis.com'
const GROQ_WHISPER_MODEL = 'whisper-large-v3-turbo'
const GROQ_CHAT_MODEL = 'llama-3.3-70b-versatile'

// Scripts we transliterate. Devanagari (Hindi) is handled DETERMINISTICALLY
// (lossless, zero AI tokens); Arabic/Urdu (an abjad — needs vowel restoration)
// goes through the guarded LLM path.
const ARABIC_RE = /[؀-ۿݐ-ݿࢠ-ࣿﭐ-﷿ﹰ-﻿]/
const DEVANAGARI_RE = /[ऀ-ॿ]/
// Small chunks + a fixed generous token budget so an LLM chunk can never be cut
// off mid-way (Roman Urdu/Hindi tokenizes densely).
const TRANSLIT_CHUNK_CHARS = 3000
const TRANSLIT_MAX_TOKENS = 8000
// Require near-complete output; otherwise discard and keep the COMPLETE
// native-script transcript (completeness wins over script).
const TRANSLIT_MIN_WORD_RATIO = 0.95

const countWords = (t: string) => t.trim().split(/\s+/).filter(Boolean).length

// Groq free-tier audio file cap is ~25 MB; stay safely under it. Bigger files
// go to Gemini (Files API) since a compressed audio stream can't be byte-sliced
// into valid chunks inside the Edge runtime.
const GROQ_AUDIO_LIMIT = 24 * 1024 * 1024
const GEMINI_INLINE_LIMIT = 18 * 1024 * 1024

// Gemini model the FALLBACK uses (from the user's profile; allowlisted).
const ALLOWED_MODELS = new Set([
  'gemini-2.5-flash',
  'gemini-2.5-flash-lite',
  'gemini-3.5-flash',
])
const resolveModel = (m: string | null) =>
  m && ALLOWED_MODELS.has(m) ? m : GEMINI_MODEL

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers':
    'authorization, x-client-info, apikey, content-type',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
}

const TRANSCRIBE_PROMPT = `You are a precise audio transcription engine.
Transcribe the ENTIRE audio from the very beginning to the very end, word for word.
Do NOT summarize, paraphrase, condense, or stop early — include every sentence through to the final word.

Language rules:
- If the speech is in English, transcribe in English.
- If the speech is in Urdu, transcribe it in ROMAN URDU (Urdu written using English/Latin letters, e.g. "kal tak report bhej dena"). NEVER use Urdu/Arabic (Nastaliq) script.
- If the speech mixes Urdu and English, keep each part as spoken (Roman Urdu for Urdu, English for English).

Output ONLY the raw transcript text. No preamble, no notes, no timestamps, no speaker labels.`

function json(body: unknown, status = 200): Response {
  return new Response(JSON.stringify(body), {
    status,
    headers: { ...corsHeaders, 'Content-Type': 'application/json' },
  })
}

/** Upstream-provider error carrying the HTTP status (429 ⇒ retryable). */
class ProviderError extends Error {
  status: number
  retryable: boolean
  provider: string
  constructor(status: number, message: string, provider: string) {
    super(message)
    this.status = status
    this.provider = provider
    this.retryable = status === 429 || status >= 500
    this.name = 'ProviderError'
  }
}

// ── GROQ (primary) ──────────────────────────────────────────────────────────
async function groqTranscribe(bytes: Uint8Array, mime: string): Promise<string> {
  const form = new FormData()
  form.append('file', new Blob([bytes], { type: mime || 'audio/webm' }), 'audio.webm')
  form.append('model', GROQ_WHISPER_MODEL)
  form.append('response_format', 'json')
  form.append('temperature', '0')

  const res = await fetch(`${GROQ_BASE}/audio/transcriptions`, {
    method: 'POST',
    headers: { Authorization: `Bearer ${GROQ_API_KEY}` },
    body: form,
  })
  if (!res.ok) {
    throw new ProviderError(res.status, `Groq transcription ${res.status}: ${await res.text()}`, 'groq')
  }
  const data = await res.json()
  const text = String(data?.text ?? '').trim()
  if (!text) throw new ProviderError(502, 'Groq returned an empty transcript.', 'groq')
  return text
}

async function groqChat(system: string, user: string, maxTokens: number): Promise<string> {
  const res = await fetch(`${GROQ_BASE}/chat/completions`, {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${GROQ_API_KEY}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      model: GROQ_CHAT_MODEL,
      temperature: 0,
      max_tokens: maxTokens,
      messages: [
        { role: 'system', content: system },
        { role: 'user', content: user },
      ],
    }),
  })
  if (!res.ok) {
    throw new ProviderError(res.status, `Groq chat ${res.status}: ${await res.text()}`, 'groq')
  }
  const data = await res.json()
  const text = String(data?.choices?.[0]?.message?.content ?? '').trim()
  if (!text) throw new ProviderError(502, 'Groq chat returned no text.', 'groq')
  return text
}

// ── GEMINI (fallback) ─────────────────────────────────────────────────────────
function geminiExtract(data: any): string {
  const parts = data?.candidates?.[0]?.content?.parts ?? []
  const text = parts.map((p: any) => p?.text ?? '').join('').trim()
  if (!text) {
    const reason = data?.candidates?.[0]?.finishReason ?? 'unknown'
    throw new ProviderError(502, `Gemini returned no text (finishReason: ${reason})`, 'gemini')
  }
  return text
}

async function geminiGenerate(
  model: string,
  parts: Record<string, unknown>[],
): Promise<string> {
  const res = await fetch(
    `${GEMINI_BASE}/v1beta/models/${model}:generateContent?key=${GEMINI_API_KEY}`,
    {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        contents: [{ parts }],
        generationConfig: {
          temperature: 0,
          maxOutputTokens: 32768,
          thinkingConfig: { thinkingBudget: 0 },
        },
      }),
    },
  )
  if (!res.ok) {
    throw new ProviderError(res.status, `Gemini ${res.status}: ${await res.text()}`, 'gemini')
  }
  return geminiExtract(await res.json())
}

async function geminiInline(model: string, bytes: Uint8Array, mime: string) {
  return geminiGenerate(model, [
    { text: TRANSCRIBE_PROMPT },
    { inline_data: { mime_type: mime, data: encodeBase64(bytes) } },
  ])
}

const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms))

async function geminiFilesApi(model: string, bytes: Uint8Array, mime: string) {
  const startRes = await fetch(`${GEMINI_BASE}/upload/v1beta/files?key=${GEMINI_API_KEY}`, {
    method: 'POST',
    headers: {
      'X-Goog-Upload-Protocol': 'resumable',
      'X-Goog-Upload-Command': 'start',
      'X-Goog-Upload-Header-Content-Length': String(bytes.byteLength),
      'X-Goog-Upload-Header-Content-Type': mime,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({ file: { display_name: 'eia-recording' } }),
  })
  if (!startRes.ok) {
    throw new ProviderError(startRes.status, `Files API start ${startRes.status}`, 'gemini')
  }
  const uploadUrl = startRes.headers.get('X-Goog-Upload-URL')
  if (!uploadUrl) throw new ProviderError(502, 'Files API gave no upload URL', 'gemini')

  const uploadRes = await fetch(uploadUrl, {
    method: 'POST',
    headers: {
      'Content-Length': String(bytes.byteLength),
      'X-Goog-Upload-Offset': '0',
      'X-Goog-Upload-Command': 'upload, finalize',
    },
    body: bytes,
  })
  if (!uploadRes.ok) {
    throw new ProviderError(uploadRes.status, `Files API upload ${uploadRes.status}`, 'gemini')
  }
  let file = (await uploadRes.json())?.file
  if (!file?.name) throw new ProviderError(502, 'Files API returned no handle', 'gemini')

  let waited = 0
  while (file.state === 'PROCESSING') {
    if (waited > 120_000) throw new ProviderError(504, 'Timed out processing audio', 'gemini')
    await sleep(2000)
    waited += 2000
    const r = await fetch(`${GEMINI_BASE}/v1beta/${file.name}?key=${GEMINI_API_KEY}`)
    file = await r.json()
  }
  if (file.state !== 'ACTIVE') {
    throw new ProviderError(502, `Audio file not ACTIVE (${file.state})`, 'gemini')
  }

  const transcript = await geminiGenerate(model, [
    { text: TRANSCRIBE_PROMPT },
    { file_data: { mime_type: file.mimeType ?? mime, file_uri: file.uri } },
  ])
  fetch(`${GEMINI_BASE}/v1beta/${file.name}?key=${GEMINI_API_KEY}`, { method: 'DELETE' }).catch(() => {})
  return transcript
}

// ── Faithful transliteration to Latin script ──────────────────────────────────
// Hindi (Devanagari) → DETERMINISTIC character map below: lossless, zero AI
// tokens, cannot drop or summarize words. Urdu/Arabic (an abjad — vowels not
// written) → a STRICT, word-preserving LLM pass, chunked, with per-chunk retry
// and a word-count guard that keeps the COMPLETE native-script transcript if the
// result is ever short (completeness wins). Only runs when non-Latin is found.

// Deterministic Devanagari → Latin (ITRANS-ish). Maps every code point; spaces
// and punctuation pass through unchanged, so the word count is preserved exactly.
const DEV_VIRAMA = '्'
const DEV_NUKTA = '़'
const DEV_INDEP: Record<string, string> = {
  अ: 'a', आ: 'aa', इ: 'i', ई: 'ii', उ: 'u', ऊ: 'uu', ऋ: 'ri', ॠ: 'rii',
  ऌ: 'li', ए: 'e', ऐ: 'ai', ओ: 'o', औ: 'au', ऍ: 'e', ऎ: 'e', ऑ: 'o', ऒ: 'o',
}
const DEV_CONS: Record<string, string> = {
  क: 'k', ख: 'kh', ग: 'g', घ: 'gh', ङ: 'ng', च: 'ch', छ: 'chh', ज: 'j',
  झ: 'jh', ञ: 'ny', ट: 't', ठ: 'th', ड: 'd', ढ: 'dh', ण: 'n', त: 't',
  थ: 'th', द: 'd', ध: 'dh', न: 'n', प: 'p', फ: 'ph', ब: 'b', भ: 'bh',
  म: 'm', य: 'y', र: 'r', ल: 'l', व: 'v', श: 'sh', ष: 'sh', स: 's', ह: 'h',
  ळ: 'l', क्ष: 'ksh', त्र: 'tr', ज्ञ: 'gy',
}
const DEV_MATRA: Record<string, string> = {
  'ा': 'aa', 'ि': 'i', 'ी': 'ii', 'ु': 'u', 'ू': 'uu',
  'ृ': 'ri', 'े': 'e', 'ै': 'ai', 'ो': 'o', 'ौ': 'au',
  'ॉ': 'o', 'ॅ': 'e', 'ॆ': 'e', 'ॊ': 'o',
}
const DEV_SIGN: Record<string, string> = {
  'ं': 'n', 'ः': 'h', 'ँ': 'n', ॐ: 'om', '।': '.', '॥': '.',
}
const DEV_DIGIT: Record<string, string> = {
  '०': '0', '१': '1', '२': '2', '३': '3', '४': '4',
  '५': '5', '६': '6', '७': '7', '८': '8', '९': '9',
}

function devanagariToLatin(input: string): string {
  const chars = Array.from(input)
  let out = ''
  for (let i = 0; i < chars.length; i++) {
    const c = chars[i]
    if (DEV_CONS[c] != null) {
      out += DEV_CONS[c]
      let j = i + 1
      if (chars[j] === DEV_NUKTA) j++ // ignore nukta; keep base consonant
      const nx = chars[j]
      if (nx === DEV_VIRAMA) {
        i = j // bare consonant, no vowel
      } else if (nx != null && DEV_MATRA[nx] != null) {
        out += DEV_MATRA[nx]
        i = j // matra replaces inherent vowel
      } else {
        out += 'a' // inherent vowel
        i = j - 1
      }
    } else if (DEV_INDEP[c] != null) out += DEV_INDEP[c]
    else if (DEV_MATRA[c] != null) out += DEV_MATRA[c]
    else if (DEV_SIGN[c] != null) out += DEV_SIGN[c]
    else if (DEV_DIGIT[c] != null) out += DEV_DIGIT[c]
    else if (c === DEV_VIRAMA || c === DEV_NUKTA) {
      /* stray combining mark — skip */
    } else out += c // spaces, punctuation, Latin pass through unchanged
  }
  return out
}

const TRANSLIT_SYSTEM =
  'You are a strict transliteration engine. Convert the given text to Latin/Roman script (Roman Urdu / romanized Hindi). RULES: (1) Transliterate EVERY word — the output must have the same number of words, in the same order. (2) Do NOT translate to English, do NOT summarize, do NOT shorten, and do NOT add, drop, merge, or reorder words. (3) Only change the script to Latin letters; keep the exact same spoken words, restoring natural vowels (e.g. "کل تک رپورٹ بھیج دینا" -> "kal tak report bhej dena"). (4) Output ONLY the transliterated text — no quotes, no notes, no commentary.'

/** Splits text into <=maxChars chunks on line/space boundaries (never mid-word where avoidable). */
function chunkText(text: string, maxChars: number): string[] {
  if (text.length <= maxChars) return [text]
  const chunks: string[] = []
  let buf = ''
  for (const para of text.split(/\n+/)) {
    if (buf && buf.length + para.length + 1 > maxChars) {
      chunks.push(buf)
      buf = ''
    }
    if (para.length > maxChars) {
      // Hard-split an oversized paragraph on spaces.
      let line = ''
      for (const word of para.split(/\s+/)) {
        if (line && line.length + word.length + 1 > maxChars) {
          chunks.push(line)
          line = ''
        }
        line = line ? `${line} ${word}` : word
      }
      if (line) buf = line
    } else {
      buf = buf ? `${buf}\n${para}` : para
    }
  }
  if (buf) chunks.push(buf)
  return chunks
}

/** One transliteration call: Groq chat primary, Gemini fallback. */
async function transliterateChunk(chunk: string, geminiModel: string): Promise<string> {
  if (GROQ_API_KEY) {
    try {
      // Fixed generous budget so a chunk's Roman output is never cut off.
      return await groqChat(TRANSLIT_SYSTEM, chunk, TRANSLIT_MAX_TOKENS)
    } catch (e) {
      console.error('Groq transliteration failed; trying Gemini:', String(e))
      if (!GEMINI_API_KEY) throw e
    }
  }
  if (GEMINI_API_KEY) {
    return await geminiGenerate(geminiModel, [{ text: `${TRANSLIT_SYSTEM}\n\nText:\n${chunk}` }])
  }
  throw new ProviderError(503, 'No transliteration provider is configured.', 'none')
}

type LatinResult = { text: string; ran: boolean; discarded: boolean; method: string }

/** Returns a Latin-script transcript. No-op (no AI) when text is already Latin. */
async function toLatin(text: string, geminiModel: string): Promise<LatinResult> {
  const hasArabic = ARABIC_RE.test(text)
  const hasDevanagari = DEVANAGARI_RE.test(text)
  if (!hasArabic && !hasDevanagari) {
    return { text, ran: false, discarded: false, method: 'none' }
  }

  // Hindi only (no Arabic) → deterministic, lossless, ZERO AI tokens.
  if (hasDevanagari && !hasArabic) {
    return {
      text: devanagariToLatin(text),
      ran: true,
      discarded: false,
      method: 'deterministic',
    }
  }

  // Urdu/Arabic (or mixed) → strict LLM pass, chunked, per-chunk retry.
  const chunks = chunkText(text, TRANSLIT_CHUNK_CHARS)
  const out: string[] = []
  for (const c of chunks) {
    const inWords = countWords(c)
    let r = await transliterateChunk(c, geminiModel)
    if (countWords(r) < inWords * TRANSLIT_MIN_WORD_RATIO) {
      r = await transliterateChunk(c, geminiModel) // one retry
    }
    if (countWords(r) < inWords * TRANSLIT_MIN_WORD_RATIO) {
      // A chunk is still short after retry → keep the COMPLETE native script.
      console.warn(
        `[transcribe] chunk short after retry (in=${inWords} out=${countWords(r)}); keeping native-script transcript`,
      )
      return { text, ran: true, discarded: true, method: 'llm' }
    }
    out.push(r)
  }
  const joined = out.join('\n').trim()

  // Final whole-transcript guard (belt-and-suspenders).
  const inWords = countWords(text)
  const outWords = countWords(joined)
  if (!joined || outWords < inWords * TRANSLIT_MIN_WORD_RATIO) {
    console.warn(
      `[transcribe] transliteration discarded (inWords=${inWords} outWords=${outWords}); keeping complete native-script transcript`,
    )
    return { text, ran: true, discarded: true, method: 'llm' }
  }
  return { text: joined, ran: true, discarded: false, method: 'llm' }
}

// ── Orchestrator: Groq primary → Gemini fallback ──────────────────────────────
// The SAVED TRANSCRIPT is the COMPLETE provider output, then converted to Latin
// script (Roman Urdu / romanized Hindi) faithfully — same words, every word —
// with a word-count guard that keeps the complete native-script text if the
// transliteration would shorten it. English transcripts are returned untouched.
async function transcribe(bytes: Uint8Array, mime: string, geminiModel: string): Promise<string> {
  let primaryError: unknown = null
  let raw = ''
  let provider = ''

  if (GROQ_API_KEY && bytes.byteLength <= GROQ_AUDIO_LIMIT) {
    try {
      raw = await groqTranscribe(bytes, mime)
      provider = 'groq'
    } catch (e) {
      primaryError = e
      console.error('Groq transcription failed; falling back to Gemini:', String(e))
      if (!GEMINI_API_KEY) throw e
    }
  }

  if (!provider) {
    if (GEMINI_API_KEY) {
      raw =
        bytes.byteLength <= GEMINI_INLINE_LIMIT
          ? await geminiInline(geminiModel, bytes, mime)
          : await geminiFilesApi(geminiModel, bytes, mime)
      provider = 'gemini'
    } else {
      if (primaryError) throw primaryError
      throw new ProviderError(503, 'No transcription provider is configured.', 'none')
    }
  }

  const { text, ran, discarded, method } = await toLatin(raw, geminiModel)
  console.log(
    `[transcribe] provider=${provider} rawWords=${countWords(raw)} translit=${ran} method=${method} discarded=${discarded} finalWords=${countWords(text)}`,
  )
  return text
}

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders })
  if (req.method !== 'POST') return json({ error: 'Method not allowed.' }, 405)

  // Verify the caller's Supabase JWT.
  const authHeader = req.headers.get('Authorization') ?? ''
  const supabase = createClient(
    Deno.env.get('SUPABASE_URL') ?? '',
    Deno.env.get('SUPABASE_ANON_KEY') ?? '',
    { global: { headers: { Authorization: authHeader } } },
  )
  const { data: { user }, error: authError } = await supabase.auth.getUser()
  if (authError || !user) {
    return json({ error: 'Unauthorized. Please sign in and try again.' }, 401)
  }

  if (!GROQ_API_KEY && !GEMINI_API_KEY) {
    return json({ error: 'Server is not configured: no AI provider key set.' }, 500)
  }

  // Read the audio bytes + optional Gemini-fallback model.
  let bytes: Uint8Array
  let mimeType = 'audio/webm'
  let model = GEMINI_MODEL
  const contentType = req.headers.get('content-type') ?? ''
  try {
    if (contentType.includes('multipart/form-data')) {
      const form = await req.formData()
      const file = form.get('audio')
      if (!(file instanceof File)) return json({ error: 'No audio file was provided.' }, 400)
      bytes = new Uint8Array(await file.arrayBuffer())
      if (file.type) mimeType = file.type
      model = resolveModel(form.get('model') as string | null)
    } else {
      bytes = new Uint8Array(await req.arrayBuffer())
      if (contentType) mimeType = contentType
    }
  } catch {
    return json({ error: 'Could not read the uploaded audio.' }, 400)
  }

  if (bytes.byteLength === 0) return json({ error: 'The audio was empty.' }, 400)

  try {
    const transcript = await transcribe(bytes, mimeType, model)
    return json({ transcript })
  } catch (e) {
    console.error('Transcription error:', e)
    if (e instanceof ProviderError && e.status === 429) {
      return json(
        {
          error:
            'The AI service is rate-limited or out of quota right now. Please wait a minute and try again.',
        },
        429,
      )
    }
    if (e instanceof ProviderError && (e.status === 401 || e.status === 403)) {
      return json({ error: 'The AI service rejected the request (check the API keys).' }, 502)
    }
    return json({ error: 'Transcription failed. Please try again.', detail: String(e) }, 502)
  }
})
