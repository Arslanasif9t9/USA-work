// EIA Recap — `set-ai-key` Edge Function (Path A / dual-provider)
//
// Lets the signed-in admin set the AI provider keys WITHOUT exposing them to
// the frontend or storing them in the database. Pasted keys are written to the
// project's GROQ_API_KEY / GEMINI_API_KEY secrets via the Supabase Management
// API, so the transcribe/summarize functions pick them up.
//
//   GET  -> { groq: boolean, gemini: boolean }   (which keys are set; never the values)
//   POST { provider: "groq" | "gemini", key }    (set/replace that key; admin only)
//
// Requires the function secret MGMT_ACCESS_TOKEN (a Supabase Personal Access
// Token). Keys are never returned to the client; this endpoint is write-only.

import { createClient } from 'jsr:@supabase/supabase-js@2'

const ADMIN_EMAIL = 'admin@eia.local'
const MGMT_TOKEN = Deno.env.get('MGMT_ACCESS_TOKEN') ?? ''
const SUPABASE_URL = Deno.env.get('SUPABASE_URL') ?? ''

const SECRET_NAMES: Record<string, string> = {
  groq: 'GROQ_API_KEY',
  gemini: 'GEMINI_API_KEY',
}

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers':
    'authorization, x-client-info, apikey, content-type',
  'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
}

function json(body: unknown, status = 200): Response {
  return new Response(JSON.stringify(body), {
    status,
    headers: { ...corsHeaders, 'Content-Type': 'application/json' },
  })
}

const projectRef = () => new URL(SUPABASE_URL).hostname.split('.')[0]
const mgmtBase = () => `https://api.supabase.com/v1/projects/${projectRef()}`

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders })

  // Verify the caller's Supabase JWT, and require the admin account.
  const authHeader = req.headers.get('Authorization') ?? ''
  const supabase = createClient(
    SUPABASE_URL,
    Deno.env.get('SUPABASE_ANON_KEY') ?? '',
    { global: { headers: { Authorization: authHeader } } },
  )
  const { data: { user }, error: authError } = await supabase.auth.getUser()
  if (authError || !user) {
    return json({ error: 'Unauthorized. Please sign in and try again.' }, 401)
  }
  if (user.email !== ADMIN_EMAIL) {
    return json({ error: 'Only the admin can change this setting.' }, 403)
  }

  if (!MGMT_TOKEN) {
    return json({ error: 'Server is not configured: MGMT_ACCESS_TOKEN is missing.' }, 500)
  }

  // GET → report which keys are configured (never the values).
  if (req.method === 'GET') {
    try {
      const res = await fetch(`${mgmtBase()}/secrets`, {
        headers: { Authorization: `Bearer ${MGMT_TOKEN}` },
      })
      if (!res.ok) throw new Error(`Management API ${res.status}`)
      const secrets = (await res.json()) as { name: string }[]
      const names = new Set(secrets.map((s) => s.name))
      return json({
        groq: names.has('GROQ_API_KEY'),
        gemini: names.has('GEMINI_API_KEY'),
      })
    } catch (e) {
      return json({ error: 'Could not read key status.', detail: String(e) }, 502)
    }
  }

  if (req.method !== 'POST') return json({ error: 'Method not allowed.' }, 405)

  // POST → set/replace the chosen provider's key.
  let provider = ''
  let key = ''
  try {
    const body = await req.json()
    provider = String(body?.provider ?? '')
    key = String(body?.key ?? '').trim()
  } catch {
    return json({ error: 'Invalid request body.' }, 400)
  }
  const secretName = SECRET_NAMES[provider]
  if (!secretName) return json({ error: 'Unknown provider.' }, 400)
  if (!key) return json({ error: 'Please paste an API key.' }, 400)

  try {
    const res = await fetch(`${mgmtBase()}/secrets`, {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${MGMT_TOKEN}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify([{ name: secretName, value: key }]),
    })
    if (!res.ok) throw new Error(`Management API ${res.status}: ${await res.text()}`)
    return json({ ok: true })
  } catch (e) {
    return json({ error: 'Could not save the key. Please try again.', detail: String(e) }, 502)
  }
})
