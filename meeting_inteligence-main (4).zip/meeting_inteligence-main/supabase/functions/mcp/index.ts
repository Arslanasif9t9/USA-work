// EIA Recap — `mcp` Edge Function (read-only MCP server / custom connector)
//
// A JSON-RPC 2.0 MCP server that lets Claude read meeting transcripts and
// summaries from this project as a custom connector. 100% additive and READ
// ONLY — it never writes, and it does not touch any other function or table.
//
// AUTH: deploy this function with verify_jwt = false (e.g.
//   `npx supabase functions deploy mcp --no-verify-jwt --project-ref <ref>`)
// because Claude authenticates with our own bearer token (MCP_BEARER), not a
// Supabase JWT. The bearer is checked inside the handler, before any DB work.
//
// BOOT-SAFE: nothing runs at module load except this import and plain constants.
// Every Deno.env.get(...) and the service-role client are created INSIDE the
// request handler; the whole handler is wrapped in try/catch and always returns
// JSON, so a missing secret returns a clean error and the function stays booted.

import { createClient } from 'jsr:@supabase/supabase-js@2'

// ── Module-scope constants only (cannot throw) ────────────────────────────────
const MCP_PROTOCOL_VERSION = '2024-11-05'
const SERVER_INFO = { name: 'callrecap-mcp', version: '1.0.0' }

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers':
    'authorization, x-client-info, apikey, content-type',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
}

const TOOLS = [
  {
    name: 'list_meetings',
    description:
      'List saved meetings (most recent first). Lightweight: returns id, title, created_at, duration_sec, word_count — no transcript.',
    inputSchema: {
      type: 'object',
      properties: {
        limit: {
          type: 'number',
          description: 'Max rows (default 20, max 50).',
        },
      },
    },
  },
  {
    name: 'get_meeting',
    description:
      'Get one meeting by id, including its full summary and transcript.',
    inputSchema: {
      type: 'object',
      properties: {
        id: { type: 'string', description: 'Meeting UUID.' },
      },
      required: ['id'],
    },
  },
  {
    name: 'search_meetings',
    description:
      'Search meetings whose transcript, summary, or title matches the query (case-insensitive). Lightweight: returns id, title, created_at, and a short summary snippet — no transcript.',
    inputSchema: {
      type: 'object',
      properties: {
        query: { type: 'string', description: 'Text to search for.' },
        limit: {
          type: 'number',
          description: 'Max rows (default 20, max 50).',
        },
      },
      required: ['query'],
    },
  },
  {
    name: 'get_latest_meeting',
    description:
      'Get the single most recent meeting, including its full summary and transcript.',
    inputSchema: { type: 'object', properties: {} },
  },
]

// ── Small JSON helpers ────────────────────────────────────────────────────────
function respond(body: unknown, status = 200): Response {
  return new Response(JSON.stringify(body), {
    status,
    headers: { ...corsHeaders, 'Content-Type': 'application/json' },
  })
}
const rpcResult = (id: unknown, result: unknown) => ({ jsonrpc: '2.0', id: id ?? null, result })
const rpcError = (id: unknown, code: number, message: string) => ({
  jsonrpc: '2.0',
  id: id ?? null,
  error: { code, message },
})
// A tools/call success wraps the data as a single MCP text content item.
const toolContent = (data: unknown) => ({
  content: [{ type: 'text', text: JSON.stringify(data, null, 2) }],
})

const clampLimit = (n: unknown) => {
  const v = typeof n === 'number' && Number.isFinite(n) ? Math.floor(n) : 20
  return Math.min(50, Math.max(1, v))
}

Deno.serve(async (req) => {
  // CORS preflight.
  if (req.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders })

  try {
    if (req.method !== 'POST') {
      return respond(rpcError(null, -32600, 'Only POST is supported.'), 405)
    }

    // Parse the JSON-RPC request (needed to echo the id).
    let rpc: { id?: unknown; method?: string; params?: any }
    try {
      rpc = await req.json()
    } catch {
      return respond(rpcError(null, -32700, 'Parse error: invalid JSON.'), 400)
    }
    const id = rpc?.id ?? null
    const method = rpc?.method

    // ── Bearer auth (before any DB work) ──────────────────────────────────────
    const expected = Deno.env.get('MCP_BEARER') ?? ''
    if (!expected) {
      return respond(rpcError(id, -32000, 'Server is not configured: MCP_BEARER is missing.'), 500)
    }
    // Accept the token from the ?token= query param first, then fall back to the
    // Authorization: Bearer <token> header.
    const queryToken = new URL(req.url).searchParams.get('token') ?? ''
    const authHeader = req.headers.get('Authorization') ?? ''
    const headerToken = authHeader.startsWith('Bearer ') ? authHeader.slice(7).trim() : ''
    const token = queryToken || headerToken
    if (!token || token !== expected) {
      return respond(rpcError(id, -32001, 'Unauthorized.'), 401)
    }

    // ── MCP method dispatch ───────────────────────────────────────────────────
    if (method === 'initialize') {
      return respond(
        rpcResult(id, {
          protocolVersion: MCP_PROTOCOL_VERSION,
          capabilities: { tools: {} },
          serverInfo: SERVER_INFO,
        }),
      )
    }

    if (method === 'notifications/initialized') {
      return respond(rpcResult(id, {}))
    }

    if (method === 'tools/list') {
      return respond(rpcResult(id, { tools: TOOLS }))
    }

    if (method === 'tools/call') {
      const name = rpc?.params?.name as string
      const args = (rpc?.params?.arguments ?? {}) as Record<string, unknown>

      // Service-role client built INSIDE the handler, only when needed, so reads
      // are not blocked by RLS. SELECT only — this connector never writes.
      const url = Deno.env.get('SUPABASE_URL') ?? ''
      const serviceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
      if (!url || !serviceKey) {
        return respond(rpcError(id, -32000, 'Server is not configured: Supabase env missing.'), 500)
      }
      const supabase = createClient(url, serviceKey, {
        auth: { persistSession: false, autoRefreshToken: false },
      })

      try {
        if (name === 'list_meetings') {
          const limit = clampLimit(args.limit)
          const { data, error } = await supabase
            .from('meetings')
            .select('id, title, created_at, duration_sec, word_count')
            .order('created_at', { ascending: false })
            .limit(limit)
          if (error) throw new Error(error.message)
          return respond(rpcResult(id, toolContent(data ?? [])))
        }

        if (name === 'get_meeting') {
          const mid = String(args.id ?? '').trim()
          if (!mid) return respond(rpcResult(id, toolContent({ error: 'id is required.' })))
          const { data, error } = await supabase
            .from('meetings')
            .select('id, title, summary, transcript, duration_sec, word_count, created_at')
            .eq('id', mid)
            .maybeSingle()
          if (error) throw new Error(error.message)
          if (!data) return respond(rpcResult(id, toolContent({ error: `No meeting found with id ${mid}.` })))
          return respond(rpcResult(id, toolContent(data)))
        }

        if (name === 'search_meetings') {
          const query = String(args.query ?? '').trim()
          if (!query) return respond(rpcResult(id, toolContent({ error: 'query is required.' })))
          const limit = clampLimit(args.limit)
          // Sanitize: strip characters that would break the PostgREST or-filter.
          const safe = query.replace(/[,()%*\\]/g, ' ').trim()
          const pattern = `%${safe}%`
          const { data, error } = await supabase
            .from('meetings')
            .select('id, title, created_at, summary')
            .or(`transcript.ilike.${pattern},summary.ilike.${pattern},title.ilike.${pattern}`)
            .order('created_at', { ascending: false })
            .limit(limit)
          if (error) throw new Error(error.message)
          const rows = (data ?? []).map((m: any) => ({
            id: m.id,
            title: m.title,
            created_at: m.created_at,
            snippet: String(m.summary ?? '').slice(0, 200),
          }))
          return respond(rpcResult(id, toolContent(rows)))
        }

        if (name === 'get_latest_meeting') {
          const { data, error } = await supabase
            .from('meetings')
            .select('id, title, summary, transcript, duration_sec, word_count, created_at')
            .order('created_at', { ascending: false })
            .limit(1)
            .maybeSingle()
          if (error) throw new Error(error.message)
          if (!data) return respond(rpcResult(id, toolContent({ error: 'No meetings found.' })))
          return respond(rpcResult(id, toolContent(data)))
        }

        return respond(rpcError(id, -32602, `Unknown tool: ${name}`))
      } catch (e) {
        return respond(rpcError(id, -32603, `Tool error: ${String(e)}`))
      }
    }

    // Unknown method.
    return respond(rpcError(id, -32601, `Method not found: ${method}`))
  } catch (e) {
    // Last-resort guard: always return JSON, never crash the worker.
    return respond(rpcError(null, -32603, `Internal error: ${String(e)}`), 500)
  }
})
