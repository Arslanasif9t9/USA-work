import { BrowserRouter, Routes, Route, Link, Outlet } from 'react-router-dom'
import './App.css'
import Home from './pages/Home'
import PlatformPage from './components/PlatformPage'
import YoutubeApi from './pages/YoutubeApi'
import Upload from './pages/Upload'

function Logo() {
  return (
    <svg className="brand-logo" width="40" height="40" viewBox="0 0 40 40" role="img" aria-label="EIA logo">
      <defs>
        <linearGradient id="eiaGrad" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0" stopColor="#6366f1" />
          <stop offset="1" stopColor="#a855f7" />
        </linearGradient>
      </defs>
      <rect width="40" height="40" rx="11" fill="url(#eiaGrad)" />
      <rect x="10" y="22" width="4.5" height="8" rx="2.25" fill="#fff" opacity="0.92" />
      <rect x="17.75" y="16.5" width="4.5" height="13.5" rx="2.25" fill="#fff" opacity="0.92" />
      <rect x="25.5" y="10" width="4.5" height="20" rx="2.25" fill="#fff" opacity="0.92" />
    </svg>
  )
}

function Layout() {
  return (
    <div className="page">
      <header className="brandbar">
        <div className="brand">
          <Link to="/" className="brand-link" aria-label="Go to home">
            <Logo />
            <span className="brand-name">
              EIA <span className="brand-sep">—</span>{' '}
              <span className="brand-full">Expert Intuitive Advisor Inc.</span>
            </span>
          </Link>
        </div>
      </header>
      <Outlet />
    </div>
  )
}

export default function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route element={<Layout />}>
          <Route path="/" element={<Home />} />
          <Route path="/youtube" element={<PlatformPage platform="youtube" />} />
          <Route path="/instagram" element={<PlatformPage platform="instagram" />} />
          <Route path="/tiktok" element={<PlatformPage platform="tiktok" />} />
          <Route path="/youtubeapi" element={<YoutubeApi />} />
          <Route path="/upload" element={<Upload />} />
          <Route path="*" element={<Home />} />
        </Route>
      </Routes>
    </BrowserRouter>
  )
}
