import { useState } from 'react'
import { Link } from 'react-router-dom'
import ReactMarkdown from 'react-markdown'
import {
  PLATFORM_LABELS,
  PLATFORM_THEME,
  detectPlatformClient,
  friendlyMessage,
} from '../lib/platform'
import { PlatformIcon } from './PlatformIcon'

const SUPABASE_URL = 'https://iooqjbkhualpraomgddn.supabase.co'
const SUPABASE_KEY =
  import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY ||
  'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Imlvb3FqYmtodWFscHJhb21nZGRuIiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODE1MTg2OTYsImV4cCI6MjA5NzA5NDY5Nn0.nWE2NQZ6lETBUkP4_73Z78_wyUhrxxjoAgv41v0pNcA'

// Reusable per-platform page. Identical backend behavior to the previous
// single-page version — only validation is scoped to the page's platform.
export default function PlatformPage({ platform }) {
  const theme = PLATFORM_THEME[platform]
  const label = PLATFORM_LABELS[platform]

  const [url, setUrl] = useState('')
  const [loading, setLoading] = useState(false)
  const [notes, setNotes] = useState('')
  const [transcript, setTranscript] = useState('')
  const [error, setError] = useState('')
  const [inputError, setInputError] = useState('')
  const [view, setView] = useState('notes')
  const [copied, setCopied] = useState(false)
  const [notesUnavailable, setNotesUnavailable] = useState(false)

  async function handleSubmit(event) {
    event.preventDefault()
    const trimmed = url.trim()
    const detected = detectPlatformClient(trimmed)

    if (!detected) {
      setInputError(`Please paste a valid ${label} link.`)
      return
    }
    if (detected !== platform) {
      setInputError(
        `This page only accepts ${label} links. Please paste a valid ${label} URL.`,
      )
      return
    }

    setInputError('')
    setLoading(true)
    setNotes('')
    setTranscript('')
    setError('')
    setView('notes')
    setCopied(false)
    setNotesUnavailable(false)

    try {
      const endpoint = new URL('/functions/v1/transcript', SUPABASE_URL).toString()
      const res = await fetch(endpoint, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          apikey: SUPABASE_KEY,
          Authorization: `Bearer ${SUPABASE_KEY}`,
        },
        body: JSON.stringify({ url: trimmed }),
      })

      const rawText = await res.text()
      let data = null
      try {
        data = rawText ? JSON.parse(rawText) : null
      } catch (parseErr) {
        console.error('[transcript] failed to parse JSON', { status: res.status, parseErr })
      }
      const payload =
        data && typeof data === 'object' && data.data && !data.transcript && !data.notes && !data.error
          ? data.data
          : data

      if (!res.ok || (payload && payload.error)) {
        setError(friendlyMessage(res.status, payload || {}))
      } else if (payload && (payload.notes || payload.transcript)) {
        setNotes(payload.notes || '')
        setTranscript(payload.transcript || '')
        if (payload.notesUnavailable || (!payload.notes && payload.transcript)) {
          setNotesUnavailable(true)
          setView('caption')
        }
      } else {
        setError(`Server returned an unexpected response (status ${res.status}). Please try again.`)
      }
    } catch (err) {
      setError(`Couldn't reach the server (${err?.message || 'network error'}). Please try again.`)
    } finally {
      setLoading(false)
    }
  }

  const currentContent = view === 'notes' ? notes || transcript : transcript

  async function handleCopy() {
    try {
      await navigator.clipboard.writeText(currentContent)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    } catch {
      /* clipboard unavailable */
    }
  }

  function handleDownload() {
    const blob = new Blob([currentContent], { type: 'text/plain;charset=utf-8' })
    const href = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = href
    a.download = view === 'notes' ? `eia-${platform}-notes.txt` : `eia-${platform}-caption.txt`
    document.body.appendChild(a)
    a.click()
    a.remove()
    URL.revokeObjectURL(href)
  }

  const hasResult = (notes || transcript) && !error

  return (
    <main className="app">
      <Link to="/" className="back-link">← Back to all platforms</Link>

      <section className="hero">
        <div className="platform-hero-icon" style={{ background: theme.gradient }}>
          <PlatformIcon platform={platform} size={36} />
        </div>
        <h1 style={{ background: theme.gradient, WebkitBackgroundClip: 'text', backgroundClip: 'text', color: 'transparent' }}>
          {label}
        </h1>
        <p className="subtitle">{theme.description}</p>
      </section>

      <form className="input-card" onSubmit={handleSubmit}>
        <input
          type="text"
          className="url-input"
          value={url}
          onChange={(e) => {
            setUrl(e.target.value)
            if (inputError) setInputError('')
          }}
          placeholder={theme.placeholder}
          aria-label={`${label} link`}
          disabled={loading}
        />
        <button
          type="submit"
          className="submit-btn"
          disabled={loading}
          style={{ background: theme.gradient }}
        >
          {loading ? 'Generating…' : 'Get Notes'}
        </button>
      </form>

      <p className="input-hint">Only {label} links are accepted on this page ({theme.hostHint}).</p>

      {inputError && <p className="field-error">{inputError}</p>}

      {loading && (
        <div className="results-card">
          <div className="loading">
            <span className="spinner" aria-hidden="true" />
            <span>Fetching {label} caption… this can take a little longer for long videos.</span>
          </div>
        </div>
      )}

      {!loading && error && (
        <div className="error-box" role="alert">
          <svg width="20" height="20" viewBox="0 0 24 24" aria-hidden="true">
            <circle cx="12" cy="12" r="10" fill="none" stroke="currentColor" strokeWidth="2" />
            <path d="M12 7v6M12 16.5v.5" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
          </svg>
          <span>{error}</span>
        </div>
      )}

      {!loading && hasResult && (
        <div className="results-card">
          <div className="platform-badge" style={{ color: theme.accent, background: `${theme.accent}1a` }}>
            {label}
          </div>
          <div className="results-head">
            <div className="toggle" role="tablist" aria-label="View">
              <button
                role="tab"
                aria-selected={view === 'notes'}
                className={view === 'notes' ? 'toggle-btn active' : 'toggle-btn'}
                onClick={() => setView('notes')}
              >
                Notes
              </button>
              <button
                role="tab"
                aria-selected={view === 'caption'}
                className={view === 'caption' ? 'toggle-btn active' : 'toggle-btn'}
                onClick={() => setView('caption')}
              >
                Original Caption
              </button>
            </div>
            <div className="actions">
              <button type="button" className="action-btn" onClick={handleCopy}>
                {copied ? 'Copied!' : 'Copy'}
              </button>
              <button type="button" className="action-btn" onClick={handleDownload}>
                Download .txt
              </button>
            </div>
          </div>

          {view === 'notes' ? (
            notesUnavailable || !notes ? (
              <div className="notes-notice" role="status">
                AI notes are temporarily unavailable (API limit reached). The original
                caption is shown below — you can still read, copy, and download it.
              </div>
            ) : (
              <article className="notes">
                <ReactMarkdown>{notes}</ReactMarkdown>
              </article>
            )
          ) : (
            <pre className="caption">{transcript}</pre>
          )}
        </div>
      )}

      {!loading && !hasResult && !error && (
        <div className="results-card empty">
          <p className="placeholder">Your notes will appear here.</p>
        </div>
      )}
    </main>
  )
}
