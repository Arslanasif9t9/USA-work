// Inline SVG icons for each supported platform. Sized via `size` prop, color
// inherits from `currentColor` so theming works via CSS.
export function PlatformIcon({ platform, size = 28 }) {
  const s = { width: size, height: size, display: 'block' }
  if (platform === 'youtube') {
    return (
      <svg style={s} viewBox="0 0 24 24" aria-hidden="true">
        <path
          fill="currentColor"
          d="M23.5 6.2a3 3 0 0 0-2.1-2.1C19.5 3.5 12 3.5 12 3.5s-7.5 0-9.4.6A3 3 0 0 0 .5 6.2C0 8.1 0 12 0 12s0 3.9.5 5.8a3 3 0 0 0 2.1 2.1c1.9.6 9.4.6 9.4.6s7.5 0 9.4-.6a3 3 0 0 0 2.1-2.1c.5-1.9.5-5.8.5-5.8s0-3.9-.5-5.8zM9.6 15.6V8.4l6.3 3.6-6.3 3.6z"
        />
      </svg>
    )
  }
  if (platform === 'instagram') {
    return (
      <svg style={s} viewBox="0 0 24 24" fill="none" aria-hidden="true">
        <rect x="3" y="3" width="18" height="18" rx="5" stroke="currentColor" strokeWidth="2" />
        <circle cx="12" cy="12" r="4" stroke="currentColor" strokeWidth="2" />
        <circle cx="17.5" cy="6.5" r="1.2" fill="currentColor" />
      </svg>
    )
  }
  if (platform === 'tiktok') {
    return (
      <svg style={s} viewBox="0 0 24 24" aria-hidden="true">
        <path
          fill="currentColor"
          d="M19.3 7.6a6.4 6.4 0 0 1-3.8-1.2v8.4a5.6 5.6 0 1 1-5.6-5.6c.3 0 .6 0 .9.1v2.9a2.8 2.8 0 1 0 2 2.7V2h2.8a4 4 0 0 0 .7 2.2A4 4 0 0 0 19.3 6v1.6z"
        />
      </svg>
    )
  }
  return null
}
