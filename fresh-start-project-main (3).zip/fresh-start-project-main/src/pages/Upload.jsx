import { useState, useRef } from 'react'
import { Link } from 'react-router-dom'

const SUPABASE_URL = 'https://iooqjbkhualpraomgddn.supabase.co'
const SUPABASE_KEY =
  import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY ||
  'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Imlvb3FqYmtodWFscHJhb21nZGRuIiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODE1MTg2OTYsImV4cCI6MjA5NzA5NDY5Nn0.nWE2NQZ6lETBUkP4_73Z78_wyUhrxxjoAgv41v0pNcA'

const ACCENT = '#a78bfa'
const GRADIENT = 'linear-gradient(135deg, #a78bfa, #7c3aed)'

export default function Upload() {
  const [file, setFile] = useState(null)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')
  const [transcript, setTranscript] = useState('')
  const [dragOver, setDragOver] = useState(false)
  const inputRef = useRef(null)

  function pickFile(f) {
    if (!f) return
    setFile(f)
    setError('')
    setTranscript('')
  }

  function onDrop(e) {
    e.preventDefault()
    setDragOver(false)
    const f = e.dataTransfer.files?.[0]
    if (f) pickFile(f)
  }

  async function handleTranscribe() {
    if (!file) {
      setError('Please choose a video file first.')
      return
    }
    setLoading(true)
    setError('')
    setTranscript('')
    try {
      const fd = new FormData()
      fd.append('file', file)
      const endpoint = new URL('/functions/v1/transcribe-upload', SUPABASE_URL).toString()
      const res = await fetch(endpoint, {
        method: 'POST',
        headers: {
          apikey: SUPABASE_KEY,
          Authorization: `Bearer ${SUPABASE_KEY}`,
        },
        body: fd,
      })
      const data = await res.json().catch(() => null)
      if (!res.ok || !data || !data.ok || !data.transcript) {
        setError("Couldn't transcribe this video — please try again.")
      } else {
        setTranscript(data.transcript)
      }
    } catch {
      setError("Couldn't transcribe this video — please try again.")
    } finally {
      setLoading(false)
    }
  }

  function handleDone() {
    setFile(null)
    setTranscript('')
    setError('')
    setLoading(false)
    if (inputRef.current) inputRef.current.value = ''
  }

  async function handleCopy() {
    try {
      await navigator.clipboard.writeText(transcript)
    } catch {
      /* ignore */
    }
  }

  return (
    <main className="app">
      <Link to="/" className="back-link">← Back to all platforms</Link>

      <section className="hero">
        <div className="platform-hero-icon" style={{ background: GRADIENT }}>
          <svg width="32" height="32" viewBox="0 0 24 24" fill="none" aria-hidden="true">
            <path d="M12 16V4M12 4l-5 5M12 4l5 5" stroke="#fff" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
            <path d="M4 17v2a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-2" stroke="#fff" strokeWidth="2" strokeLinecap="round"/>
          </svg>
        </div>
        <h1 style={{ background: GRADIENT, WebkitBackgroundClip: 'text', backgroundClip: 'text', color: 'transparent' }}>
          Upload Video
        </h1>
        <p className="subtitle">Transcribe a video that links won't open. Nothing is saved.</p>
      </section>

      {!transcript && (
        <div className="input-card" style={{ flexDirection: 'column', gap: '1rem' }}>
          <div
            onDragOver={(e) => { e.preventDefault(); setDragOver(true) }}
            onDragLeave={() => setDragOver(false)}
            onDrop={onDrop}
            onClick={() => inputRef.current?.click()}
            style={{
              border: `2px dashed ${dragOver ? ACCENT : 'rgba(255,255,255,0.2)'}`,
              borderRadius: '12px',
              padding: '2rem',
              textAlign: 'center',
              cursor: 'pointer',
              background: dragOver ? 'rgba(167,139,250,0.08)' : 'transparent',
              transition: 'all 0.15s ease',
              width: '100%',
            }}
          >
            <p style={{ margin: 0, opacity: 0.85 }}>
              {file ? <strong>{file.name}</strong> : 'Drag & drop a video here, or click to choose'}
            </p>
            <input
              ref={inputRef}
              type="file"
              accept="video/*"
              style={{ display: 'none' }}
              onChange={(e) => pickFile(e.target.files?.[0])}
            />
          </div>
          <button
            type="button"
            className="submit-btn"
            disabled={loading || !file}
            style={{ background: GRADIENT, width: '100%' }}
            onClick={handleTranscribe}
          >
            {loading ? 'Transcribing…' : 'Transcribe'}
          </button>
        </div>
      )}

      {error && <p className="field-error" role="alert">{error}</p>}

      {loading && (
        <div className="results-card">
          <div className="loading">
            <span className="spinner" aria-hidden="true" />
            <span>Transcribing… this can take a moment.</span>
          </div>
        </div>
      )}

      {transcript && !loading && (
        <div className="results-card">
          <textarea
            readOnly
            value={transcript}
            style={{
              width: '100%',
              minHeight: '320px',
              maxHeight: '60vh',
              padding: '1rem',
              borderRadius: '10px',
              border: '1px solid rgba(255,255,255,0.12)',
              background: 'rgba(0,0,0,0.25)',
              color: 'inherit',
              fontSize: '0.95rem',
              lineHeight: 1.5,
              resize: 'vertical',
              fontFamily: 'inherit',
            }}
          />
          <div style={{ display: 'flex', gap: '0.75rem', marginTop: '1rem' }}>
            <button type="button" className="submit-btn" onClick={handleCopy} style={{ background: GRADIENT }}>
              Copy
            </button>
            <button
              type="button"
              className="submit-btn"
              onClick={handleDone}
              style={{ background: 'rgba(255,255,255,0.1)' }}
            >
              Done
            </button>
          </div>
        </div>
      )}
    </main>
  )
}
