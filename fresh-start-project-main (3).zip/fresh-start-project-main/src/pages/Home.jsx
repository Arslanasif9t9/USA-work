import { Link } from 'react-router-dom'
import { PLATFORM_THEME } from '../lib/platform'
import { PlatformIcon } from '../components/PlatformIcon'

const PLATFORMS = ['youtube', 'instagram', 'tiktok']

const YT_API_CARD = {
  to: '/youtubeapi',
  label: 'YouTube API',
  description: 'Search YouTube videos by keyword.',
  accent: '#22d3ee',
  gradient: 'linear-gradient(135deg, #22d3ee, #3b82f6)',
}

const UPLOAD_CARD = {
  to: '/upload',
  label: 'Upload Video',
  description: 'Drop a video file, get the transcript. Nothing saved.',
  accent: '#a78bfa',
  gradient: 'linear-gradient(135deg, #a78bfa, #7c3aed)',
}

function SearchIcon({ size = 32 }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" aria-hidden="true">
      <circle cx="11" cy="11" r="6.5" stroke="currentColor" strokeWidth="2" />
      <path d="m20 20-3.2-3.2" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
    </svg>
  )
}

function UploadIcon({ size = 28 }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" aria-hidden="true">
      <path d="M12 16V4M12 4l-5 5M12 4l5 5" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
      <path d="M4 17v2a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-2" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
    </svg>
  )
}

export default function Home() {
  return (
    <main className="app home">
      <section className="hero">
        <h1>Transcript</h1>
        <p className="subtitle">Turn any video into readable notes.</p>
      </section>

      <div className="platform-grid">
        {PLATFORMS.map((p) => {
          const theme = PLATFORM_THEME[p]
          return (
            <Link
              key={p}
              to={`/${p}`}
              className="platform-card"
              style={{ '--card-accent': theme.accent }}
            >
              <div className="platform-card-icon" style={{ background: theme.gradient }}>
                <PlatformIcon platform={p} size={32} />
              </div>
              <div className="platform-card-body">
                <h2 className="platform-card-title">{theme.label}</h2>
                <p className="platform-card-desc">{theme.description}</p>
              </div>
              <span className="platform-card-arrow" aria-hidden="true">→</span>
            </Link>
          )
        })}

        <Link
          to={YT_API_CARD.to}
          className="platform-card"
          style={{ '--card-accent': YT_API_CARD.accent }}
        >
          <div className="platform-card-icon" style={{ background: YT_API_CARD.gradient }}>
            <SearchIcon size={28} />
          </div>
          <div className="platform-card-body">
            <h2 className="platform-card-title">{YT_API_CARD.label}</h2>
            <p className="platform-card-desc">{YT_API_CARD.description}</p>
          </div>
          <span className="platform-card-arrow" aria-hidden="true">→</span>
        </Link>

        <Link
          to={UPLOAD_CARD.to}
          className="platform-card"
          style={{ '--card-accent': UPLOAD_CARD.accent }}
        >
          <div className="platform-card-icon" style={{ background: UPLOAD_CARD.gradient }}>
            <UploadIcon size={28} />
          </div>
          <div className="platform-card-body">
            <h2 className="platform-card-title">{UPLOAD_CARD.label}</h2>
            <p className="platform-card-desc">{UPLOAD_CARD.description}</p>
          </div>
          <span className="platform-card-arrow" aria-hidden="true">→</span>
        </Link>
      </div>
    </main>
  )
}
