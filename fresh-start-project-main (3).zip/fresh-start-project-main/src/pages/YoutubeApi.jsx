import { useState } from 'react'
import { Link } from 'react-router-dom'

const SUPABASE_URL = 'https://iooqjbkhualpraomgddn.supabase.co'
const SUPABASE_KEY =
  import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY ||
  'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Imlvb3FqYmtodWFscHJhb21nZGRuIiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODE1MTg2OTYsImV4cCI6MjA5NzA5NDY5Nn0.nWE2NQZ6lETBUkP4_73Z78_wyUhrxxjoAgv41v0pNcA'

const ACCENT = '#22d3ee'
const GRADIENT = 'linear-gradient(135deg, #22d3ee, #3b82f6)'

function formatDate(iso) {
  if (!iso) return ''
  try {
    return new Date(iso).toLocaleDateString(undefined, {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
    })
  } catch {
    return ''
  }
}

export default function YoutubeApi() {
  const [q, setQ] = useState('')
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')
  const [results, setResults] = useState([])
  const [searched, setSearched] = useState(false)

  async function handleSubmit(e) {
    e.preventDefault()
    const query = q.trim()
    if (!query) {
      setError('Please type something to search.')
      setResults([])
      return
    }
    setLoading(true)
    setError('')
    setResults([])
    setSearched(true)
    try {
      const endpoint = new URL('/functions/v1/youtube-search', SUPABASE_URL).toString()
      const res = await fetch(endpoint, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          apikey: SUPABASE_KEY,
          Authorization: `Bearer ${SUPABASE_KEY}`,
        },
        body: JSON.stringify({ q: query }),
      })
      const data = await res.json().catch(() => null)
      if (!res.ok || !data || data.error) {
        setError((data && data.message) || 'Search failed. Please try again.')
      } else {
        setResults(Array.isArray(data.results) ? data.results : [])
      }
    } catch (err) {
      setError(`Couldn't reach the server (${err?.message || 'network error'}).`)
    } finally {
      setLoading(false)
    }
  }

  return (
    <main className="app">
      <Link to="/" className="back-link">← Back to all platforms</Link>

      <section className="hero">
        <div className="platform-hero-icon" style={{ background: GRADIENT }}>
          <svg width="32" height="32" viewBox="0 0 24 24" fill="none" aria-hidden="true">
            <circle cx="11" cy="11" r="6.5" stroke="#fff" strokeWidth="2" />
            <path d="m20 20-3.2-3.2" stroke="#fff" strokeWidth="2" strokeLinecap="round" />
          </svg>
        </div>
        <h1 style={{ background: GRADIENT, WebkitBackgroundClip: 'text', backgroundClip: 'text', color: 'transparent' }}>
          YouTube API
        </h1>
        <p className="subtitle">Search YouTube videos by keyword.</p>
      </section>

      <form className="input-card" onSubmit={handleSubmit}>
        <input
          type="text"
          className="url-input"
          value={q}
          onChange={(e) => { setQ(e.target.value); if (error) setError('') }}
          placeholder="Search YouTube…"
          aria-label="Search YouTube"
          disabled={loading}
        />
        <button type="submit" className="submit-btn" disabled={loading} style={{ background: GRADIENT }}>
          {loading ? 'Searching…' : 'Find'}
        </button>
      </form>

      {error && <p className="field-error" role="alert">{error}</p>}

      {loading && (
        <div className="results-card">
          <div className="loading">
            <span className="spinner" aria-hidden="true" />
            <span>Searching YouTube…</span>
          </div>
        </div>
      )}

      {!loading && results.length > 0 && (
        <div className="yt-grid">
          {results.map((r) => (
            <article key={r.videoId} className="yt-card">
              <a
                href={`https://www.youtube.com/watch?v=${r.videoId}`}
                target="_blank"
                rel="noopener noreferrer"
                className="yt-thumb-link"
              >
                {r.thumbnail && (
                  <img src={r.thumbnail} alt="" loading="lazy" className="yt-thumb" />
                )}
              </a>
              <div className="yt-body">
                <a
                  href={`https://www.youtube.com/watch?v=${r.videoId}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="yt-title"
                  dangerouslySetInnerHTML={{ __html: r.title }}
                />
                <div className="yt-meta">
                  <span className="yt-channel">{r.channelTitle}</span>
                  <span className="yt-dot">·</span>
                  <span className="yt-date">{formatDate(r.publishedAt)}</span>
                </div>
              </div>
            </article>
          ))}
        </div>
      )}

      {!loading && searched && !error && results.length === 0 && (
        <div className="results-card empty">
          <p className="placeholder">No results found. Try a different search.</p>
        </div>
      )}
    </main>
  )
}
