// YouTube Data API v3 keyword search. Key stays server-side.
const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers':
    'authorization, x-client-info, apikey, content-type',
  'Access-Control-Allow-Methods': 'POST, GET, OPTIONS',
}

function json(body: unknown, status = 200) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { ...corsHeaders, 'Content-Type': 'application/json' },
  })
}

const ALLOWED_ORDER = new Set(['relevance', 'date', 'viewCount', 'rating', 'title'])
const ALLOWED_DURATION = new Set(['any', 'short', 'medium', 'long'])

export async function runYoutubeSearch(params: {
  query: string
  limit?: number
  order?: string
  publishedAfter?: string
  videoDuration?: string
  regionCode?: string
}): Promise<
  | { ok: true; results: any[] }
  | { ok: false; status: number; error: string; message: string }
> {
  const q = String(params.query ?? '').trim()
  if (!q) return { ok: false, status: 400, error: 'empty_query', message: 'Please type something to search.' }

  const key = Deno.env.get('YOUTUBE_API_KEY')
  if (!key) return { ok: false, status: 500, error: 'config', message: 'Search is not configured.' }

  let limit = Number.isFinite(params.limit) ? Math.floor(params.limit as number) : 10
  if (limit < 1) limit = 1
  if (limit > 50) limit = 50

  const order = params.order && ALLOWED_ORDER.has(params.order) ? params.order : 'relevance'
  const videoDuration =
    params.videoDuration && ALLOWED_DURATION.has(params.videoDuration) ? params.videoDuration : undefined

  const url = new URL('https://www.googleapis.com/youtube/v3/search')
  url.searchParams.set('part', 'snippet')
  url.searchParams.set('q', q)
  url.searchParams.set('type', 'video')
  url.searchParams.set('maxResults', String(limit))
  url.searchParams.set('order', order)
  if (videoDuration && videoDuration !== 'any') url.searchParams.set('videoDuration', videoDuration)
  if (params.publishedAfter) url.searchParams.set('publishedAfter', params.publishedAfter)
  if (params.regionCode) url.searchParams.set('regionCode', params.regionCode)
  url.searchParams.set('key', key)

  const res = await fetch(url.toString())
  const data = await res.json().catch(() => null)

  if (!res.ok || !data) {
    const reason = data?.error?.errors?.[0]?.reason || ''
    let message = 'YouTube search failed. Please try again.'
    if (reason === 'quotaExceeded' || reason === 'rateLimitExceeded') {
      message = 'YouTube search quota reached. Please try again later.'
    } else if (reason === 'keyInvalid' || reason === 'badRequest') {
      message = 'YouTube search is misconfigured.'
    }
    return { ok: false, status: 502, error: 'search_failed', message }
  }

  const items = Array.isArray(data.items) ? data.items : []
  const results = items
    .filter((it: any) => it?.id?.videoId)
    .map((it: any) => {
      const sn = it.snippet || {}
      const thumbs = sn.thumbnails || {}
      const thumb = thumbs.high?.url || thumbs.medium?.url || thumbs.default?.url || ''
      const videoId = it.id.videoId
      return {
        videoId,
        title: sn.title || '',
        description: sn.description || '',
        channelTitle: sn.channelTitle || '',
        publishedAt: sn.publishedAt || '',
        thumbnail: thumb,
        url: `https://www.youtube.com/watch?v=${videoId}`,
      }
    })

  return { ok: true, results }
}

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders })

  try {
    let params: any = {}
    if (req.method === 'POST') {
      params = await req.json().catch(() => ({}))
    } else {
      const u = new URL(req.url)
      params = {
        query: u.searchParams.get('q') ?? u.searchParams.get('query') ?? '',
        limit: u.searchParams.get('limit') ? Number(u.searchParams.get('limit')) : undefined,
        order: u.searchParams.get('order') ?? undefined,
        publishedAfter: u.searchParams.get('publishedAfter') ?? undefined,
        videoDuration: u.searchParams.get('videoDuration') ?? undefined,
        regionCode: u.searchParams.get('regionCode') ?? undefined,
      }
    }
    // Support both {q} (legacy from frontend) and {query}
    const query = params.query ?? params.q ?? ''
    const result = await runYoutubeSearch({
      query,
      limit: params.limit,
      order: params.order,
      publishedAfter: params.publishedAfter,
      videoDuration: params.videoDuration,
      regionCode: params.regionCode,
    })

    if (!result.ok) return json({ error: result.error, message: result.message }, result.status)
    return json({ results: result.results })
  } catch (err) {
    return json({ error: 'server_error', message: (err as Error)?.message || 'Unexpected error' }, 500)
  }
})
