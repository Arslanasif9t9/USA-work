// deno-lint-ignore-file no-explicit-any
// MCP JSON-RPC 2.0 endpoint for the get_youtube_notes tool.
// Mirrors api/_lib/handlers.js mcp() and reuses the same caption+notes core.

const MCP_CORS_HEADERS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "POST, GET, OPTIONS",
  "Access-Control-Allow-Headers":
    "Content-Type, Authorization, apikey, x-client-info, mcp-session-id, mcp-protocol-version",
  "Access-Control-Max-Age": "86400",
};

const mcpJson = (payload: unknown, status = 200) =>
  new Response(JSON.stringify(payload), {
    status,
    headers: { ...MCP_CORS_HEADERS, "Content-Type": "application/json" },
  });

// ---- Reuse: inline copy of caption + notes logic ----
type Platform = "youtube" | "instagram" | "tiktok" | "unsupported";

function detectPlatform(rawUrl: string): { platform: Platform; url: URL | null } {
  if (!rawUrl || typeof rawUrl !== "string") return { platform: "unsupported", url: null };
  try {
    const input = rawUrl.trim();
    const url = new URL(input.includes("://") ? input : `https://${input}`);
    const host = url.hostname.replace(/^www\./, "").toLowerCase();
    if (host === "youtu.be" || host === "youtube.com" || host.endsWith(".youtube.com")) return { platform: "youtube", url };
    if (host === "instagram.com" || host.endsWith(".instagram.com")) return { platform: "instagram", url };
    if (host === "tiktok.com" || host.endsWith(".tiktok.com") || host === "vm.tiktok.com") return { platform: "tiktok", url };
    return { platform: "unsupported", url };
  } catch {
    return { platform: "unsupported", url: null };
  }
}

function extractDisplayId(platform: Platform, url: URL | null): string | null {
  if (!url) return null;
  const parts = url.pathname.split("/").filter(Boolean);
  if (platform === "youtube") {
    const ID = /^[a-zA-Z0-9_-]{11}$/;
    const host = url.hostname.replace(/^www\./, "").toLowerCase();
    if (host === "youtu.be") return parts[0] || null;
    const v = url.searchParams.get("v");
    if (v && ID.test(v)) return v;
    if (parts.length >= 2 && ["shorts", "embed", "live", "v"].includes(parts[0])) return parts[1] || null;
    return null;
  }
  if (platform === "instagram") {
    const idx = parts.findIndex((p) => p === "reel" || p === "reels" || p === "p" || p === "tv");
    if (idx !== -1 && parts[idx + 1]) return parts[idx + 1];
    return parts[parts.length - 1] || null;
  }
  if (platform === "tiktok") {
    const idx = parts.findIndex((p) => p === "video");
    if (idx !== -1 && parts[idx + 1]) return parts[idx + 1];
    return parts[parts.length - 1] || null;
  }
  return null;
}

function decodeEntities(t: string) {
  return t.replace(/&amp;/g, "&").replace(/&#39;/g, "'").replace(/&#34;/g, '"').replace(/&quot;/g, '"').replace(/&lt;/g, "<").replace(/&gt;/g, ">").replace(/&nbsp;/g, " ");
}

const SUPADATA_BASE = "https://api.supadata.ai/v1";
const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));

function extractSupadataText(data: any): string {
  const c = data?.content;
  if (typeof c === "string") return c;
  if (Array.isArray(c)) return c.map((x: any) => x?.text ?? "").join(" ");
  return "";
}

async function pollJob(jobId: string, key: string) {
  for (let i = 0; i < 55; i++) {
    await sleep(1000);
    const res = await fetch(`${SUPADATA_BASE}/transcript/${encodeURIComponent(jobId)}`, { headers: { "x-api-key": key } }).catch(() => null);
    if (!res) return { status: "failed", detail: "job network error" };
    if (!res.ok) return { status: "failed", detail: `job ${res.status}` };
    const data = await res.json().catch(() => null);
    const s = data?.status;
    if (s === "completed") {
      const text = extractSupadataText(data).trim();
      return text ? { status: "ok", text } : { status: "no_caption" };
    }
    if (s === "failed") {
      const e = typeof data?.error === "string" ? data.error : JSON.stringify(data?.error ?? {});
      if (/transcript-unavailable|no.?transcript|unavailable/i.test(e)) return { status: "no_caption" };
      return { status: "failed", detail: e.slice(0, 200) };
    }
  }
  return { status: "failed", detail: "timed out" };
}

async function fetchCaption(videoUrl: string) {
  const key = Deno.env.get("TRANSCRIPT_API_KEY");
  if (!key) return { status: "failed", detail: "TRANSCRIPT_API_KEY is not set" };
  const endpoint = `${SUPADATA_BASE}/transcript?url=${encodeURIComponent(videoUrl)}&text=true`;
  const res = await fetch(endpoint, { headers: { "x-api-key": key } }).catch(() => null);
  if (!res) return { status: "failed", detail: "network error" };
  if (res.status === 206) return { status: "no_caption" };
  if (res.status === 202) {
    const body = await res.json().catch(() => null);
    if (!body?.jobId) return { status: "failed", detail: "missing jobId" };
    return pollJob(body.jobId, key);
  }
  if (!res.ok) return { status: "failed", detail: `service ${res.status}` };
  const data = await res.json().catch(() => null);
  if (!data) return { status: "failed", detail: "invalid JSON" };
  const text = extractSupadataText(data).trim();
  return text ? { status: "ok", text } : { status: "no_caption" };
}

const YOUTUBE_INSTRUCTION =
  "You are given the raw transcript of a YouTube video. Produce complete, faithful written notes that let someone fully understand the video WITHOUT watching it. Capture all the important explanations, key points, and any steps or instructions given. Structure the notes in whatever way best fits this specific video's content — use headings, sub-points, ordered steps, or flowing paragraphs as appropriate. Do not force a rigid template. Do not omit important detail. Be thorough but clear. Output in clean markdown.";
const SHORT_CLIP_INSTRUCTION = (label: string) =>
  `You are given the raw transcript of a short ${label} clip. Produce TIGHT, concise notes that match the brevity of the clip — never pad, never invent content not in the transcript. Start with a one or two sentence summary, then list the key points/takeaways/steps as a short bulleted or numbered list. If it's a how-to, use short numbered steps. Skip headings if too short to warrant them. Keep notes proportional to transcript length. Output in clean markdown.`;
function instructionFor(p: Platform): string {
  if (p === "tiktok") return SHORT_CLIP_INSTRUCTION("TikTok");
  if (p === "instagram") return SHORT_CLIP_INSTRUCTION("Instagram Reel");
  return YOUTUBE_INSTRUCTION;
}
const chunkInstr = (p: number, t: number, platform: Platform) => {
  const label = platform === "tiktok" ? "TikTok" : platform === "instagram" ? "Instagram Reel" : "YouTube video";
  return `You are given part ${p} of ${t} of the raw transcript of a ${label}. Produce complete, faithful written notes for THIS PART only. Use clean markdown. Do NOT write overall intro/conclusion. Do not omit detail. Do not invent content not in the transcript.`;
};
const COMBINE = "Below are notes from sequential sections of a single video, in order. Combine them into one coherent, well-structured set of notes for the whole video. Preserve all detail. Remove duplicates, smooth transitions. Output clean markdown.";

async function callGemini(instr: string, content: string, key: string) {
  const model = Deno.env.get("GEMINI_MODEL") || "gemini-2.0-flash";
  const res = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${key}`, {
    method: "POST", headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ system_instruction: { parts: [{ text: instr }] }, contents: [{ role: "user", parts: [{ text: content }] }] }),
  });
  if (!res.ok) throw new Error(`Gemini ${res.status}`);
  const data = await res.json();
  const text = data?.candidates?.[0]?.content?.parts?.map((p: any) => p.text).join("") ?? "";
  if (!text.trim()) throw new Error("Gemini empty");
  return text.trim();
}
async function callGroq(instr: string, content: string, key: string) {
  const model = Deno.env.get("GROQ_MODEL") || "llama-3.3-70b-versatile";
  const res = await fetch("https://api.groq.com/openai/v1/chat/completions", {
    method: "POST", headers: { "Content-Type": "application/json", Authorization: `Bearer ${key}` },
    body: JSON.stringify({ model, messages: [{ role: "system", content: instr }, { role: "user", content }] }),
  });
  if (!res.ok) throw new Error(`Groq ${res.status}`);
  const data = await res.json();
  const text = data?.choices?.[0]?.message?.content ?? "";
  if (!text.trim()) throw new Error("Groq empty");
  return text.trim();
}
async function runAI(instr: string, content: string): Promise<string | null> {
  const chain = [
    { fn: callGemini, key: Deno.env.get("GEMINI_API_KEY_1") },
    { fn: callGroq, key: Deno.env.get("GROQ_API_KEY_1") },
    { fn: callGemini, key: Deno.env.get("GEMINI_API_KEY_2") },
    { fn: callGroq, key: Deno.env.get("GROQ_API_KEY_2") },
  ];
  for (const s of chain) {
    if (!s.key) continue;
    try { return await s.fn(instr, content, s.key); } catch (e) { console.warn("ai failed:", (e as any)?.message); }
  }
  return null;
}
function splitChunks(text: string, size: number) {
  const words = text.split(/\s+/); const out: string[] = []; let cur = "";
  for (const w of words) { if (cur && cur.length + w.length + 1 > size) { out.push(cur); cur = ""; } cur += (cur ? " " : "") + w; }
  if (cur) out.push(cur); return out;
}
async function structure(text: string, platform: Platform): Promise<string | null> {
  const t = text.length > 250000 ? text.slice(0, 250000) : text;
  const main = instructionFor(platform);
  if (t.length <= 12000) return runAI(main, t);
  const chunks = splitChunks(t, 12000); const secs: string[] = [];
  for (let i = 0; i < chunks.length; i++) { const n = await runAI(chunkInstr(i + 1, chunks.length, platform), chunks[i]); if (!n) return null; secs.push(n); }
  let combined = secs.join("\n\n");
  if (combined.length <= 30000) { const s = await runAI(COMBINE, combined); if (s) combined = s; }
  return combined;
}

async function fetchAndStructureNotes(url: string) {
  const { platform, url: parsed } = detectPlatform(url);
  if (platform === "unsupported" || !parsed) return { ok: false, code: "invalid_url" as const, platform: "unsupported" as const };
  const videoId = extractDisplayId(platform, parsed);
  const f = await fetchCaption(parsed.toString());
  if (f.status === "no_caption") return { ok: false, code: "no_caption" as const, platform, videoId };
  if (f.status !== "ok") return { ok: false, code: "fetch_failed" as const, platform, videoId };
  const raw = decodeEntities((f as any).text).trim();
  const notes = await structure(raw, platform);
  if (!notes) return { ok: true, platform, videoId, notes: null, transcript: raw, notesUnavailable: true };
  return { ok: true, platform, videoId, notes, transcript: raw };
}

function errorMessage(code: "invalid_url" | "no_caption" | "fetch_failed", platform: Platform): string {
  if (code === "invalid_url") return "Please paste a public YouTube, Instagram, or TikTok video link.";
  if (code === "no_caption") {
    if (platform === "instagram") return "This Instagram Reel has no spoken audio to transcribe. Try a Reel with people talking.";
    if (platform === "tiktok") return "This TikTok has no spoken audio to transcribe. Try a video with people talking.";
    return "This YouTube video doesn't have captions available.";
  }
  if (platform === "instagram") return "Couldn't get this Instagram Reel. Make sure it's a PUBLIC Reel with spoken audio (private Reels and Stories aren't supported).";
  if (platform === "tiktok") return "Couldn't get this TikTok. Make sure it's a PUBLIC video with spoken audio.";
  return "Couldn't fetch this YouTube video. Make sure the link is public and try again.";
}

// ---- MCP ----
const MCP_DEFAULT_PROTOCOL_VERSION = "2024-11-05";
const MCP_SERVER_INFO = { name: "TikTok IG YT Trans.", version: "1.0.0" };

const GET_YOUTUBE_NOTES_TOOL = {
  name: "tiktok_ig_yt_trans",
  description:
    "Fetches a public video's original caption and AI-structured notes. Supports YouTube, Instagram (Reels/Posts), and TikTok URLs. Always returns the original caption when available. If structured notes are included, present those notes to the user. If notes are unavailable (notesAvailable: false), generate clear, well-structured notes yourself from the provided original caption, then present those notes. Always show the user readable notes.",
  inputSchema: {
    type: "object",
    properties: {
      url: { type: "string", description: "Full public video URL from YouTube, Instagram, or TikTok (any format)." },
      include_caption: { type: "boolean", description: "Whether to include the original caption in the response.", default: true },
    },
    required: ["url"],
  },
};

function buildToolText(result: any, includeCaption: boolean) {
  const notesAvailable = !!result.notes;
  return [
    "## NOTES",
    notesAvailable ? result.notes : "NOTES_UNAVAILABLE",
    "",
    "## ORIGINAL CAPTION",
    includeCaption ? result.transcript : "(caption omitted by request)",
    "",
    "## STATUS",
    `platform: ${result.platform}`,
    `notesAvailable: ${notesAvailable}`,
    `videoId: ${result.videoId}`,
  ].join("\n");
}

async function runTool(args: any) {
  const url = typeof args?.url === "string" ? args.url : "";
  const includeCaption = args?.include_caption !== false;
  const result = await fetchAndStructureNotes(url);
  if (!result.ok) {
    const platform = (result as any).platform as Platform;
    const message = errorMessage(result.code, platform);
    const text = `${message}\n\n## STATUS\nplatform: ${platform}\nerror: ${result.code}`;
    return { content: [{ type: "text", text }], isError: true };
  }
  return { content: [{ type: "text", text: buildToolText(result, includeCaption) }], isError: false };
}

const rpcResult = (id: any, result: any) => ({ jsonrpc: "2.0", id, result });
const rpcError = (id: any, code: number, message: string) => ({ jsonrpc: "2.0", id, error: { code, message } });

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { status: 204, headers: MCP_CORS_HEADERS });
  if (req.method === "GET") return mcpJson({ ...MCP_SERVER_INFO, protocol: "mcp", transport: "http" });

  let body: any;
  try { body = await req.json(); } catch { return mcpJson(rpcError(null, -32700, "Parse error")); }
  const { id = null, method, params } = body || {};

  try {
    switch (method) {
      case "initialize":
        return mcpJson(rpcResult(id, {
          protocolVersion: params?.protocolVersion || MCP_DEFAULT_PROTOCOL_VERSION,
          capabilities: { tools: {} },
          serverInfo: MCP_SERVER_INFO,
        }));
      case "notifications/initialized":
      case "initialized":
        return new Response(null, { status: 202, headers: MCP_CORS_HEADERS });
      case "ping":
        return mcpJson(rpcResult(id, {}));
      case "tools/list":
        return mcpJson(rpcResult(id, { tools: [GET_YOUTUBE_NOTES_TOOL] }));
      case "tools/call": {
        if (params?.name !== "tiktok_ig_yt_trans")
          return mcpJson(rpcError(id, -32602, `Unknown tool: ${params?.name}`));
        const toolResult = await runTool(params?.arguments);
        return mcpJson(rpcResult(id, toolResult));
      }
      default:
        return mcpJson(rpcError(id, -32601, `Method not found: ${method}`));
    }
  } catch (err: any) {
    console.error("[mcp] error:", err?.stack || err?.message || err);
    return mcpJson(rpcError(id, -32603, "Internal error"));
  }
});
