// deno-lint-ignore-file no-explicit-any
// Edge function: POST { url } -> { videoId, notes, transcript, notesUnavailable? }
// Replicates api/_lib/handlers.js logic for the live (published) Lovable site.

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "POST, GET, OPTIONS",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type",
};

const json = (data: unknown, status = 200) =>
  new Response(JSON.stringify(data), {
    status,
    headers: { ...corsHeaders, "Content-Type": "application/json" },
  });

type Platform = "youtube" | "instagram" | "tiktok" | "unsupported";

function detectPlatform(rawUrl: string): { platform: Platform; url: URL | null } {
  if (!rawUrl || typeof rawUrl !== "string") return { platform: "unsupported", url: null };
  try {
    const input = rawUrl.trim();
    const url = new URL(input.includes("://") ? input : `https://${input}`);
    const host = url.hostname.replace(/^www\./, "").toLowerCase();
    if (host === "youtu.be" || host === "youtube.com" || host.endsWith(".youtube.com")) {
      return { platform: "youtube", url };
    }
    if (host === "instagram.com" || host.endsWith(".instagram.com")) {
      return { platform: "instagram", url };
    }
    if (host === "tiktok.com" || host.endsWith(".tiktok.com") || host === "vm.tiktok.com") {
      return { platform: "tiktok", url };
    }
    return { platform: "unsupported", url };
  } catch {
    return { platform: "unsupported", url: null };
  }
}

// Display-friendly id for the response payload. YouTube returns 11-char id when
// possible; IG/TikTok return the shortcode/numeric id slug from the path.
function extractDisplayId(platform: Platform, url: URL | null): string | null {
  if (!url) return null;
  const parts = url.pathname.split("/").filter(Boolean);
  if (platform === "youtube") {
    const ID = /^[a-zA-Z0-9_-]{11}$/;
    const host = url.hostname.replace(/^www\./, "").toLowerCase();
    if (host === "youtu.be") return parts[0] || null;
    const v = url.searchParams.get("v");
    if (v && ID.test(v)) return v;
    if (parts.length >= 2 && ["shorts", "embed", "live", "v"].includes(parts[0])) return parts[1] || null;
    return null;
  }
  if (platform === "instagram") {
    const idx = parts.findIndex((p) => p === "reel" || p === "reels" || p === "p" || p === "tv");
    if (idx !== -1 && parts[idx + 1]) return parts[idx + 1];
    return parts[parts.length - 1] || null;
  }
  if (platform === "tiktok") {
    const idx = parts.findIndex((p) => p === "video");
    if (idx !== -1 && parts[idx + 1]) return parts[idx + 1];
    return parts[parts.length - 1] || null;
  }
  return null;
}

function decodeEntities(text: string) {
  return text
    .replace(/&amp;/g, "&")
    .replace(/&#39;/g, "'")
    .replace(/&#34;/g, '"')
    .replace(/&quot;/g, '"')
    .replace(/&lt;/g, "<")
    .replace(/&gt;/g, ">")
    .replace(/&nbsp;/g, " ");
}

// ---- Supadata caption fetch ----
const SUPADATA_BASE = "https://api.supadata.ai/v1";
const SUPADATA_POLL_INTERVAL_MS = 1000;
const SUPADATA_MAX_POLLS = 55;
const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));

function extractSupadataText(data: any): string {
  const content = data?.content;
  if (typeof content === "string") return content;
  if (Array.isArray(content)) return content.map((c: any) => c?.text ?? "").join(" ");
  return "";
}

async function pollSupadataJob(jobId: string, key: string) {
  const url = `${SUPADATA_BASE}/transcript/${encodeURIComponent(jobId)}`;
  for (let i = 0; i < SUPADATA_MAX_POLLS; i++) {
    await sleep(SUPADATA_POLL_INTERVAL_MS);
    let res: Response;
    try {
      res = await fetch(url, { headers: { "x-api-key": key } });
    } catch (err: any) {
      return { status: "failed", detail: `job network error: ${err?.message || err}` };
    }
    if (!res.ok) {
      const detail = await res.text().catch(() => "");
      return { status: "failed", detail: `job ${res.status}: ${detail.slice(0, 200)}` };
    }
    const data = await res.json().catch(() => null);
    const jobStatus = data?.status;
    if (jobStatus === "completed") {
      const text = extractSupadataText(data).trim();
      return text ? { status: "ok", text } : { status: "no_caption" };
    }
    if (jobStatus === "failed") {
      const e = data?.error;
      const eStr = typeof e === "string" ? e : JSON.stringify(e ?? {});
      if (/transcript-unavailable|no.?transcript|unavailable/i.test(eStr)) {
        return { status: "no_caption" };
      }
      return { status: "failed", detail: `job failed: ${eStr.slice(0, 200)}` };
    }
  }
  return { status: "failed", detail: "transcript job timed out" };
}

async function fetchCaptionViaService(videoUrl: string) {
  const key = Deno.env.get("TRANSCRIPT_API_KEY");
  if (!key) return { status: "failed", detail: "TRANSCRIPT_API_KEY is not set" };
  const endpoint = `${SUPADATA_BASE}/transcript?url=${encodeURIComponent(videoUrl)}&text=true`;
  let res: Response;
  try {
    res = await fetch(endpoint, { headers: { "x-api-key": key } });
  } catch (err: any) {
    return { status: "failed", detail: `network error: ${err?.message || err}` };
  }
  if (res.status === 206) return { status: "no_caption" };
  if (res.status === 202) {
    const body = await res.json().catch(() => null);
    const jobId = body?.jobId;
    if (!jobId) return { status: "failed", detail: "async job missing jobId" };
    return pollSupadataJob(jobId, key);
  }
  if (!res.ok) {
    const detail = await res.text().catch(() => "");
    return { status: "failed", detail: `service ${res.status}: ${detail.slice(0, 200)}` };
  }
  const data = await res.json().catch(() => null);
  if (!data) return { status: "failed", detail: "invalid JSON from transcript service" };
  const text = extractSupadataText(data).trim();
  return text ? { status: "ok", text } : { status: "no_caption" };
}

// ---- AI fallback chain ----
// Platform-aware instructions: YouTube gets the original detailed sectioned
// style; TikTok/Instagram get tight, compact notes matching the clip's brevity.
// Never invent content beyond the transcript.
const YOUTUBE_INSTRUCTION =
  "You are given the raw transcript of a YouTube video. Produce complete, faithful written notes that let someone fully understand the video WITHOUT watching it. Capture all the important explanations, key points, and any steps or instructions given. Structure the notes in whatever way best fits this specific video's content — use headings, sub-points, ordered steps, or flowing paragraphs as appropriate. Do not force a rigid template. Do not omit important detail. Be thorough but clear. Output in clean markdown.";

const SHORT_CLIP_INSTRUCTION = (platformLabel: string) =>
  `You are given the raw transcript of a short ${platformLabel} clip. Produce TIGHT, concise notes that match the brevity of the clip — never pad, never invent content that isn't in the transcript. Start with a one or two sentence summary, then list the key points, takeaways, or steps as a short bulleted or numbered list. If it's a how-to, use short numbered steps. Skip headings if the clip is too short to warrant them. Keep notes proportional to the transcript length: short transcript = short notes. Output in clean markdown.`;

function instructionFor(platform: Platform): string {
  if (platform === "tiktok") return SHORT_CLIP_INSTRUCTION("TikTok");
  if (platform === "instagram") return SHORT_CLIP_INSTRUCTION("Instagram Reel");
  return YOUTUBE_INSTRUCTION;
}

const chunkInstruction = (part: number, total: number, platform: Platform) => {
  const label = platform === "tiktok" ? "TikTok" : platform === "instagram" ? "Instagram Reel" : "YouTube video";
  return `You are given part ${part} of ${total} of the raw transcript of a ${label}. Produce complete, faithful written notes for THIS PART only. Capture all the important explanations, key points, and any steps or instructions given. Use clean markdown. Do NOT write an overall introduction or conclusion for the whole video — this is only one section. Do not omit important detail. Do not invent content not present in the transcript.`;
};

const COMBINE_INSTRUCTION =
  "Below are notes from sequential sections of a single video, in order. Combine them into one coherent, well-structured set of notes for the whole video. Preserve all the detail, key points, and steps. Remove duplicated or redundant headings, smooth the transitions between sections, and ensure a logical flow from start to finish. Do not omit important detail. Output in clean markdown.";

const MAX_TRANSCRIPT_CHARS = 250_000;
const CHUNK_CHARS = 12_000;
const FINAL_PASS_CHARS = 30_000;

const GEMINI_MODEL = () => Deno.env.get("GEMINI_MODEL") || "gemini-2.0-flash";
const GROQ_MODEL = () => Deno.env.get("GROQ_MODEL") || "llama-3.3-70b-versatile";

async function callGemini(instruction: string, content: string, key: string) {
  if (!key) throw new Error("Gemini API key is not set");
  const model = GEMINI_MODEL();
  const res = await fetch(
    `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${key}`,
    {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        system_instruction: { parts: [{ text: instruction }] },
        contents: [{ role: "user", parts: [{ text: content }] }],
      }),
    },
  );
  if (!res.ok) {
    const detail = await res.text().catch(() => "");
    throw new Error(`Gemini request failed (${res.status}): ${detail.slice(0, 200)}`);
  }
  const data = await res.json();
  const text = data?.candidates?.[0]?.content?.parts?.map((p: any) => p.text).join("") ?? "";
  if (!text.trim()) throw new Error("Gemini returned no content");
  return text.trim();
}

async function callGroq(instruction: string, content: string, key: string) {
  if (!key) throw new Error("Groq API key is not set");
  const model = GROQ_MODEL();
  const res = await fetch("https://api.groq.com/openai/v1/chat/completions", {
    method: "POST",
    headers: { "Content-Type": "application/json", Authorization: `Bearer ${key}` },
    body: JSON.stringify({
      model,
      messages: [
        { role: "system", content: instruction },
        { role: "user", content },
      ],
    }),
  });
  if (!res.ok) {
    const detail = await res.text().catch(() => "");
    throw new Error(`Groq request failed (${res.status}): ${detail.slice(0, 200)}`);
  }
  const data = await res.json();
  const text = data?.choices?.[0]?.message?.content ?? "";
  if (!text.trim()) throw new Error("Groq returned no content");
  return text.trim();
}

async function runAI(instruction: string, content: string): Promise<string | null> {
  const chain = [
    { label: "gemini key1", fn: callGemini, key: Deno.env.get("GEMINI_API_KEY_1") },
    { label: "groq key1", fn: callGroq, key: Deno.env.get("GROQ_API_KEY_1") },
    { label: "gemini key2", fn: callGemini, key: Deno.env.get("GEMINI_API_KEY_2") },
    { label: "groq key2", fn: callGroq, key: Deno.env.get("GROQ_API_KEY_2") },
  ];
  for (const step of chain) {
    if (!step.key) {
      console.warn(`[notes] skipping ${step.label}: key not set`);
      continue;
    }
    try {
      console.log(`[notes] trying ${step.label}`);
      const text = await step.fn(instruction, content, step.key);
      console.log(`[notes] ${step.label} succeeded`);
      return text;
    } catch (err: any) {
      console.warn(`[notes] ${step.label} failed: ${err?.message || String(err)}`);
    }
  }
  return null;
}

function splitIntoChunks(text: string, size: number) {
  const words = text.split(/\s+/);
  const chunks: string[] = [];
  let current = "";
  for (const word of words) {
    if (current && current.length + word.length + 1 > size) {
      chunks.push(current);
      current = "";
    }
    current += (current ? " " : "") + word;
  }
  if (current) chunks.push(current);
  return chunks;
}

async function structureNotes(transcriptText: string, platform: Platform): Promise<string | null> {
  const text =
    transcriptText.length > MAX_TRANSCRIPT_CHARS
      ? transcriptText.slice(0, MAX_TRANSCRIPT_CHARS)
      : transcriptText;
  const mainInstruction = instructionFor(platform);
  if (text.length <= CHUNK_CHARS) return runAI(mainInstruction, text);
  const chunks = splitIntoChunks(text, CHUNK_CHARS);
  const sections: string[] = [];
  for (let i = 0; i < chunks.length; i++) {
    const note = await runAI(chunkInstruction(i + 1, chunks.length, platform), chunks[i]);
    if (!note) return null;
    sections.push(note);
  }
  let combined = sections.join("\n\n");
  if (combined.length <= FINAL_PASS_CHARS) {
    const smoothed = await runAI(COMBINE_INSTRUCTION, combined);
    if (smoothed) combined = smoothed;
  }
  return combined;
}

export async function fetchAndStructureNotes(url: string) {
  const { platform, url: parsed } = detectPlatform(url);
  if (platform === "unsupported" || !parsed) return { ok: false, code: "invalid_url" as const, platform: "unsupported" as const };
  const videoId = extractDisplayId(platform, parsed);
  const fullUrl = parsed.toString();
  const fetched = await fetchCaptionViaService(fullUrl);
  if (fetched.status === "no_caption") return { ok: false, code: "no_caption" as const, platform, videoId };
  if (fetched.status !== "ok") {
    console.error("[transcript] caption service failed", { platform, videoId, detail: (fetched as any).detail });
    return { ok: false, code: "fetch_failed" as const, platform, videoId, detail: (fetched as any).detail };
  }
  const rawTranscript = decodeEntities((fetched as any).text).trim();
  const notes = await structureNotes(rawTranscript, platform);
  if (!notes) {
    return { ok: true, platform, videoId, notes: null, transcript: rawTranscript, notesUnavailable: true };
  }
  return { ok: true, platform, videoId, notes, transcript: rawTranscript };
}

function errorMessage(code: "invalid_url" | "no_caption" | "fetch_failed", platform: Platform): string {
  if (code === "invalid_url") return "Please paste a public YouTube, Instagram, or TikTok video link.";
  if (code === "no_caption") {
    if (platform === "instagram") return "This Instagram Reel has no spoken audio to transcribe. Try a Reel with people talking.";
    if (platform === "tiktok") return "This TikTok has no spoken audio to transcribe. Try a video with people talking.";
    return "This video doesn't have captions available.";
  }
  if (platform === "instagram") return "Couldn't get this Instagram Reel. Make sure it's a PUBLIC Reel with spoken audio (private Reels and Stories aren't supported).";
  if (platform === "tiktok") return "Couldn't get this TikTok. Make sure it's a PUBLIC video with spoken audio.";
  return "Couldn't fetch this YouTube video. Make sure the link is public and try again.";
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });
  try {
    let url = "";
    if (req.method === "POST") {
      const body = await req.json().catch(() => ({}));
      url = body?.url ?? "";
    } else {
      url = new URL(req.url).searchParams.get("url") ?? "";
    }
    const result = await fetchAndStructureNotes(url);
    if (!result.ok) {
      const platform = (result as any).platform as Platform;
      const message = errorMessage(result.code, platform);
      const status = result.code === "invalid_url" ? 400 : result.code === "no_caption" ? 404 : 502;
      return json({ error: result.code, message, platform }, status);
    }
    const payload: any = {
      platform: (result as any).platform,
      videoId: result.videoId,
      notes: (result as any).notes ?? null,
      transcript: (result as any).transcript,
    };
    if ((result as any).notesUnavailable) payload.notesUnavailable = true;
    return json(payload);
  } catch (err: any) {
    console.error("[transcript] unexpected error:", err?.stack || err?.message || err);
    return json({ error: "server_error", message: "Something went wrong. Please try again." }, 500);
  }
});
