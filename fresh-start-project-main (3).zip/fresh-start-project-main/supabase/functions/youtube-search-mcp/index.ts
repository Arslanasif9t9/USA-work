// deno-lint-ignore-file no-explicit-any
// Standalone MCP JSON-RPC 2.0 connector exposing ONE tool: search_youtube.
// Independent from the transcript MCP. Wraps the youtube-search logic
// and enriches results with real view counts via a second videos.list call.

const MCP_CORS_HEADERS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "POST, GET, OPTIONS",
  "Access-Control-Allow-Headers":
    "Content-Type, Authorization, apikey, x-client-info, mcp-session-id, mcp-protocol-version",
  "Access-Control-Max-Age": "86400",
};

const mcpJson = (payload: unknown, status = 200) =>
  new Response(JSON.stringify(payload), {
    status,
    headers: { ...MCP_CORS_HEADERS, "Content-Type": "application/json" },
  });

const ALLOWED_ORDER = new Set(["relevance", "date", "viewCount", "rating", "title"]);
const ALLOWED_DURATION = new Set(["any", "short", "medium", "long"]);

function resolvePublishedAfter(input?: string): string | undefined {
  if (!input) return undefined;
  const s = String(input).trim().toLowerCase();
  const m = s.match(/^(\d+)\s*d$/);
  if (m) {
    const days = parseInt(m[1], 10);
    if (Number.isFinite(days) && days > 0) {
      const d = new Date(Date.now() - days * 24 * 60 * 60 * 1000);
      return d.toISOString();
    }
  }
  // Allow raw RFC 3339 passthrough
  if (!Number.isNaN(Date.parse(input))) return new Date(input).toISOString();
  return undefined;
}

async function runYoutubeSearch(params: {
  query: string;
  limit?: number;
  order?: string;
  publishedAfter?: string;
  videoDuration?: string;
  regionCode?: string;
  minViews?: number;
}): Promise<
  | { ok: true; results: any[] }
  | { ok: false; error: string; message: string }
> {
  const q = String(params.query ?? "").trim();
  if (!q) return { ok: false, error: "empty_query", message: "Please provide a non-empty query." };

  const key = Deno.env.get("YOUTUBE_API_KEY");
  if (!key) return { ok: false, error: "config", message: "YouTube search is not configured (missing API key)." };

  let limit = Number.isFinite(params.limit) ? Math.floor(params.limit as number) : 10;
  if (limit < 1) limit = 1;
  if (limit > 50) limit = 50;

  const order = params.order && ALLOWED_ORDER.has(params.order) ? params.order : "relevance";
  const videoDuration =
    params.videoDuration && ALLOWED_DURATION.has(params.videoDuration) ? params.videoDuration : undefined;
  const publishedAfter = resolvePublishedAfter(params.publishedAfter);
  const minViews = Number.isFinite(params.minViews) ? Math.max(0, Math.floor(params.minViews as number)) : 10000;

  // Step 1: search.list
  const searchUrl = new URL("https://www.googleapis.com/youtube/v3/search");
  searchUrl.searchParams.set("part", "snippet");
  searchUrl.searchParams.set("q", q);
  searchUrl.searchParams.set("type", "video");
  searchUrl.searchParams.set("maxResults", String(limit));
  searchUrl.searchParams.set("order", order);
  if (videoDuration && videoDuration !== "any") searchUrl.searchParams.set("videoDuration", videoDuration);
  if (publishedAfter) searchUrl.searchParams.set("publishedAfter", publishedAfter);
  if (params.regionCode) searchUrl.searchParams.set("regionCode", params.regionCode);
  searchUrl.searchParams.set("key", key);

  const sRes = await fetch(searchUrl.toString());
  const sData = await sRes.json().catch(() => null);

  if (!sRes.ok || !sData) {
    const reason = sData?.error?.errors?.[0]?.reason || "";
    let message = "YouTube search failed. Please try again.";
    if (reason === "quotaExceeded" || reason === "rateLimitExceeded") {
      message = "YouTube search quota reached. Please try again later.";
    } else if (reason === "keyInvalid" || reason === "badRequest") {
      message = "YouTube search is misconfigured.";
    }
    return { ok: false, error: "search_failed", message };
  }

  const items = Array.isArray(sData.items) ? sData.items : [];
  const base = items
    .filter((it: any) => it?.id?.videoId)
    .map((it: any) => {
      const sn = it.snippet || {};
      const videoId = it.id.videoId;
      return {
        videoId,
        title: sn.title || "",
        channelTitle: sn.channelTitle || "",
        publishedAt: sn.publishedAt || "",
        url: `https://www.youtube.com/watch?v=${videoId}`,
        views: 0,
      };
    });

  if (base.length === 0) return { ok: true, results: [] };

  // Step 2: videos.list for statistics
  const ids = base.map((b) => b.videoId).join(",");
  const statsMap = new Map<string, number>();
  try {
    const vUrl = new URL("https://www.googleapis.com/youtube/v3/videos");
    vUrl.searchParams.set("part", "snippet,statistics");
    vUrl.searchParams.set("id", ids);
    vUrl.searchParams.set("key", key);
    const vRes = await fetch(vUrl.toString());
    const vData = await vRes.json().catch(() => null);
    if (vRes.ok && vData && Array.isArray(vData.items)) {
      for (const it of vData.items) {
        const vid = it?.id;
        const vc = parseInt(it?.statistics?.viewCount ?? "0", 10);
        if (vid) statsMap.set(vid, Number.isFinite(vc) ? vc : 0);
      }
    }
  } catch (_e) {
    // ignore; views default to 0
  }

  for (const b of base) b.views = statsMap.get(b.videoId) ?? 0;

  const filtered = base.filter((b) => b.views >= minViews);
  filtered.sort((a, b) => b.views - a.views);

  return { ok: true, results: filtered };
}

const MCP_DEFAULT_PROTOCOL_VERSION = "2024-11-05";
const MCP_SERVER_INFO = { name: "youtube-search-mcp", version: "1.1.0" };

const SEARCH_YOUTUBE_TOOL = {
  name: "search_youtube",
  description:
    "Search YouTube for videos by keyword and return results enriched with real view counts. Results are filtered by minimum views (default 10,000) and always sorted by views descending. Only 'query' is required. Optional: limit (1-50, default 10), order (relevance/date/viewCount/rating/title), published_after ('30d' or '90d'), min_views (integer, default 10000; pass 0 to disable), videoDuration, regionCode.",
  inputSchema: {
    type: "object",
    properties: {
      query: { type: "string", description: "Search text." },
      limit: { type: "integer", description: "Number of videos to fetch from search (1-50). Default 10.", minimum: 1, maximum: 50, default: 10 },
      order: { type: "string", description: "Initial result ordering from YouTube search.", enum: ["relevance", "date", "viewCount", "rating", "title"], default: "relevance" },
      published_after: { type: "string", description: "Recency filter. Accepts '30d' or '90d'." },
      min_views: { type: "integer", description: "Minimum viewCount to keep a video. Default 10000. Pass 0 to disable.", minimum: 0, default: 10000 },
      videoDuration: { type: "string", description: "Filter by duration.", enum: ["any", "short", "medium", "long"], default: "any" },
      regionCode: { type: "string", description: "ISO 3166-1 alpha-2 country code." },
    },
    required: ["query"],
  },
};

function formatViews(n: number): string {
  return Number(n || 0).toLocaleString("en-US");
}

function formatResultsText(query: string, results: any[]): string {
  if (results.length === 0) return `No YouTube videos found for "${query}".`;
  const header = `Found ${results.length} YouTube video${results.length === 1 ? "" : "s"} for "${query}" (sorted by views):\n`;
  const blocks = results.map((r, i) => {
    const date = r.published ? r.published.slice(0, 10) : "unknown date";
    return [
      `${i + 1}. ${r.title}`,
      `   Channel: ${r.channel}`,
      `   Published: ${date}`,
      `   Views: ${formatViews(r.views)}`,
      `   URL: ${r.url}`,
    ].join("\n");
  });
  return [header, ...blocks].join("\n\n");
}

async function runTool(args: any) {
  const result = await runYoutubeSearch({
    query: typeof args?.query === "string" ? args.query : "",
    limit: typeof args?.limit === "number" ? args.limit : undefined,
    order: typeof args?.order === "string" ? args.order : undefined,
    publishedAfter: typeof args?.published_after === "string" ? args.published_after : undefined,
    minViews: typeof args?.min_views === "number" ? args.min_views : undefined,
    videoDuration: typeof args?.videoDuration === "string" ? args.videoDuration : undefined,
    regionCode: typeof args?.regionCode === "string" ? args.regionCode : undefined,
  });

  if (!result.ok) {
    return {
      content: [{ type: "text", text: `${result.message}\n\n(error: ${result.error})` }],
      isError: true,
    };
  }

  const shaped = result.results.map((r) => ({
    title: r.title,
    channel: r.channelTitle,
    published: r.publishedAt,
    url: r.url,
    views: r.views,
  }));

  const text = formatResultsText(String(args?.query ?? ""), shaped);
  return { content: [{ type: "text", text }], isError: false };
}

const rpcResult = (id: any, result: any) => ({ jsonrpc: "2.0", id, result });
const rpcError = (id: any, code: number, message: string) => ({ jsonrpc: "2.0", id, error: { code, message } });

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { status: 204, headers: MCP_CORS_HEADERS });
  if (req.method === "GET") return mcpJson({ ...MCP_SERVER_INFO, protocol: "mcp", transport: "http" });

  let body: any;
  try { body = await req.json(); } catch { return mcpJson(rpcError(null, -32700, "Parse error")); }
  const { id = null, method, params } = body || {};

  try {
    switch (method) {
      case "initialize":
        return mcpJson(rpcResult(id, {
          protocolVersion: params?.protocolVersion || MCP_DEFAULT_PROTOCOL_VERSION,
          capabilities: { tools: {} },
          serverInfo: MCP_SERVER_INFO,
        }));
      case "notifications/initialized":
      case "initialized":
        return new Response(null, { status: 202, headers: MCP_CORS_HEADERS });
      case "ping":
        return mcpJson(rpcResult(id, {}));
      case "tools/list":
        return mcpJson(rpcResult(id, { tools: [SEARCH_YOUTUBE_TOOL] }));
      case "tools/call": {
        if (params?.name !== "search_youtube")
          return mcpJson(rpcError(id, -32602, `Unknown tool: ${params?.name}`));
        const toolResult = await runTool(params?.arguments);
        return mcpJson(rpcResult(id, toolResult));
      }
      default:
        return mcpJson(rpcError(id, -32601, `Method not found: ${method}`));
    }
  } catch (err: any) {
    console.error("[youtube-search-mcp] error:", err?.stack || err?.message || err);
    return mcpJson(rpcError(id, -32603, "Internal error"));
  }
});
