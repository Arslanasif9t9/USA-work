// Edge function: POST multipart/form-data { file } -> { ok, transcript }
// Transcribes an uploaded video/audio file using Groq Whisper.
// NOTHING IS PERSISTED: no DB writes, no storage uploads, no Supabase client.
// File is held in memory only for the duration of the request.

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "POST, GET, OPTIONS",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type",
};

const json = (data: unknown, status = 200) =>
  new Response(JSON.stringify(data), {
    status,
    headers: { ...corsHeaders, "Content-Type": "application/json" },
  });

async function callGroqWhisper(file: File, key: string): Promise<string> {
  const fd = new FormData();
  fd.append("file", file, (file as any).name || "upload");
  fd.append("model", "whisper-large-v3-turbo");
  fd.append("response_format", "text");
  const res = await fetch("https://api.groq.com/openai/v1/audio/transcriptions", {
    method: "POST",
    headers: { Authorization: `Bearer ${key}` },
    body: fd,
  });
  if (!res.ok) {
    const detail = await res.text().catch(() => "");
    throw new Error(`groq ${res.status}: ${detail.slice(0, 200)}`);
  }
  const text = await res.text();
  return text.trim();
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });
  try {
    if (req.method !== "POST") {
      return json({ ok: false, error: "method_not_allowed" }, 405);
    }
    const key1 = Deno.env.get("GROQ_API_KEY_1");
    const key2 = Deno.env.get("GROQ_API_KEY_2");
    const key3 = Deno.env.get("GROQ_API_KEY");
    if (!key1 && !key2 && !key3) {
      return json({ ok: false, error: "transcribe_failed", detail: "no Groq API key configured" }, 502);
    }

    let form: FormData;
    try {
      form = await req.formData();
    } catch (err: any) {
      return json({ ok: false, error: "transcribe_failed", detail: `invalid form data: ${err?.message || err}` }, 400);
    }
    const file = form.get("file");
    if (!(file instanceof File)) {
      return json({ ok: false, error: "transcribe_failed", detail: "missing 'file' field" }, 400);
    }

    const keys = [key1, key2, key3].filter((k): k is string => !!k);
    let lastErr = "";
    for (const k of keys) {
      try {
        const transcript = await callGroqWhisper(file, k);
        return json({ ok: true, transcript });
      } catch (err: any) {
        lastErr = err?.message || String(err);
        console.warn(`[transcribe-upload] key failed: ${lastErr}`);
      }
    }
    return json({ ok: false, error: "transcribe_failed", detail: lastErr.slice(0, 200) }, 502);
  } catch (err: any) {
    console.error("[transcribe-upload] unexpected error:", err?.stack || err?.message || err);
    return json({ ok: false, error: "transcribe_failed", detail: "server error" }, 502);
  }
});
