// chat-with-agent: direct chat with a single agent. Owner-triggered only.
import {
  corsHeaders,
  errorResponse,
  jsonResponse,
  requireOwner,
  getServiceClient,
  loadAnthropicKey,
  callAnthropic,
  setAgentStatus,
  settleAgentStatus,
  logActivity,
  markAgentFailure,
} from "../_shared/anthropic.ts";

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });
  try {
    const auth = req.headers.get("Authorization");
    const ownerCheck = await requireOwner(auth);
    if (ownerCheck instanceof Response) return ownerCheck;

    const { agentId, projectId, history, message, attachments } = await req.json();
    if (!agentId || !message) return errorResponse("agentId and message required", 400);

    const svc = getServiceClient();
    const apiKey = await loadAnthropicKey(svc);
    if (!apiKey) return errorResponse("Anthropic key not configured.", 400);

    const { data: agent } = await svc.from("agents").select("*").eq("id", agentId).single();
    if (!agent) return errorResponse("Agent not found", 404);

    let ctx = "";
    if (projectId) {
      const { data: project } = await svc.from("projects").select("*").eq("id", projectId).single();
      if (project) {
        if ((project as any).status !== "active") {
          return errorResponse(`This project is ${(project as any).status}. Resume it to active to chat in-project.`, 409);
        }
        const refs = (project.reference_urls ?? []).map((u: string, i: number) => `  ${i + 1}. ${u}`).join("\n");
        ctx = `\n\n--- CURRENT PROJECT ---
Name: ${project.name}
Mode: ${project.mode}
Target tech stack: ${project.tech_stack_target}
Description: ${project.description ?? "(none)"}
Reference URLs:
${refs || "  (none)"}
Existing site to fix: ${project.existing_site_url ?? "(n/a)"}
--- END PROJECT ---`;
      }
    }

    const attachmentText = attachments && attachments.length > 0
      ? `\n\n--- ATTACHED FILES ---\n${attachments.map((a: any) => `### ${a.name}\n${a.content}`).join("\n\n")}\n--- END ATTACHMENTS ---`
      : "";

    const messages = [
      ...(history ?? []).map((m: any) => ({ role: m.role, content: m.content })),
      { role: "user" as const, content: message + attachmentText },
    ];

    await setAgentStatus(svc, agentId, "working", "Chatting with owner…");
    try {
      await logActivity(svc, { projectId, agentId, agentName: agent.name, message: `Direct chat: "${String(message).slice(0, 80)}"` });
      const result = await callAnthropic({
        agentId,
        projectId,
        model: agent.model,
        system: agent.base_system_prompt + ctx,
        messages,
        maxTokens: 4000,
        callType: "chat",
        apiKey,
        svc,
      });
      if ("error" in result) {
        await markAgentFailure(svc, { agentId, agentName: agent.name, projectId, functionName: "chat-with-agent", error: new Error(result.error) });
        return errorResponse(result.error, result.status ?? 502, { agent: agent.name, code: result.code });
      }
      return jsonResponse({ ok: true, reply: result.text, cost: result.cost, tokens: result.inputTokens + result.outputTokens });
    } finally {
      await settleAgentStatus(svc, agentId);
    }
  } catch (e) {
    return errorResponse(`Server error: ${e instanceof Error ? e.message : String(e)}`, 500);
  }
});
