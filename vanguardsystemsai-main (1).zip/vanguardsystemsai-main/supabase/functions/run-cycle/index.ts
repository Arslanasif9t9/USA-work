// run-cycle: STRICTLY SEQUENTIAL one-agent-at-a-time pipeline.
// Order: Claire (research) → Olivia (copy) → Sophia (QA) → Ethan (next prompt).
// The HTTP request returns immediately while the workflow continues in the background.
import {
  corsHeaders,
  jsonResponse,
  requireOwner,
  getServiceClient,
  loadAnthropicKey,
  callAnthropic,
  logActivity,
  clearAgentFailure,
  runAgentTask,
  AgentStepError,
  normalizeError,
  settleAgentStatus,
} from "../_shared/anthropic.ts";

declare const EdgeRuntime: {
  waitUntil(promise: Promise<unknown>): void;
};

interface Project {
  id: string;
  name: string;
  description: string | null;
  mode: string;
  reference_urls: string[] | null;
  existing_site_url: string | null;
  tech_stack_target: string;
  intake_notes: string | null;
  status?: string;
}

type CycleTrigger = "kick_off" | "next_prompt" | "continue_research" | "research_only" | "retry_failed";

type CycleResult =
  | { ok: true; type: "full_cycle" | "research_pass" | "research_only" }
  | {
      ok: false;
      error: string;
      code?: string;
      status: number;
      agentName?: string;
      agentId?: string;
      markedFailure?: boolean;
      level?: "warn" | "error";
    };

const ASTROGUIDE_ROADMAP = `ASTROGUIDE ROADMAP (authoritative, do not reorder, do not skip, do not invent):

Prompt #1: Auth + Profiles + Wallet + Stripe Recharge + Email Verification + Password Reset — COMPLETED
Prompt #2: Astrologer Directory + Profiles — NEXT
Prompt #3: Birth Chart Capture Modal + Server-Side Swisseph Compute
Prompt #4: D1 and D9 SVG Chart Rendering (North and South Indian styles)
Prompt #5: Vimshottari Dasha + Panchang
Prompt #6: Twilio Conference Call Routing + Chart Auto-Open on Call
Prompt #7: Astrologer-side Chart Auto-Open on Call Connect
Prompt #8: Per-Minute Billing + Wallet Drain + Low-Balance Cutoff
Prompt #9: Post-Call Rating + Recording Access
Prompt #10: Kundli Matching + Horoscopes
Prompt #11: Legal Pages + Landing Page + Final Design Polish

Always produce the NEXT prompt in this numerical order. Never skip. Never invent. Never duplicate a prior prompt's scope.`;

const ASTROGUIDE_PROMPT_ORDER = [
  "Auth + Profiles + Wallet + Stripe Recharge + Email Verification + Password Reset",
  "Astrologer Directory + Profiles",
  "Birth Chart Capture Modal + Server-Side Swisseph Compute",
  "D1 and D9 SVG Chart Rendering (North and South Indian styles)",
  "Vimshottari Dasha + Panchang",
  "Twilio Conference Call Routing + Chart Auto-Open on Call",
  "Astrologer-side Chart Auto-Open on Call Connect",
  "Per-Minute Billing + Wallet Drain + Low-Balance Cutoff",
  "Post-Call Rating + Recording Access",
  "Kundli Matching + Horoscopes",
  "Legal Pages + Landing Page + Final Design Polish",
] as const;

function roadmapLine(sequenceNumber: number) {
  return ASTROGUIDE_PROMPT_ORDER[sequenceNumber - 1] ?? null;
}

function buildProjectContext(p: Project): string {
  const refs = (p.reference_urls ?? []).map((u, i) => `  ${i + 1}. ${u}`).join("\n");
  return `--- CURRENT PROJECT ---
Name: ${p.name}
Mode: ${p.mode}
Target tech stack: ${p.tech_stack_target}
Description: ${p.description ?? "(none)"}
Reference URLs:
${refs || "  (none)"}
Existing site to fix: ${p.existing_site_url ?? "(n/a)"}
Intake notes: ${p.intake_notes ?? "(none)"}
--- END PROJECT ---`;
}

function eligible(agent: any): { ok: true } | { ok: false; reason: string; markFailure: boolean; status: number; code: string } {
  if (!agent) return { ok: false, reason: "Agent missing", markFailure: true, status: 500, code: "missing" };
  if (!agent.enabled) return { ok: false, reason: `${agent.name} is disabled`, markFailure: false, status: 409, code: "disabled" };
  if (agent.status === "paused") return { ok: false, reason: `${agent.name} is paused`, markFailure: false, status: 409, code: "paused" };
  if (agent.status === "off") return { ok: false, reason: `${agent.name} is off`, markFailure: false, status: 409, code: "off" };
  if (agent.status === "budget_paused") return { ok: false, reason: `${agent.name} is budget-paused`, markFailure: false, status: 409, code: "budget_paused" };
  return { ok: true };
}

function throwIfError(result: Awaited<ReturnType<typeof callAnthropic>>) {
  if ("error" in result) {
    const nonFailure =
      result.code === "budget_paused" ||
      result.code === "disabled" ||
      result.code === "off" ||
      result.code === "prompt_budget_warning";
    throw new AgentStepError(result.error, {
      code: result.code,
      status: result.status ?? 502,
      markFailure: !nonFailure,
    });
  }
  return result;
}

async function getNextRoadmapPrompt(svc: ReturnType<typeof getServiceClient>, projectId: string) {
  const { data: deliveredPrompts } = await svc
    .from("lovable_prompts")
    .select("sequence_number,status")
    .eq("project_id", projectId)
    .in("status", ["delivered", "implemented"])
    .order("sequence_number", { ascending: true });

  const completed = new Set((deliveredPrompts ?? []).map((p: any) => Number(p.sequence_number)));
  const nextSequence = ASTROGUIDE_PROMPT_ORDER.findIndex((_, index) => !completed.has(index + 1)) + 1;
  const resolvedSequence = nextSequence > 0 ? nextSequence : ASTROGUIDE_PROMPT_ORDER.length + 1;

  return {
    nextSequence: resolvedSequence,
    nextTitle: roadmapLine(resolvedSequence),
    completedSequences: Array.from(completed).sort((a, b) => a - b),
  };
}

async function executeSequentialCycle(args: {
  svc: ReturnType<typeof getServiceClient>;
  apiKey: string;
  projectId: string;
  project: Project;
  trigger: CycleTrigger;
  retryAgentId?: string | null;
}): Promise<CycleResult> {
  const { svc, apiKey, projectId, project, trigger, retryAgentId } = args;
  const ctx = buildProjectContext(project);
  const roleOrder = ["research_lead", "content_writer", "qa_auditor", "lead_architect"] as const;
  const { data: agents } = await svc.from("agents").select("*").order("sort_order");
  const claire = agents?.find((a: any) => a.role === "research_lead");
  const olivia = agents?.find((a: any) => a.role === "content_writer");
  const sophia = agents?.find((a: any) => a.role === "qa_auditor");
  const ethan = agents?.find((a: any) => a.role === "lead_architect");

  if (!claire || !olivia || !sophia || !ethan) {
    return { ok: false, error: "Agents not seeded. Visit setup.", status: 400, code: "agents_missing", level: "error" };
  }

  const participating = [claire, olivia, sophia, ethan];
  const roadmap = await getNextRoadmapPrompt(svc, projectId);
  const retryAgent = trigger === "retry_failed"
    ? participating.find((agent: any) => agent.id === retryAgentId) ?? null
    : null;

  if (trigger === "retry_failed" && !retryAgent) {
    return { ok: false, error: "Retry target missing or invalid.", status: 400, code: "retry_target_missing", level: "error" };
  }

  const startIndex = retryAgent ? roleOrder.indexOf(retryAgent.role as typeof roleOrder[number]) : 0;
  const shouldRun = (role: typeof roleOrder[number]) => roleOrder.indexOf(role) >= startIndex;
  const alreadyWorking = participating.find((a: any) => a.status === "working");
  if (alreadyWorking) {
    return {
      ok: false,
      error: `${alreadyWorking.name} is currently working. Wait for them to finish before triggering another cycle.`,
      status: 409,
      code: "agent_busy",
      agentName: alreadyWorking.name,
      agentId: alreadyWorking.id,
      markedFailure: false,
      level: "warn",
    };
  }

  await logActivity(svc, {
    projectId,
    agentName: "System",
    message: retryAgent
      ? `Retry cycle started from ${retryAgent.name}.`
      : `Sequential cycle started — trigger: ${trigger}.`,
  });

  for (const agent of participating.slice(startIndex)) {
    await clearAgentFailure(svc, agent.id);
  }

  if (shouldRun("research_lead")) {
    const claireEligibility = eligible(claire);
    if (claireEligibility.ok) {
    const claireStep = await runAgentTask(svc, {
      agentId: claire.id,
      agentName: claire.name,
      projectId,
      functionName: "run-cycle:claire",
      currentTask: `Analyzing references for ${project.name}…`,
      work: async () => {
        await logActivity(svc, { projectId, agentId: claire.id, agentName: claire.name, message: "Starting research pass." });
        const prevPrompts = await svc.from("lovable_prompts").select("sequence_number,title").eq("project_id", projectId).order("sequence_number");
        const completed = (prevPrompts.data ?? []).map((p: any) => `#${p.sequence_number} ${p.title}`).join("\n") || "(none yet)";
        const result = throwIfError(await callAnthropic({
          agentId: claire.id,
          projectId,
          model: claire.model,
          system: claire.base_system_prompt + "\n\n" + ctx,
          messages: [{ role: "user", content: `Produce a structured research brief for the NEXT slice of work on this project.

Already-delivered prompts:
${completed}

Output strict markdown with these sections:
## Focus area for next slice
(One paragraph: which feature or flow Ethan should build next, and why it's the right next step.)

## Reference site patterns
(Bulleted list of 6-12 specific patterns/features/flows observed on the reference URLs that apply to this slice. Describe behavior, not copy.)

${project.mode === "fix_existing" ? `## Gap analysis vs existing site
(Bulleted list of 4-8 specific things missing or wrong on the existing site relative to the references.)` : ""}

## Components & states
(Bulleted list of UI components and their states relevant to this slice.)

## Data & API
(Tables, fields, edge functions, third-party APIs needed.)

## Acceptance criteria
(Numbered list of 5-8 testable criteria for \"done\".)

Be specific. No filler. Stay under 1200 words.` }],
          maxTokens: 3000,
          callType: "research",
          apiKey,
          svc,
        }));
        await svc.from("research_findings").insert({
          project_id: projectId,
          agent_id: claire.id,
          category: "next_slice_brief",
          title: `Research brief — ${new Date().toISOString().slice(0, 10)}`,
          content_md: result.text,
        });
        await logActivity(svc, { projectId, agentId: claire.id, agentName: claire.name, message: `Research brief filed (${result.inputTokens + result.outputTokens} tokens, $${result.cost.toFixed(4)}). Sleeping.` });
      },
    });
      if (!claireStep.ok) {
        return {
          ok: false,
          error: claireStep.failure.message,
          status: claireStep.status,
          code: claireStep.code,
          agentName: claire.name,
          agentId: claire.id,
          markedFailure: claireStep.markedFailure,
          level: claireStep.markedFailure ? "error" : "warn",
        };
      }
    } else {
      await logActivity(svc, { projectId, agentId: claire.id, agentName: claire.name, level: "warn", message: `Skipped Claire: ${claireEligibility.reason}.` });
      if (claireEligibility.markFailure) {
        return { ok: false, error: claireEligibility.reason, status: claireEligibility.status, code: claireEligibility.code, agentName: claire.name, agentId: claire.id, markedFailure: true, level: "error" };
      }
      return { ok: false, error: claireEligibility.reason, status: claireEligibility.status, code: claireEligibility.code, agentName: claire.name, agentId: claire.id, markedFailure: false, level: "warn" };
    }
  }

  if (trigger === "research_only") {
    await logActivity(svc, { projectId, agentName: "System", message: "Research-only cycle complete." });
    return { ok: true, type: "research_only" };
  }

  // ────────────────────────────────────────────────────────────────────
  // STEP HELPERS (Olivia + Sophia) — used by initial run AND revision rounds.
  // Returning a structured failure lets the outer loop short-circuit.
  // ────────────────────────────────────────────────────────────────────

  type StepFailure = Extract<CycleResult, { ok: false }>;

  const runOliviaStep = async (revisionContext: string | null): Promise<StepFailure | null> => {
    const eligibility = eligible(olivia);
    if (!eligibility.ok) {
      await logActivity(svc, { projectId, agentId: olivia.id, agentName: olivia.name, level: "warn", message: `Skipped Olivia: ${eligibility.reason}.` });
      return { ok: false, error: eligibility.reason, status: eligibility.status, code: eligibility.code, agentName: olivia.name, agentId: olivia.id, markedFailure: eligibility.markFailure, level: eligibility.markFailure ? "error" : "warn" };
    }
    const step = await runAgentTask(svc, {
      agentId: olivia.id,
      agentName: olivia.name,
      projectId,
      functionName: "run-cycle:olivia",
      currentTask: revisionContext ? `Revising copy for ${project.name}…` : `Drafting copy for ${project.name}…`,
      work: async () => {
        await logActivity(svc, { projectId, agentId: olivia.id, agentName: olivia.name, message: revisionContext ? "Revising copy with Sophia's feedback." : "Drafting copy based on Claire's brief." });
        const { data: latestBrief } = await svc.from("research_findings").select("content_md").eq("project_id", projectId).order("created_at", { ascending: false }).limit(1).maybeSingle();
        if (!latestBrief?.content_md) {
          throw new AgentStepError("Claire output missing. No research brief was available for Olivia.", { code: "missing_claire_output", status: 502 });
        }
        const result = throwIfError(await callAnthropic({
          agentId: olivia.id,
          projectId,
          model: olivia.model,
          system: olivia.base_system_prompt + "\n\n" + ctx,
          messages: [{ role: "user", content: `Write user-facing copy for the next slice of work, based on Claire's research brief below.

# Research brief
${latestBrief.content_md}
${revisionContext ? `\n# Sophia's revision feedback (you MUST incorporate this)\n${revisionContext}\n` : ""}
Output strict markdown:
## Headlines & subheads
(3-6 short, on-brand options for the main screens of this slice.)

## Body copy
(Paragraphs / bullets for any informational sections introduced by this slice.)

## Microcopy
(Buttons, labels, empty states, error messages, tooltips, toast messages.)

## Tone notes
(1-3 bullets reminding Ethan how to keep voice consistent.)

Be concise. Match the tone implied by the project description and reference sites. Stay under 800 words.` }],
          maxTokens: 2000,
          callType: revisionContext ? "copy_revision" : "copy",
          apiKey,
          svc,
        }));
        await svc.from("content_drafts").insert({
          project_id: projectId,
          agent_id: olivia.id,
          category: revisionContext ? "next_slice_copy_revision" : "next_slice_copy",
          title: `Copy draft — ${new Date().toISOString().slice(0, 10)}${revisionContext ? " (revised)" : ""}`,
          content_md: result.text,
        });
        await logActivity(svc, { projectId, agentId: olivia.id, agentName: olivia.name, message: `Copy ${revisionContext ? "revision" : "draft"} filed ($${result.cost.toFixed(4)}). Sleeping.` });
      },
    });
    if (!step.ok) {
      return { ok: false, error: step.failure.message, status: step.status, code: step.code, agentName: olivia.name, agentId: olivia.id, markedFailure: step.markedFailure, level: step.markedFailure ? "error" : "warn" };
    }
    return null;
  };

  const runClaireRevisionStep = async (revisionContext: string): Promise<StepFailure | null> => {
    const eligibility = eligible(claire);
    if (!eligibility.ok) {
      await logActivity(svc, { projectId, agentId: claire.id, agentName: claire.name, level: "warn", message: `Skipped Claire revision: ${eligibility.reason}.` });
      return { ok: false, error: eligibility.reason, status: eligibility.status, code: eligibility.code, agentName: claire.name, agentId: claire.id, markedFailure: eligibility.markFailure, level: eligibility.markFailure ? "error" : "warn" };
    }
    const step = await runAgentTask(svc, {
      agentId: claire.id,
      agentName: claire.name,
      projectId,
      functionName: "run-cycle:claire-revision",
      currentTask: `Revising research brief for ${project.name}…`,
      work: async () => {
        await logActivity(svc, { projectId, agentId: claire.id, agentName: claire.name, message: "Revising research brief with Sophia's feedback." });
        const { data: prevBrief } = await svc.from("research_findings").select("content_md").eq("project_id", projectId).order("created_at", { ascending: false }).limit(1).maybeSingle();
        const prevPrompts = await svc.from("lovable_prompts").select("sequence_number,title").eq("project_id", projectId).order("sequence_number");
        const completed = (prevPrompts.data ?? []).map((p: any) => `#${p.sequence_number} ${p.title}`).join("\n") || "(none yet)";
        const result = throwIfError(await callAnthropic({
          agentId: claire.id,
          projectId,
          model: claire.model,
          system: claire.base_system_prompt + "\n\n" + ctx,
          messages: [{ role: "user", content: `Sophia's QA flagged your previous research brief as needing revision. Produce a REVISED brief that fully addresses her feedback.

Already-delivered prompts:
${completed}

# Your previous brief
${prevBrief?.content_md ?? "(no prior brief found)"}

# Sophia's revision feedback (you MUST address every point)
${revisionContext}

Re-produce the full structured brief with the same sections (Focus area, Reference site patterns, ${project.mode === "fix_existing" ? "Gap analysis vs existing site, " : ""}Components & states, Data & API, Acceptance criteria). Stay under 1200 words.` }],
          maxTokens: 3000,
          callType: "research_revision",
          apiKey,
          svc,
        }));
        await svc.from("research_findings").insert({
          project_id: projectId,
          agent_id: claire.id,
          category: "next_slice_brief_revision",
          title: `Research brief — ${new Date().toISOString().slice(0, 10)} (revised)`,
          content_md: result.text,
        });
        await logActivity(svc, { projectId, agentId: claire.id, agentName: claire.name, message: `Research brief revision filed ($${result.cost.toFixed(4)}). Sleeping.` });
      },
    });
    if (!step.ok) {
      return { ok: false, error: step.failure.message, status: step.status, code: step.code, agentName: claire.name, agentId: claire.id, markedFailure: step.markedFailure, level: step.markedFailure ? "error" : "warn" };
    }
    return null;
  };

  // Sophia step. Returns the parsed verdict so the outer loop can decide what to do next.
  type SophiaVerdict = {
    verdict: "PASS" | "PASS_WITH_NOTES" | "NEEDS_REVISION";
    revisionTargets: Array<"claire" | "olivia">;
    revisionNotes: string;
    findingsMd: string;
    revisionRound: number;
  };

  const runSophiaStep = async (revisionRound: number): Promise<{ failure: StepFailure } | { verdict: SophiaVerdict }> => {
    const eligibility = eligible(sophia);
    if (!eligibility.ok) {
      await logActivity(svc, { projectId, agentId: sophia.id, agentName: sophia.name, level: "warn", message: `Skipped Sophia: ${eligibility.reason}.` });
      return { failure: { ok: false, error: eligibility.reason, status: eligibility.status, code: eligibility.code, agentName: sophia.name, agentId: sophia.id, markedFailure: eligibility.markFailure, level: eligibility.markFailure ? "error" : "warn" } };
    }

    let parsed: SophiaVerdict | null = null;
    const step = await runAgentTask(svc, {
      agentId: sophia.id,
      agentName: sophia.name,
      projectId,
      functionName: "run-cycle:sophia",
      currentTask: revisionRound > 0 ? `Re-auditing (round ${revisionRound}) for ${project.name}…` : `Auditing brief & copy for ${project.name}…`,
      work: async () => {
        await logActivity(svc, { projectId, agentId: sophia.id, agentName: sophia.name, message: revisionRound > 0 ? `Re-auditing artifacts (revision round ${revisionRound}).` : "Auditing latest research brief and copy." });
        const { data: latestBrief } = await svc.from("research_findings").select("content_md,title").eq("project_id", projectId).order("created_at", { ascending: false }).limit(1).maybeSingle();
        if (!latestBrief?.content_md) {
          throw new AgentStepError("Claire output missing. Sophia could not find the latest research brief.", { code: "missing_claire_output", status: 502 });
        }
        const { data: latestCopy } = await svc.from("content_drafts").select("content_md").eq("project_id", projectId).order("created_at", { ascending: false }).limit(1).maybeSingle();
        if (trigger !== "continue_research" && !latestCopy?.content_md) {
          throw new AgentStepError("Olivia output missing. Sophia could not find the latest copy draft.", { code: "missing_olivia_output", status: 502 });
        }
        const result = throwIfError(await callAnthropic({
          agentId: sophia.id,
          projectId,
          model: sophia.model,
          system: sophia.base_system_prompt + "\n\n" + ctx,
          messages: [{ role: "user", content: `Audit the research brief AND the copy draft for completeness, accuracy, and gaps. Be terse.

This is revision round ${revisionRound} (0 = first audit, 1-3 = re-audits after revision).

# Research brief
${latestBrief.content_md}

# Copy draft
${latestCopy?.content_md ?? "(no copy found)"}

Output strict markdown with EXACTLY these sections, in this order:

## Verdict
(one of: PASS / PASS_WITH_NOTES / NEEDS_REVISION)

## Revision targets
(Required ONLY when verdict is NEEDS_REVISION. A comma-separated list of which agent must revise: claire, olivia, or both. If verdict is PASS or PASS_WITH_NOTES, write "none".)

## Revision notes
(Required ONLY when verdict is NEEDS_REVISION. Detailed, actionable feedback grouped per agent — e.g. "FOR CLAIRE: ..." then "FOR OLIVIA: ...". Each instruction must be specific enough that the agent can act on it without further clarification. If verdict is PASS or PASS_WITH_NOTES, write "n/a".)

## Strengths
(2-4 bullets)

## Gaps & corrections
(0-6 bullets — be specific, cite which artifact each gap belongs to)

## Approved acceptance criteria
(Restate the final, validated AC list as numbered items. Required for PASS / PASS_WITH_NOTES; for NEEDS_REVISION, restate the in-progress AC list.)

IMPORTANT: only mark NEEDS_REVISION when there are concrete blocking issues. Cosmetic preferences = PASS_WITH_NOTES. Do not exceed revision round 3 unless absolutely necessary; this is round ${revisionRound}.` }],
          maxTokens: 1500,
          callType: revisionRound > 0 ? "qa_reaudit" : "qa",
          apiKey,
          svc,
        }));
        const findingsMd = result.text;
        const verdictMatch = findingsMd.match(/##\s*Verdict\s*\n+([A-Z_]+)/);
        const rawVerdict = (verdictMatch ? verdictMatch[1] : "PASS").toUpperCase();
        const verdict: SophiaVerdict["verdict"] = rawVerdict === "NEEDS_REVISION" || rawVerdict === "PASS_WITH_NOTES" ? rawVerdict : "PASS";

        // Parse revision targets section.
        const targetsMatch = findingsMd.match(/##\s*Revision targets\s*\n+([^\n#]+)/i);
        const targetsRaw = (targetsMatch ? targetsMatch[1] : "").toLowerCase();
        const revisionTargets: Array<"claire" | "olivia"> = [];
        if (verdict === "NEEDS_REVISION") {
          if (targetsRaw.includes("both")) {
            revisionTargets.push("claire", "olivia");
          } else {
            if (targetsRaw.includes("claire")) revisionTargets.push("claire");
            if (targetsRaw.includes("olivia")) revisionTargets.push("olivia");
          }
          // Default fallback: if NEEDS_REVISION but no parseable target, send to Claire (root cause first).
          if (revisionTargets.length === 0) revisionTargets.push("claire");
        }

        // Parse revision notes section (everything between "## Revision notes" and the next "## ").
        const notesMatch = findingsMd.match(/##\s*Revision notes\s*\n+([\s\S]*?)(?=\n##\s|\s*$)/i);
        const revisionNotes = (notesMatch ? notesMatch[1] : "").trim();

        await svc.from("qa_reports").insert({
          project_id: projectId,
          agent_id: sophia.id,
          target_type: trigger === "continue_research" ? "research_brief" : "brief_and_copy",
          verdict,
          findings_md: findingsMd,
        });
        const verdictMsg = verdict === "NEEDS_REVISION"
          ? `QA verdict: NEEDS_REVISION (round ${revisionRound + 1}, targets: ${revisionTargets.join(", ")}) ($${result.cost.toFixed(4)}).`
          : `QA verdict: ${verdict} ($${result.cost.toFixed(4)}). Sleeping.`;
        await logActivity(svc, { projectId, agentId: sophia.id, agentName: sophia.name, message: verdictMsg });

        parsed = { verdict, revisionTargets, revisionNotes, findingsMd, revisionRound };
      },
    });
    if (!step.ok) {
      return { failure: { ok: false, error: step.failure.message, status: step.status, code: step.code, agentName: sophia.name, agentId: sophia.id, markedFailure: step.markedFailure, level: step.markedFailure ? "error" : "warn" } };
    }
    return { verdict: parsed! };
  };

  // ────────────────────────────────────────────────────────────────────
  // OLIVIA — first run (skipped on retries that start later in the chain
  // and on continue_research passes).
  // ────────────────────────────────────────────────────────────────────

  if (trigger !== "continue_research" && shouldRun("content_writer")) {
    const failure = await runOliviaStep(null);
    if (failure) return failure;
  }

  // ────────────────────────────────────────────────────────────────────
  // SOPHIA — first audit, then revision loop (max 3 rounds).
  // ────────────────────────────────────────────────────────────────────

  const MAX_REVISION_ROUNDS = 3;
  let sophiaResult: SophiaVerdict | null = null;

  if (shouldRun("qa_auditor")) {
    let round = 0;
    while (true) {
      const sophiaOutcome = await runSophiaStep(round);
      if ("failure" in sophiaOutcome) return sophiaOutcome.failure;
      sophiaResult = sophiaOutcome.verdict;
      if (sophiaResult.verdict !== "NEEDS_REVISION") break;
      if (round >= MAX_REVISION_ROUNDS) {
        // Escalate to human — do NOT auto-deliver to Ethan.
        await logActivity(svc, {
          projectId,
          agentName: "System",
          level: "warn",
          message: `Hit ${MAX_REVISION_ROUNDS} revision rounds without convergence. Escalating to human for decision.`,
          metadata: { escalation: true, revision_targets: sophiaResult.revisionTargets },
        });
        return { ok: true, type: "research_pass" };
      }
      round += 1;
      await logActivity(svc, {
        projectId,
        agentName: "System",
        message: `Looping back for revision round ${round} — targets: ${sophiaResult.revisionTargets.join(", ")}.`,
      });

      // Re-run targeted agents with Sophia's notes.
      const targets = sophiaResult.revisionTargets;
      if (targets.includes("claire")) {
        const failure = await runClaireRevisionStep(sophiaResult.revisionNotes);
        if (failure) return failure;
      }
      if (targets.includes("olivia") && trigger !== "continue_research") {
        const failure = await runOliviaStep(sophiaResult.revisionNotes);
        if (failure) return failure;
      }
      // Loop continues — Sophia re-audits the freshly-revised artifacts.
    }
  }

  if (trigger === "continue_research") {
    await logActivity(svc, { projectId, agentName: "System", message: "Research-pass cycle complete. Team sleeping." });
    return { ok: true, type: "research_pass" };
  }

  // Final guard: only run Ethan on a clean PASS / PASS_WITH_NOTES verdict.
  if (sophiaResult && sophiaResult.verdict === "NEEDS_REVISION") {
    await logActivity(svc, { projectId, agentName: "System", level: "warn", message: "Skipping Ethan — QA never reached PASS." });
    return { ok: true, type: "research_pass" };
  }

  // ────────────────────────────────────────────────────────────────────
  // ETHAN — drafts the final Lovable prompt.
  // ────────────────────────────────────────────────────────────────────

  const ethanEligibility = eligible(ethan);
  if (ethanEligibility.ok) {
    const ethanStep = await runAgentTask(svc, {
      agentId: ethan.id,
      agentName: ethan.name,
      projectId,
      functionName: "run-cycle:ethan",
      currentTask: `Drafting next prompt for ${project.name}…`,
      work: async () => {
        const { data: lastPrompts } = await svc.from("lovable_prompts").select("sequence_number,title,content_md,status").eq("project_id", projectId).order("sequence_number", { ascending: false }).limit(5);
        const nextSeq = roadmap.nextSequence;
        const expectedTitle = roadmap.nextTitle;
        const { data: brief } = await svc.from("research_findings").select("content_md").eq("project_id", projectId).order("created_at", { ascending: false }).limit(1).maybeSingle();
        const { data: copy } = await svc.from("content_drafts").select("content_md").eq("project_id", projectId).order("created_at", { ascending: false }).limit(1).maybeSingle();
        const { data: qa } = await svc.from("qa_reports").select("findings_md,verdict").eq("project_id", projectId).order("created_at", { ascending: false }).limit(1).maybeSingle();
        if (!expectedTitle) {
          throw new AgentStepError("Roadmap is complete. No further prompts should be generated.", { code: "roadmap_complete", status: 409, markFailure: false });
        }
        if (!brief?.content_md) throw new AgentStepError("Claire output missing. Ethan could not find the latest research brief.", { code: "missing_claire_output", status: 502 });
        if (!copy?.content_md) throw new AgentStepError("Olivia output missing. Ethan could not find the latest copy draft.", { code: "missing_olivia_output", status: 502 });
        if (!qa?.findings_md) throw new AgentStepError("Sophia output missing. Ethan could not find the latest QA report.", { code: "missing_sophia_output", status: 502 });
        const priorSummary = (lastPrompts ?? []).reverse().map((p: any) => `### Prompt #${p.sequence_number} — ${p.title}\n(already delivered)`).join("\n");
        await logActivity(svc, { projectId, agentId: ethan.id, agentName: ethan.name, message: `Drafting Prompt #${nextSeq}.` });
        const result = throwIfError(await callAnthropic({
          agentId: ethan.id,
          projectId,
          model: ethan.model,
          system: `${ethan.base_system_prompt}\n\n${ASTROGUIDE_ROADMAP}\n\n${ctx}`,
          messages: [{ role: "user", content: `Produce LOVABLE PROMPT #${nextSeq} for this project. The user will paste it as-is into a separate Lovable project.

# Prior delivered prompts
${priorSummary || "(none — this is the first prompt)"}

# Authoritative roadmap checkpoint
The next required roadmap item is Prompt #${nextSeq}: ${expectedTitle}
Completed prompts so far: ${roadmap.completedSequences.length > 0 ? roadmap.completedSequences.map((n) => `#${n}`).join(", ") : "none"}
Do not skip ahead. Do not invent missing completed work. Do not duplicate an earlier scope.

# Latest research brief from Claire
${brief.content_md}

# Latest copy draft from Olivia
${copy.content_md}

# Sophia's QA verdict
${qa.verdict ?? "PASS"}
${qa.findings_md}

Now write the prompt for Prompt #${nextSeq}: ${expectedTitle}. CRITICAL: output a natural-language Lovable specification, not literal code. Do NOT include full TypeScript files, React components, SQL migrations, or Edge Function bodies.

Format STRICTLY as follows:

# TITLE
(One line: "Prompt #${nextSeq}: ${expectedTitle}")

# CONTEXT
(2-3 sentences reminding the recipient what's been built so far and what this slice adds.)

# DEPENDENCIES
(Bullet list of prior prompt numbers this depends on, or "None" if first.)

# WHAT TO BUILD
(Numbered list of concrete deliverables — components, routes, data model changes, backend capabilities, integrations. Describe them in plain English. Mention file or route locations only when helpful, not as code scaffolding.)

# IMPLEMENTATION DETAILS
(Detailed instructions sufficient for the recipient to implement without ambiguity, but expressed as prose, concise tables, business rules, validation rules, and named technical patterns. If database changes are needed, describe the schema in words or a compact column/type/purpose table instead of full SQL, unless a tiny exact snippet is unavoidable. If backend changes are needed, describe endpoint purpose plus input/output shape instead of full function bodies. If UI changes are needed, describe layout, fields, states, validation, and interactions instead of JSX. Use Olivia's copy for any user-facing text.)

# ACCEPTANCE CRITERIA
(Numbered, testable list — ALL must pass for this slice to be considered done.)

# OUT OF SCOPE
(Bullet list of explicitly deferred items.)

The prompt must be entirely self-contained and must stay in natural language. Short exact snippets are allowed only when precision is critical, and never for more than ~10 lines at a time.

Before finalizing, verify that the title and scope exactly match Prompt #${nextSeq}: ${expectedTitle}. If not, rewrite it before responding.` }],
          maxTokens: 6000,
          callType: "prompt",
          apiKey,
          svc,
        }));
        const title = `Prompt #${nextSeq}: ${expectedTitle}`.slice(0, 200);
        const { data: insertedPrompt, error: insertError } = await svc.from("lovable_prompts").insert({
          project_id: projectId,
          sequence_number: nextSeq,
          title,
          status: "ready",
          content_md: result.text,
          created_by_agent_id: ethan.id,
        }).select().single();
        if (insertError) {
          throw new AgentStepError(`Failed to save Prompt #${nextSeq}: ${insertError.message}`, { code: "prompt_insert_failed", status: 500 });
        }
        await logActivity(svc, { projectId, agentId: ethan.id, agentName: ethan.name, message: `Delivered Prompt #${nextSeq} — "${title}" ($${result.cost.toFixed(4)}). Sleeping.`, metadata: { prompt_id: insertedPrompt?.id } });
      },
    });
    if (!ethanStep.ok) {
      return {
        ok: false,
        error: ethanStep.failure.message,
        status: ethanStep.status,
        code: ethanStep.code,
        agentName: ethan.name,
        agentId: ethan.id,
        markedFailure: ethanStep.markedFailure,
        level: ethanStep.markedFailure ? "error" : "warn",
      };
    }
  } else {
    await logActivity(svc, { projectId, agentId: ethan.id, agentName: ethan.name, level: "warn", message: `Skipped Ethan: ${ethanEligibility.reason}.` });
    if (ethanEligibility.markFailure) {
      return { ok: false, error: ethanEligibility.reason, status: ethanEligibility.status, code: ethanEligibility.code, agentName: ethan.name, agentId: ethan.id, markedFailure: true, level: "error" };
    }
    return { ok: false, error: ethanEligibility.reason, status: ethanEligibility.status, code: ethanEligibility.code, agentName: ethan.name, agentId: ethan.id, markedFailure: false, level: "warn" };
  }

  await logActivity(svc, { projectId, agentName: "System", message: "Cycle complete. All agents sleeping. Deliver the current prompt to continue the chain." });
  return { ok: true, type: "full_cycle" };
}

async function recoverStuckAgents(
  svc: ReturnType<typeof getServiceClient>,
  projectId: string,
  agents: Array<{ id: string; name: string; status: string; current_task?: string | null; updated_at?: string }>,
) {
  const now = Date.now();
  const stale = agents.filter((agent) => {
    if (agent.status !== "working" || !agent.updated_at) return false;
    return now - new Date(agent.updated_at).getTime() > 60_000;
  });

  for (const agent of stale) {
    await Promise.allSettled([
      markRecoveredAgent(svc, projectId, agent.id, agent.name, agent.current_task ?? null),
      settleAgentStatus(svc, agent.id),
    ]);
  }

  return stale;
}

async function markRecoveredAgent(
  svc: ReturnType<typeof getServiceClient>,
  projectId: string,
  agentId: string,
  agentName: string,
  currentTask: string | null,
) {
  const message = `${agentName} was auto-recovered after getting stuck in working state${currentTask ? ` during: ${currentTask}` : ""}.`;
  await Promise.allSettled([
    svc.from("errors").insert({
      project_id: projectId,
      agent_id: agentId,
      function_name: "run-cycle:stuck-recovery",
      error_message: message,
      stack_trace: null,
    }),
    svc.from("agents").update({
      failure_flag: true,
      last_error_message: message,
      last_failed_at: new Date().toISOString(),
      current_task: null,
    }).eq("id", agentId),
    logActivity(svc, {
      projectId,
      agentId,
      agentName,
      level: "error",
      message,
    }),
  ]);
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });

  try {
    const auth = req.headers.get("Authorization");
    const ownerCheck = await requireOwner(auth);
    if (ownerCheck instanceof Response) return ownerCheck;

    const { projectId, trigger, agentId } = await req.json();
    if (!projectId || !trigger) {
      return jsonResponse({ ok: false, error: "projectId and trigger required" });
    }

    const svc = getServiceClient();
    const apiKey = await loadAnthropicKey(svc);
    if (!apiKey) {
      return jsonResponse({ ok: false, error: "Anthropic key not configured. Visit /admin/settings." });
    }

    const { data: project } = await svc.from("projects").select("*").eq("id", projectId).single();
    if (!project) {
      return jsonResponse({ ok: false, error: "Project not found" });
    }
    if ((project as any).status !== "active") {
      return jsonResponse({ ok: false, error: `This project is ${(project as any).status}. Resume it to active to run agents.` });
    }

    const { data: agents } = await svc.from("agents").select("id,name,role,status,current_task,updated_at").order("sort_order");
    const participants = ["research_lead", "content_writer", "qa_auditor", "lead_architect"].map((role) =>
      agents?.find((agent: any) => agent.role === role)
    ).filter(Boolean) as Array<{ id: string; name: string; role: string; status: string }>;

    if (participants.length < 4) {
      return jsonResponse({ ok: false, error: "Agents not seeded. Visit setup." });
    }

    const recoveredAgents = await recoverStuckAgents(
      svc,
      projectId,
      participants as Array<{ id: string; name: string; status: string; current_task?: string | null; updated_at?: string }>,
    );

    const freshAgents = await svc.from("agents").select("id,name,role,status,current_task,updated_at").order("sort_order");
    const freshParticipants = ["research_lead", "content_writer", "qa_auditor", "lead_architect"].map((role) =>
      freshAgents.data?.find((agent: any) => agent.role === role)
    ).filter(Boolean) as Array<{ id: string; name: string; role: string; status: string }>;

    const alreadyWorking = freshParticipants.find((agent) => agent.status === "working");
    if (alreadyWorking) {
      return jsonResponse({
        ok: false,
        error: `${alreadyWorking.name} is currently working. Wait for them to finish before triggering another cycle.`,
        agent: alreadyWorking.name,
        code: "agent_busy",
        recovered: recoveredAgents.map((agent) => agent.name),
      });
    }

    const runner = executeSequentialCycle({
      svc,
      apiKey,
      projectId,
      project: project as Project,
      trigger: trigger as CycleTrigger,
      retryAgentId: agentId ?? null,
    }).then(async (result) => {
      if (result.ok) return;

      await logActivity(svc, {
        projectId,
        agentId: result.agentId ?? null,
        agentName: "System",
        level: result.level ?? (result.markedFailure ? "error" : "warn"),
        message: result.agentName
          ? `Cycle stopped at ${result.agentName}: ${result.error}`
          : `Cycle failed: ${result.error}`,
        metadata: result.code ? { code: result.code } : {},
      });

      if (!result.agentId) {
        const failure = normalizeError(result.error);
        await svc.from("errors").insert({
          project_id: projectId,
          function_name: "run-cycle",
          error_message: failure.message,
          stack_trace: failure.stack ?? null,
        });
      }
    }).catch(async (error) => {
      const failure = normalizeError(error);
      await Promise.allSettled([
        svc.from("errors").insert({
          project_id: projectId,
          function_name: "run-cycle:background",
          error_message: failure.message,
          stack_trace: failure.stack ?? null,
        }),
        logActivity(svc, {
          projectId,
          agentName: "System",
          level: "error",
          message: `Workflow crashed: ${failure.message}`,
        }),
      ]);
    });

    EdgeRuntime.waitUntil(runner);

    const message =
      trigger === "continue_research"
        ? "Research pass started."
        : trigger === "retry_failed"
        ? "Agent retry started."
        : trigger === "kick_off"
        ? "First workflow started."
        : "Workflow started.";

    return jsonResponse({ ok: true, accepted: true, message, recovered: recoveredAgents.map((agent) => agent.name) }, 202);
  } catch (e) {
    return jsonResponse({ ok: false, error: `Server error: ${e instanceof Error ? e.message : String(e)}` });
  }
});
