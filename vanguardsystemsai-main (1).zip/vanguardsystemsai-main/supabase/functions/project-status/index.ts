// project-status: server-side project lifecycle changes.
// Force-reopen a 'complete' project requires the password (2828).
// Other transitions (active <-> paused, active -> complete) are owner-only and don't need a password.
//
// Body: { projectId: string, action: "force_reopen" | "set_status", status?: ProjectStatus, password?: string }
import {
  corsHeaders,
  errorResponse,
  jsonResponse,
  requireOwner,
  getServiceClient,
  logActivity,
} from "../_shared/anthropic.ts";

// In-memory rate-limit per owner (resets when the function instance recycles).
const FORCE_REOPEN_PASSWORD = "2828";
const MAX_ATTEMPTS = 3;
const LOCKOUT_MS = 60_000;

interface AttemptRecord {
  count: number;
  lockedUntil: number; // epoch ms; 0 means not locked
}
const attempts = new Map<string, AttemptRecord>();

function getRecord(key: string): AttemptRecord {
  let r = attempts.get(key);
  if (!r) {
    r = { count: 0, lockedUntil: 0 };
    attempts.set(key, r);
  }
  // Expire lockout
  if (r.lockedUntil && Date.now() > r.lockedUntil) {
    r.count = 0;
    r.lockedUntil = 0;
  }
  return r;
}

const ALLOWED_STATUSES = new Set(["active", "paused", "complete", "archived"]);

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });
  try {
    const auth = req.headers.get("Authorization");
    const ownerCheck = await requireOwner(auth);
    if (ownerCheck instanceof Response) return ownerCheck;
    const { userId } = ownerCheck;

    const body = await req.json().catch(() => ({}));
    const { projectId, action, status, password } = body ?? {};

    if (!projectId || typeof projectId !== "string") {
      return errorResponse("projectId required", 400);
    }
    if (action !== "force_reopen" && action !== "set_status") {
      return errorResponse("action must be 'force_reopen' or 'set_status'", 400);
    }

    const svc = getServiceClient();
    const { data: project } = await svc
      .from("projects")
      .select("id,name,status")
      .eq("id", projectId)
      .single();
    if (!project) return errorResponse("Project not found", 404);

    if (action === "force_reopen") {
      const rec = getRecord(userId);
      if (rec.lockedUntil && Date.now() < rec.lockedUntil) {
        const secondsLeft = Math.ceil((rec.lockedUntil - Date.now()) / 1000);
        return errorResponse(`Too many attempts — try again in ${secondsLeft}s`, 429, {
          lockedUntil: rec.lockedUntil,
        });
      }
      if (typeof password !== "string" || password.length === 0) {
        return errorResponse("password required", 400);
      }
      if (password !== FORCE_REOPEN_PASSWORD) {
        rec.count += 1;
        const remaining = MAX_ATTEMPTS - rec.count;
        if (rec.count >= MAX_ATTEMPTS) {
          rec.lockedUntil = Date.now() + LOCKOUT_MS;
          rec.count = 0;
          return errorResponse("Too many attempts — try again in 60s", 429, {
            lockedUntil: rec.lockedUntil,
          });
        }
        return errorResponse("Incorrect password", 401, { remaining });
      }
      // Correct password — reset attempts and reactivate.
      rec.count = 0;
      rec.lockedUntil = 0;

      const { error: updErr } = await svc
        .from("projects")
        .update({ status: "active" })
        .eq("id", projectId);
      if (updErr) return errorResponse(updErr.message, 500);

      await logActivity(svc, {
        projectId,
        agentName: "System",
        message: `Project force-reopened by owner. Status: ${project.status} → active.`,
      });
      return jsonResponse({ ok: true, status: "active" });
    }

    // action === "set_status"
    if (typeof status !== "string" || !ALLOWED_STATUSES.has(status)) {
      return errorResponse("Invalid status", 400);
    }
    // If a project is already 'complete', require force_reopen flow to leave 'complete'.
    if (project.status === "complete" && status !== "complete") {
      return errorResponse(
        "Completed projects must be reopened via force_reopen with the password.",
        409,
      );
    }

    const { error: updErr } = await svc
      .from("projects")
      .update({ status })
      .eq("id", projectId);
    if (updErr) return errorResponse(updErr.message, 500);

    await logActivity(svc, {
      projectId,
      agentName: "System",
      message: `Project status changed: ${project.status} → ${status}.`,
    });
    return jsonResponse({ ok: true, status });
  } catch (e) {
    return errorResponse(`Server error: ${String(e)}`, 500);
  }
});
