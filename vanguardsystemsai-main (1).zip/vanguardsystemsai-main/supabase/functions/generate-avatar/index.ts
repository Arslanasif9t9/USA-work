// Owner-only: generate a photorealistic professional headshot via fal.ai (flux/dev),
// upload to the agent-avatars storage bucket, and update agents.avatar_url.
// Logs spend in agent_spend (model = "fal-flux-dev", $0.025/image).
import { corsHeaders, errorResponse, jsonResponse, requireOwner, getServiceClient, decryptSecret, logActivity } from "../_shared/anthropic.ts";

// Per-agent prompt + model config. Some agents (Ethan) use the higher-fidelity
// flux/dev model for cinematic portraits; the rest use the open-access flux/schnell.
type AgentImageConfig = {
  prompt: string;
  model: "flux/dev" | "flux/schnell";
};

const AGENT_CONFIG: Record<string, AgentImageConfig> = {
  "Ethan Caldwell": {
    model: "flux/dev",
    prompt:
      "Ultra-sharp photorealistic close-up corporate portrait of a confident man in his mid-30s, Peaky Blinders inspired styling but modernized. No hat, no cap — bare head. Short slicked-back dark brown hair with tight tapered sides, clean shaven sharp jawline, defined cheekbones, piercing focused blue-grey eyes looking directly at camera, calm intense composed expression. Wearing a three-piece charcoal grey wool suit with matching waistcoat, crisp white collared shirt, dark silk tie. Crystal clear skin texture and facial detail, tack-sharp focus on the eyes, every pore and feature visible. Moody cinematic lighting with soft key light from the front-left and gentle fill, deep but controlled shadows, desaturated film tones. Background: softly blurred modern dark boardroom with subtle warm rim light. Shot on 85mm f/1.8 lens, shallow depth of field but face fully in focus, editorial high-end portrait photography, professional film still quality, 8k detail.",
  },
  "Claire Donovan": {
    model: "flux/schnell",
    prompt:
      "Professional corporate headshot of an intelligent woman in her mid-30s, elegant cream blazer over emerald silk blouse, understated pearl jewelry, shoulder-length auburn hair, analytical sharp expression, subtle confident smile, modern NYC office background softly blurred, natural studio lighting, shallow depth of field, photorealistic, high-end corporate photography, shot on 85mm lens",
  },
  "Olivia Harper": {
    model: "flux/schnell",
    prompt:
      "Professional corporate headshot of a woman in her mid-30s, charcoal grey blazer over cream silk blouse, warm confident expression, shoulder-length brown hair styled, subtle makeup, creative intelligent look, modern editorial office background softly blurred, natural studio lighting, shallow depth of field, photorealistic, high-end corporate photography, shot on 85mm lens",
  },
  "Sophia Bennett": {
    model: "flux/schnell",
    prompt:
      "Professional corporate headshot of a detail-oriented woman in her mid-30s, white silk blouse, pearl earrings, black pencil skirt visible, dark hair in a sleek low bun, precise sharp expression, subtle smile, modern glass office background softly blurred, natural studio lighting, shallow depth of field, photorealistic, high-end corporate photography, shot on 85mm lens",
  },
  "Nathan Brooks": {
    model: "flux/schnell",
    prompt:
      "Professional corporate headshot of an analytical man in his late 30s, burgundy merino wool sweater over collared shirt, tortoiseshell glasses, short neat brown hair, warm intelligent expression, slight thoughtful smile, modern finance office background softly blurred, natural studio lighting, shallow depth of field, photorealistic, high-end corporate photography, shot on 85mm lens",
  },
};

// Cost + spend-tracking model name per fal model
const MODEL_COST: Record<string, number> = {
  "flux/dev": 0.025,
  "flux/schnell": 0.003,
};
const MODEL_SPEND_LABEL: Record<string, string> = {
  "flux/dev": "fal-flux-dev",
  "flux/schnell": "fal-flux-schnell",
};

async function loadFalKey(svc: any): Promise<string | null> {
  const { data } = await svc.from("app_secrets").select("encrypted_value").eq("key_name", "FAL_API_KEY").maybeSingle();
  if (!data) return null;
  try { return await decryptSecret(data.encrypted_value); } catch { return null; }
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });
  try {
    const auth = req.headers.get("Authorization");
    const ownerCheck = await requireOwner(auth);
    if (ownerCheck instanceof Response) return ownerCheck;

    const { agentId } = await req.json().catch(() => ({}));
    if (!agentId) return errorResponse("agentId required", 400);

    const svc = getServiceClient();
    const { data: agent, error: agentErr } = await svc.from("agents").select("*").eq("id", agentId).single();
    if (agentErr || !agent) return errorResponse("Agent not found", 404);

    const config = AGENT_CONFIG[agent.name];
    if (!config) return errorResponse(`No predefined prompt for agent "${agent.name}"`, 400);
    const { prompt, model } = config;
    const cost = MODEL_COST[model];
    const spendLabel = MODEL_SPEND_LABEL[model];

    const apiKey = await loadFalKey(svc);
    if (!apiKey) {
      return jsonResponse({
        ok: false,
        code: "NO_KEY",
        message: "Set your fal API key in Settings to generate avatars.",
      }, 200);
    }

    // 1. Call fal.ai (model selected per-agent: flux/dev for cinematic, flux/schnell otherwise)
    // flux/dev is gated — your fal account must have accepted its terms at fal.ai/models/fal-ai/flux/dev
    const isDev = model === "flux/dev";
    const falRes = await fetch(`https://fal.run/fal-ai/${model}`, {
      method: "POST",
      headers: {
        Authorization: `Key ${apiKey}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        prompt,
        image_size: "square_hd",
        num_inference_steps: isDev ? 28 : 4,
        ...(isDev ? { guidance_scale: 3.5 } : {}),
        num_images: 1,
        enable_safety_checker: true,
      }),
    });

    if (!falRes.ok) {
      const t = await falRes.text();
      return errorResponse(`fal.ai ${falRes.status}: ${t.slice(0, 300)}`, 502);
    }
    const falData = await falRes.json();
    const outputUrl: string | undefined = falData?.images?.[0]?.url;
    if (!outputUrl) return errorResponse("fal.ai returned no image URL", 502);

    // 2. Download
    const imgRes = await fetch(outputUrl);
    if (!imgRes.ok) return errorResponse("Failed to download generated image", 502);
    const imgBytes = new Uint8Array(await imgRes.arrayBuffer());

    // 3. Upload to storage
    const filename = `${agentId}-${Date.now()}.png`;
    const { error: upErr } = await svc.storage.from("agent-avatars").upload(filename, imgBytes, {
      contentType: "image/png",
      upsert: true,
    });
    if (upErr) return errorResponse(`Storage upload failed: ${upErr.message}`, 500);

    const { data: pub } = svc.storage.from("agent-avatars").getPublicUrl(filename);
    const publicUrl = pub.publicUrl;

    // 4. Update agent
    await svc.from("agents").update({ avatar_url: publicUrl }).eq("id", agentId);

    // 5. Log spend (one-time per generation; not budget-capped)
    await svc.from("agent_spend").insert({
      agent_id: agentId,
      project_id: null,
      model: spendLabel,
      input_tokens: 0,
      output_tokens: 0,
      cost_usd: cost,
      call_type: "image_generation",
    });

    await logActivity(svc, {
      agentId,
      agentName: agent.name,
      message: `Generated new avatar via fal.ai ${model} ($${cost.toFixed(3)}).`,
      level: "info",
      metadata: { url: publicUrl, model },
    });

    return jsonResponse({ ok: true, avatar_url: publicUrl, cost_usd: cost, model });
  } catch (e) {
    return errorResponse(`Server error: ${String(e)}`, 500);
  }
});
