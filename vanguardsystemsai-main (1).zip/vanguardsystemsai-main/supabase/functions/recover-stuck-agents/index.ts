// recover-stuck-agents: standalone recovery endpoint.
// Forces any agent that has been "working" for longer than the configured
// staleness window back to "sleeping", logs the recovery, and inserts an
// errors row + an agent_log entry so the UI can surface it.
//
// Two modes:
//   - default: only recover agents idle (working but not updated) for > 60s
//   - force=true: recover ALL working agents immediately (admin escape hatch)
//
// Used by the "Recover stuck agents" button on /admin/agents and as a
// safety net before run-cycle starts a new chain.

import {
  corsHeaders,
  jsonResponse,
  requireOwner,
  getServiceClient,
  logActivity,
} from "../_shared/anthropic.ts";

const STALE_THRESHOLD_MS = 60_000;

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });

  try {
    const auth = req.headers.get("Authorization");
    const ownerCheck = await requireOwner(auth);
    if (ownerCheck instanceof Response) return ownerCheck;

    const body = await req.json().catch(() => ({}));
    const force = body?.force === true;
    const projectId: string | null = body?.projectId ?? null;

    const svc = getServiceClient();
    const { data: working } = await svc
      .from("agents")
      .select("id,name,status,current_task,updated_at")
      .eq("status", "working");

    const now = Date.now();
    const candidates = (working ?? []).filter((agent: any) => {
      if (force) return true;
      if (!agent.updated_at) return true;
      return now - new Date(agent.updated_at).getTime() > STALE_THRESHOLD_MS;
    });

    const recovered: Array<{ id: string; name: string; ageMs: number | null }> = [];
    for (const agent of candidates) {
      const ageMs = agent.updated_at ? now - new Date(agent.updated_at).getTime() : null;
      const message = `${agent.name} was force-recovered after being stuck in "working" state${
        ageMs ? ` for ${Math.round(ageMs / 1000)}s` : ""
      }${agent.current_task ? ` during: ${agent.current_task}` : ""}.`;

      await Promise.allSettled([
        svc.from("agents").update({
          status: "sleeping",
          current_task: null,
          failure_flag: true,
          last_error_message: message,
          last_failed_at: new Date().toISOString(),
        }).eq("id", agent.id),
        svc.from("errors").insert({
          agent_id: agent.id,
          project_id: projectId,
          function_name: "recover-stuck-agents",
          error_message: message,
          stack_trace: null,
        }),
        logActivity(svc, {
          projectId,
          agentId: agent.id,
          agentName: agent.name,
          level: "error",
          message,
        }),
      ]);

      recovered.push({ id: agent.id, name: agent.name, ageMs });
    }

    return jsonResponse({
      ok: true,
      recovered,
      count: recovered.length,
      message: recovered.length === 0
        ? "No stuck agents found."
        : `Recovered ${recovered.length} stuck agent${recovered.length > 1 ? "s" : ""}: ${recovered.map((r) => r.name).join(", ")}.`,
    });
  } catch (e) {
    return jsonResponse({ ok: false, error: `Server error: ${e instanceof Error ? e.message : String(e)}` }, 500);
  }
});
