// Owner-only: save / load / list encrypted secrets.
// Actions: list | save | get_masked | delete
import { corsHeaders, errorResponse, jsonResponse, requireOwner, getServiceClient, encryptSecret, maskSecret } from "../_shared/anthropic.ts";

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });
  try {
    const auth = req.headers.get("Authorization");
    const ownerCheck = await requireOwner(auth);
    if (ownerCheck instanceof Response) return ownerCheck;

    const body = await req.json().catch(() => ({}));
    const action = body.action as string;
    const svc = getServiceClient();

    if (action === "list") {
      const { data } = await svc
        .from("app_secrets")
        .select("key_name, masked_preview, last_tested_at, last_test_status, updated_at");
      return jsonResponse({ secrets: data ?? [] });
    }

    if (action === "save") {
      const { key_name, value } = body;
      if (!key_name || typeof value !== "string" || !value) {
        return errorResponse("key_name and value required", 400);
      }
      const encrypted = await encryptSecret(value);
      const masked = maskSecret(value);
      const { error } = await svc
        .from("app_secrets")
        .upsert(
          { key_name, encrypted_value: encrypted, masked_preview: masked, last_test_status: null, last_tested_at: null },
          { onConflict: "key_name" },
        );
      if (error) return errorResponse(error.message, 500);
      return jsonResponse({ ok: true, masked });
    }

    if (action === "delete") {
      const { key_name } = body;
      await svc.from("app_secrets").delete().eq("key_name", key_name);
      return jsonResponse({ ok: true });
    }

    return errorResponse("Unknown action", 400);
  } catch (e) {
    return errorResponse(`Server error: ${String(e)}`, 500);
  }
});
