// Test the saved Anthropic API key with a 1-token ping.
import { corsHeaders, errorResponse, jsonResponse, requireOwner, getServiceClient, loadAnthropicKey } from "../_shared/anthropic.ts";

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });
  try {
    const auth = req.headers.get("Authorization");
    const ownerCheck = await requireOwner(auth);
    if (ownerCheck instanceof Response) return ownerCheck;

    const svc = getServiceClient();
    const key = await loadAnthropicKey(svc);
    if (!key) return jsonResponse({ ok: false, message: "No Anthropic key saved." });

    const res = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: {
        "x-api-key": key,
        "anthropic-version": "2023-06-01",
        "content-type": "application/json",
      },
      body: JSON.stringify({
        model: "claude-haiku-4-5-20251001",
        max_tokens: 8,
        messages: [{ role: "user", content: "ping" }],
      }),
    });

    const ok = res.ok;
    const status = ok ? "ok" : "fail";
    await svc
      .from("app_secrets")
      .update({ last_tested_at: new Date().toISOString(), last_test_status: status })
      .eq("key_name", "ANTHROPIC_API_KEY");

    if (!ok) {
      const t = await res.text();
      return jsonResponse({ ok: false, message: `Anthropic ${res.status}: ${t.slice(0, 200)}` });
    }
    return jsonResponse({ ok: true, message: "Anthropic key is valid." });
  } catch (e) {
    return errorResponse(`Server error: ${String(e)}`, 500);
  }
});
