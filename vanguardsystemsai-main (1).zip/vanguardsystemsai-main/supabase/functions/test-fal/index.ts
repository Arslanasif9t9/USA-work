// Owner-only: test the saved fal.ai API key with a tiny generation request.
// We hit a cheap status endpoint by issuing a minimal POST and inspecting auth.
import { corsHeaders, errorResponse, jsonResponse, requireOwner, getServiceClient, decryptSecret } from "../_shared/anthropic.ts";

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });
  try {
    const auth = req.headers.get("Authorization");
    const ownerCheck = await requireOwner(auth);
    if (ownerCheck instanceof Response) return ownerCheck;

    const svc = getServiceClient();
    const { data } = await svc
      .from("app_secrets")
      .select("encrypted_value")
      .eq("key_name", "FAL_API_KEY")
      .maybeSingle();
    if (!data) return jsonResponse({ ok: false, message: "No fal API key saved." });

    let key = "";
    try { key = await decryptSecret(data.encrypted_value); } catch {
      return jsonResponse({ ok: false, message: "Failed to decrypt key (wrong master key?)." });
    }

    // Use fal's queue endpoint with HEAD-style POST to validate auth without burning credits.
    // The cheapest valid call is a minimal request to a tiny model — we use schnell at 1 step.
    const res = await fetch("https://fal.run/fal-ai/flux/schnell", {
      method: "POST",
      headers: { Authorization: `Key ${key}`, "Content-Type": "application/json" },
      body: JSON.stringify({
        prompt: "test",
        image_size: "square",
        num_inference_steps: 1,
        num_images: 1,
        enable_safety_checker: false,
      }),
    });

    const ok = res.ok;
    const status = ok ? "ok" : "fail";
    await svc
      .from("app_secrets")
      .update({ last_tested_at: new Date().toISOString(), last_test_status: status })
      .eq("key_name", "FAL_API_KEY");

    if (!ok) {
      const t = await res.text();
      // 401/403 means bad key. Anything else (400 etc.) still indicates auth worked.
      if (res.status === 401 || res.status === 403) {
        return jsonResponse({ ok: false, message: `fal.ai auth failed (${res.status}): ${t.slice(0, 160)}` });
      }
      return jsonResponse({ ok: true, message: "fal.ai key accepted (request rejected for non-auth reason)." });
    }

    // Consume body to avoid Deno resource leak
    await res.text();
    return jsonResponse({ ok: true, message: "fal.ai key is valid." });
  } catch (e) {
    return errorResponse(`Server error: ${String(e)}`, 500);
  }
});
