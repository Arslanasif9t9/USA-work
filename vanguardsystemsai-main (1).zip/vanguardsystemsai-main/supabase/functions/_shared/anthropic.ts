// Shared crypto + Anthropic wrapper used by every edge function.
// AES-GCM encryption uses a master key from env (APP_SECRET_MASTER_KEY).
// Every Anthropic call is wrapped by nathanCheck() and logs spend.

import { createClient, SupabaseClient } from "https://esm.sh/@supabase/supabase-js@2.45.0";

export const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
  "Access-Control-Allow-Methods": "POST, GET, OPTIONS",
};

export function jsonResponse(body: unknown, status = 200) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { ...corsHeaders, "Content-Type": "application/json" },
  });
}

export function errorResponse(message: string, status = 400, extra: Record<string, unknown> = {}) {
  return jsonResponse({ error: message, ...extra }, status);
}

export function getServiceClient(): SupabaseClient {
  const url = Deno.env.get("SUPABASE_URL")!;
  const key = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
  return createClient(url, key, { auth: { persistSession: false } });
}

export function getUserClient(authHeader: string): SupabaseClient {
  const url = Deno.env.get("SUPABASE_URL")!;
  const key = Deno.env.get("SUPABASE_ANON_KEY")!;
  return createClient(url, key, {
    auth: { persistSession: false },
    global: { headers: { Authorization: authHeader } },
  });
}

export async function requireOwner(authHeader: string | null): Promise<{ userId: string } | Response> {
  if (!authHeader) return errorResponse("Missing Authorization header", 401);
  const userClient = getUserClient(authHeader);
  const { data: userData, error: userErr } = await userClient.auth.getUser();
  if (userErr || !userData.user) return errorResponse("Not authenticated", 401);
  const userId = userData.user.id;
  const svc = getServiceClient();
  const { data: roles, error: roleErr } = await svc
    .from("user_roles")
    .select("role")
    .eq("user_id", userId);
  if (roleErr) return errorResponse("Role check failed", 500);
  const isOwner = (roles ?? []).some((r: { role: string }) => r.role === "owner");
  if (!isOwner) return errorResponse("Owner role required", 403);
  return { userId };
}

async function getMasterKey(): Promise<CryptoKey> {
  let raw = Deno.env.get("APP_SECRET_MASTER_KEY") ?? "";
  if (!raw) {
    raw = "mission-control-default-master-key-please-rotate-in-prod";
  }
  const enc = new TextEncoder().encode(raw);
  const hash = await crypto.subtle.digest("SHA-256", enc);
  return crypto.subtle.importKey("raw", hash, { name: "AES-GCM" }, false, ["encrypt", "decrypt"]);
}

export async function encryptSecret(plaintext: string): Promise<string> {
  const key = await getMasterKey();
  const iv = crypto.getRandomValues(new Uint8Array(12));
  const ct = await crypto.subtle.encrypt(
    { name: "AES-GCM", iv },
    key,
    new TextEncoder().encode(plaintext),
  );
  const ctBytes = new Uint8Array(ct);
  const combined = new Uint8Array(iv.length + ctBytes.length);
  combined.set(iv, 0);
  combined.set(ctBytes, iv.length);
  return btoa(String.fromCharCode(...combined));
}

export async function decryptSecret(payload: string): Promise<string> {
  const key = await getMasterKey();
  const combined = Uint8Array.from(atob(payload), (c) => c.charCodeAt(0));
  const iv = combined.slice(0, 12);
  const data = combined.slice(12);
  const pt = await crypto.subtle.decrypt({ name: "AES-GCM", iv }, key, data);
  return new TextDecoder().decode(pt);
}

export function maskSecret(s: string): string {
  if (s.length <= 10) return "****";
  return `${s.slice(0, 6)}…${s.slice(-4)}`;
}

const PRICING: Record<string, { input: number; output: number }> = {
  "claude-opus-4-7": { input: 15, output: 75 },
  "claude-opus-4-1-20250805": { input: 15, output: 75 },
  "claude-sonnet-4-6": { input: 3, output: 15 },
  "claude-sonnet-4-5": { input: 3, output: 15 },
  "claude-haiku-4-5": { input: 1, output: 5 },
  "claude-3-5-haiku-20241022": { input: 1, output: 5 },
};

const MODEL_ALIASES: Record<string, string> = {
  "claude-opus-4-7": "claude-opus-4-1-20250805",
  "claude-sonnet-4-6": "claude-sonnet-4-5",
  "claude-haiku-4-5": "claude-3-5-haiku-20241022",
};

// Allow long Opus drafts to finish. The function runs in the background via
// EdgeRuntime.waitUntil, so we can comfortably wait far longer than the
// initial HTTP response window.
const ANTHROPIC_TIMEOUT_MS = 240_000;

export function resolveModel(name: string): string {
  return MODEL_ALIASES[name] ?? name;
}

export function priceFor(model: string, inputTokens: number, outputTokens: number): number {
  const p = PRICING[model] ?? PRICING["claude-sonnet-4-6"];
  return (inputTokens * p.input + outputTokens * p.output) / 1_000_000;
}

export async function loadAnthropicKey(svc: SupabaseClient): Promise<string | null> {
  const { data, error } = await svc
    .from("app_secrets")
    .select("encrypted_value")
    .eq("key_name", "ANTHROPIC_API_KEY")
    .maybeSingle();
  if (error || !data) return null;
  try {
    return await decryptSecret(data.encrypted_value);
  } catch {
    return null;
  }
}

export type NathanFailureCode = "not_found" | "disabled" | "off" | "budget_paused" | "prompt_budget_warning";

/**
 * Per-prompt circuit breaker. Pauses the chain (without budget_paused-ing the agent)
 * when a single prompt cycle has already consumed > 50% of the agent's daily cap.
 * Surfaces as a budget_alert so the UI can show "Budget warning — Continue?".
 *
 * `projectId` scopes the spend tally to this prompt cycle; we only count spend
 * since the last delivered prompt for that project (proxy for "this cycle").
 */
export async function checkPromptBudget(
  svc: SupabaseClient,
  agentId: string,
  projectId: string | null,
): Promise<{ ok: true } | { ok: false; reason: string; spent: number; limit: number }> {
  if (!projectId) return { ok: true };
  const { data: agent } = await svc.from("agents").select("name,daily_budget_usd").eq("id", agentId).maybeSingle();
  if (!agent) return { ok: true };
  const dailyBudget = Number(agent.daily_budget_usd ?? 0);
  if (dailyBudget <= 0) return { ok: true };

  // Anchor "this prompt cycle" to the most recent delivered prompt timestamp.
  // If nothing has been delivered yet, fall back to start of day.
  const { data: lastDelivered } = await svc
    .from("lovable_prompts")
    .select("delivered_at")
    .eq("project_id", projectId)
    .not("delivered_at", "is", null)
    .order("delivered_at", { ascending: false })
    .limit(1)
    .maybeSingle();
  const cycleStart = lastDelivered?.delivered_at
    ? new Date(lastDelivered.delivered_at)
    : (() => { const d = new Date(); d.setUTCHours(0, 0, 0, 0); return d; })();

  const { data: spend } = await svc
    .from("agent_spend")
    .select("cost_usd")
    .eq("agent_id", agentId)
    .eq("project_id", projectId)
    .gte("created_at", cycleStart.toISOString());
  const spentThisCycle = (spend ?? []).reduce((s: number, r: any) => s + Number(r.cost_usd ?? 0), 0);

  const threshold = dailyBudget * 0.5;
  if (spentThisCycle >= threshold) {
    // Open a budget_alert (idempotent-ish: only if not already an unresolved alert for this agent today).
    const { data: existing } = await svc
      .from("budget_alerts")
      .select("id")
      .eq("agent_id", agentId)
      .eq("resolved", false)
      .gte("created_at", cycleStart.toISOString())
      .maybeSingle();
    if (!existing) {
      await svc.from("budget_alerts").insert({
        agent_id: agentId,
        reason: `${agent.name} consumed $${spentThisCycle.toFixed(4)} on this prompt cycle (>50% of $${dailyBudget.toFixed(2)} daily cap). Chain paused.`,
        cost_at_pause: spentThisCycle,
        budget_limit: dailyBudget,
      });
    }
    return {
      ok: false,
      reason: `${agent.name} would exceed 50% of daily budget on this prompt cycle ($${spentThisCycle.toFixed(4)} / $${dailyBudget.toFixed(2)}).`,
      spent: spentThisCycle,
      limit: dailyBudget,
    };
  }

  return { ok: true };
}

export async function nathanCheck(
  svc: SupabaseClient,
  agentId: string,
): Promise<{ ok: true; agent: any } | { ok: false; reason: string; code: NathanFailureCode }> {
  const { data: agent, error } = await svc.from("agents").select("*").eq("id", agentId).single();
  if (error || !agent) return { ok: false, reason: "Agent not found", code: "not_found" };
  if (!agent.enabled) return { ok: false, reason: `${agent.name} is toggled off`, code: "disabled" };
  if (agent.status === "paused") return { ok: false, reason: `${agent.name} is paused`, code: "disabled" };
  if (agent.status === "off") return { ok: false, reason: `${agent.name} is off`, code: "off" };
  if (agent.status === "budget_paused") return { ok: false, reason: `${agent.name} is budget-paused`, code: "budget_paused" };

  const today = new Date();
  today.setUTCHours(0, 0, 0, 0);
  const { data: spend } = await svc
    .from("agent_spend")
    .select("cost_usd")
    .eq("agent_id", agentId)
    .gte("created_at", today.toISOString());
  const spentToday = (spend ?? []).reduce((s: number, r: any) => s + Number(r.cost_usd ?? 0), 0);
  if (spentToday >= Number(agent.daily_budget_usd)) {
    await svc.from("agents").update({ status: "budget_paused", cost_today_usd: spentToday }).eq("id", agentId);
    await svc.from("budget_alerts").insert({
      agent_id: agentId,
      reason: `Daily budget of $${agent.daily_budget_usd} reached`,
      cost_at_pause: spentToday,
      budget_limit: agent.daily_budget_usd,
    });
    await svc.from("agent_log").insert({
      agent_id: agentId,
      agent_name: "Nathan Brooks",
      level: "warn",
      message: `Paused ${agent.name} — daily budget of $${agent.daily_budget_usd} reached ($${spentToday.toFixed(2)} spent today).`,
    });
    return { ok: false, reason: `${agent.name} reached daily budget`, code: "budget_paused" };
  }
  return { ok: true, agent };
}

export interface AnthropicMessage {
  role: "user" | "assistant";
  content: string | Array<{ type: string; [k: string]: unknown }>;
}

export interface CallOptions {
  agentId: string;
  projectId?: string | null;
  model: string;
  system: string;
  messages: AnthropicMessage[];
  maxTokens?: number;
  callType?: string;
  apiKey: string;
  svc: SupabaseClient;
}

export interface CallError {
  error: string;
  status?: number;
  code?: string;
}

export class AgentStepError extends Error {
  code?: string;
  status: number;
  markFailure: boolean;
  stackTrace?: string;

  constructor(
    message: string,
    options: { code?: string; status?: number; markFailure?: boolean; stackTrace?: string } = {},
  ) {
    super(message);
    this.name = "AgentStepError";
    this.code = options.code;
    this.status = options.status ?? 500;
    this.markFailure = options.markFailure ?? true;
    this.stackTrace = options.stackTrace;
  }
}

export function normalizeError(error: unknown): { message: string; stack?: string } {
  if (error instanceof AgentStepError) {
    return {
      message: error.message,
      stack: error.stackTrace ?? error.stack,
    };
  }
  if (error instanceof Error) {
    return { message: error.message, stack: error.stack };
  }
  return { message: String(error) };
}

export async function callAnthropic(
  opts: CallOptions,
): Promise<{ text: string; inputTokens: number; outputTokens: number; cost: number; model: string } | CallError> {
  const check = await nathanCheck(opts.svc, opts.agentId);
  if (!check.ok) return { error: check.reason, code: check.code, status: check.code === "budget_paused" ? 409 : 400 };

  // Per-prompt circuit breaker — pause chain (without flipping agent to budget_paused)
  // when this single cycle has already burned >50% of the agent's daily cap.
  const promptBudget = await checkPromptBudget(opts.svc, opts.agentId, opts.projectId ?? null);
  if (!promptBudget.ok) {
    return { error: promptBudget.reason, code: "prompt_budget_warning", status: 429 };
  }

  const realModel = resolveModel(opts.model);

  let res: Response;
  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(`Anthropic request exceeded ${ANTHROPIC_TIMEOUT_MS}ms`), ANTHROPIC_TIMEOUT_MS);
  try {
    res = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      signal: controller.signal,
      headers: {
        "x-api-key": opts.apiKey,
        "anthropic-version": "2023-06-01",
        "content-type": "application/json",
      },
      body: JSON.stringify({
        model: realModel,
        max_tokens: opts.maxTokens ?? 4096,
        system: opts.system,
        messages: opts.messages,
      }),
    });
  } catch (error) {
    const failure = normalizeError(error);
    const isAbort = error instanceof Error && error.name === "AbortError";
    return {
      error: isAbort
        ? `Anthropic request timed out after ${Math.round(ANTHROPIC_TIMEOUT_MS / 1000)}s`
        : `Anthropic request failed: ${failure.message}`,
      code: isAbort ? "anthropic_timeout" : "network_error",
      status: isAbort ? 504 : 502,
    };
  } finally {
    clearTimeout(timeoutId);
  }

  if (!res.ok) {
    const errBody = await res.text();
    return {
      error: `Anthropic ${res.status}: ${errBody.slice(0, 400)}`,
      status: res.status,
      code: res.status === 429 ? "rate_limit" : res.status === 401 || res.status === 403 ? "invalid_api_key" : "anthropic_api_error",
    };
  }

  let data: any;
  try {
    data = await res.json();
  } catch (error) {
    const failure = normalizeError(error);
    return { error: `Anthropic returned unreadable JSON: ${failure.message}`, code: "invalid_json", status: 502 };
  }

  const inputTokens = data.usage?.input_tokens ?? 0;
  const outputTokens = data.usage?.output_tokens ?? 0;
  const cost = priceFor(opts.model, inputTokens, outputTokens);

  const text = (data.content ?? [])
    .filter((b: any) => b.type === "text")
    .map((b: any) => b.text)
    .join("\n");

  await opts.svc.from("agent_spend").insert({
    agent_id: opts.agentId,
    project_id: opts.projectId ?? null,
    model: opts.model,
    input_tokens: inputTokens,
    output_tokens: outputTokens,
    cost_usd: cost,
    call_type: opts.callType ?? "cycle",
  });

  const { data: agent } = await opts.svc.from("agents").select("tokens_today,cost_today_usd").eq("id", opts.agentId).single();
  await opts.svc
    .from("agents")
    .update({
      tokens_today: (agent?.tokens_today ?? 0) + inputTokens + outputTokens,
      cost_today_usd: Number(agent?.cost_today_usd ?? 0) + cost,
      last_run: new Date().toISOString(),
    })
    .eq("id", opts.agentId);

  return { text, inputTokens, outputTokens, cost, model: realModel };
}

export async function clearAgentFailure(svc: SupabaseClient, agentId: string) {
  await svc.from("agents").update({
    failure_flag: false,
    last_error_message: null,
    last_failed_at: null,
  }).eq("id", agentId);
}

export async function setAgentStatus(
  svc: SupabaseClient,
  agentId: string,
  status: "sleeping" | "working" | "standby" | "off" | "paused" | "budget_paused",
  currentTask: string | null = null,
) {
  const payload: Record<string, unknown> = { status, current_task: currentTask };
  if (status === "working") {
    payload.failure_flag = false;
    payload.last_error_message = null;
    payload.last_failed_at = null;
  }
  await svc.from("agents").update(payload).eq("id", agentId);
}

export async function settleAgentStatus(svc: SupabaseClient, agentId: string) {
  const { data: agent } = await svc.from("agents").select("status").eq("id", agentId).maybeSingle();
  const nextStatus = agent?.status === "budget_paused"
    ? "budget_paused"
    : agent?.status === "off"
    ? "off"
    : agent?.status === "paused"
    ? "paused"
    : "sleeping";
  await svc.from("agents").update({ status: nextStatus, current_task: null }).eq("id", agentId);
}

export async function logActivity(
  svc: SupabaseClient,
  args: { projectId?: string | null; agentId?: string | null; agentName: string; message: string; level?: string; metadata?: Record<string, unknown> },
) {
  await svc.from("agent_log").insert({
    project_id: args.projectId ?? null,
    agent_id: args.agentId ?? null,
    agent_name: args.agentName,
    level: args.level ?? "info",
    message: args.message,
    metadata: args.metadata ?? {},
  });
}

export async function markAgentFailure(
  svc: SupabaseClient,
  args: {
    agentId: string;
    agentName: string;
    projectId?: string | null;
    functionName: string;
    error: unknown;
  },
) {
  const failure = normalizeError(args.error);
  const failedAt = new Date().toISOString();
  const { data: agent } = await svc.from("agents").select("status").eq("id", args.agentId).maybeSingle();
  const restingStatus = agent?.status === "budget_paused"
    ? "budget_paused"
    : agent?.status === "off"
    ? "off"
    : agent?.status === "paused"
    ? "paused"
    : "sleeping";

  await Promise.allSettled([
    svc.from("errors").insert({
      agent_id: args.agentId,
      project_id: args.projectId ?? null,
      function_name: args.functionName,
      error_message: failure.message,
      stack_trace: failure.stack ?? null,
      created_at: failedAt,
    }),
    svc.from("agents").update({
      failure_flag: true,
      last_error_message: failure.message,
      last_failed_at: failedAt,
      status: restingStatus,
      current_task: null,
    }).eq("id", args.agentId),
    logActivity(svc, {
      projectId: args.projectId ?? null,
      agentId: args.agentId,
      agentName: args.agentName,
      level: "error",
      message: `${args.functionName} failed: ${failure.message}`,
    }),
  ]);

  return failure;
}

export async function runAgentTask<T>(
  svc: SupabaseClient,
  args: {
    agentId: string;
    agentName: string;
    projectId?: string | null;
    functionName: string;
    currentTask: string;
    work: () => Promise<T>;
  },
): Promise<
  | { ok: true; result: T }
  | { ok: false; failure: { message: string; stack?: string }; status: number; code?: string; markedFailure: boolean }
> {
  await setAgentStatus(svc, args.agentId, "working", args.currentTask);

  try {
    const result = await args.work();
    return { ok: true, result };
  } catch (error) {
    const stepError = error instanceof AgentStepError ? error : null;
    const normalized = normalizeError(error);

    if (stepError?.markFailure === false) {
      await logActivity(svc, {
        projectId: args.projectId ?? null,
        agentId: args.agentId,
        agentName: args.agentName,
        level: "warn",
        message: `${args.functionName} stopped: ${normalized.message}`,
      });
      return {
        ok: false,
        failure: normalized,
        status: stepError?.status ?? 409,
        code: stepError?.code,
        markedFailure: false,
      };
    }

    const failure = await markAgentFailure(svc, {
      agentId: args.agentId,
      agentName: args.agentName,
      projectId: args.projectId ?? null,
      functionName: args.functionName,
      error,
    });
    return {
      ok: false,
      failure,
      status: stepError?.status ?? 502,
      code: stepError?.code,
      markedFailure: true,
    };
  } finally {
    await settleAgentStatus(svc, args.agentId);
  }
}
