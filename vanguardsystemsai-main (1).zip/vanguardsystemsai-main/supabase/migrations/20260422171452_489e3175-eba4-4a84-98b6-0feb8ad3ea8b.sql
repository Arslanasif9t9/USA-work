CREATE OR REPLACE FUNCTION public.is_admin_or_owner()
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT public.has_role(auth.uid(), 'owner'::public.app_role)
      OR public.has_role(auth.uid(), 'admin'::public.app_role)
$$;

ALTER TYPE public.agent_status ADD VALUE IF NOT EXISTS 'waiting';

CREATE TYPE public.agent_job_trigger_source AS ENUM ('manual', 'chain_handoff', 'retry', 'watchdog_recovery');
CREATE TYPE public.agent_job_status AS ENUM ('queued', 'running', 'completed', 'failed', 'timeout');

CREATE TABLE public.agent_jobs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  agent_id uuid NOT NULL REFERENCES public.agents(id) ON DELETE CASCADE,
  project_id uuid NOT NULL REFERENCES public.projects(id) ON DELETE CASCADE,
  prompt_cycle_id uuid NOT NULL,
  trigger_source public.agent_job_trigger_source NOT NULL,
  status public.agent_job_status NOT NULL DEFAULT 'queued',
  input_payload jsonb NOT NULL DEFAULT '{}'::jsonb,
  output_payload jsonb,
  error_message text,
  error_stack text,
  started_at timestamp with time zone,
  completed_at timestamp with time zone,
  duration_ms integer,
  tokens_used integer NOT NULL DEFAULT 0,
  cost_usd numeric NOT NULL DEFAULT 0,
  attempt_number integer NOT NULL DEFAULT 1,
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  updated_at timestamp with time zone NOT NULL DEFAULT now(),
  CONSTRAINT agent_jobs_attempt_number_positive CHECK (attempt_number >= 1),
  CONSTRAINT agent_jobs_duration_positive CHECK (duration_ms IS NULL OR duration_ms >= 0),
  CONSTRAINT agent_jobs_completion_consistency CHECK (
    (status IN ('queued', 'running') AND completed_at IS NULL)
    OR (status IN ('completed', 'failed', 'timeout'))
  )
);

CREATE INDEX idx_agent_jobs_status_created_at ON public.agent_jobs (status, created_at);
CREATE INDEX idx_agent_jobs_agent_status ON public.agent_jobs (agent_id, status);
CREATE INDEX idx_agent_jobs_project_cycle ON public.agent_jobs (project_id, prompt_cycle_id, created_at);

ALTER TABLE public.agent_jobs ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Admins and owners can view agent jobs"
ON public.agent_jobs
FOR SELECT
TO authenticated
USING (public.is_admin_or_owner());

CREATE POLICY "Admins and owners can create agent jobs"
ON public.agent_jobs
FOR INSERT
TO authenticated
WITH CHECK (public.is_admin_or_owner());

CREATE POLICY "Admins and owners can update agent jobs"
ON public.agent_jobs
FOR UPDATE
TO authenticated
USING (public.is_admin_or_owner())
WITH CHECK (public.is_admin_or_owner());

CREATE POLICY "Admins and owners can delete agent jobs"
ON public.agent_jobs
FOR DELETE
TO authenticated
USING (public.is_admin_or_owner());

ALTER TABLE public.errors
  ADD COLUMN IF NOT EXISTS error_type text,
  ADD COLUMN IF NOT EXISTS prompt_context jsonb NOT NULL DEFAULT '{}'::jsonb,
  ADD COLUMN IF NOT EXISTS agent_job_id uuid REFERENCES public.agent_jobs(id) ON DELETE SET NULL;

CREATE INDEX IF NOT EXISTS idx_errors_agent_job_id ON public.errors (agent_job_id);
CREATE INDEX IF NOT EXISTS idx_errors_error_type_created_at ON public.errors (error_type, created_at DESC);

CREATE TRIGGER update_agent_jobs_updated_at
BEFORE UPDATE ON public.agent_jobs
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();

ALTER PUBLICATION supabase_realtime ADD TABLE public.agent_jobs;