ALTER TABLE public.qa_reports
  ADD COLUMN IF NOT EXISTS revision_targets text[] NOT NULL DEFAULT ARRAY[]::text[],
  ADD COLUMN IF NOT EXISTS revision_notes text,
  ADD COLUMN IF NOT EXISTS revision_round integer NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS prompt_cycle_id uuid;

CREATE INDEX IF NOT EXISTS idx_qa_reports_project_cycle_created_at
  ON public.qa_reports (project_id, prompt_cycle_id, created_at DESC);

ALTER TABLE public.budget_alerts
  ADD COLUMN IF NOT EXISTS project_id uuid REFERENCES public.projects(id) ON DELETE CASCADE,
  ADD COLUMN IF NOT EXISTS prompt_cycle_id uuid,
  ADD COLUMN IF NOT EXISTS agent_job_id uuid REFERENCES public.agent_jobs(id) ON DELETE CASCADE,
  ADD COLUMN IF NOT EXISTS decision text NOT NULL DEFAULT 'pending';

ALTER TABLE public.budget_alerts
  DROP CONSTRAINT IF EXISTS budget_alerts_decision_check;

ALTER TABLE public.budget_alerts
  ADD CONSTRAINT budget_alerts_decision_check CHECK (decision IN ('pending', 'approved', 'cancelled'));

CREATE INDEX IF NOT EXISTS idx_budget_alerts_project_cycle
  ON public.budget_alerts (project_id, prompt_cycle_id, resolved, created_at DESC);

CREATE INDEX IF NOT EXISTS idx_budget_alerts_job_pending
  ON public.budget_alerts (agent_job_id, resolved, decision);