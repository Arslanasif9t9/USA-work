-- =========================================================
-- ROLES + PROFILES
-- =========================================================
CREATE TYPE public.app_role AS ENUM ('owner', 'admin', 'user');

CREATE TABLE public.profiles (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL UNIQUE REFERENCES auth.users(id) ON DELETE CASCADE,
  display_name TEXT,
  email TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;

CREATE TABLE public.user_roles (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  role public.app_role NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (user_id, role)
);
ALTER TABLE public.user_roles ENABLE ROW LEVEL SECURITY;

CREATE OR REPLACE FUNCTION public.has_role(_user_id UUID, _role public.app_role)
RETURNS BOOLEAN
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.user_roles
    WHERE user_id = _user_id AND role = _role
  )
$$;

CREATE OR REPLACE FUNCTION public.is_owner()
RETURNS BOOLEAN
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT public.has_role(auth.uid(), 'owner'::public.app_role)
$$;

-- shared updated_at trigger
CREATE OR REPLACE FUNCTION public.update_updated_at_column()
RETURNS TRIGGER
LANGUAGE plpgsql
SET search_path = public
AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$;

-- auto-create profile + auto-assign owner if first user
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  user_count INT;
BEGIN
  INSERT INTO public.profiles (user_id, email, display_name)
  VALUES (NEW.id, NEW.email, COALESCE(NEW.raw_user_meta_data->>'display_name', split_part(NEW.email, '@', 1)));

  SELECT COUNT(*) INTO user_count FROM auth.users;
  IF user_count = 1 THEN
    INSERT INTO public.user_roles (user_id, role) VALUES (NEW.id, 'owner');
  ELSE
    INSERT INTO public.user_roles (user_id, role) VALUES (NEW.id, 'user');
  END IF;
  RETURN NEW;
END;
$$;

CREATE TRIGGER on_auth_user_created
AFTER INSERT ON auth.users
FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

CREATE POLICY "profiles_select_own" ON public.profiles FOR SELECT TO authenticated USING (auth.uid() = user_id);
CREATE POLICY "profiles_update_own" ON public.profiles FOR UPDATE TO authenticated USING (auth.uid() = user_id);
CREATE POLICY "profiles_owner_all" ON public.profiles FOR SELECT TO authenticated USING (public.is_owner());

CREATE POLICY "user_roles_select_own" ON public.user_roles FOR SELECT TO authenticated USING (auth.uid() = user_id);
CREATE POLICY "user_roles_owner_all" ON public.user_roles FOR ALL TO authenticated USING (public.is_owner()) WITH CHECK (public.is_owner());

CREATE TRIGGER trg_profiles_updated BEFORE UPDATE ON public.profiles FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- =========================================================
-- APP SECRETS (encrypted at rest via edge function AES wrapper)
-- =========================================================
CREATE TABLE public.app_secrets (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  key_name TEXT NOT NULL UNIQUE,
  encrypted_value TEXT NOT NULL,
  masked_preview TEXT NOT NULL,
  last_tested_at TIMESTAMPTZ,
  last_test_status TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.app_secrets ENABLE ROW LEVEL SECURITY;
CREATE POLICY "app_secrets_owner_all" ON public.app_secrets FOR ALL TO authenticated USING (public.is_owner()) WITH CHECK (public.is_owner());
CREATE TRIGGER trg_app_secrets_updated BEFORE UPDATE ON public.app_secrets FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- =========================================================
-- PROJECTS
-- =========================================================
CREATE TYPE public.project_mode AS ENUM ('build_new', 'fix_existing', 'research_only', 'full_stack_service');
CREATE TYPE public.project_status AS ENUM ('active', 'paused', 'complete', 'archived');

CREATE TABLE public.projects (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  owner_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  slug TEXT NOT NULL UNIQUE,
  description TEXT,
  mode public.project_mode NOT NULL DEFAULT 'build_new',
  reference_urls JSONB NOT NULL DEFAULT '[]'::jsonb,
  existing_site_url TEXT,
  tech_stack_target TEXT NOT NULL DEFAULT 'Lovable React+Vite+Supabase',
  intake_notes TEXT,
  status public.project_status NOT NULL DEFAULT 'active',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.projects ENABLE ROW LEVEL SECURITY;
CREATE POLICY "projects_owner_all" ON public.projects FOR ALL TO authenticated USING (public.is_owner()) WITH CHECK (public.is_owner());
CREATE TRIGGER trg_projects_updated BEFORE UPDATE ON public.projects FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- =========================================================
-- AGENTS (global, not per-project)
-- =========================================================
CREATE TYPE public.agent_status AS ENUM ('sleeping', 'working', 'standby', 'off', 'budget_paused');

CREATE TABLE public.agents (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL UNIQUE,
  role TEXT NOT NULL,
  title TEXT NOT NULL,
  avatar_url TEXT NOT NULL,
  attire TEXT NOT NULL,
  base_system_prompt TEXT NOT NULL,
  enabled BOOLEAN NOT NULL DEFAULT true,
  status public.agent_status NOT NULL DEFAULT 'sleeping',
  current_task TEXT,
  last_run TIMESTAMPTZ,
  tokens_today INT NOT NULL DEFAULT 0,
  cost_today_usd NUMERIC(10,4) NOT NULL DEFAULT 0,
  daily_budget_usd NUMERIC(10,2) NOT NULL DEFAULT 5,
  model TEXT NOT NULL,
  reports_to UUID REFERENCES public.agents(id),
  sort_order INT NOT NULL DEFAULT 0,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.agents ENABLE ROW LEVEL SECURITY;
CREATE POLICY "agents_select_auth" ON public.agents FOR SELECT TO authenticated USING (true);
CREATE POLICY "agents_owner_write" ON public.agents FOR INSERT TO authenticated WITH CHECK (public.is_owner());
CREATE POLICY "agents_owner_update" ON public.agents FOR UPDATE TO authenticated USING (public.is_owner());
CREATE POLICY "agents_owner_delete" ON public.agents FOR DELETE TO authenticated USING (public.is_owner());
CREATE TRIGGER trg_agents_updated BEFORE UPDATE ON public.agents FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- =========================================================
-- LOVABLE PROMPTS (the deliverable)
-- =========================================================
CREATE TYPE public.prompt_status AS ENUM ('draft', 'ready', 'delivered', 'implemented');

CREATE TABLE public.lovable_prompts (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  project_id UUID NOT NULL REFERENCES public.projects(id) ON DELETE CASCADE,
  sequence_number INT NOT NULL,
  title TEXT NOT NULL,
  status public.prompt_status NOT NULL DEFAULT 'draft',
  dependencies JSONB NOT NULL DEFAULT '[]'::jsonb,
  content_md TEXT NOT NULL,
  created_by_agent_id UUID REFERENCES public.agents(id),
  delivered_at TIMESTAMPTZ,
  notes TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (project_id, sequence_number)
);
ALTER TABLE public.lovable_prompts ENABLE ROW LEVEL SECURITY;
CREATE POLICY "prompts_owner_all" ON public.lovable_prompts FOR ALL TO authenticated USING (public.is_owner()) WITH CHECK (public.is_owner());
CREATE TRIGGER trg_prompts_updated BEFORE UPDATE ON public.lovable_prompts FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
CREATE INDEX idx_prompts_project_seq ON public.lovable_prompts(project_id, sequence_number);

-- =========================================================
-- RESEARCH FINDINGS
-- =========================================================
CREATE TABLE public.research_findings (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  project_id UUID NOT NULL REFERENCES public.projects(id) ON DELETE CASCADE,
  agent_id UUID REFERENCES public.agents(id),
  source_url TEXT,
  category TEXT NOT NULL,
  title TEXT NOT NULL,
  content_md TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.research_findings ENABLE ROW LEVEL SECURITY;
CREATE POLICY "research_owner_all" ON public.research_findings FOR ALL TO authenticated USING (public.is_owner()) WITH CHECK (public.is_owner());
CREATE INDEX idx_research_project ON public.research_findings(project_id);

-- =========================================================
-- CONTENT DRAFTS (Olivia)
-- =========================================================
CREATE TABLE public.content_drafts (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  project_id UUID NOT NULL REFERENCES public.projects(id) ON DELETE CASCADE,
  agent_id UUID REFERENCES public.agents(id),
  category TEXT NOT NULL,
  title TEXT NOT NULL,
  content_md TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.content_drafts ENABLE ROW LEVEL SECURITY;
CREATE POLICY "drafts_owner_all" ON public.content_drafts FOR ALL TO authenticated USING (public.is_owner()) WITH CHECK (public.is_owner());
CREATE INDEX idx_drafts_project ON public.content_drafts(project_id);

-- =========================================================
-- QA REPORTS (Sophia)
-- =========================================================
CREATE TABLE public.qa_reports (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  project_id UUID NOT NULL REFERENCES public.projects(id) ON DELETE CASCADE,
  agent_id UUID REFERENCES public.agents(id),
  target_type TEXT NOT NULL,
  target_id UUID,
  verdict TEXT NOT NULL,
  findings_md TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.qa_reports ENABLE ROW LEVEL SECURITY;
CREATE POLICY "qa_owner_all" ON public.qa_reports FOR ALL TO authenticated USING (public.is_owner()) WITH CHECK (public.is_owner());
CREATE INDEX idx_qa_project ON public.qa_reports(project_id);

-- =========================================================
-- AGENT LOG (live feed, free DB inserts)
-- =========================================================
CREATE TABLE public.agent_log (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  project_id UUID REFERENCES public.projects(id) ON DELETE CASCADE,
  agent_id UUID REFERENCES public.agents(id) ON DELETE SET NULL,
  agent_name TEXT NOT NULL,
  level TEXT NOT NULL DEFAULT 'info',
  message TEXT NOT NULL,
  metadata JSONB DEFAULT '{}'::jsonb,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.agent_log ENABLE ROW LEVEL SECURITY;
CREATE POLICY "log_owner_all" ON public.agent_log FOR ALL TO authenticated USING (public.is_owner()) WITH CHECK (public.is_owner());
CREATE INDEX idx_log_project_time ON public.agent_log(project_id, created_at DESC);
ALTER PUBLICATION supabase_realtime ADD TABLE public.agent_log;
ALTER PUBLICATION supabase_realtime ADD TABLE public.agents;

-- =========================================================
-- AGENT SPEND (per-call cost tracking)
-- =========================================================
CREATE TABLE public.agent_spend (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  agent_id UUID NOT NULL REFERENCES public.agents(id) ON DELETE CASCADE,
  project_id UUID REFERENCES public.projects(id) ON DELETE SET NULL,
  model TEXT NOT NULL,
  input_tokens INT NOT NULL DEFAULT 0,
  output_tokens INT NOT NULL DEFAULT 0,
  cost_usd NUMERIC(10,6) NOT NULL DEFAULT 0,
  call_type TEXT NOT NULL DEFAULT 'cycle',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.agent_spend ENABLE ROW LEVEL SECURITY;
CREATE POLICY "spend_owner_all" ON public.agent_spend FOR ALL TO authenticated USING (public.is_owner()) WITH CHECK (public.is_owner());
CREATE INDEX idx_spend_agent_time ON public.agent_spend(agent_id, created_at DESC);
CREATE INDEX idx_spend_project ON public.agent_spend(project_id);

-- =========================================================
-- BUDGET ALERTS
-- =========================================================
CREATE TABLE public.budget_alerts (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  agent_id UUID NOT NULL REFERENCES public.agents(id) ON DELETE CASCADE,
  reason TEXT NOT NULL,
  cost_at_pause NUMERIC(10,4) NOT NULL,
  budget_limit NUMERIC(10,2) NOT NULL,
  resolved BOOLEAN NOT NULL DEFAULT false,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.budget_alerts ENABLE ROW LEVEL SECURITY;
CREATE POLICY "alerts_owner_all" ON public.budget_alerts FOR ALL TO authenticated USING (public.is_owner()) WITH CHECK (public.is_owner());

-- =========================================================
-- DAILY SUMMARIES
-- =========================================================
CREATE TABLE public.daily_summaries (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  project_id UUID REFERENCES public.projects(id) ON DELETE CASCADE,
  summary_date DATE NOT NULL DEFAULT CURRENT_DATE,
  total_cost_usd NUMERIC(10,4) NOT NULL DEFAULT 0,
  total_tokens INT NOT NULL DEFAULT 0,
  prompts_produced INT NOT NULL DEFAULT 0,
  notes TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.daily_summaries ENABLE ROW LEVEL SECURITY;
CREATE POLICY "summaries_owner_all" ON public.daily_summaries FOR ALL TO authenticated USING (public.is_owner()) WITH CHECK (public.is_owner());