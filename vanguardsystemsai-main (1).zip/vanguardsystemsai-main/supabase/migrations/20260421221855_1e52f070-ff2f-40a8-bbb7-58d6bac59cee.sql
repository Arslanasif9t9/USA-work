-- Create public bucket for agent avatars
INSERT INTO storage.buckets (id, name, public)
VALUES ('agent-avatars', 'agent-avatars', true)
ON CONFLICT (id) DO NOTHING;

-- Public read
CREATE POLICY "agent_avatars_public_read"
ON storage.objects FOR SELECT
USING (bucket_id = 'agent-avatars');

-- Owner can write
CREATE POLICY "agent_avatars_owner_insert"
ON storage.objects FOR INSERT
TO authenticated
WITH CHECK (bucket_id = 'agent-avatars' AND public.is_owner());

CREATE POLICY "agent_avatars_owner_update"
ON storage.objects FOR UPDATE
TO authenticated
USING (bucket_id = 'agent-avatars' AND public.is_owner());

CREATE POLICY "agent_avatars_owner_delete"
ON storage.objects FOR DELETE
TO authenticated
USING (bucket_id = 'agent-avatars' AND public.is_owner());