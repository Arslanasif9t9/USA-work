CREATE TABLE IF NOT EXISTS public.errors (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  agent_id UUID REFERENCES public.agents(id) ON DELETE SET NULL,
  project_id UUID REFERENCES public.projects(id) ON DELETE SET NULL,
  function_name TEXT NOT NULL,
  error_message TEXT NOT NULL,
  stack_trace TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

ALTER TABLE public.errors ENABLE ROW LEVEL SECURITY;

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies
    WHERE schemaname = 'public'
      AND tablename = 'errors'
      AND policyname = 'errors_owner_all'
  ) THEN
    CREATE POLICY "errors_owner_all"
    ON public.errors
    FOR ALL
    TO authenticated
    USING (public.is_owner())
    WITH CHECK (public.is_owner());
  END IF;
END $$;

ALTER TABLE public.agents
  ADD COLUMN IF NOT EXISTS failure_flag BOOLEAN NOT NULL DEFAULT false,
  ADD COLUMN IF NOT EXISTS last_error_message TEXT,
  ADD COLUMN IF NOT EXISTS last_failed_at TIMESTAMPTZ;

CREATE INDEX IF NOT EXISTS errors_agent_id_created_at_idx
  ON public.errors (agent_id, created_at DESC);

CREATE INDEX IF NOT EXISTS errors_project_id_created_at_idx
  ON public.errors (project_id, created_at DESC);

CREATE INDEX IF NOT EXISTS agents_failure_flag_idx
  ON public.agents (failure_flag)
  WHERE failure_flag = true;