import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Route, Routes } from "react-router-dom";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { AuthProvider } from "@/contexts/AuthContext";
import { ProjectProvider } from "@/contexts/ProjectContext";
import { OwnerGuard } from "@/components/OwnerGuard";
import Index from "./pages/Index.tsx";
import NotFound from "./pages/NotFound.tsx";
import AuthPage from "./pages/Auth.tsx";
import Setup from "./pages/Setup.tsx";
import AgentsPage from "./pages/Agents.tsx";
import Settings from "./pages/Settings.tsx";
import History from "./pages/History.tsx";
import Projects from "./pages/Projects.tsx";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <Toaster />
      <Sonner />
      <BrowserRouter>
        <AuthProvider>
          <ProjectProvider>
            <Routes>
              <Route path="/auth" element={<AuthPage />} />
              <Route path="/setup" element={<Setup />} />
              <Route path="/" element={<Index />} />
              <Route path="/admin/agents" element={<OwnerGuard><AgentsPage /></OwnerGuard>} />
              <Route path="/admin/projects" element={<OwnerGuard><Projects /></OwnerGuard>} />
              <Route path="/admin/settings" element={<OwnerGuard><Settings /></OwnerGuard>} />
              <Route path="/admin/history" element={<OwnerGuard><History /></OwnerGuard>} />
              <Route path="*" element={<NotFound />} />
            </Routes>
          </ProjectProvider>
        </AuthProvider>
      </BrowserRouter>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;
