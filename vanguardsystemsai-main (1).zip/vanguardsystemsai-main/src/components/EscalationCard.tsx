import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { AlertOctagon, ChevronDown, ChevronUp, Loader2, ShieldAlert, Trash2 } from "lucide-react";
import { toast } from "sonner";
import ReactMarkdown from "react-markdown";

interface Props {
  projectId: string;
  reportId: string;
  round: number;
  onResolved: () => void;
}

/**
 * Surfaces when the chain has been escalated after MAX_REVISION_ROUNDS (3).
 * Gives the operator two explicit choices:
 *   1. Force Accept → mark Sophia's last verdict as PASS_WITH_NOTES (overrides the
 *      NEEDS_REVISION) and trigger Ethan via run-cycle (retry_failed on Ethan).
 *   2. Discard & Restart → wipe the in-flight research/copy/qa rows for this cycle
 *      and restart the chain at Claire.
 */
export function EscalationCard({ projectId, reportId, round, onResolved }: Props) {
  const [findings, setFindings] = useState<string>("");
  const [expanded, setExpanded] = useState(false);
  const [busy, setBusy] = useState<"accept" | "discard" | null>(null);

  useEffect(() => {
    supabase
      .from("qa_reports")
      .select("findings_md")
      .eq("id", reportId)
      .maybeSingle()
      .then(({ data }) => setFindings(data?.findings_md ?? ""));
  }, [reportId]);

  const findEthanId = async (): Promise<string | null> => {
    const { data } = await supabase
      .from("agents")
      .select("id")
      .eq("role", "lead_architect")
      .maybeSingle();
    return data?.id ?? null;
  };

  const handleForceAccept = async () => {
    setBusy("accept");
    try {
      // Override the latest verdict so Sophia's loop logic sees PASS_WITH_NOTES on next read.
      const overrideMd = `## Verdict\nPASS_WITH_NOTES\n\n## Revision targets\nnone\n\n## Revision notes\nn/a\n\n${findings.replace(/##\s*Verdict[\s\S]*?(?=##\s*(Strengths|Gaps))/i, "")}\n\n---\n_Operator override: forced PASS_WITH_NOTES after ${round} revision rounds without convergence._`;
      const { error: updateErr } = await supabase
        .from("qa_reports")
        .update({ verdict: "PASS_WITH_NOTES", findings_md: overrideMd })
        .eq("id", reportId);
      if (updateErr) {
        toast.error(updateErr.message);
        return;
      }

      const ethanId = await findEthanId();
      if (!ethanId) {
        toast.error("Could not find Ethan to trigger.");
        return;
      }

      const { data, error } = await supabase.functions.invoke("run-cycle", {
        body: { projectId, trigger: "retry_failed", agentId: ethanId },
      });
      if (error || data?.error) {
        toast.error(data?.error || error?.message || "Could not trigger Ethan.");
        return;
      }
      toast.success("Forced PASS_WITH_NOTES. Ethan is drafting the prompt now.");
      onResolved();
    } finally {
      setBusy(null);
    }
  };

  const handleDiscardRestart = async () => {
    if (!confirm(`Discard the current Prompt cycle artifacts (research brief, copy draft, QA report) and restart from Claire? This cannot be undone.`)) {
      return;
    }
    setBusy("discard");
    try {
      // Wipe the in-flight artifacts for this project — only the most recent cycle.
      // We keep delivered prompts intact.
      const [latestBrief, latestCopy] = await Promise.all([
        supabase.from("research_findings").select("id").eq("project_id", projectId).order("created_at", { ascending: false }).limit(5),
        supabase.from("content_drafts").select("id").eq("project_id", projectId).order("created_at", { ascending: false }).limit(5),
      ]);

      // Delete the recent QA reports clustered with this NEEDS_REVISION run plus the in-flight artifacts.
      await Promise.all([
        supabase.from("qa_reports").delete().eq("project_id", projectId).eq("verdict", "NEEDS_REVISION"),
        latestBrief.data && latestBrief.data.length > 0
          ? supabase.from("research_findings").delete().in("id", latestBrief.data.map((r: any) => r.id))
          : Promise.resolve(),
        latestCopy.data && latestCopy.data.length > 0
          ? supabase.from("content_drafts").delete().in("id", latestCopy.data.map((r: any) => r.id))
          : Promise.resolve(),
      ]);

      // Kick off a fresh chain.
      const { data, error } = await supabase.functions.invoke("run-cycle", {
        body: { projectId, trigger: "next_prompt" },
      });
      if (error || data?.error) {
        toast.error(data?.error || error?.message || "Could not restart chain.");
        return;
      }
      toast.success("Cycle artifacts discarded. Chain restarted from Claire.");
      onResolved();
    } finally {
      setBusy(null);
    }
  };

  return (
    <Card className="border-destructive/50 bg-destructive/5">
      <CardHeader className="pb-2">
        <CardTitle className="flex items-center gap-2 text-base text-destructive">
          <ShieldAlert className="h-4 w-4" />
          Prompt cycle needs your decision
        </CardTitle>
        <p className="text-xs text-muted-foreground">
          Sophia flagged blocking issues across {round} revision rounds. The chain has stopped to prevent runaway spend.
        </p>
      </CardHeader>
      <CardContent className="space-y-3">
        <button
          type="button"
          onClick={() => setExpanded((v) => !v)}
          className="flex items-center gap-1.5 text-xs font-medium text-muted-foreground hover:text-foreground"
        >
          {expanded ? <ChevronUp className="h-3.5 w-3.5" /> : <ChevronDown className="h-3.5 w-3.5" />}
          {expanded ? "Hide" : "Show"} Sophia's final feedback
        </button>
        {expanded && (
          <div className="prose prose-sm prose-invert max-w-none max-h-[300px] overflow-y-auto rounded-md bg-secondary/40 p-3 border border-border/40 text-xs">
            <ReactMarkdown>{findings || "_Loading…_"}</ReactMarkdown>
          </div>
        )}
        <div className="flex flex-wrap gap-2 pt-1">
          <Button onClick={handleForceAccept} disabled={!!busy} variant="default">
            {busy === "accept" ? (
              <><Loader2 className="h-3.5 w-3.5 mr-1.5 animate-spin" /> Sending to Ethan…</>
            ) : (
              <><AlertOctagon className="h-3.5 w-3.5 mr-1.5" /> Force Accept and Send to Ethan</>
            )}
          </Button>
          <Button onClick={handleDiscardRestart} disabled={!!busy} variant="outline">
            {busy === "discard" ? (
              <><Loader2 className="h-3.5 w-3.5 mr-1.5 animate-spin" /> Restarting…</>
            ) : (
              <><Trash2 className="h-3.5 w-3.5 mr-1.5" /> Discard and Restart this Prompt</>
            )}
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
