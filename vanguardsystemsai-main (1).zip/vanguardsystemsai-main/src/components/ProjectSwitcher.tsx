import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Plus, ChevronsUpDown, FolderKanban } from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { useProjects } from "@/contexts/ProjectContext";
import { Badge } from "@/components/ui/badge";
import { projectModeLabel } from "@/lib/agent-status";
import { useState } from "react";
import { NewProjectDialog } from "./NewProjectDialog";

export function ProjectSwitcher() {
  const { projects, currentProject, setCurrentProject } = useProjects();
  const [open, setOpen] = useState(false);
  const navigate = useNavigate();

  return (
    <>
      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <Button variant="outline" className="gap-2 h-10 min-w-[260px] justify-between bg-card/60">
            <div className="flex items-center gap-2 truncate">
              <FolderKanban className="h-4 w-4 text-primary" />
              <span className="truncate font-medium">
                {currentProject?.name ?? "No project selected"}
              </span>
              {currentProject && (
                <Badge variant="secondary" className="text-[10px] uppercase tracking-wider">
                  {projectModeLabel[currentProject.mode]}
                </Badge>
              )}
            </div>
            <ChevronsUpDown className="h-4 w-4 opacity-60" />
          </Button>
        </DropdownMenuTrigger>
        <DropdownMenuContent align="start" className="w-[320px]">
          <DropdownMenuLabel className="text-xs text-muted-foreground uppercase tracking-wider">
            Projects ({projects.length})
          </DropdownMenuLabel>
          <DropdownMenuSeparator />
          {projects.length === 0 && (
            <div className="px-2 py-3 text-sm text-muted-foreground">
              No projects yet. Create one to begin.
            </div>
          )}
          {projects.map((p) => (
            <DropdownMenuItem
              key={p.id}
              onClick={() => {
                setCurrentProject(p);
                navigate("/");
              }}
              className="flex items-center justify-between gap-2"
            >
              <span className="truncate">{p.name}</span>
              <Badge variant="outline" className="text-[10px]">
                {projectModeLabel[p.mode]}
              </Badge>
            </DropdownMenuItem>
          ))}
          <DropdownMenuSeparator />
          <DropdownMenuItem onClick={() => setOpen(true)} className="text-primary">
            <Plus className="h-4 w-4 mr-2" />
            New project
          </DropdownMenuItem>
        </DropdownMenuContent>
      </DropdownMenu>
      <NewProjectDialog open={open} onOpenChange={setOpen} />
    </>
  );
}
