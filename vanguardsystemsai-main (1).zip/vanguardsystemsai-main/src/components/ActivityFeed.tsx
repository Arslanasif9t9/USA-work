import { useEffect, useRef, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useProjects } from "@/contexts/ProjectContext";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ScrollArea } from "@/components/ui/scroll-area";
import { cn } from "@/lib/utils";
import { Activity } from "lucide-react";

interface LogRow {
  id: string;
  agent_id: string | null;
  agent_name: string;
  level: string;
  message: string;
  created_at: string;
}

export function ActivityFeed() {
  const { currentProject } = useProjects();
  const [logs, setLogs] = useState<LogRow[]>([]);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    let active = true;
    const load = async () => {
      let q = supabase.from("agent_log").select("*").order("created_at", { ascending: false }).limit(80);
      if (currentProject) q = q.eq("project_id", currentProject.id);
      const { data } = await q;
      if (active) setLogs((data ?? []) as LogRow[]);
    };
    load();

    const channel = supabase
      .channel(`activity-${currentProject?.id ?? "all"}`)
      .on(
        "postgres_changes",
        { event: "INSERT", schema: "public", table: "agent_log" },
        (payload) => {
          const row = payload.new as LogRow & { project_id: string | null };
          if (currentProject && row.project_id !== currentProject.id) return;
          setLogs((prev) => [row, ...prev].slice(0, 80));
        },
      )
      .subscribe();

    return () => {
      active = false;
      supabase.removeChannel(channel);
    };
  }, [currentProject?.id]);

  return (
    <Card className="card-elev">
      <CardHeader className="pb-3">
        <CardTitle className="text-sm flex items-center gap-2">
          <Activity className="h-4 w-4 text-primary" /> Activity feed
          {currentProject && <span className="text-xs text-muted-foreground font-normal">· {currentProject.name}</span>}
        </CardTitle>
      </CardHeader>
      <CardContent className="p-0">
        <ScrollArea className="h-[520px]" ref={scrollRef as any}>
          <div className="px-4 pb-4 space-y-2">
            {logs.length === 0 && (
              <div className="text-sm text-muted-foreground py-8 text-center">
                All agents sleeping. Mark the current prompt as delivered to continue the workflow.
              </div>
            )}
            {logs.map((l) => (
              <div key={l.id} className="text-xs border-l-2 border-border pl-2.5 py-1 animate-fade-in">
                <div className="flex items-baseline gap-2">
                  <span className={cn(
                    "font-semibold",
                    l.level === "error" ? "text-destructive" : l.level === "warn" ? "text-warning" : "text-primary",
                  )}>
                    {l.agent_name}
                  </span>
                  <span className="text-[10px] text-muted-foreground font-mono">
                    {new Date(l.created_at).toLocaleTimeString()}
                  </span>
                </div>
                <div className="text-foreground/90">{l.message}</div>
              </div>
            ))}
          </div>
        </ScrollArea>
      </CardContent>
    </Card>
  );
}
