import { Loader2, FlaskConical, PenLine, ShieldCheck, Sparkles, AlertTriangle, CheckCircle2, AlertOctagon } from "lucide-react";
import { ChainPhase, chainPhaseLabel } from "@/hooks/useChainStatus";
import { cn } from "@/lib/utils";

interface Props {
  phase: ChainPhase;
  /** When true, render a smaller, more compact version (for project cards). */
  compact?: boolean;
  onViewRevision?: (reportId: string) => void;
}

/**
 * Visual indicator for the current cycle phase. Drives the same source of truth as
 * the agents page — animated pulse while a step is in progress, calm pill when idle.
 */
export function ChainStatusBadge({ phase, compact, onViewRevision }: Props) {
  const label = chainPhaseLabel(phase);

  // Map each phase to: icon, semantic color tokens, and whether it should pulse.
  const visuals: { icon: React.ReactNode; classes: string; pulse: boolean } = (() => {
    switch (phase.kind) {
      case "researching":
        return {
          icon: <FlaskConical className="h-3.5 w-3.5" />,
          classes: "border-primary/40 bg-primary/10 text-primary",
          pulse: true,
        };
      case "drafting_copy":
        return {
          icon: <PenLine className="h-3.5 w-3.5" />,
          classes: "border-primary/40 bg-primary/10 text-primary",
          pulse: true,
        };
      case "qa_review":
        return {
          icon: <ShieldCheck className="h-3.5 w-3.5" />,
          classes: "border-warning/40 bg-warning/10 text-warning",
          pulse: true,
        };
      case "architect_drafting":
        return {
          icon: <Sparkles className="h-3.5 w-3.5" />,
          classes: "border-primary/40 bg-primary/10 text-primary",
          pulse: true,
        };
      case "needs_revision":
        return {
          icon: <AlertTriangle className="h-3.5 w-3.5" />,
          classes: "border-warning/40 bg-warning/10 text-warning",
          pulse: false,
        };
      case "escalated":
        return {
          icon: <AlertOctagon className="h-3.5 w-3.5" />,
          classes: "border-destructive/40 bg-destructive/10 text-destructive",
          pulse: false,
        };
      case "prompt_ready":
        return {
          icon: <CheckCircle2 className="h-3.5 w-3.5" />,
          classes: "border-primary/40 bg-primary/15 text-primary",
          pulse: false,
        };
      case "idle":
      default:
        return {
          icon: null,
          classes: "border-border bg-secondary/40 text-muted-foreground",
          pulse: false,
        };
    }
  })();

  const showRevisionButton =
    (phase.kind === "needs_revision" || phase.kind === "escalated") && !!onViewRevision;

  return (
    <div className={cn("inline-flex items-center gap-2", compact ? "text-[11px]" : "text-xs")}>
      <span
        className={cn(
          "inline-flex items-center gap-1.5 rounded-full border px-2 py-0.5 font-medium",
          visuals.classes,
        )}
      >
        {visuals.pulse && <Loader2 className="h-3 w-3 animate-spin" />}
        {!visuals.pulse && visuals.icon}
        <span>{label}</span>
      </span>
      {showRevisionButton && (
        <button
          type="button"
          onClick={() => onViewRevision!(phase.kind === "needs_revision" || phase.kind === "escalated" ? phase.reportId : "")}
          className="text-[11px] underline text-muted-foreground hover:text-foreground transition-colors"
        >
          View notes
        </button>
      )}
    </div>
  );
}
