import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tooltip, TooltipContent, TooltipTrigger } from "@/components/ui/tooltip";
import { Copy, CheckCircle2, Loader2, ShieldCheck } from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import type { ReadyPrompt } from "@/hooks/useReadyPrompts";
import { cn } from "@/lib/utils";

interface Props {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  prompts: ReadyPrompt[];
  /** Called after a successful "Mark Delivered" so the parent can fire run-cycle. */
  onDelivered?: (prompt: ReadyPrompt) => void;
  /**
   * Status of the project for the active prompt. When omitted the dialog assumes 'active'.
   * When not 'active', "Mark as Delivered" is disabled and "Project Complete" is hidden.
   */
  projectStatus?: "active" | "paused" | "complete" | "archived";
  /** Project name to display in the Mark-Complete confirmation. */
  projectName?: string;
  /**
   * Called when the user confirms "Project Complete" for the active prompt's project.
   * Parent should mark `projects.status = 'complete'` (server-side or client-side).
   */
  onMarkProjectComplete?: (projectId: string) => Promise<void> | void;
}

export function ReadyPromptDialog({
  open,
  onOpenChange,
  prompts,
  onDelivered,
  projectStatus = "active",
  projectName,
  onMarkProjectComplete,
}: Props) {
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [confirmComplete, setConfirmComplete] = useState(false);
  const [completing, setCompleting] = useState(false);

  const active = prompts.find((p) => p.id === selectedId) ?? prompts[0];
  const isActive = projectStatus === "active";
  const blockedReason =
    projectStatus === "complete"
      ? "Project is complete. Force-reopen to continue."
      : projectStatus === "paused"
      ? "Project is on hold. Resume it to continue."
      : null;

  const copy = async (p: ReadyPrompt) => {
    try {
      await navigator.clipboard.writeText(p.content_md);
      toast.success(`Prompt #${p.sequence_number} copied to clipboard.`);
    } catch {
      toast.error("Could not copy. Use Ctrl/Cmd+C.");
    }
  };

  const markDelivered = async (p: ReadyPrompt) => {
    if (!isActive) {
      toast.error(blockedReason ?? "Project is not active.");
      return;
    }
    setBusy(true);
    const { error } = await supabase
      .from("lovable_prompts")
      .update({ status: "delivered", delivered_at: new Date().toISOString() })
      .eq("id", p.id);
    setBusy(false);
    if (error) {
      toast.error(error.message);
      return;
    }
    toast.success(`Prompt #${p.sequence_number} marked delivered.`);
    onDelivered?.(p);
    if (prompts.length <= 1) onOpenChange(false);
    else setSelectedId(null);
  };

  const confirmMarkComplete = async () => {
    if (!active || !onMarkProjectComplete) return;
    setCompleting(true);
    try {
      await onMarkProjectComplete(active.project_id);
      toast.success(`${projectName ?? "Project"} marked complete.`);
      setConfirmComplete(false);
      onOpenChange(false);
    } catch (e: any) {
      toast.error(e?.message ?? "Could not mark project complete.");
    } finally {
      setCompleting(false);
    }
  };

  if (!active) return null;

  return (
    <>
      <Dialog open={open} onOpenChange={onOpenChange}>
        <DialogContent className="max-w-3xl max-h-[85vh] overflow-hidden flex flex-col">
          <DialogHeader>
            <div className="flex items-start justify-between gap-3 flex-wrap">
              <div className="min-w-0">
                <DialogTitle className="flex items-center gap-2 flex-wrap">
                  <span className="text-primary">✨</span>
                  Prompt #{active.sequence_number} — {active.title}
                </DialogTitle>
                <DialogDescription>Authored by Ethan · ready for delivery</DialogDescription>
              </div>
              <Badge className="bg-primary text-primary-foreground shrink-0">ready</Badge>
            </div>
          </DialogHeader>

          {prompts.length > 1 && (
            <div className="flex flex-wrap gap-2 border-b border-border/40 pb-3">
              <span className="text-xs text-muted-foreground self-center">
                {prompts.length} prompts ready:
              </span>
              {prompts.map((p) => (
                <button
                  key={p.id}
                  onClick={() => setSelectedId(p.id)}
                  className={cn(
                    "text-xs px-2 py-1 rounded border transition-colors",
                    p.id === active.id
                      ? "bg-primary text-primary-foreground border-primary"
                      : "bg-secondary border-border hover:bg-accent",
                  )}
                >
                  #{p.sequence_number}
                </button>
              ))}
            </div>
          )}

          {!isActive && blockedReason && (
            <div className="rounded-md border border-info/40 bg-info/10 text-info px-3 py-2 text-xs">
              {blockedReason}
            </div>
          )}

          <div className="flex-1 overflow-y-auto rounded-md bg-secondary/40 p-4 border border-border/40">
            <pre className="whitespace-pre-wrap font-mono text-xs leading-relaxed text-foreground">
              {active.content_md}
            </pre>
          </div>

          <div className="flex items-center justify-end gap-2 pt-2 flex-wrap">
            <Button variant="outline" onClick={() => copy(active)}>
              <Copy className="h-4 w-4 mr-1" /> Copy Full Prompt
            </Button>

            {/* Mark as Delivered — disabled & tooltip when not active */}
            <Tooltip>
              <TooltipTrigger asChild>
                <span>
                  <Button
                    onClick={() => markDelivered(active)}
                    disabled={busy || !isActive}
                    className="bg-primary hover:bg-primary/90"
                  >
                    {busy ? (
                      <><Loader2 className="h-4 w-4 mr-1 animate-spin" /> Marking…</>
                    ) : (
                      <><CheckCircle2 className="h-4 w-4 mr-1" /> Mark as Delivered</>
                    )}
                  </Button>
                </span>
              </TooltipTrigger>
              {!isActive && blockedReason && <TooltipContent>{blockedReason}</TooltipContent>}
            </Tooltip>

            {/* Project Complete — only visible when active and a handler is provided */}
            {isActive && onMarkProjectComplete && (
              <Button
                variant="outline"
                onClick={() => setConfirmComplete(true)}
                className="border-primary/40 text-primary hover:text-primary hover:bg-primary/10 hover:border-primary/60"
              >
                <ShieldCheck className="h-4 w-4 mr-1" /> ✓ Project Complete
              </Button>
            )}
          </div>
        </DialogContent>
      </Dialog>

      {/* Confirm: Mark project complete */}
      <Dialog open={confirmComplete} onOpenChange={(v) => !completing && setConfirmComplete(v)}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Mark {projectName ?? "this project"} as complete?</DialogTitle>
            <DialogDescription>
              This will stop all agents from producing new prompts for this project. You can
              force-reopen it anytime with the password.
            </DialogDescription>
          </DialogHeader>
          <div className="flex justify-end gap-2 pt-2">
            <Button
              variant="outline"
              onClick={() => setConfirmComplete(false)}
              disabled={completing}
            >
              Cancel
            </Button>
            <Button
              onClick={confirmMarkComplete}
              disabled={completing}
              className="bg-primary hover:bg-primary/90 text-primary-foreground"
            >
              {completing ? (
                <><Loader2 className="h-4 w-4 mr-1 animate-spin" /> Marking…</>
              ) : (
                <><CheckCircle2 className="h-4 w-4 mr-1" /> Mark Complete</>
              )}
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
}
