import { useEffect, useState, useCallback } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { AlertOctagon, Loader2, Wrench } from "lucide-react";
import { toast } from "sonner";

interface StuckAgent {
  id: string;
  name: string;
  current_task: string | null;
  updated_at: string;
}

/**
 * Banner that appears on the Agents page whenever one or more agents have been
 * sitting in "working" state for more than 60 seconds. Lets the operator
 * recover them in one click via the recover-stuck-agents edge function.
 */
export function StuckAgentsBanner() {
  const [stuck, setStuck] = useState<StuckAgent[]>([]);
  const [recovering, setRecovering] = useState(false);

  const refresh = useCallback(async () => {
    const { data } = await supabase
      .from("agents")
      .select("id,name,status,current_task,updated_at")
      .eq("status", "working");
    const now = Date.now();
    const filtered = (data ?? []).filter((a: any) => {
      if (!a.updated_at) return true;
      return now - new Date(a.updated_at).getTime() > 60_000;
    }) as StuckAgent[];
    setStuck(filtered);
  }, []);

  useEffect(() => {
    refresh();
    // Re-check every 15s while the page is open so a freshly-stuck agent surfaces quickly.
    const interval = setInterval(refresh, 15_000);
    const ch = supabase
      .channel("stuck-agents-banner")
      .on("postgres_changes", { event: "*", schema: "public", table: "agents" }, () => refresh())
      .subscribe();
    return () => {
      clearInterval(interval);
      supabase.removeChannel(ch);
    };
  }, [refresh]);

  if (stuck.length === 0) return null;

  const handleRecover = async () => {
    setRecovering(true);
    try {
      const { data, error } = await supabase.functions.invoke("recover-stuck-agents", {
        body: { force: true },
      });
      if (error || !data?.ok) {
        toast.error(data?.error || error?.message || "Recovery failed.");
        return;
      }
      toast.success(data.message ?? "Recovery complete.");
      await refresh();
    } finally {
      setRecovering(false);
    }
  };

  const ageLabel = (updated: string) => {
    const secs = Math.round((Date.now() - new Date(updated).getTime()) / 1000);
    if (secs < 60) return `${secs}s`;
    const mins = Math.floor(secs / 60);
    return `${mins}m ${secs - mins * 60}s`;
  };

  return (
    <div className="flex items-start gap-3 p-4 rounded-md border border-destructive/40 bg-destructive/5">
      <AlertOctagon className="h-5 w-5 text-destructive shrink-0 mt-0.5" />
      <div className="flex-1 text-sm">
        <div className="font-medium text-destructive">
          {stuck.length === 1
            ? `${stuck[0].name} appears stuck`
            : `${stuck.length} agents appear stuck`}
        </div>
        <ul className="mt-1.5 space-y-0.5 text-xs text-muted-foreground">
          {stuck.map((a) => (
            <li key={a.id}>
              <span className="font-medium text-foreground">{a.name}</span> · in "working" for{" "}
              <span className="font-mono">{ageLabel(a.updated_at)}</span>
              {a.current_task ? <> — {a.current_task}</> : null}
            </li>
          ))}
        </ul>
        <div className="text-[11px] text-muted-foreground mt-1.5">
          Likely cause: the edge runtime worker shut down mid-call. Recover them and re-trigger from their card.
        </div>
      </div>
      <Button size="sm" variant="outline" onClick={handleRecover} disabled={recovering} className="shrink-0">
        {recovering ? <Loader2 className="h-3.5 w-3.5 mr-1.5 animate-spin" /> : <Wrench className="h-3.5 w-3.5 mr-1.5" />}
        Recover {stuck.length === 1 ? "agent" : "all"}
      </Button>
    </div>
  );
}
