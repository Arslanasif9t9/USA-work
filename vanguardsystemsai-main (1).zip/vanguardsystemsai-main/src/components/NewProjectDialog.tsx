import { useState } from "react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { useProjects } from "@/contexts/ProjectContext";
import { toast } from "sonner";
import { X, Plus } from "lucide-react";

interface Props {
  open: boolean;
  onOpenChange: (v: boolean) => void;
}

const slugify = (s: string) =>
  s
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-|-$/g, "")
    .slice(0, 60) || `project-${Date.now()}`;

export function NewProjectDialog({ open, onOpenChange }: Props) {
  const { user } = useAuth();
  const { refresh, setCurrentProject } = useProjects();
  const [name, setName] = useState("");
  const [description, setDescription] = useState("");
  const [mode, setMode] = useState<"build_new" | "fix_existing" | "research_only" | "full_stack_service">("build_new");
  const [techStack, setTechStack] = useState("Lovable React+Vite+Supabase");
  const [refUrls, setRefUrls] = useState<string[]>([""]);
  const [existingUrl, setExistingUrl] = useState("");
  const [intake, setIntake] = useState("");
  const [saving, setSaving] = useState(false);

  const reset = () => {
    setName("");
    setDescription("");
    setMode("build_new");
    setTechStack("Lovable React+Vite+Supabase");
    setRefUrls([""]);
    setExistingUrl("");
    setIntake("");
  };

  const submit = async () => {
    if (!user) return;
    if (!name.trim()) {
      toast.error("Project name is required.");
      return;
    }
    const cleanRefs = refUrls.map((u) => u.trim()).filter(Boolean);
    setSaving(true);
    const { data, error } = await supabase
      .from("projects")
      .insert({
        owner_id: user.id,
        name: name.trim(),
        slug: slugify(name) + "-" + Math.random().toString(36).slice(2, 6),
        description: description.trim() || null,
        mode,
        reference_urls: cleanRefs,
        existing_site_url: mode === "fix_existing" ? existingUrl.trim() || null : null,
        tech_stack_target: techStack.trim() || "Lovable React+Vite+Supabase",
        intake_notes: intake.trim() || null,
      })
      .select()
      .single();
    setSaving(false);
    if (error) {
      toast.error(error.message);
      return;
    }
    toast.success(`Created project "${data.name}".`);
    await refresh();
    setCurrentProject(data as any);
    reset();
    onOpenChange(false);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-xl">
        <DialogHeader>
          <DialogTitle>New project</DialogTitle>
          <DialogDescription>
            Spin up a new project for the team. They'll work on it whenever you trigger them.
          </DialogDescription>
        </DialogHeader>

        <div className="grid gap-4 py-2 max-h-[60vh] overflow-y-auto pr-1">
          <div className="grid gap-2">
            <Label htmlFor="name">Name</Label>
            <Input id="name" value={name} onChange={(e) => setName(e.target.value)} placeholder="AstroGuide" />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div className="grid gap-2">
              <Label>Mode</Label>
              <Select value={mode} onValueChange={(v: any) => setMode(v)}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="build_new">Build new</SelectItem>
                  <SelectItem value="fix_existing">Fix existing</SelectItem>
                  <SelectItem value="research_only">Research only</SelectItem>
                  <SelectItem value="full_stack_service">Full-stack service</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="grid gap-2">
              <Label htmlFor="ts">Target tech stack</Label>
              <Input id="ts" value={techStack} onChange={(e) => setTechStack(e.target.value)} />
            </div>
          </div>

          <div className="grid gap-2">
            <Label htmlFor="desc">Description</Label>
            <Textarea id="desc" rows={2} value={description} onChange={(e) => setDescription(e.target.value)} placeholder="What is this project?" />
          </div>

          <div className="grid gap-2">
            <Label>Reference URLs</Label>
            {refUrls.map((u, i) => (
              <div key={i} className="flex gap-2">
                <Input
                  value={u}
                  onChange={(e) => {
                    const arr = [...refUrls];
                    arr[i] = e.target.value;
                    setRefUrls(arr);
                  }}
                  placeholder="https://example.com"
                />
                <Button
                  type="button"
                  variant="ghost"
                  size="icon"
                  onClick={() => setRefUrls(refUrls.filter((_, idx) => idx !== i))}
                  disabled={refUrls.length === 1}
                >
                  <X className="h-4 w-4" />
                </Button>
              </div>
            ))}
            <Button type="button" variant="outline" size="sm" className="w-fit" onClick={() => setRefUrls([...refUrls, ""])}>
              <Plus className="h-3 w-3 mr-1" /> Add URL
            </Button>
          </div>

          {mode === "fix_existing" && (
            <div className="grid gap-2">
              <Label htmlFor="ex">Existing site URL (to fix)</Label>
              <Input id="ex" value={existingUrl} onChange={(e) => setExistingUrl(e.target.value)} placeholder="https://mysite.com" />
            </div>
          )}

          <div className="grid gap-2">
            <Label htmlFor="intake">Intake notes (optional)</Label>
            <Textarea id="intake" rows={3} value={intake} onChange={(e) => setIntake(e.target.value)} placeholder="Anything the agents should know before starting…" />
          </div>
        </div>

        <DialogFooter>
          <Button variant="ghost" onClick={() => onOpenChange(false)} disabled={saving}>Cancel</Button>
          <Button onClick={submit} disabled={saving}>{saving ? "Creating…" : "Create project"}</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
