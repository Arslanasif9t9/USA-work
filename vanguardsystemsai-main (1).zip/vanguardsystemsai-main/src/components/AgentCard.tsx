import { motion, AnimatePresence } from "framer-motion";
import { Card, CardContent } from "@/components/ui/card";
import { Switch } from "@/components/ui/switch";
import { Button } from "@/components/ui/button";
import { MessageCircle, Power, Lock, Hourglass, Loader2, RefreshCw, Sparkles, ChevronRight, AlertCircle } from "lucide-react";
import { statusConfig, AgentStatus } from "@/lib/agent-status";
import { cn } from "@/lib/utils";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";

export interface Agent {
  id: string;
  name: string;
  role: string;
  title: string;
  avatar_url: string;
  attire: string;
  enabled: boolean;
  status: AgentStatus;
  current_task: string | null;
  last_run: string | null;
  tokens_today: number;
  cost_today_usd: number;
  daily_budget_usd: number;
  model: string;
  reports_to: string | null;
  failure_flag?: boolean;
  last_error_message?: string | null;
}

interface Props {
  agent: Agent;
  reportsToName?: string;
  onToggle: (enabled: boolean) => void;
  onChat: () => void;
  onReport: () => void;
  onRetry?: () => void;
  retrying?: boolean;
  onRegenerateAvatar?: () => void;
  regeneratingAvatar?: boolean;
  /** Number of prompts authored by this agent currently in 'ready' status. */
  readyPromptCount?: number;
  /** First ready prompt's sequence number, used for the CTA label. */
  firstReadySeq?: number;
  onViewReady?: () => void;
}

export function AgentCard({
  agent,
  reportsToName,
  onToggle,
  onChat,
  onReport,
  onRetry,
  retrying = false,
  onRegenerateAvatar,
  regeneratingAvatar,
  readyPromptCount = 0,
  firstReadySeq,
  onViewReady,
}: Props) {
  const cfg = statusConfig[agent.status];
  const budgetPct = Math.min(100, (Number(agent.cost_today_usd) / Number(agent.daily_budget_usd)) * 100);
  const budgetColor = budgetPct < 50 ? "bg-primary" : budgetPct < 85 ? "bg-warning" : "bg-destructive";

  return (
    <motion.div
      layout
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3 }}
    >
      <Card
        className={cn(
          "relative overflow-hidden border-border/60 transition-all",
          agent.status === "off" && "opacity-60",
          agent.status === "working" && "border-primary/50 glow-green",
          agent.status === "standby" && "border-warning/50",
          agent.status === "paused" && "border-warning/50",
          agent.status === "budget_paused" && "border-status-budget/50",
        )}
      >
        <CardContent className="p-5">
          <div className="flex items-start gap-4">
            {/* Avatar with status overlay */}
            <div className="relative shrink-0 group">
              <motion.div
                animate={
                  agent.status === "working"
                    ? { boxShadow: ["0 0 0 0 hsl(var(--primary)/0.7)", "0 0 0 16px hsl(var(--primary)/0)"] }
                    : {}
                }
                transition={{ duration: 1.6, repeat: Infinity }}
                className={cn(
                  "h-16 w-16 rounded-full ring-2 overflow-hidden bg-secondary",
                  cfg.ring,
                  agent.status === "off" && "opacity-40",
                )}
              >
                <img
                  src={agent.avatar_url}
                  alt={`${agent.name} headshot`}
                  loading="lazy"
                  className={cn("h-full w-full object-cover transition-opacity", regeneratingAvatar && "opacity-30")}
                  onError={(e) => {
                    const t = e.currentTarget;
                    if (!t.dataset.fallback) {
                      t.dataset.fallback = "1";
                      t.src = `https://api.dicebear.com/9.x/personas/svg?seed=${encodeURIComponent(agent.name)}`;
                    }
                  }}
                />
              </motion.div>

              {regeneratingAvatar && (
                <div className="absolute inset-0 grid place-items-center pointer-events-none">
                  <Loader2 className="h-5 w-5 animate-spin text-primary" />
                </div>
              )}

              {onRegenerateAvatar && !regeneratingAvatar && (
                <TooltipProvider delayDuration={200}>
                  <Tooltip>
                    <TooltipTrigger asChild>
                      <button
                        type="button"
                        onClick={onRegenerateAvatar}
                        aria-label={`Regenerate avatar for ${agent.name}`}
                        className="absolute -top-1 -left-1 h-6 w-6 rounded-full bg-background border border-border text-muted-foreground hover:text-primary hover:border-primary opacity-0 group-hover:opacity-100 transition-opacity grid place-items-center shadow-sm"
                      >
                        <RefreshCw className="h-3 w-3" />
                      </button>
                    </TooltipTrigger>
                    <TooltipContent side="top">Regenerate avatar</TooltipContent>
                  </Tooltip>
                </TooltipProvider>
              )}

              {/* Waiting / failed indicator */}
              <AnimatePresence>
                {agent.status === "sleeping" && !agent.failure_flag && (
                  <motion.div
                    key="waiting"
                    initial={{ opacity: 0, scale: 0.6 }}
                    animate={{ opacity: 1, scale: 1 }}
                    exit={{ opacity: 0 }}
                    className="absolute -bottom-1 -right-1 h-6 w-6 rounded-full bg-status-sleeping/20 ring-2 ring-background grid place-items-center"
                    aria-label="Waiting for next task"
                  >
                    <motion.span
                      animate={{ opacity: [0.4, 1, 0.4], scale: [0.85, 1, 0.85] }}
                      transition={{ duration: 2.2, repeat: Infinity, ease: "easeInOut" }}
                      className="h-2 w-2 rounded-full bg-status-sleeping inline-block"
                    />
                  </motion.div>
                )}
              </AnimatePresence>

              {agent.status === "sleeping" && agent.failure_flag && (
                <div
                  className="absolute -bottom-1 -right-1 h-6 w-6 rounded-full bg-destructive/15 ring-2 ring-background grid place-items-center"
                  aria-label="Agent failed and is ready to retry"
                  title={agent.last_error_message ?? "Last run failed"}
                >
                  <AlertCircle className="h-3.5 w-3.5 text-destructive" />
                </div>
              )}

              {agent.status === "working" && (
                <motion.div
                  className="absolute -bottom-1 -right-1 h-6 w-6 rounded-full bg-primary grid place-items-center text-primary-foreground"
                  animate={{ rotate: 360 }}
                  transition={{ duration: 2, repeat: Infinity, ease: "linear" }}
                >
                  <Loader2 className="h-3.5 w-3.5" />
                </motion.div>
              )}

              {agent.status === "standby" && (
                <motion.div
                  className="absolute -bottom-1 -right-1 h-6 w-6 rounded-full bg-warning grid place-items-center text-warning-foreground"
                  animate={{ rotate: 360 }}
                  transition={{ duration: 6, repeat: Infinity, ease: "linear" }}
                >
                  <Hourglass className="h-3.5 w-3.5" />
                </motion.div>
              )}

              {agent.status === "paused" && (
                <div className="absolute -bottom-1 -right-1 h-6 w-6 rounded-full bg-warning grid place-items-center">
                  <Hourglass className="h-3.5 w-3.5 text-warning-foreground" />
                </div>
              )}

              {agent.status === "off" && (
                <div className="absolute -bottom-1 -right-1 h-6 w-6 rounded-full bg-destructive grid place-items-center">
                  <Power className="h-3.5 w-3.5 text-destructive-foreground" />
                </div>
              )}

              {agent.status === "budget_paused" && (
                <div className="absolute -bottom-1 -right-1 h-6 w-6 rounded-full bg-status-budget grid place-items-center">
                  <Lock className="h-3.5 w-3.5 text-warning-foreground" />
                </div>
              )}

              {/* Pulsing green "prompt ready" dot — top-right of avatar */}
              {readyPromptCount > 0 && (
                <span className="absolute -top-1 -right-1 flex h-3.5 w-3.5" aria-label={`${readyPromptCount} prompt${readyPromptCount > 1 ? "s" : ""} ready`}>
                  <span className="absolute inline-flex h-full w-full rounded-full bg-primary opacity-75 animate-ping" />
                  <span className="relative inline-flex rounded-full h-3.5 w-3.5 bg-primary ring-2 ring-background" />
                </span>
              )}
            </div>

            <div className="flex-1 min-w-0">
              <div className="flex items-start justify-between gap-3">
                <div className="min-w-0 flex-1">
                  <div
                    className="font-semibold leading-snug break-words"
                    title={agent.attire}
                  >
                    {agent.name}
                  </div>
                  <div className="text-xs text-muted-foreground leading-snug break-words mt-0.5">
                    {agent.title}
                  </div>

                  {/* Inline elegant prompt-ready pill */}
                  {readyPromptCount > 0 && onViewReady && (
                    <motion.button
                      type="button"
                      onClick={onViewReady}
                      initial={{ opacity: 0, y: 2 }}
                      animate={{ opacity: 1, y: 0 }}
                      whileHover={{ y: -1 }}
                      whileTap={{ scale: 0.97 }}
                      className="group mt-2 inline-flex items-center gap-1.5 h-8 pl-2.5 pr-2 rounded-full text-[13px] font-medium text-white bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 shadow-sm shadow-emerald-900/30 ring-1 ring-emerald-400/20 transition-all"
                    >
                      <Sparkles className="h-3.5 w-3.5 opacity-90" />
                      <span className="leading-none">
                        {readyPromptCount > 1
                          ? `${readyPromptCount} prompts ready`
                          : `Prompt #${firstReadySeq} ready`}
                      </span>
                      <span className="inline-flex items-center justify-center h-5 w-5 rounded-full bg-white/15 group-hover:bg-white/25 transition-colors">
                        <ChevronRight className="h-3 w-3" />
                      </span>
                    </motion.button>
                  )}
                </div>
                <Switch checked={agent.enabled} onCheckedChange={onToggle} className="shrink-0 mt-1" />
              </div>

              <div className={cn("text-xs mt-3 font-medium leading-snug break-words", cfg.color)}>
                {agent.failure_flag
                  ? "Failed — retry available"
                  : agent.status === "working" && agent.current_task
                  ? agent.current_task
                  : agent.status === "standby" && reportsToName
                  ? `Standby — waiting for ${reportsToName}`
                  : cfg.subtitle}
              </div>

              {agent.failure_flag && (
                <div className="mt-1 space-y-2">
                  {agent.last_error_message && (
                    <div className="text-[11px] leading-snug text-destructive break-words">
                      {agent.last_error_message}
                    </div>
                  )}
                  {onRetry && (
                    <Button
                      size="sm"
                      variant="outline"
                      className="h-8 text-xs px-3"
                      onClick={onRetry}
                      disabled={retrying}
                    >
                      {retrying ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <RefreshCw className="h-3.5 w-3.5" />}
                      Retry agent
                    </Button>
                  )}
                </div>
              )}

              {/* Budget bar */}
              <div className="mt-4 space-y-1">
                <div className="flex justify-between text-[10px] text-muted-foreground font-mono gap-2">
                  <span>${Number(agent.cost_today_usd).toFixed(4)} / ${Number(agent.daily_budget_usd).toFixed(2)}</span>
                  <span>{agent.tokens_today.toLocaleString()} tok</span>
                </div>
                <div className="h-1.5 rounded-full bg-secondary overflow-hidden">
                  <div className={cn("h-full transition-all", budgetColor)} style={{ width: `${budgetPct}%` }} />
                </div>
              </div>

              <div className="mt-4 flex flex-wrap gap-3">
                <Button size="sm" variant="outline" className="h-8 text-xs px-3" onClick={onChat}>
                  <MessageCircle className="h-3.5 w-3.5 mr-1.5" /> Chat
                </Button>
                <Button size="sm" variant="ghost" className="h-8 text-xs px-3" onClick={onReport}>
                  Report
                </Button>
              </div>

              <div className="mt-3 text-[10px] text-muted-foreground font-mono break-words leading-snug">
                {agent.model} · last run {agent.last_run ? new Date(agent.last_run).toLocaleString() : "never"}
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
}
