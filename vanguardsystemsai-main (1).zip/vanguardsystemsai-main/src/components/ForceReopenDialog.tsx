import { useEffect, useState } from "react";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Loader2, Unlock } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";

interface Props {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  projectId: string | null;
  projectName: string | null;
  /** Called after a successful reopen so parents can refresh state. */
  onReopened?: () => void;
}

const LOCKOUT_SECONDS = 60;

/**
 * Force-reopen a completed project. Password validation happens server-side
 * in the `project-status` edge function — we never validate `2828` in the client.
 * Three wrong attempts (server-tracked too) lock the modal for 60s.
 */
export function ForceReopenDialog({ open, onOpenChange, projectId, projectName, onReopened }: Props) {
  const [password, setPassword] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [wrongCount, setWrongCount] = useState(0);
  const [lockedUntil, setLockedUntil] = useState<number | null>(null);
  const [now, setNow] = useState(Date.now());

  useEffect(() => {
    if (!open) {
      // Reset transient error/password when closed (but keep lockout — it's enforced server-side).
      setPassword("");
      setError(null);
    }
  }, [open]);

  // Tick once a second while locked so the countdown updates.
  useEffect(() => {
    if (!lockedUntil) return;
    const id = setInterval(() => setNow(Date.now()), 1000);
    return () => clearInterval(id);
  }, [lockedUntil]);

  const isLocked = !!lockedUntil && now < lockedUntil;
  const secondsLeft = isLocked && lockedUntil ? Math.ceil((lockedUntil - now) / 1000) : 0;

  const submit = async () => {
    if (!projectId) return;
    if (isLocked) return;
    if (!password) {
      setError("Enter the password.");
      return;
    }
    setBusy(true);
    setError(null);
    const { data, error: invokeError } = await supabase.functions.invoke("project-status", {
      body: { projectId, action: "force_reopen", password },
    });
    setBusy(false);

    // Edge functions surface our 4xx body inside `data` even when status != 200.
    const errMsg = (data as any)?.error ?? invokeError?.message;
    const lockedFromServer = (data as any)?.lockedUntil as number | undefined;

    if (lockedFromServer) {
      setLockedUntil(lockedFromServer);
      setWrongCount(0);
      setPassword("");
      setError(`Too many attempts — try again in ${Math.ceil((lockedFromServer - Date.now()) / 1000)}s`);
      return;
    }

    if (errMsg) {
      const next = wrongCount + 1;
      setWrongCount(next);
      setPassword("");
      // Client-side fallback lockout (server is authoritative, this is just UX).
      if (next >= 3) {
        const until = Date.now() + LOCKOUT_SECONDS * 1000;
        setLockedUntil(until);
        setWrongCount(0);
        setError(`Too many attempts — try again in ${LOCKOUT_SECONDS}s`);
      } else {
        setError(errMsg);
      }
      return;
    }

    // Success
    setWrongCount(0);
    setLockedUntil(null);
    setPassword("");
    toast.success("Project reopened.");
    onReopened?.();
    onOpenChange(false);
  };

  return (
    <Dialog open={open} onOpenChange={(v) => !busy && onOpenChange(v)}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Unlock className="h-4 w-4 text-info" /> Force reopen {projectName ?? "project"}?
          </DialogTitle>
          <DialogDescription>
            This will reactivate the project and agents can resume producing prompts.
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-2 pt-1">
          <label className="text-xs text-muted-foreground" htmlFor="force-reopen-pw">
            Password
          </label>
          <Input
            id="force-reopen-pw"
            type="password"
            autoComplete="off"
            value={password}
            onChange={(e) => {
              setPassword(e.target.value);
              if (error) setError(null);
            }}
            onKeyDown={(e) => {
              if (e.key === "Enter" && !busy && !isLocked) submit();
            }}
            disabled={busy || isLocked}
            placeholder={isLocked ? `Locked — wait ${secondsLeft}s` : "Enter password"}
            autoFocus
          />
          {error && (
            <p className="text-xs text-destructive" role="alert">
              {isLocked ? `Too many attempts — try again in ${secondsLeft}s` : error}
            </p>
          )}
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)} disabled={busy}>
            Cancel
          </Button>
          <Button onClick={submit} disabled={busy || isLocked || !password}>
            {busy ? (
              <><Loader2 className="h-4 w-4 mr-1 animate-spin" /> Verifying…</>
            ) : (
              <><Unlock className="h-4 w-4 mr-1" /> Reopen</>
            )}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
