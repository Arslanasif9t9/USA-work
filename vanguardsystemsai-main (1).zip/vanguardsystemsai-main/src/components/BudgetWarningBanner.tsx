import { useEffect, useState, useCallback } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { CircleDollarSign, Loader2 } from "lucide-react";
import { toast } from "sonner";

interface Alert {
  id: string;
  agent_id: string;
  reason: string;
  cost_at_pause: number;
  budget_limit: number;
  created_at: string;
  agent_name?: string;
}

/**
 * Surfaces unresolved per-prompt budget warnings raised by Nathan / checkPromptBudget.
 * The operator can dismiss (mark resolved) to let the chain continue on the next trigger.
 */
export function BudgetWarningBanner() {
  const [alerts, setAlerts] = useState<Alert[]>([]);
  const [busy, setBusy] = useState<string | null>(null);

  const refresh = useCallback(async () => {
    const { data } = await supabase
      .from("budget_alerts")
      .select("id, agent_id, reason, cost_at_pause, budget_limit, created_at")
      .eq("resolved", false)
      .order("created_at", { ascending: false })
      .limit(5);

    const ids = Array.from(new Set((data ?? []).map((a: any) => a.agent_id)));
    let nameMap: Record<string, string> = {};
    if (ids.length > 0) {
      const { data: ag } = await supabase.from("agents").select("id,name").in("id", ids);
      nameMap = Object.fromEntries((ag ?? []).map((a: any) => [a.id, a.name]));
    }
    setAlerts(((data ?? []) as any[]).map((a) => ({ ...a, agent_name: nameMap[a.agent_id] ?? "Agent" })));
  }, []);

  useEffect(() => {
    refresh();
    const ch = supabase
      .channel("budget-alerts-banner")
      .on("postgres_changes", { event: "*", schema: "public", table: "budget_alerts" }, () => refresh())
      .subscribe();
    return () => { supabase.removeChannel(ch); };
  }, [refresh]);

  if (alerts.length === 0) return null;

  const dismiss = async (id: string) => {
    setBusy(id);
    try {
      const { error } = await supabase.from("budget_alerts").update({ resolved: true }).eq("id", id);
      if (error) {
        toast.error(error.message);
        return;
      }
      toast.success("Budget warning acknowledged.");
      await refresh();
    } finally {
      setBusy(null);
    }
  };

  return (
    <div className="space-y-2">
      {alerts.map((a) => {
        const pct = Math.round((Number(a.cost_at_pause) / Number(a.budget_limit)) * 100);
        return (
          <div key={a.id} className="flex items-start gap-3 p-3 rounded-md border border-status-budget/40 bg-status-budget/10">
            <CircleDollarSign className="h-4 w-4 text-status-budget shrink-0 mt-0.5" />
            <div className="flex-1 text-sm">
              <div className="font-medium">
                Budget warning — {a.agent_name} at {pct}% of daily cap on this prompt cycle
              </div>
              <div className="text-xs text-muted-foreground mt-0.5">{a.reason}</div>
            </div>
            <Button size="sm" variant="outline" onClick={() => dismiss(a.id)} disabled={busy === a.id} className="shrink-0">
              {busy === a.id ? <Loader2 className="h-3.5 w-3.5 mr-1.5 animate-spin" /> : null}
              Acknowledge & continue
            </Button>
          </div>
        );
      })}
    </div>
  );
}
