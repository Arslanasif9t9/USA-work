import { useEffect, useRef, useState } from "react";
import { Sheet, SheetContent, SheetDescription, SheetHeader, SheetTitle } from "@/components/ui/sheet";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { supabase } from "@/integrations/supabase/client";
import { useProjects } from "@/contexts/ProjectContext";
import { Paperclip, Send, X } from "lucide-react";
import { toast } from "sonner";
import ReactMarkdown from "react-markdown";
import type { Agent } from "./AgentCard";

interface ChatMessage {
  role: "user" | "assistant";
  content: string;
}
interface Attachment {
  name: string;
  content: string;
}

interface Props {
  agent: Agent | null;
  open: boolean;
  onOpenChange: (v: boolean) => void;
}

export function AgentChatDrawer({ agent, open, onOpenChange }: Props) {
  const { currentProject } = useProjects();
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [draft, setDraft] = useState("");
  const [busy, setBusy] = useState(false);
  const [attachments, setAttachments] = useState<Attachment[]>([]);
  const fileRef = useRef<HTMLInputElement>(null);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (open) {
      setMessages([]);
      setDraft("");
      setAttachments([]);
    }
  }, [open, agent?.id]);

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight });
  }, [messages, busy]);

  const handleFiles = async (files: FileList | null) => {
    if (!files) return;
    const arr: Attachment[] = [];
    for (const f of Array.from(files).slice(0, 5)) {
      if (f.size > 200_000) {
        toast.error(`${f.name} is over 200KB and was skipped.`);
        continue;
      }
      const text = await f.text().catch(() => `(binary file: ${f.name}, ${f.size} bytes)`);
      arr.push({ name: f.name, content: text.slice(0, 30_000) });
    }
    setAttachments((prev) => [...prev, ...arr]);
  };

  const send = async () => {
    if (!agent || !draft.trim()) return;
    const userMsg: ChatMessage = { role: "user", content: draft.trim() };
    const newHistory = [...messages, userMsg];
    setMessages(newHistory);
    setDraft("");
    setBusy(true);
    const sentAttachments = attachments;
    setAttachments([]);

    const { data, error } = await supabase.functions.invoke("chat-with-agent", {
      body: {
        agentId: agent.id,
        projectId: currentProject?.id ?? null,
        history: messages,
        message: userMsg.content,
        attachments: sentAttachments,
      },
    });
    setBusy(false);
    if (error || !data?.ok) {
      toast.error(data?.error || error?.message || "Chat failed");
      return;
    }
    setMessages([...newHistory, { role: "assistant", content: data.reply }]);
  };

  return (
    <Sheet open={open} onOpenChange={onOpenChange}>
      <SheetContent side="right" className="w-full sm:max-w-lg flex flex-col p-0">
        <SheetHeader className="p-4 border-b border-border/60">
          <div className="flex items-center gap-3">
            {agent && <img src={agent.avatar_url} className="h-10 w-10 rounded-full ring-2 ring-primary/40" alt={agent.name} />}
            <div>
              <SheetTitle>{agent?.name}</SheetTitle>
              <SheetDescription>{agent?.title}{currentProject && <> · scoped to {currentProject.name}</>}</SheetDescription>
            </div>
          </div>
        </SheetHeader>

        <div ref={scrollRef} className="flex-1 overflow-y-auto p-4 space-y-3">
          {messages.length === 0 && (
            <div className="text-sm text-muted-foreground text-center py-12">
              Start the conversation. {agent?.name} has full context of {currentProject?.name ?? "no current project"}.
            </div>
          )}
          {messages.map((m, i) => (
            <div key={i} className={m.role === "user" ? "flex justify-end" : "flex justify-start"}>
              <div className={`max-w-[85%] rounded-lg px-3 py-2 text-sm ${
                m.role === "user" ? "bg-primary text-primary-foreground" : "bg-secondary text-foreground"
              }`}>
                <div className="prose prose-sm prose-invert max-w-none">
                  <ReactMarkdown>{m.content}</ReactMarkdown>
                </div>
              </div>
            </div>
          ))}
          {busy && (
            <div className="flex justify-start">
              <div className="bg-secondary rounded-lg px-3 py-2 text-sm text-muted-foreground">
                {agent?.name} is thinking…
              </div>
            </div>
          )}
        </div>

        {attachments.length > 0 && (
          <div className="px-4 pt-2 flex flex-wrap gap-2">
            {attachments.map((a, i) => (
              <div key={i} className="flex items-center gap-1 bg-secondary text-xs rounded px-2 py-1">
                <Paperclip className="h-3 w-3" />
                <span className="max-w-[140px] truncate">{a.name}</span>
                <button onClick={() => setAttachments((p) => p.filter((_, idx) => idx !== i))}>
                  <X className="h-3 w-3" />
                </button>
              </div>
            ))}
          </div>
        )}

        <div className="p-4 border-t border-border/60 space-y-2">
          <Textarea
            rows={3}
            value={draft}
            onChange={(e) => setDraft(e.target.value)}
            placeholder={`Message ${agent?.name ?? ""}…`}
            onKeyDown={(e) => {
              if (e.key === "Enter" && (e.metaKey || e.ctrlKey)) send();
            }}
          />
          <div className="flex justify-between">
            <Button variant="ghost" size="sm" onClick={() => fileRef.current?.click()}>
              <Paperclip className="h-4 w-4 mr-1" /> Attach
            </Button>
            <input
              ref={fileRef}
              type="file"
              multiple
              accept=".txt,.md,.json,.csv,.html,.tsx,.ts,.js,.jsx,.css,.svg,.pdf"
              className="hidden"
              onChange={(e) => handleFiles(e.target.files)}
            />
            <Button size="sm" onClick={send} disabled={busy || !draft.trim()}>
              <Send className="h-4 w-4 mr-1" /> Send
            </Button>
          </div>
        </div>
      </SheetContent>
    </Sheet>
  );
}
