import { ReactNode } from "react";
import { Navigate } from "react-router-dom";
import { useAuth } from "@/contexts/AuthContext";

export function OwnerGuard({ children }: { children: ReactNode }) {
  const { session, isOwner, loading } = useAuth();
  if (loading) return <div className="min-h-screen grid place-items-center text-muted-foreground">Loading…</div>;
  if (!session) return <Navigate to="/auth" replace />;
  if (!isOwner) {
    return (
      <div className="min-h-screen grid place-items-center p-4">
        <div className="max-w-md text-center">
          <h1 className="text-xl font-semibold mb-2">Owner access only</h1>
          <p className="text-sm text-muted-foreground">Vanguard Systems is restricted to the workspace owner.</p>
        </div>
      </div>
    );
  }
  return <>{children}</>;
}
