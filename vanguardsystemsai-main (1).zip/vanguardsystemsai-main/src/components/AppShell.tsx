import { ReactNode, useEffect, useState } from "react";
import { Link, NavLink, useNavigate } from "react-router-dom";
import { useAuth } from "@/contexts/AuthContext";
import { useProjects } from "@/contexts/ProjectContext";
import { ProjectSwitcher } from "./ProjectSwitcher";
import { Button } from "@/components/ui/button";
import { Activity, History, LogOut, Settings, Users, LayoutDashboard, AlertTriangle, DollarSign, FolderKanban } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { cn } from "@/lib/utils";

interface BudgetAlertRow {
  id: string;
  agent_id: string;
  reason: string;
  resolved: boolean;
}

export function AppShell({ children }: { children: ReactNode }) {
  const { signOut, user } = useAuth();
  const { currentProject } = useProjects();
  const navigate = useNavigate();
  const [alerts, setAlerts] = useState<BudgetAlertRow[]>([]);
  const [workingAgentName, setWorkingAgentName] = useState<string | null>(null);
  const [todaySpend, setTodaySpend] = useState(0);

  // Banner: any unresolved budget alerts? Any agents currently working?
  useEffect(() => {
    const fetchAlerts = async () => {
      const { data } = await supabase.from("budget_alerts").select("*").eq("resolved", false);
      setAlerts((data ?? []) as BudgetAlertRow[]);
    };
    const fetchWorking = async () => {
      const { data } = await supabase.from("agents").select("name,status").eq("status", "working").limit(1).maybeSingle();
      setWorkingAgentName(data?.name ?? null);
    };
    const fetchSpend = async () => {
      const today = new Date();
      today.setHours(0, 0, 0, 0);
      const { data } = await supabase
        .from("agent_spend")
        .select("cost_usd")
        .gte("created_at", today.toISOString());
      const total = (data ?? []).reduce((s, r: any) => s + Number(r.cost_usd ?? 0), 0);
      setTodaySpend(total);
    };
    fetchAlerts();
    fetchWorking();
    fetchSpend();

    const ch = supabase
      .channel("shell-realtime")
      .on("postgres_changes", { event: "*", schema: "public", table: "agents" }, () => {
        fetchWorking();
      })
      .on("postgres_changes", { event: "*", schema: "public", table: "budget_alerts" }, () => fetchAlerts())
      .on("postgres_changes", { event: "INSERT", schema: "public", table: "agent_spend" }, () => fetchSpend())
      .subscribe();
    return () => {
      supabase.removeChannel(ch);
    };
  }, []);

  const navItems = [
    { to: "/", label: "Dashboard", icon: LayoutDashboard },
    { to: "/admin/projects", label: "Projects", icon: FolderKanban },
    { to: "/admin/agents", label: "Agents", icon: Users },
    { to: "/admin/history", label: "History", icon: History },
    { to: "/admin/settings", label: "Settings", icon: Settings },
  ];

  return (
    <div className="min-h-screen flex flex-col">
      {/* Top nav */}
      <header className="sticky top-0 z-40 border-b border-border/60 bg-background/80 backdrop-blur-md">
        <div className="container max-w-[1480px] flex items-center gap-4 h-16">
          <Link to="/" className="flex items-center gap-2 font-bold text-lg">
            <div className="h-8 w-8 rounded-md gradient-primary grid place-items-center text-primary-foreground">
              <Activity className="h-4 w-4" />
            </div>
            <span className="tracking-tight">Vanguard Systems</span>
          </Link>

          <nav className="hidden md:flex items-center gap-1 ml-4">
            {navItems.map((it) => (
              <NavLink
                key={it.to}
                to={it.to}
                end={it.to === "/"}
                className={({ isActive }) =>
                  cn(
                    "px-3 py-1.5 rounded-md text-sm font-medium flex items-center gap-1.5 transition-colors",
                    isActive ? "bg-secondary text-foreground" : "text-muted-foreground hover:text-foreground hover:bg-secondary/60",
                  )
                }
              >
                <it.icon className="h-3.5 w-3.5" />
                {it.label}
              </NavLink>
            ))}
          </nav>

          <div className="ml-auto flex items-center gap-3">
            <ProjectSwitcher />
            <div className="hidden lg:flex items-center gap-1.5 text-xs text-muted-foreground bg-secondary/40 rounded-md px-2 py-1.5">
              <DollarSign className="h-3.5 w-3.5" />
              <span className="font-mono">${todaySpend.toFixed(4)}</span>
              <span>today</span>
            </div>
            <Button variant="ghost" size="icon" onClick={async () => { await signOut(); navigate("/auth"); }}>
              <LogOut className="h-4 w-4" />
            </Button>
          </div>
        </div>

        {/* Work-in-progress banner */}
        {workingAgentName && (
          <div className="bg-primary/10 border-t border-primary/30">
            <div className="container max-w-[1480px] flex items-center gap-2 py-2 text-sm">
              <span className="relative flex h-2 w-2">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-primary opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2 w-2 bg-primary"></span>
              </span>
              <span className="font-medium text-primary">{workingAgentName}</span>
              <span className="text-muted-foreground">is working now…</span>
            </div>
          </div>
        )}

        {alerts.length > 0 && (
          <div className="bg-destructive/10 border-t border-destructive/40">
            <div className="container max-w-[1480px] flex items-center gap-2 py-2 text-sm text-destructive-foreground">
              <AlertTriangle className="h-4 w-4 text-destructive" />
              <span className="font-medium">Budget paused:</span>
              <span className="text-muted-foreground">{alerts.length} agent(s) over budget. {alerts[0]?.reason}</span>
            </div>
          </div>
        )}
      </header>

      <main className="flex-1 container max-w-[1480px] py-6">{children}</main>

      <footer className="border-t border-border/60 py-4 text-center text-xs text-muted-foreground">
        Vanguard Systems · {user?.email}
        {currentProject && <> · viewing <span className="text-foreground/80">{currentProject.name}</span></>}
      </footer>
    </div>
  );
}
