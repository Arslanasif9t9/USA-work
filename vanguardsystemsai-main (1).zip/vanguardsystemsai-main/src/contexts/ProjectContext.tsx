import { createContext, useContext, useEffect, useState, ReactNode, useCallback } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "./AuthContext";

export interface Project {
  id: string;
  name: string;
  slug: string;
  description: string | null;
  mode: "build_new" | "fix_existing" | "research_only" | "full_stack_service";
  reference_urls: string[];
  existing_site_url: string | null;
  tech_stack_target: string;
  intake_notes: string | null;
  status: "active" | "paused" | "complete" | "archived";
  created_at: string;
}

interface ProjectState {
  projects: Project[];
  currentProject: Project | null;
  setCurrentProject: (p: Project | null) => void;
  refresh: () => Promise<void>;
  loading: boolean;
}

const ProjectContext = createContext<ProjectState | undefined>(undefined);

const STORAGE_KEY = "mc:current_project_id";

export function ProjectProvider({ children }: { children: ReactNode }) {
  const { user, isOwner } = useAuth();
  const [projects, setProjects] = useState<Project[]>([]);
  const [currentProject, setCurrentProjectState] = useState<Project | null>(null);
  const [loading, setLoading] = useState(true);

  const refresh = useCallback(async () => {
    if (!user || !isOwner) {
      setProjects([]);
      setCurrentProjectState(null);
      setLoading(false);
      return;
    }
    setLoading(true);
    const { data } = await supabase
      .from("projects")
      .select("*")
      .order("created_at", { ascending: false });
    const list = (data ?? []) as unknown as Project[];
    setProjects(list);
    // Restore current project from localStorage if still in list
    const savedId = localStorage.getItem(STORAGE_KEY);
    const found = list.find((p) => p.id === savedId);
    if (found) setCurrentProjectState(found);
    else if (list.length > 0) setCurrentProjectState(list[0]);
    else setCurrentProjectState(null);
    setLoading(false);
  }, [user, isOwner]);

  useEffect(() => {
    refresh();
  }, [refresh]);

  // Realtime: keep project list and currentProject status in sync without manual refresh.
  useEffect(() => {
    if (!user || !isOwner) return;
    const ch = supabase
      .channel("projects-realtime")
      .on(
        "postgres_changes",
        { event: "*", schema: "public", table: "projects" },
        () => {
          refresh();
        },
      )
      .subscribe();
    return () => {
      supabase.removeChannel(ch);
    };
  }, [user, isOwner, refresh]);

  // Keep currentProject object in sync with the latest projects list (e.g. status changes).
  useEffect(() => {
    if (!currentProject) return;
    const fresh = projects.find((p) => p.id === currentProject.id);
    if (fresh && fresh !== currentProject) {
      setCurrentProjectState(fresh);
    }
  }, [projects, currentProject]);

  const setCurrentProject = (p: Project | null) => {
    setCurrentProjectState(p);
    if (p) localStorage.setItem(STORAGE_KEY, p.id);
    else localStorage.removeItem(STORAGE_KEY);
  };

  return (
    <ProjectContext.Provider value={{ projects, currentProject, setCurrentProject, refresh, loading }}>
      {children}
    </ProjectContext.Provider>
  );
}

export function useProjects() {
  const ctx = useContext(ProjectContext);
  if (!ctx) throw new Error("useProjects must be used within ProjectProvider");
  return ctx;
}
