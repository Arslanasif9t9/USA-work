import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";

export interface ReadyPrompt {
  id: string;
  sequence_number: number;
  title: string;
  content_md: string;
  project_id: string;
  created_by_agent_id: string | null;
  created_at: string;
}

/**
 * Subscribe to lovable_prompts with status = 'ready' authored by a specific agent.
 * Optionally scope to a single project.
 */
export function useReadyPrompts(agentId: string | undefined, projectId?: string) {
  const [readyPrompts, setReadyPrompts] = useState<ReadyPrompt[]>([]);

  useEffect(() => {
    if (!agentId) {
      setReadyPrompts([]);
      return;
    }
    const load = async () => {
      let q = supabase
        .from("lovable_prompts")
        .select("id, sequence_number, title, content_md, project_id, created_by_agent_id, created_at")
        .eq("status", "ready")
        .eq("created_by_agent_id", agentId)
        .order("sequence_number", { ascending: true });
      if (projectId) q = q.eq("project_id", projectId);
      const { data } = await q;
      setReadyPrompts((data ?? []) as ReadyPrompt[]);
    };
    load();
    const ch = supabase
      .channel(`ready-prompts-${agentId}-${projectId ?? "all"}`)
      .on(
        "postgres_changes",
        { event: "*", schema: "public", table: "lovable_prompts" },
        () => load()
      )
      .subscribe();
    return () => { supabase.removeChannel(ch); };
  }, [agentId, projectId]);

  return readyPrompts;
}
