import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";

export type ChainPhase =
  | { kind: "idle" }
  | { kind: "researching"; agentName: string; task?: string | null }
  | { kind: "drafting_copy"; agentName: string; task?: string | null }
  | { kind: "qa_review"; agentName: string; task?: string | null }
  | { kind: "architect_drafting"; agentName: string; task?: string | null }
  | { kind: "needs_revision"; round: number; targets: string[]; reportId: string }
  | { kind: "prompt_ready"; sequence: number; title: string; promptId: string }
  | { kind: "escalated"; round: number; reportId: string };

interface ChainState {
  phase: ChainPhase;
  loading: boolean;
}

/**
 * Derives the current cycle phase for a project by looking at:
 *  - which agent (if any) is `working`
 *  - the latest QA verdict (NEEDS_REVISION → needs_revision)
 *  - any `ready` prompts (awaiting human delivery)
 *
 * Subscribes to realtime changes on agents, qa_reports, and lovable_prompts
 * scoped to the project so the indicator stays live without manual refresh.
 */
export function useChainStatus(projectId: string | null | undefined): ChainState {
  const [phase, setPhase] = useState<ChainPhase>({ kind: "idle" });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!projectId) {
      setPhase({ kind: "idle" });
      setLoading(false);
      return;
    }

    let cancelled = false;

    const compute = async () => {
      const [{ data: agents }, { data: qa }, { data: ready }] = await Promise.all([
        supabase
          .from("agents")
          .select("id,name,role,status,current_task")
          .order("sort_order"),
        supabase
          .from("qa_reports")
          .select("id,verdict,findings_md,created_at")
          .eq("project_id", projectId)
          .order("created_at", { ascending: false })
          .limit(1)
          .maybeSingle(),
        supabase
          .from("lovable_prompts")
          .select("id,sequence_number,title,created_at")
          .eq("project_id", projectId)
          .eq("status", "ready")
          .order("sequence_number", { ascending: true }),
      ]);

      if (cancelled) return;

      // 1. Working agent takes priority — show its phase live.
      const working = (agents ?? []).find((a: any) => a.status === "working");
      if (working) {
        const role = working.role as string;
        const task = working.current_task as string | null;
        if (role === "research_lead") {
          setPhase({ kind: "researching", agentName: working.name, task });
        } else if (role === "content_writer") {
          setPhase({ kind: "drafting_copy", agentName: working.name, task });
        } else if (role === "qa_auditor") {
          setPhase({ kind: "qa_review", agentName: working.name, task });
        } else if (role === "lead_architect") {
          setPhase({ kind: "architect_drafting", agentName: working.name, task });
        } else {
          setPhase({ kind: "idle" });
        }
        setLoading(false);
        return;
      }

      // 2. Ready prompt awaiting delivery beats stale revision state.
      if (ready && ready.length > 0) {
        const next = ready[0];
        setPhase({
          kind: "prompt_ready",
          sequence: next.sequence_number,
          title: next.title,
          promptId: next.id,
        });
        setLoading(false);
        return;
      }

      // 3. NEEDS_REVISION verdict — stalled awaiting next cycle (or escalated).
      if (qa && qa.verdict === "NEEDS_REVISION") {
        // Count how many recent NEEDS_REVISION reports cluster together to estimate round.
        const { data: recent } = await supabase
          .from("qa_reports")
          .select("verdict,created_at")
          .eq("project_id", projectId)
          .order("created_at", { ascending: false })
          .limit(6);
        let round = 0;
        for (const r of recent ?? []) {
          if (r.verdict === "NEEDS_REVISION") round += 1;
          else break;
        }
        // Parse "Revision targets" line from findings_md.
        const targetsMatch = (qa.findings_md ?? "").match(/##\s*Revision targets\s*\n+([^\n#]+)/i);
        const targetsRaw = (targetsMatch ? targetsMatch[1] : "").toLowerCase();
        const targets: string[] = [];
        if (targetsRaw.includes("both")) {
          targets.push("Claire", "Olivia");
        } else {
          if (targetsRaw.includes("claire")) targets.push("Claire");
          if (targetsRaw.includes("olivia")) targets.push("Olivia");
        }
        if (round >= 3) {
          setPhase({ kind: "escalated", round, reportId: qa.id });
        } else {
          setPhase({ kind: "needs_revision", round, targets, reportId: qa.id });
        }
        setLoading(false);
        return;
      }

      setPhase({ kind: "idle" });
      setLoading(false);
    };

    compute();

    const channel = supabase
      .channel(`chain-status-${projectId}`)
      .on(
        "postgres_changes",
        { event: "*", schema: "public", table: "agents" },
        () => compute(),
      )
      .on(
        "postgres_changes",
        { event: "*", schema: "public", table: "qa_reports", filter: `project_id=eq.${projectId}` },
        () => compute(),
      )
      .on(
        "postgres_changes",
        { event: "*", schema: "public", table: "lovable_prompts", filter: `project_id=eq.${projectId}` },
        () => compute(),
      )
      .subscribe();

    return () => {
      cancelled = true;
      supabase.removeChannel(channel);
    };
  }, [projectId]);

  return { phase, loading };
}

export function chainPhaseLabel(phase: ChainPhase): string {
  switch (phase.kind) {
    case "researching":
      return "Researching…";
    case "drafting_copy":
      return "Drafting copy…";
    case "qa_review":
      return "Under QA review…";
    case "architect_drafting":
      return "Architect drafting…";
    case "needs_revision":
      return `Needs revision (round ${phase.round})`;
    case "prompt_ready":
      return `Prompt #${phase.sequence} ready — review to deliver`;
    case "escalated":
      return `Escalated — needs your decision (${phase.round} rounds)`;
    case "idle":
    default:
      return "Idle";
  }
}
