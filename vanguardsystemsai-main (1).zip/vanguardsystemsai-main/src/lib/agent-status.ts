// Status visual + label helpers used across the UI.
export type AgentStatus = "sleeping" | "working" | "standby" | "off" | "paused" | "budget_paused";

export const statusConfig: Record<
  AgentStatus,
  { label: string; subtitle: string; color: string; bg: string; ring: string }
> = {
  sleeping: {
    label: "Waiting",
    subtitle: "Waiting for next task",
    color: "text-status-sleeping",
    bg: "bg-secondary/40",
    ring: "ring-status-sleeping/30",
  },
  working: {
    label: "Working",
    subtitle: "Working now",
    color: "text-status-working",
    bg: "bg-primary/10",
    ring: "ring-status-working/60",
  },
  standby: {
    label: "Standby",
    subtitle: "Standby — waiting for hand-off",
    color: "text-status-standby",
    bg: "bg-warning/10",
    ring: "ring-status-standby/40",
  },
  off: {
    label: "Off",
    subtitle: "Off — toggle to enable",
    color: "text-status-off",
    bg: "bg-destructive/10",
    ring: "ring-status-off/40",
  },
  paused: {
    label: "Paused",
    subtitle: "Paused — manually halted",
    color: "text-warning",
    bg: "bg-warning/10",
    ring: "ring-warning/40",
  },
  budget_paused: {
    label: "Budget paused",
    subtitle: "Budget paused — resets at midnight ET",
    color: "text-status-budget",
    bg: "bg-status-budget/10",
    ring: "ring-status-budget/40",
  },
};

export const projectModeLabel: Record<string, string> = {
  build_new: "Build new",
  fix_existing: "Fix existing",
  research_only: "Research only",
  full_stack_service: "Full-stack service",
};

// Project lifecycle. We reuse the existing `paused` enum value as "On Hold" in the UI.
export type ProjectStatus = "active" | "paused" | "complete" | "archived";

export const projectStatusLabel: Record<ProjectStatus, string> = {
  active: "Active",
  paused: "On Hold",
  complete: "Complete",
  archived: "Archived",
};

// Tailwind classes for the status badge — semantic tokens only.
export const projectStatusBadgeClass: Record<ProjectStatus, string> = {
  active: "bg-primary/15 text-primary border-primary/30",
  paused: "bg-warning/15 text-warning border-warning/30",
  complete: "bg-info/15 text-info border-info/30",
  archived: "bg-muted text-muted-foreground border-border",
};

export function isProjectRunnable(status: string | undefined | null): boolean {
  return status === "active";
}

export function projectBlockedReason(status: string | undefined | null): string | null {
  if (status === "active" || !status) return null;
  return `This project is ${projectStatusLabel[(status as ProjectStatus)] ?? status}. Resume it to run agents.`;
}
