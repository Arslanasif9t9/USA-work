import { useEffect, useState } from "react";
import { AppShell } from "@/components/AppShell";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { Check, Key, Loader2, RefreshCw, Trash2 } from "lucide-react";

interface SecretRow {
  key_name: string;
  masked_preview: string;
  last_test_status: string | null;
  last_tested_at: string | null;
}

export default function Settings() {
  const [secrets, setSecrets] = useState<SecretRow[]>([]);
  const [anthropicKey, setAnthropicKey] = useState("");
  const [unsplashKey, setUnsplashKey] = useState("");
  const [falKey, setFalKey] = useState("");
  const [busy, setBusy] = useState(false);
  const [testing, setTesting] = useState(false);
  const [testingFal, setTestingFal] = useState(false);

  useEffect(() => { document.title = "Settings · Vanguard Systems"; load(); }, []);

  const load = async () => {
    const { data } = await supabase.functions.invoke("manage-secret", { body: { action: "list" } });
    setSecrets(data?.secrets ?? []);
    // One-shot deprecation cleanup: drop the old Replicate token if it lingers.
    if ((data?.secrets ?? []).some((s: any) => s.key_name === "REPLICATE_API_TOKEN")) {
      await supabase.functions.invoke("manage-secret", { body: { action: "delete", key_name: "REPLICATE_API_TOKEN" } });
      const refreshed = await supabase.functions.invoke("manage-secret", { body: { action: "list" } });
      setSecrets(refreshed.data?.secrets ?? []);
    }
  };

  const save = async (key_name: string, value: string) => {
    if (!value.trim()) return toast.error("Value required");
    setBusy(true);
    const { error } = await supabase.functions.invoke("manage-secret", {
      body: { action: "save", key_name, value: value.trim() },
    });
    setBusy(false);
    if (error) return toast.error(error.message);
    toast.success(`${key_name} saved.`);
    if (key_name === "ANTHROPIC_API_KEY") setAnthropicKey("");
    if (key_name === "UNSPLASH_ACCESS_KEY") setUnsplashKey("");
    if (key_name === "FAL_API_KEY") setFalKey("");
    load();
  };

  const test = async () => {
    setTesting(true);
    const { data, error } = await supabase.functions.invoke("test-anthropic", { body: {} });
    setTesting(false);
    if (error || !data?.ok) toast.error(data?.message || error?.message || "Test failed");
    else toast.success("Anthropic OK.");
    load();
  };

  const testFal = async () => {
    setTestingFal(true);
    const { data, error } = await supabase.functions.invoke("test-fal", { body: {} });
    setTestingFal(false);
    if (error || !data?.ok) toast.error(data?.message || error?.message || "Test failed");
    else toast.success(data.message ?? "fal.ai OK.");
    load();
  };

  const remove = async (key_name: string) => {
    await supabase.functions.invoke("manage-secret", { body: { action: "delete", key_name } });
    toast.success(`${key_name} removed.`);
    load();
  };

  const reseed = async () => {
    setBusy(true);
    const { error } = await supabase.functions.invoke("seed-agents", { body: {} });
    setBusy(false);
    if (error) return toast.error(error.message);
    toast.success("Agents reseeded.");
  };

  const find = (n: string) => secrets.find((s) => s.key_name === n);

  return (
    <AppShell>
      <div className="space-y-6 max-w-3xl">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Settings</h1>
          <p className="text-sm text-muted-foreground">Manage encrypted API keys and reseed the team.</p>
        </div>

        <Card className="card-elev">
          <CardHeader>
            <CardTitle className="flex items-center gap-2"><Key className="h-4 w-4 text-primary" /> Anthropic API key</CardTitle>
            <CardDescription>Powers all agents. Encrypted at rest with AES-256.</CardDescription>
          </CardHeader>
          <CardContent className="space-y-3">
            {find("ANTHROPIC_API_KEY") && (
              <div className="flex items-center justify-between p-3 bg-secondary rounded-md">
                <div>
                  <div className="font-mono text-sm">{find("ANTHROPIC_API_KEY")?.masked_preview}</div>
                  <div className="text-xs text-muted-foreground">
                    Last test: {find("ANTHROPIC_API_KEY")?.last_test_status ?? "never"}
                    {find("ANTHROPIC_API_KEY")?.last_tested_at && ` · ${new Date(find("ANTHROPIC_API_KEY")!.last_tested_at!).toLocaleString()}`}
                  </div>
                </div>
                <div className="flex gap-2">
                  <Button size="sm" variant="outline" onClick={test} disabled={testing}>
                    {testing ? <Loader2 className="h-4 w-4 animate-spin" /> : <Check className="h-4 w-4" />}
                    <span className="ml-1">Test</span>
                  </Button>
                  <Button size="sm" variant="ghost" onClick={() => remove("ANTHROPIC_API_KEY")}>
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            )}
            <div className="flex gap-2">
              <Input type="password" placeholder="sk-ant-…" value={anthropicKey} onChange={(e) => setAnthropicKey(e.target.value)} />
              <Button onClick={() => save("ANTHROPIC_API_KEY", anthropicKey)} disabled={busy || !anthropicKey.trim()}>Save</Button>
            </div>
          </CardContent>
        </Card>

        <Card className="card-elev">
          <CardHeader>
            <CardTitle className="flex items-center gap-2"><Key className="h-4 w-4 text-primary" /> fal.ai API key</CardTitle>
            <CardDescription>Powers AI-generated agent headshots (flux/dev, ~$0.025 each).</CardDescription>
          </CardHeader>
          <CardContent className="space-y-3">
            {find("FAL_API_KEY") && (
              <div className="flex items-center justify-between p-3 bg-secondary rounded-md">
                <div>
                  <div className="font-mono text-sm">{find("FAL_API_KEY")?.masked_preview}</div>
                  <div className="text-xs text-muted-foreground">
                    Last test: {find("FAL_API_KEY")?.last_test_status ?? "never"}
                    {find("FAL_API_KEY")?.last_tested_at && ` · ${new Date(find("FAL_API_KEY")!.last_tested_at!).toLocaleString()}`}
                  </div>
                </div>
                <div className="flex gap-2">
                  <Button size="sm" variant="outline" onClick={testFal} disabled={testingFal}>
                    {testingFal ? <Loader2 className="h-4 w-4 animate-spin" /> : <Check className="h-4 w-4" />}
                    <span className="ml-1">Test</span>
                  </Button>
                  <Button size="sm" variant="ghost" onClick={() => remove("FAL_API_KEY")}>
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            )}
            <div className="flex gap-2">
              <Input type="password" placeholder="fal_…" value={falKey} onChange={(e) => setFalKey(e.target.value)} />
              <Button onClick={() => save("FAL_API_KEY", falKey)} disabled={busy || !falKey.trim()}>Save</Button>
            </div>
            <p className="text-xs text-muted-foreground">
              Get a key at <a className="underline hover:text-primary" href="https://fal.ai/dashboard/keys" target="_blank" rel="noreferrer">fal.ai/dashboard/keys</a>.
            </p>
          </CardContent>
        </Card>

        <Card className="card-elev">
          <CardHeader>
            <CardTitle className="flex items-center gap-2"><Key className="h-4 w-4 text-primary" /> Unsplash access key</CardTitle>
            <CardDescription>Optional — for image search in research.</CardDescription>
          </CardHeader>
          <CardContent className="space-y-3">
            {find("UNSPLASH_ACCESS_KEY") && (
              <div className="flex items-center justify-between p-3 bg-secondary rounded-md">
                <div className="font-mono text-sm">{find("UNSPLASH_ACCESS_KEY")?.masked_preview}</div>
                <Button size="sm" variant="ghost" onClick={() => remove("UNSPLASH_ACCESS_KEY")}>
                  <Trash2 className="h-4 w-4" />
                </Button>
              </div>
            )}
            <div className="flex gap-2">
              <Input type="password" value={unsplashKey} onChange={(e) => setUnsplashKey(e.target.value)} />
              <Button onClick={() => save("UNSPLASH_ACCESS_KEY", unsplashKey)} disabled={busy || !unsplashKey.trim()}>Save</Button>
            </div>
          </CardContent>
        </Card>

        <Card className="card-elev">
          <CardHeader>
            <CardTitle>Team</CardTitle>
            <CardDescription>Reseed the 5 agents (idempotent — won't duplicate).</CardDescription>
          </CardHeader>
          <CardContent>
            <Button variant="outline" onClick={reseed} disabled={busy}>
              <RefreshCw className="h-4 w-4 mr-1" /> Reseed agents
            </Button>
          </CardContent>
        </Card>
      </div>
    </AppShell>
  );
}
