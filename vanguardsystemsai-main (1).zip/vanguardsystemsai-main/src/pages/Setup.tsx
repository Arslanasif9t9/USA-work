import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "@/contexts/AuthContext";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";
import { Check, Key, UserCircle2, Users, Activity, ChevronRight, Loader2 } from "lucide-react";

type Step = 1 | 2 | 3;

export default function Setup() {
  const navigate = useNavigate();
  const { user, isOwner, loading } = useAuth();
  const [step, setStep] = useState<Step>(1);
  const [anthropicKey, setAnthropicKey] = useState("");
  const [unsplashKey, setUnsplashKey] = useState("");
  const [keyTested, setKeyTested] = useState(false);
  const [testing, setTesting] = useState(false);
  const [saving, setSaving] = useState(false);
  const [displayName, setDisplayName] = useState("");
  const [seeding, setSeeding] = useState(false);
  const [seedDone, setSeedDone] = useState(false);

  useEffect(() => {
    document.title = "Setup · Vanguard Systems";
  }, []);

  useEffect(() => {
    if (!loading && !user) navigate("/auth");
  }, [user, loading, navigate]);

  useEffect(() => {
    if (!user) return;
    supabase.from("profiles").select("display_name").eq("user_id", user.id).maybeSingle().then(({ data }) => {
      if (data?.display_name) setDisplayName(data.display_name);
    });
  }, [user]);

  const saveKey = async () => {
    if (!anthropicKey.trim().startsWith("sk-")) {
      toast.error("Anthropic key should start with 'sk-'");
      return;
    }
    setSaving(true);
    const { error } = await supabase.functions.invoke("manage-secret", {
      body: { action: "save", key_name: "ANTHROPIC_API_KEY", value: anthropicKey.trim() },
    });
    if (error) {
      setSaving(false);
      toast.error(error.message);
      return;
    }
    if (unsplashKey.trim()) {
      await supabase.functions.invoke("manage-secret", {
        body: { action: "save", key_name: "UNSPLASH_ACCESS_KEY", value: unsplashKey.trim() },
      });
    }
    setSaving(false);
    toast.success("Key saved. Testing connection…");
    await testKey();
  };

  const testKey = async () => {
    setTesting(true);
    const { data, error } = await supabase.functions.invoke("test-anthropic", { body: {} });
    setTesting(false);
    if (error || !data?.ok) {
      toast.error(data?.message || error?.message || "Test failed");
      setKeyTested(false);
      return;
    }
    toast.success("Anthropic connected.");
    setKeyTested(true);
  };

  const saveProfile = async () => {
    if (!user) return;
    if (!displayName.trim()) return toast.error("Display name required");
    await supabase.from("profiles").update({ display_name: displayName.trim() }).eq("user_id", user.id);
    toast.success("Profile saved.");
    setStep(3);
  };

  const seedAgents = async () => {
    setSeeding(true);
    const { data, error } = await supabase.functions.invoke("seed-agents", { body: {} });
    setSeeding(false);
    if (error) {
      toast.error(error.message);
      return;
    }
    toast.success(`Seeded ${data.count} agents.`);
    setSeedDone(true);
  };

  const finish = () => navigate("/", { replace: true });

  if (loading) return <div className="min-h-screen grid place-items-center text-muted-foreground">Loading…</div>;
  if (!isOwner) {
    return (
      <div className="min-h-screen grid place-items-center p-4">
        <Card className="max-w-md">
          <CardHeader>
            <CardTitle>Owner access required</CardTitle>
            <CardDescription>Only the owner can run setup.</CardDescription>
          </CardHeader>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen p-4 grid place-items-center">
      <div className="w-full max-w-2xl">
        <div className="flex items-center justify-center gap-2 mb-6">
          <div className="h-10 w-10 rounded-md gradient-primary grid place-items-center text-primary-foreground">
            <Activity className="h-5 w-5" />
          </div>
          <h1 className="text-2xl font-bold">Vanguard Systems · Setup</h1>
        </div>

        {/* Stepper */}
        <div className="flex items-center justify-center gap-2 mb-6 text-sm">
          {[1, 2, 3].map((n) => (
            <div key={n} className="flex items-center gap-2">
              <div
                className={`h-8 w-8 rounded-full grid place-items-center font-semibold border ${
                  step === n ? "bg-primary text-primary-foreground border-primary" :
                  step > n ? "bg-primary/20 text-primary border-primary/40" : "bg-secondary text-muted-foreground border-border"
                }`}
              >
                {step > n ? <Check className="h-4 w-4" /> : n}
              </div>
              {n < 3 && <ChevronRight className="h-4 w-4 text-muted-foreground" />}
            </div>
          ))}
        </div>

        {step === 1 && (
          <Card className="card-elev">
            <CardHeader>
              <CardTitle className="flex items-center gap-2"><Key className="h-5 w-5 text-primary" /> Step 1 — API keys</CardTitle>
              <CardDescription>Paste your Anthropic API key. It's encrypted at rest with AES-256.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid gap-2">
                <Label>Anthropic API key (required)</Label>
                <Input
                  type="password"
                  placeholder="sk-ant-…"
                  value={anthropicKey}
                  onChange={(e) => { setAnthropicKey(e.target.value); setKeyTested(false); }}
                />
              </div>
              <div className="grid gap-2">
                <Label>Unsplash access key (optional)</Label>
                <Input type="password" value={unsplashKey} onChange={(e) => setUnsplashKey(e.target.value)} />
              </div>
              <div className="flex gap-2">
                <Button onClick={saveKey} disabled={saving || !anthropicKey.trim()}>
                  {saving ? "Saving…" : "Save & test"}
                </Button>
                {keyTested && (
                  <Button variant="ghost" onClick={testKey} disabled={testing}>
                    {testing ? <Loader2 className="h-4 w-4 animate-spin" /> : <Check className="h-4 w-4 text-primary" />}
                    <span className="ml-1">Re-test</span>
                  </Button>
                )}
              </div>
              {keyTested && (
                <div className="flex items-center gap-2 text-sm text-primary">
                  <Check className="h-4 w-4" /> Anthropic key verified.
                </div>
              )}
              <div className="flex justify-end">
                <Button onClick={() => setStep(2)} disabled={!keyTested}>
                  Next <ChevronRight className="h-4 w-4 ml-1" />
                </Button>
              </div>
            </CardContent>
          </Card>
        )}

        {step === 2 && (
          <Card className="card-elev">
            <CardHeader>
              <CardTitle className="flex items-center gap-2"><UserCircle2 className="h-5 w-5 text-primary" /> Step 2 — Owner profile</CardTitle>
              <CardDescription>How should the team address you?</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid gap-2">
                <Label>Display name</Label>
                <Input value={displayName} onChange={(e) => setDisplayName(e.target.value)} />
              </div>
              <div className="flex justify-between">
                <Button variant="ghost" onClick={() => setStep(1)}>Back</Button>
                <Button onClick={saveProfile}>Next <ChevronRight className="h-4 w-4 ml-1" /></Button>
              </div>
            </CardContent>
          </Card>
        )}

        {step === 3 && (
          <Card className="card-elev">
            <CardHeader>
              <CardTitle className="flex items-center gap-2"><Users className="h-5 w-5 text-primary" /> Step 3 — Seed the team</CardTitle>
              <CardDescription>Spin up Ethan, Claire, Olivia, Sophia, and Nathan.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {!seedDone ? (
                <Button onClick={seedAgents} disabled={seeding} className="w-full">
                  {seeding ? <><Loader2 className="h-4 w-4 mr-2 animate-spin" /> Seeding…</> : "Seed 5 agents"}
                </Button>
              ) : (
                <div className="text-sm text-primary flex items-center gap-2">
                  <Check className="h-4 w-4" /> Team is ready.
                </div>
              )}
              <div className="flex justify-between">
                <Button variant="ghost" onClick={() => setStep(2)}>Back</Button>
                <Button onClick={finish} disabled={!seedDone}>Enter Vanguard Systems</Button>
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}
