import { useEffect, useState } from "react";
import { AppShell } from "@/components/AppShell";
import { useProjects } from "@/contexts/ProjectContext";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import ReactMarkdown from "react-markdown";

interface AgentLite { id: string; name: string; role: string; }
interface LogRow { id: string; agent_name: string; message: string; level: string; created_at: string; project_id: string | null; }
interface PromptRow { id: string; sequence_number: number; title: string; status: string; content_md: string; project_id: string; }
interface ResearchRow { id: string; title: string; content_md: string; created_at: string; }

export default function History() {
  const { currentProject, projects } = useProjects();
  const [allProjects, setAllProjects] = useState(false);
  const [agents, setAgents] = useState<AgentLite[]>([]);
  const [logs, setLogs] = useState<LogRow[]>([]);
  const [prompts, setPrompts] = useState<PromptRow[]>([]);
  const [research, setResearch] = useState<ResearchRow[]>([]);

  useEffect(() => { document.title = "History · Vanguard Systems"; }, []);

  useEffect(() => {
    supabase.from("agents").select("id,name,role").order("sort_order").then(({ data }) => {
      setAgents((data ?? []) as AgentLite[]);
    });
  }, []);

  useEffect(() => {
    const load = async () => {
      const scope = !allProjects && currentProject ? currentProject.id : null;

      let logQ = supabase.from("agent_log").select("*").order("created_at", { ascending: false }).limit(200);
      if (scope) logQ = logQ.eq("project_id", scope);
      const { data: logsData } = await logQ;
      setLogs((logsData ?? []) as LogRow[]);

      let promptQ = supabase.from("lovable_prompts").select("*").order("created_at", { ascending: false }).limit(200);
      if (scope) promptQ = promptQ.eq("project_id", scope);
      const { data: pData } = await promptQ;
      setPrompts((pData ?? []) as PromptRow[]);

      let resQ = supabase.from("research_findings").select("*").order("created_at", { ascending: false }).limit(100);
      if (scope) resQ = resQ.eq("project_id", scope);
      const { data: rData } = await resQ;
      setResearch((rData ?? []) as ResearchRow[]);
    };
    load();
  }, [currentProject?.id, allProjects]);

  const projectName = (id: string | null) => projects.find((p) => p.id === id)?.name ?? "—";

  const logsForAgent = (name: string) => logs.filter((l) => l.agent_name === name);

  return (
    <AppShell>
      <div className="space-y-6">
        <div className="flex items-center justify-between flex-wrap gap-3">
          <div>
            <h1 className="text-2xl font-bold tracking-tight">History</h1>
            <p className="text-sm text-muted-foreground">
              {allProjects ? "Across all projects" : `Scoped to ${currentProject?.name ?? "no project"}`}
            </p>
          </div>
          <div className="flex items-center gap-2">
            <Label htmlFor="all" className="text-sm">All projects</Label>
            <Switch id="all" checked={allProjects} onCheckedChange={setAllProjects} />
          </div>
        </div>

        <Tabs defaultValue="prompts">
          <TabsList>
            <TabsTrigger value="prompts">Prompts ({prompts.length})</TabsTrigger>
            <TabsTrigger value="research">Research ({research.length})</TabsTrigger>
            {agents.map((a) => (
              <TabsTrigger key={a.id} value={a.id}>{a.name.split(" ")[0]}</TabsTrigger>
            ))}
            <TabsTrigger value="all">All activity</TabsTrigger>
          </TabsList>

          <TabsContent value="prompts">
            <Card className="card-elev">
              <CardContent className="p-0">
                <ScrollArea className="h-[60vh]">
                  <div className="divide-y divide-border">
                    {prompts.map((p) => (
                      <details key={p.id} className="px-4 py-3 group">
                        <summary className="flex items-center gap-3 cursor-pointer">
                          <span className="font-mono text-xs text-muted-foreground w-8">#{p.sequence_number}</span>
                          <span className="flex-1 truncate text-sm">{p.title}</span>
                          {allProjects && <Badge variant="outline" className="text-[10px]">{projectName(p.project_id)}</Badge>}
                          <Badge variant="secondary" className="text-[10px]">{p.status}</Badge>
                        </summary>
                        <div className="prose prose-sm prose-invert max-w-none mt-3 pl-11">
                          <ReactMarkdown>{p.content_md}</ReactMarkdown>
                        </div>
                      </details>
                    ))}
                    {prompts.length === 0 && <div className="p-8 text-sm text-muted-foreground text-center">No prompts.</div>}
                  </div>
                </ScrollArea>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="research">
            <Card className="card-elev">
              <CardContent className="p-0">
                <ScrollArea className="h-[60vh]">
                  <div className="divide-y divide-border">
                    {research.map((r) => (
                      <details key={r.id} className="px-4 py-3">
                        <summary className="flex items-center gap-3 cursor-pointer">
                          <span className="flex-1 truncate text-sm">{r.title}</span>
                          <span className="text-[10px] text-muted-foreground">{new Date(r.created_at).toLocaleString()}</span>
                        </summary>
                        <div className="prose prose-sm prose-invert max-w-none mt-3">
                          <ReactMarkdown>{r.content_md}</ReactMarkdown>
                        </div>
                      </details>
                    ))}
                    {research.length === 0 && <div className="p-8 text-sm text-muted-foreground text-center">No research.</div>}
                  </div>
                </ScrollArea>
              </CardContent>
            </Card>
          </TabsContent>

          {agents.map((a) => (
            <TabsContent key={a.id} value={a.id}>
              <Card className="card-elev">
                <CardHeader><CardTitle className="text-sm">{a.name}</CardTitle></CardHeader>
                <CardContent className="p-0">
                  <ScrollArea className="h-[60vh]">
                    <div className="px-4 pb-4 space-y-1.5">
                      {logsForAgent(a.name).map((l) => (
                        <div key={l.id} className="text-xs border-l-2 border-border pl-2.5 py-1">
                          <div className="text-[10px] text-muted-foreground font-mono">{new Date(l.created_at).toLocaleString()}{allProjects && ` · ${projectName(l.project_id)}`}</div>
                          <div>{l.message}</div>
                        </div>
                      ))}
                      {logsForAgent(a.name).length === 0 && <div className="p-6 text-sm text-muted-foreground text-center">No activity.</div>}
                    </div>
                  </ScrollArea>
                </CardContent>
              </Card>
            </TabsContent>
          ))}

          <TabsContent value="all">
            <Card className="card-elev">
              <CardContent className="p-0">
                <ScrollArea className="h-[60vh]">
                  <div className="px-4 pb-4 space-y-1.5">
                    {logs.map((l) => (
                      <div key={l.id} className="text-xs border-l-2 border-border pl-2.5 py-1">
                        <div className="flex items-baseline gap-2">
                          <span className="font-semibold text-primary">{l.agent_name}</span>
                          <span className="text-[10px] text-muted-foreground font-mono">{new Date(l.created_at).toLocaleString()}{allProjects && ` · ${projectName(l.project_id)}`}</span>
                        </div>
                        <div>{l.message}</div>
                      </div>
                    ))}
                  </div>
                </ScrollArea>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </AppShell>
  );
}
