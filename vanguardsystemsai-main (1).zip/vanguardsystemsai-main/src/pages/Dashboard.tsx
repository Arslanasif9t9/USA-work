import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { AppShell } from "@/components/AppShell";
import { ActivityFeed } from "@/components/ActivityFeed";
import { useProjects } from "@/contexts/ProjectContext";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Switch } from "@/components/ui/switch";
import { Copy, ExternalLink, FlaskConical, Loader2, Plus, FolderPlus, Sparkles, CheckCircle2, Unlock, PlayCircle } from "lucide-react";
import { projectModeLabel, projectStatusBadgeClass, projectStatusLabel, isProjectRunnable, projectBlockedReason, type ProjectStatus } from "@/lib/agent-status";
import { Tooltip, TooltipContent, TooltipTrigger } from "@/components/ui/tooltip";
import { cn } from "@/lib/utils";
import { toast } from "sonner";
import ReactMarkdown from "react-markdown";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { NewProjectDialog } from "@/components/NewProjectDialog";
import { useReadyPrompts } from "@/hooks/useReadyPrompts";
import { ReadyPromptDialog } from "@/components/ReadyPromptDialog";
import { ForceReopenDialog } from "@/components/ForceReopenDialog";
import { useChainStatus } from "@/hooks/useChainStatus";
import { ChainStatusBadge } from "@/components/ChainStatusBadge";
import { EscalationCard } from "@/components/EscalationCard";
import { BudgetWarningBanner } from "@/components/BudgetWarningBanner";

// Safely normalize a user-entered URL — accepts "example.com" without protocol.
const safeHref = (u: string): string => {
  if (!u) return "#";
  try { new URL(u); return u; } catch {}
  try { new URL(`https://${u}`); return `https://${u}`; } catch {}
  return "#";
};
const safeHostname = (u: string): string => {
  if (!u) return "";
  try { return new URL(u).hostname; } catch {}
  try { return new URL(`https://${u}`).hostname; } catch {}
  return u;
};

interface Prompt {
  id: string;
  sequence_number: number;
  title: string;
  status: "draft" | "ready" | "delivered" | "implemented";
  content_md: string;
  delivered_at: string | null;
  created_at: string;
}

export default function Dashboard() {
  const navigate = useNavigate();
  const { currentProject, refresh: refreshProjects } = useProjects();
  const [prompts, setPrompts] = useState<Prompt[]>([]);
  const [busyTrigger, setBusyTrigger] = useState<string | null>(null);
  const [previewOpen, setPreviewOpen] = useState(false);
  const [previewPrompt, setPreviewPrompt] = useState<Prompt | null>(null);
  const [newOpen, setNewOpen] = useState(false);
  const [projectSpend, setProjectSpend] = useState(0);
  const [ethanId, setEthanId] = useState<string | undefined>(undefined);
  const [bannerOpen, setBannerOpen] = useState(false);
  const [reopenOpen, setReopenOpen] = useState(false);

  useEffect(() => { document.title = "Dashboard · Vanguard Systems"; }, []);

  // Resolve Ethan's id once for the ready-prompts hook
  useEffect(() => {
    supabase
      .from("agents")
      .select("id")
      .eq("role", "lead_architect")
      .maybeSingle()
      .then(({ data }) => setEthanId(data?.id));
  }, []);

  // Ethan's ready prompts scoped to this project
  const ethanReadyPrompts = useReadyPrompts(ethanId, currentProject?.id);

  useEffect(() => {
    if (!currentProject) {
      setPrompts([]);
      return;
    }
    const load = async () => {
      const { data } = await supabase
        .from("lovable_prompts")
        .select("*")
        .eq("project_id", currentProject.id)
        .order("sequence_number", { ascending: false });
      setPrompts((data ?? []) as Prompt[]);

      const { data: spend } = await supabase
        .from("agent_spend")
        .select("cost_usd")
        .eq("project_id", currentProject.id);
      setProjectSpend((spend ?? []).reduce((s, r: any) => s + Number(r.cost_usd ?? 0), 0));
    };
    load();
    const ch = supabase
      .channel(`dashboard-${currentProject.id}`)
      .on("postgres_changes", { event: "*", schema: "public", table: "lovable_prompts", filter: `project_id=eq.${currentProject.id}` }, () => load())
      .on("postgres_changes", { event: "INSERT", schema: "public", table: "agent_spend", filter: `project_id=eq.${currentProject.id}` }, () => load())
      .subscribe();
    return () => { supabase.removeChannel(ch); };
  }, [currentProject?.id]);

  const trigger = async (kind: "kick_off" | "next_prompt" | "continue_research") => {
    if (!currentProject) return;
    // Auto-resume project if it's on hold so the user can kick off the next cycle in one click.
    if (currentProject.status === "paused") {
      const { error: resumeErr } = await supabase
        .from("projects")
        .update({ status: "active" })
        .eq("id", currentProject.id);
      if (resumeErr) {
        toast.error(`Could not resume project: ${resumeErr.message}`);
        return;
      }
      await refreshProjects();
    } else if (!isProjectRunnable(currentProject.status)) {
      toast.error(projectBlockedReason(currentProject.status) ?? "Project is not active.");
      return;
    }
    // Re-paused agents from the emergency stop need to come back to "sleeping" so the cycle can run.
    await supabase
      .from("agents")
      .update({ status: "sleeping", enabled: true, current_task: null })
      .eq("status", "paused");

    setBusyTrigger(kind);
    const { data, error } = await supabase.functions.invoke("run-cycle", {
      body: { projectId: currentProject.id, trigger: kind },
    });
    setBusyTrigger(null);
    if (error || data?.error) {
      toast.error(data?.error || error?.message || "Cycle failed");
      return;
    }
    toast.success(kind === "continue_research" ? "Research pass started." : "Workflow started — agents are picking up the next prompt.");
  };

  const markDelivered = async (p: Prompt, delivered: boolean) => {
    if (!currentProject) return;
    // Marking as delivered is a human gate — allow even when project is On Hold so the
    // user can record completion without first resuming the project.
    const { error } = await supabase
      .from("lovable_prompts")
      .update({ status: delivered ? "delivered" : "ready", delivered_at: delivered ? new Date().toISOString() : null })
      .eq("id", p.id);
    if (error) {
      toast.error(error.message);
      return;
    }
    if (delivered) {
      toast.success(`Prompt #${p.sequence_number} marked delivered. Click "Start Prompt #${p.sequence_number + 1}" when you're ready to begin the next cycle.`);
    }
  };

  const copyPrompt = async (p: Prompt) => {
    try {
      await navigator.clipboard.writeText(p.content_md);
      toast.success(`Prompt #${p.sequence_number} copied to clipboard.`);
    } catch {
      toast.error("Could not copy. Use Ctrl/Cmd+C in the preview.");
    }
  };

  // Find the next "ready" prompt (lowest sequence not yet delivered)
  const nextReady = [...prompts].reverse().find((p) => p.status === "ready");
  const delivered = prompts.filter((p) => p.status === "delivered" || p.status === "implemented").length;
  const total = prompts.length;
  const completePct = total === 0 ? 0 : Math.round((delivered / total) * 100);
  const runnable = currentProject ? isProjectRunnable(currentProject.status) : false;
  const blockedReason = currentProject ? projectBlockedReason(currentProject.status) : null;
  const projectStatus = (currentProject?.status as ProjectStatus) ?? "active";

  // Sequence number for the NEXT prompt the chain will produce.
  // Highest delivered sequence + 1, or 1 if nothing delivered yet.
  const highestDelivered = prompts
    .filter((p) => p.status === "delivered" || p.status === "implemented")
    .reduce((max, p) => Math.max(max, p.sequence_number), 0);
  const nextSequence = highestDelivered + 1;
  // Only show the kick-off CTA when there's no ready prompt waiting and no agent is currently working.
  const showKickoffCta =
    !nextReady &&
    ethanReadyPrompts.length === 0 &&
    projectStatus !== "complete" &&
    projectStatus !== "archived";

  const { phase: chainPhase } = useChainStatus(currentProject?.id ?? null);
  const [revisionReportId, setRevisionReportId] = useState<string | null>(null);
  const [revisionMd, setRevisionMd] = useState<string>("");

  useEffect(() => {
    if (!revisionReportId) { setRevisionMd(""); return; }
    supabase.from("qa_reports").select("findings_md").eq("id", revisionReportId).maybeSingle()
      .then(({ data }) => setRevisionMd(data?.findings_md ?? ""));
  }, [revisionReportId]);

  if (!currentProject) {
    return (
      <AppShell>
        <div className="grid place-items-center min-h-[60vh]">
          <Card className="max-w-md card-elev">
            <CardHeader>
              <CardTitle className="flex items-center gap-2"><FolderPlus className="h-5 w-5 text-primary" /> No project selected</CardTitle>
              <CardDescription>Create your first project to put the team to work.</CardDescription>
            </CardHeader>
            <CardContent>
              <Button onClick={() => setNewOpen(true)} className="w-full">
                <Plus className="h-4 w-4 mr-1" /> New project
              </Button>
            </CardContent>
          </Card>
          <NewProjectDialog open={newOpen} onOpenChange={setNewOpen} />
        </div>
      </AppShell>
    );
  }

  return (
    <AppShell>
      <div className="space-y-6">
        {/* Project header */}
        <Card className="card-elev gradient-card">
          <CardContent className="p-5 flex items-start justify-between gap-4 flex-wrap">
            <div>
              <div className="flex items-center gap-2 flex-wrap">
                <h1 className="text-2xl font-bold tracking-tight">{currentProject.name}</h1>
                <Badge variant="secondary">{projectModeLabel[currentProject.mode]}</Badge>
                <span
                  className={cn(
                    "inline-flex items-center rounded-full border px-2 py-0.5 text-[11px] font-semibold",
                    projectStatusBadgeClass[projectStatus],
                  )}
                >
                  {projectStatusLabel[projectStatus]}
                </span>
                <ChainStatusBadge phase={chainPhase} onViewRevision={(id) => setRevisionReportId(id)} />
              </div>
              {currentProject.description && (
                <p className="text-sm text-muted-foreground mt-1 max-w-2xl">{currentProject.description}</p>
              )}
              <div className="text-xs text-muted-foreground mt-2 font-mono">{currentProject.tech_stack_target}</div>

              {currentProject.reference_urls && currentProject.reference_urls.length > 0 && (
                <div className="flex flex-wrap gap-2 mt-3">
                  {currentProject.reference_urls.map((u, i) => (
                    <a key={i} href={safeHref(u)} target="_blank" rel="noreferrer" className="inline-flex items-center gap-1 text-xs bg-secondary px-2 py-1 rounded hover:bg-accent">
                      <ExternalLink className="h-3 w-3" /> {safeHostname(u)}
                    </a>
                  ))}
                  {currentProject.existing_site_url && (
                    <a href={safeHref(currentProject.existing_site_url)} target="_blank" rel="noreferrer" className="inline-flex items-center gap-1 text-xs bg-warning/20 text-warning px-2 py-1 rounded hover:bg-warning/30">
                      <ExternalLink className="h-3 w-3" /> existing: {safeHostname(currentProject.existing_site_url)}
                    </a>
                  )}
                </div>
              )}
            </div>

            <div className="text-right space-y-1 min-w-[180px]">
              <div className="text-xs text-muted-foreground">Project spend</div>
              <div className="text-lg font-mono">${projectSpend.toFixed(4)}</div>
              <div className="text-xs text-muted-foreground">{delivered} / {total} delivered</div>
              <Progress value={completePct} className="h-1.5" />
              {projectStatus === "complete" && (
                <Button
                  size="sm"
                  variant="outline"
                  className="mt-2 border-info/40 text-info hover:bg-info/10 hover:text-info hover:border-info/60"
                  onClick={() => setReopenOpen(true)}
                >
                  <Unlock className="h-3.5 w-3.5 mr-1" /> 🔓 Force Reopen Project
                </Button>
              )}
            </div>
          </CardContent>
        </Card>

        <BudgetWarningBanner />

        {chainPhase.kind === "escalated" && currentProject && (
          <EscalationCard
            projectId={currentProject.id}
            reportId={chainPhase.reportId}
            round={chainPhase.round}
            onResolved={() => { /* realtime will refresh chain status */ }}
          />
        )}

        <div className="grid lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2 space-y-6">
            {/* Workflow controls */}
            <Card className="card-elev">
              <CardHeader className="pb-3">
                <CardTitle className="text-sm">Workflow controls</CardTitle>
                <CardDescription className="text-xs">
                  Marking a prompt as delivered is a human gate. The workflow stays stopped until you explicitly trigger the next cycle.
                </CardDescription>
              </CardHeader>
              <CardContent className="flex flex-wrap gap-2">
                {projectStatus === "paused" && (
                  <div className="w-full rounded-md border border-warning/40 bg-warning/10 text-warning px-3 py-2 text-xs mb-1">
                    This project is On Hold. Starting the next prompt will resume it automatically.
                  </div>
                )}
                {projectStatus === "complete" && (
                  <div className="w-full rounded-md border border-info/40 bg-info/10 text-info px-3 py-2 text-xs mb-1">
                    {blockedReason} <a href="/admin/projects" className="underline font-medium">Manage projects →</a>
                  </div>
                )}
                {projectStatus === "archived" && blockedReason && (
                  <div className="w-full rounded-md border border-warning/40 bg-warning/10 text-warning px-3 py-2 text-xs mb-1">
                    {blockedReason} <a href="/admin/projects" className="underline font-medium">Manage projects →</a>
                  </div>
                )}

                {showKickoffCta && (
                  <Button
                    onClick={() => trigger("next_prompt")}
                    disabled={!!busyTrigger}
                    className="bg-primary text-primary-foreground hover:bg-primary/90"
                  >
                    {busyTrigger === "next_prompt" ? (
                      <><Loader2 className="h-4 w-4 mr-2 animate-spin" /> Starting Prompt #{nextSequence}…</>
                    ) : (
                      <><PlayCircle className="h-4 w-4 mr-1.5" /> Start Prompt #{nextSequence} (full chain)</>
                    )}
                  </Button>
                )}

                <Button
                  variant="outline"
                  onClick={() => trigger("continue_research")}
                  disabled={!!busyTrigger || (projectStatus !== "active" && projectStatus !== "paused")}
                >
                  {busyTrigger === "continue_research" ? <><Loader2 className="h-4 w-4 mr-2 animate-spin" /> Researching…</> : <><FlaskConical className="h-4 w-4 mr-1" /> Continue research (Claire only)</>}
                </Button>
                <Button variant="ghost" onClick={() => navigate("/admin/agents")}>View team →</Button>
              </CardContent>
            </Card>

            {/* High-visibility banner — Ethan has ready prompt(s) */}
            {ethanReadyPrompts.length > 0 && (
              <div className="rounded-lg border-2 border-primary/60 bg-gradient-to-r from-primary/15 via-primary/10 to-transparent p-4 flex items-center justify-between gap-3 flex-wrap glow-green animate-in fade-in slide-in-from-top-2">
                <div className="flex items-center gap-3 min-w-0 flex-1">
                  <div className="relative shrink-0">
                    <Sparkles className="h-5 w-5 text-primary" />
                    <span className="absolute -top-1 -right-1 flex h-2.5 w-2.5">
                      <span className="absolute inline-flex h-full w-full rounded-full bg-primary opacity-75 animate-ping" />
                      <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-primary" />
                    </span>
                  </div>
                  <div className="min-w-0">
                    <div className="text-sm font-semibold text-foreground truncate">
                      ✨ {ethanReadyPrompts.length > 1
                        ? `${ethanReadyPrompts.length} new prompts ready from Ethan`
                        : `New prompt ready from Ethan — Prompt #${ethanReadyPrompts[0].sequence_number}: ${ethanReadyPrompts[0].title}`}
                    </div>
                    <div className="text-xs text-muted-foreground mt-0.5">
                      Awaiting your review and delivery.
                    </div>
                  </div>
                </div>
                <div className="flex gap-2 shrink-0">
                  <Button size="sm" variant="outline" onClick={() => copyPrompt(ethanReadyPrompts[0] as any)}>
                    <Copy className="h-3.5 w-3.5 mr-1" /> Copy
                  </Button>
                  <Button size="sm" onClick={() => setBannerOpen(true)}>
                    <CheckCircle2 className="h-3.5 w-3.5 mr-1" /> View & Deliver
                  </Button>
                </div>
              </div>
            )}

            {/* NEXT READY PROMPT */}
            {nextReady ? (
              <Card className="card-elev border-primary/40">
                <CardHeader>
                  <div className="flex items-start justify-between gap-3">
                    <div>
                      <div className="text-xs text-primary uppercase tracking-wider mb-1">Next ready prompt</div>
                      <CardTitle>#{nextReady.sequence_number} — {nextReady.title}</CardTitle>
                    </div>
                    <Badge className="bg-primary text-primary-foreground">ready</Badge>
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="prose prose-sm prose-invert max-w-none max-h-[360px] overflow-y-auto rounded-md bg-secondary/40 p-4 border border-border/40">
                    <ReactMarkdown>{nextReady.content_md}</ReactMarkdown>
                  </div>
                  <div className="flex items-center justify-between flex-wrap gap-3">
                    <div className="flex gap-2">
                      <Button onClick={() => copyPrompt(nextReady)}>
                        <Copy className="h-4 w-4 mr-1" /> Copy full prompt
                      </Button>
                      <Button variant="outline" onClick={() => { setPreviewPrompt(nextReady); setPreviewOpen(true); }}>
                        View full
                      </Button>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="text-sm text-muted-foreground">Mark as delivered</span>
                      <Tooltip>
                        <TooltipTrigger asChild>
                          <span>
                            <Switch checked={false} onCheckedChange={(v) => markDelivered(nextReady, v)} />
                          </span>
                        </TooltipTrigger>
                        {!runnable && <TooltipContent>{blockedReason}</TooltipContent>}
                      </Tooltip>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ) : total === 0 ? (
              <Card className="card-elev border-dashed">
                <CardContent className="p-8 text-center text-sm text-muted-foreground">
                  No prompts yet. The first prompt will appear here as soon as the workflow completes.
                </CardContent>
              </Card>
            ) : (
              <Card className="card-elev border-dashed">
                <CardContent className="p-8 text-center text-sm text-muted-foreground">
                  All prompts delivered. The team is sleeping. 🎉
                </CardContent>
              </Card>
            )}

            {/* Roadmap */}
            <Card className="card-elev">
              <CardHeader><CardTitle className="text-sm">Roadmap ({total})</CardTitle></CardHeader>
              <CardContent className="space-y-1.5">
                {[...prompts].sort((a, b) => a.sequence_number - b.sequence_number).map((p) => (
                  <button
                    key={p.id}
                    onClick={() => { setPreviewPrompt(p); setPreviewOpen(true); }}
                    className="w-full flex items-center gap-3 px-3 py-2 rounded-md hover:bg-secondary text-left transition-colors"
                  >
                    <span className="font-mono text-xs text-muted-foreground w-8">#{p.sequence_number}</span>
                    <span className="flex-1 truncate text-sm">{p.title}</span>
                    <Badge variant={p.status === "delivered" || p.status === "implemented" ? "default" : "secondary"} className="text-[10px]">
                      {p.status}
                    </Badge>
                  </button>
                ))}
                {total === 0 && <div className="text-xs text-muted-foreground py-3">No prompts yet.</div>}
              </CardContent>
            </Card>
          </div>

          <div className="lg:col-span-1">
            <ActivityFeed />
          </div>
        </div>

        <Dialog open={!!revisionReportId} onOpenChange={(v) => !v && setRevisionReportId(null)}>
          <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
            <DialogHeader><DialogTitle>Sophia's revision notes</DialogTitle></DialogHeader>
            <div className="prose prose-sm prose-invert max-w-none">
              <ReactMarkdown>{revisionMd || "_Loading…_"}</ReactMarkdown>
            </div>
          </DialogContent>
        </Dialog>

        <Dialog open={previewOpen} onOpenChange={setPreviewOpen}>
          <DialogContent className="max-w-3xl max-h-[85vh] overflow-y-auto">
            {previewPrompt && (
              <>
                <DialogHeader>
                  <DialogTitle>#{previewPrompt.sequence_number} — {previewPrompt.title}</DialogTitle>
                </DialogHeader>
                <div className="prose prose-sm prose-invert max-w-none">
                  <ReactMarkdown>{previewPrompt.content_md}</ReactMarkdown>
                </div>
                <div className="flex justify-end pt-2">
                  <Button onClick={() => copyPrompt(previewPrompt)}>
                    <Copy className="h-4 w-4 mr-1" /> Copy full prompt
                  </Button>
                </div>
              </>
            )}
          </DialogContent>
        </Dialog>

        <ReadyPromptDialog
          open={bannerOpen}
          onOpenChange={setBannerOpen}
          prompts={ethanReadyPrompts as any}
          projectStatus={projectStatus}
          projectName={currentProject.name}
          onMarkProjectComplete={async (projectId) => {
            const { error } = await supabase.functions.invoke("project-status", {
              body: { projectId, action: "set_status", status: "complete" },
            });
            if (error) throw new Error(error.message);
            await refreshProjects();
          }}
          onDelivered={async () => {
            toast.success("Prompt marked delivered. Start the next cycle manually when you're ready.");
          }}
        />

        <ForceReopenDialog
          open={reopenOpen}
          onOpenChange={setReopenOpen}
          projectId={currentProject.id}
          projectName={currentProject.name}
          onReopened={() => refreshProjects()}
        />
      </div>
    </AppShell>
  );
}
