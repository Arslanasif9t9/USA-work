import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { AgentCard, Agent } from "@/components/AgentCard";
import { AgentChatDrawer } from "@/components/AgentChatDrawer";
import { ActivityFeed } from "@/components/ActivityFeed";
import { AppShell } from "@/components/AppShell";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useProjects } from "@/contexts/ProjectContext";
import { Pause, Power, Sparkles, Loader2, AlertTriangle, CheckCircle2, Bell } from "lucide-react";
import { toast } from "sonner";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import ReactMarkdown from "react-markdown";
import { Link } from "react-router-dom";
import { useReadyPrompts } from "@/hooks/useReadyPrompts";
import { ReadyPromptDialog } from "@/components/ReadyPromptDialog";
import { StuckAgentsBanner } from "@/components/StuckAgentsBanner";
import { BudgetWarningBanner } from "@/components/BudgetWarningBanner";

export default function AgentsPage() {
  const { currentProject, refresh: refreshProjects } = useProjects();
  const [agents, setAgents] = useState<Agent[]>([]);
  const [chatOpen, setChatOpen] = useState(false);
  const [chatAgent, setChatAgent] = useState<Agent | null>(null);
  const [reportOpen, setReportOpen] = useState(false);
  const [reportContent, setReportContent] = useState("");
  const [reportTitle, setReportTitle] = useState("");
  const [regeneratingIds, setRegeneratingIds] = useState<Set<string>>(new Set());
  const [hasFalKey, setHasFalKey] = useState<boolean | null>(null);
  const [bulkProgress, setBulkProgress] = useState<{ current: number; total: number } | null>(null);
  const [retryingAgentId, setRetryingAgentId] = useState<string | null>(null);

  useEffect(() => { document.title = "Agents · Vanguard Systems"; }, []);

  useEffect(() => {
    supabase.functions.invoke("manage-secret", { body: { action: "list" } }).then(({ data }) => {
      const present = (data?.secrets ?? []).some((s: any) => s.key_name === "FAL_API_KEY");
      setHasFalKey(present);
    }).catch(() => setHasFalKey(false));
  }, []);

  useEffect(() => {
    const load = async () => {
      const { data } = await supabase.from("agents").select("*").order("sort_order");
      setAgents((data ?? []) as unknown as Agent[]);
    };
    load();
    const ch = supabase
      .channel("agents-realtime")
      .on("postgres_changes", { event: "*", schema: "public", table: "agents" }, () => load())
      .subscribe();
    return () => { supabase.removeChannel(ch); };
  }, []);

  const toggleAgent = async (a: Agent, enabled: boolean) => {
    await supabase.from("agents").update({
      enabled,
      status: enabled ? "sleeping" : "paused",
    }).eq("id", a.id);
  };

  const pauseAll = async () => {
    await supabase.from("agents").update({ enabled: false, status: "paused", current_task: null }).neq("id", "00000000-0000-0000-0000-000000000000");
    toast.success("All agents paused. Emergency stop engaged.");
  };

  const openReport = async (a: Agent) => {
    const today = new Date(); today.setHours(0,0,0,0);
    const { data: spend } = await supabase.from("agent_spend").select("*").eq("agent_id", a.id).gte("created_at", today.toISOString()).order("created_at", { ascending: false });
    const { data: logs } = await supabase.from("agent_log").select("*").eq("agent_id", a.id).order("created_at", { ascending: false }).limit(20);
    const md = `# ${a.name} — daily report

**Title:** ${a.title}
**Model:** ${a.model}
**Status:** ${a.status}
**Tokens today:** ${a.tokens_today.toLocaleString()}
**Cost today:** $${Number(a.cost_today_usd).toFixed(4)} / $${Number(a.daily_budget_usd).toFixed(2)}

## Recent calls (${spend?.length ?? 0})
${(spend ?? []).slice(0, 10).map((s: any) => `- **${new Date(s.created_at).toLocaleString()}** · ${s.call_type} · ${s.input_tokens}+${s.output_tokens} tok · $${Number(s.cost_usd).toFixed(4)}`).join("\n") || "_no calls today_"}

## Recent activity
${(logs ?? []).map((l: any) => `- **${new Date(l.created_at).toLocaleTimeString()}** — ${l.message}`).join("\n") || "_no activity_"}
`;
    setReportContent(md);
    setReportTitle(`${a.name} — Daily report`);
    setReportOpen(true);
    try { await navigator.clipboard.writeText(md); toast.success("Report copied to clipboard."); } catch {}
  };

  const retryAgent = async (agent: Agent) => {
    if (!currentProject) {
      toast.error("Select an active project before retrying an agent.");
      return;
    }
    if (currentProject.status !== "active") {
      toast.error("Resume this project before retrying the workflow.");
      return;
    }

    setRetryingAgentId(agent.id);
    try {
      const { data, error } = await supabase.functions.invoke("run-cycle", {
        body: { projectId: currentProject.id, trigger: "retry_failed", agentId: agent.id },
      });

      if (error || data?.error) {
        toast.error(data?.error || error?.message || `Could not retry ${agent.name}.`);
        return;
      }

      toast.success(`${agent.name} retry started.`);
    } finally {
      setRetryingAgentId(null);
    }
  };

  const ethan = agents.find((a) => a.role === "lead_architect");
  const middle = agents.filter((a) => ["research_lead", "content_writer", "qa_auditor"].includes(a.role));
  const nathan = agents.find((a) => a.role === "credit_controller");

  // Subscribe to ALL ready prompts authored by Ethan across every project
  const ethanReadyPrompts = useReadyPrompts(ethan?.id);
  const [readyDialogOpen, setReadyDialogOpen] = useState(false);

  const reportsToName = (id: string | null) => agents.find((a) => a.id === id)?.name;

  const regenerateAvatar = async (agent: Agent): Promise<boolean> => {
    if (hasFalKey === false) {
      toast.error("Set your fal API key in Settings to generate avatars.");
      return false;
    }
    setRegeneratingIds((prev) => new Set(prev).add(agent.id));
    try {
      const { data, error } = await supabase.functions.invoke("generate-avatar", { body: { agentId: agent.id } });
      if (error) { toast.error(error.message); return false; }
      if (data?.code === "NO_KEY") {
        setHasFalKey(false);
        toast.error(data.message);
        return false;
      }
      if (!data?.ok) { toast.error(data?.error ?? "Generation failed"); return false; }
      toast.success(`${agent.name}'s avatar regenerated.`);
      return true;
    } finally {
      setRegeneratingIds((prev) => { const n = new Set(prev); n.delete(agent.id); return n; });
    }
  };

  const generateAllAvatars = async () => {
    if (hasFalKey === false) {
      toast.error("Set your fal API key in Settings to generate avatars.");
      return;
    }
    const ordered = [
      ...(ethan ? [ethan] : []),
      ...middle,
      ...(nathan ? [nathan] : []),
    ];
    setBulkProgress({ current: 0, total: ordered.length });
    let succeeded = 0;
    for (let i = 0; i < ordered.length; i++) {
      setBulkProgress({ current: i + 1, total: ordered.length });
      const ok = await regenerateAvatar(ordered[i]);
      if (ok) succeeded++;
    }
    setBulkProgress(null);
    toast.success(`Generated ${succeeded} of ${ordered.length} avatars (~$${(succeeded * 0.025).toFixed(3)}).`);
  };

  return (
    <AppShell>
      <div className="space-y-6">
        <div className="flex items-center justify-between flex-wrap gap-3">
          <div>
            <h1 className="text-2xl font-bold tracking-tight">Team</h1>
            <p className="text-sm text-muted-foreground">5 reusable agents working across all your projects.</p>
          </div>
          <div className="flex gap-2 flex-wrap">
            <Button variant="outline" size="sm" onClick={pauseAll}>
              <Pause className="h-3.5 w-3.5 mr-1" /> Pause all
            </Button>
          </div>
        </div>

        <StuckAgentsBanner />
        <BudgetWarningBanner />

        {hasFalKey === false && (
          <div className="flex items-start gap-3 p-4 rounded-md border border-warning/40 bg-warning/5">
            <AlertTriangle className="h-4 w-4 text-warning shrink-0 mt-0.5" />
            <div className="flex-1 text-sm">
              <div className="font-medium">Set your fal API key in Settings to generate avatars.</div>
              <div className="text-xs text-muted-foreground mt-1">
                Avatars are generated by fal-ai/flux/dev (~$0.025 per portrait, ~$0.125 for the full team).
              </div>
            </div>
            <Button asChild size="sm" variant="outline">
              <Link to="/admin/settings">Open Settings</Link>
            </Button>
          </div>
        )}

        <div className="grid xl:grid-cols-3 gap-6">
          <div className="xl:col-span-2 space-y-6">
            {/* Org chart — Ethan full width */}
            {ethan && (
              <div className="space-y-2">
                <AgentCard
                  agent={ethan}
                  onToggle={(v) => toggleAgent(ethan, v)}
                  onChat={() => { setChatAgent(ethan); setChatOpen(true); }}
                  onReport={() => openReport(ethan)}
                  onRetry={() => retryAgent(ethan)}
                  retrying={retryingAgentId === ethan.id}
                  onRegenerateAvatar={() => regenerateAvatar(ethan)}
                  regeneratingAvatar={regeneratingIds.has(ethan.id)}
                  readyPromptCount={ethanReadyPrompts.length}
                  firstReadySeq={ethanReadyPrompts[0]?.sequence_number}
                  onViewReady={() => setReadyDialogOpen(true)}
                />
                {currentProject?.status === "complete" && (
                  <div className="flex items-center gap-2 rounded-md border border-info/40 bg-info/10 text-info px-3 py-2 text-xs">
                    <CheckCircle2 className="h-3.5 w-3.5 shrink-0" />
                    <span>
                      ✓ This project is complete. Use{" "}
                      <Link to="/admin/projects" className="underline font-medium">
                        Force Reopen on the Projects page
                      </Link>{" "}
                      to resume.
                    </span>
                  </div>
                )}
                {currentProject?.status === "paused" && (
                  <div className="flex items-center gap-2 rounded-md border border-warning/40 bg-warning/10 text-warning px-3 py-2 text-xs">
                    <span>
                      ⏸ This project is on hold. Resume it from the{" "}
                      <Link to="/admin/projects" className="underline font-medium">
                        Projects page
                      </Link>{" "}
                      to continue.
                    </span>
                  </div>
                )}
              </div>
            )}

            {/* Middle three — responsive grid: 1 col narrow, 2 col md, 3 col xl, min 280px each */}
            <div className="grid gap-4 [grid-template-columns:repeat(auto-fit,minmax(280px,1fr))]">
              {middle.map((a) => (
                <AgentCard
                  key={a.id}
                  agent={a}
                  reportsToName={reportsToName(a.reports_to)}
                  onToggle={(v) => toggleAgent(a, v)}
                  onChat={() => { setChatAgent(a); setChatOpen(true); }}
                  onReport={() => openReport(a)}
                  onRetry={() => retryAgent(a)}
                  retrying={retryingAgentId === a.id}
                  onRegenerateAvatar={() => regenerateAvatar(a)}
                  regeneratingAvatar={regeneratingIds.has(a.id)}
                />
              ))}
            </div>

            {nathan && (
              <Card className="border-dashed border-status-budget/40">
                <CardHeader className="pb-2">
                  <CardTitle className="text-xs uppercase text-muted-foreground tracking-wider flex items-center gap-1.5">
                    <Power className="h-3 w-3 text-status-budget" /> Watchdog
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <AgentCard
                    agent={nathan}
                    onToggle={(v) => toggleAgent(nathan, v)}
                    onChat={() => { setChatAgent(nathan); setChatOpen(true); }}
                    onReport={() => openReport(nathan)}
                    onRetry={() => retryAgent(nathan)}
                    retrying={retryingAgentId === nathan.id}
                    onRegenerateAvatar={() => regenerateAvatar(nathan)}
                    regeneratingAvatar={regeneratingIds.has(nathan.id)}
                  />
                </CardContent>
              </Card>
            )}
          </div>

          <div className="xl:col-span-1">
            <ActivityFeed />
          </div>
        </div>

        <AgentChatDrawer agent={chatAgent} open={chatOpen} onOpenChange={setChatOpen} />

        <ReadyPromptDialog
          open={readyDialogOpen}
          onOpenChange={setReadyDialogOpen}
          prompts={ethanReadyPrompts}
          projectStatus={
            // The active prompt's project status — fall back to currentProject if it matches.
            (ethanReadyPrompts[0] && currentProject && ethanReadyPrompts[0].project_id === currentProject.id
              ? currentProject.status
              : "active") as "active" | "paused" | "complete" | "archived"
          }
          projectName={
            ethanReadyPrompts[0] && currentProject && ethanReadyPrompts[0].project_id === currentProject.id
              ? currentProject.name
              : undefined
          }
          onMarkProjectComplete={async (projectId) => {
            const { error } = await supabase.functions.invoke("project-status", {
              body: { projectId, action: "set_status", status: "complete" },
            });
            if (error) throw new Error(error.message);
            await refreshProjects();
          }}
          onDelivered={async () => {
            toast.success("Prompt marked delivered. Start the next cycle manually when you're ready.");
          }}
        />

        <Dialog open={reportOpen} onOpenChange={setReportOpen}>
          <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
            <DialogHeader><DialogTitle>{reportTitle}</DialogTitle></DialogHeader>
            <div className="prose prose-sm prose-invert max-w-none">
              <ReactMarkdown>{reportContent}</ReactMarkdown>
            </div>
          </DialogContent>
        </Dialog>
      </div>
    </AppShell>
  );
}
