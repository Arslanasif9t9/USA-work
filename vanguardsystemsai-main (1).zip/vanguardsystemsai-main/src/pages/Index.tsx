// Index dispatcher: routes the user to the right place based on auth + setup state.
import { useEffect, useState } from "react";
import { Navigate } from "react-router-dom";
import { useAuth } from "@/contexts/AuthContext";
import { supabase } from "@/integrations/supabase/client";
import Dashboard from "./Dashboard";

const Index = () => {
  const { session, isOwner, loading } = useAuth();
  const [setupChecked, setSetupChecked] = useState(false);
  const [needsSetup, setNeedsSetup] = useState(false);

  useEffect(() => {
    if (loading || !isOwner) {
      setSetupChecked(true);
      return;
    }
    const check = async () => {
      const [secretsRes, agentsRes] = await Promise.all([
        supabase.functions.invoke("manage-secret", { body: { action: "list" } }),
        supabase.from("agents").select("id", { count: "exact", head: true }),
      ]);
      const hasAnthropic = (secretsRes.data?.secrets ?? []).some((s: any) => s.key_name === "ANTHROPIC_API_KEY");
      const agentCount = agentsRes.count ?? 0;
      setNeedsSetup(!hasAnthropic || agentCount === 0);
      setSetupChecked(true);
    };
    check();
  }, [loading, isOwner]);

  if (loading || !setupChecked) {
    return <div className="min-h-screen grid place-items-center text-muted-foreground">Loading Vanguard Systems…</div>;
  }
  if (!session) return <Navigate to="/auth" replace />;
  if (!isOwner) {
    return (
      <div className="min-h-screen grid place-items-center p-4">
        <div className="max-w-md text-center">
          <h1 className="text-xl font-semibold mb-2">Owner access only</h1>
          <p className="text-sm text-muted-foreground">Vanguard Systems is restricted to the workspace owner.</p>
        </div>
      </div>
    );
  }
  if (needsSetup) return <Navigate to="/setup" replace />;
  return <Dashboard />;
};

export default Index;
