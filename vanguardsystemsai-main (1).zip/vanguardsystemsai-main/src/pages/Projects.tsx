import { useEffect, useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { AppShell } from "@/components/AppShell";
import { useProjects, type Project } from "@/contexts/ProjectContext";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { NewProjectDialog } from "@/components/NewProjectDialog";
import { toast } from "sonner";
import {
  MoreVertical,
  Plus,
  PauseCircle,
  CheckCircle2,
  Trash2,
  Play,
  Download,
  ExternalLink,
  FolderKanban,
  Unlock,
} from "lucide-react";
import { ForceReopenDialog } from "@/components/ForceReopenDialog";
import {
  projectModeLabel,
  projectStatusBadgeClass,
  projectStatusLabel,
  type ProjectStatus,
} from "@/lib/agent-status";
import { cn } from "@/lib/utils";
import { useChainStatus } from "@/hooks/useChainStatus";
import { ChainStatusBadge } from "@/components/ChainStatusBadge";

function ProjectChainStatus({ projectId }: { projectId: string }) {
  const { phase } = useChainStatus(projectId);
  if (phase.kind === "idle") return null;
  return <ChainStatusBadge phase={phase} compact />;
}

type DialogKind = "complete" | "delete" | null;

interface OpenDialog {
  kind: DialogKind;
  project: Project | null;
}

export default function Projects() {
  const navigate = useNavigate();
  const { projects, refresh, setCurrentProject } = useProjects();
  const [newOpen, setNewOpen] = useState(false);
  const [dialog, setDialog] = useState<OpenDialog>({ kind: null, project: null });
  const [deleteText, setDeleteText] = useState("");
  const [busy, setBusy] = useState(false);
  const [reopenProject, setReopenProject] = useState<Project | null>(null);

  useEffect(() => {
    document.title = "Projects · Vanguard Systems";
  }, []);

  const grouped = useMemo(() => {
    const order: ProjectStatus[] = ["active", "paused", "complete", "archived"];
    return order
      .map((s) => ({ status: s, items: projects.filter((p) => (p.status as ProjectStatus) === s) }))
      .filter((g) => g.items.length > 0);
  }, [projects]);

  const setStatus = async (p: Project, status: ProjectStatus) => {
    setBusy(true);
    const { error } = await supabase.from("projects").update({ status }).eq("id", p.id);
    setBusy(false);
    if (error) {
      toast.error(error.message);
      return;
    }
    toast.success(`${p.name} → ${projectStatusLabel[status]}`);
    await refresh();
  };

  const handleDelete = async () => {
    const p = dialog.project;
    if (!p) return;
    if (deleteText.trim() !== p.name) {
      toast.error("Project name does not match.");
      return;
    }
    setBusy(true);
    // Cascade-delete in dependency order. Database has no FK cascade, so do this client-side.
    const tables = [
      "lovable_prompts",
      "research_findings",
      "content_drafts",
      "qa_reports",
      "agent_log",
      "agent_spend",
      "daily_summaries",
    ] as const;
    for (const t of tables) {
      await supabase.from(t).delete().eq("project_id", p.id);
    }
    const { error } = await supabase.from("projects").delete().eq("id", p.id);
    setBusy(false);
    if (error) {
      toast.error(error.message);
      return;
    }
    toast.success(`${p.name} permanently deleted.`);
    setDialog({ kind: null, project: null });
    setDeleteText("");
    setCurrentProject(null);
    await refresh();
  };

  const handleDownloadPrompts = async (p: Project) => {
    const { data, error } = await supabase
      .from("lovable_prompts")
      .select("sequence_number,title,status,content_md,created_at,delivered_at")
      .eq("project_id", p.id)
      .order("sequence_number", { ascending: true });
    if (error) {
      toast.error(error.message);
      return;
    }
    const rows = data ?? [];
    if (rows.length === 0) {
      toast.error("No prompts to download.");
      return;
    }
    const md = [
      `# ${p.name} — All Prompts`,
      ``,
      `Mode: ${projectModeLabel[p.mode] ?? p.mode}`,
      `Status: ${projectStatusLabel[p.status as ProjectStatus] ?? p.status}`,
      `Exported: ${new Date().toISOString()}`,
      ``,
      `---`,
      ``,
      ...rows.map(
        (r: any) =>
          `## #${r.sequence_number} — ${r.title}\n\n` +
          `Status: ${r.status} · Created: ${r.created_at}` +
          (r.delivered_at ? ` · Delivered: ${r.delivered_at}` : "") +
          `\n\n${r.content_md}\n\n---\n`,
      ),
    ].join("\n");
    const blob = new Blob([md], { type: "text/markdown;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `${p.slug || p.name.replace(/\s+/g, "-").toLowerCase()}-prompts.md`;
    document.body.appendChild(a);
    a.click();
    a.remove();
    URL.revokeObjectURL(url);
    toast.success(`Downloaded ${rows.length} prompt(s).`);
  };

  const openProject = (p: Project) => {
    setCurrentProject(p);
    navigate("/");
  };

  return (
    <AppShell>
      <div className="space-y-6">
        <div className="flex items-end justify-between gap-4 flex-wrap">
          <div>
            <h1 className="text-2xl font-bold tracking-tight flex items-center gap-2">
              <FolderKanban className="h-6 w-6 text-primary" /> Projects
            </h1>
            <p className="text-sm text-muted-foreground mt-1">
              Each project runs its agents independently. Only Active projects can trigger work.
            </p>
          </div>
          <Button onClick={() => setNewOpen(true)}>
            <Plus className="h-4 w-4 mr-1" /> New project
          </Button>
        </div>

        {projects.length === 0 && (
          <Card className="card-elev border-dashed">
            <CardContent className="p-10 text-center text-sm text-muted-foreground">
              No projects yet. Create one to put the team to work.
            </CardContent>
          </Card>
        )}

        {grouped.map((group) => (
          <section key={group.status} className="space-y-3">
            <h2 className="text-xs uppercase tracking-wider text-muted-foreground font-semibold">
              {projectStatusLabel[group.status]} ({group.items.length})
            </h2>
            <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">
              {group.items.map((p) => {
                const status = (p.status as ProjectStatus) ?? "active";
                const isComplete = status === "complete";
                const isOnHold = status === "paused";
                return (
                  <Card
                    key={p.id}
                    className={cn(
                      "card-elev gradient-card relative overflow-hidden transition hover:border-primary/40",
                      isComplete && "opacity-90",
                    )}
                  >
                    {isComplete && (
                      <div className="absolute top-3 right-3 z-10 pointer-events-none">
                        <span className="inline-flex items-center gap-1 rounded-md bg-info/15 text-info border border-info/30 px-2 py-0.5 text-[10px] font-bold uppercase tracking-wider">
                          ✓ Complete
                        </span>
                      </div>
                    )}

                    <CardContent className="p-5 space-y-3">
                      <div className="flex items-start justify-between gap-2">
                        <button
                          onClick={() => openProject(p)}
                          className="text-left flex-1 min-w-0 group"
                        >
                          <div className="font-semibold text-base truncate group-hover:text-primary transition-colors">
                            {p.name}
                          </div>
                          <div className="text-xs text-muted-foreground font-mono mt-0.5 truncate">
                            {p.slug}
                          </div>
                        </button>
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button
                              variant="ghost"
                              size="icon"
                              className="h-8 w-8 -mr-2 -mt-1 shrink-0"
                              aria-label="Project actions"
                            >
                              <MoreVertical className="h-4 w-4" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end" className="w-56">
                            {status === "active" && (
                              <>
                                <DropdownMenuItem onClick={() => setStatus(p, "paused")}>
                                  <PauseCircle className="h-4 w-4 mr-2" /> Put On Hold
                                </DropdownMenuItem>
                                <DropdownMenuItem
                                  onClick={() => setDialog({ kind: "complete", project: p })}
                                >
                                  <CheckCircle2 className="h-4 w-4 mr-2" /> Mark Complete
                                </DropdownMenuItem>
                              </>
                            )}
                            {isOnHold && (
                              <DropdownMenuItem onClick={() => setStatus(p, "active")}>
                                <Play className="h-4 w-4 mr-2" /> Resume (make active)
                              </DropdownMenuItem>
                            )}
                            {isComplete && (
                              <>
                                <DropdownMenuItem onClick={() => setReopenProject(p)}>
                                  <Unlock className="h-4 w-4 mr-2" /> 🔓 Force Reopen
                                </DropdownMenuItem>
                                <DropdownMenuItem onClick={() => handleDownloadPrompts(p)}>
                                  <Download className="h-4 w-4 mr-2" /> Download all prompts as .md
                                </DropdownMenuItem>
                              </>
                            )}
                            <DropdownMenuSeparator />
                            <DropdownMenuItem
                              className="text-destructive focus:text-destructive"
                              onClick={() => {
                                setDeleteText("");
                                setDialog({ kind: "delete", project: p });
                              }}
                            >
                              <Trash2 className="h-4 w-4 mr-2" /> Delete
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </div>

                      <div className="flex items-center gap-2 flex-wrap">
                        <span
                          className={cn(
                            "inline-flex items-center rounded-full border px-2 py-0.5 text-[11px] font-semibold",
                            projectStatusBadgeClass[status],
                          )}
                        >
                          {projectStatusLabel[status]}
                        </span>
                        <span className="inline-flex items-center rounded-full border border-border bg-secondary/40 text-muted-foreground px-2 py-0.5 text-[11px]">
                          {projectModeLabel[p.mode] ?? p.mode}
                        </span>
                      </div>

                      <ProjectChainStatus projectId={p.id} />

                      {p.description && (
                        <p className="text-xs text-muted-foreground line-clamp-2">
                          {p.description}
                        </p>
                      )}

                      {isComplete && (
                        <Button
                          variant="outline"
                          size="sm"
                          className="w-full h-8 border-info/40 text-info hover:bg-info/10 hover:text-info hover:border-info/60"
                          onClick={() => setReopenProject(p)}
                        >
                          <Unlock className="h-3.5 w-3.5 mr-1" /> 🔓 Force Reopen Project
                        </Button>
                      )}

                      <div className="flex items-center justify-between pt-1">
                        <div className="text-[10px] font-mono text-muted-foreground truncate">
                          {p.tech_stack_target}
                        </div>
                        <Button
                          variant="ghost"
                          size="sm"
                          className="h-7 text-xs"
                          onClick={() => openProject(p)}
                        >
                          Open <ExternalLink className="h-3 w-3 ml-1" />
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          </section>
        ))}
      </div>

      {/* New project */}
      <NewProjectDialog open={newOpen} onOpenChange={setNewOpen} />

      {/* Mark Complete confirmation */}
      <Dialog
        open={dialog.kind === "complete"}
        onOpenChange={(v) => !v && setDialog({ kind: null, project: null })}
      >
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Mark project complete?</DialogTitle>
            <DialogDescription>
              Mark <span className="font-semibold text-foreground">{dialog.project?.name}</span> as
              complete? You can still view all prompts and research, but agents will stop running.
              You can reopen anytime.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setDialog({ kind: null, project: null })}
              disabled={busy}
            >
              Cancel
            </Button>
            <Button
              onClick={async () => {
                if (dialog.project) await setStatus(dialog.project, "complete");
                setDialog({ kind: null, project: null });
              }}
              disabled={busy}
            >
              <CheckCircle2 className="h-4 w-4 mr-1" /> Confirm
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Delete confirmation */}
      <AlertDialog
        open={dialog.kind === "delete"}
        onOpenChange={(v) => !v && setDialog({ kind: null, project: null })}
      >
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle className="text-destructive">Delete project permanently?</AlertDialogTitle>
            <AlertDialogDescription>
              This permanently removes{" "}
              <span className="font-semibold text-foreground">{dialog.project?.name}</span> and all
              its data — prompts, research, chat history, and logs. This cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <div className="space-y-2">
            <label className="text-xs text-muted-foreground">
              Type <span className="font-mono text-foreground">{dialog.project?.name}</span> to
              confirm:
            </label>
            <Input
              value={deleteText}
              onChange={(e) => setDeleteText(e.target.value)}
              placeholder={dialog.project?.name}
              autoFocus
            />
          </div>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={busy}>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={(e) => {
                e.preventDefault();
                handleDelete();
              }}
              disabled={busy || deleteText.trim() !== (dialog.project?.name ?? "")}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              <Trash2 className="h-4 w-4 mr-1" /> Delete permanently
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Force Reopen — password-protected, server-validated */}
      <ForceReopenDialog
        open={!!reopenProject}
        onOpenChange={(v) => !v && setReopenProject(null)}
        projectId={reopenProject?.id ?? null}
        projectName={reopenProject?.name ?? null}
        onReopened={() => {
          setReopenProject(null);
          refresh();
        }}
      />
    </AppShell>
  );
}
