export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.5"
  }
  public: {
    Tables: {
      agent_jobs: {
        Row: {
          agent_id: string
          attempt_number: number
          completed_at: string | null
          cost_usd: number
          created_at: string
          duration_ms: number | null
          error_message: string | null
          error_stack: string | null
          id: string
          input_payload: Json
          output_payload: Json | null
          project_id: string
          prompt_cycle_id: string
          started_at: string | null
          status: Database["public"]["Enums"]["agent_job_status"]
          tokens_used: number
          trigger_source: Database["public"]["Enums"]["agent_job_trigger_source"]
          updated_at: string
        }
        Insert: {
          agent_id: string
          attempt_number?: number
          completed_at?: string | null
          cost_usd?: number
          created_at?: string
          duration_ms?: number | null
          error_message?: string | null
          error_stack?: string | null
          id?: string
          input_payload?: Json
          output_payload?: Json | null
          project_id: string
          prompt_cycle_id: string
          started_at?: string | null
          status?: Database["public"]["Enums"]["agent_job_status"]
          tokens_used?: number
          trigger_source: Database["public"]["Enums"]["agent_job_trigger_source"]
          updated_at?: string
        }
        Update: {
          agent_id?: string
          attempt_number?: number
          completed_at?: string | null
          cost_usd?: number
          created_at?: string
          duration_ms?: number | null
          error_message?: string | null
          error_stack?: string | null
          id?: string
          input_payload?: Json
          output_payload?: Json | null
          project_id?: string
          prompt_cycle_id?: string
          started_at?: string | null
          status?: Database["public"]["Enums"]["agent_job_status"]
          tokens_used?: number
          trigger_source?: Database["public"]["Enums"]["agent_job_trigger_source"]
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "agent_jobs_agent_id_fkey"
            columns: ["agent_id"]
            isOneToOne: false
            referencedRelation: "agents"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "agent_jobs_project_id_fkey"
            columns: ["project_id"]
            isOneToOne: false
            referencedRelation: "projects"
            referencedColumns: ["id"]
          },
        ]
      }
      agent_log: {
        Row: {
          agent_id: string | null
          agent_name: string
          created_at: string
          id: string
          level: string
          message: string
          metadata: Json | null
          project_id: string | null
        }
        Insert: {
          agent_id?: string | null
          agent_name: string
          created_at?: string
          id?: string
          level?: string
          message: string
          metadata?: Json | null
          project_id?: string | null
        }
        Update: {
          agent_id?: string | null
          agent_name?: string
          created_at?: string
          id?: string
          level?: string
          message?: string
          metadata?: Json | null
          project_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "agent_log_agent_id_fkey"
            columns: ["agent_id"]
            isOneToOne: false
            referencedRelation: "agents"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "agent_log_project_id_fkey"
            columns: ["project_id"]
            isOneToOne: false
            referencedRelation: "projects"
            referencedColumns: ["id"]
          },
        ]
      }
      agent_spend: {
        Row: {
          agent_id: string
          call_type: string
          cost_usd: number
          created_at: string
          id: string
          input_tokens: number
          model: string
          output_tokens: number
          project_id: string | null
        }
        Insert: {
          agent_id: string
          call_type?: string
          cost_usd?: number
          created_at?: string
          id?: string
          input_tokens?: number
          model: string
          output_tokens?: number
          project_id?: string | null
        }
        Update: {
          agent_id?: string
          call_type?: string
          cost_usd?: number
          created_at?: string
          id?: string
          input_tokens?: number
          model?: string
          output_tokens?: number
          project_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "agent_spend_agent_id_fkey"
            columns: ["agent_id"]
            isOneToOne: false
            referencedRelation: "agents"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "agent_spend_project_id_fkey"
            columns: ["project_id"]
            isOneToOne: false
            referencedRelation: "projects"
            referencedColumns: ["id"]
          },
        ]
      }
      agents: {
        Row: {
          attire: string
          avatar_url: string
          base_system_prompt: string
          cost_today_usd: number
          created_at: string
          current_task: string | null
          daily_budget_usd: number
          enabled: boolean
          failure_flag: boolean
          id: string
          last_error_message: string | null
          last_failed_at: string | null
          last_run: string | null
          model: string
          name: string
          reports_to: string | null
          role: string
          sort_order: number
          status: Database["public"]["Enums"]["agent_status"]
          title: string
          tokens_today: number
          updated_at: string
        }
        Insert: {
          attire: string
          avatar_url: string
          base_system_prompt: string
          cost_today_usd?: number
          created_at?: string
          current_task?: string | null
          daily_budget_usd?: number
          enabled?: boolean
          failure_flag?: boolean
          id?: string
          last_error_message?: string | null
          last_failed_at?: string | null
          last_run?: string | null
          model: string
          name: string
          reports_to?: string | null
          role: string
          sort_order?: number
          status?: Database["public"]["Enums"]["agent_status"]
          title: string
          tokens_today?: number
          updated_at?: string
        }
        Update: {
          attire?: string
          avatar_url?: string
          base_system_prompt?: string
          cost_today_usd?: number
          created_at?: string
          current_task?: string | null
          daily_budget_usd?: number
          enabled?: boolean
          failure_flag?: boolean
          id?: string
          last_error_message?: string | null
          last_failed_at?: string | null
          last_run?: string | null
          model?: string
          name?: string
          reports_to?: string | null
          role?: string
          sort_order?: number
          status?: Database["public"]["Enums"]["agent_status"]
          title?: string
          tokens_today?: number
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "agents_reports_to_fkey"
            columns: ["reports_to"]
            isOneToOne: false
            referencedRelation: "agents"
            referencedColumns: ["id"]
          },
        ]
      }
      app_secrets: {
        Row: {
          created_at: string
          encrypted_value: string
          id: string
          key_name: string
          last_test_status: string | null
          last_tested_at: string | null
          masked_preview: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          encrypted_value: string
          id?: string
          key_name: string
          last_test_status?: string | null
          last_tested_at?: string | null
          masked_preview: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          encrypted_value?: string
          id?: string
          key_name?: string
          last_test_status?: string | null
          last_tested_at?: string | null
          masked_preview?: string
          updated_at?: string
        }
        Relationships: []
      }
      budget_alerts: {
        Row: {
          agent_id: string
          agent_job_id: string | null
          budget_limit: number
          cost_at_pause: number
          created_at: string
          decision: string
          id: string
          project_id: string | null
          prompt_cycle_id: string | null
          reason: string
          resolved: boolean
        }
        Insert: {
          agent_id: string
          agent_job_id?: string | null
          budget_limit: number
          cost_at_pause: number
          created_at?: string
          decision?: string
          id?: string
          project_id?: string | null
          prompt_cycle_id?: string | null
          reason: string
          resolved?: boolean
        }
        Update: {
          agent_id?: string
          agent_job_id?: string | null
          budget_limit?: number
          cost_at_pause?: number
          created_at?: string
          decision?: string
          id?: string
          project_id?: string | null
          prompt_cycle_id?: string | null
          reason?: string
          resolved?: boolean
        }
        Relationships: [
          {
            foreignKeyName: "budget_alerts_agent_id_fkey"
            columns: ["agent_id"]
            isOneToOne: false
            referencedRelation: "agents"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "budget_alerts_agent_job_id_fkey"
            columns: ["agent_job_id"]
            isOneToOne: false
            referencedRelation: "agent_jobs"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "budget_alerts_project_id_fkey"
            columns: ["project_id"]
            isOneToOne: false
            referencedRelation: "projects"
            referencedColumns: ["id"]
          },
        ]
      }
      content_drafts: {
        Row: {
          agent_id: string | null
          category: string
          content_md: string
          created_at: string
          id: string
          project_id: string
          title: string
        }
        Insert: {
          agent_id?: string | null
          category: string
          content_md: string
          created_at?: string
          id?: string
          project_id: string
          title: string
        }
        Update: {
          agent_id?: string | null
          category?: string
          content_md?: string
          created_at?: string
          id?: string
          project_id?: string
          title?: string
        }
        Relationships: [
          {
            foreignKeyName: "content_drafts_agent_id_fkey"
            columns: ["agent_id"]
            isOneToOne: false
            referencedRelation: "agents"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "content_drafts_project_id_fkey"
            columns: ["project_id"]
            isOneToOne: false
            referencedRelation: "projects"
            referencedColumns: ["id"]
          },
        ]
      }
      daily_summaries: {
        Row: {
          created_at: string
          id: string
          notes: string | null
          project_id: string | null
          prompts_produced: number
          summary_date: string
          total_cost_usd: number
          total_tokens: number
        }
        Insert: {
          created_at?: string
          id?: string
          notes?: string | null
          project_id?: string | null
          prompts_produced?: number
          summary_date?: string
          total_cost_usd?: number
          total_tokens?: number
        }
        Update: {
          created_at?: string
          id?: string
          notes?: string | null
          project_id?: string | null
          prompts_produced?: number
          summary_date?: string
          total_cost_usd?: number
          total_tokens?: number
        }
        Relationships: [
          {
            foreignKeyName: "daily_summaries_project_id_fkey"
            columns: ["project_id"]
            isOneToOne: false
            referencedRelation: "projects"
            referencedColumns: ["id"]
          },
        ]
      }
      errors: {
        Row: {
          agent_id: string | null
          agent_job_id: string | null
          created_at: string
          error_message: string
          error_type: string | null
          function_name: string
          id: string
          project_id: string | null
          prompt_context: Json
          stack_trace: string | null
        }
        Insert: {
          agent_id?: string | null
          agent_job_id?: string | null
          created_at?: string
          error_message: string
          error_type?: string | null
          function_name: string
          id?: string
          project_id?: string | null
          prompt_context?: Json
          stack_trace?: string | null
        }
        Update: {
          agent_id?: string | null
          agent_job_id?: string | null
          created_at?: string
          error_message?: string
          error_type?: string | null
          function_name?: string
          id?: string
          project_id?: string | null
          prompt_context?: Json
          stack_trace?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "errors_agent_id_fkey"
            columns: ["agent_id"]
            isOneToOne: false
            referencedRelation: "agents"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "errors_agent_job_id_fkey"
            columns: ["agent_job_id"]
            isOneToOne: false
            referencedRelation: "agent_jobs"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "errors_project_id_fkey"
            columns: ["project_id"]
            isOneToOne: false
            referencedRelation: "projects"
            referencedColumns: ["id"]
          },
        ]
      }
      lovable_prompts: {
        Row: {
          content_md: string
          created_at: string
          created_by_agent_id: string | null
          delivered_at: string | null
          dependencies: Json
          id: string
          notes: string | null
          project_id: string
          sequence_number: number
          status: Database["public"]["Enums"]["prompt_status"]
          title: string
          updated_at: string
        }
        Insert: {
          content_md: string
          created_at?: string
          created_by_agent_id?: string | null
          delivered_at?: string | null
          dependencies?: Json
          id?: string
          notes?: string | null
          project_id: string
          sequence_number: number
          status?: Database["public"]["Enums"]["prompt_status"]
          title: string
          updated_at?: string
        }
        Update: {
          content_md?: string
          created_at?: string
          created_by_agent_id?: string | null
          delivered_at?: string | null
          dependencies?: Json
          id?: string
          notes?: string | null
          project_id?: string
          sequence_number?: number
          status?: Database["public"]["Enums"]["prompt_status"]
          title?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "lovable_prompts_created_by_agent_id_fkey"
            columns: ["created_by_agent_id"]
            isOneToOne: false
            referencedRelation: "agents"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "lovable_prompts_project_id_fkey"
            columns: ["project_id"]
            isOneToOne: false
            referencedRelation: "projects"
            referencedColumns: ["id"]
          },
        ]
      }
      profiles: {
        Row: {
          created_at: string
          display_name: string | null
          email: string | null
          id: string
          updated_at: string
          user_id: string
        }
        Insert: {
          created_at?: string
          display_name?: string | null
          email?: string | null
          id?: string
          updated_at?: string
          user_id: string
        }
        Update: {
          created_at?: string
          display_name?: string | null
          email?: string | null
          id?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      projects: {
        Row: {
          created_at: string
          description: string | null
          existing_site_url: string | null
          id: string
          intake_notes: string | null
          mode: Database["public"]["Enums"]["project_mode"]
          name: string
          owner_id: string
          reference_urls: Json
          slug: string
          status: Database["public"]["Enums"]["project_status"]
          tech_stack_target: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          description?: string | null
          existing_site_url?: string | null
          id?: string
          intake_notes?: string | null
          mode?: Database["public"]["Enums"]["project_mode"]
          name: string
          owner_id: string
          reference_urls?: Json
          slug: string
          status?: Database["public"]["Enums"]["project_status"]
          tech_stack_target?: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          description?: string | null
          existing_site_url?: string | null
          id?: string
          intake_notes?: string | null
          mode?: Database["public"]["Enums"]["project_mode"]
          name?: string
          owner_id?: string
          reference_urls?: Json
          slug?: string
          status?: Database["public"]["Enums"]["project_status"]
          tech_stack_target?: string
          updated_at?: string
        }
        Relationships: []
      }
      qa_reports: {
        Row: {
          agent_id: string | null
          created_at: string
          findings_md: string
          id: string
          project_id: string
          prompt_cycle_id: string | null
          revision_notes: string | null
          revision_round: number
          revision_targets: string[]
          target_id: string | null
          target_type: string
          verdict: string
        }
        Insert: {
          agent_id?: string | null
          created_at?: string
          findings_md: string
          id?: string
          project_id: string
          prompt_cycle_id?: string | null
          revision_notes?: string | null
          revision_round?: number
          revision_targets?: string[]
          target_id?: string | null
          target_type: string
          verdict: string
        }
        Update: {
          agent_id?: string | null
          created_at?: string
          findings_md?: string
          id?: string
          project_id?: string
          prompt_cycle_id?: string | null
          revision_notes?: string | null
          revision_round?: number
          revision_targets?: string[]
          target_id?: string | null
          target_type?: string
          verdict?: string
        }
        Relationships: [
          {
            foreignKeyName: "qa_reports_agent_id_fkey"
            columns: ["agent_id"]
            isOneToOne: false
            referencedRelation: "agents"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "qa_reports_project_id_fkey"
            columns: ["project_id"]
            isOneToOne: false
            referencedRelation: "projects"
            referencedColumns: ["id"]
          },
        ]
      }
      research_findings: {
        Row: {
          agent_id: string | null
          category: string
          content_md: string
          created_at: string
          id: string
          project_id: string
          source_url: string | null
          title: string
        }
        Insert: {
          agent_id?: string | null
          category: string
          content_md: string
          created_at?: string
          id?: string
          project_id: string
          source_url?: string | null
          title: string
        }
        Update: {
          agent_id?: string | null
          category?: string
          content_md?: string
          created_at?: string
          id?: string
          project_id?: string
          source_url?: string | null
          title?: string
        }
        Relationships: [
          {
            foreignKeyName: "research_findings_agent_id_fkey"
            columns: ["agent_id"]
            isOneToOne: false
            referencedRelation: "agents"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "research_findings_project_id_fkey"
            columns: ["project_id"]
            isOneToOne: false
            referencedRelation: "projects"
            referencedColumns: ["id"]
          },
        ]
      }
      user_roles: {
        Row: {
          created_at: string
          id: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          role?: Database["public"]["Enums"]["app_role"]
          user_id?: string
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      has_role: {
        Args: {
          _role: Database["public"]["Enums"]["app_role"]
          _user_id: string
        }
        Returns: boolean
      }
      is_admin_or_owner: { Args: never; Returns: boolean }
      is_owner: { Args: never; Returns: boolean }
    }
    Enums: {
      agent_job_status:
        | "queued"
        | "running"
        | "completed"
        | "failed"
        | "timeout"
      agent_job_trigger_source:
        | "manual"
        | "chain_handoff"
        | "retry"
        | "watchdog_recovery"
      agent_status:
        | "sleeping"
        | "working"
        | "standby"
        | "off"
        | "budget_paused"
        | "paused"
        | "waiting"
      app_role: "owner" | "admin" | "user"
      project_mode:
        | "build_new"
        | "fix_existing"
        | "research_only"
        | "full_stack_service"
      project_status: "active" | "paused" | "complete" | "archived"
      prompt_status: "draft" | "ready" | "delivered" | "implemented"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      agent_job_status: ["queued", "running", "completed", "failed", "timeout"],
      agent_job_trigger_source: [
        "manual",
        "chain_handoff",
        "retry",
        "watchdog_recovery",
      ],
      agent_status: [
        "sleeping",
        "working",
        "standby",
        "off",
        "budget_paused",
        "paused",
        "waiting",
      ],
      app_role: ["owner", "admin", "user"],
      project_mode: [
        "build_new",
        "fix_existing",
        "research_only",
        "full_stack_service",
      ],
      project_status: ["active", "paused", "complete", "archived"],
      prompt_status: ["draft", "ready", "delivered", "implemented"],
    },
  },
} as const
