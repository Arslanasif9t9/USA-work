# Expert Intuitive Advisor — Lovable Port

Ported from a Replit (Vite + React + TypeScript + Tailwind + shadcn/ui + wouter) project. Cleaned for direct GitHub → Lovable import.

## What changed from the Replit version

- `client/src/` → `src/` (Lovable's expected layout)
- `client/public/` → `public/`
- `client/index.html` → `index.html` (root)
- Removed: `server/`, `shared/`, `script/`, `drizzle.config.ts` (all unused on the frontend)
- Removed: Replit-specific Vite plugins, Express, Drizzle, Passport, Neon DB deps
- `vite.config.ts` simplified
- `tsconfig.json` paths point to `src/`
- `components.json` css path updated to `src/index.css`

## Local dev

```
npm install
npm run dev
```

## Deploy via Lovable

1. Push this repo to GitHub.
2. In Lovable: New Project → connect to this GitHub repo.
3. Lovable will mount the existing code without burning AI credits.
4. Connect domain in Lovable settings, then update Namecheap DNS.

## Routes

All defined in `src/App.tsx` via wouter:
- `/` Home
- `/about`
- `/services`
- `/digital-ai-advisory`
- `/leadership-coaching`
- `/case-studies`
- `/insights` and `/insights/:slug`
- `/resources`
- `/careers`
- `/contact`
