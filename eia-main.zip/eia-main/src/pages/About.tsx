import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import CTASection from "@/components/CTASection";
import { Card, CardContent } from "@/components/ui/card";
import { Brain, TrendingUp, Target, Eye, Award, Users, Globe, Zap } from "lucide-react";
import aboutImage from "@assets/stock_images/executive_business_p_5531f6d8.jpg";
import teamImage from "@assets/stock_images/modern_office_busine_413aba0c.jpg";

const capabilities = [
  {
    icon: Brain,
    title: "Rapid Pattern Recognition",
    description: "Identifying market signals and strategic opportunities before they become obvious to competitors.",
  },
  {
    icon: TrendingUp,
    title: "High-Level Strategic Instincts",
    description: "Leveraging decades of cross-industry experience for decisive guidance in complex situations.",
  },
  {
    icon: Target,
    title: "Decision Intelligence",
    description: "Advanced frameworks and methodologies that transform complexity into clarity.",
  },
  {
    icon: Eye,
    title: "Executive Foresight",
    description: "Anticipating market shifts and positioning organizations for sustained success.",
  },
];

const values = [
  {
    icon: Award,
    title: "Excellence",
    description: "Uncompromising standards in everything we deliver.",
  },
  {
    icon: Users,
    title: "Partnership",
    description: "Deep collaboration with clients as trusted advisors.",
  },
  {
    icon: Globe,
    title: "Global Perspective",
    description: "Cross-industry insights with worldwide applicability.",
  },
  {
    icon: Zap,
    title: "Impact",
    description: "Measurable outcomes that transform organizations.",
  },
];

export default function About() {
  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <main>
        <section className="relative pt-32 pb-20 lg:pt-40 lg:pb-28 bg-primary">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <h1 className="text-4xl lg:text-5xl font-bold text-primary-foreground mb-6">
              About Us
            </h1>
            <p className="text-xl text-primary-foreground/80 max-w-3xl mx-auto">
              A U.S.-based corporate consulting firm providing strategic clarity 
              and decision support for the world's most complex challenges.
            </p>
          </div>
        </section>

        <section className="py-20 lg:py-28 bg-background">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid lg:grid-cols-2 gap-12 lg:gap-16 items-center">
              <div>
                <p className="text-sm font-medium text-primary uppercase tracking-wider mb-3">
                  Our Approach
                </p>
                <h2 className="text-3xl lg:text-4xl font-bold text-foreground mb-6">
                  Intuitive Advisory Defined
                </h2>
                <p className="text-lg text-muted-foreground mb-6 leading-relaxed">
                  Our Intuitive Advisory methodology represents a distinctive approach 
                  to strategic consulting. It combines rigorous analytical frameworks 
                  with the pattern recognition capabilities developed through decades 
                  of cross-industry leadership experience.
                </p>
                <p className="text-lg text-muted-foreground mb-8 leading-relaxed">
                  This approach enables us to see beyond surface-level data and identify 
                  the underlying dynamics that will shape future market conditions. We 
                  help leaders make decisions with confidence, even in the face of 
                  unprecedented uncertainty.
                </p>
              </div>
              <div className="relative">
                <div className="aspect-[4/3] rounded-md overflow-hidden">
                  <img
                    src={aboutImage}
                    alt="Executive leadership presentation"
                    className="w-full h-full object-cover"
                  />
                </div>
              </div>
            </div>
          </div>
        </section>

        <section className="py-20 lg:py-28 bg-card">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-16">
              <p className="text-sm font-medium text-primary uppercase tracking-wider mb-3">
                Our Methodology
              </p>
              <h2 className="text-3xl lg:text-4xl font-bold text-foreground mb-4">
                Four Pillars of Strategic Intelligence
              </h2>
            </div>
            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
              {capabilities.map((capability) => (
                <Card key={capability.title} className="border border-border text-center">
                  <CardContent className="p-6">
                    <div className="w-14 h-14 rounded-md bg-primary/10 flex items-center justify-center mx-auto mb-5">
                      <capability.icon className="h-7 w-7 text-primary" />
                    </div>
                    <h3 className="text-lg font-semibold text-foreground mb-3">
                      {capability.title}
                    </h3>
                    <p className="text-sm text-muted-foreground leading-relaxed">
                      {capability.description}
                    </p>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </section>

        <section className="py-20 lg:py-28 bg-background">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid lg:grid-cols-2 gap-12 lg:gap-16 items-center">
              <div className="order-2 lg:order-1">
                <div className="aspect-[4/3] rounded-md overflow-hidden">
                  <img
                    src={teamImage}
                    alt="Expert Intuitive Advisor Inc team collaboration"
                    className="w-full h-full object-cover"
                  />
                </div>
              </div>
              <div className="order-1 lg:order-2">
                <p className="text-sm font-medium text-primary uppercase tracking-wider mb-3">
                  Our Values
                </p>
                <h2 className="text-3xl lg:text-4xl font-bold text-foreground mb-8">
                  What Drives Us
                </h2>
                <div className="space-y-6">
                  {values.map((value) => (
                    <div key={value.title} className="flex gap-4">
                      <div className="flex-shrink-0 w-12 h-12 rounded-md bg-primary/10 flex items-center justify-center">
                        <value.icon className="h-6 w-6 text-primary" />
                      </div>
                      <div>
                        <h3 className="font-semibold text-foreground mb-1">
                          {value.title}
                        </h3>
                        <p className="text-muted-foreground">
                          {value.description}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </section>

        <CTASection />
      </main>
      <Footer />
    </div>
  );
}
