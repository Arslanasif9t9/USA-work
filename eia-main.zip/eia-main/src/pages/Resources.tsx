import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import CTASection from "@/components/CTASection";
import { Card, CardContent } from "@/components/ui/card";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import {
  FileText,
  CheckSquare,
  HelpCircle,
  Clock,
  ArrowRight,
  Download,
} from "lucide-react";

const clientResources = [
  {
    icon: FileText,
    title: "Engagement Overview (PDF)",
    description: "What to expect when working with Expert Intuitive Advisor Inc.",
  },
  {
    icon: CheckSquare,
    title: "Strategy Session Checklist",
    description: "How to prepare for a high-impact working session.",
  },
];

const candidateResources = [
  {
    icon: HelpCircle,
    title: "Careers FAQ",
    description:
      "How we recruit, interview steps, and expectations for candidates.",
    link: "/careers",
  },
  {
    icon: Clock,
    title: "Remote Work Expectations",
    description:
      "Working hours, communication norms, and performance standards for our distributed team.",
    link: "/careers",
  },
];

export default function Resources() {
  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <main>
        <section className="relative pt-32 pb-20 lg:pt-40 lg:pb-28 bg-primary">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <h1
              className="text-4xl lg:text-5xl font-bold text-primary-foreground mb-6"
              data-testid="page-title"
            >
              Resources
            </h1>
            <p className="text-xl text-primary-foreground/80 max-w-3xl mx-auto">
              Tools and reference material for clients, candidates, and
              partners.
            </p>
          </div>
        </section>

        <section className="py-20 lg:py-28 bg-background">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="mb-16">
              <h2 className="text-2xl lg:text-3xl font-bold text-foreground mb-8">
                For clients
              </h2>
              <div className="grid md:grid-cols-2 gap-6">
                {clientResources.map((resource, index) => (
                  <Card
                    key={resource.title}
                    className="border border-border"
                    data-testid={`client-resource-${index}`}
                  >
                    <CardContent className="p-6">
                      <div className="flex items-start gap-4">
                        <div className="flex-shrink-0 w-12 h-12 rounded-md bg-primary/10 flex items-center justify-center">
                          <resource.icon className="h-6 w-6 text-primary" />
                        </div>
                        <div className="flex-1">
                          <h3 className="text-lg font-semibold text-foreground mb-2">
                            {resource.title}
                          </h3>
                          <p className="text-muted-foreground text-sm mb-4">
                            {resource.description}
                          </p>
                          <Button variant="outline" size="sm" disabled>
                            <Download className="mr-2 h-4 w-4" />
                            Coming soon
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>

            <div className="mb-16">
              <h2 className="text-2xl lg:text-3xl font-bold text-foreground mb-8">
                For candidates
              </h2>
              <div className="grid md:grid-cols-2 gap-6">
                {candidateResources.map((resource, index) => (
                  <Link key={resource.title} href={resource.link}>
                    <Card
                      className="border border-border hover-elevate cursor-pointer h-full"
                      data-testid={`candidate-resource-${index}`}
                    >
                      <CardContent className="p-6">
                        <div className="flex items-start gap-4">
                          <div className="flex-shrink-0 w-12 h-12 rounded-md bg-primary/10 flex items-center justify-center">
                            <resource.icon className="h-6 w-6 text-primary" />
                          </div>
                          <div className="flex-1">
                            <h3 className="text-lg font-semibold text-foreground mb-2">
                              {resource.title}
                            </h3>
                            <p className="text-muted-foreground text-sm mb-4">
                              {resource.description}
                            </p>
                            <span className="inline-flex items-center text-primary font-medium text-sm">
                              Learn more
                              <ArrowRight className="ml-2 h-4 w-4" />
                            </span>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  </Link>
                ))}
              </div>
            </div>

            <div className="bg-muted/30 rounded-lg p-8">
              <h2 className="text-2xl font-bold text-foreground mb-4">
                Contact & Support
              </h2>
              <p className="text-muted-foreground mb-6">
                For project enquiries, partnerships, or media, please contact us
                through the Contact page.
              </p>
              <Link href="/contact">
                <Button data-testid="contact-button">
                  Contact Us
                  <ArrowRight className="ml-2 h-4 w-4" />
                </Button>
              </Link>
            </div>
          </div>
        </section>

        <CTASection />
      </main>
      <Footer />
    </div>
  );
}
