import Navbar from "@/components/Navbar";
import HeroSection from "@/components/HeroSection";
import AboutSection from "@/components/AboutSection";
import ServicesSection from "@/components/ServicesSection";
import CaseStudiesSection from "@/components/CaseStudiesSection";
import HowWeHelpSection from "@/components/HowWeHelpSection";
import CommitmentSection from "@/components/CommitmentSection";
import CTASection from "@/components/CTASection";
import Footer from "@/components/Footer";

export default function Home() {
  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <main>
        <HeroSection />
        <AboutSection />
        <HowWeHelpSection />
        <ServicesSection />
        <CaseStudiesSection />
        <CommitmentSection />
        <CTASection />
      </main>
      <Footer />
    </div>
  );
}
