import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import CTASection from "@/components/CTASection";
import { Link, useParams } from "wouter";
import { Button } from "@/components/ui/button";
import { ArrowLeft, ArrowRight } from "lucide-react";

const articles: Record<
  string,
  { title: string; content: string[] }
> = {
  "making-decisions-when-the-data-is-noisy": {
    title: "Making Decisions When the Data Is Noisy",
    content: [
      "In an ideal world, leaders would have access to complete, reliable information before making important decisions. In reality, data is often incomplete, contradictory, or arrives too late to be useful. The most effective leaders have learned to navigate this uncertainty by combining analytical rigor with structured intuition.",
      "The first step is recognizing when data quality is a limiting factor. Not all decisions require the same level of precision. For reversible choices with limited downside, moving quickly with imperfect information often beats waiting for certainty that may never come. For high-stakes, irreversible decisions, investing more time in validation and triangulation makes sense.",
      "Structured intuition means drawing on pattern recognition and experience in a deliberate way. Rather than simply 'going with your gut,' effective leaders articulate the assumptions underlying their instincts and test them against available evidence. This creates a feedback loop that improves judgment over time.",
      "When facing conflicting data, consider the source and incentives behind each data point. Look for convergent evidence from independent sources. And remember that the absence of data is itself information – it often signals areas where the organization lacks visibility or where the situation is genuinely novel.",
      "Finally, build decision processes that acknowledge uncertainty rather than pretending it doesn't exist. Scenario planning, pre-mortems, and explicit confidence intervals help teams make better choices in ambiguous conditions. The goal is not to eliminate uncertainty, but to make robust decisions despite it.",
    ],
  },
  "designing-a-practical-digital-roadmap": {
    title: "Designing a Practical Digital Roadmap",
    content: [
      "Many organizations struggle with digital transformation not because they lack ambition, but because they try to do too much at once. A practical digital roadmap focuses on the few initiatives that will create the most visible business value, rather than attempting comprehensive change across all fronts simultaneously.",
      "Start by identifying the specific business problems you're trying to solve. Digital transformation is a means to an end, not an end in itself. The most successful initiatives begin with a clear understanding of customer pain points, operational bottlenecks, or competitive disadvantages that technology can address.",
      "Prioritise ruthlessly. Most organizations have more digital opportunities than they have capacity to execute. Use a simple framework that weighs business impact against implementation complexity. Focus first on initiatives that offer high impact with manageable complexity – these quick wins build momentum and organizational confidence.",
      "Design for learning, not just delivery. The best roadmaps include explicit checkpoints where teams can assess what's working and adjust course. Build in time for pilots and proof-of-concepts before committing to full-scale rollout. Accept that some initiatives will fail, and create mechanisms to capture and share those lessons.",
      "Finally, remember that technology is the easy part. The harder work involves changing processes, developing new capabilities, and shifting organizational culture. Allocate time and resources for change management, training, and the organizational work that makes digital initiatives stick.",
    ],
  },
  "leading-remote-distributed-teams": {
    title: "Leading Remote and Distributed Teams",
    content: [
      "The shift to remote and distributed work has fundamentally changed how leaders need to operate. The informal interactions and visual cues that once made coordination easy are no longer available. Successful remote leadership requires intentional practices that replace what used to happen naturally.",
      "Alignment becomes more important than ever. When team members can't overhear conversations or pick up context from the office environment, leaders must be more explicit about goals, priorities, and expectations. Regular, structured communication rhythms help ensure everyone stays on the same page.",
      "Accountability in remote settings requires clearer metrics and more frequent check-ins. This doesn't mean micromanagement – it means creating visibility into work progress so that issues surface early and support can be provided when needed. The best remote leaders focus on outcomes rather than activity, trusting their teams to manage their own time while holding them responsible for results.",
      "Culture doesn't happen by accident in distributed teams. Leaders need to create deliberate opportunities for connection, recognition, and shared experience. This might include virtual social events, regular one-on-ones focused on personal as well as professional topics, and explicit attention to onboarding new team members into the team's norms and relationships.",
      "Finally, recognize that remote work affects different people differently. Some thrive with the autonomy and flexibility; others struggle with isolation or difficulty separating work from home life. Effective remote leaders check in regularly on wellbeing and adapt their approach to individual needs rather than applying a one-size-fits-all management style.",
    ],
  },
};

export default function InsightArticle() {
  const params = useParams<{ slug: string }>();
  const slug = params.slug || "";
  const article = articles[slug];

  if (!article) {
    return (
      <div className="min-h-screen bg-background">
        <Navbar />
        <main className="pt-32 pb-20">
          <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <h1 className="text-2xl font-bold text-foreground mb-4">
              Article not found
            </h1>
            <Link href="/insights">
              <Button variant="outline">
                <ArrowLeft className="mr-2 h-4 w-4" />
                Back to Insights
              </Button>
            </Link>
          </div>
        </main>
        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <main>
        <section className="relative pt-32 pb-12 lg:pt-40 lg:pb-16 bg-primary">
          <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
            <Link href="/insights">
              <span className="inline-flex items-center text-primary-foreground/80 hover:text-primary-foreground mb-6 cursor-pointer">
                <ArrowLeft className="mr-2 h-4 w-4" />
                Back to Insights
              </span>
            </Link>
            <h1
              className="text-3xl lg:text-4xl font-bold text-primary-foreground"
              data-testid="article-title"
            >
              {article.title}
            </h1>
          </div>
        </section>

        <section className="py-12 lg:py-16 bg-background">
          <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
            <article className="prose prose-lg max-w-none">
              {article.content.map((paragraph, index) => (
                <p
                  key={index}
                  className="text-muted-foreground leading-relaxed mb-6"
                  data-testid={`paragraph-${index}`}
                >
                  {paragraph}
                </p>
              ))}
            </article>

            <div className="mt-12 pt-8 border-t border-border">
              <Link href="/contact">
                <Button size="lg" data-testid="cta-button">
                  Discuss Your Challenges
                  <ArrowRight className="ml-2 h-5 w-5" />
                </Button>
              </Link>
            </div>
          </div>
        </section>

        <CTASection />
      </main>
      <Footer />
    </div>
  );
}
