import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import CTASection from "@/components/CTASection";
import { Card, CardContent } from "@/components/ui/card";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import {
  Users,
  Target,
  Brain,
  MessageSquare,
  Clock,
  Zap,
  UsersRound,
  CheckCircle,
  ArrowRight,
} from "lucide-react";

const whoWeCoach = [
  "Founders and owner-CEOs",
  "Senior executives in high-growth or transforming businesses",
  "Emerging leaders taking on expanded responsibilities",
];

const approach = [
  {
    icon: Target,
    title: "Strategic clarity",
    description:
      "Framing decisions, trade-offs, and timing so leaders move from uncertainty to action.",
  },
  {
    icon: Brain,
    title: "Decision discipline",
    description:
      "Building personal routines for prioritisation, focus, and follow-through.",
  },
  {
    icon: MessageSquare,
    title: "Leadership presence",
    description:
      "Strengthening how leaders communicate with boards, teams, and key stakeholders.",
  },
];

const formats = [
  {
    icon: Users,
    title: "Executive 1:1 Coaching",
    description:
      "Structured weekly or bi-weekly sessions (60–90 minutes).",
  },
  {
    icon: Zap,
    title: "Decision Sprints",
    description:
      "Short, intensive coaching around a specific strategic decision or transition.",
  },
  {
    icon: UsersRound,
    title: "Leadership Circles",
    description: "Small group sessions for leadership teams.",
  },
];

const gains = [
  "Clearer decision-making under pressure",
  "Stronger alignment between strategy, time, and energy",
  "Reduced noise, increased focus on high-value work",
];

export default function LeadershipCoaching() {
  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <main>
        <section className="relative pt-32 pb-20 lg:pt-40 lg:pb-28 bg-primary">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <h1
              className="text-4xl lg:text-5xl font-bold text-primary-foreground mb-6"
              data-testid="page-title"
            >
              Leadership Coaching
            </h1>
            <p className="text-xl text-primary-foreground/80 max-w-3xl mx-auto">
              One-to-one support for leaders navigating complexity, growth, and
              constant change.
            </p>
          </div>
        </section>

        <section className="py-20 lg:py-28 bg-background">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="max-w-3xl mb-16">
              <p className="text-lg text-muted-foreground leading-relaxed">
                We coach founders and senior leaders who need a trusted thinking
                partner – someone outside the organization who brings structured
                analysis, pattern recognition, and clear challenge.
              </p>
            </div>

            <div className="mb-20">
              <h2 className="text-2xl lg:text-3xl font-bold text-foreground mb-8">
                Who we coach
              </h2>
              <ul className="space-y-4">
                {whoWeCoach.map((item, index) => (
                  <li
                    key={index}
                    className="flex items-start gap-3"
                    data-testid={`who-we-coach-${index}`}
                  >
                    <Users className="h-5 w-5 text-primary flex-shrink-0 mt-0.5" />
                    <span className="text-lg text-foreground">{item}</span>
                  </li>
                ))}
              </ul>
            </div>

            <div className="mb-20">
              <h2 className="text-2xl lg:text-3xl font-bold text-foreground mb-8">
                Our approach
              </h2>
              <div className="grid md:grid-cols-3 gap-8">
                {approach.map((item, index) => (
                  <Card
                    key={item.title}
                    className="border border-border"
                    data-testid={`approach-${index}`}
                  >
                    <CardContent className="p-6">
                      <div className="w-12 h-12 rounded-md bg-primary/10 flex items-center justify-center mb-4">
                        <item.icon className="h-6 w-6 text-primary" />
                      </div>
                      <h3 className="text-lg font-bold text-foreground mb-3">
                        {item.title}
                      </h3>
                      <p className="text-sm text-muted-foreground leading-relaxed">
                        {item.description}
                      </p>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>

            <div className="mb-20">
              <h2 className="text-2xl lg:text-3xl font-bold text-foreground mb-8">
                Coaching formats
              </h2>
              <div className="grid md:grid-cols-3 gap-8">
                {formats.map((item, index) => (
                  <div
                    key={item.title}
                    className="flex items-start gap-4"
                    data-testid={`format-${index}`}
                  >
                    <div className="flex-shrink-0 w-12 h-12 rounded-md bg-primary/10 flex items-center justify-center">
                      <item.icon className="h-6 w-6 text-primary" />
                    </div>
                    <div>
                      <h3 className="text-lg font-bold text-foreground mb-2">
                        {item.title}
                      </h3>
                      <p className="text-sm text-muted-foreground">
                        {item.description}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div>
              <h2 className="text-2xl lg:text-3xl font-bold text-foreground mb-8">
                What clients gain
              </h2>
              <div className="grid md:grid-cols-3 gap-6">
                {gains.map((gain, index) => (
                  <div
                    key={index}
                    className="flex items-start gap-3 p-4 bg-muted/30 rounded-lg"
                    data-testid={`gain-${index}`}
                  >
                    <CheckCircle className="h-5 w-5 text-primary flex-shrink-0 mt-0.5" />
                    <span className="text-foreground">{gain}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </section>

        <section className="py-16 bg-muted/30">
          <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <h2 className="text-2xl lg:text-3xl font-bold text-foreground mb-4">
              Ready to strengthen your leadership?
            </h2>
            <p className="text-muted-foreground mb-8">
              Let's discuss how coaching can support your growth and
              effectiveness.
            </p>
            <Link href="/contact">
              <Button size="lg" data-testid="cta-button">
                Start a Conversation
                <ArrowRight className="ml-2 h-5 w-5" />
              </Button>
            </Link>
          </div>
        </section>

        <CTASection />
      </main>
      <Footer />
    </div>
  );
}
