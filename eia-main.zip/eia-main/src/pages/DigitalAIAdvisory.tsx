import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import CTASection from "@/components/CTASection";
import { Card, CardContent } from "@/components/ui/card";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import {
  Compass,
  Brain,
  BarChart3,
  Settings,
  Search,
  Map,
  Rocket,
  CheckCircle,
  ArrowRight,
} from "lucide-react";

const whatWeDo = [
  {
    icon: Compass,
    title: "Digital Strategy",
    description:
      "Clarifying where digital can create value across your organization, from customer journeys to internal operations.",
  },
  {
    icon: Brain,
    title: "AI Use-Case Design",
    description:
      "Identifying practical AI applications that augment human decision making instead of replacing it.",
  },
  {
    icon: BarChart3,
    title: "Data & Analytics",
    description:
      "Structuring the data, dashboards, and KPIs leaders need for real-time decisions.",
  },
  {
    icon: Settings,
    title: "Operating Model & Change",
    description:
      "Aligning roles, processes, and governance so digital initiatives actually stick.",
  },
];

const howWeWork = [
  {
    step: "01",
    title: "Diagnose",
    description:
      "Rapid assessment of current digital capabilities, constraints, and opportunities.",
  },
  {
    step: "02",
    title: "Design",
    description:
      "Prioritised roadmap with 3–5 high-impact initiatives and clear success metrics.",
  },
  {
    step: "03",
    title: "Deliver",
    description:
      "Hands-on support to launch pilots, refine, and scale what works.",
  },
];

const engagements = [
  "Modernising decision dashboards for a global services firm",
  "Designing AI-assisted workflows for a founder-led startup",
  "Building a lean digital roadmap for a remote, multi-country team",
];

const outcomes = [
  "Faster, clearer executive decisions",
  "Reduced operational friction and manual work",
  "Better visibility on risk, performance, and growth opportunities",
];

export default function DigitalAIAdvisory() {
  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <main>
        <section className="relative pt-32 pb-20 lg:pt-40 lg:pb-28 bg-primary">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <h1
              className="text-4xl lg:text-5xl font-bold text-primary-foreground mb-6"
              data-testid="page-title"
            >
              Digital & AI Advisory
            </h1>
            <p className="text-xl text-primary-foreground/80 max-w-3xl mx-auto">
              Transform intuition into measurable outcomes with pragmatic
              digital and AI strategies.
            </p>
          </div>
        </section>

        <section className="py-20 lg:py-28 bg-background">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="max-w-3xl mb-16">
              <p className="text-lg text-muted-foreground leading-relaxed">
                We help founders and decision makers turn data, experience, and
                intuition into clear digital roadmaps. From automation to
                analytics, we focus on practical initiatives that create visible
                business value – not experimental technology projects.
              </p>
            </div>

            <div className="mb-20">
              <h2 className="text-2xl lg:text-3xl font-bold text-foreground mb-8">
                What we do
              </h2>
              <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
                {whatWeDo.map((item, index) => (
                  <Card
                    key={item.title}
                    className="border border-border"
                    data-testid={`what-we-do-${index}`}
                  >
                    <CardContent className="p-6">
                      <div className="w-12 h-12 rounded-md bg-primary/10 flex items-center justify-center mb-4">
                        <item.icon className="h-6 w-6 text-primary" />
                      </div>
                      <h3 className="text-lg font-bold text-foreground mb-3">
                        {item.title}
                      </h3>
                      <p className="text-sm text-muted-foreground leading-relaxed">
                        {item.description}
                      </p>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>

            <div className="mb-20">
              <h2 className="text-2xl lg:text-3xl font-bold text-foreground mb-8">
                How we work
              </h2>
              <div className="grid md:grid-cols-3 gap-8">
                {howWeWork.map((item, index) => (
                  <div key={item.title} data-testid={`how-we-work-${index}`}>
                    <div className="text-4xl font-bold text-primary/20 mb-2">
                      {item.step}
                    </div>
                    <h3 className="text-xl font-bold text-foreground mb-3">
                      {item.title}
                    </h3>
                    <p className="text-muted-foreground leading-relaxed">
                      {item.description}
                    </p>
                  </div>
                ))}
              </div>
            </div>

            <div className="grid lg:grid-cols-2 gap-12">
              <div>
                <h2 className="text-2xl lg:text-3xl font-bold text-foreground mb-6">
                  Typical engagements
                </h2>
                <ul className="space-y-4">
                  {engagements.map((engagement, index) => (
                    <li
                      key={index}
                      className="flex items-start gap-3"
                      data-testid={`engagement-${index}`}
                    >
                      <Search className="h-5 w-5 text-primary flex-shrink-0 mt-0.5" />
                      <span className="text-muted-foreground">{engagement}</span>
                    </li>
                  ))}
                </ul>
              </div>

              <div>
                <h2 className="text-2xl lg:text-3xl font-bold text-foreground mb-6">
                  Outcomes
                </h2>
                <ul className="space-y-4">
                  {outcomes.map((outcome, index) => (
                    <li
                      key={index}
                      className="flex items-start gap-3"
                      data-testid={`outcome-${index}`}
                    >
                      <CheckCircle className="h-5 w-5 text-primary flex-shrink-0 mt-0.5" />
                      <span className="text-muted-foreground">{outcome}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          </div>
        </section>

        <section className="py-16 bg-muted/30">
          <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <h2 className="text-2xl lg:text-3xl font-bold text-foreground mb-4">
              Ready to build your digital roadmap?
            </h2>
            <p className="text-muted-foreground mb-8">
              Let's discuss how digital and AI can create value for your
              organization.
            </p>
            <Link href="/contact">
              <Button size="lg" data-testid="cta-button">
                Start a Conversation
                <ArrowRight className="ml-2 h-5 w-5" />
              </Button>
            </Link>
          </div>
        </section>

        <CTASection />
      </main>
      <Footer />
    </div>
  );
}
