import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import CTASection from "@/components/CTASection";
import { Card, CardContent } from "@/components/ui/card";
import { Link } from "wouter";
import { ArrowRight, FileText } from "lucide-react";

const articles = [
  {
    id: 1,
    slug: "making-decisions-when-the-data-is-noisy",
    title: "Making Decisions When the Data Is Noisy",
    summary:
      "Why leaders should combine analytics, experience, and structured intuition when facing conflicting information.",
  },
  {
    id: 2,
    slug: "designing-a-practical-digital-roadmap",
    title: "Designing a Practical Digital Roadmap",
    summary:
      "How to avoid over-complex digital strategies and focus on the few moves that matter.",
  },
  {
    id: 3,
    slug: "leading-remote-distributed-teams",
    title: "Leading Remote and Distributed Teams",
    summary:
      "Principles for alignment, accountability, and culture when your team is everywhere.",
  },
];

export default function Insights() {
  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <main>
        <section className="relative pt-32 pb-20 lg:pt-40 lg:pb-28 bg-primary">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <h1
              className="text-4xl lg:text-5xl font-bold text-primary-foreground mb-6"
              data-testid="page-title"
            >
              Insights
            </h1>
            <p className="text-xl text-primary-foreground/80 max-w-3xl mx-auto">
              Perspectives on strategy, decision making, and leadership.
            </p>
          </div>
        </section>

        <section className="py-20 lg:py-28 bg-background">
          <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="max-w-3xl mb-12">
              <p className="text-lg text-muted-foreground leading-relaxed">
                We publish concise, practitioner-focused notes to help leaders
                navigate uncertainty and make better decisions.
              </p>
            </div>

            <div className="space-y-6">
              {articles.map((article, index) => (
                <Link
                  key={article.id}
                  href={`/insights/${article.slug}`}
                >
                  <Card
                    className="border border-border hover-elevate cursor-pointer transition-all"
                    data-testid={`article-${index}`}
                  >
                    <CardContent className="p-6">
                      <div className="flex items-start gap-4">
                        <div className="flex-shrink-0 w-10 h-10 rounded-md bg-primary/10 flex items-center justify-center">
                          <FileText className="h-5 w-5 text-primary" />
                        </div>
                        <div className="flex-1">
                          <h2 className="text-xl font-semibold text-foreground mb-2">
                            {article.title}
                          </h2>
                          <p className="text-muted-foreground mb-4">
                            {article.summary}
                          </p>
                          <span className="inline-flex items-center text-primary font-medium text-sm">
                            Read more
                            <ArrowRight className="ml-2 h-4 w-4" />
                          </span>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </Link>
              ))}
            </div>
          </div>
        </section>

        <CTASection />
      </main>
      <Footer />
    </div>
  );
}
