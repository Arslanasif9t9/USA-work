import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import CTASection from "@/components/CTASection";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import {
  TrendingUp,
  Cpu,
  Users,
  Megaphone,
  Lightbulb,
  Settings,
  CheckCircle,
  ArrowRight,
} from "lucide-react";

const capabilities = [
  {
    icon: TrendingUp,
    title: "Strategy & Corporate Finance",
    description:
      "We help clients develop and implement bold strategies by providing advice on valuation, financial analysis and modeling, transaction support, capital markets, and treasury.",
    features: [
      "Market entry and expansion strategy",
      "Competitive analysis and positioning",
      "Revenue optimization frameworks",
      "Strategic planning and execution",
      "M&A strategy and integration",
    ],
  },
  {
    icon: Cpu,
    title: "Digital & AI Advisory",
    description:
      "We help clients unlock the power of AI at scale, modernize technology delivery, and build new businesses to fuel growth. Our AI and technology consulting helps clients outcompete and deliver value at scale.",
    features: [
      "AI strategy and implementation",
      "Digital transformation roadmaps",
      "Technology due diligence",
      "Innovation program design",
      "Data and analytics platforms",
    ],
  },
  {
    icon: Users,
    title: "Leadership Coaching",
    description:
      "Our Leadership Coaching practice helps develop a workforce that can thrive through disruption so you can realize your strategy today and sustain performance in the future.",
    features: [
      "Executive coaching and development",
      "Leadership team alignment",
      "Organizational culture transformation",
      "Talent strategy and succession planning",
      "Change leadership capabilities",
    ],
  },
  {
    icon: Megaphone,
    title: "Growth, Marketing & Sales",
    description:
      "We help companies strengthen their marketing capabilities by advising them on digital processes, analytics, pricing, channel and sales management, and branding.",
    features: [
      "Brand strategy development",
      "Go-to-market planning",
      "Customer experience optimization",
      "Marketing performance analytics",
      "Sales force effectiveness",
    ],
  },
  {
    icon: Lightbulb,
    title: "Transformation",
    description:
      "Our approach to transformation powers comprehensive, rapid, and enduring organizational change. We help organizations accelerate execution to achieve long-term performance improvement.",
    features: [
      "Enterprise-wide transformation",
      "Performance improvement programs",
      "Cost reduction and efficiency",
      "Operating model redesign",
      "Change management",
    ],
  },
  {
    icon: Settings,
    title: "Operations",
    description:
      "We connect boardroom strategies to the frontline—infusing technology and rapidly delivering lasting transformations enabled by capability building.",
    features: [
      "Supply chain optimization",
      "Manufacturing excellence",
      "Procurement transformation",
      "Service operations improvement",
      "Sustainability and net-zero operations",
    ],
  },
];

export default function Services() {
  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <main>
        <section className="relative pt-32 pb-20 lg:pt-40 lg:pb-28 bg-primary">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <h1 className="text-4xl lg:text-5xl font-bold text-primary-foreground mb-6">
              Capabilities
            </h1>
            <p className="text-xl text-primary-foreground/80 max-w-3xl mx-auto">
              Practical experience and know-how on transforming how organizations work. 
              We help you think bigger, build stronger, and expand opportunity.
            </p>
          </div>
        </section>

        <section className="py-20 lg:py-28 bg-background">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid lg:grid-cols-3 gap-8 mb-16">
              {capabilities.slice(0, 3).map((capability, index) => (
                <Card
                  key={capability.title}
                  className="border border-border"
                  data-testid={`capability-${index}`}
                >
                  <CardContent className="p-6">
                    <div className="w-12 h-12 rounded-md bg-primary/10 flex items-center justify-center mb-4">
                      <capability.icon className="h-6 w-6 text-primary" />
                    </div>
                    <h3 className="text-xl font-bold text-foreground mb-3">
                      {capability.title}
                    </h3>
                    <p className="text-muted-foreground text-sm leading-relaxed mb-4">
                      {capability.description}
                    </p>
                    <ul className="space-y-2">
                      {capability.features.slice(0, 3).map((feature) => (
                        <li key={feature} className="flex items-start gap-2 text-sm">
                          <CheckCircle className="h-4 w-4 text-primary flex-shrink-0 mt-0.5" />
                          <span className="text-muted-foreground">{feature}</span>
                        </li>
                      ))}
                    </ul>
                  </CardContent>
                </Card>
              ))}
            </div>

            <div className="grid lg:grid-cols-3 gap-8">
              {capabilities.slice(3).map((capability, index) => (
                <Card
                  key={capability.title}
                  className="border border-border"
                  data-testid={`capability-${index + 3}`}
                >
                  <CardContent className="p-6">
                    <div className="w-12 h-12 rounded-md bg-primary/10 flex items-center justify-center mb-4">
                      <capability.icon className="h-6 w-6 text-primary" />
                    </div>
                    <h3 className="text-xl font-bold text-foreground mb-3">
                      {capability.title}
                    </h3>
                    <p className="text-muted-foreground text-sm leading-relaxed mb-4">
                      {capability.description}
                    </p>
                    <ul className="space-y-2">
                      {capability.features.slice(0, 3).map((feature) => (
                        <li key={feature} className="flex items-start gap-2 text-sm">
                          <CheckCircle className="h-4 w-4 text-primary flex-shrink-0 mt-0.5" />
                          <span className="text-muted-foreground">{feature}</span>
                        </li>
                      ))}
                    </ul>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </section>

        <section className="py-16 bg-muted/30">
          <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <h2 className="text-2xl lg:text-3xl font-bold text-foreground mb-4">
              Ready to transform your organization?
            </h2>
            <p className="text-muted-foreground mb-8">
              Let's discuss how our capabilities can address your most pressing challenges.
            </p>
            <Link href="/contact">
              <Button size="lg">
                Start a Conversation
                <ArrowRight className="ml-2 h-5 w-5" />
              </Button>
            </Link>
          </div>
        </section>

        <CTASection />
      </main>
      <Footer />
    </div>
  );
}
