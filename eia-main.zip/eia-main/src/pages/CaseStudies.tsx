import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import CTASection from "@/components/CTASection";
import { Card, CardContent } from "@/components/ui/card";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { ArrowRight, Target, Users, BarChart3 } from "lucide-react";

const caseStudies = [
  {
    id: 1,
    icon: Target,
    title: "Founder-Led Services Company",
    challenge:
      "Rapid growth created operational bottlenecks and inconsistent decision making.",
    approach:
      "6-week strategy sprint to clarify priorities, redesign leadership routines, and define a simple operating rhythm.",
    outcome:
      "Leadership team aligned around 3 strategic priorities, weekly performance dashboard, and clearer role definitions.",
  },
  {
    id: 2,
    icon: Users,
    title: "Remote Professional Firm",
    challenge:
      "Distributed teams struggled with coordination and client experience.",
    approach:
      "Mapped critical workflows, introduced digital collaboration tools, and created a remote-first operating model.",
    outcome:
      "Faster client response times, fewer escalations, and improved team engagement.",
  },
  {
    id: 3,
    icon: BarChart3,
    title: "Digital Transformation Program",
    challenge:
      "Existing digital projects were fragmented and not delivering impact.",
    approach:
      "Independent review of initiatives, reset of roadmap, and leadership coaching for the program sponsor.",
    outcome:
      "Consolidated portfolio around 4 high-impact initiatives with clear metrics and governance.",
  },
];

export default function CaseStudies() {
  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <main>
        <section className="relative pt-32 pb-20 lg:pt-40 lg:pb-28 bg-primary">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <h1
              className="text-4xl lg:text-5xl font-bold text-primary-foreground mb-6"
              data-testid="page-title"
            >
              Case Studies
            </h1>
            <p className="text-xl text-primary-foreground/80 max-w-3xl mx-auto">
              Selected examples of how we support leaders and organizations.
            </p>
          </div>
        </section>

        <section className="py-20 lg:py-28 bg-background">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="max-w-3xl mb-16">
              <p className="text-lg text-muted-foreground leading-relaxed">
                Client confidentiality is critical to our work. The examples
                below are anonymised but reflect real engagements and impact.
              </p>
            </div>

            <div className="space-y-8">
              {caseStudies.map((study, index) => (
                <Card
                  key={study.id}
                  className="border border-border overflow-hidden"
                  data-testid={`case-study-${index}`}
                >
                  <CardContent className="p-0">
                    <div className="grid lg:grid-cols-4 gap-0">
                      <div className="bg-primary/5 p-6 lg:p-8 flex flex-col justify-center">
                        <div className="w-12 h-12 rounded-md bg-primary/10 flex items-center justify-center mb-4">
                          <study.icon className="h-6 w-6 text-primary" />
                        </div>
                        <h2 className="text-xl font-bold text-foreground">
                          {study.title}
                        </h2>
                      </div>
                      <div className="lg:col-span-3 p-6 lg:p-8">
                        <div className="grid md:grid-cols-3 gap-6">
                          <div>
                            <h3 className="text-sm font-semibold text-primary uppercase tracking-wider mb-3">
                              Challenge
                            </h3>
                            <p className="text-muted-foreground text-sm leading-relaxed">
                              {study.challenge}
                            </p>
                          </div>
                          <div>
                            <h3 className="text-sm font-semibold text-primary uppercase tracking-wider mb-3">
                              Approach
                            </h3>
                            <p className="text-muted-foreground text-sm leading-relaxed">
                              {study.approach}
                            </p>
                          </div>
                          <div>
                            <h3 className="text-sm font-semibold text-primary uppercase tracking-wider mb-3">
                              Outcome
                            </h3>
                            <p className="text-muted-foreground text-sm leading-relaxed">
                              {study.outcome}
                            </p>
                          </div>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </section>

        <section className="py-16 bg-muted/30">
          <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <h2 className="text-2xl lg:text-3xl font-bold text-foreground mb-4">
              Facing similar challenges?
            </h2>
            <p className="text-muted-foreground mb-8">
              Let's discuss how we can help your organization achieve its goals.
            </p>
            <Link href="/contact">
              <Button size="lg" data-testid="cta-button">
                Start a Conversation
                <ArrowRight className="ml-2 h-5 w-5" />
              </Button>
            </Link>
          </div>
        </section>

        <CTASection />
      </main>
      <Footer />
    </div>
  );
}
