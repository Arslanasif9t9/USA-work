import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { Briefcase, CheckCircle, ArrowRight } from "lucide-react";
import careersImage from "@assets/stock_images/young_professionals__c08f269c.jpg";

const openings = [
  {
    id: 1,
    title: "Intuitive Advisor Associate (Voice/Chat)",
    type: "Remote",
  },
  {
    id: 2,
    title: "Operations & Support Assistant",
    type: "Remote",
  },
  {
    id: 3,
    title: "Research & Insights Assistant",
    type: "Remote",
  },
];

const qualifications = [
  "Strong English communication",
  "Clarity, calmness, professionalism",
  "Ability to follow structured processes",
  "Comfortable speaking with international clients",
];

const hiringSteps = [
  "Online application",
  "Short skills screening",
  "Interview",
  "Paid trial (for some roles)",
];

export default function Careers() {
  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <main>
        <section className="relative pt-32 pb-20 lg:pt-40 lg:pb-28 bg-primary">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <h1 className="text-4xl lg:text-5xl font-bold text-primary-foreground mb-6">
              Careers at Expert Intuitive Advisor Inc
            </h1>
            <p className="text-xl text-primary-foreground/80 max-w-3xl mx-auto">
              We are building a small, high-quality remote team to support our 
              advisory work. Our roles focus on communication, analysis, and 
              structured problem solving.
            </p>
          </div>
        </section>

        <section className="py-16 lg:py-24 bg-muted/30">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid lg:grid-cols-2 gap-12 items-center">
              <div>
                <p className="text-sm font-medium text-primary uppercase tracking-wider mb-4">Careers</p>
                <h2 className="text-3xl lg:text-4xl font-bold text-foreground mb-6">
                  Looking for your next move?
                </h2>
                <p className="text-lg text-muted-foreground mb-8 leading-relaxed">
                  We look for people who are energized by the same things as our clients: 
                  bold thinking, real impact, and the courage to move first.
                </p>
                <Link href="/contact">
                  <Button size="lg">
                    Explore Opportunities
                    <ArrowRight className="ml-2 h-5 w-5" />
                  </Button>
                </Link>
              </div>
              <div className="aspect-video overflow-hidden rounded-md">
                <img 
                  src={careersImage} 
                  alt="Team collaboration at Expert Intuitive Advisor Inc"
                  className="w-full h-full object-cover"
                />
              </div>
            </div>
          </div>
        </section>

        <section className="py-20 lg:py-28 bg-background">
          <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="mb-16">
              <h2 className="text-2xl font-bold text-foreground mb-8">
                Current Opportunities
              </h2>
              <div className="space-y-4">
                {openings.map((opening) => (
                  <Card
                    key={opening.id}
                    className="border border-border"
                    data-testid={`job-opening-${opening.id}`}
                  >
                    <CardContent className="p-6">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-4">
                          <div className="w-10 h-10 rounded-md bg-primary/10 flex items-center justify-center">
                            <Briefcase className="h-5 w-5 text-primary" />
                          </div>
                          <div>
                            <h3 className="font-semibold text-foreground">
                              {opening.title}
                            </h3>
                            <p className="text-sm text-muted-foreground">
                              {opening.type}
                            </p>
                          </div>
                        </div>
                        <Link href="/contact">
                          <Button variant="outline" size="sm">
                            Apply
                            <ArrowRight className="ml-2 h-4 w-4" />
                          </Button>
                        </Link>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>

            <div className="grid md:grid-cols-2 gap-12">
              <div>
                <h2 className="text-2xl font-bold text-foreground mb-6">
                  What We Look For
                </h2>
                <div className="space-y-4">
                  {qualifications.map((qualification) => (
                    <div key={qualification} className="flex items-start gap-3">
                      <CheckCircle className="h-5 w-5 text-primary flex-shrink-0 mt-0.5" />
                      <span className="text-muted-foreground">{qualification}</span>
                    </div>
                  ))}
                </div>
              </div>

              <div>
                <h2 className="text-2xl font-bold text-foreground mb-6">
                  Hiring Process
                </h2>
                <div className="space-y-4">
                  {hiringSteps.map((step, index) => (
                    <div key={step} className="flex items-start gap-4">
                      <div className="w-8 h-8 rounded-full bg-primary text-primary-foreground flex items-center justify-center text-sm font-medium flex-shrink-0">
                        {index + 1}
                      </div>
                      <span className="text-muted-foreground pt-1">{step}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </div>
  );
}
