import { Brain, TrendingUp, Target, Eye } from "lucide-react";
import aboutImage from "@assets/stock_images/business_professiona_2e39f82b.jpg";

const capabilities = [
  {
    icon: Brain,
    title: "Rapid Pattern Recognition",
    description: "Identifying market signals and strategic opportunities before they become obvious.",
  },
  {
    icon: TrendingUp,
    title: "High-Level Strategic Instincts",
    description: "Leveraging decades of cross-industry experience for decisive guidance.",
  },
  {
    icon: Target,
    title: "Decision Intelligence",
    description: "Frameworks and methodologies that transform complexity into clarity.",
  },
  {
    icon: Eye,
    title: "Executive Foresight",
    description: "Anticipating market shifts and positioning organizations for success.",
  },
];

export default function AboutSection() {
  return (
    <section className="py-20 lg:py-28 bg-background" data-testid="about-section">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-12 lg:gap-16 items-center">
          <div>
            <p className="text-sm font-medium text-primary uppercase tracking-wider mb-3">
              About the Firm
            </p>
            <h2
              className="text-3xl lg:text-4xl font-bold text-foreground mb-6"
              data-testid="about-title"
            >
              Strategic Clarity for Complex Decisions
            </h2>
            <p className="text-lg text-muted-foreground mb-6 leading-relaxed">
              Expert Intuitive Advisor Inc is a U.S.-based corporate consulting firm providing strategic 
              clarity and decision support across multiple domains. We partner with executives, 
              founders, and leadership teams to navigate complexity and drive exceptional outcomes.
            </p>
            <p className="text-lg text-muted-foreground mb-8 leading-relaxed">
              Our Intuitive Advisory approach combines rigorous analytical frameworks with 
              pattern recognition developed through decades of cross-industry experience. 
              This enables us to deliver insights that traditional consulting methodologies 
              often miss.
            </p>

            <div className="grid sm:grid-cols-2 gap-6">
              {capabilities.map((capability) => (
                <div
                  key={capability.title}
                  className="flex gap-4"
                  data-testid={`capability-${capability.title.toLowerCase().replace(/ /g, "-")}`}
                >
                  <div className="flex-shrink-0 w-10 h-10 rounded-md bg-primary/10 flex items-center justify-center">
                    <capability.icon className="h-5 w-5 text-primary" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-foreground mb-1">
                      {capability.title}
                    </h3>
                    <p className="text-sm text-muted-foreground">
                      {capability.description}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="relative">
            <div className="aspect-[4/3] rounded-md overflow-hidden">
              <img
                src={aboutImage}
                alt="Expert Intuitive Advisor Inc consulting team collaboration"
                className="w-full h-full object-cover"
                data-testid="about-image"
              />
            </div>
            <div className="absolute -bottom-6 -left-6 bg-primary text-primary-foreground p-6 rounded-md shadow-lg hidden lg:block">
              <div className="text-3xl font-bold">15+</div>
              <div className="text-sm opacity-90">Years of Excellence</div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
