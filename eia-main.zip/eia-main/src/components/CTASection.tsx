import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { ArrowRight } from "lucide-react";

export default function CTASection() {
  return (
    <section
      className="py-20 lg:py-24 bg-primary"
      data-testid="cta-section"
    >
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
        <h2
          className="text-3xl lg:text-4xl font-bold text-primary-foreground mb-6"
          data-testid="cta-title"
        >
          Ready to Transform Your Organization?
        </h2>
        <p className="text-lg text-primary-foreground/80 mb-10 max-w-2xl mx-auto">
          Partner with Expert Intuitive Advisor Inc to navigate complexity, accelerate growth, 
          and achieve extraordinary results.
        </p>
        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <Link href="/contact">
            <Button
              size="lg"
              variant="secondary"
              className="text-base px-8"
              data-testid="cta-primary-button"
            >
              Schedule a Consultation
              <ArrowRight className="ml-2 h-5 w-5" />
            </Button>
          </Link>
          <Link href="/services">
            <Button
              size="lg"
              variant="outline"
              className="text-base px-8 border-primary-foreground/30 text-primary-foreground bg-primary-foreground/10"
              data-testid="cta-secondary-button"
            >
              Explore Services
            </Button>
          </Link>
        </div>
      </div>
    </section>
  );
}
