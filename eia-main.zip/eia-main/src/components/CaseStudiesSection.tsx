import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { ArrowRight, TrendingUp, DollarSign, Clock, BarChart3 } from "lucide-react";

// todo: remove mock functionality
const caseStudies = [
  {
    id: 1,
    category: "Operations",
    title: "Operational Excellence Transformation",
    description:
      "Comprehensive operational redesign for a mid-market manufacturing company, streamlining processes and reducing overhead.",
    metric: "32%",
    metricLabel: "Cost Reduction",
    icon: TrendingUp,
  },
  {
    id: 2,
    category: "Growth Strategy",
    title: "Market Entry Strategy",
    description:
      "Strategic market entry plan for a technology company expanding into new geographic territories and customer segments.",
    metric: "41%",
    metricLabel: "Revenue Increase",
    icon: DollarSign,
  },
  {
    id: 3,
    category: "Digital Transformation",
    title: "AI-Powered Decision Platform",
    description:
      "Development and implementation of an AI-driven analytics platform to enhance executive decision-making capabilities.",
    metric: "3x",
    metricLabel: "Faster Decisions",
    icon: Clock,
  },
  {
    id: 4,
    category: "Leadership",
    title: "Executive Team Alignment",
    description:
      "Leadership development program and organizational restructuring to improve cross-functional collaboration.",
    metric: "87%",
    metricLabel: "Team Effectiveness",
    icon: BarChart3,
  },
];

export default function CaseStudiesSection() {
  return (
    <section
      className="py-20 lg:py-28 bg-background"
      data-testid="case-studies-section"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <p className="text-sm font-medium text-primary uppercase tracking-wider mb-3">
            Impact & Results
          </p>
          <h2
            className="text-3xl lg:text-4xl font-bold text-foreground mb-4"
            data-testid="case-studies-title"
          >
            Proven Track Record
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Our advisory engagements deliver measurable outcomes that transform 
            organizations and create lasting competitive advantage.
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-6">
          {caseStudies.map((study) => (
            <Card
              key={study.id}
              className="group border border-border overflow-hidden hover-elevate transition-all duration-300"
              data-testid={`case-study-card-${study.id}`}
            >
              <CardContent className="p-0">
                <div className="flex flex-col sm:flex-row">
                  <div className="sm:w-1/3 bg-primary/5 p-6 flex flex-col items-center justify-center">
                    <study.icon className="h-8 w-8 text-primary mb-3" />
                    <div className="text-4xl font-bold text-primary">
                      {study.metric}
                    </div>
                    <div className="text-sm text-muted-foreground text-center">
                      {study.metricLabel}
                    </div>
                  </div>
                  <div className="sm:w-2/3 p-6">
                    <span className="text-xs font-medium text-primary uppercase tracking-wider">
                      {study.category}
                    </span>
                    <h3 className="text-lg font-semibold text-foreground mt-2 mb-3">
                      {study.title}
                    </h3>
                    <p className="text-sm text-muted-foreground leading-relaxed">
                      {study.description}
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="text-center mt-12">
          <Link href="/case-studies">
            <Button variant="outline" size="lg" data-testid="case-studies-cta">
              View All Case Studies
              <ArrowRight className="ml-2 h-5 w-5" />
            </Button>
          </Link>
        </div>
      </div>
    </section>
  );
}
