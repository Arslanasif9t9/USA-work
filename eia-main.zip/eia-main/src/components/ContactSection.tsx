import { Card, CardContent } from "@/components/ui/card";
import { MapPin, Mail, Phone } from "lucide-react";
import { useEffect } from "react";

export default function ContactSection() {
  useEffect(() => {
    const script = document.createElement("script");
    script.src = "//embed.typeform.com/next/embed.js";
    script.async = true;
    document.body.appendChild(script);

    return () => {
      document.body.removeChild(script);
    };
  }, []);

  return (
    <section
      className="py-20 lg:py-28 bg-card"
      data-testid="contact-section"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <p className="text-sm font-medium text-primary uppercase tracking-wider mb-3">
            Get in Touch
          </p>
          <h2
            className="text-3xl lg:text-4xl font-bold text-foreground mb-4"
            data-testid="contact-title"
          >
            Start a Conversation
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Reach out to discuss how our advisory services can address your 
            organization's most pressing strategic challenges.
          </p>
        </div>

        <div className="grid lg:grid-cols-5 gap-8 lg:gap-12">
          <div className="lg:col-span-3">
            <Card className="border border-border">
              <CardContent className="p-6 lg:p-8">
                <p className="text-sm text-muted-foreground mb-6">
                  For candidates and clients: please complete this brief form and our team will contact you.
                </p>
                <div 
                  className="min-h-[600px]"
                  data-testid="typeform-container"
                >
                  <div data-tf-live="01KBK3K3A6ATWE1N5TN6Y6HGR4"></div>
                </div>
              </CardContent>
            </Card>
          </div>

          <div className="lg:col-span-2 space-y-6">
            <div>
              <h3 className="text-lg font-semibold text-foreground mb-4">
                Headquarters
              </h3>
              <div className="flex gap-4">
                <div className="flex-shrink-0 w-10 h-10 rounded-md bg-primary/10 flex items-center justify-center">
                  <MapPin className="h-5 w-5 text-primary" />
                </div>
                <div data-testid="contact-address">
                  <p className="font-medium text-foreground">Expert Intuitive Advisor Inc</p>
                  <p className="text-muted-foreground">223 W 39th St</p>
                  <p className="text-muted-foreground">New York, NY 10001</p>
                </div>
              </div>
            </div>

            <div>
              <h3 className="text-lg font-semibold text-foreground mb-4">
                Contact
              </h3>
              <div className="space-y-4">
                <div className="flex gap-4">
                  <div className="flex-shrink-0 w-10 h-10 rounded-md bg-primary/10 flex items-center justify-center">
                    <Mail className="h-5 w-5 text-primary" />
                  </div>
                  <div>
                    <p className="font-medium text-foreground">Email</p>
                    <p className="text-muted-foreground">support@expertintuitiveadvisor.com</p>
                  </div>
                </div>
                <div className="flex gap-4">
                  <div className="flex-shrink-0 w-10 h-10 rounded-md bg-primary/10 flex items-center justify-center">
                    <Phone className="h-5 w-5 text-primary" />
                  </div>
                  <div>
                    <p className="font-medium text-foreground">Phone</p>
                    <p className="text-muted-foreground">+1-888-751-6086</p>
                  </div>
                </div>
              </div>
            </div>

            <Card className="border border-border bg-primary/5">
              <CardContent className="p-6">
                <h4 className="font-semibold text-foreground mb-2">
                  Response Time
                </h4>
                <p className="text-sm text-muted-foreground">
                  Our team responds to all inquiries within 24 business hours. 
                  For urgent matters, please indicate in your message.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </section>
  );
}
