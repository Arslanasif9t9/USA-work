import { CheckCircle } from "lucide-react";

const commitments = [
  "We never ask candidates to pay fees or buy courses.",
  "We focus on clear communication, realistic expectations, and structured training.",
  "We are transparent about roles, responsibilities, and compensation.",
  "We are respectful of people's time and do not spam or sell personal data.",
];

export default function CommitmentSection() {
  return (
    <section className="py-20 lg:py-28 bg-muted/30" data-testid="commitment-section">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <p className="text-sm font-medium text-primary uppercase tracking-wider mb-3">
            Our Promise
          </p>
          <h2 className="text-3xl lg:text-4xl font-bold text-foreground mb-6">
            Our Commitment to Candidates and Clients
          </h2>
          <p className="text-lg text-muted-foreground leading-relaxed max-w-3xl mx-auto">
            Expert Intuitive Advisor Inc is a small but serious advisory firm. We work with 
            real clients across different platforms and are building a long-term remote team. 
            Here is how we work with people who visit this site.
          </p>
        </div>

        <div className="space-y-4">
          {commitments.map((commitment) => (
            <div 
              key={commitment} 
              className="flex items-start gap-4 p-4 bg-background rounded-md border border-border"
            >
              <CheckCircle className="h-6 w-6 text-primary flex-shrink-0 mt-0.5" />
              <span className="text-foreground">{commitment}</span>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
