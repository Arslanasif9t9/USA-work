import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { ArrowRight, Volume2, VolumeX, Play } from "lucide-react";
import { useRef, useState } from "react";

export default function HeroSection() {
  const videoRef = useRef<HTMLVideoElement>(null);
  const [isMuted, setIsMuted] = useState(false);
  const [hasStarted, setHasStarted] = useState(false);
  const [hasEnded, setHasEnded] = useState(false);

  const startVideo = () => {
    const video = videoRef.current;
    if (!video) return;

    video.muted = false;
    setIsMuted(false);
    video.currentTime = 0;
    video.play();
    setHasStarted(true);
  };

  const handleVideoEnd = () => {
    const video = videoRef.current;
    if (video) {
      video.currentTime = 0;
      video.pause();
      setHasEnded(true);
    }
  };

  const toggleMute = () => {
    const video = videoRef.current;
    if (video) {
      video.muted = !video.muted;
      setIsMuted(video.muted);
    }
  };

  const replayVideo = () => {
    const video = videoRef.current;
    if (video) {
      video.currentTime = 0;
      video.muted = false;
      setIsMuted(false);
      video.play();
      setHasEnded(false);
    }
  };

  return (
    <section
      className="relative min-h-screen flex items-center overflow-hidden"
      data-testid="hero-section"
    >
      <video
        ref={videoRef}
        playsInline
        onEnded={handleVideoEnd}
        className="absolute inset-0 w-full h-full object-cover"
        data-testid="hero-video"
      >
        <source src="/hero.mp4" type="video/mp4" />
      </video>

      <div className="absolute inset-0 bg-black/60" />

      {/* Click to start overlay - shown before video starts */}
      {!hasStarted && (
        <div 
          className="absolute inset-0 z-20 flex items-center justify-center bg-black/70 cursor-pointer"
          onClick={startVideo}
          data-testid="video-start-overlay"
        >
          <div className="text-center">
            <div className="w-24 h-24 mx-auto mb-6 rounded-full bg-white/20 backdrop-blur-sm flex items-center justify-center hover:bg-white/30 transition-colors">
              <Play className="h-12 w-12 text-white ml-2" fill="white" />
            </div>
            <p className="text-white/90 text-lg font-light tracking-wide">Click to experience our story</p>
            <p className="text-white/60 text-sm mt-2">with sound</p>
          </div>
        </div>
      )}

      {/* Sound toggle button - shown after video starts */}
      {hasStarted && !hasEnded && (
        <button
          onClick={toggleMute}
          className="absolute bottom-8 right-8 z-20 p-3 rounded-full bg-white/20 backdrop-blur-sm hover:bg-white/30 transition-colors"
          data-testid="video-mute-toggle"
          aria-label={isMuted ? "Unmute video" : "Mute video"}
        >
          {isMuted ? (
            <VolumeX className="h-5 w-5 text-white" />
          ) : (
            <Volume2 className="h-5 w-5 text-white" />
          )}
        </button>
      )}

      {/* Replay button - shown after video ends */}
      {hasEnded && (
        <button
          onClick={replayVideo}
          className="absolute bottom-8 right-8 z-20 p-3 rounded-full bg-white/20 backdrop-blur-sm hover:bg-white/30 transition-colors flex items-center gap-2"
          data-testid="video-replay"
        >
          <Play className="h-5 w-5 text-white" />
          <span className="text-white text-sm">Replay</span>
        </button>
      )}

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full py-20">
        <div className="max-w-2xl">
          <h1
            className="text-4xl sm:text-5xl lg:text-6xl xl:text-7xl font-serif font-light text-white tracking-tight mb-6 leading-tight"
            data-testid="hero-headline"
          >
            What's your next<br />
            decisive move?
          </h1>
          <p
            className="text-lg sm:text-xl text-white/80 max-w-xl mb-10"
            data-testid="hero-subheadline"
          >
            At Expert Intuitive Advisor Inc, we help leaders and founders turn complex choices into clear, confident action.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-start">
            <Link href="/contact">
              <Button
                size="lg"
                className="text-base px-8 py-6 bg-white text-primary hover:bg-white/90"
                data-testid="hero-cta-primary"
              >
                Start Project Inquiry
                <ArrowRight className="ml-2 h-5 w-5" />
              </Button>
            </Link>
            <Link href="/services">
              <Button
                size="lg"
                variant="outline"
                className="text-base px-8 py-6 border-white/30 text-white bg-white/10 backdrop-blur-sm"
                data-testid="hero-cta-secondary"
              >
                Explore Services
              </Button>
            </Link>
          </div>
        </div>
      </div>

      <div className="absolute bottom-8 left-1/2 -translate-x-1/2 animate-bounce hidden lg:block">
        <div className="w-6 h-10 rounded-full border-2 border-white/40 flex items-start justify-center p-2">
          <div className="w-1 h-2 bg-white/60 rounded-full" />
        </div>
      </div>
    </section>
  );
}
