import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import {
  TrendingUp,
  Cpu,
  Users,
  Megaphone,
  Lightbulb,
  Settings,
  ArrowRight,
} from "lucide-react";

const services = [
  {
    icon: TrendingUp,
    title: "Business Strategy & Growth",
    description:
      "Market expansion, competitive positioning, and growth acceleration strategies tailored to your organization's unique challenges and opportunities.",
  },
  {
    icon: Cpu,
    title: "Digital & AI Advisory",
    description:
      "Technology transformation, AI integration, and digital strategy to position your organization at the forefront of innovation.",
  },
  {
    icon: Users,
    title: "Leadership & Executive Coaching",
    description:
      "Developing exceptional leaders through personalized coaching, team dynamics optimization, and succession planning.",
  },
  {
    icon: Megaphone,
    title: "Marketing & Brand Acceleration",
    description:
      "Brand strategy, market positioning, and go-to-market execution that drives measurable business impact.",
  },
  {
    icon: Lightbulb,
    title: "Decision Intelligence & Foresight",
    description:
      "Advanced analytics, scenario planning, and strategic foresight to navigate uncertainty with confidence.",
  },
  {
    icon: Settings,
    title: "Operations & Systems Optimization",
    description:
      "Process improvement, operational excellence, and organizational design that enhances efficiency and scalability.",
  },
];

export default function ServicesSection() {
  return (
    <section
      className="py-20 lg:py-28 bg-card"
      data-testid="services-section"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <p className="text-sm font-medium text-primary uppercase tracking-wider mb-3">
            Advisory Divisions
          </p>
          <h2
            className="text-3xl lg:text-4xl font-bold text-foreground mb-4"
            data-testid="services-title"
          >
            Comprehensive Strategic Services
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Our integrated advisory practice delivers expertise across the full 
            spectrum of strategic challenges facing modern organizations.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {services.map((service) => (
            <Card
              key={service.title}
              className="group border border-border hover-elevate transition-all duration-300"
              data-testid={`service-card-${service.title.toLowerCase().replace(/ & /g, "-").replace(/ /g, "-")}`}
            >
              <CardContent className="p-6">
                <div className="w-12 h-12 rounded-md bg-primary/10 flex items-center justify-center mb-5 group-hover:bg-primary/20 transition-colors">
                  <service.icon className="h-6 w-6 text-primary" />
                </div>
                <h3 className="text-xl font-semibold text-foreground mb-3">
                  {service.title}
                </h3>
                <p className="text-muted-foreground leading-relaxed">
                  {service.description}
                </p>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="text-center mt-12">
          <Link href="/contact">
            <Button size="lg" data-testid="services-cta">
              Discuss Your Needs
              <ArrowRight className="ml-2 h-5 w-5" />
            </Button>
          </Link>
        </div>
      </div>
    </section>
  );
}
