import { Link } from "wouter";

const footerLinks = {
  company: [
    { label: "About", href: "/about" },
    { label: "Careers", href: "/careers" },
    { label: "Contact", href: "/contact" },
  ],
  capabilities: [
    { label: "Strategy", href: "/services" },
    { label: "Digital & AI Advisory", href: "/digital-ai-advisory" },
    { label: "Leadership Coaching", href: "/leadership-coaching" },
  ],
  insights: [
    { label: "Case Studies", href: "/case-studies" },
    { label: "Insights", href: "/insights" },
    { label: "Resources", href: "/resources" },
  ],
};

export default function Footer() {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-primary text-primary-foreground" data-testid="footer">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="py-12 lg:py-16">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            <div className="col-span-2 md:col-span-1">
              <div className="mb-4" data-testid="footer-logo">
                <span className="text-lg font-bold text-white">
                  Expert Intuitive Advisor Inc
                </span>
              </div>
              <p className="text-primary-foreground/80 text-sm leading-relaxed mb-4">
                Strategic insight for leaders, founders, and decision makers.
              </p>
              <div className="text-sm text-primary-foreground/70" data-testid="footer-address">
                <p>223 W 39th St</p>
                <p>New York, NY 10001</p>
              </div>
            </div>

            <div>
              <h4 className="font-semibold mb-4">Company</h4>
              <ul className="space-y-2">
                {footerLinks.company.map((link) => (
                  <li key={link.label}>
                    <Link 
                      href={link.href}
                      className="text-sm text-primary-foreground/80 hover:text-primary-foreground transition-colors cursor-pointer block"
                      data-testid={`footer-link-${link.label.toLowerCase()}`}
                    >
                      {link.label}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>

            <div>
              <h4 className="font-semibold mb-4">Capabilities</h4>
              <ul className="space-y-2">
                {footerLinks.capabilities.map((link) => (
                  <li key={link.label}>
                    <Link 
                      href={link.href}
                      className="text-sm text-primary-foreground/80 hover:text-primary-foreground transition-colors cursor-pointer block"
                      data-testid={`footer-link-${link.label.toLowerCase().replace(/ /g, "-")}`}
                    >
                      {link.label}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>

            <div>
              <h4 className="font-semibold mb-4">Insights</h4>
              <ul className="space-y-2">
                {footerLinks.insights.map((link) => (
                  <li key={link.label}>
                    <Link 
                      href={link.href}
                      className="text-sm text-primary-foreground/80 hover:text-primary-foreground transition-colors cursor-pointer block"
                      data-testid={`footer-link-${link.label.toLowerCase().replace(/ /g, "-")}`}
                    >
                      {link.label}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>

        <div className="py-6 border-t border-primary-foreground/20">
          <div className="flex flex-col sm:flex-row justify-between items-center gap-4">
            <p className="text-sm text-primary-foreground/70" data-testid="footer-copyright">
              &copy; {currentYear} Expert Intuitive Advisor Inc. All rights reserved.
            </p>
            <div className="flex gap-6">
              <Link 
                href="/contact"
                className="text-sm text-primary-foreground/70 hover:text-primary-foreground transition-colors cursor-pointer"
              >
                Privacy Policy
              </Link>
              <Link 
                href="/contact"
                className="text-sm text-primary-foreground/70 hover:text-primary-foreground transition-colors cursor-pointer"
              >
                Terms of Service
              </Link>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}
