import { useState, useEffect } from "react";
import { Link, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Menu, X, ChevronDown } from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

const navLinks = [
  { href: "/", label: "Home" },
  { href: "/about", label: "About" },
];

const capabilitiesLinks = [
  { href: "/services", label: "All Capabilities" },
  { href: "/digital-ai-advisory", label: "Digital & AI Advisory" },
  { href: "/leadership-coaching", label: "Leadership Coaching" },
];

const insightsLinks = [
  { href: "/case-studies", label: "Case Studies" },
  { href: "/insights", label: "Insights" },
  { href: "/resources", label: "Resources" },
];

const moreLinks = [
  { href: "/careers", label: "Careers" },
  { href: "/contact", label: "Contact" },
];

export default function Navbar() {
  const [location] = useLocation();
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 10);
    };
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const isCapabilitiesActive = capabilitiesLinks.some(
    (link) => location === link.href
  );
  const isInsightsActive = insightsLinks.some((link) => location === link.href);

  return (
    <nav
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        isScrolled
          ? "bg-background/95 backdrop-blur-sm shadow-sm border-b border-border"
          : "bg-primary"
      }`}
      data-testid="navbar"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 lg:h-20">
          <Link href="/">
            <span
              className={`text-base lg:text-lg font-bold tracking-tight cursor-pointer ${
                isScrolled ? "text-foreground" : "text-white"
              }`}
              data-testid="logo-text"
            >
              Expert Intuitive Advisor Inc
            </span>
          </Link>

          <div className="hidden lg:flex items-center gap-6">
            {navLinks.map((link) => (
              <Link key={link.href} href={link.href}>
                <span
                  className={`text-sm font-medium transition-colors cursor-pointer ${
                    location === link.href
                      ? isScrolled
                        ? "text-primary"
                        : "text-white"
                      : isScrolled
                      ? "text-muted-foreground hover:text-primary"
                      : "text-white/80 hover:text-white"
                  }`}
                  data-testid={`nav-link-${link.label.toLowerCase().replace(" ", "-")}`}
                >
                  {link.label}
                </span>
              </Link>
            ))}

            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <button
                  className={`flex items-center gap-1 text-sm font-medium transition-colors ${
                    isCapabilitiesActive
                      ? isScrolled
                        ? "text-primary"
                        : "text-white"
                      : isScrolled
                      ? "text-muted-foreground hover:text-primary"
                      : "text-white/80 hover:text-white"
                  }`}
                  data-testid="nav-capabilities-dropdown"
                >
                  Capabilities
                  <ChevronDown className="h-4 w-4" />
                </button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="start" className="w-48">
                {capabilitiesLinks.map((link) => (
                  <DropdownMenuItem key={link.href} asChild>
                    <Link href={link.href}>
                      <span
                        className="w-full cursor-pointer"
                        data-testid={`nav-link-${link.label.toLowerCase().replace(/ /g, "-")}`}
                      >
                        {link.label}
                      </span>
                    </Link>
                  </DropdownMenuItem>
                ))}
              </DropdownMenuContent>
            </DropdownMenu>

            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <button
                  className={`flex items-center gap-1 text-sm font-medium transition-colors ${
                    isInsightsActive
                      ? isScrolled
                        ? "text-primary"
                        : "text-white"
                      : isScrolled
                      ? "text-muted-foreground hover:text-primary"
                      : "text-white/80 hover:text-white"
                  }`}
                  data-testid="nav-insights-dropdown"
                >
                  Insights
                  <ChevronDown className="h-4 w-4" />
                </button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="start" className="w-48">
                {insightsLinks.map((link) => (
                  <DropdownMenuItem key={link.href} asChild>
                    <Link href={link.href}>
                      <span
                        className="w-full cursor-pointer"
                        data-testid={`nav-link-${link.label.toLowerCase().replace(/ /g, "-")}`}
                      >
                        {link.label}
                      </span>
                    </Link>
                  </DropdownMenuItem>
                ))}
              </DropdownMenuContent>
            </DropdownMenu>

            {moreLinks.map((link) => (
              <Link key={link.href} href={link.href}>
                <span
                  className={`text-sm font-medium transition-colors cursor-pointer ${
                    location === link.href
                      ? isScrolled
                        ? "text-primary"
                        : "text-white"
                      : isScrolled
                      ? "text-muted-foreground hover:text-primary"
                      : "text-white/80 hover:text-white"
                  }`}
                  data-testid={`nav-link-${link.label.toLowerCase().replace(" ", "-")}`}
                >
                  {link.label}
                </span>
              </Link>
            ))}

            <Link href="/contact">
              <Button
                variant={isScrolled ? "default" : "outline"}
                className={
                  isScrolled
                    ? ""
                    : "border-white/30 text-white bg-white/10 backdrop-blur-sm"
                }
                data-testid="nav-cta-button"
              >
                Get Started
              </Button>
            </Link>
          </div>

          <Button
            variant="ghost"
            size="icon"
            className={`lg:hidden ${isScrolled ? "" : "text-white"}`}
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            data-testid="mobile-menu-toggle"
          >
            {isMobileMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
          </Button>
        </div>
      </div>

      {isMobileMenuOpen && (
        <div className="lg:hidden bg-background border-b border-border">
          <div className="px-4 py-4 space-y-3">
            {navLinks.map((link) => (
              <Link key={link.href} href={link.href}>
                <span
                  className={`block py-2 text-base font-medium cursor-pointer ${
                    location === link.href
                      ? "text-primary"
                      : "text-muted-foreground"
                  }`}
                  onClick={() => setIsMobileMenuOpen(false)}
                  data-testid={`mobile-nav-link-${link.label.toLowerCase().replace(" ", "-")}`}
                >
                  {link.label}
                </span>
              </Link>
            ))}

            <div className="py-2">
              <span className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">
                Capabilities
              </span>
              <div className="mt-2 space-y-1 pl-2">
                {capabilitiesLinks.map((link) => (
                  <Link key={link.href} href={link.href}>
                    <span
                      className={`block py-1.5 text-sm cursor-pointer ${
                        location === link.href
                          ? "text-primary"
                          : "text-muted-foreground"
                      }`}
                      onClick={() => setIsMobileMenuOpen(false)}
                      data-testid={`mobile-nav-link-${link.label.toLowerCase().replace(/ /g, "-")}`}
                    >
                      {link.label}
                    </span>
                  </Link>
                ))}
              </div>
            </div>

            <div className="py-2">
              <span className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">
                Insights
              </span>
              <div className="mt-2 space-y-1 pl-2">
                {insightsLinks.map((link) => (
                  <Link key={link.href} href={link.href}>
                    <span
                      className={`block py-1.5 text-sm cursor-pointer ${
                        location === link.href
                          ? "text-primary"
                          : "text-muted-foreground"
                      }`}
                      onClick={() => setIsMobileMenuOpen(false)}
                      data-testid={`mobile-nav-link-${link.label.toLowerCase().replace(/ /g, "-")}`}
                    >
                      {link.label}
                    </span>
                  </Link>
                ))}
              </div>
            </div>

            {moreLinks.map((link) => (
              <Link key={link.href} href={link.href}>
                <span
                  className={`block py-2 text-base font-medium cursor-pointer ${
                    location === link.href
                      ? "text-primary"
                      : "text-muted-foreground"
                  }`}
                  onClick={() => setIsMobileMenuOpen(false)}
                  data-testid={`mobile-nav-link-${link.label.toLowerCase().replace(" ", "-")}`}
                >
                  {link.label}
                </span>
              </Link>
            ))}

            <Link href="/contact">
              <Button
                className="w-full mt-2"
                onClick={() => setIsMobileMenuOpen(false)}
                data-testid="mobile-nav-cta-button"
              >
                Get Started
              </Button>
            </Link>
          </div>
        </div>
      )}
    </nav>
  );
}
