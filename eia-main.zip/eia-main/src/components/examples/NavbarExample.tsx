import Navbar from "../Navbar";

export default function NavbarExample() {
  return (
    <div className="min-h-[200px] bg-primary relative">
      <Navbar />
    </div>
  );
}
