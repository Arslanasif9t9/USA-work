import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { ArrowRight } from "lucide-react";

export default function HowWeHelpSection() {
  return (
    <section className="py-16 lg:py-24 bg-background" data-testid="how-we-help-section">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="mb-12">
          <p className="text-sm font-medium text-primary uppercase tracking-wider mb-3">
            How We Help Clients
          </p>
          <h2 className="text-3xl lg:text-4xl font-bold text-foreground mb-4">
            Let's turn your biggest opportunities into your next big moves.
          </h2>
        </div>

        <div className="mb-16 p-8 bg-primary rounded-md">
          <div className="max-w-3xl">
            <p className="text-xs font-medium text-primary-foreground/70 uppercase tracking-wider mb-2">
              Tech & AI at Expert Intuitive Advisor Inc
            </p>
            <h3 className="text-2xl lg:text-3xl font-semibold text-primary-foreground mb-4">
              Tech that moves everything
            </h3>
            <p className="text-primary-foreground/80 mb-6 leading-relaxed">
              There's tech. Then there's tech that reimagines and rewires organizations — 
              powered by people, built with AI, and proven to create lasting value in 
              the most ambitious transformations.
            </p>
            <Link href="/services">
              <Button 
                variant="outline" 
                className="border-primary-foreground/30 text-primary-foreground bg-primary-foreground/10 backdrop-blur-sm"
              >
                Explore Tech & AI
                <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
            </Link>
          </div>
        </div>

        <div className="text-center mb-12">
          <h2 className="text-3xl lg:text-4xl font-serif font-light text-foreground">
            Ecosystem of alliances
          </h2>
        </div>

        <div className="grid lg:grid-cols-2 gap-12 items-start">
          <div>
            <h3 className="text-2xl lg:text-3xl font-bold text-foreground mb-6 leading-tight">
              Partnering for seamless tech transformation
            </h3>
            <p className="text-muted-foreground mb-4 leading-relaxed">
              AI that delivers value comes from more than technology. It comes from 
              leadership, design, and the people who move with it.
            </p>
            <p className="text-muted-foreground mb-8 leading-relaxed">
              We bring them all together through Expert Intuitive Advisor Inc's global 
              ecosystem of tech and AI partnerships.
            </p>
            <Link href="/services">
              <Button variant="outline" data-testid="alliances-cta">
                See all tech alliances
              </Button>
            </Link>
          </div>

          <div className="bg-card border border-border rounded-md p-4">
            <img 
              src="/alliances-logos.jpg" 
              alt="Technology Partners - Aleph Alpha, Anthropic, AWS, Cohere, Credo AI, Databricks, Glean, Google Cloud, WatsonX, Jasper, Microsoft, Mistral AI, Moveworks, NVIDIA, Salesforce, SAP, Scale, Snorkel, Spark Beyond, MongoDB"
              className="w-full h-auto"
              data-testid="alliances-logos"
            />
          </div>
        </div>

        <div className="text-center mt-12">
          <Link href="/services">
            <Button variant="outline" data-testid="capabilities-cta">
              See all capabilities
            </Button>
          </Link>
        </div>
      </div>
    </section>
  );
}
