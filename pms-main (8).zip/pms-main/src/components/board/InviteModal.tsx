/**
 * Invite link modal — admin only (per docs/PERMISSIONS-REDESIGN-PLAN.md).
 *
 * Admin picks an expiry + scope (whole board OR a specific group within
 * the board OR the whole workspace), clicks "Generate invite link", and
 * copies the resulting `/invite/{token}` URL to share via any channel.
 * Every invite assigns the `manager` role — there's no Viewer / Editor
 * option anymore.
 *
 * Group-scoped invites carry `group_id` on the invite itself. At accept
 * time (Phase 3 / migration 0056) the server creates the board
 * subscription with group_id = NULL (membership) AND inserts the
 * corresponding group_user_visibility ACL row so the new manager sees
 * only the granted group. Board-wide invites grant zero ACL rows by
 * default — admins explicitly grant via /admin → Group access.
 */
import { useMemo, useState } from 'react';
import { toast } from 'sonner';
import {
  Link2, Copy, Check, Trash2, Globe, Lock, ChevronDown, Mail,
} from 'lucide-react';
import { Modal } from '@/components/Modal';
import { RoleBadge } from '@/components/RoleBadge';
import { Spinner } from '@/components/Spinner';
import { EmptyMessage } from '@/components/EmptyMessage';
import {
  useInvitesForBoard, useCreateInvite, useRevokeInvite,
  type InviteRow,
} from '@/hooks/invites';
import { useGroups } from '@/hooks/groups';
import { useAuthStore } from '@/state/authStore';
import { supabase } from '@/lib/supabase';
import { safeGetSession } from '@/lib/safeAuth';
import type { UserRole } from '@/lib/database.types';
import { cn } from '@/lib/cn';

// Loose-but-useful email shape check. Matches the server's regex in
// api/send-invite-email.ts so what passes here also passes there —
// no point in pre-validating stricter than the route does.
const EMAIL_RE = /^.+@.+\..+$/;

interface InviteModalProps {
  open: boolean;
  onClose: () => void;
  boardId: string;
  boardName: string;
}

export function InviteModal({ open, onClose, boardId, boardName }: InviteModalProps) {
  // 'board' = whole board access; 'workspace' = workspace-wide (no
  // board scope, joins main workspace only); 'group' = scoped to a
  // single group on this board.
  const [scope, setScope] = useState<'board' | 'workspace' | 'group'>('board');
  const [groupId, setGroupId] = useState<string | null>(null);
  // Role the invitee gets when they accept. Backend (migration 0020 +
  // 0023) already supports admin/manager/viewer in create_invite +
  // accept_invite. Default = Manager (the most common case).
  const [role, setRole] = useState<UserRole>('manager');
  // `null` ⇒ never expires (sent as null to RPC; migration 0037 treats
  // null expires_at as no-expiry). Default flipped to Never per spec.
  const [expires, setExpires] = useState<24 | 168 | 720 | null>(null);
  // Optional invitee email — when set, the "Send Invite" button mints
  // the invite with this email AND fires the branded email via
  // /api/send-invite-email. Leaving it blank keeps the legacy
  // "Generate invite link" flow working unchanged.
  const [inviteeEmail, setInviteeEmail] = useState('');
  const [newLink, setNewLink] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);
  // Independent loading flag for the Send-Invite path so the Generate
  // button's spinner (create.isPending) doesn't bleed onto it.
  const [sending, setSending] = useState(false);

  const { data: groups } = useGroups(boardId);
  const list = useInvitesForBoard(scope === 'workspace' ? null : boardId);
  const create = useCreateInvite();
  const revoke = useRevokeInvite();
  const profile = useAuthStore((s) => s.profile);

  const onGenerate = async () => {
    if (scope === 'group' && !groupId) {
      toast.error('Pick a group to scope this invite to');
      return;
    }
    try {
      const data = await create.mutateAsync({
        // User-selected role (admin / manager / viewer). The backend
        // RPC (create_invite, migration 0023) gates this by is_admin()
        // already — only admins can reach this modal anyway.
        role,
        boardId: scope === 'workspace' ? null : boardId,
        groupId: scope === 'group' ? groupId : null,
        // expires === null is the "Never expires" choice — sent through
        // to the RPC, which stores expires_at = NULL.
        expiresInHours: expires,
      });
      const link = `${window.location.origin}/invite/${data.token}`;
      setNewLink(link);
      setCopied(false);
      toast.success('Invite link ready');
    } catch (err) {
      toast.error(err instanceof Error ? err.message : 'Could not generate invite');
    }
  };

  const onSendInvite = async () => {
    const email = inviteeEmail.trim();
    if (!email || !EMAIL_RE.test(email)) {
      toast.error('Enter a valid email to send an invite');
      return;
    }
    if (scope === 'group' && !groupId) {
      toast.error('Pick a group to scope this invite to');
      return;
    }

    setSending(true);
    try {
      // 1) Mint the invite — same RPC + same args as Generate, plus
      //    the new invitee_email param wired through 0040.
      const data = await create.mutateAsync({
        role,
        boardId: scope === 'workspace' ? null : boardId,
        groupId: scope === 'group' ? groupId : null,
        expiresInHours: expires,
        inviteeEmail: email,
      });
      const link = `${window.location.origin}/invite/${data.token}`;

      // 2) Grab the current session JWT — /api/send-invite-email
      //    re-validates it server-side via is_admin().
      const { data: sessionData, timedOut } = await safeGetSession('invite-email');
      const jwt = timedOut ? null : sessionData.session?.access_token;
      if (!jwt) {
        // Show the link anyway so the admin can copy/share it manually.
        setNewLink(link);
        setCopied(false);
        toast.error(timedOut
          ? 'Auth check timed out — link generated but email not sent'
          : 'Not signed in — link generated but email not sent');
        return;
      }

      // 3) POST to the same-origin email route. Relative path is
      //    deliberate: hitting `/api/...` keeps us on the current
      //    origin (the canonical Vercel URL strips the Authorization
      //    header on cross-origin redirects).
      const inviterName =
        (profile?.full_name && profile.full_name.trim()) ||
        (profile?.username && profile.username.trim()) ||
        'An admin';
      const resp = await fetch('/api/send-invite-email', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${jwt}`,
        },
        body: JSON.stringify({
          token: data.token,
          invitee_email: email,
          board_name: scope === 'workspace' ? '' : boardName,
          role,
          inviter_name: inviterName,
        }),
      });
      const payload = await resp.json().catch(() => null) as
        | { sent?: boolean; id?: string | null; error?: string; resend?: { message?: string } }
        | null;

      if (!resp.ok || !payload?.sent) {
        // Surface server's error verbatim. Still show the generated
        // link so the admin can fall back to manual sharing.
        setNewLink(link);
        setCopied(false);
        const errMsg =
          payload?.resend?.message
          || payload?.error
          || `Send failed (HTTP ${resp.status})`;
        toast.error(errMsg);
        return;
      }

      setNewLink(link);
      setCopied(false);
      toast.success(`Invite emailed to ${email}`);
    } catch (err) {
      toast.error(err instanceof Error ? err.message : 'Could not send invite');
    } finally {
      setSending(false);
    }
  };

  const onCopy = async () => {
    if (!newLink) return;
    try {
      await navigator.clipboard.writeText(newLink);
      setCopied(true);
      toast.success('Link copied');
      setTimeout(() => setCopied(false), 2000);
    } catch {
      toast.error('Copy failed — select and copy manually');
    }
  };

  // Reset transient state when modal re-opens
  const handleClose = () => {
    setNewLink(null);
    setCopied(false);
    setInviteeEmail('');
    onClose();
  };

  return (
    <Modal open={open} onClose={handleClose} title={`Invite people — ${boardName}`} size="md">
      <div className="space-y-5">
        {/* Role — three-option selector. Backend (create_invite RPC,
            migrations 0020 / 0023 / 0056) accepts admin/manager/viewer.
            accept_invite (0056) writes board_subscribers with
            group_id = NULL plus an ACL grant per the invite scope. */}
        <Section label="Role">
          <div className="flex items-stretch gap-2">
            <RoleChoice
              value="admin"   current={role} onSelect={setRole}
              label="Admin"   hint="Full access — manage boards, columns, users, everything."
            />
            <RoleChoice
              value="manager" current={role} onSelect={setRole}
              label="Manager" hint="Assigned board(s) only; can change Status + post comments."
            />
            <RoleChoice
              value="viewer"  current={role} onSelect={setRole}
              label="Viewer"  hint="Read-only — can view the board but cannot edit anything."
            />
          </div>
        </Section>

        {/* Scope: whole workspace / whole board / specific group */}
        <Section label="Scope">
          <div className="flex items-center gap-2 mb-2">
            <ScopeChoice
              value="board"
              current={scope}
              onSelect={(v) => { setScope(v); if (v !== 'group') setGroupId(null); }}
              icon={<Lock className="h-4 w-4" />}
              label="This board"
              hint={boardName}
            />
            <ScopeChoice
              value="group"
              current={scope}
              onSelect={(v) => { setScope(v); if (v !== 'group') setGroupId(null); }}
              icon={<Lock className="h-4 w-4" />}
              label="Specific group"
              hint="One group on this board"
            />
            <ScopeChoice
              value="workspace"
              current={scope}
              onSelect={(v) => { setScope(v); if (v !== 'group') setGroupId(null); }}
              icon={<Globe className="h-4 w-4" />}
              label="Whole workspace"
              hint="No board attached"
            />
          </div>
          {scope === 'group' && (
            <div className="relative">
              <select
                value={groupId ?? ''}
                onChange={(e) => setGroupId(e.target.value || null)}
                className="input pr-8 appearance-none w-full"
              >
                <option value="">Pick a group…</option>
                {(groups ?? []).map((g) => (
                  <option key={g.id} value={g.id}>{g.name}</option>
                ))}
              </select>
              <ChevronDown className="absolute right-2 top-1/2 -translate-y-1/2 h-4 w-4 text-text-secondary pointer-events-none" />
              <p className="text-[11px] text-text-secondary mt-1">
                The invitee will see only this group's tasks on this board. Other groups stay hidden.
              </p>
            </div>
          )}
        </Section>

        {/* Expires — four options now, including "Never". */}
        <Section label="Expires after">
          <div className="flex items-center gap-2">
            <ExpiresChoice value={24}   current={expires} onSelect={setExpires} label="24 hours" />
            <ExpiresChoice value={168}  current={expires} onSelect={setExpires} label="7 days" />
            <ExpiresChoice value={720}  current={expires} onSelect={setExpires} label="30 days" />
            <ExpiresChoice value={null} current={expires} onSelect={setExpires} label="Never" />
          </div>
          {expires === null && (
            <p className="text-[11px] text-warning mt-1.5">
              Never-expiring invites stay valid until you revoke them. Use sparingly.
            </p>
          )}
        </Section>

        {/* Invitee email — optional. When filled, "Send Invite" emails
            the branded invite via /api/send-invite-email (admin-only,
            JWT-gated). Leaving it blank keeps "Generate invite link"
            working exactly as before — the email is a pure add-on. */}
        <Section label="Invitee email (optional)">
          <div className="relative">
            <Mail className="absolute left-2.5 top-1/2 -translate-y-1/2 h-4 w-4 text-text-secondary pointer-events-none" />
            <input
              type="email"
              autoComplete="off"
              spellCheck={false}
              placeholder="person@example.com"
              value={inviteeEmail}
              onChange={(e) => setInviteeEmail(e.target.value)}
              className="input pl-8 w-full"
            />
          </div>
          <p className="text-[11px] text-text-secondary mt-1">
            Leave blank to just generate a link you'll share manually.
          </p>
        </Section>

        {/* Generate / Send / copy row */}
        <div>
          {!newLink ? (
            <div className="flex items-stretch gap-2">
              <button
                type="button"
                onClick={() => void onGenerate()}
                disabled={create.isPending || sending}
                className="btn-ghost flex-1 inline-flex items-center justify-center gap-2 border border-border-light"
              >
                {create.isPending && !sending && <Spinner className="h-3 w-3" />}
                <Link2 className="h-4 w-4" />
                Generate invite link
              </button>
              <button
                type="button"
                onClick={() => void onSendInvite()}
                disabled={sending || create.isPending}
                className="btn-primary flex-1 inline-flex items-center justify-center gap-2"
              >
                {sending && <Spinner className="h-3 w-3" />}
                <Mail className="h-4 w-4" />
                Send Invite
              </button>
            </div>
          ) : (
            <div className="space-y-2">
              <div className="flex items-center gap-2">
                <input
                  readOnly
                  value={newLink}
                  className="input flex-1 font-mono text-[12px]"
                  onClick={(e) => (e.target as HTMLInputElement).select()}
                />
                <button
                  type="button"
                  onClick={() => void onCopy()}
                  className={cn('btn-primary h-9 px-3 inline-flex items-center gap-1.5', copied && 'bg-success hover:bg-success')}
                >
                  {copied ? <Check className="h-4 w-4" /> : <Copy className="h-4 w-4" />}
                  {copied ? 'Copied' : 'Copy'}
                </button>
              </div>
              <p className="text-[13px] text-text-secondary">
                Anyone with this link can claim {role === 'admin' ? 'an' : 'a'} {role} account
                {scope === 'workspace'
                  ? ' in the workspace.'
                  : scope === 'group'
                  ? ' scoped to the selected group on this board.'
                  : ' subscribed to this board.'}
                {' '}Share it on WhatsApp / Signal / etc. — it's single-use and{' '}
                {expires === null
                  ? 'never expires (revoke it manually when no longer needed).'
                  : expires === 24
                  ? 'expires in 24 hours.'
                  : expires === 168
                  ? 'expires in 7 days.'
                  : 'expires in 30 days.'}
              </p>
              <button
                type="button"
                onClick={() => setNewLink(null)}
                className="btn-ghost h-8 text-[13px]"
              >
                Generate another
              </button>
            </div>
          )}
        </div>

        {/* Outstanding invites */}
        <div className="pt-4 border-t border-border-light">
          <h3 className="text-sm font-semibold mb-2">Outstanding invites</h3>
          {list.isLoading ? (
            <div className="flex items-center justify-center py-6">
              <Spinner className="h-5 w-5 text-brand" />
            </div>
          ) : !list.data || list.data.length === 0 ? (
            <EmptyMessage
              title="No invites yet"
              description="Generated links will show here so you can revoke or re-share them."
            />
          ) : (
            <ul className="space-y-2 max-h-[240px] overflow-y-auto">
              {list.data.map((inv) => (
                <InviteListItem
                  key={inv.id}
                  invite={inv}
                  onRevoke={async () => {
                    if (!window.confirm('Revoke this invite? The link will stop working immediately.')) return;
                    try {
                      await revoke.mutateAsync({ id: inv.id, boardId: scope === 'workspace' ? null : boardId });
                      toast.success('Invite revoked');
                    } catch (err) {
                      toast.error(err instanceof Error ? err.message : 'Revoke failed');
                    }
                  }}
                />
              ))}
            </ul>
          )}
        </div>
      </div>
    </Modal>
  );
}

// ---------------------------------------------------------------------
function InviteListItem({ invite, onRevoke }: { invite: InviteRow; onRevoke: () => void }) {
  const state = useMemo(() => deriveState(invite), [invite]);
  return (
    <li className="flex items-center gap-3 border border-border-light rounded-base p-2.5 bg-app/30">
      <RoleBadge role={invite.role} />
      <div className="flex-1 min-w-0">
        <p className="text-[13px] text-text-secondary truncate">
          {state.label}
          {' · '}
          {invite.expires_at
            ? `expires ${new Date(invite.expires_at).toLocaleDateString()}`
            : 'never expires'}
        </p>
        <p className="text-[11px] text-text-disabled font-mono truncate">
          {invite.token}
        </p>
      </div>
      <span className={cn(
        'inline-flex items-center h-5 px-2 rounded-pill text-[10px] uppercase tracking-wide font-medium',
        state.kind === 'active'   && 'bg-success/15 text-success',
        state.kind === 'used'     && 'bg-text-secondary/15 text-text-secondary',
        state.kind === 'expired'  && 'bg-warning/15 text-warning',
        state.kind === 'revoked'  && 'bg-error/15 text-error',
      )}>
        {state.kind}
      </span>
      {state.kind === 'active' && (
        <button
          type="button"
          onClick={onRevoke}
          aria-label="Revoke"
          title="Revoke"
          className="h-7 w-7 inline-flex items-center justify-center rounded-base text-error hover:bg-error/10"
        >
          <Trash2 className="h-3.5 w-3.5" />
        </button>
      )}
    </li>
  );
}

function deriveState(inv: InviteRow): { kind: 'active' | 'used' | 'expired' | 'revoked'; label: string } {
  if (inv.revoked_at) return { kind: 'revoked', label: 'Revoked' };
  if (inv.used_at)    return { kind: 'used',    label: `Used ${new Date(inv.used_at).toLocaleDateString()}` };
  // Null expires_at ⇒ never expires (migration 0037).
  if (inv.expires_at && new Date(inv.expires_at) <= new Date()) {
    return { kind: 'expired', label: 'Expired' };
  }
  return { kind: 'active', label: 'Active' };
}

// ---------------------------------------------------------------------
function Section({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <section>
      <p className="text-[13px] uppercase tracking-wide text-text-secondary font-medium mb-1.5">{label}</p>
      {children}
    </section>
  );
}

function ScopeChoice<T extends string>({
  value, current, onSelect, icon, label, hint,
}: {
  value: T; current: T; onSelect: (v: T) => void;
  icon: React.ReactNode; label: string; hint: string;
}) {
  const active = value === current;
  return (
    <button
      type="button"
      onClick={() => onSelect(value)}
      className={cn(
        'flex-1 rounded-base border p-2.5 text-left transition-colors flex items-center gap-2',
        active ? 'border-brand bg-brand/10' : 'border-border-light hover:bg-hover',
      )}
    >
      <span className={active ? 'text-brand' : 'text-text-secondary'}>{icon}</span>
      <div className="min-w-0">
        <p className={cn('text-sm font-medium', active && 'text-brand')}>{label}</p>
        <p className="text-[11px] text-text-secondary truncate">{hint}</p>
      </div>
    </button>
  );
}

// Three-option role chip — same visual rhythm as ScopeChoice but
// driven by a UserRole + a small RoleBadge inside the chip.
function RoleChoice({
  value, current, onSelect, label, hint,
}: {
  value: UserRole;
  current: UserRole;
  onSelect: (v: UserRole) => void;
  label: string;
  hint: string;
}) {
  const active = value === current;
  return (
    <button
      type="button"
      onClick={() => onSelect(value)}
      className={cn(
        'flex-1 rounded-base border p-2.5 text-left transition-colors flex items-start gap-2',
        active ? 'border-brand bg-brand/10' : 'border-border-light hover:bg-hover',
      )}
      aria-pressed={active}
    >
      <span className="shrink-0 mt-0.5"><RoleBadge role={value} /></span>
      <span className="min-w-0">
        <p className={cn('text-sm font-medium', active && 'text-brand')}>{label}</p>
        <p className="text-[11px] text-text-secondary">{hint}</p>
      </span>
    </button>
  );
}

// Accepts either a number (hours) or null (never expires). The state in
// the parent is `24 | 168 | 720 | null`; we generalize so the same chip
// component can render the "Never" choice too.
function ExpiresChoice<T extends number | null>({
  value, current, onSelect, label,
}: { value: T; current: T; onSelect: (v: T) => void; label: string }) {
  const active = value === current;
  return (
    <button
      type="button"
      onClick={() => onSelect(value)}
      className={cn(
        'flex-1 h-9 rounded-base border text-sm font-medium transition-colors',
        active ? 'border-brand bg-brand/10 text-brand' : 'border-border-light hover:bg-hover text-text-secondary',
      )}
    >
      {label}
    </button>
  );
}
