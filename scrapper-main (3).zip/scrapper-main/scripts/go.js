'use strict';

// One-command launcher: starts the web dashboard AND opens it in the browser.
// Usage: npm run go
process.env.AUTO_OPEN = 'true';
require('../server/server.js');
