#!/usr/bin/env node
'use strict';

const readline = require('readline');
const { analyze } = require('./src/ai/promptAnalyzer');
const { isComplete } = require('./src/ai/planSchema');
const { runSession } = require('./src/orchestrator');
const { SessionControl } = require('./src/control/sessionControl');

/**
 * CLI entry: node index.js --url <url> --prompt "<request>"
 * Missing args are asked interactively. AI follow-up questions are resolved
 * before crawling begins.
 */
async function main() {
  const args = parseArgs(process.argv.slice(2));

  let url = args.url || '';
  let prompt = args.prompt || '';

  if (!prompt) {
    prompt = await ask('What would you like to scrape? (e.g. "all reviews") ');
  }
  if (!url) {
    url = await ask('Website URL (https://...): ');
  }

  // Run the AI planner ("brain").
  let { plan, source, error } = await analyze(prompt, { url });
  log(`[planner] using ${source}${error ? ` (ai error: ${error})` : ''}`);

  // Resolve any follow-up questions the planner raised.
  plan = await resolveQuestions(plan, { url, prompt });

  if (!isComplete(plan)) {
    log('[planner] still missing required info — aborting.');
    process.exitCode = 1;
    return;
  }

  log(`[plan] site=${plan.siteName} type=${plan.siteType} strategy=${plan.scrollStrategy}`);
  log(`[plan] url=${plan.url}`);

  const control = new SessionControl();

  const summary = await runSession({
    plan,
    control,
    userPrompt: prompt,
    onStatus: printStatus,
    // Called ONLY when a halting error interrupts the run (a normal run never pauses).
    askContinue: async (info) => {
      const reason = (info && info.reason) || 'unknown error';
      log(`\n[run] Something interrupted the run: ${reason}`);
      log('[run] A checkpoint was saved (RAW kept). ');
      return control.askContinue('Continue scraping? (yes/no) ');
    },
  });

  log('\n=== Session complete ===');
  const last = summary.batches[summary.batches.length - 1] || {};
  log(`Pages visited: ${summary.pages != null ? summary.pages : 1} | Filtered items: ${summary.totalReviews} | RAW blocks: ${last.rawLines || 0}`);
  log('\nOutput files:');
  if (last.file) log(`  Filtered : ${require('path').resolve(last.file)}`);
  if (last.rawFile) log(`  RAW      : ${require('path').resolve(last.rawFile)}`);
  log('\n(RAW is always produced — even if the AI filter is unavailable.)');
}

function parseArgs(argv) {
  const out = {};
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a === '--url') out.url = argv[++i];
    else if (a === '--prompt') out.prompt = argv[++i];
    else if (a.startsWith('--url=')) out.url = a.slice(6);
    else if (a.startsWith('--prompt=')) out.prompt = a.slice(9);
  }
  return out;
}

async function resolveQuestions(plan, ctx) {
  let current = plan;
  let guard = 0;
  while (current.missingInfoQuestions.length > 0 && guard < 5) {
    guard++;
    const q = current.missingInfoQuestions[0];
    const answer = await ask(`[question] ${q}\n> `);
    // Re-plan with the new info folded into the prompt/url.
    const maybeUrl = /https?:\/\//i.test(answer) ? answer.trim() : ctx.url;
    const merged = `${ctx.prompt}\n${q} ${answer}`.trim();
    const res = await analyze(merged, { url: maybeUrl });
    current = res.plan;
    ctx = { url: maybeUrl, prompt: merged };
  }
  return current;
}

function printStatus(s) {
  if (s.type === 'progress' && s.phase === 'scroll') {
    process.stdout.write(`\r[crawl] batch ${s.batch} round ${s.rounds}   `);
  } else if (s.type === 'progress' && s.phase === 'load_more') {
    process.stdout.write(`\n[crawl] clicked "load more"\n`);
  } else if (s.type === 'raw') {
    process.stdout.write(`\r[raw] batch ${s.batch}: ${s.total} raw lines so far   `);
  } else if (s.type === 'raw_saved') {
    log(`\n[raw] saved ${s.count} lines → ${rel(s.file)}`);
  } else if (s.type === 'filtering') {
    log(`[ai] filtering ${s.rawLines} raw lines with Gemini…`);
  } else if (s.type === 'filtered_saved') {
    const via = s.via === 'local' ? ' (via local cleaner — Gemini unavailable)' : s.via === 'mixed' ? ' (via Gemini + local cleaner)' : ' (via Gemini)';
    log(`[filter] saved ${s.count} item(s)${via} → ${rel(s.file)}`);
  } else if (s.type === 'filter_note') {
    log(`[ai] no matches (${s.reason}) — RAW kept; note written to clean file`);
  } else if (s.type === 'batch_start') {
    log(`\n[batch ${s.batch}] starting → ${s.url}`);
  }
}

function gitText(git) {
  if (!git) return 'n/a';
  if (git.reason === 'disabled') return 'disabled';
  if (git.committed && git.pushed) return 'committed + pushed';
  if (git.committed) return `committed (${git.reason || 'not pushed'})`;
  return git.reason || 'skipped';
}

function ask(question) {
  const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
  return new Promise((resolve) => rl.question(question, (a) => { rl.close(); resolve(a.trim()); }));
}

function rel(p) {
  return require('path').relative(process.cwd(), p);
}

function log(msg) {
  process.stdout.write(msg + '\n');
}

main().catch((err) => {
  process.stderr.write(`\n[fatal] ${err.stack || err.message}\n`);
  process.exit(1);
});
