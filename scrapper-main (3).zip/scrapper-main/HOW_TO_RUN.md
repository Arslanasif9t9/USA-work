# How to Run This Scraper (Plain-Language Guide)

This guide is written so a **non-technical person** (or **Claude Code** acting on their
behalf) can set up and run the scraper without knowing any commands by heart.

> What this tool does: you give it a website link and say what you want (e.g.
> "all customer reviews"). It visits the page(s), pulls the text, uses AI to keep
> only the parts you asked for, and saves them as plain `.txt` files on your computer.
> A full-text **RAW** file is **always** saved as a safety net — even if the AI is busy.

---

## For a brand-new PC (easiest — just double-click)

No commands needed. On Windows:

1. **Double-click `FIRST_TIME_SETUP.bat`** (run it once). It installs everything and
   creates a `.env` file for you.
2. **Open `.env`** and replace `PASTE_YOUR_KEY_HERE` with your Google Gemini key
   (get a free one at https://aistudio.google.com/app/apikey), then save the file.
3. **Double-click `START.bat`** every time you want to use it — the server starts and
   your browser opens the dashboard automatically. Type a website URL + what to extract,
   then click **Start**.

> No key yet, or Gemini is busy? It still works — a built-in **local cleaner** produces
> the clean reviews file, and the **RAW** full-text file is **always** saved.

The sections below explain the same thing in more detail (and the command-line way).

---

## Part 1 — First-time setup (do this once)

1. **Install Node.js** (version 18 or newer).
   - Check if it's already there: `node --version`
   - If that errors, install from https://nodejs.org (the "LTS" version), then reopen the terminal.

2. **Open a terminal in this project folder** (the folder that contains `package.json`).

3. **Install the project + browser engine** (one command):
   ```
   npm run setup
   ```
   This runs `npm install` and downloads the Chromium browser Playwright uses.
   (Equivalent to: `npm install` then `npx playwright install chromium`.)

4. **Create your `.env` file** (holds your AI key). Copy the example:
   - Windows: `copy .env.example .env`
   - Mac/Linux: `cp .env.example .env`

   Then open `.env` and set:
   ```
   GEMINI_API_KEY=your_key_here
   GEMINI_MODEL=gemini-2.5-flash
   GIT_SYNC=false
   ```
   - **Where to get a key:** https://aistudio.google.com/app/apikey (free). Paste it after `GEMINI_API_KEY=`.
   - `GEMINI_MODEL` can stay `gemini-2.5-flash`.
   - `GIT_SYNC=false` unless you specifically want results auto-pushed to GitHub.

   > No key yet? The tool still runs and always saves the **RAW** text file; the
   > AI-filtered file just won't be produced until a key is set.

---

## Part 2 — Two ways to run

### (A) The Dashboard — easiest, point-and-click

1. Start it with **one command**:
   ```
   npm run go
   ```
2. Your **browser opens automatically** to the dashboard (usually http://localhost:3000).
   If it doesn't open, the terminal prints the exact link to click.
3. In the page:
   - Type the **Website URL** (e.g. `https://www.trustpilot.com/review/www.keen.com`).
   - Type **what to extract** (e.g. `extract all customer reviews`).
   - Click **Start scraping**.
4. While it runs you'll see live progress (pages opened, items found, time used).
   - **Finish now** — stop the current crawl pass but save everything collected.
   - **Stop** — end the whole run; already-saved work stays.
   - The run goes continuously until the time limit; it only pauses to ask
     **Continue / Stop** if something goes wrong (e.g. a page error).
5. **History tab** — lists every output file with counts/sizes; download or view/edit any file.
6. **Settings tab** — change the **Save location**, total run time, checkpoint interval,
   max pages, headless on/off, deep-crawl on/off, and auto-git-push. Click **Save settings**.
   Changes take effect on the **next run** (no restart needed).
7. To stop the server, press **Ctrl+C** in the terminal.

### (B) Direct command — one line, no browser

```
npm run scrape -- --url "https://www.trustpilot.com/review/www.keen.com" --prompt "extract all customer reviews"
```
- Replace the URL and the prompt with whatever you want.
- When it finishes it prints the **exact output file paths** (Filtered + RAW).
- Tip: leave `--url`/`--prompt` off and it will ask you for them interactively.

---

## Part 3 — Where the output goes

- Files are saved under the **Save location** (Settings → Save location).
  - **Default:** your Desktop in a folder named `raw_data`
    (e.g. `C:\Users\YOU\Desktop\raw_data`). It's created automatically if missing.
- For each run you get, under `…/<save location>/<site_name>/`:
  - `batch_001.txt` — the **AI-filtered** result (numbered records, blank line between each).
  - `batch_001_RAW.txt` — the **RAW** full-text safety net (always produced).
- **Deep-crawl** (on by default) follows sub-pages on the same website; the output
  groups each page under a `--- from: <url> ---` marker.

---

## Part 4 — Common issues & quick fixes

- **"Executable doesn't exist" / Chromium not installed**
  Run: `npx playwright install chromium`

- **AI filter says "429 / quota exceeded"**
  Google's free AI quota for the day is used up. Either wait for it to reset, or put a
  **new `GEMINI_API_KEY`** in `.env`. Your **RAW** files are still saved in the meantime.

- **"Port 3000 is busy" / dashboard won't start**
  `npm run go` now **auto-picks the next free port** and opens that instead (it prints
  the link). If you want to free port 3000, stop the old server:
  - Windows: `npx kill-port 3000`  (or close the other terminal / Ctrl+C in it)
  - Mac/Linux: `lsof -ti:3000 | xargs kill`

- **Browser didn't open automatically**
  Just click the link the terminal prints (e.g. `http://localhost:3000`).

- **Want to see the browser work (not headless)?**
  Settings → turn **Headless** off (needs a real desktop screen).

---

## If Gemini is down and the clean file is empty

The project already handles this automatically: if Gemini fails (429 / quota / offline)
**or** returns nothing, it runs a built-in **local cleaner** (no AI) on the same RAW text
and writes real review records to `batch_xxx.txt`. The log will say
**"Filtered via local cleaner (Gemini unavailable)"**. So in almost all cases the clean
file is populated even with no AI.

**Only if the local cleaner ALSO produced nothing** (the clean file is just a one-line
"No matching content found …" note), Claude Code should do this as a last resort:

1. Find the newest `*_RAW.txt` under the **Save location** (Settings → Save location,
   default `C:\Users\<you>\Desktop\raw_data\<site_name>\batch_xxx_RAW.txt`).
2. Read that RAW file.
3. From the RAW text, keep ONLY genuine review/testimonial text — drop navigation,
   headers/footers, ads, cookie/consent text, marketing copy, prices, rating/number-only
   lines, bios/about, AI-summary blurbs, and UI labels (login, sign up, chat, voice call,
   more filters, show more, etc.). If a short reviewer-name line precedes a review, keep it
   as the record's first line.
4. Write the result back **next to the RAW file** as `batch_xxx.txt` (overwriting the
   empty note), in the SAME format the tool uses:
   ```
   --- from: <page url> ---

   [1]
   <reviewer name (if any)>
   <review text>

   [2]
   <review text>
   ```
5. Also **show the cleaned reviews in the chat** so the user sees them immediately.

> Reminder: the project's own filter (Gemini → local cleaner) is the primary path. Only do
> this manual step if the local cleaner also produced nothing. Never delete the RAW file.

## Quick reference (commands)

| Goal | Command |
|------|---------|
| One-time setup | `npm run setup` |
| Open the dashboard (auto-opens browser) | `npm run go` |
| Run one scrape from the command line | `npm run scrape -- --url "<URL>" --prompt "<what to extract>"` |
| Start the server without auto-open | `npm run web` |
| Run the built-in tests | `npm test` |

---

## Notes for Claude Code (when a user says "run this project")

1. Confirm setup: check `node --version`; if `node_modules` is missing run `npm run setup`;
   ensure `.env` exists with `GEMINI_API_KEY` (ask the user for a key from
   https://aistudio.google.com/app/apikey if absent — but the RAW path works without it).
2. If the user wants to click around → run `npm run go` (it opens the browser).
   If the user just wants results for a specific site → run
   `npm run scrape -- --url "<their URL>" --prompt "<their request>"` and then report the
   printed output file paths back to them.
3. After a run, tell the user the exact saved file paths (the CLI prints them; for the
   dashboard, point them to the **History** tab and the Save location).
4. Never delete anything in `raw_data/` or `memory/`.
