'use strict';

/**
 * Single source of truth for turning a status event into:
 *  - a plain-English one-line description (for the server log + activity feed), and
 *  - a coarse "phase" label shown prominently in the dashboard.
 *
 * Used by the web server so the browser doesn't need its own copy of this logic.
 */

function describeEvent(ev) {
  if (!ev || !ev.type) return null;
  switch (ev.type) {
    case 'config':
      return `Loaded per-site config for ${ev.siteName}`;
    case 'browser':
      if (ev.phase === 'launching') return `Launching browser (headless=${ev.headless})`;
      if (ev.phase === 'launched') return 'Browser launched';
      if (ev.phase === 'launch_failed') return `Browser failed to launch (${ev.message})`;
      return 'Browser';
    case 'batch_start':
      return `Batch ${ev.batch} starting → ${ev.url}`;
    case 'file_created':
      return `Files created → clean: ${shortPath(ev.file)} | raw: ${shortPath(ev.rawFile)}`;
    case 'raw':
      return `Raw dump +${ev.newCount} line(s) — ${ev.total} total`;
    case 'raw_saved':
      return `RAW text saved: ${ev.count} line(s) → ${shortPath(ev.file)}`;
    case 'settings':
      return `Save location: ${ev.saveLocation}` + (ev.saveLocationOk ? '' : ' (could not create — using project raw_data)');
    case 'page':
      return `Opening page ${ev.index}/${ev.maxPages}: ${ev.url} (queue: ${ev.queued})`;
    case 'links':
      return `${ev.source === 'heuristic' ? 'Heuristic' : 'AI'} picked ${ev.picked} of ${ev.candidates} link(s) — +${ev.added} queued (queue: ${ev.queued})`;
    case 'links_error':
      return `Link selection skipped: ${ev.message}`;
    case 'filtering':
      return `${ev.checkpoint === 'final' ? 'Final checkpoint' : 'Checkpoint'}: AI-filtering ${ev.rawLines} new raw line(s)…`;
    case 'filtered_saved': {
      const via =
        ev.via === 'local' ? ' — Filtered via local cleaner (Gemini unavailable)'
        : ev.via === 'mixed' ? ' — Filtered via Gemini + local cleaner'
        : ' — Filtered via Gemini';
      return `Checkpoint saved: +${ev.added != null ? ev.added : ev.count} item(s) (total ${ev.count})${via} → ${shortPath(ev.file)}`;
    }
    case 'checkpoint_failed':
      return `Checkpoint filter failed (${ev.reason}) — will retry next checkpoint; RAW already on disk`;
    case 'filter_note':
      return `AI filter produced nothing (${ev.reason}) — RAW kept; note written to clean file`;
    case 'progress':
      return describeProgress(ev);
    case 'reviews':
      return `Found +${ev.newCount} review(s) — ${ev.total} this batch`;
    case 'saving':
      return ev.count
        ? `Saving ${ev.count} review(s) → ${shortPath(ev.file)}`
        : `0 extracted — file created at ${shortPath(ev.file)}`;
    case 'batch_done':
      return `Batch ${ev.batch} done: ${ev.newReviews} review(s)` +
        (ev.file ? ` → ${shortPath(ev.file)}` : '') +
        (ev.git ? ` | git: ${gitText(ev.git)}` : '');
    case 'run_error':
      return `Something interrupted the run: ${ev.reason}`;
    case 'page_issue':
      return `Page issue (${ev.reason}) — continuing with queued pages`;
    case 'awaiting_decision':
      return ev.reason
        ? `Interrupted: ${ev.reason}. Continue scraping? (Continue / Stop)`
        : 'Waiting for Continue or Stop';
    case 'session_done':
      return `Session complete — ${ev.totalReviews} review(s) across ${
        (ev.batches && ev.batches.length) || 0
      } batch(es)`;
    case 'error':
      return `Error: ${ev.message}`;
    default:
      return null;
  }
}

function describeProgress(ev) {
  switch (ev.phase) {
    case 'navigating':
      return `Navigating to ${ev.url}`;
    case 'page_loaded':
      return 'Page DOM loaded';
    case 'networkidle':
      return 'Network idle reached';
    case 'networkidle_timeout':
      return 'Network idle timed out — continuing anyway';
    case 'await_content':
      return 'Waiting for review content to render…';
    case 'page_blocked':
      return `Page blocked or no content (${ev.reason || 'unknown'})`;
    case 'nav_failed':
      return `Navigation failed: ${ev.message}`;
    case 'scroll':
      return `Scrolling — round ${ev.rounds}`;
    case 'renavigate':
      return `Re-settling after navigation (round ${ev.rounds})`;
    case 'load_more':
      return 'Clicked "load more" / next page';
    case 'extract_error':
      return `Extract error: ${ev.message}`;
    case 'done':
      return `Crawl finished (${ev.reason}) after ${ev.rounds} round(s)`;
    default:
      return ev.phase || 'working';
  }
}

/** Coarse phase label for the big status line. Returns null to keep the previous phase. */
function phaseOf(ev) {
  if (!ev || !ev.type) return null;
  if (ev.type === 'browser') {
    if (ev.phase === 'launched') return 'Browser ready';
    if (ev.phase === 'launch_failed') return 'Browser failed';
    return 'Launching browser';
  }
  if (ev.type === 'batch_start') return 'Starting batch';
  if (ev.type === 'page') return `Opening page ${ev.index}/${ev.maxPages}`;
  if (ev.type === 'links') return 'Choosing links (AI)';
  if (ev.type === 'reviews') return 'Extracting reviews';
  if (ev.type === 'raw') return 'Collecting raw text';
  if (ev.type === 'raw_saved') return 'Raw text saved';
  if (ev.type === 'filtering') return 'AI filtering';
  if (ev.type === 'filtered_saved') return 'Filtered result saved';
  if (ev.type === 'filter_note') return 'No AI matches';
  if (ev.type === 'run_error') return 'Interrupted — awaiting choice';
  if (ev.type === 'page_issue') return 'Page issue — continuing';
  if (ev.type === 'saving') return 'Saving file';
  if (ev.type === 'batch_done') return 'Batch done';
  if (ev.type === 'awaiting_decision') return 'Waiting for your choice';
  if (ev.type === 'session_done') return 'Done';
  if (ev.type === 'error') return 'Error';
  if (ev.type === 'progress') {
    switch (ev.phase) {
      case 'navigating':
      case 'page_loaded':
      case 'networkidle':
      case 'networkidle_timeout':
      case 'await_content':
        return 'Loading page';
      case 'page_blocked':
        return 'Blocked / no content';
      case 'nav_failed':
        return 'Navigation failed';
      case 'scroll':
        return `Scrolling (round ${ev.rounds})`;
      case 'renavigate':
        return 'Re-settling';
      case 'load_more':
        return 'Loading more';
      case 'done':
        return 'Crawl finished';
      default:
        return null;
    }
  }
  return null;
}

function gitText(git) {
  if (!git) return 'n/a';
  if (git.reason === 'disabled') return 'disabled';
  if (git.committed && git.pushed) return 'committed + pushed';
  if (git.committed) return `committed (${git.reason || 'not pushed'})`;
  return git.reason || 'skipped';
}

function shortPath(p) {
  if (!p) return '';
  const parts = String(p).split(/[\\/]/);
  return parts.slice(-3).join('/');
}

module.exports = { describeEvent, phaseOf, gitText, shortPath };
