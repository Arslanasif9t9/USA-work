'use strict';

const readline = require('readline');
const config = require('../config');

/**
 * Scraping control:
 *  - Bounds each batch by a time guard (random point in [MIN_BATCH_MS, MAX_BATCH_MS]).
 *  - Exposes a stop flag the crawler polls (manual pause / SIGINT).
 *  - Asks the user "Continue scraping next batch? (yes/no)" between batches (CLI).
 *  - Handles SIGINT so an in-flight batch can finish + flush before exit.
 */
class SessionControl {
  constructor(opts = {}) {
    this._stop = false;
    this._finish = false;
    this._sigintHandler = null;
    this.onInterrupt = opts.onInterrupt || null; // async cleanup hook
  }

  /** Returns a deadline timestamp for the current batch. */
  newDeadline() {
    return Date.now() + config.timing.totalRunMs;
  }

  shouldStop() {
    return this._stop;
  }

  requestStop() {
    this._stop = true;
  }

  /** Request the current batch to end immediately (without ending the session). */
  finishBatch() {
    this._finish = true;
  }

  shouldFinishBatch() {
    return this._finish;
  }

  reset() {
    this._stop = false;
    this._finish = false;
  }

  /** Install a SIGINT handler that flips the stop flag (and runs cleanup once). */
  installSignalHandler() {
    if (this._sigintHandler) return;
    let interrupted = false;
    this._sigintHandler = async () => {
      if (interrupted) {
        process.exit(130); // second Ctrl+C: hard exit
        return;
      }
      interrupted = true;
      this._stop = true;
      process.stdout.write(
        '\n[control] Interrupt received — finishing current batch and saving...\n'
      );
      if (this.onInterrupt) {
        try {
          await this.onInterrupt();
        } catch (_) {
          /* ignore cleanup errors on shutdown */
        }
      }
    };
    process.on('SIGINT', this._sigintHandler);
  }

  removeSignalHandler() {
    if (this._sigintHandler) {
      process.removeListener('SIGINT', this._sigintHandler);
      this._sigintHandler = null;
    }
  }

  /** CLI prompt between batches. Resolves true to continue, false to stop. */
  async askContinue(question = 'Continue scraping next batch? (yes/no) ') {
    if (this._stop) return false;
    const rl = readline.createInterface({
      input: process.stdin,
      output: process.stdout,
    });
    const answer = await new Promise((resolve) => rl.question(question, resolve));
    rl.close();
    return /^\s*(y|yes)\s*$/i.test(answer);
  }
}

module.exports = { SessionControl };
