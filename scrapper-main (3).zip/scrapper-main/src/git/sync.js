'use strict';

const fs = require('fs');
const path = require('path');
const config = require('../config');

let _git = null;
function git() {
  if (_git) return _git;
  const simpleGit = require('simple-git');
  _git = simpleGit(config.root);
  return _git;
}

async function isRepo() {
  try {
    return await git().checkIsRepo();
  } catch {
    return false;
  }
}

/**
 * Commit the new batch TXT + memory JSON, then pull --rebase and push.
 *
 * Team-safe:
 *  - rebase before push avoids overwriting teammates' commits,
 *  - skips entirely when there is nothing to commit (no empty/duplicate commits),
 *  - never force-pushes; surfaces conflicts for manual resolution.
 *
 * @returns {Promise<{committed:boolean, pushed:boolean, reason?:string}>}
 */
async function syncBatch(message, files = []) {
  if (!config.git.enabled) return { committed: false, pushed: false, reason: 'disabled' };

  if (!(await isRepo())) {
    return { committed: false, pushed: false, reason: 'not_a_git_repo' };
  }

  const g = git();

  // Stage only the files that exist (batch TXT + memory JSONs).
  const toAdd = files.filter((f) => f && fs.existsSync(f)).map((f) => path.relative(config.root, f));
  if (toAdd.length === 0) return { committed: false, pushed: false, reason: 'no_files' };
  await g.add(toAdd);

  const status = await g.status();
  if (status.staged.length === 0) {
    return { committed: false, pushed: false, reason: 'nothing_to_commit' };
  }

  await g.commit(message);

  // Try to integrate remote work then push.
  // --autostash stashes any leftover working-tree changes (e.g. Windows CRLF
  // renormalization) around the rebase so it can't fail with "unstaged changes".
  let pushed = false;
  let reason;
  try {
    await g.fetch(config.git.remote, config.git.branch).catch(() => {});
    await g.pull(config.git.remote, config.git.branch, { '--rebase': 'true', '--autostash': null });
    await g.push(config.git.remote, config.git.branch);
    pushed = true;
  } catch (err) {
    reason = `push_failed: ${err.message.split('\n')[0]}`;
  }

  return { committed: true, pushed, reason };
}

module.exports = { syncBatch, isRepo };
