'use strict';

const config = require('../config');

let cachedModel = null;

function isConfigured() {
  return Boolean(config.ai.apiKey);
}

function getModel() {
  if (cachedModel) return cachedModel;
  if (!isConfigured()) return null;
  // Lazy-require so the package isn't needed when running without AI.
  const { GoogleGenerativeAI } = require('@google/generative-ai');
  const genAI = new GoogleGenerativeAI(config.ai.apiKey);
  cachedModel = genAI.getGenerativeModel({
    model: config.ai.model,
    generationConfig: { responseMimeType: 'application/json' },
  });
  return cachedModel;
}

/**
 * Send a prompt to Gemini and parse a JSON object from the response.
 * Throws on network/parse errors so callers can fall back gracefully.
 */
async function generateJson(prompt) {
  const model = getModel();
  if (!model) throw new Error('GEMINI_API_KEY not configured');

  const result = await model.generateContent(prompt);
  const text = result.response.text();
  return parseJsonLoose(text);
}

/** Generate JSON using a specific model name (used for fallback on transient errors). */
async function generateJsonModel(modelName, prompt) {
  if (!isConfigured()) throw new Error('GEMINI_API_KEY not configured');
  const { GoogleGenerativeAI } = require('@google/generative-ai');
  const genAI = new GoogleGenerativeAI(config.ai.apiKey);
  const model = genAI.getGenerativeModel({
    model: modelName,
    generationConfig: { responseMimeType: 'application/json' },
  });
  const result = await model.generateContent(prompt);
  return parseJsonLoose(result.response.text());
}

// Configured model first, then alternates when the primary is transiently overloaded.
const FALLBACK_MODELS = ['gemini-2.5-flash-lite', 'gemini-flash-latest', 'gemini-2.5-flash'];

/**
 * Generate JSON with retry on transient errors (429/500/503) and model fallback.
 * Shared by the AI filter and the planner so neither fails on a transient hiccup.
 */
async function generateJsonResilient(prompt) {
  if (!isConfigured()) throw new Error('GEMINI_API_KEY not configured');
  const models = [...new Set([config.ai.model, ...FALLBACK_MODELS])];
  let lastErr;
  for (const modelName of models) {
    for (let attempt = 1; attempt <= 2; attempt++) {
      try {
        return await generateJsonModel(modelName, prompt);
      } catch (err) {
        lastErr = err;
        const transient = /\b(429|500|503)\b|overload|unavailable|experiencing|timed out|fetch failed/i.test(err.message);
        if (!transient) throw err; // real error (bad request, auth) — surface it
        await new Promise((r) => setTimeout(r, 800 * attempt));
      }
    }
  }
  throw lastErr;
}

function parseJsonLoose(text) {
  try {
    return JSON.parse(text);
  } catch {
    const start = text.indexOf('{');
    const end = text.lastIndexOf('}');
    if (start !== -1 && end > start) {
      return JSON.parse(text.slice(start, end + 1));
    }
    throw new Error('Gemini response was not valid JSON');
  }
}

module.exports = { isConfigured, generateJson, generateJsonModel, generateJsonResilient };
