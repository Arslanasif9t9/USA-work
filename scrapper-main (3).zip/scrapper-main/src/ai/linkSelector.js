'use strict';

const gemini = require('./geminiClient');

/**
 * Deep-crawl link intelligence.
 *
 * collectCandidateLinks(page, startHost): gather same-domain anchors with their
 *   visible text + nearby context (NOT url patterns).
 * selectLinks(candidates, userPrompt): ask Gemini which candidates are worth
 *   opening to find the content the user asked for. Returns a subset of hrefs.
 *   Reasoning is text/content based; we validate the AI's indices against the
 *   real candidate list so it can never invent URLs.
 */

const MAX_CANDIDATES = 80; // cap payload size sent to the model
const MAX_PICK = 30; // cap links enqueued per page

/** Strip a leading www. for host comparison. */
function normHost(host) {
  return String(host || '').replace(/^www\./i, '').toLowerCase();
}

async function collectCandidateLinks(page, startHost) {
  try {
    return await page.evaluate((args) => {
      const startHost = args.startHost;
      const max = args.max;
      const norm = (h) => String(h || '').replace(/^www\./i, '').toLowerCase();
      const out = [];
      const seen = new Set();
      const anchors = document.querySelectorAll('a[href]');
      for (const a of anchors) {
        const href = a.href; // resolved absolute URL
        if (!/^https?:/i.test(href)) continue;
        let host;
        try { host = norm(new URL(href).hostname); } catch { continue; }
        if (host !== startHost) continue; // same-domain only
        const clean = href.split('#')[0];
        if (seen.has(clean)) continue;
        seen.add(clean);
        const text = (a.innerText || a.textContent || '').replace(/\s+/g, ' ').trim().slice(0, 100);
        let context = '';
        const p = a.closest('li, article, [class*="card" i], [class*="item" i], td, tr, div');
        if (p) context = (p.innerText || '').replace(/\s+/g, ' ').trim().slice(0, 180);
        if (!text && !context) continue;
        out.push({ href: clean, text, context });
        if (out.length >= max) break;
      }
      return out;
    }, { startHost: normHost(startHost), max: MAX_CANDIDATES });
  } catch {
    return [];
  }
}

/**
 * Choose which candidate links to open next.
 * Returns { hrefs, source } where source is 'ai' | 'heuristic' | 'none'.
 *
 * AI-first, with a guaranteed NON-AI heuristic fallback so deep crawl keeps
 * visiting subpages even when Gemini is unavailable (e.g. 429 quota).
 *
 * @param {object} [opts] - { forceNoAI } to skip the AI path (also honored via
 *   the DISABLE_AI_LINKS env var) for testing the fallback.
 */
async function selectLinks(candidates, userPrompt, opts = {}) {
  if (!candidates || !candidates.length) return { hrefs: [], source: 'none' };

  const forceNoAI = opts.forceNoAI || String(process.env.DISABLE_AI_LINKS).toLowerCase() === 'true';

  // 1) AI selection (primary).
  if (!forceNoAI && gemini.isConfigured()) {
    try {
      const list = candidates
        .map((c, i) => `[${i}] text="${c.text}" context="${truncate(c.context, 160)}"`)
        .join('\n');
      const instruction = [
        'You decide which links on a web page to open NEXT to find the content the user wants.',
        `USER WANTS: "${userPrompt || 'the main content items / reviews'}"`,
        '',
        'Below are candidate links with their visible text and nearby context, each with an index.',
        'Pick the indices of links that lead to DETAIL / PROFILE / ITEM / LISTING pages likely to',
        'contain that content (e.g. an individual advisor, product, place, or listing whose page has reviews).',
        'Reason ONLY from the text and context — do NOT rely on URL patterns.',
        '',
        'EXCLUDE: navigation, menus, breadcrumbs, login / sign-up / account, categories, tag clouds,',
        'social media, footer, help/about/legal/contact, and "load more / next page" of the SAME list.',
        '',
        'Return a JSON array of integer indices (e.g. [0,3,7]). If none are worth opening, return [].',
        '',
        'CANDIDATES:',
        list,
      ].join('\n');

      const res = await gemini.generateJsonResilient(instruction);
      const picked = mapIndices(toIndices(res), candidates);
      if (picked.length) return { hrefs: picked, source: 'ai' };
      // AI returned 0 → fall through to heuristic.
    } catch {
      // AI failed (e.g. 429) → fall through to heuristic.
    }
  }

  // 2) Heuristic fallback (no AI): pick content-like, same-domain links.
  return { hrefs: heuristicSelect(candidates), source: 'heuristic' };
}

function mapIndices(idxs, candidates) {
  const out = [];
  const seen = new Set();
  for (const i of idxs) {
    const c = candidates[i];
    if (!c || seen.has(c.href)) continue;
    seen.add(c.href);
    out.push(c.href);
    if (out.length >= MAX_PICK) break;
  }
  return out;
}

// Obvious non-content links to skip in the heuristic fallback.
const SKIP_TEXT = /(^|\b)(log\s?in|login|sign\s?in|signin|sign\s?up|signup|register|logout|my\s?account|account|cart|basket|checkout|subscribe|newsletter|terms|privacy|cookies?|policy|policies|legal|gdpr|disclaimer|imprint|contact|about\s?us|about|help|faq|support|careers?|jobs|press|advertise|sitemap|home|menu|skip to|back to top|read more|show more|load more)(\b|$)/i;
const SKIP_SOCIAL = /(facebook|twitter|x\.com|instagram|youtube|linkedin|pinterest|tiktok|reddit|whatsapp|telegram|snapchat|mailto:|tel:)/i;
const SKIP_PAGING = /^(\s*[«»‹›<>]\s*|next|previous|prev|first|last|page\s*\d+|\d+)$/i;

function looksSkippable(c) {
  const t = (c.text || '').trim();
  if (!t || t.length < 2) return true; // icon / empty anchor
  if (!/[a-z0-9]/i.test(t)) return true; // punctuation-only
  if (SKIP_TEXT.test(t)) return true;
  if (SKIP_PAGING.test(t)) return true;
  if (SKIP_SOCIAL.test(t) || SKIP_SOCIAL.test(c.href)) return true;
  return false;
}

/** Score by how content-like a link is: substantial anchor text + surrounding context. */
function scoreCandidate(c) {
  const textLen = (c.text || '').trim().length;
  const ctxLen = Math.min((c.context || '').trim().length, 200);
  return textLen + ctxLen * 0.4;
}

function heuristicSelect(candidates) {
  const kept = candidates.filter((c) => !looksSkippable(c));
  kept.sort((a, b) => scoreCandidate(b) - scoreCandidate(a));
  const out = [];
  const seen = new Set();
  for (const c of kept) {
    if (seen.has(c.href)) continue;
    seen.add(c.href);
    out.push(c.href);
    if (out.length >= MAX_PICK) break;
  }
  return out;
}

function toIndices(res) {
  let arr = [];
  if (Array.isArray(res)) arr = res;
  else if (res && Array.isArray(res.indices)) arr = res.indices;
  else if (res && typeof res === 'object') {
    for (const v of Object.values(res)) if (Array.isArray(v)) { arr = v; break; }
  }
  return arr.map((n) => parseInt(n, 10)).filter((n) => Number.isInteger(n) && n >= 0);
}

function truncate(s, n) {
  s = String(s || '');
  return s.length > n ? s.slice(0, n) + '…' : s;
}

module.exports = { collectCandidateLinks, selectLinks, heuristicSelect, normHost };
