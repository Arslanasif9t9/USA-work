'use strict';

const gemini = require('./geminiClient');

// Conservative chunk size so very large pages are split and each piece filtered.
const MAX_CHARS = 12000;

/**
 * AI FILTER: given the RAW page text + the user's short "what to extract" prompt,
 * internally build a strict Gemini instruction and return ONLY genuine content
 * items (real reviews / quotes), with all UI/nav/ads/marketing noise removed.
 *
 * Completeness: long input is chunked; EVERY chunk is filtered (with retry +
 * model fallback) and ALL items combined + de-duplicated — no silent loss.
 * If some chunks fail after all retries, the rest are still returned (partial=true).
 *
 * @returns {Promise<{ok:boolean, lines:string[], reason?:string, chunks:number,
 *                     failedChunks:number, partial:boolean}>}
 */
async function filterText(rawText, userPrompt) {
  if (!gemini.isConfigured()) {
    return { ok: false, lines: [], reason: 'gemini_not_configured', chunks: 0, failedChunks: 0, partial: false };
  }
  if (!rawText || !rawText.trim()) {
    return { ok: true, lines: [], chunks: 0, failedChunks: 0, partial: false };
  }

  const chunks = chunkText(rawText, MAX_CHARS);
  const all = [];
  let failedChunks = 0;
  let lastErr;

  for (let i = 0; i < chunks.length; i++) {
    try {
      const res = await gemini.generateJsonResilient(buildInstruction(userPrompt, chunks[i]));
      all.push(...toLines(res));
    } catch (err) {
      // Don't abandon the whole page because one chunk failed — keep going.
      failedChunks += 1;
      lastErr = err;
    }
  }

  const lines = dedupe(all);
  if (failedChunks === chunks.length) {
    // Nothing succeeded at all.
    return { ok: false, lines, reason: oneLine(lastErr && lastErr.message), chunks: chunks.length, failedChunks, partial: false };
  }
  return {
    ok: true,
    lines,
    chunks: chunks.length,
    failedChunks,
    partial: failedChunks > 0,
    reason: failedChunks > 0 ? `${failedChunks}/${chunks.length} chunks failed` : undefined,
  };
}

function buildInstruction(userPrompt, pageText) {
  return [
    'You are a precise content extractor. You are given the RAW visible text of ONE web page',
    'and a user request. Return ONLY the genuine content items the user asked for.',
    '',
    `USER REQUEST: "${userPrompt || 'the main content items on this page'}"`,
    '',
    'KEEP (only genuine items):',
    '- Real user-written content matching the request (e.g. actual customer reviews, actual quotes).',
    '- The full verbatim text of each item, cleaned of trailing UI fragments.',
    '',
    'REMOVE (never include any of these):',
    '- Navigation, menus, breadcrumbs, headers, footers, sidebars.',
    '- Advertisements, sponsored blocks, promotional/marketing copy, calls-to-action.',
    '- Cookie/consent banners and privacy notices.',
    '- AI-generated or site-generated SUMMARY blurbs (e.g. "Evaluating 116 reviews, reviewers had...").',
    '- Rating widgets, star counts, score breakdowns, "X% of reviewers", filter/sort controls.',
    '- UI labels and chrome such as "Login", "Sign in", "More filters", "Tags:", "See more",',
    '  "Write a review", "Verified", dates/author lines on their own, page numbers, button text.',
    '',
    'RULES:',
    '- Output a JSON array of strings. Each string = ONE genuine item, verbatim, no surrounding noise.',
    '- Include EVERY genuine item you find in the text below — do not summarize, truncate, or drop any.',
    '- Do NOT merge two separate items into one, and do NOT split one item into several.',
    '- No commentary, numbering, markdown, or keys. If there are no genuine items, return [].',
    '',
    'PAGE TEXT:',
    pageText,
  ].join('\n');
}

/** Split on line boundaries so we never cut an item in half. */
function chunkText(text, max) {
  const lines = String(text).split('\n');
  const chunks = [];
  let cur = '';
  for (const ln of lines) {
    if (cur && cur.length + ln.length + 1 > max) {
      chunks.push(cur);
      cur = '';
    }
    cur += (cur ? '\n' : '') + ln;
  }
  if (cur) chunks.push(cur);
  return chunks.length ? chunks : [''];
}

/** Accept an array, {items:[...]}, or any object holding the first array value. */
function toLines(res) {
  if (Array.isArray(res)) return res.map(String);
  if (res && Array.isArray(res.items)) return res.items.map(String);
  if (res && typeof res === 'object') {
    for (const v of Object.values(res)) if (Array.isArray(v)) return v.map(String);
  }
  return [];
}

function dedupe(arr) {
  const seen = new Set();
  const out = [];
  for (const s of arr) {
    const t = String(s).replace(/\s+/g, ' ').trim();
    if (!t) continue;
    const k = t.toLowerCase();
    if (seen.has(k)) continue;
    seen.add(k);
    out.push(t);
  }
  return out;
}

function oneLine(s) {
  return String(s || 'unknown error').split('\n')[0].slice(0, 200);
}

module.exports = { filterText, chunkText };
