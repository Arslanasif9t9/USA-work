'use strict';

const { siteNameFromUrl } = require('../extractor/selectors');

/**
 * The scraping plan is the "brain output" that drives the crawler + extractor.
 *
 * Shape:
 * {
 *   url: string,
 *   siteName: string,
 *   siteType: string,            // e.g. "review_platform", "ecommerce", "unknown"
 *   keywords: string[],          // terms that hint at review content
 *   extractionFocus: "reviews",  // always reviews for this system
 *   scrollStrategy: "infinite" | "load_more" | "paginate" | "auto",
 *   loadMoreSelector: string|null,
 *   scrollContainer: string|null,
 *   stopConditions: { maxMinutes:number, idleRounds:number },
 *   missingInfoQuestions: string[]
 * }
 */

const DEFAULTS = {
  siteType: 'unknown',
  keywords: ['review', 'rating', 'comment', 'feedback', 'testimonial'],
  extractionFocus: 'reviews',
  scrollStrategy: 'auto',
  loadMoreSelector: null,
  scrollContainer: null,
  stopConditions: { maxMinutes: 10, idleRounds: 4 },
  missingInfoQuestions: [],
};

function isValidUrl(url) {
  try {
    const u = new URL(url);
    return u.protocol === 'http:' || u.protocol === 'https:';
  } catch {
    return false;
  }
}

/** Merge a (possibly partial / AI-produced) plan with defaults and validate. */
function normalizePlan(partial = {}, ctx = {}) {
  const url = partial.url || ctx.url || '';
  const plan = {
    ...DEFAULTS,
    ...partial,
    url,
    siteName: partial.siteName || (url ? siteNameFromUrl(url) : ''),
    extractionFocus: 'reviews',
    keywords: dedupeStrings(partial.keywords && partial.keywords.length ? partial.keywords : DEFAULTS.keywords),
    stopConditions: { ...DEFAULTS.stopConditions, ...(partial.stopConditions || {}) },
    missingInfoQuestions: Array.isArray(partial.missingInfoQuestions)
      ? partial.missingInfoQuestions.slice()
      : [],
  };

  // Derive required follow-up questions for missing critical info.
  if (!isValidUrl(plan.url)) {
    addQuestion(plan, 'What is the full website URL (including https://) you want to scrape reviews from?');
  }

  return plan;
}

function addQuestion(plan, q) {
  if (!plan.missingInfoQuestions.includes(q)) plan.missingInfoQuestions.push(q);
}

function dedupeStrings(arr) {
  return Array.from(new Set((arr || []).map((s) => String(s).trim()).filter(Boolean)));
}

function isComplete(plan) {
  return plan.missingInfoQuestions.length === 0 && isValidUrl(plan.url);
}

module.exports = { DEFAULTS, normalizePlan, isComplete, isValidUrl };
