'use strict';

const gemini = require('./geminiClient');
const { normalizePlan, isComplete } = require('./planSchema');

/**
 * The "brain": convert a free-text user prompt (+ optional URL) into a structured
 * scraping plan. Uses Gemini when configured; otherwise falls back to a safe
 * rule-based plan so the pipeline always runs.
 *
 * @param {string} userPrompt - what the user wants ("scrape all reviews from ...").
 * @param {object} ctx        - { url } extracted/known separately (optional).
 * @returns {Promise<{plan:object, source:'gemini'|'fallback'}>}
 */
async function analyze(userPrompt, ctx = {}) {
  const url = ctx.url || extractUrl(userPrompt);

  if (gemini.isConfigured()) {
    try {
      const raw = await gemini.generateJsonResilient(buildPrompt(userPrompt, url));
      return { plan: normalizePlan(raw, { url }), source: 'gemini' };
    } catch (err) {
      // Fall through to rule-based planning on any AI failure.
      return { plan: ruleBasedPlan(userPrompt, url), source: 'fallback', error: err.message };
    }
  }

  return { plan: ruleBasedPlan(userPrompt, url), source: 'fallback' };
}

function buildPrompt(userPrompt, url) {
  return [
    'You are a scraping planner. Output ONLY a JSON object (no prose) with this shape:',
    '{',
    '  "url": string,',
    '  "siteType": string,                  // e.g. "review_platform", "ecommerce", "directory", "unknown"',
    '  "keywords": string[],                // words that signal review content on this site',
    '  "extractionFocus": "reviews",',
    '  "scrollStrategy": "infinite" | "load_more" | "paginate" | "auto",',
    '  "loadMoreSelector": string|null,     // CSS selector for a load-more button if known, else null',
    '  "scrollContainer": string|null,      // CSS selector if reviews scroll inside a container, else null',
    '  "stopConditions": { "maxMinutes": number, "idleRounds": number },',
    '  "missingInfoQuestions": string[]     // follow-up questions if the request is incomplete',
    '}',
    'Rules: extract ONLY public review text. Never plan logins. If the URL is missing or invalid,',
    'add a question to missingInfoQuestions asking for it.',
    '',
    `User request: """${userPrompt || ''}"""`,
    `Known URL: ${url || '(none provided)'}`,
  ].join('\n');
}

function ruleBasedPlan(userPrompt, url) {
  const text = (userPrompt || '').toLowerCase();
  let scrollStrategy = 'auto';
  if (/load more|show more|view more/.test(text)) scrollStrategy = 'load_more';
  else if (/infinite|keep scrolling|scroll/.test(text)) scrollStrategy = 'infinite';
  else if (/page|pagination|next page/.test(text)) scrollStrategy = 'paginate';

  const keywords = ['review', 'rating', 'comment', 'feedback', 'testimonial'];
  for (const w of ['psychic', 'product', 'hotel', 'restaurant', 'app', 'service']) {
    if (text.includes(w)) keywords.push(w);
  }

  return normalizePlan({ url, scrollStrategy, keywords }, { url });
}

function extractUrl(text) {
  const m = String(text || '').match(/https?:\/\/[^\s"'<>]+/i);
  return m ? m[0] : '';
}

module.exports = { analyze, isComplete, extractUrl };
