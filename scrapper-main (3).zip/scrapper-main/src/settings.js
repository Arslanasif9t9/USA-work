'use strict';

const fs = require('fs');
const os = require('os');
const path = require('path');
const config = require('./config');

const SETTINGS_PATH = path.join(config.root, 'settings.json');

/** Default save location: the user's Desktop in a folder named "raw_data". */
function defaultSaveLocation() {
  return path.join(os.homedir(), 'Desktop', 'raw_data');
}

// Snapshot the original .env-derived defaults ONCE at module load, before any
// applyToConfig() mutates the shared config singleton. This keeps "Reset to
// defaults" faithful to .env even after a run has overridden config in-process.
// Note: scroll delay and Gemini model are intentionally NOT user-facing settings.
// They stay on their .env / internal defaults (config.timing.scroll*, config.ai.model).
const ORIGINAL_DEFAULTS = Object.freeze({
  totalRunMs: config.timing.totalRunMs,
  checkpointMs: config.timing.checkpointMs,
  maxPages: config.crawler.maxPages,
  saveLocation: defaultSaveLocation(),
  headless: config.crawler.headless,
  deepCrawl: config.crawler.deepCrawl, // default ON
  gitSync: config.git.enabled,
});

/** Baseline values — settings.json overrides these; .env (via config) is the fallback. */
function defaults() {
  return { ...ORIGINAL_DEFAULTS };
}

function load() {
  try {
    return JSON.parse(fs.readFileSync(SETTINGS_PATH, 'utf8')) || {};
  } catch {
    return {};
  }
}

/** Effective settings = defaults (.env) overlaid with the persisted settings.json. */
function resolved() {
  return { ...defaults(), ...load() };
}

function validate(input) {
  const errors = [];
  const out = {};
  const numKeys = ['totalRunMs', 'checkpointMs', 'maxPages'];
  for (const k of numKeys) {
    if (input[k] === undefined || input[k] === null || input[k] === '') continue;
    const n = Number(input[k]);
    if (!Number.isFinite(n) || n < 0) { errors.push(`${k} must be a non-negative number`); continue; }
    out[k] = Math.round(n);
  }
  if (input.saveLocation !== undefined) {
    const p = String(input.saveLocation).trim();
    if (!p) errors.push('Save location cannot be empty');
    else out.saveLocation = p;
  }
  for (const k of ['headless', 'deepCrawl', 'gitSync']) {
    if (input[k] !== undefined) out[k] = Boolean(input[k]);
  }
  const merged = { ...resolved(), ...out };
  if (merged.checkpointMs > merged.totalRunMs) errors.push('Checkpoint interval cannot exceed total run time');
  return { errors, value: out };
}

function ensureSaveLocation(loc) {
  try {
    fs.mkdirSync(loc, { recursive: true });
    return { ok: true };
  } catch (e) {
    return { ok: false, error: e.message };
  }
}

function save(input) {
  const { errors, value } = validate(input);
  if (errors.length) return { ok: false, errors };

  const loc = value.saveLocation || resolved().saveLocation;
  const mk = ensureSaveLocation(loc);
  if (!mk.ok) return { ok: false, errors: [`Could not create save location "${loc}": ${mk.error}`] };

  const merged = { ...load(), ...value };
  fs.writeFileSync(SETTINGS_PATH, JSON.stringify(merged, null, 2), 'utf8');
  return { ok: true, settings: resolved() };
}

function reset() {
  try { fs.unlinkSync(SETTINGS_PATH); } catch { /* already absent */ }
  return { ok: true, settings: resolved() };
}

/**
 * Apply the resolved settings onto the shared config singleton so every module
 * (crawler, browser, gemini, git, writer) picks them up. Called at job start.
 * Save location is created if missing; falls back to project raw_data/ if not.
 */
function applyToConfig() {
  const s = resolved();
  config.timing.totalRunMs = s.totalRunMs;
  config.timing.checkpointMs = s.checkpointMs;
  config.crawler.maxPages = s.maxPages;
  // scroll delay + gemini model intentionally left on their .env/internal defaults.
  config.crawler.headless = s.headless;
  config.git.enabled = s.gitSync;
  config.deepCrawl = s.deepCrawl;

  // Save location: use the EXACT typed path (normalized to absolute). Only an
  // empty/blank value falls back to the Desktop default. If the path can't be
  // created, fall back to the Desktop default and surface the error.
  const raw = (s.saveLocation == null ? '' : String(s.saveLocation)).trim();
  const target = raw ? path.resolve(raw) : defaultSaveLocation();
  const mk = ensureSaveLocation(target);
  if (mk.ok) {
    config.paths.rawData = target;
  } else {
    const fallback = defaultSaveLocation();
    ensureSaveLocation(fallback);
    config.paths.rawData = fallback;
  }
  return { resolved: s, saveLocationOk: mk.ok, saveLocation: config.paths.rawData, error: mk.error };
}

module.exports = {
  SETTINGS_PATH,
  defaults,
  defaultSaveLocation,
  load,
  resolved,
  validate,
  save,
  reset,
  ensureSaveLocation,
  applyToConfig,
};
