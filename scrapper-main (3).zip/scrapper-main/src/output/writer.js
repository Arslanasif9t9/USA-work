'use strict';

const fs = require('fs');
const path = require('path');
const config = require('../config');
const { siteNameFromUrl } = require('../extractor/selectors');

/**
 * File output: one scraping session/batch = one TXT file.
 *   raw_data/{site_name}/batch_xxx.txt
 *
 * Each file contains ONLY review text — one review per line, no metadata, no HTML.
 */

function siteDir(siteName) {
  return path.join(config.paths.rawData, siteName);
}

/** Find the next zero-padded batch index by scanning existing files. */
function nextBatchNumber(dir) {
  let max = 0;
  try {
    for (const name of fs.readdirSync(dir)) {
      const m = name.match(/^batch_(\d+)\.txt$/i);
      if (m) max = Math.max(max, parseInt(m[1], 10));
    }
  } catch {
    // dir doesn't exist yet -> start at 0
  }
  return max + 1;
}

function batchFileName(n) {
  return `batch_${String(n).padStart(3, '0')}.txt`;
}

/**
 * Write reviews to the next batch file for a site.
 * @returns {{file:string, count:number, batch:number}|null} null when no reviews.
 */
function writeBatch(reviews, opts = {}) {
  const cleaned = (reviews || []).map((r) => String(r).replace(/\s+/g, ' ').trim()).filter(Boolean);
  if (cleaned.length === 0) return null;

  const siteName = opts.siteName || (opts.url ? siteNameFromUrl(opts.url) : 'unknown');
  const dir = siteDir(siteName);
  fs.mkdirSync(dir, { recursive: true });

  const batch = opts.batch != null ? opts.batch : nextBatchNumber(dir);
  const file = path.join(dir, batchFileName(batch));

  fs.writeFileSync(file, cleaned.join('\n') + '\n', 'utf8');
  return { file, count: cleaned.length, batch };
}

/**
 * FIX 1: create the site folder + an EMPTY batch file at the start of a batch,
 * so the user always ends up with a folder + file even if 0 lines are extracted.
 * @returns {{file:string, batch:number, siteName:string}}
 */
function beginBatch(opts = {}) {
  const siteName = opts.siteName || (opts.url ? siteNameFromUrl(opts.url) : 'unknown');
  const dir = siteDir(siteName);
  fs.mkdirSync(dir, { recursive: true });
  const batch = opts.batch != null ? opts.batch : nextBatchNumber(dir);
  const pad = String(batch).padStart(3, '0');
  const file = path.join(dir, `batch_${pad}.txt`);
  const rawFile = path.join(dir, `batch_${pad}_RAW.txt`);
  // Create BOTH files up front so the user is never left empty-handed.
  fs.writeFileSync(file, '', 'utf8');
  fs.writeFileSync(rawFile, '', 'utf8');
  return { file, rawFile, batch, siteName };
}

/** Overwrite a file with cleaned lines. Returns number of lines written. */
function writeFinal(file, lines) {
  const cleaned = (lines || []).map((r) => String(r).replace(/\s+/g, ' ').trim()).filter(Boolean);
  fs.writeFileSync(file, cleaned.length ? cleaned.join('\n') + '\n' : '', 'utf8');
  return cleaned.length;
}

/**
 * Append RAW text blocks, one per distinct block, separated by a blank line
 * (structured & readable — not one giant wall). Used live during the crawl.
 */
function appendRawBlocks(file, blocks) {
  const cleaned = (blocks || []).map((b) => String(b).replace(/\s+/g, ' ').trim()).filter(Boolean);
  if (cleaned.length === 0) return 0;
  fs.appendFileSync(file, cleaned.map((b) => b + '\n\n').join(''), 'utf8');
  return cleaned.length;
}

/**
 * Write the filtered file as numbered, spaced records:
 *   [1]
 *   <text>
 *
 *   [2]
 *   <text>
 * One blank line after every record. Returns record count.
 */
function writeFiltered(file, items) {
  const cleaned = (items || []).map((s) => String(s).replace(/\s+/g, ' ').trim()).filter(Boolean);
  const body = cleaned.map((t, i) => `[${i + 1}]\n${t}\n\n`).join('');
  fs.writeFileSync(file, body, 'utf8');
  return cleaned.length;
}

/**
 * APPEND filtered records to an existing file, CONTINUING the numbering from
 * `startIndex` (the count already written). Keeps the [n] + blank-line format.
 * Used by checkpointing so the clean file grows incrementally. Returns count added.
 */
function appendFiltered(file, items, startIndex = 0) {
  // Clean each line but PRESERVE internal line breaks so a record can be
  // "Name\nReview text" (used by the local cleaner). AI single-line records are
  // unaffected.
  const cleaned = (items || [])
    .map((s) =>
      String(s)
        .split('\n')
        .map((l) => l.replace(/\s+/g, ' ').trim())
        .filter(Boolean)
        .join('\n')
    )
    .filter(Boolean);
  if (cleaned.length === 0) return 0;
  const body = cleaned.map((t, i) => `[${startIndex + i + 1}]\n${t}\n\n`).join('');
  fs.appendFileSync(file, body, 'utf8');
  return cleaned.length;
}

/** Write a single human-readable note line (used when AI finds nothing/unavailable). */
function writeNote(file, note) {
  fs.writeFileSync(file, String(note).replace(/\s+/g, ' ').trim() + '\n', 'utf8');
}

/** Append a per-page source separator used by deep-crawl: "--- from: <url> ---". */
function appendSeparator(file, url) {
  fs.appendFileSync(file, `--- from: ${url} ---\n\n`, 'utf8');
}

/** Append cleaned review lines to an existing batch file. Returns lines written. */
function appendReviews(file, lines) {
  const cleaned = (lines || []).map((r) => String(r).replace(/\s+/g, ' ').trim()).filter(Boolean);
  if (cleaned.length === 0) return 0;
  fs.appendFileSync(file, cleaned.join('\n') + '\n', 'utf8');
  return cleaned.length;
}

module.exports = {
  writeBatch,
  beginBatch,
  appendReviews,
  appendRawBlocks,
  writeFinal,
  writeFiltered,
  appendFiltered,
  writeNote,
  appendSeparator,
  nextBatchNumber,
  siteDir,
  batchFileName,
};
