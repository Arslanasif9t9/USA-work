'use strict';

const path = require('path');
require('dotenv').config();

const ROOT = path.resolve(__dirname, '..', '..');

function num(value, fallback) {
  const n = Number(value);
  return Number.isFinite(n) ? n : fallback;
}

function bool(value, fallback) {
  if (value === undefined || value === null || value === '') return fallback;
  return String(value).toLowerCase() === 'true';
}

const config = {
  root: ROOT,
  paths: {
    rawData: path.join(ROOT, 'raw_data'),
    memory: path.join(ROOT, 'memory'),
    scrapedUrls: path.join(ROOT, 'memory', 'scraped_urls.json'),
    reviewHashes: path.join(ROOT, 'memory', 'review_hashes.json'),
    configs: path.join(ROOT, 'configs'),
  },

  ai: {
    apiKey: process.env.GEMINI_API_KEY || '',
    model: process.env.GEMINI_MODEL || 'gemini-1.5-flash',
  },

  timing: {
    scrollMinDelayMs: num(process.env.SCROLL_MIN_DELAY_MS, 600),
    scrollMaxDelayMs: num(process.env.SCROLL_MAX_DELAY_MS, 1800),
    // Total continuous run budget (the only run-length cap). Default 1 hour.
    totalRunMs: num(process.env.TOTAL_RUN_MS, 60 * 60 * 1000),
    // Periodic auto-save (filter + append) interval. Default 5 minutes.
    checkpointMs: num(process.env.CHECKPOINT_MS, 5 * 60 * 1000),
  },

  crawler: {
    headless: bool(process.env.HEADLESS, true),
    navTimeoutMs: num(process.env.NAV_TIMEOUT_MS, 45000),
    // Short cap so a never-settling 'networkidle' (sites with polling/websockets)
    // can't consume the whole batch window before scrolling begins.
    idleTimeoutMs: num(process.env.IDLE_TIMEOUT_MS, 12000),
    // How long to wait for review content to hydrate (SPAs render after load).
    contentTimeoutMs: num(process.env.CONTENT_TIMEOUT_MS, 9000),
    // Deep-crawl: hard cap on how many pages a single run may visit.
    maxPages: num(process.env.MAX_PAGES, 50),
    // Deep-crawl (follow subpages) default — ON unless overridden in settings/.env.
    deepCrawl: bool(process.env.DEEP_CRAWL, true),
  },

  extraction: {
    minReviewLength: num(process.env.MIN_REVIEW_LENGTH, 40),
  },

  git: {
    enabled: bool(process.env.GIT_SYNC, false),
    remote: process.env.GIT_REMOTE || 'origin',
    branch: process.env.GIT_BRANCH || 'main',
  },
};

// Safe, loggable view of the resolved config — NEVER includes the API key.
config.summary = () => ({
  headless: config.crawler.headless,
  navTimeoutMs: config.crawler.navTimeoutMs,
  idleTimeoutMs: config.crawler.idleTimeoutMs,
  totalRunMs: config.timing.totalRunMs,
  checkpointMs: config.timing.checkpointMs,
  maxPages: config.crawler.maxPages,
  minReviewLength: config.extraction.minReviewLength,
  gitSync: config.git.enabled,
  gitRemote: config.git.remote,
  gitBranch: config.git.branch,
  geminiModel: config.ai.model,
  geminiKeyPresent: Boolean(config.ai.apiKey),
});

module.exports = config;
