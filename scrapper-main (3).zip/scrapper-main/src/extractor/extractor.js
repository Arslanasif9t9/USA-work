'use strict';

const config = require('../config');
const cleaner = require('./cleaner');
const heuristics = require('./heuristics');
const { loadSiteConfig, extractWithSelectors, siteNameFromUrl } = require('./selectors');

/**
 * Extract clean review strings from a live Playwright page.
 *
 * Order of precedence:
 *   1. Per-site config selectors (configs/{site_name}.json) when present.
 *   2. Generic heuristics otherwise.
 * Raw results always pass through the cleaner (no HTML, normalized, deduped-in-batch).
 *
 * @returns {Promise<string[]>}
 */
async function extractReviews(page, { siteName, url, minLength } = {}) {
  const site = siteName || (url ? siteNameFromUrl(url) : '');
  const min = minLength != null ? minLength : config.extraction.minReviewLength;

  let raw = [];
  const siteCfg = site ? loadSiteConfig(site) : null;

  if (siteCfg) {
    raw = await extractWithSelectors(page, siteCfg);
  } else {
    raw = await heuristics.extractWithHeuristics(page, { minLength: min });
  }

  return cleaner.cleanMany(raw, { minLength: min });
}

module.exports = { extractReviews };
