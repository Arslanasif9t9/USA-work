'use strict';

/**
 * RAW dump: extract ALL readable visible text from the current page
 * (headings, paragraphs, list items, blockquotes, review/quote blocks — everything),
 * excluding nav / header / footer / aside / form / script / style.
 *
 * Strategy: temporarily hide excluded regions, read body.innerText (which is the
 * faithful, already-deduplicated visible text incl. spans), then restore. Runs
 * synchronously inside page.evaluate so the crawl is never affected.
 *
 * @returns {Promise<string[]>} one trimmed line per visible text block
 */
async function extractRawText(page) {
  try {
    return await page.evaluate(() => {
      const EXCLUDE =
        'nav,header,footer,aside,form,script,style,noscript,svg,' +
        '[role="navigation"],[role="banner"],[role="contentinfo"]';
      const hidden = [];
      document.querySelectorAll(EXCLUDE).forEach((el) => {
        hidden.push([el, el.style.display]);
        el.style.display = 'none';
      });
      const raw = (document.body && document.body.innerText) || '';
      // Restore original inline display so scrolling/load-more is unaffected.
      hidden.forEach(([el, d]) => {
        el.style.display = d;
      });
      return raw
        .split('\n')
        .map((s) => s.replace(/\s+/g, ' ').trim())
        .filter((s) => s.length > 1);
    });
  } catch (err) {
    return [];
  }
}

module.exports = { extractRawText };
