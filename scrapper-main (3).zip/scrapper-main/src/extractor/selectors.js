'use strict';

const fs = require('fs');
const path = require('path');
const config = require('../config');

/**
 * Derive a stable site_name from a URL host.
 * www.example.com -> example_com
 */
function siteNameFromUrl(url) {
  let host;
  try {
    host = new URL(url).hostname;
  } catch {
    host = String(url);
  }
  return host
    .replace(/^www\./i, '')
    .replace(/[^a-z0-9]+/gi, '_')
    .replace(/^_+|_+$/g, '')
    .toLowerCase();
}

/**
 * Load an optional per-site selector config from configs/{site_name}.json.
 * Returns null when no config exists (caller falls back to heuristics).
 */
function loadSiteConfig(siteName) {
  const file = path.join(config.paths.configs, `${siteName}.json`);
  try {
    const raw = fs.readFileSync(file, 'utf8');
    const json = JSON.parse(raw);
    if (!json || !json.reviewSelector) return null;
    return json;
  } catch {
    return null;
  }
}

/**
 * Browser-side extraction using explicit CSS selectors.
 * Runs inside page.evaluate; receives a plain config object.
 */
function inPageSelectorExtract(cfg) {
  const out = [];
  const excludeSel = (cfg.exclude || []).join(',');
  const nodes = document.querySelectorAll(cfg.reviewSelector);
  nodes.forEach((node) => {
    if (excludeSel) {
      node.querySelectorAll(excludeSel).forEach((bad) => bad.remove());
    }
    const text = (node.innerText || node.textContent || '').trim();
    if (text) out.push(text);
  });
  return out;
}

async function extractWithSelectors(page, cfg) {
  return page.evaluate(inPageSelectorExtract, cfg);
}

module.exports = { siteNameFromUrl, loadSiteConfig, extractWithSelectors };
