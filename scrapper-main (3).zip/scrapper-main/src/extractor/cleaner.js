'use strict';

const config = require('../config');

/**
 * Text cleaning + normalization.
 *
 * Guarantee: returned strings contain NO HTML — tags and entities are stripped,
 * whitespace collapsed, unicode normalized (NFKC), and short/noise fragments dropped.
 */

const NAMED_ENTITIES = {
  '&amp;': '&',
  '&lt;': '<',
  '&gt;': '>',
  '&quot;': '"',
  '&#39;': "'",
  '&apos;': "'",
  '&nbsp;': ' ',
  '&hellip;': '…',
  '&mdash;': '—',
  '&ndash;': '–',
  '&rsquo;': '’',
  '&lsquo;': '‘',
  '&rdquo;': '”',
  '&ldquo;': '“',
};

function decodeEntities(text) {
  let out = text;
  for (const [k, v] of Object.entries(NAMED_ENTITIES)) {
    out = out.split(k).join(v);
  }
  // Numeric entities: &#123; and &#x1F600;
  out = out.replace(/&#x([0-9a-fA-F]+);/g, (_, hex) =>
    safeCodePoint(parseInt(hex, 16))
  );
  out = out.replace(/&#(\d+);/g, (_, dec) => safeCodePoint(parseInt(dec, 10)));
  return out;
}

function safeCodePoint(cp) {
  try {
    return String.fromCodePoint(cp);
  } catch {
    return '';
  }
}

function stripHtml(text) {
  // Remove script/style blocks entirely, then any remaining tags.
  return String(text)
    .replace(/<script[\s\S]*?<\/script>/gi, ' ')
    .replace(/<style[\s\S]*?<\/style>/gi, ' ')
    .replace(/<[^>]+>/g, ' ');
}

/** Clean a single raw string into normalized plain text (or '' if it should be dropped). */
function clean(raw, opts = {}) {
  const minLength =
    opts.minLength != null ? opts.minLength : config.extraction.minReviewLength;

  let text = String(raw == null ? '' : raw);
  text = stripHtml(text);
  text = decodeEntities(text);
  text = text.normalize('NFKC');
  // Collapse all whitespace (incl. newlines/tabs) to single spaces.
  text = text.replace(/\s+/g, ' ').trim();

  if (!text) return '';
  if (text.length < minLength) return '';
  if (!hasLetters(text)) return '';
  return text;
}

function hasLetters(text) {
  return /[\p{L}]/u.test(text);
}

/**
 * Clean an array of raw strings, returning normalized non-empty results.
 * De-dups exact repeats within the same batch (case/space-insensitive).
 */
function cleanMany(rawList, opts = {}) {
  const seen = new Set();
  const out = [];
  for (const raw of rawList || []) {
    const c = clean(raw, opts);
    if (!c) continue;
    const key = c.toLowerCase();
    if (seen.has(key)) continue;
    seen.add(key);
    out.push(c);
  }
  return out;
}

module.exports = { clean, cleanMany, stripHtml, decodeEntities };
