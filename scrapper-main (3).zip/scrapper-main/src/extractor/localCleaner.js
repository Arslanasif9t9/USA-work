'use strict';

const config = require('../config');

/**
 * NON-AI fallback cleaner: turns RAW page text into clean review records using
 * heuristics only — no Gemini / network. Used when the AI filter is unavailable
 * (429 / quota / offline) so the clean file is still populated.
 *
 * Output records match the AI path: an array of strings (each possibly
 * "Name\nReview text"). The orchestrator adds the [n] numbering, blank-line
 * spacing, and "--- from: <url> ---" per-page separators.
 */

// UI labels / nav / chrome that are never reviews (whole-line match).
const SKIP_EXACT = /^(log\s?in|login|sign\s?up|sign\s?in|signin|signup|register|logout|my account|account|cart|basket|checkout|subscribe|newsletter|home|menu|search|filter|filters|more filters|sort|sort by|show more|see more|read more|load more|view more|write a review|leave a review|chat|live chat|voice call|phone call|call now|message|send message|email|share|useful|helpful|report|reply|verified|follow|following|edit|delete|save|next|next page|previous|prev|first|last|back to top|skip to content|terms|terms of service|privacy|privacy policy|cookies?|cookie policy|policy|policies|legal|gdpr|disclaimer|contact|contact us|about|about us|help|faq|support|careers?|jobs|press|advertise|sitemap|download|get the app|app store|google play|facebook|twitter|instagram|youtube|linkedin|pinterest|tiktok)$/i;

// Metadata lines that surround reviews but are not the review text itself.
const META = /^(date of experience|reply from|updated\b|posted\b|joined\b|member since|review of\b|verified (purchase|order|review)|recommended|not recommended|advertisement|sponsored)/i;

// Site/AI-generated summary + marketing/boilerplate blurbs (matched anywhere in the line).
const MARKETING = /(evaluating \d+ reviews|\d+% of reviewers|our \d{4} transparency report|companies on trustpilot|how trustpilot|labels reviews|claimed profile|since \d{4},|guided over [\d,]+ |we are here to help|get the guidance|top .* advisors)/i;

// AI-generated review summaries + platform statements that read like prose but aren't reviews.
const SUMMARY = /(created with ai|based on recent reviews|ai[- ]generated|summary (of|based on)|we use technology|fact[- ]?check(ing)? reviews|protect platform integrity|(users|consumers|customers|reviewers|clients|people) (share|describe|report|find|mention|appreciate|note|highlight|said|had|express)|many (users|reviewers|customers|consumers|clients|people)|some (users|reviewers|customers|consumers|clients))/i;

// Generic platform boilerplate (review-invitation / moderation notices) + company about-copy.
const BOILERPLATE = /(this company (invites|asked|usually)|invites (their|its)? ?customers to (review|leave)|people who write reviews|see how (their|these) reviews|sourced,? scored|reviews and ratings are|are sourced|we fight fake reviews|review (collection|invitation)|verification can help|is a (trusted|leading|global) (network|platform|provider))/i;

/** Address-like lines (street + zip / country) — common on business profile pages. */
function isAddress(t) {
  if (/^\d{1,5}\s+\S+.*\b(st|street|ave|avenue|road|rd|blvd|suite|unit|floor|fl|drive|dr|lane|ln)\b/i.test(t)) return true;
  if (/\b\d{5}(-\d{4})?\b/.test(t) && /(united states|united kingdom|usa|canada|australia|, [a-z]{2}\b)/i.test(t)) return true;
  return false;
}

function normalize(s) {
  return String(s == null ? '' : s).replace(/\s+/g, ' ').trim();
}

function wordCount(t) {
  return t.split(/\s+/).filter(Boolean).length;
}

/** Prices, ratings, counts, star/score lines, date/number-only lines. */
function isNumberish(t) {
  if (/^[\$£€]?\s*\d[\d.,]*\s*(stars?|reviews?|ratings?|%|usd|eur|gbp|out of \d)?$/i.test(t)) return true;
  if (/^\d+(\.\d+)?$/.test(t)) return true;
  const letters = t.replace(/[^a-z]/gi, '').length;
  if (/\d/.test(t) && letters < 3) return true; // mostly digits/punctuation
  return false;
}

function looksSkippable(t) {
  if (!t || t.length < 2) return true;
  if (!/[a-z]/i.test(t)) return true; // no letters at all
  if (SKIP_EXACT.test(t)) return true;
  if (META.test(t)) return true;
  if (MARKETING.test(t)) return true;
  if (SUMMARY.test(t)) return true;
  if (BOILERPLATE.test(t)) return true;
  if (isAddress(t)) return true;
  if (isNumberish(t)) return true;
  return false;
}

/** Strip trailing UI affordances like "… See more" / "Read more" from review text. */
function stripTrailingUi(t) {
  return t.replace(/\s*(\.{2,}|…)?\s*(see|read|show)\s+more\s*$/i, '').trim();
}

/** A genuine review/testimonial: prose, long enough, multi-word, letter-dense. */
function isReviewLike(t, minLen) {
  if (looksSkippable(t)) return false;
  if (t.length < minLen) return false;
  if (wordCount(t) < 6) return false;
  if (!/[a-z]/.test(t)) return false; // needs lowercase prose (not a heading)
  const alpha = (t.match(/[a-z]/gi) || []).length;
  if (alpha / t.length < 0.5) return false; // letter density
  return true;
}

/** A short reviewer-name line that may precede a review (e.g. "Ashlin", "Miss Bathesda", "Jane D."). */
function isNameLike(t) {
  if (!t || t.length > 40) return false;
  if (/\d/.test(t) || t.includes(':')) return false;
  if (looksSkippable(t)) return false;
  const words = t.split(/\s+/).filter(Boolean);
  if (words.length < 1 || words.length > 4) return false;
  const significant = words.filter((w) => w.replace(/[^a-z]/gi, '').length > 2);
  if (!significant.every((w) => /^[A-Z]/.test(w))) return false; // significant words capitalized
  if (/[.!?]$/.test(t) && !/\b[A-Z]\.$/.test(t)) return false; // not a sentence (allow trailing initial)
  return true;
}

/**
 * @param {string|string[]} raw  RAW page text (array of blocks, or newline-joined string)
 * @param {{minLength?:number}} [opts]
 * @returns {string[]} clean review records
 */
function cleanReviews(raw, opts = {}) {
  const minLen = opts.minLength != null ? opts.minLength : config.extraction.minReviewLength;
  const blocks = (Array.isArray(raw) ? raw : String(raw).split('\n')).map(normalize);
  const out = [];
  const seen = new Set();
  for (let i = 0; i < blocks.length; i++) {
    const raw = blocks[i];
    if (!isReviewLike(raw, minLen)) continue;
    const t = stripTrailingUi(raw);
    if (!isReviewLike(t, minLen)) continue; // re-check after stripping UI suffix
    const prev = blocks[i - 1] || '';
    const name = prev && isNameLike(prev) ? prev : '';
    const record = name ? `${name}\n${t}` : t;
    const key = record.toLowerCase();
    if (seen.has(key)) continue;
    seen.add(key);
    out.push(record);
  }
  return out;
}

module.exports = { cleanReviews, isReviewLike, isNameLike };
