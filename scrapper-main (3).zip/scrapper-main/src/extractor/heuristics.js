'use strict';

/**
 * Generic, config-free review detection.
 *
 * Strategy (runs in the browser via page.evaluate):
 *  1. Ignore anything inside nav / header / footer / aside / forms / ad-like nodes.
 *  2. Prefer obvious review containers (schema.org reviewBody, class/id hints).
 *  3. Otherwise collect text blocks (p, li, blockquote, article, div) that have
 *     enough text and a LOW link density (reviews are prose, menus are links).
 *  4. Drop blocks fully contained within an already-collected block (no nesting dupes).
 */

function inPageHeuristicExtract(opts) {
  const minLength = opts.minLength || 40;

  const EXCLUDE_ANCESTORS = ['nav', 'header', 'footer', 'aside', 'form'];
  const AD_HINT = /(^|[-_ ])(ad|ads|advert|banner|sponsor|promo|cookie|newsletter|sidebar|menu|breadcrumb)([-_ ]|$)/i;
  const REVIEW_HINT = /(review|comment|testimonial|feedback|rating|opinion)/i;

  function isExcluded(el) {
    let node = el;
    while (node && node !== document.body) {
      const tag = node.tagName ? node.tagName.toLowerCase() : '';
      if (EXCLUDE_ANCESTORS.includes(tag)) return true;
      const role = (node.getAttribute && node.getAttribute('role')) || '';
      if (/(navigation|banner|contentinfo|menu)/i.test(role)) return true;
      const idClass = `${node.id || ''} ${node.className || ''}`;
      if (typeof idClass === 'string' && AD_HINT.test(idClass)) return true;
      node = node.parentElement;
    }
    return false;
  }

  function linkDensity(el) {
    const textLen = (el.innerText || '').replace(/\s+/g, ' ').trim().length || 1;
    let linkLen = 0;
    el.querySelectorAll('a').forEach((a) => {
      linkLen += (a.innerText || '').length;
    });
    return linkLen / textLen;
  }

  const results = [];
  const chosen = [];

  function consider(el) {
    if (!el || chosen.includes(el)) return;
    if (isExcluded(el)) return;
    // Skip if an ancestor is already chosen (avoid nested duplicates).
    for (const c of chosen) {
      if (c.contains(el) || el.contains(c)) {
        // If the new element is a tighter prose block inside a chosen one we still
        // skip to keep one entry per review block.
        return;
      }
    }
    const text = (el.innerText || el.textContent || '').replace(/\s+/g, ' ').trim();
    if (text.length < minLength) return;
    if (linkDensity(el) > 0.5) return;
    chosen.push(el);
    results.push(text);
  }

  // Pass 1: explicit review-like containers.
  const hinted = new Set();
  document
    .querySelectorAll('[itemprop="reviewBody"], [class*="review" i], [class*="comment" i], [class*="testimonial" i], [id*="review" i]')
    .forEach((el) => {
      if (REVIEW_HINT.test(`${el.id || ''} ${el.className || ''}`)) {
        hinted.add(el);
      }
    });
  hinted.forEach(consider);

  // Pass 2: generic prose blocks (only if pass 1 found little).
  if (results.length < 3) {
    document
      .querySelectorAll('p, li, blockquote, article')
      .forEach(consider);
  }

  return results;
}

async function extractWithHeuristics(page, opts = {}) {
  return page.evaluate(inPageHeuristicExtract, { minLength: opts.minLength || 40 });
}

module.exports = { extractWithHeuristics, inPageHeuristicExtract };
