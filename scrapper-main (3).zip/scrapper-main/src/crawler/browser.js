'use strict';

const { chromium } = require('playwright');
const config = require('../config');

const USER_AGENT =
  'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 ' +
  '(KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36';

/**
 * Launch a Chromium browser + a single realistic context/page.
 * Caller is responsible for calling close().
 */
async function launch(opts = {}) {
  const headless = opts.headless != null ? opts.headless : config.crawler.headless;
  const browser = await chromium.launch({ headless });
  const context = await browser.newContext({
    userAgent: USER_AGENT,
    viewport: { width: 1366, height: 900 },
    locale: 'en-US',
  });
  const page = await context.newPage();

  async function close() {
    await context.close().catch(() => {});
    await browser.close().catch(() => {});
  }

  return { browser, context, page, close };
}

module.exports = { launch, USER_AGENT };
