'use strict';

const config = require('../config');
const { think, humanScrollStep } = require('./humanize');

const LOAD_MORE_TEXT = /(load|show|view|see)\s+more|more\s+(reviews|comments)|^more$/i;

/**
 * Try to click a "load more" control. Returns true if one was clicked.
 * Honors an explicit selector from a site config when provided.
 */
async function clickLoadMore(page, loadMoreSelector) {
  if (loadMoreSelector) {
    const btn = page.locator(loadMoreSelector).first();
    if ((await btn.count()) > 0 && (await btn.isVisible().catch(() => false))) {
      await btn.click({ timeout: 5000 }).catch(() => {});
      return true;
    }
    return false;
  }

  // Generic: find a visible button/link whose text looks like "load more".
  let handle;
  try {
    handle = await page.evaluateHandle((rxSource) => {
    const rx = new RegExp(rxSource, 'i');
    const candidates = Array.from(
      document.querySelectorAll('button, a, [role="button"]')
    );
    for (const el of candidates) {
      const text = (el.innerText || el.textContent || '').trim();
      if (!text || text.length > 30) continue;
      if (!rx.test(text)) continue;
      const rect = el.getBoundingClientRect();
      if (rect.width === 0 || rect.height === 0) continue;
      return el;
      }
      return null;
    }, LOAD_MORE_TEXT.source);
  } catch (err) {
    // Context destroyed by navigation while searching — treat as "no button".
    return false;
  }

  const el = handle.asElement();
  if (!el) {
    await handle.dispose();
    return false;
  }
  await el.scrollIntoViewIfNeeded().catch(() => {});
  await el.click({ timeout: 5000 }).catch(() => {});
  await handle.dispose();
  return true;
}

/**
 * Drive a JS-heavy page: navigate, wait for load, then human-scroll + load-more
 * in a loop, invoking onRound() after each settle so the caller can extract live.
 *
 * Stops when ANY of:
 *  - deadline reached (time guard),
 *  - shouldStop() returns true (manual pause/SIGINT),
 *  - no new scroll height for `maxIdleRounds` consecutive rounds and no load-more.
 *
 * @returns {Promise<{reason:string, rounds:number}>}
 */
async function crawl(page, options = {}) {
  const {
    url,
    plan = {},
    deadlineMs = Date.now() + config.timing.totalRunMs,
    shouldStop = () => false,
    onRound = async () => {},
    onProgress = () => {},
  } = options;

  const loadMoreSelector = plan.loadMoreSelector || null;
  const scrollContainer = plan.scrollContainer || null;
  const navTimeoutMs = options.navTimeoutMs || config.crawler.navTimeoutMs;
  const shouldFinishBatch = options.shouldFinishBatch || (() => false);
  const maxIdleRounds = 4;

  // --- Navigation with a hard timeout so goto can never hang forever. ---
  onProgress({ phase: 'navigating', url });
  try {
    await page.goto(url, { waitUntil: 'domcontentloaded', timeout: navTimeoutMs });
  } catch (err) {
    onProgress({ phase: 'nav_failed', message: oneLine(err.message) });
    onProgress({ phase: 'done', reason: 'nav_failed', rounds: 0 });
    return { reason: 'nav_failed', rounds: 0 };
  }
  onProgress({ phase: 'page_loaded' });

  // Cap the networkidle wait: many sites never go idle (analytics/websockets),
  // and a long wait here would burn the batch window before scrolling starts.
  const idleOk = await page
    .waitForLoadState('networkidle', { timeout: config.crawler.idleTimeoutMs })
    .then(() => true)
    .catch(() => false);
  onProgress({ phase: idleOk ? 'networkidle' : 'networkidle_timeout' });

  // --- Give SPA content a chance to hydrate before judging the page. ---
  const reviewSelector = plan.reviewSelector || null;
  if (reviewSelector) {
    onProgress({ phase: 'await_content' });
    await page
      .waitForSelector(reviewSelector, { timeout: config.crawler.contentTimeoutMs, state: 'attached' })
      .catch(() => {});
  }
  await think(800, 1600);

  // --- Bot-block / empty-page detection (after hydration). ---
  const block = await detectBlock(page, reviewSelector);
  if (block.blocked) {
    onProgress({ phase: 'page_blocked', reason: block.reason });
    onProgress({ phase: 'done', reason: 'page_blocked', rounds: 0 });
    return { reason: 'page_blocked', rounds: 0 };
  }

  let rounds = 0;
  let idle = 0;
  let lastMax = -1;
  let reason = 'complete';

  while (true) {
    if (Date.now() >= deadlineMs) {
      reason = 'time_guard';
      break;
    }
    if (await safeShouldStop(shouldStop)) {
      reason = 'stopped';
      break;
    }
    if (await safeShouldStop(shouldFinishBatch)) {
      reason = 'finished';
      break;
    }

    const step = await humanScrollStep(page, scrollContainer);
    await think();
    rounds += 1;

    // A redirect/navigation can destroy the context mid-step; re-settle and retry.
    if (step.navigated) {
      onProgress({ phase: 'renavigate', rounds });
      await page.waitForLoadState('networkidle', { timeout: 15000 }).catch(() => {});
      await think(800, 1600);
      continue;
    }

    const { y, max } = step;
    onProgress({ phase: 'scroll', rounds, y, max });

    // Let the caller extract whatever is currently on the page (never fatal).
    try {
      await onRound(page);
    } catch (err) {
      onProgress({ phase: 'extract_error', rounds, message: err.message });
    }

    const grew = max > lastMax + 5;
    lastMax = Math.max(lastMax, max);

    const atBottom = y >= max - 5;
    if (atBottom || !grew) {
      const clicked = await clickLoadMore(page, loadMoreSelector);
      if (clicked) {
        onProgress({ phase: 'load_more', rounds });
        await page.waitForLoadState('networkidle', { timeout: 15000 }).catch(() => {});
        await think(1000, 2200);
        idle = 0;
        continue;
      }
      idle += 1;
      if (idle >= maxIdleRounds) {
        reason = 'no_more_content';
        break;
      }
    } else {
      idle = 0;
    }
  }

  onProgress({ phase: 'done', reason, rounds });
  return { reason, rounds };
}

async function safeShouldStop(fn) {
  try {
    return await fn();
  } catch {
    return false;
  }
}

/**
 * Heuristic detection of a bot-challenge or empty page so we emit a clear status
 * instead of silently scrolling a wall. Looks at visible text size + known
 * challenge phrases in the title/body.
 */
async function detectBlock(page, reviewSelector) {
  let info;
  try {
    info = await page.evaluate((sel) => ({
      title: document.title || '',
      textLen: (document.body && document.body.innerText
        ? document.body.innerText.replace(/\s+/g, ' ').trim().length
        : 0),
      sample: (document.body && document.body.innerText ? document.body.innerText : '')
        .replace(/\s+/g, ' ')
        .trim()
        .slice(0, 400),
      reviewCount: sel ? document.querySelectorAll(sel).length : -1,
    }), reviewSelector);
  } catch (err) {
    return { blocked: false };
  }

  // Real anti-bot interstitials always block, regardless of content.
  const CHALLENGE = /(captcha|are you (a )?human|verify you are|just a moment|access denied|unusual traffic|cf-browser-verification|checking your browser|enable javascript and cookies|request blocked)/i;
  if (CHALLENGE.test(`${info.title} ${info.sample}`)) {
    return { blocked: true, reason: 'challenge/anti-bot page detected' };
  }
  // If the known review nodes rendered, the page is good (SPA hydrated).
  if (info.reviewCount > 0) return { blocked: false };
  // No review nodes AND almost no text → genuinely empty/blocked.
  if (info.reviewCount === 0 && info.textLen < 200) {
    return { blocked: true, reason: `no review content rendered (${info.textLen} chars)` };
  }
  if (info.reviewCount < 0 && info.textLen < 200) {
    return { blocked: true, reason: `very little visible text (${info.textLen} chars)` };
  }
  return { blocked: false };
}

function oneLine(s) {
  return String(s || '').split('\n')[0].slice(0, 200);
}

module.exports = { crawl, clickLoadMore };
