'use strict';

const config = require('../config');

function randInt(min, max) {
  return Math.floor(min + Math.random() * (max - min));
}

/** Resolve after a randomized human-like delay within the configured range. */
function think(minMs, maxMs) {
  const lo = minMs != null ? minMs : config.timing.scrollMinDelayMs;
  const hi = maxMs != null ? maxMs : config.timing.scrollMaxDelayMs;
  return new Promise((resolve) => setTimeout(resolve, randInt(lo, hi)));
}

/**
 * Scroll the page down by one human-ish step (partial viewport with jitter)
 * and return the new scrollY. Operates on window or a given container selector.
 */
async function humanScrollStep(page, containerSelector) {
  try {
    return await page.evaluate((sel) => {
      const jitter = 0.5 + Math.random() * 0.4; // 50%-90% of viewport
      if (sel) {
        const el = document.querySelector(sel);
        if (el) {
          el.scrollTop += el.clientHeight * jitter;
          return { y: el.scrollTop, max: el.scrollHeight };
        }
      }
      window.scrollBy(0, window.innerHeight * jitter);
      return {
        y: window.scrollY,
        max: document.body.scrollHeight - window.innerHeight,
      };
    }, containerSelector || null);
  } catch (err) {
    // A navigation/redirect can destroy the execution context mid-evaluate.
    // Treat as a no-op step; the crawler will re-settle and retry.
    return { y: 0, max: 0, navigated: true };
  }
}

module.exports = { think, humanScrollStep, randInt };
