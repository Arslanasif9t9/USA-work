'use strict';

const config = require('./config');
const browser = require('./crawler/browser');
const { crawl } = require('./crawler/crawler');
const { extractRawText } = require('./extractor/rawText');
const { filterText } = require('./ai/reviewFilter');
const localCleaner = require('./extractor/localCleaner');
const { loadSiteConfig } = require('./extractor/selectors');
const { Memory, canonicalUrl } = require('./dedup/memory');
const { beginBatch, appendRawBlocks, appendFiltered, writeNote, appendSeparator } = require('./output/writer');
const { collectCandidateLinks, selectLinks, normHost } = require('./ai/linkSelector');
const gitSync = require('./git/sync');
const settings = require('./settings');
const { SessionControl } = require('./control/sessionControl');

/**
 * Shared core flow (used by both CLI and the web server).
 *
 * For each batch:
 *   crawl (human scroll + load-more, live extraction) → dedup via memory →
 *   write TXT → flush memory → git sync → ask to continue.
 *
 * @param {object} args
 * @param {object} args.plan        Normalized scraping plan (must have a valid url).
 * @param {SessionControl} args.control
 * @param {(s:object)=>void} [args.onStatus]   progress/status callback
 * @param {()=>Promise<boolean>} [args.askContinue]  return true to run another batch
 * @returns {Promise<{batches:Array, totalReviews:number, memory:object}>}
 */
async function runSession({ plan, control, onStatus = () => {}, askContinue, handleSignals = true, userPrompt = '' }) {
  if (!plan || !plan.url) throw new Error('runSession requires a plan with a url');

  // Apply web-editable settings (settings.json) onto config; .env is the fallback.
  // This sets timing, headless, scroll speed, gemini model, git, and save location.
  const applied = settings.applyToConfig();
  onStatus({ type: 'settings', saveLocation: applied.saveLocation, saveLocationOk: applied.saveLocationOk });

  const ctrl = control || new SessionControl();
  const memory = new Memory().load();

  // Overlay any per-site config (configs/{site}.json) onto the plan so its
  // loadMoreSelector / scrollContainer reach the crawler (not just the extractor).
  const siteCfg = plan.siteName ? loadSiteConfig(plan.siteName) : null;
  if (siteCfg) {
    if (!plan.loadMoreSelector && siteCfg.loadMoreSelector) plan.loadMoreSelector = siteCfg.loadMoreSelector;
    if (!plan.scrollContainer && siteCfg.scrollContainer) plan.scrollContainer = siteCfg.scrollContainer;
    // Expose the review selector so the crawler can wait for content to hydrate.
    if (!plan.reviewSelector && siteCfg.reviewSelector) plan.reviewSelector = siteCfg.reviewSelector;
    onStatus({ type: 'config', siteName: plan.siteName, source: 'site_config' });
  }

  // FIX 2: never sit on "Launching browser" forever — cap launch at 20s.
  onStatus({ type: 'browser', phase: 'launching', headless: config.crawler.headless });
  let session;
  try {
    session = await withTimeout(browser.launch(), 20000, 'browser launch timed out after 20s');
  } catch (err) {
    onStatus({ type: 'browser', phase: 'launch_failed', message: err.message });
    throw new Error(`Browser failed to launch: ${err.message}`);
  }
  let { page, close } = session; // mutable so we can relaunch after a browser crash
  onStatus({ type: 'browser', phase: 'launched' });

  // Re-launch the browser if the page/context died (e.g. after a crash) so a
  // user-chosen "Continue" can resume.
  async function ensurePageAlive() {
    try {
      await page.evaluate(() => 1);
      return;
    } catch {
      /* page/browser is dead → relaunch below */
    }
    try { await close(); } catch (_) { /* ignore */ }
    const s = await withTimeout(browser.launch(), 20000, 'browser relaunch timed out');
    page = s.page;
    close = s.close;
    onStatus({ type: 'browser', phase: 'relaunched' });
  }

  const summary = { batches: [], totalReviews: 0, memory: memory.stats() };

  // --- Continuous run bounded by a TOTAL time budget, with periodic checkpoints. ---
  const startTs = Date.now();
  const totalMs = config.timing.totalRunMs;
  const checkpointMs = config.timing.checkpointMs;
  const deadline = startTs + totalMs;

  // Deep-crawl is ON if the toggle is set OR the user gave a bare domain/homepage.
  const maxPages = config.crawler.maxPages;
  const deepCrawl = Boolean(config.deepCrawl) || isBareDomain(plan.url);
  const startHost = normHost(safeHost(plan.url));

  // One session = one file pair (clean + RAW), created up front.
  const out = beginBatch({ siteName: plan.siteName, url: plan.url });

  onStatus({ type: 'batch_start', batch: 1, url: plan.url, startTs, limitMs: totalMs, file: out.file, rawFile: out.rawFile, deepCrawl, maxPages });
  onStatus({ type: 'file_created', batch: 1, file: out.file, rawFile: out.rawFile });

  // Shared collection state.
  const rawSeen = new Set();
  const rawAll = []; // every distinct RAW block as { url, text } (also appended live to disk)
  const filteredSeen = new Set(); // session-local dedup for the clean file
  const writtenSeparators = new Set(); // urls whose "--- from ---" header is already in the clean file
  let filteredIndex = 0; // count of rawAll already filtered
  let recordIndex = 0; // running [n] number in the clean file
  let finalNoteWritten = false;

  // Checkpoints are serialized via a promise chain so they never overlap and the
  // FINAL one can drain anything in flight.
  let chain = Promise.resolve();
  const scheduleCheckpoint = (label) => {
    chain = chain.then(() => doCheckpoint(label)).catch(() => {});
    return chain;
  };

  async function doCheckpoint(label) {
    const claim = rawAll.length;
    if (claim <= filteredIndex) return; // nothing new since last checkpoint
    const slice = rawAll.slice(filteredIndex, claim);

    // Group consecutive raw blocks by their source page so each page's records
    // get the correct "--- from: <url> ---" header and numbering stays continuous.
    const groups = [];
    for (const e of slice) {
      const last = groups[groups.length - 1];
      if (last && last.url === e.url) last.texts.push(e.text);
      else groups.push({ url: e.url, texts: [e.text] });
    }

    onStatus({ type: 'filtering', batch: 1, rawLines: slice.length, checkpoint: label });

    let consumed = 0;
    let added = 0;
    let usedGemini = false;
    let usedLocal = false;
    for (const g of groups) {
      const result = await filterText(g.texts.join('\n'), userPrompt);

      // Gemini first; if it FAILS or returns NOTHING, fall back to the local
      // (no-AI) cleaner so the clean file is still populated. RAW is always kept.
      let recLines;
      if (result.ok && result.lines.length) {
        recLines = result.lines;
        usedGemini = true;
      } else {
        recLines = localCleaner.cleanReviews(g.texts);
        usedLocal = true;
      }
      consumed += g.texts.length;

      const fresh = [];
      for (const line of recLines) {
        const key = line.toLowerCase();
        if (filteredSeen.has(key)) continue;
        filteredSeen.add(key);
        fresh.push(line);
        memory.addReview(line);
      }
      if (fresh.length) {
        if (deepCrawl && !writtenSeparators.has(g.url)) {
          appendSeparator(out.file, g.url); // "--- from: <url> ---"
          writtenSeparators.add(g.url);
        }
        appendFiltered(out.file, fresh, recordIndex); // continue numbering
        recordIndex += fresh.length;
        added += fresh.length;
        finalNoteWritten = false;
      }
    }

    if (consumed > 0) {
      filteredIndex += consumed;
      memory.flush(); // persist dedup memory at each checkpoint
      const via = usedGemini && usedLocal ? 'mixed' : usedLocal ? 'local' : 'gemini';
      onStatus({
        type: 'filtered_saved',
        batch: 1,
        count: recordIndex,
        added,
        via,
        file: out.file,
        checkpoint: label,
      });
    }
  }

  // Background auto-save timer.
  const timer = setInterval(() => scheduleCheckpoint('periodic'), checkpointMs);

  // Flush + final checkpoint if interrupted (SIGINT / Stop).
  ctrl.onInterrupt = async () => {
    memory.flush();
  };
  if (handleSignals) ctrl.installSignalHandler();

  // --- Queue-based crawl: single page when deep-crawl OFF, many pages when ON. ---
  const queue = [plan.url];
  const visited = new Set();
  let pagesVisited = 0;

  try {
    while (
      queue.length &&
      pagesVisited < maxPages &&
      Date.now() < deadline &&
      !ctrl.shouldStop()
    ) {
      const url = queue.shift();
      const key = canonicalUrl(url);
      if (visited.has(key)) continue;
      visited.add(key);
      memory.addUrl(url);
      pagesVisited += 1;

      const currentUrl = url;
      onStatus({ type: 'page', batch: 1, url, index: pagesVisited, maxPages, queued: queue.length });
      if (deepCrawl) appendSeparator(out.rawFile, url); // group RAW per page

      // Crawl one page. A NORMAL run never pauses; only a halting ERROR prompts.
      let crawlResult = null;
      let thrown = null;
      try {
        crawlResult = await crawl(page, {
          url,
          plan,
          deadlineMs: deadline, // TOTAL run budget across all pages
          navTimeoutMs: config.crawler.navTimeoutMs,
          shouldStop: () => ctrl.shouldStop(),
          shouldFinishBatch: () => ctrl.shouldFinishBatch(),
          onProgress: (p) => onStatus({ type: 'progress', batch: 1, ...p }),
          onRound: async (pg) => {
            const lines = await extractRawText(pg);
            const fresh = [];
            for (const ln of lines) {
              const k = ln.toLowerCase();
              if (rawSeen.has(k)) continue;
              rawSeen.add(k);
              fresh.push(ln);
            }
            if (fresh.length) {
              appendRawBlocks(out.rawFile, fresh); // RAW appended live (safety net)
              for (const t of fresh) rawAll.push({ url: currentUrl, text: t });
              onStatus({ type: 'raw', batch: 1, newCount: fresh.length, total: rawAll.length });
            }
          },
        });
        // Test hook: simulate a mid-run browser/navigation failure.
        if (process.env.FORCE_RUN_ERROR && pagesVisited === 1) {
          throw new Error('simulated browser/navigation failure (FORCE_RUN_ERROR)');
        }
      } catch (err) {
        thrown = err;
      }

      // Deep crawl: pick next links (only when this page crawled OK).
      if (!thrown && deepCrawl && pagesVisited < maxPages && Date.now() < deadline && !ctrl.shouldStop()) {
        try {
          const candidates = await collectCandidateLinks(page, startHost);
          const { hrefs, source } = await selectLinks(candidates, userPrompt);
          let addedLinks = 0;
          for (const href of hrefs) {
            const hk = canonicalUrl(href);
            if (normHost(safeHost(href)) !== startHost) continue; // same-domain guard
            if (visited.has(hk) || queue.some((q) => canonicalUrl(q) === hk)) continue;
            queue.push(href);
            addedLinks += 1;
          }
          onStatus({ type: 'links', batch: 1, url, candidates: candidates.length, picked: hrefs.length, added: addedLinks, source, queued: queue.length });
        } catch (err) {
          onStatus({ type: 'links_error', batch: 1, message: err.message });
        }
      }

      // --- Error/issue handling: prompt ONLY when crawling is actually halted. ---
      const pageIssue = thrown
        ? thrown.message
        : (crawlResult && (crawlResult.reason === 'nav_failed' || crawlResult.reason === 'page_blocked'))
          ? `${crawlResult.reason} on ${url}`
          : null;
      const moreWork = queue.length > 0 && pagesVisited < maxPages && Date.now() < deadline;

      if (pageIssue && !ctrl.shouldStop()) {
        if (!thrown && moreWork) {
          // Non-halting: a single page failed but there are more queued pages → carry on.
          onStatus({ type: 'page_issue', batch: 1, url, reason: pageIssue });
        } else {
          // Halting issue → (a) auto-save a checkpoint, then (b) ask Continue/Stop.
          try { await chain; await scheduleCheckpoint('error'); await chain; } catch (_) { /* best effort */ }
          onStatus({ type: 'run_error', batch: 1, reason: pageIssue });
          const cont = askContinue ? await askContinue({ error: true, reason: pageIssue }) : false;
          if (cont && !ctrl.shouldStop()) {
            await ensurePageAlive(); // relaunch browser if it died, then resume
            ctrl.reset();
            continue;
          }
          break; // Stop → exit; already-saved work stays.
        }
      }

      // "Finish now" ends the whole crawl pass after the current page.
      if (ctrl.shouldFinishBatch()) break;
    }
  } finally {
    // CRASH SAFETY: always run a FINAL checkpoint before exit so nothing collected is lost.
    clearInterval(timer);
    try {
      await chain; // drain any in-flight periodic checkpoint
      await scheduleCheckpoint('final');
      await chain;
    } catch (_) {
      /* checkpoint best-effort on shutdown */
    }

    onStatus({ type: 'raw_saved', batch: 1, count: rawAll.length, file: out.rawFile });

    // If we never wrote a single record, leave a clear note (RAW is still on disk).
    if (recordIndex === 0 && !finalNoteWritten) {
      writeNote(out.file, `No matching content found — see ${path_basename(out.rawFile)}`);
      finalNoteWritten = true;
      onStatus({ type: 'filter_note', batch: 1, reason: 'no_matches', file: out.file });
    }

    memory.flush();
    ctrl.removeSignalHandler();

    let git = { committed: false, pushed: false, reason: 'disabled' };
    try {
      const msg = `scrape: ${plan.siteName} ${path_basename(out.file)} (+${recordIndex} items, ${rawAll.length} raw)`;
      git = await gitSync.syncBatch(msg, [out.file, out.rawFile, config.paths.scrapedUrls, config.paths.reviewHashes]);
    } catch (_) {
      git = { committed: false, pushed: false, reason: 'git_error' };
    }

    await close();

    const batchResult = {
      batch: 1,
      newReviews: recordIndex,
      rawLines: rawAll.length,
      pages: pagesVisited,
      deepCrawl,
      file: out.file,
      rawFile: out.rawFile,
      git,
    };
    summary.batches.push(batchResult);
    summary.totalReviews = recordIndex;
    summary.pages = pagesVisited;
    summary.memory = memory.stats();
    onStatus({ type: 'batch_done', ...batchResult });
  }

  onStatus({ type: 'session_done', ...summary });
  return summary;
}

function path_basename(p) {
  return String(p).split(/[\\/]/).pop();
}

function safeHost(url) {
  try { return new URL(url).hostname; } catch { return ''; }
}

/** True when the URL points at a site root / homepage (no meaningful path). */
function isBareDomain(url) {
  try {
    const u = new URL(url);
    return (u.pathname === '/' || u.pathname === '') && !u.search;
  } catch {
    return false;
  }
}

/** Reject if the promise doesn't settle within ms (used to bound browser.launch). */
function withTimeout(promise, ms, message) {
  let timer;
  const timeout = new Promise((_, reject) => {
    timer = setTimeout(() => reject(new Error(message || `timed out after ${ms}ms`)), ms);
  });
  return Promise.race([promise, timeout]).finally(() => clearTimeout(timer));
}

module.exports = { runSession };
