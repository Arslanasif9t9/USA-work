'use strict';

const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const config = require('../config');

/**
 * Memory-based deduplication store.
 *
 * - Visited URLs live in a Set (O(1) membership).
 * - Review hashes live in a Set of SHA-256 hex digests (O(1) membership).
 *
 * Optimized for large datasets: all lookups/inserts are in-memory; disk writes
 * happen only on explicit flush() (or debounced autoFlush), never per-record.
 */
class Memory {
  constructor(opts = {}) {
    this.urlsPath = opts.urlsPath || config.paths.scrapedUrls;
    this.hashesPath = opts.hashesPath || config.paths.reviewHashes;
    this.urls = new Set();
    this.hashes = new Set();
    this._dirty = false;
    this._flushTimer = null;
    this._loaded = false;
  }

  load() {
    this.urls = new Set(readJson(this.urlsPath, []));
    // hashes persisted as an object { hash: 1 } for compactness + fast load.
    const hashObj = readJson(this.hashesPath, {});
    this.hashes = new Set(Object.keys(hashObj));
    this._loaded = true;
    this._dirty = false;
    return this;
  }

  static hashReview(text) {
    return crypto
      .createHash('sha256')
      .update(normalizeForHash(text), 'utf8')
      .digest('hex');
  }

  hasUrl(url) {
    return this.urls.has(canonicalUrl(url));
  }

  addUrl(url) {
    const u = canonicalUrl(url);
    if (this.urls.has(u)) return false;
    this.urls.add(u);
    this._markDirty();
    return true;
  }

  hasReview(text) {
    return this.hashes.has(Memory.hashReview(text));
  }

  /** Adds a review hash. Returns true if new, false if duplicate. */
  addReview(text) {
    const h = Memory.hashReview(text);
    if (this.hashes.has(h)) return false;
    this.hashes.add(h);
    this._markDirty();
    return true;
  }

  /** Filters an array of review strings down to only the unseen ones, recording them. */
  filterNew(reviews) {
    const fresh = [];
    for (const r of reviews) {
      if (this.addReview(r)) fresh.push(r);
    }
    return fresh;
  }

  _markDirty() {
    this._dirty = true;
  }

  /** Schedule a debounced flush so bursty inserts don't hammer the disk. */
  autoFlush(delayMs = 2000) {
    if (this._flushTimer) return;
    this._flushTimer = setTimeout(() => {
      this._flushTimer = null;
      this.flush();
    }, delayMs);
    if (this._flushTimer.unref) this._flushTimer.unref();
  }

  flush() {
    if (!this._dirty) return false;
    ensureDir(path.dirname(this.urlsPath));
    ensureDir(path.dirname(this.hashesPath));

    writeJsonAtomic(this.urlsPath, Array.from(this.urls));

    const hashObj = {};
    for (const h of this.hashes) hashObj[h] = 1;
    writeJsonAtomic(this.hashesPath, hashObj);

    this._dirty = false;
    return true;
  }

  stats() {
    return { urls: this.urls.size, reviews: this.hashes.size };
  }
}

function canonicalUrl(url) {
  try {
    const u = new URL(String(url).trim());
    u.hash = '';
    // Drop trailing slash on path for stable identity.
    if (u.pathname.length > 1 && u.pathname.endsWith('/')) {
      u.pathname = u.pathname.slice(0, -1);
    }
    return u.toString();
  } catch {
    return String(url).trim();
  }
}

function normalizeForHash(text) {
  return String(text)
    .normalize('NFKC')
    .replace(/\s+/g, ' ')
    .trim()
    .toLowerCase();
}

function readJson(file, fallback) {
  try {
    const raw = fs.readFileSync(file, 'utf8');
    if (!raw.trim()) return fallback;
    return JSON.parse(raw);
  } catch {
    return fallback;
  }
}

function writeJsonAtomic(file, data) {
  const tmp = `${file}.tmp`;
  fs.writeFileSync(tmp, JSON.stringify(data), 'utf8');
  fs.renameSync(tmp, file);
}

function ensureDir(dir) {
  fs.mkdirSync(dir, { recursive: true });
}

module.exports = { Memory, canonicalUrl };
