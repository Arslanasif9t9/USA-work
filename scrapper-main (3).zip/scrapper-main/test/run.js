'use strict';

/**
 * Lightweight no-network checks for the deterministic core modules:
 * cleaner, memory (dedup), and writer. Run with: npm test
 */

const fs = require('fs');
const os = require('os');
const path = require('path');
const assert = require('assert');

let passed = 0;
function test(name, fn) {
  try {
    fn();
    passed++;
    console.log(`  ok  ${name}`);
  } catch (err) {
    console.error(`FAIL  ${name}\n      ${err.message}`);
    process.exitCode = 1;
  }
}

// --- cleaner ---------------------------------------------------------------
const cleaner = require('../src/extractor/cleaner');

test('cleaner strips HTML tags', () => {
  const out = cleaner.clean('<p>Great <b>psychic</b> reading, very accurate!</p>', { minLength: 5 });
  assert.ok(!/[<>]/.test(out), 'no angle brackets remain');
  assert.strictEqual(out, 'Great psychic reading, very accurate!');
});

test('cleaner decodes entities and collapses whitespace', () => {
  const out = cleaner.clean('Loved   it &amp; will\nreturn &#33;', { minLength: 3 });
  assert.strictEqual(out, 'Loved it & will return !');
});

test('cleaner drops too-short and letter-less fragments', () => {
  assert.strictEqual(cleaner.clean('ok', { minLength: 40 }), '');
  assert.strictEqual(cleaner.clean('12345 67890', { minLength: 3 }), '');
});

test('cleanMany dedupes case-insensitively within a batch', () => {
  const out = cleaner.cleanMany(['Nice reading', 'nice reading', 'Different one here'], { minLength: 3 });
  assert.strictEqual(out.length, 2);
});

// --- memory (dedup) --------------------------------------------------------
const { Memory } = require('../src/dedup/memory');

test('memory detects duplicate urls and reviews + persists', () => {
  const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'scraper-mem-'));
  const urlsPath = path.join(tmp, 'urls.json');
  const hashesPath = path.join(tmp, 'hashes.json');

  const m = new Memory({ urlsPath, hashesPath }).load();
  assert.strictEqual(m.addUrl('https://x.com/a'), true);
  assert.strictEqual(m.addUrl('https://x.com/a/'), false, 'trailing slash is same url');
  assert.strictEqual(m.addReview('A wonderful, detailed review text here.'), true);
  assert.strictEqual(m.addReview('a wonderful, detailed review text here.'), false, 'hash is normalized');
  m.flush();

  const reloaded = new Memory({ urlsPath, hashesPath }).load();
  assert.ok(reloaded.hasUrl('https://x.com/a'));
  assert.ok(reloaded.hasReview('A WONDERFUL, DETAILED REVIEW TEXT HERE.'));
  assert.deepStrictEqual(reloaded.stats(), { urls: 1, reviews: 1 });
});

test('memory filterNew returns only unseen reviews', () => {
  const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'scraper-mem2-'));
  const m = new Memory({
    urlsPath: path.join(tmp, 'u.json'),
    hashesPath: path.join(tmp, 'h.json'),
  }).load();
  const first = m.filterNew(['one review long enough', 'two review long enough']);
  assert.strictEqual(first.length, 2);
  const second = m.filterNew(['two review long enough', 'three review long enough']);
  assert.strictEqual(second.length, 1);
  assert.strictEqual(second[0], 'three review long enough');
});

// --- writer ----------------------------------------------------------------
const writer = require('../src/output/writer');

test('writer auto-increments batch files with line-per-review', () => {
  const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'scraper-out-'));
  // Point writer at a temp raw_data via the config path override is not exposed,
  // so we test nextBatchNumber + batchFileName directly plus a manual write.
  assert.strictEqual(writer.batchFileName(1), 'batch_001.txt');
  assert.strictEqual(writer.batchFileName(42), 'batch_042.txt');

  const dir = path.join(tmp, 'site');
  fs.mkdirSync(dir, { recursive: true });
  assert.strictEqual(writer.nextBatchNumber(dir), 1);
  fs.writeFileSync(path.join(dir, 'batch_001.txt'), 'a\n');
  fs.writeFileSync(path.join(dir, 'batch_002.txt'), 'b\n');
  assert.strictEqual(writer.nextBatchNumber(dir), 3);
});

test('writeBatch writes only review lines, no empty, returns count', () => {
  const r = writer.writeBatch(['  first review  ', '', '   ', 'second review'], {
    siteName: '__test_writer_site__',
  });
  assert.ok(r, 'returns a result');
  assert.strictEqual(r.count, 2);
  const content = fs.readFileSync(r.file, 'utf8');
  assert.strictEqual(content, 'first review\nsecond review\n');
  // cleanup the file we created under raw_data
  fs.rmSync(path.dirname(r.file), { recursive: true, force: true });
});

console.log(`\n${passed} checks passed.`);
