# AI Review Scraper

AI-powered web scraper that extracts **only public review text** from JS-heavy sites,
deduplicates across runs, and stores clean TXT output. GitHub-ready and team-friendly.

> Ethics & safety: public data only, **no login bypass**, slow human-like crawling.
> Always respect each site's Terms of Service and `robots.txt`.

## Features

- **Gemini-powered planner** turns a free-text prompt into a structured scraping plan
  (falls back to rule-based planning when no API key is set, so it always runs).
- **Playwright crawler** with human-like scrolling, infinite-scroll + "load more" support,
  and a 5–10 minute batch time guard.
- **Generic extraction** that auto-detects review blocks, with optional per-site CSS
  selector overrides in `configs/`.
- **Deduplication memory** (`memory/`) of visited URLs + review hashes — optimized for
  large datasets (O(1) in-memory lookups, debounced disk flush).
- **TXT output**: `raw_data/{site_name}/batch_xxx.txt`, one review per line, no HTML/metadata.
- **Pause control**: between batches it asks "Continue scraping next batch? (yes/no)";
  `Ctrl+C` finishes the current batch, saves, and exits cleanly.
- **GitHub sync**: auto commit + `pull --rebase` + push per batch (no overwrites).
- **Two modes**: CLI and a simple web dashboard, sharing one core engine.

## Setup

```bash
npm install            # also runs `playwright install chromium`
cp .env.example .env   # then edit .env (Windows: copy .env.example .env)
```

Set `GEMINI_API_KEY` in `.env` for AI planning (optional — omit to use the rule-based planner).

## CLI mode

```bash
node index.js --url "https://example.com/reviews" --prompt "all customer reviews"
# or run with no args and answer the prompts interactively
npm run scrape
```

## Web dashboard

```bash
npm run web
# open http://localhost:3000
```

Enter a URL + prompt, watch live progress, approve each batch, and download the TXT.

## Output & memory layout

```
raw_data/
  example_com/
    batch_001.txt        # one review per line, plain text only
memory/
  scraped_urls.json      # visited URLs (committed — shared dedup state)
  review_hashes.json     # SHA-256 of each review (committed)
```

## Per-site tuning (optional)

Drop a `configs/{site_name}.json` (e.g. `configs/example_com.json`) to use exact selectors:

```json
{
  "host": "example.com",
  "reviewSelector": ".review .review-text",
  "loadMoreSelector": "button.load-more",
  "scrollContainer": null,
  "exclude": [".reply"]
}
```

`site_name` is derived from the host: `www.example.com` → `example_com`.

## Team workflow (GitHub)

1. `git pull` the repo.
2. Run the scraper — it skips URLs/reviews already in `memory/`, so no duplicate work.
3. Enable `GIT_SYNC=true` in `.env`; each batch auto-commits the new TXT + memory and
   pushes with `pull --rebase` so teammates never overwrite each other.

## Environment variables

See `.env.example` — covers Gemini key/model, batch timing, scroll delays, headless mode,
minimum review length, and git sync remote/branch.

## Architecture

```
INPUT (url + prompt)
  → AI planner (Gemini)      src/ai/*
  → Crawler (Playwright)     src/crawler/*
  → Extractor (clean text)   src/extractor/*
  → Dedup (memory JSON)      src/dedup/memory.js
  → Output writer (TXT)      src/output/writer.js
  → Git sync                 src/git/sync.js
  → Control loop (pause)     src/control/sessionControl.js
The orchestrator (src/orchestrator.js) wires these together and is shared by
the CLI (index.js) and the web server (server/).
```
