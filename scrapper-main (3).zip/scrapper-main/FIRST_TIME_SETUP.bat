@echo off
REM ============================================================
REM  AI Review Scraper - First-time setup (double-click to run)
REM  Installs everything and creates a .env you only edit once.
REM ============================================================
setlocal
cd /d "%~dp0"

echo.
echo ============================================================
echo   AI Review Scraper - First-time setup
echo ============================================================
echo.

REM --- 1. Check Node.js ---
where node >nul 2>nul
if errorlevel 1 (
  echo [X] Node.js is NOT installed.
  echo.
  echo     Please install Node.js ^(the "LTS" version^) from:
  echo         https://nodejs.org
  echo     Then run this FIRST_TIME_SETUP.bat again.
  echo.
  pause
  exit /b 1
)
for /f "delims=" %%v in ('node --version') do echo [OK] Node.js found: %%v
echo.

REM --- 2. Install project dependencies ---
echo [*] Installing project dependencies ^(npm install^)...
call npm install
if errorlevel 1 (
  echo [X] npm install failed. Check your internet connection and try again.
  pause
  exit /b 1
)
echo.

REM --- 3. Install the Chromium browser engine ---
echo [*] Installing the Chromium browser engine ^(this can take a minute^)...
call npx playwright install chromium
if errorlevel 1 (
  echo [!] Chromium install reported a problem. You can re-run this later with:
  echo        npx playwright install chromium
)
echo.

REM --- 4. Create .env if it does not exist (NEVER overwrite an existing one) ---
if exist ".env" (
  echo [OK] A .env file already exists - leaving it untouched.
) else (
  echo [*] Creating .env with a placeholder key...
  >  ".env" echo GEMINI_API_KEY=PASTE_YOUR_KEY_HERE
  >> ".env" echo GEMINI_MODEL=gemini-2.5-flash
  >> ".env" echo GIT_SYNC=false
  >> ".env" echo HEADLESS=false
  echo [OK] Created .env
)
echo.

echo ============================================================
echo   ALMOST DONE - one small step left:
echo ============================================================
echo.
echo   1^) Open the file ".env" in this folder ^(double-click it,
echo      or open with Notepad^).
echo   2^) Replace  PASTE_YOUR_KEY_HERE  with your Google Gemini key.
echo      Get a free key here:  https://aistudio.google.com/app/apikey
echo   3^) Save and close .env.
echo.
echo   After that, just double-click  START.bat  whenever you want
echo   to use the scraper. ^(Tip: it still works without a key - it
echo   uses a built-in cleaner and always saves the RAW text.^)
echo.
pause
endlocal
