@echo off
REM ============================================================
REM  AI Review Scraper - START (double-click to run)
REM  Starts the dashboard server AND opens it in your browser.
REM ============================================================
setlocal
cd /d "%~dp0"

REM Safety net: if dependencies are missing, point the user to setup.
if not exist "node_modules" (
  echo [!] It looks like this project hasn't been set up yet.
  echo     Please double-click  FIRST_TIME_SETUP.bat  first.
  echo.
  pause
  exit /b 1
)

echo.
echo Starting the AI Review Scraper dashboard...
echo Your browser will open automatically. Keep THIS window open while you work.
echo Press Ctrl+C here ^(or close this window^) to stop the server.
echo.

call npm run go

REM If the server exits/errors, keep the window open so the user can read why.
echo.
pause
endlocal
