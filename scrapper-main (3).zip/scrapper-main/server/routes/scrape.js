'use strict';

const express = require('express');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { analyze } = require('../../src/ai/promptAnalyzer');
const { isComplete } = require('../../src/ai/planSchema');
const { runSession } = require('../../src/orchestrator');
const { SessionControl } = require('../../src/control/sessionControl');
const { describeEvent, phaseOf } = require('../../src/statusText');

const router = express.Router();

/** In-memory job registry. Each job runs one scraping session. */
const jobs = new Map();

function ts() {
  return new Date().toISOString().slice(11, 19);
}

function log(job, msg) {
  // Server-side visibility into exactly what the crawl is doing.
  process.stdout.write(`[${ts()}] [job ${job.id}] ${msg}\n`);
}

function newJob() {
  const id = crypto.randomBytes(4).toString('hex');
  const job = {
    id,
    state: 'starting', // starting | running | awaiting | done | error
    phase: 'Starting…',
    events: [],
    batches: [],
    foundThisBatch: 0,
    savedTotal: 0,
    batchStartTs: null,
    batchLimitMs: null,
    lastFile: null,
    rawFile: null,
    rawCount: 0,
    filteredCount: 0,
    error: null,
    errorReason: null,
    control: new SessionControl(),
    _decision: null,
  };
  jobs.set(id, job);
  return job;
}

function record(job, ev) {
  const text = describeEvent(ev);
  const phase = phaseOf(ev);
  if (phase) job.phase = phase;

  // Maintain live counters / timer anchors.
  switch (ev.type) {
    case 'batch_start':
      job.foundThisBatch = 0;
      job.batchStartTs = ev.startTs || Date.now();
      job.batchLimitMs = ev.limitMs || null;
      if (ev.file) job.lastFile = ev.file;
      if (ev.rawFile) job.rawFile = ev.rawFile;
      break;
    case 'file_created':
      if (ev.file) job.lastFile = ev.file; // downloadable immediately (even while empty)
      if (ev.rawFile) job.rawFile = ev.rawFile;
      break;
    case 'raw':
      job.foundThisBatch = ev.total; // live raw line count
      break;
    case 'raw_saved':
      job.rawCount = ev.count;
      if (ev.file) job.rawFile = ev.file;
      break;
    case 'filtered_saved':
      job.filteredCount = ev.count;
      if (ev.file) job.lastFile = ev.file;
      break;
    case 'filter_note':
      job.filteredCount = 0;
      if (ev.file) job.lastFile = ev.file;
      break;
    case 'batch_done':
      job.savedTotal += ev.newReviews || 0;
      if (ev.file) job.lastFile = ev.file;
      if (ev.rawFile) job.rawFile = ev.rawFile;
      job.batches.push({
        batch: ev.batch,
        filtered: ev.newReviews || 0,
        rawLines: ev.rawLines || 0,
        file: ev.file,
        rawFile: ev.rawFile,
        git: ev.git,
      });
      job.batchStartTs = null; // batch no longer counting
      break;
    default:
      break;
  }

  if (text) {
    job.events.push({ t: Date.now(), type: ev.type, phase: ev.phase, text });
    if (job.events.length > 300) job.events.shift();
    log(job, text);
  }
}

// POST /api/scrape { url, prompt }
router.post('/scrape', async (req, res) => {
  const { url = '', prompt = '' } = req.body || {};
  if (!prompt && !url) {
    return res.status(400).json({ error: 'Provide at least a prompt or a url.' });
  }

  const { plan, source } = await analyze(prompt, { url });

  if (!isComplete(plan)) {
    return res.json({ status: 'need_info', questions: plan.missingInfoQuestions, plan });
  }

  const job = newJob();
  log(job, `planner=${source} site=${plan.siteName} strategy=${plan.scrollStrategy} url=${plan.url}`);
  res.json({ status: 'started', jobId: job.id, plan: publicPlan(plan) });

  runSession({
    plan,
    control: job.control,
    userPrompt: prompt, // the user's short "what to extract" text drives the AI filter
    handleSignals: false, // the web server owns process signals, not the job
    onStatus: (s) => record(job, s),
    // Called ONLY when a halting error interrupts the run (never on a normal run).
    askContinue: (info) =>
      new Promise((resolve) => {
        job.state = 'awaiting';
        job.errorReason = (info && info.reason) || 'unknown error';
        record(job, { type: 'awaiting_decision', reason: job.errorReason });
        job._decision = { resolve };
      }),
  })
    .then(() => {
      job.state = 'done';
      job.phase = 'Done';
    })
    .catch((err) => {
      job.state = 'error';
      job.error = err.message;
      job.phase = 'Error';
      record(job, { type: 'error', message: err.message });
    });

  job.state = 'running';
});

// GET /api/status/:id
router.get('/status/:id', (req, res) => {
  const job = jobs.get(req.params.id);
  if (!job) return res.status(404).json({ error: 'unknown job' });

  const running = Boolean(job.batchStartTs) && job.state === 'running';
  res.json({
    id: job.id,
    state: job.state,
    phase: job.phase,
    awaiting: job.state === 'awaiting',
    errorReason: job.errorReason,
    foundThisBatch: job.foundThisBatch,
    savedTotal: job.savedTotal,
    batch: {
      running,
      startTs: job.batchStartTs,
      limitMs: job.batchLimitMs,
      elapsedMs: job.batchStartTs ? Date.now() - job.batchStartTs : 0,
    },
    // Completed-batch history (each with filtered + raw counts; downloads keyed by batch).
    batches: job.batches.map((b) => ({
      batch: b.batch,
      filtered: b.filtered,
      rawLines: b.rawLines,
      hasFile: Boolean(b.file && fs.existsSync(b.file)),
      hasRaw: Boolean(b.rawFile && fs.existsSync(b.rawFile)),
    })),
    error: job.error,
    // Filtered (clean) result — latest
    hasDownload: Boolean(job.lastFile && fs.existsSync(job.lastFile)),
    downloadName: job.lastFile ? path.basename(job.lastFile) : null,
    lastFile: job.lastFile,
    filteredCount: job.filteredCount,
    filteredLines: job.filteredCount, // records, for display
    // RAW safety-net file — latest
    hasRaw: Boolean(job.rawFile && fs.existsSync(job.rawFile)),
    rawName: job.rawFile ? path.basename(job.rawFile) : null,
    rawFile: job.rawFile,
    rawLines: job.rawCount, // blocks, for display
    events: job.events.slice(-60),
  });
});

// POST /api/control/:id { action: 'continue' | 'stop' | 'finish' }
router.post('/control/:id', (req, res) => {
  const job = jobs.get(req.params.id);
  if (!job) return res.status(404).json({ error: 'unknown job' });
  const action = (req.body && req.body.action) || 'stop';

  if (action === 'stop') {
    job.control.requestStop();
    log(job, 'control: STOP requested');
  } else if (action === 'finish') {
    job.control.finishBatch();
    log(job, 'control: FINISH-NOW requested (ending current batch)');
  } else if (action === 'continue') {
    log(job, 'control: CONTINUE requested');
  }

  // Resolve a pending error-recovery decision (continue/stop only).
  if (job._decision && (action === 'continue' || action === 'stop')) {
    const { resolve } = job._decision;
    job._decision = null;
    job.state = 'running';
    job.errorReason = null; // clear the interruption banner on resume/stop
    resolve(action === 'continue');
  }
  res.json({ ok: true, action });
});

// GET /api/download/:id[?batch=N] → filtered (clean) TXT (latest, or a specific batch)
router.get('/download/:id', (req, res) => {
  const job = jobs.get(req.params.id);
  if (!job) return res.status(404).send('unknown job');
  const file = pickFile(job, req.query.batch, 'file') || job.lastFile;
  if (!file || !fs.existsSync(file)) return res.status(404).send('No file available yet.');
  res.download(file);
});

// GET /api/download-raw/:id[?batch=N] → RAW safety-net TXT (latest, or a specific batch)
router.get('/download-raw/:id', (req, res) => {
  const job = jobs.get(req.params.id);
  if (!job) return res.status(404).send('unknown job');
  const file = pickFile(job, req.query.batch, 'rawFile') || job.rawFile;
  if (!file || !fs.existsSync(file)) return res.status(404).send('No raw file available yet.');
  res.download(file);
});

function pickFile(job, batchNo, key) {
  if (!batchNo) return null;
  const rec = job.batches.find((b) => String(b.batch) === String(batchNo));
  return rec ? rec[key] : null;
}

function publicPlan(plan) {
  return {
    url: plan.url,
    siteName: plan.siteName,
    siteType: plan.siteType,
    scrollStrategy: plan.scrollStrategy,
    keywords: plan.keywords,
  };
}

module.exports = router;
