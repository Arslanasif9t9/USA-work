'use strict';

const express = require('express');
const settings = require('../../src/settings');

const router = express.Router();

// GET /api/settings → effective settings (defaults overlaid with settings.json)
router.get('/settings', (_req, res) => {
  res.json({
    settings: settings.resolved(),
    defaults: settings.defaults(),
    path: settings.SETTINGS_PATH,
  });
});

// POST /api/settings → validate + persist; creates save location; returns errors if any
router.post('/settings', (req, res) => {
  const result = settings.save(req.body || {});
  if (!result.ok) return res.status(400).json({ ok: false, errors: result.errors });
  res.json({ ok: true, settings: result.settings });
});

// POST /api/settings/reset → remove settings.json, back to .env defaults
router.post('/settings/reset', (_req, res) => {
  const result = settings.reset();
  res.json({ ok: true, settings: result.settings });
});

module.exports = router;
