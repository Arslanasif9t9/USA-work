'use strict';

const express = require('express');
const fs = require('fs');
const path = require('path');
const settings = require('../../src/settings');

const router = express.Router();

/** Base = the configured save location (created if missing). */
function baseDir() {
  const loc = settings.resolved().saveLocation;
  settings.ensureSaveLocation(loc);
  return loc;
}

/** Resolve a user-supplied relative path safely inside the save location. */
function safeResolve(rel) {
  const base = baseDir();
  const full = path.resolve(base, rel || '');
  const rb = path.resolve(base);
  if (full !== rb && !full.startsWith(rb + path.sep)) return null; // path traversal guard
  return full;
}

function isRaw(name) {
  return /_RAW\.txt$/i.test(name);
}

function countRecords(file, raw) {
  try {
    const txt = fs.readFileSync(file, 'utf8');
    if (!txt.trim()) return 0;
    if (raw) return txt.split('\n').filter((l) => l.trim()).length; // RAW blocks (one per line)
    const markers = txt.match(/^\[\d+\]$/gm); // filtered records [n]
    return markers ? markers.length : txt.split('\n').filter((l) => l.trim()).length;
  } catch {
    return 0;
  }
}

// GET /api/files → list all output files grouped by site folder, newest first
router.get('/files', (_req, res) => {
  const base = baseDir();
  const groups = {};
  let entries = [];
  try {
    entries = fs.readdirSync(base, { withFileTypes: true });
  } catch (e) {
    return res.json({ base, sites: [], error: e.message });
  }

  for (const dirent of entries) {
    if (!dirent.isDirectory()) continue;
    const site = dirent.name;
    const siteDir = path.join(base, site);
    let files = [];
    try { files = fs.readdirSync(siteDir); } catch { continue; }
    for (const name of files) {
      if (!name.toLowerCase().endsWith('.txt')) continue;
      const full = path.join(siteDir, name);
      let st;
      try { st = fs.statSync(full); } catch { continue; }
      if (!st.isFile()) continue;
      const raw = isRaw(name);
      (groups[site] = groups[site] || []).push({
        site,
        name,
        rel: path.join(site, name),
        type: raw ? 'RAW' : 'Filtered',
        count: countRecords(full, raw),
        size: st.size,
        mtime: st.mtimeMs,
      });
    }
  }

  const sites = Object.keys(groups)
    .sort()
    .map((site) => ({
      site,
      files: groups[site].sort((a, b) => b.mtime - a.mtime),
    }))
    // sites with the most recent file first
    .sort((a, b) => (b.files[0]?.mtime || 0) - (a.files[0]?.mtime || 0));

  res.json({ base, sites });
});

// GET /api/files/view?path=site/name → return text content
router.get('/files/view', (req, res) => {
  const full = safeResolve(req.query.path);
  if (!full || !fs.existsSync(full)) return res.status(404).json({ error: 'file not found' });
  try {
    res.json({ path: req.query.path, content: fs.readFileSync(full, 'utf8') });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// POST /api/files/save { path, content } → write back to disk
router.post('/files/save', (req, res) => {
  const full = safeResolve(req.body && req.body.path);
  if (!full) return res.status(400).json({ error: 'invalid path' });
  if (!fs.existsSync(full)) return res.status(404).json({ error: 'file not found' });
  try {
    fs.writeFileSync(full, String((req.body && req.body.content) || ''), 'utf8');
    const st = fs.statSync(full);
    res.json({ ok: true, size: st.size });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// GET /api/files/download?path=site/name → download any file under save location
router.get('/files/download', (req, res) => {
  const full = safeResolve(req.query.path);
  if (!full || !fs.existsSync(full)) return res.status(404).send('file not found');
  res.download(full);
});

module.exports = router;
