'use strict';

const $ = (id) => document.getElementById(id);
let jobId = null;
let pollTimer = null;
let tickTimer = null;
let batch = { startTs: null, limitMs: null, running: false, elapsedAtPoll: 0, polledAt: 0 };

$('form').addEventListener('submit', (e) => {
  e.preventDefault();
  start();
});

async function start() {
  const url = $('url').value.trim();
  const prompt = $('prompt').value.trim();
  setBadge('starting');
  $('phase').textContent = 'Submitting…';

  const res = await postJSON('/api/scrape', { url, prompt });

  if (res.status === 'need_info') {
    renderQuestions(res.questions);
    return;
  }
  if (res.error) {
    showPanel();
    $('phase').textContent = 'Error: ' + res.error;
    return;
  }
  if (res.status === 'started') {
    $('questions').classList.add('hidden');
    showPanel();
    $('planLine').textContent =
      `${res.plan.siteName} · ${res.plan.scrollStrategy} · ${res.plan.url}`;
    jobId = res.jobId;
    resetResult();
    startPolling();
  }
}

function renderQuestions(questions) {
  const box = $('questionList');
  box.innerHTML = '';
  questions.forEach((q, i) => {
    const wrap = document.createElement('div');
    wrap.className = 'qrow';
    const label = document.createElement('label');
    label.textContent = q;
    const input = document.createElement('input');
    input.id = `q_${i}`;
    label.appendChild(input);
    wrap.appendChild(label);
    box.appendChild(wrap);
  });
  const btn = document.createElement('button');
  btn.textContent = 'Continue';
  btn.onclick = () => {
    const answer = $('q_0') ? $('q_0').value.trim() : '';
    if (/^https?:\/\//i.test(answer)) $('url').value = answer;
    start();
  };
  box.appendChild(btn);
  $('questions').classList.remove('hidden');
}

function showPanel() {
  $('panel').classList.remove('hidden');
}

function startPolling() {
  clearInterval(pollTimer);
  clearInterval(tickTimer);
  pollTimer = setInterval(refresh, 1200);
  tickTimer = setInterval(tick, 250); // smooth local timer between polls
  refresh();
}

async function refresh() {
  if (!jobId) return;
  const s = await getJSON(`/api/status/${jobId}`);
  if (s.error) return;

  setBadge(s.state);
  $('phase').textContent = s.phase || '—';
  $('found').textContent = s.foundThisBatch ?? 0;
  $('saved').textContent = s.savedTotal ?? 0;

  batch = {
    startTs: s.batch.startTs,
    limitMs: s.batch.limitMs,
    running: s.batch.running,
    elapsedAtPoll: s.batch.elapsedMs || 0,
    polledAt: Date.now(),
  };
  renderTimer();
  renderFeed(s.events);

  // Controls: Stop always available while active; Finish while running;
  // Continue while awaiting a decision.
  const active = s.state === 'running' || s.state === 'awaiting';
  $('controls').classList.toggle('hidden', !active);
  $('finish').classList.toggle('hidden', s.state !== 'running');
  $('continueBtn').classList.toggle('hidden', s.state !== 'awaiting');

  // Error-recovery banner: only shown when a halting error paused the run.
  const banner = $('errorBanner');
  if (s.state === 'awaiting' && s.errorReason) {
    banner.textContent = `⚠ Something interrupted the run: ${s.errorReason} — Continue or Stop?`;
    banner.classList.remove('hidden');
  } else {
    banner.classList.add('hidden');
  }

  updateDownloads(s);
  renderHistory(s.batches);

  if (s.state === 'done' || s.state === 'error') {
    finishUp(s);
  }
}

function tick() {
  if (batch.running) renderTimer();
}

function renderTimer() {
  let elapsed = batch.elapsedAtPoll;
  if (batch.running && batch.polledAt) elapsed += Date.now() - batch.polledAt;
  const limit = batch.limitMs;
  const es = Math.max(0, Math.floor(elapsed / 1000));
  const ls = limit ? Math.floor(limit / 1000) : null;
  $('timer').textContent = ls != null ? `${es}s / ${ls}s` : `${es}s`;
  const pct = limit ? Math.min(100, (elapsed / limit) * 100) : 0;
  $('progressBar').style.width = pct + '%';
}

function renderFeed(events) {
  const lines = (events || []).map((e) => {
    const t = new Date(e.t).toLocaleTimeString();
    return `${t}  ${e.text}`;
  });
  const el = $('log');
  el.textContent = lines.join('\n');
  el.scrollTop = el.scrollHeight;
}

function updateDownloads(s) {
  // Both files exist from batch start; show buttons + live line counts.
  $('filteredCount').textContent = s.filteredLines ?? 0;
  $('rawCount').textContent = s.rawLines ?? 0;
  if (s.hasDownload) {
    $('download').href = `/api/download/${jobId}`;
    $('download').classList.remove('hidden');
  }
  if (s.hasRaw) {
    $('downloadRaw').href = `/api/download-raw/${jobId}`;
    $('downloadRaw').classList.remove('hidden');
  }
  // Reveal the result container as soon as files exist so downloads are reachable live.
  if (s.hasDownload || s.hasRaw) $('result').classList.remove('hidden');
}

function finishUp(s) {
  clearInterval(pollTimer);
  clearInterval(tickTimer);
  batch.running = false;
  $('controls').classList.add('hidden');
  $('result').classList.remove('hidden');
  if (s.state === 'error') {
    $('result').style.borderColor = 'var(--red)';
    $('resultMsg').textContent = `Stopped with error: ${s.error}`;
  } else {
    $('resultMsg').textContent =
      `Done — ${s.filteredLines ?? 0} filtered item(s), ${s.rawLines ?? 0} raw line(s).`;
  }
  $('resultFile').innerHTML = (s.lastFile ? `Filtered: ${s.lastFile}<br>` : '') +
    (s.rawFile ? `Raw: ${s.rawFile}` : '');
  updateDownloads(s);
}

function resetResult() {
  $('result').classList.add('hidden');
  $('download').classList.add('hidden');
  $('downloadRaw').classList.add('hidden');
  $('result').style.borderColor = '';
  $('log').textContent = '';
  $('found').textContent = '0';
  $('saved').textContent = '0';
  $('timer').textContent = '0s / —';
  $('progressBar').style.width = '0%';
}

// Control buttons
$('stop').onclick = () => sendControl('stop');
$('finish').onclick = () => sendControl('finish');
$('continueBtn').onclick = () => sendControl('continue');

async function sendControl(action) {
  if (!jobId) return;
  if (action === 'finish') $('finish').disabled = true;
  await postJSON(`/api/control/${jobId}`, { action });
  setTimeout(() => { $('finish').disabled = false; }, 1500);
  refresh();
}

function renderHistory(batches) {
  const box = $('history');
  if (!batches || !batches.length) {
    box.innerHTML = '<span class="muted">No completed batches yet.</span>';
    return;
  }
  box.innerHTML = batches
    .map((b) => {
      const filtered = b.hasFile
        ? `<a href="/api/download/${jobId}?batch=${b.batch}">Filtered (${b.filtered})</a>`
        : `Filtered (${b.filtered})`;
      const raw = b.hasRaw
        ? `<a href="/api/download-raw/${jobId}?batch=${b.batch}">Raw (${b.rawLines})</a>`
        : `Raw (${b.rawLines})`;
      return `<div class="hist-row"><span class="hist-batch">Batch ${b.batch}</span> ${filtered} · ${raw}</div>`;
    })
    .join('');
}

function setBadge(state) {
  const el = $('state');
  el.textContent = state;
  el.className = 'badge ' + (state || '');
}

async function postJSON(url, body) {
  const r = await fetch(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body),
  });
  return r.json();
}
async function getJSON(url) {
  const r = await fetch(url);
  return r.json();
}

// ===================== Tabs =====================
document.querySelectorAll('.tab-btn').forEach((btn) => {
  btn.addEventListener('click', () => switchTab(btn.dataset.tab));
});
function switchTab(name) {
  document.querySelectorAll('.tab-btn').forEach((b) => b.classList.toggle('active', b.dataset.tab === name));
  document.querySelectorAll('.tab').forEach((t) => t.classList.toggle('hidden', t.id !== 'tab-' + name));
  if (name === 'history') loadFiles();
  if (name === 'settings') loadSettings();
}

// ===================== Settings =====================
const MIN = 60000;
const round1 = (n) => Math.round(n * 10) / 10;

async function loadSettings() {
  const data = await getJSON('/api/settings');
  const s = data.settings;
  $('settingsPath').textContent = data.path;
  $('set_total').value = round1(s.totalRunMs / MIN);
  $('set_checkpoint').value = round1(s.checkpointMs / MIN);
  $('set_maxPages').value = s.maxPages;
  $('set_save').value = s.saveLocation;
  $('set_headless').checked = !!s.headless;
  $('set_deep').checked = !!s.deepCrawl;
  $('set_git').checked = !!s.gitSync;
}

$('settingsForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  const payload = {
    totalRunMs: Math.round(parseFloat($('set_total').value) * MIN),
    checkpointMs: Math.round(parseFloat($('set_checkpoint').value) * MIN),
    maxPages: parseInt($('set_maxPages').value, 10),
    saveLocation: $('set_save').value.trim(),
    headless: $('set_headless').checked,
    deepCrawl: $('set_deep').checked,
    gitSync: $('set_git').checked,
  };
  const res = await postJSON('/api/settings', payload);
  const msg = $('settingsMsg');
  if (res.ok) {
    msg.textContent = '✓ Settings saved';
    msg.className = 'settings-msg ok';
    setTimeout(() => { msg.textContent = ''; }, 4000);
  } else {
    msg.textContent = '✗ ' + (res.errors || ['error']).join('; ');
    msg.className = 'settings-msg err';
  }
});

$('resetSettings').addEventListener('click', async () => {
  await postJSON('/api/settings/reset', {});
  await loadSettings();
  const msg = $('settingsMsg');
  msg.textContent = 'Reset to defaults';
  msg.className = 'settings-msg ok';
  setTimeout(() => { msg.textContent = ''; }, 3000);
});

// ===================== History / Files =====================
$('refreshFiles').addEventListener('click', loadFiles);

async function loadFiles() {
  const box = $('fileList');
  box.innerHTML = '<span class="muted">Loading…</span>';
  const data = await getJSON('/api/files');
  $('historyBase').textContent = 'Location: ' + data.base;
  if (data.error) { box.innerHTML = `<span class="muted">Cannot read folder: ${data.error}</span>`; return; }
  if (!data.sites || !data.sites.length) { box.innerHTML = '<span class="muted">No files yet in this location.</span>'; return; }
  box.innerHTML = data.sites.map(renderSite).join('');
  box.querySelectorAll('[data-view]').forEach((a) =>
    a.addEventListener('click', (e) => { e.preventDefault(); viewFile(a.dataset.view); }));
}

function renderSite(site) {
  const rows = site.files.map((f) => `
    <tr>
      <td>${f.name}</td>
      <td><span class="tag ${f.type === 'RAW' ? 'raw' : 'filt'}">${f.type}</span></td>
      <td>${f.count}</td>
      <td>${fmtSize(f.size)}</td>
      <td>${new Date(f.mtime).toLocaleString()}</td>
      <td class="actions">
        <a href="/api/files/download?path=${encodeURIComponent(f.rel)}">Download</a>
        <a href="#" data-view="${encodeURIComponent(f.rel)}">View / Edit</a>
      </td>
    </tr>`).join('');
  return `<div class="site-group"><h3>${site.site}</h3>
    <table class="files"><thead><tr><th>File</th><th>Type</th><th>Count</th><th>Size</th><th>Modified</th><th></th></tr></thead>
    <tbody>${rows}</tbody></table></div>`;
}

function fmtSize(b) {
  if (b < 1024) return b + ' B';
  if (b < 1048576) return (b / 1024).toFixed(1) + ' KB';
  return (b / 1048576).toFixed(1) + ' MB';
}

let currentFile = null;
async function viewFile(relEnc) {
  const rel = decodeURIComponent(relEnc);
  const data = await getJSON('/api/files/view?path=' + encodeURIComponent(rel));
  if (data.error) { alert(data.error); return; }
  currentFile = rel;
  $('viewerName').textContent = rel;
  $('viewerText').value = data.content;
  $('viewerMsg').textContent = '';
  $('viewer').classList.remove('hidden');
  $('viewer').scrollIntoView({ behavior: 'smooth' });
}

$('viewerClose').addEventListener('click', () => $('viewer').classList.add('hidden'));
$('viewerSave').addEventListener('click', async () => {
  if (!currentFile) return;
  const res = await postJSON('/api/files/save', { path: currentFile, content: $('viewerText').value });
  const msg = $('viewerMsg');
  if (res.ok) { msg.textContent = '✓ Saved (' + fmtSize(res.size) + ')'; loadFiles(); }
  else msg.textContent = '✗ ' + (res.error || 'save failed');
});
