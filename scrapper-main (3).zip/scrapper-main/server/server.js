'use strict';

const path = require('path');
const net = require('net');
const { exec } = require('child_process');
const express = require('express');
const config = require('../src/config');
const scrapeRouter = require('./routes/scrape');
const settingsRouter = require('./routes/settings');
const filesRouter = require('./routes/files');

const app = express();
const START_PORT = Number(process.env.PORT) || 3000;
const AUTO_OPEN = String(process.env.AUTO_OPEN).toLowerCase() === 'true';

app.use(express.json({ limit: '5mb' })); // allow editing/saving larger files
app.use(express.static(path.join(__dirname, 'public')));
app.use('/api', scrapeRouter);
app.use('/api', settingsRouter);
app.use('/api', filesRouter);

app.get('/health', (_req, res) => res.json({ ok: true }));

/** Return the first free port >= start (tries up to 20 ports). */
function findFreePort(start, attempt = 0) {
  return new Promise((resolve, reject) => {
    if (attempt >= 20) return reject(new Error('no free port found near ' + start));
    const port = start + attempt;
    const tester = net.createServer();
    tester.once('error', () => { tester.close(); resolve(findFreePort(start, attempt + 1)); });
    tester.once('listening', () => tester.close(() => resolve(port)));
    tester.listen(port); // bind the same way app.listen does (all interfaces)
  });
}

/** Open a URL in the user's default browser, cross-platform. */
function openBrowser(url) {
  const cmd =
    process.platform === 'win32' ? `start "" "${url}"`
    : process.platform === 'darwin' ? `open "${url}"`
    : `xdg-open "${url}"`;
  process.stdout.write(`[launcher] opening browser: ${cmd}\n`);
  exec(cmd, (err) => {
    if (err) {
      process.stdout.write(`[launcher] could not auto-open the browser — please open ${url} manually.\n`);
    }
  });
}

(async () => {
  let port;
  try {
    port = await findFreePort(START_PORT);
  } catch {
    port = START_PORT;
  }
  const url = `http://localhost:${port}`;

  const server = app.listen(port, () => {
    const s = config.summary();
    process.stdout.write('\n=== AI Review Scraper — server starting ===\n');
    process.stdout.write('Resolved config (from .env / settings):\n');
    process.stdout.write(`  headless        : ${s.headless}\n`);
    process.stdout.write(`  total run       : ${s.totalRunMs} ms\n`);
    process.stdout.write(`  checkpoint      : ${s.checkpointMs} ms\n`);
    process.stdout.write(`  max pages       : ${s.maxPages}\n`);
    process.stdout.write(`  git sync        : ${s.gitSync} (${s.gitRemote}/${s.gitBranch})\n`);
    process.stdout.write(`  gemini model    : ${s.geminiModel}\n`);
    process.stdout.write(`  gemini key set  : ${s.geminiKeyPresent} (value never logged)\n`);

    if (port !== START_PORT) {
      process.stdout.write(`\n[launcher] Port ${START_PORT} was busy — using ${port} instead.\n`);
    }
    process.stdout.write(`\n────────────────────────────────────────────────────────\n`);
    process.stdout.write(`  ✅ Your scraper dashboard is ready!\n`);
    process.stdout.write(`  👉 ${url}\n`);
    if (AUTO_OPEN) {
      process.stdout.write(`  Opening it in your browser now…\n`);
    } else {
      process.stdout.write(`  Open that link in your browser (or run "npm run go" to auto-open).\n`);
    }
    process.stdout.write(`  In the page: type a website URL + what to extract, then click Start.\n`);
    process.stdout.write(`  Press Ctrl+C here to stop the server.\n`);
    process.stdout.write(`────────────────────────────────────────────────────────\n\n`);

    if (AUTO_OPEN) openBrowser(url);
  });

  server.on('error', (err) => {
    if (err && err.code === 'EADDRINUSE') {
      process.stdout.write(`\n[launcher] Port ${port} is already in use. Stop the other server (Ctrl+C in its window) or free the port, then try again.\n`);
    } else {
      process.stdout.write(`\n[launcher] Server error: ${err && err.message}\n`);
    }
    process.exit(1);
  });
})();
